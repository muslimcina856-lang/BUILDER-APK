package com.tweakx.android

import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Bridges typed tweak operations (brightness, animation scale, timeout,
 * device info) to CommandAllowlist + ShizukuCommandExecutor.
 *
 * This is the layer MainActivity's MethodChannel handler delegates to,
 * so MainActivity itself stays a thin router.
 */
class TweakBridge(private val windowManager: WindowManager) {

    fun getBrightness(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getBrightness()).toMap()

    fun setBrightness(value: Int): Map<String, Any> {
        return try {
            ShizukuCommandExecutor.execute(CommandAllowlist.setBrightness(value)).toMap()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            mapOf("success" to false, "exitCode" to -1, "stdout" to "", "stderr" to (e.message ?: "invalid input"))
        }
    }

    fun getScreenTimeout(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getScreenTimeout()).toMap()

    fun setScreenTimeout(valueMs: Int): Map<String, Any> {
        return try {
            ShizukuCommandExecutor.execute(CommandAllowlist.setScreenTimeout(valueMs)).toMap()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            mapOf("success" to false, "exitCode" to -1, "stdout" to "", "stderr" to (e.message ?: "invalid input"))
        }
    }

    fun getAnimationScale(setting: String): Map<String, Any> {
        val enumSetting = mapAnimationSetting(setting)
            ?: return mapOf("success" to false, "exitCode" to -1, "stdout" to "", "stderr" to "Unknown animation setting: $setting")
        return ShizukuCommandExecutor.execute(CommandAllowlist.getAnimationScale(enumSetting)).toMap()
    }

    fun setAnimationScale(setting: String, value: Double): Map<String, Any> {
        val enumSetting = mapAnimationSetting(setting)
            ?: return mapOf("success" to false, "exitCode" to -1, "stdout" to "", "stderr" to "Unknown animation setting: $setting")
        return try {
            ShizukuCommandExecutor.execute(CommandAllowlist.setAnimationScale(enumSetting, value)).toMap()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            mapOf("success" to false, "exitCode" to -1, "stdout" to "", "stderr" to (e.message ?: "invalid input"))
        }
    }

    private fun mapAnimationSetting(key: String): CommandAllowlist.AnimationSetting? {
        return when (key) {
            "window" -> CommandAllowlist.AnimationSetting.WINDOW
            "transition" -> CommandAllowlist.AnimationSetting.TRANSITION
            "animator" -> CommandAllowlist.AnimationSetting.ANIMATOR
            else -> null
        }
    }

    /**
     * Device info gathered from real Android APIs (Build.*, DisplayMetrics),
     * no Shizuku required — these are public, unprivileged APIs.
     */
    fun getDeviceInfo(): Map<String, Any> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        @Suppress("DEPRECATION")
        val refreshRate = windowManager.defaultDisplay.refreshRate

        return mapOf(
            "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
            "androidVersion" to Build.VERSION.RELEASE,
            "sdkInt" to Build.VERSION.SDK_INT,
            "cpuAbi" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
            "widthPx" to metrics.widthPixels,
            "heightPx" to metrics.heightPixels,
            "densityDpi" to metrics.densityDpi,
            "refreshRateHz" to refreshRate
        )
    }
}
