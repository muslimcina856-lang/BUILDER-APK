package com.tweakx.android

import android.os.Handler
import android.os.Looper
import java.util.regex.Pattern

/**
 * Polls the foreground app (via `dumpsys activity activities` through
 * Shizuku) to detect when a monitored game has been closed, then triggers
 * a revert callback.
 *
 * HONEST LIMITATION: There is no push-based "app closed" event available
 * to a non-root, non-accessibility-service app. This polls on an interval,
 * so there is an inherent detection delay (default 3s) between the game
 * actually closing and TweakX noticing. This is disclosed in the UI, not
 * hidden.
 */
class GameMonitor(private val gameBridge: GameBridge) {

    companion object {
        private const val POLL_INTERVAL_MS = 3000L

        // Matches the topResumedActivity / mResumedActivity package name
        // out of `dumpsys activity activities` output across common
        // Android versions.
        private val FOCUSED_PACKAGE_PATTERN = Pattern.compile(
            "(?:mResumedActivity|topResumedActivity).*?\\{[^}]*\\s([a-zA-Z0-9_.]+)/"
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private var monitoredPackage: String? = null
    private var onGameClosed: (() -> Unit)? = null
    private var running = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            checkForegroundApp()
            handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    fun start(packageName: String, onClosed: () -> Unit) {
        stop()
        monitoredPackage = packageName
        onGameClosed = onClosed
        running = true
        handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)
    }

    fun stop() {
        running = false
        monitoredPackage = null
        onGameClosed = null
        handler.removeCallbacks(pollRunnable)
    }

    private fun checkForegroundApp() {
        val target = monitoredPackage ?: return
        val result = ShizukuCommandExecutor.execute(CommandAllowlist.getForegroundApp())
        if (!result.success) {
            // If we can't read foreground state (e.g. Shizuku dropped),
            // stop monitoring rather than silently spinning forever.
            stop()
            return
        }
        val matcher = FOCUSED_PACKAGE_PATTERN.matcher(result.stdout)
        val foregroundPackage = if (matcher.find()) matcher.group(1) else null

        if (foregroundPackage != null && foregroundPackage != target) {
            val callback = onGameClosed
            stop()
            callback?.invoke()
        }
    }
}
