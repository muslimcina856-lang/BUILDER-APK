package com.tweakx.android

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import java.io.ByteArrayOutputStream

/**
 * Lists installed, launchable apps using the standard (non-privileged)
 * Android PackageManager API. This does NOT require Shizuku — querying
 * installed apps and their launcher icons is a normal unprivileged
 * operation.
 */
class AppListManager(private val context: Context) {

    data class AppEntry(
        val packageName: String,
        val label: String,
        val iconBase64: String?
    )

    /**
     * Returns every app that exposes a launcher activity (i.e. appears in
     * the device's app drawer), sorted alphabetically by label. This
     * intentionally does not filter by "is this a game" — Android has no
     * reliable cross-OEM way to detect that, so the user picks manually
     * via the Add Game flow, exactly as requested.
     */
    fun getLaunchableApps(): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        @Suppress("DEPRECATION")
        val resolvedApps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        return resolvedApps
            .distinctBy { it.activityInfo.packageName }
            .mapNotNull { resolveInfo ->
                try {
                    val appInfo: ApplicationInfo = resolveInfo.activityInfo.applicationInfo
                    val label = pm.getApplicationLabel(appInfo).toString()
                    val packageName = resolveInfo.activityInfo.packageName
                    val icon = try {
                        pm.getApplicationIcon(packageName)
                    } catch (t: Throwable) {
                        null
                    }
                    AppEntry(
                        packageName = packageName,
                        label = label,
                        iconBase64 = icon?.let { drawableToBase64(it) }
                    )
                } catch (t: Throwable) {
                    null
                }
            }
            .sortedBy { it.label.lowercase() }
    }

    fun getAppLabel(packageName: String): String? {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (t: Throwable) {
            null
        }
    }

    private fun drawableToBase64(drawable: Drawable): String? {
        return try {
            val size = 128
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, size, size)
            drawable.draw(canvas)

            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream)
            android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
        } catch (t: Throwable) {
            null
        }
    }
}
