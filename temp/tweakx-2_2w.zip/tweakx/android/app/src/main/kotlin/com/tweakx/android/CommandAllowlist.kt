package com.tweakx.android

/**
 * Single source of truth for every privileged command TweakX is allowed to
 * run. Per project security requirements, TweakX never exposes free-form
 * command execution to Flutter/users as a primary feature — every command
 * that reaches ShizukuCommandExecutor is built here from typed inputs,
 * never from raw user strings.
 *
 * All values are validated (see validate* functions) before a command
 * is constructed, so out-of-range input never reaches the shell.
 */
object CommandAllowlist {

    class InvalidTweakInputException(message: String) : IllegalArgumentException(message)

    // ---- Brightness (0-255) ----
    fun getBrightness(): List<String> =
        listOf("settings", "get", "system", "screen_brightness")

    fun setBrightness(value: Int): List<String> {
        if (value !in 0..255) {
            throw InvalidTweakInputException("Brightness must be between 0 and 255")
        }
        return listOf("settings", "put", "system", "screen_brightness", value.toString())
    }

    // ---- Screen timeout (milliseconds) ----
    private val ALLOWED_TIMEOUTS_MS = setOf(15_000, 30_000, 60_000, 300_000, 600_000)

    fun getScreenTimeout(): List<String> =
        listOf("settings", "get", "system", "screen_off_timeout")

    fun setScreenTimeout(valueMs: Int): List<String> {
        if (valueMs !in ALLOWED_TIMEOUTS_MS) {
            throw InvalidTweakInputException(
                "Screen timeout must be one of $ALLOWED_TIMEOUTS_MS milliseconds"
            )
        }
        return listOf("settings", "put", "system", "screen_off_timeout", valueMs.toString())
    }

    // ---- Animation scale (window / transition / animator) ----
    private val ALLOWED_ANIMATION_SCALES = setOf(0.0, 0.5, 1.0, 1.5, 2.0)

    enum class AnimationSetting(val key: String) {
        WINDOW("window_animation_scale"),
        TRANSITION("transition_animation_scale"),
        ANIMATOR("animator_duration_scale")
    }

    fun getAnimationScale(setting: AnimationSetting): List<String> =
        listOf("settings", "get", "global", setting.key)

    fun setAnimationScale(setting: AnimationSetting, value: Double): List<String> {
        if (value !in ALLOWED_ANIMATION_SCALES) {
            throw InvalidTweakInputException(
                "Animation scale must be one of $ALLOWED_ANIMATION_SCALES"
            )
        }
        return listOf("settings", "put", "global", setting.key, value.toString())
    }

    // ---- Read-only device / display info commands ----
    fun getRefreshRate(): List<String> =
        listOf("dumpsys", "display")

    fun getDensity(): List<String> =
        listOf("wm", "density")

    // ---- Resolution (wm size) ----
    fun getResolution(): List<String> = listOf("wm", "size")

    fun setResolution(width: Int, height: Int): List<String> {
        if (width !in 480..7680 || height !in 480..7680) {
            throw InvalidTweakInputException("Resolution out of supported range")
        }
        return listOf("wm", "size", "${width}x${height}")
    }

    fun resetResolution(): List<String> = listOf("wm", "size", "reset")

    // ---- DPI (wm density) ----
    fun setDpi(dpi: Int): List<String> {
        if (dpi !in 120..640) {
            throw InvalidTweakInputException("DPI must be between 120 and 640")
        }
        return listOf("wm", "density", dpi.toString())
    }

    fun resetDpi(): List<String> = listOf("wm", "density", "reset")

    // ---- Refresh rate / FPS (peak & min refresh rate, Android 11+) ----
    private val ALLOWED_REFRESH_RATES = setOf(30, 60, 90, 120, 144)

    fun getPeakRefreshRate(): List<String> =
        listOf("settings", "get", "system", "peak_refresh_rate")

    fun setPeakRefreshRate(hz: Int): List<String> {
        if (hz !in ALLOWED_REFRESH_RATES) {
            throw InvalidTweakInputException(
                "Refresh rate must be one of $ALLOWED_REFRESH_RATES"
            )
        }
        return listOf("settings", "put", "system", "peak_refresh_rate", hz.toString())
    }

    fun resetPeakRefreshRate(): List<String> =
        listOf("settings", "delete", "system", "peak_refresh_rate")

    // ---- Touch sampling: exposed as read-only info; no universal setter exists ----
    fun getTouchSampleRateInfo(): List<String> =
        listOf("dumpsys", "input")

    // ---- Thermal status: read-only, no universal cross-OEM "set profile" exists ----
    fun getThermalStatus(): List<String> =
        listOf("dumpsys", "thermalservice")

    // ---- Foreground app detection, used for auto-revert-on-close monitoring ----
    fun getForegroundApp(): List<String> =
        listOf("dumpsys", "activity", "activities")

    // ---- Launch an app by package name (used by Save & Launch) ----
    fun launchApp(packageName: String): List<String> {
        if (!packageName.matches(Regex("^[a-zA-Z0-9_.]+$"))) {
            throw InvalidTweakInputException("Invalid package name")
        }
        return listOf(
            "monkey", "-p", packageName,
            "-c", "android.intent.category.LAUNCHER", "1"
        )
    }
}
