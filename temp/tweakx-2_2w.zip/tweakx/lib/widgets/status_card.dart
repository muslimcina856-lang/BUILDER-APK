import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/shizuku_status.dart';

class StatusCard extends StatelessWidget {
  final ShizukuStatus status;
  final VoidCallback onRefresh;
  final VoidCallback onRequestPermission;
  final bool isRequesting;

  const StatusCard({
    super.key,
    required this.status,
    required this.onRefresh,
    required this.onRequestPermission,
    this.isRequesting = false,
  });

  Color get _dotColor {
    switch (status.state) {
      case ShizukuState.permissionGranted:
        return AppTheme.accent;
      case ShizukuState.availableNoPermission:
        return const Color(0xFFFFC107);
      case ShizukuState.unavailable:
      case ShizukuState.legacyUnsupported:
      case ShizukuState.unknown:
        return AppTheme.error;
    }
  }

  String get _title {
    switch (status.state) {
      case ShizukuState.permissionGranted:
        return 'Shizuku Running';
      case ShizukuState.availableNoPermission:
        return 'Shizuku Running';
      case ShizukuState.unavailable:
        return 'Shizuku Not Available';
      case ShizukuState.legacyUnsupported:
        return 'Shizuku Version Unsupported';
      case ShizukuState.unknown:
        return 'Shizuku Status Unknown';
    }
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: _dotColor,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _dotColor.withValues(alpha: 0.5),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _title,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: onRefresh,
                    icon: const Icon(Icons.refresh_rounded, size: 20),
                    color: AppTheme.textSecondary,
                    tooltip: 'Refresh Status',
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                status.humanMessage,
                style: const TextStyle(
                  fontSize: 13.5,
                  color: AppTheme.textSecondary,
                  height: 1.4,
                ),
              ),
              if (status.available && status.apiVersion > 0) ...[
                const SizedBox(height: 6),
                Text(
                  'Shizuku API v${status.apiVersion}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
              if (status.state == ShizukuState.availableNoPermission) ...[
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: isRequesting ? null : onRequestPermission,
                    child: isRequesting
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.black,
                            ),
                          )
                        : const Text('Request Permission'),
                  ),
                ),
              ],
              if (status.state == ShizukuState.unavailable) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceVariant,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline_rounded,
                          size: 16, color: AppTheme.textSecondary),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Shizuku allows this app to perform selected Android operations without root access.',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    ));
  }
}
