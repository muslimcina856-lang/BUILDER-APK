/// Mirrors the allowlisted values defined natively in
/// android/.../CommandAllowlist.kt. Keeping these in sync means the UI never
/// offers a value the native layer would reject.
class TweakOptions {
  TweakOptions._();

  static const List<double> animationScales = [0.0, 0.5, 1.0, 1.5, 2.0];

  static const Map<int, String> screenTimeouts = {
    15000: '15 seconds',
    30000: '30 seconds',
    60000: '1 minute',
    300000: '5 minutes',
    600000: '10 minutes',
  };

  static const int brightnessMin = 0;
  static const int brightnessMax = 255;

  static const List<int> refreshRates = [30, 60, 90, 120, 144];

  static const List<Map<String, int>> resolutions = [
    {'width': 1280, 'height': 720},
    {'width': 1600, 'height': 900},
    {'width': 1920, 'height': 1080},
    {'width': 2340, 'height': 1080},
  ];

  static const List<int> dpiOptions = [280, 320, 360, 400, 440, 480];
}
