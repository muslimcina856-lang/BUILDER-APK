/// Central place for MethodChannel / EventChannel names so Dart and Kotlin
/// sides never drift out of sync silently.
class Channels {
  Channels._();

  static const String shizuku = 'com.tweakx.android/shizuku';
  static const String tweak = 'com.tweakx.android/tweak';
  static const String device = 'com.tweakx.android/device';
  static const String shizukuEvents = 'com.tweakx.android/shizuku_events';
  static const String apps = 'com.tweakx.android/apps';
  static const String game = 'com.tweakx.android/game';
  static const String gameEvents = 'com.tweakx.android/game_events';
}
