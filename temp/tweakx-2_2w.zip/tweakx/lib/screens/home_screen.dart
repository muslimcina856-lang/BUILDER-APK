import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/game_profile.dart';
import '../models/installed_app.dart';
import '../models/shizuku_status.dart';
import '../services/game_storage_service.dart';
import '../services/shizuku_service.dart';
import '../widgets/status_card.dart';
import 'add_game_screen.dart';
import 'game_detail_screen.dart';
import 'shizuku_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _shizuku = ShizukuService.instance;
  final _storage = GameStorageService.instance;

  ShizukuStatus _status = ShizukuStatus.initial();
  bool _loadingStatus = true;
  List<GameProfile> _games = [];
  bool _loadingGames = true;

  @override
  void initState() {
    super.initState();
    _shizuku.statusStream.listen((status) {
      if (!mounted) return;
      setState(() {
        _status = status;
        _loadingStatus = false;
      });
    });
    _init();
  }

  Future<void> _init() async {
    final status = await _shizuku.getStatus();
    final games = await _storage.loadGames();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loadingStatus = false;
      _games = games;
      _loadingGames = false;
    });
  }

  Future<void> _refreshStatus() async {
    setState(() => _loadingStatus = true);
    final status = await _shizuku.getStatus();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loadingStatus = false;
    });
  }

  Future<void> _reloadGames() async {
    final games = await _storage.loadGames();
    if (!mounted) return;
    setState(() => _games = games);
  }

  Future<void> _addGame() async {
    final existingPackages = _games.map((g) => g.packageName).toSet();
    final picked = await Navigator.of(context).push<InstalledApp>(
      MaterialPageRoute(
        builder: (_) => AddGameScreen(alreadyAddedPackages: existingPackages),
      ),
    );
    if (picked == null) return;

    final profile = GameProfile(
      packageName: picked.packageName,
      label: picked.label,
      iconBase64: picked.iconBase64,
    );
    await _storage.addOrUpdateGame(profile);
    await _reloadGames();

    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GameDetailScreen(profile: profile)),
    );
    await _reloadGames();
  }

  Future<void> _openGame(GameProfile profile) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GameDetailScreen(profile: profile)),
    );
    await _reloadGames();
  }

  Future<void> _removeGame(GameProfile profile) async {
    await _storage.removeGame(profile.packageName);
    await _reloadGames();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('TweakX'),
            Text(
              'By F@riiik',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addGame,
        backgroundColor: AppTheme.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add Game',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await _refreshStatus();
          await _reloadGames();
        },
        color: AppTheme.accent,
        backgroundColor: AppTheme.surface,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ShizukuScreen()),
              ),
              child: AbsorbPointer(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: _loadingStatus
                      ? const Padding(
                          padding: EdgeInsets.symmetric(vertical: 24),
                          child: Center(
                            child:
                                CircularProgressIndicator(color: AppTheme.accent),
                          ),
                        )
                      : StatusCard(
                          status: _status,
                          onRefresh: _refreshStatus,
                          onRequestPermission: () {},
                        ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Padding(
                  padding: EdgeInsets.only(left: 4),
                  child: Text(
                    'My Games',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textSecondary,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                if (_games.isNotEmpty)
                  Text(
                    '${_games.length}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: _loadingGames
                  ? const Padding(
                      key: ValueKey('loading'),
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Center(
                        child: CircularProgressIndicator(color: AppTheme.accent),
                      ),
                    )
                  : _games.isEmpty
                      ? const _EmptyGamesState(key: ValueKey('empty'))
                      : ListView.builder(
                          key: const ValueKey('list'),
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _games.length,
                          itemBuilder: (context, index) {
                            final game = _games[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: _GameCard(
                                profile: game,
                                onTap: () => _openGame(game),
                                onRemove: () => _removeGame(game),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyGamesState extends StatelessWidget {
  const _EmptyGamesState({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 24),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.accent.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.videogame_asset_outlined,
                color: AppTheme.accent, size: 32),
          ),
          const SizedBox(height: 16),
          const Text(
            'No games added yet',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tap "Add Game" to pick an installed game and configure its resolution, DPI, refresh rate, and more.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12.5,
              color: AppTheme.textSecondary,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _GameCard extends StatelessWidget {
  final GameProfile profile;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _GameCard({
    required this.profile,
    required this.onTap,
    required this.onRemove,
  });

  Widget _icon() {
    if (profile.iconBase64 != null) {
      try {
        final bytes = base64Decode(profile.iconBase64!);
        return ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Image.memory(
            bytes,
            width: 52,
            height: 52,
            fit: BoxFit.cover,
            cacheWidth: 160,
            cacheHeight: 160,
          ),
        );
      } catch (_) {
        // fall through
      }
    }
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariant,
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Icon(Icons.videogame_asset_outlined,
          color: AppTheme.textSecondary, size: 24),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Card(
        child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        onLongPress: () => _confirmRemove(context),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              _icon(),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile.label,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      profile.hasAnyCustomSetting
                          ? 'Custom settings configured'
                          : 'No custom settings yet',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: profile.hasAnyCustomSetting
                            ? AppTheme.accent
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: AppTheme.textSecondary),
            ],
          ),
        ),
      ),
      ),
    );
  }

  void _confirmRemove(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Remove game?',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: Text(
          'This removes ${profile.label} and its saved settings from TweakX. The app itself will not be uninstalled.',
          style: const TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              onRemove();
            },
            child: const Text('Remove',
                style: TextStyle(color: AppTheme.error)),
          ),
        ],
      ),
    );
  }
}
