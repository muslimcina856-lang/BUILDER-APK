import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/constants/tweak_options.dart';
import '../core/theme/app_theme.dart';
import '../models/game_profile.dart';
import '../services/game_service.dart';
import '../services/game_storage_service.dart';
import '../widgets/tweak_card.dart';

class GameDetailScreen extends StatefulWidget {
  final GameProfile profile;

  const GameDetailScreen({super.key, required this.profile});

  @override
  State<GameDetailScreen> createState() => _GameDetailScreenState();
}

class _GameDetailScreenState extends State<GameDetailScreen> {
  final _service = GameService.instance;
  final _storage = GameStorageService.instance;

  late GameProfile _profile;
  bool _saving = false;
  String? _thermalInfo;
  String? _touchInfo;
  bool _loadingReadOnlyInfo = true;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    _loadReadOnlyInfo();
  }

  Future<void> _loadReadOnlyInfo() async {
    final thermal = await _service.getThermalStatus();
    final touch = await _service.getTouchInfo();
    if (!mounted) return;
    setState(() {
      _thermalInfo = thermal.success
          ? _summarizeThermal(thermal.stdout)
          : thermal.humanError;
      _touchInfo =
          touch.success ? _summarizeTouch(touch.stdout) : touch.humanError;
      _loadingReadOnlyInfo = false;
    });
  }

  String _summarizeThermal(String raw) {
    // dumpsys thermalservice output is verbose; surface just the current
    // status line if present, otherwise a short honest fallback.
    final match = RegExp(r'mStatus\s*=\s*(\d+)').firstMatch(raw);
    if (match != null) {
      const labels = {
        '0': 'None',
        '1': 'Light',
        '2': 'Moderate',
        '3': 'Severe',
        '4': 'Critical',
        '5': 'Emergency',
        '6': 'Shutdown',
      };
      final level = labels[match.group(1)] ?? 'Unknown';
      return 'Current thermal level: $level';
    }
    return raw.isEmpty ? 'No thermal data available' : 'Status read from device';
  }

  String _summarizeTouch(String raw) {
    return raw.isEmpty
        ? 'No touch data available'
        : 'Touch input service is active';
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Settings saved')),
    );
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);

    final errors = <String>[];

    if (_profile.resolutionWidth != null && _profile.resolutionHeight != null) {
      final r = await _service.setResolution(
          _profile.resolutionWidth!, _profile.resolutionHeight!);
      if (!r.success) errors.add('Resolution: ${r.humanError}');
    }
    if (_profile.dpi != null) {
      final r = await _service.setDpi(_profile.dpi!);
      if (!r.success) errors.add('DPI: ${r.humanError}');
    }
    if (_profile.refreshRateHz != null) {
      final r = await _service.setPeakRefreshRate(_profile.refreshRateHz!);
      if (!r.success) errors.add('Refresh rate: ${r.humanError}');
    }
    if (_profile.brightness != null) {
      final r = await _service.setBrightness(_profile.brightness!);
      if (!r.success) errors.add('Brightness: ${r.humanError}');
    }
    if (_profile.animationScale != null) {
      for (final setting in ['window', 'transition', 'animator']) {
        final r = await _service.setAnimationScale(
            setting, _profile.animationScale!);
        if (!r.success) {
          errors.add('Animation: ${r.humanError}');
          break;
        }
      }
    }

    final launchResult = await _service.launchApp(_profile.packageName);
    if (!launchResult.success) {
      errors.add('Launch: ${launchResult.humanError}');
    } else {
      // Only monitor for auto-revert if settings were actually applied
      // and the launch itself succeeded.
      if (_profile.hasAnyCustomSetting) {
        await _service.startMonitoring(_profile.packageName);
        _listenForGameClose();
      }
    }

    if (!mounted) return;
    setState(() => _saving = false);

    if (errors.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errors.join(' • '))),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${_profile.label} launched')),
      );
    }
  }

  void _listenForGameClose() {
    _service.onGameClosed.first.then((closedPackage) async {
      if (closedPackage != _profile.packageName) return;
      // Auto-revert to system defaults.
      if (_profile.resolutionWidth != null) {
        await _service.resetResolution();
      }
      if (_profile.dpi != null) {
        await _service.resetDpi();
      }
      if (_profile.refreshRateHz != null) {
        await _service.resetPeakRefreshRate();
      }
      // Brightness and animation scale are left as-is on revert since
      // there is no single universal "default" value to restore them to
      // without having recorded it beforehand; resolution/DPI have an
      // explicit `reset` command that restores the true hardware default.
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_profile.label, overflow: TextOverflow.ellipsis),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          RepaintBoundary(child: _Header(profile: _profile)),
          const SizedBox(height: 20),
          const _SectionLabel('Display'),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.aspect_ratio_outlined,
            title: 'Resolution',
            description: 'Rendering resolution for this game',
            currentValueLabel: _profile.resolutionWidth != null
                ? '${_profile.resolutionWidth}×${_profile.resolutionHeight}'
                : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.resolutions.map((res) {
                final selected = _profile.resolutionWidth == res['width'] &&
                    _profile.resolutionHeight == res['height'];
                return ChoiceChip(
                  label: Text('${res['width']}×${res['height']}'),
                  selected: selected,
                  onSelected: (_) => setState(() {
                    _profile = _profile.copyWith(
                      resolutionWidth: res['width'],
                      resolutionHeight: res['height'],
                    );
                  }),
                  selectedColor: AppTheme.accent,
                  backgroundColor: AppTheme.surfaceVariant,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppTheme.textSecondary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  side: BorderSide.none,
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.grid_on_outlined,
            title: 'DPI',
            description: 'Screen density for this game',
            currentValueLabel: _profile.dpi != null ? '${_profile.dpi}' : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.dpiOptions.map((dpi) {
                final selected = _profile.dpi == dpi;
                return ChoiceChip(
                  label: Text('$dpi'),
                  selected: selected,
                  onSelected: (_) =>
                      setState(() => _profile = _profile.copyWith(dpi: dpi)),
                  selectedColor: AppTheme.accent,
                  backgroundColor: AppTheme.surfaceVariant,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppTheme.textSecondary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  side: BorderSide.none,
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.speed_outlined,
            title: 'Refresh Rate / FPS',
            description: 'Peak display refresh rate for this game',
            currentValueLabel: _profile.refreshRateHz != null
                ? '${_profile.refreshRateHz} Hz'
                : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.refreshRates.map((hz) {
                final selected = _profile.refreshRateHz == hz;
                return ChoiceChip(
                  label: Text('${hz}Hz'),
                  selected: selected,
                  onSelected: (_) => setState(
                      () => _profile = _profile.copyWith(refreshRateHz: hz)),
                  selectedColor: AppTheme.accent,
                  backgroundColor: AppTheme.surfaceVariant,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppTheme.textSecondary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  side: BorderSide.none,
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.brightness_6_outlined,
            title: 'Brightness',
            description: 'Screen brightness for this game',
            control: _BrightnessControl(
              value: _profile.brightness,
              onChanged: (value) {
                if (!mounted) return;
                setState(() => _profile = _profile.copyWith(brightness: value));
              },
            ),
          ),
          const SizedBox(height: 24),
          const _SectionLabel('Performance'),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.animation_outlined,
            title: 'Animation Scale',
            description: 'System animation speed while playing',
            currentValueLabel: _profile.animationScale != null
                ? '${_profile.animationScale}x'
                : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.animationScales.map((scale) {
                final selected = _profile.animationScale == scale;
                return ChoiceChip(
                  label: Text('${scale}x'),
                  selected: selected,
                  onSelected: (_) => setState(
                      () => _profile = _profile.copyWith(animationScale: scale)),
                  selectedColor: AppTheme.accent,
                  backgroundColor: AppTheme.surfaceVariant,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppTheme.textSecondary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  side: BorderSide.none,
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.thermostat_outlined,
            title: 'Thermal Status',
            subtitle:
                'Read-only — Android has no universal API to force a thermal profile across devices',
            value: _loadingReadOnlyInfo ? null : _thermalInfo,
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.touch_app_outlined,
            title: 'Touch Input',
            subtitle:
                'Read-only — no universal touch-sampling setter exists via Shizuku',
            value: _loadingReadOnlyInfo ? null : _touchInfo,
          ),
          if (_profile.hasAnyCustomSetting) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      size: 16, color: AppTheme.textSecondary),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Resolution and DPI automatically revert to system defaults a few seconds after this game closes.',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _saving ? null : _save,
                  child: const Text('Save'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: FilledButton.icon(
                  onPressed: _saving ? null : _saveAndLaunch,
                  icon: _saving
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.black,
                          ),
                        )
                      : const Icon(Icons.play_arrow_rounded, size: 20),
                  label: Text(_saving ? 'Applying...' : 'Save & Launch'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _BrightnessControl extends StatefulWidget {
  final int? value;
  final ValueChanged<int> onChanged;

  const _BrightnessControl({required this.value, required this.onChanged});

  @override
  State<_BrightnessControl> createState() => _BrightnessControlState();
}

class _BrightnessControlState extends State<_BrightnessControl> {
  late double _value;

  @override
  void initState() {
    super.initState();
    _value = (widget.value ?? 128)
        .clamp(TweakOptions.brightnessMin, TweakOptions.brightnessMax)
        .toDouble();
  }

  @override
  void didUpdateWidget(covariant _BrightnessControl oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value && widget.value != null) {
      _value = widget.value!.clamp(
        TweakOptions.brightnessMin,
        TweakOptions.brightnessMax,
      ).toDouble();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Slider(
            value: _value,
            min: TweakOptions.brightnessMin.toDouble(),
            max: TweakOptions.brightnessMax.toDouble(),
            onChanged: (value) => setState(() => _value = value),
            onChangeEnd: (value) => widget.onChanged(value.round()),
          ),
        ),
        SizedBox(
          width: 42,
          child: Text(
            _value.round().toString(),
            textAlign: TextAlign.end,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppTheme.accent,
            ),
          ),
        ),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  final GameProfile profile;
  const _Header({required this.profile});

  @override
  Widget build(BuildContext context) {
    Widget icon;
    if (profile.iconBase64 != null) {
      try {
        final bytes = base64Decode(profile.iconBase64!);
        icon = ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.memory(bytes, width: 56, height: 56, fit: BoxFit.cover, cacheWidth: 176, cacheHeight: 176),
        );
      } catch (_) {
        icon = _fallbackIcon();
      }
    } else {
      icon = _fallbackIcon();
    }

    return Row(
      children: [
        icon,
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                profile.label,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                profile.packageName,
                style: const TextStyle(
                  fontSize: 11.5,
                  color: AppTheme.textSecondary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _fallbackIcon() => Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.videogame_asset_outlined,
            color: AppTheme.textSecondary, size: 26),
      );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          color: AppTheme.textSecondary,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _ReadOnlyInfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? value;

  const _ReadOnlyInfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppTheme.textSecondary, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  value == null
                      ? const SizedBox(
                          height: 14,
                          width: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.accent,
                          ),
                        )
                      : Text(
                          value!,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.accent,
                          ),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
