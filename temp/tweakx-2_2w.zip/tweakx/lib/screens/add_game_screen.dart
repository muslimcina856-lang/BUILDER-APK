import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/installed_app.dart';
import '../services/app_list_service.dart';

/// Lets the user pick an installed app to add as a game profile.
/// Returns the picked InstalledApp via Navigator.pop, or null if cancelled.
class AddGameScreen extends StatefulWidget {
  final Set<String> alreadyAddedPackages;

  const AddGameScreen({super.key, required this.alreadyAddedPackages});

  @override
  State<AddGameScreen> createState() => _AddGameScreenState();
}

class _AddGameScreenState extends State<AddGameScreen> {
  final _service = AppListService.instance;
  List<InstalledApp> _allApps = [];
  List<InstalledApp> _filtered = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final apps = await _service.getLaunchableApps();
    if (!mounted) return;
    setState(() {
      _allApps = apps;
      _filtered = apps;
      _loading = false;
    });
  }

  void _onSearch(String query) {
    setState(() {
      _query = query;
      final q = query.toLowerCase();
      _filtered = _allApps
          .where((a) =>
              a.label.toLowerCase().contains(q) ||
              a.packageName.toLowerCase().contains(q))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Game'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              onChanged: _onSearch,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: InputDecoration(
                hintText: 'Search installed apps',
                hintStyle: const TextStyle(color: AppTheme.textSecondary),
                prefixIcon:
                    const Icon(Icons.search_rounded, color: AppTheme.textSecondary),
                filled: true,
                fillColor: AppTheme.surfaceVariant,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.accent),
                  )
                : _filtered.isEmpty
                    ? Center(
                        child: Text(
                          _query.isEmpty
                              ? 'No apps found on this device'
                              : 'No apps match "$_query"',
                          style: const TextStyle(color: AppTheme.textSecondary),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 24),
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final app = _filtered[index];
                          final alreadyAdded = widget.alreadyAddedPackages
                              .contains(app.packageName);
                          return ListTile(
                            leading: _AppIcon(app: app),
                            title: Text(
                              app.label,
                              style: const TextStyle(
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w600,
                                fontSize: 14.5,
                              ),
                            ),
                            subtitle: Text(
                              app.packageName,
                              style: const TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 11.5,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: alreadyAdded
                                ? const Icon(Icons.check_circle_rounded,
                                    color: AppTheme.accent, size: 20)
                                : const Icon(Icons.add_circle_outline_rounded,
                                    color: AppTheme.textSecondary, size: 20),
                            onTap: alreadyAdded
                                ? null
                                : () => Navigator.of(context).pop(app),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _AppIcon extends StatelessWidget {
  final InstalledApp app;
  const _AppIcon({required this.app});

  @override
  Widget build(BuildContext context) {
    if (app.iconBase64 != null) {
      try {
        final bytes = base64Decode(app.iconBase64!);
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.memory(bytes, width: 40, height: 40, fit: BoxFit.cover, cacheWidth: 128, cacheHeight: 128),
        );
      } catch (_) {
        // fall through to placeholder
      }
    }
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariant,
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Icon(Icons.videogame_asset_outlined,
          color: AppTheme.textSecondary, size: 20),
    );
  }
}
