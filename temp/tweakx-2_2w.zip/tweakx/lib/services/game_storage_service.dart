import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/game_profile.dart';

/// Persists the user's manually-added game list + per-game settings on
/// device using SharedPreferences (real local storage, not in-memory only —
/// profiles survive app restarts).
class GameStorageService {
  GameStorageService._internal();

  static final GameStorageService instance = GameStorageService._internal();

  static const String _storageKey = 'tweakx.game_profiles.v1';

  Future<List<GameProfile>> loadGames() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => GameProfile.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveGames(List<GameProfile> games) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(games.map((g) => g.toJson()).toList());
    await prefs.setString(_storageKey, raw);
  }

  Future<void> addOrUpdateGame(GameProfile profile) async {
    final games = await loadGames();
    final index =
        games.indexWhere((g) => g.packageName == profile.packageName);
    if (index >= 0) {
      games[index] = profile;
    } else {
      games.add(profile);
    }
    await saveGames(games);
  }

  Future<void> removeGame(String packageName) async {
    final games = await loadGames();
    games.removeWhere((g) => g.packageName == packageName);
    await saveGames(games);
  }
}
