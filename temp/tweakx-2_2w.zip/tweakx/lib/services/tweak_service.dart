import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/command_result.dart';
import '../models/device_info.dart';

/// Wraps tweak/* and device/* MethodChannel calls. Every method returns a
/// real CommandResult produced by the native ShizukuCommandExecutor —
/// nothing here is simulated.
class TweakService {
  TweakService._internal();

  static final TweakService instance = TweakService._internal();

  static const MethodChannel _tweakChannel = MethodChannel(Channels.tweak);
  static const MethodChannel _deviceChannel = MethodChannel(Channels.device);

  Future<CommandResult> getBrightness() => _invokeTweak('getBrightness');

  Future<CommandResult> setBrightness(int value) =>
      _invokeTweak('setBrightness', {'value': value});

  Future<CommandResult> getScreenTimeout() => _invokeTweak('getScreenTimeout');

  Future<CommandResult> setScreenTimeout(int valueMs) =>
      _invokeTweak('setScreenTimeout', {'valueMs': valueMs});

  Future<CommandResult> getAnimationScale(String setting) =>
      _invokeTweak('getAnimationScale', {'setting': setting});

  Future<CommandResult> setAnimationScale(String setting, double value) =>
      _invokeTweak('setAnimationScale', {'setting': setting, 'value': value});

  Future<DeviceInfo?> getDeviceInfo() async {
    try {
      final result = await _deviceChannel.invokeMethod('getInfo');
      return DeviceInfo.fromMap(Map<dynamic, dynamic>.from(result as Map));
    } on PlatformException {
      return null;
    }
  }

  Future<CommandResult> _invokeTweak(
    String method, [
    Map<String, dynamic>? args,
  ]) async {
    try {
      final result = await _tweakChannel.invokeMethod(method, args);
      return CommandResult.fromMap(Map<dynamic, dynamic>.from(result as Map));
    } on PlatformException catch (e) {
      return CommandResult.failure(e.message ?? 'Platform error: $method');
    } on MissingPluginException {
      return CommandResult.failure('Native handler not available for $method');
    }
  }
}
