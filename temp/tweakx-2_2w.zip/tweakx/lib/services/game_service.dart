import 'dart:async';
import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/command_result.dart';

/// Wraps game/* MethodChannel calls (resolution, DPI, refresh rate,
/// thermal/touch read-only info, brightness/animation reuse, launch) plus
/// the game_events EventChannel used to detect when a monitored game closes.
///
/// Every method here crosses into GameBridge.kt / GameMonitor.kt on the
/// native side — nothing is simulated.
class GameService {
  GameService._internal() {
    _gameClosedController = StreamController<String>.broadcast();
    _eventChannel.receiveBroadcastStream().listen((event) {
      final map = Map<dynamic, dynamic>.from(event as Map);
      if (map['event'] == 'gameClosed') {
        final pkg = map['packageName'] as String? ?? '';
        _gameClosedController.add(pkg);
      }
    }, onError: (_) {});
  }

  static final GameService instance = GameService._internal();

  static const MethodChannel _channel = MethodChannel(Channels.game);
  static const EventChannel _eventChannel = EventChannel(Channels.gameEvents);

  late final StreamController<String> _gameClosedController;

  /// Emits the package name of a monitored game whenever native detects
  /// the foreground app changed away from it (poll-based, ~3s latency —
  /// see GameMonitor.kt for why there's no instant push event).
  Stream<String> get onGameClosed => _gameClosedController.stream;

  Future<CommandResult> getResolution() => _invoke('getResolution');

  Future<CommandResult> setResolution(int width, int height) =>
      _invoke('setResolution', {'width': width, 'height': height});

  Future<CommandResult> resetResolution() => _invoke('resetResolution');

  Future<CommandResult> setDpi(int dpi) => _invoke('setDpi', {'dpi': dpi});

  Future<CommandResult> resetDpi() => _invoke('resetDpi');

  Future<CommandResult> getPeakRefreshRate() => _invoke('getPeakRefreshRate');

  Future<CommandResult> setPeakRefreshRate(int hz) =>
      _invoke('setPeakRefreshRate', {'hz': hz});

  Future<CommandResult> resetPeakRefreshRate() =>
      _invoke('resetPeakRefreshRate');

  /// Read-only: no universal cross-OEM setter exists via Shizuku.
  Future<CommandResult> getThermalStatus() => _invoke('getThermalStatus');

  /// Read-only: no universal cross-OEM setter exists via Shizuku.
  Future<CommandResult> getTouchInfo() => _invoke('getTouchInfo');

  Future<CommandResult> getBrightness() => _invoke('getBrightness');

  Future<CommandResult> setBrightness(int value) =>
      _invoke('setBrightness', {'value': value});

  Future<CommandResult> getAnimationScale(String setting) =>
      _invoke('getAnimationScale', {'setting': setting});

  Future<CommandResult> setAnimationScale(String setting, double value) =>
      _invoke('setAnimationScale', {'setting': setting, 'value': value});

  Future<CommandResult> launchApp(String packageName) =>
      _invoke('launchApp', {'packageName': packageName});

  Future<void> startMonitoring(String packageName) async {
    try {
      await _channel
          .invokeMethod('startMonitoring', {'packageName': packageName});
    } on PlatformException {
      // Monitoring is best-effort; failure here doesn't block gameplay.
    }
  }

  Future<void> stopMonitoring() async {
    try {
      await _channel.invokeMethod('stopMonitoring');
    } on PlatformException {
      // no-op
    }
  }

  Future<CommandResult> _invoke(
    String method, [
    Map<String, dynamic>? args,
  ]) async {
    try {
      final result = await _channel.invokeMethod(method, args);
      return CommandResult.fromMap(Map<dynamic, dynamic>.from(result as Map));
    } on PlatformException catch (e) {
      return CommandResult.failure(e.message ?? 'Platform error: $method');
    } on MissingPluginException {
      return CommandResult.failure('Native handler not available for $method');
    }
  }
}
