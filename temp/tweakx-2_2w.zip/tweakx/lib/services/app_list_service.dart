import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/installed_app.dart';

/// Wraps the apps/getLaunchableApps MethodChannel call. Backed by the real
/// Android PackageManager on the native side (AppListManager.kt) — the
/// returned list always reflects what's actually installed on the device.
class AppListService {
  AppListService._internal();

  static final AppListService instance = AppListService._internal();

  static const MethodChannel _channel = MethodChannel(Channels.apps);

  Future<List<InstalledApp>> getLaunchableApps() async {
    try {
      final result = await _channel.invokeMethod('getLaunchableApps');
      final list = result as List<dynamic>;
      return list
          .map((e) => InstalledApp.fromMap(Map<dynamic, dynamic>.from(e as Map)))
          .toList();
    } on PlatformException {
      return [];
    }
  }
}
