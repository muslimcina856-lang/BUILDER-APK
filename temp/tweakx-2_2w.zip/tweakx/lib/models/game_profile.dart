/// A saved per-game configuration: which app it launches, and what
/// resolution/DPI/refresh-rate/brightness/animation values to apply
/// before launch.
///
/// All numeric fields are nullable: null means "leave this setting alone /
/// use system default" rather than forcing a value.
class GameProfile {
  final String packageName;
  final String label;
  final String? iconBase64;

  final int? resolutionWidth;
  final int? resolutionHeight;
  final int? dpi;
  final int? refreshRateHz;
  final int? brightness;
  final double? animationScale;

  const GameProfile({
    required this.packageName,
    required this.label,
    this.iconBase64,
    this.resolutionWidth,
    this.resolutionHeight,
    this.dpi,
    this.refreshRateHz,
    this.brightness,
    this.animationScale,
  });

  GameProfile copyWith({
    int? resolutionWidth,
    int? resolutionHeight,
    int? dpi,
    int? refreshRateHz,
    int? brightness,
    double? animationScale,
    bool clearResolution = false,
    bool clearDpi = false,
    bool clearRefreshRate = false,
    bool clearBrightness = false,
    bool clearAnimationScale = false,
  }) {
    return GameProfile(
      packageName: packageName,
      label: label,
      iconBase64: iconBase64,
      resolutionWidth:
          clearResolution ? null : (resolutionWidth ?? this.resolutionWidth),
      resolutionHeight:
          clearResolution ? null : (resolutionHeight ?? this.resolutionHeight),
      dpi: clearDpi ? null : (dpi ?? this.dpi),
      refreshRateHz:
          clearRefreshRate ? null : (refreshRateHz ?? this.refreshRateHz),
      brightness: clearBrightness ? null : (brightness ?? this.brightness),
      animationScale: clearAnimationScale
          ? null
          : (animationScale ?? this.animationScale),
    );
  }

  Map<String, dynamic> toJson() => {
        'packageName': packageName,
        'label': label,
        'iconBase64': iconBase64,
        'resolutionWidth': resolutionWidth,
        'resolutionHeight': resolutionHeight,
        'dpi': dpi,
        'refreshRateHz': refreshRateHz,
        'brightness': brightness,
        'animationScale': animationScale,
      };

  factory GameProfile.fromJson(Map<String, dynamic> json) => GameProfile(
        packageName: json['packageName'] as String,
        label: json['label'] as String,
        iconBase64: json['iconBase64'] as String?,
        resolutionWidth: json['resolutionWidth'] as int?,
        resolutionHeight: json['resolutionHeight'] as int?,
        dpi: json['dpi'] as int?,
        refreshRateHz: json['refreshRateHz'] as int?,
        brightness: json['brightness'] as int?,
        animationScale: (json['animationScale'] as num?)?.toDouble(),
      );

  bool get hasAnyCustomSetting =>
      resolutionWidth != null ||
      dpi != null ||
      refreshRateHz != null ||
      brightness != null ||
      animationScale != null;
}
