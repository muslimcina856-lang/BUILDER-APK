/// Represents an app returned by PackageManager's launcher query.
/// Used both by the "Add Game" picker and to render each saved GameProfile.
class InstalledApp {
  final String packageName;
  final String label;

  /// Base64-encoded PNG icon rendered natively, or null if the icon
  /// couldn't be loaded.
  final String? iconBase64;

  const InstalledApp({
    required this.packageName,
    required this.label,
    this.iconBase64,
  });

  factory InstalledApp.fromMap(Map<dynamic, dynamic> map) {
    final icon = map['iconBase64'] as String?;
    return InstalledApp(
      packageName: map['packageName'] as String? ?? '',
      label: map['label'] as String? ?? 'Unknown',
      iconBase64: (icon == null || icon.isEmpty) ? null : icon,
    );
  }
}
