# TweakX UI Performance Pass

This pass focuses on keeping the Flutter UI responsive on 60–90 Hz devices without changing Shizuku/native behavior.

## Changes

- Added short, GPU-friendly page transitions (fade + tiny horizontal slide).
- Replaced continuously animated status/card containers with static rendering plus `RepaintBoundary` isolation.
- Added `RepaintBoundary` around game cards and tweak cards so unrelated changes do not repaint the whole screen.
- Changed the home game list to `ListView.builder` with `shrinkWrap` instead of eagerly building a `Column` of every game card.
- Added image decode bounds (`cacheWidth`/`cacheHeight`) for app icons to reduce memory pressure and texture upload cost.
- Moved brightness slider drag state into a dedicated stateful widget. The parent game screen now updates only when the drag ends instead of rebuilding the complete screen for every slider tick.
- Kept blur-heavy/glow-heavy effects out of the UI pass.

## Frame targets

- 60 Hz: <= 16.67 ms/frame
- 90 Hz: <= 11.11 ms/frame

The project should still be profiled on a real device in **profile mode** before claiming a measured 60–90 FPS result. This environment does not include the Flutter SDK, so this archive has not been device-built here.
