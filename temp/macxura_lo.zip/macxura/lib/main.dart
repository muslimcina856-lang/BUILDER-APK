import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:camera/camera.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

// ─────────────────────────────────────────────
//  THEME CONSTANTS
// ─────────────────────────────────────────────
const Color kBg        = Color(0xFF0D0D1A);
const Color kSurface   = Color(0xFF111127);
const Color kCard      = Color(0xFF14142B);
const Color kBorder    = Color(0xFF1E1E35);
const Color kPurple    = Color(0xFF7F77DD);
const Color kPurpleL   = Color(0xFFAFA9EC);
const Color kPurpleD   = Color(0xFF534AB7);
const Color kGreen     = Color(0xFF1D9E75);
const Color kAmber     = Color(0xFFEF9F27);
const Color kRed       = Color(0xFFE24B4A);
const Color kTeal      = Color(0xFF5DCAA5);
const Color kBlue      = Color(0xFF378ADD);
const Color kText      = Color(0xFFFFFFFF);
const Color kTextMuted = Color(0xFF534AB7);
const Color kTextSub   = Color(0xFFAFA9EC);

// ─────────────────────────────────────────────
//  MAIN
// ─────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const MacxuraApp());
}

class MacxuraApp extends StatelessWidget {
  const MacxuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Macxura',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(
          primary: kPurple,
          surface: kSurface,
        ),
        textTheme: GoogleFonts.outfitTextTheme(
          ThemeData.dark().textTheme,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// ─────────────────────────────────────────────
//  SPLASH SCREEN
// ─────────────────────────────────────────────
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _progress;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    );
    _logoScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.4, curve: Curves.elasticOut)),
    );
    _logoOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.3, curve: Curves.easeIn)),
    );
    _progress = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0.3, 1.0, curve: Curves.easeInOut)),
    );
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const LoginScreen(),
            transitionsBuilder: (_, anim, __, child) =>
                FadeTransition(opacity: anim, child: child),
            transitionDuration: const Duration(milliseconds: 600),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, _) => Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FadeTransition(
                opacity: _logoOpacity,
                child: ScaleTransition(
                  scale: _logoScale,
                  child: Container(
                    width: 90,
                    height: 90,
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(
                        color: kPurple.withOpacity(0.5 + 0.5 * _progress.value),
                        width: 1.5,
                      ),
                    ),
                    child: const Icon(Icons.shield_rounded, size: 46, color: kPurple),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              FadeTransition(
                opacity: _logoOpacity,
                child: Text(
                  'MACXURA',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 28,
                    fontWeight: FontWeight.w600,
                    color: kText,
                    letterSpacing: 4,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              FadeTransition(
                opacity: _logoOpacity,
                child: Text(
                  'ENTERPRISE DEVICE CONTROLLER',
                  style: GoogleFonts.outfit(
                    fontSize: 10,
                    color: kPurpleD,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: 100,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _progress.value,
                    backgroundColor: kBorder,
                    valueColor: const AlwaysStoppedAnimation<Color>(kPurple),
                    minHeight: 2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  LOGIN SCREEN
// ─────────────────────────────────────────────
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _login() async {
    setState(() { _error = null; _loading = true; });
    await Future.delayed(const Duration(milliseconds: 800));
    if (_userCtrl.text.trim() == 'macxura' &&
        _passCtrl.text.trim() == 'claude ai') {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => const DashboardScreen(),
            transitionsBuilder: (_, anim, __, child) => SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(1, 0),
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
              child: child,
            ),
            transitionDuration: const Duration(milliseconds: 500),
          ),
        );
      }
    } else {
      setState(() {
        _error = 'Username atau password salah!';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Column(
                      children: [
                        Container(
                          width: 72,
                          height: 72,
                          decoration: BoxDecoration(
                            color: kSurface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: kBorder, width: 1),
                          ),
                          child: const Icon(Icons.shield_rounded, size: 36, color: kPurpleL),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'MACXURA',
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: kText,
                            letterSpacing: 4,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'INTERNAL USE ONLY',
                          style: GoogleFonts.outfit(
                            fontSize: 10,
                            color: kPurpleD,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  Container(height: 0.5, color: kBorder),
                  const SizedBox(height: 24),
                  Text(
                    'Login Account',
                    style: GoogleFonts.outfit(
                      fontSize: 16,
                      color: kPurpleL,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 18),
                  _fieldLabel('USERNAME'),
                  const SizedBox(height: 6),
                  _inputField(
                    controller: _userCtrl,
                    hint: 'Masukkan username',
                    icon: Icons.person_outline_rounded,
                  ),
                  const SizedBox(height: 14),
                  _fieldLabel('PASSWORD'),
                  const SizedBox(height: 6),
                  _inputField(
                    controller: _passCtrl,
                    hint: 'Masukkan password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscure,
                    suffix: IconButton(
                      icon: Icon(
                        _obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                        color: kPurpleD,
                        size: 20,
                      ),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: kRed.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kRed.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline, color: kRed, size: 16),
                          const SizedBox(width: 8),
                          Text(_error!,
                            style: GoogleFonts.outfit(fontSize: 12, color: kRed)),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPurple,
                        foregroundColor: kText,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        elevation: 0,
                      ),
                      child: _loading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              'Masuk ke Akun',
                              style: GoogleFonts.outfit(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: Text(
                      'Macxura v1.0.0 — Perangkat Pribadi',
                      style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _fieldLabel(String label) => Text(
    label,
    style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD, letterSpacing: 1.5),
  );

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: GoogleFonts.outfit(color: kPurpleL, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.outfit(color: kPurpleD, fontSize: 13),
          prefixIcon: Icon(icon, color: kPurpleD, size: 20),
          suffixIcon: suffix,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
        onSubmitted: (_) => _login(),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  DASHBOARD SCREEN
// ─────────────────────────────────────────────
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  int _tabIndex = 0;
  late AnimationController _fadeCtrl;

  final List<_FeatureItem> features = [
    _FeatureItem('GPS Tracker', 'Pantau lokasi real-time', Icons.location_on_rounded, kGreen, const Color(0xFF0D1F16)),
    _FeatureItem('Lock Screen', 'Kunci layar via PIN', Icons.lock_rounded, kPurple, const Color(0xFF111127)),
    _FeatureItem('Kamera', 'Pantau depan & belakang', Icons.camera_alt_rounded, kAmber, const Color(0xFF1A1208)),
    _FeatureItem('Layar', 'Screen recording', Icons.screen_share_rounded, kRed, const Color(0xFF1A0D0D)),
    _FeatureItem('File Manager', 'Kelola file perangkat', Icons.folder_rounded, kTeal, const Color(0xFF0A1A1A)),
  ];

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _openFeature(_FeatureItem item) {
    Widget page;
    switch (item.title) {
      case 'GPS Tracker':
        page = const GpsScreen();
        break;
      case 'Lock Screen':
        page = const LockPinScreen();
        break;
      case 'Kamera':
        page = const CameraScreen();
        break;
      case 'Layar':
        page = const ScreenRecordScreen();
        break;
      case 'File Manager':
        page = const FileManagerScreen();
        break;
      default:
        return;
    }
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 1),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeCtrl,
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: _tabIndex == 0
                    ? _buildHome()
                    : _tabIndex == 2
                        ? const SettingsScreen()
                        : _buildPlaceholder(),
              ),
              _buildTabBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F1E),
        border: Border(bottom: BorderSide(color: kBorder, width: 0.5)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kBorder),
            ),
            child: const Icon(Icons.shield_rounded, size: 20, color: kPurple),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('MACXURA',
                style: GoogleFonts.spaceGrotesk(
                  fontSize: 15, fontWeight: FontWeight.w600,
                  color: kText, letterSpacing: 2,
                )),
              Text('DEVICE CONTROLLER',
                style: GoogleFonts.outfit(fontSize: 9, color: kPurpleD, letterSpacing: 1.5)),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFF0D1F16),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGreen.withOpacity(0.4)),
            ),
            child: Row(
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    color: kGreen,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                Text('ONLINE',
                  style: GoogleFonts.outfit(fontSize: 9, color: kGreen, letterSpacing: 0.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHome() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        _sectionLabel('PENGGUNA AKTIF'),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder, width: 0.5),
          ),
          child: Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: kCard,
                  shape: BoxShape.circle,
                  border: Border.all(color: kBorder),
                ),
                child: const Icon(Icons.person_rounded, color: kPurple, size: 20),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('macxura',
                    style: GoogleFonts.outfit(fontSize: 14, color: kText, fontWeight: FontWeight.w500)),
                  Text('Administrator',
                    style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF0D1226),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kBlue.withOpacity(0.4)),
                ),
                child: Text('Owner',
                  style: GoogleFonts.outfit(fontSize: 10, color: kBlue)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _sectionLabel('FITUR KONTROL'),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: features.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.1,
          ),
          itemBuilder: (context, i) {
            final f = features[i];
            final isWide = i == features.length - 1 && features.length % 2 != 0;
            return _FeatureCard(
              item: f,
              onTap: () => _openFeature(f),
            );
          },
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _buildPlaceholder() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.construction_rounded, color: kPurpleD, size: 48),
          const SizedBox(height: 12),
          Text('Segera Hadir',
            style: GoogleFonts.outfit(fontSize: 16, color: kPurpleL)),
          const SizedBox(height: 4),
          Text('Fitur ini dalam pengembangan',
            style: GoogleFonts.outfit(fontSize: 12, color: kPurpleD)),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    final tabs = [
      _TabItem(Icons.home_rounded, 'HOME'),
      _TabItem(Icons.bar_chart_rounded, 'STATUS'),
      _TabItem(Icons.settings_rounded, 'SETTING'),
      _TabItem(Icons.person_rounded, 'PROFIL'),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F1E),
        border: Border(top: BorderSide(color: kBorder, width: 0.5)),
      ),
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(tabs.length, (i) {
          final isOn = _tabIndex == i;
          return GestureDetector(
            onTap: () => setState(() => _tabIndex = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(tabs[i].icon,
                    color: isOn ? kPurpleL : const Color(0xFF2A2A4A), size: 22),
                  const SizedBox(height: 3),
                  Text(tabs[i].label,
                    style: GoogleFonts.outfit(
                      fontSize: 8,
                      color: isOn ? kPurple : const Color(0xFF2A2A4A),
                      letterSpacing: 0.5,
                    )),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(
    text,
    style: GoogleFonts.outfit(fontSize: 9, color: kPurpleD, letterSpacing: 2, fontWeight: FontWeight.w500),
  );
}

class _FeatureItem {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  final Color bgColor;
  const _FeatureItem(this.title, this.desc, this.icon, this.color, this.bgColor);
}

class _TabItem {
  final IconData icon;
  final String label;
  const _TabItem(this.icon, this.label);
}

class _FeatureCard extends StatefulWidget {
  final _FeatureItem item;
  final VoidCallback onTap;
  const _FeatureCard({required this.item, required this.onTap});

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
      lowerBound: 0.0,
      upperBound: 0.04,
    );
    _scale = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, child) => Transform.scale(scale: _scale.value, child: child),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder, width: 0.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: widget.item.bgColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(widget.item.icon, color: widget.item.color, size: 20),
              ),
              const Spacer(),
              Text(widget.item.title,
                style: GoogleFonts.outfit(fontSize: 12, color: kText, fontWeight: FontWeight.w500)),
              const SizedBox(height: 2),
              Text(widget.item.desc,
                style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD),
                maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  GPS SCREEN
// ─────────────────────────────────────────────
class GpsScreen extends StatefulWidget {
  const GpsScreen({super.key});
  @override
  State<GpsScreen> createState() => _GpsScreenState();
}

class _GpsScreenState extends State<GpsScreen> {
  Position? _position;
  String _status = 'Tekan tombol untuk ambil lokasi';
  bool _loading = false;

  Future<void> _getLocation() async {
    setState(() { _loading = true; _status = 'Meminta izin lokasi...'; });
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() { _status = 'GPS tidak aktif. Nyalakan GPS dahulu.'; _loading = false; });
      return;
    }
    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied) {
        setState(() { _status = 'Izin lokasi ditolak.'; _loading = false; });
        return;
      }
    }
    if (perm == LocationPermission.deniedForever) {
      setState(() { _status = 'Izin lokasi ditolak permanen.'; _loading = false; });
      return;
    }
    setState(() { _status = 'Mengambil koordinat...'; });
    final pos = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    setState(() { _position = pos; _status = 'Lokasi berhasil diambil'; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return _featureScaffold(
      title: 'GPS Tracker',
      icon: Icons.location_on_rounded,
      color: kGreen,
      child: Column(
        children: [
          _infoBox(
            children: [
              _infoRow('Status', _status, kGreen),
              if (_position != null) ...[
                _infoRow('Latitude', _position!.latitude.toStringAsFixed(6), kPurpleL),
                _infoRow('Longitude', _position!.longitude.toStringAsFixed(6), kPurpleL),
                _infoRow('Akurasi', '${_position!.accuracy.toStringAsFixed(1)} m', kAmber),
                _infoRow('Altitude', '${_position!.altitude.toStringAsFixed(1)} m', kBlue),
                _infoRow('Kecepatan', '${(_position!.speed * 3.6).toStringAsFixed(1)} km/h', kTeal),
              ],
            ],
          ),
          const SizedBox(height: 20),
          _actionButton(
            label: _loading ? 'Mengambil...' : 'Ambil Lokasi Sekarang',
            icon: Icons.my_location_rounded,
            color: kGreen,
            onTap: _loading ? null : _getLocation,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  LOCK PIN SCREEN
// ─────────────────────────────────────────────
class LockPinScreen extends StatefulWidget {
  const LockPinScreen({super.key});
  @override
  State<LockPinScreen> createState() => _LockPinScreenState();
}

class _LockPinScreenState extends State<LockPinScreen> {
  final _pinCtrl = TextEditingController();
  final _newPinCtrl = TextEditingController();
  bool _isLocked = false;
  bool _obscurePin = true;
  String _msg = '';

  Future<void> _lock() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPin = prefs.getString('lock_pin') ?? '';
    if (savedPin.isEmpty) {
      setState(() => _msg = 'Atur PIN dahulu sebelum mengunci!');
      return;
    }
    setState(() { _isLocked = true; _msg = 'Layar terkunci!'; });
  }

  Future<void> _unlock() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPin = prefs.getString('lock_pin') ?? '';
    if (_pinCtrl.text == savedPin) {
      setState(() { _isLocked = false; _msg = 'Berhasil dibuka!'; _pinCtrl.clear(); });
    } else {
      setState(() => _msg = 'PIN salah!');
    }
  }

  Future<void> _savePin() async {
    if (_newPinCtrl.text.length < 4) {
      setState(() => _msg = 'PIN minimal 4 digit!');
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lock_pin', _newPinCtrl.text);
    setState(() { _msg = 'PIN berhasil disimpan!'; _newPinCtrl.clear(); });
  }

  @override
  Widget build(BuildContext context) {
    return _featureScaffold(
      title: 'Lock Screen',
      icon: Icons.lock_rounded,
      color: kPurple,
      child: _isLocked
          ? Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kRed.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.lock_rounded, color: kRed, size: 48),
                      const SizedBox(height: 12),
                      Text('LAYAR TERKUNCI',
                        style: GoogleFonts.spaceGrotesk(
                          fontSize: 16, color: kRed, letterSpacing: 2, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _pinCtrl,
                        obscureText: true,
                        keyboardType: TextInputType.number,
                        maxLength: 8,
                        style: GoogleFonts.outfit(color: kPurpleL, fontSize: 20, letterSpacing: 8),
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          counterText: '',
                          hintText: '• • • •',
                          hintStyle: GoogleFonts.outfit(color: kPurpleD, letterSpacing: 8),
                          filled: true,
                          fillColor: kCard,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _actionButton(label: 'Buka Kunci', icon: Icons.lock_open_rounded, color: kPurple, onTap: _unlock),
                if (_msg.isNotEmpty) _msgText(_msg),
              ],
            )
          : Column(
              children: [
                _infoBox(children: [
                  _infoRow('Status', 'Tidak Terkunci', kGreen),
                ]),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: kSurface, borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: kBorder, width: 0.5),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Atur PIN Baru', style: GoogleFonts.outfit(fontSize: 13, color: kPurpleL, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _newPinCtrl,
                        keyboardType: TextInputType.number,
                        obscureText: _obscurePin,
                        maxLength: 8,
                        style: GoogleFonts.outfit(color: kPurpleL, fontSize: 14),
                        decoration: InputDecoration(
                          counterText: '',
                          hintText: 'Min. 4 digit',
                          hintStyle: GoogleFonts.outfit(color: kPurpleD, fontSize: 13),
                          filled: true, fillColor: kCard,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(_obscurePin ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                              color: kPurpleD, size: 18),
                            onPressed: () => setState(() => _obscurePin = !_obscurePin),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      _actionButton(label: 'Simpan PIN', icon: Icons.save_rounded, color: kPurpleD, onTap: _savePin),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _actionButton(label: 'Kunci Sekarang', icon: Icons.lock_rounded, color: kRed, onTap: _lock),
                if (_msg.isNotEmpty) _msgText(_msg),
              ],
            ),
    );
  }
}

// ─────────────────────────────────────────────
//  CAMERA SCREEN
// ─────────────────────────────────────────────
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _ctrl;
  List<CameraDescription>? _cameras;
  int _camIndex = 0;
  bool _initialized = false;
  bool _loading = false;
  String? _capturedPath;
  String _msg = '';

  Future<void> _initCamera() async {
    setState(() { _loading = true; _msg = ''; });
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      setState(() { _msg = 'Izin kamera ditolak.'; _loading = false; });
      return;
    }
    _cameras = await availableCameras();
    if (_cameras == null || _cameras!.isEmpty) {
      setState(() { _msg = 'Tidak ada kamera tersedia.'; _loading = false; });
      return;
    }
    await _setupCamera(_camIndex);
  }

  Future<void> _setupCamera(int index) async {
    _ctrl?.dispose();
    _ctrl = CameraController(_cameras![index], ResolutionPreset.medium);
    await _ctrl!.initialize();
    if (mounted) setState(() { _initialized = true; _loading = false; });
  }

  Future<void> _switchCamera() async {
    if (_cameras == null || _cameras!.length < 2) return;
    _camIndex = _camIndex == 0 ? 1 : 0;
    setState(() { _initialized = false; _loading = true; });
    await _setupCamera(_camIndex);
  }

  Future<void> _capturePhoto() async {
    if (_ctrl == null || !_ctrl!.value.isInitialized) return;
    final file = await _ctrl!.takePicture();
    setState(() { _capturedPath = file.path; _msg = 'Foto tersimpan: ${file.path}'; });
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _featureScaffold(
      title: 'Kamera',
      icon: Icons.camera_alt_rounded,
      color: kAmber,
      child: Column(
        children: [
          if (!_initialized && !_loading)
            _actionButton(label: 'Aktifkan Kamera', icon: Icons.camera_alt_rounded, color: kAmber, onTap: _initCamera),
          if (_loading)
            const Center(child: CircularProgressIndicator(color: kAmber)),
          if (_initialized && _ctrl != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: AspectRatio(
                aspectRatio: _ctrl!.value.aspectRatio,
                child: CameraPreview(_ctrl!),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _actionButton(
                  label: 'Ganti Kamera',
                  icon: Icons.flip_camera_android_rounded,
                  color: kPurpleD,
                  onTap: _switchCamera,
                )),
                const SizedBox(width: 10),
                Expanded(child: _actionButton(
                  label: 'Ambil Foto',
                  icon: Icons.camera_rounded,
                  color: kAmber,
                  onTap: _capturePhoto,
                )),
              ],
            ),
          ],
          if (_msg.isNotEmpty) _msgText(_msg),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SCREEN RECORD SCREEN
// ─────────────────────────────────────────────
class ScreenRecordScreen extends StatefulWidget {
  const ScreenRecordScreen({super.key});
  @override
  State<ScreenRecordScreen> createState() => _ScreenRecordScreenState();
}

class _ScreenRecordScreenState extends State<ScreenRecordScreen> {
  bool _recording = false;
  String _msg = 'Tekan tombol untuk memulai recording.\nAndroid akan menampilkan konfirmasi sistem.';

  void _toggleRecord() {
    // Screen recording di Flutter memerlukan platform channel native
    // atau plugin seperti screen_recorder. Untuk versi ini,
    // kita tampilkan panduan penggunaan media projection API bawaan Android.
    setState(() {
      if (!_recording) {
        _recording = true;
        _msg = 'Recording aktif (via sistem Android).\nIndikator recording muncul di status bar.';
      } else {
        _recording = false;
        _msg = 'Recording dihentikan.';
      }
    });
    // Catatan: implementasi penuh memerlukan MediaProjection API
    // melalui platform channel Flutter ↔ Android native.
  }

  @override
  Widget build(BuildContext context) {
    return _featureScaffold(
      title: 'Screen Recording',
      icon: Icons.screen_share_rounded,
      color: kRed,
      child: Column(
        children: [
          _infoBox(children: [
            _infoRow('Status', _recording ? 'Sedang Recording' : 'Tidak Aktif',
              _recording ? kRed : kPurpleD),
          ]),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kBorder, width: 0.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.info_outline_rounded, color: kAmber, size: 16),
                  const SizedBox(width: 6),
                  Text('Informasi', style: GoogleFonts.outfit(fontSize: 12, color: kAmber, fontWeight: FontWeight.w500)),
                ]),
                const SizedBox(height: 8),
                Text(
                  'Screen recording di Android memerlukan konfirmasi eksplisit dari sistem (MediaProjection API). Android akan selalu menampilkan notifikasi saat recording aktif.',
                  style: GoogleFonts.outfit(fontSize: 11, color: kPurpleD, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _actionButton(
            label: _recording ? 'Hentikan Recording' : 'Mulai Recording',
            icon: _recording ? Icons.stop_circle_rounded : Icons.fiber_manual_record_rounded,
            color: _recording ? kRed : kPurpleD,
            onTap: _toggleRecord,
          ),
          if (_msg.isNotEmpty) _msgText(_msg),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  FILE MANAGER SCREEN
// ─────────────────────────────────────────────
class FileManagerScreen extends StatefulWidget {
  const FileManagerScreen({super.key});
  @override
  State<FileManagerScreen> createState() => _FileManagerScreenState();
}

class _FileManagerScreenState extends State<FileManagerScreen> {
  List<FileSystemEntity> _files = [];
  Directory? _currentDir;
  bool _loading = false;
  String _msg = '';

  @override
  void initState() {
    super.initState();
    _loadDir();
  }

  Future<void> _loadDir() async {
    setState(() { _loading = true; });
    final status = await Permission.storage.request();
    if (!status.isGranted) {
      await Permission.manageExternalStorage.request();
    }
    try {
      final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final parent = dir.parent.parent.parent.parent;
      setState(() {
        _currentDir = parent;
        _files = parent.listSync().toList()
          ..sort((a, b) {
            final aIsDir = a is Directory;
            final bIsDir = b is Directory;
            if (aIsDir && !bIsDir) return -1;
            if (!aIsDir && bIsDir) return 1;
            return a.path.compareTo(b.path);
          });
        _loading = false;
      });
    } catch (e) {
      setState(() { _msg = 'Error: $e'; _loading = false; });
    }
  }

  void _navigate(Directory dir) {
    setState(() { _loading = true; });
    try {
      final files = dir.listSync().toList()
        ..sort((a, b) {
          final aIsDir = a is Directory;
          final bIsDir = b is Directory;
          if (aIsDir && !bIsDir) return -1;
          if (!aIsDir && bIsDir) return 1;
          return a.path.compareTo(b.path);
        });
      setState(() {
        _currentDir = dir;
        _files = files;
        _loading = false;
      });
    } catch (e) {
      setState(() { _msg = 'Tidak bisa membuka folder ini.'; _loading = false; });
    }
  }

  void _goUp() {
    if (_currentDir == null) return;
    final parent = _currentDir!.parent;
    if (parent.path == _currentDir!.path) return;
    _navigate(parent);
  }

  String _fileName(FileSystemEntity e) {
    return e.path.split('/').last;
  }

  String _fileSize(File f) {
    final bytes = f.lengthSync();
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    return _featureScaffold(
      title: 'File Manager',
      icon: Icons.folder_rounded,
      color: kTeal,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_currentDir != null) ...[
            Row(
              children: [
                IconButton(
                  onPressed: _goUp,
                  icon: const Icon(Icons.arrow_upward_rounded, color: kPurpleL, size: 18),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    _currentDir!.path,
                    style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
          if (_loading)
            const Center(child: CircularProgressIndicator(color: kTeal))
          else if (_files.isEmpty)
            Center(child: Text('Folder kosong', style: GoogleFonts.outfit(color: kPurpleD, fontSize: 13)))
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _files.length,
              separatorBuilder: (_, __) => Container(height: 0.5, color: kBorder),
              itemBuilder: (_, i) {
                final f = _files[i];
                final isDir = f is Directory;
                return ListTile(
                  dense: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
                  leading: Icon(
                    isDir ? Icons.folder_rounded : Icons.insert_drive_file_rounded,
                    color: isDir ? kAmber : kPurpleL,
                    size: 20,
                  ),
                  title: Text(_fileName(f),
                    style: GoogleFonts.outfit(fontSize: 13, color: kText),
                    overflow: TextOverflow.ellipsis),
                  subtitle: isDir
                      ? null
                      : Text(_fileSize(f as File),
                          style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
                  onTap: isDir ? () => _navigate(f as Directory) : null,
                );
              },
            ),
          if (_msg.isNotEmpty) _msgText(_msg),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SETTINGS SCREEN (embedded in dashboard tab)
// ─────────────────────────────────────────────
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Text('PENGATURAN', style: GoogleFonts.outfit(fontSize: 9, color: kPurpleD, letterSpacing: 2)),
        const SizedBox(height: 10),
        _settingTile(context, Icons.person_outline_rounded, 'Akun', 'macxura / Administrator'),
        _settingTile(context, Icons.shield_outlined, 'Keamanan', 'Ganti PIN, autentikasi'),
        _settingTile(context, Icons.notifications_outlined, 'Notifikasi', 'Atur alert & push notif'),
        _settingTile(context, Icons.info_outline_rounded, 'Tentang', 'Macxura v1.0.0'),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: () => Navigator.pushAndRemoveUntil(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => const LoginScreen(),
              transitionsBuilder: (_, anim, __, child) =>
                FadeTransition(opacity: anim, child: child),
              transitionDuration: const Duration(milliseconds: 500),
            ),
            (r) => false,
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kRed.withOpacity(0.3), width: 0.5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.logout_rounded, color: kRed, size: 18),
                const SizedBox(width: 8),
                Text('Keluar / Logout',
                  style: GoogleFonts.outfit(fontSize: 14, color: kRed, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _settingTile(BuildContext context, IconData icon, String title, String sub) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder, width: 0.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: kPurpleL, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: GoogleFonts.outfit(fontSize: 13, color: kText, fontWeight: FontWeight.w500)),
                Text(sub, style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: kPurpleD, size: 18),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SHARED UI HELPERS
// ─────────────────────────────────────────────
Widget _featureScaffold({
  required String title,
  required IconData icon,
  required Color color,
  required Widget child,
}) {
  return Builder(builder: (context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: const BoxDecoration(
                color: Color(0xFF0F0F1E),
                border: Border(bottom: BorderSide(color: kBorder, width: 0.5)),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: kSurface,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kBorder),
                      ),
                      child: const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: kPurpleL),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Text(title, style: GoogleFonts.spaceGrotesk(
                    fontSize: 16, fontWeight: FontWeight.w600, color: kText)),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: child,
              ),
            ),
          ],
        ),
      ),
    );
  });
}

Widget _infoBox({required List<Widget> children}) {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: kSurface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: kBorder, width: 0.5),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: children,
    ),
  );
}

Widget _infoRow(String label, String value, Color valueColor) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      children: [
        Text(label, style: GoogleFonts.outfit(fontSize: 12, color: kPurpleD)),
        const Spacer(),
        Text(value, style: GoogleFonts.outfit(fontSize: 12, color: valueColor, fontWeight: FontWeight.w500)),
      ],
    ),
  );
}

Widget _actionButton({
  required String label,
  required IconData icon,
  required Color color,
  VoidCallback? onTap,
}) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: color.withOpacity(0.4), width: 0.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Text(label, style: GoogleFonts.outfit(
            fontSize: 13, color: color, fontWeight: FontWeight.w500)),
        ],
      ),
    ),
  );
}

Widget _msgText(String msg) {
  return Padding(
    padding: const EdgeInsets.only(top: 12),
    child: Text(msg,
      textAlign: TextAlign.center,
      style: GoogleFonts.outfit(fontSize: 11, color: kPurpleL, height: 1.5)),
  );
}
