import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.image.UtmArchiveEntry
import com.virtual.devicelization.core.image.UtmConfigParser
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.core.vm.SingleVmPolicy

fun main() {
    repeat(2000) {
        val mac = MacAddressGenerator.generate()
        check(MacAddressGenerator.isLocallyAdministeredUnicast(mac)) { "Bad MAC: $mac" }
    }
    val p1 = Profile("1", "A", 13, 33, network = NetworkConfig(MacAddressGenerator.generate()), status = VmStatus.RUNNING)
    val p2 = Profile("2", "B", 14, 34, network = NetworkConfig(MacAddressGenerator.generate()), status = VmStatus.STOPPED)
    check(!SingleVmPolicy.canStart(listOf(p1, p2), "2"))
    check(SingleVmPolicy.canStart(listOf(p1, p2), "1"))
    SingleVmPolicy.assertInvariant(listOf(p1, p2))

    // A QMP-paused/suspended process still owns RAM and is therefore the one active VM.
    val suspended = p1.copy(status = VmStatus.SUSPENDED)
    check(!SingleVmPolicy.canStart(listOf(suspended, p2), "2"))
    SingleVmPolicy.assertInvariant(listOf(suspended, p2))

    testUtmLayoutParser()

    println("Core self-test passed")
}

private fun testUtmLayoutParser() {
    val plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <plist version="1.0"><dict>
        <key>Drive</key><array>
          <dict>
            <key>Identifier</key><string>vda</string>
            <key>ImageName</key><string>@UTM_VM_OUT_DISK_IMAGE_VDA_FILENAME@</string>
            <key>ImageType</key><string>Disk</string>
            <key>Interface</key><string>VirtIO</string>
            <key>ReadOnly</key><false/>
          </dict>
          <dict>
            <key>Identifier</key><string>vdb</string>
            <key>ImageName</key><string>vdb.qcow2</string>
            <key>ImageType</key><string>Disk</string>
            <key>Interface</key><string>VirtIO</string>
            <key>ReadOnly</key><false/>
          </dict>
        </array>
        </dict></plist>
    """.trimIndent()
    val entries = listOf(
        UtmArchiveEntry("LineageOS_on_arm64.utm/config.plist", 4000),
        UtmArchiveEntry("LineageOS_on_arm64.utm/Data/lineage-main-arm64.qcow2", 900_000_000),
        UtmArchiveEntry("LineageOS_on_arm64.utm/Data/vdb.qcow2", 100_000_000),
        UtmArchiveEntry("LineageOS_on_arm64.utm/Data/efi_vars.fd", 64_000_000),
    )
    val documented = UtmConfigParser.resolveDocumentedLineageLayout(
        listOf(
            UtmArchiveEntry("LineageOS_on_arm64.utm/config.plist", 4000),
            UtmArchiveEntry("LineageOS_on_arm64.utm/Data/vda.qcow2", 900_000_000),
            UtmArchiveEntry("LineageOS_on_arm64.utm/Data/vdb.qcow2", 100_000_000),
            UtmArchiveEntry("LineageOS_on_arm64.utm/Data/efi_vars.fd", 64_000_000),
        )
    )
    check(documented != null)
    check(documented.drives.map { it.spec.identifier } == listOf("vda", "vdb"))
    check(documented.firmwareVarsEntryName.endsWith("efi_vars.fd"))

    val layout = UtmConfigParser.resolve(plist, entries)
    check(layout.drives[0].spec.identifier == "vda")
    check(layout.drives[0].archiveEntryName.endsWith("lineage-main-arm64.qcow2"))
    check(layout.drives[1].archiveEntryName.endsWith("vdb.qcow2"))
    check(layout.firmwareVarsEntryName.endsWith("efi_vars.fd"))

    val explicit = plist.replace(
        "@UTM_VM_OUT_DISK_IMAGE_VDA_FILENAME@",
        "custom-vda.img",
    )
    val explicitLayout = UtmConfigParser.resolve(
        explicit,
        entries + UtmArchiveEntry("LineageOS_on_arm64.utm/Data/custom-vda.img", 800_000_000),
    )
    check(explicitLayout.drives[0].archiveEntryName.endsWith("custom-vda.img"))
    check(UtmConfigParser.qemuFormat("custom-vda.img") == "raw")
}
