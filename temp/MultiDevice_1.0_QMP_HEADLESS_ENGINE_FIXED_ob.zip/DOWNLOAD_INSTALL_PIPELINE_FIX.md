# Download / Install Pipeline Fix

This revision separates a guest image download from installation.

## Rules

1. Completed archives are stored in `filesDir/guest_downloads`, not `cacheDir`.
2. A completed download is never deleted because installation failed.
3. Retry Install uses only the already-downloaded local archive; it performs no network request.
4. The completed archive is deleted only after the installed guest image has been reopened and validated.
5. Partial downloads are kept as `.part` and resume with HTTP Range when supported.
6. Old completed downloads from `cacheDir/guest_downloads` are migrated to persistent storage when possible.
7. Current jqssun LineageOS UTM catalog releases first use the documented QEMU layout:
   `Data/vda.qcow2`, `Data/vdb.qcow2`, `Data/efi_vars.fd`.
8. `config.plist` parsing remains a fallback for non-standard/older UTM bundles.
9. Interrupted/invalid final image directories are cleaned so they cannot poison future retry attempts.
10. `versionCode = 1` and `versionName = "1.0"` remain unchanged.
