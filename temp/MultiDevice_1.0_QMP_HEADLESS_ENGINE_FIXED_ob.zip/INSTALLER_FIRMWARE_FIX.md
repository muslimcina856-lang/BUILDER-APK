# Installer firmware fix

Observed on-device failure:

`firmware/edk2-aarch64-code.fd.gz`

The failure was common to every downloaded UTM/QEMU guest because the mandatory ARM64 EDK2 code
firmware was looked up through `AssetManager` at install time. The guest ZIP was valid and remained
saved locally, but the installer could not finish its own engine-support step.

Fix:

- mandatory firmware moved to `app/src/main/res/raw/edk2_aarch64_code_fd.gz`;
- installer opens it through compile-time `R.raw.edk2_aarch64_code_fd`;
- firmware is checked before large guest disks are extracted;
- decompressed firmware must be exactly 67,108,864 bytes;
- decompressed SHA-256 must be
  `47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d`;
- `preBuild` verifies the same resource, size and hash, so a broken APK package fails at build time;
- completed guest downloads remain persistent and Retry Install still performs no network download.

Release metadata remains user-managed: versionCode 1, versionName 1.0.
