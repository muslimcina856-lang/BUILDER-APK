# Multi Device guest bundle format (.mdvm)

A `.mdvm` file is a ZIP archive whose root contains `manifest.json` plus every file referenced by
that manifest. Multi Device extracts it into app-private storage and refuses path traversal,
unsupported host-facing QEMU options, non-ARM64 manifests, or missing referenced files.

The supplied `manifest.json` is a **schema/example only**. It is not a bootable Android ROM by
itself. A full Android guest must be built for the virtual hardware it declares: its kernel/init,
`fstab`, SELinux policy, graphics stack and partition layout must agree with QEMU `virt`/virtio.

## Two supported boot styles

1. **Direct kernel** — set `kernel`, optional `initrd`, `kernelCmdline`, and drives. The example
   manifest in this directory uses this style.
2. **UEFI/pflash** — set both `firmwareCode` and `firmwareVars`, then declare the guest drives.
   Multi Device keeps firmware code shared/read-only and copies the UEFI variable store per profile.

For the ARM64 QEMU/UTM images from `jqssun/android-lineage-qemu`, the project includes:

```bash
python3 native-engine/fetch_qemu_firmware.py
python3 tools/make_lineage_qemu_mdvm.py \
  --source UTM-VM-lineage-...-virtio_arm64only.zip \
  --firmware-code guest-image-template/edk2-aarch64-code.fd \
  --android-version 16 --api-level 36 \
  --id lineage-arm64 --name "LineageOS ARM64" \
  --output lineage-arm64.mdvm
```

The converter copies `vda.qcow2`, `vdb.qcow2`, `efi_vars.fd`, and the supplied ARM64 QEMU UEFI code
into a Multi Device bundle with virtio graphics/input devices. It does not modify or bypass Android
integrity/security mechanisms.

## Drive isolation

- `readOnly: true` + `profileScoped: false`: shared immutable system/vendor-style image.
- Writable drives default to `profileScoped: true`: Multi Device copies the base file into
  `filesDir/profile_data/<profile>/drives/` on first boot.
- Cloning a profile also clones its private disk and firmware-variable directory.

This conservative copy-on-first-use design costs more storage than qcow2 backing overlays, but it
prevents one profile from modifying another profile's userdata.

## Safe extraArgs

Imported bundles cannot inject arbitrary QEMU CLI arguments. Only the small allow-list implemented
in `GuestImageStore.validateExtraArgs()` is accepted. Put file-backed storage in `drives` or the
explicit firmware fields rather than trying to pass host filesystem paths through `extraArgs`.
