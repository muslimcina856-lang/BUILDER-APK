# UTM image import fix

The catalog downloader uses LineageOS/QEMU `UTM-VM-lineage-*.zip` assets.

The importer must not assume that the first UTM disk is always literally named `vda.qcow2`.
LineageOS' UTM `config.plist` template exposes the vda image filename as a build-time replacement
value, while UTM packages describe their actual disk mapping in `config.plist`.

This revision therefore:

- reads `config.plist` from the downloaded `.utm` bundle;
- resolves every `Drive` entry by `Identifier` + `ImageName`;
- extracts the actual configured ARM64 disk files rather than hardcoding filenames;
- keeps a safe fallback for a placeholder/renamed vda disk;
- imports the bundle's `efi_vars.fd`;
- preserves drive boot order via `bootIndex` in the generated Multi Device manifest;
- validates GitHub asset size and SHA-256 digest when the release API provides one;
- keeps a completed valid download in cache if installation fails, so Retry does not download a
  multi-gigabyte archive again.

`core-selftest/CoreSelfTest.kt` contains a regression test where vda is deliberately named
`lineage-main-arm64.qcow2` instead of `vda.qcow2`.
