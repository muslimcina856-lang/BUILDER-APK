# UI + VM start fix

Observed from real-device screenshots:

- Create/Edit routes were outside any root Surface. MaterialTheme supplied a ColorScheme but not a background/content color provider, causing the Android window fallback gray and default black Text/Icon content in several places.
- NeonCard now provides TextPrimary explicitly.
- MultiDeviceTheme now wraps every route in a full-screen dark Surface using Bg/TextPrimary.
- The Android window fallback background is also Bg to avoid gray flashes.
- ConnectivityManager.activeNetwork/getNetworkCapabilities require ACCESS_NETWORK_STATE. The manifest now declares it.
- HostVpnInspector catches platform SecurityException/failures and returns a safe false state rather than leaking a raw ConnectivityService exception to the UI.
- prepare() failures occur before QEMU starts, so they now return the profile to STOPPED instead of persisting ERROR. Actual QEMU start failures still use ERROR.

Version remains versionCode 1 / versionName 1.0.
