# Multi Device

Android project for **Multi Device** (`com.virtual.devicelization`).

## Release values

Current Gradle values are:

- `versionCode = 1`
- `versionName = "1.0"`

These values are **not locked**. Updates made to this project keep them unchanged unless the owner
explicitly asks for a version change. The owner can edit them manually at any time.

## Core rule

Multi Device may store many profiles, but **exactly one VM process may be active at a time**.
RUNNING, STARTING, STOPPING and QMP-paused/SUSPENDED states all reserve that single active slot.

## What is implemented

- Approved Multi Device launcher icon and neon Compose UI.
- Home, Profiles, Create/Edit Profile, Device, Network, Image Library, Running VM and Settings flows.
- Persistent profile configuration.
- Hard **MAX_ACTIVE_VM = 1** policy.
- Create, edit, clone and delete profile flows.
- Profile clone copies private writable disk/UEFI-variable data and always receives a new virtual MAC.
- Local disk snapshot/create/restore.
- Android 8 through Android 16 profile/API choices; boot still requires a real matching guest image.
- Device presets plus configurable CPU, RAM, storage, resolution, DPI and refresh-rate metadata.
- Per-profile locally-administered unicast virtual MAC generation.
- Manual MAC reset, keep-current and random-every-boot modes.
- Direct/NAT, Encrypted Tunnel and Offline network modes.
- Local `.mdvm`/ZIP Android guest image library/importer.
- Zip path-traversal protection, extraction/storage limits and QEMU argument allow-listing.
- Shared immutable drives plus isolated per-profile writable drive copies.
- Direct-kernel and ARM64 UEFI/pflash guest boot definitions.
- Per-profile writable UEFI variables.
- Local QEMU process lifecycle: prepare/start/pause/resume/shutdown/force-stop.
- Local loopback QMP control channel.
- Headless local QEMU display/input bridge using QMP screendump, absolute pointer events and QMP keyboard events; no VNC runtime dependency.
- Foreground service to keep the one active VM session owned by the app.
- Optional native parent-death launcher so QEMU cannot be intentionally left orphaned when the app dies.
- Runtime asset extraction (`assets/qemu`) into app-private storage.
- Host-VPN inspection and optional fail-closed VPN-loss kill switch for Encrypted Tunnel profiles.
- Backend state reconciliation so a dead runtime cannot remain shown as RUNNING.
- Native QEMU fetch/build helpers.
- ARM64 QEMU UEFI template firmware.
- Converter for user-supplied ARM64 LineageOS/QEMU UTM guest images.

## Local engine: no remote backend required

The VM backend can be completely local:

```text
Multi Device APK
  -> LocalQemuVmBackend
     -> Android/Bionic ARM64 qemu-system-aarch64 PIE process
        -> profile disks in app-private storage
        -> QMP loopback endpoint  (lifecycle + framebuffer + input)
        -> QMP 127.0.0.1:4444   (lifecycle)
        -> QEMU user-mode NAT   (when networking is enabled)
```

The native executable contract is:

`app/src/main/jniLibs/arm64-v8a/libqemu-system-aarch64.so`

The `.so` filename is deliberate: Android extracts files from `jniLibs`, while the project executes
this PIE binary as a subprocess rather than loading it as JNI.

### Prepare the local QEMU runtime

On a networked development machine:

```bash
./native-engine/prepare_local_engine.sh
```

That fetches a Podroid release APK and extracts only its Android ARM64 QEMU/SLIRP runtime and QEMU
support assets. Alternatively build it from source:

```bash
./native-engine/prepare_local_engine.sh --build
```

The build path needs Docker/Git/network. If `ANDROID_NDK_HOME` is set, the helper also builds the
small Multi Device parent-death launcher. See `THIRD_PARTY_NOTICES.md` before distributing binaries.

## Guest Android images

Multi Device does not fake an Android version by changing a string. Every bootable profile needs a
real guest image built for the virtual hardware it declares: kernel/boot chain, partition layout,
graphics, virtio devices, SELinux/fstab and Android userspace must agree.

The app imports `.mdvm`: a ZIP containing `manifest.json` and every referenced file. See
`guest-image-template/README.md` and `guest-image-template/manifest.json`.

Two boot styles are supported:

- **Direct kernel**: kernel + optional initrd/cmdline + drives.
- **ARM64 UEFI/pflash**: shared read-only firmware code + per-profile writable firmware variables + drives.

A QEMU ARM64 UEFI code file is included in `guest-image-template/edk2-aarch64-code.fd`.

For a compatible user-supplied LineageOS/QEMU UTM ARM64 image:

```bash
python3 tools/make_lineage_qemu_mdvm.py \
  --source UTM-VM-lineage-...-virtio_arm64only.zip \
  --firmware-code guest-image-template/edk2-aarch64-code.fd \
  --android-version 16 --api-level 36 \
  --id lineage-arm64 --name "LineageOS ARM64" \
  --output lineage-arm64.mdvm
```

Then import `lineage-arm64.mdvm` from **Library** in Multi Device. No LineageOS/Google Play guest is
redistributed by this source project.

## Per-profile isolation

Every profile stores its own:

- profile UUID and configuration,
- virtual MAC,
- writable drive copies,
- UEFI variable store (when applicable),
- snapshots,
- network mode/kill-switch configuration.

Read-only image components may be shared. Writable guest content is never intentionally shared
between profiles. Cloning explicitly copies private profile data into a new profile.

## Networking

### Direct / NAT

QEMU user-mode networking (`-netdev user`) gives the guest outbound connectivity through Android.

### Offline

The guest is started with no NIC.

### Encrypted Tunnel

Multi Device does not need a VPN server/backend of its own. In this implementation, an Encrypted
Tunnel profile requires an **already-active Android VPN that includes Multi Device's traffic**.
`HostVpnInspector` verifies that the network visible to the app is a VPN before VM startup. If
**Require VPN DNS** is enabled, the VPN network must also publish DNS resolvers through Android
`LinkProperties`. QEMU's NAT sockets are then opened by this app process and follow that host VPN
route. The saved region string is only a per-profile note; the actual exit region is selected in the
VPN provider/app.

If the profile's **Kill Switch** is enabled, Multi Device polls the app-visible VPN state while the
VM runs. If the VPN disappears, the local QEMU process is forcibly terminated instead of silently
continuing over the physical/default network. This is a fail-closed process-level guard; a device
VPN's own always-on/block-without-VPN mode is still the strongest system-level protection.

## Snapshots

Snapshots are conservative **disk/profile-data snapshots**, not live RAM checkpoints. If a running
profile is snapshotted, Multi Device cleanly stops it first, copies private profile data, and may
restart it afterward. Restoring is allowed only while the profile is inactive.

## Build configuration

- Android Gradle Plugin: 8.5.2
- Gradle: 8.7 wrapper bootstrap
- Kotlin: 1.9.24
- compileSdk / targetSdk: 34
- minSdk: 26
- Java/Kotlin target: 17
- production local VM runtime target: ARM64 (`arm64-v8a`)
- application backup disabled because VM/profile data is private state

After installing the local QEMU runtime and a compatible guest:

```bash
./gradlew assembleDebug
```

This artifact environment itself does not provide a complete Android SDK/NDK/device build/test
pipeline, so it cannot honestly claim a compiled APK or physical-device full-Android boot was
validated here. The source includes the integration and preparation tools needed to perform that
last build/device test on an Android development machine.

## Verification

```bash
python3 tools/verify_project.py

kotlinc \
  app/src/main/java/com/virtual/devicelization/core/model/Models.kt \
  app/src/main/java/com/virtual/devicelization/core/network/MacAddressGenerator.kt \
  app/src/main/java/com/virtual/devicelization/core/vm/SingleVmPolicy.kt \
  app/src/main/java/com/virtual/devicelization/core/image/UtmConfigParser.kt \
  core-selftest/CoreSelfTest.kt \
  -include-runtime -d /tmp/multidevice-selftest.jar
java -jar /tmp/multidevice-selftest.jar
```

The verifier reports `versionCode`/`versionName`; it does **not** enforce or lock them.

## Design references

Approved screen previews are in `design/previews/`. The selected icon is
`design/multi_device_icon_original.png`.

## First launch and guest images

- A fresh install starts with **zero profiles**. Multi Device never auto-creates sample/demo devices.
- The **Library** tab is the Android guest image manager. Full Android images are intentionally not bundled into the APK because each image can be around a gigabyte or more.
- The Catalog loads compatible ARM64 LineageOS/QEMU release variants on demand; users download only the image they want.
- Installed `.mdvm` / compatible UTM-QEMU ZIP bundles can also be imported locally.
- Profiles can only be created after at least one bootable Android image is installed.

## Local QEMU runtime at build time

`assembleDebug` / `assembleRelease` now depend on `prepareLocalQemuRuntime`. If `libqemu-system-aarch64.so` is not already present, Gradle fetches the latest Podroid release APK and extracts the local ARM64 QEMU runtime before packaging. If that download fails, the build fails rather than generating an APK that can never start a VM.


### LineageOS UTM archive compatibility

Catalog installs read the UTM bundle's `config.plist` and resolve the disk names declared there.
The importer does not require the first disk to be named `vda.qcow2`; renamed/build-generated vda
disks are supported. Downloaded release assets are size-checked and SHA-256 checked when GitHub
publishes a digest. A valid completed download is retained after an import error so the same image
can be retried without downloading it again.

## Persistent download / retry install behavior

Guest image downloads are now staged persistently under the app's files directory. Installation is a separate transaction. If extraction or validation fails, the completed ZIP remains available and the Library exposes Retry Install without performing another download. Partial downloads also remain resumable where the upstream server supports HTTP Range.
