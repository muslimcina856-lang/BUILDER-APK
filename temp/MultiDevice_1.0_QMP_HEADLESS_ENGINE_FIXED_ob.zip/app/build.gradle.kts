import java.security.MessageDigest
import java.util.zip.GZIPInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.virtual.devicelization"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.virtual.devicelization"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // User-managed release version. Do not auto-increment it during project updates.

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

val verifyEmbeddedArm64Firmware by tasks.registering {
    group = "verification"
    description = "Verifies the ARM64 EDK2 firmware bundled into res/raw before APK build"

    val firmware = layout.projectDirectory.file("src/main/res/raw/edk2_aarch64_code_fd.gz").asFile
    inputs.file(firmware)

    doLast {
        if (!firmware.isFile || firmware.length() <= 0L) {
            throw GradleException(
                "Missing app/src/main/res/raw/edk2_aarch64_code_fd.gz. " +
                    "Android guest images cannot install without the bundled ARM64 UEFI firmware."
            )
        }

        val digest: MessageDigest = MessageDigest.getInstance("SHA-256")
        var bytes = 0L
        GZIPInputStream(firmware.inputStream().buffered(1024 * 1024)).use { input: GZIPInputStream ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count: Int = input.read(buffer)
                if (count <= 0) break
                bytes += count.toLong()
                digest.update(buffer, 0, count)
            }
        }
        val sha = digest.digest().joinToString(separator = "") { byte: Byte ->
            "%02x".format(byte.toInt() and 0xff)
        }
        if (bytes != 67_108_864L) {
            throw GradleException("Bundled ARM64 UEFI firmware has invalid decompressed size: $bytes")
        }
        if (!sha.equals("47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d", ignoreCase = true)) {
            throw GradleException("Bundled ARM64 UEFI firmware failed SHA-256 verification: $sha")
        }
        logger.lifecycle("Multi Device: embedded ARM64 UEFI firmware verified")
    }
}

val prepareLocalQemuRuntime by tasks.registering {
    group = "build setup"
    description = "Ensures the local ARM64 QEMU runtime is packaged in the APK"

    val runtimeFile = layout.projectDirectory.file(
        "src/main/jniLibs/arm64-v8a/libqemu-system-aarch64.so"
    ).asFile
    val fetchScript = rootProject.layout.projectDirectory.file(
        "native-engine/fetch_prebuilt_qemu.py"
    ).asFile

    inputs.file(fetchScript)
    outputs.file(runtimeFile)

    doLast {
        if (!runtimeFile.isFile) {
            logger.lifecycle("Multi Device: local QEMU runtime missing; preparing it now...")

            fun runPython(executable: String): Int {
                return try {
                    project.exec {
                        commandLine(
                            executable,
                            fetchScript.absolutePath,
                            "--root",
                            rootProject.projectDir.absolutePath
                        )
                        isIgnoreExitValue = true
                    }.exitValue
                } catch (_: Exception) {
                    -1
                }
            }

            var exitCode = runPython("python3")
            if (exitCode != 0) {
                logger.lifecycle("Multi Device: python3 unavailable/failed; trying python...")
                exitCode = runPython("python")
            }

            if (exitCode != 0 || !runtimeFile.isFile) {
                throw GradleException(
                    "Unable to prepare libqemu-system-aarch64.so. " +
                        "Run native-engine/prepare_local_engine.sh manually or place the ARM64 " +
                        "runtime in app/src/main/jniLibs/arm64-v8a/."
                )
            }
        }

        if (runtimeFile.length() <= 0L) {
            throw GradleException("Packaged QEMU runtime is empty: ${runtimeFile.absolutePath}")
        }

        logger.lifecycle("Multi Device: local QEMU runtime ready (${runtimeFile.length()} bytes)")
    }
}

tasks.named("preBuild") {
    dependsOn(verifyEmbeddedArm64Firmware)
    dependsOn(prepareLocalQemuRuntime)
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
