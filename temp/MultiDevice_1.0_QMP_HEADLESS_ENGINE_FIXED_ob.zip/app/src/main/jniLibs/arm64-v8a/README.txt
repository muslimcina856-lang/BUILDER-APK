Native runtime output directory.

Required for the local VM engine:
  libqemu-system-aarch64.so   ARM64 Android/Bionic PIE QEMU executable

Optional/recommended:
  libslirp.so                 if required by the QEMU build
  libmultidevice-launcher.so  PR_SET_PDEATHSIG wrapper

From the project root run:
  ./native-engine/prepare_local_engine.sh

or build QEMU from the open-source Android pipeline:
  ./native-engine/prepare_local_engine.sh --build

Do not place a desktop Linux QEMU binary here; the executable must target Android/Bionic arm64-v8a.
