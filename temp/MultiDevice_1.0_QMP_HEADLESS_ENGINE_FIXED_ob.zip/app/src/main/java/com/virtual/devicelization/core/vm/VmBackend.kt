package com.virtual.devicelization.core.vm

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.virtual.devicelization.core.model.Profile

/**
 * Boundary for the virtualization engine.
 * UI/profile code must not depend directly on QEMU, AVF, crosvm, JNI, or a vendor runtime.
 */
interface VmBackend {
    fun status(): VmBackendStatus
    suspend fun prepare(profile: Profile): Result<Unit>
    suspend fun start(profile: Profile): Result<Unit>
    suspend fun suspendVm(profile: Profile): Result<Unit>
    suspend fun resume(profile: Profile): Result<Unit>
    suspend fun shutdown(profile: Profile): Result<Unit>
    suspend fun forceStop(profile: Profile): Result<Unit>
    fun isRunning(profileId: String): Boolean = false
}

data class VmBackendStatus(
    val backendName: String,
    val available: Boolean,
    val arm64: Boolean,
    val avfFeaturePresent: Boolean,
    val avfJavaApiPresent: Boolean,
    val manageVmPermissionGranted: Boolean,
    val fullAndroidGuestSupported: Boolean,
    val message: String,
)

/**
 * Capability scanner retained as diagnostics only. Multi Device's portable production path is the
 * local userspace engine; it does not require AVF or a remote server.
 */
class StockAndroidCapabilityScanner(private val context: Context) {
    fun scan(): VmBackendStatus {
        val arm64 = Build.SUPPORTED_64_BIT_ABIS.any { it.contains("arm64", ignoreCase = true) }
        val avfFeature = context.packageManager.hasSystemFeature("android.software.virtualization_framework")
        val avfApi = runCatching { Class.forName("android.system.virtualmachine.VirtualMachineManager") }.isSuccess
        val permission = context.checkSelfPermission("android.permission.MANAGE_VIRTUAL_MACHINE") == PackageManager.PERMISSION_GRANTED
        return VmBackendStatus(
            backendName = "Android host diagnostics",
            available = false,
            arm64 = arm64,
            avfFeaturePresent = avfFeature,
            avfJavaApiPresent = avfApi,
            manageVmPermissionGranted = permission,
            fullAndroidGuestSupported = false,
            message = if (avfFeature) "AVF detected for diagnostics; Multi Device uses its local userspace engine when installed."
            else "AVF not detected; this does not prevent the local userspace engine from running.",
        )
    }
}
