package com.virtual.devicelization.core.vm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Extracts QEMU ROM/keymap assets from the APK into app-private storage for QEMU's -L data dir. */
class QemuAssetInstaller(private val context: Context) {
    private val outputDir = File(context.filesDir, "qemu")

    suspend fun ensureInstalled(): File = withContext(Dispatchers.IO) {
        outputDir.mkdirs()
        copyAssetTree("qemu", outputDir)
        outputDir
    }

    private fun copyAssetTree(assetPath: String, destination: File) {
        val children = context.assets.list(assetPath).orEmpty()
        if (children.isEmpty()) {
            // AssetManager also returns an empty list for an absent/empty directory. A runtime may
            // work without optional ROM/keymap assets, so do not turn that into a false VM error.
            runCatching { copyFileIfChanged(assetPath, destination) }
            return
        }
        destination.mkdirs()
        for (child in children) {
            copyAssetTree("$assetPath/$child", File(destination, child))
        }
    }

    private fun copyFileIfChanged(assetPath: String, destination: File) {
        val bytes = context.assets.open(assetPath).use { it.readBytes() }
        if (destination.isFile && destination.length() == bytes.size.toLong()) return
        destination.parentFile?.mkdirs()
        destination.outputStream().use { it.write(bytes) }
    }
}
