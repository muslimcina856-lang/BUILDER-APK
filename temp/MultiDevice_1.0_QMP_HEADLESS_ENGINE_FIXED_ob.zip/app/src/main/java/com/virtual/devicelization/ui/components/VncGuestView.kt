package com.virtual.devicelization.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.virtual.devicelization.core.display.VncClient

/** Live loopback display/input surface for the one running local QEMU guest. */
class LocalVncView(context: Context) : View(context), VncClient.Listener {
    private var client: VncClient? = null
    private var framebuffer: Bitmap? = null
    private val destination = RectF()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(169, 182, 211)
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.scaledDensity
    }
    @Volatile private var statusText = "Connecting to local guest display…"
    private var pointerDown = false
    private var lastKeyboardRequest = 0

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        connectIfNeeded()
    }

    override fun onDetachedFromWindow() {
        client?.stop()
        client = null
        framebuffer?.recycle()
        framebuffer = null
        super.onDetachedFromWindow()
    }

    private fun connectIfNeeded() {
        if (!isAttachedToWindow || client != null) return
        statusText = "Connecting to local guest display…"
        invalidate()
        val c = VncClient(listener = this)
        client = c
        Thread({ c.runBlocking() }, "MultiDevice-VNC").apply { isDaemon = true }.start()
    }

    override fun onFramebufferSize(width: Int, height: Int) {
        post {
            framebuffer?.recycle()
            framebuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            statusText = "Guest display connected"
            invalidate()
        }
    }

    override fun onRawRectangle(x: Int, y: Int, width: Int, height: Int, argb: IntArray) {
        post {
            val bitmap = framebuffer ?: return@post
            if (x >= 0 && y >= 0 && x + width <= bitmap.width && y + height <= bitmap.height) {
                bitmap.setPixels(argb, 0, width, x, y, width, height)
                invalidate()
            }
        }
    }

    override fun onConnected(name: String) {
        post {
            statusText = if (name.isBlank()) "Guest display connected" else name
            invalidate()
        }
    }

    override fun onDisconnected(message: String?) {
        post {
            statusText = message?.let { "Display disconnected: $it" } ?: "Guest display disconnected"
            client = null
            invalidate()
            if (isAttachedToWindow) postDelayed({ connectIfNeeded() }, 900)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(3, 7, 18))
        val bitmap = framebuffer
        if (bitmap == null || bitmap.isRecycled) {
            canvas.drawText(statusText, width / 2f, height / 2f, textPaint)
            return
        }
        val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        val left = (width - drawW) / 2f
        val top = (height - drawH) / 2f
        destination.set(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bitmap, null, destination, bitmapPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bitmap = framebuffer ?: return true
        if (destination.width() <= 0f || destination.height() <= 0f) return true
        val inside = event.x in destination.left..destination.right && event.y in destination.top..destination.bottom
        val gx = (((event.x - destination.left) / destination.width()) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
        val gy = (((event.y - destination.top) / destination.height()) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (inside) {
                requestFocus()
                pointerDown = true
                client?.sendPointer(gx, gy, 1)
            }
            MotionEvent.ACTION_MOVE -> if (inside && pointerDown) client?.sendPointer(gx, gy, 1)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                client?.sendPointer(gx, gy, 0)
                pointerDown = false
            }
        }
        return true
    }

    fun showKeyboard(requestToken: Int = lastKeyboardRequest + 1) {
        if (requestToken <= lastKeyboardRequest) return
        lastKeyboardRequest = requestToken
        requestFocus()
        val imm = context.getSystemService(InputMethodManager::class.java)
        imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return object : BaseInputConnection(this, false) {
            private var composing = ""

            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val committed = text?.toString().orEmpty()
                if (committed != composing) {
                    if (composing.isNotEmpty()) repeat(composing.codePointCount(0, composing.length)) { sendKeySym(KEYSYM_BACKSPACE) }
                    if (committed.isNotEmpty()) sendText(committed)
                }
                composing = ""
                return true
            }

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val next = text?.toString().orEmpty()
                if (next.startsWith(composing)) {
                    sendText(next.substring(composing.length))
                } else {
                    repeat(composing.codePointCount(0, composing.length)) { sendKeySym(KEYSYM_BACKSPACE) }
                    sendText(next)
                }
                composing = next
                return true
            }

            override fun finishComposingText(): Boolean {
                composing = ""
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                composing = ""
                repeat(beforeLength.coerceIn(0, 128)) { sendKeySym(KEYSYM_BACKSPACE) }
                repeat(afterLength.coerceIn(0, 128)) { sendKeySym(KEYSYM_DELETE) }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean = handlePhysicalKey(event)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = handlePhysicalKey(event)
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean = handlePhysicalKey(event)

    private fun handlePhysicalKey(event: KeyEvent): Boolean {
        val keySym = androidKeyToXKeySym(event) ?: return false
        client?.sendKey(keySym, event.action == KeyEvent.ACTION_DOWN)
        return true
    }

    private fun sendText(text: String) {
        var offset = 0
        while (offset < text.length) {
            val cp = text.codePointAt(offset)
            val keySym = if (cp in 0x20..0x7e) cp else 0x01000000 or cp
            sendKeySym(keySym)
            offset += Character.charCount(cp)
        }
    }

    private fun sendKeySym(keySym: Int) {
        client?.sendKey(keySym, true)
        client?.sendKey(keySym, false)
    }

    private fun androidKeyToXKeySym(event: KeyEvent): Int? {
        return when (event.keyCode) {
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> KEYSYM_RETURN
            KeyEvent.KEYCODE_DEL -> KEYSYM_BACKSPACE
            KeyEvent.KEYCODE_FORWARD_DEL -> KEYSYM_DELETE
            KeyEvent.KEYCODE_TAB -> KEYSYM_TAB
            KeyEvent.KEYCODE_ESCAPE -> KEYSYM_ESCAPE
            KeyEvent.KEYCODE_DPAD_LEFT -> 0xFF51
            KeyEvent.KEYCODE_DPAD_UP -> 0xFF52
            KeyEvent.KEYCODE_DPAD_RIGHT -> 0xFF53
            KeyEvent.KEYCODE_DPAD_DOWN -> 0xFF54
            KeyEvent.KEYCODE_MOVE_HOME -> 0xFF50
            KeyEvent.KEYCODE_MOVE_END -> 0xFF57
            KeyEvent.KEYCODE_PAGE_UP -> 0xFF55
            KeyEvent.KEYCODE_PAGE_DOWN -> 0xFF56
            KeyEvent.KEYCODE_SHIFT_LEFT -> 0xFFE1
            KeyEvent.KEYCODE_SHIFT_RIGHT -> 0xFFE2
            KeyEvent.KEYCODE_CTRL_LEFT -> 0xFFE3
            KeyEvent.KEYCODE_CTRL_RIGHT -> 0xFFE4
            KeyEvent.KEYCODE_ALT_LEFT -> 0xFFE9
            KeyEvent.KEYCODE_ALT_RIGHT -> 0xFFEA
            in KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12 -> 0xFFBE + (event.keyCode - KeyEvent.KEYCODE_F1)
            else -> event.unicodeChar.takeIf { it > 0 }?.let { cp -> if (cp <= 0xFF) cp else 0x01000000 or cp }
        }
    }

    companion object {
        private const val KEYSYM_BACKSPACE = 0xFF08
        private const val KEYSYM_TAB = 0xFF09
        private const val KEYSYM_RETURN = 0xFF0D
        private const val KEYSYM_ESCAPE = 0xFF1B
        private const val KEYSYM_DELETE = 0xFFFF
    }
}

@Composable
fun VncGuestView(modifier: Modifier = Modifier, keyboardRequest: Int = 0) {
    AndroidView(
        modifier = modifier,
        factory = { LocalVncView(it) },
        update = { view -> if (keyboardRequest > 0) view.showKeyboard(keyboardRequest) },
    )
}
