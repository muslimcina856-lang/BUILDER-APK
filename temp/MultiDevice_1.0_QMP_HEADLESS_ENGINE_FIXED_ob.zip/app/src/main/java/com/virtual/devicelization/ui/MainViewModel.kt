package com.virtual.devicelization.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.virtual.devicelization.core.image.*
import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.core.vm.LocalEngineRegistry
import com.virtual.devicelization.core.vm.SingleVmPolicy
import com.virtual.devicelization.core.vm.VmBackend
import com.virtual.devicelization.core.vm.VmBackendStatus
import com.virtual.devicelization.data.ProfileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID

enum class StartResult { STARTED, CONFLICT, FAILED }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val store = ProfileStore(application)
    private val imageStore = LocalEngineRegistry.imageStore(application)
    private val backend: VmBackend = LocalEngineRegistry.backend(application)
    private val remoteCatalog = RemoteImageCatalog(application)
    private val vmOperationMutex = Mutex()

    val profiles = mutableStateListOf<Profile>()
    val guestImages = mutableStateListOf<GuestImageManifest>()
    val backendStatus: VmBackendStatus get() = backend.status()

    var remoteImages by mutableStateOf<List<RemoteGuestImage>>(emptyList())
        private set
    var catalogLoading by mutableStateOf(false)
        private set
    var catalogError by mutableStateOf<String?>(null)
        private set
    var imageDownloadProgress by mutableStateOf<ImageDownloadProgress?>(null)
        private set
    var installingImageId by mutableStateOf<String?>(null)
        private set
    var downloadedImageIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var imageInstallErrors by mutableStateOf<Map<String, String>>(emptyMap())
        private set

    var operationMessage by mutableStateOf<String?>(null)
        private set

    init {
        /*
         * A native child VM belongs to the current application-process lifetime. Never trust a
         * persisted RUNNING/SUSPENDED state after process recreation; the backend is source of truth.
         */
        val loaded = store.load().map { profile ->
            when {
                backend.isRunning(profile.id) && profile.status !in activeStates -> profile.copy(status = VmStatus.RUNNING)
                !backend.isRunning(profile.id) && profile.status in activeStates -> profile.copy(status = VmStatus.STOPPED)
                !backend.isRunning(profile.id) && profile.status == VmStatus.ERROR -> profile.copy(status = VmStatus.STOPPED)
                else -> profile
            }
        }
        profiles.addAll(loaded)
        refreshImages()
        SingleVmPolicy.assertInvariant(profiles)
        persist()
    }

    val activeProfile: Profile? get() = SingleVmPolicy.activeProfile(profiles)

    fun consumeMessage() { operationMessage = null }

    fun refreshImages() {
        guestImages.clear()
        guestImages.addAll(imageStore.list())
    }

    fun refreshRemoteCatalog() {
        if (catalogLoading) return
        catalogLoading = true
        catalogError = null
        viewModelScope.launch {
            remoteCatalog.fetch()
                .onSuccess { images ->
                    remoteImages = images
                    refreshDownloadedImageState(images)
                }
                .onFailure { catalogError = it.message ?: "Unable to load image catalog." }
            catalogLoading = false
        }
    }

    private suspend fun refreshDownloadedImageState(images: List<RemoteGuestImage> = remoteImages) {
        val downloaded = mutableSetOf<String>()
        for (image in images) {
            if (remoteCatalog.downloadedFile(image) != null) downloaded += image.id
        }
        downloadedImageIds = downloaded
    }

    fun downloadRemoteImage(image: RemoteGuestImage) {
        if (installingImageId != null) {
            operationMessage = "Wait for the current image download/install to finish."
            return
        }
        if (guestImages.any { it.id == GuestImageStore.sanitizeId(image.id) }) {
            operationMessage = "${image.name} is already installed."
            return
        }
        installingImageId = image.id
        imageInstallErrors = imageInstallErrors - image.id
        imageDownloadProgress = ImageDownloadProgress(image.id, 0, image.sizeBytes)
        viewModelScope.launch {
            val downloaded = remoteCatalog.download(image) { progress -> imageDownloadProgress = progress }
            if (downloaded.isFailure) {
                operationMessage = downloaded.exceptionOrNull()?.message ?: "Unable to download Android image."
                imageDownloadProgress = null
                installingImageId = null
                refreshDownloadedImageState()
                return@launch
            }

            val file = downloaded.getOrThrow()
            downloadedImageIds = downloadedImageIds + image.id
            imageDownloadProgress = null
            installDownloadedImageInternal(image, file)
        }
    }

    /** Retry installation from the persistent completed ZIP without performing a network request. */
    fun installDownloadedImage(image: RemoteGuestImage) {
        if (installingImageId != null) {
            operationMessage = "Wait for the current image download/install to finish."
            return
        }
        if (guestImages.any { it.id == GuestImageStore.sanitizeId(image.id) }) {
            operationMessage = "${image.name} is already installed."
            return
        }
        installingImageId = image.id
        imageInstallErrors = imageInstallErrors - image.id
        imageDownloadProgress = null
        viewModelScope.launch {
            val file = remoteCatalog.downloadedFile(image)
            if (file == null) {
                downloadedImageIds = downloadedImageIds - image.id
                imageInstallErrors = imageInstallErrors + (image.id to "The completed local archive is missing or failed verification.")
                operationMessage = "Local download is missing or corrupt. Download is required again."
                installingImageId = null
                return@launch
            }
            installDownloadedImageInternal(image, file)
        }
    }

    private suspend fun installDownloadedImageInternal(image: RemoteGuestImage, file: java.io.File) {
        operationMessage = "Installing ${image.name} from the completed local download…"
        val result = imageStore.importLineageUtmZip(file, image)
        if (result.manifest != null) {
            // Only delete the large archive after the final installed image has been reopened and
            // validated successfully. Any install failure keeps the ZIP for Retry Install.
            remoteCatalog.discardDownload(image)
            downloadedImageIds = downloadedImageIds - image.id
            imageInstallErrors = imageInstallErrors - image.id
            refreshImages()
            operationMessage = "Installed ${result.manifest.name}. You can now create a profile with it."
        } else {
            val error = result.error ?: "Unable to install downloaded Android image."
            downloadedImageIds = downloadedImageIds + image.id
            imageInstallErrors = imageInstallErrors + (image.id to error)
            operationMessage = "$error Download is still saved. Tap Retry Install; it will not download again."
        }
        imageDownloadProgress = null
        installingImageId = null
    }

    fun reconcileBackendState() {
        var changed = false
        profiles.indices.forEach { index ->
            val p = profiles[index]
            val alive = backend.isRunning(p.id)
            when {
                alive && p.status !in activeStates -> {
                    profiles[index] = p.copy(status = VmStatus.RUNNING)
                    changed = true
                }
                !alive && p.status in setOf(VmStatus.RUNNING, VmStatus.SUSPENDED, VmStatus.RESUMING, VmStatus.SUSPENDING) -> {
                    profiles[index] = p.copy(status = VmStatus.ERROR)
                    operationMessage = "${p.name} stopped unexpectedly. Check the VM log and VPN state if Encrypted Tunnel was enabled."
                    changed = true
                }
            }
        }
        if (changed) {
            SingleVmPolicy.assertInvariant(profiles)
            persist()
        }
    }

    fun importGuestImage(uri: Uri) {
        viewModelScope.launch {
            val result = imageStore.importBundle(uri)
            if (result.manifest != null) {
                refreshImages()
                operationMessage = "Installed ${result.manifest.name}."
            } else {
                operationMessage = result.error ?: "Unable to import Android image bundle."
            }
        }
    }

    fun deleteGuestImage(imageId: String) {
        if (profiles.any { it.status in activeStates && imageStore.findFor(it)?.id == imageId }) {
            operationMessage = "Stop the profile using this image before deleting it."
            return
        }
        viewModelScope.launch {
            val deleted = withContext(Dispatchers.IO) { imageStore.delete(imageId) }
            if (deleted) {
                profiles.indices.forEach { index ->
                    if (profiles[index].imageId == imageId) profiles[index] = profiles[index].copy(imageId = null)
                }
                persist()
                refreshImages()
                operationMessage = "Android image deleted."
            } else {
                operationMessage = "Android image was not found."
            }
        }
    }

    fun createProfile(
        name: String,
        imageId: String,
        device: DeviceConfig,
        network: NetworkConfig,
    ): Profile? {
        val image = guestImages.firstOrNull { it.id == imageId }
        if (image == null) {
            operationMessage = "Install/select an Android image before creating the profile."
            return null
        }
        val profile = Profile(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "New Profile" },
            androidVersion = image.androidVersion,
            apiLevel = image.apiLevel,
            architecture = image.architecture,
            imageId = image.id,
            modelLabel = device.preset,
            device = device,
            network = ensureUniqueMac(network),
            status = VmStatus.STOPPED,
        )
        profiles += profile
        persist()
        return profile
    }

    fun updateProfile(profile: Profile): Boolean {
        val index = profiles.indexOfFirst { it.id == profile.id }
        if (index < 0) return false
        if (profiles[index].status in activeStates) {
            operationMessage = "Stop the profile before editing its virtual hardware or image settings."
            return false
        }
        val image = profile.imageId?.let { id -> guestImages.firstOrNull { it.id == id } }
        if (image == null) {
            operationMessage = "The selected Android image is not installed."
            return false
        }
        profiles[index] = profile.copy(
            androidVersion = image.androidVersion,
            apiLevel = image.apiLevel,
            architecture = image.architecture,
            imageId = image.id,
            modelLabel = profile.device.preset,
            network = ensureUniqueMac(profile.network, profile.id),
            status = VmStatus.STOPPED,
        )
        persist()
        operationMessage = "Profile updated."
        return true
    }

    fun cloneProfile(profileId: String): Profile? {
        val source = profiles.firstOrNull { it.id == profileId } ?: return null
        if (source.status in activeStates) {
            operationMessage = "Stop the profile before cloning its disk data."
            return null
        }
        val clone = source.copy(
            id = UUID.randomUUID().toString(),
            name = "${source.name} Copy",
            network = source.network.copy(virtualMac = generateUniqueMac()),
            status = VmStatus.CREATING,
            createdAtEpochMs = System.currentTimeMillis(),
        )
        profiles += clone
        persist()
        operationMessage = "Cloning profile data…"
        viewModelScope.launch {
            runCatching { imageStore.cloneProfileData(source.id, clone.id) }
                .onSuccess {
                    setStatusInternal(clone.id, VmStatus.STOPPED)
                    operationMessage = "Profile cloned with isolated disk data and a new virtual MAC."
                }
                .onFailure {
                    setStatusInternal(clone.id, VmStatus.ERROR)
                    operationMessage = it.message ?: "Unable to clone profile data."
                }
        }
        return clone
    }

    fun createSnapshot(profileId: String) {
        viewModelScope.launch {
            var restartAfter = false
            vmOperationMutex.withLock {
                var profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                if (profile.status in setOf(VmStatus.STARTING, VmStatus.STOPPING, VmStatus.CREATING)) {
                    operationMessage = "Wait for the current VM operation to finish before taking a snapshot."
                    return@withLock
                }
                if (profile.status in setOf(VmStatus.RUNNING, VmStatus.SUSPENDED)) {
                    if (profile.status == VmStatus.SUSPENDED && backend.isRunning(profile.id)) {
                        val resumed = backend.resume(profile)
                        if (resumed.isFailure) {
                            operationMessage = resumed.exceptionOrNull()?.message ?: "Unable to resume VM for snapshot."
                            return@withLock
                        }
                    }
                    setStatusInternal(profile.id, VmStatus.STOPPING)
                    val stopped = backend.shutdown(profile)
                    if (stopped.isFailure) {
                        setStatusInternal(profile.id, VmStatus.ERROR)
                        operationMessage = stopped.exceptionOrNull()?.message ?: "Unable to stop VM cleanly for snapshot."
                        return@withLock
                    }
                    setStatusInternal(profile.id, VmStatus.STOPPED)
                    restartAfter = true
                    profile = profiles.first { it.id == profileId }
                }
                runCatching { imageStore.createProfileSnapshot(profile) }
                    .onSuccess { operationMessage = "Disk snapshot created: ${it.id}" }
                    .onFailure { operationMessage = it.message ?: "Unable to create snapshot." }
            }
            if (restartAfter) startProfile(profileId, forceSwitch = false) { }
        }
    }

    fun restoreLatestSnapshot(profileId: String) {
        val profile = profiles.firstOrNull { it.id == profileId } ?: return
        if (profile.status in activeStates) {
            operationMessage = "Stop the profile before restoring a snapshot."
            return
        }
        viewModelScope.launch {
            runCatching { imageStore.restoreLatestProfileSnapshot(profile) }
                .onSuccess { restored -> operationMessage = if (restored) "Latest disk snapshot restored." else "No snapshot exists for this profile." }
                .onFailure { operationMessage = it.message ?: "Unable to restore snapshot." }
        }
    }

    fun resetMac(profileId: String): String? {
        val index = profiles.indexOfFirst { it.id == profileId }
        if (index < 0) return null
        val mac = generateUniqueMac()
        profiles[index] = profiles[index].copy(network = profiles[index].network.copy(virtualMac = mac))
        persist()
        operationMessage = if (profiles[index].status in activeStates) {
            "Virtual MAC changed to $mac. It applies on the next VM boot."
        } else {
            "Virtual MAC reset to $mac"
        }
        return mac
    }

    fun startProfile(profileId: String, forceSwitch: Boolean = false, onResult: (StartResult) -> Unit) {
        if (profiles.none { it.id == profileId }) {
            onResult(StartResult.FAILED)
            return
        }
        viewModelScope.launch {
            vmOperationMutex.withLock {
                if (!forceSwitch && !SingleVmPolicy.canStart(profiles, profileId)) {
                    onResult(StartResult.CONFLICT)
                    return@withLock
                }

                if (forceSwitch) {
                    val other = SingleVmPolicy.activeProfile(profiles)?.takeIf { it.id != profileId }
                    if (other != null) {
                        val stopped = backend.shutdown(other)
                        if (stopped.isFailure) {
                            setStatusInternal(other.id, VmStatus.ERROR)
                            operationMessage = stopped.exceptionOrNull()?.message ?: "Unable to stop the current VM."
                            onResult(StartResult.FAILED)
                            return@withLock
                        }
                        setStatusInternal(other.id, VmStatus.STOPPED)
                    }
                }

                var target: Profile = profiles.firstOrNull { it.id == profileId } ?: run {
                    onResult(StartResult.FAILED)
                    return@withLock
                }
                if (target.status == VmStatus.CREATING) {
                    operationMessage = "This profile is still being created/cloned."
                    onResult(StartResult.FAILED)
                    return@withLock
                }

                if (target.status == VmStatus.SUSPENDED && backend.isRunning(target.id)) {
                    setStatusInternal(target.id, VmStatus.RESUMING)
                    val resumed = backend.resume(target)
                    if (resumed.isSuccess) {
                        setStatusInternal(target.id, VmStatus.RUNNING)
                        onResult(StartResult.STARTED)
                    } else {
                        setStatusInternal(target.id, VmStatus.ERROR)
                        operationMessage = resumed.exceptionOrNull()?.message ?: "Unable to resume VM."
                        onResult(StartResult.FAILED)
                    }
                    return@withLock
                }

                if (target.network.macMode == MacMode.RANDOM_EVERY_BOOT) {
                    resetMac(profileId)
                    target = profiles.firstOrNull { it.id == profileId } ?: target
                }

                setStatusInternal(profileId, VmStatus.STARTING)
                val prepared = backend.prepare(target)
                if (prepared.isFailure) {
                    // prepare() is preflight only; no QEMU process exists yet. Keep the profile usable
                    // instead of persisting a misleading ERROR state for permission/VPN/image checks.
                    setStatusInternal(profileId, VmStatus.STOPPED)
                    operationMessage = prepared.exceptionOrNull()?.message ?: "Unable to prepare VM."
                    onResult(StartResult.FAILED)
                    return@withLock
                }

                val started = backend.start(target)
                if (started.isSuccess) {
                    setStatusInternal(profileId, VmStatus.RUNNING)
                    onResult(StartResult.STARTED)
                } else {
                    setStatusInternal(profileId, VmStatus.ERROR)
                    operationMessage = started.exceptionOrNull()?.message ?: "Unable to start VM."
                    onResult(StartResult.FAILED)
                }
            }
        }
    }

    fun stopProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.STOPPING)
                val result = backend.shutdown(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.STOPPED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to stop VM."
            }
            onDone?.invoke()
        }
    }

    fun forceStopProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                val result = backend.forceStop(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.STOPPED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to force-stop VM."
            }
            onDone?.invoke()
        }
    }

    fun suspendProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.SUSPENDING)
                val result = backend.suspendVm(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.SUSPENDED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to suspend VM."
            }
            onDone?.invoke()
        }
    }

    fun resumeProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.RESUMING)
                val result = backend.resume(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.RUNNING else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to resume VM."
            }
            onDone?.invoke()
        }
    }

    fun restartProfile(profileId: String) {
        viewModelScope.launch {
            val shouldStart = vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock false
                val stopped = backend.shutdown(profile)
                if (stopped.isFailure) {
                    setStatusInternal(profileId, VmStatus.ERROR)
                    operationMessage = stopped.exceptionOrNull()?.message ?: "Unable to restart VM."
                    false
                } else {
                    setStatusInternal(profileId, VmStatus.STOPPED)
                    true
                }
            }
            if (shouldStart) startProfile(profileId, forceSwitch = false) { }
        }
    }

    fun deleteProfile(id: String) {
        if (profiles.firstOrNull { it.id == id }?.status in activeStates) {
            operationMessage = "Stop the active profile before deleting it."
            return
        }
        profiles.removeAll { it.id == id }
        persist()
        viewModelScope.launch {
            imageStore.deleteProfileData(id)
            operationMessage = "Profile and its private disk data deleted."
        }
    }

    private fun setStatusInternal(id: String, status: VmStatus) {
        val index = profiles.indexOfFirst { it.id == id }
        if (index >= 0) profiles[index] = profiles[index].copy(status = status)
        SingleVmPolicy.assertInvariant(profiles)
        persist()
    }

    private fun ensureUniqueMac(network: NetworkConfig, exceptProfileId: String? = null): NetworkConfig {
        val duplicate = profiles.any {
            it.id != exceptProfileId && it.network.virtualMac.equals(network.virtualMac, ignoreCase = true)
        }
        return if (duplicate || !MacAddressGenerator.isLocallyAdministeredUnicast(network.virtualMac)) {
            network.copy(virtualMac = generateUniqueMac())
        } else network
    }

    private fun generateUniqueMac(): String {
        var mac: String
        do mac = MacAddressGenerator.generate()
        while (profiles.any { it.network.virtualMac.equals(mac, ignoreCase = true) })
        return mac
    }

    private fun persist() = store.save(profiles)

    companion object {
        private val activeStates = setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )
    }
}
