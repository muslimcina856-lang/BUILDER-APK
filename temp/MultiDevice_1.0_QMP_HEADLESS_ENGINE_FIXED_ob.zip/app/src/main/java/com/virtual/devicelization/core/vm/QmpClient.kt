package com.virtual.devicelization.core.vm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket

/** Small one-command-per-connection QMP client for the loopback-only local QEMU process. */
class QmpClient(
    private val host: String = "127.0.0.1",
    private val port: Int = QemuCommandBuilder.DEFAULT_QMP_PORT,
    private val timeoutMs: Int = 6_000,
) {
    suspend fun execute(command: String, arguments: JSONObject? = null): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            // screendump and input are issued by different threads. Serialize QMP transactions so
            // command responses can never be confused and the headless runtime sees a small load.
            synchronized(globalCommandLock) {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), 1_500)
                    socket.soTimeout = timeoutMs
                    val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                    val writer = OutputStreamWriter(socket.getOutputStream())

                    val greeting = reader.readLine() ?: error("QMP greeting missing")
                    val greetingJson = JSONObject(greeting)
                    check(greetingJson.has("QMP")) { "Invalid QMP greeting" }

                    writer.write("{\"execute\":\"qmp_capabilities\"}\r\n")
                    writer.flush()
                    val capabilities = readUntilReturn(reader)
                    throwIfError(capabilities)

                    val request = JSONObject().put("execute", command)
                    if (arguments != null) request.put("arguments", arguments)
                    writer.write(request.toString())
                    writer.write("\r\n")
                    writer.flush()
                    val response = readUntilReturn(reader)
                    throwIfError(response)
                    response
                }
            }
        }
    }

    suspend fun commandNames(): Result<Set<String>> = execute("query-commands").map { response ->
        val items: JSONArray = response.optJSONArray("return") ?: JSONArray()
        buildSet {
            for (i in 0 until items.length()) {
                val name = items.optJSONObject(i)?.optString("name").orEmpty()
                if (name.isNotBlank()) add(name)
            }
        }
    }

    suspend fun queryStatus(): Result<String> = execute("query-status").map { response ->
        response.optJSONObject("return")?.optString("status").orEmpty()
    }

    private fun throwIfError(response: JSONObject) {
        if (response.has("error")) {
            val error = response.getJSONObject("error")
            throw IllegalStateException(error.optString("desc", error.toString()))
        }
    }

    private fun readUntilReturn(reader: BufferedReader): JSONObject {
        while (true) {
            val line = reader.readLine() ?: error("QMP connection closed")
            val json = JSONObject(line)
            // QMP may interleave asynchronous events; only a command response ends this call.
            if (json.has("return") || json.has("error")) return json
        }
    }

    companion object {
        private val globalCommandLock = Any()
    }
}
