package com.virtual.devicelization.core.vm

/**
 * Process-local connection information for the one allowed active VM.
 *
 * This is intentionally not persisted: if the app process dies, the registry/backend reconciles
 * the VM state instead of trusting stale loopback endpoints from a previous process.
 */
object VmRuntimeState {
    @Volatile var activeProfileId: String? = null
        private set
    @Volatile var qmpPort: Int? = null
        private set

    @Synchronized
    fun activate(profileId: String, port: Int) {
        activeProfileId = profileId
        qmpPort = port
    }

    @Synchronized
    fun clear(profileId: String? = null) {
        if (profileId == null || activeProfileId == profileId) {
            activeProfileId = null
            qmpPort = null
        }
    }
}
