package com.virtual.devicelization.core.display

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Minimal RFB/VNC 3.x client for the loopback QEMU display.
 *
 * It intentionally negotiates only the uncompressed RAW encoding and 32-bit true colour. This
 * keeps the display bridge dependency-free and deterministic. It is not exposed to the network:
 * QEMU listens on 127.0.0.1 only.
 */
class VncClient(
    private val host: String = "127.0.0.1",
    private val port: Int = 5901,
    private val listener: Listener,
) {
    interface Listener {
        fun onFramebufferSize(width: Int, height: Int)
        fun onRawRectangle(x: Int, y: Int, width: Int, height: Int, argb: IntArray)
        fun onConnected(name: String) = Unit
        fun onDisconnected(message: String?) = Unit
    }

    private val running = AtomicBoolean(false)
    private var socket: Socket? = null
    private var output: DataOutputStream? = null
    @Volatile private var framebufferWidth = 0
    @Volatile private var framebufferHeight = 0

    fun runBlocking() {
        if (!running.compareAndSet(false, true)) return
        var error: String? = null
        try {
            val s = Socket()
            socket = s
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, port), 2500)
            s.soTimeout = 15_000
            val input = DataInputStream(BufferedInputStream(s.getInputStream(), 256 * 1024))
            val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 64 * 1024))
            output = out

            val serverVersion = readFixedString(input, 12)
            require(serverVersion.startsWith("RFB ")) { "Invalid RFB server greeting." }
            val negotiated = when {
                serverVersion.contains("003.008") -> "RFB 003.008\n"
                serverVersion.contains("003.007") -> "RFB 003.007\n"
                else -> "RFB 003.003\n"
            }
            out.write(negotiated.toByteArray(StandardCharsets.US_ASCII))
            out.flush()

            if (negotiated.contains("003.003")) {
                val security = input.readInt()
                require(security == 1) { "QEMU VNC requires unsupported security type $security." }
            } else {
                val count = input.readUnsignedByte()
                if (count == 0) {
                    val len = safeLength(input.readInt(), 1024 * 1024)
                    val reason = readFixedString(input, len)
                    error("VNC server rejected connection: $reason")
                }
                val types = IntArray(count) { input.readUnsignedByte() }
                require(types.contains(1)) { "QEMU VNC does not offer unauthenticated loopback security." }
                out.writeByte(1) // SecurityType None; loopback only.
                out.flush()
                val result = input.readInt()
                if (result != 0) error("VNC security negotiation failed ($result).")
            }

            out.writeByte(1) // ClientInit: shared.
            out.flush()

            framebufferWidth = input.readUnsignedShort()
            framebufferHeight = input.readUnsignedShort()
            require(framebufferWidth in 1..8192 && framebufferHeight in 1..8192) {
                "Invalid VNC framebuffer size ${framebufferWidth}x${framebufferHeight}."
            }
            // Server pixel format (16 bytes); Multi Device immediately requests its own format.
            skipFully(input, 16)
            val nameLength = safeLength(input.readInt(), 1024 * 1024)
            val desktopName = readFixedString(input, nameLength)

            sendPixelFormat(out)
            sendEncodings(out)
            listener.onFramebufferSize(framebufferWidth, framebufferHeight)
            listener.onConnected(desktopName)
            requestFramebuffer(out, incremental = false)

            while (running.get()) {
                when (val messageType = input.readUnsignedByte()) {
                    0 -> readFramebufferUpdate(input)
                    1 -> readColorMap(input)
                    2 -> Unit // Bell.
                    3 -> readServerCutText(input)
                    else -> error("Unsupported VNC server message type $messageType.")
                }
                if (running.get()) requestFramebuffer(out, incremental = true)
            }
        } catch (t: Throwable) {
            if (running.get()) error = t.message ?: t.javaClass.simpleName
        } finally {
            running.set(false)
            runCatching { socket?.close() }
            socket = null
            output = null
            listener.onDisconnected(error)
        }
    }

    fun stop() {
        running.set(false)
        runCatching { socket?.close() }
    }

    @Synchronized
    fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        val out = output ?: return
        if (!running.get() || framebufferWidth <= 0 || framebufferHeight <= 0) return
        runCatching {
            out.writeByte(5)
            out.writeByte(buttonMask and 0xFF)
            out.writeShort(x.coerceIn(0, framebufferWidth - 1))
            out.writeShort(y.coerceIn(0, framebufferHeight - 1))
            out.flush()
        }
    }

    @Synchronized
    fun sendKey(keySym: Int, down: Boolean) {
        val out = output ?: return
        if (!running.get()) return
        runCatching {
            out.writeByte(4)
            out.writeByte(if (down) 1 else 0)
            out.writeShort(0)
            out.writeInt(keySym)
            out.flush()
        }
    }

    private fun readFramebufferUpdate(input: DataInputStream) {
        input.readUnsignedByte() // padding
        val rectangles = input.readUnsignedShort()
        repeat(rectangles) {
            val x = input.readUnsignedShort()
            val y = input.readUnsignedShort()
            val width = input.readUnsignedShort()
            val height = input.readUnsignedShort()
            val encoding = input.readInt()
            require(width >= 0 && height >= 0 && width <= 8192 && height <= 8192) { "Unsafe VNC rectangle." }
            when (encoding) {
                0 -> readRawRectangle(input, x, y, width, height)
                else -> error("QEMU returned unsupported VNC encoding $encoding; RAW was requested.")
            }
        }
    }

    private fun readRawRectangle(input: DataInputStream, x: Int, y: Int, width: Int, height: Int) {
        val pixels = width.toLong() * height.toLong()
        require(pixels <= 67_108_864L) { "VNC rectangle is too large." }
        val bytes = ByteArray((pixels * 4L).toInt())
        input.readFully(bytes)
        val argb = IntArray(pixels.toInt())
        var p = 0
        var b = 0
        while (p < argb.size) {
            val blue = bytes[b].toInt() and 0xFF
            val green = bytes[b + 1].toInt() and 0xFF
            val red = bytes[b + 2].toInt() and 0xFF
            argb[p] = (0xFF shl 24) or (red shl 16) or (green shl 8) or blue
            p++
            b += 4
        }
        listener.onRawRectangle(x, y, width, height, argb)
    }

    private fun readColorMap(input: DataInputStream) {
        input.readUnsignedByte()
        input.readUnsignedShort() // first colour
        val count = input.readUnsignedShort()
        skipFully(input, count * 6)
    }

    private fun readServerCutText(input: DataInputStream) {
        skipFully(input, 3)
        val length = safeLength(input.readInt(), 8 * 1024 * 1024)
        skipFully(input, length)
    }

    private fun sendPixelFormat(out: DataOutputStream) {
        out.writeByte(0)
        out.write(byteArrayOf(0, 0, 0))
        out.writeByte(32) // bits-per-pixel
        out.writeByte(24) // depth
        out.writeByte(0)  // little endian
        out.writeByte(1)  // true colour
        out.writeShort(255)
        out.writeShort(255)
        out.writeShort(255)
        out.writeByte(16) // red shift
        out.writeByte(8)  // green shift
        out.writeByte(0)  // blue shift
        out.write(byteArrayOf(0, 0, 0))
        out.flush()
    }

    private fun sendEncodings(out: DataOutputStream) {
        out.writeByte(2)
        out.writeByte(0)
        out.writeShort(1)
        out.writeInt(0) // RAW
        out.flush()
    }

    private fun requestFramebuffer(out: DataOutputStream, incremental: Boolean) {
        out.writeByte(3)
        out.writeByte(if (incremental) 1 else 0)
        out.writeShort(0)
        out.writeShort(0)
        out.writeShort(framebufferWidth)
        out.writeShort(framebufferHeight)
        out.flush()
    }

    private fun readFixedString(input: DataInputStream, length: Int): String {
        val bytes = ByteArray(length)
        input.readFully(bytes)
        return String(bytes, StandardCharsets.UTF_8)
    }

    private fun safeLength(value: Int, max: Int): Int {
        require(value in 0..max) { "Unsafe RFB payload length $value." }
        return value
    }

    private fun skipFully(input: DataInputStream, length: Int) {
        var remaining = length
        while (remaining > 0) {
            val skipped = input.skipBytes(remaining)
            if (skipped <= 0) {
                input.readByte()
                remaining--
            } else remaining -= skipped
        }
    }
}
