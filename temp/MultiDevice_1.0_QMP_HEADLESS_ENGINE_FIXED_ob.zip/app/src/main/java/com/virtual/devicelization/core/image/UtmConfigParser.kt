package com.virtual.devicelization.core.image

/**
 * Minimal parser/resolver for the UTM plist shipped inside LineageOS vm-utm-zip artifacts.
 *
 * We deliberately do not assume that the first disk is literally named vda.qcow2. LineageOS'
 * UTM template makes that filename replaceable at build time, so the archive's config.plist is
 * the source of truth. The parser is intentionally narrow: it only reads the Drive array and
 * the fields Multi Device needs to attach disk images to QEMU.
 */
data class UtmDriveSpec(
    val identifier: String,
    val imageName: String,
    val imageType: String,
    val interfaceName: String,
    val readOnly: Boolean,
)

data class UtmArchiveEntry(
    val name: String,
    val size: Long = -1L,
)

data class UtmResolvedDrive(
    val spec: UtmDriveSpec,
    val archiveEntryName: String,
)

data class UtmArchiveLayout(
    val configEntryName: String,
    val firmwareVarsEntryName: String,
    val drives: List<UtmResolvedDrive>,
)

object UtmConfigParser {
    private val driveArrayRegex = Regex(
        """<key>\s*Drive\s*</key>\s*<array>(.*?)</array>""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
    )
    private val dictRegex = Regex(
        """<dict>(.*?)</dict>""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
    )


    /**
     * Resolve the layout documented by jqssun/android-lineage-qemu for UTM release archives.
     * Current official QEMU instructions attach Data/vda.qcow2, Data/vdb.qcow2 and Data/efi_vars.fd.
     * This fast path intentionally does not parse config.plist, so binary/newer plist encodings cannot
     * break installation of the standard published release bundle.
     */
    fun resolveDocumentedLineageLayout(entries: List<UtmArchiveEntry>): UtmArchiveLayout? {
        val normalized = entries
            .filter { it.name.isNotBlank() }
            .map { it.copy(name = normalize(it.name)) }

        val vdaCandidates = normalized.filter { basename(it.name).equals("vda.qcow2", ignoreCase = true) }
        for (vda in vdaCandidates) {
            val dataPrefix = vda.name.substringBeforeLast('/', missingDelimiterValue = "")
                .let { if (it.isBlank()) "" else "$it/" }
            val vdb = normalized.firstOrNull { it.name.equals("${dataPrefix}vdb.qcow2", ignoreCase = true) }
                ?: continue
            val vars = normalized.firstOrNull { it.name.equals("${dataPrefix}efi_vars.fd", ignoreCase = true) }
                ?: continue
            val bundlePrefix = dataPrefix.removeSuffix("Data/")
            val config = normalized.firstOrNull {
                it.name.equals("${bundlePrefix}config.plist", ignoreCase = true)
            }
            return UtmArchiveLayout(
                configEntryName = config?.name.orEmpty(),
                firmwareVarsEntryName = vars.name,
                drives = listOf(
                    UtmResolvedDrive(
                        UtmDriveSpec("vda", "vda.qcow2", "Disk", "VirtIO", false),
                        vda.name,
                    ),
                    UtmResolvedDrive(
                        UtmDriveSpec("vdb", "vdb.qcow2", "Disk", "VirtIO", false),
                        vdb.name,
                    ),
                ),
            )
        }
        return null
    }

    fun parseDriveSpecs(plist: String): List<UtmDriveSpec> {
        val driveBlock = driveArrayRegex.find(plist)?.groupValues?.get(1)
            ?: throw IllegalArgumentException("UTM config.plist does not contain a Drive array.")
        val result = dictRegex.findAll(driveBlock).mapNotNull { match ->
            val body = match.groupValues[1]
            val identifier = stringValue(body, "Identifier")?.trim().orEmpty()
            val imageName = stringValue(body, "ImageName")?.trim().orEmpty()
            val imageType = stringValue(body, "ImageType")?.trim().orEmpty()
            val interfaceName = stringValue(body, "Interface")?.trim().orEmpty()
            if (identifier.isBlank() || imageName.isBlank() || !imageType.equals("Disk", ignoreCase = true)) {
                null
            } else {
                UtmDriveSpec(
                    identifier = identifier,
                    imageName = imageName,
                    imageType = imageType,
                    interfaceName = interfaceName,
                    readOnly = boolValue(body, "ReadOnly") ?: false,
                )
            }
        }.toList()
        require(result.isNotEmpty()) { "UTM config.plist does not describe any disk drives." }
        require(result.map { it.identifier.lowercase() }.distinct().size == result.size) {
            "UTM config.plist contains duplicate drive identifiers."
        }
        return result
    }

    fun resolve(plist: String, entries: List<UtmArchiveEntry>): UtmArchiveLayout {
        require(entries.isNotEmpty()) { "Downloaded UTM archive is empty." }
        val normalizedEntries = entries
            .filter { it.name.isNotBlank() }
            .map { it.copy(name = normalize(it.name)) }

        val configName = findConfigEntryName(normalizedEntries)
        val config = normalizedEntries.first { it.name.equals(configName, ignoreCase = true) }

        val bundlePrefix = config.name.substringBeforeLast('/', missingDelimiterValue = "")
            .let { if (it.isBlank()) "" else "$it/" }
        val dataPrefix = "${bundlePrefix}Data/"

        val firmwareVars = normalizedEntries.firstOrNull {
            it.name.equals("${dataPrefix}efi_vars.fd", ignoreCase = true)
        } ?: normalizedEntries.firstOrNull {
            basename(it.name).equals("efi_vars.fd", ignoreCase = true) &&
                (bundlePrefix.isBlank() || it.name.startsWith(bundlePrefix, ignoreCase = true))
        } ?: throw IllegalArgumentException("Downloaded UTM image is missing efi_vars.fd.")

        val specs = parseDriveSpecs(plist)
        val diskEntries = normalizedEntries.filter {
            !it.name.endsWith('/') &&
                (bundlePrefix.isBlank() || it.name.startsWith(bundlePrefix, ignoreCase = true)) &&
                supportedDiskExtension(basename(it.name)) != null
        }
        require(diskEntries.isNotEmpty()) { "Downloaded UTM image does not contain a supported disk image." }

        val used = mutableSetOf<String>()
        val resolvedById = linkedMapOf<String, UtmResolvedDrive>()

        // Resolve explicit filenames first (for example vdb.qcow2). Placeholder/renamed drives are
        // handled afterwards so a heuristic can never steal a disk that config.plist named exactly.
        val orderedForResolution = specs.sortedBy { spec ->
            val name = spec.imageName.trim()
            if (name.startsWith('@') && name.endsWith('@')) 1 else 0
        }
        for (spec in orderedForResolution) {
            val entry = resolveDriveEntry(spec, dataPrefix, diskEntries, used)
                ?: throw IllegalArgumentException(
                    "Downloaded UTM image is missing the disk for '${spec.identifier}' " +
                        "(config.plist requested '${spec.imageName}')."
                )
            used += entry.name.lowercase()
            resolvedById[spec.identifier.lowercase()] = UtmResolvedDrive(spec, entry.name)
        }
        val resolved = specs.map { resolvedById.getValue(it.identifier.lowercase()) }

        return UtmArchiveLayout(
            configEntryName = config.name,
            firmwareVarsEntryName = firmwareVars.name,
            drives = resolved,
        )
    }


    fun findConfigEntryName(entries: List<UtmArchiveEntry>): String {
        return entries
            .map { it.copy(name = normalize(it.name)) }
            .filter { basename(it.name).equals("config.plist", ignoreCase = true) }
            .sortedWith(
                compareByDescending<UtmArchiveEntry> { it.name.contains(".utm/", ignoreCase = true) }
                    .thenBy { it.name.length }
            )
            .firstOrNull()?.name
            ?: throw IllegalArgumentException("Downloaded UTM image is missing config.plist.")
    }

    fun supportedDiskExtension(fileName: String): String? = when (fileName.substringAfterLast('.', "").lowercase()) {
        "qcow2" -> "qcow2"
        "img" -> "img"
        "raw" -> "raw"
        else -> null
    }

    fun qemuFormat(fileName: String): String = when (supportedDiskExtension(fileName)) {
        "qcow2" -> "qcow2"
        "img", "raw" -> "raw"
        else -> throw IllegalArgumentException("Unsupported UTM disk format: ${basename(fileName)}")
    }

    private fun resolveDriveEntry(
        spec: UtmDriveSpec,
        dataPrefix: String,
        candidates: List<UtmArchiveEntry>,
        used: Set<String>,
    ): UtmArchiveEntry? {
        val available = candidates.filter { it.name.lowercase() !in used }
        val configuredName = decodeXml(spec.imageName).trim()
        val configuredIsPlaceholder = configuredName.startsWith('@') && configuredName.endsWith('@')

        if (!configuredIsPlaceholder) {
            available.firstOrNull {
                it.name.equals("$dataPrefix$configuredName", ignoreCase = true)
            }?.let { return it }
            available.firstOrNull {
                basename(it.name).equals(basename(configuredName), ignoreCase = true)
            }?.let { return it }
        }

        // Historical/current Lineage builds can substitute a different vda filename. Prefer a file
        // whose basename still identifies the configured drive, then fall back to the only/largest
        // remaining disk inside the UTM bundle. vdb is resolved explicitly before this fallback in
        // normal packages because its config name is stable.
        val id = spec.identifier.lowercase()
        val idMatches = available.filter { entry ->
            val base = basename(entry.name).lowercase()
            base == id || base.startsWith("$id.") || base.startsWith("$id-") || base.startsWith("${id}_")
        }
        if (idMatches.size == 1) return idMatches.first()
        if (idMatches.isNotEmpty()) return idMatches.maxByOrNull { it.size }

        if (available.size == 1) return available.first()
        return available.maxByOrNull { it.size }
    }

    private fun stringValue(dictBody: String, key: String): String? {
        val regex = Regex(
            """<key>\s*${Regex.escape(key)}\s*</key>\s*<string>(.*?)</string>""",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
        )
        return regex.find(dictBody)?.groupValues?.get(1)?.let(::decodeXml)
    }

    private fun boolValue(dictBody: String, key: String): Boolean? {
        val regex = Regex(
            """<key>\s*${Regex.escape(key)}\s*</key>\s*<(true|false)\s*/>""",
            RegexOption.IGNORE_CASE,
        )
        return regex.find(dictBody)?.groupValues?.get(1)?.equals("true", ignoreCase = true)
    }

    private fun normalize(name: String): String = name.replace('\\', '/').trimStart('/')
    private fun basename(name: String): String = normalize(name).substringAfterLast('/')

    private fun decodeXml(value: String): String = value
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&amp;", "&")
}
