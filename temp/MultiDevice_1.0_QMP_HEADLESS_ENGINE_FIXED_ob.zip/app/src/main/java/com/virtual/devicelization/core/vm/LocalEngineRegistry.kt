package com.virtual.devicelization.core.vm

import android.content.Context
import com.virtual.devicelization.core.image.GuestImageStore

/** Process-wide owner so Activity/ViewModel recreation never creates a second QEMU controller. */
object LocalEngineRegistry {
    @Volatile private var imageStoreInstance: GuestImageStore? = null
    @Volatile private var backendInstance: LocalQemuVmBackend? = null

    fun imageStore(context: Context): GuestImageStore {
        return imageStoreInstance ?: synchronized(this) {
            imageStoreInstance ?: GuestImageStore(context.applicationContext).also { imageStoreInstance = it }
        }
    }

    fun backend(context: Context): LocalQemuVmBackend {
        return backendInstance ?: synchronized(this) {
            backendInstance ?: LocalQemuVmBackend(
                context.applicationContext,
                imageStore(context),
            ).also { backendInstance = it }
        }
    }
}
