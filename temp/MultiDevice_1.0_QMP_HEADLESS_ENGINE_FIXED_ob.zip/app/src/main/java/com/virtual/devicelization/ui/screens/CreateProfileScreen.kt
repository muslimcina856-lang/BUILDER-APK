package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.ui.components.*
import com.virtual.devicelization.ui.theme.*

private data class DevicePreset(val name: String, val config: DeviceConfig)

private val devicePresets = listOf(
    DevicePreset("Compact Phone", DeviceConfig("Compact Phone", 2, 3072, 32, 1080, 2340, 420, 60)),
    DevicePreset("Standard Phone", DeviceConfig("Standard Phone", 4, 4096, 32, 1080, 2400, 420, 60)),
    DevicePreset("Large Phone", DeviceConfig("Large Phone", 4, 6144, 64, 1440, 3200, 560, 60)),
    DevicePreset("Performance Phone", DeviceConfig("Performance Phone", 8, 8192, 128, 1440, 3120, 560, 120)),
    DevicePreset("Small Tablet", DeviceConfig("Small Tablet", 4, 4096, 64, 1600, 2560, 320, 60)),
    DevicePreset("Large Tablet", DeviceConfig("Large Tablet", 8, 8192, 128, 2560, 1600, 320, 90)),
    DevicePreset("Foldable", DeviceConfig("Foldable", 8, 8192, 128, 2208, 1840, 420, 120)),
)

@Composable
fun CreateProfileScreen(
    onCancel: () -> Unit,
    onOpenLibrary: () -> Unit,
    availableImages: List<GuestImageManifest>,
    initialProfile: Profile? = null,
    onCreate: (String, String, DeviceConfig, NetworkConfig) -> Unit,
) {
    var step by remember(initialProfile?.id) { mutableIntStateOf(1) }
    var name by remember(initialProfile?.id) { mutableStateOf(initialProfile?.name.orEmpty()) }
    var selectedImageId by remember(initialProfile?.id, availableImages.size) {
        mutableStateOf(
            initialProfile?.imageId?.takeIf { id -> availableImages.any { it.id == id } }
                ?: availableImages.firstOrNull()?.id
        )
    }
    var device by remember(initialProfile?.id) { mutableStateOf(initialProfile?.device ?: DeviceConfig()) }
    var network by remember(initialProfile?.id) {
        mutableStateOf(initialProfile?.network ?: NetworkConfig(MacAddressGenerator.generate()))
    }

    val selectedImage = availableImages.firstOrNull { it.id == selectedImageId }
    val canContinue = when (step) {
        1 -> name.trim().isNotEmpty()
        2 -> selectedImage != null
        else -> true
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onCancel) { Icon(Icons.Outlined.ArrowBack, "Back") }
            Text(
                if (initialProfile == null) "Create Profile" else "Edit Profile",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
            )
        }
        Stepper(step)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (step) {
                1 -> BasicStep(name) { name = it }
                2 -> AndroidImageStep(
                    images = availableImages,
                    selectedId = selectedImageId,
                    onSelect = { selectedImageId = it },
                    onOpenLibrary = onOpenLibrary,
                )
                3 -> DeviceStep(device) { device = it }
                4 -> NetworkStep(network) { network = it }
                else -> ReviewStep(name, selectedImage, device, network)
            }
        }

        Row(
            Modifier.padding(18.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedButton(
                onClick = { if (step > 1) step-- else onCancel() },
                modifier = Modifier.weight(1f).heightIn(min = 54.dp),
            ) { Text("Back", color = TextPrimary) }
            GradientButton(
                text = if (step < 5) "Continue ›" else if (initialProfile == null) "Create Profile" else "Save Changes",
                enabled = canContinue && (step < 5 || selectedImage != null),
                onClick = {
                    if (!canContinue) return@GradientButton
                    if (step < 5) step++
                    else selectedImage?.let { onCreate(name.trim(), it.id, device, network) }
                },
                modifier = Modifier.weight(1.25f),
            )
        }
    }
}

@Composable
private fun Stepper(step: Int) {
    val labels = listOf("Basic", "Android", "Device", "Network", "Review")
    Row(
        Modifier.padding(horizontal = 18.dp, vertical = 4.dp).fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        labels.forEachIndexed { i, label ->
            val complete = i + 1 < step
            val current = i + 1 == step
            val color = if (complete || current) Cyan else TextSubtle
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = MaterialTheme.shapes.extraLarge,
                    color = if (current) Cyan.copy(alpha = .16f) else Surface2,
                    border = BorderStroke(1.dp, if (complete || current) Cyan else Outline),
                ) {
                    Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        if (complete) Icon(Icons.Outlined.Check, null, tint = Green, modifier = Modifier.size(18.dp))
                        else Text("${i + 1}", color = color, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = color, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun BasicStep(name: String, onName: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Basic Profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text("Name the virtual device. Nothing is created until you finish the wizard.", color = TextMuted)
        }
        item {
            OutlinedTextField(
                value = name,
                onValueChange = { onName(it.take(60)) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Profile name") },
                placeholder = { Text("Example: Work Device", color = TextSubtle) },
                leadingIcon = { Icon(Icons.Outlined.Badge, null) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedBorderColor = Outline,
                    unfocusedLabelColor = TextMuted,
                ),
            )
        }
        item {
            NeonCard(Modifier.fillMaxWidth(), borderColor = Cyan) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Outlined.Security, null, tint = Green)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Isolated profile", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            "Apps, data, storage, virtual MAC and network configuration stay separate from every other profile.",
                            color = TextMuted,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AndroidImageStep(
    images: List<GuestImageManifest>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    onOpenLibrary: () -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Android Image", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text(
                "Choose an installed bootable image. Multi Device downloads Android images separately so the APK does not become several gigabytes.",
                color = TextMuted,
            )
        }
        if (images.isEmpty()) {
            item {
                NeonCard(Modifier.fillMaxWidth(), borderColor = Purple) {
                    Icon(Icons.Outlined.CloudDownload, null, tint = Purple, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No Android image installed", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Open Image Library, download the recommended ARM64 QEMU image or import a compatible .mdvm / UTM ZIP, then return here.",
                        color = TextMuted,
                    )
                    Spacer(Modifier.height(14.dp))
                    GradientButton("Open Image Library", onOpenLibrary, Modifier.fillMaxWidth())
                }
            }
        } else {
            items(images, key = { it.id }) { image ->
                InstalledImageChoice(image, selected = image.id == selectedId) { onSelect(image.id) }
            }
            item {
                OutlinedButton(onClick = onOpenLibrary, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Get another Android image")
                }
            }
        }
        item {
            NeonCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Memory, null, tint = Cyan)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("ARM64 guest architecture", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("The local QEMU engine currently targets ARM64 Android guests.", color = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun InstalledImageChoice(image: GuestImageManifest, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        color = if (selected) Cyan.copy(alpha = .10f) else Surface,
        border = BorderStroke(1.dp, if (selected) Cyan else Outline),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Outlined.Android,
                null,
                tint = if (selected) Green else Cyan,
                modifier = Modifier.size(42.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(image.name, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Android ${image.androidVersion} • API ${image.apiLevel} • ${image.architecture}", color = TextMuted)
                Text(image.id, color = TextSubtle, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}

@Composable
private fun DeviceStep(value: DeviceConfig, onChange: (DeviceConfig) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Device Configuration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("Choose a preset or tune virtual resources manually.", color = TextMuted)
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                devicePresets.forEach { preset ->
                    DeviceFilterChip(value.preset == preset.name, preset.name) { onChange(preset.config) }
                }
                DeviceFilterChip(value.preset == "Custom", "Custom") { onChange(value.copy(preset = "Custom")) }
            }
        }
        item { ConfigSlider("CPU Cores", value.cpuCores, 1, 8) { onChange(value.copy(preset = "Custom", cpuCores = it)) } }
        item { ConfigSlider("RAM (GB)", value.ramMb / 1024, 2, 12) { onChange(value.copy(preset = "Custom", ramMb = it * 1024)) } }
        item { ConfigSlider("Storage (GB)", value.storageGb, 16, 256) { onChange(value.copy(preset = "Custom", storageGb = it)) } }
        item {
            NeonCard(Modifier.fillMaxWidth()) {
                Text("Resolution", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ConfigNumberField("Width", value.width, Modifier.weight(1f)) {
                        onChange(value.copy(preset = "Custom", width = it.coerceIn(480, 4096)))
                    }
                    ConfigNumberField("Height", value.height, Modifier.weight(1f)) {
                        onChange(value.copy(preset = "Custom", height = it.coerceIn(480, 4096)))
                    }
                }
            }
        }
        item { ConfigSlider("DPI", value.dpi, 240, 640) { onChange(value.copy(preset = "Custom", dpi = it)) } }
        item { ConfigSlider("Refresh Rate", value.refreshRate, 60, 144) { onChange(value.copy(preset = "Custom", refreshRate = it)) } }
    }
}

@Composable
private fun DeviceFilterChip(selected: Boolean, label: String, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, maxLines = 1) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Surface,
            labelColor = TextMuted,
            selectedContainerColor = Cyan.copy(alpha = .16f),
            selectedLabelColor = TextPrimary,
        ),
        border = BorderStroke(1.dp, if (selected) Cyan else Outline),
    )
}

@Composable
private fun ConfigNumberField(label: String, value: Int, modifier: Modifier = Modifier, onValue: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { raw -> raw.filter(Char::isDigit).toIntOrNull()?.let(onValue) },
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Outline),
    )
}

@Composable
private fun ConfigSlider(label: String, value: Int, min: Int, max: Int, onValue: (Int) -> Unit) {
    NeonCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(value.toString(), color = Cyan, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.toFloat(), onValueChange = { onValue(it.toInt()) }, valueRange = min.toFloat()..max.toFloat())
    }
}

@Composable
private fun NetworkStep(value: NetworkConfig, onChange: (NetworkConfig) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Network & Privacy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("These settings belong only to this profile.", color = TextMuted)
        }
        item {
            NeonCard(Modifier.fillMaxWidth(), Cyan) {
                Text("Virtual MAC Address", color = Cyan)
                Text(value.virtualMac, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { onChange(value.copy(virtualMac = MacAddressGenerator.generate())) }) {
                    Icon(Icons.Outlined.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Generate new MAC")
                }
            }
        }
        item { SectionLabel("MAC Mode") }
        items(MacMode.entries.size) { i ->
            val mode = MacMode.entries[i]
            RadioLine(modeLabel(mode), value.macMode == mode) { onChange(value.copy(macMode = mode)) }
        }
        item { SectionLabel("Connection Mode") }
        items(NetworkMode.entries.size) { i ->
            val mode = NetworkMode.entries[i]
            RadioLine(networkLabel(mode), value.mode == mode) { onChange(value.copy(mode = mode)) }
        }
        if (value.mode == NetworkMode.ENCRYPTED_TUNNEL) {
            item {
                NeonCard(Modifier.fillMaxWidth(), Purple) {
                    Text("Encrypted Tunnel", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = value.exitRegion,
                        onValueChange = { onChange(value.copy(exitRegion = it.take(64))) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("VPN profile / region note") },
                        supportingText = { Text("The actual exit location is controlled by your VPN app.", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Outline),
                    )
                    ToggleLine("Require VPN DNS", value.dnsProtection) { onChange(value.copy(dnsProtection = it)) }
                    ToggleLine("Kill Switch", value.killSwitch) { onChange(value.copy(killSwitch = it)) }
                    Text(
                        "With Kill Switch enabled, the VM is stopped if the required Android VPN path disappears rather than silently falling back to the direct connection.",
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = TextPrimary)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun RadioLine(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        color = if (selected) Cyan.copy(alpha = .09f) else Surface,
        border = BorderStroke(1.dp, if (selected) Cyan else Outline.copy(alpha = .8f)),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Text(text, color = TextPrimary)
        }
    }
}

private fun modeLabel(mode: MacMode) = when (mode) {
    MacMode.KEEP_CURRENT -> "Keep Current"
    MacMode.RANDOM_EVERY_BOOT -> "Random Every Boot"
    MacMode.MANUAL_RESET_ONLY -> "Manual Reset Only"
}

private fun networkLabel(mode: NetworkMode) = when (mode) {
    NetworkMode.DIRECT_NAT -> "Direct / NAT"
    NetworkMode.ENCRYPTED_TUNNEL -> "Encrypted Tunnel"
    NetworkMode.OFFLINE -> "Offline"
}

@Composable
private fun ReviewStep(name: String, image: GuestImageManifest?, device: DeviceConfig, network: NetworkConfig) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Review", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary) }
        item {
            NeonCard(Modifier.fillMaxWidth()) {
                Text(name.ifBlank { "New Profile" }, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                if (image != null) {
                    Text(image.name, color = Cyan, fontWeight = FontWeight.Medium)
                    Text("Android ${image.androidVersion} • API ${image.apiLevel} • ${image.architecture}", color = TextMuted)
                } else {
                    Text("No Android image selected", color = Danger)
                }
                Spacer(Modifier.height(8.dp))
                Text(device.preset, color = TextPrimary, fontWeight = FontWeight.Medium)
                Text("${device.cpuCores} cores • ${device.ramMb / 1024} GB RAM • ${device.storageGb} GB storage", color = TextMuted)
                Text("${device.width} × ${device.height} • ${device.dpi} DPI • ${device.refreshRate} Hz", color = TextMuted)
                Spacer(Modifier.height(10.dp))
                Text(network.virtualMac, color = Cyan, fontWeight = FontWeight.Medium)
                Text("${networkLabel(network.mode)} • ${modeLabel(network.macMode)}", color = TextMuted)
            }
        }
    }
}
