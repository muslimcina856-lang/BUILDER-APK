package com.virtual.devicelization.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.vm.VmBackendStatus
import com.virtual.devicelization.ui.components.NeonCard
import com.virtual.devicelization.ui.theme.*

@Composable
fun SettingsScreen(backend: VmBackendStatus) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Header("Settings", "Runtime, compatibility and app information") }

        item {
            NeonCard(
                modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                borderColor = Cyan.copy(alpha = .65f),
            ) {
                SectionTitle(Icons.Outlined.Security, "App Identity")
                Spacer(Modifier.height(10.dp))
                KeyValue("Package", "com.virtual.devicelization", monospace = true)
                KeyValue("Version code", "1")
                KeyValue("Version name", "1.0")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Version values stay unchanged in project updates. Change them yourself only when you want to publish a new release.",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        item {
            NeonCard(
                modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                borderColor = if (backend.fullAndroidGuestSupported) Green else Purple,
            ) {
                SectionTitle(Icons.Outlined.Memory, "Local VM Engine")
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (backend.fullAndroidGuestSupported) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline,
                        contentDescription = null,
                        tint = if (backend.fullAndroidGuestSupported) Green else Danger,
                        modifier = Modifier.size(24.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (backend.fullAndroidGuestSupported) "Runtime ready" else "Runtime not available",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            if (backend.fullAndroidGuestSupported) "QEMU ARM64 can start local guest profiles." else "This build does not contain a usable local QEMU ARM64 runtime.",
                            color = TextMuted,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                KeyValue("Android host", "${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
                KeyValue("Primary ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown", monospace = true)
                KeyValue("ARM64 host", yesNo(backend.arm64))
                KeyValue("AVF feature", yesNo(backend.avfFeaturePresent))
                KeyValue("AVF Java API", yesNo(backend.avfJavaApiPresent))
                KeyValue("VM permission", yesNo(backend.manageVmPermissionGranted))
                Spacer(Modifier.height(10.dp))
                Surface(
                    color = Surface3,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        backend.message,
                        modifier = Modifier.padding(12.dp),
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        item {
            NeonCard(
                modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                borderColor = Blue.copy(alpha = .55f),
            ) {
                Text("Storage model", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Android guest images are installed separately from the APK. Profiles keep their own writable data while compatible base images can be reused.",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(9.dp))
        Text(title, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun KeyValue(key: String, value: String, monospace: Boolean = false) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(key, color = TextSubtle, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(2.dp))
        Text(
            value,
            color = TextPrimary,
            fontWeight = FontWeight.Medium,
            fontFamily = if (monospace) FontFamily.Monospace else FontFamily.Default,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private fun yesNo(value: Boolean) = if (value) "Yes" else "No"
