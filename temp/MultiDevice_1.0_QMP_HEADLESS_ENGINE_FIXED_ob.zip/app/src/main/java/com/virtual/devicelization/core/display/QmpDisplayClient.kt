package com.virtual.devicelization.core.display

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.virtual.devicelization.core.vm.QmpClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Headless QEMU display/input bridge.
 *
 * QEMU does not need a VNC/SDL/GTK backend. Frames are captured from its primary graphical console
 * with QMP screendump, while pointer/keyboard events are injected with QMP input commands.
 */
class QmpDisplayClient(
    private val qmp: QmpClient,
    private val frameDirectory: File,
) {
    @Volatile private var pngSupported = true

    init {
        frameDirectory.mkdirs()
    }

    suspend fun captureFrame(): Result<Bitmap> {
        if (pngSupported) {
            val png = File(frameDirectory, "guest-frame.png")
            runCatching { png.delete() }
            val result = qmp.execute(
                "screendump",
                JSONObject()
                    .put("filename", png.absolutePath)
                    .put("format", "png"),
            )
            if (result.isSuccess && png.isFile && png.length() > 0L) {
                val bitmap = BitmapFactory.decodeFile(png.absolutePath)
                if (bitmap != null) return Result.success(bitmap)
            }
            // Older QEMU builds support screendump but not the optional format argument.
            pngSupported = false
        }

        val ppm = File(frameDirectory, "guest-frame.ppm")
        runCatching { ppm.delete() }
        val result = qmp.execute(
            "screendump",
            JSONObject().put("filename", ppm.absolutePath),
        )
        if (result.isFailure) return Result.failure(result.exceptionOrNull() ?: IllegalStateException("QMP screendump failed"))
        return runCatching { decodePpm(ppm) }
    }

    suspend fun sendPointer(x: Int, y: Int, buttonDown: Boolean? = null): Result<Unit> {
        val nx = x.coerceIn(0, ABS_MAX)
        val ny = y.coerceIn(0, ABS_MAX)
        val events = JSONArray()
            .put(absEvent("x", nx))
            .put(absEvent("y", ny))
        if (buttonDown != null) {
            events.put(
                JSONObject()
                    .put("type", "btn")
                    .put("data", JSONObject().put("down", buttonDown).put("button", "left")),
            )
        }
        return qmp.execute("input-send-event", JSONObject().put("events", events)).map { Unit }
    }

    suspend fun sendQCodes(keys: List<String>): Result<Unit> {
        if (keys.isEmpty()) return Result.success(Unit)
        val values = JSONArray()
        keys.distinct().forEach { code ->
            values.put(JSONObject().put("type", "qcode").put("data", code))
        }
        return qmp.execute(
            "send-key",
            JSONObject().put("keys", values).put("hold-time", 45),
        ).map { Unit }
    }

    private fun absEvent(axis: String, value: Int): JSONObject = JSONObject()
        .put("type", "abs")
        .put("data", JSONObject().put("axis", axis).put("value", value))

    private fun decodePpm(file: File): Bitmap {
        val bytes = file.readBytes()
        var cursor = 0

        fun skipHeaderSpaceAndComments() {
            while (cursor < bytes.size) {
                val b = bytes[cursor].toInt() and 0xff
                if (b == '#'.code) {
                    while (cursor < bytes.size && bytes[cursor].toInt() != '\n'.code) cursor++
                } else if (b == ' '.code || b == '\t'.code || b == '\r'.code || b == '\n'.code) {
                    cursor++
                } else {
                    break
                }
            }
        }

        fun token(): String {
            skipHeaderSpaceAndComments()
            val start = cursor
            while (cursor < bytes.size) {
                val b = bytes[cursor].toInt() and 0xff
                if (b == '#'.code || b == ' '.code || b == '\t'.code || b == '\r'.code || b == '\n'.code) break
                cursor++
            }
            check(cursor > start) { "Invalid PPM header" }
            return bytes.copyOfRange(start, cursor).toString(Charsets.US_ASCII)
        }

        check(token() == "P6") { "Unsupported QMP screendump format" }
        val width = token().toInt()
        val height = token().toInt()
        val max = token().toInt()
        check(width in 1..8192 && height in 1..8192) { "Invalid guest framebuffer ${width}x$height" }
        check(width.toLong() * height.toLong() <= 33_554_432L) { "Guest framebuffer is too large" }
        check(max == 255) { "Unsupported PPM channel depth: $max" }

        check(cursor < bytes.size) { "PPM raster is missing" }
        if (bytes[cursor].toInt() == '\r'.code && cursor + 1 < bytes.size && bytes[cursor + 1].toInt() == '\n'.code) {
            cursor += 2
        } else {
            val separator = bytes[cursor].toInt() and 0xff
            check(separator == ' '.code || separator == '\t'.code || separator == '\r'.code || separator == '\n'.code) {
                "Invalid PPM raster separator"
            }
            cursor++
        }

        val pixels = width.toLong() * height.toLong()
        val expected = pixels * 3L
        check(expected <= Int.MAX_VALUE && bytes.size.toLong() - cursor >= expected) { "Incomplete PPM raster" }
        val argb = IntArray(pixels.toInt())
        var src = cursor
        for (i in argb.indices) {
            val r = bytes[src++].toInt() and 0xff
            val g = bytes[src++].toInt() and 0xff
            val b = bytes[src++].toInt() and 0xff
            argb[i] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
        }
        return Bitmap.createBitmap(argb, width, height, Bitmap.Config.ARGB_8888)
    }

    companion object {
        const val ABS_MAX = 0x7fff
    }
}
