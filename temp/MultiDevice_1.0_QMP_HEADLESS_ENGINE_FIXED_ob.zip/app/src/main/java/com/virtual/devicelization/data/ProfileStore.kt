package com.virtual.devicelization.data

import android.content.Context
import com.virtual.devicelization.core.model.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent profile store.
 *
 * Important product rule: a fresh installation starts EMPTY. Multi Device never creates demo
 * profiles on the user's behalf. Profiles only exist after the user explicitly creates/imports one.
 */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("multi_device_profiles", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val raw = prefs.getString(KEY_PROFILES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val loaded = buildList {
                for (i in 0 until arr.length()) add(fromJson(arr.getJSONObject(i)))
            }

            // One-time development migration: early preview builds auto-created exactly these five
            // demo profiles. Remove only that exact legacy seed set so upgrading a tester build
            // behaves like a clean first launch without touching genuine user-created profiles.
            if (!prefs.getBoolean(KEY_LEGACY_SEEDS_REMOVED, false) && isLegacySeedSet(loaded)) {
                prefs.edit()
                    .remove(KEY_PROFILES)
                    .putBoolean(KEY_LEGACY_SEEDS_REMOVED, true)
                    .apply()
                emptyList()
            } else {
                loaded
            }
        }.getOrElse { emptyList() }
    }

    fun save(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_PROFILES).apply()
    }

    private fun toJson(p: Profile) = JSONObject().apply {
        put("id", p.id); put("name", p.name); put("androidVersion", p.androidVersion)
        put("apiLevel", p.apiLevel); put("architecture", p.architecture)
        put("imageId", p.imageId ?: JSONObject.NULL); put("modelLabel", p.modelLabel)
        put("status", p.status.name); put("createdAt", p.createdAtEpochMs)
        put("device", JSONObject().apply {
            put("preset", p.device.preset); put("cpu", p.device.cpuCores); put("ram", p.device.ramMb)
            put("storage", p.device.storageGb); put("width", p.device.width); put("height", p.device.height)
            put("dpi", p.device.dpi); put("refresh", p.device.refreshRate)
        })
        put("network", JSONObject().apply {
            put("mac", p.network.virtualMac); put("macMode", p.network.macMode.name)
            put("mode", p.network.mode.name); put("region", p.network.exitRegion)
            put("dns", p.network.dnsProtection); put("kill", p.network.killSwitch)
        })
    }

    private fun fromJson(o: JSONObject): Profile {
        val d = o.getJSONObject("device")
        val n = o.getJSONObject("network")
        return Profile(
            id = o.getString("id"), name = o.getString("name"),
            androidVersion = o.getInt("androidVersion"), apiLevel = o.getInt("apiLevel"),
            architecture = o.optString("architecture", "ARM64"),
            imageId = if (o.isNull("imageId")) null else o.optString("imageId", null),
            modelLabel = o.optString("modelLabel", "Standard Phone"),
            device = DeviceConfig(
                preset = d.getString("preset"), cpuCores = d.getInt("cpu"), ramMb = d.getInt("ram"),
                storageGb = d.getInt("storage"), width = d.getInt("width"), height = d.getInt("height"),
                dpi = d.getInt("dpi"), refreshRate = d.getInt("refresh")
            ),
            network = NetworkConfig(
                virtualMac = n.getString("mac"), macMode = MacMode.valueOf(n.getString("macMode")),
                mode = NetworkMode.valueOf(n.getString("mode")), exitRegion = n.getString("region"),
                dnsProtection = n.getBoolean("dns"), killSwitch = n.getBoolean("kill")
            ),
            status = VmStatus.valueOf(o.getString("status")),
            createdAtEpochMs = o.optLong("createdAt", System.currentTimeMillis())
        )
    }

    private fun isLegacySeedSet(profiles: List<Profile>): Boolean {
        if (profiles.size != LEGACY_SEED_NAMES.size) return false
        return profiles.map { it.name }.toSet() == LEGACY_SEED_NAMES
    }

    private companion object {
        const val KEY_PROFILES = "profiles"
        const val KEY_LEGACY_SEEDS_REMOVED = "legacy_seed_profiles_removed_v1"
        val LEGACY_SEED_NAMES = setOf(
            "Personal Test",
            "Work Environment",
            "Gaming Sandbox",
            "Banking Test",
            "Tablet Lab",
        )
    }
}
