package com.virtual.devicelization.core.vm

import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VmStatus

/**
 * Product invariant: one native VM process maximum.
 *
 * SUSPENDED is intentionally active here because the current local backend implements suspend as a
 * QMP pause; RAM/device state still lives in the one QEMU process until it is resumed or stopped.
 */
object SingleVmPolicy {
    private val activeStates = setOf(
        VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
        VmStatus.RESUMING, VmStatus.STOPPING
    )

    fun activeProfile(profiles: List<Profile>): Profile? =
        profiles.firstOrNull { it.status in activeStates }

    fun canStart(profiles: List<Profile>, targetId: String): Boolean =
        profiles.none { it.id != targetId && it.status in activeStates }

    fun assertInvariant(profiles: List<Profile>) {
        check(profiles.count { it.status in activeStates } <= 1) {
            "Multi Device invariant violated: more than one active VM"
        }
    }
}
