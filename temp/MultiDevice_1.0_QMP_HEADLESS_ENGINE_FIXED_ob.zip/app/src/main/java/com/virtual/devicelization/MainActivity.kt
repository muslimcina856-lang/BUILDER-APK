package com.virtual.devicelization

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.virtual.devicelization.ui.MultiDeviceApp
import com.virtual.devicelization.ui.theme.MultiDeviceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent { MultiDeviceTheme { MultiDeviceApp() } }
    }
}
