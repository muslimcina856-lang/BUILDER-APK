package com.virtual.devicelization.core.image

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Download catalog for bootable Android guest images.
 *
 * Guest archives are intentionally kept outside the APK. Completed downloads live in filesDir,
 * not cacheDir, so Android cache cleanup cannot silently force a multi-gigabyte re-download after
 * an install/import error. A .part file is kept for interrupted downloads and resumed with HTTP
 * Range when the upstream server supports it.
 */
data class RemoteGuestImage(
    val id: String,
    val name: String,
    val androidVersion: Int,
    val apiLevel: Int,
    val architecture: String,
    val source: String,
    val releaseTag: String,
    val downloadUrl: String,
    val sizeBytes: Long,
    val format: String,
    val sha256: String? = null,
)

data class ImageDownloadProgress(
    val imageId: String,
    val bytesDownloaded: Long,
    val totalBytes: Long,
) {
    val fraction: Float
        get() = if (totalBytes > 0L) {
            (bytesDownloaded.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
        } else 0f
}

class RemoteImageCatalog(private val context: Context) {
    private val downloadDir = File(context.filesDir, "guest_downloads").apply { mkdirs() }

    suspend fun fetch(): Result<List<RemoteGuestImage>> = withContext(Dispatchers.IO) {
        runCatching { fetchLineageQemuCatalog() }
    }

    /** Returns the already-completed archive without touching the network. */
    suspend fun downloadedFile(image: RemoteGuestImage): File? = withContext(Dispatchers.IO) {
        val target = targetFile(image)
        migrateLegacyCacheIfPresent(image, target)
        if (completedDownloadIsValid(target, image)) target else null
    }

    suspend fun isDownloaded(image: RemoteGuestImage): Boolean = downloadedFile(image) != null

    suspend fun discardDownload(image: RemoteGuestImage) = withContext(Dispatchers.IO) {
        targetFile(image).delete()
        partialFile(image).delete()
        metadataFile(image).delete()
    }

    suspend fun download(
        image: RemoteGuestImage,
        onProgress: (ImageDownloadProgress) -> Unit,
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(
                image.downloadUrl.startsWith("https://github.com/") ||
                    image.downloadUrl.startsWith("https://objects.githubusercontent.com/")
            ) { "Untrusted image download host." }

            val target = targetFile(image)
            migrateLegacyCacheIfPresent(image, target)
            if (completedDownloadIsValid(target, image)) {
                val size = target.length()
                onProgress(ImageDownloadProgress(image.id, size, image.sizeBytes.takeIf { it > 0L } ?: size))
                return@runCatching target
            }

            // An invalid final archive is never treated as reusable, but a partial file can resume.
            if (target.exists()) {
                target.delete()
                metadataFile(image).delete()
            }

            val part = partialFile(image)
            if (image.sizeBytes > 0L && part.length() > image.sizeBytes) part.delete()
            var existing = part.takeIf { it.isFile }?.length() ?: 0L

            var connection = open(image.downloadUrl)
            configureConnection(connection, existing.takeIf { it > 0L })
            connection.connect()

            // A completed .part can happen if the process died after the final byte but before rename.
            if (connection.responseCode == 416 && image.sizeBytes > 0L && existing == image.sizeBytes) {
                connection.disconnect()
                commitPartial(part, target)
                verifyCompletedDownload(target, image)
                writeVerifiedMetadata(target, image)
                return@runCatching target
            }

            var append = existing > 0L && connection.responseCode == HttpURLConnection.HTTP_PARTIAL
            if (connection.responseCode !in 200..299) {
                val code = connection.responseCode
                connection.disconnect()
                error("Image download failed: HTTP $code")
            }

            // Some CDNs ignore Range and reply 200. In that case restart locally, not recursively.
            if (existing > 0L && !append) {
                existing = 0L
                part.delete()
                append = false
            }

            val responseLength = connection.contentLengthLong.takeIf { it > 0L } ?: 0L
            val total = when {
                image.sizeBytes > 0L -> image.sizeBytes
                append && responseLength > 0L -> existing + responseLength
                responseLength > 0L -> responseLength
                else -> 0L
            }
            var downloaded = existing
            onProgress(ImageDownloadProgress(image.id, downloaded, total))

            try {
                connection.inputStream.buffered(1024 * 1024).use { input ->
                    FileOutputStream(part, append).buffered(1024 * 1024).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            onProgress(ImageDownloadProgress(image.id, downloaded, total))
                        }
                        output.flush()
                    }
                }
            } finally {
                connection.disconnect()
            }

            if (image.sizeBytes > 0L && downloaded != image.sizeBytes) {
                // Keep the partial file. The next press resumes instead of throwing away progress.
                error(
                    "Download incomplete: expected ${image.sizeBytes} bytes, got $downloaded bytes. " +
                        "Progress was kept and will resume on Retry."
                )
            }

            commitPartial(part, target)
            try {
                verifyCompletedDownload(target, image)
                writeVerifiedMetadata(target, image)
            } catch (t: Throwable) {
                target.delete()
                metadataFile(image).delete()
                throw t
            }
            target
        }
    }

    private fun targetFile(image: RemoteGuestImage): File =
        File(downloadDir, "${GuestImageStore.sanitizeId(image.id)}.zip")

    private fun partialFile(image: RemoteGuestImage): File =
        File(downloadDir, "${GuestImageStore.sanitizeId(image.id)}.zip.part")

    private fun metadataFile(image: RemoteGuestImage): File =
        File(downloadDir, "${GuestImageStore.sanitizeId(image.id)}.verified.json")

    private fun configureConnection(connection: HttpURLConnection, resumeFrom: Long?) {
        connection.connectTimeout = 20_000
        connection.readTimeout = 90_000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept-Encoding", "identity")
        resumeFrom?.takeIf { it > 0L }?.let {
            connection.setRequestProperty("Range", "bytes=$it-")
        }
    }

    /**
     * Old builds stored completed downloads under cacheDir. Preserve them across this update if the
     * OS has not cleared that cache yet, so users who already spent the bandwidth can Retry Install.
     */
    private fun migrateLegacyCacheIfPresent(image: RemoteGuestImage, target: File) {
        if (target.isFile) return
        val legacy = File(File(context.cacheDir, "guest_downloads"), target.name)
        if (!legacy.isFile || legacy.length() <= 0L) return
        if (image.sizeBytes > 0L && legacy.length() != image.sizeBytes) return
        target.parentFile?.mkdirs()
        if (!legacy.renameTo(target)) {
            legacy.inputStream().buffered(1024 * 1024).use { input ->
                target.outputStream().buffered(1024 * 1024).use { output ->
                    input.copyTo(output, 1024 * 1024)
                }
            }
            if (target.length() == legacy.length()) legacy.delete()
        }
    }

    private fun completedDownloadIsValid(file: File, image: RemoteGuestImage): Boolean {
        if (!file.isFile || file.length() <= 0L) return false
        if (image.sizeBytes > 0L && file.length() != image.sizeBytes) return false

        val meta = metadataFile(image)
        if (meta.isFile) {
            val validMeta = runCatching {
                val json = JSONObject(meta.readText())
                json.optString("id") == image.id &&
                    json.optLong("bytes", -1L) == file.length() &&
                    json.optString("sha256", "") == (image.sha256 ?: "") &&
                    json.optString("url", "") == image.downloadUrl
            }.getOrDefault(false)
            if (validMeta) return true
        }

        // Legacy completed downloads have no sidecar. Verify once, then mark them persistent/verified.
        return runCatching {
            verifyCompletedDownload(file, image)
            writeVerifiedMetadata(file, image)
            true
        }.getOrDefault(false)
    }

    private fun verifyCompletedDownload(file: File, image: RemoteGuestImage) {
        require(file.isFile && file.length() > 0L) { "Downloaded image archive is empty." }
        if (image.sizeBytes > 0L) {
            require(file.length() == image.sizeBytes) {
                "Downloaded image size mismatch: expected ${image.sizeBytes} bytes, got ${file.length()} bytes."
            }
        }
        image.sha256?.let { expected ->
            val actual = sha256(file)
            require(actual.equals(expected, ignoreCase = true)) {
                "Downloaded image checksum mismatch. Delete the local download and retry."
            }
        }
    }

    private fun writeVerifiedMetadata(file: File, image: RemoteGuestImage) {
        val json = JSONObject().apply {
            put("id", image.id)
            put("url", image.downloadUrl)
            put("bytes", file.length())
            put("sha256", image.sha256 ?: "")
            put("verifiedAt", System.currentTimeMillis())
        }
        metadataFile(image).writeText(json.toString())
    }

    private fun commitPartial(part: File, target: File) {
        require(part.isFile && part.length() > 0L) { "Downloaded image archive is empty." }
        if (target.exists()) target.delete()
        if (!part.renameTo(target)) {
            part.inputStream().buffered(1024 * 1024).use { input ->
                target.outputStream().buffered(1024 * 1024).use { output ->
                    input.copyTo(output, 1024 * 1024)
                }
            }
            require(target.length() == part.length()) { "Unable to finalize downloaded image archive." }
            part.delete()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(1024 * 1024).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Read several recent releases rather than only one asset. The first/newest compatible asset
     * for each Lineage version + VM flavour is kept.
     */
    private fun fetchLineageQemuCatalog(): List<RemoteGuestImage> {
        val connection = open(LINEAGE_RELEASES_API)
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/vnd.github+json")
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.connect()
        if (connection.responseCode !in 200..299) {
            error("Image catalog unavailable: HTTP ${connection.responseCode}")
        }

        val releases = JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
        connection.disconnect()
        val selected = linkedMapOf<String, RemoteGuestImage>()
        for (r in 0 until releases.length()) {
            val release = releases.getJSONObject(r)
            if (release.optBoolean("draft", false)) continue
            val tag = release.optString("tag_name", "release")
            val assets = release.optJSONArray("assets") ?: continue
            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                val assetName = asset.optString("name")
                val parsed = parseLineageAsset(assetName) ?: continue
                val key = "${parsed.lineageVersion}:${parsed.flavourKey}"
                if (key in selected) continue
                selected[key] = RemoteGuestImage(
                    id = "lineage-${parsed.lineageVersion}-${parsed.flavourKey}-$tag",
                    name = "LineageOS ${parsed.lineageVersion} • ${parsed.flavourLabel}",
                    androidVersion = parsed.androidVersion,
                    apiLevel = parsed.apiLevel,
                    architecture = "ARM64",
                    source = "jqssun/android-lineage-qemu",
                    releaseTag = tag,
                    downloadUrl = asset.getString("browser_download_url"),
                    sizeBytes = asset.optLong("size", 0L),
                    format = "UTM/QEMU ZIP",
                    sha256 = asset.optString("digest")
                        .takeIf { it.startsWith("sha256:", ignoreCase = true) }
                        ?.substringAfter(':')
                        ?.takeIf { it.matches(Regex("[0-9a-fA-F]{64}")) },
                )
                if (selected.size >= MAX_CATALOG_ITEMS) break
            }
            if (selected.size >= MAX_CATALOG_ITEMS) break
        }
        if (selected.isEmpty()) error("No compatible ARM64 UTM/QEMU Android images were found.")
        return selected.values.sortedWith(compareByDescending<RemoteGuestImage> { it.androidVersion }.thenBy { it.name })
    }

    private data class ParsedLineageAsset(
        val lineageVersion: String,
        val androidVersion: Int,
        val apiLevel: Int,
        val flavourKey: String,
        val flavourLabel: String,
    )

    private fun parseLineageAsset(name: String): ParsedLineageAsset? {
        if (!name.startsWith("UTM-VM-lineage-") || !name.endsWith(".zip", ignoreCase = true)) return null
        val lower = name.lowercase()
        if (!lower.contains("virtio_arm64")) return null
        val match = Regex("lineage-([0-9]+(?:\\.[0-9]+)?)").find(lower) ?: return null
        val lineageVersion = match.groupValues[1]
        val lineageMajor = lineageVersion.substringBefore('.').toIntOrNull() ?: return null
        val (androidVersion, apiLevel) = when (lineageMajor) {
            23 -> 16 to 36
            22 -> 15 to 35
            21 -> 14 to 34
            20 -> 13 to 33
            19 -> 12 to 32
            18 -> 11 to 30
            else -> return null
        }
        val go = lower.contains("_go") || lower.contains("-go")
        val only64 = lower.contains("arm64only")
        val flavourKey = buildString {
            append(if (only64) "arm64only" else "arm64")
            if (go) append("-go")
        }
        val flavourLabel = when {
            only64 && go -> "ARM64-only Go"
            only64 -> "ARM64-only"
            go -> "ARM64 multi-ABI Go"
            else -> "ARM64 multi-ABI"
        }
        return ParsedLineageAsset(lineageVersion, androidVersion, apiLevel, flavourKey, flavourLabel)
    }

    private fun open(url: String): HttpURLConnection = URL(url).openConnection() as HttpURLConnection

    private companion object {
        const val LINEAGE_RELEASES_API = "https://api.github.com/repos/jqssun/android-lineage-qemu/releases?per_page=30"
        const val USER_AGENT = "MultiDevice/1.0"
        const val MAX_CATALOG_ITEMS = 8
    }
}
