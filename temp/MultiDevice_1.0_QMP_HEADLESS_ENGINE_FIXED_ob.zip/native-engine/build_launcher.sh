#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$NDK" ]]; then
  echo "Set ANDROID_NDK_HOME (NDK r27+ recommended)." >&2
  exit 2
fi
HOST_TAG="linux-x86_64"
case "$(uname -s)" in
  Darwin) HOST_TAG="darwin-x86_64" ;;
esac
BIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin"
CC="$BIN/aarch64-linux-android26-clang"
STRIP="$BIN/llvm-strip"
OUT="$ROOT/app/src/main/jniLibs/arm64-v8a/libmultidevice-launcher.so"
mkdir -p "$(dirname "$OUT")"
"$CC" -O2 -fPIE -pie -Wl,-z,relro,-z,now -Wl,-z,max-page-size=16384 \
  "$ROOT/native-engine/multidevice-launcher.c" -o "$OUT"
if [[ -x "$STRIP" ]]; then "$STRIP" "$OUT"; fi
echo "Built $OUT"
