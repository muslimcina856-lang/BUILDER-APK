#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

cat <<'MSG'
Multi Device local engine preparation
-------------------------------------
This installs the local ARM64 QEMU runtime into app/src/main/jniLibs/arm64-v8a.
No cloud/backend server is used by the VM runtime.

Default path: fetch the latest Podroid release APK and extract its GPL-covered QEMU runtime.
Fallback: run native-engine/build_qemu_runtime.sh to build QEMU from the open-source pipeline.
MSG

if [[ "${1:-}" == "--build" ]]; then
  exec "$ROOT/native-engine/build_qemu_runtime.sh"
fi

python3 "$ROOT/native-engine/fetch_prebuilt_qemu.py" "${@:1}"

if [[ -n "${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}" ]]; then
  "$ROOT/native-engine/build_launcher.sh"
else
  echo "ANDROID_NDK_HOME is not set; skipping optional parent-death launcher build."
fi

echo
echo "Local QEMU runtime prepared. Next: import a compatible .mdvm guest and build the APK."
