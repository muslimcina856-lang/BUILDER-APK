/*
 * Multi Device local native process launcher.
 *
 * This tiny wrapper makes the child emulator die if the Android app process that launched it dies.
 * It is intentionally independent from the QEMU source tree.
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: multidevice-launcher <executable> [args...]\n");
        return 64;
    }
    pid_t parent = getppid();
    if (prctl(PR_SET_PDEATHSIG, SIGKILL) != 0) {
        perror("prctl(PR_SET_PDEATHSIG)");
        return 70;
    }
    if (getppid() != parent || parent == 1) {
        return 71;
    }
    execv(argv[1], &argv[1]);
    perror("execv");
    return errno ? errno : 72;
}
