#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${MULTIDEVICE_ENGINE_WORK:-$ROOT/.engine-build}"
PODROID="$WORK/Podroid"
OUT="$ROOT/app/src/main/jniLibs/arm64-v8a"
ASSET_OUT="$ROOT/app/src/main/assets/qemu"
mkdir -p "$WORK" "$OUT" "$ASSET_OUT/keymaps"

cat <<'MSG'
Multi Device local QEMU runtime builder
--------------------------------------
This reproducible helper uses the open-source Podroid Android/QEMU build pipeline to produce an
ARM64 Android PIE headless qemu-system-aarch64 executable. Multi Device uses QMP for display/input,
so a QEMU VNC backend is not required. Docker, Git and network access are required.
QEMU and Podroid are GPLv2 components. If you redistribute the resulting binary, comply with the
GPL and provide the corresponding source/build information described in THIRD_PARTY_NOTICES.md.
MSG

if [[ ! -d "$PODROID/.git" ]]; then
  git clone --depth 1 https://github.com/ExTV/Podroid.git "$PODROID"
else
  git -C "$PODROID" pull --ff-only
fi

(
  cd "$PODROID"
  ./build-qemu-android.sh
)

QEMU_SRC="$PODROID/app/src/main/jniLibs/arm64-v8a/libqemu-system-aarch64.so"
SLIRP_SRC="$PODROID/app/src/main/jniLibs/arm64-v8a/libslirp.so"
[[ -s "$QEMU_SRC" ]] || { echo "QEMU build completed without $QEMU_SRC" >&2; exit 3; }
cp -f "$QEMU_SRC" "$OUT/libqemu-system-aarch64.so"
if [[ -s "$SLIRP_SRC" ]]; then cp -f "$SLIRP_SRC" "$OUT/libslirp.so"; fi

# Podroid's QEMU build also exports the ROM/keymap files QEMU may request at runtime.
if [[ -s "$PODROID/app/src/main/assets/qemu/efi-virtio.rom" ]]; then
  cp -f "$PODROID/app/src/main/assets/qemu/efi-virtio.rom" "$ASSET_OUT/efi-virtio.rom"
fi
if [[ -d "$PODROID/app/src/main/assets/qemu/keymaps" ]]; then
  cp -Rf "$PODROID/app/src/main/assets/qemu/keymaps/." "$ASSET_OUT/keymaps/"
fi

# Build our independent orphan-process guard when a local Android NDK is available.
if [[ -n "${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}" ]]; then
  "$ROOT/native-engine/build_launcher.sh"
else
  echo "Note: ANDROID_NDK_HOME is not set; QEMU is installed, but the optional pdeath launcher was not built."
fi

echo "Local runtime installed into: $OUT"
echo "QEMU support assets installed into: $ASSET_OUT"
