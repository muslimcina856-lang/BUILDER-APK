#!/usr/bin/env python3
"""Fetch the QEMU 11 ARM64 UEFI code image used by UEFI-based Android guest bundles."""
from __future__ import annotations
import argparse, bz2, hashlib, pathlib, urllib.request

DEFAULT_URL = "https://gitlab.com/qemu-project/qemu/-/raw/v11.0.0/pc-bios/edk2-aarch64-code.fd.bz2"
UA = "MultiDevice-Firmware-Fetcher/1.0"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--output", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1] / "guest-image-template/edk2-aarch64-code.fd")
    args = ap.parse_args()
    req = urllib.request.Request(args.url, headers={"User-Agent": UA})
    print("Downloading QEMU ARM64 UEFI firmware...")
    with urllib.request.urlopen(req, timeout=120) as r:
        compressed = r.read()
    data = bz2.decompress(compressed)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    print("Wrote", args.output)
    print("SHA-256", hashlib.sha256(data).hexdigest())
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
