#!/usr/bin/env python3
"""Fetch the latest Podroid release APK and extract its Android ARM64 headless QEMU runtime.

Multi Device intentionally does not require QEMU VNC/SDL/GTK support. Its Android UI captures the
primary guest console and injects input through QMP, matching a headless QEMU build. This fetcher
does not copy Podroid application code or guest images. The extracted QEMU/SLIRP binaries remain
GPL-covered; see THIRD_PARTY_NOTICES.md before redistribution.
"""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, shutil, sys, tempfile, urllib.request, zipfile

API = "https://api.github.com/repos/ExTV/Podroid/releases/latest"
UA = "MultiDevice-QEMU-Fetcher/1.0"

def get_json(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)

def download(url: str, dest: pathlib.Path) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=120) as r, dest.open("wb") as out:
        while True:
            block = r.read(1024 * 1024)
            if not block: break
            h.update(block); out.write(block)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    ap.add_argument("--apk", type=pathlib.Path, help="Use an already-downloaded Podroid release APK")
    args = ap.parse_args()
    root = args.root.resolve()
    jni = root / "app/src/main/jniLibs/arm64-v8a"
    assets = root / "app/src/main/assets/qemu"
    jni.mkdir(parents=True, exist_ok=True); (assets / "keymaps").mkdir(parents=True, exist_ok=True)

    release = None
    apk = args.apk.resolve() if args.apk else None
    sha = None
    if apk is None:
        release = get_json(API)
        candidates = [a for a in release.get("assets", []) if str(a.get("name", "")).lower().endswith(".apk")]
        if not candidates: raise SystemExit("Latest Podroid release exposes no APK asset.")
        candidates.sort(key=lambda a: ("release" not in a.get("name", "").lower(), -int(a.get("size", 0))))
        asset = candidates[0]
        td = pathlib.Path(tempfile.mkdtemp(prefix="multidevice-podroid-"))
        apk = td / asset["name"]
        print(f"Downloading {asset['name']} from Podroid {release.get('tag_name')}...")
        sha = download(asset["browser_download_url"], apk)
        digest = asset.get("digest")
        if digest and digest.startswith("sha256:") and sha.lower() != digest.split(":", 1)[1].lower():
            raise SystemExit("Downloaded APK SHA-256 does not match GitHub release metadata.")
    if not apk.is_file(): raise SystemExit(f"APK not found: {apk}")

    wanted = {
        "lib/arm64-v8a/libqemu-system-aarch64.so": jni / "libqemu-system-aarch64.so",
        "lib/arm64-v8a/libslirp.so": jni / "libslirp.so",
        "assets/qemu/efi-virtio.rom": assets / "efi-virtio.rom",
    }
    extracted = []
    with zipfile.ZipFile(apk) as z:
        names = set(z.namelist())
        if "lib/arm64-v8a/libqemu-system-aarch64.so" not in names:
            raise SystemExit("Podroid APK does not contain the expected ARM64 QEMU runtime.")
        for src, dst in wanted.items():
            if src in names:
                dst.parent.mkdir(parents=True, exist_ok=True)
                with z.open(src) as inp, dst.open("wb") as out: shutil.copyfileobj(inp, out)
                extracted.append(str(dst.relative_to(root)))
        for name in names:
            if name.startswith("assets/qemu/keymaps/") and not name.endswith("/"):
                rel = pathlib.PurePosixPath(name).relative_to("assets/qemu/keymaps")
                if ".." in rel.parts: continue
                dst = assets / "keymaps" / pathlib.Path(*rel.parts)
                dst.parent.mkdir(parents=True, exist_ok=True)
                with z.open(name) as inp, dst.open("wb") as out: shutil.copyfileobj(inp, out)

    origin = root / "native-engine/runtime-origin.txt"
    origin.write_text(
        "source=ExTV/Podroid release APK\n" +
        (f"tag={release.get('tag_name')}\n" if release else "tag=user-supplied-apk\n") +
        (f"apk_sha256={sha}\n" if sha else f"apk_sha256={hashlib.sha256(apk.read_bytes()).hexdigest()}\n") +
        "runtime=lib/arm64-v8a/libqemu-system-aarch64.so\n"
    )
    print("Installed:")
    for item in extracted: print(" -", item)
    print("Recorded origin:", origin)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
