# Multi Device UI audit

Audit performed against the real-device screenshot supplied during development and every current Compose screen.

## Fixed defects

1. **First launch showed fake profiles** — removed all automatic seeding. Added a one-time migration that deletes only the exact five legacy preview profiles from earlier test builds.
2. **Profile names and Android/device metadata wrapped into narrow columns** — profile cards now give the text block the full available width; status stays top-right and actions live on a separate row.
3. **Low-contrast / default-looking snackbar** — snackbar now uses the app's dark surface, bright primary text and cyan action color.
4. **Muted text was too dim** — theme surfaces, muted text, subtle text, outlines and status colors were raised to readable contrast levels.
5. **No Image Library destination** — bottom navigation now shows `Library`; the screen has Catalog and Installed sections.
6. **Create Profile presented hard-coded Android versions** — it now shows only actually installed bootable images and directs the user to Library when none exist.
7. **Running VM screen could clip controls on smaller phones** — normal mode is now scrollable and VM actions use equal-width compact cells; fullscreen stays dedicated to the guest display.
8. **Settings key/value rows could collide on narrow screens** — settings now use stacked two-line values inside a scrollable layout.
9. **Broken APK could compile without QEMU runtime** — `preBuild` now ensures the runtime is packaged or fails the build with a clear error.
10. **Image strategy was unclear** — guest OS images are downloaded/imported separately; the APK contains the engine/support firmware, not every Android system image.

## Responsive UI rules kept in code

- Profile names: max 2 lines + ellipsis.
- IDs/MACs: monospace, bounded line count.
- Long selectors/presets: horizontally scrollable where appropriate.
- Wizard content: each step scrolls independently while Back/Continue stay visible.
- Main screens: lazy/scrollable containers with bottom safe spacing.
- Destructive/error states use dedicated high-contrast error color rather than muted purple/gray.

## Real-device audit 2026-08-18

Screenshots 11774/11775/11776 exposed two issues not visible in static previews:

1. Create/Edit/VM routes were rendered directly under MaterialTheme instead of a root Surface. The Android window fallback showed through as gray, and Text/Icon composables without explicit colors inherited an unsuitable dark/black LocalContentColor. The fix is a full-screen root Material3 Surface with Bg/TextPrimary plus explicit contentColor on NeonCard and critical wizard labels.
2. Starting an encrypted-tunnel profile called ConnectivityManager.activeNetwork/getNetworkCapabilities without declaring ACCESS_NETWORK_STATE. The manifest now declares the normal permission, HostVpnInspector fails safely, and preflight failures return to STOPPED instead of persisting ERROR when no QEMU process was started.

No layout redesign was made beyond color/readability correction; the approved navigation, cards, controls and workflow remain unchanged.
