# Multi Device — Project Rules

1. App name: **Multi Device**.
2. Package ID: **com.virtual.devicelization**.
3. Assistant-made project updates keep `versionCode = 1` and `versionName = "1.0"` unless the user explicitly asks for a version change. There is **no version lock/guard**; the owner may edit either value manually.
4. Multiple profiles may be stored, but **MAX_ACTIVE_VM = 1**. A QMP-paused/SUSPENDED QEMU process still counts as the one active VM because it still owns RAM/process state.
5. A profile owns its own Android image reference, writable disk copy, device config, UEFI-variable copy (when used), virtual MAC and network config.
6. `Reset MAC` changes only the guest virtual NIC MAC. Never touch the host factory Wi-Fi/Bluetooth MAC.
7. No host IMEI/serial/SIM identifier spoofing.
8. Encrypted networking is described as an **Encrypted Tunnel**, not "encrypted IP".
9. When `ENCRYPTED_TUNNEL` is selected, startup requires an active Android VPN that is actually visible to Multi Device. If the profile kill switch is enabled and that VPN disappears, terminate the guest/fail closed. Never silently fall back to Direct/NAT.
10. UI talks to a `VmBackend` abstraction. UI must not depend directly on QEMU/AVF/crosvm/JNI details.
11. Never claim a full Android guest is running unless a real local backend process started and exposed its real display endpoint.
12. Do not add a second simultaneously running or QMP-paused VM.
13. Do not turn the project into a launcher replacement or ordinary app-cloner.
14. No simulated RUNNING state is allowed when the local runtime/image is absent.
15. Imported guest bundles are untrusted input: enforce path containment, storage limits and a QEMU argument allow-list.
16. Guest model/device labels are compatibility/profile metadata only; do not claim hardware-backed/certified identity or bypass platform integrity checks.
## First-run and image rules

- Fresh installation MUST start with zero profiles. Never add demo/seed profiles.
- The bottom navigation MUST expose **Library** for guest Android images.
- Do not bundle multi-gigabyte Android guest images into the base APK. Download/import the selected compatible image on demand.
- Do not allow profile creation to silently invent an Android image; a profile must reference an installed image.
- The local VM runtime itself IS part of the APK. Builds must fail if the ARM64 QEMU runtime cannot be packaged.
- Keep UI text high-contrast and responsive; names/metadata/actions must not compete in the same narrow row.

