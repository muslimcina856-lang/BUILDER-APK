#!/usr/bin/env python3
"""Pack one prepared Multi Device guest-image directory into a .mdvm ZIP."""
from pathlib import Path
import argparse, json, zipfile, sys

p = argparse.ArgumentParser()
p.add_argument("source", type=Path, help="directory containing manifest.json and referenced files")
p.add_argument("output", type=Path, help="output .mdvm")
a = p.parse_args()
source = a.source.resolve()
manifest_path = source / "manifest.json"
if not manifest_path.is_file():
    sys.exit("manifest.json missing")
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
refs = [manifest.get("kernel"), manifest.get("initrd"), manifest.get("firmwareCode"), manifest.get("firmwareVars")]
refs += [d.get("file") for d in manifest.get("drives", [])]
for rel in filter(None, refs):
    f = (source / rel).resolve()
    if source not in f.parents or not f.is_file():
        sys.exit(f"missing/unsafe referenced file: {rel}")
a.output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(a.output, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for f in source.rglob("*"):
        if f.is_file():
            z.write(f, f.relative_to(source).as_posix())
print(a.output)
