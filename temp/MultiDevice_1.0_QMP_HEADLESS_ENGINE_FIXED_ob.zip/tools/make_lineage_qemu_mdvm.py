#!/usr/bin/env python3
"""Convert an extracted/ZIP LineageOS QEMU UTM ARM64 image into a Multi Device .mdvm bundle.

Expected inputs are the ARM64 UTM VM release layout from jqssun/android-lineage-qemu and an ARM64
QEMU UEFI code file (edk2-aarch64-code.fd/AAVMF_CODE.fd). This script does not download or modify
LineageOS; it repackages user-supplied files for Multi Device's local QEMU backend.
"""
from __future__ import annotations
import argparse, json, pathlib, shutil, tempfile, zipfile


def find_one(root: pathlib.Path, name: str) -> pathlib.Path:
    hits = [p for p in root.rglob(name) if p.is_file()]
    if len(hits) != 1:
        raise SystemExit(f"Expected exactly one {name}; found {len(hits)}")
    return hits[0]


def materialize_source(source: pathlib.Path) -> tuple[pathlib.Path, tempfile.TemporaryDirectory | None]:
    if source.is_dir(): return source, None
    if not zipfile.is_zipfile(source): raise SystemExit("--source must be an extracted UTM directory or ZIP")
    td = tempfile.TemporaryDirectory(prefix="multidevice-lineage-")
    root = pathlib.Path(td.name)
    with zipfile.ZipFile(source) as z:
        for info in z.infolist():
            rel = pathlib.PurePosixPath(info.filename)
            if rel.is_absolute() or ".." in rel.parts: raise SystemExit("Unsafe ZIP path")
            target = root.joinpath(*rel.parts)
            if info.is_dir(): target.mkdir(parents=True, exist_ok=True); continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as inp, target.open("wb") as out: shutil.copyfileobj(inp, out, 1024 * 1024)
    return root, td


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=pathlib.Path, required=True, help="UTM-VM-lineage-...-virtio_arm64only.zip or extracted directory")
    ap.add_argument("--firmware-code", type=pathlib.Path, required=True, help="edk2-aarch64-code.fd / AAVMF_CODE.fd")
    ap.add_argument("--android-version", type=int, required=True)
    ap.add_argument("--api-level", type=int, required=True)
    ap.add_argument("--id", required=True)
    ap.add_argument("--name", default="LineageOS ARM64 QEMU")
    ap.add_argument("--output", type=pathlib.Path, required=True)
    args = ap.parse_args()
    if not args.firmware_code.is_file(): raise SystemExit("Firmware code file not found")
    root, td = materialize_source(args.source.resolve())
    try:
        vda, vdb, varsfd = (find_one(root, n) for n in ("vda.qcow2", "vdb.qcow2", "efi_vars.fd"))
        with tempfile.TemporaryDirectory(prefix="multidevice-mdvm-") as build:
            b = pathlib.Path(build)
            shutil.copy2(vda, b / "vda.qcow2")
            shutil.copy2(vdb, b / "vdb.qcow2")
            shutil.copy2(varsfd, b / "efi_vars.fd")
            shutil.copy2(args.firmware_code, b / "edk2-aarch64-code.fd")
            manifest = {
                "id": args.id,
                "name": args.name,
                "androidVersion": args.android_version,
                "apiLevel": args.api_level,
                "architecture": "ARM64",
                "machine": "virt",
                "cpu": "max,pauth-impdef=on",
                "firmwareCode": "edk2-aarch64-code.fd",
                "firmwareVars": "efi_vars.fd",
                "drives": [
                    {"id":"vda","file":"vda.qcow2","format":"qcow2","readOnly":False,"profileScoped":True,"if":"none","device":"virtio-blk-pci"},
                    {"id":"vdb","file":"vdb.qcow2","format":"qcow2","readOnly":False,"profileScoped":True,"if":"none","device":"virtio-blk-pci"},
                ],
                "extraArgs": [
                    "-device", "virtio-gpu-pci",
                    "-device", "usb-ehci,id=usb-bus",
                    "-device", "usb-tablet,bus=usb-bus.0",
                    "-device", "usb-mouse,bus=usb-bus.0",
                    "-device", "usb-kbd,bus=usb-bus.0",
                    "-device", "virtio-serial",
                    "-device", "virtio-rng-pci",
                ],
            }
            (b / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as z:
                for p in sorted(b.iterdir()): z.write(p, p.name)
        print("Created", args.output)
        print("Import this .mdvm from Multi Device > Images.")
        return 0
    finally:
        if td is not None: td.cleanup()

if __name__ == "__main__":
    raise SystemExit(main())
