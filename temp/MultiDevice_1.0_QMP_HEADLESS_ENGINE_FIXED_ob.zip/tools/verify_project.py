#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []


def text(path: str) -> str:
    p = ROOT / path
    if not p.is_file():
        errors.append(f"Missing file: {path}")
        return ""
    return p.read_text(encoding="utf-8")


def require(path: str, pattern: str, message: str) -> None:
    if not re.search(pattern, text(path), re.MULTILINE | re.DOTALL):
        errors.append(message)


def require_file(path: str, message: str) -> None:
    if not (ROOT / path).is_file():
        errors.append(message)


require('app/build.gradle.kts', r'\bapplicationId\s*=\s*"com\.virtual\.devicelization"', 'Package ID changed')
require('app/src/main/res/values/strings.xml', r'<string name="app_name">Multi Device</string>', 'App name changed')
require('app/src/main/AndroidManifest.xml', r'android:allowBackup="false"', 'Application backup must remain disabled for private VM/profile data')
require('app/src/main/AndroidManifest.xml', r'android\.permission\.ACCESS_NETWORK_STATE', 'ACCESS_NETWORK_STATE permission is required for ConnectivityManager VPN/network checks')
require('app/src/main/res/values/styles.xml', r'android:windowBackground">#020817', 'Android window fallback background must stay dark')
require('app/src/main/java/com/virtual/devicelization/ui/theme/Theme.kt', r'MaterialSurface\s*\(.*?color\s*=\s*Bg.*?contentColor\s*=\s*TextPrimary', 'Root dark Surface/content color provider missing')
require('app/src/main/java/com/virtual/devicelization/ui/components/NeonComponents.kt', r'CardDefaults\.cardColors\s*\(.*?contentColor\s*=\s*TextPrimary', 'NeonCard must provide readable TextPrimary content color')
require('app/src/main/java/com/virtual/devicelization/core/vm/SingleVmPolicy.kt', r'count\s*\{[^\n]*activeStates[^\n]*\}\s*<=\s*1', 'Single-VM invariant missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt', r'class\s+LocalQemuVmBackend', 'Local QEMU backend missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt', r'libqemu-system-aarch64\.so', 'QEMU runtime contract missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt', r'startVpnGuardIfNeeded', 'Encrypted Tunnel VPN-loss guard missing')
require('app/src/main/java/com/virtual/devicelization/core/network/HostVpnInspector.kt', r'TRANSPORT_VPN', 'Host VPN detection missing')
require('app/src/main/java/com/virtual/devicelization/core/network/HostVpnInspector.kt', r'hasVpnDnsServers', 'VPN DNS readiness check missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt', r'tcg,thread=multi,tb-size=512', 'TCG engine configuration missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt', r'if=pflash,unit=0', 'ARM64 UEFI/pflash command path missing')
require_file('app/src/main/java/com/virtual/devicelization/core/display/QmpDisplayClient.kt', 'QMP framebuffer/input bridge missing')
require('app/src/main/java/com/virtual/devicelization/core/display/QmpDisplayClient.kt', r'screendump', 'QMP screendump framebuffer capture missing')
require('app/src/main/java/com/virtual/devicelization/core/display/QmpDisplayClient.kt', r'input-send-event', 'QMP pointer input bridge missing')
require('app/src/main/java/com/virtual/devicelization/ui/components/QmpGuestView.kt', r'onCreateInputConnection', 'QMP soft-keyboard bridge missing')
require('app/src/main/java/com/virtual/devicelization/ui/screens/RunningVmScreen.kt', r'QmpGuestView', 'Running VM screen must use the headless QMP display bridge')
require('app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt', r'REQUIRED_QMP_COMMANDS', 'QMP runtime capability preflight missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt', r'probeRuntimeDevices', 'QEMU device capability preflight missing')
require_file('app/src/main/java/com/virtual/devicelization/core/vm/VmRuntimeState.kt', 'Process-local QMP endpoint state missing')
if re.search(r'"-vnc"', text('app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt')):
    errors.append('QemuCommandBuilder must not require VNC from the headless Android runtime')
require('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt', r'firmwareCode', 'Guest firmware manifest support missing')
require('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt', r'createProfileSnapshot', 'Profile snapshot support missing')
require('app/src/main/java/com/virtual/devicelization/ui/MainViewModel.kt', r'fun\s+updateProfile', 'Profile editing support missing')
require('app/src/main/java/com/virtual/devicelization/ui/MainViewModel.kt', r'prepared\.isFailure.*?VmStatus\.STOPPED', 'VM preflight failures must return profile to STOPPED rather than misleading ERROR')

require('app/src/main/java/com/virtual/devicelization/data/ProfileStore.kt', r'raw = prefs\.getString\(KEY_PROFILES, null\) \?: return emptyList\(\)', 'Fresh install must start with zero profiles')
if 'seedProfiles(' in text('app/src/main/java/com/virtual/devicelization/data/ProfileStore.kt'):
    errors.append('Demo profile seeding must not return')
require('app/src/main/java/com/virtual/devicelization/ui/screens/Common.kt', r'Library', 'Bottom navigation Library tab missing')
require('app/src/main/java/com/virtual/devicelization/ui/screens/ImagesScreen.kt', r'Image Library', 'Image Library screen missing')
require('app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt', r'releases\?per_page=30', 'Multi-variant remote image catalog missing')
require_file('app/src/main/java/com/virtual/devicelization/core/image/UtmConfigParser.kt', 'UTM config.plist parser missing')
require('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt', r'resolveDocumentedLineageLayout', 'Documented Lineage UTM release layout fast path missing')
require('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt', r'UtmConfigParser\.resolve', 'Non-standard UTM config.plist fallback missing')
require('app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt', r'bootindex=', 'UTM boot drive ordering support missing')
require('app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt', r'checksum mismatch', 'Downloaded image checksum validation missing')
require('app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt', r'File\(context\.filesDir, "guest_downloads"\)', 'Completed image downloads must be persistent under filesDir')
require('app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt', r'Range', 'Interrupted image download resume support missing')
require('app/src/main/java/com/virtual/devicelization/ui/MainViewModel.kt', r'fun\s+installDownloadedImage', 'Retry Install from saved download missing')
require('app/src/main/java/com/virtual/devicelization/ui/screens/ImagesScreen.kt', r'Retry Install.*No Re-download', 'Image Library must expose no-redownload retry install state')
require('app/build.gradle.kts', r'prepareLocalQemuRuntime', 'Build-time local QEMU runtime preparation missing')
require('app/build.gradle.kts', r'tasks\.named\("preBuild"\).*dependsOn\(prepareLocalQemuRuntime\)', 'preBuild must require local QEMU runtime')
require_file('UI_AUDIT.md', 'UI audit report missing')
require_file('app/src/main/res/raw/edk2_aarch64_code_fd.gz', 'APK-bundled ARM64 UEFI firmware resource missing')
require('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt', r'R\.raw\.edk2_aarch64_code_fd', 'Installer must open firmware through compile-time res/raw resource ID')
if 'context.assets.open("firmware/edk2-aarch64-code.fd.gz")' in text('app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt'):
    errors.append('Installer must not depend on runtime AssetManager lookup for mandatory ARM64 firmware')
require('app/build.gradle.kts', r'verifyEmbeddedArm64Firmware', 'Build must verify embedded ARM64 UEFI firmware before packaging')

# Compose compatibility guard. This project intentionally uses Compose BOM 2024.06.00.
# Material3 1.2.x does not expose the newer DropdownMenu custom container/shape/elevation/border
# parameters that were added for Material3 1.3. Keep the menu call on the older compatible API.
profiles_screen = text('app/src/main/java/com/virtual/devicelization/ui/screens/ProfilesScreen.kt')
for match in re.finditer(r'DropdownMenu\s*\((.*?)\)\s*\{', profiles_screen, re.DOTALL):
    args = match.group(1)
    for unsupported in ('containerColor', 'shape', 'tonalElevation', 'shadowElevation', 'border'):
        if re.search(rf'\b{unsupported}\s*=', args):
            errors.append(
                f'Compose BOM 2024.06.00 compatibility: DropdownMenu parameter {unsupported} is not allowed'
            )

require_file('native-engine/prepare_local_engine.sh', 'Local engine preparation helper missing')
require_file('native-engine/fetch_prebuilt_qemu.py', 'Prebuilt QEMU fetch helper missing')
require_file('native-engine/build_qemu_runtime.sh', 'QEMU source build helper missing')
require_file('tools/make_lineage_qemu_mdvm.py', 'Lineage/QEMU guest conversion helper missing')
require('tools/make_mdvm.py', r'firmwareCode', 'Generic .mdvm packer does not include UEFI firmware references')
require_file('design/multi_device_icon_original.png', 'Approved application icon missing')
for n in range(1, 8):
    matches = list((ROOT / 'design/previews').glob(f'{n:02d}_*.png'))
    if not matches:
        errors.append(f'Missing approved screen preview {n:02d}')

firmware = ROOT / 'guest-image-template/edk2-aarch64-code.fd'
if not firmware.is_file():
    errors.append('ARM64 UEFI template firmware missing')
else:
    digest = hashlib.sha256(firmware.read_bytes()).hexdigest()
    expected = '47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d'
    if digest != expected:
        errors.append(f'Unexpected UEFI template firmware SHA-256: {digest}')

raw_firmware = ROOT / 'app/src/main/res/raw/edk2_aarch64_code_fd.gz'
if raw_firmware.is_file():
    import gzip
    try:
        with gzip.open(raw_firmware, 'rb') as fh:
            data = fh.read()
        if len(data) != 67_108_864:
            errors.append(f'Unexpected embedded UEFI firmware size: {len(data)}')
        embedded_digest = hashlib.sha256(data).hexdigest()
        if embedded_digest != '47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d':
            errors.append(f'Unexpected embedded UEFI firmware SHA-256: {embedded_digest}')
    except Exception as exc:
        errors.append(f'Embedded UEFI firmware resource is not a valid gzip stream: {exc}')

build = text('app/build.gradle.kts')
vc = re.search(r'\bversionCode\s*=\s*([^\n]+)', build)
vn = re.search(r'\bversionName\s*=\s*([^\n]+)', build)

# Version values are intentionally only reported. The user owns release/version changes and this
# verifier must never act as a version lock.
if errors:
    print('PROJECT VERIFICATION FAILED')
    for e in errors:
        print(f'- {e}')
    sys.exit(1)

print('PROJECT VERIFICATION PASSED')
print('App: Multi Device')
print('Package: com.virtual.devicelization')
print('versionCode:', vc.group(1).strip() if vc else '(not found)')
print('versionName:', vn.group(1).strip() if vn else '(not found)')
print('Version values are reported only; they are NOT locked by this verifier.')
print('MAX_ACTIVE_VM: 1')
print('Local headless QEMU + QMP framebuffer/touch/keyboard: present')
print('Direct/NAT + Offline + host-VPN Encrypted Tunnel guard: present')
print('Direct-kernel + UEFI guest image support: present')
print('Profile editing + virtual MAC + disk snapshots: present')
print('Approved icon + 7 screen previews: present')
