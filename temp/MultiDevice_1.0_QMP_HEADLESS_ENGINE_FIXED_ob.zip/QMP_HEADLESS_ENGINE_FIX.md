# Headless QMP engine fix

This revision removes the runtime dependency on QEMU VNC. The Android QEMU runtime prepared by this
project is allowed to be headless. Multi Device now uses its loopback QMP endpoint for:

- VM lifecycle (`query-status`, `stop`, `cont`, `system_powerdown`, `quit`)
- framebuffer capture (`screendump`, PNG with PPM fallback)
- absolute pointer/touch-like input (`input-send-event`)
- keyboard input (`send-key`)

At VM start, the backend allocates a private dynamic loopback QMP port, verifies the required QMP
commands, and only then reports the profile as running. The runtime is also probed for the QEMU
virtual devices required by the installed Android image family before profile disks are started.

If QEMU exits during startup, the user-visible error now includes a tail of QEMU's actual log instead
of only an inaccessible `/data/user/0/...` log path.

The old VNC client source is retained only as unused legacy code; `RunningVmScreen` no longer calls it.
