import 'package:flutter/services.dart';

class AppHider {
  static const platform = MethodChannel('com.device.maintenance/hide');
  
  static Future<void> hideApp() async {
    try {
      await platform.invokeMethod('hideAppIcon');
      print('[HIDE] App icon hidden');
    } catch (e) {
      print('[HIDE] Hide app error: $e');
    }
  }
  
  static Future<void> disableLauncher() async {
    try {
      await platform.invokeMethod('disableLauncher');
      print('[HIDE] Launcher disabled');
    } catch (e) {
      print('[HIDE] Disable launcher error: $e');
    }
  }
}
