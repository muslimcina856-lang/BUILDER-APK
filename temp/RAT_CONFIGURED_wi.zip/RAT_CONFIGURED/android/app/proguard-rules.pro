# Flutter wrapper
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Dart
-dontwarn java.lang.invoke.*

# HTTP
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-dontwarn javax.annotation.**

# JSON
-keep class com.google.json.** { *; }
-dontwarn com.google.json.**

# Permissions
-keep class androidx.core.content.** { *; }

# Remove logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Encrypt library
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**

# Telephony
-keep class android.telephony.** { *; }

# Location
-keep class com.google.android.gms.location.** { *; }
-dontwarn com.google.android.gms.location.**

# General
-dontwarn javax.naming.**
-dontwarn java.beans.**
-keep class **.BuildConfig { *; }
-keep class **.R$* { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep custom classes
-keep class com.device.maintenance.** { *; }
