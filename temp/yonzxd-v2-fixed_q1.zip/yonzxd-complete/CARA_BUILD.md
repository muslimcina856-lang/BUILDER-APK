# Cara Build YONZXD Jadi APK Android

**VERSION: 2.0 (FIXED GRADLE ERROR)** ✅

Project ini sudah disiapkan dalam bentuk **Capacitor** dengan struktur Android yang **sudah lengkap**, sehingga langsung bisa di-build tanpa masalah Gradle.

---

## 🔧 Perbedaan Versi 2.0

**Versi 1.0** mendapat error:
```
Could not read script 'capacitor.settings.gradle' as it does not exist.
```

**Versi 2.0 sudah include:**
✅ `android/capacitor.settings.gradle` (file yang hilang)
✅ `android/settings.gradle` (konfigurasi lengkap)
✅ `android/build.gradle` & `android/app/build.gradle` (Gradle build files)
✅ `android/gradle.properties` (optimasi Gradle)
✅ Folder `www/` dengan `index.html` yang siap pakai
✅ Struktur Capacitor yang benar

---

## ⚙️ Yang harus disiapkan dulu di komputer

1. **Node.js** 18+ — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio
3. **Java JDK 17** (biasanya sudah dengan Android Studio)

---

## 🚀 Langkah Build (SUPER MUDAH)

### 1️⃣ Install Dependencies
```bash
npm install
```
Tunggu sampai selesai (pertama kali: 2-5 menit).

### 2️⃣ Sinkronkan File Web ke Android
```bash
npx cap sync
```

### 3️⃣ Buka di Android Studio
```bash
npx cap open android
```
Android Studio akan terbuka otomatis.

### 4️⃣ Tunggu Gradle Sync
Di pojok **bawah kanan** Android Studio, tunggu progress bar "Gradle Sync" selesai (3-10 menit pertama kali).

### 5️⃣ Build APK
Di menu Android Studio:
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

### 6️⃣ Tunggu Notifikasi
Tunggu notifikasi "APK(s) generated successfully". Klik "locate" untuk membuka folder.

APK ada di:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### 7️⃣ Install ke HP
Salin `app-debug.apk` ke HP Android, install seperti biasa.

> Mungkin perlu izin "Install dari sumber tidak dikenal" di Pengaturan HP.

---

## ❌ Troubleshooting

### Error: "npm not found"
```bash
# Verifikasi Node.js terinstall
node -v
npm -v
```
Jika tidak ada, unduh dari https://nodejs.org dan install ulang.

### Error: "Android SDK not found"
1. Buka Android Studio
2. Tools → SDK Manager
3. Pasang SDK yang diperlukan
4. Set environment variable `ANDROID_HOME`

### Error: "Java not found"
1. Buka Android Studio
2. File → Project Structure → SDK Location
3. Pastikan JDK 17 sudah ada

### Gradle Sync Lambat
- Pertama kali bisa 10-15 menit (download Gradle & dependencies)
- Berikutnya lebih cepat
- Pastikan koneksi internet stabil

### APK Build Gagal
1. Build → Clean Project
2. Tunggu selesai
3. Build → Build APK(s) lagi

---

## 🎨 Customization

### Ubah Nama Aplikasi
Edit `capacitor.config.json`:
```json
{
  "appName": "Nama Baru YONZXD"
}
```
Lalu:
```bash
npx cap sync
```

### Ubah App ID (Package Name)
Edit `capacitor.config.json`:
```json
{
  "appId": "com.namamu.appmu"
}
```
Dan edit `android/app/build.gradle`:
```gradle
applicationId "com.namamu.appmu"
```

### Ubah Ikon Aplikasi
Ikon ada di: `android/app/src/main/res/mipmap-*/ic_launcher.png`

Ganti dengan ikon PNG kamu:
- `mipmap-ldpi/` → 36x36px
- `mipmap-mdpi/` → 48x48px
- `mipmap-hdpi/` → 72x72px
- `mipmap-xhdpi/` → 96x96px
- `mipmap-xxhdpi/` → 144x144px
- `mipmap-xxxhdpi/` → 192x192px

Atau gunakan **Image Asset Studio** di Android Studio:
1. Klik kanan `res` folder → New → Image Asset
2. Pilih ikon PNG → Next/Finish

---

## 📝 Edit Fitur App

Semua fitur ada di `www/index.html` (satu file, mudah diedit):

1. Edit `www/index.html`
2. Simpan file
3. Jalankan:
   ```bash
   npx cap sync
   ```
4. Buka Android Studio & build lagi

---

## 🔌 Tambah Plugin Capacitor

Contoh: Camera Plugin
```bash
npm install @capacitor/camera
npx cap sync
```

Gunakan di `www/index.html`:
```javascript
import { Camera } from '@capacitor/camera';
const photo = await Camera.getPhoto();
```

---

## 📦 File Structure

```
yonzxd-complete/
├── package.json                          # Node.js dependencies
├── capacitor.config.json                 # Capacitor config
├── www/
│   └── index.html                        # Frontend aplikasi
├── android/                              # Android project (LENGKAP!)
│   ├── settings.gradle                   ✅ FIX: file yang sering hilang
│   ├── capacitor.settings.gradle         ✅ FIX: required by Capacitor
│   ├── build.gradle
│   ├── gradle.properties
│   ├── gradle/wrapper/
│   └── app/
│       ├── build.gradle
│       └── proguard-rules.pro
└── CARA_BUILD.md                        # File ini
```

---

## ✨ Fitur Aplikasi

- ⬆️ **Auto-Scroll** - Scroll otomatis
- 🖱️ **Auto-Click** - Klik otomatis
- 🌐 **Translator** - Multi-bahasa
- ⏰ **Scheduler** - Jadwal pekerjaan
- 📝 **Logger** - Catat aktivitas
- 📊 **Analytics** - Statistik
- 💬 **Messenger** - Kirim pesan
- 💾 **Backup** - Sinkronisasi
- 🔒 **Security** - Pengaturan keamanan

---

## 🎯 Catatan Penting

- **Jangan hapus folder `android/`** — itu untuk project Android
- **Jangan hapus `www/` folder** — itu untuk web app
- **Jangan edit di dalam `android/` folder** — biarkan Capacitor yang kelola
- Untuk production release APK, sign dengan key store (bukan debug APK)

---

## 📞 Support

**Developer:** AYONZ Soul Founder  
**Email:** ayonsoulfounder@gmail.com  
**Version:** 2.0.0  
**License:** ISC

---

**Happy Building! 🚀**
