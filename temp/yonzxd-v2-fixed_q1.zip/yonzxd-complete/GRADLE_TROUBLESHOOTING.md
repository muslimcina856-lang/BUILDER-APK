# 🔧 GRADLE TROUBLESHOOTING GUIDE

## Error: "capacitor.settings.gradle does not exist"

**Status:** ✅ FIXED di versi 2.0

File `android/capacitor.settings.gradle` sudah include dalam project ini.

---

## Jika Masih Error

### Solusi 1: Clean Build
```bash
cd android
./gradlew clean
cd ..
npx cap sync
npx cap open android
```

### Solusi 2: Delete Build Cache
```bash
# Hapus folder build
rm -rf android/app/build
rm -rf android/build

# Rebuild
npx cap sync
npx cap open android
```

### Solusi 3: Reset Android Project
```bash
# Hapus android folder
rm -rf android

# Recreate
npx cap add android
npx cap sync
npx cap open android
```

---

## Error: Gradle Sync "Error resolving dependencies"

**Penyebab:** Internet terputus atau repo Maven down

**Solusi:**
1. Pastikan koneksi internet stabil
2. Buka Android Studio
3. File → Sync Now
4. Tunggu sampai selesai

---

## Error: "Java 17 not found"

**Solusi:**
1. Buka Android Studio
2. File → Project Structure → SDK Location
3. Pastikan JDK 17 ada
4. Jika tidak ada, download dari https://www.oracle.com/java/technologies/downloads/#java17

Atau set di terminal:
```bash
# Windows
set JAVA_HOME=C:\Program Files\Java\jdk-17

# Mac/Linux
export JAVA_HOME=/usr/libexec/java_home -v 17
```

---

## Error: "Android SDK not configured"

**Solusi:**
1. Buka Android Studio
2. Tools → SDK Manager
3. Install Android SDK Level 34 & tools
4. Buka `android/local.properties` dan tambahkan:
```properties
sdk.dir=/path/to/Android/Sdk
```

---

## Error: "Build failed: Execution failed for task ':app:mergeDebugResources'"

**Penyebab:** Konflik resource atau gradle cache corrupt

**Solusi:**
```bash
cd android
./gradlew clean
cd ..
npx cap sync
npx cap open android
```

---

## Error: "Gradle Sync Timeout"

**Penyebab:** Dependencies terlalu banyak atau internet lambat

**Solusi:**
1. Tunggu lebih lama (bisa 15-20 menit pertama kali)
2. Atau increase timeout di `android/gradle.properties`:
```properties
org.gradle.daemon.idletimeout=15000
org.gradle.workers.max=1
```

---

## Gradle Jalan Lambat

**Optimization di `android/gradle.properties`:**
```properties
# Already set to optimal defaults:
org.gradle.jvmargs=-Xmx2048m
org.gradle.parallel=true
org.gradle.daemon=true
org.gradle.caching=true
```

Jika masih lambat:
1. Tutup aplikasi lain
2. Restart Android Studio
3. Jalankan: `./gradlew --stop` (untuk reset daemon)

---

## Error: APK Build Gagal

**Common Issues:**

### 1. Out of Memory
```bash
# Edit android/gradle.properties
org.gradle.jvmargs=-Xmx4096m
```

### 2. Conflicting Dependencies
```bash
# Delete lockfile
rm -f android/build.gradle.kts.lock
npx cap sync
```

### 3. ProGuard Error
Edit `android/app/build.gradle`:
```gradle
buildTypes {
    release {
        minifyEnabled false  // Set ke false
    }
}
```

---

## Debugging Tips

### Check Gradle Version
```bash
cd android
./gradlew --version
```

### Check Java Version
```bash
java -version
javac -version
```

### See Build Output
Di Android Studio:
```
View → Tool Windows → Build → Rebuild Project
```
Lihat output di bawah untuk detail error.

---

## Nuclear Option: Start Fresh

Jika semua gagal:

```bash
# Backup important files
cp www/index.html ~/backup-index.html

# Delete everything
rm -rf node_modules
rm -rf android
rm package-lock.json

# Start fresh
npm install
npx cap add android
npx cap sync
npx cap open android
```

---

## Masih Error?

1. Pastikan semua files dalam `android/` folder ada
2. Verifikasi `package.json` & `capacitor.config.json` benar
3. Check file permissions: `chmod -R 755 android/`
4. Coba di komputer lain atau OS berbeda

---

**Still stuck? Email:** ayonsoulfounder@gmail.com
