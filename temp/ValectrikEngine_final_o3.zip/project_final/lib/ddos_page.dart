import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';

class DdosPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const DdosPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.black, Colors.black],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // === HEADER ===
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.redAccent.withOpacity(0.2), Colors.transparent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.redAccent, width: 1),
                  ),
                  child: Column(
                    children: const [
                      Text(
                        "Internet Attack",
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontSize: 24,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(color: Colors.redAccent, blurRadius: 10),
                          ],
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 4),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // === GRID MENU ===
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1,
                    children: [
                      _menuCard(
                        context: context,
                        icon: Icons.flash_on,
                        glowColor: Colors.red,
                        label: "Attack Panel",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => AttackPanel(
                                sessionKey: sessionKey,
                                listDoos: listDoos,
                              ),
                            ),
                          );
                        },
                      ),
                      _menuCard(
                        context: context,
                        icon: Icons.dns,
                        glowColor: Colors.blueAccent,
                        label: "Manage Server",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  ManageServerPage(keyToken: sessionKey),
                            ),
                          );
                        },
                      ),
                      _menuCard(
                        context: context,
                        icon: Icons.wifi_off,
                        glowColor: Colors.greenAccent,
                        label: "WiFi Killer (Internal)",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => WifiKillerPage(),
                            ),
                          );
                        },
                      ),
                      if (userRole == "vip" || userRole == "owner")
                        _menuCard(
                          context: context,
                          icon: Icons.router,
                          glowColor: Colors.orangeAccent,
                          label: "WiFi Killer (External)",
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => WifiInternalPage(
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _menuCard({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color glowColor,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: GestureDetector(
        onTap: onTap,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: glowColor, width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: glowColor.withOpacity(0.7),
                    blurRadius: 20,
                    spreadRadius: -4,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: glowColor, size: 50),
                  const SizedBox(height: 14),
                  Text(
                    label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      color: glowColor,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(color: glowColor, blurRadius: 12),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
