package com.dorksystem.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.dorksystem.app.databinding.FragmentSearchBinding
import java.net.URLEncoder

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by activityViewModels()

    private var currentSite: DorkHelper.SiteOption = DorkHelper.ALL_SITES[0]
    private var currentEngine = "Google"

    private val engines = listOf("Google", "Bing", "DuckDuckGo", "Telegago (Telegram)")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupPlatformSpinner()
        setupEngineSpinner()
        setupWebView()
        setupButtons()
    }

    private fun setupPlatformSpinner() {
        val names = DorkHelper.getDisplayNames()
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names)
        binding.spinnerPlatform.setAdapter(adapter)
        binding.spinnerPlatform.setText(names[0], false)
        currentSite = DorkHelper.ALL_SITES[0]

        binding.spinnerPlatform.setOnItemClickListener { _, _, position, _ ->
            currentSite = DorkHelper.ALL_SITES[position]
            if (currentSite.domain == "__custom__") {
                binding.customDomainLayout.visibility = View.VISIBLE
            } else {
                binding.customDomainLayout.visibility = View.GONE
            }
        }
    }

    private fun setupEngineSpinner() {
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, engines)
        binding.spinnerEngine.setAdapter(adapter)
        binding.spinnerEngine.setText(engines[0], false)

        binding.spinnerEngine.setOnItemClickListener { _, _, position, _ ->
            currentEngine = engines[position]
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webSettings: WebSettings = binding.webview.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        webSettings.builtInZoomControls = true
        webSettings.displayZoomControls = false
        webSettings.setSupportZoom(true)
        webSettings.userAgentString = webSettings.userAgentString.replace("; wv", "")

        binding.webview.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return false
            }
        }
        binding.webview.webChromeClient = WebChromeClient()
    }

    private fun setupButtons() {
        binding.btnSearch.setOnClickListener { doSearch() }
        binding.btnExtract.setOnClickListener { extractLinks() }

        binding.etKeyword.setOnEditorActionListener { _, _, _ ->
            doSearch()
            true
        }
    }

    private fun buildSearchUrl(dork: String, engine: String): String {
        val encoded = URLEncoder.encode(dork, "UTF-8")
        return when (engine) {
            "Bing" -> "https://www.bing.com/search?q=$encoded&count=50"
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
            "Telegago (Telegram)" -> {
                // Telegago is a Google CSE focused on Telegram
                "https://cse.google.com/cse?cx=006368593537057042503:efxu7xprihg&q=$encoded"
            }
            else -> "https://www.google.com/search?q=$encoded&num=100&filter=0&hl=en"
        }
    }

    private fun doSearch() {
        val keyword = binding.etKeyword.text?.toString()?.trim() ?: ""
        if (keyword.isEmpty()) {
            Toast.makeText(requireContext(), "Sila masukkan keyword", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedName = binding.spinnerPlatform.text.toString()
        currentSite = DorkHelper.findByDisplayName(selectedName) ?: DorkHelper.ALL_SITES[0]
        currentEngine = binding.spinnerEngine.text.toString().ifBlank { "Google" }

        val customDomain = binding.etCustomDomain.text?.toString()?.trim() ?: ""
        if (currentSite.domain == "__custom__" && customDomain.isEmpty()) {
            Toast.makeText(requireContext(), "Sila masukkan domain custom", Toast.LENGTH_SHORT).show()
            return
        }

        // Untuk Telegago, force target Telegram supaya lebih relevant
        val dork = if (currentEngine.startsWith("Telegago")) {
            keyword
        } else {
            DorkHelper.buildDork(currentSite, keyword, customDomain)
        }

        if (dork.isEmpty()) return

        val url = buildSearchUrl(dork, currentEngine)

        viewModel.lastPlatform = "${currentSite.displayName} ($currentEngine)"
        viewModel.lastKeyword = keyword
        viewModel.addHistory(viewModel.lastPlatform, keyword)
        viewModel.clearLinks()

        binding.webview.stopLoading()
        binding.webview.loadUrl("about:blank")
        binding.webview.postDelayed({
            binding.webview.loadUrl(url)
        }, 180)

        Toast.makeText(
            requireContext(),
            "Loading $currentEngine… Solve CAPTCHA jika ada, kemudian Extract",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun extractLinks() {
        val customDomain = binding.etCustomDomain.text?.toString()?.trim() ?: ""
        val patterns = DorkHelper.getLinkPatterns(currentSite, customDomain)

        // Kalau Telegago atau Semua, guna pattern social
        val finalPatterns = if (currentEngine.startsWith("Telegago") || patterns.isEmpty()) {
            listOf("t.me/", "telegram.me/", "chat.whatsapp.com/", "wa.me/", "discord.gg/", "discord.com/invite/")
        } else {
            patterns
        }

        val js = """
            (function() {
                var links = [];
                var anchors = document.querySelectorAll('a[href]');
                var patterns = ${finalPatterns.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }};
                for (var i = 0; i < anchors.length; i++) {
                    var href = anchors[i].href;
                    if (!href) continue;
                    for (var j = 0; j < patterns.length; j++) {
                        if (href.indexOf(patterns[j]) !== -1) {
                            var clean = href.split('&')[0].split('?')[0];
                            if (links.indexOf(clean) === -1) {
                                links.push(clean);
                            }
                            break;
                        }
                    }
                }
                return JSON.stringify(links);
            })();
        """.trimIndent()

        binding.webview.evaluateJavascript(js) { result ->
            try {
                var clean = result ?: "[]"
                if (clean.startsWith("\"") && clean.endsWith("\"")) {
                    clean = clean.substring(1, clean.length - 1)
                        .replace("\\\"", "\"")
                        .replace("\\\\", "\\")
                }
                val arr = org.json.JSONArray(clean)
                val list = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    list.add(arr.getString(i))
                }
                viewModel.setLinks(list)
                Toast.makeText(requireContext(), "${list.size} link dijumpai", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.resultsFragment)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    requireContext(),
                    "Gagal extract. Pastikan page dah load siap / CAPTCHA dah solve.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
