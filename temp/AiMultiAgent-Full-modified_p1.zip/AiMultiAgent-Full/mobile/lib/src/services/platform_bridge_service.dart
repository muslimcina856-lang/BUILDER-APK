import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../config/app_config.dart';

class PlatformBridgeService {
  static const MethodChannel _channel = MethodChannel('com.aiauto.claw/device');

  /// Salin asset Flutter besar secara streaming terus daripada APK.
  ///
  /// Ini mengelakkan runtime Linux dimuatkan sepenuhnya ke heap Dart.
  Future<Map<String, dynamic>> copyBundledAsset({
    required String assetPath,
    required String destinationPath,
    required String expectedSha256,
    required int maxBytes,
  }) async {
    if (kIsWeb || !Platform.isAndroid) {
      throw const FileSystemException(
        'Runtime Linux bawaan hanya boleh disalin pada Android.',
      );
    }
    try {
      final result = await _channel.invokeMapMethod<String, dynamic>(
        'copyBundledAsset',
        <String, dynamic>{
          'assetPath': assetPath,
          'destinationPath': destinationPath,
          'expectedSha256': expectedSha256,
          'maxBytes': maxBytes,
        },
      );
      if (result == null) {
        throw const FileSystemException('Salinan runtime bawaan tidak lengkap.');
      }
      return Map<String, dynamic>.from(result);
    } on PlatformException catch (error) {
      throw FileSystemException(
        error.message ?? 'Gagal menyalin runtime bawaan APK.',
        destinationPath,
      );
    }
  }

  Future<Map<String, dynamic>> runtimeContext() async {
    if (kIsWeb || !Platform.isAndroid) return _fallbackContext();
    try {
      final raw = await _channel.invokeMapMethod<String, dynamic>('getRuntimeContext');
      if (raw == null) return _fallbackContext();
      return <String, dynamic>{
        ...Map<String, dynamic>.from(raw),
        'edition': AppConfig.editionName,
        'configuredTargetSdk': AppConfig.androidTargetSdk,
      };
    } on MissingPluginException {
      return _fallbackContext();
    } on PlatformException catch (error) {
      return <String, dynamic>{
        ..._fallbackContext(),
        'nativeError': error.message ?? error.code,
      };
    }
  }

  Future<void> startExecutionKeepAlive({
    Duration maxDuration = AppConfig.backgroundExecutionLimit,
  }) async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('startExecutionKeepAlive', <String, dynamic>{
        'maxDurationMs': maxDuration.inMilliseconds,
      });
    } on MissingPluginException {
      // Unit tests and unsupported platforms intentionally have no native bridge.
    } on PlatformException {
      // Sesetengah OEM menolak permulaan foreground service. Tugasan utama
      // masih boleh terus berjalan semasa proses aplikasi kekal hidup.
    }
  }

  Future<void> stopExecutionKeepAlive() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('stopExecutionKeepAlive');
    } on MissingPluginException {
      // Unit tests and unsupported platforms intentionally have no native bridge.
    } on PlatformException {
      // Servis mungkin telah dihentikan oleh sistem atau OEM.
    }
  }

  Future<void> openNotificationSettings() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('openNotificationSettings');
    } on MissingPluginException {
      // Tiada tetapan notifikasi native pada platform ini.
    } on PlatformException {
      // Sesetengah Android OEM tidak menyediakan halaman khusus aplikasi.
    }
  }

  Future<void> openAppSettings() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('openAppSettings');
    } on MissingPluginException {
      // Tiada halaman tetapan aplikasi native pada platform ini.
    } on PlatformException {
      // Sesetengah OEM menyekat intent tetapan aplikasi.
    }
  }


  /// true jika bateri app = Tiada sekatan / Unrestricted.
  Future<bool> isBatteryUnrestricted() async {
    if (kIsWeb || !Platform.isAndroid) return true;
    try {
      final value = await _channel.invokeMethod<bool>('isBatteryUnrestricted');
      return value ?? false;
    } on MissingPluginException {
      return true;
    } on PlatformException {
      return false;
    }
  }

  /// Buka page bateri app (dialog sistem / OEM) supaya user pilih "Tiada sekatan".
  Future<void> openBatteryOptimizationSettings() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('openBatteryOptimizationSettings');
    } on MissingPluginException {
      await openAppSettings();
    } on PlatformException {
      await openAppSettings();
    }
  }

  Map<String, dynamic> _fallbackContext() => <String, dynamic>{
        'platform': kIsWeb ? 'web' : Platform.operatingSystem,
        'edition': AppConfig.editionName,
        'packageName': AppConfig.packageName,
        'configuredTargetSdk': AppConfig.androidTargetSdk,
        'embeddedBrowserAvailable': !kIsWeb && Platform.isAndroid,
        'embeddedBrowserEngine': 'Android System WebView/Chromium',
        'browserDefaultMode': 'desktop-emulation',
        'remotePcAccess': false,
        'remotePcNote':
            'Tiada akses kepada PC jauh atau tab browser sedia ada kecuali pengguna menyambungkan tool MCP/companion yang berkenaan.',
      };
}
