package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BillerProduct
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.data.model.Administrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(entities = [User::class, Transaction::class, BillerProduct::class, Administrator::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun billerProductDao(): BillerProductDao
    abstract fun administratorDao(): AdministratorDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nusa_wallet_db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database)
                    }
                }
            }

            suspend fun populateDatabase(db: AppDatabase) {
                val userDao = db.userDao()
                val productDao = db.billerProductDao()
                val transactionDao = db.transactionDao()
                val adminDao = db.administratorDao()

                // Seed Default Administrator
                val defaultAdmin = Administrator(
                    adminId = "admin_1",
                    username = "admin",
                    fullName = "Administrator Utama",
                    email = "admin@nusawallet.com",
                    password = "admin123"
                )
                adminDao.insertAdmin(defaultAdmin)

                // Seed Default User (Budi Setiawan) with Rp 750.000 balance
                val defaultUser = User(
                    userId = "user_1",
                    fullName = "Budi Setiawan",
                    phoneNumber = "081234567890",
                    balance = 750000.0,
                    pin = "123456"
                )
                userDao.insertUser(defaultUser)

                // Seed historical Transactions to make it look ready and real!
                val historicalTransactions = listOf(
                    Transaction(
                        transactionId = UUID.randomUUID().toString(),
                        amount = 50000.0,
                        type = "TOPUP",
                        description = "Top Up via BCA Virtual Account",
                        paymentChannel = "BCA Virtual Account",
                        status = "SUCCESS",
                        timestamp = System.currentTimeMillis() - 86400000 * 2 // 2 days ago
                    ),
                    Transaction(
                        transactionId = UUID.randomUUID().toString(),
                        amount = 15000.0,
                        type = "PULSA",
                        description = "Pembelian Pulsa Telkomsel 10K ke 0812998877",
                        paymentChannel = "Wallet Balance",
                        status = "SUCCESS",
                        timestamp = System.currentTimeMillis() - 86400000 // 1 day ago
                    ),
                    Transaction(
                        transactionId = UUID.randomUUID().toString(),
                        amount = 120000.0,
                        type = "QRIS_PAY",
                        description = "Pembayaran di Kopi Kenangan",
                        merchantId = "MID-KOPIKEN-589",
                        merchantName = "Kopi Kenangan - Grand Indonesia",
                        paymentChannel = "QRIS (Wallet Balance)",
                        status = "SUCCESS",
                        timestamp = System.currentTimeMillis() - 3600000 * 4 // 4 hours ago
                    )
                )
                for (tx in historicalTransactions) {
                    transactionDao.insertTransaction(tx)
                }

                // Seed Pulsa & Paket Data Products
                val defaultProducts = listOf(
                    // Pulsa Products
                    BillerProduct("TSEL_P_10", "Telkomsel Pulsa Rp10.000", "Telkomsel", 11500.0, "PULSA", "Masa aktif 15 hari"),
                    BillerProduct("TSEL_P_50", "Telkomsel Pulsa Rp50.000", "Telkomsel", 51000.0, "PULSA", "Masa aktif 45 hari"),
                    BillerProduct("TSEL_P_100", "Telkomsel Pulsa Rp100.000", "Telkomsel", 99200.0, "PULSA", "Masa aktif 60 hari"),
                    
                    BillerProduct("IND_P_10", "Indosat Pulsa Rp10.000", "Indosat", 11000.0, "PULSA", "Masa aktif 15 hari"),
                    BillerProduct("IND_P_50", "Indosat Pulsa Rp50.000", "Indosat", 50500.0, "PULSA", "Masa aktif 45 hari"),
                    BillerProduct("IND_P_100", "Indosat Pulsa Rp100.000", "Indosat", 98500.0, "PULSA", "Masa aktif 60 hari"),

                    BillerProduct("XL_P_10", "XL Pulsa Rp10.000", "XL", 11200.0, "PULSA", "Masa aktif 20 hari"),
                    BillerProduct("XL_P_50", "XL Pulsa Rp50.000", "XL", 50800.0, "PULSA", "Masa aktif 45 hari"),
                    BillerProduct("XL_P_100", "XL Pulsa Rp100.000", "XL", 99000.0, "PULSA", "Masa aktif 60 hari"),

                    BillerProduct("TRI_P_5", "Tri Pulsa Rp5.000", "Tri", 6200.0, "PULSA", "Masa aktif 7 hari"),
                    BillerProduct("TRI_P_50", "Tri Pulsa Rp50.000", "Tri", 50200.0, "PULSA", "Masa aktif 45 hari"),

                    // Data Package Products
                    BillerProduct("TSEL_D_5", "Telkomsel OMG! 5GB", "Telkomsel", 35000.0, "DATA", "5GB Internet Utama + Chat 30 Hari"),
                    BillerProduct("TSEL_D_20", "Telkomsel Max 20GB", "Telkomsel", 85000.0, "DATA", "20GB Internet Utama + Film 30 Hari"),
                    
                    BillerProduct("IND_D_15", "Indosat Freedom 15GB", "Indosat", 52000.0, "DATA", "15GB kuota utama 24 Jam, 30 Hari"),
                    BillerProduct("IND_D_50", "Indosat Freedom Unlimited 50GB", "Indosat", 112000.0, "DATA", "Unlimited Apps + 50GB Utama, 30 Hari"),

                    BillerProduct("XL_D_10", "XL Xtra Combo Flex 10GB", "XL", 42000.0, "DATA", "10GB kuota utama + flex bonus, 30 Hari"),
                    BillerProduct("XL_D_40", "XL Xtra Combo Flex 40GB", "XL", 95000.0, "DATA", "40GB kuota utama + premium bonus, 30 Hari"),

                    BillerProduct("TRI_D_25", "Tri AlwaysOn 25GB", "Tri", 60000.0, "DATA", "25GB Kuota Aktif Selamanya mengikuti masa aktif kartu")
                )
                productDao.insertProducts(defaultProducts)
            }
        }
    }
}
