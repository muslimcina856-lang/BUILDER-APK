package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class User(
    @PrimaryKey val userId: String = "user_1",
    val fullName: String,
    val phoneNumber: String,
    val balance: Double,
    val pin: String = "123456", // Default PIN for secure transactions
    val avatarId: String = "avatar_1",
    val isNameChanged: Boolean = false
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey val transactionId: String = UUID.randomUUID().toString(),
    val userId: String = "user_1",
    val amount: Double,
    val type: String, // "PULSA", "DATA", "TOPUP", "QRIS_PAY", "QRIS_RECEIVE"
    val description: String,
    val merchantId: String? = null, // Track merchant ID for transactions
    val merchantName: String? = null, // Descriptive merchant name
    val paymentChannel: String, // VA Bank, Alfamart, Indomaret, QRIS, etc.
    val status: String, // "PENDING", "SUCCESS", "FAILED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "biller_products")
data class BillerProduct(
    @PrimaryKey val productId: String,
    val name: String,
    val provider: String, // "Telkomsel", "Indosat", "XL", "Tri", "Smartfren"
    val price: Double,
    val type: String, // "PULSA", "DATA"
    val description: String
)

@Entity(tableName = "administrators")
data class Administrator(
    @PrimaryKey val adminId: String,
    val username: String,
    val fullName: String,
    val email: String,
    val password: String,
    val role: String = "SUPER_ADMIN",
    val createdAt: Long = System.currentTimeMillis()
)

