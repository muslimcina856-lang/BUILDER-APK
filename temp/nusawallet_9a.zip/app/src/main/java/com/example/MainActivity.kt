package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.Transaction
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.QrisScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.AdminScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.TransactionState
import com.example.ui.viewmodel.WalletViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: WalletViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppLayout(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppLayout(viewModel: WalletViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()

    // Core States
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val txState by viewModel.transactionState.collectAsStateWithLifecycle()
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsStateWithLifecycle()
    val currentAdmin by viewModel.currentAdmin.collectAsStateWithLifecycle()

    // UI Overlays state
    var showPinDialog by remember { mutableStateOf(false) }
    var pinDialogTitle by remember { mutableStateOf("") }
    var pinDialogAmount by remember { mutableStateOf(0.0) }
    var pinConfirmCallback by remember { mutableStateOf<((String) -> Unit)?>(null) }

    var selectedTransactionForReceipt by remember { mutableStateOf<Transaction?>(null) }

    var showSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        showSplash = false
    }

    // Bottom Navigation current selection
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"

    // Listen to transaction outcomes
    LaunchedEffect(txState) {
        when (txState) {
            is TransactionState.Success -> {
                val tx = (txState as TransactionState.Success).transaction
                selectedTransactionForReceipt = tx
                viewModel.clearTransactionState()
                Toast.makeText(context, "Transaksi Berhasil!", Toast.LENGTH_SHORT).show()
            }
            is TransactionState.Error -> {
                val errMsg = (txState as TransactionState.Error).message
                Toast.makeText(context, "Error: $errMsg", Toast.LENGTH_LONG).show()
                viewModel.clearTransactionState()
            }
            else -> {}
        }
    }

    if (showSplash) {
        SplashScreen()
    } else if (currentAdmin != null) {
        AdminScreen(
            viewModel = viewModel,
            onLogout = {
                navController.navigate("home") {
                    popUpTo(0) { inclusive = true }
                }
            }
        )
    } else if (!isUserLoggedIn) {
        AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = {
                navController.navigate("home") {
                    popUpTo(0) { inclusive = true }
                }
            },
            onAdminSuccess = {
                navController.navigate("home") {
                    popUpTo(0) { inclusive = true }
                }
            }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "NusaWallet",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                fontSize = 20.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF002244), // Classic Fintech Deep Navy
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    // Home Tab
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = {
                            navController.navigate("home") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(imageVector = Icons.Outlined.Home, contentDescription = "Home") },
                        label = { Text("Dompet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF008CE6),
                            selectedTextColor = Color(0xFF008CE6),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFFEDF7FF)
                        )
                    )

                    // QRIS Tab
                    NavigationBarItem(
                        selected = currentRoute == "qris",
                        onClick = {
                            navController.navigate("qris") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(imageVector = Icons.Outlined.QrCodeScanner, contentDescription = "QRIS") },
                        label = { Text("Scanner QRIS", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF008CE6),
                            selectedTextColor = Color(0xFF008CE6),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFFEDF7FF)
                        )
                    )

                    // Analisis Tab
                    NavigationBarItem(
                        selected = currentRoute == "analytics",
                        onClick = {
                            navController.navigate("analytics") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(imageVector = Icons.Default.Analytics, contentDescription = "Analisis") },
                        label = { Text("Analisis", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF008CE6),
                            selectedTextColor = Color(0xFF008CE6),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFFEDF7FF)
                        )
                    )

                    // Profil Tab
                    NavigationBarItem(
                        selected = currentRoute == "architecture",
                        onClick = {
                            navController.navigate("architecture") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Profil") },
                        label = { Text("Profil", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF008CE6),
                            selectedTextColor = Color(0xFF008CE6),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFFEDF7FF)
                        )
                    )
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(innerPadding)
            ) {
                composable("home") {
                    HomeScreen(
                        viewModel = viewModel,
                        user = currentUser,
                        transactions = transactions,
                        onNavigateToQrisTab = { tabIndex ->
                            navController.navigate("qris") {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        onRequirePin = { title, amount, onConfirm ->
                            pinDialogTitle = title
                            pinDialogAmount = amount
                            pinConfirmCallback = onConfirm
                            showPinDialog = true
                        },
                        onShowReceipt = { selectedTransactionForReceipt = it }
                    )
                }

                composable("qris") {
                    QrisScreen(
                        viewModel = viewModel,
                        onRequirePin = { title, amount, onConfirm ->
                            pinDialogTitle = title
                            pinDialogAmount = amount
                            pinConfirmCallback = onConfirm
                            showPinDialog = true
                        }
                    )
                }

                composable("analytics") {
                    AnalyticsScreen(viewModel = viewModel)
                }

                composable("architecture") {
                    ProfileScreen(
                        viewModel = viewModel,
                        onLogout = {
                            navController.navigate("home") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }

    // Processing / Loading Overlay Dialog
    if (txState is TransactionState.Loading) {
        Dialog(onDismissRequest = {}) {
            Card(
                modifier = Modifier
                    .width(180.dp)
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = Color(0xFF008CE6))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Memproses...",
                        color = Color.DarkGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    // Security PIN dialog modal
    if (showPinDialog) {
        PinAuthDialog(
            title = pinDialogTitle,
            amount = pinDialogAmount,
            onDismiss = { showPinDialog = false },
            onConfirm = { pinCode ->
                showPinDialog = false
                pinConfirmCallback?.invoke(pinCode)
            }
        )
    }

    // Receipt Invoice Modal Overlay
    selectedTransactionForReceipt?.let { tx ->
        TransactionReceiptDialog(
            transaction = tx,
            onDismiss = { selectedTransactionForReceipt = null }
        )
    }
}

/**
 * Authentication PIN Prompt (Simulating lock mechanism)
 */
@Composable
fun PinAuthDialog(
    title: String,
    amount: Double,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var pinText by remember { mutableStateOf("") }
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Konfirmasi Transaksi",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    color = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = idrFormat.format(amount),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF008CE6)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Masukkan 6-Digit PIN NusaWallet Anda:",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Standard filled text field disguised for PIN input
                OutlinedTextField(
                    value = pinText,
                    onValueChange = { if (it.length <= 6) pinText = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    placeholder = { Text("******", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                    modifier = Modifier.width(180.dp),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Simulasi PIN Default: 123456",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD32F2F)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(pinText) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                enabled = pinText.length == 6
            ) {
                Text("Bayar Lah", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

/**
 * Detailed invoice receipt popup modal
 */
@Composable
fun TransactionReceiptDialog(
    transaction: Transaction,
    onDismiss: () -> Unit
) {
    val df = remember { SimpleDateFormat("dd MMMM yyyy, HH:mm:ss", Locale("in", "ID")) }
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            if (transaction.status == "SUCCESS") Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                            shape = androidx.compose.foundation.shape.CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (transaction.status == "SUCCESS") Icons.Default.CheckCircle else Icons.Default.Cancel,
                        contentDescription = null,
                        tint = if (transaction.status == "SUCCESS") Color(0xFF2E7D32) else Color(0xFFD32F2F),
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (transaction.status == "SUCCESS") "Transaksi Sukses" else "Transaksi Gagal",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = if (transaction.status == "SUCCESS") Color(0xFF2E7D32) else Color(0xFFD32F2F)
                )
                Text(
                    text = transaction.description,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Divider()
                Spacer(modifier = Modifier.height(10.dp))

                ReceiptRow("Status Pembayaran", transaction.status) {
                    Box(
                        modifier = Modifier
                            .background(
                                if (transaction.status == "SUCCESS") Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = transaction.status,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (transaction.status == "SUCCESS") Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }
                }

                ReceiptRow("Metode Bayar", transaction.paymentChannel)
                ReceiptRow("Waktu Transaksi", df.format(Date(transaction.timestamp)))
                
                transaction.merchantId?.let {
                    ReceiptRow("ID Merchant", it)
                    ReceiptRow("Nama Merchant", transaction.merchantName ?: "")
                }

                ReceiptRow("No. Invoice/ID", transaction.transactionId.take(16).uppercase()) {
                    Text(
                        text = transaction.transactionId.take(12).uppercase(),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.DarkGray
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider()
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Total Nominal", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Text(
                        text = idrFormat.format(transaction.amount),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF0F3261)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Selesai & Tutup", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun ReceiptRow(label: String, value: String, customValueElement: @Composable (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = Color.Gray)
        if (customValueElement != null) {
            customValueElement()
        } else {
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF002244), Color(0xFF004488))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // High-fidelity rounded logo container
            Card(
                modifier = Modifier
                    .size(140.dp)
                    .border(2.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                shape = CircleShape,
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.img_nusawallet_logo),
                        contentDescription = "NusaWallet Logo",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "NusaWallet",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Dompet Digital Indonesia",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.7f),
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            CircularProgressIndicator(
                color = Color(0xFF008CE6),
                strokeWidth = 3.dp,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}
