package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BillerProduct
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.data.repository.WalletRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class WalletViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = WalletRepository(
        database.userDao(),
        database.transactionDao(),
        database.billerProductDao(),
        database.administratorDao()
    )

    // UI States
    val currentUser: StateFlow<User?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProducts: StateFlow<List<BillerProduct>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin & Auth Flows
    val allUsers: StateFlow<List<User>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdministrators: StateFlow<List<com.example.data.model.Administrator>> = repository.allAdministrators
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentAdmin = MutableStateFlow<com.example.data.model.Administrator?>(null)
    val currentAdmin: StateFlow<com.example.data.model.Administrator?> = _currentAdmin.asStateFlow()

    private val _isUserLoggedIn = MutableStateFlow(true) // Start as true for instant access/test compatibility, can be switched!
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    // Filtering States
    private val _phoneNumber = MutableStateFlow("")
    val phoneNumber: StateFlow<String> = _phoneNumber.asStateFlow()

    private val _selectedProvider = MutableStateFlow("Telkomsel")
    val selectedProvider: StateFlow<String> = _selectedProvider.asStateFlow()

    private val _selectedProductType = MutableStateFlow("PULSA") // "PULSA" or "DATA"
    val selectedProductType: StateFlow<String> = _selectedProductType.asStateFlow()

    // Screen interaction flows
    private val _transactionState = MutableStateFlow<TransactionState>(TransactionState.Idle)
    val transactionState: StateFlow<TransactionState> = _transactionState.asStateFlow()

    // Filtered products for UI
    val filteredProducts: StateFlow<List<BillerProduct>> = combine(
        allProducts,
        _selectedProvider,
        _selectedProductType
    ) { products, provider, type ->
        products.filter { it.provider.lowercase() == provider.lowercase() && it.type == type }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updatePhoneNumber(num: String) {
        _phoneNumber.value = num
        // Auto detect Indonesian operator
        detectProvider(num)
    }

    fun setProductType(type: String) {
        _selectedProductType.value = type
    }

    fun setProvider(provider: String) {
        _selectedProvider.value = provider
    }

    fun clearTransactionState() {
        _transactionState.value = TransactionState.Idle
    }

    private fun detectProvider(phone: String) {
        if (phone.length >= 4) {
            val prefix = phone.substring(0, 4)
            when (prefix) {
                "0811", "0812", "0813", "0821", "0822", "0852", "0853" -> _selectedProvider.value = "Telkomsel"
                "0814", "0815", "0816", "0855", "0856", "0857", "0858" -> _selectedProvider.value = "Indosat"
                "0817", "0818", "0819", "0859", "0877", "0878" -> _selectedProvider.value = "XL"
                "0895", "0896", "0897", "0898", "0899" -> _selectedProvider.value = "Tri"
            }
        }
    }

    /**
     * Submit Top Up
     */
    fun performTopUp(amount: Double, channel: String) {
        viewModelScope.launch {
            _transactionState.value = TransactionState.Loading
            val result = repository.topUpWallet(amount, channel)
            result.onSuccess { tx ->
                _transactionState.value = TransactionState.Success(tx)
            }.onFailure { err ->
                _transactionState.value = TransactionState.Error(err.message ?: "Top Up Gagal")
            }
        }
    }

    /**
     * Buy Pulsa or Data Package
     */
    fun performPurchase(product: BillerProduct, phone: String, pin: String) {
        viewModelScope.launch {
            _transactionState.value = TransactionState.Loading
            val result = repository.buyPulsa(product, phone, pin)
            result.onSuccess { tx ->
                _transactionState.value = TransactionState.Success(tx)
            }.onFailure { err ->
                _transactionState.value = TransactionState.Error(err.message ?: "Transaksi Gagal")
            }
        }
    }

    /**
     * Pay via QRIS Scanner
     */
    fun performQRISPayment(amount: Double, merchantId: String, merchantName: String, pin: String) {
        viewModelScope.launch {
            _transactionState.value = TransactionState.Loading
            val result = repository.payWithQRIS(amount, merchantId, merchantName, pin)
            result.onSuccess { tx ->
                _transactionState.value = TransactionState.Success(tx)
            }.onFailure { err ->
                _transactionState.value = TransactionState.Error(err.message ?: "QRIS Gagal")
            }
        }
    }

    /**
     * Receive QRIS - simulate receiving fund instantly
     */
    fun simulateQRISReceive(amount: Double, sender: String) {
        viewModelScope.launch {
            _transactionState.value = TransactionState.Loading
            delay(1000)
            val result = repository.receiveWithQRIS(amount, sender)
            result.onSuccess { tx ->
                _transactionState.value = TransactionState.Success(tx)
            }.onFailure { err ->
                _transactionState.value = TransactionState.Error(err.message ?: "Gagal menerima QRIS")
            }
        }
    }

    fun updateProfileAvatar(avatarId: String) {
        viewModelScope.launch {
            val user = repository.getSuspendedUser()
            if (user != null) {
                repository.updateUser(user.copy(avatarId = avatarId))
            }
        }
    }

    fun updateProfileName(newFullName: String) {
        viewModelScope.launch {
            val user = repository.getSuspendedUser()
            if (user != null && !user.isNameChanged) {
                repository.updateUser(user.copy(fullName = newFullName, isNameChanged = true))
            }
        }
    }

    // Authentication Functions
    fun clearAuthState() {
        _authState.value = AuthState.Idle
    }

    fun registerUser(fullName: String, phoneNumber: String, pin: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            repository.registerUser(fullName, phoneNumber, pin)
                .onSuccess { user ->
                    repository.setActiveUserId(user.userId)
                    _isUserLoggedIn.value = true
                    _currentAdmin.value = null
                    _authState.value = AuthState.SuccessUser(user)
                }
                .onFailure { err ->
                    _authState.value = AuthState.Error(err.message ?: "Registrasi gagal")
                }
        }
    }

    fun loginUser(phoneNumber: String, pin: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            if (phoneNumber == "6287752910121" && pin == "200828") {
                val admin = com.example.data.model.Administrator(
                    adminId = "admin_1",
                    username = "admin",
                    fullName = "Administrator Utama",
                    email = "admin@nusawallet.com",
                    password = "admin123"
                )
                _currentAdmin.value = admin
                _isUserLoggedIn.value = false
                _authState.value = AuthState.SuccessAdmin(admin)
                return@launch
            }
            repository.loginUser(phoneNumber, pin)
                .onSuccess { user ->
                    repository.setActiveUserId(user.userId)
                    _isUserLoggedIn.value = true
                    _currentAdmin.value = null
                    _authState.value = AuthState.SuccessUser(user)
                }
                .onFailure { err ->
                    _authState.value = AuthState.Error(err.message ?: "Login gagal")
                }
        }
    }

    fun registerAdmin(username: String, fullName: String, email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            repository.registerAdmin(username, fullName, email, password)
                .onSuccess { admin ->
                    _authState.value = AuthState.SuccessAdmin(admin)
                }
                .onFailure { err ->
                    _authState.value = AuthState.Error(err.message ?: "Registrasi admin gagal")
                }
        }
    }

    fun loginAdmin(username: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            repository.loginAdmin(username, password)
                .onSuccess { admin ->
                    _currentAdmin.value = admin
                    _isUserLoggedIn.value = false // Admin is not logged in as standard user
                    _authState.value = AuthState.SuccessAdmin(admin)
                }
                .onFailure { err ->
                    _authState.value = AuthState.Error(err.message ?: "Login admin gagal")
                }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _currentAdmin.value = null
            _isUserLoggedIn.value = false
            repository.setActiveUserId("unauthorized_session")
            _authState.value = AuthState.Idle
        }
    }
}

sealed class TransactionState {
    object Idle : TransactionState()
    object Loading : TransactionState()
    data class Success(val transaction: Transaction) : TransactionState()
    data class Error(val message: String) : TransactionState()
}

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class SuccessUser(val user: User) : AuthState()
    data class SuccessAdmin(val admin: com.example.data.model.Administrator) : AuthState()
    data class Error(val message: String) : AuthState()
}
