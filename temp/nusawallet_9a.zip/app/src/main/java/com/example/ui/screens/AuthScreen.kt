package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.res.painterResource
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.WalletViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: WalletViewModel,
    onAuthSuccess: () -> Unit,
    onAdminSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val authState by viewModel.authState.collectAsState()

    // Screen state: "LOGIN" or "REGISTER" or "ADMIN"
    var activeTab by remember { mutableStateOf("LOGIN") }

    // User Login States
    var loginPhone by remember { mutableStateOf("") }
    var loginPin by remember { mutableStateOf("") }
    var loginPinVisible by remember { mutableStateOf(false) }

    // User Register States
    var regName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regPin by remember { mutableStateOf("") }
    var regConfirmPin by remember { mutableStateOf("") }
    var regPinVisible by remember { mutableStateOf(false) }

    // Admin Login States
    var adminUsername by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var adminPasswordVisible by remember { mutableStateOf(false) }

    // Track state outcomes
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.SuccessUser -> {
                Toast.makeText(context, "Selamat datang kembali, ${(authState as AuthState.SuccessUser).user.fullName}!", Toast.LENGTH_SHORT).show()
                viewModel.clearAuthState()
                onAuthSuccess()
            }
            is AuthState.SuccessAdmin -> {
                Toast.makeText(context, "Admin login sukses! Selamat datang ${(authState as AuthState.SuccessAdmin).admin.fullName}!", Toast.LENGTH_SHORT).show()
                viewModel.clearAuthState()
                onAdminSuccess()
            }
            is AuthState.Error -> {
                Toast.makeText(context, (authState as AuthState.Error).message, Toast.LENGTH_LONG).show()
                viewModel.clearAuthState()
            }
            else -> {}
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
    ) {
        // Decorative background top arc
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.35f)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF002244), Color(0xFF004488))
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(30.dp))

            // Brand Header Logo - Premium Image Logo from painterResource
            Card(
                modifier = Modifier
                    .size(100.dp)
                    .border(2.dp, Color.White, CircleShape),
                shape = CircleShape,
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.img_nusawallet_logo),
                        contentDescription = "NusaWallet Logo",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "NusaWallet",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 1.sp
            )

            Text(
                text = "Solusi Pembayaran & Dompet Elektronik Anda",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Main Credentials Card container
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Custom tab selector for standard user / admin / register
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF0F2F5), RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val tabs = listOf(
                            "LOGIN" to "Masuk",
                            "REGISTER" to "Daftar"
                        )

                        tabs.forEach { (tabId, label) ->
                            val isSelected = activeTab == tabId
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFF008CE6) else Color.Transparent)
                                    .clickable { activeTab = tabId }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    AnimatedContent(
                        targetState = activeTab,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "auth_tab"
                    ) { tab ->
                        when (tab) {
                            "LOGIN" -> {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "Selamat Datang Pengguna!",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F3261),
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )
                                    Text(
                                        text = "Masuk menggunakan nomor telepon dan PIN terdaftar Anda.",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(bottom = 20.dp)
                                    )

                                    OutlinedTextField(
                                        value = loginPhone,
                                        onValueChange = { loginPhone = it },
                                        label = { Text("Nomor Telepon") },
                                        placeholder = { Text("Contoh: 081234567890") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color.Gray)
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    OutlinedTextField(
                                        value = loginPin,
                                        onValueChange = { if (it.length <= 6) loginPin = it },
                                        label = { Text("6-Digit PIN Keamanan") },
                                        placeholder = { Text("******") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        visualTransformation = if (loginPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color.Gray)
                                        },
                                        trailingIcon = {
                                            IconButton(onClick = { loginPinVisible = !loginPinVisible }) {
                                                Icon(
                                                    imageVector = if (loginPinVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                    contentDescription = null,
                                                    tint = Color.Gray
                                                )
                                            }
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "User default: 081234567890 (PIN: 123456) | Admin: 6287752910121 (PIN: 200828)",
                                        fontSize = 10.sp,
                                        color = Color(0xFFC62828),
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Start
                                    )

                                    Spacer(modifier = Modifier.height(24.dp))

                                    Button(
                                        onClick = {
                                            if (loginPhone.isEmpty()) {
                                                Toast.makeText(context, "Nomor telepon wajib diisi!", Toast.LENGTH_SHORT).show()
                                            } else if (loginPin.length != 6) {
                                                Toast.makeText(context, "PIN harus 6 digit angka!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                viewModel.loginUser(loginPhone, loginPin)
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Masuk Sekarang", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }
                            "REGISTER" -> {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "Buat Rekening NusaWallet",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F3261),
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )
                                    Text(
                                        text = "Daftar sekarang untuk membuat akun NusaWallet baru secara instan.",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(bottom = 20.dp)
                                    )

                                    OutlinedTextField(
                                        value = regName,
                                        onValueChange = { regName = it },
                                        label = { Text("Nama Lengkap") },
                                        placeholder = { Text("Contoh: Andi Pratama") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color.Gray)
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    OutlinedTextField(
                                        value = regPhone,
                                        onValueChange = { regPhone = it },
                                        label = { Text("Nomor Telepon Baru") },
                                        placeholder = { Text("Contoh: 0852XXXXXXXX") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color.Gray)
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    OutlinedTextField(
                                        value = regPin,
                                        onValueChange = { if (it.length <= 6) regPin = it },
                                        label = { Text("Buat 6-Digit PIN") },
                                        placeholder = { Text("******") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        visualTransformation = if (regPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Next),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color.Gray)
                                        },
                                        trailingIcon = {
                                            IconButton(onClick = { regPinVisible = !regPinVisible }) {
                                                Icon(
                                                    imageVector = if (regPinVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                    contentDescription = null,
                                                    tint = Color.Gray
                                                )
                                            }
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    OutlinedTextField(
                                        value = regConfirmPin,
                                        onValueChange = { if (it.length <= 6) regConfirmPin = it },
                                        label = { Text("Konfirmasi 6-Digit PIN") },
                                        placeholder = { Text("******") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        visualTransformation = if (regPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.LockClock, contentDescription = null, tint = Color.Gray)
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(24.dp))

                                    Button(
                                        onClick = {
                                            if (regName.trim().isEmpty() || regPhone.trim().isEmpty() || regPin.isEmpty()) {
                                                Toast.makeText(context, "Harap lengkapi semua data!", Toast.LENGTH_SHORT).show()
                                            } else if (regPin.length != 6) {
                                                Toast.makeText(context, "PIN harus terdiri dari 6 digit angka!", Toast.LENGTH_SHORT).show()
                                            } else if (regPin != regConfirmPin) {
                                                Toast.makeText(context, "PIN konfirmasi tidak cocok!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                viewModel.registerUser(regName.trim(), regPhone.trim(), regPin)
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Daftar Sekarang", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Loading overlay
    if (authState is AuthState.Loading) {
        Dialog(onDismissRequest = {}) {
            Card(
                modifier = Modifier
                    .width(150.dp)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = Color(0xFF008CE6))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Memverifikasi...", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}
