package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Transaction
import com.example.ui.viewmodel.WalletViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AnalyticsScreen(
    viewModel: WalletViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val transactions by viewModel.transactions.collectAsState()
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    // Aggregate statistics
    val successTxCount = transactions.count { it.status == "SUCCESS" }
    val pendingTxCount = transactions.count { it.status == "PENDING" }
    val failedTxCount = transactions.count { it.status == "FAILED" }
    val totalCount = transactions.size

    val totalSpending = transactions
        .filter { it.status == "SUCCESS" && it.type in listOf("PULSA", "DATA", "QRIS_PAY") }
        .sumOf { it.amount }

    // Let's create category spending mapping
    val pulsaSpending = transactions
        .filter { it.status == "SUCCESS" && it.type == "PULSA" }
        .sumOf { it.amount }
    val dataSpending = transactions
        .filter { it.status == "SUCCESS" && it.type == "DATA" }
        .sumOf { it.amount }
    val qrisSpending = transactions
        .filter { it.status == "SUCCESS" && it.type == "QRIS_PAY" }
        .sumOf { it.amount }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Upper card: Summary
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF002244)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = null,
                        tint = Color(0xFF00E676),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Total Pengeluaran Sukses",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = idrFormat.format(totalSpending),
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Diambil dari total $totalCount histori transaksi terdaftar",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chart 1: Spending patterns (Pulsa vs Data vs QRIS Card layout)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        tint = Color(0xFF008CE6),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Komposisi Pengeluaran",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F3261)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Render dynamic Stacked Bar Chart representational progress
                val activeTotals = (pulsaSpending + dataSpending + qrisSpending).coerceAtLeast(1.0)
                val pulsaPct = (pulsaSpending / activeTotals).toFloat()
                val dataPct = (dataSpending / activeTotals).toFloat()
                val qrisPct = (qrisSpending / activeTotals).toFloat()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFEDEFFF))
                ) {
                    if (pulsaPct > 0f) {
                        Box(
                            modifier = Modifier
                                .weight(pulsaPct.coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFFFFB300))
                        )
                    }
                    if (dataPct > 0f) {
                        Box(
                            modifier = Modifier
                                .weight(dataPct.coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFF00E676))
                        )
                    }
                    if (qrisPct > 0f) {
                        Box(
                            modifier = Modifier
                                .weight(qrisPct.coerceAtLeast(0.01f))
                                .fillMaxHeight()
                                .background(Color(0xFF008CE6))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Legend
                CategoryIndicator(name = "Pulsa", amount = pulsaSpending, color = Color(0xFFFFB300), idrFormat = idrFormat)
                CategoryIndicator(name = "Paket Data", amount = dataSpending, color = Color(0xFF00E676), idrFormat = idrFormat)
                CategoryIndicator(name = "Merchant QRIS", amount = qrisSpending, color = Color(0xFF008CE6), idrFormat = idrFormat)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Chart 2: Transaction Status Ratio (PENDING, SUCCESS, FAILED)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PieChart,
                        contentDescription = null,
                        tint = Color(0xFF008CE6),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Status Distribusi Transaksi",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F3261)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Beautiful interactive Canvas Pie/Donut Chart rendering ratios
                Box(
                    modifier = Modifier.size(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 24.dp.toPx()
                        val successFloat = if (totalCount == 0) 1f else successTxCount.toFloat() / totalCount
                        val pendingFloat = if (totalCount == 0) 0f else pendingTxCount.toFloat() / totalCount
                        val failedFloat = if (totalCount == 0) 0f else failedTxCount.toFloat() / totalCount

                        val successAngle = successFloat * 360f
                        val pendingAngle = pendingFloat * 360f
                        val failedAngle = failedFloat * 360f

                        // Draw SUCCESS arc (Green)
                        drawArc(
                            color = Color(0xFF2E7D32),
                            startAngle = -90f,
                            sweepAngle = successAngle,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )

                        // Draw PENDING arc (Orange)
                        drawArc(
                            color = Color(0xFFEF6C00),
                            startAngle = -90f + successAngle,
                            sweepAngle = pendingAngle,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )

                        // Draw FAILED arc (Ked)
                        drawArc(
                            color = Color(0xFFC62828),
                            startAngle = -90f + successAngle + pendingAngle,
                            sweepAngle = failedAngle,
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    // Display aggregate transaction label inside donut hole
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$totalCount",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F3261)
                        )
                        Text(
                            text = "Transaksi",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Status Legends
                StatusRowItem(status = "SUCCESS", count = successTxCount, color = Color(0xFF2E7D32), total = totalCount)
                StatusRowItem(status = "PENDING", count = pendingTxCount, color = Color(0xFFEF6C00), total = totalCount)
                StatusRowItem(status = "FAILED", count = failedTxCount, color = Color(0xFFC62828), total = totalCount)
            }
        }
    }
}

@Composable
fun CategoryIndicator(
    name: String,
    amount: Double,
    color: Color,
    idrFormat: NumberFormat
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = name, fontSize = 13.sp, color = Color.DarkGray)
        }
        Text(
            text = idrFormat.format(amount),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
    }
}

@Composable
fun StatusRowItem(
    status: String,
    count: Int,
    color: Color,
    total: Int
) {
    val pct = if (total == 0) "0%" else "${(count.toFloat() / total * 100).toInt()}%"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = status,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$count Transaksi",
                fontSize = 12.sp,
                color = Color.DarkGray,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .background(color.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = pct,
                    color = color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}
