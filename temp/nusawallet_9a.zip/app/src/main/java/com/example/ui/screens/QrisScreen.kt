package com.example.ui.screens

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.TransactionState
import com.example.ui.viewmodel.WalletViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import java.io.File
import java.text.NumberFormat
import java.util.Locale
import kotlin.random.Random
import kotlinx.coroutines.delay

data class MockQrMerchant(
    val name: String,
    val merchantId: String,
    val presetAmount: Double,
    val isDynamic: Boolean,
    val category: String
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun QrisScreen(
    viewModel: WalletViewModel,
    onRequirePin: (title: String, amount: Double, onConfirm: (String) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val density = LocalDensity.current

    var qrisTabState by remember { mutableStateOf(0) } // 0: Scan (Bayar), 1: Tampilkan QR (Terima)

    // User details & balance
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val userBalance = currentUser?.balance ?: 0.0

    // Locale formatting IDR
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    // Camera permission handler using Accompanist
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)

    // Simulation states
    var isFlashOn by remember { mutableStateOf(false) }
    var useVirtualCameraFeed by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(false) }

    // Scanned Merchant results state
    var showConfirmationModal by remember { mutableStateOf(false) }
    var scannedMerchantName by remember { mutableStateOf("") }
    var scannedMerchantId by remember { mutableStateOf("") }
    var scannedAmount by remember { mutableStateOf(0.0) }
    var isDynamicQr by remember { mutableStateOf(false) }

    // Manual custom input inside modal (for static QR)
    var inputAmountStr by remember { mutableStateOf("") }

    // Infinite transitions for neon scanning line and background pulsating
    val infiniteTransition = rememberInfiniteTransition(label = "qris_laser")
    val laserOffsetFraction by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_fraction"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Simulating delay upon scanning sequence
    LaunchedEffect(isScanning) {
        if (isScanning) {
            delay(1400)
            isScanning = false
            showConfirmationModal = true
        }
    }

    // Mock QR Merchants for interactive simulator list
    val mockMerchants = remember {
        listOf(
            MockQrMerchant("Starbucks Coffee GI", "MID-SBUX-898", 58000.0, true, "☕ Coffee & Drinks"),
            MockQrMerchant("Warmindo Sederhana", "MID-WARMIN-129", 15000.0, true, "🍜 Nasi & Mie"),
            MockQrMerchant("Indomaret Point", "MID-INDOPT-420", 34500.0, true, "🏪 Minimarket"),
            MockQrMerchant("SPBU Pertamina Juanda", "MID-SPBU-501", 125000.0, true, "⛽ Pengisian BBM"),
            MockQrMerchant("Warung Bakso Pak Kumis", "MID-KUMIS-007", 0.0, false, "🍲 Bakso & Mie (Static QR)")
        )
    }

    // Gallery File image selector launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            scannedMerchantName = "QRis Lokal Galeri"
            scannedMerchantId = "MID-GAL-" + Random.nextInt(100, 999)
            // Decide dynamic or static
            val randomChoice = Random.nextBoolean()
            if (randomChoice) {
                scannedAmount = (Random.nextInt(1, 10) * 15000).toDouble()
                isDynamicQr = true
            } else {
                scannedAmount = 0.0
                isDynamicQr = false
                inputAmountStr = ""
            }
            isScanning = true
            Toast.makeText(context, "Membaca gambar QR...", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
    ) {
        // Tab Selector at the Top
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFFE5E9F0))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (qrisTabState == 0) Color(0xFF008CE6) else Color.Transparent)
                    .clickable { qrisTabState = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = if (qrisTabState == 0) Color.White else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Scan QRIS",
                        color = if (qrisTabState == 0) Color.White else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (qrisTabState == 1) Color(0xFF008CE6) else Color.Transparent)
                    .clickable { qrisTabState = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        tint = if (qrisTabState == 1) Color.White else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tampil QRIS",
                        color = if (qrisTabState == 1) Color.White else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        if (qrisTabState == 0) {
            // SCANNER TAB VIEW
            val hasCameraPermission = cameraPermissionState.status.isGranted

            if (hasCameraPermission || useVirtualCameraFeed) {
                // ACTIVE SCAN VIEW
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasCameraPermission && !useVirtualCameraFeed) {
                        // Live CameraX Feed
                        CameraXFeed(isFlashOn = isFlashOn)
                    } else {
                        // Simulated Digital Matrix scope fallback
                        VirtualScannerFeed(pulseScale = pulseScale)
                    }

                    // Cutout mask layout & corner brackets
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val widthPx = constraints.maxWidth.toFloat()
                        val heightPx = constraints.maxHeight.toFloat()

                        // Calculate essential layout metrics using density cleanly outside Canvas
                        val reticlePx = with(density) { 250.dp.toPx() }
                        val strokeWidthPx = with(density) { 3.dp.toPx() }
                        val cornerLengthPx = with(density) { 24.dp.toPx() }
                        val laserPaddingPx = with(density) { 8.dp.toPx() }
                        val laserStrokeWidthPx = with(density) { 2.5f.dp.toPx() }

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val left = (widthPx - reticlePx) / 2
                            val top = (heightPx - reticlePx) / 2

                            // Draw dark transparent masks
                            // Top mask
                            drawRect(
                                color = Color.Black.copy(alpha = 0.65f),
                                topLeft = Offset(0f, 0f),
                                size = Size(widthPx, top)
                            )
                            // Bottom mask
                            drawRect(
                                color = Color.Black.copy(alpha = 0.65f),
                                topLeft = Offset(0f, top + reticlePx),
                                size = Size(widthPx, heightPx - (top + reticlePx))
                            )
                            // Left mask
                            drawRect(
                                color = Color.Black.copy(alpha = 0.65f),
                                topLeft = Offset(0f, top),
                                size = Size(left, reticlePx)
                            )
                            // Right mask
                            drawRect(
                                color = Color.Black.copy(alpha = 0.65f),
                                topLeft = Offset(left + reticlePx, top),
                                size = Size(widthPx - (left + reticlePx), reticlePx)
                            )

                            // Draw glowing green bounds
                            val neonGreen = Color(0xFF00FF88)

                            // Top Left Corner Bracket
                            drawLine(color = neonGreen, start = Offset(left, top), end = Offset(left + cornerLengthPx, top), strokeWidth = strokeWidthPx)
                            drawLine(color = neonGreen, start = Offset(left, top), end = Offset(left, top + cornerLengthPx), strokeWidth = strokeWidthPx)

                            // Top Right Corner Bracket
                            drawLine(color = neonGreen, start = Offset(left + reticlePx, top), end = Offset(left + reticlePx - cornerLengthPx, top), strokeWidth = strokeWidthPx)
                            drawLine(color = neonGreen, start = Offset(left + reticlePx, top), end = Offset(left + reticlePx, top + cornerLengthPx), strokeWidth = strokeWidthPx)

                            // Bottom Left Corner Bracket
                            drawLine(color = neonGreen, start = Offset(left, top + reticlePx), end = Offset(left + cornerLengthPx, top + reticlePx), strokeWidth = strokeWidthPx)
                            drawLine(color = neonGreen, start = Offset(left, top + reticlePx), end = Offset(left, top + reticlePx - cornerLengthPx), strokeWidth = strokeWidthPx)

                            // Bottom Right Corner Bracket
                            drawLine(color = neonGreen, start = Offset(left + reticlePx, top + reticlePx), end = Offset(left + reticlePx - cornerLengthPx, top + reticlePx), strokeWidth = strokeWidthPx)
                            drawLine(color = neonGreen, start = Offset(left + reticlePx, top + reticlePx), end = Offset(left + reticlePx, top + reticlePx - cornerLengthPx), strokeWidth = strokeWidthPx)

                            // Animated traversing neon red/cyan scanline
                            val laserY = top + (reticlePx * laserOffsetFraction)
                            drawLine(
                                color = Color(0xFFFF2D55),
                                start = Offset(left + laserPaddingPx, laserY),
                                end = Offset(left + reticlePx - laserPaddingPx, laserY),
                                strokeWidth = laserStrokeWidthPx
                            )
                        }

                        // Guidance header overlay
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .padding(top = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Arahkan kamera ke Kode QRIS",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Mendeteksi secara otomatis",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )
                        }

                        // Flash and Gallery buttons
                        Row(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset(y = 170.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { isFlashOn = !isFlashOn }) {
                                Icon(
                                    imageVector = if (isFlashOn) Icons.Outlined.FlashOn else Icons.Outlined.FlashOff,
                                    contentDescription = "Flashlight",
                                    tint = if (isFlashOn) Color(0xFFFFD600) else Color.White
                                )
                            }
                            IconButton(onClick = { galleryLauncher.launch("image/*") }) {
                                Icon(
                                    imageVector = Icons.Outlined.PhotoLibrary,
                                    contentDescription = "Pilih Galeri",
                                    tint = Color.White
                                )
                            }
                            if (hasCameraPermission) {
                                IconButton(onClick = { useVirtualCameraFeed = !useVirtualCameraFeed }) {
                                    Icon(
                                        imageVector = Icons.Default.SwapHoriz,
                                        contentDescription = "Ubah Sumber Kamera",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        // Lock animation overlay if scanning
                        if (isScanning) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.5f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color(0xFF00FF88))
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "Memecahkan Enkripsi QRIS...",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = scannedMerchantName,
                                        color = Color.LightGray,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // SIMULATOR CAROUSEL AT BOTTOM
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 0.dp, bottomEnd = 0.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Matriks Simulasi Pindai Cepat (Tap untuk Scan)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F3261),
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(mockMerchants) { merchant ->
                                Card(
                                    modifier = Modifier
                                        .width(170.dp)
                                        .clickable {
                                            focusManager.clearFocus()
                                            scannedMerchantName = merchant.name
                                            scannedMerchantId = merchant.merchantId
                                            scannedAmount = merchant.presetAmount
                                            isDynamicQr = merchant.isDynamic
                                            if (!merchant.isDynamic) {
                                                inputAmountStr = ""
                                            }
                                            isScanning = true
                                        },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEDF7FF)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = merchant.category,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF008CE6)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = merchant.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            color = Color(0xFF0F3261)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            if (merchant.isDynamic) {
                                                Text(
                                                    text = idrFormat.format(merchant.presetAmount),
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 12.sp,
                                                    color = Color(0xFF2E7D32)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(Color(0xFFE8F5E9))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text("DYN", fontSize = 7.sp, color = Color(0xFF1B5E20), fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Text(
                                                    text = "Bebas Nominal",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = Color.Gray
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(Color(0xFFECEFF1))
                                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                                ) {
                                                    Text("STC", fontSize = 7.sp, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // REQUEST CAMERA ACCESS UI
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .background(Color(0xFFFFECB3), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = Color(0xFFFF8F00),
                            modifier = Modifier.size(45.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "NusaWallet Butuh Akses Kamera",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F3261),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Kami memerlukan izin kamera Anda untuk memindai kode QRIS Merchant asli secara langsung di gerai.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    Button(
                        onClick = { cameraPermissionState.launchPermissionRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Izinkan Akses Kamera", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { useVirtualCameraFeed = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF008CE6))
                    ) {
                        Text("Gunakan Feed Simulator Virtual", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        } else {
            // TAMPIL QRIS (RECEIVE MONEY) - Original preserved features
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Terima Dana QRIS NusaWallet",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F3261),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tampilkan QRIS berlisensi ASPI untuk menerima dana instan.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    var receiveAmountStr by remember { mutableStateOf("25000") }
                    var senderName by remember { mutableStateOf("Budi Anto") }

                    OutlinedTextField(
                        value = receiveAmountStr,
                        onValueChange = { receiveAmountStr = it },
                        label = { Text("Nominal Terima Dana (Rp)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = senderName,
                        onValueChange = { senderName = it },
                        label = { Text("Nama Pengirim (Simulasi)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    val finalAmt = receiveAmountStr.toDoubleOrNull() ?: 0.0

                    // Dynamic QRIS canvas drawing
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .background(Color.White)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        QrisCodeDrawing(seedAmount = finalAmt)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // QRIS Brand Sign
                    Row(
                        modifier = Modifier
                            .width(220.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFE1F5FE))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "QRIS All Payment",
                            color = Color(0xFF0288D1),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (finalAmt > 0) {
                                focusManager.clearFocus()
                                viewModel.simulateQRISReceive(finalAmt, senderName)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = finalAmt > 0
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Transform,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Simulasikan Kirim ke QR ini", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // CONFIRMATION MODAL (PAYMENT breakdown receipt dialog)
    if (showConfirmationModal) {
        val finalAmountToPay = if (isDynamicQr) scannedAmount else (inputAmountStr.toDoubleOrNull() ?: 0.0)
        val isSufficient = userBalance >= finalAmountToPay
        val canSubmit = finalAmountToPay > 0 && isSufficient

        Dialog(onDismissRequest = { showConfirmationModal = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title Header with elegant alignment
                    Text(
                        text = "Konfirmasi Pembayaran",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF0F3261),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "QRIS All Payment Indonesia",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Sleek Digital Receipt Summary Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F8FC)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE3EFFC))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Merchant Logo Avatar
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(Color(0xFFE3F2FD), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Store,
                                    contentDescription = null,
                                    tint = Color(0xFF008CE6),
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Large Visual Summary of Merchant Name
                            Text(
                                text = scannedMerchantName,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color(0xFF0F3261),
                                textAlign = TextAlign.Center
                            )
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = "NMID: $scannedMerchantId",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Normal,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Verified Tag ASPI
                            Row(
                                modifier = Modifier
                                    .background(Color(0xFFE8F5E9), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Merchant Resmi QRIS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }

                            // Custom Premium Dashed/Dotted Line Divider
                            Spacer(modifier = Modifier.height(16.dp))
                            Divider(
                                color = Color(0xFFE0E0E0),
                                modifier = Modifier.fillMaxWidth().height(1.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            // Big Display Summary of Total Amount to Pay
                            Text(
                                text = "TOTAL YANG DIBAYAR",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                letterSpacing = 1.sp
                            )
                            
                            Spacer(modifier = Modifier.height(6.dp))

                            // Render dynamic / static preview cleanly
                            Text(
                                text = idrFormat.format(finalAmountToPay),
                                fontWeight = FontWeight.Black,
                                fontSize = 30.sp,
                                color = Color(0xFF008CE6),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Static QRIS (Free Amount Input) Form - beautifully integrated
                    if (!isDynamicQr) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF9FAFC), RoundedCornerShape(14.dp))
                                .border(1.dp, Color(0xFFE4E8EF), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "Masukkan Nominal Pembayaran:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F3261),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            OutlinedTextField(
                                value = inputAmountStr,
                                onValueChange = { inputAmountStr = it },
                                prefix = { Text("Rp ", fontWeight = FontWeight.Bold, color = Color(0xFF0F3261)) },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("0", color = Color.Gray) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White,
                                    focusedBorderColor = Color(0xFF008CE6),
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Account Source & Balance Check Container
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF0F0F0))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color(0xFF0F3261),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "NusaWallet Saldo",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.DarkGray
                                )
                            }
                            Text(
                                text = idrFormat.format(userBalance),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0F3261)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Detail bill breakdown table in soft details
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Subtotal", fontSize = 12.sp, color = Color.Gray)
                            Text(text = idrFormat.format(finalAmountToPay), fontSize = 12.sp, color = Color.DarkGray, fontWeight = FontWeight.Medium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Biaya Admin (QRIS)", fontSize = 12.sp, color = Color.Gray)
                            Text(text = "Rp 0 (Gratis)", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Insufficient Balance Warning Banner
                    if (finalAmountToPay > 0 && !isSufficient) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFFEEBEE), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color(0xFFFF2D55),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Saldo tidak cukup untuk pembayaran ini",
                                color = Color(0xFFFF2D55),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    Divider(color = Color(0xFFF0F0F0))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Dialog actions with nice touch targets and proper accessibility tags
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showConfirmationModal = false },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Text("Batal", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Button(
                            onClick = {
                                showConfirmationModal = false
                                onRequirePin(
                                    "Bayar QRIS ke $scannedMerchantName",
                                    finalAmountToPay
                                ) { enteredPin ->
                                    viewModel.performQRISPayment(
                                        amount = finalAmountToPay,
                                        merchantId = scannedMerchantId,
                                        merchantName = scannedMerchantName,
                                        pin = enteredPin
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                            shape = RoundedCornerShape(14.dp),
                            enabled = canSubmit,
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                        ) {
                            Text("Bayar Sekarang", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CameraXFeed(
    isFlashOn: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
            val executor = ContextCompat.getMainExecutor(ctx)

            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    cameraProvider.unbindAll()
                    val camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview
                    )
                    // Toggle torch / flash
                    if (camera.cameraInfo.hasFlashUnit()) {
                        camera.cameraControl.enableTorch(isFlashOn)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, executor)

            previewView
        },
        update = { previewView ->
            try {
                val cameraProvider = cameraProviderFuture.get()
                // Update flashlight state cleanly if possible
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                // We let preview update normally. Torch is set during binding, 
                // but we rebind cleanly when torch changes to apply flash changes robustly.
            } catch (e: Exception) {
                // Ignore
            }
        },
        modifier = modifier.fillMaxSize()
    )

    // Handle flashlight toggle rebind
    LaunchedEffect(isFlashOn) {
        try {
            val cameraProvider = cameraProviderFuture.get()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            val preview = Preview.Builder().build()
            cameraProvider.unbindAll()
            val camera = cameraProvider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview
            )
            if (camera.cameraInfo.hasFlashUnit()) {
                camera.cameraControl.enableTorch(isFlashOn)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }
}

@Composable
fun VirtualScannerFeed(
    pulseScale: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0F3261), Color(0xFF021730)),
                    radius = 350f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Draw elegant radial sci-fi scopes representing simulated camera matrix
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            
            // Draw concentric orbits with dashed matrix design
            drawCircle(
                color = Color(0xFF00FF88).copy(alpha = 0.2f),
                radius = 120.dp.toPx() * pulseScale,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )

            drawCircle(
                color = Color(0xFF00FF88).copy(alpha = 0.1f),
                radius = 180.dp.toPx() * (2.0f - pulseScale),
                center = center,
                style = Stroke(width = 1.5f.dp.toPx())
            )

            drawCircle(
                color = Color(0xFF00FF88).copy(alpha = 0.05f),
                radius = 60.dp.toPx(),
                center = center
            )
            
            // Crosshairs
            drawLine(
                color = Color(0xFF00FF88).copy(alpha = 0.3f),
                start = Offset(center.x - 30.dp.toPx(), center.y),
                end = Offset(center.x + 30.dp.toPx(), center.y),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = Color(0xFF00FF88).copy(alpha = 0.3f),
                start = Offset(center.x, center.y - 30.dp.toPx()),
                end = Offset(center.x, center.y + 30.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.FilterCenterFocus,
                contentDescription = null,
                tint = Color(0xFF00FF88).copy(alpha = 0.7f),
                modifier = Modifier.size(60.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Feed Kamera Virtual Aktif",
                color = Color(0xFF00FF88),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                text = "Pilih merchant di bawah untuk mensimulasikan scan",
                color = Color.LightGray,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}

@Composable
fun QrisCodeDrawing(seedAmount: Double) {
    // Canvas rendering for a beautiful retro QR Code matrix with standard target squares
    Canvas(modifier = Modifier.fillMaxSize()) {
        val squareSize = size.width
        val blockCount = 19
        val blockSize = squareSize / blockCount

        // 1. Draw solid background
        drawRect(color = Color.White, size = size)

        // Find standard QR target locations (Top-Left, Top-Right, Bottom-Left)
        val targets = listOf(
            Offset(0f, 0f),
            Offset((blockCount - 5) * blockSize, 0f),
            Offset(0f, (blockCount - 5) * blockSize)
        )

        // 2. Draw standard QR Targets (Three corners)
        targets.forEach { target ->
            // Outer block
            drawRect(
                color = Color.Black,
                topLeft = target,
                size = Size(5 * blockSize, 5 * blockSize)
            )
            // Inner white
            drawRect(
                color = Color.White,
                topLeft = Offset(target.x + blockSize, target.y + blockSize),
                size = Size(3 * blockSize, 3 * blockSize)
            )
            // Inner black center
            drawRect(
                color = Color.Black,
                topLeft = Offset(target.x + 1.5f * blockSize, target.y + 1.5f * blockSize),
                size = Size(2 * blockSize, 2 * blockSize)
            )
        }

        // 3. Draw seed-based pseudo random QR pixels
        val rand = Random(seedAmount.toLong() + 1289)
        for (r in 0 until blockCount) {
            for (c in 0 until blockCount) {
                // Skip corners where the target codes are situated
                val isCornerTL = r < 5 && c < 5
                val isCornerTR = r < 5 && c >= blockCount - 5
                val isCornerBL = r >= blockCount - 5 && c < 5
                
                if (!isCornerTL && !isCornerTR && !isCornerBL) {
                    if (rand.nextBoolean()) {
                        drawRect(
                            color = Color.Black,
                            topLeft = Offset(c * blockSize, r * blockSize),
                            size = Size(blockSize, blockSize)
                        )
                    }
                }
            }
        }

        // 4. Center DANA-like cyan-blue micro indicator
        val centerStart = (blockCount / 2 - 1) * blockSize
        drawRect(
            color = Color(0xFF002244),
            topLeft = Offset(centerStart - 2, centerStart - 2),
            size = Size(3 * blockSize + 4, 3 * blockSize + 4)
        )
        drawRect(
            color = Color(0xFF008CE6),
            topLeft = Offset(centerStart, centerStart),
            size = Size(3 * blockSize, 3 * blockSize)
        )
        // Little white center block
        drawRect(
            color = Color.White,
            topLeft = Offset(centerStart + blockSize, centerStart + blockSize),
            size = Size(blockSize, blockSize)
        )
    }
}
