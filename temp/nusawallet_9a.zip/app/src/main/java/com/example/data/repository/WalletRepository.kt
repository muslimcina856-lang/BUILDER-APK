package com.example.data.repository

import com.example.data.local.BillerProductDao
import com.example.data.local.TransactionDao
import com.example.data.local.UserDao
import com.example.data.local.AdministratorDao
import com.example.data.model.BillerProduct
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.data.model.Administrator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.withContext
import java.util.UUID

class WalletRepository(
    private val userDao: UserDao,
    private val transactionDao: TransactionDao,
    private val billerProductDao: BillerProductDao,
    private val administratorDao: AdministratorDao
) {
    private val _activeUserId = MutableStateFlow<String>("user_1")

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentUser: Flow<User?> = _activeUserId.flatMapLatest { id ->
        userDao.getUserById(id)
    }

    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val allProducts: Flow<List<BillerProduct>> = billerProductDao.getAllProducts()
    val allAdministrators: Flow<List<Administrator>> = administratorDao.getAllAdministrators()
    val allUsers: Flow<List<User>> = userDao.getAllUsers()

    fun getActiveUserId(): String = _activeUserId.value

    fun setActiveUserId(id: String) {
        _activeUserId.value = id
    }

    // Standard User registration
    suspend fun registerUser(fullName: String, phoneNumber: String, pin: String): Result<User> = withContext(Dispatchers.IO) {
        val existingUser = userDao.getUserByPhone(phoneNumber)
        if (existingUser != null) {
            return@withContext Result.failure(Exception("Nomor telepon sudah terdaftar!"))
        }

        val newUser = User(
            userId = "user_" + UUID.randomUUID().toString().take(8),
            fullName = fullName,
            phoneNumber = phoneNumber,
            balance = 0.0, // No signup bonus balance
            pin = pin
        )
        userDao.insertUser(newUser)
        Result.success(newUser)
    }

    // Standard User Login
    suspend fun loginUser(phoneNumber: String, pin: String): Result<User> = withContext(Dispatchers.IO) {
        val user = userDao.getUserByPhone(phoneNumber) ?: return@withContext Result.failure(Exception("Nomor telepon tidak ditemukan!"))
        if (user.pin != pin) {
            return@withContext Result.failure(Exception("PIN yang Anda masukkan salah!"))
        }
        Result.success(user)
    }

    // Administrator registration
    suspend fun registerAdmin(username: String, fullName: String, email: String, password: String): Result<Administrator> = withContext(Dispatchers.IO) {
        val existingAdmin = administratorDao.getAdminByUsername(username)
        if (existingAdmin != null) {
            return@withContext Result.failure(Exception("Username administrator sudah digunakan!"))
        }

        val newAdmin = Administrator(
            adminId = "admin_" + UUID.randomUUID().toString().take(8),
            username = username,
            fullName = fullName,
            email = email,
            password = password
        )
        administratorDao.insertAdmin(newAdmin)
        Result.success(newAdmin)
    }

    // Administrator Login
    suspend fun loginAdmin(username: String, password: String): Result<Administrator> = withContext(Dispatchers.IO) {
        val admin = administratorDao.getAdminByUsername(username) ?: return@withContext Result.failure(Exception("Username administrator tidak ditemukan!"))
        if (admin.password != password) {
            return@withContext Result.failure(Exception("Password administrator salah!"))
        }
        Result.success(admin)
    }

    fun getProductsByType(type: String): Flow<List<BillerProduct>> {
        return billerProductDao.getProductsByType(type)
    }

    suspend fun getSuspendedUser(): User? = withContext(Dispatchers.IO) {
        userDao.getUserByIdSuspending(getActiveUserId())
    }

    /**
     * Top up process
     */
    suspend fun topUpWallet(amount: Double, paymentChannel: String): Result<Transaction> = withContext(Dispatchers.IO) {
        val user = userDao.getUserByIdSuspending(getActiveUserId()) ?: return@withContext Result.failure(Exception("User not found"))
        
        // 1. Create a PENDING transaction
        val txId = UUID.randomUUID().toString()
        val pendingTx = Transaction(
            transactionId = txId,
            userId = user.userId,
            amount = amount,
            type = "TOPUP",
            description = "Top Up via $paymentChannel",
            paymentChannel = paymentChannel,
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(pendingTx)

        // Simulate gateway network processing latency
        delay(1200)

        // 2. Complete transaction and update balance
        val updatedUser = user.copy(balance = user.balance + amount)
        userDao.updateUser(updatedUser)
        
        // 3. Mark transaction as SUCCESS
        transactionDao.updateTransactionStatus(txId, "SUCCESS")
        
        // Fetch and return final transaction
        val finalTx = transactionDao.getTransactionById(txId) ?: pendingTx.copy(status = "SUCCESS")
        Result.success(finalTx)
    }

    /**
     * Spend on pulsa / paket data
     */
    suspend fun buyPulsa(product: BillerProduct, phoneNumber: String, pin: String): Result<Transaction> = withContext(Dispatchers.IO) {
        val user = userDao.getUserByIdSuspending(getActiveUserId()) ?: return@withContext Result.failure(Exception("User not found"))
        
        // Pin Verification
        if (user.pin != pin) {
            return@withContext Result.failure(Exception("PIN yang Anda masukkan salah!"))
        }

        // Balance Check
        if (user.balance < product.price) {
            // Log a failed transaction
            val failedTx = Transaction(
                transactionId = UUID.randomUUID().toString(),
                userId = user.userId,
                amount = product.price,
                type = product.type,
                description = "Gagal: ${product.name} ke $phoneNumber (Saldo Tidak Cukup)",
                paymentChannel = "Wallet Balance",
                status = "FAILED",
                timestamp = System.currentTimeMillis()
            )
            transactionDao.insertTransaction(failedTx)
            return@withContext Result.failure(Exception("Saldo NusaWallet tidak cukup untuk transaksi ini!"))
        }

        // 1. Create PENDING transaction
        val txId = UUID.randomUUID().toString()
        val pendingTx = Transaction(
            transactionId = txId,
            userId = user.userId,
            amount = product.price,
            type = product.type,
            description = "Beli ${product.name} ke $phoneNumber",
            paymentChannel = "Wallet Balance",
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(pendingTx)

        // Simulate biller aggregator API call processing
        delay(1500)

        // 2. Complete transaction, decrease balance
        val updatedUser = user.copy(balance = user.balance - product.price)
        userDao.updateUser(updatedUser)

        // 3. Mark transaction as SUCCESS
        transactionDao.updateTransactionStatus(txId, "SUCCESS")

        val finalTx = transactionDao.getTransactionById(txId) ?: pendingTx.copy(status = "SUCCESS")
        Result.success(finalTx)
    }

    /**
     * Pay with QRIS
     */
    suspend fun payWithQRIS(amount: Double, merchantId: String, merchantName: String, pin: String): Result<Transaction> = withContext(Dispatchers.IO) {
        val user = userDao.getUserByIdSuspending(getActiveUserId()) ?: return@withContext Result.failure(Exception("User not found"))

        // PIN validation
        if (user.pin != pin) {
            return@withContext Result.failure(Exception("PIN yang Anda masukkan salah!"))
        }

        // Balance Validation
        if (user.balance < amount) {
            val failedTx = Transaction(
                transactionId = UUID.randomUUID().toString(),
                userId = user.userId,
                amount = amount,
                type = "QRIS_PAY",
                description = "Gagal: Pembayaran QRIS $merchantName (Saldo Tidak Cukup)",
                merchantId = merchantId,
                merchantName = merchantName,
                paymentChannel = "QRIS (Wallet Balance)",
                status = "FAILED",
                timestamp = System.currentTimeMillis()
            )
            transactionDao.insertTransaction(failedTx)
            return@withContext Result.failure(Exception("Saldo NusaWallet tidak cukup untuk pembayaran QRIS ini!"))
        }

        // 1. Create PENDING transaction
        val txId = UUID.randomUUID().toString()
        val pendingTx = Transaction(
            transactionId = txId,
            userId = user.userId,
            amount = amount,
            type = "QRIS_PAY",
            description = "Pembayaran QRIS ke $merchantName",
            merchantId = merchantId,
            merchantName = merchantName,
            paymentChannel = "QRIS (Wallet Balance)",
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(pendingTx)

        // Simulate payment authorization
        delay(1300)

        // 2. Update balance
        val updatedUser = user.copy(balance = user.balance - amount)
        userDao.updateUser(updatedUser)

        // 3. Mark transaction as SUCCESS
        transactionDao.updateTransactionStatus(txId, "SUCCESS")

        val finalTx = transactionDao.getTransactionById(txId) ?: pendingTx.copy(status = "SUCCESS")
        Result.success(finalTx)
    }

    /**
     * Show QRIS scan back -> receive money representation
     */
    suspend fun receiveWithQRIS(amount: Double, senderName: String): Result<Transaction> = withContext(Dispatchers.IO) {
        val user = userDao.getUserByIdSuspending(getActiveUserId()) ?: return@withContext Result.failure(Exception("User not found"))

        val txId = UUID.randomUUID().toString()
        val tx = Transaction(
            transactionId = txId,
            userId = user.userId,
            amount = amount,
            type = "QRIS_RECEIVE",
            description = "Terima Dana QRIS dari $senderName",
            paymentChannel = "QRIS (NusaWallet QR)",
            status = "SUCCESS", // Directly success as it is funded externally
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(tx)

        // Update balance immediately
        val updatedUser = user.copy(balance = user.balance + amount)
        userDao.updateUser(updatedUser)

        Result.success(tx)
    }

    /**
     * Direct update for setup/testing
     */
    suspend fun updateUser(user: User) = withContext(Dispatchers.IO) {
        userDao.updateUser(user)
    }
}
