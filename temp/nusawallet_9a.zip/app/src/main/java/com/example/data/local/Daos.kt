package com.example.data.local

import androidx.room.*
import com.example.data.model.BillerProduct
import com.example.data.model.Transaction
import com.example.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE userId = :userId")
    fun getUserById(userId: String): Flow<User?>

    @Query("SELECT * FROM users WHERE userId = :userId")
    suspend fun getUserByIdSuspending(userId: String): User?

    @Query("SELECT * FROM users WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getUserByPhone(phoneNumber: String): User?

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE transactionId = :transactionId")
    suspend fun getTransactionById(transactionId: String): Transaction?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction)

    @Query("UPDATE transactions SET status = :status WHERE transactionId = :transactionId")
    suspend fun updateTransactionStatus(transactionId: String, status: String)
}

@Dao
interface BillerProductDao {
    @Query("SELECT * FROM biller_products")
    fun getAllProducts(): Flow<List<BillerProduct>>

    @Query("SELECT * FROM biller_products WHERE type = :type")
    fun getProductsByType(type: String): Flow<List<BillerProduct>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<BillerProduct>)
}

@Dao
interface AdministratorDao {
    @Query("SELECT * FROM administrators ORDER BY createdAt DESC")
    fun getAllAdministrators(): Flow<List<com.example.data.model.Administrator>>

    @Query("SELECT * FROM administrators WHERE username = :username LIMIT 1")
    suspend fun getAdminByUsername(username: String): com.example.data.model.Administrator?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(administrator: com.example.data.model.Administrator)

    @Delete
    suspend fun deleteAdmin(administrator: com.example.data.model.Administrator)
}

