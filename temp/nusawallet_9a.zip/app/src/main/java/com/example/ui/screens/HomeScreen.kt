package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import com.example.data.model.BillerProduct
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.ui.viewmodel.TransactionState
import com.example.ui.viewmodel.WalletViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    viewModel: WalletViewModel,
    user: User?,
    transactions: List<Transaction>,
    onNavigateToQrisTab: (tabIndex: Int) -> Unit,
    onRequirePin: (title: String, amount: Double, onConfirm: (String) -> Unit) -> Unit,
    onShowReceipt: (Transaction) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }

    // Navigation and Focus helpers
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val billerFocusRequester = remember { FocusRequester() }

    // Pulsa UI States
    val enteredPhone by viewModel.phoneNumber.collectAsState()
    val selectedProvider by viewModel.selectedProvider.collectAsState()
    val productType by viewModel.selectedProductType.collectAsState()
    val products by viewModel.filteredProducts.collectAsState()

    // Top Up State
    var showTopUpDialog by remember { mutableStateOf(false) }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
    ) {
        // 1. Digital Wallet Top Blue Banner (resembling DANA design)
        item {
            EWalletHeaderSection(
                user = user,
                idrFormat = idrFormat,
                onTopUpClick = { showTopUpDialog = true },
                onNavigateToQrisTab = onNavigateToQrisTab
            )
        }

        // Top Up & Pulsa/Data Quick Selection Navigation Card
        item {
            TopUpQuickNavSection(
                onTopUpClick = { showTopUpDialog = true },
                onPulsaClick = {
                    viewModel.setProductType("PULSA")
                    coroutineScope.launch {
                        // Scroll to index 2 (TopUpQuickNavSection is 1, BillerPortalSection is 2)
                        listState.animateScrollToItem(2)
                        billerFocusRequester.requestFocus()
                    }
                },
                onDataClick = {
                    viewModel.setProductType("DATA")
                    coroutineScope.launch {
                        listState.animateScrollToItem(2)
                        billerFocusRequester.requestFocus()
                    }
                }
            )
        }

        // 2. Buy Pulsa & Paket Data (Biller Portal)
        item {
            BillerPortalSection(
                enteredPhone = enteredPhone,
                onPhoneChanged = { viewModel.updatePhoneNumber(it) },
                selectedProvider = selectedProvider,
                onProviderSelected = { viewModel.setProvider(it) },
                productType = productType,
                onProductTypeSelected = { viewModel.setProductType(it) },
                products = products,
                idrFormat = idrFormat,
                focusRequester = billerFocusRequester,
                onProductClick = { product ->
                    focusManager.clearFocus()
                    if (enteredPhone.length < 10) {
                        // Skip if phone too short
                        return@BillerPortalSection
                    }
                    onRequirePin(
                        "Beli ${product.name} ke $enteredPhone",
                        product.price
                    ) { pin ->
                        viewModel.performPurchase(product, enteredPhone, pin)
                    }
                }
            )
        }

        // 3. Transactions History Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Riwayat Transaksi",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F3261)
                )
                Text(
                    text = "Lihat Semua",
                    fontSize = 13.sp,
                    color = Color(0xFF008CE6),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { /* future detail filtering */ }
                )
            }
        }

        if (transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inbox,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Belum ada riwayat transaksi", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(transactions) { tx ->
                TransactionListItem(
                    transaction = tx,
                    idrFormat = idrFormat,
                    onClick = { onShowReceipt(tx) }
                )
            }
        }

        // Bottom space so dynamic navigation doesn't cut list items
        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Top Up Dialog
    if (showTopUpDialog) {
        TopUpDialog(
            idrFormat = idrFormat,
            onDismiss = { showTopUpDialog = false },
            onConfirmTopUp = { amount, channel ->
                viewModel.performTopUp(amount, channel)
                showTopUpDialog = false
            }
        )
    }
}

@Composable
fun EWalletHeaderSection(
    user: User?,
    idrFormat: NumberFormat,
    onTopUpClick: () -> Unit,
    onNavigateToQrisTab: (Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF002244)) // Dark navy top
            .padding(bottom = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        ) {
            // Profile top row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val avatarId = user?.avatarId ?: "avatar_1"
                    val isCustomImage = !avatarId.startsWith("avatar_")

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCustomImage) {
                            val file = java.io.File(avatarId)
                            if (file.exists()) {
                                coil.compose.AsyncImage(
                                    model = file,
                                    contentDescription = "Foto Profil",
                                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Gray),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        } else {
                            val avatarEmoji = when (avatarId) {
                                "avatar_1" -> "🐱"
                                "avatar_2" -> "🚀"
                                "avatar_3" -> "🥷"
                                "avatar_4" -> "🕵️"
                                "avatar_5" -> "🎧"
                                "avatar_6" -> "🦁"
                                else -> "🐱"
                            }
                            val avatarBg = when (avatarId) {
                                "avatar_1" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFFF9A9E), Color(0xFFFECFEF)))
                                "avatar_2" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF84FAB0), Color(0xFF8FD3F4)))
                                "avatar_3" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFA1C4FD), Color(0xFFC2E9FB)))
                                "avatar_4" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFF6D365), Color(0xFFFDA085)))
                                "avatar_5" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFFFE29F), Color(0xFFFFA99F)))
                                "avatar_6" -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFCFD9DF), Color(0xFFE2EBF0)))
                                else -> androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFFF9A9E), Color(0xFFFECFEF)))
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(avatarBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = avatarEmoji,
                                    fontSize = 24.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Halo, " + (user?.fullName ?: "Pengguna"),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Premium Account",
                                color = Color(0xFF00E676),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                IconButton(onClick = { /* Help */ }) {
                    Icon(
                        imageVector = Icons.Outlined.Help,
                        contentDescription = "Help center",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Balance Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF008CE6)), // Classic DANA Blue
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Saldo NusaWallet",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = idrFormat.format(user?.balance ?: 0.0),
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        // Secondary dynamic balance security check
                        Icon(
                            imageVector = Icons.Outlined.AccountBalanceWallet,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = Color.White.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Fintech Core Action Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        CoreButton(
                            title = "Top Up",
                            icon = Icons.Default.AddCircle,
                            onClick = onTopUpClick
                        )
                        CoreButton(
                            title = "Scan QRIS",
                            icon = Icons.Default.QrCodeScanner,
                            onClick = { onNavigateToQrisTab(0) } // Navigate to Scan QRIS
                        )
                        CoreButton(
                            title = "Tampil QR",
                            icon = Icons.Default.QrCode,
                            onClick = { onNavigateToQrisTab(1) } // Navigate to Show QRIS
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CoreButton(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TopUpQuickNavSection(
    onTopUpClick: () -> Unit,
    onPulsaClick: () -> Unit,
    onDataClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Top Up",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F3261)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // 1. Top Up E-Wallet Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onTopUpClick() }
                        .padding(4.dp)
                        .weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFF3E0)), // Very soft orange/cream background
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AccountBalanceWallet,
                            contentDescription = "Top Up E-Wallet",
                            tint = Color(0xFFE06D1F), // Orange/Brown wallet icon color
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Top Up",
                        color = Color.DarkGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "E-Wallet",
                        color = Color.DarkGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }

                // 2. Pulsa Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onPulsaClick() }
                        .padding(4.dp)
                        .weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)), // Very soft green background
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1FAA4A)), // Green circle (matching the green icon in the screenshot)
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = "Pulsa",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            // "Rp" symbol inside standard Android icon badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .offset(x = 1.dp, y = 1.dp)
                                    .background(Color(0xFF1FAA4A), CircleShape)
                                    .padding(horizontal = 1.dp)
                            ) {
                                Text(
                                    text = "Rp",
                                    color = Color.White,
                                    fontSize = 6.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Pulsa",
                        color = Color.DarkGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "",
                        fontSize = 12.sp
                    )
                }

                // 3. Data Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onDataClick() }
                        .padding(4.dp)
                        .weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)), // Very soft green background
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1FAA4A)), // Green circle (matching the green icon in the screenshot)
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = "Data",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            // "Wifi/wave" badge icon overlay inside green circle
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .size(9.dp)
                                    .align(Alignment.BottomEnd)
                                    .offset(x = 1.dp, y = 1.dp)
                                    .background(Color(0xFF1FAA4A), CircleShape)
                                    .padding(0.5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Data",
                        color = Color.DarkGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "",
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BillerPortalSection(
    enteredPhone: String,
    onPhoneChanged: (String) -> Unit,
    selectedProvider: String,
    onProviderSelected: (String) -> Unit,
    productType: String,
    onProductTypeSelected: (String) -> Unit,
    products: List<BillerProduct>,
    idrFormat: NumberFormat,
    focusRequester: FocusRequester,
    onProductClick: (BillerProduct) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Beli Pulsa & Paket Data (Kuota)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F3261)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone Input
            OutlinedTextField(
                value = enteredPhone,
                onValueChange = { onPhoneChanged(it) },
                label = { Text("Masukkan Nomor Hanphone") },
                placeholder = { Text("Contoh: 0812XXXXXXXX") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester),
                shape = RoundedCornerShape(12.dp),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = Color(0xFF008CE6)
                    )
                },
                trailingIcon = {
                    // Operator Auto Detect Visual Indicator!
                    if (enteredPhone.length >= 4) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFFECB3))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = selectedProvider,
                                color = Color(0xFFE65100),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Provider manual grid (if they want to swap manually)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Operator:", fontSize = 12.sp, color = Color.Gray)
                Row {
                    val list = listOf("Telkomsel", "Indosat", "XL", "Tri")
                    list.forEach { provider ->
                        val isSel = selectedProvider.lowercase() == provider.lowercase()
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSel) Color(0xFFEDF7FF) else Color.Transparent)
                                .clickable { onProviderSelected(provider) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = provider,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color(0xFF008CE6) else Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider()
            Spacer(modifier = Modifier.height(12.dp))

            // Pulse vs Data selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF1F3F5))
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (productType == "PULSA") Color(0xFF008CE6) else Color.Transparent)
                        .clickable { onProductTypeSelected("PULSA") }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Pulsa",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (productType == "PULSA") Color.White else Color.DarkGray
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (productType == "DATA") Color(0xFF008CE6) else Color.Transparent)
                        .clickable { onProductTypeSelected("DATA") }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Paket Data",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (productType == "DATA") Color.White else Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Products Grid
            if (enteredPhone.length < 10) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nomor telepon minimal 10 digit untuk melihat produk", color = Color.Gray, fontSize = 11.sp)
                }
            } else {
                Text(
                    text = "$selectedProvider - Pilihan Terbaik Untuk Anda:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Simple list of dynamic products so they render instantly
                Column {
                    products.forEach { prod ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onProductClick(prod) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = prod.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF0F3261)
                                    )
                                    Text(
                                        text = prod.description,
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = idrFormat.format(prod.price),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF2E7D32)
                                    )
                                    Text(
                                        text = "Beli Instan",
                                        fontSize = 10.sp,
                                        color = Color(0xFF008CE6),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionListItem(
    transaction: Transaction,
    idrFormat: NumberFormat,
    onClick: () -> Unit
) {
    val df = remember { SimpleDateFormat("dd MMM, HH:mm", Locale("in", "ID")) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                // Circular icon representing transaction flow
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            when (transaction.type) {
                                "TOPUP", "QRIS_RECEIVE" -> Color(0xFFE8F5E9)
                                else -> Color(0xFFE1F5FE)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (transaction.type) {
                            "TOPUP", "QRIS_RECEIVE" -> Icons.Default.ArrowDownward
                            else -> Icons.Default.ArrowUpward
                        },
                        contentDescription = null,
                        tint = when (transaction.type) {
                            "TOPUP", "QRIS_RECEIVE" -> Color(0xFF2E7D32)
                            else -> Color(0xFF008CE6)
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = transaction.description,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F3261),
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${transaction.paymentChannel} • ${df.format(Date(transaction.timestamp))}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (transaction.type == "TOPUP" || transaction.type == "QRIS_RECEIVE") "+" else "-") +
                            idrFormat.format(transaction.amount),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = when (transaction.type) {
                        "TOPUP", "QRIS_RECEIVE" -> Color(0xFF2E7D32)
                        else -> Color(0xFF0F3261)
                    }
                )

                Spacer(modifier = Modifier.height(4.dp))

                // STATUS BADGE - EXACTLY MEETING REQUESTS!
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when (transaction.status) {
                                "SUCCESS" -> Color(0xFFE8F5E9)
                                "PENDING" -> Color(0xFFFFF3E0)
                                else -> Color(0xFFFFEBEE)
                            }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = transaction.status,
                        color = when (transaction.status) {
                            "SUCCESS" -> Color(0xFF2E7D32)
                            "PENDING" -> Color(0xFFEF6C00)
                            else -> Color(0xFFC62828)
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Top Up Panel Input Dialog box
 */
@Composable
fun TopUpDialog(
    idrFormat: NumberFormat,
    onDismiss: () -> Unit,
    onConfirmTopUp: (Double, String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var selectedChannel by remember { mutableStateOf("BCA Virtual Account") }

    val bankChannels = listOf("BCA Virtual Account", "Mandiri Virtual Account", "Alfamart / Indomaret", "BNI Virtual Account")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Top Up NusaWallet Balance", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Masukkan nominal top up:", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("cth: 50000") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Pilih Jalur Pembayaran (Channel):", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(6.dp))

                bankChannels.forEach { cardChannel ->
                    val isSel = selectedChannel == cardChannel
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedChannel = cardChannel },
                        colors = CardDefaults.cardColors(containerColor = if (isSel) Color(0xFFEDF7FF) else Color(0xFFF1F3F5)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSel,
                                onClick = { selectedChannel = cardChannel }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(cardChannel, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val doubleAmt = amountText.toDoubleOrNull() ?: 0.0
                    if (doubleAmt > 0) {
                        onConfirmTopUp(doubleAmt, selectedChannel)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008CE6)),
                enabled = amountText.trim().isNotEmpty() && (amountText.toDoubleOrNull() ?: 0.0) > 0
            ) {
                Text("Lanjutkan", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
