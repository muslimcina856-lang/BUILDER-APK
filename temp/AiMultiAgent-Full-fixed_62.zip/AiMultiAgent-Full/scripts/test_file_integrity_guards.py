#!/usr/bin/env python3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
provider = (ROOT / "mobile/lib/src/services/provider_service.dart").read_text(
    encoding="utf-8"
)
guard = ROOT / "mobile/lib/src/services/provider_response_guard.dart"
coordinator = ROOT / "mobile/lib/src/services/file_write_coordinator.dart"
tool_engine = (ROOT / "mobile/lib/src/services/tool_engine.dart").read_text(
    encoding="utf-8"
)
runtime = (ROOT / "mobile/lib/src/services/agent_runtime.dart").read_text(
    encoding="utf-8"
)

errors = []


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


require(guard.exists(), "Provider response guard belum dibuat")
require(coordinator.exists(), "Transactional file coordinator belum dibuat")
require("ProviderResponseGuard.ensureOpenAiChatComplete" in provider,
        "OpenAI Chat finish_reason belum disemak")
require("ProviderResponseGuard.ensureOpenAiResponsesComplete" in provider,
        "OpenAI Responses incomplete status belum disemak")
require("ProviderResponseGuard.ensureAnthropicComplete" in provider,
        "Anthropic stop_reason belum disemak")
require("ProviderResponseGuard.ensureGeminiComplete" in provider,
        "Gemini finishReason belum disemak")
require("{'value': value.toString()}" not in provider,
        "Argumen tool rosak masih diteruskan sebagai value fallback")
require("_suggestedWritePath" not in tool_engine,
        "Path fail masih diteka dan boleh bertukar kepada dokumen.txt")
require("'chunks': <String, dynamic>" not in tool_engine,
        "chunks array satu-call masih boleh mencetuskan truncation")
require("FileWriteCoordinator.maxChunkBytes" in tool_engine,
        "Hard cap chunk belum dikuatkuasakan pada schema tool")
require("id: 'file_commit'" in tool_engine,
        "Tool commit fail belum tersedia")
require("id: 'file_write_status'" in tool_engine,
        "Tool status/resume fail belum tersedia")
require("id: 'file_abort'" in tool_engine,
        "Tool abort fail belum tersedia")
require("id: 'present_files'" in tool_engine,
        "Tool present_files belum tersedia")
require("expected_sha256" in tool_engine,
        "Pengesahan hash fail belum diekspos kepada model")
require("ProviderResponseIntegrityException" in runtime,
        "Orchestrator belum mengendalikan respons provider terpotong")
require("pendingFileWrites" in runtime,
        "Orchestrator masih boleh menamatkan tugasan dengan fail belum commit")
require("abortPendingFileWrites" in runtime,
        "Pembatalan run belum membersihkan transaksi staging")
require("final replaceAll = arguments['replace_all'] == true" in tool_engine,
        "file_replace masih mengganti semua padanan secara lalai")

if errors:
    print("UJIAN GUARD FAIL")
    for error in errors:
        print("-", error)
    raise SystemExit(1)

print("UJIAN GUARD LULUS")
