import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

class FileWriteException implements Exception {
  const FileWriteException(this.code, this.message);

  final String code;
  final String message;

  @override
  String toString() => '$code: $message';
}

class FileWriteSnapshot {
  const FileWriteSnapshot({
    required this.writeId,
    required this.path,
    required this.nextSequence,
    required this.bytes,
    required this.lines,
    required this.sha256,
    required this.tail,
    required this.committed,
    this.deduplicated = false,
  });

  final String writeId;
  final String path;
  final int nextSequence;
  final int bytes;
  final int lines;
  final String sha256;
  final String tail;
  final bool committed;
  final bool deduplicated;

  Map<String, dynamic> toData() => <String, dynamic>{
        'write_id': writeId,
        'path': path,
        'next_sequence': nextSequence,
        'bytes': bytes,
        'lines': lines,
        'sha256': sha256,
        'tail': tail,
        'committed': committed,
        'deduplicated': deduplicated,
      };
}

class _WriteSession {
  _WriteSession({
    required this.id,
    required this.ownerId,
    required this.targetPath,
    required this.relativePath,
    required this.tempPath,
    required this.nextSequence,
    required this.stagedBytes,
    required this.chunkHashes,
    required this.overwrite,
    required this.createdAt,
    required this.updatedAt,
    this.baseSha256,
    this.expectedSha256,
    this.expectedBytes,
  });

  final String id;
  final String ownerId;
  final String targetPath;
  final String relativePath;
  final String tempPath;
  int nextSequence;
  int stagedBytes;
  final Map<int, String> chunkHashes;
  final bool overwrite;
  final String? baseSha256;
  String? expectedSha256;
  int? expectedBytes;
  final DateTime createdAt;
  DateTime updatedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'owner_id': ownerId,
        'target_path': targetPath,
        'relative_path': relativePath,
        'temp_path': tempPath,
        'next_sequence': nextSequence,
        'staged_bytes': stagedBytes,
        'chunk_hashes': chunkHashes.map(
          (key, value) => MapEntry<String, String>(key.toString(), value),
        ),
        'overwrite': overwrite,
        'base_sha256': baseSha256,
        'expected_sha256': expectedSha256,
        'expected_bytes': expectedBytes,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory _WriteSession.fromJson(Map<String, dynamic> json) {
    final hashes = <int, String>{};
    for (final entry in (json['chunk_hashes'] as Map? ?? const <dynamic, dynamic>{})
        .entries) {
      final key = int.tryParse(entry.key.toString());
      if (key != null) hashes[key] = entry.value.toString();
    }
    return _WriteSession(
      id: json['id']?.toString() ?? '',
      ownerId: json['owner_id']?.toString() ?? '',
      targetPath: json['target_path']?.toString() ?? '',
      relativePath: json['relative_path']?.toString() ?? '',
      tempPath: json['temp_path']?.toString() ?? '',
      nextSequence: (json['next_sequence'] as num?)?.toInt() ?? 0,
      stagedBytes: (json['staged_bytes'] as num?)?.toInt() ?? 0,
      chunkHashes: hashes,
      overwrite: json['overwrite'] == true,
      baseSha256: json['base_sha256']?.toString(),
      expectedSha256: json['expected_sha256']?.toString(),
      expectedBytes: (json['expected_bytes'] as num?)?.toInt(),
      createdAt: DateTime.tryParse(json['created_at']?.toString() ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(json['updated_at']?.toString() ?? '') ??
          DateTime.now(),
    );
  }
}

class _AsyncMutex {
  Future<void> _tail = Future<void>.value();

  Future<T> protect<T>(Future<T> Function() action) {
    final previous = _tail;
    final release = Completer<void>();
    _tail = release.future;
    return () async {
      await previous;
      try {
        return await action();
      } finally {
        release.complete();
      }
    }();
  }
}

/// Penulis fail bertransaksi. Kandungan hanya dipindahkan ke path sasaran
/// selepas urutan, hash, saiz dan format asas disahkan.
class FileWriteCoordinator {
  FileWriteCoordinator(this.workspace);

  static const int maxChunkBytes = 6000;
  static const int maxFileBytes = 16 * 1024 * 1024;
  static const _uuid = Uuid();

  final Directory workspace;
  final Map<String, _WriteSession> _sessions = <String, _WriteSession>{};
  final Map<String, FileWriteSnapshot> _completed =
      <String, FileWriteSnapshot>{};
  final Map<String, Map<int, String>> _completedChunkHashes =
      <String, Map<int, String>>{};
  final Map<String, String> _activeByPath = <String, String>{};
  final Map<String, _AsyncMutex> _pathLocks = <String, _AsyncMutex>{};
  Future<void>? _loadFuture;

  Directory get _staging => Directory(p.join(workspace.path, '.write_staging'));

  static String sha256Bytes(List<int> bytes) => sha256.convert(bytes).toString();

  static String sha256Text(String value) => sha256Bytes(utf8.encode(value));

  static Future<String> sha256File(File file) async =>
      sha256Bytes(await file.readAsBytes());

  Future<FileWriteSnapshot> begin({
    required String ownerId,
    required File target,
    required String relativePath,
    required String content,
    bool done = true,
    bool overwrite = false,
    String? baseSha256,
    String? expectedSha256,
    int? expectedBytes,
  }) async {
    await _ensureLoaded();
    _validateChunk(content);
    final targetPath = p.normalize(target.path);
    _ensureTargetWithinWorkspace(targetPath);
    return _mutex(targetPath).protect(() async {
      final active = _activeByPath[targetPath];
      if (active != null) {
        throw FileWriteException(
          'FILE_BUSY',
          'Fail sedang ditulis oleh transaksi $active. Sambung transaksi itu atau tunggu ia selesai.',
        );
      }

      String? normalizedBase;
      if (await target.exists()) {
        if (!overwrite) {
          throw const FileWriteException(
            'TARGET_EXISTS',
            'Fail sudah wujud. Gunakan file_read + file_replace, atau overwrite=true bersama base_sha256.',
          );
        }
        if (baseSha256 == null || baseSha256.trim().isEmpty) {
          throw const FileWriteException(
            'BASE_HASH_REQUIRED',
            'overwrite memerlukan base_sha256 daripada file_read supaya perubahan lain tidak tertindih.',
          );
        }
        normalizedBase = baseSha256.trim().toLowerCase();
        final current = await sha256File(target);
        if (current != normalizedBase) {
          throw const FileWriteException(
            'VERSION_CONFLICT',
            'Fail telah berubah sejak dibaca. Baca semula fail dan bina perubahan daripada versi terkini.',
          );
        }
      } else if (overwrite && baseSha256?.trim().isNotEmpty == true) {
        throw const FileWriteException(
          'VERSION_CONFLICT',
          'Fail asas sudah tiada; overwrite dibatalkan.',
        );
      }

      await _staging.create(recursive: true);
      final id = _uuid.v4();
      final temp = File(p.join(_staging.path, '$id.part'));
      final bytes = utf8.encode(content);
      final session = _WriteSession(
        id: id,
        ownerId: ownerId,
        targetPath: targetPath,
        relativePath: relativePath,
        tempPath: temp.path,
        nextSequence: 1,
        stagedBytes: bytes.length,
        chunkHashes: <int, String>{0: sha256Bytes(bytes)},
        overwrite: overwrite,
        baseSha256: normalizedBase,
        expectedSha256: _normalizeExpectedHash(expectedSha256),
        expectedBytes: expectedBytes,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _sessions[id] = session;
      _activeByPath[targetPath] = id;
      try {
        await temp.writeAsBytes(bytes, flush: true);
        await _persist(session);
        if (done) return _commitLocked(session);
        return _snapshot(session);
      } catch (_) {
        // file_write(done=true) tidak pernah memulangkan write_id sebelum
        // commit berjaya. Jika validasi/commit gagal, buang staging supaya
        // retry pada path yang sama tidak tersangkut dengan FILE_BUSY.
        if (done) {
          await _deleteQuietly(temp);
          await _deleteQuietly(_metadataFile(id));
          await _deleteQuietly(File('${_metadataFile(id).path}.tmp'));
          _sessions.remove(id);
          _activeByPath.remove(targetPath);
        } else if (!await temp.exists()) {
          _sessions.remove(id);
          _activeByPath.remove(targetPath);
        }
        rethrow;
      }
    });
  }

  Future<FileWriteSnapshot> atomicReplace({
    required File target,
    required String relativePath,
    required String content,
    required String baseSha256,
  }) async {
    await _ensureLoaded();
    final bytes = utf8.encode(content);
    if (bytes.isEmpty || content.trim().isEmpty) {
      throw const FileWriteException(
        'EMPTY_CONTENT',
        'Hasil edit kosong ditolak.',
      );
    }
    if (bytes.length > maxFileBytes) {
      throw const FileWriteException(
        'FILE_TOO_LARGE',
        'Hasil edit melebihi had 16 MiB.',
      );
    }
    final normalizedBase = _normalizeExpectedHash(baseSha256);
    if (normalizedBase == null) {
      throw const FileWriteException(
        'BASE_HASH_REQUIRED',
        'Edit memerlukan expected_sha256 daripada file_read.',
      );
    }
    final targetPath = p.normalize(target.path);
    _ensureTargetWithinWorkspace(targetPath);
    return _mutex(targetPath).protect(() async {
      final active = _activeByPath[targetPath];
      if (active != null) {
        throw FileWriteException(
          'FILE_BUSY',
          'Fail sedang ditulis oleh transaksi $active.',
        );
      }
      if (!await target.exists()) {
        throw const FileWriteException(
          'TARGET_MISSING',
          'Fail yang hendak diedit tidak ditemui.',
        );
      }
      if (await sha256File(target) != normalizedBase) {
        throw const FileWriteException(
          'VERSION_CONFLICT',
          'Fail berubah sejak file_read. Baca semula sebelum mengedit.',
        );
      }
      _validateFormat(relativePath, bytes);
      await _staging.create(recursive: true);
      final id = _uuid.v4();
      final temp = File(p.join(_staging.path, '$id.replace.part'));
      try {
        await temp.writeAsBytes(bytes, flush: true);
        if (await sha256File(target) != normalizedBase) {
          throw const FileWriteException(
            'VERSION_CONFLICT',
            'Fail berubah semasa edit disediakan. Atomic replace dibatalkan.',
          );
        }
        final session = _WriteSession(
          id: id,
          ownerId: 'atomic-replace',
          targetPath: targetPath,
          relativePath: relativePath,
          tempPath: target.path,
          nextSequence: 1,
          stagedBytes: bytes.length,
          chunkHashes: <int, String>{0: sha256Bytes(bytes)},
          overwrite: true,
          baseSha256: normalizedBase,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        final snapshot = await _snapshotForFile(
          session: session,
          file: temp,
          committed: true,
        );
        try {
          await temp.rename(target.path);
        } on FileSystemException catch (error) {
          throw FileWriteException(
            'ATOMIC_COMMIT_FAILED',
            'Atomic replace gagal; fail asal dikekalkan. ${error.message}',
          );
        }
        return snapshot;
      } finally {
        await _deleteQuietly(temp);
      }
    });
  }

  Future<FileWriteSnapshot> append({
    required String ownerId,
    required String writeId,
    required int sequence,
    required String content,
    bool done = false,
    String? expectedSha256,
    int? expectedBytes,
  }) async {
    await _ensureLoaded();
    _validateChunk(content);
    final completed = _completed[writeId];
    if (completed != null) {
      final chunkHash = sha256Text(content);
      if (sequence >= completed.nextSequence ||
          _completedChunkHashes[writeId]?[sequence] != chunkHash) {
        throw const FileWriteException(
          'WRITE_ALREADY_COMMITTED',
          'Transaksi sudah committed; chunk baharu atau berbeza ditolak.',
        );
      }
      return FileWriteSnapshot(
        writeId: completed.writeId,
        path: completed.path,
        nextSequence: completed.nextSequence,
        bytes: completed.bytes,
        lines: completed.lines,
        sha256: completed.sha256,
        tail: completed.tail,
        committed: true,
        deduplicated: true,
      );
    }
    final session = _requireSession(writeId, ownerId);
    return _mutex(session.targetPath).protect(() async {
      final chunkHash = sha256Text(content);
      if (sequence < session.nextSequence) {
        if (session.chunkHashes[sequence] == chunkHash) {
          final current = await _snapshot(session);
          return FileWriteSnapshot(
            writeId: current.writeId,
            path: current.path,
            nextSequence: current.nextSequence,
            bytes: current.bytes,
            lines: current.lines,
            sha256: current.sha256,
            tail: current.tail,
            committed: false,
            deduplicated: true,
          );
        }
        throw const FileWriteException(
          'DUPLICATE_CONFLICT',
          'Sequence lama dihantar semula dengan kandungan berbeza.',
        );
      }
      if (sequence != session.nextSequence) {
        throw FileWriteException(
          'SEQUENCE_MISMATCH',
          'Sequence dijangka ${session.nextSequence}, tetapi menerima $sequence. Semak file_write_status.',
        );
      }
      final temp = File(session.tempPath);
      final currentBytes = await temp.length();
      final incoming = utf8.encode(content);
      if (currentBytes + incoming.length > maxFileBytes) {
        throw const FileWriteException(
          'FILE_TOO_LARGE',
          'Jumlah fail melebihi had transaksi 16 MiB.',
        );
      }
      await temp.writeAsBytes(incoming, mode: FileMode.append, flush: true);
      session.chunkHashes[sequence] = chunkHash;
      session.nextSequence++;
      session.stagedBytes = currentBytes + incoming.length;
      session.updatedAt = DateTime.now();
      if (expectedSha256?.trim().isNotEmpty == true) {
        session.expectedSha256 = _normalizeExpectedHash(expectedSha256);
      }
      if (expectedBytes != null) session.expectedBytes = expectedBytes;
      await _persist(session);
      if (done) return _commitLocked(session);
      return _snapshot(session);
    });
  }

  Future<FileWriteSnapshot> commit({
    required String ownerId,
    required String writeId,
    String? expectedSha256,
    int? expectedBytes,
  }) async {
    await _ensureLoaded();
    final completed = _completed[writeId];
    if (completed != null) return completed;
    final session = _requireSession(writeId, ownerId);
    return _mutex(session.targetPath).protect(() async {
      if (expectedSha256?.trim().isNotEmpty == true) {
        session.expectedSha256 = _normalizeExpectedHash(expectedSha256);
      }
      if (expectedBytes != null) session.expectedBytes = expectedBytes;
      await _persist(session);
      return _commitLocked(session);
    });
  }

  Future<FileWriteSnapshot> status({
    required String ownerId,
    required String writeId,
  }) async {
    await _ensureLoaded();
    final completed = _completed[writeId];
    if (completed != null) return completed;
    return _snapshot(_requireSession(writeId, ownerId));
  }

  Future<void> abort({
    required String ownerId,
    required String writeId,
  }) async {
    await _ensureLoaded();
    final session = _requireSession(writeId, ownerId);
    await _mutex(session.targetPath).protect(() async {
      await _deleteIfExists(File(session.tempPath));
      await _deleteIfExists(_metadataFile(session.id));
      await _deleteIfExists(File('${_metadataFile(session.id).path}.tmp'));
      _sessions.remove(session.id);
      _activeByPath.remove(session.targetPath);
    });
  }

  Future<List<FileWriteSnapshot>> pendingForOwner(String ownerId) async {
    await _ensureLoaded();
    final values = <FileWriteSnapshot>[];
    for (final session in _sessions.values.where((item) => item.ownerId == ownerId)) {
      values.add(await _snapshot(session));
    }
    return values;
  }

  Future<void> abortAllForOwner(String ownerId) async {
    await _ensureLoaded();
    final ids = _sessions.values
        .where((item) => item.ownerId == ownerId)
        .map((item) => item.id)
        .toList(growable: false);
    for (final id in ids) {
      await abort(ownerId: ownerId, writeId: id);
    }
  }

  Future<bool> isTargetBusy(String targetPath) async {
    await _ensureLoaded();
    return _activeByPath.containsKey(p.normalize(targetPath));
  }

  Future<FileWriteSnapshot> _commitLocked(_WriteSession session) async {
    final temp = File(session.tempPath);
    if (!await temp.exists()) {
      throw const FileWriteException(
        'STAGING_MISSING',
        'Kandungan staging tidak ditemui; transaksi tidak boleh diteruskan.',
      );
    }
    final bytes = await temp.readAsBytes();
    if (bytes.isEmpty) {
      throw const FileWriteException(
        'EMPTY_CONTENT',
        'Fail kosong tidak boleh di-commit.',
      );
    }
    if (bytes.length > maxFileBytes) {
      throw const FileWriteException(
        'FILE_TOO_LARGE',
        'Jumlah fail melebihi had transaksi 16 MiB.',
      );
    }
    final actualHash = sha256Bytes(bytes);
    if (session.expectedBytes != null && bytes.length != session.expectedBytes) {
      throw FileWriteException(
        'SIZE_MISMATCH',
        'Saiz dijangka ${session.expectedBytes} bait tetapi staging mempunyai ${bytes.length} bait.',
      );
    }
    if (session.expectedSha256 != null && actualHash != session.expectedSha256) {
      throw const FileWriteException(
        'HASH_MISMATCH',
        'SHA-256 staging tidak sepadan dengan nilai dijangka.',
      );
    }
    _validateFormat(session.relativePath, bytes);

    final target = File(session.targetPath);
    if (await target.exists()) {
      if (!session.overwrite || session.baseSha256 == null) {
        throw const FileWriteException(
          'VERSION_CONFLICT',
          'Fail sasaran muncul atau berubah semasa transaksi. Commit dibatalkan.',
        );
      }
      final currentHash = await sha256File(target);
      if (currentHash != session.baseSha256) {
        throw const FileWriteException(
          'VERSION_CONFLICT',
          'Fail berubah selepas transaksi bermula. Commit dibatalkan.',
        );
      }
    } else if (session.overwrite && session.baseSha256 != null) {
      throw const FileWriteException(
        'VERSION_CONFLICT',
        'Fail sasaran dipadam semasa transaksi. Commit dibatalkan.',
      );
    }

    final snapshot = await _snapshotForFile(
      session: session,
      file: temp,
      committed: true,
    );
    await target.parent.create(recursive: true);
    try {
      await temp.rename(target.path);
    } on FileSystemException catch (error) {
      throw FileWriteException(
        'ATOMIC_COMMIT_FAILED',
        'Atomic rename gagal; fail asal dikekalkan. ${error.message}',
      );
    }
    // Sasaran sudah committed. Kegagalan housekeeping tidak boleh menukar
    // commit berjaya menjadi ralat lalu memprovokasi model menulis semula.
    await _deleteQuietly(_metadataFile(session.id));
    await _deleteQuietly(File('${_metadataFile(session.id).path}.tmp'));
    _sessions.remove(session.id);
    _activeByPath.remove(session.targetPath);
    _completed[session.id] = snapshot;
    _completedChunkHashes[session.id] =
        Map<int, String>.from(session.chunkHashes);
    if (_completed.length > 128) {
      final oldest = _completed.keys.first;
      _completed.remove(oldest);
      _completedChunkHashes.remove(oldest);
    }
    return snapshot;
  }

  Future<FileWriteSnapshot> _snapshot(_WriteSession session) =>
      _snapshotForFile(
        session: session,
        file: File(session.tempPath),
        committed: false,
      );

  Future<FileWriteSnapshot> _snapshotForFile({
    required _WriteSession session,
    required File file,
    required bool committed,
  }) async {
    final bytes = await file.readAsBytes();
    final text = utf8.decode(bytes, allowMalformed: true);
    return FileWriteSnapshot(
      writeId: session.id,
      path: session.relativePath,
      nextSequence: session.nextSequence,
      bytes: bytes.length,
      lines: _lineCount(text),
      sha256: sha256Bytes(bytes),
      tail: _tail(text),
      committed: committed,
    );
  }

  _WriteSession _requireSession(String writeId, String ownerId) {
    final session = _sessions[writeId];
    if (session == null) {
      throw const FileWriteException(
        'WRITE_NOT_FOUND',
        'Transaksi tidak ditemui. Mulakan semula dengan file_write.',
      );
    }
    if (session.ownerId != ownerId) {
      throw const FileWriteException(
        'WRITE_OWNER_MISMATCH',
        'Transaksi dimiliki oleh agent/run lain.',
      );
    }
    return session;
  }

  void _validateChunk(String content) {
    final bytes = utf8.encode(content);
    if (bytes.isEmpty || content.trim().isEmpty) {
      throw const FileWriteException(
        'EMPTY_CONTENT',
        'Chunk kosong ditolak. Jangan cipta atau append fail kosong.',
      );
    }
    if (bytes.length > maxChunkBytes) {
      throw FileWriteException(
        'PAYLOAD_TOO_LARGE',
        'Chunk ${bytes.length} bait melebihi had $maxChunkBytes bait. '
            'Hantar potongan lebih kecil pada transaksi/path yang sama.',
      );
    }
  }

  static void _validateFormat(String path, List<int> bytes) {
    final extension = p.extension(path).toLowerCase();
    String text;
    try {
      text = utf8.decode(bytes);
    } on FormatException {
      throw const FileWriteException(
        'FORMAT_INVALID',
        'Fail teks mengandungi UTF-8 yang tidak sah.',
      );
    }
    try {
      if (extension == '.json') {
        jsonDecode(text);
      } else if (extension == '.jsonl') {
        for (final line in const LineSplitter().convert(text)) {
          if (line.trim().isNotEmpty) jsonDecode(line);
        }
      } else if (extension == '.svg' &&
          !RegExp(r'<svg(?:\s|>)', caseSensitive: false).hasMatch(text)) {
        throw const FormatException('Elemen svg tiada');
      }
    } catch (error) {
      throw FileWriteException(
        'FORMAT_INVALID',
        'Kandungan tidak sah untuk $extension: $error',
      );
    }
  }

  static String? _normalizeExpectedHash(String? value) {
    final normalized = value?.trim().toLowerCase();
    if (normalized == null || normalized.isEmpty) return null;
    if (!RegExp(r'^[a-f0-9]{64}$').hasMatch(normalized)) {
      throw const FileWriteException(
        'INVALID_HASH',
        'SHA-256 mesti tepat 64 aksara heksadesimal.',
      );
    }
    return normalized;
  }

  void _ensureTargetWithinWorkspace(String targetPath) {
    final normalizedRoot = p.normalize(workspace.path);
    if (!p.isWithin(normalizedRoot, targetPath)) {
      throw const FileWriteException(
        'PATH_OUTSIDE_WORKSPACE',
        'Path sasaran mesti berada dalam workspace.',
      );
    }
  }

  Future<void> _ensureLoaded() => _loadFuture ??= _loadSessions();

  Future<void> _loadSessions() async {
    await workspace.create(recursive: true);
    if (!await _staging.exists()) return;
    await for (final entity in _staging.list(followLinks: false)) {
      if (entity is! File || !entity.path.endsWith('.json')) continue;
      try {
        final decoded = jsonDecode(await entity.readAsString());
        if (decoded is! Map) continue;
        final session = _WriteSession.fromJson(
          Map<String, dynamic>.from(decoded),
        );
        if (session.id.isEmpty ||
            session.ownerId.isEmpty ||
            session.targetPath.isEmpty ||
            session.tempPath.isEmpty ||
            session.stagedBytes <= 0 ||
            !p.isWithin(workspace.path, session.targetPath) ||
            !p.isWithin(_staging.path, session.tempPath) ||
            !await File(session.tempPath).exists()) {
          continue;
        }
        final temp = File(session.tempPath);
        final actualBytes = await temp.length();
        if (actualBytes < session.stagedBytes) continue;
        if (actualBytes > session.stagedBytes) {
          final handle = await temp.open(mode: FileMode.writeOnlyAppend);
          try {
            await handle.truncate(session.stagedBytes);
            await handle.flush();
          } finally {
            await handle.close();
          }
        }
        _sessions[session.id] = session;
        _activeByPath[session.targetPath] = session.id;
      } catch (_) {
        // Metadata staging rosak tidak pernah digunakan untuk menulis target.
      }
    }
  }

  Future<void> _persist(_WriteSession session) async {
    await _staging.create(recursive: true);
    final metadata = _metadataFile(session.id);
    final temporary = File('${metadata.path}.tmp');
    await temporary.writeAsString(
      jsonEncode(session.toJson()),
      flush: true,
    );
    await temporary.rename(metadata.path);
  }

  File _metadataFile(String id) => File(p.join(_staging.path, '$id.json'));

  _AsyncMutex _mutex(String path) =>
      _pathLocks.putIfAbsent(path, _AsyncMutex.new);

  static int _lineCount(String text) =>
      text.isEmpty ? 0 : '\n'.allMatches(text).length + 1;

  static String _tail(String text) {
    const maxChars = 300;
    return text.length <= maxChars
        ? text
        : text.substring(text.length - maxChars);
  }

  static Future<void> _deleteIfExists(File file) async {
    if (await file.exists()) await file.delete();
  }

  static Future<void> _deleteQuietly(File file) async {
    try {
      await _deleteIfExists(file);
    } catch (_) {
      // Housekeeping staging tidak boleh merosakkan fail sasaran.
    }
  }
}
