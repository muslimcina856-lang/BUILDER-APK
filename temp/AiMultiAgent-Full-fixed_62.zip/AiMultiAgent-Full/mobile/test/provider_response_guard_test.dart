import 'package:ai_multiagent/src/services/provider_response_guard.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('ProviderResponseGuard', () {
    test('rejects OpenAI Chat output truncated by token limit', () {
      expect(
        () => ProviderResponseGuard.ensureOpenAiChatComplete(
          <String, dynamic>{
            'choices': <Map<String, dynamic>>[
              <String, dynamic>{'finish_reason': 'length'},
            ],
          },
        ),
        throwsA(
          isA<ProviderResponseIntegrityException>().having(
            (error) => error.code,
            'code',
            'OUTPUT_TRUNCATED',
          ),
        ),
      );
    });

    test('rejects incomplete OpenAI Responses output', () {
      expect(
        () => ProviderResponseGuard.ensureOpenAiResponsesComplete(
          <String, dynamic>{
            'status': 'incomplete',
            'incomplete_details': <String, dynamic>{
              'reason': 'max_output_tokens',
            },
          },
        ),
        throwsA(isA<ProviderResponseIntegrityException>()),
      );
    });

    test('rejects Anthropic max_tokens stop reason', () {
      expect(
        () => ProviderResponseGuard.ensureAnthropicComplete(
          <String, dynamic>{'stop_reason': 'max_tokens'},
        ),
        throwsA(isA<ProviderResponseIntegrityException>()),
      );
    });

    test('rejects Gemini MAX_TOKENS finish reason', () {
      expect(
        () => ProviderResponseGuard.ensureGeminiComplete(
          <String, dynamic>{
            'candidates': <Map<String, dynamic>>[
              <String, dynamic>{'finishReason': 'MAX_TOKENS'},
            ],
          },
        ),
        throwsA(isA<ProviderResponseIntegrityException>()),
      );
    });

    test('rejects Gemini malformed function call', () {
      expect(
        () => ProviderResponseGuard.ensureGeminiComplete(
          <String, dynamic>{
            'candidates': <Map<String, dynamic>>[
              <String, dynamic>{
                'finishReason': 'MALFORMED_FUNCTION_CALL',
              },
            ],
          },
        ),
        throwsA(
          isA<ProviderResponseIntegrityException>().having(
            (error) => error.code,
            'code',
            'INVALID_TOOL_ARGUMENTS',
          ),
        ),
      );
    });

    test('invalid tool arguments are never converted to a value fallback', () {
      expect(
        () => ProviderResponseGuard.decodeToolArguments(
          '{"path":"index.html","content":"unfinished',
        ),
        throwsA(
          isA<ProviderResponseIntegrityException>().having(
            (error) => error.code,
            'code',
            'INVALID_TOOL_ARGUMENTS',
          ),
        ),
      );
    });

    test('accepts valid completed output and arguments', () {
      ProviderResponseGuard.ensureOpenAiChatComplete(
        <String, dynamic>{
          'choices': <Map<String, dynamic>>[
            <String, dynamic>{'finish_reason': 'tool_calls'},
          ],
        },
      );
      expect(
        ProviderResponseGuard.decodeToolArguments('{"path":"index.html"}'),
        <String, dynamic>{'path': 'index.html'},
      );
    });
  });
}
