import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  /// Ganti URL ini sesuai server kamu
  /// - Lokal (emulator Android): http://10.0.2.2:5000
  /// - Lokal (HP satu WiFi): http://IP-KOMPUTER:5000
  /// - Online (Render dll): https://keuanganku.onrender.com
  static String baseUrl = 'http://10.0.2.2:5000';

  static Future<String?> getToken() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('token');
  }

  static Future<void> setToken(String? t) async {
    final p = await SharedPreferences.getInstance();
    if (t == null) {
      await p.remove('token');
      await p.remove('nama');
    } else {
      await p.setString('token', t);
    }
  }

  static Future<void> setNama(String n) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('nama', n);
  }

  static Future<String> getNama() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('nama') ?? '';
  }

  static Future<Map<String, String>> _headers() async {
    final t = await getToken();
    return {
      'Content-Type': 'application/json',
      if (t != null) 'Authorization': 'Bearer $t',
    };
  }

  static Future<Map<String, dynamic>> login(String user, String pass) async {
    final r = await http.post(
      Uri.parse('$baseUrl/api/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': user, 'password': pass}),
    );
    final body = jsonDecode(r.body);
    if (r.statusCode == 200) {
      await setToken(body['token']);
      await setNama(body['user']['nama'] ?? user);
      return body;
    }
    throw Exception(body['error'] ?? 'Login gagal');
  }

  static Future<void> register(String nama, String user, String pass) async {
    final r = await http.post(
      Uri.parse('$baseUrl/api/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'nama': nama, 'username': user, 'password': pass}),
    );
    final body = jsonDecode(r.body);
    if (r.statusCode != 201) {
      throw Exception(body['error'] ?? 'Daftar gagal');
    }
  }

  static Future<void> logout() async {
    try {
      await http.post(Uri.parse('$baseUrl/api/logout'), headers: await _headers());
    } catch (_) {}
    await setToken(null);
  }

  static Future<Map<String, dynamic>> summary() async {
    final r = await http.get(Uri.parse('$baseUrl/api/summary'), headers: await _headers());
    if (r.statusCode != 200) throw Exception('Gagal ambil data');
    return jsonDecode(r.body);
  }

  static Future<List<dynamic>> transaksi() async {
    final r = await http.get(Uri.parse('$baseUrl/api/transaksi'), headers: await _headers());
    if (r.statusCode != 200) throw Exception('Gagal ambil transaksi');
    return jsonDecode(r.body);
  }

  static Future<void> addTransaksi(Map<String, dynamic> data) async {
    final r = await http.post(
      Uri.parse('$baseUrl/api/transaksi'),
      headers: await _headers(),
      body: jsonEncode(data),
    );
    if (r.statusCode != 201) {
      final b = jsonDecode(r.body);
      throw Exception(b['error'] ?? 'Gagal simpan');
    }
  }

  static Future<void> deleteTransaksi(int id) async {
    final r = await http.delete(
      Uri.parse('$baseUrl/api/transaksi/$id'),
      headers: await _headers(),
    );
    if (r.statusCode != 200) throw Exception('Gagal hapus');
  }

  static Future<Map<String, dynamic>> kalkulator(Map<String, dynamic> data) async {
    final r = await http.post(
      Uri.parse('$baseUrl/api/kalkulator'),
      headers: await _headers(),
      body: jsonEncode(data),
    );
    if (r.statusCode != 200) throw Exception('Gagal hitung');
    return jsonDecode(r.body);
  }

  static Future<bool> health() async {
    try {
      final r = await http.get(Uri.parse('$baseUrl/api/health')).timeout(const Duration(seconds: 5));
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
