import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/api_service.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  bool loading = true;
  String nama = '';
  Map<String, dynamic>? summary;
  List<dynamic> txList = [];
  final fmt = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      nama = await ApiService.getNama();
      summary = await ApiService.summary();
      txList = await ApiService.transaksi();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString().replaceAll("Exception: ", "")}')),
        );
      }
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _logout() async {
    await ApiService.logout();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  void _addTx() {
    String jenis = 'pengeluaran';
    String kategori = 'Makanan';
    final jumlahCtrl = TextEditingController();
    final ketCtrl = TextEditingController();
    final katsOut = ['Makanan', 'Transportasi', 'Tagihan', 'Belanja', 'Hiburan', 'Kesehatan', 'Sewa', 'Lainnya'];
    final katsIn = ['Gaji', 'Freelance', 'Investasi', 'Bonus', 'Lainnya'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setM) {
          final kats = jenis == 'pemasukan' ? katsIn : katsOut;
          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Tambah Transaksi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: ChoiceChip(label: const Text('Pengeluaran'), selected: jenis == 'pengeluaran', onSelected: (_) => setM(() { jenis = 'pengeluaran'; kategori = katsOut.first; }))),
                  const SizedBox(width: 8),
                  Expanded(child: ChoiceChip(label: const Text('Pemasukan'), selected: jenis == 'pemasukan', onSelected: (_) => setM(() { jenis = 'pemasukan'; kategori = katsIn.first; }))),
                ]),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: kategori,
                  decoration: const InputDecoration(labelText: 'Kategori', border: OutlineInputBorder()),
                  items: kats.map((k) => DropdownMenuItem(value: k, child: Text(k))).toList(),
                  onChanged: (v) => setM(() => kategori = v!),
                ),
                const SizedBox(height: 10),
                TextField(controller: jumlahCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah (Rp)', border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(controller: ketCtrl, decoration: const InputDecoration(labelText: 'Keterangan', border: OutlineInputBorder())),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1A56DB), foregroundColor: Colors.white),
                    onPressed: () async {
                      final j = double.tryParse(jumlahCtrl.text) ?? 0;
                      if (j <= 0) return;
                      try {
                        await ApiService.addTransaksi({
                          'jenis': jenis,
                          'kategori': kategori,
                          'jumlah': j,
                          'keterangan': ketCtrl.text.trim(),
                          'tanggal': DateFormat('yyyy-MM-dd').format(DateTime.now()),
                        });
                        if (ctx.mounted) Navigator.pop(ctx);
                        _load();
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                      }
                    },
                    child: const Text('Simpan'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : IndexedStack(
              index: tab,
              children: [
                _dashboard(),
                _riwayat(),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addTx,
        backgroundColor: const Color(0xFF1A56DB),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(icon: Icon(Icons.home, color: tab == 0 ? const Color(0xFF1A56DB) : Colors.grey), onPressed: () => setState(() => tab = 0)),
            const SizedBox(width: 40),
            IconButton(icon: Icon(Icons.list, color: tab == 1 ? const Color(0xFF1A56DB) : Colors.grey), onPressed: () => setState(() => tab = 1)),
          ],
        ),
      ),
    );
  }

  Widget _dashboard() {
    final s = summary ?? {};
    final pem = (s['pemasukan'] as num?)?.toDouble() ?? 0;
    final peng = (s['pengeluaran'] as num?)?.toDouble() ?? 0;
    final saldo = (s['saldo'] as num?)?.toDouble() ?? 0;
    final labels = (s['labels'] as List?)?.cast<String>() ?? [];
    final gPem = (s['g_pem'] as List?)?.map((e) => (e as num).toDouble()).toList() ?? [];
    final gPeng = (s['g_peng'] as List?)?.map((e) => (e as num).toDouble()).toList() ?? [];

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 160,
          pinned: true,
          backgroundColor: const Color(0xFF1A56DB),
          actions: [IconButton(icon: const Icon(Icons.logout, color: Colors.white70), onPressed: _logout)],
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF0F172A), Color(0xFF1A56DB)]),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Halo, $nama', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  const Text('Saldo', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  Text(fmt.format(saldo), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Row(children: [
                    Text('↓ ${fmt.format(pem)}', style: const TextStyle(color: Colors.greenAccent, fontSize: 12)),
                    const SizedBox(width: 16),
                    Text('↑ ${fmt.format(peng)}', style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
                  ]),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Tren 6 Bulan', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 160,
                          child: labels.isEmpty
                              ? const Center(child: Text('Belum ada data', style: TextStyle(color: Colors.grey)))
                              : BarChart(BarChartData(
                                  alignment: BarChartAlignment.spaceAround,
                                  maxY: [...gPem, ...gPeng, 1.0].reduce((a, b) => a > b ? a : b) * 1.2,
                                  barGroups: List.generate(labels.length, (i) => BarChartGroupData(x: i, barRods: [
                                    BarChartRodData(toY: i < gPem.length ? gPem[i] : 0, color: Colors.green, width: 8, borderRadius: BorderRadius.circular(3)),
                                    BarChartRodData(toY: i < gPeng.length ? gPeng[i] : 0, color: Colors.redAccent, width: 8, borderRadius: BorderRadius.circular(3)),
                                  ])),
                                  titlesData: FlTitlesData(
                                    leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, _) => Text(labels[v.toInt()], style: const TextStyle(fontSize: 10)))),
                                  ),
                                  gridData: const FlGridData(show: false),
                                  borderData: FlBorderData(show: false),
                                )),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Transaksi Terbaru', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        if (txList.isEmpty)
                          const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada transaksi', style: TextStyle(color: Colors.grey))))
                        else
                          ...txList.take(8).map((t) => ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(t['kategori'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                                subtitle: Text('${t['tanggal']} · ${t['keterangan'] ?? t['jenis']}', style: const TextStyle(fontSize: 12)),
                                trailing: Text(
                                  '${t['jenis'] == 'pemasukan' ? '+' : '-'}${fmt.format(t['jumlah'])}',
                                  style: TextStyle(fontWeight: FontWeight.bold, color: t['jenis'] == 'pemasukan' ? Colors.green : Colors.red),
                                ),
                              )),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _riwayat() {
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat'), backgroundColor: const Color(0xFF1A56DB), foregroundColor: Colors.white, automaticallyImplyLeading: false),
      body: RefreshIndicator(
        onRefresh: _load,
        child: txList.isEmpty
            ? ListView(children: const [SizedBox(height: 100), Center(child: Text('Belum ada transaksi', style: TextStyle(color: Colors.grey)))])
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: txList.length,
                itemBuilder: (_, i) {
                  final t = txList[i];
                  return Card(
                    child: ListTile(
                      title: Text(t['kategori'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${t['tanggal']} · ${t['jenis']}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            fmt.format(t['jumlah']),
                            style: TextStyle(fontWeight: FontWeight.bold, color: t['jenis'] == 'pemasukan' ? Colors.green : Colors.red),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 20, color: Colors.grey),
                            onPressed: () async {
                              try {
                                await ApiService.deleteTransaksi(t['id']);
                                _load();
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
