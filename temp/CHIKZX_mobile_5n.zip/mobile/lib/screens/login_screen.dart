import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isLogin = true;
  bool loading = false;
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final namaCtrl = TextEditingController();
  final urlCtrl = TextEditingController(text: ApiService.baseUrl);

  void _toast(String m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(m), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _submit() async {
    setState(() => loading = true);
    try {
      // save server url
      final url = urlCtrl.text.trim().replaceAll(RegExp(r'/$'), '');
      if (url.isNotEmpty) {
        ApiService.baseUrl = url;
        final p = await SharedPreferences.getInstance();
        await p.setString('server_url', url);
      }

      if (isLogin) {
        await ApiService.login(userCtrl.text.trim(), passCtrl.text);
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      } else {
        await ApiService.register(namaCtrl.text.trim(), userCtrl.text.trim(), passCtrl.text);
        _toast('Daftar berhasil! Silakan login');
        setState(() => isLogin = true);
      }
    } catch (e) {
      _toast(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F172A), Color(0xFF1A56DB)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 30)],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('💰', style: TextStyle(fontSize: 42)),
                    Text(isLogin ? 'Masuk' : 'Daftar', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text('Hubungkan ke server CHIKZX', style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                    const SizedBox(height: 20),
                    TextField(
                      controller: urlCtrl,
                      decoration: const InputDecoration(
                        labelText: 'URL Server API',
                        hintText: 'http://192.168.1.10:5000',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.cloud_outlined, size: 20),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (!isLogin) ...[
                      TextField(
                        controller: namaCtrl,
                        decoration: const InputDecoration(labelText: 'Nama Lengkap', border: OutlineInputBorder(), isDense: true),
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: userCtrl,
                      decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder(), isDense: true),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: passCtrl,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder(), isDense: true),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: ElevatedButton(
                        onPressed: loading ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1A56DB),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        child: loading
                            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : Text(isLogin ? 'Masuk' : 'Daftar'),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(() => isLogin = !isLogin),
                      child: Text(isLogin ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Login'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
