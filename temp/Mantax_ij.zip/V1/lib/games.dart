import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';

class GamesPage extends StatefulWidget {
  const GamesPage({super.key});

  @override
  State<GamesPage> createState() => _GamesPageState();
}

class _GamesPageState extends State<GamesPage> {
  int _selectedIndex = 0;
  final List<Widget> _gameWidgets = [
    const TicTacToeGame(),
    const ChessGame(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _gameWidgets[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFF1E3A8A).withOpacity(0.9),
              const Color(0xFF0F172A),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) => setState(() => _selectedIndex = index),
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: const Color(0xFF60A5FA),
          unselectedItemColor: Colors.white70,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.grid_3x3),
              label: 'Tic Tac Toe',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.casino),
              label: 'Catur',
            ),
          ],
        ),
      ),
    );
  }
}

// TIC TAC TOE GAME dengan Bot dan Timer
class TicTacToeGame extends StatefulWidget {
  const TicTacToeGame({super.key});

  @override
  State<TicTacToeGame> createState() => _TicTacToeGameState();
}

class _TicTacToeGameState extends State<TicTacToeGame> {
  String _currentPlayer = 'X';
  List<String> _board = List.filled(9, '');
  String? _winner;
  bool _gameOver = false;
  bool _isPlayingVsBot = false;
  String _botLevel = 'medium'; // low, medium, hard
  
  int _playerScore = 0;
  int _botScore = 0;
  int _draws = 0;
  
  // Timer variables
  int _playerTime = 300; // 5 minutes in seconds
  int _botTime = 300;
  Timer? _timer;
  bool _isPlayerTurn = true;
  
  // Bot difficulty multipliers
  final Map<String, double> _botDifficulty = {
    'low': 0.3,    // 30% chance to make optimal move
    'medium': 0.6, // 60% chance to make optimal move
    'hard': 0.9,   // 90% chance to make optimal move
  };

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_gameOver || !_isPlayingVsBot) return;
      
      setState(() {
        if (_isPlayerTurn) {
          if (_playerTime > 0) {
            _playerTime--;
          } else {
            _gameOver = true;
            _winner = 'O'; // Bot wins by time
            _botScore++;
            _timer?.cancel();
            _showGameOverDialog();
          }
        } else {
          if (_botTime > 0) {
            _botTime--;
          }
        }
      });
    });
  }

  void _makeMove(int index) {
    if (_gameOver || _board[index] != '' || !_isPlayerTurn) return;
    
    setState(() {
      _board[index] = _currentPlayer;
      final winner = _checkWinner(_board);
      final isDraw = !_board.contains('') && winner == null;
      
      if (winner != null || isDraw) {
        _gameOver = true;
        _winner = winner ?? 'Draw';
        _timer?.cancel();
        
        if (winner == 'X') {
          _playerScore++;
        } else if (winner == 'O') {
          _botScore++;
        } else {
          _draws++;
        }
        
        Future.delayed(const Duration(milliseconds: 500), () {
          _showGameOverDialog();
        });
      } else {
        _currentPlayer = 'O';
        _isPlayerTurn = false;
        
        if (_isPlayingVsBot) {
          Future.delayed(const Duration(milliseconds: 500), () {
            _makeBotMove();
          });
        }
      }
    });
  }

  void _makeBotMove() {
    if (_gameOver) return;
    
    final emptyIndices = _board.asMap().entries
        .where((entry) => entry.value == '')
        .map((entry) => entry.key)
        .toList();
    
    if (emptyIndices.isEmpty) return;
    
    int botMoveIndex;
    
    // AI Logic based on difficulty
    if (_botLevel == 'hard' && Random().nextDouble() < _botDifficulty['hard']!) {
      // Hard: Try to win or block player
      botMoveIndex = _findBestMove();
    } else if (_botLevel == 'medium' && Random().nextDouble() < _botDifficulty['medium']!) {
      // Medium: Sometimes optimal, sometimes random
      if (Random().nextBool()) {
        botMoveIndex = _findBestMove();
      } else {
        botMoveIndex = emptyIndices[Random().nextInt(emptyIndices.length)];
      }
    } else {
      // Low: Always random
      botMoveIndex = emptyIndices[Random().nextInt(emptyIndices.length)];
    }
    
    setState(() {
      _board[botMoveIndex] = 'O';
      final winner = _checkWinner(_board);
      final isDraw = !_board.contains('') && winner == null;
      
      if (winner != null || isDraw) {
        _gameOver = true;
        _winner = winner ?? 'Draw';
        _timer?.cancel();
        
        if (winner == 'O') {
          _botScore++;
        } else if (winner == 'X') {
          _playerScore++;
        } else {
          _draws++;
        }
        
        Future.delayed(const Duration(milliseconds: 500), () {
          _showGameOverDialog();
        });
      } else {
        _currentPlayer = 'X';
        _isPlayerTurn = true;
      }
    });
  }

  int _findBestMove() {
    // Check for winning move
    for (int i = 0; i < 9; i++) {
      if (_board[i] == '') {
        List<String> tempBoard = List.from(_board);
        tempBoard[i] = 'O';
        if (_checkWinner(tempBoard) == 'O') {
          return i;
        }
      }
    }
    
    // Check for blocking move
    for (int i = 0; i < 9; i++) {
      if (_board[i] == '') {
        List<String> tempBoard = List.from(_board);
        tempBoard[i] = 'X';
        if (_checkWinner(tempBoard) == 'X') {
          return i;
        }
      }
    }
    
    // Take center if available
    if (_board[4] == '') return 4;
    
    // Take corners
    List<int> corners = [0, 2, 6, 8];
    corners.shuffle();
    for (int corner in corners) {
      if (_board[corner] == '') return corner;
    }
    
    // Take any available
    final emptyIndices = _board.asMap().entries
        .where((entry) => entry.value == '')
        .map((entry) => entry.key)
        .toList();
    return emptyIndices[Random().nextInt(emptyIndices.length)];
  }

  String? _checkWinner(List<String> board) {
    const winningCombinations = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];

    for (final combo in winningCombinations) {
      if (board[combo[0]] != '' &&
          board[combo[0]] == board[combo[1]] &&
          board[combo[0]] == board[combo[2]]) {
        return board[combo[0]];
      }
    }
    return null;
  }

  void _resetGame() {
    _timer?.cancel();
    setState(() {
      _board = List.filled(9, '');
      _currentPlayer = 'X';
      _winner = null;
      _gameOver = false;
      _playerTime = 300;
      _botTime = 300;
      _isPlayerTurn = true;
    });
    _startTimer();
  }

  void _startVsBot(String level) {
    setState(() {
      _isPlayingVsBot = true;
      _botLevel = level;
      _playerScore = 0;
      _botScore = 0;
      _draws = 0;
      _resetGame();
    });
  }

  void _showGameOverDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: Center(
          child: Text(
            _winner == 'Draw' ? 'SERI!' : 'MENANG!',
            style: TextStyle(
              color: _winner == 'X' ? const Color(0xFF60A5FA) : 
                     _winner == 'O' ? const Color(0xFF10B981) : 
                     const Color(0xFFF59E0B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        content: Container(
          width: double.maxFinite,
          child: Text(
            _winner == 'Draw' 
              ? 'Permainan berakhir seri!' 
              : _winner == 'X'
                ? 'Anda menang!'
                : 'Bot menang!',
            style: const TextStyle(color: Colors.white70),
          ),
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _resetGame();
                },
                child: const Text('MAIN LAGI', style: TextStyle(color: Color(0xFF60A5FA))),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _isPlayingVsBot = false;
                  });
                },
                child: const Text('KELUAR', style: TextStyle(color: Color(0xFFEF4444))),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF3B82F6),
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Widget _buildScoreBoard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              const Text('ANDA', style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF60A5FA),
              )),
              const SizedBox(height: 4),
              Text('$_playerScore', style: const TextStyle(
                fontSize: 24,
                color: Colors.white,
              )),
              Text(
                _formatTime(_playerTime),
                style: TextStyle(
                  color: _isPlayerTurn ? const Color(0xFF10B981) : Colors.white70,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          Column(
            children: [
              const Text('SERI', style: TextStyle(
                fontSize: 14,
                color: Color(0xFFF59E0B),
              )),
              const SizedBox(height: 4),
              Text('$_draws', style: const TextStyle(
                fontSize: 20,
                color: Colors.white,
              )),
            ],
          ),
          Column(
            children: [
              Text(
                _isPlayingVsBot ? 'BOT' : 'LAWAN',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF10B981),
                ),
              ),
              const SizedBox(height: 4),
              Text('$_botScore', style: const TextStyle(
                fontSize: 24,
                color: Colors.white,
              )),
              Text(
                _formatTime(_botTime),
                style: TextStyle(
                  color: !_isPlayerTurn ? const Color(0xFFEF4444) : Colors.white70,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGameBoard() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemCount: 9,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () => _makeMove(index),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _board[index] == 'X' 
                  ? const Color(0xFF60A5FA)
                  : _board[index] == 'O'
                  ? const Color(0xFF10B981)
                  : const Color(0xFF334155),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: _board[index].isNotEmpty
                    ? (_board[index] == 'X' 
                        ? const Color(0xFF60A5FA).withOpacity(0.3)
                        : const Color(0xFF10B981).withOpacity(0.3))
                    : Colors.transparent,
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Center(
              child: Text(
                _board[index],
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                  color: _board[index] == 'X' 
                    ? const Color(0xFF60A5FA)
                    : const Color(0xFF10B981),
                  shadows: [
                    Shadow(
                      blurRadius: 10,
                      color: _board[index] == 'X'
                        ? const Color(0xFF60A5FA).withOpacity(0.5)
                        : const Color(0xFF10B981).withOpacity(0.5),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMainMenu() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF1E3A8A),
                    const Color(0xFF0F172A),
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF3B82F6).withOpacity(0.3),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.grid_3x3,
                    size: 64,
                    color: const Color(0xFF60A5FA),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'TIC TAC TOE',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Pilih mode permainan',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 32),
                  
                  Text(
                    'VS BOT',
                    style: TextStyle(
                      color: const Color(0xFF60A5FA),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  _buildDifficultyButton('MUDAH', 'low', const Color(0xFF10B981)),
                  const SizedBox(height: 12),
                  _buildDifficultyButton('SEDANG', 'medium', const Color(0xFFF59E0B)),
                  const SizedBox(height: 12),
                  _buildDifficultyButton('SULIT', 'hard', const Color(0xFFEF4444)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDifficultyButton(String text, String level, Color color) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: () => _startVsBot(level),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 5,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              level == 'low' ? Icons.arrow_circle_down :
              level == 'medium' ? Icons.arrow_circle_right :
              Icons.arrow_circle_up,
              size: 24,
            ),
            const SizedBox(width: 8),
            Text(
              text,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameScreen() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'LEVEL: ${_botLevel.toUpperCase()}',
                      style: TextStyle(
                        color: _botLevel == 'low' ? const Color(0xFF10B981) :
                               _botLevel == 'medium' ? const Color(0xFFF59E0B) :
                               const Color(0xFFEF4444),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _isPlayerTurn ? 'Giliran Anda' : 'Giliran Bot',
                      style: TextStyle(
                        color: _isPlayerTurn ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                Text(
                  'GILIRAN: $_currentPlayer',
                  style: TextStyle(
                    color: _currentPlayer == 'X' 
                      ? const Color(0xFF60A5FA)
                      : const Color(0xFF10B981),
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _isPlayingVsBot = false;
                      _resetGame();
                    });
                  },
                  icon: const Icon(Icons.exit_to_app, color: Color(0xFFEF4444)),
                  tooltip: 'Kembali ke Menu',
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          
          _buildScoreBoard(),
          const SizedBox(height: 20),
          
          Expanded(
            child: _buildGameBoard(),
          ),
          const SizedBox(height: 20),
          
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _resetGame,
              icon: const Icon(Icons.refresh),
              label: const Text('ULANGI PERMAINAN'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF59E0B),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: !_isPlayingVsBot ? _buildMainMenu() : _buildGameScreen(),
    );
  }
}

// CHESS GAME dengan Bot dan Timer
class ChessGame extends StatefulWidget {
  const ChessGame({super.key});

  @override
  State<ChessGame> createState() => _ChessGameState();
}

class _ChessGameState extends State<ChessGame> {
  String _botLevel = 'medium'; // low, medium, hard
  bool _isPlayingVsBot = false;
  bool _isWhite = true;
  bool _isPlayerTurn = true;
  bool _gameOver = false;
  String _winner = '';
  
  int _playerScore = 0;
  int _botScore = 0;
  int _draws = 0;
  
  // Timer variables
  int _playerTime = 600; // 10 minutes in seconds
  int _botTime = 600;
  Timer? _timer;
  
  List<List<String>> _board = [
    ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
    ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
    ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
  ];
  
  List<List<bool>> _possibleMoves = List.generate(8, (_) => List.filled(8, false));
  int? _selectedRow;
  int? _selectedCol;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_gameOver || !_isPlayingVsBot) return;
      
      setState(() {
        if (_isPlayerTurn) {
          if (_playerTime > 0) {
            _playerTime--;
          } else {
            _gameOver = true;
            _winner = 'Bot'; // Bot wins by time
            _botScore++;
            _timer?.cancel();
            _showGameOverDialog();
          }
        } else {
          if (_botTime > 0) {
            _botTime--;
          } else {
            _gameOver = true;
            _winner = 'Player'; // Player wins by time
            _playerScore++;
            _timer?.cancel();
            _showGameOverDialog();
          }
        }
      });
    });
  }

  void _selectPiece(int row, int col) {
    if (_gameOver || !_isPlayerTurn) return;
    
    final piece = _board[row][col];
    if (piece.isEmpty) return;
    
    final isWhitePiece = piece == piece.toUpperCase();
    if ((_isWhite && !isWhitePiece) || (!_isWhite && isWhitePiece)) {
      _showMessage('Ini bukan bidakmu!');
      return;
    }

    setState(() {
      _selectedRow = row;
      _selectedCol = col;
      _calculatePossibleMoves(row, col);
    });
  }

  void _calculatePossibleMoves(int row, int col) {
    _possibleMoves = List.generate(8, (_) => List.filled(8, false));
    final piece = _board[row][col].toLowerCase();
    
    // Simplified move calculation for demo
    switch (piece) {
      case 'p': // Pawn
        final direction = _board[row][col] == 'P' ? -1 : 1;
        if (_isInBoard(row + direction, col) && _board[row + direction][col].isEmpty) {
          _possibleMoves[row + direction][col] = true;
        }
        // Capture diagonally
        if (_isInBoard(row + direction, col - 1) && _board[row + direction][col - 1].isNotEmpty) {
          _possibleMoves[row + direction][col - 1] = true;
        }
        if (_isInBoard(row + direction, col + 1) && _board[row + direction][col + 1].isNotEmpty) {
          _possibleMoves[row + direction][col + 1] = true;
        }
        break;
      case 'r': // Rook
        _calculateRookMoves(row, col);
        break;
      case 'n': // Knight
        _calculateKnightMoves(row, col);
        break;
      case 'b': // Bishop
        _calculateBishopMoves(row, col);
        break;
      case 'q': // Queen
        _calculateRookMoves(row, col);
        _calculateBishopMoves(row, col);
        break;
      case 'k': // King
        _calculateKingMoves(row, col);
        break;
    }
  }

  void _calculateRookMoves(int row, int col) {
    const directions = [[-1, 0], [1, 0], [0, -1], [0, 1]];
    
    for (final dir in directions) {
      var r = row + dir[0];
      var c = col + dir[1];
      while (_isInBoard(r, c)) {
        if (_board[r][c].isEmpty) {
          _possibleMoves[r][c] = true;
        } else {
          if (_isOpponentPiece(row, col, r, c)) {
            _possibleMoves[r][c] = true;
          }
          break;
        }
        r += dir[0];
        c += dir[1];
      }
    }
  }

  void _calculateBishopMoves(int row, int col) {
    const directions = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
    
    for (final dir in directions) {
      var r = row + dir[0];
      var c = col + dir[1];
      while (_isInBoard(r, c)) {
        if (_board[r][c].isEmpty) {
          _possibleMoves[r][c] = true;
        } else {
          if (_isOpponentPiece(row, col, r, c)) {
            _possibleMoves[r][c] = true;
          }
          break;
        }
        r += dir[0];
        c += dir[1];
      }
    }
  }

  void _calculateKnightMoves(int row, int col) {
    const moves = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1]
    ];
    
    for (final move in moves) {
      final r = row + move[0];
      final c = col + move[1];
      if (_isInBoard(r, c) && 
          (_board[r][c].isEmpty || _isOpponentPiece(row, col, r, c))) {
        _possibleMoves[r][c] = true;
      }
    }
  }

  void _calculateKingMoves(int row, int col) {
    const moves = [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, -1], [1, 0], [1, 1]
    ];
    
    for (final move in moves) {
      final r = row + move[0];
      final c = col + move[1];
      if (_isInBoard(r, c) && 
          (_board[r][c].isEmpty || _isOpponentPiece(row, col, r, c))) {
        _possibleMoves[r][c] = true;
      }
    }
  }

  bool _isInBoard(int row, int col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
  }

  bool _isOpponentPiece(int fromRow, int fromCol, int toRow, int toCol) {
    final fromPiece = _board[fromRow][fromCol];
    final toPiece = _board[toRow][toCol];
    if (toPiece.isEmpty) return false;
    
    final fromIsWhite = fromPiece == fromPiece.toUpperCase();
    final toIsWhite = toPiece == toPiece.toUpperCase();
    return fromIsWhite != toIsWhite;
  }

  void _makeMove(int toRow, int toCol) {
    if (_selectedRow == null || _selectedCol == null || !_possibleMoves[toRow][toCol]) {
      return;
    }

    if (_gameOver || !_isPlayerTurn) return;

    setState(() {
      final capturedPiece = _board[toRow][toCol];
      
      // Check for checkmate (simplified)
      if (capturedPiece.toLowerCase() == 'k') {
        _gameOver = true;
        _winner = _board[_selectedRow!][_selectedCol!] == _board[_selectedRow!][_selectedCol!].toUpperCase() 
            ? 'Player' 
            : 'Bot';
        
        if (_winner == 'Player') {
          _playerScore++;
        } else {
          _botScore++;
        }
        
        _timer?.cancel();
        Future.delayed(const Duration(milliseconds: 500), () {
          _showGameOverDialog();
        });
      }

      _board[toRow][toCol] = _board[_selectedRow!][_selectedCol!];
      _board[_selectedRow!][_selectedCol!] = '';

      _selectedRow = null;
      _selectedCol = null;
      _possibleMoves = List.generate(8, (_) => List.filled(8, false));
      
      if (_isPlayingVsBot) {
        _isPlayerTurn = false;
        Future.delayed(const Duration(milliseconds: 500), () {
          _makeBotMove();
        });
      }
    });
  }

  void _makeBotMove() {
    if (_gameOver) return;
    
    // Find all possible moves for bot
    List<Map<String, dynamic>> allMoves = [];
    
    for (int row = 0; row < 8; row++) {
      for (int col = 0; col < 8; col++) {
        final piece = _board[row][col];
        if (piece.isNotEmpty && piece != piece.toUpperCase()) { // Bot is black (lowercase)
          _calculatePossibleMoves(row, col);
          for (int toRow = 0; toRow < 8; toRow++) {
            for (int toCol = 0; toCol < 8; toCol++) {
              if (_possibleMoves[toRow][toCol]) {
                allMoves.add({
                  'fromRow': row,
                  'fromCol': col,
                  'toRow': toRow,
                  'toCol': toCol,
                  'piece': piece,
                  'capture': _board[toRow][toCol].isNotEmpty,
                  'isKing': _board[toRow][toCol].toLowerCase() == 'k',
                });
              }
            }
          }
        }
      }
    }
    
    if (allMoves.isEmpty) return;
    
    Map<String, dynamic> selectedMove;
    
    // Bot logic based on difficulty
    if (_botLevel == 'hard') {
      // Hard: Prefer captures and center control
      final captures = allMoves.where((move) => move['capture']).toList();
      if (captures.isNotEmpty) {
        captures.shuffle();
        selectedMove = captures.first;
      } else {
        allMoves.shuffle();
        selectedMove = allMoves.first;
      }
    } else if (_botLevel == 'medium') {
      // Medium: Sometimes capture, sometimes random
      final captures = allMoves.where((move) => move['capture']).toList();
      if (captures.isNotEmpty && Random().nextBool()) {
        captures.shuffle();
        selectedMove = captures.first;
      } else {
        allMoves.shuffle();
        selectedMove = allMoves.first;
      }
    } else {
      // Low: Always random
      allMoves.shuffle();
      selectedMove = allMoves.first;
    }
    
    setState(() {
      final capturedPiece = _board[selectedMove['toRow']][selectedMove['toCol']];
      
      if (capturedPiece.toLowerCase() == 'k') {
        _gameOver = true;
        _winner = 'Bot';
        _botScore++;
        _timer?.cancel();
        Future.delayed(const Duration(milliseconds: 500), () {
          _showGameOverDialog();
        });
      }
      
      _board[selectedMove['toRow']][selectedMove['toCol']] = _board[selectedMove['fromRow']][selectedMove['fromCol']];
      _board[selectedMove['fromRow']][selectedMove['fromCol']] = '';
      
      _isPlayerTurn = true;
    });
  }

  void _resetGame() {
    _timer?.cancel();
    setState(() {
      _board = [
        ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
        ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['', '', '', '', '', '', '', ''],
        ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
        ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
      ];
      _playerTime = 600;
      _botTime = 600;
      _gameOver = false;
      _winner = '';
      _selectedRow = null;
      _selectedCol = null;
      _possibleMoves = List.generate(8, (_) => List.filled(8, false));
      _isPlayerTurn = true;
    });
    _startTimer();
  }

  void _startVsBot(String level) {
    setState(() {
      _isPlayingVsBot = true;
      _botLevel = level;
      _playerScore = 0;
      _botScore = 0;
      _draws = 0;
      _resetGame();
    });
  }

  void _showGameOverDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: Center(
          child: Text(
            _winner == 'Draw' ? 'SERI!' : 'CHECKMATE!',
            style: TextStyle(
              color: _winner == 'Player' ? const Color(0xFF60A5FA) : 
                     _winner == 'Bot' ? const Color(0xFFEF4444) : 
                     const Color(0xFFF59E0B),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        content: Container(
          width: double.maxFinite,
          child: Text(
            _winner == 'Draw' 
              ? 'Permainan berakhir seri!' 
              : '${_winner == 'Player' ? 'Anda' : 'Bot'} memenangkan permainan!',
            style: const TextStyle(color: Colors.white70),
          ),
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _resetGame();
                },
                child: const Text('MAIN LAGI', style: TextStyle(color: Color(0xFF60A5FA))),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _isPlayingVsBot = false;
                  });
                },
                child: const Text('KELUAR', style: TextStyle(color: Color(0xFFEF4444))),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF3B82F6),
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Widget _buildChessBoard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 8,
        ),
        itemCount: 64,
        itemBuilder: (context, index) {
          final row = index ~/ 8;
          final col = index % 8;
          final isWhite = (row + col) % 2 == 0;
          final piece = _board[row][col];
          final isSelected = row == _selectedRow && col == _selectedCol;
          final isPossibleMove = _possibleMoves[row][col];

          return GestureDetector(
            onTap: () {
              if (_possibleMoves[row][col]) {
                _makeMove(row, col);
              } else {
                _selectPiece(row, col);
              }
            },
            child: Container(
              decoration: BoxDecoration(
                color: isSelected
                  ? const Color(0xFF3B82F6).withOpacity(0.5)
                  : isPossibleMove
                  ? const Color(0xFF10B981).withOpacity(0.3)
                  : isWhite
                  ? const Color(0xFFF0D9B5)
                  : const Color(0xFFB58863),
                border: Border.all(
                  color: isSelected
                    ? const Color(0xFF3B82F6)
                    : Colors.transparent,
                  width: 2,
                ),
              ),
              child: piece.isNotEmpty
                ? Center(
                    child: Text(
                      _getPieceSymbol(piece),
                      style: TextStyle(
                        fontSize: 30,
                        color: piece == piece.toUpperCase()
                          ? const Color(0xFFF0F0F0)
                          : const Color(0xFF1E293B),
                        fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(
                            blurRadius: 2,
                            color: Colors.black.withOpacity(0.5),
                          ),
                        ],
                      ),
                    ),
                  )
                : null,
            ),
          );
        },
      ),
    );
  }

  String _getPieceSymbol(String piece) {
    switch (piece.toLowerCase()) {
      case 'k': return '♔';
      case 'q': return '♕';
      case 'r': return '♖';
      case 'b': return '♗';
      case 'n': return '♘';
      case 'p': return '♙';
      default: return '';
    }
  }

  Widget _buildMainMenu() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF0F172A),
                    const Color(0xFF1E293B),
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF3B82F6).withOpacity(0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.casino,
                    size: 64,
                    color: const Color(0xFFF0D9B5),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'CATUR',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Pilih mode permainan',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 32),
                  
                  Text(
                    'VS BOT',
                    style: TextStyle(
                      color: const Color(0xFFF0D9B5),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  _buildDifficultyButton('MUDAH', 'low', const Color(0xFF10B981)),
                  const SizedBox(height: 12),
                  _buildDifficultyButton('SEDANG', 'medium', const Color(0xFFF59E0B)),
                  const SizedBox(height: 12),
                  _buildDifficultyButton('SULIT', 'hard', const Color(0xFFEF4444)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDifficultyButton(String text, String level, Color color) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: () => _startVsBot(level),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 5,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              level == 'low' ? Icons.arrow_circle_down :
              level == 'medium' ? Icons.arrow_circle_right :
              Icons.arrow_circle_up,
              size: 24,
            ),
            const SizedBox(width: 8),
            Text(
              text,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreBoard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              Text(
                _isWhite ? 'PUTIH' : 'HITAM',
                style: const TextStyle(
                  color: Color(0xFFF0D9B5),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text('$_playerScore', style: const TextStyle(
                fontSize: 24,
                color: Colors.white,
              )),
              Text(
                _formatTime(_playerTime),
                style: TextStyle(
                  color: _isPlayerTurn ? const Color(0xFF10B981) : Colors.white70,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          Column(
            children: [
              const Text('SERI', style: TextStyle(
                color: Color(0xFFF59E0B),
              )),
              const SizedBox(height: 4),
              Text('$_draws', style: const TextStyle(
                fontSize: 20,
                color: Colors.white,
              )),
            ],
          ),
          Column(
            children: [
              Text(
                'BOT',
                style: const TextStyle(
                  color: Color(0xFFB58863),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text('$_botScore', style: const TextStyle(
                fontSize: 24,
                color: Colors.white,
              )),
              Text(
                _formatTime(_botTime),
                style: TextStyle(
                  color: !_isPlayerTurn ? const Color(0xFFEF4444) : Colors.white70,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGameScreen() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'LEVEL: ${_botLevel.toUpperCase()}',
                      style: TextStyle(
                        color: _botLevel == 'low' ? const Color(0xFF10B981) :
                               _botLevel == 'medium' ? const Color(0xFFF59E0B) :
                               const Color(0xFFEF4444),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      _isPlayerTurn ? 'Giliran Anda' : 'Giliran Bot',
                      style: TextStyle(
                        color: _isPlayerTurn ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        setState(() {
                          _isPlayingVsBot = false;
                          _resetGame();
                        });
                      },
                      icon: const Icon(Icons.exit_to_app, color: Color(0xFFEF4444)),
                      tooltip: 'Kembali ke Menu',
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          
          _buildScoreBoard(),
          
          const SizedBox(height: 20),
          
          Expanded(child: _buildChessBoard()),
          
          const SizedBox(height: 20),
          
          Column(
            children: [
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _resetGame,
                  icon: const Icon(Icons.refresh),
                  label: const Text('ULANGI PERMAINAN'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF59E0B),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: !_isPlayingVsBot ? _buildMainMenu() : _buildGameScreen(),
    );
  }
}