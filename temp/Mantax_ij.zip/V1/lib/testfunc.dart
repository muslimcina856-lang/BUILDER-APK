import 'dart:convert';
import 'dart:ui';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'tipep/.dart';
final baseUrl = Api.api;

class TestFunctionPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final String expiredDate;

  const TestFunctionPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.expiredDate,
  }) : super(key: key);

  @override
  State<TestFunctionPage> createState() => _TestFunctionPageState();
}

class _TestFunctionPageState extends State<TestFunctionPage> {
  final TextEditingController targetController = TextEditingController();
  final TextEditingController functionController = TextEditingController();
  final TextEditingController delayController = TextEditingController(text: '1000');
  final TextEditingController jumlahController = TextEditingController(text: '1');

  bool _isTesting = false;
  String? _testResponseMessage;
  int _successCount = 0;
  int _failCount = 0;
  final List<String> _errorMessages = <String>[];
  String _currentStatus = '';
  String? _pickedFileName;

  static const Color bg = Color(0xFF0B1014);
  static const Color panel = Color(0xFF171C22);
  static const Color field = Color(0xFF151A20);
  static const Color cyan = Color(0xFF03BCD4);
  static const Color cyanDark = Color(0xFF002E34);
  static const Color border = Color(0xFF2A323A);
  static const Color text = Color(0xFFE9EEF2);
  static const Color muted = Color(0xFF9BA4AA);
  static const Color danger = Color(0xFFE65353);

  @override
  void dispose() {
    targetController.dispose();
    functionController.dispose();
    delayController.dispose();
    jumlahController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final String cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.startsWith('+') && cleaned.length >= 8) return cleaned;
    if (cleaned.startsWith('62') && cleaned.length >= 8) return '+$cleaned';
    return null;
  }

  Future<void> _pickJsFile() async {
    try {
      const XTypeGroup jsGroup = XTypeGroup(
        label: 'JavaScript / Text',
        extensions: <String>['js', 'txt'],
      );

      final XFile? file = await openFile(
        acceptedTypeGroups: <XTypeGroup>[jsGroup],
      );

      if (file == null) return;

      final List<int> bytes = await file.readAsBytes();
      final String content = utf8.decode(bytes, allowMalformed: true);

      if (!mounted) return;
      setState(() {
        _pickedFileName = file.name;
        functionController.text = content;
      });
    } catch (e) {
      _showAlert('File Error', 'Gagal memilih file: $e');
    }
  }

  Future<void> _testFunction() async {
    final String rawInput = targetController.text.trim();
    final String? target = formatPhoneNumber(rawInput);
    final int jumlah = int.tryParse(jumlahController.text) ?? 1;
    final int delay = int.tryParse(delayController.text) ?? 1000;

    if (target == null) {
      _showAlert('Invalid Number', 'Gunakan format nomor internasional, contoh: 62xxxxxxxxxx');
      return;
    }

    if (functionController.text.trim().isEmpty) {
      _showAlert('No Function', 'Paste function atau pilih file .js terlebih dahulu.');
      return;
    }

    if (delay < 0) {
      _showAlert('Invalid Delay', 'Delay tidak boleh minus.');
      return;
    }

    if (jumlah <= 0 || jumlah > 1000) {
      _showAlert('Invalid Loops', 'Jumlah loops harus antara 1 - 1000.');
      return;
    }

    setState(() {
      _isTesting = true;
      _testResponseMessage = null;
      _successCount = 0;
      _failCount = 0;
      _errorMessages.clear();
      _currentStatus = 'Mengirim...';
    });

    try {
      final http.Response response = await http.post(
        Uri.parse('$baseUrl/testFunction'),
        headers: <String, String>{'Content-Type': 'application/json'},
        body: jsonEncode(<String, dynamic>{
          'key': widget.sessionKey,
          'target': target,
          'jumlah': jumlah,
          'delay': delay,
          'functionCode': functionController.text,
          'username': widget.username,
          'role': widget.role,
        }),
      );

      final Map<String, dynamic> data = jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;
      setState(() {
        if (data['success'] == true) {
          _successCount = data['successCount'] as int? ?? 0;
          _failCount = data['failCount'] as int? ?? 0;
          if (data['errors'] != null) {
            _errorMessages.addAll(List<String>.from(data['errors'] as List));
          }
          _testResponseMessage = data['message'] as String? ?? 'Function selesai dikirim';
          _currentStatus = _failCount == 0 ? 'Berhasil' : 'Selesai dengan error';
        } else {
          _testResponseMessage = data['message'] as String? ?? 'Gagal menjalankan function';
          _currentStatus = 'Gagal';
        }
        _isTesting = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _testResponseMessage = 'Error: $e';
        _currentStatus = 'Error';
        _isTesting = false;
      });
    }
  }

  void _clearFunction() {
    setState(() {
      functionController.clear();
      _pickedFileName = null;
    });
  }

  void _resetAll() {
    setState(() {
      targetController.clear();
      functionController.clear();
      delayController.text = '1000';
      jumlahController.text = '1';
      _pickedFileName = null;
      _testResponseMessage = null;
      _successCount = 0;
      _failCount = 0;
      _errorMessages.clear();
      _currentStatus = '';
    });
  }

  void _showAlert(String title, String msg) {
    showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: AlertDialog(
            backgroundColor: panel,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: const BorderSide(color: border),
            ),
            title: Text(title, style: const TextStyle(color: text, fontWeight: FontWeight.w700)),
            content: Text(msg, style: const TextStyle(color: muted)),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK', style: TextStyle(color: cyan)),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _topBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 12, 0, 22),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: () => Navigator.maybePop(context),
            icon: const Icon(Icons.arrow_back, color: text, size: 26),
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'TES FUNC',
              style: TextStyle(
                color: text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.1,
              ),
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.history, color: text, size: 25),
          ),
        ],
      ),
    );
  }

  Widget _heroCard() {
    return Container(
      height: 115,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF06373D), Color(0xFF0B2227)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF0C5660), width: 1),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: cyan.withOpacity(0.12),
            blurRadius: 22,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[Color(0xFF0CD0E5), Color(0xFF0699AD)],
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(color: cyan.withOpacity(0.35), blurRadius: 25, spreadRadius: 3),
              ],
            ),
            child: const Icon(Icons.code, color: Colors.white, size: 31),
          ),
          const SizedBox(width: 20),
          const Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Test Function',
                  style: TextStyle(color: text, fontSize: 19, fontWeight: FontWeight.w800),
                ),
                SizedBox(height: 8),
                Text(
                  'Kirim function custom dengan delay & loops',
                  style: TextStyle(color: muted, fontSize: 13.5, height: 1.2),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _label(String label) {
    return Padding(
      padding: const EdgeInsets.only(top: 26, bottom: 12),
      child: Text(
        label,
        style: const TextStyle(color: text, fontSize: 16.5, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _inputBox({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    int minLines = 1,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      minLines: minLines,
      maxLines: maxLines,
      keyboardType: keyboardType,
      cursorColor: cyan,
      style: const TextStyle(color: text, fontSize: 15.5, letterSpacing: 0.3),
      decoration: InputDecoration(
        filled: true,
        fillColor: field,
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFF8B9298), fontSize: 15),
        prefixIcon: Padding(
          padding: EdgeInsets.only(top: maxLines > 1 ? 16 : 0),
          child: Icon(icon, color: cyan, size: 23),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 58),
        contentPadding: EdgeInsets.fromLTRB(0, maxLines > 1 ? 22 : 20, 18, maxLines > 1 ? 22 : 20),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: border, width: 1.2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFF0C6670), width: 1.4),
        ),
      ),
    );
  }

  Widget _fileRow() {
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Row(
        children: <Widget>[
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: _pickJsFile,
              child: Container(
                height: 55,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: cyanDark.withOpacity(0.72),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF0A5964), width: 1.2),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const Icon(Icons.upload_file_outlined, color: Color(0xFF2396A4), size: 21),
                    const SizedBox(width: 9),
                    Flexible(
                      child: Text(
                        _pickedFileName == null ? 'Pilih file js' : _pickedFileName!,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Color(0xFF2396A4), fontSize: 15.5, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: _clearFunction,
            child: Container(
              width: 78,
              height: 55,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFF230F14),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: danger.withOpacity(0.35), width: 1),
              ),
              child: const Text('Clear', style: TextStyle(color: danger, fontSize: 14.5, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _smallInput({
    required String title,
    required TextEditingController controller,
    required IconData icon,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: const TextStyle(color: text, fontSize: 15.8, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            cursorColor: cyan,
            style: const TextStyle(color: text, fontSize: 15.5),
            decoration: InputDecoration(
              filled: true,
              fillColor: field,
              prefixIcon: Icon(icon, color: cyan, size: 23),
              prefixIconConstraints: const BoxConstraints(minWidth: 58),
              contentPadding: const EdgeInsets.symmetric(vertical: 20),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(13),
                borderSide: const BorderSide(color: border, width: 1.2),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(13),
                borderSide: const BorderSide(color: Color(0xFF0C6670), width: 1.4),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sendRow() {
    return Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Row(
        children: <Widget>[
          Expanded(
            child: SizedBox(
              height: 66,
              child: ElevatedButton(
                onPressed: _isTesting ? null : _testFunction,
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: cyan,
                  disabledBackgroundColor: cyan.withOpacity(0.45),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: _isTesting
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.6),
                          ),
                          const SizedBox(width: 12),
                          Text(_currentStatus, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(Icons.send_rounded, color: Colors.white, size: 22),
                          SizedBox(width: 12),
                          Text(
                            'KIRIM FUNCTION',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15.5, letterSpacing: 1.1),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(width: 20),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _resetAll,
            child: Container(
              width: 74,
              height: 74,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFF210E14),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: danger.withOpacity(0.35)),
              ),
              child: const Icon(Icons.refresh_rounded, color: danger, size: 28),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoCard() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 36),
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: border, width: 1.2),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.info_outline, color: cyan, size: 22),
              SizedBox(width: 14),
              Text('informasi', style: TextStyle(color: text, fontSize: 16, fontWeight: FontWeight.w700)),
            ],
          ),
          SizedBox(height: 20),
          Text('• Gunakan format nomor internasional (62xxx)', style: TextStyle(color: muted, fontSize: 13.4, height: 1.55)),
          Text('• File .js akan dibaca sebagai plain text', style: TextStyle(color: muted, fontSize: 13.4, height: 1.55)),
          Text('• Delay dalam milidetik (ms)', style: TextStyle(color: muted, fontSize: 13.4, height: 1.55)),
          Text('• Loops menentukan jumlah pengiriman', style: TextStyle(color: muted, fontSize: 13.4, height: 1.55)),
          Text('• Function akan dikirim sebagai payload', style: TextStyle(color: muted, fontSize: 13.4, height: 1.55)),
        ],
      ),
    );
  }

  Widget _resultCard() {
    if (_testResponseMessage == null && !_isTesting) return const SizedBox.shrink();

    final bool ok = _failCount == 0;
    final Color resultColor = ok ? Colors.greenAccent : danger;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 22),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: resultColor.withOpacity(0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(ok ? Icons.check_circle_outline : Icons.error_outline, color: resultColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _testResponseMessage ?? _currentStatus,
                  style: TextStyle(color: resultColor, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          if (_successCount > 0 || _failCount > 0) ...<Widget>[
            const SizedBox(height: 10),
            Text('Sukses: $_successCount   Gagal: $_failCount', style: const TextStyle(color: muted)),
          ],
          if (_errorMessages.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            ..._errorMessages.map((String e) => Text('• $e', style: const TextStyle(color: danger, fontSize: 12))).toList(),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(25, 0, 25, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _topBar(context),
              _heroCard(),
              _label('Nomor Target'),
              _inputBox(
                controller: targetController,
                hint: '62xxx (contoh: 6281234567890)',
                icon: Icons.phone,
                keyboardType: TextInputType.phone,
              ),
              _label('Function / Message'),
              _inputBox(
                controller: functionController,
                hint: 'Paste function atau message di sini...',
                icon: Icons.code_rounded,
                minLines: 8,
                maxLines: 10,
                keyboardType: TextInputType.multiline,
              ),
              _fileRow(),
              const SizedBox(height: 44),
              Row(
                children: <Widget>[
                  _smallInput(title: 'Delay (ms)', controller: delayController, icon: Icons.timer_rounded),
                  const SizedBox(width: 20),
                  _smallInput(title: 'jumlah Loops', controller: jumlahController, icon: Icons.repeat_rounded),
                ],
              ),
              _sendRow(),
              _resultCard(),
              _infoCard(),
            ],
          ),
        ),
      ),
    );
  }
}
