import 'dart:convert';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import 'tipep/.dart';

final baseUrl = Api.api;

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  final TextEditingController _joinController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  late AnimationController _glowController;
  late AnimationController _pulseController;
  late AnimationController _rotateController;
  late Animation<double> _glow;
  late Animation<double> _pulse;
  late Animation<double> _rotate;

  VideoPlayerController? _videoController;
  bool _videoReady = false;

  bool _loading = true;
  bool _joining = false;
  bool _sending = false;
  bool _hasSender = false;
  String _statusText = 'No sender connected';
  String? _selectedGroupId;
  String? _selectedGroupName;
  String _selectedBug = 'delay';
  Map<String, dynamic>? _sender;
  List<Map<String, dynamic>> _groups = [];

  final Color _bg = const Color(0xFF080C16);
  final Color _nav = const Color(0xFF14182A);
  final Color _card = const Color(0xFF0E1017);
  final Color _field = const Color(0xFF090B11);
  final Color _red = const Color(0xFFE10D1A);
  final Color _redDark = const Color(0xFF7F0711);
  final Color _muted = const Color(0xFF8A8E99);
  final Color _line = const Color(0xFF202637);

  @override
  void initState() {
    super.initState();
    _initAnim();
    _initVideo();
    _fetchGroups();
    _searchController.addListener(() => setState(() {}));
  }

  void _initAnim() {
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
    _rotateController = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _glow = Tween<double>(begin: .35, end: 1).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _pulse = Tween<double>(begin: .96, end: 1.05).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
    _rotate = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _rotateController, curve: Curves.linear));
  }

  void _initVideo() {
    final c = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController = c;
    c.initialize().then((_) {
      if (!mounted) return;
      c
        ..setLooping(true)
        ..setVolume(0)
        ..play();
      setState(() => _videoReady = true);
    }).catchError((_) {});
  }

  Uri _api(String path, Map<String, String> query) {
    final base = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    return Uri.parse('$base/api/whatsapp/$path').replace(queryParameters: query);
  }

  Future<void> _fetchGroups() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _selectedGroupId = null;
      _selectedGroupName = null;
    });

    try {
      final res = await http.get(_api('groupStatus', {'key': widget.sessionKey})).timeout(const Duration(seconds: 20));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final raw = data['groups'];
      final parsed = raw is List ? raw.map((e) => Map<String, dynamic>.from(e as Map)).toList() : <Map<String, dynamic>>[];

      if (!mounted) return;
      setState(() {
        _hasSender = data['hasSender'] == true;
        _sender = data['sender'] is Map ? Map<String, dynamic>.from(data['sender']) : null;
        _groups = parsed;
        _statusText = data['message']?.toString() ?? (_hasSender ? 'Sender connected' : 'No sender connected');
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _hasSender = false;
        _groups = [];
        _statusText = 'No sender connected';
        _loading = false;
      });
    }
  }

  bool _validInvite(String v) {
    return RegExp(r'^(https?:\/\/)?chat\.whatsapp\.com\/[A-Za-z0-9]{20,30}$').hasMatch(v.trim());
  }

  Future<void> _joinGroup() async {
    if (_joining) return;
    final link = _joinController.text.trim();

    if (!_hasSender) {
      _toast('No sender connected. Pair sender user dulu.');
      return;
    }
    if (!_validInvite(link)) {
      _toast('Masukkan link group WhatsApp yang benar.');
      return;
    }

    setState(() => _joining = true);
    try {
      final res = await http.get(_api('joinGroup', {
        'key': widget.sessionKey,
        'linkGroup': link,
      })).timeout(const Duration(seconds: 45));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && data['success'] == true) {
        _joinController.clear();
        await _fetchGroups();
        final g = data['group'];
        if (g is Map && g['id'] != null && mounted) {
          setState(() {
            _selectedGroupId = g['id'].toString();
            _selectedGroupName = (g['subject'] ?? 'Unknown Group').toString();
          });
        }
        _toast(data['message']?.toString() ?? 'Group berhasil join dan sudah kebaca di list.');
      } else {
        _alert('FAILED', data['message']?.toString() ?? 'Gagal join group.');
      }
    } catch (_) {
      _alert('CONNECTION ERROR', 'Backend tidak merespons.');
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  Future<void> _sendSelectedBug() async {
    if (_sending) return;
    if (!_hasSender) {
      _toast('No sender connected. Pair sender user dulu.');
      return;
    }
    if (_groups.isEmpty) {
      _toast('Sender ada, tapi belum ada group. Join group dulu.');
      return;
    }
    if (_selectedGroupId == null) {
      _toast('Pilih group dulu.');
      return;
    }

    setState(() => _sending = true);
    try {
      final res = await http.get(_api('raidgroup', {
        'key': widget.sessionKey,
        'groupJid': _selectedGroupId!,
        'bug': _selectedBug,
      })).timeout(const Duration(seconds: 35));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && data['success'] == true) {
        _success(data);
      } else {
        _alert('FAILED', data['message']?.toString() ?? 'Request gagal dikirim.');
      }
    } catch (_) {
      _alert('CONNECTION ERROR', 'Backend tidak merespons.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _card,
      behavior: SnackBarBehavior.floating,
      content: Text(msg, style: const TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w800)),
    ));
  }

  void _alert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: _red.withOpacity(.45))),
        title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, letterSpacing: 1.6)),
        content: Text(msg, style: TextStyle(color: Colors.white.withOpacity(.7), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700)),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('OK', style: TextStyle(color: _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900)))],
      ),
    );
  }

  void _success(Map<String, dynamic> data) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(color: _card.withOpacity(.96), borderRadius: BorderRadius.circular(26), border: Border.all(color: _red.withOpacity(.5)), boxShadow: [BoxShadow(color: _red.withOpacity(.25), blurRadius: 36, spreadRadius: 3)]),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 74, height: 74, decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.15), border: Border.all(color: _red)), child: const Icon(Icons.done_rounded, color: Colors.white, size: 42)),
                  const SizedBox(height: 16),
                  const Text('DELAY SENT', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: 2.5)),
                  const SizedBox(height: 14),
                  _detail('Group', data['groupName']?.toString() ?? _selectedGroupName ?? '-'),
                  _detail('Sender', data['sender']?.toString() ?? _sender?['sessionName']?.toString() ?? '-'),
                  _detail('Bug', _selectedBug),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(backgroundColor: _red, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                      child: const Text('CLOSE', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, letterSpacing: 2)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _detail(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        SizedBox(width: 72, child: Text(k, style: TextStyle(color: _muted, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700))),
        Expanded(child: Text(v, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900))),
      ]),
    );
  }

  List<Map<String, dynamic>> get _visibleGroups {
    final q = _searchController.text.trim().toLowerCase();
    if (q.isEmpty) return _groups;
    return _groups.where((g) => (g['subject']?.toString().toLowerCase() ?? '').contains(q)).toList();
  }

  Widget _background() {
    return Stack(children: [
      Container(color: _bg),
      if (_videoReady && _videoController != null)
        Positioned.fill(
          child: Opacity(
            opacity: .035,
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(width: _videoController!.value.size.width, height: _videoController!.value.size.height, child: VideoPlayer(_videoController!)),
            ),
          ),
        ),
      Positioned.fill(child: Container(decoration: BoxDecoration(gradient: RadialGradient(center: const Alignment(.9, .95), radius: 1.2, colors: [_red.withOpacity(.09), Colors.transparent])))),
      AnimatedBuilder(
        animation: _rotate,
        builder: (_, __) => Positioned(right: -110, bottom: -90, child: Transform.rotate(angle: _rotate.value * pi * 2, child: Container(width: 250, height: 250, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _red.withOpacity(.09), width: 2))))),
      ),
    ]);
  }

  Widget _topBar() {
    return Container(
      height: 84,
      padding: const EdgeInsets.fromLTRB(16, 30, 12, 8),
      color: const Color(0xFF131722).withOpacity(.98),
      child: Row(children: [
        Icon(Icons.menu_rounded, color: Colors.white.withOpacity(.9), size: 28),
        const Spacer(),
        const Text('TAXONE', style: TextStyle(color: Colors.white, fontSize: 23, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, letterSpacing: 1.4)),
        const Spacer(),
        Icon(Icons.headphones_rounded, color: Colors.white.withOpacity(.9), size: 23),
        const SizedBox(width: 20),
        Icon(Icons.music_note_rounded, color: Colors.white.withOpacity(.9), size: 24),
        const SizedBox(width: 20),
        Icon(Icons.notifications_rounded, color: Colors.white.withOpacity(.9), size: 23),
        const SizedBox(width: 18),
        Icon(Icons.logout_rounded, color: Colors.white.withOpacity(.9), size: 23),
      ]),
    );
  }

  Widget _header() {
    final sub = !_hasSender ? 'No sender connected' : (_groups.isEmpty ? 'Sender connected • no groups' : '${_groups.length} groups detected');
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 12),
      child: Row(children: [
        Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.16)), child: Icon(Icons.groups_rounded, color: _red, size: 25)),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Bug Groups', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: 1.8)),
          const SizedBox(height: 7),
          Text(sub, style: TextStyle(color: _muted, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: 1.2), overflow: TextOverflow.ellipsis),
        ])),
        InkWell(onTap: _fetchGroups, borderRadius: BorderRadius.circular(30), child: Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.05)), child: Icon(Icons.hourglass_empty_rounded, color: Colors.white.withOpacity(.45))))
      ]),
    );
  }

  Widget _joinCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(28, 4, 28, 18),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withOpacity(.025))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(Icons.add_circle_rounded, color: _red, size: 20), const SizedBox(width: 12), const Text('Join New Group', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 17, letterSpacing: 1.4))]),
        const SizedBox(height: 18),
        Container(
          height: 58,
          decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(15)),
          child: TextField(
            controller: _joinController,
            enabled: !_joining,
            style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800),
            decoration: InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(Icons.link_rounded, color: Colors.white.withOpacity(.36), size: 20),
              hintText: 'Enter group link...',
              hintStyle: TextStyle(color: Colors.white.withOpacity(.28), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, letterSpacing: 1.1),
            ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 61,
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _joining ? null : _joinGroup,
            style: ElevatedButton.styleFrom(backgroundColor: _red, disabledBackgroundColor: _redDark, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
            child: _joining ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white)) : const Text('+ JOIN GROUP', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2.0)),
          ),
        )
      ]),
    );
  }

  Widget _searchBar() {
    return Container(
      height: 70,
      margin: const EdgeInsets.fromLTRB(28, 0, 28, 22),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(.025))),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w800),
        decoration: InputDecoration(
          border: InputBorder.none,
          prefixIcon: Icon(Icons.search_rounded, color: _red, size: 24),
          suffixIcon: Icon(Icons.keyboard_arrow_down_rounded, color: _red.withOpacity(.8), size: 23),
          hintText: 'Search groups...',
          hintStyle: TextStyle(color: Colors.white.withOpacity(.36), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, letterSpacing: 1.2),
        ),
      ),
    );
  }

  Widget _sectionTitle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 4),
      child: Row(children: [
        Icon(Icons.notes_rounded, color: _red, size: 21),
        const SizedBox(width: 15),
        const Text('Your Groups', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 1.6)),
        const Spacer(),
        Container(padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 10), decoration: BoxDecoration(color: Colors.white.withOpacity(.055), borderRadius: BorderRadius.circular(14)), child: Text('${_groups.length} groups', style: TextStyle(color: Colors.white.withOpacity(.64), fontFamily: 'Rajdhani', fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 1.1))),
      ]),
    );
  }

  Widget _emptyState() {
    final title = !_hasSender ? 'No Sender Connected' : 'No Group Found';
    final desc = !_hasSender ? 'Connect a WhatsApp sender and join groups\nto start sending bugs' : 'Sender sudah aktif. Join group pakai link\natau refresh untuk baca group otomatis.';
    final icon = !_hasSender ? Icons.phonelink_off_rounded : Icons.group_off_rounded;
    return Padding(
      padding: const EdgeInsets.only(top: 70),
      child: Column(children: [
        AnimatedBuilder(
          animation: _glow,
          builder: (_, __) => Container(
            width: 132,
            height: 132,
            decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.08), border: Border.all(color: _red.withOpacity(.22 + (.22 * _glow.value))), boxShadow: [BoxShadow(color: _red.withOpacity(.16 * _glow.value), blurRadius: 42, spreadRadius: 3)]),
            child: Icon(icon, color: Colors.white.withOpacity(.75), size: 58),
          ),
        ),
        const SizedBox(height: 30),
        Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 21, letterSpacing: 1.2)),
        const SizedBox(height: 15),
        Text(desc, textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.56), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 14, height: 1.45, letterSpacing: 1.1)),
      ]),
    );
  }

  Widget _groupTile(Map<String, dynamic> g) {
    final id = g['id']?.toString() ?? '';
    final name = (g['subject']?.toString().trim().isNotEmpty == true) ? g['subject'].toString() : 'Unknown Group';
    final members = g['participants']?.toString() ?? '0';
    final selected = id == _selectedGroupId;
    return AnimatedBuilder(
      animation: _glow,
      builder: (_, __) => Container(
        margin: const EdgeInsets.fromLTRB(24, 7, 24, 7),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(19), border: Border.all(color: selected ? _red.withOpacity(.75) : _line.withOpacity(.45)), boxShadow: selected ? [BoxShadow(color: _red.withOpacity(.22 * _glow.value), blurRadius: 25, spreadRadius: 1)] : []),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(19),
            onTap: () => setState(() { _selectedGroupId = id; _selectedGroupName = name; }),
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Row(children: [
                Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.92)), child: const Icon(Icons.groups_rounded, color: Colors.white, size: 24)),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: .7)),
                  const SizedBox(height: 7),
                  Text('$members members • delay only', style: TextStyle(color: Colors.white.withOpacity(.5), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 1)),
                ])),
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: selected ? _red.withOpacity(.16) : Colors.transparent, borderRadius: BorderRadius.circular(18), border: Border.all(color: _red.withOpacity(selected ? .9 : .45))), child: Text(selected ? 'SELECTED' : 'JOINED', style: TextStyle(color: selected ? Colors.white : _red, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 9, letterSpacing: 1.2))),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  void _openBugSheet() {
    if (!_hasSender) {
      _toast('No sender connected. Pair sender user dulu.');
      return;
    }
    if (_groups.isEmpty) {
      _toast('Sender ada, tapi belum ada group. Join group dulu.');
      return;
    }
    if (_selectedGroupId == null) {
      _toast('Pilih group dulu dari list.');
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setSheet) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
                    decoration: BoxDecoration(
                      color: _card.withOpacity(.98),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
                      border: Border(top: BorderSide(color: _red.withOpacity(.5), width: 1.2)),
                      boxShadow: [BoxShadow(color: _red.withOpacity(.24), blurRadius: 42, spreadRadius: 3)],
                    ),
                    child: SafeArea(
                      top: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 54,
                              height: 5,
                              decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(20)),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.18), border: Border.all(color: _red.withOpacity(.55))),
                                child: Icon(Icons.bolt_rounded, color: _red, size: 26),
                              ),
                              const SizedBox(width: 14),
                              const Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Bug Options', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 21, letterSpacing: 1.4)),
                                    SizedBox(height: 4),
                                    Text('Pilih bug lalu kirim ke group terpilih', style: TextStyle(color: Color(0xFF8A8E99), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: .8)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(15),
                            decoration: BoxDecoration(color: _field, borderRadius: BorderRadius.circular(17), border: Border.all(color: _line.withOpacity(.7))),
                            child: Row(
                              children: [
                                Icon(Icons.groups_rounded, color: _red, size: 21),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('TARGET GROUP', style: TextStyle(color: _muted, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: 1.4)),
                                      const SizedBox(height: 4),
                                      Text(_selectedGroupName ?? '-', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 15)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 18),
                          Text('BUG TYPE', style: TextStyle(color: _muted, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.4)),
                          const SizedBox(height: 10),
                          GestureDetector(
                            onTap: () => setSheet(() => _selectedBug = 'delay'),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                              decoration: BoxDecoration(
                                color: _selectedBug == 'delay' ? _red.withOpacity(.16) : _field,
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: _selectedBug == 'delay' ? _red : _line.withOpacity(.7), width: 1.4),
                              ),
                              child: Row(
                                children: [
                                  Container(width: 39, height: 39, decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(.16)), child: Icon(Icons.timer_rounded, color: _red, size: 22)),
                                  const SizedBox(width: 13),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('DELAY', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 17, letterSpacing: 1.5)),
                                        SizedBox(height: 3),
                                        Text('Only available option', style: TextStyle(color: Color(0xFF8A8E99), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: .8)),
                                      ],
                                    ),
                                  ),
                                  Icon(_selectedBug == 'delay' ? Icons.check_circle_rounded : Icons.circle_outlined, color: _selectedBug == 'delay' ? _red : _muted, size: 24),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 22),
                          SizedBox(
                            width: double.infinity,
                            height: 58,
                            child: ElevatedButton(
                              onPressed: _sending
                                  ? null
                                  : () async {
                                      Navigator.pop(context);
                                      await _sendSelectedBug();
                                    },
                              style: ElevatedButton.styleFrom(backgroundColor: _red, disabledBackgroundColor: _redDark, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))),
                              child: _sending
                                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                                  : const Text('SEND DELAY', style: TextStyle(fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2.0)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _bottomBar() {
    return Positioned(
      left: 18,
      right: 18,
      bottom: 18,
      child: Container(
        height: 72,
        decoration: BoxDecoration(color: _nav.withOpacity(.98), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withOpacity(.06))),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _navItem(Icons.home_rounded, 'Home'),
          _navItem(Icons.chat_bubble_outline_rounded, 'Chat'),
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Transform.scale(
              scale: _pulse.value,
              child: GestureDetector(
                onTap: _sending ? null : _openBugSheet,
                child: Container(
                  width: 74,
                  height: 74,
                  transform: Matrix4.translationValues(0, -14, 0),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: _red, boxShadow: [BoxShadow(color: _red.withOpacity(.74), blurRadius: 30, spreadRadius: 2)]),
                  child: _sending ? const Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white)) : const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.bolt_rounded, color: Colors.white, size: 25), SizedBox(height: 4), Text('BUG', style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w900, fontSize: 10))]),
                ),
              ),
            ),
          ),
          _navItem(Icons.build_rounded, 'Tools'),
          _navItem(Icons.person_rounded, 'Profile'),
        ]),
      ),
    );
  }

  Widget _navItem(IconData icon, String label) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: Colors.white.withOpacity(.28), size: 21),
      const SizedBox(height: 5),
      Text(label, style: TextStyle(color: Colors.white.withOpacity(.28), fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 10)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        _background(),
        Column(children: [
          _topBar(),
          Expanded(
            child: RefreshIndicator(
              color: _red,
              backgroundColor: _card,
              onRefresh: _fetchGroups,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                padding: const EdgeInsets.only(bottom: 118),
                children: [
                  _header(),
                  _joinCard(),
                  _searchBar(),
                  _sectionTitle(),
                  if (_loading)
                    Padding(padding: const EdgeInsets.only(top: 80), child: Center(child: CircularProgressIndicator(color: _red)))
                  else if (!_hasSender || _groups.isEmpty || _visibleGroups.isEmpty)
                    _emptyState()
                  else
                    ..._visibleGroups.map(_groupTile),
                ],
              ),
            ),
          ),
        ]),
        _bottomBar(),
      ]),
    );
  }

  @override
  void dispose() {
    _joinController.dispose();
    _searchController.dispose();
    _glowController.dispose();
    _pulseController.dispose();
    _rotateController.dispose();
    _videoController?.dispose();
    super.dispose();
  }
}
