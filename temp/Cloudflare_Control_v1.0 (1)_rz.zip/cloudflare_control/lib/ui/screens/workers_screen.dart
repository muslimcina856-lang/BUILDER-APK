import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class WorkersScreen extends StatefulWidget {
  const WorkersScreen({super.key});

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  List<dynamic> workers = [];
  List<dynamic> pages = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final w = await api.getWorkers().catchError((_) => <dynamic>[]);
      final p = await api.getPagesProjects().catchError((_) => <dynamic>[]);
      setState(() {
        workers = w;
        pages = p;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.parse(url);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  Future<void> _openWorker(String name) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final api = CloudflareApi(account);
      final code = await api.getWorkerScript(name);
      if (!mounted) return;
      Navigator.pop(context);

      final changed = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => WorkerCodeScreen(
            name: name,
            code: code,
            accountId: account.id,
            canEdit: true,
          ),
        ),
      );
      if (changed == true) _load();
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context);
      _openExternal(
        'https://dash.cloudflare.com/${account.id}/workers/services/view/$name/production',
      );
    }
  }

  Future<void> _createWorker() async {
    final nameCtrl = TextEditingController();
    final codeCtrl = TextEditingController(
      text: '''export default {
  async fetch(request, env, ctx) {
    return new Response("Hello from Cloudflare Control!");
  },
};''',
    );

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta Worker'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Nama Worker',
                    hintText: 'my-worker',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: codeCtrl,
                  maxLines: 10,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  decoration: const InputDecoration(
                    labelText: 'Kod (JS/TS)',
                    alignLabelWithHint: true,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Deploy')),
        ],
      ),
    );

    if (result != true) return;
    final name = nameCtrl.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9-_]'), '-');
    final code = codeCtrl.text;
    if (name.isEmpty || code.trim().isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createWorkerScript(name, code);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Worker berjaya di-deploy'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deleteWorker(String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Worker?'),
        content: Text('Padam "$name"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteWorkerScript(name);
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _createPage() async {
    final nameCtrl = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta Pages Project'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(
            labelText: 'Nama project',
            hintText: 'my-site',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (result != true) return;
    final name = nameCtrl.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9-]'), '-');
    if (name.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createPagesProject(name);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pages project dicipta. Upload fail di Dashboard.'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deletePage(String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Pages?'),
        content: Text('Padam project "$name"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deletePagesProject(name);
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _openPage(String name, String? subdomain) async {
    if (subdomain != null && subdomain.isNotEmpty) {
      final url = subdomain.startsWith('http') ? subdomain : 'https://$subdomain';
      await _openExternal(url);
    } else {
      final app = context.read<AppController>();
      final id = app.activeAccount?.id ?? '';
      await _openExternal('https://dash.cloudflare.com/$id/pages/view/$name');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Workers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              FilledButton.icon(
                onPressed: _createWorker,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Cipta'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (workers.isEmpty)
            const Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Text('Tiada Workers', style: TextStyle(color: AppColors.muted)),
            )
          else
            ...workers.map((w) {
              final name = (w['id'] ?? w['name'] ?? '-').toString();
              final modified = w['modified_on']?.toString() ?? '-';
              final short = modified.length > 19 ? modified.substring(0, 19) : modified;
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.code, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text('Modified: $short'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                        onPressed: () => _deleteWorker(name),
                      ),
                      const Icon(Icons.chevron_right, color: AppColors.muted),
                    ],
                  ),
                  onTap: () => _openWorker(name),
                ),
              );
            }),
          const SizedBox(height: 24),
          Row(
            children: [
              const Expanded(
                child: Text('Pages Projects', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              FilledButton.icon(
                onPressed: _createPage,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Cipta'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (pages.isEmpty)
            const Text('Tiada Pages project', style: TextStyle(color: AppColors.muted))
          else
            ...pages.map((p) {
              final name = (p['name'] ?? '-').toString();
              final subdomain = p['subdomain']?.toString();
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.web, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text(subdomain ?? ''),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                        onPressed: () => _deletePage(name),
                      ),
                      const Icon(Icons.open_in_new, size: 18, color: AppColors.muted),
                    ],
                  ),
                  onTap: () => _openPage(name, subdomain),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class WorkerCodeScreen extends StatefulWidget {
  final String name;
  final String code;
  final String accountId;
  final bool canEdit;

  const WorkerCodeScreen({
    super.key,
    required this.name,
    required this.code,
    required this.accountId,
    this.canEdit = false,
  });

  @override
  State<WorkerCodeScreen> createState() => _WorkerCodeScreenState();
}

class _WorkerCodeScreenState extends State<WorkerCodeScreen> {
  late TextEditingController _codeCtrl;
  bool editing = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _codeCtrl = TextEditingController(text: widget.code);
  }

  @override
  void dispose() {
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() => saving = true);
    try {
      final api = CloudflareApi(account);
      await api.createWorkerScript(widget.name, _codeCtrl.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Worker dikemaskini'), backgroundColor: AppColors.success),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _openDash() async {
    final uri = Uri.parse(
      'https://dash.cloudflare.com/${widget.accountId}/workers/services/view/${widget.name}/production',
    );
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name, overflow: TextOverflow.ellipsis),
        actions: [
          if (widget.canEdit)
            IconButton(
              icon: Icon(editing ? Icons.visibility_outlined : Icons.edit_outlined),
              tooltip: editing ? 'View' : 'Edit',
              onPressed: () => setState(() => editing = !editing),
            ),
          IconButton(
            icon: const Icon(Icons.open_in_new),
            tooltip: 'Dashboard',
            onPressed: _openDash,
          ),
        ],
      ),
      body: widget.code.isEmpty && !editing
          ? const Center(child: Text('Tiada kod', style: TextStyle(color: AppColors.muted)))
          : Column(
              children: [
                Expanded(
                  child: editing
                      ? Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _codeCtrl,
                            maxLines: null,
                            expands: true,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              alignLabelWithHint: true,
                            ),
                          ),
                        )
                      : SingleChildScrollView(
                          padding: const EdgeInsets.all(16),
                          child: SelectableText(
                            _codeCtrl.text,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12, height: 1.4),
                          ),
                        ),
                ),
                if (editing)
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: saving ? null : _save,
                          child: saving
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                              : const Text('Deploy / Simpan'),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}
