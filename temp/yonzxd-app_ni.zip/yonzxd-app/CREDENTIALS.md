# 🔐 YonzXD App - Login Credentials & Setup Guide

## 📱 Aplikasi Information
- **Nama**: YonzXD - Advanced Multi-functional Bot Application
- **Versi**: 1.0.0
- **Platform**: Flutter/Web
- **Status**: Ready to Deploy

---

## 🔑 AKUN LOGIN - 23 Akun Siap Pakai

### 👑 OWNER ACCOUNT
```
Username: yonzxd_owner
Password: YonzXD@Owner123!
Email: owner@yonzxd.app
Role: Owner
Telegram ID: 1000000001
```

---

### 🛡️ ADMIN ACCOUNTS (2)

#### Admin 1
```
Username: yonzxd_admin
Password: YonzXD@Admin123!
Email: admin@yonzxd.app
Role: Admin
Telegram ID: 1000000002
```

#### Admin 2 (Supreme)
```
Username: admin_supreme
Password: Supreme@Admin123!
Email: admin.supreme@yonzxd.app
Role: Admin
Telegram ID: 1000000020
```

---

### 👮 MODERATOR ACCOUNTS (2)

#### Moderator 1
```
Username: yonzxd_moderator
Password: YonzXD@Mod123!
Email: moderator@yonzxd.app
Role: Moderator
Telegram ID: 1000000003
```

#### Moderator 2 (Senior)
```
Username: moderator_senior
Password: Senior@Mod123!
Email: moderator.senior@yonzxd.app
Role: Moderator
Telegram ID: 1000000015
```

---

### 💼 FOUNDER ACCOUNTS (2)

#### Founder 1
```
Username: yonzxd_founder
Password: YonzXD@Founder123!
Email: founder@yonzxd.app
Role: Founder
Telegram ID: 1000000005
```

#### Founder 2 (Prime)
```
Username: founder_prime
Password: Prime@Founder123!
Email: founder.prime@yonzxd.app
Role: Founder
Telegram ID: 1000000019
```

---

### 🤝 RESELLER ACCOUNTS (4)

#### Reseller 1
```
Username: yonzxd_reseller
Password: YonzXD@Reseller123!
Email: reseller@yonzxd.app
Role: Reseller
Telegram ID: 1000000004
```

#### Reseller 2 (Prime)
```
Username: reseller_prime
Password: Prime@Reseller123!
Email: reseller.prime@yonzxd.app
Role: Reseller
Telegram ID: 1000000011
```

#### Reseller 3 (Plus)
```
Username: reseller_plus
Password: Plus@Reseller123!
Email: reseller.plus@yonzxd.app
Role: Reseller
Telegram ID: 1000000012
```

#### Reseller 4 (Elite)
```
Username: reseller_elite
Password: Elite@Reseller123!
Email: reseller.elite@yonzxd.app
Role: Reseller
Telegram ID: 1000000022
```

---

### 🤖 AGENT ACCOUNTS (4)

#### Agent 1
```
Username: agent_yonz
Password: Agent@Yonz123!
Email: agent1@yonzxd.app
Role: Agent
Telegram ID: 1000000006
```

#### Agent 2 (Supreme)
```
Username: agent_supreme
Password: Supreme@Agent123!
Email: agent.supreme@yonzxd.app
Role: Agent
Telegram ID: 1000000013
```

#### Agent 3 (Elite)
```
Username: agent_elite
Password: Elite@Agent123!
Email: agent.elite@yonzxd.app
Role: Agent
Telegram ID: 1000000014
```

#### Agent 4 (VIP)
```
Username: agent_vip
Password: VIP@Agent123!
Email: agent.vip@yonzxd.app
Role: Agent
Telegram ID: 1000000023
```

---

### 👤 USER ACCOUNTS (8)

#### User 1 (Alpha)
```
Username: user_alpha
Password: Alpha@User123!
Email: user.alpha@yonzxd.app
Role: User
Telegram ID: 1000000007
```

#### User 2 (Beta)
```
Username: user_beta
Password: Beta@User123!
Email: user.beta@yonzxd.app
Role: User
Telegram ID: 1000000008
```

#### User 3 (Gamma)
```
Username: user_gamma
Password: Gamma@User123!
Email: user.gamma@yonzxd.app
Role: User
Telegram ID: 1000000009
```

#### User 4 (Delta)
```
Username: user_delta
Password: Delta@User123!
Email: user.delta@yonzxd.app
Role: User
Telegram ID: 1000000010
```

#### User 5 (Epsilon)
```
Username: user_epsilon
Password: Epsilon@User123!
Email: user.epsilon@yonzxd.app
Role: User
Telegram ID: 1000000016
```

#### User 6 (Zeta)
```
Username: user_zeta
Password: Zeta@User123!
Email: user.zeta@yonzxd.app
Role: User
Telegram ID: 1000000017
```

#### User 7 (Eta)
```
Username: user_eta
Password: Eta@User123!
Email: user.eta@yonzxd.app
Role: User
Telegram ID: 1000000018
```

#### User 8 (Theta)
```
Username: user_theta
Password: Theta@User123!
Email: user.theta@yonzxd.app
Role: User
Telegram ID: 1000000021
```

---

## 🚀 SETUP & INSTALLATION

### Untuk Flutter (Mobile App)
```bash
# 1. Instalasi dependencies
flutter pub get

# 2. Generate code jika ada
flutter pub run build_runner build

# 3. Run aplikasi
flutter run

# Untuk build production:
flutter build apk  # Android
flutter build ios  # iOS
```

### Untuk Web
```bash
# 1. Install dependencies
npm install

# 2. Start server
npm start

# 3. Akses di browser
http://localhost:3000
```

---

## 📋 ROLE PERMISSIONS

| Role | Permissions |
|------|-------------|
| **Owner** | Full access, manage system, users, settings |
| **Admin** | Manage users, moderators, content, reports |
| **Moderator** | Monitor content, handle disputes, moderate chats |
| **Founder** | Create products, manage resellers, analytics |
| **Reseller** | Sell products, manage agents, earn commissions |
| **Agent** | Promote products, handle customer inquiries |
| **User** | Browse, purchase, use services |

---

## ⚙️ FITUR UTAMA

✅ Multi-role authentication system
✅ WhatsApp Business integration
✅ Telegram bot integration
✅ Real-time chat & notifications
✅ Product marketplace
✅ Payment processing (Dana, QRIS)
✅ User management dashboard
✅ Analytics & reporting
✅ Commission system
✅ Support ticket system

---

## 🔄 DATABASE NOTES

- Semua data tersimpan di `user.json` (untuk development)
- Untuk production, gunakan Firebase atau database lainnya
- Pastikan backup database secara berkala
- Session data di `sessions.json`

---

## 🛠️ TROUBLESHOOTING

### Login Gagal?
- Pastikan username & password benar (case-sensitive)
- Clear cache/cookies browser
- Restart aplikasi

### Data Tidak Tersimpan?
- Pastikan localStorage enabled
- Check browser console untuk error
- Verify Firebase connection (jika production)

### Notifikasi Tidak Masuk?
- Enable notification permissions
- Check Telegram bot token di config.js
- Verify WhatsApp API integration

---

## 📞 SUPPORT

Untuk bantuan lebih lanjut, hubungi:
- Email: support@yonzxd.app
- Telegram: @YonzXD_Support
- WhatsApp: (Sesuai config.js)

---

## 📄 FILE STRUCTURE

```
yonzxd-app/
├── lib/                 # Flutter source (if using Flutter)
├── web/                 # Web assets
├── assets/              # Images, icons, animations
├── node_modules/        # Dependencies (Node.js)
├── index.js             # Main server file
├── main.js              # Entry point
├── user.json            # User database ⭐
├── sessions.json        # Session storage
├── package.json         # Node.js dependencies
├── pubspec.yaml         # Flutter dependencies
└── HTML pages           # UI components
    ├── Login.html
    ├── Dashboard.html
    ├── Profil.html
    ├── User-management.html
    └── ... (other pages)
```

---

## 🎯 NEXT STEPS

1. ✅ Uncompress ZIP file
2. ✅ Install dependencies (`npm install` atau `flutter pub get`)
3. ✅ Configure environment variables
4. ✅ Login dengan salah satu akun di atas
5. ✅ Explore dashboard & fitur

---

**Version**: 1.0.0
**Updated**: June 2024
**Status**: Production Ready ✅

---

*YonzXD - Advanced Multi-functional Bot Application*
*Powered by AYONZ Soul Founder*
