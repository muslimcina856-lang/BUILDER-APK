// Root build.gradle.kts — Gradle 9.x: allprojects{} masih valid
// tapi repo resolution sudah di settings.gradle.kts
// Cukup register clean task

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
