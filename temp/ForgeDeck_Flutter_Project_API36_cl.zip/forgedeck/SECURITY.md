# Polisi keselamatan

## Rahsia

Jangan commit PAT, token bot, signing key atau credential lain. Jika credential pernah dihantar melalui chat, issue, log atau commit, anggap ia bocor dan revoke segera.

## Reka bentuk token

- Token disimpan melalui secure storage platform.
- Metadata akaun dan token disimpan berasingan.
- Token tidak dipaparkan semula selepas disimpan.
- Client HTTP tidak memasang log interceptor.
- Header Authorization menggunakan `Bearer`.
- Force push tidak menyelitkan token dalam remote URL.

## Operasi destruktif

Force push dan delete repository memerlukan pengesahan teks. GitHub masih boleh menolak tindakan berdasarkan permission PAT, branch protection, ruleset atau polisi organisasi.

## Laporan isu

Semasa melaporkan bug, padam semua token, authorization header, URL yang mengandungi credential dan data repository private.
