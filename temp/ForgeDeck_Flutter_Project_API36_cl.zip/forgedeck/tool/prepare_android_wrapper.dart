import 'dart:io';

Future<void> main() async {
  final projectRoot = File.fromUri(Platform.script).parent.parent;
  final target = File(
    '${projectRoot.path}${Platform.pathSeparator}android${Platform.pathSeparator}'
    'gradle${Platform.pathSeparator}wrapper${Platform.pathSeparator}'
    'gradle-wrapper.jar',
  );

  if (target.existsSync()) {
    stdout.writeln('Gradle wrapper sudah tersedia.');
    return;
  }

  final tempRoot = await Directory.systemTemp.createTemp('forgedeck_wrapper_');
  final scaffold = Directory(
    '${tempRoot.path}${Platform.pathSeparator}scaffold',
  );

  try {
    stdout.writeln('Menjana Gradle wrapper daripada Flutter SDK tempatan...');
    final result = await Process.run(
      'flutter',
      <String>[
        'create',
        '--platforms=android',
        '--empty',
        '--org', 'com.example',
        scaffold.path,
      ],
      runInShell: Platform.isWindows,
    );
    if (result.exitCode != 0) {
      stderr.writeln(result.stdout);
      stderr.writeln(result.stderr);
      exitCode = result.exitCode;
      return;
    }

    final source = File(
      '${scaffold.path}${Platform.pathSeparator}android'
      '${Platform.pathSeparator}gradle${Platform.pathSeparator}wrapper'
      '${Platform.pathSeparator}gradle-wrapper.jar',
    );
    if (!source.existsSync()) {
      stderr.writeln('Flutter SDK tidak menghasilkan gradle-wrapper.jar.');
      exitCode = 1;
      return;
    }

    target.parent.createSync(recursive: true);
    await source.copy(target.path);
    stdout.writeln('Gradle wrapper berjaya disediakan.');
  } finally {
    if (tempRoot.existsSync()) {
      await tempRoot.delete(recursive: true);
    }
  }
}
