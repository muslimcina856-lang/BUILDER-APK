import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';

class ActivityScreen extends StatelessWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: controller.refreshAll,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 14),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('Aktiviti', style: Theme.of(context).textTheme.headlineMedium),
                          const SizedBox(height: 5),
                          const Text(
                            'Notifikasi daripada akaun aktif.',
                            style: TextStyle(color: AppColors.muted),
                          ),
                        ],
                      ),
                    ),
                    if (controller.notifications.isNotEmpty)
                      TextButton.icon(
                        onPressed: controller.markNotificationsRead,
                        icon: const Icon(Icons.done_all_rounded),
                        label: const Text('Tanda dibaca'),
                      ),
                  ],
                ),
              ),
            ),
            if (controller.notifications.isEmpty)
              const SliverPadding(
                padding: EdgeInsets.all(20),
                sliver: SliverToBoxAdapter(
                  child: EmptyState(
                    icon: Icons.notifications_none_rounded,
                    title: 'Tiada notifikasi',
                    message: 'Tarik ke bawah untuk semak semula.',
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
                sliver: SliverList.separated(
                  itemCount: controller.notifications.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final item = controller.notifications[index];
                    final subject = item['subject'] as Map<String, dynamic>? ?? const {};
                    final repo = item['repository'] as Map<String, dynamic>? ?? const {};
                    final reason = item['reason'] as String? ?? 'notification';
                    return Panel(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: AppColors.accentSoft,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(
                              Icons.notifications_active_outlined,
                              color: AppColors.accent,
                            ),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  subject['title'] as String? ?? 'Aktiviti GitHub',
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  repo['full_name'] as String? ?? '',
                                  style: const TextStyle(color: AppColors.muted),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  reason.replaceAll('_', ' '),
                                  style: const TextStyle(
                                    color: AppColors.accent,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
