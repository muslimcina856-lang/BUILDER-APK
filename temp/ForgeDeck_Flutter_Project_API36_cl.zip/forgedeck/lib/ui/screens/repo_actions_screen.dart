import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_repo.dart';
import '../../models/github_workflow.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class RepoActionsScreen extends StatefulWidget {
  const RepoActionsScreen({
    required this.repo,
    required this.branch,
    super.key,
  });

  final GitHubRepo repo;
  final String branch;

  @override
  State<RepoActionsScreen> createState() => _RepoActionsScreenState();
}

class _RepoActionsScreenState extends State<RepoActionsScreen> {
  List<GitHubWorkflow> _workflows = const [];
  List<GitHubWorkflowRun> _runs = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RepoActionsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.branch != widget.branch ||
        oldWidget.repo.fullName != widget.repo.fullName) {
      _load();
    }
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    try {
      final api = AppScope.of(context, listen: false).api;
      final results = await Future.wait<dynamic>(<Future<dynamic>>[
        api.listWorkflows(widget.repo.owner, widget.repo.name),
        api.listWorkflowRuns(widget.repo.owner, widget.repo.name),
      ]);
      if (mounted) {
        setState(() {
          _workflows = results[0] as List<GitHubWorkflow>;
          _runs = results[1] as List<GitHubWorkflowRun>;
          _error = null;
        });
      }
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _dispatch(GitHubWorkflow workflow) async {
    if (widget.branch.isEmpty) return;
    final inputs = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _WorkflowInputDialog(workflowName: workflow.name),
    );
    if (inputs == null || !mounted) return;
    try {
      await AppScope.of(context, listen: false).api.dispatchWorkflow(
            widget.repo.owner,
            widget.repo.name,
            workflow.id,
            ref: widget.branch,
            inputs: inputs,
          );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${workflow.name} telah dihantar.')),
        );
      }
      await Future<void>.delayed(const Duration(seconds: 1));
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  Future<void> _runAction(GitHubWorkflowRun run, String action) async {
    try {
      final api = AppScope.of(context, listen: false).api;
      if (action == 'cancel') {
        await api.cancelWorkflow(widget.repo.owner, widget.repo.name, run.id);
      } else {
        await api.rerunWorkflow(widget.repo.owner, widget.repo.name, run.id);
      }
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
        children: <Widget>[
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            EmptyState(
              icon: Icons.error_outline_rounded,
              title: 'Gagal memuat Actions',
              message: _error!,
              action: OutlinedButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Cuba lagi'),
              ),
            )
          else ...<Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text('Workflow', style: Theme.of(context).textTheme.titleLarge),
                ),
                StatusPill(
                  label: widget.branch.isEmpty ? 'Tiada branch' : widget.branch,
                  icon: Icons.call_split_rounded,
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_workflows.isEmpty)
              const EmptyState(
                icon: Icons.bolt_outlined,
                title: 'Tiada workflow',
                message: 'Fail workflow dalam .github/workflows akan muncul di sini.',
              )
            else
              Panel(
                padding: EdgeInsets.zero,
                child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _workflows.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final workflow = _workflows[index];
                    final enabled = workflow.state == 'active';
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      leading: Icon(
                        Icons.bolt_rounded,
                        color: enabled ? AppColors.accent : AppColors.muted,
                      ),
                      title: Text(workflow.name),
                      subtitle: Text(workflow.path),
                      trailing: IconButton(
                        onPressed: enabled && widget.repo.canPush
                            ? () => _dispatch(workflow)
                            : null,
                        icon: const Icon(Icons.play_arrow_rounded),
                        tooltip: 'Jalankan workflow_dispatch',
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 22),
            Text('Run terkini', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            if (_runs.isEmpty)
              const EmptyState(
                icon: Icons.history_rounded,
                title: 'Belum ada run',
                message: 'Run Actions akan dipaparkan selepas workflow dijalankan.',
              )
            else
              Panel(
                padding: EdgeInsets.zero,
                child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _runs.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final run = _runs[index];
                    final active = run.status == 'in_progress' || run.status == 'queued';
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                      leading: Icon(
                        active ? Icons.sync_rounded : _runIcon(run.conclusion),
                        color: _runColor(run),
                      ),
                      title: Text(run.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                        '${run.branch} - ${run.event} - ${timeAgo(run.createdAt)}',
                        maxLines: 2,
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) => _runAction(run, value),
                        itemBuilder: (_) => <PopupMenuEntry<String>>[
                          if (active)
                            const PopupMenuItem(value: 'cancel', child: Text('Batalkan run')),
                          if (!active)
                            const PopupMenuItem(value: 'rerun', child: Text('Jalankan semula')),
                        ],
                      ),
                    );
                  },
                ),
              ),
          ],
        ],
      ),
    );
  }

  IconData _runIcon(String conclusion) {
    return switch (conclusion) {
      'success' => Icons.check_circle_rounded,
      'failure' || 'timed_out' => Icons.cancel_rounded,
      'cancelled' => Icons.remove_circle_outline_rounded,
      _ => Icons.help_outline_rounded,
    };
  }

  Color _runColor(GitHubWorkflowRun run) {
    if (run.status == 'in_progress' || run.status == 'queued') {
      return AppColors.warning;
    }
    return switch (run.conclusion) {
      'success' => AppColors.accent,
      'failure' || 'timed_out' => AppColors.danger,
      _ => AppColors.muted,
    };
  }
}


class _WorkflowInputDialog extends StatefulWidget {
  const _WorkflowInputDialog({required this.workflowName});

  final String workflowName;

  @override
  State<_WorkflowInputDialog> createState() => _WorkflowInputDialogState();
}

class _WorkflowInputDialogState extends State<_WorkflowInputDialog> {
  final _inputs = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _inputs.dispose();
    super.dispose();
  }

  Map<String, dynamic>? _parse() {
    final output = <String, dynamic>{};
    final lines = _inputs.text.split('\n');
    for (final rawLine in lines) {
      final line = rawLine.trim();
      if (line.isEmpty) continue;
      final separator = line.indexOf('=');
      if (separator <= 0) {
        _error = 'Gunakan format nama=nilai, satu input setiap baris.';
        return null;
      }
      final key = line.substring(0, separator).trim();
      final value = line.substring(separator + 1).trim();
      if (key.isEmpty) {
        _error = 'Nama input tidak boleh kosong.';
        return null;
      }
      output[key] = value;
    }
    return output;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Jalankan ${widget.workflowName}'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text(
            'Masukkan input pilihan dalam format nama=nilai. Biarkan kosong jika workflow tidak memerlukan input.',
            style: TextStyle(color: AppColors.muted, height: 1.4),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _inputs,
            maxLines: 6,
            decoration: InputDecoration(
              labelText: 'Input workflow',
              hintText: 'environment=production\nversion=1.2.0',
              errorText: _error,
              alignLabelWithHint: true,
            ),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        FilledButton(
          onPressed: () {
            final parsed = _parse();
            if (parsed == null) {
              setState(() {});
              return;
            }
            Navigator.pop(context, parsed);
          },
          child: const Text('Jalankan'),
        ),
      ],
    );
  }
}
