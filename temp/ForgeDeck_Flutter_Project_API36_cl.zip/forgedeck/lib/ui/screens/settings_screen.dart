import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _clear(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Padam semua akaun?'),
        content: const Text(
          'Semua PAT dan metadata akaun akan dipadam dari peranti ini.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam semua'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      await AppScope.of(context, listen: false).clearAllAccounts();
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final permission = controller.storagePermission;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 100),
        children: <Widget>[
          Text('Tetapan', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 5),
          const Text(
            'Kawalan privasi dan akses peranti.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 22),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.security_rounded, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Text('Token dan sambungan', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 14),
                const Text(
                  'PAT disimpan dalam storan selamat Android. Aplikasi tidak meletakkan token dalam URL, fail projek, atau log paparan.',
                  style: TextStyle(color: AppColors.muted, height: 1.5),
                ),
                const SizedBox(height: 14),
                const StatusPill(
                  label: 'Permission ikut PAT',
                  icon: Icons.admin_panel_settings_outlined,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.folder_open_rounded, color: AppColors.warning),
                    const SizedBox(width: 10),
                    Text('Akses fail', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  permission == null
                      ? 'Status izin belum tersedia.'
                      : permission.required
                          ? permission.granted
                              ? 'Izin storan Android lama sudah diberi.'
                              : 'Izin storan Android lama belum diberi.'
                          : 'Android moden menggunakan pemilih fail sistem. Tiada izin storan luas diperlukan.',
                  style: const TextStyle(color: AppColors.muted, height: 1.45),
                ),
                if (permission?.permanentlyDenied == true) ...<Widget>[
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: openAppSettings,
                    icon: const Icon(Icons.settings_outlined),
                    label: const Text('Buka tetapan aplikasi'),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            borderColor: AppColors.danger.withValues(alpha: 0.38),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Zon sensitif', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                const Text(
                  'Tindakan seperti delete repository, merge, dan force push akan meminta pengesahan tambahan.',
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: () => _clear(context),
                  icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.danger),
                  label: const Text(
                    'Padam semua akaun dari peranti',
                    style: TextStyle(color: AppColors.danger),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'ForgeDeck 0.1.0',
              style: TextStyle(color: AppColors.muted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
