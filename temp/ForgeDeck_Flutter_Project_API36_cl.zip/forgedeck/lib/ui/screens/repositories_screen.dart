import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../models/github_repo.dart';
import '../../state/app_scope.dart';
import '../widgets/account_avatar.dart';
import '../widgets/empty_state.dart';
import '../widgets/repo_card.dart';
import '../widgets/status_pill.dart';
import 'repo_detail_screen.dart';

class RepositoriesScreen extends StatefulWidget {
  const RepositoriesScreen({super.key});

  @override
  State<RepositoriesScreen> createState() => _RepositoriesScreenState();
}

class _RepositoriesScreenState extends State<RepositoriesScreen> {
  final _searchController = TextEditingController();
  String _filter = 'all';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<GitHubRepo> _filtered(List<GitHubRepo> repos) {
    final query = _searchController.text.trim().toLowerCase();
    return repos.where((repo) {
      final filterMatch = switch (_filter) {
        'private' => repo.isPrivate,
        'public' => !repo.isPrivate,
        'owned' => repo.owner == AppScope.of(context, listen: false).activeAccount?.login,
        _ => true,
      };
      final searchMatch = query.isEmpty ||
          repo.name.toLowerCase().contains(query) ||
          repo.owner.toLowerCase().contains(query) ||
          repo.description.toLowerCase().contains(query);
      return filterMatch && searchMatch;
    }).toList();
  }

  Future<void> _openCreateRepo() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _CreateRepoSheet(),
    );
    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Repository berjaya dicipta.')),
      );
    }
  }

  Future<void> _showAccountSwitcher() async {
    final controller = AppScope.of(context, listen: false);
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Text('Tukar akaun', style: Theme.of(context).textTheme.titleLarge),
                  ],
                ),
                const SizedBox(height: 12),
                for (final account in controller.accounts)
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                    leading: AccountAvatar(
                      url: account.avatarUrl,
                      fallback: account.login,
                    ),
                    title: Text(account.displayName),
                    subtitle: Text('@${account.login}'),
                    trailing: controller.activeAccount?.id == account.id
                        ? const Icon(Icons.check_circle_rounded, color: AppColors.accent)
                        : null,
                    onTap: () async {
                      Navigator.pop(sheetContext);
                      await controller.switchAccount(account.id);
                    },
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final account = controller.activeAccount!;
    final user = controller.activeUser;
    final repos = _filtered(controller.repositories);

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: controller.refreshAll,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            'Ruang kerja',
                            style: TextStyle(color: AppColors.muted, fontSize: 13),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            user?.name.isNotEmpty == true ? user!.name : account.login,
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                        ],
                      ),
                    ),
                    IconButton.filledTonal(
                      onPressed: _showAccountSwitcher,
                      icon: AccountAvatar(
                        url: account.avatarUrl,
                        fallback: account.login,
                        radius: 19,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    StatusPill(
                      label: '${controller.repositories.length} repository',
                      icon: Icons.folder_open_rounded,
                    ),
                    const SizedBox(width: 8),
                    StatusPill(
                      label: '${controller.notifications.length} notifikasi',
                      color: controller.notifications.isEmpty
                          ? AppColors.muted
                          : AppColors.warning,
                      icon: Icons.notifications_none_rounded,
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
              sliver: SliverToBoxAdapter(
                child: TextField(
                  controller: _searchController,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Cari repository',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: _searchController.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              _searchController.clear();
                              setState(() {});
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
              sliver: SliverToBoxAdapter(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      for (final item in const <(String, String)>[
                        ('all', 'Semua'),
                        ('owned', 'Milik sendiri'),
                        ('private', 'Private'),
                        ('public', 'Public'),
                      ])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(item.$2),
                            selected: _filter == item.$1,
                            onSelected: (_) => setState(() => _filter = item.$1),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            if (controller.loading && controller.repositories.isEmpty)
              const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              )
            else if (repos.isEmpty)
              SliverPadding(
                padding: const EdgeInsets.all(20),
                sliver: SliverToBoxAdapter(
                  child: EmptyState(
                    icon: Icons.folder_off_outlined,
                    title: 'Tiada repository ditemui',
                    message: 'Cuba ubah carian atau cipta repository baharu.',
                    action: FilledButton.icon(
                      onPressed: _openCreateRepo,
                      icon: const Icon(Icons.add_rounded),
                      label: const Text('Cipta repository'),
                    ),
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                sliver: SliverList.separated(
                  itemCount: repos.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final repo = repos[index];
                    return RepoCard(
                      repo: repo,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => RepoDetailScreen(repo: repo),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _CreateRepoSheet extends StatefulWidget {
  const _CreateRepoSheet();

  @override
  State<_CreateRepoSheet> createState() => _CreateRepoSheetState();
}

class _CreateRepoSheetState extends State<_CreateRepoSheet> {
  final _name = TextEditingController();
  final _description = TextEditingController();
  bool _private = true;
  bool _autoInit = true;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final name = _name.text.trim();
    if (name.isEmpty) return;
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).createRepository(
        name: name,
        description: _description.text.trim(),
        isPrivate: _private,
        autoInit: _autoInit,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        8,
        20,
        MediaQuery.viewInsetsOf(context).bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Repository baharu', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 18),
          TextField(
            controller: _name,
            autofocus: true,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'Nama repository',
              prefixIcon: Icon(Icons.folder_outlined),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Penerangan',
              alignLabelWithHint: true,
            ),
          ),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Private repository'),
            subtitle: const Text('Hanya pengguna yang dibenarkan boleh melihatnya.'),
            value: _private,
            onChanged: (value) => setState(() => _private = value),
          ),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Cipta README awal'),
            value: _autoInit,
            onChanged: (value) => setState(() => _autoInit = value),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _busy ? null : _create,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.add_rounded),
            label: const Text('Cipta repository'),
          ),
        ],
      ),
    );
  }
}
