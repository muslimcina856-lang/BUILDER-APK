import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;

import '../../models/zip_plan.dart';

class ZipPlanException implements Exception {
  const ZipPlanException(this.message);

  final String message;

  @override
  String toString() => message;
}

class ZipService {
  const ZipService();

  static const maxFiles = 3000;
  static const maxSingleFileBytes = 50 * 1024 * 1024;
  static const maxTotalBytes = 250 * 1024 * 1024;
  static const maxPathLength = 1024;

  Future<ZipPlan?> pickAndPlan() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      allowMultiple: false,
      withData: false,
    );
    if (result == null || result.files.isEmpty) return null;

    final platformFile = result.files.single;
    InputFileStream? stream;
    try {
      final Archive archive;
      if (platformFile.path != null) {
        stream = InputFileStream(platformFile.path!);
        archive = ZipDecoder().decodeStream(stream);
      } else {
        final bytes = await result.xFiles.single.readAsBytes();
        archive = ZipDecoder().decodeBytes(bytes);
      }
      return _buildPlan(archive, platformFile.name);
    } finally {
      stream?.closeSync();
    }
  }

  ZipPlan _buildPlan(Archive archive, String fileName) {
    final rawFiles = archive.where((entry) => entry.isFile).toList();
    if (rawFiles.isEmpty) {
      throw const ZipPlanException('ZIP tidak mengandungi fail.');
    }
    if (rawFiles.length > maxFiles) {
      throw const ZipPlanException(
        'ZIP mempunyai terlalu banyak fail. Had keselamatan ialah 3000 fail.',
      );
    }

    final normalizedPaths = rawFiles
        .map((entry) => normalizeZipPath(entry.name))
        .where((path) => path.isNotEmpty && !_shouldIgnore(path))
        .toList();
    final root = _singleRootFolder(normalizedPaths);

    final entries = <ZipEntryPlan>[];
    final seenPaths = <String>{};
    var totalBytes = 0;
    for (final file in rawFiles) {
      if (file.isSymbolicLink) {
        throw ZipPlanException(
          'ZIP mengandungi symbolic link yang belum disokong: ${file.name}',
        );
      }

      var path = normalizeZipPath(file.name);
      if (path.isEmpty || _shouldIgnore(path)) continue;
      if (root.isNotEmpty && path.startsWith('$root/')) {
        path = path.substring(root.length + 1);
      }
      path = normalizeZipPath(path);
      if (path.isEmpty || _shouldIgnore(path)) continue;
      if (!seenPaths.add(path)) {
        throw ZipPlanException('ZIP mengandungi laluan pendua: $path');
      }

      final declaredSize = file.size;
      if (declaredSize > maxSingleFileBytes) {
        throw ZipPlanException(
          'Fail $path melebihi had keselamatan 50 MB.',
        );
      }
      totalBytes += declaredSize;
      if (totalBytes > maxTotalBytes) {
        throw const ZipPlanException(
          'Jumlah kandungan ZIP melebihi had keselamatan 250 MB.',
        );
      }

      final bytes = file.readBytes();
      if (bytes == null) {
        throw ZipPlanException('Kandungan fail $path tidak dapat dibaca.');
      }
      if (bytes.length > maxSingleFileBytes) {
        throw ZipPlanException(
          'Fail $path melebihi had keselamatan 50 MB selepas diekstrak.',
        );
      }

      entries.add(
        ZipEntryPlan(
          path: path,
          bytes: bytes,
          executable: (file.unixPermissions & 0x49) != 0,
        ),
      );
    }

    if (entries.isEmpty) {
      throw const ZipPlanException(
        'Tiada fail yang boleh dimuat naik selepas penapisan ZIP.',
      );
    }

    entries.sort((a, b) => a.path.compareTo(b.path));
    return ZipPlan(
      fileName: fileName,
      entries: entries,
      totalBytes: entries.fold<int>(0, (sum, entry) => sum + entry.bytes.length),
      strippedRoot: root,
    );
  }

  static String normalizeZipPath(String input) {
    if (input.contains('\u0000')) {
      throw const ZipPlanException('ZIP mengandungi nama fail yang tidak sah.');
    }
    var value = input.replaceAll('\\', '/').trim();
    if (RegExp(r'^[A-Za-z]:/').hasMatch(value)) {
      throw const ZipPlanException('ZIP mengandungi laluan mutlak Windows.');
    }
    while (value.startsWith('/')) {
      value = value.substring(1);
    }
    final safeParts = <String>[];
    for (final part in p.posix.split(value)) {
      if (part.isEmpty || part == '.') continue;
      if (part == '..') {
        throw const ZipPlanException('ZIP mengandungi laluan yang tidak selamat.');
      }
      safeParts.add(part);
    }
    final normalized = safeParts.join('/');
    if (normalized.length > maxPathLength) {
      throw const ZipPlanException('ZIP mengandungi laluan fail yang terlalu panjang.');
    }
    return normalized;
  }

  static String _singleRootFolder(List<String> paths) {
    if (paths.isEmpty) return '';
    final firstSegments = paths
        .where((path) => path.contains('/'))
        .map((path) => path.split('/').first)
        .toSet();
    if (firstSegments.length != 1) return '';
    final candidate = firstSegments.single;
    final allInside = paths.every((path) => path.startsWith('$candidate/'));
    return allInside ? candidate : '';
  }

  static bool _shouldIgnore(String path) {
    final parts = path.split('/');
    return parts.contains('.git') ||
        parts.contains('__MACOSX') ||
        parts.last == '.DS_Store';
  }
}
