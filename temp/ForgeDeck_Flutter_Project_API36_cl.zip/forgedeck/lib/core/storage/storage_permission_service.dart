import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class StoragePermissionResult {
  const StoragePermissionResult({
    required this.required,
    required this.granted,
    required this.permanentlyDenied,
  });

  final bool required;
  final bool granted;
  final bool permanentlyDenied;
}

class StoragePermissionService {
  const StoragePermissionService();

  Future<StoragePermissionResult> requestAtStartup() async {
    if (!Platform.isAndroid) {
      return const StoragePermissionResult(
        required: false,
        granted: true,
        permanentlyDenied: false,
      );
    }

    final info = await DeviceInfoPlugin().androidInfo;
    if (info.version.sdkInt >= 33) {
      return const StoragePermissionResult(
        required: false,
        granted: true,
        permanentlyDenied: false,
      );
    }

    var status = await Permission.storage.status;
    if (!status.isGranted) {
      status = await Permission.storage.request();
    }

    return StoragePermissionResult(
      required: true,
      granted: status.isGranted,
      permanentlyDenied: status.isPermanentlyDenied,
    );
  }
}
