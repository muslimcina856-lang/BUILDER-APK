import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../models/github_account.dart';

class AccountVault {
  AccountVault() : _storage = const FlutterSecureStorage();

  static const _metadataKey = 'forgedeck.accounts.metadata.v1';
  static const _activeAccountKey = 'forgedeck.accounts.active.v1';
  static const _tokenPrefix = 'forgedeck.account.token.';

  final FlutterSecureStorage _storage;

  Future<List<GitHubAccount>> readAccounts() async {
    final raw = await _storage.read(key: _metadataKey);
    if (raw == null || raw.isEmpty) return const [];

    final decoded = jsonDecode(raw);
    if (decoded is! List<dynamic>) return const [];

    final accounts = <GitHubAccount>[];
    for (final item in decoded) {
      if (item is! Map<String, dynamic>) continue;
      final id = item['id'] as String?;
      if (id == null || id.isEmpty) continue;
      final token = await _storage.read(key: '$_tokenPrefix$id');
      if (token == null || token.isEmpty) continue;
      accounts.add(GitHubAccount.fromMetadataJson(item, token: token));
    }
    return accounts;
  }

  Future<void> saveAccounts(List<GitHubAccount> accounts) async {
    final metadata = accounts.map((account) => account.toMetadataJson()).toList();
    await _storage.write(key: _metadataKey, value: jsonEncode(metadata));
    for (final account in accounts) {
      await _storage.write(
        key: '$_tokenPrefix${account.id}',
        value: account.token,
      );
    }
  }

  Future<void> removeAccount(GitHubAccount account) async {
    await _storage.delete(key: '$_tokenPrefix${account.id}');
  }

  Future<String?> readActiveAccountId() {
    return _storage.read(key: _activeAccountKey);
  }

  Future<void> writeActiveAccountId(String? id) async {
    if (id == null || id.isEmpty) {
      await _storage.delete(key: _activeAccountKey);
      return;
    }
    await _storage.write(key: _activeAccountKey, value: id);
  }

  Future<void> clear() async {
    await _storage.deleteAll();
  }
}
