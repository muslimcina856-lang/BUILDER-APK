package com.earlxz.forgedeck

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
