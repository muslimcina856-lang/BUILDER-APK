# Changelog

## 0.1.0

- Multi-akaun PAT dengan secure storage.
- Senarai repository dan pull-to-refresh.
- Pengurusan repository, branch, fail, isu, pull request, Actions dan release.
- Force push ZIP melalui Git Database API.
- Ikon dan tema ForgeDeck tersuai.
