# ForgeDeck

Aplikasi Android Flutter untuk mengurus beberapa akaun GitHub menggunakan Personal Access Token (PAT). Semua fungsi sentiasa tertakluk kepada jenis token, permission repository, polisi organisasi, branch protection dan endpoint GitHub yang menyokong token tersebut.

## Fungsi yang tersedia

- Onboarding PAT pada pembukaan pertama.
- Akaun tanpa had tetap pada peringkat aplikasi.
- Token disimpan melalui `flutter_secure_storage` dan tidak ditulis ke log atau URL.
- Paparan nama, avatar dan maklumat akaun aktif.
- Senarai repository dengan carian, penapis dan pull-to-refresh.
- Cipta, kemas kini, arkib, tukar visibility dan padam repository.
- Senarai branch, cipta branch, tukar default branch dan padam branch bukan default.
- Pelayar fail dan folder mengikut branch.
- Pratonton, edit, muat naik dan padam fail melalui Contents API.
- Isu: senarai, cipta, tutup dan buka semula.
- Pull request: senarai, cipta dan merge.
- GitHub Actions: senarai workflow, `workflow_dispatch`, run terkini, cancel dan rerun.
- Release: senarai, cipta dan padam release.
- Notifikasi akaun jika endpoint dan token membenarkan.
- Force push dari ZIP dengan Git Database API.

## Force push ZIP

Aliran ini tidak menjalankan `git` atau shell pada telefon:

1. ZIP dipilih melalui pemilih fail sistem.
2. Laluan fail diperiksa untuk menghalang `../`, `.git`, `__MACOSX` dan fail metadata tidak perlu.
3. Setiap fail dimuat naik sebagai Git blob.
4. Tree penuh baharu dibina tanpa `base_tree`, jadi tree lama diganti.
5. Commit baharu dicipta.
6. Ref branch dikemas kini dengan `force: true`.

Had keselamatan lalai:

- Maksimum 3000 fail.
- Maksimum 50 MB untuk satu fail.
- Maksimum 250 MB jumlah kandungan ZIP.
- Bit executable dipelihara jika ZIP menyimpan Unix permissions.
- Symbolic link ditolak; folder kosong tidak boleh dijejak oleh Git.
- Git LFS dan submodule khas belum diproses secara automatik.

## Izin storan Android

- Android 13 dan lebih baharu menggunakan Storage Access Framework/pemilih fail sistem untuk ZIP dan fail lain. Izin storan luas tidak diperlukan.
- Android 12 dan lebih lama akan meminta `READ_EXTERNAL_STORAGE` semasa aplikasi mula jika belum diberi.
- Aplikasi tidak meminta `MANAGE_EXTERNAL_STORAGE`.

## Jalankan projek

Keperluan minimum projek ini:

- Flutter 3.44.0 atau lebih baharu.
- Dart 3.12 atau lebih baharu.
- Java 17.
- Android SDK yang serasi dengan Flutter semasa.

```bash
dart run tool/prepare_android_wrapper.dart
flutter pub get
flutter analyze
flutter test
flutter run
```

Skrip persediaan mencipta projek sementara dengan Flutter SDK tempatan dan hanya menyalin `gradle-wrapper.jar`. Manifest, ikon dan konfigurasi ForgeDeck tidak disentuh.

Bina APK debug:

```bash
flutter build apk --debug
```

Bina APK release selepas menyediakan signing key sendiri:

```bash
flutter build apk --release
```

Konfigurasi `release` dalam projek ini masih menggunakan debug signing supaya projek mudah diuji. Tukar kepada upload keystore sebelum edaran sebenar.

## Keselamatan

Jangan letakkan PAT dalam:

- source code,
- `pubspec.yaml`,
- fail `.env` yang dibungkus dalam APK,
- log aplikasi,
- URL clone,
- screenshot atau mesej chat.

Token Telegram dan GitHub yang pernah dikongsi secara terbuka perlu direvoke dan diganti. Projek ini tidak mengandungi token contoh sebenar.

## Struktur utama

```text
lib/
  core/network/       GitHub REST dan Git Database API
  core/storage/       secure vault, permission, ZIP validation
  core/theme/         tema visual
  models/             model data GitHub
  state/              keadaan aplikasi dan multi-akaun
  ui/screens/         skrin utama dan fungsi repository
  ui/widgets/         komponen UI tersuai
```
