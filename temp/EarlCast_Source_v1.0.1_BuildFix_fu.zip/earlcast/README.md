# EarlCast

EarlCast ialah aplikasi Flutter Android yang menjalankan Node.js dan Baileys secara lokal di dalam APK. Tiada VPS, panel Telegram atau backend luar. Enjin WhatsApp disambungkan hanya ketika aplikasi berada di hadapan; apabila app masuk latar atau ditutup, queue dihentikan dan socket diputuskan.

> **Status projek:** proof-of-concept Android. Baileys menggunakan protokol WhatsApp Web tidak rasmi. Gunakan nombor ujian/sekunder dahulu dan jangan jadikan binaan ini sistem produksi tanpa ujian peranti sendiri.

## Fungsi yang tersedia

- Pair WhatsApp menggunakan nombor telefon dan pairing code.
- Simpan sesi di private app storage.
- Reconnect sesi apabila app dibuka semula.
- Putuskan socket semasa app masuk background; sambung semula ketika app kembali aktif.
- Ambil, cari dan pilih group.
- Had keras 50 group; had lalai 30 dan boleh dikecilkan.
- Hantar teks, gambar, video, audio dan dokumen lokal.
- Pilih sehingga 10 fail, maksimum 64 MB setiap fail.
- Queue satu demi satu dengan delay terkawal.
- Pause, resume, stop dan retry sehingga dua kali.
- Progress masa nyata dan history lokal.
- Auto-reply private sekali bagi setiap nombor untuk satu sesi app.
- Logout dan padam sesi lokal.
- Ikon EarlCast asli; tiada logo WhatsApp digunakan.

Fungsi berikut sengaja **tidak disediakan**:

- Scrape nombor atau ahli group.
- DM pukal kepada ahli group.
- Hidden mention atau mention semua secara senyap.
- Autojoin melalui senarai link.
- Penghantaran tanpa had atau concurrency agresif.
- Mod bypass, anti-ban atau penyamaran trafik.
- Background/foreground service yang kekal hidup.

## Struktur sistem

```text
Flutter UI
   │ native tagged-message bridge
   ▼
node_flutter / embedded Node.js
   │
   ▼
Baileys engine
   │ WebSocket
   ▼
WhatsApp
```

Aplikasi tidak membuka HTTP server, port LAN atau backend lokal berasaskan TCP. Flutter dan Node berkomunikasi melalui bridge native `node_flutter`.

## Keperluan build

- Windows 10/11, Linux atau macOS.
- Flutter stable yang menyertakan Dart 3.7.2 atau lebih baharu.
- Android Studio dan Android SDK.
- JDK 17.
- NDK `28.2.13676358`.
- Node.js dan npm pada PC untuk menyediakan `node_modules` ke dalam asset APK.
- Git untuk dependency legacy Baileys.
- Python 3.
- Peranti Android 7.0 atau lebih baharu (`minSdk 24`).

Semak tool:

```powershell
flutter doctor
node --version
npm --version
git --version
python --version
```

## Build cepat pada Windows

Ekstrak ZIP, buka PowerShell dalam folder `earlcast`, kemudian:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build_apk.ps1
```

APK release akan berada di:

```text
build\app\outputs\flutter-apk\app-release.apk
```

Binaan release semasa menggunakan debug signing untuk kegunaan peribadi. Tukar kepada release keystore sendiri sebelum pengedaran.

### Setup tanpa build

```powershell
.\scripts\setup.ps1
flutter run
```

### Linux/macOS

```bash
chmod +x scripts/*.sh scripts/bootstrap.py
./scripts/build_apk.sh
```

## Apa yang dibuat oleh setup

1. Menjana Android Gradle wrapper melalui `flutter create` jika wrapper tiada.
2. Menetapkan package ID `com.earlxz.earlcast`, `minSdk 24` dan NDK 27.
3. Menjalankan `flutter pub get`.
4. Menyalin `nodejs-project` ke `android/app/src/main/assets/nodejs-project`.
5. Menjalankan `npm install --omit=dev --omit=optional` dalam asset tersebut.
6. Menjalankan `postinstall` keselamatan untuk manifest legacy.
7. Menjana semula launcher icon Android.

Jangan jalankan `npm install` di root projek. Dependency Node mesti berada dalam folder asset Android supaya disertakan dalam APK.

## Cara guna

1. Buka app dan tunggu status engine menjadi hijau.
2. Masukkan nombor bersama kod negara, contohnya `60123456789`.
3. Tekan **Jana pairing code**.
4. Dalam WhatsApp buka **Linked devices → Link a device → Link with phone number**.
5. Masukkan code yang dipaparkan oleh EarlCast.
6. Refresh group, pilih group yang anda urus atau dibenarkan.
7. Tulis mesej dan pilih media dari telefon.
8. Semak ringkasan sasaran sebelum memulakan queue.
9. Kekalkan app di hadapan sehingga queue selesai.

Apabila app masuk background, EarlCast meminta queue berhenti dan menutup socket. Android masih berhak menamatkan proses pada bila-bila masa.

## Data lokal

Sesi Baileys disimpan di private app directory dalam subfolder:

```text
earlcast/wa-session
```

History penghantaran disimpan sebagai JSON lokal. Kandungan mesej penuh tidak dimasukkan dalam history; hanya preview ringkas dan statistik. Fail sesi tidak disimpan dalam Downloads dan Android backup dimatikan melalui manifest.

## Pilihan versi Baileys

### Laluan lalai: Node 18 compatibility

Manifest lalai menggunakan:

```text
baileys@6.7.8
```

Sebabnya ialah runtime Node.js Mobile yang dibekalkan oleh keluarga plugin semasa berasaskan Node 18, manakala Baileys 6.7.22 ke atas memerlukan Node 20.

Versi 6.7.8 mempunyai advisory kritikal `GHSA-qvv5-jq5g-4cgg / CVE-2026-48063`. Projek ini tidak memasangnya secara mentah. Semasa `npm install`, skrip wajib:

```text
nodejs-project/scripts/apply_security_backport.cjs
```

akan menerapkan guard rasmi ke dependency yang dipasang. Setup gagal jika patch tidak dapat diterapkan atau disahkan. Selain itu, app mematikan history sync dan menolak event `requestId` daripada auto-reply sebagai defense-in-depth.

Baca `SECURITY_PATCH.md`. Backport ini hanya menangani isu tertentu dan **tidak menjadikan versi legacy setara dengan Baileys terkini**.

### Laluan eksperimen: Baileys 7

Kod loader boleh membaca CommonJS legacy atau ESM Baileys 7. Manifest pilihan disediakan:

```powershell
.\scripts\use_baileys7.ps1
```

atau:

```bash
./scripts/use_baileys7.sh
```

Laluan ini memerlukan runtime Node.js Mobile 20/22 custom. Ia tidak serasi dengan runtime Node 18 stock dan belum disahkan pada peranti dalam projek ini.

Kembali ke manifest lalai:

```powershell
.\scripts\use_legacy.ps1
```

## Semakan source Node

Sebelum build penuh, selepas dependency selesai dipasang:

```powershell
cd android\app\src\main\assets\nodejs-project
npm run check
```

Untuk manifest legacy, arahan ini mesti mengesahkan marker backport keselamatan.

## Troubleshooting

### `Cannot find module 'baileys'`

Jalankan semula:

```powershell
.\scripts\setup.ps1
```

Pastikan folder berikut wujud:

```text
android\app\src\main\assets\nodejs-project\node_modules
```

### `Cannot find module 'flutter-bridge'`

Jangan jalankan `node main.js` secara terus pada PC. `flutter-bridge` dibekalkan oleh runtime native ketika app Android memulakan Node melalui `Nodejs.start()`.

### `npm install` gagal pada dependency Git

- Pastikan Git tersedia dalam `PATH`.
- Pastikan PC boleh mengakses GitHub dan registry npm.
- Padam folder asset Node, kemudian jalankan setup semula.
- Jangan gunakan `--ignore-scripts`; ia akan melangkau backport keselamatan.

### NDK atau Gradle gagal

Pasang NDK `28.2.13676358` melalui Android Studio SDK Manager, kemudian:

```powershell
flutter clean
.\scripts\setup.ps1
flutter build apk --release
```

### Pairing atau reconnect gagal

- Gunakan nombor dengan kod negara.
- Uji pada peranti arm64 sebenar.
- Logout dan pair semula jika sesi rosak.
- Pastikan app kekal di foreground ketika pairing.
- Perubahan protokol WhatsApp mungkin menyebabkan versi legacy berhenti berfungsi.

### APK terlalu besar

Embedded Node dan `node_modules` memang menambah saiz. Bina per ABI:

```powershell
flutter build apk --release --split-per-abi
```

## Struktur projek

```text
lib/
  controllers/app_controller.dart
  models/
  screens/
  services/node_engine_service.dart
nodejs-project/
  main.js
  engine/whatsapp_engine.cjs
  engine/campaign_queue.cjs
  engine/media.cjs
  scripts/apply_security_backport.cjs
  test/
android/
assets/icon/
scripts/
```

## Keselamatan asal ZIP

ZIP rujukan asal mengandungi token Telegram sebenar. Token itu tidak dimasukkan dalam EarlCast. Revoke/regenerate token lama melalui BotFather sebelum bot asal digunakan semula.

## Penggunaan bertanggungjawab

Gunakan hanya untuk group yang anda urus atau mempunyai izin. WhatsApp boleh mengehadkan atau memutuskan akaun yang melanggar syarat perkhidmatan. Projek ini tidak menjanjikan “anti-ban”.

## Lesen

Kod EarlCast menggunakan lesen MIT. Dependency pihak ketiga mempunyai lesen masing-masing; semak `THIRD_PARTY.md` sebelum mengedar source atau APK.
