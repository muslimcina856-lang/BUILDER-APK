import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';
import '../theme/app_theme.dart';
import '../models/extract_result.dart';
import '../services/history_service.dart';
import 'result_screen.dart';

class ExtractingScreen extends StatefulWidget {
  final String url;

  const ExtractingScreen({super.key, required this.url});

  @override
  State<ExtractingScreen> createState() => _ExtractingScreenState();
}

class _ExtractingScreenState extends State<ExtractingScreen> {
  late final WebViewController _controller;
  String _step = 'Menyediakan browser...';
  bool _hasError = false;
  String _errorMsg = '';
  bool _started = false;

  static const _ua =
      'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  void _initWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_ua)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() => _step = 'Memuat halaman...');
          },
          onPageFinished: (_) async {
            if (_started) return;
            _started = true;
            await _doFullExtract();
          },
          onWebResourceError: (err) {
            if (!_started && mounted) {
              setState(() {
                _hasError = true;
                _errorMsg = 'Gagal load: ${err.description}';
              });
            }
          },
        ),
      );

    String url = widget.url.trim();
    if (!url.startsWith('http')) url = 'https://$url';
    _controller.loadRequest(Uri.parse(url));
  }

  /// Auto-scroll to trigger lazy loading
  Future<void> _autoScroll() async {
    if (mounted) setState(() => _step = 'Scroll automatik (lazy load)...');

    // Scroll down in steps to trigger intersection observers / lazy load
    for (int i = 0; i < 8; i++) {
      await _controller.runJavaScript('''
        window.scrollBy({ top: window.innerHeight * 0.85, behavior: 'smooth' });
      ''');
      await Future.delayed(const Duration(milliseconds: 600));
    }

    // Scroll back to top
    await _controller.runJavaScript('window.scrollTo({ top: 0, behavior: "instant" });');
    await Future.delayed(const Duration(milliseconds: 500));

    // One more full scroll to bottom
    await _controller.runJavaScript('''
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    ''');
    await Future.delayed(const Duration(milliseconds: 1200));
    await _controller.runJavaScript('window.scrollTo({ top: 0 });');
  }

  Future<void> _doFullExtract() async {
    try {
      // 1. Initial wait for hydration
      if (mounted) setState(() => _step = 'Menunggu JavaScript & hydration...');
      await Future.delayed(const Duration(milliseconds: 2500));

      // 2. Auto scroll to load lazy content
      await _autoScroll();

      // 3. Extra wait after scroll
      if (mounted) setState(() => _step = 'Menunggu content tambahan...');
      await Future.delayed(const Duration(milliseconds: 1500));

      // 4. Extract HTML
      if (mounted) setState(() => _step = 'Mengambil HTML penuh...');
      final htmlRaw = await _controller.runJavaScriptReturningResult(
        'document.documentElement.outerHTML',
      );
      final html = _clean(htmlRaw.toString());

      // 5. Extract CSS
      if (mounted) setState(() => _step = 'Mengambil CSS...');
      final cssRaw = await _controller.runJavaScriptReturningResult('''
        (function(){
          let c = '';
          document.querySelectorAll('style').forEach((s,i)=>{
            c += '/* INLINE STYLE #'+(i+1)+' */\\n'+s.innerHTML+'\\n\\n';
          });
          document.querySelectorAll('link[rel="stylesheet"]').forEach(l=>{
            c += '/* LINK: '+l.href+' */\\n';
            try{
              if(l.sheet && l.sheet.cssRules){
                for(let r of l.sheet.cssRules) c += r.cssText+'\\n';
              }
            }catch(e){ c += '/* CORS */\\n'; }
            c += '\\n';
          });
          return c;
        })()
      ''');
      String css = _clean(cssRaw.toString());

      // 6. Extract JS
      if (mounted) setState(() => _step = 'Mengambil JavaScript...');
      final jsRaw = await _controller.runJavaScriptReturningResult('''
        (function(){
          let j = '';
          let n = 0;
          document.querySelectorAll('script').forEach(s=>{
            if(s.src){
              j += '/* EXTERNAL: '+s.src+' */\\n// '+s.src+'\\n\\n';
            } else if(s.innerHTML && s.innerHTML.trim()){
              n++;
              j += '/* INLINE SCRIPT #'+n+' */\\n'+s.innerHTML+'\\n\\n';
            }
          });
          return j;
        })()
      ''');
      String js = _clean(jsRaw.toString());

      // 7. Fetch external files
      if (mounted) setState(() => _step = 'Mengambil fail luaran...');
      final uri = Uri.parse(widget.url.startsWith('http') ? widget.url : 'https://${widget.url}');
      css = await _fetchExtras(css, html, uri, isCss: true);
      js = await _fetchExtras(js, html, uri, isCss: false);

      final result = ExtractResult(
        url: uri.toString(),
        html: html,
        css: css.isEmpty ? '/* Tiada CSS */' : css,
        js: js.isEmpty ? '/* Tiada JS */' : js,
        extractedAt: DateTime.now(),
        htmlSize: utf8.encode(html).length,
        cssSize: utf8.encode(css).length,
        jsSize: utf8.encode(js).length,
      );

      await HistoryService.addToHistory(result);

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ResultScreen(result: result)),
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _hasError = true;
          _errorMsg = e.toString().replaceFirst('Exception: ', '');
        });
      }
    }
  }

  Future<String> _fetchExtras(String current, String html, Uri base, {required bool isCss}) async {
    final set = <String>{};
    final pattern = isCss
        ? RegExp(r'''href=["']([^"']+\.css[^"']*)["']''', caseSensitive: false)
        : RegExp(r'''src=["']([^"']+\.js[^"']*)["']''', caseSensitive: false);

    for (final m in pattern.allMatches(html)) {
      set.add(m.group(1)!);
    }

    final buf = StringBuffer(current);
    int count = 0;
    for (final link in set) {
      if (link.startsWith('data:')) continue;
      try {
        final full = link.startsWith('http')
            ? link
            : link.startsWith('//')
                ? '${base.scheme}:$link'
                : link.startsWith('/')
                    ? '${base.scheme}://${base.host}$link'
                    : '${base.scheme}://${base.host}/$link';
        if (current.contains(full)) continue;
        final res = await http.get(Uri.parse(full), headers: {'User-Agent': _ua})
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) {
          count++;
          buf.writeln('\n/* FETCHED: $full */');
          final body = res.body;
          if (body.length > 1800000) {
            buf.writeln(body.substring(0, 120000));
            buf.writeln('/* truncated */');
          } else {
            buf.writeln(body);
          }
        }
      } catch (_) {}
    }
    return buf.toString();
  }

  String _clean(String s) {
    if (s.startsWith('"') && s.endsWith('"')) s = s.substring(1, s.length - 1);
    return s
        .replaceAll(r'\"', '"')
        .replaceAll(r'\n', '\n')
        .replaceAll(r'\t', '\t')
        .replaceAll(r'\\', r'\')
        .replaceAll(r'\u003C', '<');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Stack(
        children: [
          Opacity(
            opacity: 0.02,
            child: WebViewWidget(controller: _controller),
          ),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (!_hasError) ...[
                      const SizedBox(
                        width: 36,
                        height: 36,
                        child: CircularProgressIndicator(strokeWidth: 3, color: AppTheme.primary),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        _step,
                        style: const TextStyle(fontSize: 15, color: AppTheme.textSecondary),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Auto-scroll dijalankan supaya\nlazy-load & content tersembunyi turut diambil',
                        style: TextStyle(fontSize: 12, color: AppTheme.textMuted),
                        textAlign: TextAlign.center,
                      ),
                    ] else ...[
                      const Icon(Icons.error_outline_rounded, color: AppTheme.error, size: 48),
                      const SizedBox(height: 16),
                      Text(
                        _errorMsg,
                        style: const TextStyle(color: AppTheme.error, fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('KEMBALI'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
