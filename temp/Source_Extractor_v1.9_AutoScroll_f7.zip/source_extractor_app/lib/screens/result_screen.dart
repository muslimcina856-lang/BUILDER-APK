import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../providers/theme_provider.dart';
import '../models/extract_result.dart';
import '../services/zip_service.dart';
import '../services/mirror_service.dart';
import '../widgets/code_view.dart';
import '../widgets/premium_button.dart';
import 'preview_screen.dart';

class ResultScreen extends StatefulWidget {
  final ExtractResult result;

  const ResultScreen({super.key, required this.result});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isZipping = false;
  bool _isMirroring = false;
  int _viewMode = 0; // 0 = code tabs, 1 = directory style

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _downloadZip() async {
    setState(() => _isZipping = true);
    HapticFeedback.mediumImpact();
    try {
      await ZipService.createAndShareZip(widget.result);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ZIP kod berjaya')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isZipping = false);
    }
  }

  Future<void> _downloadMirror() async {
    setState(() => _isMirroring = true);
    HapticFeedback.mediumImpact();
    try {
      final mirror = await MirrorService.createMirror(
        rawUrl: widget.result.url,
        html: widget.result.html,
        onProgress: (_) {},
      );
      await MirrorService.shareAsZip(mirror);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Mirror siap: ${mirror.assets.length + 1} fail')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mirror: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isMirroring = false);
    }
  }

  void _shareAll() {
    final text = '''
SOURCE EXTRACTOR
URL: ${widget.result.url}
Saiz: ${widget.result.formattedTotalSize}

===== HTML =====
${widget.result.html}

===== CSS =====
${widget.result.css}

===== JS =====
${widget.result.js}
''';
    Share.share(text, subject: 'Source - ${widget.result.url}');
  }

  void _copyCurrent() {
    String content;
    switch (_tabController.index) {
      case 0:
        content = widget.result.html;
        break;
      case 1:
        content = widget.result.css;
        break;
      default:
        content = widget.result.js;
    }
    Clipboard.setData(ClipboardData(text: content));
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kod disalin')),
    );
  }

  Future<void> _openOriginal() async {
    final uri = Uri.tryParse(widget.result.url);
    if (uri != null) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDark;
    final host = Uri.tryParse(widget.result.url)?.host ?? widget.result.url;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 6, 8, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          host,
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          widget.result.formattedTotalSize,
                          style: TextStyle(
                            fontSize: 12,
                            color: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _openOriginal,
                    icon: const Icon(Icons.open_in_new_rounded, size: 20),
                    tooltip: 'Buka laman asal',
                  ),
                  IconButton(
                    onPressed: _copyCurrent,
                    icon: const Icon(Icons.copy_all_rounded, size: 20),
                    tooltip: 'Salin',
                  ),
                ],
              ),
            ),

            // Stats
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
              child: Row(
                children: [
                  _StatChip(label: 'HTML', value: _fmt(widget.result.htmlSize), color: const Color(0xFFE34C26)),
                  const SizedBox(width: 8),
                  _StatChip(label: 'CSS', value: _fmt(widget.result.cssSize), color: const Color(0xFF264DE4)),
                  const SizedBox(width: 8),
                  _StatChip(label: 'JS', value: _fmt(widget.result.jsSize), color: const Color(0xFFCA8A04)),
                ],
              ),
            ),

            // View mode toggle
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  _ModeChip(
                    label: 'Kod',
                    selected: _viewMode == 0,
                    onTap: () => setState(() => _viewMode = 0),
                  ),
                  const SizedBox(width: 8),
                  _ModeChip(
                    label: 'Direktori',
                    selected: _viewMode == 1,
                    onTap: () => setState(() => _viewMode = 1),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 6),

            // Content
            Expanded(
              child: _viewMode == 0 ? _buildCodeTabs(isDark) : _buildDirectoryView(isDark),
            ),

            // Bottom actions - fixed overflow
            Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(
                    color: (isDark ? AppTheme.border : AppTheme.lightBorder).withOpacity(0.7),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _ActionBtn(
                      label: 'Mirror',
                      icon: Icons.account_tree_rounded,
                      loading: _isMirroring,
                      filled: true,
                      onTap: _downloadMirror,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _ActionBtn(
                      label: 'Kod ZIP',
                      icon: Icons.folder_zip_rounded,
                      loading: _isZipping,
                      filled: false,
                      onTap: _downloadZip,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _ActionBtn(
                      label: 'Preview',
                      icon: Icons.visibility_rounded,
                      loading: false,
                      filled: false,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PreviewScreen(result: widget.result),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCodeTabs(bool isDark) {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.surfaceLight : AppTheme.lightSurfaceLight,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isDark ? AppTheme.border : AppTheme.lightBorder),
          ),
          child: TabBar(
            controller: _tabController,
            indicator: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            labelColor: AppTheme.primary,
            unselectedLabelColor: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
            labelStyle: GoogleFonts.spaceGrotesk(fontSize: 13, fontWeight: FontWeight.w700),
            tabs: const [
              Tab(text: 'HTML'),
              Tab(text: 'CSS'),
              Tab(text: 'JS'),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TabBarView(
              controller: _tabController,
              children: [
                CodeView(code: widget.result.html, language: 'html'),
                CodeView(code: widget.result.css, language: 'css'),
                CodeView(code: widget.result.js, language: 'javascript'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDirectoryView(bool isDark) {
    final files = <_FileItem>[
      _FileItem('index.html', _fmt(widget.result.htmlSize), Icons.html, widget.result.html, 'html'),
      _FileItem('styles.css', _fmt(widget.result.cssSize), Icons.css, widget.result.css, 'css'),
      _FileItem('scripts.js', _fmt(widget.result.jsSize), Icons.javascript, widget.result.js, 'javascript'),
    ];

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: files.length,
      itemBuilder: (context, index) {
        final f = files[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.card : AppTheme.lightCard,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: isDark ? AppTheme.border : AppTheme.lightBorder),
          ),
          child: ListTile(
            leading: Icon(f.icon, color: AppTheme.primary, size: 22),
            title: Text(
              f.name,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
            ),
            subtitle: Text(
              f.size,
              style: TextStyle(
                fontSize: 12,
                color: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
              ),
            ),
            trailing: const Icon(Icons.chevron_right_rounded, size: 20),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => _SingleFileScreen(
                    title: f.name,
                    code: f.content,
                    language: f.lang,
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  String _fmt(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color, letterSpacing: 0.5)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _ModeChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ModeChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppTheme.primary.withOpacity(0.5) : AppTheme.border,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: selected ? AppTheme.primary : AppTheme.textMuted,
          ),
        ),
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool loading;
  final bool filled;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.label,
    required this.icon,
    required this.loading,
    required this.filled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: filled ? AppTheme.primary : Colors.transparent,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: loading ? null : onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: filled ? null : Border.all(color: AppTheme.primary.withOpacity(0.6)),
          ),
          child: loading
              ? const Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  ),
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, size: 18, color: filled ? Colors.white : AppTheme.primary),
                    const SizedBox(height: 4),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: filled ? Colors.white : AppTheme.primary,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _FileItem {
  final String name;
  final String size;
  final IconData icon;
  final String content;
  final String lang;

  _FileItem(this.name, this.size, this.icon, this.content, this.lang);
}

class _SingleFileScreen extends StatelessWidget {
  final String title;
  final String code;
  final String language;

  const _SingleFileScreen({
    required this.title,
    required this.code,
    required this.language,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: code));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Disalin')),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: CodeView(code: code, language: language),
      ),
    );
  }
}
