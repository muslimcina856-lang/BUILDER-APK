package com.batteryalarm.earl;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

public class BatteryAlarmService extends Service {

    private static final String CHANNEL_ID = "battery_alarm_channel";
    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_ALARM_TRIGGERED = "alarm_triggered";

    private static boolean running = false;

    private int threshold = 80;
    private Uri ringtoneUri;
    private boolean alarmTriggered = false;

    private PowerManager.WakeLock wakeLock;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int batteryPct = (level * 100) / scale;

            boolean isCharging = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                == BatteryManager.BATTERY_STATUS_CHARGING;

            updateNotification(batteryPct, isCharging);

            if (batteryPct >= threshold) {
                if (!alarmTriggered) {
                    alarmTriggered = true;
                    saveAlarmTriggered(true);
                    AlarmHelper.startAlarm(context, ringtoneUri, threshold);
                }
            } else {
                if (alarmTriggered) {
                    alarmTriggered = false;
                    saveAlarmTriggered(false);
                    AlarmHelper.stopAlarm(context);
                }
            }
        }
    };

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createNotificationChannel();
        acquireWakeLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        threshold = intent != null ? intent.getIntExtra("threshold", 80) : 80;

        String uriStr = intent != null ? intent.getStringExtra("ringtone_uri") : null;
        ringtoneUri = uriStr != null ? Uri.parse(uriStr) : null;

        alarmTriggered = getAlarmTriggered();

        // Re-derive the alarm state from the current battery level every time this runs -
        // whether that's a cold start (app reopened, reboot) or a warm redelivery from a
        // threshold change while already running - rather than trusting a persisted flag that
        // could be stale relative to whatever threshold is now in effect. Symmetric in both
        // directions: this is what stops a threshold change from either resurrecting an alarm
        // that no longer applies, or leaving one sounding that no longer should.
        int currentPct = readCurrentBatteryPercent();
        if (currentPct >= threshold) {
            if (!alarmTriggered) {
                alarmTriggered = true;
                saveAlarmTriggered(true);
            }
            Uri ringtoneForAlarm = ringtoneUri;
            if (ringtoneForAlarm == null) {
                ringtoneForAlarm = android.media.RingtoneManager
                    .getDefaultUri(android.media.RingtoneManager.TYPE_ALARM);
            }
            AlarmHelper.startAlarm(this, ringtoneForAlarm, threshold);
        } else if (alarmTriggered) {
            alarmTriggered = false;
            saveAlarmTriggered(false);
            AlarmHelper.stopAlarm(this);
        }

        Notification notification = buildNotification(0, false);
        startForeground(1, notification);

        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            unregisterReceiver(batteryReceiver);
        } catch (IllegalArgumentException ignored) {}

        AlarmHelper.stopAlarm(this);
        // Without this, alarm_triggered stays true in storage after a normal stop. The next
        // time monitoring starts, onStartCommand() below would see that stale true and sound
        // the alarm again immediately - regardless of what the battery level or threshold
        // actually are by then.
        saveAlarmTriggered(false);
        releaseWakeLock();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Battery Alarm",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Battery level monitoring notifications");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(int batteryPct, boolean isCharging) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        String contentText = "Battery: " + batteryPct + "% | Threshold: " + threshold + "%"
            + (isCharging ? " | Charging" : "");

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Battery Alarm")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    private void updateNotification(int batteryPct, boolean isCharging) {
        Notification notification = buildNotification(batteryPct, isCharging);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.notify(1, notification);
        }
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "BatteryAlarm:WakeLock"
            );
            wakeLock.acquire(10 * 60 * 1000L);
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            wakeLock = null;
        }
    }

    private int readCurrentBatteryPercent() {
        Intent batteryStatus = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (batteryStatus == null) return 0;
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return scale > 0 ? (level * 100) / scale : 0;
    }

    private boolean getAlarmTriggered() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getBoolean(KEY_ALARM_TRIGGERED, false);
    }

    private void saveAlarmTriggered(boolean triggered) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALARM_TRIGGERED, triggered)
            .apply();
    }
}
