package com.batteryalarm.earl;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_THRESHOLD = "threshold";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_RINGTONE_URI = "ringtone_uri";

    private TextView tvBatteryLevel;
    private Button btnStopAlarm;
    private TextView tvThresholdValue;
    private SeekBar seekBarThreshold;
    private SwitchMaterial switchService;
    private Button btnPickRingtone;
    private TextView tvRingtoneName;
    private TextView tvServiceStatus;

    private int currentBatteryLevel = 0;
    private Uri ringtoneUri;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            currentBatteryLevel = (level * 100) / scale;
            updateBatteryDisplay();
        }
    };

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied - alarm may not work", Toast.LENGTH_LONG).show();
            }
        });

    private final ActivityResultLauncher<Intent> ringtonePickerLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri pickedUri = result.getData().getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (pickedUri != null) {
                    ringtoneUri = pickedUri;
                    saveRingtoneUri(pickedUri);
                    updateRingtoneDisplay();
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        loadPreferences();
        requestPermissions();
        setupListeners();
        updateServiceStatus();
        updateRingtoneDisplay();
        updateAlarmActiveUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        updateServiceStatus();
        updateAlarmActiveUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(batteryReceiver);
        } catch (IllegalArgumentException ignored) {}
    }

    private void initViews() {
        tvBatteryLevel = findViewById(R.id.tv_battery_level);
        btnStopAlarm = findViewById(R.id.btn_stop_alarm);
        tvThresholdValue = findViewById(R.id.tv_threshold_value);
        seekBarThreshold = findViewById(R.id.seekbar_threshold);
        switchService = findViewById(R.id.switch_service);
        btnPickRingtone = findViewById(R.id.btn_pick_ringtone);
        tvRingtoneName = findViewById(R.id.tv_ringtone_name);
        tvServiceStatus = findViewById(R.id.tv_service_status);
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int threshold = prefs.getInt(KEY_THRESHOLD, 80);
        seekBarThreshold.setProgress(threshold);
        tvThresholdValue.setText(threshold + "%");
        boolean serviceRunning = prefs.getBoolean(KEY_SERVICE_RUNNING, false);
        switchService.setChecked(serviceRunning);

        String uriStr = prefs.getString(KEY_RINGTONE_URI, null);
        if (uriStr != null) {
            ringtoneUri = Uri.parse(uriStr);
        } else {
            ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        }
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            boolean alreadyIgnoring = powerManager != null
                && powerManager.isIgnoringBatteryOptimizations(getPackageName());
            if (!alreadyIgnoring) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }

    private void setupListeners() {
        seekBarThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 10) {
                    progress = 10;
                    if (fromUser) {
                        // Actually move the thumb, not just the displayed text - previously this
                        // only clamped the local variable, so dragging below 10 showed "10%" on
                        // screen while seekBar.getProgress() (what actually got saved and used
                        // to arm the alarm) still held the real, lower, un-clamped value.
                        seekBar.setProgress(10);
                    }
                }
                tvThresholdValue.setText(progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveThreshold(seekBar.getProgress());
            }
        });

        switchService.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startMonitoring();
            } else {
                stopMonitoring();
            }
        });

        btnPickRingtone.setOnClickListener(v -> pickRingtone());

        btnStopAlarm.setOnClickListener(v -> {
            AlarmHelper.stopAlarm(this);
            updateAlarmActiveUi();
        });
    }

    private void startMonitoring() {
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            Toast.makeText(this, "Notifications disabled - enable in settings", Toast.LENGTH_LONG).show();
            switchService.setChecked(false);
            return;
        }

        int threshold = seekBarThreshold.getProgress();
        Intent serviceIntent = new Intent(this, BatteryAlarmService.class);
        serviceIntent.putExtra("threshold", threshold);
        if (ringtoneUri != null) {
            serviceIntent.putExtra("ringtone_uri", ringtoneUri.toString());
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        saveServiceRunning(true);
        // Not calling updateServiceStatus() here: startForegroundService() is async, so
        // BatteryAlarmService.isRunning() would still read false for a moment, and re-checking
        // the switch against that stale value is what snapped it back off after one tap. The
        // switch already reflects the user's tap correctly, so it's left alone; only the status
        // label is set directly here.
        tvServiceStatus.setText("Status: Monitoring active");
        tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        Toast.makeText(this, "Battery alarm started at " + threshold + "%", Toast.LENGTH_SHORT).show();
    }

    private void stopMonitoring() {
        stopService(new Intent(this, BatteryAlarmService.class));
        saveServiceRunning(false);
        // Same reasoning as startMonitoring(): stopService() is async too, so this sets the
        // status directly instead of re-deriving it from isRunning() immediately afterward.
        tvServiceStatus.setText("Status: Stopped");
        tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        Toast.makeText(this, "Battery alarm stopped", Toast.LENGTH_SHORT).show();
    }

    private void pickRingtone() {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        if (ringtoneUri != null) {
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri);
        }
        ringtonePickerLauncher.launch(intent);
    }

    private void updateBatteryDisplay() {
        tvBatteryLevel.setText(currentBatteryLevel + "%");
        int color;
        if (currentBatteryLevel < 20) {
            color = ContextCompat.getColor(this, android.R.color.holo_red_dark);
        } else if (currentBatteryLevel <= seekBarThreshold.getProgress()) {
            color = ContextCompat.getColor(this, android.R.color.holo_orange_dark);
        } else {
            color = ContextCompat.getColor(this, android.R.color.holo_green_dark);
        }
        tvBatteryLevel.setTextColor(color);
    }

    private void updateServiceStatus() {
        boolean running = BatteryAlarmService.isRunning();
        if (running) {
            tvServiceStatus.setText("Status: Monitoring active");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            tvServiceStatus.setText("Status: Stopped");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        }
        switchService.setChecked(running);
    }

    private void updateAlarmActiveUi() {
        // The notification's own Dismiss button only shows up in the notification shade. When
        // the alarm fires with the screen off/locked, the full-screen alert launches this
        // Activity directly instead, and that view never had any way to silence the alarm - this
        // button fills that gap and calls the exact same AlarmHelper.stopAlarm() as Dismiss does.
        btnStopAlarm.setVisibility(AlarmHelper.isAlarmActive() ? View.VISIBLE : View.GONE);
    }

    private void updateRingtoneDisplay() {
        if (ringtoneUri != null) {
            String name = RingtoneManager.getRingtone(this, ringtoneUri).getTitle(this);
            tvRingtoneName.setText(name);
        } else {
            tvRingtoneName.setText("Default alarm");
        }
    }

    private void saveThreshold(int threshold) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_THRESHOLD, threshold)
            .apply();

        // Previously, changing the slider while monitoring was already running never reached
        // the live service - it kept comparing battery level against whatever threshold it was
        // originally started with, which is why the alarm could fire below what the screen now
        // showed as the target. startForegroundService()/startService() on an already-running
        // service just redelivers onStartCommand() with the new extras, so this pushes the
        // update through the same path it already uses to start monitoring in the first place.
        if (BatteryAlarmService.isRunning()) {
            Intent serviceIntent = new Intent(this, BatteryAlarmService.class);
            serviceIntent.putExtra("threshold", threshold);
            if (ringtoneUri != null) {
                serviceIntent.putExtra("ringtone_uri", ringtoneUri.toString());
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        }

        BatteryAlarmWidgetProvider.refreshAllWidgets(this, threshold, BatteryAlarmService.isRunning());
    }

    private void saveServiceRunning(boolean running) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SERVICE_RUNNING, running)
            .apply();
        BatteryAlarmWidgetProvider.refreshAllWidgets(this, seekBarThreshold.getProgress(), running);
    }

    private void saveRingtoneUri(Uri uri) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_RINGTONE_URI, uri.toString())
            .apply();
    }
}
