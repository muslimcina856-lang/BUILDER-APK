import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_controller.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();

    if (app.accounts.isEmpty) {
      return const Center(child: Text('Tiada akaun'));
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Notifikasi',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        const Text(
          'Hidupkan notifikasi untuk menerima makluman berkaitan akaun Cloudflare. Default adalah Off.',
          style: TextStyle(color: AppColors.muted, height: 1.5),
        ),
        const SizedBox(height: 24),
        ...app.accounts.map((account) {
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: SwitchListTile(
              title: Text(account.email, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                account.notificationsEnabled ? 'Notifikasi aktif' : 'Notifikasi dimatikan',
                style: const TextStyle(fontSize: 13),
              ),
              value: account.notificationsEnabled,
              activeColor: AppColors.primary,
              onChanged: (value) {
                app.toggleNotifications(account.id, value);
              },
            ),
          );
        }),
        const SizedBox(height: 20),
        const Text(
          'Nota: Notifikasi sebenar bergantung kepada sokongan Cloudflare API dan permission token.',
          style: TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ],
    );
  }
}
