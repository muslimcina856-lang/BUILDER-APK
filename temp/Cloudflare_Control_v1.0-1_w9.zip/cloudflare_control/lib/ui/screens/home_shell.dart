import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_controller.dart';
import 'settings_screen.dart';
import 'dns_screen.dart';
import 'email_routing_screen.dart';
import 'dashboard_screen.dart';
import 'workers_screen.dart';
import 'storage_screen.dart';
import 'account_screen.dart';
import 'security_screen.dart';
import 'notifications_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;

  final List<_MenuItem> _menu = [
    _MenuItem(Icons.dashboard_outlined, 'Dashboard', 'Dashboard'),
    _MenuItem(Icons.language, 'Domain & DNS', 'Domain & DNS'),
    _MenuItem(Icons.email_outlined, 'Email Routing', 'Email Routing'),
    _MenuItem(Icons.code, 'Workers & Pages', 'Workers & Pages'),
    _MenuItem(Icons.storage_outlined, 'Storage', 'Storage'),
    _MenuItem(Icons.security_outlined, 'Security', 'Security'),
    _MenuItem(Icons.account_circle_outlined, 'Account', 'Account'),
    _MenuItem(Icons.notifications_outlined, 'Notifikasi', 'Notifications'),
  ];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final account = app.activeAccount;

    return Scaffold(
      appBar: AppBar(
        title: Text(account?.email ?? 'Cloudflare Control'),
        actions: [
          if (app.accounts.length > 1)
            PopupMenuButton<String>(
              onSelected: (id) => app.setActiveAccount(id),
              itemBuilder: (ctx) => app.accounts
                  .map((a) => PopupMenuItem(
                        value: a.id,
                        child: Text(a.email),
                      ))
                  .toList(),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Icon(Icons.swap_horiz),
              ),
            ),
        ],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset('assets/icon/app_icon.png', width: 48, height: 48),
                    const SizedBox(height: 12),
                    const Text(
                      'Cloudflare Control',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (account != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        account.email,
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ],
                ),
              ),

              // Menu items
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    for (int i = 0; i < _menu.length; i++)
                      ListTile(
                        leading: Icon(
                          _menu[i].icon,
                          color: _selectedIndex == i ? AppColors.primary : AppColors.muted,
                        ),
                        title: Text(
                          _menu[i].ms,
                          style: TextStyle(
                            fontWeight: _selectedIndex == i ? FontWeight.w600 : FontWeight.w400,
                            color: _selectedIndex == i ? AppColors.primary : AppColors.text,
                          ),
                        ),
                        selected: _selectedIndex == i,
                        onTap: () {
                          setState(() => _selectedIndex = i);
                          Navigator.pop(context);
                        },
                      ),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.settings_outlined),
                      title: const Text('Tetapan'),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SettingsScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ),

              // Footer
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  '© 2026 Earlxz. All rights reserved.',
                  style: TextStyle(fontSize: 11, color: AppColors.muted),
                ),
              ),
            ],
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return const DashboardScreen();
      case 1:
        return const DnsScreen();
      case 2:
        return const EmailRoutingScreen();
      case 3:
        return const WorkersScreen();
      case 4:
        return const StorageScreen();
      case 5:
        return const SecurityScreen();
      case 6:
        return const AccountScreen();
      case 7:
        return const NotificationsScreen();
      default:
        return const Center(child: Text('Coming soon'));
    }
  }
}





class _MenuItem {
  final IconData icon;
  final String ms;
  final String en;
  const _MenuItem(this.icon, this.ms, this.en);
}
