import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class EmailRoutingScreen extends StatefulWidget {
  const EmailRoutingScreen({super.key});

  @override
  State<EmailRoutingScreen> createState() => _EmailRoutingScreenState();
}

class _EmailRoutingScreenState extends State<EmailRoutingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  List<dynamic> zones = [];
  List<dynamic> destinations = [];
  bool loadingZones = true;
  bool loadingDest = true;

  String? selectedZoneId;
  String? selectedZoneName;
  List<dynamic> rules = [];
  bool loadingRules = false;
  Map<String, dynamic>? catchAll;
  bool loadingCatchAll = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadZones();
    _loadDestinations();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadZones() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() => loadingZones = true);

    try {
      final api = CloudflareApi(account);
      final data = await api.getZones();
      setState(() {
        zones = data;
        loadingZones = false;
      });
    } catch (e) {
      setState(() => loadingZones = false);
    }
  }

  Future<void> _loadDestinations() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() => loadingDest = true);

    try {
      final api = CloudflareApi(account);
      final data = await api.getEmailDestinationAddresses();
      setState(() {
        destinations = data;
        loadingDest = false;
      });
    } catch (e) {
      setState(() => loadingDest = false);
    }
  }

  Future<void> _loadRules(String zoneId, String zoneName) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      selectedZoneId = zoneId;
      selectedZoneName = zoneName;
      loadingRules = true;
      rules = [];
    });

    try {
      final api = CloudflareApi(account);
      final data = await api.getEmailRoutingRules(zoneId);
      Map<String, dynamic>? ca;
      try {
        ca = await api.getCatchAll(zoneId);
      } catch (_) {}
      setState(() {
        rules = data;
        catchAll = ca;
        loadingRules = false;
      });
    } catch (e) {
      setState(() => loadingRules = false);
    }
  }

  Future<void> _addDestination() async {
    final emailController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tambah Destination Email'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Cloudflare akan hantar email verification.\nBuka Gmail/email tersebut dan klik link untuk verify.',
              style: TextStyle(fontSize: 13, height: 1.45),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email destination',
                hintText: 'contoh@gmail.com',
              ),
              keyboardType: TextInputType.emailAddress,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hantar Verification')),
        ],
      ),
    );

    if (result != true) return;

    final email = emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email tidak sah'), backgroundColor: AppColors.danger),
      );
      return;
    }

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createEmailDestinationAddress(email);
      await _loadDestinations();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Verification email dah dihantar. Check inbox & klik link verify.'),
            backgroundColor: AppColors.success,
            duration: Duration(seconds: 5),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _createRule() async {
    if (selectedZoneId == null) return;

    final verifiedDest = destinations.where((d) => d['verified'] != null).toList();

    if (verifiedDest.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tiada destination verified. Tambah & verify di tab Destination dulu.'),
          backgroundColor: AppColors.warning,
          duration: Duration(seconds: 4),
        ),
      );
      _tabController.animateTo(1);
      return;
    }

    final prefixController = TextEditingController();
    String? selectedDest = verifiedDest.first['email'] as String?;

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Cipta Email Address'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: prefixController,
                decoration: InputDecoration(
                  labelText: 'Prefix',
                  suffixText: '@$selectedZoneName',
                  hintText: 'info / support / hello',
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedDest,
                decoration: const InputDecoration(labelText: 'Forward ke'),
                items: verifiedDest
                    .map((d) => DropdownMenuItem(
                          value: d['email'] as String,
                          child: Text(d['email']),
                        ))
                    .toList(),
                onChanged: (v) => setDialogState(() => selectedDest = v),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
          ],
        ),
      ),
    );

    if (result != true) return;

    final prefix = prefixController.text.trim().toLowerCase();
    if (prefix.isEmpty || selectedDest == null) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createEmailRoutingRule(selectedZoneId!, {
        'name': prefix,
        'enabled': true,
        'matchers': [
          {'type': 'literal', 'field': 'to', 'value': '$prefix@$selectedZoneName'}
        ],
        'actions': [
          {'type': 'forward', 'value': [selectedDest]}
        ],
      });

      await _loadRules(selectedZoneId!, selectedZoneName!);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$prefix@$selectedZoneName berjaya dicipta'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger, duration: const Duration(seconds: 5)),
        );
      }
    }
  }

  Future<void> _deleteRule(String ruleId, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Email Address?'),
        content: Text('Padam $name?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );

    if (confirm != true || selectedZoneId == null) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteEmailRoutingRule(selectedZoneId!, ruleId);
      await _loadRules(selectedZoneId!, selectedZoneName!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _toggleCatchAll(bool enable) async {
    if (selectedZoneId == null) return;

    final verifiedDest = destinations.where((d) => d['verified'] != null).toList();
    if (enable && verifiedDest.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Perlukan destination yang verified untuk aktifkan Catch-all'),
          backgroundColor: AppColors.warning,
        ),
      );
      _tabController.animateTo(1);
      return;
    }

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      final destEmail = verifiedDest.isNotEmpty ? verifiedDest.first['email'] : null;
      await api.updateCatchAll(selectedZoneId!, {
        'enabled': enable,
        'matchers': [{'type': 'all'}],
        'actions': [
          if (enable && destEmail != null)
            {'type': 'forward', 'value': [destEmail]}
          else
            {'type': 'drop'}
        ],
      });
      await _loadRules(selectedZoneId!, selectedZoneName!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(enable ? 'Catch-all diaktifkan' : 'Catch-all dimatikan'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Material(
          color: Colors.white,
          child: TabBar(
            controller: _tabController,
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.muted,
            indicatorColor: AppColors.primary,
            tabs: const [
              Tab(text: 'Routing Rules'),
              Tab(text: 'Destination'),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildRulesTab(),
              _buildDestinationTab(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRulesTab() {
    if (loadingZones) return const Center(child: CircularProgressIndicator());

    if (selectedZoneId != null) {
      return Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => setState(() {
                    selectedZoneId = null;
                    selectedZoneName = null;
                    rules = [];
                  }),
                ),
                Expanded(
                  child: Text(selectedZoneName ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: _createRule,
                  tooltip: 'Cipta Email Address',
                ),
              ],
            ),
          ),
          Expanded(
            child: loadingRules
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    padding: const EdgeInsets.all(12),
                    children: [
                      // Catch-all card
                      if (catchAll != null)
                        Card(
                          color: (catchAll!['enabled'] == true)
                              ? AppColors.primary.withOpacity(0.08)
                              : null,
                          child: SwitchListTile(
                            title: const Text('Catch-all Address', style: TextStyle(fontWeight: FontWeight.w600)),
                            subtitle: Text(
                              catchAll!['enabled'] == true
                                  ? 'Aktif — semua email lain akan di-forward'
                                  : 'Tidak aktif',
                            ),
                            value: catchAll!['enabled'] == true,
                            activeColor: AppColors.primary,
                            onChanged: (v) => _toggleCatchAll(v),
                          ),
                        ),
                      const SizedBox(height: 8),
                      if (rules.isEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 40),
                          child: Column(
                            children: [
                              const Icon(Icons.email_outlined, size: 56, color: AppColors.muted),
                              const SizedBox(height: 12),
                              const Text('Tiada email address lagi'),
                              const SizedBox(height: 8),
                              const Text(
                                'Pastikan ada Destination yang verified sebelum create.',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: AppColors.muted, fontSize: 13),
                              ),
                              const SizedBox(height: 20),
                              FilledButton.icon(
                                onPressed: _createRule,
                                icon: const Icon(Icons.add),
                                label: const Text('Cipta Email Address'),
                              ),
                            ],
                          ),
                        )
                      else
                        ...rules.map((r) {
                          final matchers = r['matchers'] as List? ?? [];
                          final actions = r['actions'] as List? ?? [];
                          String address = '-';
                          String destination = '-';
                          final enabled = r['enabled'] == true;

                          if (matchers.isNotEmpty) {
                            address = matchers.first['value']?.toString() ?? '-';
                          }
                          if (actions.isNotEmpty && actions.first['value'] != null) {
                            final vals = actions.first['value'] as List;
                            if (vals.isNotEmpty) destination = vals.first.toString();
                          }

                          return ListTile(
                            leading: Icon(
                              Icons.email_outlined,
                              color: enabled ? AppColors.primary : AppColors.muted,
                            ),
                            title: Text(address),
                            subtitle: Text('→ $destination ${enabled ? '' : '(disabled)'}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                              onPressed: () => _deleteRule(r['id'], address),
                            ),
                          );
                        }),
                    ],
                  ),
          ),
        ],
      );
    }

    return RefreshIndicator(
      onRefresh: _loadZones,
      child: zones.isEmpty
          ? const Center(child: Text('Tiada domain'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: zones.length,
              itemBuilder: (ctx, i) {
                final z = zones[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: const Icon(Icons.language, color: AppColors.primary),
                    title: Text(z['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: const Text('Email Routing Rules'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _loadRules(z['id'], z['name']),
                  ),
                );
              },
            ),
    );
  }

  Widget _buildDestinationTab() {
    if (loadingDest) return const Center(child: CircularProgressIndicator());

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              const Expanded(
                child: Text(
                  'Destination Addresses',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
              FilledButton.icon(
                onPressed: _addDestination,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Tambah'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                ),
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'Destination mesti verified dulu. Selepas tambah, check email & klik link verification. Status akan jadi Pending sehingga verified.',
            style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.4),
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: destinations.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.inbox_outlined, size: 56, color: AppColors.muted),
                      const SizedBox(height: 12),
                      const Text('Tiada destination lagi'),
                      const SizedBox(height: 8),
                      const Text(
                        'Tambah email (contoh Gmail) untuk terima forward.',
                        style: TextStyle(color: AppColors.muted, fontSize: 13),
                      ),
                      const SizedBox(height: 20),
                      FilledButton.icon(
                        onPressed: _addDestination,
                        icon: const Icon(Icons.add),
                        label: const Text('Tambah Destination'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadDestinations,
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: destinations.length,
                    itemBuilder: (ctx, i) {
                      final d = destinations[i];
                      final email = d['email'] ?? '-';
                      final verified = d['verified'] != null;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: Icon(
                            verified ? Icons.verified : Icons.hourglass_empty,
                            color: verified ? AppColors.success : AppColors.warning,
                          ),
                          title: Text(email, style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text(
                            verified ? 'Verified • Siap digunakan' : 'Pending • Check email & verify',
                            style: TextStyle(
                              color: verified ? AppColors.success : AppColors.warning,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }
}
