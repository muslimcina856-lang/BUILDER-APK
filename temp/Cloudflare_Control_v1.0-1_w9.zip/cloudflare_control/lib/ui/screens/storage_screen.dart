import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class StorageScreen extends StatefulWidget {
  const StorageScreen({super.key});

  @override
  State<StorageScreen> createState() => _StorageScreenState();
}

class _StorageScreenState extends State<StorageScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<dynamic> buckets = [];
  List<dynamic> kvNamespaces = [];
  bool loadingR2 = true;
  bool loadingKv = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadR2();
    _loadKv();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadR2() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;
    setState(() => loadingR2 = true);
    try {
      final api = CloudflareApi(account);
      final data = await api.getR2Buckets();
      setState(() {
        buckets = data;
        loadingR2 = false;
      });
    } catch (e) {
      setState(() => loadingR2 = false);
    }
  }

  Future<void> _loadKv() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;
    setState(() => loadingKv = true);
    try {
      final api = CloudflareApi(account);
      final data = await api.getKvNamespaces();
      setState(() {
        kvNamespaces = data;
        loadingKv = false;
      });
    } catch (e) {
      setState(() => loadingKv = false);
    }
  }

  Future<void> _createBucket() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta R2 Bucket'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Bucket name', hintText: 'my-bucket'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (result != true) return;
    final name = controller.text.trim().toLowerCase();
    if (name.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createR2Bucket(name);
      await _loadR2();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Bucket berjaya dicipta'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deleteBucket(String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Bucket?'),
        content: Text('Padam $name? Tindakan ini tidak boleh diundur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteR2Bucket(name);
      await _loadR2();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _createKv() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta KV Namespace'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Title'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (result != true) return;
    final title = controller.text.trim();
    if (title.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createKvNamespace(title);
      await _loadKv();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('KV Namespace berjaya dicipta'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Material(
          color: Colors.white,
          child: TabBar(
            controller: _tabController,
            labelColor: AppColors.primary,
            unselectedLabelColor: AppColors.muted,
            indicatorColor: AppColors.primary,
            tabs: const [
              Tab(text: 'R2 Buckets'),
              Tab(text: 'KV Namespaces'),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildR2(),
              _buildKv(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildR2() {
    if (loadingR2) return const Center(child: CircularProgressIndicator());
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: _createBucket,
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Cipta Bucket'),
            ),
          ),
        ),
        Expanded(
          child: buckets.isEmpty
              ? const Center(child: Text('Tiada R2 bucket', style: TextStyle(color: AppColors.muted)))
              : RefreshIndicator(
                  onRefresh: _loadR2,
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: buckets.length,
                    itemBuilder: (ctx, i) {
                      final b = buckets[i];
                      final name = b['name'] ?? '-';
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: const Icon(Icons.storage, color: AppColors.primary),
                          title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text('Created: ${b['creation_date'] ?? '-'}'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                            onPressed: () => _deleteBucket(name),
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildKv() {
    if (loadingKv) return const Center(child: CircularProgressIndicator());
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: _createKv,
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Cipta Namespace'),
            ),
          ),
        ),
        Expanded(
          child: kvNamespaces.isEmpty
              ? const Center(child: Text('Tiada KV Namespace', style: TextStyle(color: AppColors.muted)))
              : RefreshIndicator(
                  onRefresh: _loadKv,
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: kvNamespaces.length,
                    itemBuilder: (ctx, i) {
                      final n = kvNamespaces[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: const Icon(Icons.folder_outlined, color: AppColors.primary),
                          title: Text(n['title'] ?? n['id'] ?? '-', style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text('ID: ${n['id']}'),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }
}
