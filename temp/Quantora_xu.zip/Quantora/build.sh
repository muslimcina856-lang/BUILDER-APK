#!/bin/bash
echo "===== INSTALL DEPENDENCIES ====="
npm install

echo "===== BUILD WEB ====="
npm run build

echo "===== INIT ANDROID ====="
npx cap add android

echo "===== SYNC ANDROID ====="
npx cap sync android

echo "===== BUILD APK ====="
cd android && ./gradlew assembleDebug

echo "===== DONE ====="
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"