import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Categories from './pages/Categories';
import Reports from './pages/Reports';
import Assets from './pages/Assets';
import Watchlist from './pages/Stocks/Watchlist';
import Portfolio from './pages/Stocks/Portfolio';
import Analysis from './pages/Stocks/Analysis';
import Profile from './pages/Profile';
import { seedDefaultCategories } from './db/db';

export default function App() {
  useEffect(() => {
    seedDefaultCategories();
  }, []);

  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/transactions" element={<Transactions />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/assets" element={<Assets />} />
          <Route path="/stocks/watchlist" element={<Watchlist />} />
          <Route path="/stocks/portfolio" element={<Portfolio />} />
          <Route path="/stocks/analysis" element={<Analysis />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}