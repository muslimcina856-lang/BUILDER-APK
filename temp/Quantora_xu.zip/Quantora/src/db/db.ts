import Dexie, { Table } from 'dexie';

export interface Transaction {
  id?: number;
  categoryId: number;
  type: 'INCOME' | 'EXPENSE';
  amount: number;
  description: string;
  date: string;
}

export interface Category {
  id?: number;
  name: string;
  type: 'INCOME' | 'EXPENSE';
  icon?: string;
}

export interface AssetItem {
  id?: number;
  name: string;
  type: 'PROPERTY' | 'VEHICLE' | 'SAVINGS' | 'INVESTMENT' | 'OTHER';
  currentValue: number;
  acquisitionCost?: number;
  notes?: string;
}

export interface LiabilityItem {
  id?: number;
  name: string;
  type: 'LOAN' | 'CREDIT_CARD' | 'MORTGAGE' | 'OTHER';
  amount: number;
  interestRate?: number;
  dueDate?: string;
  notes?: string;
}

export interface Stock {
  id?: number;
  code: string;
  name: string;
  sector?: string;
  currentPrice?: number;
}

export interface WatchlistItem {
  id?: number;
  stockCode: string;
  targetPrice?: number;
  notes?: string;
}

export interface PortfolioTransaction {
  id?: number;
  stockCode: string;
  type: 'BUY' | 'SELL';
  lotCount: number;
  pricePerShare: number;
  totalAmount: number;
  fee?: number;
  date: string;
  notes?: string;
}

export interface AppSettings {
  key: string;
  value: any;
}

class FinAppDB extends Dexie {
  transactions!: Table<Transaction>;
  categories!: Table<Category>;
  assets!: Table<AssetItem>;
  liabilities!: Table<LiabilityItem>;
  stocks!: Table<Stock>;
  watchlist!: Table<WatchlistItem>;
  portfolio!: Table<PortfolioTransaction>;
  settings!: Table<AppSettings>;

  constructor() {
    super('FinAppOffline');
    this.version(1).stores({
      transactions: '++id, type, categoryId, date',
      categories: '++id, type',
      assets: '++id',
      liabilities: '++id',
      stocks: '++id, code',
      watchlist: '++id, stockCode',
      portfolio: '++id, stockCode, date',
      settings: 'key',
    });
  }
}

export const db = new FinAppDB();

export async function seedDefaultCategories() {
  const count = await db.categories.count();
  if (count > 0) return;

  const defaults: Omit<Category, 'id'>[] = [
    { name: 'Gaji', type: 'INCOME', icon: '💼' },
    { name: 'Bisnis', type: 'INCOME', icon: '📊' },
    { name: 'Investasi', type: 'INCOME', icon: '📈' },
    { name: 'Makanan', type: 'EXPENSE', icon: '🍔' },
    { name: 'Transportasi', type: 'EXPENSE', icon: '🚗' },
    { name: 'Hiburan', type: 'EXPENSE', icon: '🎮' },
    { name: 'Pendidikan', type: 'EXPENSE', icon: '📚' },
    { name: 'Kesehatan', type: 'EXPENSE', icon: '🏥' },
    { name: 'Tagihan', type: 'EXPENSE', icon: '📄' },
    { name: 'Lainnya', type: 'EXPENSE', icon: '❓' },
  ];
  await db.categories.bulkAdd(defaults);
}