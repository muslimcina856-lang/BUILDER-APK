import { db, Stock, WatchlistItem, PortfolioTransaction } from '../db/db';

export async function addStock(data: Omit<Stock, 'id'>) {
  return db.stocks.put(data);
}

export async function getAllStocks() {
  return db.stocks.toArray();
}

export async function getStockByCode(code: string) {
  return db.stocks.where('code').equals(code).first();
}

export async function getWatchlist() {
  return db.watchlist.toArray();
}

export async function addToWatchlist(item: Omit<WatchlistItem, 'id'>) {
  return db.watchlist.put(item);
}

export async function removeFromWatchlist(id: number) {
  return db.watchlist.delete(id);
}

export async function addPortfolioTransaction(data: Omit<PortfolioTransaction, 'id'>) {
  return db.portfolio.add(data);
}

export async function getPortfolioTransactions(stockCode?: string) {
  if (stockCode) {
    return db.portfolio.where('stockCode').equals(stockCode).toArray();
  }
  return db.portfolio.toArray();
}

export interface PortfolioSummary {
  stockCode: string;
  totalLots: number;
  avgPrice: number;
  totalInvested: number;
  currentPrice?: number;
  marketValue?: number;
  gainLoss?: number;
  gainLossPercent?: number;
}

export async function getPortfolioSummary(): Promise<PortfolioSummary[]> {
  const transactions = await db.portfolio.toArray();
  const stocks = await db.stocks.toArray();
  const stockMap = new Map(stocks.map((s) => [s.code, s]));

  const grouped = new Map<
    string,
    { totalLots: number; totalCost: number; totalShares: number }
  >();
  for (const t of transactions) {
    const code = t.stockCode;
    const current = grouped.get(code) || { totalLots: 0, totalCost: 0, totalShares: 0 };
    if (t.type === 'BUY') {
      current.totalLots += t.lotCount;
      current.totalCost += t.totalAmount + (t.fee || 0);
      current.totalShares += t.lotCount * 100;
    } else if (t.type === 'SELL') {
      current.totalLots -= t.lotCount;
      if (current.totalLots > 0) {
        const avgBefore = current.totalCost / current.totalLots;
        current.totalCost -= avgBefore * t.lotCount;
        current.totalShares -= t.lotCount * 100;
      } else {
        current.totalCost = 0;
        current.totalShares = 0;
      }
    }
    grouped.set(code, current);
  }

  const result: PortfolioSummary[] = [];
  for (const [code, data] of grouped) {
    if (data.totalLots <= 0) continue;
    const avgPrice = data.totalLots > 0 ? data.totalCost / data.totalLots : 0;
    const stockInfo = stockMap.get(code);
    const currentPrice = stockInfo?.currentPrice;
    const marketValue = currentPrice ? currentPrice * data.totalLots * 100 : undefined;
    const gainLoss = marketValue ? marketValue - data.totalCost : undefined;
    const gainLossPercent =
      marketValue && data.totalCost
        ? ((marketValue - data.totalCost) / data.totalCost) * 100
        : undefined;
    result.push({
      stockCode: code,
      totalLots: data.totalLots,
      avgPrice,
      totalInvested: data.totalCost,
      currentPrice,
      marketValue,
      gainLoss,
      gainLossPercent,
    });
  }
  return result;
}