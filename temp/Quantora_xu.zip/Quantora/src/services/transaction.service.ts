import { db, Transaction } from '../db/db';

export async function addTransaction(data: Omit<Transaction, 'id'>) {
  return db.transactions.add(data);
}

export async function updateTransaction(id: number, data: Partial<Transaction>) {
  return db.transactions.update(id, data);
}

export async function deleteTransaction(id: number) {
  return db.transactions.delete(id);
}

export async function getTransaction(id: number) {
  return db.transactions.get(id);
}

export async function getAllTransactions(filter?: {
  startDate?: string;
  endDate?: string;
  type?: string;
}) {
  let collection = db.transactions.orderBy('date').reverse();
  const arr = await collection.toArray();
  let filtered = arr;
  if (filter?.startDate) filtered = filtered.filter((t) => t.date >= filter.startDate!);
  if (filter?.endDate) filtered = filtered.filter((t) => t.date <= filter.endDate!);
  if (filter?.type) filtered = filtered.filter((t) => t.type === filter.type);
  return filtered;
}

export async function getTotalIncome(startDate?: string, endDate?: string) {
  const txs = await getAllTransactions({ startDate, endDate });
  return txs.filter((t) => t.type === 'INCOME').reduce((sum, t) => sum + t.amount, 0);
}

export async function getTotalExpense(startDate?: string, endDate?: string) {
  const txs = await getAllTransactions({ startDate, endDate });
  return txs.filter((t) => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amount, 0);
}

export async function getCurrentBalance() {
  const income = await getTotalIncome();
  const expense = await getTotalExpense();
  return income - expense;
}

export async function importTransactionsFromCSV(csvText: string) {
  const lines = csvText.split('\n').filter((line) => line.trim() !== '');
  const header = lines[0].toLowerCase();
  if (!header.includes('type') || !header.includes('amount') || !header.includes('date')) {
    throw new Error('Format CSV tidak valid. Harus ada kolom: type, amount, date, description, categoryId (opsional)');
  }
  const rows = lines.slice(1).map((line) => {
    const cols = line.split(',');
    return {
      type: cols[0] as 'INCOME' | 'EXPENSE',
      amount: parseFloat(cols[1]),
      date: cols[2],
      description: cols[3] || '',
      categoryId: parseInt(cols[4]) || 1,
    };
  });
  await db.transactions.bulkAdd(rows);
}