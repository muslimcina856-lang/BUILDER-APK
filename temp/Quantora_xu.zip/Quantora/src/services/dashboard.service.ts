import { getCurrentBalance, getTotalIncome, getTotalExpense } from './transaction.service';
import { getTotalAssetsValue } from './asset.service';
import { getTotalLiabilitiesValue } from './liability.service';
import { getCurrentMonthRange } from '../lib/utils';

export async function getDashboardSummary() {
  const { start, end } = getCurrentMonthRange();
  const [balance, totalIncome, totalExpense, assets, liabilities] = await Promise.all([
    getCurrentBalance(),
    getTotalIncome(start, end),
    getTotalExpense(start, end),
    getTotalAssetsValue(),
    getTotalLiabilitiesValue(),
  ]);
  const netWorth = balance + assets - liabilities;
  const monthlyCashFlow = totalIncome - totalExpense;
  return {
    totalBalance: balance,
    totalAssets: assets,
    totalLiabilities: liabilities,
    totalIncomeThisMonth: totalIncome,
    totalExpenseThisMonth: totalExpense,
    monthlyCashFlow,
    netWorth,
  };
}