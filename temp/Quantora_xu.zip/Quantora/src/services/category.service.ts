import { db, Category } from '../db/db';

export async function getAllCategories() {
  return db.categories.toArray();
}

export async function addCategory(data: Omit<Category, 'id'>) {
  return db.categories.add(data);
}

export async function updateCategory(id: number, data: Partial<Category>) {
  return db.categories.update(id, data);
}

export async function deleteCategory(id: number) {
  const count = await db.transactions.where('categoryId').equals(id).count();
  if (count > 0) {
    throw new Error('Kategori masih digunakan oleh transaksi. Hapus atau pindahkan transaksi terlebih dahulu.');
  }
  return db.categories.delete(id);
}