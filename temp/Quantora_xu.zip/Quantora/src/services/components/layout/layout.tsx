import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const navItems = [
  { to: '/', label: '📊 Dashboard' },
  { to: '/transactions', label: '💳 Transaksi' },
  { to: '/categories', label: '📁 Kategori' },
  { to: '/reports', label: '📄 Laporan' },
  { to: '/assets', label: '🏠 Aset & Utang' },
  { to: '/stocks/watchlist', label: '⭐ Watchlist' },
  { to: '/stocks/portfolio', label: '📈 Portofolio' },
  { to: '/stocks/analysis', label: '🔍 Analisis Fundamental' },
  { to: '/profile', label: '⚙️ Pengaturan' },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      {/* Mobile hamburger */}
      <div className="md:hidden fixed top-0 left-0 z-50 p-2">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-gray-800 text-white p-2 rounded"
        >
          ☰
        </button>
      </div>

      {/* Overlay mobile */}
      {sidebarOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:sticky top-0 left-0 z-40 h-screen w-64 bg-gray-800 text-white flex-shrink-0 transform transition-transform duration-200 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0`}
      >
        <div className="p-4 text-xl font-bold border-b border-gray-700">
          💰 FinApp
        </div>
        <nav className="p-2 overflow-y-auto h-[calc(100vh-65px)]">
          <ul>
            {navItems.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  onClick={() => setSidebarOpen(false)}
                  className={`block px-4 py-2 rounded mb-1 text-sm ${
                    location.pathname === item.to
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 p-4 md:p-6 pt-12 md:pt-6 overflow-auto w-full">
        {children}
      </main>
    </div>
  );
}