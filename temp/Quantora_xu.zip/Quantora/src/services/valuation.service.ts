export interface FundamentalInput {
  currentPrice: number;
  eps: number;
  bvps: number;
  roe: number;
  dividendPayoutRatio: number;
  growthRate?: number;
  requiredReturn: number;
}

export interface ValuationResult {
  method: string;
  intrinsicValue: number;
  marginOfSafety: number;
  expectedReturn?: number;
}

function calculateSustainableGrowth(roe: number, payoutRatio: number): number {
  const retentionRatio = 1 - payoutRatio / 100;
  return (roe / 100) * retentionRatio * 100;
}

function grahamNumber(eps: number, bvps: number): number {
  return Math.sqrt(22.5 * eps * bvps);
}

function dcfGordonValue(
  eps: number,
  payoutRatio: number,
  growthRate: number,
  requiredReturn: number
): number {
  const g = growthRate / 100;
  const r = requiredReturn / 100;
  if (r <= g) return Infinity;
  const dividendPerShare = eps * (payoutRatio / 100);
  const d1 = dividendPerShare * (1 + g);
  return d1 / (r - g);
}

function perFairValue(eps: number, fairPER: number = 15): number {
  return eps * fairPER;
}

function pbvFairValue(bvps: number, fairPBV: number = 1.5): number {
  return bvps * fairPBV;
}

function expectedReturn(
  currentPrice: number,
  intrinsicValue: number,
  eps: number,
  payoutRatio: number,
  years: number = 5
): number {
  const capitalGainCAGR = Math.pow(intrinsicValue / currentPrice, 1 / years) - 1;
  const dividendYield = (eps * (payoutRatio / 100)) / currentPrice;
  return (capitalGainCAGR + dividendYield) * 100;
}

export function calculateValuations(input: FundamentalInput): ValuationResult[] {
  const {
    currentPrice,
    eps,
    bvps,
    roe,
    dividendPayoutRatio,
    growthRate: inputGrowth,
    requiredReturn,
  } = input;

  const growthRate =
    inputGrowth ?? calculateSustainableGrowth(roe, dividendPayoutRatio);

  const results: ValuationResult[] = [];

  const grahamVal = grahamNumber(eps, bvps);
  results.push({
    method: 'Graham Number',
    intrinsicValue: grahamVal,
    marginOfSafety: ((grahamVal - currentPrice) / currentPrice) * 100,
    expectedReturn: expectedReturn(currentPrice, grahamVal, eps, dividendPayoutRatio),
  });

  const dcfVal = dcfGordonValue(eps, dividendPayoutRatio, growthRate, requiredReturn);
  if (isFinite(dcfVal)) {
    results.push({
      method: 'DCF (Gordon Growth)',
      intrinsicValue: dcfVal,
      marginOfSafety: ((dcfVal - currentPrice) / currentPrice) * 100,
      expectedReturn: expectedReturn(currentPrice, dcfVal, eps, dividendPayoutRatio),
    });
  }

  const perVal = perFairValue(eps);
  results.push({
    method: 'PER (15x)',
    intrinsicValue: perVal,
    marginOfSafety: ((perVal - currentPrice) / currentPrice) * 100,
    expectedReturn: expectedReturn(currentPrice, perVal, eps, dividendPayoutRatio),
  });

  const pbvVal = pbvFairValue(bvps);
  results.push({
    method: 'PBV (1.5x)',
    intrinsicValue: pbvVal,
    marginOfSafety: ((pbvVal - currentPrice) / currentPrice) * 100,
    expectedReturn: expectedReturn(currentPrice, pbvVal, eps, dividendPayoutRatio),
  });

  const vals = [grahamVal, dcfVal, perVal, pbvVal].filter((v) => isFinite(v));
  const avgVal = vals.reduce((a, b) => a + b, 0) / vals.length;
  results.push({
    method: 'Rata-rata Semua Metode',
    intrinsicValue: avgVal,
    marginOfSafety: ((avgVal - currentPrice) / currentPrice) * 100,
    expectedReturn: expectedReturn(currentPrice, avgVal, eps, dividendPayoutRatio),
  });

  return results;
}