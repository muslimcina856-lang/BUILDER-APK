import React, { useState, useEffect } from 'react';
import {
  getAllTransactions,
  addTransaction,
  updateTransaction,
  deleteTransaction,
  importTransactionsFromCSV,
} from '../services/transaction.service';
import { getAllCategories } from '../services/category.service';
import { Transaction, Category } from '../db/db';
import { formatRupiah, formatDate, downloadCSV } from '../lib/utils';

export default function Transactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filterType, setFilterType] = useState('');
  const [filterDateStart, setFilterDateStart] = useState('');
  const [filterDateEnd, setFilterDateEnd] = useState('');
  const [form, setForm] = useState({
    categoryId: 1,
    type: 'EXPENSE' as 'INCOME' | 'EXPENSE',
    amount: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);

  const fetchData = async () => {
    const txs = await getAllTransactions({
      type: filterType || undefined,
      startDate: filterDateStart || undefined,
      endDate: filterDateEnd || undefined,
    });
    setTransactions(txs);
    const cats = await getAllCategories();
    setCategories(cats);
  };

  useEffect(() => {
    fetchData();
  }, [filterType, filterDateStart, filterDateEnd]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      categoryId: form.categoryId,
      type: form.type,
      amount: parseFloat(form.amount),
      description: form.description,
      date: form.date,
    };
    if (editingId) {
      await updateTransaction(editingId, data);
    } else {
      await addTransaction(data);
    }
    setForm({
      categoryId: 1,
      type: 'EXPENSE',
      amount: '',
      description: '',
      date: new Date().toISOString().split('T')[0],
    });
    setEditingId(null);
    setShowForm(false);
    fetchData();
  };

  const handleEdit = (tx: Transaction) => {
    setForm({
      categoryId: tx.categoryId,
      type: tx.type,
      amount: tx.amount.toString(),
      description: tx.description,
      date: tx.date,
    });
    setEditingId(tx.id ?? null);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Hapus transaksi ini?')) {
      await deleteTransaction(id);
      fetchData();
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const text = ev.target?.result as string;
      try {
        await importTransactionsFromCSV(text);
        fetchData();
        alert('Import berhasil!');
      } catch (err: any) {
        alert(err.message);
      }
    };
    reader.readAsText(file);
  };

  const exportCSV = () => {
    const rows = [['Tanggal', 'Tipe', 'Kategori', 'Jumlah', 'Deskripsi']];
    transactions.forEach((t) => {
      const cat = categories.find((c) => c.id === t.categoryId);
      rows.push([t.date, t.type, cat?.name || '', t.amount.toString(), t.description]);
    });
    downloadCSV(rows, 'transaksi.csv');
  };

  const filteredCategories = categories.filter((c) => c.type === form.type);

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Transaksi</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
        >
          {showForm ? 'Tutup Form' : '+ Tambah'}
        </button>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-4 flex-wrap">
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        >
          <option value="">Semua Tipe</option>
          <option value="INCOME">Pemasukan</option>
          <option value="EXPENSE">Pengeluaran</option>
        </select>
        <input
          type="date"
          value={filterDateStart}
          onChange={(e) => setFilterDateStart(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        />
        <input
          type="date"
          value={filterDateEnd}
          onChange={(e) => setFilterDateEnd(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        />
        <button
          onClick={fetchData}
          className="px-3 py-1 bg-gray-500 text-white rounded text-sm"
        >
          Filter
        </button>
        <button
          onClick={exportCSV}
          className="px-3 py-1 bg-green-600 text-white rounded text-sm"
        >
          Export CSV
        </button>
        <label className="px-3 py-1 bg-yellow-600 text-white rounded text-sm cursor-pointer">
          Import CSV
          <input type="file" accept=".csv" onChange={handleImport} className="hidden" />
        </label>
      </div>

      {/* Form */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="bg-white p-4 rounded shadow mb-4 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <div>
            <label className="block text-sm font-medium">Tipe</label>
            <select
              value={form.type}
              onChange={(e) =>
                setForm({ ...form, type: e.target.value as any, categoryId: 1 })
              }
              className="mt-1 block w-full border rounded px-3 py-2"
            >
              <option value="INCOME">Pemasukan</option>
              <option value="EXPENSE">Pengeluaran</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">Kategori</label>
            <select
              value={form.categoryId}
              onChange={(e) =>
                setForm({ ...form, categoryId: parseInt(e.target.value) })
              }
              className="mt-1 block w-full border rounded px-3 py-2"
            >
              {filteredCategories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.icon} {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">Jumlah (Rp)</label>
            <input
              type="number"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className="mt-1 block w-full border rounded px-3 py-2"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Tanggal</label>
            <input
              type="date"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
              className="mt-1 block w-full border rounded px-3 py-2"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium">Deskripsi</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div className="md:col-span-2 flex gap-2">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              {editingId ? 'Update' : 'Simpan'}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm({
                    categoryId: 1,
                    type: 'EXPENSE',
                    amount: '',
                    description: '',
                    date: new Date().toISOString().split('T')[0],
                  });
                  setShowForm(false);
                }}
                className="px-4 py-2 bg-gray-300 rounded"
              >
                Batal
              </button>
            )}
          </div>
        </form>
      )}

      {/* List */}
      <div className="bg-white rounded shadow overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                Tanggal
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                Kategori
              </th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                Deskripsi
              </th>
              <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                Jumlah
              </th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                Aksi
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {transactions.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                  Belum ada transaksi.
                </td>
              </tr>
            ) : (
              transactions.map((tx) => {
                const cat = categories.find((c) => c.id === tx.categoryId);
                return (
                  <tr key={tx.id}>
                    <td className="px-4 py-2 text-sm">{formatDate(tx.date)}</td>
                    <td className="px-4 py-2 text-sm">
                      {cat?.icon} {cat?.name}
                    </td>
                    <td className="px-4 py-2 text-sm">{tx.description}</td>
                    <td
                      className={`px-4 py-2 text-sm text-right font-semibold ${
                        tx.type === 'INCOME' ? 'text-green-600' : 'text-red-600'
                      }`}
                    >
                      {tx.type === 'INCOME' ? '+' : '-'} {formatRupiah(tx.amount)}
                    </td>
                    <td className="px-4 py-2 text-sm text-center">
                      <button
                        onClick={() => handleEdit(tx)}
                        className="text-blue-600 mr-2 hover:underline"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => tx.id && handleDelete(tx.id)}
                        className="text-red-600 hover:underline"
                      >
                        Hapus
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}