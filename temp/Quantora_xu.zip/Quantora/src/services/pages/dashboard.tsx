import React from 'react';
import { useDashboard } from '../hooks/useDashboard';
import Card from '../components/ui/Card';
import { formatRupiah } from '../lib/utils';

export default function Dashboard() {
  const { data, loading, refetch } = useDashboard();

  if (loading)
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-gray-500">Memuat dashboard...</p>
      </div>
    );

  if (!data)
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-gray-500">Belum ada data. Tambahkan transaksi pertama Anda!</p>
      </div>
    );

  const cards = [
    { title: 'Saldo Kas', value: data.totalBalance },
    { title: 'Total Aset', value: data.totalAssets },
    { title: 'Total Utang', value: data.totalLiabilities },
    { title: 'Kekayaan Bersih', value: data.netWorth },
    { title: 'Pemasukan Bulan Ini', value: data.totalIncomeThisMonth },
    { title: 'Pengeluaran Bulan Ini', value: data.totalExpenseThisMonth },
    { title: 'Arus Kas Bulan Ini', value: data.monthlyCashFlow },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <button
          onClick={refetch}
          className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
        >
          🔄 Refresh
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {cards.map((card, i) => (
          <Card key={i} title={card.title}>
            <p className="text-xl md:text-2xl font-semibold">
              {formatRupiah(card.value)}
            </p>
          </Card>
        ))}
      </div>
    </div>
  );
}