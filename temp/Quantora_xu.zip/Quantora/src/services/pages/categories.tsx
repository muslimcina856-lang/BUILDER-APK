import React, { useState, useEffect } from 'react';
import {
  getAllCategories,
  addCategory,
  updateCategory,
  deleteCategory,
} from '../services/category.service';
import { Category } from '../db/db';

export default function Categories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState({
    name: '',
    type: 'EXPENSE' as 'INCOME' | 'EXPENSE',
    icon: '',
  });
  const [editingId, setEditingId] = useState<number | null>(null);

  const fetch = async () => {
    setCategories(await getAllCategories());
  };

  useEffect(() => {
    fetch();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await updateCategory(editingId, form);
    } else {
      await addCategory(form);
    }
    setForm({ name: '', type: 'EXPENSE', icon: '' });
    setEditingId(null);
    fetch();
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteCategory(id);
      fetch();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Kategori</h1>

      <form
        onSubmit={handleSubmit}
        className="bg-white p-4 rounded shadow mb-4 flex gap-2 flex-wrap"
      >
        <input
          type="text"
          placeholder="Nama Kategori"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border px-3 py-2 rounded flex-1 min-w-[150px]"
          required
        />
        <select
          value={form.type}
          onChange={(e) => setForm({ ...form, type: e.target.value as any })}
          className="border px-3 py-2 rounded"
        >
          <option value="INCOME">Pemasukan</option>
          <option value="EXPENSE">Pengeluaran</option>
        </select>
        <input
          type="text"
          placeholder="Ikon (emoji)"
          value={form.icon}
          onChange={(e) => setForm({ ...form, icon: e.target.value })}
          className="border px-3 py-2 rounded w-28"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          {editingId ? 'Update' : 'Tambah'}
        </button>
        {editingId && (
          <button
            onClick={() => {
              setEditingId(null);
              setForm({ name: '', type: 'EXPENSE', icon: '' });
            }}
            className="px-4 py-2 bg-gray-300 rounded"
          >
            Batal
          </button>
        )}
      </form>

      <div className="bg-white rounded shadow overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left">Nama</th>
              <th className="px-4 py-2 text-left">Tipe</th>
              <th className="px-4 py-2 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {categories.map((cat) => (
              <tr key={cat.id}>
                <td className="px-4 py-2">
                  {cat.icon} {cat.name}
                </td>
                <td className="px-4 py-2">
                  {cat.type === 'INCOME' ? 'Pemasukan' : 'Pengeluaran'}
                </td>
                <td className="px-4 py-2 text-center">
                  <button
                    onClick={() => {
                      setForm({
                        name: cat.name,
                        type: cat.type,
                        icon: cat.icon || '',
                      });
                      setEditingId(cat.id!);
                    }}
                    className="text-blue-600 mr-2 hover:underline"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => cat.id && handleDelete(cat.id)}
                    className="text-red-600 hover:underline"
                  >
                    Hapus
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}