import React, { useState } from 'react';
import {
  getTotalIncome,
  getTotalExpense,
  getAllTransactions,
} from '../services/transaction.service';
import { getTotalAssetsValue } from '../services/asset.service';
import { getTotalLiabilitiesValue } from '../services/liability.service';
import { formatRupiah } from '../lib/utils';
import Card from '../components/ui/Card';

export default function Reports() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [income, setIncome] = useState(0);
  const [expense, setExpense] = useState(0);
  const [assets, setAssets] = useState(0);
  const [liabilities, setLiabilities] = useState(0);
  const [balance, setBalance] = useState(0);
  const [calculated, setCalculated] = useState(false);

  const calculate = async () => {
    const inc = await getTotalIncome(startDate || undefined, endDate || undefined);
    const exp = await getTotalExpense(startDate || undefined, endDate || undefined);
    const ast = await getTotalAssetsValue();
    const lia = await getTotalLiabilitiesValue();
    const all = await getAllTransactions();
    const totalInc = all.filter((t) => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
    const totalExp = all.filter((t) => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
    setIncome(inc);
    setExpense(exp);
    setAssets(ast);
    setLiabilities(lia);
    setBalance(totalInc - totalExp);
    setCalculated(true);
  };

  const netIncome = income - expense;
  const netWorth = balance + assets - liabilities;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Laporan Keuangan</h1>

      <div className="flex gap-2 mb-4 flex-wrap">
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        />
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="border px-2 py-1 rounded text-sm"
        />
        <button
          onClick={calculate}
          className="px-4 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
        >
          Hitung
        </button>
      </div>

      {calculated && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card title="📄 Laporan Laba Rugi">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Pemasukan</span>
                <span className="text-green-600 font-semibold">
                  {formatRupiah(income)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Pengeluaran</span>
                <span className="text-red-600 font-semibold">
                  {formatRupiah(expense)}
                </span>
              </div>
              <hr />
              <div className="flex justify-between font-bold text-lg">
                <span>Laba/Rugi Bersih</span>
                <span className={netIncome >= 0 ? 'text-green-600' : 'text-red-600'}>
                  {formatRupiah(netIncome)}
                </span>
              </div>
            </div>
          </Card>

          <Card title="📊 Neraca (Posisi Keuangan)">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Total Aset</span>
                <span className="font-semibold">{formatRupiah(assets)}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Utang</span>
                <span className="text-red-600 font-semibold">
                  {formatRupiah(liabilities)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Saldo Kas</span>
                <span>{formatRupiah(balance)}</span>
              </div>
              <hr />
              <div className="flex justify-between font-bold text-lg">
                <span>Kekayaan Bersih</span>
                <span className="text-green-600">{formatRupiah(netWorth)}</span>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}