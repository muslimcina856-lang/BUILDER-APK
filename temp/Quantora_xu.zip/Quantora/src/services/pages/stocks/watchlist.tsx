import React, { useState, useEffect } from 'react';
import {
  addStock,
  getAllStocks,
  getWatchlist,
  addToWatchlist,
  removeFromWatchlist,
  Stock,
  WatchlistItem,
} from '../../services/stock.service';
import { formatRupiah } from '../../lib/utils';

export default function Watchlist() {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [watchlist, setWatchlist] = useState<(WatchlistItem & { stock?: Stock })[]>(
    []
  );
  const [form, setForm] = useState({
    code: '',
    name: '',
    targetPrice: '',
    notes: '',
  });

  const fetch = async () => {
    const allStocks = await getAllStocks();
    setStocks(allStocks);
    const wl = await getWatchlist();
    const merged = wl.map((item) => ({
      ...item,
      stock: allStocks.find((s) => s.code === item.stockCode),
    }));
    setWatchlist(merged);
  };

  useEffect(() => {
    fetch();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = form.code.toUpperCase();
    const existing = stocks.find((s) => s.code === code);
    if (!existing) {
      await addStock({ code, name: form.name, currentPrice: undefined });
    }
    await addToWatchlist({
      stockCode: code,
      targetPrice: form.targetPrice ? parseFloat(form.targetPrice) : undefined,
      notes: form.notes,
    });
    setForm({ code: '', name: '', targetPrice: '', notes: '' });
    fetch();
  };

  const handleRemove = async (id: number) => {
    await removeFromWatchlist(id);
    fetch();
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Watchlist Saham</h1>

      <form
        onSubmit={handleAdd}
        className="bg-white p-4 rounded shadow mb-4 flex gap-2 flex-wrap"
      >
        <input
          type="text"
          placeholder="Kode (BBRI)"
          value={form.code}
          onChange={(e) => setForm({ ...form, code: e.target.value })}
          className="border px-3 py-2 rounded"
          required
        />
        <input
          type="text"
          placeholder="Nama Emiten"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border px-3 py-2 rounded"
          required
        />
        <input
          type="number"
          placeholder="Target Harga"
          value={form.targetPrice}
          onChange={(e) => setForm({ ...form, targetPrice: e.target.value })}
          className="border px-3 py-2 rounded w-36"
        />
        <input
          type="text"
          placeholder="Catatan"
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          className="border px-3 py-2 rounded"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          + Tambah
        </button>
      </form>

      <div className="bg-white rounded shadow overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left">Kode</th>
              <th className="px-4 py-2 text-left">Nama</th>
              <th className="px-4 py-2 text-right">Target Harga</th>
              <th className="px-4 py-2">Catatan</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {watchlist.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                  Watchlist kosong.
                </td>
              </tr>
            ) : (
              watchlist.map((item) => (
                <tr key={item.id}>
                  <td className="px-4 py-2 font-medium">{item.stockCode}</td>
                  <td className="px-4 py-2">{item.stock?.name || '-'}</td>
                  <td className="px-4 py-2 text-right">
                    {item.targetPrice
                      ? formatRupiah(item.targetPrice)
                      : '-'}
                  </td>
                  <td className="px-4 py-2 text-sm">{item.notes}</td>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => item.id && handleRemove(item.id)}
                      className="text-red-600 hover:underline text-sm"
                    >
                      Hapus
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}