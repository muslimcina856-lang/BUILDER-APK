import React, { useState, useEffect } from 'react';
import {
  addPortfolioTransaction,
  getPortfolioSummary,
  PortfolioSummary,
} from '../../services/stock.service';
import { formatRupiah, formatPercent } from '../../lib/utils';
import Card from '../../components/ui/Card';

export default function Portfolio() {
  const [summary, setSummary] = useState<PortfolioSummary[]>([]);
  const [form, setForm] = useState({
    stockCode: '',
    type: 'BUY' as 'BUY' | 'SELL',
    lotCount: '',
    pricePerShare: '',
    fee: '',
    date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  const fetch = async () => {
    setSummary(await getPortfolioSummary());
  };

  useEffect(() => {
    fetch();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const lot = parseInt(form.lotCount);
    const price = parseFloat(form.pricePerShare);
    const fee = parseFloat(form.fee) || 0;
    const total = lot * 100 * price + fee;
    await addPortfolioTransaction({
      stockCode: form.stockCode.toUpperCase(),
      type: form.type,
      lotCount: lot,
      pricePerShare: price,
      totalAmount: total,
      fee,
      date: form.date,
      notes: form.notes,
    });
    setForm({
      stockCode: '',
      type: 'BUY',
      lotCount: '',
      pricePerShare: '',
      fee: '',
      date: new Date().toISOString().split('T')[0],
      notes: '',
    });
    fetch();
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Portofolio Saham</h1>

      <Card className="mb-4">
        <h2 className="text-lg font-semibold mb-2">Tambah Transaksi</h2>
        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2"
        >
          <input
            type="text"
            placeholder="Kode Saham"
            value={form.stockCode}
            onChange={(e) => setForm({ ...form, stockCode: e.target.value })}
            className="border px-3 py-2 rounded"
            required
          />
          <select
            value={form.type}
            onChange={(e) =>
              setForm({ ...form, type: e.target.value as any })
            }
            className="border px-3 py-2 rounded"
          >
            <option value="BUY">Beli</option>
            <option value="SELL">Jual</option>
          </select>
          <input
            type="number"
            placeholder="Jumlah Lot"
            value={form.lotCount}
            onChange={(e) => setForm({ ...form, lotCount: e.target.value })}
            className="border px-3 py-2 rounded"
            required
          />
          <input
            type="number"
            placeholder="Harga per Lembar"
            value={form.pricePerShare}
            onChange={(e) =>
              setForm({ ...form, pricePerShare: e.target.value })
            }
            className="border px-3 py-2 rounded"
            required
          />
          <input
            type="number"
            placeholder="Fee (opsional)"
            value={form.fee}
            onChange={(e) => setForm({ ...form, fee: e.target.value })}
            className="border px-3 py-2 rounded"
          />
          <input
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className="border px-3 py-2 rounded"
            required
          />
          <input
            type="text"
            placeholder="Catatan"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            className="border px-3 py-2 rounded sm:col-span-2"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Simpan
          </button>
        </form>
      </Card>

      <h2 className="text-xl font-semibold mb-2">Ringkasan Portofolio</h2>
      {summary.length === 0 ? (
        <p className="text-gray-500">Belum ada transaksi portofolio.</p>
      ) : (
        <div className="grid gap-4">
          {summary.map((item) => (
            <Card key={item.stockCode}>
              <div className="flex flex-col sm:flex-row justify-between">
                <div>
                  <h3 className="font-bold text-lg">{item.stockCode}</h3>
                  <p className="text-sm">
                    Lot: {item.totalLots} | Avg Price:{' '}
                    {formatRupiah(item.avgPrice)}
                  </p>
                  <p className="text-sm">
                    Total Investasi: {formatRupiah(item.totalInvested)}
                  </p>
                </div>
                <div className="text-right mt-2 sm:mt-0">
                  {item.currentPrice ? (
                    <>
                      <p className="text-sm">
                        Harga Terkini: {formatRupiah(item.currentPrice)}
                      </p>
                      <p className="text-sm">
                        Nilai Pasar: {formatRupiah(item.marketValue!)}
                      </p>
                      <p
                        className={`font-bold ${
                          item.gainLoss! >= 0
                            ? 'text-green-600'
                            : 'text-red-600'
                        }`}
                      >
                        {item.gainLoss! >= 0 ? '▲' : '▼'}{' '}
                        {formatRupiah(item.gainLoss!)} (
                        {formatPercent(item.gainLossPercent!)})
                      </p>
                    </>
                  ) : (
                    <p className="text-yellow-600 text-sm">
                      Harga terkini belum diinput
                    </p>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}