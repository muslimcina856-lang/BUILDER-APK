import React, { useState } from 'react';
import {
  calculateValuations,
  FundamentalInput,
  ValuationResult,
} from '../../services/valuation.service';
import { formatRupiah, formatPercent } from '../../lib/utils';
import Card from '../../components/ui/Card';

export default function Analysis() {
  const [form, setForm] = useState<FundamentalInput>({
    currentPrice: 0,
    eps: 0,
    bvps: 0,
    roe: 15,
    dividendPayoutRatio: 40,
    growthRate: undefined,
    requiredReturn: 10,
  });

  const [results, setResults] = useState<ValuationResult[]>([]);
  const [errors, setErrors] = useState<string[]>([]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value === '' ? undefined : parseFloat(value),
    }));
  };

  const handleCalculate = () => {
    const errs: string[] = [];
    if (form.currentPrice <= 0) errs.push('Harga saham harus > 0');
    if (form.eps <= 0) errs.push('EPS harus > 0');
    if (form.bvps <= 0) errs.push('BVPS harus > 0');
    if (form.requiredReturn <= 0) errs.push('Required Return harus > 0');
    setErrors(errs);
    if (errs.length > 0) {
      setResults([]);
      return;
    }
    const valuations = calculateValuations(form);
    setResults(valuations);
  };

  const handleReset = () => {
    setForm({
      currentPrice: 0,
      eps: 0,
      bvps: 0,
      roe: 15,
      dividendPayoutRatio: 40,
      growthRate: undefined,
      requiredReturn: 10,
    });
    setResults([]);
    setErrors([]);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Analisis Fundamental Saham</h1>

      <Card className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Input Data Fundamental</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">
              Harga Saat Ini (Rp)
            </label>
            <input
              type="number"
              name="currentPrice"
              value={form.currentPrice || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">EPS (Rp)</label>
            <input
              type="number"
              name="eps"
              value={form.eps || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">BVPS (Rp)</label>
            <input
              type="number"
              name="bvps"
              value={form.bvps || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">ROE (%)</label>
            <input
              type="number"
              name="roe"
              value={form.roe || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">
              Dividend Payout Ratio (%)
            </label>
            <input
              type="number"
              name="dividendPayoutRatio"
              value={form.dividendPayoutRatio || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">
              Growth Rate (%)
              <span className="text-gray-400 text-xs">
                {' '}
                (kosongkan untuk hitung otomatis)
              </span>
            </label>
            <input
              type="number"
              name="growthRate"
              value={form.growthRate ?? ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">
              Required Return (%)
            </label>
            <input
              type="number"
              name="requiredReturn"
              value={form.requiredReturn || ''}
              onChange={handleChange}
              className="mt-1 block w-full border rounded px-3 py-2"
            />
          </div>
        </div>

        {errors.length > 0 && (
          <div className="mt-4 p-3 bg-red-50 text-red-700 rounded">
            <ul className="list-disc pl-4">
              {errors.map((e, i) => (
                <li key={i}>{e}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-6 flex gap-3">
          <button
            onClick={handleCalculate}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            🔍 Hitung Valuasi
          </button>
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
          >
            Reset
          </button>
        </div>
      </Card>

      {results.length > 0 && (
        <Card>
          <h2 className="text-lg font-semibold mb-4">
            Hasil Valuasi & Potensi Return
          </h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Metode
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Nilai Wajar (Rp)
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Margin of Safety
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Expected Return/Thn
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {results.map((r, i) => (
                  <tr
                    key={i}
                    className={
                      i === results.length - 1 ? 'font-semibold bg-blue-50' : ''
                    }
                  >
                    <td className="px-4 py-3">{r.method}</td>
                    <td className="px-4 py-3">
                      {isFinite(r.intrinsicValue)
                        ? formatRupiah(r.intrinsicValue)
                        : 'N/A'}
                    </td>
                    <td
                      className={`px-4 py-3 ${
                        r.marginOfSafety > 0
                          ? 'text-green-600'
                          : 'text-red-600'
                      }`}
                    >
                      {formatPercent(r.marginOfSafety)}
                    </td>
                    <td className="px-4 py-3">
                      {r.expectedReturn
                        ? formatPercent(r.expectedReturn)
                        : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 p-3 bg-gray-50 rounded text-sm text-gray-600">
            <p>
              <strong>Margin of Safety positif</strong> = harga pasar di bawah
              nilai wajar (undervalued).
            </p>
            <p>
              <strong>Expected Return</strong> = perkiraan imbal hasil tahunan
              jika harga bergerak ke nilai wajar dalam 5 tahun + dividen.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}