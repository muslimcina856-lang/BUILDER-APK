import React from 'react';
import { db } from '../db/db';
import { downloadJSON } from '../lib/utils';
import Card from '../components/ui/Card';

export default function Profile() {
  const handleExportAllData = async () => {
    const transactions = await db.transactions.toArray();
    const categories = await db.categories.toArray();
    const assets = await db.assets.toArray();
    const liabilities = await db.liabilities.toArray();
    const stocks = await db.stocks.toArray();
    const watchlist = await db.watchlist.toArray();
    const portfolio = await db.portfolio.toArray();
    const allData = {
      transactions,
      categories,
      assets,
      liabilities,
      stocks,
      watchlist,
      portfolio,
      exportedAt: new Date().toISOString(),
    };
    downloadJSON(
      allData,
      `finapp-backup-${new Date().toISOString().split('T')[0]}.json`
    );
  };

  const handleResetData = async () => {
    if (
      confirm(
        '⚠️ Anda yakin ingin menghapus SEMUA data? Tindakan ini tidak dapat dibatalkan. Pastikan Anda sudah mengekspor backup terlebih dahulu.'
      )
    ) {
      await db.transactions.clear();
      await db.categories.clear();
      await db.assets.clear();
      await db.liabilities.clear();
      await db.stocks.clear();
      await db.watchlist.clear();
      await db.portfolio.clear();
      alert('Semua data telah dihapus.');
      window.location.reload();
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Pengaturan</h1>

      <Card className="mb-4">
        <h2 className="font-semibold mb-2">💾 Ekspor Semua Data</h2>
        <p className="text-sm text-gray-600 mb-3">
          Unduh seluruh data keuangan dan saham sebagai file JSON untuk backup.
        </p>
        <button
          onClick={handleExportAllData}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          📥 Ekspor JSON
        </button>
      </Card>

      <Card className="border border-red-200">
        <h2 className="font-semibold text-red-700 mb-2">
          ⚠️ Reset Semua Data
        </h2>
        <p className="text-sm text-red-600 mb-3">
          Hapus seluruh data transaksi, aset, saham, dll. Aksi ini permanen.
        </p>
        <button
          onClick={handleResetData}
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
        >
          🗑 Reset Semua Data
        </button>
      </Card>
    </div>
  );
}