import React, { useState, useEffect } from 'react';
import {
  getAllAssets,
  addAsset,
  deleteAsset,
} from '../services/asset.service';
import {
  getAllLiabilities,
  addLiability,
  deleteLiability,
} from '../services/liability.service';
import { AssetItem, LiabilityItem } from '../db/db';
import { formatRupiah } from '../lib/utils';

export default function Assets() {
  const [assets, setAssets] = useState<AssetItem[]>([]);
  const [liabilities, setLiabilities] = useState<LiabilityItem[]>([]);
  const [assetForm, setAssetForm] = useState({
    name: '',
    type: 'OTHER' as AssetItem['type'],
    currentValue: '',
    acquisitionCost: '',
    notes: '',
  });
  const [liabilityForm, setLiabilityForm] = useState({
    name: '',
    type: 'LOAN' as LiabilityItem['type'],
    amount: '',
    interestRate: '',
    dueDate: '',
    notes: '',
  });

  const fetchData = async () => {
    setAssets(await getAllAssets());
    setLiabilities(await getAllLiabilities());
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    await addAsset({
      name: assetForm.name,
      type: assetForm.type,
      currentValue: parseFloat(assetForm.currentValue),
      acquisitionCost: assetForm.acquisitionCost
        ? parseFloat(assetForm.acquisitionCost)
        : undefined,
      notes: assetForm.notes,
    });
    setAssetForm({
      name: '',
      type: 'OTHER',
      currentValue: '',
      acquisitionCost: '',
      notes: '',
    });
    fetchData();
  };

  const handleAddLiability = async (e: React.FormEvent) => {
    e.preventDefault();
    await addLiability({
      name: liabilityForm.name,
      type: liabilityForm.type,
      amount: parseFloat(liabilityForm.amount),
      interestRate: liabilityForm.interestRate
        ? parseFloat(liabilityForm.interestRate)
        : undefined,
      dueDate: liabilityForm.dueDate || undefined,
      notes: liabilityForm.notes,
    });
    setLiabilityForm({
      name: '',
      type: 'LOAN',
      amount: '',
      interestRate: '',
      dueDate: '',
      notes: '',
    });
    fetchData();
  };

  const totalAssets = assets.reduce((s, a) => s + a.currentValue, 0);
  const totalLiabilities = liabilities.reduce((s, l) => s + l.amount, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Aset & Liabilitas</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ASET */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-xl font-semibold">Aset</h2>
            <span className="text-green-600 font-bold">
              {formatRupiah(totalAssets)}
            </span>
          </div>
          <form
            onSubmit={handleAddAsset}
            className="bg-white p-4 rounded shadow mb-4 space-y-2"
          >
            <input
              type="text"
              placeholder="Nama Aset"
              value={assetForm.name}
              onChange={(e) =>
                setAssetForm({ ...assetForm, name: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
              required
            />
            <select
              value={assetForm.type}
              onChange={(e) =>
                setAssetForm({
                  ...assetForm,
                  type: e.target.value as any,
                })
              }
              className="border px-3 py-2 rounded w-full"
            >
              <option value="PROPERTY">Properti</option>
              <option value="VEHICLE">Kendaraan</option>
              <option value="SAVINGS">Tabungan</option>
              <option value="INVESTMENT">Investasi</option>
              <option value="OTHER">Lainnya</option>
            </select>
            <input
              type="number"
              placeholder="Nilai Saat Ini (Rp)"
              value={assetForm.currentValue}
              onChange={(e) =>
                setAssetForm({ ...assetForm, currentValue: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
              required
            />
            <input
              type="number"
              placeholder="Harga Perolehan (opsional)"
              value={assetForm.acquisitionCost}
              onChange={(e) =>
                setAssetForm({ ...assetForm, acquisitionCost: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
            />
            <input
              type="text"
              placeholder="Catatan"
              value={assetForm.notes}
              onChange={(e) =>
                setAssetForm({ ...assetForm, notes: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 w-full"
            >
              + Tambah Aset
            </button>
          </form>
          <ul className="space-y-2">
            {assets.map((asset) => (
              <li
                key={asset.id}
                className="bg-white p-3 rounded shadow flex justify-between"
              >
                <div>
                  <p className="font-medium">
                    {asset.name}{' '}
                    <span className="text-xs text-gray-500">({asset.type})</span>
                  </p>
                  <p className="text-sm text-gray-500">{asset.notes}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-green-600">
                    {formatRupiah(asset.currentValue)}
                  </p>
                  <button
                    onClick={() =>
                      asset.id && deleteAsset(asset.id).then(fetchData)
                    }
                    className="text-red-600 text-sm hover:underline"
                  >
                    Hapus
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* LIABILITAS */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-xl font-semibold">Utang</h2>
            <span className="text-red-600 font-bold">
              {formatRupiah(totalLiabilities)}
            </span>
          </div>
          <form
            onSubmit={handleAddLiability}
            className="bg-white p-4 rounded shadow mb-4 space-y-2"
          >
            <input
              type="text"
              placeholder="Nama Utang"
              value={liabilityForm.name}
              onChange={(e) =>
                setLiabilityForm({ ...liabilityForm, name: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
              required
            />
            <select
              value={liabilityForm.type}
              onChange={(e) =>
                setLiabilityForm({
                  ...liabilityForm,
                  type: e.target.value as any,
                })
              }
              className="border px-3 py-2 rounded w-full"
            >
              <option value="LOAN">Pinjaman</option>
              <option value="CREDIT_CARD">Kartu Kredit</option>
              <option value="MORTGAGE">KPR</option>
              <option value="OTHER">Lainnya</option>
            </select>
            <input
              type="number"
              placeholder="Jumlah (Rp)"
              value={liabilityForm.amount}
              onChange={(e) =>
                setLiabilityForm({ ...liabilityForm, amount: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
              required
            />
            <input
              type="number"
              placeholder="Bunga (%) per tahun"
              value={liabilityForm.interestRate}
              onChange={(e) =>
                setLiabilityForm({
                  ...liabilityForm,
                  interestRate: e.target.value,
                })
              }
              className="border px-3 py-2 rounded w-full"
            />
            <input
              type="date"
              value={liabilityForm.dueDate}
              onChange={(e) =>
                setLiabilityForm({ ...liabilityForm, dueDate: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
            />
            <input
              type="text"
              placeholder="Catatan"
              value={liabilityForm.notes}
              onChange={(e) =>
                setLiabilityForm({ ...liabilityForm, notes: e.target.value })
              }
              className="border px-3 py-2 rounded w-full"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 w-full"
            >
              + Tambah Utang
            </button>
          </form>
          <ul className="space-y-2">
            {liabilities.map((liab) => (
              <li
                key={liab.id}
                className="bg-white p-3 rounded shadow flex justify-between"
              >
                <div>
                  <p className="font-medium">
                    {liab.name}{' '}
                    <span className="text-xs text-gray-500">
                      ({liab.type})
                    </span>
                  </p>
                  <p className="text-sm text-gray-500">{liab.notes}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-red-600">
                    {formatRupiah(liab.amount)}
                  </p>
                  <button
                    onClick={() =>
                      liab.id &&
                      deleteLiability(liab.id).then(fetchData)
                    }
                    className="text-red-600 text-sm hover:underline"
                  >
                    Hapus
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}