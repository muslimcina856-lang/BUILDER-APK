import { useState, useEffect } from 'react';
import { getDashboardSummary } from '../services/dashboard.service';

export function useDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetch = async () => {
    setLoading(true);
    const summary = await getDashboardSummary();
    setData(summary);
    setLoading(false);
  };

  useEffect(() => {
    fetch();
  }, []);

  return { data, loading, refetch: fetch };
}