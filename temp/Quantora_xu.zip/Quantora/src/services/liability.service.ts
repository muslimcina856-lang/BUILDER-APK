import { db, LiabilityItem } from '../db/db';

export async function getAllLiabilities() {
  return db.liabilities.toArray();
}

export async function addLiability(data: Omit<LiabilityItem, 'id'>) {
  return db.liabilities.add(data);
}

export async function updateLiability(id: number, data: Partial<LiabilityItem>) {
  return db.liabilities.update(id, data);
}

export async function deleteLiability(id: number) {
  return db.liabilities.delete(id);
}

export async function getTotalLiabilitiesValue() {
  const liabilities = await db.liabilities.toArray();
  return liabilities.reduce((sum, l) => sum + l.amount, 0);
}