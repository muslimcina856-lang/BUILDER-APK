import { db, AssetItem } from '../db/db';

export async function getAllAssets() {
  return db.assets.toArray();
}

export async function addAsset(data: Omit<AssetItem, 'id'>) {
  return db.assets.add(data);
}

export async function updateAsset(id: number, data: Partial<AssetItem>) {
  return db.assets.update(id, data);
}

export async function deleteAsset(id: number) {
  return db.assets.delete(id);
}

export async function getTotalAssetsValue() {
  const assets = await db.assets.toArray();
  return assets.reduce((sum, a) => sum + a.currentValue, 0);
}