package com.premium.aetherrun.game

import kotlin.math.sin
import kotlin.random.Random

/**
 * Professional screen shake with trauma decay.
 * Used for impact / death / big events.
 */
class ScreenShake {

    private var trauma = 0f          // 0..1
    private var time = 0f

    val offsetX: Float
        get() = if (trauma <= 0f) 0f else (Random.nextFloat() - 0.5f) * 2f * maxOffset * trauma * trauma

    val offsetY: Float
        get() = if (trauma <= 0f) 0f else (Random.nextFloat() - 0.5f) * 2f * maxOffset * trauma * trauma

    private val maxOffset = 28f
    private val traumaDecay = 1.6f

    fun addTrauma(amount: Float) {
        trauma = (trauma + amount).coerceIn(0f, 1f)
    }

    fun update(deltaTime: Float) {
        if (trauma > 0f) {
            trauma = (trauma - traumaDecay * deltaTime).coerceAtLeast(0f)
            time += deltaTime
        }
    }

    fun reset() {
        trauma = 0f
    }
}
