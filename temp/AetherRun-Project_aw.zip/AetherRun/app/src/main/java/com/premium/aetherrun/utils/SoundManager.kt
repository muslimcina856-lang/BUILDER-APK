package com.premium.aetherrun.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/**
 * Lightweight SoundManager ready for SFX.
 * Currently structured so you can drop .ogg / .wav into res/raw later.
 * No crash if files missing.
 */
class SoundManager(context: Context) {

    private var soundPool: SoundPool? = null
    private val soundMap = mutableMapOf<String, Int>()

    init {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            soundPool = SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(attrs)
                .build()

            // Example: later you can do
            // soundMap["jump"] = soundPool?.load(context, R.raw.jump, 1) ?: 0
            // soundMap["hit"]  = soundPool?.load(context, R.raw.hit, 1) ?: 0
            // soundMap["score"]= soundPool?.load(context, R.raw.score, 1) ?: 0
        } catch (_: Exception) {
            soundPool = null
        }
    }

    fun play(name: String, volume: Float = 0.8f) {
        val id = soundMap[name] ?: return
        soundPool?.play(id, volume, volume, 1, 0, 1f)
    }

    fun release() {
        soundPool?.release()
        soundPool = null
    }
}
