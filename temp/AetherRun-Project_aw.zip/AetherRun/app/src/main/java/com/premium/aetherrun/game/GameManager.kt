package com.premium.aetherrun.game

import android.graphics.Canvas
import com.premium.aetherrun.model.CharacterType
import kotlin.random.Random

/**
 * Central game logic controller – fully polished production version.
 * ParticleSystem + ScreenShake + FloatingText + perfect physics + difficulty ramp.
 */
class GameManager(
    private var screenWidth: Int,
    private var screenHeight: Int
) {
    enum class State { READY, PLAYING, GAME_OVER }

    var state: State = State.READY
    var score: Int = 0
    var highScore: Int = 0

    val player = Player(screenWidth, screenHeight)
    private val background = ParallaxBackground(screenWidth, screenHeight)
    private val particleSystem = ParticleSystem(poolSize = 140)
    val screenShake = ScreenShake()

    private val floatingTexts = Array(12) { FloatingText() }
    private val obstacles = Array(12) { Obstacle() }

    private var baseSpeed = 480f
    private var currentSpeed = baseSpeed
    private var spawnTimer = 0f
    private var nextSpawnInterval = 1.4f
    private var distanceAccum = 0f
    private var trailTimer = 0f
    private var wasOnGround = true
    private var lastScoreMilestone = 0

    private val groundY: Float
        get() = screenHeight * 0.78f

    fun resize(w: Int, h: Int) {
        screenWidth = w
        screenHeight = h
        player.resize(w, h)
        background.resize(w, h)
    }

    fun setCharacter(type: CharacterType) {
        player.character = type
    }

    fun startGame() {
        state = State.PLAYING
        score = 0
        currentSpeed = baseSpeed
        spawnTimer = 0f
        nextSpawnInterval = 1.3f
        distanceAccum = 0f
        trailTimer = 0f
        wasOnGround = true
        lastScoreMilestone = 0
        player.isAlive = true
        player.y = groundY
        player.velocityY = 0f
        player.isOnGround = true

        obstacles.forEach { it.active = false }
        particleSystem.clear()
        floatingTexts.forEach { it.active = false }
        screenShake.reset()
    }

    fun onTap() {
        when (state) {
            State.READY -> startGame()
            State.PLAYING -> {
                val wasGrounded = player.isOnGround
                player.jump()
                if (wasGrounded) {
                    particleSystem.emitJumpBurst(
                        player.x,
                        player.y - 10f,
                        player.character.trailColor.toInt()
                    )
                }
            }
            State.GAME_OVER -> startGame()
        }
    }

    fun update(deltaTime: Float) {
        screenShake.update(deltaTime)

        if (state != State.PLAYING) {
            background.update(currentSpeed * 0.3f, deltaTime)
            particleSystem.update(deltaTime)
            floatingTexts.forEach { if (it.active) it.update(deltaTime) }
            return
        }

        currentSpeed = baseSpeed + (score * 1.8f).coerceAtMost(420f)

        background.update(currentSpeed, deltaTime)
        player.update(deltaTime)

        // Landing
        if (player.isOnGround && !wasOnGround) {
            particleSystem.emitLandingDust(player.x, player.y, player.character.trailColor.toInt())
            screenShake.addTrauma(0.18f)
        }
        wasOnGround = player.isOnGround

        // Energy trail
        trailTimer += deltaTime
        if (trailTimer >= 0.045f) {
            trailTimer = 0f
            particleSystem.emitEnergyTrail(
                player.x,
                player.y - 40f,
                player.character.trailColor.toInt()
            )
        }

        // Obstacles
        spawnTimer += deltaTime
        if (spawnTimer >= nextSpawnInterval) {
            spawnObstacle()
            spawnTimer = 0f
            nextSpawnInterval = Random.nextFloat() * 0.7f + 0.9f - (score * 0.0015f).coerceAtMost(0.4f)
        }

        for (obs in obstacles) {
            if (!obs.active) continue
            obs.update(currentSpeed, deltaTime)

            if (checkCollision(player, obs)) {
                player.isAlive = false
                state = State.GAME_OVER
                particleSystem.emitExplosion(player.x, player.y - 40f)
                screenShake.addTrauma(0.85f)
                if (score > highScore) highScore = score
                break
            }
        }

        particleSystem.update(deltaTime)
        floatingTexts.forEach { if (it.active) it.update(deltaTime) }

        // Scoring
        distanceAccum += currentSpeed * deltaTime
        if (distanceAccum >= 25f) {
            score += 1
            distanceAccum = 0f

            if (player.isOnGround) {
                particleSystem.emitFootDust(
                    player.x - 15f,
                    player.y,
                    player.character.trailColor.toInt(),
                    1.1f
                )
            }

            if (score >= lastScoreMilestone + 50) {
                lastScoreMilestone = score
                spawnFloatingText(player.x, player.y - 120f, "+$score", player.character.primaryColor.toInt())
            }
        }
    }

    private fun spawnObstacle() {
        val obs = obstacles.firstOrNull { !it.active } ?: return
        val type = when {
            score < 30 -> 0
            score < 80 -> Random.nextInt(0, 2)
            else -> Random.nextInt(0, 3)
        }
        obs.reset(screenWidth + 80f, groundY, type)
    }

    private fun checkCollision(p: Player, o: Obstacle): Boolean {
        return p.getHitboxLeft() < o.getRight() &&
                p.getHitboxRight() > o.getLeft() &&
                p.getHitboxTop() < o.getBottom() &&
                p.getHitboxBottom() > o.getTop()
    }

    private fun spawnFloatingText(px: Float, py: Float, value: String, color: Int) {
        val ft = floatingTexts.firstOrNull { !it.active } ?: return
        ft.reset(px, py, value, color)
    }

    fun draw(canvas: Canvas) {
        canvas.save()
        canvas.translate(screenShake.offsetX, screenShake.offsetY)

        background.draw(canvas)

        for (obs in obstacles) {
            if (obs.active) obs.draw(canvas)
        }

        particleSystem.draw(canvas)
        player.draw(canvas)

        floatingTexts.forEach { if (it.active) it.draw(canvas) }

        canvas.restore()
    }
}
