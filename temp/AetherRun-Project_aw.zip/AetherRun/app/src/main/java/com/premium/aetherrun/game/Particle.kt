package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max

/**
 * Advanced Particle with full physics simulation.
 * Supports:
 * - Velocity + Acceleration (gravity)
 * - Linear drag / air resistance
 * - Angular velocity + rotation
 * - Size over lifetime (curve)
 * - Alpha over lifetime
 * - Soft glow rendering
 *
 * Designed for high-performance object pooling.
 */
class Particle {

    // Transform
    var x: Float = 0f
    var y: Float = 0f
    var rotation: Float = 0f

    // Physics
    var vx: Float = 0f
    var vy: Float = 0f
    var ax: Float = 0f          // acceleration X
    var ay: Float = 0f          // acceleration Y (gravity usually)
    var drag: Float = 0.98f     // velocity multiplier per second (air resistance)
    var angularVelocity: Float = 0f

    // Lifetime
    var life: Float = 0f
    var maxLife: Float = 1f

    // Visual
    var startSize: Float = 8f
    var endSize: Float = 0f
    var color: Int = 0xFF00F5FF.toInt()
    var startAlpha: Float = 1f
    var endAlpha: Float = 0f
    var useSoftGlow: Boolean = true

    var active: Boolean = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /**
     * Full reset for pooling.
     */
    fun reset(
        px: Float,
        py: Float,
        pvx: Float,
        pvy: Float,
        pLife: Float,
        pStartSize: Float,
        pEndSize: Float = 0f,
        pColor: Int,
        pDrag: Float = 0.98f,
        pAy: Float = 380f,              // default gravity
        pAngularVel: Float = 0f,
        pStartAlpha: Float = 1f,
        pEndAlpha: Float = 0f,
        softGlow: Boolean = true
    ) {
        x = px
        y = py
        vx = pvx
        vy = pvy
        ax = 0f
        ay = pAy
        drag = pDrag
        angularVelocity = pAngularVel
        rotation = 0f

        life = pLife
        maxLife = pLife

        startSize = pStartSize
        endSize = pEndSize
        color = pColor
        startAlpha = pStartAlpha
        endAlpha = pEndAlpha
        useSoftGlow = softGlow

        active = true
    }

    fun update(deltaTime: Float) {
        if (!active) return

        // Integrate acceleration
        vx += ax * deltaTime
        vy += ay * deltaTime

        // Apply drag (frame-rate independent)
        val dragFactor = Math.pow(drag.toDouble(), deltaTime.toDouble()).toFloat()
        vx *= dragFactor
        vy *= dragFactor

        // Integrate velocity
        x += vx * deltaTime
        y += vy * deltaTime

        // Rotation
        rotation += angularVelocity * deltaTime

        // Lifetime
        life -= deltaTime
        if (life <= 0f) {
            active = false
        }
    }

    fun draw(canvas: Canvas) {
        if (!active) return

        val t = 1f - (life / maxLife)          // 0 → 1 over lifetime
        val currentSize = startSize + (endSize - startSize) * t
        val currentAlpha = startAlpha + (endAlpha - startAlpha) * t
        val alphaInt = (255 * currentAlpha).toInt().coerceIn(0, 255)

        if (currentSize <= 0.5f || alphaInt <= 5) return

        val finalColor = (color and 0x00FFFFFF) or (alphaInt shl 24)

        if (useSoftGlow && currentSize > 3f) {
            // Soft radial glow
            glowPaint.shader = RadialGradient(
                x, y, currentSize * 1.8f,
                intArrayOf(finalColor, finalColor and 0x00FFFFFF),
                floatArrayOf(0.15f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(x, y, currentSize * 1.8f, glowPaint)
        }

        // Core
        paint.color = finalColor
        paint.style = Paint.Style.FILL
        canvas.save()
        canvas.rotate(rotation, x, y)
        canvas.drawCircle(x, y, currentSize, paint)
        canvas.restore()
    }

    /** Normalized lifetime progress 0..1 */
    fun progress(): Float = max(0f, 1f - (life / maxLife))
}
