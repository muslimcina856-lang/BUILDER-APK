package com.premium.aetherrun.game

import android.graphics.Canvas
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Professional Particle System
 * - Object pool (zero allocation during gameplay)
 * - Multiple high-level emitters
 * - Physics-driven (drag, gravity, angular velocity)
 * - Tuned for 60fps endless runner
 */
class ParticleSystem(poolSize: Int = 120) {

    private val pool = Array(poolSize) { Particle() }

    // --------------------------------------------------
    // Core
    // --------------------------------------------------

    fun update(deltaTime: Float) {
        for (p in pool) {
            if (p.active) p.update(deltaTime)
        }
    }

    fun draw(canvas: Canvas) {
        for (p in pool) {
            if (p.active) p.draw(canvas)
        }
    }

    fun clear() {
        pool.forEach { it.active = false }
    }

    private fun obtain(): Particle? = pool.firstOrNull { !it.active }

    // --------------------------------------------------
    // High-level Emitters (tuned for premium feel)
    // --------------------------------------------------

    /**
     * Continuous foot dust while running on ground.
     */
    fun emitFootDust(x: Float, y: Float, characterColor: Int, intensity: Float = 1f) {
        val count = (3 * intensity).toInt().coerceIn(2, 6)
        repeat(count) {
            val p = obtain() ?: return
            p.reset(
                px = x + Random.nextFloat() * 18f - 6f,
                py = y - 4f,
                pvx = -Random.nextFloat() * 90f - 30f,
                pvy = -Random.nextFloat() * 140f - 20f,
                pLife = 0.35f + Random.nextFloat() * 0.35f,
                pStartSize = 3.5f + Random.nextFloat() * 4f,
                pEndSize = 0.5f,
                pColor = characterColor,
                pDrag = 0.92f,
                pAy = 520f,
                pAngularVel = (Random.nextFloat() - 0.5f) * 360f,
                softGlow = true
            )
        }
    }

    /**
     * Strong burst when player jumps.
     */
    fun emitJumpBurst(x: Float, y: Float, characterColor: Int) {
        repeat(14) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = 180f + Random.nextFloat() * 220f
            val p = obtain() ?: return
            p.reset(
                px = x,
                py = y,
                pvx = cos(angle) * speed * 0.7f,
                pvy = sin(angle) * speed - 120f,
                pLife = 0.45f + Random.nextFloat() * 0.4f,
                pStartSize = 5f + Random.nextFloat() * 7f,
                pEndSize = 0f,
                pColor = characterColor,
                pDrag = 0.94f,
                pAy = 300f,
                pAngularVel = (Random.nextFloat() - 0.5f) * 480f,
                softGlow = true
            )
        }
    }

    /**
     * Death / impact explosion (dramatic).
     */
    fun emitExplosion(x: Float, y: Float, baseColor: Int = 0xFFFF2E97.toInt()) {
        // Core flash particles
        repeat(22) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = 220f + Random.nextFloat() * 380f
            val p = obtain() ?: return
            p.reset(
                px = x + (Random.nextFloat() - 0.5f) * 20f,
                py = y + (Random.nextFloat() - 0.5f) * 20f,
                pvx = cos(angle) * speed,
                pvy = sin(angle) * speed - 80f,
                pLife = 0.55f + Random.nextFloat() * 0.55f,
                pStartSize = 6f + Random.nextFloat() * 10f,
                pEndSize = 0f,
                pColor = baseColor,
                pDrag = 0.91f,
                pAy = 180f,
                pAngularVel = (Random.nextFloat() - 0.5f) * 720f,
                softGlow = true
            )
        }

        // Secondary slower sparks
        repeat(12) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = 80f + Random.nextFloat() * 140f
            val p = obtain() ?: return
            p.reset(
                px = x,
                py = y,
                pvx = cos(angle) * speed,
                pvy = sin(angle) * speed - 40f,
                pLife = 0.8f + Random.nextFloat() * 0.6f,
                pStartSize = 3f + Random.nextFloat() * 4f,
                pEndSize = 1f,
                pColor = 0xFFFFFFFF.toInt(),
                pDrag = 0.96f,
                pAy = 250f,
                softGlow = false
            )
        }
    }

    /**
     * Soft energy trail behind the runner (called every few frames).
     */
    fun emitEnergyTrail(x: Float, y: Float, characterColor: Int) {
        repeat(2) {
            val p = obtain() ?: return
            p.reset(
                px = x - 25f + Random.nextFloat() * 10f,
                py = y - 30f + Random.nextFloat() * 40f,
                pvx = -40f - Random.nextFloat() * 60f,
                pvy = (Random.nextFloat() - 0.5f) * 40f,
                pLife = 0.25f + Random.nextFloat() * 0.25f,
                pStartSize = 8f + Random.nextFloat() * 6f,
                pEndSize = 2f,
                pColor = characterColor,
                pDrag = 0.88f,
                pAy = 0f,               // no gravity for pure energy trail
                pStartAlpha = 0.7f,
                pEndAlpha = 0f,
                softGlow = true
            )
        }
    }

    /**
     * Landing impact dust.
     */
    fun emitLandingDust(x: Float, y: Float, characterColor: Int) {
        repeat(10) {
            val p = obtain() ?: return
            p.reset(
                px = x + (Random.nextFloat() - 0.5f) * 40f,
                py = y,
                pvx = (Random.nextFloat() - 0.5f) * 160f,
                pvy = -Random.nextFloat() * 180f - 40f,
                pLife = 0.4f + Random.nextFloat() * 0.35f,
                pStartSize = 4f + Random.nextFloat() * 5f,
                pEndSize = 0.5f,
                pColor = characterColor,
                pDrag = 0.90f,
                pAy = 600f,
                softGlow = true
            )
        }
    }
}
