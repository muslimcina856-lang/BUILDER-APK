package com.premium.aetherrun.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.premium.aetherrun.R
import com.premium.aetherrun.game3d.Aether3DView
import com.premium.aetherrun.game3d.Game3DRenderer
import com.premium.aetherrun.model.CharacterType
import com.premium.aetherrun.utils.PrefsManager

class GameActivity : AppCompatActivity() {

    private lateinit var view3d: Aether3DView
    private lateinit var tvScore: TextView
    private lateinit var tvHigh: TextView
    private lateinit var tvHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { PrefsManager(this) }

    private val hudUpdater = object : Runnable {
        override fun run() {
            if (::view3d.isInitialized) {
                tvScore.text = "SKOR  ${view3d.getScore()}"
                tvHigh.text = "TERBAIK  ${view3d.getHighScore()}"

                when (view3d.getState()) {
                    Game3DRenderer.State.READY -> {
                        tvHint.visibility = android.view.View.VISIBLE
                        tvHint.text = "KETIK = LOMPAT\nSWIPE KIRI/KANAN = LORONG"
                    }
                    Game3DRenderer.State.PLAYING -> {
                        tvHint.visibility = android.view.View.GONE
                    }
                    Game3DRenderer.State.GAME_OVER -> {
                        tvHint.visibility = android.view.View.VISIBLE
                        tvHint.text = "TAMAT - Ketik untuk cuba lagi\nSkor: ${view3d.getScore()}"
                        if (view3d.getScore() > prefs.highScore) {
                            prefs.highScore = view3d.getScore()
                        }
                    }
                }
            }
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_game)

        val container = findViewById<FrameLayout>(R.id.container3d)
        tvScore = findViewById(R.id.tvScore)
        tvHigh = findViewById(R.id.tvHigh)
        tvHint = findViewById(R.id.tvHint)

        view3d = Aether3DView(this)
        container.addView(
            view3d,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val char = CharacterType.fromOrdinalSafe(prefs.selectedCharacterIndex)
        view3d.setCharacter(char)
        tvHigh.text = "TERBAIK  ${prefs.highScore}"
    }

    override fun onResume() {
        super.onResume()
        view3d.start()
        handler.post(hudUpdater)
    }

    override fun onPause() {
        super.onPause()
        view3d.stop()
        handler.removeCallbacks(hudUpdater)
    }

    override fun onDestroy() {
        super.onDestroy()
        view3d.destroy()
    }
}
