package com.premium.aetherrun.game3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.premium.aetherrun.model.CharacterType
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Final polished 3D Endless Runner
 * - Multi-part character + lighting
 * - 3 lanes (left / center / right)
 * - Particles, trail, camera shake
 * - Background pillars, varied obstacles
 */
class Game3DRenderer : GLSurfaceView.Renderer {

    enum class State { READY, PLAYING, GAME_OVER }

    var state = State.READY
    var score = 0
    var highScore = 0

    // Player
    private var playerX = 0f          // lane position
    private var targetX = 0f
    private var lane = 1              // 0 left, 1 center, 2 right
    private val lanePos = floatArrayOf(-3.2f, 0f, 3.2f)

    private var playerY = 1.05f
    private var playerZ = 0f
    private var velocityY = 0f
    private var isOnGround = true
    private var wasOnGround = true
    private var runAnim = 0f

    private val gravity = -38f
    private val jumpForce = 15.2f
    private var speed = 18f
    private var distance = 0f
    private var spawnTimer = 0f
    private var nextSpawn = 1.3f

    // Obstacles
    private val obsZ = FloatArray(18) { -30f - it * 13f }
    private val obsType = IntArray(18) { 0 }
    private val obsLane = IntArray(18) { 1 }
    private val obsActive = BooleanArray(18) { true }

    // Camera
    private var camY = 6.5f
    private var camZ = 13f
    private var camX = 0f
    private var shakeX = 0f
    private var shakeY = 0f
    private var trauma = 0f

    // Particles
    private data class P(
        var x: Float = 0f, var y: Float = 0f, var z: Float = 0f,
        var vx: Float = 0f, var vy: Float = 0f, var vz: Float = 0f,
        var life: Float = 0f, var maxLife: Float = 1f,
        var size: Float = 0.15f, var active: Boolean = false,
        var r: Float = 1f, var g: Float = 1f, var b: Float = 1f
    )
    private val particles = Array(90) { P() }

    // Background
    private val pillarZ = FloatArray(12) { -18f - it * 18f }
    private val pillarX = FloatArray(12) { if (it % 2 == 0) -13f else 13f }

    // GL
    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val tempMatrix = FloatArray(16)

    private var program = 0
    private var positionHandle = 0
    private var normalHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private var lightDirHandle = 0

    private lateinit var cubePosBuffer: FloatBuffer
    private lateinit var cubeNormalBuffer: FloatBuffer
    private lateinit var indexBuffer: ShortBuffer

    private var character = CharacterType.NOVA_STRIKER
    private var lastTime = System.nanoTime()

    private val cubePositions = floatArrayOf(
        -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
        -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f, -0.5f, 0.5f,-0.5f,
        -0.5f,-0.5f,-0.5f, -0.5f,-0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f,-0.5f,
         0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f,  0.5f, 0.5f,-0.5f,
        -0.5f, 0.5f,-0.5f, -0.5f, 0.5f, 0.5f,  0.5f, 0.5f, 0.5f,  0.5f, 0.5f,-0.5f,
        -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f, -0.5f,-0.5f, 0.5f
    )
    private val cubeNormals = floatArrayOf(
         0f,0f,1f, 0f,0f,1f, 0f,0f,1f, 0f,0f,1f,
         0f,0f,-1f,0f,0f,-1f,0f,0f,-1f,0f,0f,-1f,
        -1f,0f,0f,-1f,0f,0f,-1f,0f,0f,-1f,0f,0f,
         1f,0f,0f, 1f,0f,0f, 1f,0f,0f, 1f,0f,0f,
         0f,1f,0f, 0f,1f,0f, 0f,1f,0f, 0f,1f,0f,
         0f,-1f,0f,0f,-1f,0f,0f,-1f,0f,0f,-1f,0f
    )
    private val cubeIndices = shortArrayOf(
        0,1,2,0,2,3, 4,5,6,4,6,7, 8,9,10,8,10,11,
        12,13,14,12,14,15, 16,17,18,16,18,19, 20,21,22,20,22,23
    )

    private val vsCode = """
        uniform mat4 uMVPMatrix;
        attribute vec4 vPosition;
        attribute vec3 vNormal;
        varying vec3 vN;
        void main() {
            vN = vNormal;
            gl_Position = uMVPMatrix * vPosition;
        }
    """.trimIndent()

    private val fsCode = """
        precision mediump float;
        uniform vec4 vColor;
        uniform vec3 uLightDir;
        varying vec3 vN;
        void main() {
            float diff = max(dot(normalize(vN), normalize(uLightDir)), 0.0);
            float light = 0.22 + diff * 0.88;
            gl_FragColor = vec4(vColor.rgb * light, vColor.a);
        }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.01f, 0.01f, 0.03f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)

        cubePosBuffer = bufF(cubePositions)
        cubeNormalBuffer = bufF(cubeNormals)
        indexBuffer = bufS(cubeIndices)

        val vs = loadShader(GLES20.GL_VERTEX_SHADER, vsCode)
        val fs = loadShader(GLES20.GL_FRAGMENT_SHADER, fsCode)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)

        positionHandle = GLES20.glGetAttribLocation(program, "vPosition")
        normalHandle = GLES20.glGetAttribLocation(program, "vNormal")
        colorHandle = GLES20.glGetUniformLocation(program, "vColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        lightDirHandle = GLES20.glGetUniformLocation(program, "uLightDir")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat().coerceAtLeast(1f)
        Matrix.perspectiveM(projectionMatrix, 0, 38f, ratio, 0.3f, 170f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = ((now - lastTime) / 1e9f).coerceIn(0.001f, 0.04f)
        lastTime = now
        update(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        GLES20.glUniform3f(lightDirHandle, 0.35f, 0.9f, 0.28f)

        // Camera
        val tCamY = playerY + 6.2f
        val tCamZ = playerZ + 13.5f
        val tCamX = playerX * 0.35f
        camY += (tCamY - camY) * 0.1f
        camZ += (tCamZ - camZ) * 0.1f
        camX += (tCamX - camX) * 0.1f

        if (trauma > 0f) {
            shakeX = (Random.nextFloat() - 0.5f) * trauma * 2f
            shakeY = (Random.nextFloat() - 0.5f) * trauma * 1.5f
            trauma = (trauma - dt * 2.4f).coerceAtLeast(0f)
        } else {
            shakeX = 0f
            shakeY = 0f
        }

        Matrix.setLookAtM(viewMatrix, 0,
            camX + shakeX, camY + shakeY, camZ,
            camX * 0.4f, playerY + 1.4f, playerZ - 3f,
            0f, 1f, 0f)

        // Background pillars
        for (i in pillarZ.indices) {
            if (pillarZ[i] > playerZ + 45f) {
                pillarZ[i] = playerZ - 100f - Random.nextFloat() * 25f
            }
            drawBox(pillarX[i], 4.5f, pillarZ[i], 2f, 10f, 2f, floatArrayOf(0.07f, 0.07f, 0.16f, 1f))
            drawBox(pillarX[i], 9.6f, pillarZ[i], 2.4f, 0.45f, 2.4f, floatArrayOf(0.1f, 0.18f, 0.32f, 1f))
        }

        // Ground
        drawBox(0f, -0.35f, playerZ - 60f, 48f, 0.7f, 160f, floatArrayOf(0.04f, 0.04f, 0.1f, 1f))
        // Lane lines
        for (lx in lanePos) {
            drawBox(lx, 0.02f, playerZ - 40f, 0.12f, 0.04f, 100f, floatArrayOf(0f, 0.55f, 0.7f, 0.5f))
        }
        for (i in 0..12) {
            val gz = playerZ - 6f - i * 11f
            drawBox(0f, 0.015f, gz, 46f, 0.05f, 0.3f, floatArrayOf(0f, 0.35f, 0.45f, 0.55f))
        }

        // Particles
        for (p in particles) {
            if (!p.active) continue
            val a = (p.life / p.maxLife).coerceIn(0.05f, 1f)
            drawBox(p.x, p.y, p.z, p.size, p.size, p.size, floatArrayOf(p.r, p.g, p.b, a))
        }

        drawCharacter()

        for (i in obsZ.indices) {
            if (!obsActive[i] || obsZ[i] > playerZ + 35f) continue
            drawObstacle(i)
        }
    }

    private fun drawCharacter() {
        val base = charColor()
        val dark = floatArrayOf(base[0] * 0.48f, base[1] * 0.48f, base[2] * 0.48f, 1f)
        val bright = floatArrayOf(
            (base[0] * 1.28f).coerceAtMost(1f),
            (base[1] * 1.28f).coerceAtMost(1f),
            (base[2] * 1.28f).coerceAtMost(1f), 1f
        )

        val leg = sin(runAnim.toDouble()).toFloat() * 0.4f
        val arm = sin(runAnim.toDouble()).toFloat() * 0.45f
        val bob = if (isOnGround) sin(runAnim * 2f) * 0.05f else 0f
        val py = playerY + bob
        val px = playerX

        // Torso
        drawBox(px, py + 0.95f, playerZ, 0.76f, 0.9f, 0.46f, base)
        drawBox(px, py + 1.2f, playerZ + 0.15f, 0.66f, 0.44f, 0.22f, bright)
        drawBox(px, py + 1.06f, playerZ + 0.26f, 0.24f, 0.24f, 0.14f, bright)

        // Head
        drawBox(px, py + 1.7f, playerZ, 0.46f, 0.46f, 0.46f, base)
        drawBox(px, py + 1.98f, playerZ, 0.22f, 0.26f, 0.4f, bright)
        drawBox(px, py + 1.72f, playerZ + 0.22f, 0.36f, 0.16f, 0.1f, floatArrayOf(0.9f, 0.97f, 1f, 1f))

        // Arms
        drawBox(px - 0.6f, py + 1.1f, playerZ + arm * 0.3f, 0.26f, 0.6f, 0.26f, dark)
        drawBox(px - 0.68f, py + 0.68f + arm * 0.12f, playerZ + arm * 0.55f, 0.22f, 0.44f, 0.22f, base)
        drawBox(px + 0.6f, py + 1.1f, playerZ - arm * 0.3f, 0.26f, 0.6f, 0.26f, dark)
        drawBox(px + 0.68f, py + 0.68f - arm * 0.12f, playerZ - arm * 0.55f, 0.22f, 0.44f, 0.22f, base)

        // Legs
        drawBox(px - 0.26f, py + 0.38f, playerZ + leg, 0.3f, 0.6f, 0.32f, dark)
        drawBox(px - 0.26f, py + 0.05f, playerZ + leg * 1.4f, 0.28f, 0.32f, 0.36f, base)
        drawBox(px + 0.26f, py + 0.38f, playerZ - leg, 0.3f, 0.6f, 0.32f, dark)
        drawBox(px + 0.26f, py + 0.05f, playerZ - leg * 1.4f, 0.28f, 0.32f, 0.36f, base)

        // Shoulders
        drawBox(px - 0.54f, py + 1.38f, playerZ, 0.3f, 0.24f, 0.34f, bright)
        drawBox(px + 0.54f, py + 1.38f, playerZ, 0.3f, 0.24f, 0.34f, bright)
    }

    private fun drawObstacle(i: Int) {
        val z = obsZ[i]
        val x = lanePos[obsLane[i].coerceIn(0, 2)]
        val pink = floatArrayOf(1f, 0.08f, 0.38f, 1f)
        val dark = floatArrayOf(0.6f, 0.03f, 0.2f, 1f)
        when (obsType[i]) {
            0 -> {
                drawBox(x, 0.58f, z, 1.5f, 1.2f, 1.1f, pink)
                drawBox(x, 1.25f, z, 1.65f, 0.2f, 1.2f, dark)
            }
            1 -> {
                drawBox(x, 1.2f, z, 1.2f, 2.4f, 1.2f, pink)
                drawBox(x, 2.5f, z, 1.45f, 0.28f, 1.45f, dark)
            }
            else -> {
                drawBox(x, 0.5f, z, 2.2f, 1.0f, 1.3f, pink)
                drawBox(x - 0.8f, 1.0f, z, 0.5f, 0.5f, 0.5f, dark)
                drawBox(x + 0.8f, 1.0f, z, 0.5f, 0.5f, 0.5f, dark)
            }
        }
    }

    private fun update(dt: Float) {
        // Particles
        for (p in particles) {
            if (!p.active) continue
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.z += p.vz * dt
            p.vy -= 14f * dt
            p.life -= dt
            if (p.life <= 0f) p.active = false
        }

        // Lane lerp
        targetX = lanePos[lane]
        playerX += (targetX - playerX) * (12f * dt).coerceAtMost(1f)

        if (state != State.PLAYING) return

        runAnim += dt * (if (isOnGround) 12.5f else 3.5f)
        playerZ -= speed * dt
        distance += speed * dt
        score = (distance / 2.4f).toInt()

        velocityY += gravity * dt
        playerY += velocityY * dt
        if (playerY <= 1.05f) {
            playerY = 1.05f
            velocityY = 0f
            isOnGround = true
        }

        if (isOnGround && !wasOnGround) {
            trauma = 0.32f
            emitBurst(playerX, 1.15f, playerZ, 14, 0.7f)
        }
        wasOnGround = isOnGround

        // Dust + trail
        if (isOnGround && Random.nextFloat() < 0.5f) {
            emitOne(playerX + (Random.nextFloat() - 0.5f) * 0.5f, 0.25f, playerZ + 0.4f,
                (Random.nextFloat() - 0.5f) * 2f, 1.2f + Random.nextFloat() * 2f, 2f + Random.nextFloat() * 3f,
                0.28f, 0.13f)
        }
        if (Random.nextFloat() < 0.55f) {
            val c = charColor()
            emitOne(playerX + (Random.nextFloat() - 0.5f) * 0.6f, playerY + 0.7f + Random.nextFloat() * 0.7f, playerZ + 0.9f,
                (Random.nextFloat() - 0.5f) * 1.5f, (Random.nextFloat() - 0.5f) * 1.2f, 3.5f + Random.nextFloat() * 4f,
                0.32f, 0.16f, c[0], c[1], c[2])
        }

        // Spawn
        spawnTimer += dt
        if (spawnTimer >= nextSpawn) {
            spawnTimer = 0f
            nextSpawn = 0.85f + Random.nextFloat() * 0.75f - (score * 0.0013f).coerceAtMost(0.4f)
            var idx = 0
            var far = -99999f
            for (i in obsZ.indices) {
                if (obsZ[i] > far) {
                    far = obsZ[i]
                    idx = i
                }
            }
            obsZ[idx] = playerZ - 28f - Random.nextFloat() * 8f
            obsLane[idx] = Random.nextInt(0, 3)
            obsType[idx] = when {
                score < 18 -> 0
                score < 50 -> Random.nextInt(0, 2)
                else -> Random.nextInt(0, 3)
            }
            obsActive[idx] = true
        }

        // Collision (same lane only)
        for (i in obsZ.indices) {
            if (!obsActive[i]) continue
            if (obsLane[i] != lane) continue
            val dz = obsZ[i] - playerZ
            val hLimit = if (obsType[i] == 1) 3.4f else 2.6f
            if (dz > -1.5f && dz < 1.5f && playerY < hLimit && abs(playerX - lanePos[obsLane[i]]) < 1.6f) {
                state = State.GAME_OVER
                trauma = 1f
                emitBurst(playerX, playerY + 0.9f, playerZ, 32, 1.6f)
                if (score > highScore) highScore = score
                break
            }
        }

        speed = 18f + (score * 0.06f).coerceAtMost(15f)
    }

    private fun emitBurst(x: Float, y: Float, z: Float, count: Int, force: Float) {
        val c = charColor()
        repeat(count) {
            val p = particles.firstOrNull { !it.active } ?: return
            val ang = Random.nextFloat() * 6.2832f
            p.x = x
            p.y = y
            p.z = z
            p.vx = cos(ang) * force * (0.4f + Random.nextFloat())
            p.vy = 1.5f + Random.nextFloat() * force * 1.6f
            p.vz = sin(ang) * force * (0.4f + Random.nextFloat())
            p.life = 0.35f + Random.nextFloat() * 0.55f
            p.maxLife = p.life
            p.size = 0.09f + Random.nextFloat() * 0.22f
            p.r = c[0]; p.g = c[1]; p.b = c[2]
            p.active = true
        }
    }

    private fun emitOne(
        x: Float, y: Float, z: Float,
        vx: Float, vy: Float, vz: Float,
        life: Float, size: Float,
        r: Float = 0.25f, g: Float = 0.75f, b: Float = 1f
    ) {
        val p = particles.firstOrNull { !it.active } ?: return
        p.x = x; p.y = y; p.z = z
        p.vx = vx; p.vy = vy; p.vz = vz
        p.life = life; p.maxLife = life
        p.size = size
        p.r = r; p.g = g; p.b = b
        p.active = true
    }

    /** Called from view: jump or lane change */
    fun onTap() {
        when (state) {
            State.READY -> startGame()
            State.PLAYING -> {
                if (isOnGround) {
                    velocityY = jumpForce
                    isOnGround = false
                    emitBurst(playerX, 1.25f, playerZ, 11, 1f)
                }
            }
            State.GAME_OVER -> startGame()
        }
    }

    fun moveLeft() {
        if (state == State.PLAYING && lane > 0) {
            lane--
            trauma = 0.08f
        }
    }

    fun moveRight() {
        if (state == State.PLAYING && lane < 2) {
            lane++
            trauma = 0.08f
        }
    }

    private fun startGame() {
        state = State.PLAYING
        score = 0
        distance = 0f
        playerY = 1.05f
        playerZ = 0f
        playerX = 0f
        targetX = 0f
        lane = 1
        velocityY = 0f
        isOnGround = true
        wasOnGround = true
        speed = 18f
        runAnim = 0f
        spawnTimer = 0f
        nextSpawn = 1.2f
        trauma = 0f
        particles.forEach { it.active = false }
        for (i in obsZ.indices) {
            obsZ[i] = -24f - i * 12f
            obsType[i] = 0
            obsLane[i] = Random.nextInt(0, 3)
            obsActive[i] = true
        }
        for (i in pillarZ.indices) {
            pillarZ[i] = -12f - i * 18f
            pillarX[i] = if (i % 2 == 0) -13.5f else 13.5f
        }
    }

    fun setCharacter(type: CharacterType) {
        character = type
    }

    private fun charColor(): FloatArray = when (character) {
        CharacterType.AETHER_PHANTOM -> floatArrayOf(0.7f, 0.15f, 1f, 1f)
        CharacterType.NOVA_STRIKER -> floatArrayOf(0f, 0.9f, 1f, 1f)
        CharacterType.EMBER_RONIN -> floatArrayOf(1f, 0.3f, 0.05f, 1f)
        CharacterType.VOID_RUNNER -> floatArrayOf(0.35f, 0.1f, 0.55f, 1f)
        CharacterType.SOLARIX -> floatArrayOf(1f, 0.8f, 0.1f, 1f)
        CharacterType.KAIROS -> floatArrayOf(0.8f, 0.88f, 1f, 1f)
    }

    private fun drawBox(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, color: FloatArray) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        Matrix.multiplyMM(tempMatrix, 0, viewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, tempMatrix, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniform4fv(colorHandle, 1, color, 0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 12, cubePosBuffer)
        GLES20.glEnableVertexAttribArray(normalHandle)
        GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 12, cubeNormalBuffer)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, cubeIndices.size, GLES20.GL_UNSIGNED_SHORT, indexBuffer)
        GLES20.glDisableVertexAttribArray(positionHandle)
        GLES20.glDisableVertexAttribArray(normalHandle)
    }

    private fun bufF(d: FloatArray): FloatBuffer {
        val b = ByteBuffer.allocateDirect(d.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(d)
        b.position(0)
        return b
    }

    private fun bufS(d: ShortArray): ShortBuffer {
        val b = ByteBuffer.allocateDirect(d.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        b.put(d)
        b.position(0)
        return b
    }

    private fun loadShader(type: Int, code: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, code)
        GLES20.glCompileShader(s)
        return s
    }
}
