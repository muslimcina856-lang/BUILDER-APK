package com.premium.aetherrun.game3d

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.premium.aetherrun.model.CharacterType
import com.premium.aetherrun.utils.PrefsManager

/**
 * 3D Endless Runner View
 * Tap = jump / start / restart
 * Swipe left / right = change lane
 */
class Aether3DView(context: Context) : GLSurfaceView(context) {

    private val renderer = Game3DRenderer()
    private val prefs = PrefsManager(context)

    private var downX = 0f
    private var downY = 0f
    private var moved = false

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY

        val char = CharacterType.fromOrdinalSafe(prefs.selectedCharacterIndex)
        renderer.setCharacter(char)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                if (Math.abs(dx) > 80f) {
                    moved = true
                    if (dx < 0) renderer.moveLeft()
                    else renderer.moveRight()
                    downX = event.x
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    renderer.onTap()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    fun setCharacter(type: CharacterType) {
        renderer.setCharacter(type)
        prefs.selectedCharacterIndex = type.ordinal
    }

    fun getScore(): Int = renderer.score
    fun getHighScore(): Int = renderer.highScore
    fun getState(): Game3DRenderer.State = renderer.state

    fun start() = onResume()
    fun stop() = onPause()
    fun destroy() {}
}
