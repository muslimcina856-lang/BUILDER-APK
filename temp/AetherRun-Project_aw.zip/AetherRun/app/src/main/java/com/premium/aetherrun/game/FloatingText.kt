package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface

/**
 * Floating score / feedback text with fade + rise animation.
 * Poolable.
 */
class FloatingText {

    var x: Float = 0f
    var y: Float = 0f
    var text: String = ""
    var life: Float = 0f
    var maxLife: Float = 1f
    var active: Boolean = false
    var color: Int = 0xFFFFFFFF.toInt()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 42f
    }

    fun reset(px: Float, py: Float, value: String, pColor: Int = 0xFF00F5FF.toInt()) {
        x = px
        y = py
        text = value
        life = 1.1f
        maxLife = 1.1f
        color = pColor
        active = true
    }

    fun update(deltaTime: Float) {
        if (!active) return
        y -= 70f * deltaTime          // rise
        life -= deltaTime
        if (life <= 0f) active = false
    }

    fun draw(canvas: Canvas) {
        if (!active) return
        val t = life / maxLife
        val alpha = (255 * t).toInt().coerceIn(0, 255)
        paint.color = (color and 0x00FFFFFF) or (alpha shl 24)
        paint.textSize = 38f + 18f * t
        canvas.drawText(text, x, y, paint)
    }
}
