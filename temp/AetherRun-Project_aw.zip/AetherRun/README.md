# AetherRun 3D

## Status: Working 3D Foundation (OpenGL ES)

Game sudah ditukar ke **3D sebenar** menggunakan OpenGL ES 2.0.

### Apa yang berfungsi sekarang:
- Perspective camera (follow player)
- Depth buffer
- 3D cubes untuk Player, Obstacle, Ground
- Jump physics
- Collision
- Score + High score
- Character color berbeza ikut pilihan
- HUD overlay
- Icon dari gambar kau

### Cara main
- Ketik skrin = Mula / Lompat / Restart

### Nota teknikal
- Tiada dependency Filament (supaya tak crash & tak berat)
- Semua geometry & shader ada dalam code
- Boleh terus Run dalam Android Studio

### Langkah seterusnya (kalau nak lebih advanced)
- Ganti cube dengan model .obj / .glb
- Tambah texture & lighting yang lebih baik
- Particle 3D
- Atau pindah ke Filament / Unity kemudian
