# Sistem combat v0.4

## Pipeline

Hero dan musuh menggunakan model bersama: `CombatActorState`, `HealthPool`,
`SkillController`, `StatusController` dan `CombatResolver`.

1. Input atau AI meminta aktivasi skill.
2. Controller menyemak kematian, stun, cast aktif, resource dan cooldown.
3. Skill masuk fasa windup dan telegraph dilukis.
4. `attackWindowOpened` diterbitkan tepat sekali apabila fasa active bermula.
5. Melee, area dan dash menyemak sasaran; projectile mencipta komponen bergerak.
6. Resolver mengira crit, defense, resistance, shield, HP dan invulnerability.
7. Hit sah memproses knockback, poise, stagger, status dan life steal.
8. Game menghasilkan hit flash, VFX, damage text, audio, shake dan haptic.
9. Kematian dilaporkan sekali dan progress misi dikemas kini.

## Formula damage

```text
rawDamage = baseDamage + attackPower × attackScaling
criticalDamage = rawDamage × criticalMultiplier          (jika crit)
defenseMultiplier = 100 ÷ (100 + defense)
resistanceMultiplier = 1 - resistance
gameplayDamage = max(1, criticalDamage × defenseMultiplier × resistanceMultiplier)
```

`trueDamage` mengabaikan defense dan resistance. Shield menyerap damage dahulu.
Nombor damage menggunakan jumlah sebenar yang diserap shield dan ditolak
kepada HP.

## Fasa skill

| Fasa | Fungsi |
|---|---|
| Windup | Telegraph dan ruang untuk bertindak balas |
| Active | Membuka hit window atau menghasilkan projectile |
| Recovery | Actor belum boleh memulakan skill lain |
| Cooldown | Masa sebelum skill sama boleh digunakan semula |

## Corak serangan

- `melee`: hit arc mengikut arah actor.
- `projectile`: komponen bergerak dengan velocity, range dan collision.
- `area`: shockwave bulat dengan maksimum sasaran.
- `dash`: impulse mendatar, trail dan optional invulnerability.

## Status

- Burning: damage api berkala.
- Poisoned: damage racun berkala.
- Chilled: mengurangkan kelajuan gerakan.
- Stunned: menghalang tindakan.
- Armor Broken: mengurangkan perlindungan sasaran.

Status mempunyai tempoh, stack limit dan tick interval. Tick akhir diproses
secara konsisten sebelum status tamat.

## Feedback pemain

- Telegraph windup berbeza untuk melee, area dan projectile.
- Hit flash putih, impact particle dan nombor damage.
- Damage kritikal mempunyai penekanan visual lebih kuat.
- Projectile mempunyai trail dan warna mengikut elemen.
- Serangan berat menghasilkan screen shake lebih kuat.
- Butang aksi sentuh memberi haptic selection feedback.


## Monitor Golem v0.4

- `screen_beam` menyimpan arah sasaran ketika `castStarted`; projectile
  menggunakan arah simpanan itu ketika `attackWindowOpened`, jadi tiada
  tracking selepas tembakan.
- `aether_barrage` menghasilkan tiga projectile pada sudut `-0.18`, `0` dan
  `+0.18` radian.
- `core_pulse` menggunakan telegraph tiga ring sebelum area hit dibuka.
- AI boss memilih skill mengikut jarak, cooldown, fasa dan urutan pattern.
- HUD memaparkan nama cast aktif, manakala arena serta aura bertukar warna pada
  Fasa 2.
