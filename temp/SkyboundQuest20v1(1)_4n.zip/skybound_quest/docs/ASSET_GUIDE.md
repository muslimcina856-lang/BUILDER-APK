# Panduan aset v0.4

## Arah seni

Tema visual ialah **Aether Ruins**: hutan terang yang tumbuh di atas struktur
sci-fi purba. Palet utama menggunakan hijau lumut, teal gelap, cyan bercahaya,
coklat tanah dan emas relik.

## Aset runtime

Semua imej yang dibundle berada di:

```text
assets/images/generated/
```

| Folder | Kandungan | Bilangan |
|---|---|---:|
| `backgrounds/` | 5 lapisan parallax | 5 |
| `branding/` | ikon runtime 512px dan logo | 2 |
| `heroes/` | 4 wira × 4 keadaan | 16 |
| `enemies/` | 6 musuh; boss mempunyai phase/charge/hurt/defeat | 16 |
| `props/` | relik, pickup, portal, checkpoint dan dekorasi | 15 |
| `tiles/` | tanah, platform, spike dan ruin tiles | 9 |
| `vfx/` | slash, orb elemen, Aether orb, dust dan shockwave | 9 |
| **Jumlah** |  | **72** |

`pubspec.yaml` membundle folder ini sebagai satu direktori. Folder grafik lama
di luar `generated/` tidak dibundle.

## Branding

- Runtime/menu: `assets/images/generated/branding/app_icon_512.png`
- Runtime/menu: `assets/images/generated/branding/skybound_logo.png`
- Store icon: `store_assets/skybound_quest_app_icon_1024.png`
- Store/logo export: `store_assets/skybound_quest_logo.png`

Ikon Android untuk `mdpi` hingga `xxxhdpi`, adaptive foreground dan round icon
sudah berada di `android/app/src/main/res/`.

## Penambahan aset baharu

1. Kekalkan latar belakang telus untuk sprite dan props.
2. Elakkan margin telus yang terlalu besar kerana ia menyukarkan collision
   visual dan scaling.
3. Gunakan nama fail huruf kecil dengan underscore.
4. Letakkan sprite di subfolder yang sesuai.
5. Rujuk fail relatif kepada `assets/images/` ketika menggunakan Flame:

```dart
await images.load('generated/props/portal.png');
```

6. Jalankan `python3 tool/validate_project.py` selepas menambah atau membuang
   fail dan kemas kini kiraan dalam validator serta dokumen ini.

## Prestasi

- Ikon store 1024px tidak dibundle dalam runtime.
- Background dirender sebagai empat segmen maksimum setiap lapisan.
- Paint stage dikitar semula dan tidak dicipta semula setiap frame.
- `FilterQuality.medium` digunakan untuk aset yang perlu diskalakan dengan
  lembut; sprite karakter menggunakan `FilterQuality.none` untuk kekal tajam.
