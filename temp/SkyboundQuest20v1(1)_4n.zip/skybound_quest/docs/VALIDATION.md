# Rekod validasi v0.4.0+4

## Semakan statik yang dijalankan

Arahan:

```bash
python3 tool/validate_project.py
```

Validator menyemak:

- nama package, versi dan direktori aset dalam `pubspec.yaml`;
- semua import relatif dan package dalaman;
- delimiter, string dan komen asas yang tidak ditutup;
- setiap rujukan PNG, OGG dan CSV yang boleh dikesan;
- signature serta dimensi PNG dan header OGG;
- 72 aset visual runtime dan 130 audio;
- ikon launcher Android, adaptive icon dan Android XML;
- 10 actor, 17 skill dan ID unik;
- pembetulan `num` kepada `double` serta import `ValueListenable`;
- ketinggian lompat, reach hero paling perlahan dan jurang level;
- merge-conflict marker dan fail sumber tidak konsisten.

Keputusan terakhir:

```text
PASS: semakan statik projek selesai
  versi              : 0.4.0+4
  fail Dart          : 25
  import disemak     : 111
  aset dirujuk       : 73
  imej projek/bundle : 352/72
  audio runtime      : 130
  actor/skill        : 10/17
  fail Android       : 41
  direktori aset     : 3
  jump/reach/gap     : 94.0/106.8/80.0
```

Semakan ini turut membuka semua PNG runtime, mengesahkan signature semua OGG,
memparse XML Android, menyemak ikon density dan menguji integriti konfigurasi
projek.

## Semakan regression boss

`test/combat_core_test.dart` dan `tool/verify_combat.dart` kini menyemak bahawa
Monitor Golem mempunyai:

- `golem_slam`;
- `screen_beam`;
- `aether_barrage`;
- `core_pulse`;
- windup beam sekurang-kurangnya `1.2s`;
- cooldown beam sekurang-kurangnya `6s`.

## Semakan Flutter penuh

Pada mesin yang mempunyai Flutter 3.41 atau lebih baharu, jalankan:

```bash
./tool/validate_flutter.sh
```

Skrip tersebut menjalankan `flutter pub get`, formatter, analyzer, unit test,
combat verifier dan build APK debug. Persekitaran penyediaan ZIP ini tidak
mempunyai executable Flutter/Dart, jadi dokumen ini tidak mendakwa build APK
telah dijalankan di sini. Semakan statik, aset, Android, XML dan arkib tetap
dijalankan sebelum release dibungkus.
