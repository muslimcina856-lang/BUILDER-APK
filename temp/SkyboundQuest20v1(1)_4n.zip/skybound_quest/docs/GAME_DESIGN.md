# Reka bentuk semasa — Aether Ruins v0.4

Dokumen ini menerangkan kandungan yang benar-benar terdapat dalam projek
`0.4.0+4`.

## Identiti

- Genre: action-platformer 2D dengan combat berasaskan timing.
- Platform utama: Android landscape.
- Format: satu vertical slice dengan pemilihan wira, traversal, objective,
  checkpoint, boss dan penamat.
- Arah seni: hutan sci-fi, runtuhan berlumut, tenaga Aether cyan dan relik emas.
- Sasaran sesi: satu misi pendek yang boleh diulang dengan empat wira.

## Aliran misi

1. Pemain memilih Nova, Aegis, Pyra atau Volt.
2. Zon awal mengajar pergerakan, lompatan dan serangan asas.
3. Relik pertama memperkenalkan laluan platform.
4. Hazard, musuh ranged dan flying menambah tekanan traversal.
5. Checkpoint tengah menetapkan titik respawn dan memberi ruang pemulihan.
6. Boost pad membuka laluan tinggi ke relik seterusnya.
7. Monitor Golem mengunci objektif akhir sehingga ditewaskan.
8. Portal aktif selepas tiga relik dan boss selesai.

## Dunia

- Saiz dunia: `3360 × 560` unit.
- Empat segmen tanah utama dengan jurang maksimum 80 unit.
- Sepuluh platform tinggi membentuk laluan alternatif.
- Empat kelompok spike mempunyai damage collision sebenar.
- Lima lapisan background bergerak pada kadar parallax berbeza.
- Checkpoint, dua health pickup, satu energy pickup dan satu boost pad.
- Kamera zoom `1.24`, mempunyai look-ahead, bounds dan screen shake.

## Wira

| Wira | Peranan | Skill utama | Skill kedua |
|---|---|---|---|
| Nova | Seimbang | Sunsteel Slash | Sky Dash |
| Aegis | Tank / kawalan | Shield Breaker | Guardian Quake |
| Pyra | Ranged / area | Ember Orb | Solar Burst |
| Volt | Pantas / burst | Spark Jab | Thunder Step |

Setiap wira menggunakan frame idle, run, jump dan attack yang berasingan.
Gerakan asas dikongsi supaya semua pilihan boleh menamatkan level, manakala
statistik dan skill memberi gaya permainan berbeza.

## Traversal

- Acceleration dan braking mengelakkan gerakan terasa seperti suis hidup/mati.
- Air control lebih lemah daripada kawalan di tanah.
- Coyote time: `0.13s`.
- Jump buffer: `0.16s`.
- Menahan butang lompat memberi apex lebih tinggi; melepaskannya memotong lompat.
- Landing snap mengurangkan jitter pada permukaan platform.
- Boost pad melancarkan hero ke laluan tinggi.
- Jatuh ke bawah dunia mengembalikan pemain ke checkpoint dengan penalti HP.

## Musuh

- Mimic Cube: melee dan hop pendek.
- Ember Wisp: terbang dan menembak dari jarak selamat.
- Drill Spike: mengejar serta melakukan dash charge.
- Guard Bot: ranged spacing.
- Scout Drone: hover dan swoop.
- Monitor Golem: slam dekat, locked beam, barrage tiga orb, Core Pulse dan Fasa 2 di bawah 50% HP.

AI memeriksa edge platform supaya musuh darat tidak berjalan kosong ke jurang
kecuali ditolak atau terbunuh.

## Keadaan tamat

- Victory: semua relik dikutip, boss mati dan hero memasuki portal.
- Defeat: HP hero mencecah sifar.
- Pause: engine dihentikan dan input dilepaskan.
- Restart: combatant, pickup, checkpoint, portal, projectile, VFX dan progress
  dikembalikan kepada keadaan awal.


## Prinsip boss fairness

- Arah Screen Beam dikunci ketika windup dan tidak dikemas kini semula selepas
  projectile dilepaskan.
- Beam hanya dipilih pada jarak sederhana atau jauh.
- Telegraph beam mempunyai garis tebal, core putih dan reticle hujung.
- Aether Barrage meninggalkan dua ruang di antara tiga orb.
- Core Pulse menunjukkan ring penuh sebelum damage window.
- Boss mempunyai recovery lebih panjang selepas serangan berat dan cuba
  menjaga jarak, bukan menekan pemain tanpa henti.
