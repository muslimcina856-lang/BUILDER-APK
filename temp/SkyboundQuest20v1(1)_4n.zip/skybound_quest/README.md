# Skybound Quest — Relics of the Aether

`v0.4.0` ialah vertical slice action-platformer 2D untuk Android yang dibina
menggunakan Flutter dan Flame. Fokus versi ini ialah rasa gerakan yang lebih
lancar, presentation yang lebih konsisten dan pertarungan boss yang jelas,
berfasa serta adil tanpa laser yang mengekori pemain selepas dilepaskan.

## Misi

1. Pilih Nova, Aegis, Pyra atau Volt.
2. Teroka Aether Ruins dan kumpul tiga Relik Langit.
3. Tewaskan Monitor Golem.
4. Masuk ke portal yang telah diaktifkan.

## Ciri utama

- Dunia `3360 × 560` dengan lima lapisan parallax, platform, jurang, spike,
  props, ambient lights dan arena boss bercahaya.
- Empat hero dengan statistik, resource, dua skill serta frame idle, run, jump
  dan attack berasingan.
- Enam jenis musuh dengan AI melee, ranged, flying, patrol, edge probe dan
  penjagaan jarak.
- Gerakan hero menggunakan acceleration, braking, air control, coyote time,
  jump buffer, variable jump dan landing snap.
- Projectile sebenar dengan collision, jarak, trail, hit VFX dan maksimum
  sasaran.
- HP, shield, defense, resistance, crit, life steal, i-frame, poise, stagger
  serta status berkala.
- HUD lengkap untuk vitals, resource, cooldown, objektif, relik, baki musuh,
  nama serangan boss dan fasa boss.
- Audio combat, traversal, pickup, checkpoint, kemenangan dan kekalahan.
- Pause, defeat, victory, restart penuh dan statistik masa tamat.
- Ikon launcher Android adaptif, ikon store 1024 px dan logo projek.

## Monitor Golem v0.4

Boss kini mempunyai empat serangan yang dibaca melalui telegraph:

- **Golem Slam** — hentaman jarak dekat dengan retakan lantai.
- **Screen Beam** — arah dikunci ketika charging; beam tidak mengekori pemain
  selepas ditembak.
- **Aether Barrage** — tiga orb berkipas dengan ruang di antara projectile.
- **Core Pulse** — kawasan bulat besar dengan windup panjang.

Pada 50% HP, boss memasuki Fasa 2 dengan aura jingga, sprite berasingan,
invulnerability pendek semasa transisi dan urutan serangan baharu. HUD
memaparkan fasa serta nama serangan aktif supaya pemain boleh bertindak balas.

## Kawalan

### Android

- Kiri/kanan: kawalan sentuh di kiri bawah.
- Lompat: `LOMPAT`.
- Serangan utama: `SERANG`.
- Skill khas: `SKILL`.
- Pause: butang kanan atas.

### Papan kekunci

| Tindakan | Kekunci |
|---|---|
| Bergerak | `A/D` atau anak panah kiri/kanan |
| Lompat | `W`, anak panah atas atau `Space` |
| Serangan utama | `J` atau `Z` |
| Skill khas | `K` atau `X` |
| Pause | `P` atau `Esc` |

## Build Android

```bash
./tool/bootstrap_android.sh
flutter run
```

Atau secara manual:

```bash
flutter pub get
dart format lib test tool/verify_combat.dart
flutter analyze
flutter test
dart run tool/verify_combat.dart
flutter build apk --debug
```

APK debug:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Semakan projek

Semakan tanpa Flutter SDK:

```bash
python3 tool/validate_project.py
```

Semakan penuh dengan Flutter 3.41 atau lebih baharu:

```bash
./tool/validate_flutter.sh
```

## Struktur penting

```text
lib/game/combat/       Model HP, damage, status, poise dan lifecycle skill
lib/game/components/   Level, actor, AI, projectile, pickup dan VFX
lib/game/data/         Katalog hero, musuh dan balancing skill
lib/game/input/        Input multi-touch dan papan kekunci
lib/game/level/        Kemajuan objektif serta portal
lib/ui/                Skrin tajuk, HUD, kawalan dan overlay
assets/images/generated/  72 aset visual runtime
assets/audio/          130 fail audio OGG
store_assets/          Ikon store dan logo resolusi tinggi
test/                  Ujian combat, progress dan input
tool/                  Bootstrap serta validator projek
```

## Skop

Versi `0.4.0` ialah satu misi lengkap yang boleh ditamatkan dan diulang dengan
empat hero. Ia belum menjadi kempen berbilang kawasan atau release Play Store
muktamad; save progression, localization penuh dan lebih banyak level masih di
luar skop vertical slice ini.
