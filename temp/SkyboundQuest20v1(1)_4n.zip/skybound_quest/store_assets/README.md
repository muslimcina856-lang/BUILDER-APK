# Store assets

- `skybound_quest_app_icon_1024.png`: ikon square 1024 × 1024 untuk listing/store.
- `skybound_quest_logo.png`: logo bertema Aether Ruins untuk bahan promosi.

Fail ini sengaja tidak dibundle oleh `pubspec.yaml`. Ikon runtime bersaiz 512px
berada di `assets/images/generated/branding/` dan ikon launcher Android sudah
dijana dalam `android/app/src/main/res/`.
