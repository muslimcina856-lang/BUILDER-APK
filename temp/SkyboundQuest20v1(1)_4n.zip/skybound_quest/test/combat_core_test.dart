import 'package:flutter_test/flutter_test.dart';
import 'package:skybound_quest/game/combat/combat_actor_state.dart';
import 'package:skybound_quest/game/combat/combat_models.dart';
import 'package:skybound_quest/game/combat/combat_resolver.dart';
import 'package:skybound_quest/game/combat/health_pool.dart';
import 'package:skybound_quest/game/combat/skill_controller.dart';
import 'package:skybound_quest/game/data/actor_catalog.dart';

void main() {
  group('HealthPool', () {
    test('shield penuh masih mengaktifkan i-frame dan melindungi hit susulan', () {
      final health = HealthPool(100)..addShield(40);

      final first = health.applyDamage(15, invulnerabilityAfterHit: 0.25);
      final second = health.applyDamage(15);

      expect(first.absorbedByShield, 15);
      expect(first.healthDamage, 0);
      expect(second.blockedByInvulnerability, isTrue);
      expect(health.shield, 25);
      expect(health.current, 100);
    });

    test('shield, i-frame, clamp dan death event menggunakan laluan sama', () {
      final health = HealthPool(100)..addShield(15);
      final first = health.applyDamage(25, invulnerabilityAfterHit: 0.2);
      expect(first.absorbedByShield, 15);
      expect(first.healthDamage, 10);
      expect(health.current, 90);
      expect(health.applyDamage(30).blockedByInvulnerability, isTrue);
      health.update(0.21);
      expect(health.applyDamage(200).killed, isTrue);
      expect(health.current, 0);
      expect(health.applyDamage(10).killed, isFalse);
    });
  });

  group('Katalog actor', () {
    test('setiap hero dan mob mempunyai skill serangan sah', () {
      expect(ActorCatalog.all, hasLength(10));
      for (final actor in ActorCatalog.all) {
        expect(actor.skills, isNotEmpty, reason: actor.id);
        expect(
          actor.skills.every(
            (skill) =>
                skill.hit.baseDamage + actor.stats.attackPower * skill.hit.attackScaling > 0,
          ),
          isTrue,
          reason: actor.id,
        );
      }
      expect(ActorCatalog.validate, returnsNormally);
    });

    test('Monitor Golem mempunyai serangan berfasa yang boleh dibaca', () {
      final skills = {
        for (final skill in ActorCatalog.monitorGolem.skills) skill.id: skill,
      };
      expect(
        skills.keys,
        containsAll(<String>[
          'golem_slam',
          'screen_beam',
          'aether_barrage',
          'core_pulse',
        ]),
      );
      expect(skills['screen_beam']!.windup, greaterThanOrEqualTo(1.2));
      expect(skills['screen_beam']!.cooldown, greaterThanOrEqualTo(6));
      expect(skills['core_pulse']!.windup, greaterThanOrEqualTo(1));
      expect(skills['aether_barrage']!.hit.baseDamage, lessThan(20));
    });
  });

  group('Resource', () {
    test('pickup tenaga memulihkan resource tanpa melebihi maksimum', () {
      final hero = CombatActorState(ActorCatalog.pyra);
      hero.resource = 12;

      expect(hero.restoreResource(45), 45);
      expect(hero.resource, 57);
      expect(hero.restoreResource(999), 43);
      expect(hero.resource, hero.blueprint.stats.maxResource);
    });
  });

  group('CombatResolver', () {
    test('hero dan mob melalui formula damage yang sama', () {
      const resolver = CombatResolver();
      final hero = CombatActorState(ActorCatalog.nova);
      final mob = CombatActorState(ActorCatalog.mimicCube);
      final heroHit = resolver.resolve(
        attacker: hero,
        target: mob,
        hit: ActorCatalog.nova.skills.first.hit,
      );
      mob.health.update(1);
      final mobHit = resolver.resolve(
        attacker: mob,
        target: hero,
        hit: ActorCatalog.mimicCube.skills.first.hit,
      );
      expect(heroHit.landed, isTrue);
      expect(mobHit.landed, isTrue);
      expect(hero.health.current, lessThan(hero.health.maximum));
      expect(mob.health.current, lessThan(mob.health.maximum));
    });

    test('friendly fire ditolak', () {
      const resolver = CombatResolver();
      final nova = CombatActorState(ActorCatalog.nova);
      final aegis = CombatActorState(ActorCatalog.aegis);
      final result = resolver.resolve(
        attacker: nova,
        target: aegis,
        hit: ActorCatalog.nova.skills.first.hit,
      );
      expect(result.rejection, DamageRejection.sameFaction);
      expect(aegis.health.current, aegis.health.maximum);
    });

    test('true damage mengabaikan defense dan resistance', () {
      const resolver = CombatResolver();
      final nova = CombatActorState(ActorCatalog.nova);
      final boss = CombatActorState(ActorCatalog.monitorGolem);
      final result = resolver.resolve(
        attacker: nova,
        target: boss,
        hit: const HitDefinition(
          baseDamage: 30,
          attackScaling: 0,
          damageType: DamageType.trueDamage,
        ),
      );
      expect(result.application.healthDamage, 30);
    });
  });

  group('Status berkala', () {
    test('tick terakhir berlaku tepat pada hujung duration', () {
      final target = CombatActorState(ActorCatalog.pyra);
      target.statuses.apply(
        ActorCatalog.burning,
        sourceActorId: ActorCatalog.emberWisp.id,
      );

      final frame = target.update(ActorCatalog.burning.duration);

      expect(frame.periodicDamage, hasLength(4));
      expect(
        frame.periodicDamage.map((event) => event.amount),
        everyElement(closeTo(2.1, 0.0001)),
      );
      expect(target.health.current, closeTo(86.6, 0.0001));
      expect(target.statuses.active, isEmpty);
    });
  });

  group('SkillController', () {
    test('windup membuka satu damage window dan cooldown menghalang spam', () {
      final skill = ActorCatalog.nova.skills.first;
      final controller = SkillController([skill]);
      expect(
        controller
            .tryActivate(skill.id, availableResource: 100, actionPrevented: false)
            .accepted,
        isTrue,
      );
      expect(
        controller
            .tryActivate(skill.id, availableResource: 100, actionPrevented: false)
            .accepted,
        isFalse,
      );
      expect(controller.cooldownRatio(skill.id), closeTo(1, 0.0001));
      final events = controller.update(skill.windup + 0.001);
      expect(
        events.where((event) => event.type == SkillEventType.attackWindowOpened),
        hasLength(1),
      );
      expect(controller.phase, SkillPhase.active);
      expect(controller.cooldownRatio(skill.id), lessThan(1));

      final finishEvents = controller.update(skill.activeTime + skill.recovery + 0.01);
      expect(
        finishEvents.where((event) => event.type == SkillEventType.castFinished),
        hasLength(1),
      );
      expect(controller.isCasting, isFalse);
    });
  });
}

