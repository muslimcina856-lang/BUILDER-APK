import 'combat_models.dart';

enum SkillPhase { windup, active, recovery }

enum SkillEventType { castStarted, attackWindowOpened, recoveryStarted, castFinished, interrupted }

class SkillEvent {
  const SkillEvent({required this.type, required this.skill});

  final SkillEventType type;
  final SkillDefinition skill;
}

class SkillActivationResult {
  const SkillActivationResult._(this.accepted, this.reason, this.skill);

  const SkillActivationResult.accepted(SkillDefinition skill)
      : this._(true, null, skill);

  const SkillActivationResult.rejected(String reason)
      : this._(false, reason, null);

  final bool accepted;
  final String? reason;
  final SkillDefinition? skill;
}

class _SkillCast {
  _SkillCast(this.skill)
      : phase = SkillPhase.windup,
        remaining = skill.windup;

  final SkillDefinition skill;
  SkillPhase phase;
  double remaining;
}

class SkillController {
  SkillController(List<SkillDefinition> skills)
      : _skills = {for (final skill in skills) skill.id: skill};

  final Map<String, SkillDefinition> _skills;
  final Map<String, double> _cooldowns = {};
  _SkillCast? _cast;
  final List<SkillEvent> _pendingEvents = [];

  bool get isCasting => _cast != null;
  SkillPhase? get phase => _cast?.phase;
  SkillDefinition? get activeSkill => _cast?.skill;
  double get phaseRemaining => _cast?.remaining ?? 0.0;

  double remainingCooldown(String skillId) => _cooldowns[skillId] ?? 0.0;

  double cooldownRatio(String skillId) {
    final skill = _skills[skillId];
    if (skill == null || skill.cooldown <= 0) return 0;
    return (remainingCooldown(skillId) / skill.cooldown).clamp(0, 1).toDouble();
  }

  double get phaseProgress {
    final cast = _cast;
    if (cast == null) return 0;
    final duration = switch (cast.phase) {
      SkillPhase.windup => cast.skill.windup,
      SkillPhase.active => cast.skill.activeTime,
      SkillPhase.recovery => cast.skill.recovery,
    };
    if (duration <= 0) return 1;
    return (1 - cast.remaining / duration).clamp(0, 1).toDouble();
  }

  SkillActivationResult tryActivate(
    String skillId, {
    required double availableResource,
    required bool actionPrevented,
  }) {
    final skill = _skills[skillId];
    if (skill == null) return const SkillActivationResult.rejected('unknown_skill');
    if (actionPrevented) return const SkillActivationResult.rejected('action_prevented');
    if (_cast != null) return const SkillActivationResult.rejected('already_casting');
    if (remainingCooldown(skillId) > 0) {
      return const SkillActivationResult.rejected('cooldown');
    }
    if (availableResource < skill.resourceCost) {
      return const SkillActivationResult.rejected('insufficient_resource');
    }

    _cast = _SkillCast(skill);
    _cooldowns[skill.id] = skill.cooldown;
    _pendingEvents.add(SkillEvent(type: SkillEventType.castStarted, skill: skill));
    return SkillActivationResult.accepted(skill);
  }

  List<SkillEvent> update(double dt) {
    if (dt < 0) throw ArgumentError.value(dt, 'dt');
    for (final entry in Map<String, double>.of(_cooldowns).entries) {
      final value = (entry.value - dt).clamp(0, double.infinity).toDouble();
      if (value == 0) {
        _cooldowns.remove(entry.key);
      } else {
        _cooldowns[entry.key] = value;
      }
    }

    final events = <SkillEvent>[..._pendingEvents];
    _pendingEvents.clear();
    var remainingFrameTime = dt;
    var safety = 0;
    while (_cast != null && safety++ < 4) {
      final cast = _cast!;
      if (cast.remaining > remainingFrameTime) {
        cast.remaining -= remainingFrameTime;
        break;
      }
      remainingFrameTime -= cast.remaining;
      if (cast.phase == SkillPhase.windup) {
        cast.phase = SkillPhase.active;
        cast.remaining = cast.skill.activeTime;
        events.add(
          SkillEvent(type: SkillEventType.attackWindowOpened, skill: cast.skill),
        );
      } else if (cast.phase == SkillPhase.active) {
        cast.phase = SkillPhase.recovery;
        cast.remaining = cast.skill.recovery;
        events.add(
          SkillEvent(type: SkillEventType.recoveryStarted, skill: cast.skill),
        );
      } else {
        events.add(
          SkillEvent(type: SkillEventType.castFinished, skill: cast.skill),
        );
        _cast = null;
      }
      if (remainingFrameTime <= 0 && _cast?.remaining != 0) break;
    }
    return events;
  }

  SkillEvent? interrupt() {
    final cast = _cast;
    if (cast == null) return null;
    _cast = null;
    return SkillEvent(type: SkillEventType.interrupted, skill: cast.skill);
  }

  void reset() {
    _cast = null;
    _cooldowns.clear();
    _pendingEvents.clear();
  }
}
