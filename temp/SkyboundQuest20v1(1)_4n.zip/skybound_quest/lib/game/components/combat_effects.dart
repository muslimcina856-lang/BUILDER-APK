import 'dart:math' as math;
import 'dart:ui' hide TextStyle;

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show TextPainter, TextSpan, TextStyle;

abstract class TransientComponent extends PositionComponent {
  TransientComponent({
    required Vector2 position,
    Vector2? size,
    Anchor anchor = Anchor.center,
  }) : super(position: position, size: size ?? Vector2.zero(), anchor: anchor) {
    priority = 10000;
  }
}

class AttackArcEffect extends TransientComponent {
  AttackArcEffect({
    required Vector2 position,
    required this.facing,
    required this.color,
    this.radius = 42,
  }) : super(position: position, size: Vector2.all(radius * 2));

  final double facing;
  final Color color;
  final double radius;
  double _elapsed = 0;
  static const _duration = 0.2;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final alpha = ((1 - t) * 230).round().clamp(0, 255).toInt();
    final stroke = 8.0 * (1 - t * 0.45);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = stroke
      ..color = color.withAlpha(alpha);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = stroke + 8.0
      ..color = color.withAlpha((alpha * 0.22).round());
    final rect = Rect.fromCircle(
      center: Offset(size.x / 2, size.y / 2),
      radius: radius * (0.72 + t * 0.28),
    );
    final start = facing >= 0 ? -1.05 : math.pi - 1.05;
    final sweep = facing >= 0 ? 1.9 : -1.9;
    canvas.drawArc(rect, start, sweep, false, glow);
    canvas.drawArc(rect, start, sweep, false, paint);
  }
}

class ShockwaveEffect extends TransientComponent {
  ShockwaveEffect({
    required Vector2 position,
    required this.color,
    required this.maximumRadius,
  }) : super(position: position, size: Vector2.all(maximumRadius * 2));

  final Color color;
  final double maximumRadius;
  double _elapsed = 0;
  static const _duration = 0.38;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final eased = 1 - math.pow(1 - t, 3).toDouble();
    final alpha = ((1 - t) * 210).round().clamp(0, 255).toInt();
    final center = Offset(size.x / 2, size.y / 2);
    final radius = maximumRadius * eased;
    final fill = Paint()..color = color.withAlpha((alpha * 0.14).round());
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7.0 * (1 - t) + 2.0
      ..color = color.withAlpha(alpha);
    canvas.drawCircle(center, radius, fill);
    canvas.drawCircle(center, radius, ring);
  }
}

class ImpactEffect extends TransientComponent {
  ImpactEffect({
    required Vector2 position,
    required this.color,
    this.heavy = false,
    int seed = 1,
  })  : _random = math.Random(seed),
        super(position: position, size: Vector2.all(80)) {
    final count = heavy ? 16 : 9;
    for (var i = 0; i < count; i++) {
      final angle = _random.nextDouble() * math.pi * 2;
      final speed =
          (heavy ? 95.0 : 65.0) +
          _random.nextDouble() * (heavy ? 150.0 : 90.0);
      _particles.add(
        _EffectParticle(
          position: Vector2.zero(),
          velocity: Vector2(math.cos(angle), math.sin(angle)) * speed,
          size: 2.5 + _random.nextDouble() * (heavy ? 5.0 : 3.0),
        ),
      );
    }
  }

  final Color color;
  final bool heavy;
  final math.Random _random;
  final List<_EffectParticle> _particles = [];
  double _elapsed = 0;
  double get _duration => heavy ? 0.48 : 0.3;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    for (final particle in _particles) {
      particle.position.add(particle.velocity * dt);
      particle.velocity.scale(math.pow(0.06, dt).toDouble());
      particle.velocity.y += 170.0 * dt;
    }
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final alpha = ((1 - t) * 255).round().clamp(0, 255).toInt();
    final center = Offset(size.x / 2, size.y / 2);
    final flash = Paint()..color = const Color(0xFFFFFFFF).withAlpha((alpha * 0.55).round());
    canvas.drawCircle(center, (heavy ? 17.0 : 10.0) * (1 - t), flash);
    final paint = Paint()..color = color.withAlpha(alpha);
    for (final particle in _particles) {
      final p = center + Offset(particle.position.x, particle.position.y);
      final side = particle.size * (1 - t * 0.65);
      canvas.drawRect(Rect.fromCenter(center: p, width: side, height: side), paint);
    }
  }
}

class FloatingTextEffect extends TransientComponent {
  FloatingTextEffect({
    required Vector2 position,
    required this.text,
    required this.color,
    this.emphasized = false,
  }) : super(position: position, size: Vector2(120, 36));

  final String text;
  final Color color;
  final bool emphasized;
  double _elapsed = 0;
  static const _duration = 0.78;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    position.y -= (emphasized ? 48.0 : 34.0) * dt;
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final alpha = ((1 - t) * 255).round().clamp(0, 255).toInt();
    final painter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color.withAlpha(alpha),
          fontSize: emphasized ? 20.0 : 15.0,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(
              color: const Color(0xFF000000).withAlpha(alpha),
              blurRadius: 3,
              offset: const Offset(1.5, 1.5),
            ),
          ],
        ),
      ),
    )..layout(maxWidth: size.x);
    painter.paint(canvas, Offset((size.x - painter.width) / 2, 0));
  }
}

class TrailPuffEffect extends TransientComponent {
  TrailPuffEffect({required Vector2 position, required this.color, this.radius = 10})
      : super(position: position, size: Vector2.all(radius * 2));

  final Color color;
  final double radius;
  double _elapsed = 0;
  static const _duration = 0.24;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final alpha = ((1 - t) * 130).round().clamp(0, 255).toInt();
    final paint = Paint()..color = color.withAlpha(alpha);
    canvas.drawCircle(
      Offset(size.x / 2, size.y / 2),
      radius * (0.55 + t * 0.55),
      paint,
    );
  }
}

class GroundRiftEffect extends TransientComponent {
  GroundRiftEffect({
    required Vector2 position,
    required this.color,
    required this.width,
  }) : super(position: position, size: Vector2(width, 48));

  final Color color;
  final double width;
  double _elapsed = 0;
  static const double _duration = 0.46;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    if (_elapsed >= _duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / _duration).clamp(0, 1).toDouble();
    final eased = 1 - math.pow(1 - t, 3).toDouble();
    final alpha = ((1 - t) * 220).round().clamp(0, 255).toInt();
    final center = Offset(size.x / 2, size.y / 2);
    final half = width * 0.5 * eased;
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10 * (1 - t) + 2
      ..strokeCap = StrokeCap.round
      ..color = color.withAlpha((alpha * 0.2).round());
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5 * (1 - t * 0.35)
      ..strokeCap = StrokeCap.round
      ..color = color.withAlpha(alpha);
    final path = Path()..moveTo(center.dx - half, center.dy);
    const segments = 10;
    for (var i = 1; i <= segments; i++) {
      final x = center.dx - half + (half * 2) * i / segments;
      final jagged = i == segments
          ? 0.0
          : math.sin(i * 2.2 + _elapsed * 8) * (7 * (1 - t));
      path.lineTo(x, center.dy + jagged);
    }
    canvas.drawPath(path, glow);
    canvas.drawPath(path, line);
  }
}

class BossPhaseBurstEffect extends TransientComponent {
  BossPhaseBurstEffect({
    required Vector2 position,
    required this.primaryColor,
    required this.secondaryColor,
    this.duration = 0.9,
    this.maximumRadius = 150,
    int seed = 731,
  })  : _random = math.Random(seed),
        super(position: position, size: Vector2.all(maximumRadius * 2)) {
    for (var i = 0; i < 24; i++) {
      final angle = _random.nextDouble() * math.pi * 2;
      final speed = 80 + _random.nextDouble() * 180;
      _particles.add(
        _EffectParticle(
          position: Vector2.zero(),
          velocity: Vector2(math.cos(angle), math.sin(angle)) * speed,
          size: 2.5 + _random.nextDouble() * 5.5,
        ),
      );
    }
  }

  final Color primaryColor;
  final Color secondaryColor;
  final double duration;
  final double maximumRadius;
  final math.Random _random;
  final List<_EffectParticle> _particles = [];
  double _elapsed = 0;

  @override
  void update(double dt) {
    super.update(dt);
    _elapsed += dt;
    for (final particle in _particles) {
      particle.position.add(particle.velocity * dt);
      particle.velocity.scale(math.pow(0.12, dt).toDouble());
    }
    if (_elapsed >= duration) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final t = (_elapsed / duration).clamp(0, 1).toDouble();
    final eased = 1 - math.pow(1 - t, 3).toDouble();
    final alpha = ((1 - t) * 235).round().clamp(0, 255).toInt();
    final center = Offset(size.x / 2, size.y / 2);
    final radius = maximumRadius * eased;

    canvas.drawCircle(
      center,
      radius * 0.55,
      Paint()
        ..shader = Gradient.radial(
          center,
          radius * 0.55,
          [primaryColor.withAlpha((alpha * 0.22).round()), primaryColor.withAlpha(0)],
        ),
    );
    for (var i = 0; i < 3; i++) {
      final ringRadius = radius * (0.5 + i * 0.22);
      canvas.drawCircle(
        center,
        ringRadius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 7 - i * 1.6
          ..color = (i.isEven ? primaryColor : secondaryColor)
              .withAlpha((alpha * (0.9 - i * 0.18)).round()),
      );
    }

    for (var i = 0; i < _particles.length; i++) {
      final particle = _particles[i];
      final point = center + Offset(particle.position.x, particle.position.y);
      final side = particle.size * (1 - t * 0.55);
      canvas.drawRect(
        Rect.fromCenter(center: point, width: side, height: side),
        Paint()
          ..color = (i.isEven ? primaryColor : secondaryColor).withAlpha(alpha),
      );
    }
  }
}

class _EffectParticle {
  _EffectParticle({
    required this.position,
    required this.velocity,
    required this.size,
  });

  final Vector2 position;
  final Vector2 velocity;
  final double size;
}
