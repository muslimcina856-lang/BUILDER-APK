import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../combat/combat_actor_state.dart';
import '../combat/combat_models.dart';
import '../combat/combat_resolver.dart';
import '../combat/health_pool.dart';
import '../combat/skill_controller.dart';
import '../skybound_game.dart';
import 'combat_effects.dart';
import 'projectile_component.dart';

abstract class CombatActorComponent extends PositionComponent {
  CombatActorComponent({
    required this.gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
    Vector2? size,
  })  : state = CombatActorState(blueprint),
        spawnPosition = position.clone(),
        super(
          position: position,
          size: size ?? Vector2.all(52),
          anchor: Anchor.center,
        );

  final SkyboundGame gameRef;
  final CombatActorState state;
  final Vector2 spawnPosition;
  double facing = 1;
  double horizontalImpulse = 0;

  final List<Sprite> _frames = [];
  SpriteComponent? _visual;
  late HealthSnapshot _lastHealth;
  late final HealthListener _healthListener;
  bool _listenerAttached = false;
  bool _deathReported = false;
  double _frameClock = 0;
  int _frameIndex = 0;
  double _hitFlashRemaining = 0;
  double _deathTime = 0;
  final Map<String, Vector2> _lockedAimDirections = {};

  ActorBlueprint get blueprint => state.blueprint;
  bool get isBoss => blueprint.id == 'monitor_golem';
  bool get isGrounded => false;
  double get motionSpeed => 0;
  double get verticalSpeed => 0;

  Color get accentColor => switch (blueprint.id) {
        'nova' => const Color(0xFF62E88F),
        'aegis' => const Color(0xFF77B8FF),
        'pyra' => const Color(0xFFFF759D),
        'volt' => const Color(0xFFFFCA3A),
        'ember_wisp' => const Color(0xFFFF7043),
        'guard_bot' => const Color(0xFF70D6FF),
        'scout_drone' => const Color(0xFFFFD166),
        'monitor_golem' => const Color(0xFF47D7FF),
        _ => const Color(0xFFFF8A65),
      };

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    for (final path in blueprint.spriteFrames) {
      _frames.add(Sprite(await gameRef.images.load(path)));
    }
    _visual = SpriteComponent(
      sprite: _frames.first,
      position: size / 2,
      size: size,
      anchor: Anchor.center,
      paint: Paint()..filterQuality = FilterQuality.none,
    );
    add(_visual!);

    _lastHealth = state.health.snapshot;
    _healthListener = _handleHealthChanged;
    state.health.addListener(_healthListener);
    _listenerAttached = true;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final frame = state.update(dt);
    for (final periodic in frame.periodicDamage) {
      gameRef.onPeriodicDamage(this, periodic);
    }
    for (final event in frame.skillEvents) {
      _handleSkillEvent(event);
    }
    _hitFlashRemaining = math.max(0, _hitFlashRemaining - dt).toDouble();
    if (state.isDead) _deathTime += dt;
    _updateVisual(dt);
    priority = position.y.round();
  }

  SkillActivationResult tryUseSkill(String skillId) => state.tryUseSkill(skillId);

  void receiveKnockback(double impulse) {
    horizontalImpulse += impulse;
  }

  void resetAt(Vector2 target) {
    _deathReported = false;
    _deathTime = 0;
    _hitFlashRemaining = 0;
    horizontalImpulse = 0;
    _lockedAimDirections.clear();
    position.setFrom(target);
    facing = 1;
    state.reset();
    final visual = _visual;
    if (visual != null) {
      visual.opacity = 1;
      visual.angle = 0;
      visual.paint.colorFilter = null;
      visual.scale.setValues(1, 1);
    }
    _lastHealth = state.health.snapshot;
  }

  Iterable<CombatActorComponent> get hostileTargets => gameRef.combatants.where(
        (other) =>
            !identical(other, this) &&
            !other.state.isDead &&
            other.blueprint.faction != blueprint.faction,
      );

  DamageResolution resolveSkillHit(
    CombatActorComponent target,
    SkillDefinition skill, {
    Vector2? impactPosition,
  }) {
    final deltaX = target.position.x - position.x;
    final result = gameRef.combatResolver.resolve(
      attacker: state,
      target: target.state,
      hit: skill.hit,
      criticalRoll: gameRef.random.nextDouble(),
    );
    if (result.landed) {
      final direction = deltaX.abs() < 0.01 ? facing : deltaX.sign;
      target.receiveKnockback(direction * result.knockback);
      gameRef.onCombatHit(
        attacker: this,
        target: target,
        skill: skill,
        result: result,
        position: impactPosition ?? target.position,
      );
    }
    return result;
  }

  void _handleSkillEvent(SkillEvent event) {
    switch (event.type) {
      case SkillEventType.castStarted:
        _captureAimForSkill(event.skill);
        gameRef.onSkillCast(this, event.skill);
        break;
      case SkillEventType.attackWindowOpened:
        _executeAttack(event.skill);
        break;
      case SkillEventType.recoveryStarted:
      case SkillEventType.castFinished:
      case SkillEventType.interrupted:
        break;
    }
  }


  void _captureAimForSkill(SkillDefinition skill) {
    if (skill.pattern != AttackPattern.projectile) return;
    _lockedAimDirections[skill.id] = _projectileDirectionFor(skill, lockOnWindup: true);
  }

  Vector2 _projectileDirectionFor(
    SkillDefinition skill, {
    bool lockOnWindup = false,
  }) {
    Vector2 direction;
    if (blueprint.faction == ActorFaction.hero) {
      direction = Vector2(facing, -0.025);
    } else {
      final targets = hostileTargets.toList()
        ..sort(
          (a, b) => position
              .distanceTo(a.position)
              .compareTo(position.distanceTo(b.position)),
        );
      if (targets.isEmpty) {
        direction = Vector2(facing, 0);
      } else {
        direction = lockOnWindup
            ? targets.first.position - position
            : (_lockedAimDirections[skill.id]?.clone() ??
                (targets.first.position - position));
      }
      if (direction.length2 == 0) direction = Vector2(facing, 0);
      if (skill.id == 'screen_beam') {
        if (direction.x.abs() < 0.28) {
          direction.x = facing == 0 ? 1 : facing;
        }
        direction.y = direction.y.clamp(-60.0, 60.0).toDouble();
      }
    }
    if (direction.length2 == 0) {
      direction = Vector2(facing == 0 ? 1 : facing, 0);
    }
    direction.normalize();
    return direction;
  }

  void _executeAttack(SkillDefinition skill) {
    if (state.isDead || gameRef.phase.value != GamePhase.playing) return;

    if (skill.pattern == AttackPattern.dash && skill.dashDistance > 0) {
      if (skill.selfInvulnerability > 0) {
        state.health.grantInvulnerability(
          skill.selfInvulnerability + skill.activeTime,
        );
      }
      final activeDuration = math.max(0.12, skill.activeTime).toDouble();
      horizontalImpulse += facing * skill.dashDistance / activeDuration;
      for (var i = 0; i < 4; i++) {
        gameRef.addTransient(
          TrailPuffEffect(
            position: position + Vector2(-facing * (10 + i * 11), 12),
            color: accentColor,
            radius: 8.0 + i.toDouble() * 1.5,
          ),
        );
      }
    }

    if (skill.pattern == AttackPattern.projectile) {
      if (skill.id == 'aether_barrage') {
        _spawnAetherBarrage(skill);
      } else {
        _spawnProjectile(skill);
      }
      return;
    }

    if (skill.pattern == AttackPattern.area) {
      final color = damageColor(skill.hit.damageType);
      gameRef.addTransient(
        ShockwaveEffect(
          position: position.clone(),
          color: color,
          maximumRadius: skill.range,
        ),
      );
      if (skill.id == 'golem_slam') {
        gameRef.addTransient(
          GroundRiftEffect(
            position: position + Vector2(0, size.y * 0.42),
            color: color,
            width: 215,
          ),
        );
      } else if (skill.id == 'core_pulse') {
        gameRef.addTransient(
          BossPhaseBurstEffect(
            position: position.clone(),
            primaryColor: const Color(0xFFFFB347),
            secondaryColor: const Color(0xFF61E8FF),
            duration: 0.62,
            maximumRadius: skill.range + 24,
          ),
        );
      }
    } else {
      gameRef.addTransient(
        AttackArcEffect(
          position: position + Vector2(facing * 20, -2),
          facing: facing,
          color: damageColor(skill.hit.damageType),
          radius: math.min(54, skill.range * 0.72).toDouble(),
        ),
      );
    }

    final targets = hostileTargets.toList()
      ..sort(
        (a, b) => position
            .distanceTo(a.position)
            .compareTo(position.distanceTo(b.position)),
      );
    var landed = 0;
    for (final target in targets) {
      final deltaX = target.position.x - position.x;
      final distance = position.distanceTo(target.position);
      final requiresFacing = skill.pattern != AttackPattern.area;
      if (distance > skill.range || (requiresFacing && deltaX * facing < -12)) {
        continue;
      }
      final result = resolveSkillHit(target, skill);
      if (result.landed) landed++;
      if (landed >= skill.maximumTargets) break;
    }
  }

  void _spawnAetherBarrage(SkillDefinition skill) {
    final baseDirection = _projectileDirectionFor(skill);
    _lockedAimDirections.remove(skill.id);
    for (final angle in const [-0.18, 0.0, 0.18]) {
      final direction = baseDirection.clone()..rotate(angle);
      _spawnProjectile(
        skill,
        directionOverride: direction,
        speedOverride: 335,
        colorOverride: angle == 0
            ? const Color(0xFFFFFFFF)
            : const Color(0xFF63E8FF),
      );
    }
  }

  void _spawnProjectile(
    SkillDefinition skill, {
    Vector2? directionOverride,
    double? speedOverride,
    Color? colorOverride,
  }) {
    final direction = directionOverride?.clone() ?? _projectileDirectionFor(skill);
    if (direction.length2 == 0) direction.setValues(facing == 0 ? 1 : facing, 0);
    direction.normalize();
    if (directionOverride == null) _lockedAimDirections.remove(skill.id);

    final speed = speedOverride ??
        switch (skill.id) {
          'cinder_spit' => 285.0,
          'guard_bolt' => 360.0,
          'screen_beam' => 470.0,
          'aether_barrage' => 335.0,
          _ => 430.0,
        };
    gameRef.addTransient(
      ProjectileComponent(
        owner: this,
        skill: skill,
        position: position + direction * (size.x * 0.48),
        velocity: direction * speed,
        color: colorOverride ?? damageColor(skill.hit.damageType),
      ),
    );
  }

  void _handleHealthChanged(HealthSnapshot snapshot) {
    final healthDamage = _lastHealth.current - snapshot.current;
    final shieldDamage = _lastHealth.shield - snapshot.shield;
    if (healthDamage > 0 || shieldDamage > 0) {
      _hitFlashRemaining = 0.13;
    }
    if (snapshot.isDead && !_deathReported) {
      _deathReported = true;
      gameRef.onActorDefeated(this);
    }
    _lastHealth = snapshot;
    if (identical(this, gameRef.heroOrNull)) gameRef.publishHeroVitals();
  }

  void _updateVisual(double dt) {
    final visual = _visual;
    if (visual == null || _frames.isEmpty) return;

    final casting = state.skills.isCasting;
    final moving = motionSpeed > 14;
    final interval = moving ? 0.14 : 0.5;
    _frameClock += dt;

    if (isBoss && _frames.length >= 6) {
      final skillId = state.skills.activeSkill?.id;
      if (state.isDead) {
        _frameIndex = 5;
      } else if (_hitFlashRemaining > 0) {
        _frameIndex = 4;
      } else if (casting && state.skills.phase != SkillPhase.recovery) {
        _frameIndex = skillId == 'screen_beam' || skillId == 'aether_barrage'
            ? 3
            : 1;
      } else if (state.health.ratio < 0.5) {
        _frameIndex = 2;
      } else {
        _frameIndex = 0;
      }
    } else if (blueprint.faction == ActorFaction.hero && _frames.length >= 4) {
      if (casting && state.skills.phase != SkillPhase.recovery) {
        _frameIndex = 3;
      } else if (!isGrounded) {
        _frameIndex = 2;
      } else if (moving) {
        _frameIndex = 1;
      } else {
        _frameIndex = 0;
      }
    } else if (_frames.length > 1) {
      if (casting && state.skills.phase != SkillPhase.recovery) {
        _frameIndex = _frames.length - 1;
      } else if (moving && _frameClock >= interval) {
        _frameClock %= interval;
        _frameIndex = _frameIndex == 0 ? 1 : 0;
      } else if (!moving) {
        _frameIndex = 0;
      }
    }
    visual.sprite = _frames[_frameIndex.clamp(0, _frames.length - 1).toInt()];

    var scaleX = facing < 0 ? -1.0 : 1.0;
    var scaleY = 1.0;
    var bob = 0.0;
    if (isGrounded && moving) {
      bob = math.sin(_frameClock / interval * math.pi * 2) * 1.35;
    } else if (!isGrounded && blueprint.faction == ActorFaction.enemy) {
      bob = math.sin(_frameClock * 3.2) * 1.2;
    }

    final phase = state.skills.phase;
    if (phase == SkillPhase.windup) {
      final progress = state.skills.phaseProgress;
      scaleX *= 0.96 - progress * 0.05;
      scaleY = 1.04 + progress * 0.07;
    } else if (phase == SkillPhase.active) {
      scaleX *= 1.1;
      scaleY = 0.91;
    } else if (!isGrounded && verticalSpeed < 0) {
      scaleX *= 0.95;
      scaleY = 1.06;
    } else if (!isGrounded && verticalSpeed > 0) {
      scaleX *= 1.04;
      scaleY = 0.96;
    }

    if (state.isDead) {
      final deathT = (_deathTime / 0.55).clamp(0, 1).toDouble();
      visual.angle = facing * deathT * 1.35;
      visual.opacity = (1 - deathT * 0.62).clamp(0, 1).toDouble();
      scaleY *= 1 - deathT * 0.28;
      bob = deathT * 9;
    } else {
      visual.angle = 0;
      visual.opacity = 1;
    }

    visual.position.setValues(size.x / 2, size.y / 2 + bob);
    visual.scale.setValues(scaleX, scaleY);
    visual.paint.colorFilter = _hitFlashRemaining > 0
        ? const ColorFilter.mode(Color(0xFFFFFFFF), BlendMode.srcATop)
        : null;
  }

  @override
  void render(Canvas canvas) {
    _drawBossAura(canvas);
    _drawShadow(canvas);
    _drawTelegraph(canvas);
    super.render(canvas);
    _drawStatusPips(canvas);
    _drawHealthBar(canvas);
    if (state.health.isInvulnerable && !state.isDead) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(2, 2, size.x - 4, size.y - 4),
          const Radius.circular(10),
        ),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = const Color(0xFFFFE082).withAlpha(180),
      );
    }
  }

  void _drawBossAura(Canvas canvas) {
    if (!isBoss || state.isDead) return;
    final phaseTwo = state.health.ratio < 0.5;
    final pulse = (math.sin(_frameClock * (phaseTwo ? 5.0 : 3.0)) + 1) / 2;
    final center = Offset(size.x / 2, size.y / 2 + 3);
    final color = phaseTwo ? const Color(0xFFFF9F43) : const Color(0xFF55DFFF);
    final radius = size.x * (0.48 + pulse * 0.08);
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = Gradient.radial(
          center,
          radius,
          [color.withAlpha(42 + (pulse * 38).round()), color.withAlpha(0)],
        ),
    );
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius * 0.82),
      _frameClock * 1.4,
      phaseTwo ? 4.7 : 3.3,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = phaseTwo ? 3.5 : 2.2
        ..strokeCap = StrokeCap.round
        ..color = color.withAlpha(90 + (pulse * 80).round()),
    );
  }

  void _drawShadow(Canvas canvas) {
    final height = isGrounded ? 9.0 : 6.0;
    final width = state.isDead ? size.x * 0.82 : size.x * 0.64;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.x / 2, size.y * 0.88),
        width: width,
        height: height,
      ),
      Paint()..color = const Color(0x62000000),
    );
  }

  void _drawTelegraph(Canvas canvas) {
    final skill = state.skills.activeSkill;
    if (skill == null || state.skills.phase != SkillPhase.windup || state.isDead) {
      return;
    }
    final progress = state.skills.phaseProgress;
    final danger = blueprint.faction == ActorFaction.enemy
        ? const Color(0xFFFF5A67)
        : accentColor;
    final alpha = (70 + progress * 145).round().clamp(0, 255).toInt();
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 + progress * 2
      ..color = danger.withAlpha(alpha);

    if (skill.pattern == AttackPattern.area) {
      final center = Offset(size.x / 2, size.y / 2);
      final radiusLimit = skill.id == 'core_pulse' ? 145.0 : 120.0;
      final radius = math.min(skill.range, radiusLimit).toDouble();
      canvas.drawCircle(center, radius * (0.72 + progress * 0.28), paint);
      if (skill.id == 'core_pulse') {
        final innerPaint = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5 + progress * 2
          ..color = const Color(0xFFFFC45A).withAlpha(alpha);
        canvas.drawCircle(center, radius * (0.28 + progress * 0.2), innerPaint);
        canvas.drawCircle(center, radius * (0.5 + progress * 0.2), innerPaint);
      }
    } else if (skill.pattern == AttackPattern.projectile) {
      final start = Offset(size.x / 2, size.y / 2);
      final baseDirection = _lockedAimDirections[skill.id]?.clone() ??
          _projectileDirectionFor(skill, lockOnWindup: true);
      final telegraphLength = math
          .min(skill.range, skill.id == 'screen_beam' ? 220 : 165)
          .toDouble();
      final directions = skill.id == 'aether_barrage'
          ? <Vector2>[
              baseDirection.clone()..rotate(-0.18),
              baseDirection,
              baseDirection.clone()..rotate(0.18),
            ]
          : <Vector2>[baseDirection];
      for (final direction in directions) {
        final end = start.translate(
          direction.x * telegraphLength,
          direction.y * telegraphLength,
        );
        if (skill.id == 'screen_beam') {
          canvas.drawLine(
            start,
            end,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeCap = StrokeCap.round
              ..strokeWidth = 10 + progress * 6
              ..color = danger.withAlpha((alpha * 0.2).round()),
          );
          canvas.drawLine(
            start,
            end,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeCap = StrokeCap.round
              ..strokeWidth = 2.0 + progress * 2.0
              ..color = const Color(0xFFFFFFFF).withAlpha(alpha),
          );
          canvas.drawCircle(end, 8 + progress * 5, paint);
          canvas.drawLine(end.translate(-12, 0), end.translate(12, 0), paint);
          canvas.drawLine(end.translate(0, -12), end.translate(0, 12), paint);
        } else {
          canvas.drawLine(start, end, paint);
          canvas.drawCircle(end, 4 + progress * 4, paint);
        }
      }
    } else {
      final rect = Rect.fromCircle(
        center: Offset(size.x / 2 + facing * 14, size.y / 2),
        radius: math.min(skill.range, 72).toDouble(),
      );
      canvas.drawArc(
        rect,
        facing > 0 ? -0.9 : math.pi - 0.9,
        facing > 0 ? 1.8 : -1.8,
        false,
        paint,
      );
    }
  }

  void _drawStatusPips(Canvas canvas) {
    if (state.statuses.active.isEmpty || state.isDead) return;
    var x = size.x / 2 - (state.statuses.active.length - 1) * 4.5;
    for (final status in state.statuses.active) {
      final color = switch (status.type) {
        StatusType.burning => const Color(0xFFFF6A3D),
        StatusType.poisoned => const Color(0xFF8DE35C),
        StatusType.chilled => const Color(0xFF63D4FF),
        StatusType.stunned => const Color(0xFFFFE66D),
        StatusType.armorBroken => const Color(0xFFB8A0FF),
      };
      canvas.drawCircle(Offset(x, -15), 4, Paint()..color = color);
      x += 9;
    }
  }

  void _drawHealthBar(Canvas canvas) {
    if (blueprint.faction == ActorFaction.hero || state.isDead) return;
    final width = math.max(size.x, isBoss ? 76 : 44).toDouble();
    final left = (size.x - width) / 2;
    final background = Paint()..color = const Color(0xDD151B2E);
    final healthPaint = Paint()
      ..color = isBoss ? const Color(0xFF4AD5FF) : const Color(0xFFFF5B66);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(left, -10, width, 6),
        const Radius.circular(2),
      ),
      background,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(left, -10, width * state.health.ratio, 6),
        const Radius.circular(2),
      ),
      healthPaint,
    );
    final poiseRatio =
        (state.poise / blueprint.stats.maxPoise).clamp(0, 1).toDouble();
    canvas.drawRect(
      Rect.fromLTWH(left, -2, width * poiseRatio, 2),
      Paint()..color = const Color(0xFFFFD166),
    );
  }

  Color damageColor(DamageType type) => switch (type) {
        DamageType.fire => const Color(0xFFFF7043),
        DamageType.frost => const Color(0xFF66D9FF),
        DamageType.poison => const Color(0xFF89E15B),
        DamageType.lightning => const Color(0xFFFFD84D),
        DamageType.trueDamage => const Color(0xFFFFFFFF),
        DamageType.physical => accentColor,
      };

  @override
  void onRemove() {
    if (_listenerAttached) {
      state.health.removeListener(_healthListener);
      _listenerAttached = false;
    }
    super.onRemove();
  }
}
