import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import '../skybound_game.dart';
import 'arena_stage.dart';
import 'combat_actor_component.dart';

class HeroComponent extends CombatActorComponent {
  HeroComponent({
    required SkyboundGame gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
  }) : super(
          gameRef: gameRef,
          blueprint: blueprint,
          position: position,
          size: Vector2(48, 50),
        );

  static const gravity = 1030.0;
  static const jumpVelocity = -440.0;
  static const coyoteDuration = 0.13;
  static const jumpBufferDuration = 0.16;
  static const maximumFallSpeed = 690.0;

  final Vector2 velocity = Vector2.zero();
  double _runVelocityX = 0;
  double _coyoteRemaining = 0;
  double _jumpBufferRemaining = 0;
  double _stepTimer = 0;
  bool _grounded = false;

  @override
  bool get isGrounded => _grounded;

  @override
  double get motionSpeed => _runVelocityX.abs();

  @override
  double get verticalSpeed => velocity.y;

  @override
  void update(double dt) {
    super.update(dt);
    if (state.isDead || gameRef.phase.value != GamePhase.playing) return;

    final input = gameRef.input;
    if (input.consumePrimary()) tryUseSkill(blueprint.skills.first.id);
    if (input.consumeSecondary() && blueprint.skills.length > 1) {
      tryUseSkill(blueprint.skills[1].id);
    }
    if (input.consumeJump()) _jumpBufferRemaining = jumpBufferDuration;

    _coyoteRemaining = _grounded
        ? coyoteDuration
        : (_coyoteRemaining - dt).clamp(0, coyoteDuration).toDouble();
    _jumpBufferRemaining =
        (_jumpBufferRemaining - dt).clamp(0, jumpBufferDuration).toDouble();

    final movementAllowed = state.canAct;
    final double axis = movementAllowed ? input.horizontalAxis : 0.0;
    if (axis.abs() > 0.08) facing = axis.sign;

    final castMultiplier = state.skills.isCasting ? 0.48 : 1.0;
    final targetSpeed = axis * state.effectiveMoveSpeed * castMultiplier;
    final acceleration = _grounded ? 1120.0 : 680.0;
    final braking = _grounded ? 1540.0 : 410.0;
    _runVelocityX = _moveTowards(
      _runVelocityX,
      targetSpeed,
      (axis.abs() > 0.08 ? acceleration : braking) * dt,
    );

    if (_jumpBufferRemaining > 0 && _coyoteRemaining > 0 && movementAllowed) {
      velocity.y = jumpVelocity;
      _grounded = false;
      _coyoteRemaining = 0;
      _jumpBufferRemaining = 0;
      gameRef.onHeroJump(position);
    }

    if (!input.jumpHeld && velocity.y < -95) velocity.y *= 0.56;

    final gravityScale = velocity.y < -80
        ? (input.jumpHeld ? 0.82 : 1.55)
        : velocity.y < 80
            ? 0.74
            : 1.22;
    velocity.y = math
        .min(
          maximumFallSpeed,
          velocity.y + gravity * gravityScale * dt,
        )
        .toDouble();

    horizontalImpulse *= math.pow(0.006, dt).toDouble();
    velocity.x = _runVelocityX + horizontalImpulse;

    final previousBottom = position.y + size.y / 2;
    final nextX = (position.x + velocity.x * dt)
        .clamp(24, ArenaStage.worldWidth - 24)
        .toDouble();
    final nextY = position.y + velocity.y * dt;
    final landing = gameRef.stage.landingTop(
      left: nextX - size.x * 0.29,
      right: nextX + size.x * 0.29,
      previousBottom: previousBottom,
      nextBottom: nextY + size.y / 2,
    );

    position.x = nextX;
    if (velocity.y >= 0 && landing != null) {
      final landingSpeed = velocity.y;
      position.y = landing - size.y / 2;
      velocity.y = 0;
      if (!_grounded && landingSpeed > 145) {
        gameRef.onHeroLanded(position, landingSpeed);
      }
      _grounded = true;
    } else {
      position.y = nextY;
      _grounded = false;
    }

    if (!_grounded && velocity.y >= 0 && velocity.y < 90) {
      final support = gameRef.stage.supportingPlatform(
        x: position.x,
        feetY: position.y + size.y / 2,
        maximumDrop: 7,
      );
      if (support != null) {
        position.y = support.top - size.y / 2;
        velocity.y = 0;
        _grounded = true;
      }
    }

    _updateFootsteps(dt, axis);
    _checkHazards();
    if (position.y > ArenaStage.worldHeight + 70) {
      gameRef.handleHeroFall();
    }
  }

  double _moveTowards(double current, double target, double maximumDelta) {
    if ((target - current).abs() <= maximumDelta) return target;
    return current + (target - current).sign * maximumDelta;
  }

  void _updateFootsteps(double dt, double axis) {
    if (!_grounded || axis.abs() < 0.08 || state.skills.isCasting) {
      _stepTimer = 0;
      return;
    }
    _stepTimer -= dt;
    if (_stepTimer <= 0) {
      final speedRatio = (_runVelocityX.abs() / state.effectiveMoveSpeed)
          .clamp(0.35, 1.0)
          .toDouble();
      _stepTimer = 0.38 - speedRatio * 0.11;
      gameRef.onHeroStep();
    }
  }

  void _checkHazards() {
    final bounds = Rect.fromCenter(
      center: Offset(position.x, position.y + 7),
      width: size.x * 0.43,
      height: size.y * 0.64,
    );
    if (gameRef.stage.collidesHazard(bounds)) {
      gameRef.damageHeroFromHazard(knockbackDirection: -facing);
    }
  }

  void launchUp({double speed = 545}) {
    velocity.y = -speed.abs();
    _grounded = false;
    _coyoteRemaining = 0;
    _jumpBufferRemaining = 0;
  }

  void teleport(Vector2 target) {
    position.setFrom(target);
    velocity.setZero();
    _runVelocityX = 0;
    horizontalImpulse = 0;
    _grounded = false;
    _coyoteRemaining = 0;
    _jumpBufferRemaining = 0;
  }

  @override
  void resetAt(Vector2 target) {
    super.resetAt(target);
    velocity.setZero();
    _runVelocityX = 0;
    _grounded = false;
    _coyoteRemaining = 0;
    _jumpBufferRemaining = 0;
    _stepTimer = 0;
  }

  @override
  void receiveKnockback(double impulse) {
    super.receiveKnockback(impulse);
    _runVelocityX *= 0.4;
    velocity.y = -145;
    _grounded = false;
  }
}
