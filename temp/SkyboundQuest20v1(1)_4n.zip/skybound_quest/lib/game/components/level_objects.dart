import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../skybound_game.dart';

class RelicComponent extends PositionComponent {
  RelicComponent({
    required this.gameRef,
    required Vector2 position,
    required this.index,
  }) : super(position: position, size: Vector2.all(54), anchor: Anchor.center) {
    priority = 20;
  }

  final SkyboundGame gameRef;
  final int index;
  Sprite? _sprite;
  bool active = true;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final name = switch (index % 3) {
      0 => 'relic_gold.png',
      1 => 'relic_cyan.png',
      _ => 'relic_purple.png',
    };
    _sprite = Sprite(await gameRef.images.load('generated/props/$name'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (!active || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && !hero.state.isDead && position.distanceTo(hero.position) < 44) {
      active = false;
      gameRef.collectRelic(this);
    }
  }

  void reset() {
    active = true;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    if (!active) return;
    final pulse = (math.sin(_time * 3.6 + index) + 1) / 2;
    final bob = math.sin(_time * 2.2 + index) * 4;
    final center = Offset(size.x / 2, size.y / 2 + bob);
    final colors = const [
      Color(0xFFFFD45F),
      Color(0xFF6CEBFF),
      Color(0xFFC987FF),
    ];
    final color = colors[index % colors.length];
    canvas.drawCircle(
      center,
      30 + pulse * 6,
      Paint()
        ..shader = Gradient.radial(
          center,
          36,
          [color.withAlpha(125), color.withAlpha(0)],
        ),
    );
    _sprite?.render(
      canvas,
      position: Vector2(2, 2 + bob),
      size: Vector2.all(50),
      overridePaint: Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class HealingPickupComponent extends PositionComponent {
  HealingPickupComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(52, 42), anchor: Anchor.center) {
    priority = 20;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  bool active = true;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(
      await gameRef.images.load('generated/props/health_pickup.png'),
    );
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (!active || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 40) {
      final healed = hero.state.health.heal(38);
      if (healed > 0) {
        active = false;
        gameRef.collectHealing(position, healed);
      }
    }
  }

  void reset() {
    active = true;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    if (!active) return;
    final bob = math.sin(_time * 2.5) * 3;
    final pulse = (math.sin(_time * 4) + 1) / 2;
    canvas.drawCircle(
      Offset(size.x / 2, size.y / 2 + bob),
      20 + pulse * 4,
      Paint()..color = const Color(0x42FF506D),
    );
    _sprite?.render(
      canvas,
      position: Vector2(0, bob),
      size: size,
      overridePaint: Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class EnergyPickupComponent extends PositionComponent {
  EnergyPickupComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(52, 42), anchor: Anchor.center) {
    priority = 20;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  bool active = true;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(
      await gameRef.images.load('generated/props/energy_pickup.png'),
    );
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (!active || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero == null || position.distanceTo(hero.position) >= 40) return;
    final restored = hero.state.restoreResource(46);
    if (restored <= 0) return;
    active = false;
    gameRef.collectEnergy(position, restored);
  }

  void reset() {
    active = true;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    if (!active) return;
    final bob = math.sin(_time * 2.8 + 1.1) * 3;
    final pulse = (math.sin(_time * 4.5) + 1) / 2;
    canvas.drawCircle(
      Offset(size.x / 2, size.y / 2 + bob),
      20 + pulse * 5,
      Paint()..color = const Color(0x493FFFD4),
    );
    _sprite?.render(
      canvas,
      position: Vector2(0, bob),
      size: size,
      overridePaint: Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class BoostPadComponent extends PositionComponent {
  BoostPadComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(70, 42), anchor: Anchor.bottomCenter) {
    priority = 18;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  double _cooldown = 0;
  double _pulse = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(await gameRef.images.load('generated/props/boost_pad.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _pulse += dt;
    _cooldown = math.max(0, _cooldown - dt).toDouble();
    if (_cooldown > 0 || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero == null || hero.state.isDead || hero.velocity.y < -80) return;
    final closeX = (hero.position.x - position.x).abs() < size.x * 0.48;
    final heroFeet = hero.position.y + hero.size.y / 2;
    final closeY = (heroFeet - position.y).abs() < 20;
    if (!closeX || !closeY) return;
    _cooldown = 0.55;
    hero.launchUp(speed: 560);
    gameRef.activateBoostPad(position);
  }

  void reset() {
    _cooldown = 0;
    _pulse = 0;
  }

  @override
  void render(Canvas canvas) {
    final glow = _cooldown > 0
        ? 0.25
        : 0.55 + math.sin(_pulse * 4.2).abs() * 0.35;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.x / 2, size.y * 0.78),
        width: size.x * (0.9 + glow * 0.14),
        height: 18 + glow * 8,
      ),
      Paint()..color = const Color(0xFFFFE56C).withAlpha((glow * 110).round()),
    );
    _sprite?.render(
      canvas,
      position: Vector2.zero(),
      size: size,
      overridePaint: Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class CheckpointComponent extends PositionComponent {
  CheckpointComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(76, 100), anchor: Anchor.bottomCenter) {
    priority = 8;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  bool activated = false;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(await gameRef.images.load('generated/props/checkpoint.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (activated || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 68) {
      activated = true;
      gameRef.activateCheckpoint(this);
    }
  }

  void reset() {
    activated = false;
    _time = 0;
  }

  Vector2 get respawnPoint => Vector2(position.x + 34, position.y - 28);

  @override
  void render(Canvas canvas) {
    final pulse = (math.sin(_time * 3) + 1) / 2;
    if (activated) {
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(size.x / 2, 28),
          width: 70 + pulse * 18,
          height: 70 + pulse * 18,
        ),
        Paint()
          ..shader = Gradient.radial(
            Offset(size.x / 2, 28),
            48,
            const [Color(0x995BFFF1), Color(0x005BFFF1)],
          ),
      );
    }
    _sprite?.render(
      canvas,
      position: Vector2.zero(),
      size: size,
      overridePaint: Paint()
        ..filterQuality = FilterQuality.medium
        ..colorFilter = activated
            ? null
            : const ColorFilter.mode(Color(0xFF778995), BlendMode.modulate),
    );
  }
}

class GoalPortalComponent extends PositionComponent {
  GoalPortalComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(132, 145), anchor: Anchor.bottomCenter) {
    priority = 12;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  double _time = 0;
  bool _entered = false;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(await gameRef.images.load('generated/props/portal.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (_entered || !gameRef.portalUnlocked || gameRef.phase.value != GamePhase.playing) {
      return;
    }
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 64) {
      _entered = true;
      gameRef.completeLevel();
    }
  }

  void reset() {
    _entered = false;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    final unlocked = gameRef.portalUnlocked;
    final pulse = (math.sin(_time * 2.8) + 1) / 2;
    final center = Offset(size.x / 2, size.y * 0.48);
    final portalColor = unlocked ? const Color(0xFF62F4FF) : const Color(0xFF738097);
    canvas.drawOval(
      Rect.fromCenter(
        center: center,
        width: 95 + pulse * 12,
        height: 112 + pulse * 12,
      ),
      Paint()
        ..shader = Gradient.radial(
          center,
          68,
          [portalColor.withAlpha(unlocked ? 150 : 45), portalColor.withAlpha(0)],
        ),
    );
    _sprite?.render(
      canvas,
      position: Vector2.zero(),
      size: size,
      overridePaint: Paint()
        ..filterQuality = FilterQuality.medium
        ..colorFilter = unlocked
            ? null
            : const ColorFilter.mode(Color(0xFF687A86), BlendMode.modulate),
    );
    if (!unlocked) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: center, width: 28, height: 24),
          const Radius.circular(5),
        ),
        Paint()..color = const Color(0xE0202C3B),
      );
      canvas.drawArc(
        Rect.fromCenter(center: center.translate(0, -14), width: 18, height: 22),
        math.pi,
        math.pi,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 5
          ..color = const Color(0xFFC7D0DF),
      );
    }
  }
}
