import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../skybound_game.dart';

class ArenaStage extends PositionComponent {
  ArenaStage({required this.gameRef})
      : platforms = const [
          Rect.fromLTWH(-120, 390, 820, 170),
          Rect.fromLTWH(760, 390, 740, 170),
          Rect.fromLTWH(1580, 390, 780, 170),
          Rect.fromLTWH(2440, 390, 920, 170),
          Rect.fromLTWH(315, 310, 190, 30),
          Rect.fromLTWH(545, 235, 180, 30),
          Rect.fromLTWH(865, 305, 190, 30),
          Rect.fromLTWH(1125, 300, 180, 30),
          Rect.fromLTWH(1310, 225, 190, 30),
          Rect.fromLTWH(1700, 300, 190, 30),
          Rect.fromLTWH(1940, 225, 200, 30),
          Rect.fromLTWH(2170, 150, 185, 30),
          Rect.fromLTWH(2560, 300, 190, 30),
          Rect.fromLTWH(2810, 235, 190, 30),
        ],
        hazards = const [
          Rect.fromLTWH(1010, 365, 90, 25),
          Rect.fromLTWH(1845, 365, 72, 25),
          Rect.fromLTWH(2245, 365, 72, 25),
          Rect.fromLTWH(2685, 365, 72, 25),
        ],
        super(position: Vector2.zero(), size: Vector2(3360, 560)) {
    priority = -100;
    _skyPaint.shader = Gradient.linear(
      const Offset(0, 0),
      const Offset(0, worldHeight),
      const [
        Color(0xFF07172C),
        Color(0xFF17606F),
        Color(0xFF7CCB99),
      ],
      const [0, 0.62, 1],
    );
    _abyssPaint.shader = Gradient.linear(
      const Offset(0, 350),
      const Offset(0, worldHeight),
      const [Color(0x2237F0D1), Color(0xFF06131D)],
    );
    _groundPaint.shader = Gradient.linear(
      const Offset(0, 390),
      const Offset(0, worldHeight),
      const [Color(0xFF744A32), Color(0xFF2A302B), Color(0xFF101A1F)],
      const [0.0, 0.58, 1.0],
    );
  }

  final SkyboundGame gameRef;
  final List<Rect> platforms;
  final List<Rect> hazards;
  final Map<String, Sprite> _sprites = {};
  final Paint _smoothPaint = Paint()..filterQuality = FilterQuality.medium;
  final Paint _parallaxPaint = Paint()..filterQuality = FilterQuality.medium;
  final Paint _decorationPaint = Paint()..filterQuality = FilterQuality.medium;
  final Paint _groundTilePaint = Paint()
    ..filterQuality = FilterQuality.medium
    ..color = const Color(0xB8FFFFFF);
  final Paint _skyPaint = Paint();
  final Paint _abyssPaint = Paint();
  final Paint _groundPaint = Paint();
  final Paint _platformFallbackPaint = Paint()..color = const Color(0xFF4E8D5C);
  final Paint _platformHighlightPaint = Paint()..color = const Color(0xAAE7FF96);
  final Paint _hazardFallbackPaint = Paint()..color = const Color(0xFFFF5666);
  final Paint _ambientPaint = Paint();
  final Paint _bossFloorPaint = Paint()..strokeCap = StrokeCap.round;
  final Paint _bossRunePaint = Paint()..style = PaintingStyle.stroke;
  final Paint _bossPillarPaint = Paint()..strokeCap = StrokeCap.round;
  double _time = 0;

  static const double worldWidth = 3360;
  static const double worldHeight = 560;

  static const _assetPaths = <String, String>{
    'sky': 'generated/backgrounds/sky.png',
    'mountains': 'generated/backgrounds/mountains.png',
    'forest': 'generated/backgrounds/forest.png',
    'ruinsMid': 'generated/backgrounds/ruins_mid.png',
    'ruinsNear': 'generated/backgrounds/ruins_near.png',
    'platformLong': 'generated/tiles/platform_grass_long.png',
    'platformMid': 'generated/tiles/platform_grass_mid.png',
    'platformShort': 'generated/tiles/platform_grass_short.png',
    'groundBlock': 'generated/tiles/ground_block.png',
    'spikes': 'generated/tiles/spikes.png',
    'tree': 'generated/props/tree.png',
    'bush': 'generated/props/bush.png',
    'mushrooms': 'generated/props/mushrooms.png',
    'pillar': 'generated/props/pillar.png',
    'sign': 'generated/props/sign.png',
    'crateWood': 'generated/props/crate_wood.png',
    'crateTech': 'generated/props/crate_tech.png',
  };

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    for (final entry in _assetPaths.entries) {
      _sprites[entry.key] = Sprite(await gameRef.images.load(entry.value));
    }
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
  }

  double? landingTop({
    required double left,
    required double right,
    required double previousBottom,
    required double nextBottom,
  }) {
    double? nearest;
    for (final platform in platforms) {
      final overlaps = right > platform.left + 3 && left < platform.right - 3;
      final crossesTop =
          previousBottom <= platform.top + 5 && nextBottom >= platform.top;
      if (overlaps &&
          crossesTop &&
          (nearest == null || platform.top < nearest)) {
        nearest = platform.top;
      }
    }
    return nearest;
  }

  Rect? supportingPlatform({
    required double x,
    required double feetY,
    double maximumDrop = 34,
  }) {
    Rect? best;
    var bestDistance = double.infinity;
    for (final platform in platforms) {
      if (x < platform.left + 8 || x > platform.right - 8) continue;
      final distance = platform.top - feetY;
      if (distance < -8 || distance > maximumDrop) continue;
      if (distance.abs() < bestDistance) {
        bestDistance = distance.abs();
        best = platform;
      }
    }
    return best;
  }

  bool hasSupportAhead({
    required double x,
    required double feetY,
    double maximumDrop = 30,
  }) =>
      supportingPlatform(x: x, feetY: feetY, maximumDrop: maximumDrop) != null;

  bool collidesHazard(Rect actorBounds) {
    for (final hazard in hazards) {
      if (hazard.overlaps(actorBounds)) return true;
    }
    return false;
  }

  bool collidesSolid(Rect bounds) {
    for (final platform in platforms) {
      if (platform.overlaps(bounds)) return true;
    }
    return false;
  }

  @override
  void render(Canvas canvas) {
    _drawSkyGradient(canvas);
    _drawParallax(canvas);
    _drawAbyss(canvas);
    for (final platform in platforms) {
      _drawPlatform(canvas, platform);
    }
    _drawHazards(canvas);
    _drawDecorations(canvas);
    _drawBossArena(canvas);
    _drawAmbientLights(canvas);
  }

  void _drawSkyGradient(Canvas canvas) {
    canvas.drawRect(Offset.zero & Size(size.x, size.y), _skyPaint);
  }

  void _drawParallax(Canvas canvas) {
    _drawParallaxStrip(
      canvas,
      sprite: _sprites['sky'],
      y: 0,
      height: 165,
      width: 1040,
      speedFactor: 0.08,
      opacity: 0.95,
    );
    _drawParallaxStrip(
      canvas,
      sprite: _sprites['mountains'],
      y: 92,
      height: 175,
      width: 1120,
      speedFactor: 0.18,
      opacity: 0.92,
    );
    _drawParallaxStrip(
      canvas,
      sprite: _sprites['forest'],
      y: 185,
      height: 165,
      width: 1080,
      speedFactor: 0.34,
      opacity: 0.88,
    );
    _drawParallaxStrip(
      canvas,
      sprite: _sprites['ruinsMid'],
      y: 250,
      height: 155,
      width: 1040,
      speedFactor: 0.5,
      opacity: 0.82,
    );
    _drawParallaxStrip(
      canvas,
      sprite: _sprites['ruinsNear'],
      y: 292,
      height: 170,
      width: 1050,
      speedFactor: 0.68,
      opacity: 0.6,
    );
  }

  void _drawParallaxStrip(
    Canvas canvas, {
    required Sprite? sprite,
    required double y,
    required double height,
    required double width,
    required double speedFactor,
    required double opacity,
  }) {
    if (sprite == null) return;
    final cameraX = gameRef.camera.viewfinder.position.x;
    final worldOffset = cameraX * (1 - speedFactor);
    final first = ((cameraX * speedFactor) / width).floor() - 1;
    _parallaxPaint.color = Color.fromRGBO(255, 255, 255, opacity);
    for (var i = first; i < first + 4; i++) {
      sprite.render(
        canvas,
        position: Vector2(worldOffset + i * width, y),
        size: Vector2(width + 2, height),
        overridePaint: _parallaxPaint,
      );
    }
  }

  void _drawAbyss(Canvas canvas) {
    canvas.drawRect(
      Rect.fromLTWH(0, 350, size.x, size.y - 350),
      _abyssPaint,
    );
  }

  void _drawPlatform(Canvas canvas, Rect platform) {
    final isGround = platform.height > 80;
    if (isGround) {
      canvas.drawRect(platform, _groundPaint);
      final block = _sprites['groundBlock'];
      if (block != null) {
        const tileWidth = 112.0;
        for (var x = platform.left; x < platform.right; x += tileWidth) {
          block.render(
            canvas,
            position: Vector2(x, platform.top + 34),
            size: Vector2(
              math.min(tileWidth, platform.right - x).toDouble(),
              math.min(115, platform.height - 30).toDouble(),
            ),
            overridePaint: _groundTilePaint,
          );
        }
      }
    }

    final sprite = platform.width > 500
        ? _sprites['platformLong']
        : platform.width > 185
            ? _sprites['platformMid']
            : _sprites['platformShort'];
    if (sprite != null) {
      final visualHeight = isGround ? 62.0 : 42.0;
      sprite.render(
        canvas,
        position: Vector2(platform.left, platform.top - 6),
        size: Vector2(platform.width, visualHeight),
        overridePaint: _smoothPaint,
      );
    } else {
      canvas.drawRRect(
        RRect.fromRectAndRadius(platform, const Radius.circular(6)),
        _platformFallbackPaint,
      );
    }

    canvas.drawRect(
      Rect.fromLTWH(platform.left + 4, platform.top, platform.width - 8, 2),
      _platformHighlightPaint,
    );
  }

  void _drawHazards(Canvas canvas) {
    final spike = _sprites['spikes'];
    for (final hazard in hazards) {
      if (spike != null) {
        spike.render(
          canvas,
          position: Vector2(hazard.left, hazard.top - 15),
          size: Vector2(hazard.width, 42),
          overridePaint: _smoothPaint,
        );
      } else {
        canvas.drawRect(hazard, _hazardFallbackPaint);
      }
    }
  }

  void _drawDecorations(Canvas canvas) {
    const decorations = <_Decoration>[
      _Decoration('tree', 85, 260, 100, 120, 0.9),
      _Decoration('bush', 215, 330, 90, 55, 0.86),
      _Decoration('sign', 690, 300, 95, 66, 0.9),
      _Decoration('mushrooms', 800, 340, 94, 58, 0.9),
      _Decoration('crateWood', 1085, 330, 62, 54, 0.94),
      _Decoration('pillar', 1505, 252, 72, 128, 0.78),
      _Decoration('bush', 1660, 340, 100, 58, 0.86),
      _Decoration('crateTech', 1890, 328, 70, 58, 0.94),
      _Decoration('tree', 2335, 250, 105, 130, 0.82),
      _Decoration('mushrooms', 2480, 337, 88, 54, 0.88),
      _Decoration('pillar', 3035, 255, 70, 125, 0.8),
      _Decoration('bush', 3145, 335, 100, 58, 0.86),
    ];
    for (final decoration in decorations) {
      final sprite = _sprites[decoration.sprite];
      if (sprite == null) continue;
      sprite.render(
        canvas,
        position: Vector2(decoration.x, decoration.y),
        size: Vector2(decoration.width, decoration.height),
        overridePaint: _decorationPaint
          ..color = Color.fromRGBO(255, 255, 255, decoration.opacity),
      );
    }
  }

  void _drawBossArena(Canvas canvas) {
    const arenaLeft = 2480.0;
    const arenaRight = 3075.0;
    const floorY = 387.0;
    final active = gameRef.bossEncounter.value;
    final phaseTwo = gameRef.bossPhase.value >= 2;
    final pulse = (math.sin(_time * (phaseTwo ? 5.4 : 3.2)) + 1) / 2;
    final accent = phaseTwo ? const Color(0xFFFF9B42) : const Color(0xFF58E7FF);
    final alpha = active ? 95 + (pulse * 80).round() : 24;

    final floorStart = const Offset(arenaLeft, floorY - 2);
    final floorEnd = const Offset(arenaRight, floorY - 2);
    _bossFloorPaint
      ..strokeWidth = active ? 12 : 6
      ..color = accent.withAlpha((alpha * 0.12).round());
    canvas.drawLine(floorStart, floorEnd, _bossFloorPaint);
    _bossFloorPaint
      ..strokeWidth = active ? 4 : 2
      ..color = accent.withAlpha(alpha);
    canvas.drawLine(floorStart, floorEnd, _bossFloorPaint);

    final center = const Offset((arenaLeft + arenaRight) / 2, floorY + 2);
    for (var i = 0; i < 3; i++) {
      final width = 170.0 + i * 92.0 + pulse * 16;
      final height = 22.0 + i * 8.0;
      _bossRunePaint
        ..strokeWidth = 1.5 + (2 - i) * 0.6
        ..color = accent.withAlpha((alpha * (0.72 - i * 0.15)).round());
      canvas.drawOval(
        Rect.fromCenter(center: center, width: width, height: height),
        _bossRunePaint,
      );
    }

    for (final x in const [2505.0, 3048.0]) {
      final glowHeight = active ? 94.0 + pulse * 24 : 48.0;
      final bottom = Offset(x, floorY);
      final top = Offset(x, floorY - glowHeight);
      _bossPillarPaint
        ..strokeWidth = active ? 12 : 6
        ..color = accent.withAlpha((alpha * 0.12).round());
      canvas.drawLine(bottom, top, _bossPillarPaint);
      _bossPillarPaint
        ..strokeWidth = active ? 3 : 2
        ..color = accent.withAlpha(alpha);
      canvas.drawLine(bottom, top, _bossPillarPaint);
      canvas.drawCircle(
        top,
        active ? 5 + pulse * 3 : 2.5,
        _bossPillarPaint,
      );
    }
  }

  void _drawAmbientLights(Canvas canvas) {
    for (var i = 0; i < 34; i++) {
      final x = 45.0 + i * 101.0;
      final y = 150.0 +
          math.sin(_time * 1.15 + i * 0.7) * 24.0 +
          (i % 4) * 42.0;
      final pulse = (math.sin(_time * 2.1 + i) + 1) / 2;
      _ambientPaint.color =
          const Color(0xFFB8FFB0).withAlpha((35 + pulse * 100).round());
      canvas.drawCircle(Offset(x, y), 1.2 + pulse * 1.5, _ambientPaint);
    }
  }
}

class _Decoration {
  const _Decoration(
    this.sprite,
    this.x,
    this.y,
    this.width,
    this.height,
    this.opacity,
  );

  final String sprite;
  final double x;
  final double y;
  final double width;
  final double height;
  final double opacity;
}
