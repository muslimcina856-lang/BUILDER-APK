class PlayerInput {
  bool _leftHeld = false;
  bool _rightHeld = false;
  double _touchAxis = 0;
  bool jumpHeld = false;
  bool _jumpQueued = false;
  bool _primaryQueued = false;
  bool _secondaryQueued = false;

  double get horizontalAxis {
    if (_touchAxis.abs() >= 0.08) return _touchAxis;
    if (_leftHeld == _rightHeld) return 0.0;
    return _leftHeld ? -1.0 : 1.0;
  }

  void setLeft(bool held) => _leftHeld = held;
  void setRight(bool held) => _rightHeld = held;

  void setHorizontalAxis(double value) {
    _touchAxis = value.clamp(-1.0, 1.0).toDouble();
  }

  void setJump(bool held) {
    if (held && !jumpHeld) _jumpQueued = true;
    jumpHeld = held;
  }

  void queuePrimary() => _primaryQueued = true;
  void queueSecondary() => _secondaryQueued = true;

  bool consumeJump() {
    final value = _jumpQueued;
    _jumpQueued = false;
    return value;
  }

  bool consumePrimary() {
    final value = _primaryQueued;
    _primaryQueued = false;
    return value;
  }

  bool consumeSecondary() {
    final value = _secondaryQueued;
    _secondaryQueued = false;
    return value;
  }

  void releaseAll() {
    _leftHeld = false;
    _rightHeld = false;
    _touchAxis = 0.0;
    jumpHeld = false;
    _jumpQueued = false;
    _primaryQueued = false;
    _secondaryQueued = false;
  }
}
