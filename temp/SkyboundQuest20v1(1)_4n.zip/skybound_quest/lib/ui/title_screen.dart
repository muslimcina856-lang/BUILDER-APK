import 'package:flutter/material.dart';

import '../game/combat/combat_models.dart';
import '../game/data/actor_catalog.dart';

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key, required this.onStart});

  final ValueChanged<String> onStart;

  @override
  State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen> {
  String _selectedId = 'nova';

  @override
  Widget build(BuildContext context) {
    final selected = ActorCatalog.byId(_selectedId);
    return Scaffold(
      backgroundColor: const Color(0xFF06131D),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF07172C), Color(0xFF17606F), Color(0xFF0A241D)],
              ),
            ),
          ),
          Positioned(
            left: -24,
            right: -24,
            top: 58,
            height: 205,
            child: Opacity(
              opacity: 0.78,
              child: Image.asset(
                'assets/images/generated/backgrounds/mountains.png',
                fit: BoxFit.fill,
                filterQuality: FilterQuality.medium,
              ),
            ),
          ),
          Positioned(
            left: -20,
            right: -20,
            bottom: 86,
            height: 180,
            child: Opacity(
              opacity: 0.66,
              child: Image.asset(
                'assets/images/generated/backgrounds/forest.png',
                fit: BoxFit.fill,
                filterQuality: FilterQuality.medium,
              ),
            ),
          ),
          Positioned(
            left: -18,
            right: -18,
            bottom: -24,
            height: 218,
            child: Opacity(
              opacity: 0.9,
              child: Image.asset(
                'assets/images/generated/backgrounds/ruins_near.png',
                fit: BoxFit.fill,
                filterQuality: FilterQuality.medium,
              ),
            ),
          ),
          Container(color: const Color(0x33030A10)),
          SafeArea(
            minimum: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxHeight < 520;
                return Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1120),
                    child: Column(
                      children: [
                        SizedBox(
                          height: compact ? 132 : 178,
                          child: Image.asset(
                            'assets/images/generated/branding/skybound_logo.png',
                            cacheWidth: 768,
                            fit: BoxFit.contain,
                            filterQuality: FilterQuality.medium,
                          ),
                        ),
                        SizedBox(height: compact ? 2 : 8),
                        Expanded(
                          child: _AvatarStrip(
                            selectedId: _selectedId,
                            compact: compact,
                            onSelected: (id) => setState(() => _selectedId = id),
                          ),
                        ),
                        SizedBox(height: compact ? 5 : 10),
                        _SelectedSummary(avatar: selected, compact: compact),
                        SizedBox(height: compact ? 6 : 10),
                        SizedBox(
                          width: compact ? 300 : 350,
                          height: compact ? 44 : 50,
                          child: FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: _avatarColor(selected.id),
                              foregroundColor: const Color(0xFF05131B),
                              elevation: 8,
                              shadowColor: _avatarColor(selected.id).withAlpha(120),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                                side: const BorderSide(color: Colors.white, width: 1.5),
                              ),
                            ),
                            onPressed: () => widget.onStart(selected.id),
                            icon: const Icon(Icons.play_arrow_rounded, size: 25),
                            label: Text(
                              'MULA MISI · ${selected.name.toUpperCase()}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.9,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: compact ? 4 : 8),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _AvatarStrip extends StatelessWidget {
  const _AvatarStrip({
    required this.selectedId,
    required this.compact,
    required this.onSelected,
  });

  final String selectedId;
  final bool compact;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 840;
        final cardWidth = wide
            ? (constraints.maxWidth - 30) / 4
            : compact
                ? 170.0
                : 190.0;
        return ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.symmetric(horizontal: wide ? 0 : 8),
          itemCount: ActorCatalog.playableAvatars.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (context, index) {
            final avatar = ActorCatalog.playableAvatars[index];
            return SizedBox(
              width: cardWidth,
              child: _AvatarCard(
                avatar: avatar,
                compact: compact,
                selected: avatar.id == selectedId,
                onTap: () => onSelected(avatar.id),
              ),
            );
          },
        );
      },
    );
  }
}

class _AvatarCard extends StatelessWidget {
  const _AvatarCard({
    required this.avatar,
    required this.compact,
    required this.selected,
    required this.onTap,
  });

  final ActorBlueprint avatar;
  final bool compact;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = _avatarColor(avatar.id);
    return AnimatedScale(
      duration: const Duration(milliseconds: 150),
      scale: selected ? 1 : 0.965,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: EdgeInsets.fromLTRB(10, compact ? 6 : 10, 10, 9),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: selected
                    ? [const Color(0xF01B4050), const Color(0xF00B1D2A)]
                    : [const Color(0xD91A2934), const Color(0xD908131E)],
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected ? accent : const Color(0x885F7D8B),
                width: selected ? 2.5 : 1.2,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: accent.withAlpha(95),
                        blurRadius: 18,
                        spreadRadius: 1,
                      ),
                    ]
                  : const [],
            ),
            child: Column(
              children: [
                Expanded(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: compact ? 82 : 105,
                        height: compact ? 82 : 105,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [accent.withAlpha(100), accent.withAlpha(0)],
                          ),
                        ),
                      ),
                      Image.asset(
                        'assets/images/${avatar.spriteFrames.first}',
                        fit: BoxFit.contain,
                        filterQuality: FilterQuality.medium,
                      ),
                    ],
                  ),
                ),
                Text(
                  avatar.name.toUpperCase(),
                  style: TextStyle(
                    color: selected ? accent : Colors.white,
                    fontSize: compact ? 14 : 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.3,
                  ),
                ),
                const SizedBox(height: 5),
                _MiniStats(avatar: avatar, compact: compact),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MiniStats extends StatelessWidget {
  const _MiniStats({required this.avatar, required this.compact});

  final ActorBlueprint avatar;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _StatChip(
          icon: Icons.favorite_rounded,
          value: avatar.stats.maxHealth.round().toString(),
          color: const Color(0xFFFF6B78),
          compact: compact,
        ),
        const SizedBox(width: 4),
        _StatChip(
          icon: Icons.flash_on_rounded,
          value: avatar.stats.attackPower.round().toString(),
          color: const Color(0xFFFFD166),
          compact: compact,
        ),
        const SizedBox(width: 4),
        _StatChip(
          icon: Icons.directions_run_rounded,
          value: avatar.stats.moveSpeed.round().toString(),
          color: const Color(0xFF69E5FF),
          compact: compact,
        ),
      ],
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({
    required this.icon,
    required this.value,
    required this.color,
    required this.compact,
  });

  final IconData icon;
  final String value;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: compact ? 3 : 4),
        decoration: BoxDecoration(
          color: const Color(0x77030A10),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: compact ? 11 : 13, color: color),
            const SizedBox(width: 2),
            Text(
              value,
              style: TextStyle(
                fontSize: compact ? 9 : 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SelectedSummary extends StatelessWidget {
  const _SelectedSummary({required this.avatar, required this.compact});

  final ActorBlueprint avatar;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final accent = _avatarColor(avatar.id);
    return Container(
      constraints: const BoxConstraints(maxWidth: 760),
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 12 : 18,
        vertical: compact ? 6 : 9,
      ),
      decoration: BoxDecoration(
        color: const Color(0xD90A1722),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accent.withAlpha(160)),
      ),
      child: Row(
        children: [
          Icon(Icons.auto_awesome_rounded, color: accent, size: compact ? 17 : 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '${avatar.skills.first.name} · ${avatar.skills.last.name} — ${avatar.skills.last.description}',
              maxLines: compact ? 1 : 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: const Color(0xFFE8F7F8),
                fontSize: compact ? 10 : 12,
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Color _avatarColor(String id) => switch (id) {
      'nova' => const Color(0xFF62E8D4),
      'aegis' => const Color(0xFF63DDE2),
      'pyra' => const Color(0xFFFF765E),
      'volt' => const Color(0xFFFFD84D),
      _ => const Color(0xFFFFFFFF),
    };
