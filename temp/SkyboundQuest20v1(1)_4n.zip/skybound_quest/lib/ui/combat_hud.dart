import 'dart:math' as math;

import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/combat/health_pool.dart';
import '../game/skybound_game.dart';

class CombatHud extends StatefulWidget {
  const CombatHud({
    super.key,
    required this.game,
    required this.onExit,
  });

  final SkyboundGame game;
  final VoidCallback onExit;

  @override
  State<CombatHud> createState() => _CombatHudState();
}

class _CombatHudState extends State<CombatHud> {
  bool _soundEnabled = true;

  SkyboundGame get game => widget.game;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.all(7),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxHeight < 500;
          final uiScale = math
              .min(1.0, constraints.maxWidth / 950)
              .clamp(0.78, 1.0)
              .toDouble();
          return Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Transform.scale(
                  scale: uiScale,
                  alignment: Alignment.topLeft,
                  child: _Vitals(game: game, compact: compact),
                ),
              ),
              Positioned(
                left: compact ? 220 : 245,
                right: compact ? 54 : 62,
                top: 0,
                child: _ObjectivePanel(game: game, compact: compact),
              ),
              Positioned(
                right: 0,
                top: 0,
                child: _PauseButton(onPressed: game.togglePause, compact: compact),
              ),
              Positioned(
                left: constraints.maxWidth * 0.24,
                right: constraints.maxWidth * 0.24,
                top: compact ? 42 : 50,
                child: _BossBar(game: game, compact: compact),
              ),
              Positioned.fill(child: _Banner(game: game, compact: compact)),
              Positioned.fill(child: _Controls(game: game, compact: compact)),
              Positioned.fill(
                child: _PhaseOverlay(
                  game: game,
                  onExit: widget.onExit,
                  soundEnabled: _soundEnabled,
                  onSoundChanged: (value) {
                    setState(() => _soundEnabled = value);
                    game.setSoundEnabled(value);
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _Vitals extends StatelessWidget {
  const _Vitals({required this.game, required this.compact});

  final SkyboundGame game;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final avatar = game.selectedAvatar;
    return _Panel(
      width: compact ? 210 : 232,
      padding: EdgeInsets.all(compact ? 7 : 8),
      child: Row(
        children: [
          Container(
            width: compact ? 42 : 48,
            height: compact ? 42 : 48,
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: const Color(0xAA06131D),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: const Color(0xFF70E8D6), width: 1.5),
            ),
            child: Image.asset(
              'assets/images/${avatar.spriteFrames.first}',
              fit: BoxFit.contain,
              filterQuality: FilterQuality.medium,
            ),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        avatar.name.toUpperCase(),
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: compact ? 10 : 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    ValueListenableBuilder<int>(
                      valueListenable: game.relicCount,
                      builder: (_, count, __) => Text(
                        '◆ $count/3',
                        style: TextStyle(
                          color: const Color(0xFF7EEBFF),
                          fontSize: compact ? 9 : 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ValueListenableBuilder<HealthSnapshot>(
                  valueListenable: game.heroHealth,
                  builder: (_, health, __) => _Meter(
                    value: health.ratio,
                    secondaryValue: health.maximum == 0
                        ? 0.0
                        : (health.shield / health.maximum).clamp(0, 1).toDouble(),
                    color: const Color(0xFFFF5C6A),
                    label: '${health.current.ceil()} / ${health.maximum.ceil()}',
                    height: compact ? 10 : 12,
                  ),
                ),
                const SizedBox(height: 4),
                ValueListenableBuilder<double>(
                  valueListenable: game.heroResource,
                  builder: (_, value, __) => _Meter(
                    value: value,
                    color: const Color(0xFF4FD7FF),
                    label: '${(value * 100).ceil()}%',
                    height: compact ? 8 : 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ObjectivePanel extends StatelessWidget {
  const _ObjectivePanel({required this.game, required this.compact});

  final SkyboundGame game;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _Panel(
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 9 : 12,
          vertical: compact ? 6 : 7,
        ),
        child: ValueListenableBuilder<String>(
          valueListenable: game.objective,
          builder: (_, objective, __) => ValueListenableBuilder<int>(
            valueListenable: game.enemiesRemaining,
            builder: (_, enemies, __) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.explore_rounded,
                  color: const Color(0xFFFFD166),
                  size: compact ? 14 : 16,
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    objective.toUpperCase(),
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: compact ? 8.5 : 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '☠ $enemies',
                  style: TextStyle(
                    color: const Color(0xFFFF8A8F),
                    fontSize: compact ? 8.5 : 9.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BossBar extends StatelessWidget {
  const _BossBar({required this.game, required this.compact});

  final SkyboundGame game;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: game.bossEncounter,
      builder: (_, active, __) {
        if (!active) return const SizedBox.shrink();
        return ValueListenableBuilder<double>(
          valueListenable: game.bossHealth,
          builder: (_, health, __) => ValueListenableBuilder<int>(
            valueListenable: game.bossPhase,
            builder: (_, phase, __) => ValueListenableBuilder<String?>(
              valueListenable: game.bossAttack,
              builder: (_, attack, __) {
                final phaseTwo = phase >= 2;
                final accent = phaseTwo
                    ? const Color(0xFFFFA84A)
                    : const Color(0xFF55DFFF);
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withAlpha(phaseTwo ? 71 : 46),
                        blurRadius: phaseTwo ? 18 : 12,
                        spreadRadius: phaseTwo ? 2 : 0,
                      ),
                    ],
                  ),
                  child: _Panel(
                    padding: EdgeInsets.symmetric(
                      horizontal: compact ? 9 : 12,
                      vertical: compact ? 5 : 6,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'MONITOR GOLEM',
                              style: TextStyle(
                                color: accent,
                                fontSize: compact ? 8 : 9,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(width: 7),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: accent.withAlpha(41),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: accent.withAlpha(140),
                                ),
                              ),
                              child: Text(
                                'FASA $phase',
                                style: TextStyle(
                                  color: accent,
                                  fontSize: compact ? 6.5 : 7.5,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 3),
                        _Meter(
                          value: health,
                          color: accent,
                          label: '${(health * 100).ceil()}%',
                          height: compact ? 8 : 10,
                        ),
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 140),
                          child: attack == null
                              ? const SizedBox(height: 0)
                              : Padding(
                                  key: ValueKey(attack),
                                  padding: const EdgeInsets.only(top: 3),
                                  child: Text(
                                    attack,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: phaseTwo
                                          ? const Color(0xFFFFD18A)
                                          : const Color(0xFFC9F7FF),
                                      fontSize: compact ? 6.5 : 7.5,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 0.7,
                                    ),
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.game, required this.compact});

  final SkyboundGame game;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Align(
        alignment: const Alignment(0, -0.28),
        child: ValueListenableBuilder<String?>(
          valueListenable: game.banner,
          builder: (_, message, __) => AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            child: message == null
                ? const SizedBox.shrink()
                : _Panel(
                    key: ValueKey(message),
                    padding: EdgeInsets.symmetric(
                      horizontal: compact ? 14 : 18,
                      vertical: compact ? 7 : 9,
                    ),
                    child: Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: compact ? 10 : 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.game, required this.compact});

  final SkyboundGame game;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GamePhase>(
      valueListenable: game.phase,
      builder: (_, phase, __) {
        final enabled = phase == GamePhase.playing;
        return IgnorePointer(
          ignoring: !enabled,
          child: AnimatedOpacity(
            opacity: enabled ? 1 : 0,
            duration: const Duration(milliseconds: 130),
            child: Stack(
              children: [
                Positioned(
                  left: compact ? 4 : 8,
                  bottom: compact ? 1 : 5,
                  child: _VirtualStick(
                    size: compact ? 104 : 122,
                    onChanged: game.input.setHorizontalAxis,
                  ),
                ),
                Positioned(
                  right: compact ? 4 : 8,
                  bottom: compact ? 2 : 6,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _ActionButton(
                        icon: Icons.auto_awesome_rounded,
                        label: 'SKILL',
                        color: const Color(0xFF9B6DFF),
                        size: compact ? 52 : 58,
                        cooldown: game.secondaryCooldown,
                        onDown: game.input.queueSecondary,
                      ),
                      SizedBox(width: compact ? 8 : 10),
                      _ActionButton(
                        icon: Icons.gps_fixed_rounded,
                        label: 'SERANG',
                        color: const Color(0xFFFF5B67),
                        size: compact ? 58 : 65,
                        cooldown: game.primaryCooldown,
                        onDown: game.input.queuePrimary,
                      ),
                      SizedBox(width: compact ? 8 : 10),
                      _ActionButton(
                        icon: Icons.arrow_upward_rounded,
                        label: 'LOMPAT',
                        color: const Color(0xFF42BDF4),
                        size: compact ? 64 : 72,
                        onDown: () => game.input.setJump(true),
                        onUp: () => game.input.setJump(false),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _VirtualStick extends StatefulWidget {
  const _VirtualStick({required this.size, required this.onChanged});

  final double size;
  final ValueChanged<double> onChanged;

  @override
  State<_VirtualStick> createState() => _VirtualStickState();
}

class _VirtualStickState extends State<_VirtualStick> {
  int? _pointer;
  double _axis = 0.0;

  void _update(Offset position) {
    final axis = ((position.dx - widget.size / 2) / (widget.size * 0.31))
        .clamp(-1.0, 1.0)
        .toDouble();
    setState(() => _axis = axis);
    widget.onChanged(axis);
  }

  void _release(int pointer) {
    if (_pointer != pointer) return;
    _pointer = null;
    setState(() => _axis = 0.0);
    widget.onChanged(0.0);
  }

  @override
  void dispose() {
    widget.onChanged(0.0);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (event) {
        if (_pointer != null) return;
        _pointer = event.pointer;
        _update(event.localPosition);
      },
      onPointerMove: (event) {
        if (_pointer == event.pointer) _update(event.localPosition);
      },
      onPointerUp: (event) => _release(event.pointer),
      onPointerCancel: (event) => _release(event.pointer),
      child: SizedBox.square(
        dimension: widget.size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: widget.size,
              height: widget.size * 0.62,
              decoration: BoxDecoration(
                color: const Color(0x7010202A),
                borderRadius: BorderRadius.circular(widget.size * 0.31),
                border: Border.all(color: const Color(0x886DE5D7), width: 1.5),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Icon(Icons.chevron_left_rounded, color: Colors.white54, size: widget.size * 0.28),
                  Icon(Icons.chevron_right_rounded, color: Colors.white54, size: widget.size * 0.28),
                ],
              ),
            ),
            AnimatedAlign(
              duration: const Duration(milliseconds: 35),
              curve: Curves.easeOut,
              alignment: Alignment(_axis * 0.72, 0),
              child: Container(
                width: widget.size * 0.39,
                height: widget.size * 0.39,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF78E8DB), Color(0xFF279D9D)],
                  ),
                  border: Border.all(color: Colors.white70, width: 1.5),
                  boxShadow: const [
                    BoxShadow(color: Color(0x66000000), blurRadius: 6, offset: Offset(0, 3)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatefulWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.size,
    required this.onDown,
    this.onUp,
    this.cooldown,
  });

  final IconData icon;
  final String label;
  final Color color;
  final double size;
  final VoidCallback onDown;
  final VoidCallback? onUp;
  final ValueListenable<double>? cooldown;

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton> {
  bool _pressed = false;
  int? _pointer;

  void _down(PointerDownEvent event) {
    if (_pointer != null) return;
    _pointer = event.pointer;
    setState(() => _pressed = true);
    HapticFeedback.selectionClick();
    widget.onDown();
  }

  void _up(PointerEvent event) {
    if (_pointer != event.pointer) return;
    _pointer = null;
    if (_pressed) setState(() => _pressed = false);
    widget.onUp?.call();
  }

  @override
  void dispose() {
    if (_pressed) widget.onUp?.call();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final content = Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: _down,
      onPointerUp: _up,
      onPointerCancel: _up,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 65),
        scale: _pressed ? 0.9 : 1,
        child: SizedBox.square(
          dimension: widget.size,
          child: DecoratedBox(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: widget.color.withAlpha(222),
              border: Border.all(color: Colors.white70, width: 1.5),
              boxShadow: const [
                BoxShadow(color: Color(0x66000000), blurRadius: 7, offset: Offset(0, 4)),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(widget.icon, color: Colors.white, size: widget.size * 0.39),
                Positioned(
                  bottom: widget.size * 0.09,
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      fontSize: widget.size * 0.095,
                      fontWeight: FontWeight.w900,
                      shadows: const [Shadow(color: Colors.black, blurRadius: 3)],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    final cooldown = widget.cooldown;
    if (cooldown == null) return content;
    return ValueListenableBuilder<double>(
      valueListenable: cooldown,
      builder: (_, value, __) => Stack(
        alignment: Alignment.center,
        children: [
          content,
          if (value > 0.001)
            IgnorePointer(
              child: SizedBox.square(
                dimension: widget.size * 0.9,
                child: CircularProgressIndicator(
                  value: value,
                  strokeWidth: widget.size * 0.08,
                  color: const Color(0xD909111B),
                  backgroundColor: Colors.transparent,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _PhaseOverlay extends StatelessWidget {
  const _PhaseOverlay({
    required this.game,
    required this.onExit,
    required this.soundEnabled,
    required this.onSoundChanged,
  });

  final SkyboundGame game;
  final VoidCallback onExit;
  final bool soundEnabled;
  final ValueChanged<bool> onSoundChanged;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GamePhase>(
      valueListenable: game.phase,
      builder: (_, phase, __) {
        if (phase == GamePhase.playing) return const SizedBox.shrink();
        if (phase == GamePhase.loading) {
          return const ColoredBox(
            color: Color(0xE6071225),
            child: Center(
              child: _Panel(
                width: 310,
                padding: EdgeInsets.symmetric(horizontal: 26, vertical: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Color(0xFF66E2C4)),
                    SizedBox(height: 14),
                    Text(
                      'MEMUATKAN AETHER RUINS',
                      style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        final victory = phase == GamePhase.victory;
        final defeat = phase == GamePhase.defeat;
        final title = victory
            ? 'MISI SELESAI'
            : defeat
                ? '${game.selectedAvatar.name.toUpperCase()} TUMBANG'
                : 'PERMAINAN DIJEDA';
        final subtitle = victory
            ? 'Portal Aether berjaya distabilkan.'
            : defeat
                ? 'Cuba semula dari checkpoint dan gunakan skill pada masa yang tepat.'
                : 'Kawalan sentuh atau A/D · W/Space · J · K';

        return ColoredBox(
          color: const Color(0xC9040B16),
          child: Center(
            child: _Panel(
              width: 420,
              padding: const EdgeInsets.fromLTRB(28, 20, 28, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/images/generated/branding/app_icon_512.png',
                    width: 58,
                    height: 58,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.medium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Color(0xFFB8CDDB), fontSize: 11),
                  ),
                  if (victory || defeat) ...[
                    const SizedBox(height: 12),
                    Text(
                      'MASA ${game.elapsedTimeLabel}  ·  RELIK ${game.progress.relicsCollected}/3  ·  MUSUH ${game.progress.enemiesDefeated}',
                      style: const TextStyle(
                        color: Color(0xFF7EEBFF),
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  if (phase == GamePhase.paused) ...[
                    _MenuButton(
                      label: 'SAMBUNG',
                      icon: Icons.play_arrow_rounded,
                      primary: true,
                      onPressed: game.resumeGame,
                    ),
                    const SizedBox(height: 8),
                  ],
                  _MenuButton(
                    label: victory || defeat ? 'MAIN SEMULA' : 'MULA SEMULA',
                    icon: Icons.refresh_rounded,
                    primary: victory || defeat,
                    onPressed: game.restartLevel,
                  ),
                  const SizedBox(height: 8),
                  _MenuButton(
                    label: 'PILIH WATAK',
                    icon: Icons.people_alt_rounded,
                    onPressed: onExit,
                  ),
                  const SizedBox(height: 7),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.volume_up_rounded, size: 17, color: Color(0xFFB8CDDB)),
                      const SizedBox(width: 6),
                      const Text('BUNYI', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
                      Switch.adaptive(value: soundEnabled, onChanged: onSoundChanged),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    this.primary = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback onPressed;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 265,
      height: 42,
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: primary ? const Color(0xFF66E2C4) : const Color(0xFF233B55),
          foregroundColor: primary ? const Color(0xFF071225) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: primary ? Colors.white : const Color(0xFF58718A),
              width: 1.5,
            ),
          ),
        ),
        onPressed: onPressed,
        icon: Icon(icon),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.7)),
      ),
    );
  }
}

class _Meter extends StatelessWidget {
  const _Meter({
    required this.value,
    required this.color,
    required this.label,
    this.secondaryValue = 0,
    this.height = 12,
  });

  final double value;
  final Color color;
  final String label;
  final double secondaryValue;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Stack(
        fit: StackFit.expand,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              color: const Color(0xFF050B12),
              borderRadius: BorderRadius.circular(height / 2),
              border: Border.all(color: Colors.white12),
            ),
          ),
          FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: value.clamp(0, 1).toDouble(),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(height / 2),
              ),
            ),
          ),
          if (secondaryValue > 0)
            FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: secondaryValue.clamp(0, 1).toDouble(),
              child: Align(
                alignment: Alignment.centerRight,
                child: Container(width: 3, color: const Color(0xFFB5F5FF)),
              ),
            ),
          Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: height <= 9 ? 6.5 : 7.5,
                fontWeight: FontWeight.w900,
                shadows: const [Shadow(color: Colors.black, blurRadius: 2)],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PauseButton extends StatelessWidget {
  const _PauseButton({required this.onPressed, required this.compact});

  final VoidCallback onPressed;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final size = compact ? 40.0 : 46.0;
    return SizedBox.square(
      dimension: size,
      child: IconButton.filled(
        style: IconButton.styleFrom(
          backgroundColor: const Color(0xCC10243A),
          foregroundColor: Colors.white,
          side: const BorderSide(color: Color(0xAA6A91A6), width: 1.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        onPressed: onPressed,
        icon: Icon(Icons.pause_rounded, size: compact ? 21 : 24),
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({
    super.key,
    required this.child,
    this.width,
    this.padding = const EdgeInsets.all(9),
  });

  final Widget child;
  final double? width;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xD90B1B2A),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: const Color(0xAA52798B), width: 1.4),
        boxShadow: const [
          BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 4)),
        ],
      ),
      child: child,
    );
  }
}
