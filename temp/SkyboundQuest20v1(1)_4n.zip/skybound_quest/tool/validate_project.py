#!/usr/bin/env python3
"""Semakan statik tanpa Flutter SDK untuk arkib Skybound Quest."""

from __future__ import annotations

import re
import struct
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOTS = (ROOT / "lib", ROOT / "test", ROOT / "tool")
DART_FILES = sorted(
    path
    for source_root in SOURCE_ROOTS
    if source_root.exists()
    for path in source_root.rglob("*.dart")
)


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def check_pubspec() -> tuple[str, list[str]]:
    text = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
    name_match = re.search(r"(?m)^name:\s*([^\s#]+)", text)
    version_match = re.search(r"(?m)^version:\s*([^\s#]+)", text)
    if name_match is None or name_match.group(1) != "skybound_quest":
        fail("Nama package dalam pubspec.yaml tidak sah.")
    if version_match is None:
        fail("Versi pubspec.yaml tidak dijumpai.")

    asset_dirs = re.findall(r"(?m)^\s{4}-\s+(assets/[^\n#]+/?)\s*$", text)
    if not asset_dirs:
        fail("Tiada direktori aset diisytiharkan dalam pubspec.yaml.")
    for relative in asset_dirs:
        if not (ROOT / relative).exists():
            fail(f"Direktori aset pubspec hilang: {relative}")

    removed_dependencies = ("flame_tiled", "shared_preferences")
    for package in removed_dependencies:
        if re.search(rf"(?m)^\s*{re.escape(package)}\s*:", text):
            fail(f"Dependency tidak digunakan masih ada: {package}")
    return version_match.group(1), asset_dirs


def check_imports() -> int:
    checked = 0
    pattern = re.compile(r"(?m)^\s*import\s+['\"]([^'\"]+)['\"]")
    for dart_file in DART_FILES:
        text = dart_file.read_text(encoding="utf-8")
        for target in pattern.findall(text):
            checked += 1
            if target.startswith("dart:") or target.startswith("package:flutter"):
                continue
            if target.startswith("package:flame"):
                continue
            if target.startswith("package:skybound_quest/"):
                relative = target.removeprefix("package:skybound_quest/")
                destination = ROOT / "lib" / relative
            elif target.startswith("package:"):
                continue
            else:
                destination = (dart_file.parent / target).resolve()
            if not destination.is_file():
                fail(
                    f"Import hilang: {dart_file.relative_to(ROOT)} -> "
                    f"{destination.relative_to(ROOT) if destination.is_relative_to(ROOT) else destination}"
                )
    return checked


def strip_comments_and_strings(text: str) -> str:
    """Kekalkan delimiter struktur, kosongkan komen dan kandungan string Dart."""
    output: list[str] = []
    i = 0
    state = "code"
    quote = ""
    triple = False
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if ch == "/" and nxt == "/":
                state = "line_comment"
                output.extend("  ")
                i += 2
                continue
            if ch == "/" and nxt == "*":
                state = "block_comment"
                output.extend("  ")
                i += 2
                continue
            if ch in ("'", '"'):
                quote = ch
                triple = text[i : i + 3] == ch * 3
                state = "string"
                width = 3 if triple else 1
                output.extend(" " * width)
                i += width
                continue
            output.append(ch)
            i += 1
            continue
        if state == "line_comment":
            if ch == "\n":
                state = "code"
                output.append("\n")
            else:
                output.append(" ")
            i += 1
            continue
        if state == "block_comment":
            if ch == "*" and nxt == "/":
                state = "code"
                output.extend("  ")
                i += 2
            else:
                output.append("\n" if ch == "\n" else " ")
                i += 1
            continue
        if state == "string":
            if ch == "\\":
                output.extend("  ")
                i += min(2, len(text) - i)
                continue
            if triple and text[i : i + 3] == quote * 3:
                state = "code"
                output.extend("   ")
                i += 3
                continue
            if not triple and ch == quote:
                state = "code"
                output.append(" ")
                i += 1
                continue
            output.append("\n" if ch == "\n" else " ")
            i += 1
    if state in {"string", "block_comment"}:
        fail(f"String atau komen tidak ditutup (state={state}).")
    return "".join(output)


def check_delimiters() -> int:
    pairs = {')': '(', ']': '[', '}': '{'}
    openings = set(pairs.values())
    checked = 0
    for dart_file in DART_FILES:
        clean = strip_comments_and_strings(dart_file.read_text(encoding="utf-8"))
        stack: list[tuple[str, int]] = []
        for offset, ch in enumerate(clean):
            if ch in openings:
                stack.append((ch, offset))
            elif ch in pairs:
                if not stack or stack[-1][0] != pairs[ch]:
                    line = clean.count("\n", 0, offset) + 1
                    fail(f"Delimiter tidak sepadan: {dart_file.relative_to(ROOT)}:{line}")
                stack.pop()
        if stack:
            ch, offset = stack[-1]
            line = clean.count("\n", 0, offset) + 1
            fail(f"Delimiter {ch} tidak ditutup: {dart_file.relative_to(ROOT)}:{line}")
        checked += 1
    return checked


def normalize_asset(raw: str) -> Path | None:
    if "$" in raw or "{" in raw:
        return None
    if raw.startswith("assets/"):
        return ROOT / raw
    if raw.endswith(".ogg"):
        return ROOT / "assets" / "audio" / raw
    if raw.endswith(".csv"):
        return ROOT / "assets" / "manifests" / raw
    if raw.endswith(".png") and raw.split("/", 1)[0] in {
        "characters",
        "tiles",
        "backgrounds",
        "ui",
        "controls",
        "generated",
    }:
        return ROOT / "assets" / "images" / raw
    return None


def check_assets() -> tuple[int, int, int, int]:
    literal_pattern = re.compile(r"(?<![A-Za-z0-9_])['\"]([^'\"\n]+\.(?:png|ogg|csv))['\"]")
    referenced: set[Path] = set()
    for dart_file in DART_FILES:
        text = dart_file.read_text(encoding="utf-8")
        for raw in literal_pattern.findall(text):
            path = normalize_asset(raw)
            if path is not None:
                referenced.add(path)

    # Nama relik dipilih secara dinamik dalam level_objects.dart.
    for name in ("relic_gold.png", "relic_cyan.png", "relic_purple.png"):
        referenced.add(ROOT / "assets" / "images" / "generated" / "props" / name)

    missing = sorted(path for path in referenced if not path.is_file())
    if missing:
        fail("Aset dirujuk tetapi hilang:\n" + "\n".join(f"  - {p.relative_to(ROOT)}" for p in missing))

    image_files = [path for path in (ROOT / "assets/images").rglob("*.png") if path.is_file()]
    image_count = len(image_files)
    audio_count = sum(1 for path in (ROOT / "assets/audio").rglob("*.ogg") if path.is_file())
    generated_count = sum(
        1 for path in (ROOT / "assets/images/generated").rglob("*.png") if path.is_file()
    )
    if image_count != 352:
        fail(f"Bilangan imej runtime berubah tanpa kemas kini validator: {image_count} (jangkaan 352).")
    if generated_count != 72:
        fail(f"Bilangan aset baharu tidak lengkap: {generated_count} (jangkaan 72).")
    if audio_count != 130:
        fail(f"Bilangan audio runtime berubah tanpa kemas kini manifest: {audio_count} (jangkaan 130).")
    return len(referenced), image_count, generated_count, audio_count


def check_png(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        signature = handle.read(8)
        if signature != b"\x89PNG\r\n\x1a\n":
            fail(f"PNG tidak sah: {path.relative_to(ROOT)}")
        length = struct.unpack(">I", handle.read(4))[0]
        chunk = handle.read(4)
        if chunk != b"IHDR" or length < 8:
            fail(f"IHDR PNG hilang: {path.relative_to(ROOT)}")
        width, height = struct.unpack(">II", handle.read(8))
    if width <= 0 or height <= 0:
        fail(f"Dimensi PNG tidak sah: {path.relative_to(ROOT)}")
    return width, height


def check_binary_assets() -> tuple[int, int]:
    png_files = sorted((ROOT / "assets/images").rglob("*.png"))
    for path in png_files:
        check_png(path)
    for path in sorted((ROOT / "assets/audio").rglob("*.ogg")):
        if path.read_bytes()[:4] != b"OggS":
            fail(f"OGG tidak sah: {path.relative_to(ROOT)}")

    expected_branding = {
        "assets/images/generated/branding/app_icon_512.png": (512, 512),
        "assets/images/generated/branding/skybound_logo.png": (1024, 743),
    }
    for relative, dimensions in expected_branding.items():
        if check_png(ROOT / relative) != dimensions:
            fail(f"Dimensi branding tidak tepat: {relative}")
    expected_store_assets = {
        "store_assets/skybound_quest_app_icon_1024.png": (1024, 1024),
        "store_assets/skybound_quest_logo.png": (1024, 743),
    }
    for relative, dimensions in expected_store_assets.items():
        path = ROOT / relative
        if not path.is_file():
            fail(f"Aset store hilang: {relative}")
        if check_png(path) != dimensions:
            fail(f"Dimensi aset store tidak tepat: {relative}")
    return len(png_files), sum(1 for _ in (ROOT / "assets/audio").rglob("*.ogg"))


def check_android_project() -> int:
    required = (
        "android/settings.gradle",
        "android/build.gradle",
        "android/gradle.properties",
        "android/app/build.gradle",
        "android/app/src/main/AndroidManifest.xml",
        "android/app/src/main/java/com/skybound/quest/MainActivity.java",
        "android/gradle/wrapper/gradle-wrapper.properties",
        "android/gradlew",
        "android/gradlew.bat",
        "android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml",
        "android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml",
        "android/app/src/main/res/values/colors.xml",
        "android/app/src/main/res/values-v31/styles.xml",
        "android/app/src/main/res/values-night-v31/styles.xml",
    )
    for relative in required:
        path = ROOT / relative
        if not path.is_file() or path.stat().st_size == 0:
            fail(f"Fail Android hilang atau kosong: {relative}")

    gradlew = ROOT / "android/gradlew"
    if gradlew.stat().st_mode & 0o111 == 0:
        fail("android/gradlew tidak executable.")

    manifest = (ROOT / "android/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
    if 'android:screenOrientation="sensorLandscape"' not in manifest:
        fail("Orientasi landscape Android tidak ditetapkan.")
    if 'android:icon="@mipmap/ic_launcher"' not in manifest:
        fail("Ikon launcher tidak ditetapkan dalam AndroidManifest.xml.")

    icon_count = 0
    for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
        for icon in (
            "ic_launcher.png",
            "ic_launcher_round.png",
            "ic_launcher_foreground.png",
        ):
            path = ROOT / f"android/app/src/main/res/mipmap-{density}/{icon}"
            if not path.is_file():
                fail(f"Ikon launcher Android hilang: {path.relative_to(ROOT)}")
            check_png(path)
            icon_count += 1

    xml_files = sorted((ROOT / "android/app/src").rglob("*.xml"))
    for path in xml_files:
        try:
            ET.parse(path)
        except ET.ParseError as error:
            fail(f"XML Android tidak sah: {path.relative_to(ROOT)} ({error})")

    wrapper_jar = ROOT / "android/gradle/wrapper/gradle-wrapper.jar"
    if wrapper_jar.exists():
        try:
            with zipfile.ZipFile(wrapper_jar) as archive:
                if "org/gradle/wrapper/GradleWrapperMain.class" not in archive.namelist():
                    fail("Gradle Wrapper JAR tidak mengandungi GradleWrapperMain.")
        except zipfile.BadZipFile:
            fail("Gradle Wrapper JAR rosak.")
    return len(required) + icon_count + len(xml_files)


def check_catalog_ids() -> tuple[int, int]:
    text = (ROOT / "lib/game/data/actor_catalog.dart").read_text(encoding="utf-8")
    actor_ids = re.findall(r"ActorBlueprint\(\s*\n\s*id:\s*'([^']+)'", text)
    skill_ids = re.findall(r"SkillDefinition\(\s*\n\s*id:\s*'([^']+)'", text)
    if len(actor_ids) != len(set(actor_ids)):
        fail("ID actor berulang dalam ActorCatalog.")
    if len(skill_ids) != len(set(skill_ids)):
        fail("ID skill berulang dalam ActorCatalog.")
    if len(actor_ids) != 10:
        fail(f"Katalog sepatutnya mempunyai 10 actor, ditemui {len(actor_ids)}.")
    if len(skill_ids) < 10:
        fail(f"Bilangan skill tidak munasabah: {len(skill_ids)}.")
    return len(actor_ids), len(skill_ids)



def check_level_reachability() -> tuple[float, float, float]:
    arena_text = (ROOT / "lib/game/components/arena_stage.dart").read_text(
        encoding="utf-8"
    )
    hero_text = (ROOT / "lib/game/components/hero_component.dart").read_text(
        encoding="utf-8"
    )
    catalog_text = (ROOT / "lib/game/data/actor_catalog.dart").read_text(
        encoding="utf-8"
    )

    gravity_match = re.search(r"static const gravity = ([0-9.]+);", hero_text)
    jump_match = re.search(r"static const jumpVelocity = -([0-9.]+);", hero_text)
    if gravity_match is None or jump_match is None:
        fail("Hero jump constants were not found.")
    gravity = float(gravity_match.group(1))
    jump_speed = float(jump_match.group(1))
    maximum_height = jump_speed * jump_speed / (2 * gravity)

    hero_catalog = catalog_text.split("static final mimicCube", 1)[0]
    hero_speeds = [
        float(value)
        for value in re.findall(r"moveSpeed:\s*([0-9.]+)", hero_catalog)
    ]
    if len(hero_speeds) != 4:
        fail(f"Expected four hero move speeds, found {len(hero_speeds)}.")
    slowest_speed = min(hero_speeds)

    platforms = [
        tuple(map(float, values))
        for values in re.findall(
            r"Rect\.fromLTWH\((-?[0-9.]+),\s*([0-9.]+),\s*([0-9.]+),\s*([0-9.]+)\)",
            arena_text,
        )
    ]
    by_left = {round(left): (left, top, width, height) for left, top, width, height in platforms}

    def descending_time(rise: float) -> float:
        discriminant = jump_speed * jump_speed - 2 * gravity * rise
        if discriminant < 0:
            fail(
                f"Required platform rise {rise:.1f} exceeds jump height "
                f"{maximum_height:.1f}."
            )
        return (jump_speed + discriminant ** 0.5) / gravity

    ground_top = 390.0
    # None means the platform can be approached directly from ground below it.
    required_chains: list[tuple[int | None, int]] = [
        (None, 315),
        (315, 545),
        (None, 1125),
        (1125, 1310),
        (None, 1700),
        (1700, 1940),
        (1940, 2170),
        (None, 2560),
        (2560, 2810),
    ]
    for source_key, destination_key in required_chains:
        destination = by_left.get(destination_key)
        if destination is None:
            fail(f"Required platform at x={destination_key} is missing.")
        destination_left, destination_top, _, _ = destination
        if source_key is None:
            source_top = ground_top
            horizontal_gap = 0.0
        else:
            source = by_left.get(source_key)
            if source is None:
                fail(f"Required platform at x={source_key} is missing.")
            source_left, source_top, source_width, _ = source
            horizontal_gap = max(0.0, destination_left - (source_left + source_width))
        rise = source_top - destination_top
        reach = slowest_speed * descending_time(rise)
        if horizontal_gap > reach + 0.5:
            fail(
                f"Platform jump {source_key}->{destination_key} needs "
                f"{horizontal_gap:.1f} horizontal units; slowest hero reaches {reach:.1f}."
            )

    ground_segments = sorted(
        (left, left + width)
        for left, top, width, height in platforms
        if abs(top - ground_top) < 0.01 and height >= 90
    )
    same_level_reach = slowest_speed * (2 * jump_speed / gravity)
    maximum_gap = 0.0
    for (_, right), (next_left, _) in zip(ground_segments, ground_segments[1:]):
        gap = max(0.0, next_left - right)
        maximum_gap = max(maximum_gap, gap)
        if gap > same_level_reach + 0.5:
            fail(
                f"Ground gap {gap:.1f} exceeds slowest hero reach "
                f"{same_level_reach:.1f}."
            )
    return maximum_height, same_level_reach, maximum_gap

def check_forbidden_references() -> None:
    merged = "\n".join(path.read_text(encoding="utf-8") for path in DART_FILES)
    for package in ("package:flame_tiled", "package:shared_preferences"):
        if package in merged:
            fail(f"Import dependency tidak digunakan ditemui: {package}")

    hero_text = (ROOT / "lib/game/components/hero_component.dart").read_text(
        encoding="utf-8"
    )
    if "movementAllowed ? input.horizontalAxis : 0;" in hero_text:
        fail("Ralat num/double asal muncul semula dalam hero_component.dart.")
    if "final double axis = movementAllowed ? input.horizontalAxis : 0.0;" not in hero_text:
        fail("Jenis double paksi hero tidak dinyatakan dengan jelas.")

    hud_text = (ROOT / "lib/ui/combat_hud.dart").read_text(encoding="utf-8")
    required_import = (
        "import 'package:flutter/foundation.dart' show ValueListenable;"
    )
    if required_import not in hud_text:
        fail("Import ValueListenable yang diperlukan HUD hilang.")

    game_text = (ROOT / "lib/game/skybound_game.dart").read_text(encoding="utf-8")
    if "bossHealth.value = 1;" in game_text:
        fail("Nilai bossHealth perlu kekal sebagai double eksplisit.")

    obsolete_runtime_icon = (
        ROOT / "assets/images/generated/branding/app_icon_1024.png"
    )
    if obsolete_runtime_icon.exists():
        fail("Ikon 1024px tidak patut dibundle dua kali dalam aset runtime.")


def check_source_hygiene() -> None:
    conflict_markers = ("<<<<<<<", "=======", ">>>>>>>")
    text_files = [
        *DART_FILES,
        ROOT / "pubspec.yaml",
        ROOT / "android/settings.gradle",
        ROOT / "android/app/build.gradle",
        ROOT / "README.md",
        ROOT / "CHANGELOG.md",
        ROOT / "UPGRADE_NOTES.md",
        *sorted((ROOT / "docs").glob("*.md")),
    ]
    for path in text_files:
        text = path.read_text(encoding="utf-8")
        if any(marker in text for marker in conflict_markers):
            fail(f"Merge conflict marker ditemui: {path.relative_to(ROOT)}")
        if "\x00" in text:
            fail(f"Aksara NUL ditemui: {path.relative_to(ROOT)}")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    if "v0.4.0" not in readme or "v0.2.0" in readme:
        fail("README belum dikemas kini untuk v0.4.0.")

def main() -> None:
    version, asset_dirs = check_pubspec()
    import_count = check_imports()
    dart_count = check_delimiters()
    referenced_count, image_count, bundled_image_count, audio_count = check_assets()
    verified_png_count, verified_audio_count = check_binary_assets()
    actor_count, skill_count = check_catalog_ids()
    android_count = check_android_project()
    jump_height, ground_reach, maximum_gap = check_level_reachability()
    check_forbidden_references()
    check_source_hygiene()
    if (verified_png_count, verified_audio_count) != (image_count, audio_count):
        fail("Kiraan pengesahan binari tidak sepadan dengan katalog aset.")

    print("PASS: semakan statik projek selesai")
    print(f"  versi              : {version}")
    print(f"  fail Dart          : {dart_count}")
    print(f"  import disemak     : {import_count}")
    print(f"  aset dirujuk       : {referenced_count}")
    print(f"  imej projek/bundle : {image_count}/{bundled_image_count}")
    print(f"  audio runtime      : {audio_count}")
    print(f"  actor/skill        : {actor_count}/{skill_count}")
    print(f"  fail Android       : {android_count}")
    print(f"  direktori aset     : {len(asset_dirs)}")
    print(f"  jump/reach/gap     : {jump_height:.1f}/{ground_reach:.1f}/{maximum_gap:.1f}")


if __name__ == "__main__":
    main()
