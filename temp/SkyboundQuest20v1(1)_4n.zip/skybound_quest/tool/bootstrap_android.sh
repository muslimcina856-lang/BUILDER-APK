#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK tidak dijumpai. Pasang Flutter 3.41 atau lebih baharu dahulu." >&2
  exit 1
fi

if [[ ! -f android/settings.gradle || ! -f android/app/build.gradle || ! -f android/gradle/wrapper/gradle-wrapper.jar ]]; then
  flutter create --platforms=android --org com.skybound .
fi

./tool/validate_flutter.sh

echo "Projek Android dan APK debug sudah disediakan. Jalankan: flutter run"
