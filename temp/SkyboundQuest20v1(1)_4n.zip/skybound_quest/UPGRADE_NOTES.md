# Nota naik taraf 0.3 → 0.4

## Tujuan

Versi 0.4 memperkayakan encounter Monitor Golem tanpa menambah serangan yang
menipu atau tracking berlebihan. Semua serangan boss mempunyai windup, arah
atau kawasan yang dapat dibaca dan recovery window selepas serangan berat.

## Perubahan boss

| Bahagian | v0.3 | v0.4 |
|---|---|---|
| Serangan jauh | Satu beam projectile | Beam terkunci + barrage tiga arah |
| Serangan area | Slam | Slam + Core Pulse |
| Aiming beam | Sasaran dihitung semasa serangan | Arah disimpan ketika windup |
| Fasa 2 | Buff kelajuan asas | AI sequence, aura, sprite dan VFX khusus |
| HUD | Nama boss dan HP | Fasa, HP dan nama serangan aktif |
| Visual | 2 sprite boss | 6 sprite boss |
| Arena | Platform biasa | Rune, glow dan warna fasa dinamik |

## Fail utama berubah

```text
lib/game/data/actor_catalog.dart
lib/game/components/mob_component.dart
lib/game/components/combat_actor_component.dart
lib/game/components/projectile_component.dart
lib/game/components/combat_effects.dart
lib/game/components/arena_stage.dart
lib/game/skybound_game.dart
lib/ui/combat_hud.dart
assets/images/generated/enemies/monitor_golem_*.png
```

## Prinsip fairness

- Beam tidak tracking selepas dilepaskan.
- Beam hanya digunakan pada jarak sederhana/jauh.
- Telegraph beam menunjukkan arah terkunci dan reticle hujung.
- Core Pulse mempunyai windup panjang dan ring kawasan.
- Aether Barrage mempunyai ruang jelas antara tiga orb.
- Serangan berat mempunyai recovery lebih lama.
- Transisi Fasa 2 memberi invulnerability pendek supaya pertukaran fasa tidak
  terganggu oleh hit berturut-turut.
