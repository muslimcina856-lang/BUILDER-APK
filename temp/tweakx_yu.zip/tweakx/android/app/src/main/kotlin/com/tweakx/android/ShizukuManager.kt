package com.tweakx.android

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Wraps the real Shizuku API (dev.rikka.shizuku:api) to expose availability,
 * permission and lifecycle state to the rest of the app.
 *
 * This is NOT a mock. Every method here calls straight into the Shizuku
 * binder API. If Shizuku is not installed/running, these calls reflect that
 * truthfully instead of pretending success.
 */
object ShizukuManager {

    const val REQUEST_CODE = 1000

    /**
     * True only if the Shizuku binder is alive, i.e. the Shizuku app/service
     * is actually running (started via ADB, wireless debugging, or root).
     */
    fun isAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            // Shizuku.pingBinder() throws if the binder was never received.
            false
        }
    }

    /**
     * True only if this app has been granted the Shizuku permission by the
     * user via the Shizuku manager app. Distinct from isAvailable():
     * Shizuku can be running while permission is still denied.
     */
    fun isPermissionGranted(): Boolean {
        if (!isAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                // Legacy Shizuku (pre v11) used a different permission model
                // exposed only via the manager app; treat as not-yet-supported
                // rather than silently claiming granted.
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (t: Throwable) {
            false
        }
    }

    /**
     * Returns true if the currently running Shizuku predates API v11
     * (the version that introduced the modern runtime permission model).
     * Used to explain unsupported states truthfully instead of failing silently.
     */
    fun isLegacyShizuku(): Boolean {
        if (!isAvailable()) return false
        return try {
            Shizuku.isPreV11()
        } catch (t: Throwable) {
            false
        }
    }

    /**
     * Triggers the real Shizuku permission request dialog. The result is
     * delivered asynchronously via Shizuku.OnRequestPermissionResultListener,
     * which MainActivity registers and forwards back to Flutter.
     */
    fun requestPermission() {
        if (!isAvailable()) {
            throw IllegalStateException("Shizuku is not running")
        }
        if (Shizuku.isPreV11()) {
            throw IllegalStateException(
                "This Shizuku version is too old to support in-app permission requests"
            )
        }
        Shizuku.requestPermission(REQUEST_CODE)
    }

    /**
     * Human-readable status snapshot used by the MethodChannel bridge.
     */
    fun getStatusMap(): Map<String, Any> {
        val available = isAvailable()
        val legacy = if (available) isLegacyShizuku() else false
        val granted = if (available) isPermissionGranted() else false
        return mapOf(
            "available" to available,
            "permissionGranted" to granted,
            "isLegacyVersion" to legacy,
            "shizukuApiVersion" to (if (available) safeApiVersion() else -1)
        )
    }

    private fun safeApiVersion(): Int {
        return try {
            Shizuku.getVersion()
        } catch (t: Throwable) {
            -1
        }
    }
}
