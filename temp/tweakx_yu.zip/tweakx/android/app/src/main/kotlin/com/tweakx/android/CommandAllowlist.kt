package com.tweakx.android

/**
 * Single source of truth for every privileged command TweakX is allowed to
 * run. Inputs are typed and validated before they reach Shizuku.
 */
object CommandAllowlist {
    class InvalidTweakInputException(message: String) : IllegalArgumentException(message)

    fun getBrightness(): List<String> =
        listOf("settings", "get", "system", "screen_brightness")

    fun setBrightness(value: Int): List<String> {
        if (value !in 0..255) throw InvalidTweakInputException("Brightness must be between 0 and 255")
        return listOf("settings", "put", "system", "screen_brightness", value.toString())
    }

    private val allowedTimeoutsMs = setOf(15_000, 30_000, 60_000, 300_000, 600_000)

    fun getScreenTimeout(): List<String> =
        listOf("settings", "get", "system", "screen_off_timeout")

    fun setScreenTimeout(valueMs: Int): List<String> {
        if (valueMs !in allowedTimeoutsMs) {
            throw InvalidTweakInputException("Screen timeout is not supported")
        }
        return listOf("settings", "put", "system", "screen_off_timeout", valueMs.toString())
    }

    private val allowedAnimationScales = setOf(0.0, 0.5, 1.0, 1.5, 2.0)

    enum class AnimationSetting(val key: String) {
        WINDOW("window_animation_scale"),
        TRANSITION("transition_animation_scale"),
        ANIMATOR("animator_duration_scale")
    }

    fun getAnimationScale(setting: AnimationSetting): List<String> =
        listOf("settings", "get", "global", setting.key)

    fun setAnimationScale(setting: AnimationSetting, value: Double): List<String> {
        if (value !in allowedAnimationScales) {
            throw InvalidTweakInputException("Animation scale is not supported")
        }
        return listOf("settings", "put", "global", setting.key, value.toString())
    }

    fun setResolution(width: Int?, height: Int?): List<String> {
        if (width == null || height == null) return listOf("wm", "size", "reset")
        if (width !in 480..3840 || height !in 800..7680) {
            throw InvalidTweakInputException("Resolution is outside the safe range")
        }
        return listOf("wm", "size", "${width}x$height")
    }

    fun setDensity(density: Int): List<String> {
        if (density !in 120..1000) throw InvalidTweakInputException("DPI is outside the safe range")
        return listOf("wm", "density", density.toString())
    }

    fun setRefreshRate(hz: Double?): List<String> {
        if (hz == null) return listOf("settings", "delete", "system", "peak_refresh_rate")
        if (hz !in setOf(60.0, 90.0, 120.0, 144.0)) {
            throw InvalidTweakInputException("Refresh rate is not supported")
        }
        return listOf("settings", "put", "system", "peak_refresh_rate", hz.toString())
    }

    fun setFps(fps: Int?): List<String> {
        if (fps == null) return listOf("settings", "delete", "system", "user_refresh_rate")
        if (fps !in setOf(30, 60, 90, 120, 144)) {
            throw InvalidTweakInputException("FPS is not supported")
        }
        return listOf("settings", "put", "system", "user_refresh_rate", fps.toString())
    }

    fun getRefreshRate(): List<String> = listOf("dumpsys", "display")
    fun getDensity(): List<String> = listOf("wm", "density")
}
