package com.tweakx.android

import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

class TweakBridge(private val windowManager: WindowManager) {
    fun getBrightness(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getBrightness()).toMap()

    fun setBrightness(value: Int): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setBrightness(value)).toMap()
    }

    fun getScreenTimeout(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getScreenTimeout()).toMap()

    fun setScreenTimeout(valueMs: Int): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setScreenTimeout(valueMs)).toMap()
    }

    fun getAnimationScale(setting: String): Map<String, Any> {
        val enumSetting = mapAnimationSetting(setting)
            ?: return failure("Unknown animation setting: $setting")
        return ShizukuCommandExecutor.execute(CommandAllowlist.getAnimationScale(enumSetting)).toMap()
    }

    fun setAnimationScale(setting: String, value: Double): Map<String, Any> {
        val enumSetting = mapAnimationSetting(setting)
            ?: return failure("Unknown animation setting: $setting")
        return safe {
            ShizukuCommandExecutor.execute(CommandAllowlist.setAnimationScale(enumSetting, value)).toMap()
        }
    }

    fun setGameDisplay(width: Int?, height: Int?): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setResolution(width, height)).toMap()
    }

    fun setDensity(density: Int): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setDensity(density)).toMap()
    }

    fun setRefreshRate(hz: Double?): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setRefreshRate(hz)).toMap()
    }

    fun setFps(fps: Int?): Map<String, Any> = safe {
        ShizukuCommandExecutor.execute(CommandAllowlist.setFps(fps)).toMap()
    }

    fun setThermalMode(mode: String): Map<String, Any> =
        failure("Thermal profiles require vendor/root support and are not available through Shizuku")

    fun setTouchMode(mode: String): Map<String, Any> =
        failure("Touch profiles require vendor/root support and are not available through Shizuku")

    private fun mapAnimationSetting(key: String): CommandAllowlist.AnimationSetting? = when (key) {
        "window" -> CommandAllowlist.AnimationSetting.WINDOW
        "transition" -> CommandAllowlist.AnimationSetting.TRANSITION
        "animator" -> CommandAllowlist.AnimationSetting.ANIMATOR
        else -> null
    }

    private fun safe(block: () -> Map<String, Any>): Map<String, Any> {
        return try {
            block()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            failure(e.message ?: "Invalid tweak input")
        }
    }

    private fun failure(message: String): Map<String, Any> = mapOf(
        "success" to false,
        "exitCode" to -1,
        "stdout" to "",
        "stderr" to message,
    )

    fun getDeviceInfo(): Map<String, Any> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        @Suppress("DEPRECATION")
        val refreshRate = windowManager.defaultDisplay.refreshRate
        return mapOf(
            "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
            "androidVersion" to Build.VERSION.RELEASE,
            "sdkInt" to Build.VERSION.SDK_INT,
            "cpuAbi" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
            "widthPx" to metrics.widthPixels,
            "heightPx" to metrics.heightPixels,
            "densityDpi" to metrics.densityDpi,
            "refreshRateHz" to refreshRate,
        )
    }
}
