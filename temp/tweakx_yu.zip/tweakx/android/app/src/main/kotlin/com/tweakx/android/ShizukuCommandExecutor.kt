package com.tweakx.android

import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Executes shell commands through Shizuku's privileged process API
 * (Shizuku.newProcess), NOT through Runtime.exec directly — that would run
 * as the app's own unprivileged UID and defeats the purpose of Shizuku.
 *
 * SECURITY MODEL:
 * This executor is intentionally NOT exposed to Flutter as free-form
 * arbitrary command execution. Callers on the Kotlin side (TweakService
 * equivalents) must build commands from a fixed allowlist of argv arrays
 * (see CommandAllowlist.kt). This class only knows how to run whatever
 * argv array it's given — it performs no shell string interpolation,
 * so there is no shell-injection surface from user-controlled strings.
 *
 * KNOWN CAVEAT (documented honestly, not hidden):
 * Shizuku.newProcess is accessed here via reflection because it is not
 * part of the officially stable public surface in newer dev.rikka.shizuku:api
 * releases — the Shizuku maintainers have signaled intent to eventually
 * remove newProcess in favor of UserService (a more robust, TTY-less
 * mechanism for running privileged code in a separate process). This
 * reflection approach is the same pattern used by other real-world Shizuku
 * consumer apps today and works on current published Shizuku versions,
 * but if a future Shizuku release removes newProcess entirely, this
 * executor would need to be migrated to a UserService-based implementation.
 * The try/catch below already surfaces that failure mode as a normal
 * CommandResult failure rather than crashing.
 */
object ShizukuCommandExecutor {

    data class CommandResult(
        val success: Boolean,
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    ) {
        fun toMap(): Map<String, Any> = mapOf(
            "success" to success,
            "exitCode" to exitCode,
            "stdout" to stdout,
            "stderr" to stderr
        )
    }

    /**
     * Runs [argv] as a privileged process via Shizuku.
     *
     * @param argv command split into program + arguments, e.g.
     *             ["settings", "get", "system", "screen_brightness"].
     *             Never pass a single shell string with unescaped user input.
     */
    fun execute(argv: List<String>): CommandResult {
        if (!ShizukuManager.isAvailable()) {
            return CommandResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku is not running"
            )
        }
        if (!ShizukuManager.isPermissionGranted()) {
            return CommandResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku permission denied"
            )
        }
        if (argv.isEmpty()) {
            return CommandResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = "Empty command"
            )
        }

        return try {
            // Shizuku.newProcess is the documented (reflection-based, but
            // public and stable) entry point exposed by dev.rikka.shizuku:api
            // for running a process with Shizuku's privileges.
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null,
                argv.toTypedArray(),
                null,
                null
            ) as Process

            val stdout = readStream(process.inputStream)
            val stderr = readStream(process.errorStream)
            val exitCode = process.waitFor()

            CommandResult(
                success = exitCode == 0,
                exitCode = exitCode,
                stdout = stdout.trim(),
                stderr = stderr.trim()
            )
        } catch (t: Throwable) {
            CommandResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = "${t.javaClass.simpleName}: ${t.message ?: "unknown error"}"
            )
        }
    }

    private fun readStream(stream: java.io.InputStream): String {
        return BufferedReader(InputStreamReader(stream)).use { reader ->
            reader.readLines().joinToString("\n")
        }
    }
}
