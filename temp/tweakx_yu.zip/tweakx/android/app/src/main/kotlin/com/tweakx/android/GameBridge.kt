package com.tweakx.android

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class GameBridge(private val context: Context) {
    private val prefs = context.getSharedPreferences("tweakx_games", Context.MODE_PRIVATE)
    private val packageManager = context.packageManager
    private val gamesKey = "games"
    private val profilesKey = "profiles"

    fun getInstalledApps(): List<Map<String, Any>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .asSequence()
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
            .map {
                mapOf(
                    "packageName" to it.packageName,
                    "label" to it.loadLabel(packageManager).toString(),
                    "icon" to iconBytes(it.loadIcon(packageManager))
                )
            }
            .toList()
    }

    fun getSavedGames(): List<Map<String, Any>> {
        val saved = JSONArray(prefs.getString(gamesKey, "[]") ?: "[]")
        val result = mutableListOf<Map<String, Any>>()
        for (index in 0 until saved.length()) {
            val item = saved.optJSONObject(index) ?: continue
            val packageName = item.optString("packageName")
            if (packageName.isBlank()) continue
            val appInfo = try {
                packageManager.getApplicationInfo(packageName, 0)
            } catch (_: PackageManager.NameNotFoundException) {
                null
            } ?: continue
            result += mapOf(
                "packageName" to packageName,
                "label" to appInfo.loadLabel(packageManager).toString(),
                "icon" to iconBytes(appInfo.loadIcon(packageManager))
            )
        }
        return result
    }

    fun saveGames(rawGames: List<Map<String, Any?>>) {
        val json = JSONArray()
        rawGames.forEach { game ->
            val packageName = game["packageName"] as? String ?: return@forEach
            val label = game["label"] as? String ?: packageName
            json.put(JSONObject().put("packageName", packageName).put("label", label))
        }
        prefs.edit().putString(gamesKey, json.toString()).apply()
    }

    fun getProfile(packageName: String): Map<String, Any?> {
        val profiles = JSONObject(prefs.getString(profilesKey, "{}") ?: "{}")
        val profile = profiles.optJSONObject(packageName) ?: return emptyMap()
        val result = mutableMapOf<String, Any?>()
        listOf("width", "height", "density", "refreshRate", "fps", "thermalMode", "touchMode", "brightness", "animationScale")
            .forEach { key ->
                if (profile.has(key) && !profile.isNull(key)) result[key] = profile.get(key)
            }
        return result
    }

    fun saveProfile(packageName: String, profile: Map<String, Any?>) {
        val profiles = JSONObject(prefs.getString(profilesKey, "{}") ?: "{}")
        val json = JSONObject()
        profile.forEach { (key, value) -> if (value != null) json.put(key, value) }
        profiles.put(packageName, json)
        prefs.edit().putString(profilesKey, profiles.toString()).apply()
    }

    fun launchGame(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    private fun iconBytes(drawable: Drawable): ByteArray {
        val size = 96
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, size, size)
        drawable.draw(canvas)
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, output)
        return output.toByteArray()
    }
}
