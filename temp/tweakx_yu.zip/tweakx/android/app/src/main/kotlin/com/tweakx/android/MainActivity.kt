package com.tweakx.android

import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import rikka.shizuku.Shizuku

class MainActivity : FlutterActivity() {
    private val shizukuChannelName = "com.tweakx.android/shizuku"
    private val tweakChannelName = "com.tweakx.android/tweak"
    private val deviceChannelName = "com.tweakx.android/device"
    private val gamesChannelName = "com.tweakx.android/games"
    private val shizukuEventChannelName = "com.tweakx.android/shizuku_events"

    private lateinit var tweakBridge: TweakBridge
    private lateinit var gameBridge: GameBridge
    private var eventSink: EventChannel.EventSink? = null

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == ShizukuManager.REQUEST_CODE) {
            runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
        }
    }
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        tweakBridge = TweakBridge(getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
        gameBridge = GameBridge(this)

        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuChannelName)
            .setMethodCallHandler { call, result -> handleShizukuCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, tweakChannelName)
            .setMethodCallHandler { call, result -> handleTweakCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result ->
                try {
                    if (call.method == "getInfo") result.success(tweakBridge.getDeviceInfo())
                    else result.notImplemented()
                } catch (e: Exception) {
                    result.error("DEVICE_ERROR", e.message ?: "Unknown device error", null)
                }
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, gamesChannelName)
            .setMethodCallHandler { call, result -> handleGameCall(call, result) }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuEventChannelName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    eventSink = sink
                    sink?.success(ShizukuManager.getStatusMap())
                }
                override fun onCancel(arguments: Any?) { eventSink = null }
            })
    }

    private fun handleShizukuCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "isAvailable" -> result.success(ShizukuManager.isAvailable())
                "isPermissionGranted" -> result.success(ShizukuManager.isPermissionGranted())
                "requestPermission" -> { ShizukuManager.requestPermission(); result.success(null) }
                "getStatus" -> result.success(ShizukuManager.getStatusMap())
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("SHIZUKU_ERROR", e.message ?: "Unknown Shizuku error", null)
        }
    }

    private fun handleTweakCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getBrightness" -> result.success(tweakBridge.getBrightness())
                "setBrightness" -> result.success(tweakBridge.setBrightness(call.argument<Int>("value") ?: throw IllegalArgumentException("Missing 'value'")))
                "getScreenTimeout" -> result.success(tweakBridge.getScreenTimeout())
                "setScreenTimeout" -> result.success(tweakBridge.setScreenTimeout(call.argument<Int>("valueMs") ?: throw IllegalArgumentException("Missing 'valueMs'")))
                "getAnimationScale" -> result.success(tweakBridge.getAnimationScale(call.argument<String>("setting") ?: throw IllegalArgumentException("Missing 'setting'")))
                "setAnimationScale" -> result.success(tweakBridge.setAnimationScale(
                    call.argument<String>("setting") ?: throw IllegalArgumentException("Missing 'setting'"),
                    call.argument<Double>("value") ?: throw IllegalArgumentException("Missing 'value'"),
                ))
                "setGameDisplay" -> result.success(tweakBridge.setGameDisplay(
                    call.argument<Int>("width"), call.argument<Int>("height"),
                ))
                "setDensity" -> result.success(tweakBridge.setDensity(call.argument<Int>("density") ?: throw IllegalArgumentException("Missing 'density'")))
                "setRefreshRate" -> result.success(tweakBridge.setRefreshRate(call.argument<Double>("hz")))
                "setFps" -> result.success(tweakBridge.setFps(call.argument<Int>("fps")))
                "setThermalMode" -> result.success(tweakBridge.setThermalMode(call.argument<String>("mode") ?: "default"))
                "setTouchMode" -> result.success(tweakBridge.setTouchMode(call.argument<String>("mode") ?: "default"))
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("TWEAK_ERROR", e.message ?: "Unknown tweak error", null)
        }
    }

    private fun handleGameCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getInstalledApps" -> result.success(gameBridge.getInstalledApps())
                "getSavedGames" -> result.success(gameBridge.getSavedGames())
                "saveGames" -> {
                    val games = call.argument<List<Map<String, Any?>>>("games") ?: emptyList()
                    gameBridge.saveGames(games)
                    result.success(null)
                }
                "getProfile" -> result.success(gameBridge.getProfile(call.argument<String>("packageName") ?: ""))
                "saveProfile" -> {
                    gameBridge.saveProfile(
                        call.argument<String>("packageName") ?: throw IllegalArgumentException("Missing 'packageName'"),
                        call.argument<Map<String, Any?>>("profile") ?: emptyMap(),
                    )
                    result.success(null)
                }
                "launchGame" -> result.success(gameBridge.launchGame(call.argument<String>("packageName") ?: ""))
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("GAME_ERROR", e.message ?: "Unknown game error", null)
        }
    }

    override fun onResume() {
        super.onResume()
        eventSink?.success(ShizukuManager.getStatusMap())
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }
}
