import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/command_result.dart';
import '../services/tweak_service.dart';
import '../widgets/command_output.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _tweak = TweakService.instance;
  CommandResult? _debugResult;
  bool _running = false;

  /// Developer-only diagnostic: runs a single read-only allowlisted command
  /// (device density query) and shows raw stdout/stderr/exit code. This is
  /// NOT a free-form command runner — it calls one fixed allowlisted
  /// operation so users can verify their Shizuku setup end-to-end.
  Future<void> _runDiagnostic() async {
    setState(() {
      _running = true;
      _debugResult = null;
    });
    final result = await _tweak.getScreenTimeout();
    if (!mounted) return;
    setState(() {
      _debugResult = result;
      _running = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'TweakX',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Version 1.0.0',
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'TweakX applies Android system tweaks through Shizuku, '
                    'without requiring root access. All tweaks run through '
                    'an allowlist of safe, reversible settings.',
                    style: TextStyle(
                      fontSize: 13,
                      color: AppTheme.textSecondary,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Developer',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppTheme.textSecondary,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Connection Diagnostic',
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Runs a single read-only Shizuku command and shows the raw result, including stack-trace-level error detail.',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: AppTheme.textSecondary,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton(
                    onPressed: _running ? null : _runDiagnostic,
                    child: _running
                        ? const SizedBox(
                            height: 16,
                            width: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Run Diagnostic'),
                  ),
                  if (_debugResult != null) ...[
                    const SizedBox(height: 14),
                    CommandOutput(result: _debugResult!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
