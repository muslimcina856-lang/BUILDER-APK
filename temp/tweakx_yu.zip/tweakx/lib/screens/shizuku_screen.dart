import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/shizuku_status.dart';
import '../services/shizuku_service.dart';
import '../widgets/status_card.dart';

class ShizukuScreen extends StatefulWidget {
  const ShizukuScreen({super.key});

  @override
  State<ShizukuScreen> createState() => _ShizukuScreenState();
}

class _ShizukuScreenState extends State<ShizukuScreen> {
  final _service = ShizukuService.instance;
  ShizukuStatus _status = ShizukuStatus.initial();
  bool _loading = true;
  bool _requesting = false;
  String? _lastError;

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _service.statusStream.listen((status) {
      if (!mounted) return;
      setState(() {
        _status = status;
        _loading = false;
        _requesting = false;
      });
    });
  }

  Future<void> _loadInitial() async {
    final status = await _service.getStatus();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loading = false;
    });
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final status = await _service.getStatus();
    if (!mounted) return;
    setState(() {
      _status = status;
      _loading = false;
    });
  }

  Future<void> _requestPermission() async {
    setState(() {
      _requesting = true;
      _lastError = null;
    });
    final error = await _service.requestPermission();
    if (!mounted) return;
    if (error != null) {
      setState(() {
        _requesting = false;
        _lastError = error;
      });
    }
    // On success, the async permission callback updates status via
    // statusStream — nothing more to do here.
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shizuku')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        color: AppTheme.accent,
        backgroundColor: AppTheme.surface,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: _loading
                  ? const Padding(
                      key: ValueKey('loading'),
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Center(
                        child: CircularProgressIndicator(color: AppTheme.accent),
                      ),
                    )
                  : StatusCard(
                      key: const ValueKey('status'),
                      status: _status,
                      onRefresh: _refresh,
                      onRequestPermission: _requestPermission,
                      isRequesting: _requesting,
                    ),
            ),
            if (_lastError != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.error.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _lastError!,
                  style: const TextStyle(color: AppTheme.error, fontSize: 13),
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text(
              'About Shizuku',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    _InfoRow(
                      icon: Icons.shield_outlined,
                      text:
                          'Shizuku allows this app to perform selected Android operations without root access.',
                    ),
                    SizedBox(height: 12),
                    _InfoRow(
                      icon: Icons.warning_amber_rounded,
                      text:
                          'Not every Android operation is possible without root. TweakX only exposes tweaks that work reliably through Shizuku.',
                    ),
                    SizedBox(height: 12),
                    _InfoRow(
                      icon: Icons.usb_rounded,
                      text:
                          'Shizuku itself must be started using a method your device supports: ADB over USB, wireless debugging, or root.',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _InfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 18, color: AppTheme.textSecondary),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 13,
              color: AppTheme.textSecondary,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }
}
