import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/game_app.dart';
import '../models/shizuku_status.dart';
import '../services/game_service.dart';
import '../services/shizuku_service.dart';
import '../widgets/status_card.dart';
import 'game_settings_screen.dart';
import 'settings_screen.dart';
import 'shizuku_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _shizuku = ShizukuService.instance;
  final _games = GameService.instance;
  ShizukuStatus _status = ShizukuStatus.initial();
  List<GameApp> _gamesList = const [];
  bool _loadingStatus = true;
  bool _loadingGames = true;

  bool get _ready => _status.state == ShizukuState.permissionGranted;

  @override
  void initState() {
    super.initState();
    _shizuku.statusStream.listen((status) {
      if (!mounted) return;
      setState(() {
        _status = status;
        _loadingStatus = false;
      });
    });
    _init();
  }

  Future<void> _init() async {
    final results = await Future.wait([
      _shizuku.getStatus(),
      _games.getSavedGames(),
    ]);
    if (!mounted) return;
    setState(() {
      _status = results[0] as ShizukuStatus;
      _gamesList = results[1] as List<GameApp>;
      _loadingStatus = false;
      _loadingGames = false;
    });
  }

  Future<void> _refresh() async {
    setState(() {
      _loadingStatus = true;
      _loadingGames = true;
    });
    await _init();
  }

  Future<void> _addGame() async {
    final installed = await _games.getInstalledApps();
    if (!mounted) return;
    final selected = await showModalBottomSheet<GameApp>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.surface,
      showDragHandle: true,
      builder: (context) => _AddGameSheet(
        apps: installed,
        existingPackages: _gamesList.map((game) => game.packageName).toSet(),
      ),
    );
    if (selected == null || !mounted) return;
    final updated = [..._gamesList, selected];
    await _games.saveGames(updated);
    if (mounted) setState(() => _gamesList = updated);
  }

  Future<void> _removeGame(GameApp game) async {
    final updated = _gamesList.where((item) => item.packageName != game.packageName).toList();
    await _games.saveGames(updated);
    if (mounted) setState(() => _gamesList = updated);
  }

  void _openGame(GameApp game) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GameSettingsScreen(game: game)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('TX'),
            Text('Game Tuner', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: AppTheme.textSecondary)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addGame,
        backgroundColor: AppTheme.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add game'),
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        color: AppTheme.accent,
        backgroundColor: AppTheme.surface,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ShizukuScreen()),
              ),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: _loadingStatus
                    ? const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Center(
                          child: CircularProgressIndicator(color: AppTheme.accent),
                        ),
                      )
                    : StatusCard(
                        status: _status,
                        onRefresh: _refresh,
                        onRequestPermission: () async {
                          final error = await _shizuku.requestPermission();
                          if (error != null && mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(error)),
                            );
                          }
                        },
                      ),
              ),
            ),
            const SizedBox(height: 28),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Your games', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                      SizedBox(height: 4),
                      Text('Add games manually, then tune before launch.', style: TextStyle(color: AppTheme.textSecondary)),
                    ],
                  ),
                ),
                if (_gamesList.isNotEmpty) Text('${_gamesList.length}', style: const TextStyle(color: AppTheme.accent, fontWeight: FontWeight.w800, fontSize: 18)),
              ],
            ),
            const SizedBox(height: 16),
            if (!_ready) _ShizukuHint(),
            if (_loadingGames)
              const Padding(padding: EdgeInsets.all(36), child: Center(child: CircularProgressIndicator(color: AppTheme.accent)))
            else if (_gamesList.isEmpty)
              _EmptyGames(onAdd: _addGame)
            else
              ..._gamesList.map((game) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Dismissible(
                      key: ValueKey(game.packageName),
                      direction: DismissDirection.endToStart,
                      confirmDismiss: (_) async => true,
                      onDismissed: (_) => _removeGame(game),
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 22),
                        decoration: BoxDecoration(color: AppTheme.error, borderRadius: BorderRadius.circular(20)),
                        child: const Icon(Icons.delete_outline, color: Colors.white),
                      ),
                      child: _GameTile(game: game, onTap: () => _openGame(game)),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  final GameApp game;
  final VoidCallback onTap;
  const _GameTile({required this.game, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              _AppIcon(game: game),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text('Tap to configure profile', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12))])),
              const Icon(Icons.tune_rounded, color: AppTheme.accent),
            ]),
          ),
        ),
      );
}

class _AppIcon extends StatelessWidget {
  final GameApp game;
  const _AppIcon({required this.game});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: game.icon == null
            ? Container(width: 58, height: 58, color: AppTheme.surfaceVariant, child: const Icon(Icons.sports_esports_outlined, color: AppTheme.accent))
            : Image.memory(game.icon!, width: 58, height: 58, fit: BoxFit.cover),
      );
}

class _EmptyGames extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyGames({required this.onAdd});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 34, 24, 30),
          child: Column(children: [
            Container(width: 68, height: 68, decoration: BoxDecoration(color: AppTheme.accent.withValues(alpha: .12), shape: BoxShape.circle), child: const Icon(Icons.sports_esports_rounded, color: AppTheme.accent, size: 32)),
            const SizedBox(height: 16),
            const Text('No games added yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text('Your library stays clean until you choose the games you want to tune.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, height: 1.4)),
            const SizedBox(height: 18),
            OutlinedButton.icon(onPressed: onAdd, icon: const Icon(Icons.add_rounded), label: const Text('Choose installed game')),
          ]),
        ),
      );
}

class _ShizukuHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.orangeAccent.withValues(alpha: .08), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.orangeAccent.withValues(alpha: .22))),
        child: const Row(children: [Icon(Icons.info_outline, color: Colors.orangeAccent), SizedBox(width: 10), Expanded(child: Text('You can add games now. Start and grant Shizuku before using Save & Launch to apply tweaks.', style: TextStyle(color: AppTheme.textSecondary, height: 1.35)))]),
      );
}

class _AddGameSheet extends StatefulWidget {
  final List<GameApp> apps;
  final Set<String> existingPackages;
  const _AddGameSheet({required this.apps, required this.existingPackages});
  @override
  State<_AddGameSheet> createState() => _AddGameSheetState();
}

class _AddGameSheetState extends State<_AddGameSheet> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final apps = widget.apps.where((app) => !widget.existingPackages.contains(app.packageName) && (query.isEmpty || app.label.toLowerCase().contains(query.toLowerCase()))).toList();
    return SafeArea(
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .78,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(children: [
            const Align(alignment: Alignment.centerLeft, child: Text('Add a game', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
            const SizedBox(height: 12),
            TextField(onChanged: (value) => setState(() => query = value), decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search installed apps')),
            const SizedBox(height: 12),
            Expanded(child: apps.isEmpty ? const Center(child: Text('No matching apps available.', style: TextStyle(color: AppTheme.textSecondary))) : ListView.separated(itemCount: apps.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, index) { final app = apps[index]; return Card(child: ListTile(onTap: () => Navigator.pop(context, app), leading: _AppIcon(game: app), title: Text(app.label), subtitle: Text(app.packageName, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: const Icon(Icons.add_circle_outline, color: AppTheme.accent))); })),
          ]),
        ),
      ),
    );
  }
}
