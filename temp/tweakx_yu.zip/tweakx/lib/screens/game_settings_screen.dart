import 'package:flutter/material.dart';
import '../core/constants/tweak_options.dart';
import '../core/theme/app_theme.dart';
import '../models/command_result.dart';
import '../models/game_app.dart';
import '../models/game_profile.dart';
import '../services/game_service.dart';
import '../services/tweak_service.dart';

class GameSettingsScreen extends StatefulWidget {
  final GameApp game;
  const GameSettingsScreen({super.key, required this.game});

  @override
  State<GameSettingsScreen> createState() => _GameSettingsScreenState();
}

class _GameSettingsScreenState extends State<GameSettingsScreen> {
  final _games = GameService.instance;
  final _tweak = TweakService.instance;
  GameProfile _profile = const GameProfile();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final profile = await _games.getProfile(widget.game.packageName);
    if (!mounted) return;
    setState(() {
      _profile = profile;
      _loading = false;
    });
  }

  Future<bool> _applyProfile() async {
    final results = <CommandResult>[];
    if (_profile.width != null || _profile.height != null) {
      if (_profile.width == null || _profile.height == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Set both resolution width and height, or clear both.')),
          );
        }
        return false;
      }
      results.add(await _tweak.setGameDisplay(
        width: _profile.width,
        height: _profile.height,
      ));
    }
    if (_profile.density != null) {
      results.add(await _tweak.setDensity(_profile.density));
    }
    if (_profile.refreshRate != null) {
      results.add(await _tweak.setRefreshRate(_profile.refreshRate));
    }
    if (_profile.fps != null) {
      results.add(await _tweak.setFps(_profile.fps));
    }
    results.add(await _tweak.setBrightness(_profile.brightness));
    for (final setting in ['window', 'transition', 'animator']) {
      results.add(await _tweak.setAnimationScale(setting, _profile.animationScale));
    }
    final failures = results.where((result) => !result.success).toList();
    final failed = failures.isEmpty ? null : failures.first;
    if (failed == null) return true;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(failed.humanError)),
      );
    }
    return false;
  }

  Future<void> _save({required bool launch}) async {
    setState(() => _saving = true);
    await _games.saveProfile(widget.game.packageName, _profile);
    final applied = await _applyProfile();
    if (applied && launch) await _games.launchGame(widget.game.packageName);
    if (!mounted) return;
    setState(() => _saving = false);
    if (applied && launch) Navigator.of(context).pop();
    if (applied && !launch) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Game profile saved and applied')),
      );
    }
  }

  void _update(GameProfile profile) => setState(() => _profile = profile);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.game.label),
        actions: [
          IconButton(
            tooltip: 'Save profile',
            onPressed: _saving ? null : () => _save(launch: false),
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: FilledButton.icon(
          onPressed: _loading || _saving ? null : () => _save(launch: true),
          icon: _saving
              ? const SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                )
              : const Icon(Icons.play_arrow_rounded),
          label: Text(_saving ? 'Applying…' : 'Save & Launch'),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.accent))
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
              children: [
                _GameHero(game: widget.game),
                const SizedBox(height: 20),
                _GroupTitle('Display'),
                _NumberField(
                  label: 'Resolution width',
                  hint: 'e.g. 1080 (leave blank for default)',
                  value: _profile.width?.toString() ?? '',
                  onChanged: (value) => _update(value.trim().isEmpty ? _profile.copyWith(clearWidth: true) : _profile.copyWith(width: int.tryParse(value))),
                ),
                _NumberField(
                  label: 'Resolution height',
                  hint: 'e.g. 2400 (leave blank for default)',
                  value: _profile.height?.toString() ?? '',
                  onChanged: (value) => _update(value.trim().isEmpty ? _profile.copyWith(clearHeight: true) : _profile.copyWith(height: int.tryParse(value))),
                ),
                _NumberField(
                  label: 'DPI',
                  hint: '120–1000 (leave blank for default)',
                  value: _profile.density?.toString() ?? '',
                  onChanged: (value) => _update(value.trim().isEmpty ? _profile.copyWith(clearDensity: true) : _profile.copyWith(density: int.tryParse(value))),
                ),
                _ChoiceSetting<double>(
                  icon: Icons.refresh_rounded,
                  title: 'Refresh rate',
                  value: _profile.refreshRate,
                  values: const [null, 60.0, 90.0, 120.0, 144.0],
                  label: (value) => value == null ? 'Default' : '${value.toInt()} Hz',
                  onChanged: (value) => _update(value == null ? _profile.copyWith(clearRefreshRate: true) : _profile.copyWith(refreshRate: value)),
                ),
                _ChoiceSetting<int>(
                  icon: Icons.speed_rounded,
                  title: 'FPS target',
                  value: _profile.fps,
                  values: const [null, 30, 60, 90, 120, 144],
                  label: (value) => value == null ? 'Default' : '$value FPS',
                  onChanged: (value) => _update(value == null ? _profile.copyWith(clearFps: true) : _profile.copyWith(fps: value)),
                ),
                const SizedBox(height: 20),
                _GroupTitle('Experience'),
                _SliderSetting(
                  icon: Icons.brightness_6_outlined,
                  title: 'Brightness',
                  value: _profile.brightness.toDouble(),
                  min: TweakOptions.brightnessMin.toDouble(),
                  max: TweakOptions.brightnessMax.toDouble(),
                  valueLabel: '${_profile.brightness}',
                  onChanged: (value) => _update(_profile.copyWith(brightness: value.round())),
                ),
                _ChoiceSetting<double>(
                  icon: Icons.motion_photos_on_outlined,
                  title: 'Animation scale',
                  value: _profile.animationScale,
                  values: TweakOptions.animationScales,
                  label: (value) => '${value}x',
                  onChanged: (value) => _update(_profile.copyWith(animationScale: value)),
                ),
                _UnsupportedSetting(title: 'Thermal', icon: Icons.thermostat_outlined),
                _UnsupportedSetting(title: 'Touch response', icon: Icons.touch_app_outlined),
                const SizedBox(height: 12),
                Text(
                  'Resolution, DPI, refresh rate, FPS, brightness, and animation scale are applied through Shizuku. Thermal and touch controls depend on manufacturer/root-only interfaces and stay safely unavailable.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.textSecondary, height: 1.4),
                ),
              ],
            ),
    );
  }
}

class _GameHero extends StatelessWidget {
  final GameApp game;
  const _GameHero({required this.game});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            _AppIcon(game: game, size: 62),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(game.label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(game.packageName, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupTitle extends StatelessWidget {
  final String title;
  const _GroupTitle(this.title);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 10),
        child: Text(title.toUpperCase(), style: const TextStyle(color: AppTheme.accent, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
      );
}

class _NumberField extends StatelessWidget {
  final String label;
  final String hint;
  final String value;
  final ValueChanged<String> onChanged;
  const _NumberField({required this.label, required this.hint, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextFormField(
          initialValue: value,
          keyboardType: TextInputType.number,
          onChanged: onChanged,
          decoration: InputDecoration(labelText: label, hintText: hint, prefixIcon: const Icon(Icons.tune_rounded)),
        ),
      );
}

class _ChoiceSetting<T> extends StatelessWidget {
  final IconData icon;
  final String title;
  final T? value;
  final List<T?> values;
  final String Function(T?) label;
  final ValueChanged<T?> onChanged;
  const _ChoiceSetting({required this.icon, required this.title, required this.value, required this.values, required this.label, required this.onChanged});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: AppTheme.accent, size: 20), const SizedBox(width: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.w700))]),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: values.map((item) => ChoiceChip(label: Text(label(item)), selected: value == item, onSelected: (_) => onChanged(item))).toList()),
          ]),
        ),
      );
}

class _SliderSetting extends StatelessWidget {
  final IconData icon;
  final String title;
  final double value;
  final double min;
  final double max;
  final String valueLabel;
  final ValueChanged<double> onChanged;
  const _SliderSetting({required this.icon, required this.title, required this.value, required this.min, required this.max, required this.valueLabel, required this.onChanged});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Column(children: [
            Row(children: [Icon(icon, color: AppTheme.accent, size: 20), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))), Text(valueLabel, style: const TextStyle(color: AppTheme.accent, fontWeight: FontWeight.w700))]),
            Slider(value: value.clamp(min, max), min: min, max: max, onChanged: onChanged),
          ]),
        ),
      );
}

class _UnsupportedSetting extends StatelessWidget {
  final String title;
  final IconData icon;
  const _UnsupportedSetting({required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(leading: Icon(icon, color: AppTheme.textSecondary), title: Text(title), subtitle: const Text('Not available on this device through Shizuku'), trailing: const Icon(Icons.lock_outline, color: AppTheme.textSecondary)),
      );
}

class _AppIcon extends StatelessWidget {
  final GameApp game;
  final double size;
  const _AppIcon({required this.game, required this.size});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(size * .22),
        child: game.icon == null
            ? Container(width: size, height: size, color: AppTheme.surfaceVariant, child: const Icon(Icons.sports_esports_outlined, color: AppTheme.accent))
            : Image.memory(game.icon!, width: size, height: size, fit: BoxFit.cover),
      );
}
