import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'screens/home_screen.dart';

class TweakXApp extends StatelessWidget {
  const TweakXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TweakX',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      home: const HomeScreen(),
    );
  }
}
