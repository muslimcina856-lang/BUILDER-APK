import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

/// Generic card shell: icon, title, description, current value, and a
/// caller-supplied control widget (slider, segmented button, etc).
class TweakCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final String? currentValueLabel;
  final Widget control;
  final bool enabled;
  final String? disabledReason;

  const TweakCard({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    required this.control,
    this.currentValueLabel,
    this.enabled = true,
    this.disabledReason,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1.0 : 0.5,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.accent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(icon, color: AppTheme.accent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          description,
                          style: const TextStyle(
                            fontSize: 12.5,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (currentValueLabel != null)
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        currentValueLabel!,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.accent,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              AbsorbPointer(
                absorbing: !enabled,
                child: control,
              ),
              if (!enabled && disabledReason != null) ...[
                const SizedBox(height: 8),
                Text(
                  disabledReason!,
                  style: const TextStyle(
                    fontSize: 11.5,
                    color: AppTheme.error,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
