import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/command_result.dart';

/// Displays raw stdout/stderr from a CommandResult. Used on a
/// developer/debug surface — regular tweak cards show only the
/// human-readable error (see CommandResult.humanError).
class CommandOutput extends StatelessWidget {
  final CommandResult result;

  const CommandOutput({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: result.success
              ? AppTheme.accent.withValues(alpha: 0.3)
              : AppTheme.error.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                result.success
                    ? Icons.check_circle_outline_rounded
                    : Icons.error_outline_rounded,
                size: 16,
                color: result.success ? AppTheme.accent : AppTheme.error,
              ),
              const SizedBox(width: 6),
              Text(
                'exit code: ${result.exitCode}',
                style: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 12,
                  color: result.success ? AppTheme.accent : AppTheme.error,
                ),
              ),
            ],
          ),
          if (result.stdout.isNotEmpty) ...[
            const SizedBox(height: 8),
            SelectableText(
              result.stdout,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                color: AppTheme.textPrimary,
              ),
            ),
          ],
          if (result.stderr.isNotEmpty) ...[
            const SizedBox(height: 8),
            SelectableText(
              result.stderr,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                color: AppTheme.error,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
