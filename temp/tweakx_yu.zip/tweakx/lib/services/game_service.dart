import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/game_app.dart';
import '../models/game_profile.dart';

class GameService {
  GameService._internal();

  static final GameService instance = GameService._internal();
  static const MethodChannel _channel = MethodChannel(Channels.games);

  Future<List<GameApp>> getInstalledApps() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('getInstalledApps');
      return (raw ?? [])
          .map((item) => GameApp.fromMap(Map<dynamic, dynamic>.from(item as Map)))
          .where((app) => app.packageName.isNotEmpty)
          .toList();
    } on PlatformException {
      return const [];
    } on MissingPluginException {
      return const [];
    }
  }

  Future<List<GameApp>> getSavedGames() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('getSavedGames');
      return (raw ?? [])
          .map((item) => GameApp.fromMap(Map<dynamic, dynamic>.from(item as Map)))
          .where((app) => app.packageName.isNotEmpty)
          .toList();
    } on PlatformException {
      return const [];
    } on MissingPluginException {
      return const [];
    }
  }

  Future<void> saveGames(List<GameApp> games) {
    return _channel.invokeMethod<void>('saveGames', {
      'games': games
          .map((game) => {
                'packageName': game.packageName,
                'label': game.label,
              })
          .toList(),
    });
  }

  Future<GameProfile> getProfile(String packageName) async {
    try {
      final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getProfile',
        {'packageName': packageName},
      );
      return GameProfile.fromMap(raw);
    } on PlatformException {
      return const GameProfile();
    }
  }

  Future<void> saveProfile(String packageName, GameProfile profile) {
    return _channel.invokeMethod<void>('saveProfile', {
      'packageName': packageName,
      'profile': profile.toMap(),
    });
  }

  Future<bool> launchGame(String packageName) async {
    try {
      return await _channel.invokeMethod<bool>(
            'launchGame',
            {'packageName': packageName},
          ) ??
          false;
    } on PlatformException {
      return false;
    }
  }
}
