class DeviceInfo {
  final String manufacturer;
  final String model;
  final String androidVersion;
  final int sdkInt;
  final String cpuAbi;
  final int widthPx;
  final int heightPx;
  final int densityDpi;
  final double refreshRateHz;

  const DeviceInfo({
    required this.manufacturer,
    required this.model,
    required this.androidVersion,
    required this.sdkInt,
    required this.cpuAbi,
    required this.widthPx,
    required this.heightPx,
    required this.densityDpi,
    required this.refreshRateHz,
  });

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> map) {
    return DeviceInfo(
      manufacturer: map['manufacturer'] as String? ?? 'Unknown',
      model: map['model'] as String? ?? 'Unknown',
      androidVersion: map['androidVersion'] as String? ?? 'Unknown',
      sdkInt: map['sdkInt'] as int? ?? 0,
      cpuAbi: map['cpuAbi'] as String? ?? 'Unknown',
      widthPx: map['widthPx'] as int? ?? 0,
      heightPx: map['heightPx'] as int? ?? 0,
      densityDpi: map['densityDpi'] as int? ?? 0,
      refreshRateHz: (map['refreshRateHz'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
