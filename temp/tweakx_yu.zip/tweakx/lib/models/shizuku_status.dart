enum ShizukuState {
  unavailable,
  availableNoPermission,
  permissionGranted,
  legacyUnsupported,
  unknown,
}

class ShizukuStatus {
  final bool available;
  final bool permissionGranted;
  final bool isLegacyVersion;
  final int apiVersion;

  const ShizukuStatus({
    required this.available,
    required this.permissionGranted,
    required this.isLegacyVersion,
    required this.apiVersion,
  });

  factory ShizukuStatus.fromMap(Map<dynamic, dynamic> map) {
    return ShizukuStatus(
      available: map['available'] as bool? ?? false,
      permissionGranted: map['permissionGranted'] as bool? ?? false,
      isLegacyVersion: map['isLegacyVersion'] as bool? ?? false,
      apiVersion: map['shizukuApiVersion'] as int? ?? -1,
    );
  }

  factory ShizukuStatus.initial() => const ShizukuStatus(
        available: false,
        permissionGranted: false,
        isLegacyVersion: false,
        apiVersion: -1,
      );

  ShizukuState get state {
    if (!available) return ShizukuState.unavailable;
    if (isLegacyVersion) return ShizukuState.legacyUnsupported;
    if (!permissionGranted) return ShizukuState.availableNoPermission;
    return ShizukuState.permissionGranted;
  }

  String get humanMessage {
    switch (state) {
      case ShizukuState.unavailable:
        return 'Shizuku is not running. Start it via ADB, wireless debugging, or root, then refresh.';
      case ShizukuState.legacyUnsupported:
        return 'Installed Shizuku version is too old and is not supported by TweakX.';
      case ShizukuState.availableNoPermission:
        return 'Shizuku is running but permission has not been granted yet.';
      case ShizukuState.permissionGranted:
        return 'Shizuku is running and permission is granted.';
      case ShizukuState.unknown:
        return 'Shizuku status is unknown.';
    }
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ShizukuStatus &&
          runtimeType == other.runtimeType &&
          available == other.available &&
          permissionGranted == other.permissionGranted &&
          isLegacyVersion == other.isLegacyVersion &&
          apiVersion == other.apiVersion;

  @override
  int get hashCode =>
      Object.hash(available, permissionGranted, isLegacyVersion, apiVersion);
}
