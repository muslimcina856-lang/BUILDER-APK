import 'dart:typed_data';

class GameApp {
  final String packageName;
  final String label;
  final Uint8List? icon;

  const GameApp({
    required this.packageName,
    required this.label,
    this.icon,
  });

  factory GameApp.fromMap(Map<dynamic, dynamic> map) {
    final rawIcon = map['icon'];
    return GameApp(
      packageName: map['packageName'] as String? ?? '',
      label: map['label'] as String? ?? 'Unknown app',
      icon: rawIcon is Uint8List
          ? rawIcon
          : rawIcon is List<int>
              ? Uint8List.fromList(rawIcon)
              : null,
    );
  }
}
