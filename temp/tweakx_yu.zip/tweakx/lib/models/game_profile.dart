class GameProfile {
  final int? width;
  final int? height;
  final int? density;
  final double? refreshRate;
  final int? fps;
  final String thermalMode;
  final String touchMode;
  final int brightness;
  final double animationScale;

  const GameProfile({
    this.width,
    this.height,
    this.density,
    this.refreshRate,
    this.fps,
    this.thermalMode = 'default',
    this.touchMode = 'default',
    this.brightness = 180,
    this.animationScale = 1.0,
  });

  GameProfile copyWith({
    int? width,
    int? height,
    int? density,
    double? refreshRate,
    int? fps,
    String? thermalMode,
    String? touchMode,
    int? brightness,
    double? animationScale,
    bool clearWidth = false,
    bool clearHeight = false,
    bool clearDensity = false,
    bool clearRefreshRate = false,
    bool clearFps = false,
  }) {
    return GameProfile(
      width: clearWidth ? null : (width ?? this.width),
      height: clearHeight ? null : (height ?? this.height),
      density: clearDensity ? null : (density ?? this.density),
      refreshRate: clearRefreshRate ? null : (refreshRate ?? this.refreshRate),
      fps: clearFps ? null : (fps ?? this.fps),
      thermalMode: thermalMode ?? this.thermalMode,
      touchMode: touchMode ?? this.touchMode,
      brightness: brightness ?? this.brightness,
      animationScale: animationScale ?? this.animationScale,
    );
  }

  Map<String, dynamic> toMap() => {
        'width': width,
        'height': height,
        'density': density,
        'refreshRate': refreshRate,
        'fps': fps,
        'thermalMode': thermalMode,
        'touchMode': touchMode,
        'brightness': brightness,
        'animationScale': animationScale,
      };

  factory GameProfile.fromMap(Map<dynamic, dynamic>? map) {
    if (map == null) return const GameProfile();
    return GameProfile(
      width: (map['width'] as num?)?.toInt(),
      height: (map['height'] as num?)?.toInt(),
      density: (map['density'] as num?)?.toInt(),
      refreshRate: (map['refreshRate'] as num?)?.toDouble(),
      fps: (map['fps'] as num?)?.toInt(),
      thermalMode: map['thermalMode'] as String? ?? 'default',
      touchMode: map['touchMode'] as String? ?? 'default',
      brightness: (map['brightness'] as num?)?.toInt() ?? 180,
      animationScale: (map['animationScale'] as num?)?.toDouble() ?? 1.0,
    );
  }
}
