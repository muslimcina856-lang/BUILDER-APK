/// Maps directly to the JSON object returned by ShizukuCommandExecutor on
/// the Kotlin side: {success, exitCode, stdout, stderr}.
class CommandResult {
  final bool success;
  final int exitCode;
  final String stdout;
  final String stderr;

  const CommandResult({
    required this.success,
    required this.exitCode,
    required this.stdout,
    required this.stderr,
  });

  factory CommandResult.fromMap(Map<dynamic, dynamic> map) {
    return CommandResult(
      success: map['success'] as bool? ?? false,
      exitCode: map['exitCode'] as int? ?? -1,
      stdout: map['stdout'] as String? ?? '',
      stderr: map['stderr'] as String? ?? '',
    );
  }

  factory CommandResult.failure(String message) => CommandResult(
        success: false,
        exitCode: -1,
        stdout: '',
        stderr: message,
      );

  /// Translates common native error strings into user-facing messages.
  /// Raw stderr is still available for a debug/developer view.
  String get humanError {
    if (success) return '';
    final s = stderr.toLowerCase();
    if (s.contains('not running')) {
      return 'Shizuku is not running. Please start Shizuku and try again.';
    }
    if (s.contains('permission denied')) {
      return 'Permission was denied. Grant Shizuku permission in the Shizuku tab.';
    }
    if (s.contains('securityexception')) {
      return 'The system blocked this operation (SecurityException).';
    }
    if (s.contains('remoteexception')) {
      return 'Lost connection to the Shizuku service (RemoteException).';
    }
    if (s.contains('service disconnected') || s.contains('binder')) {
      return 'Shizuku service disconnected. Please refresh and try again.';
    }
    if (stderr.isEmpty) {
      return 'Command failed with exit code $exitCode.';
    }
    return 'Command failed: $stderr';
  }
}
