import 'package:flutter/material.dart';

enum TweakCategory { display, performance, system, device }

/// Lightweight descriptor used purely for rendering home screen cards.
/// The actual read/write logic always goes through TweakService — this
/// class carries no behavior of its own, only presentation metadata.
class TweakItem {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final TweakCategory category;

  const TweakItem({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.category,
  });
}
