/// Mirrors the allowlisted values defined natively in
/// android/.../CommandAllowlist.kt. Keeping these in sync means the UI never
/// offers a value the native layer would reject.
class TweakOptions {
  TweakOptions._();

  static const List<double> animationScales = [0.0, 0.5, 1.0, 1.5, 2.0];

  static const Map<int, String> screenTimeouts = {
    15000: '15 seconds',
    30000: '30 seconds',
    60000: '1 minute',
    300000: '5 minutes',
    600000: '10 minutes',
  };

  static const int brightnessMin = 0;
  static const int brightnessMax = 255;
}
