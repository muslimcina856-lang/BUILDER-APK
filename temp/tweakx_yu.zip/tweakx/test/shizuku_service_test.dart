import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/services/shizuku_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const shizukuChannel = MethodChannel('com.tweakx.android/shizuku');

  final service = ShizukuService.instance;

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(shizukuChannel, null);
  });

  group('ShizukuService.isAvailable', () {
    test('returns true when native side reports availability', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        expect(call.method, 'isAvailable');
        return true;
      });

      final result = await service.isAvailable();
      expect(result, isTrue);
    });

    test('returns false when a PlatformException is thrown', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        throw PlatformException(code: 'SHIZUKU_ERROR');
      });

      final result = await service.isAvailable();
      expect(result, isFalse);
    });
  });

  group('ShizukuService.isPermissionGranted', () {
    test('returns the native boolean value', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        expect(call.method, 'isPermissionGranted');
        return false;
      });

      final result = await service.isPermissionGranted();
      expect(result, isFalse);
    });
  });

  group('ShizukuService.getStatus', () {
    test('parses a full status map from native side', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        return {
          'available': true,
          'permissionGranted': true,
          'isLegacyVersion': false,
          'shizukuApiVersion': 13,
        };
      });

      final status = await service.getStatus();
      expect(status.available, isTrue);
      expect(status.permissionGranted, isTrue);
      expect(status.apiVersion, 13);
    });

    test('returns initial status on PlatformException', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        throw PlatformException(code: 'SHIZUKU_ERROR');
      });

      final status = await service.getStatus();
      expect(status.available, isFalse);
    });
  });

  group('ShizukuService.requestPermission', () {
    test('returns null on success', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        expect(call.method, 'requestPermission');
        return null;
      });

      final error = await service.requestPermission();
      expect(error, isNull);
    });

    test('returns the error message on failure', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(shizukuChannel, (call) async {
        throw PlatformException(
          code: 'SHIZUKU_ERROR',
          message: 'Shizuku is not running',
        );
      });

      final error = await service.requestPermission();
      expect(error, 'Shizuku is not running');
    });
  });
}
