import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/services/tweak_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const tweakChannel = MethodChannel('com.tweakx.android/tweak');
  const deviceChannel = MethodChannel('com.tweakx.android/device');

  final service = TweakService.instance;

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(tweakChannel, null);
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(deviceChannel, null);
  });

  group('TweakService brightness', () {
    test('getBrightness returns a successful CommandResult from native side',
        () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(tweakChannel, (call) async {
        expect(call.method, 'getBrightness');
        return {
          'success': true,
          'exitCode': 0,
          'stdout': '180',
          'stderr': '',
        };
      });

      final result = await service.getBrightness();
      expect(result.success, isTrue);
      expect(result.stdout, '180');
    });

    test('setBrightness forwards the value argument', () async {
      int? receivedValue;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(tweakChannel, (call) async {
        receivedValue = call.arguments['value'] as int;
        return {
          'success': true,
          'exitCode': 0,
          'stdout': '',
          'stderr': '',
        };
      });

      await service.setBrightness(200);
      expect(receivedValue, 200);
    });

    test('surfaces a PlatformException as a failed CommandResult', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(tweakChannel, (call) async {
        throw PlatformException(
          code: 'TWEAK_ERROR',
          message: 'Shizuku permission denied',
        );
      });

      final result = await service.setBrightness(100);
      expect(result.success, isFalse);
      expect(result.stderr, contains('permission denied'));
    });
  });

  group('TweakService animation scale', () {
    test('setAnimationScale forwards setting and value', () async {
      Map<dynamic, dynamic>? receivedArgs;
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(tweakChannel, (call) async {
        receivedArgs = call.arguments as Map;
        return {
          'success': true,
          'exitCode': 0,
          'stdout': '',
          'stderr': '',
        };
      });

      await service.setAnimationScale('window', 0.5);
      expect(receivedArgs?['setting'], 'window');
      expect(receivedArgs?['value'], 0.5);
    });
  });

  group('TweakService device info', () {
    test('getDeviceInfo parses a full map from native side', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(deviceChannel, (call) async {
        expect(call.method, 'getInfo');
        return {
          'manufacturer': 'Google',
          'model': 'Pixel 8',
          'androidVersion': '15',
          'sdkInt': 35,
          'cpuAbi': 'arm64-v8a',
          'widthPx': 1080,
          'heightPx': 2400,
          'densityDpi': 420,
          'refreshRateHz': 120.0,
        };
      });

      final info = await service.getDeviceInfo();
      expect(info, isNotNull);
      expect(info!.manufacturer, 'Google');
      expect(info.sdkInt, 35);
      expect(info.refreshRateHz, 120.0);
    });

    test('getDeviceInfo returns null on PlatformException', () async {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(deviceChannel, (call) async {
        throw PlatformException(code: 'DEVICE_ERROR');
      });

      final info = await service.getDeviceInfo();
      expect(info, isNull);
    });
  });
}
