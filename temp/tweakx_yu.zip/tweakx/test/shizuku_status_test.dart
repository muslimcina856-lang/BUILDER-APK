import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/models/shizuku_status.dart';

void main() {
  group('ShizukuStatus.fromMap', () {
    test('parses a fully granted status', () {
      final status = ShizukuStatus.fromMap({
        'available': true,
        'permissionGranted': true,
        'isLegacyVersion': false,
        'shizukuApiVersion': 13,
      });

      expect(status.available, isTrue);
      expect(status.permissionGranted, isTrue);
      expect(status.state, ShizukuState.permissionGranted);
    });

    test('parses an unavailable status', () {
      final status = ShizukuStatus.fromMap({
        'available': false,
        'permissionGranted': false,
        'isLegacyVersion': false,
        'shizukuApiVersion': -1,
      });

      expect(status.state, ShizukuState.unavailable);
    });

    test('parses available-but-no-permission status', () {
      final status = ShizukuStatus.fromMap({
        'available': true,
        'permissionGranted': false,
        'isLegacyVersion': false,
        'shizukuApiVersion': 13,
      });

      expect(status.state, ShizukuState.availableNoPermission);
    });

    test('parses legacy unsupported status', () {
      final status = ShizukuStatus.fromMap({
        'available': true,
        'permissionGranted': false,
        'isLegacyVersion': true,
        'shizukuApiVersion': 5,
      });

      expect(status.state, ShizukuState.legacyUnsupported);
    });

    test('falls back to safe defaults on missing keys', () {
      final status = ShizukuStatus.fromMap({});
      expect(status.available, isFalse);
      expect(status.state, ShizukuState.unavailable);
    });
  });

  group('ShizukuStatus.humanMessage', () {
    test('gives a distinct, non-empty message for every state', () {
      final messages = <String>{};
      for (final available in [true, false]) {
        for (final granted in [true, false]) {
          for (final legacy in [true, false]) {
            final status = ShizukuStatus(
              available: available,
              permissionGranted: granted,
              isLegacyVersion: legacy,
              apiVersion: available ? 13 : -1,
            );
            expect(status.humanMessage, isNotEmpty);
            messages.add(status.humanMessage);
          }
        }
      }
      // Distinct semantic states should map to more than one message string.
      expect(messages.length, greaterThan(1));
    });
  });

  group('ShizukuStatus.initial', () {
    test('represents an unavailable, ungranted state', () {
      final status = ShizukuStatus.initial();
      expect(status.available, isFalse);
      expect(status.permissionGranted, isFalse);
      expect(status.state, ShizukuState.unavailable);
    });
  });
}
