import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/models/command_result.dart';

void main() {
  group('CommandResult.fromMap', () {
    test('parses a successful result correctly', () {
      final result = CommandResult.fromMap({
        'success': true,
        'exitCode': 0,
        'stdout': '128',
        'stderr': '',
      });

      expect(result.success, isTrue);
      expect(result.exitCode, 0);
      expect(result.stdout, '128');
      expect(result.stderr, '');
    });

    test('parses a failure result correctly', () {
      final result = CommandResult.fromMap({
        'success': false,
        'exitCode': 1,
        'stdout': '',
        'stderr': 'permission denied',
      });

      expect(result.success, isFalse);
      expect(result.exitCode, 1);
      expect(result.stderr, 'permission denied');
    });

    test('falls back to safe defaults on missing keys', () {
      final result = CommandResult.fromMap({});

      expect(result.success, isFalse);
      expect(result.exitCode, -1);
      expect(result.stdout, '');
      expect(result.stderr, '');
    });
  });

  group('CommandResult.failure factory', () {
    test('builds a failure result with the given message', () {
      final result = CommandResult.failure('Shizuku is not running');

      expect(result.success, isFalse);
      expect(result.exitCode, -1);
      expect(result.stderr, 'Shizuku is not running');
    });
  });

  group('CommandResult.humanError', () {
    test('returns empty string when successful', () {
      const result = CommandResult(
        success: true,
        exitCode: 0,
        stdout: 'ok',
        stderr: '',
      );
      expect(result.humanError, '');
    });

    test('maps "not running" to a friendly message', () {
      const result = CommandResult(
        success: false,
        exitCode: -1,
        stdout: '',
        stderr: 'Shizuku is not running',
      );
      expect(result.humanError, contains('start Shizuku'));
    });

    test('maps "permission denied" to a friendly message', () {
      const result = CommandResult(
        success: false,
        exitCode: -1,
        stdout: '',
        stderr: 'permission denied',
      );
      expect(result.humanError, contains('Grant Shizuku permission'));
    });

    test('maps SecurityException to a friendly message', () {
      const result = CommandResult(
        success: false,
        exitCode: -1,
        stdout: '',
        stderr: 'SecurityException: not allowed',
      );
      expect(result.humanError, contains('SecurityException'));
    });

    test('falls back to raw stderr for unrecognized errors', () {
      const result = CommandResult(
        success: false,
        exitCode: 2,
        stdout: '',
        stderr: 'unexpected native failure',
      );
      expect(result.humanError, contains('unexpected native failure'));
    });

    test('falls back to exit code message when stderr is empty', () {
      const result = CommandResult(
        success: false,
        exitCode: 127,
        stdout: '',
        stderr: '',
      );
      expect(result.humanError, contains('127'));
    });
  });
}
