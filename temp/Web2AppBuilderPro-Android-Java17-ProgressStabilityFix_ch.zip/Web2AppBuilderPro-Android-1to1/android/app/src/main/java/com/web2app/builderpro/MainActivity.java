package com.web2app.builderpro;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE_CHOOSER = 2001;
    private static final int REQUEST_STORAGE = 2002;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private LocalBuildManager localBuildManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0F172A"));
        getWindow().setNavigationBarColor(Color.parseColor("#0F172A"));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0F172A"));
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0F172A"));
        webView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(webView);

        localBuildManager = new LocalBuildManager(this);
        configureWebView();
        requestLegacyStorageIfNeeded();
        webView.addJavascriptInterface(new AndroidFunction(), "AndroidFunction");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme();
                if ("file".equalsIgnoreCase(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (Exception ignored) { return false; }
            }
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null || url.startsWith("file://")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); return true; }
                catch (Exception ignored) { return false; }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, REQUEST_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak dapat membuka pemilih fail", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
    }

    private void requestLegacyStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILE_CHOOSER || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) results = new Uri[]{data.getData()};
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidFunction"); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    public class AndroidFunction {
        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Web2App Prompt", text == null ? "" : text));
                Toast.makeText(MainActivity.this, "Copied!", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface
        public String getBuildToolsStatus() {
            return localBuildManager == null ? "{\"installed\":false}" : localBuildManager.getStatusJson();
        }

        @JavascriptInterface
        public void installBuildTools(final String requestId) {
            if (localBuildManager == null) return;
            new Thread(() -> {
                try {
                    emitToolsEvent(requestId, 0, "Preparing local build tools...", false, false, null);
                    localBuildManager.install((progress, stage) -> emitToolsEvent(requestId, progress, stage, false, false, null));
                    emitToolsEvent(requestId, 100, "Local build tools ready", true, true, "Installation complete. Generate can now include a signed APK.");
                } catch (Exception e) {
                    emitToolsEvent(requestId, 0, "Installation failed", true, false, e.getMessage());
                }
            }, "w2a-tool-installer").start();
        }

        @JavascriptInterface
        public void buildProjectWithApk(final String base64Data, final String requestedFileName, final String appName, final String requestId) {
            final String safeName = sanitizeFileName(requestedFileName);
            final byte[] sourceData;
            try {
                sourceData = Base64.decode(base64Data, Base64.DEFAULT);
            } catch (Exception e) {
                emitBuildEvent(requestId, 0, "Invalid project ZIP", true, false, false, e.getMessage());
                return;
            }

            if (localBuildManager == null || !localBuildManager.isReady()) {
                try {
                    saveBytesToDownloads(sourceData, safeName, "application/zip");
                    toast("Build tools belum dipasang — ZIP project disimpan seperti biasa: " + safeName);
                    emitBuildEvent(requestId, 100, "Source ZIP saved", true, true, true, "Build tools not installed; source ZIP saved normally.");
                } catch (Exception e) {
                    emitBuildEvent(requestId, 0, "Could not save ZIP", true, false, true, e.getMessage());
                }
                return;
            }

            new Thread(() -> {
                File finalZip = null;
                try {
                    emitBuildEvent(requestId, 1, "Starting local APK build...", false, true, false, null);
                    finalZip = localBuildManager.buildProject(sourceData, appName, (progress, stage) -> emitBuildEvent(requestId, progress, stage, false, true, false, null));
                    saveFileToDownloads(finalZip, safeName, "application/zip");
                    toast("ZIP + APK disimpan dalam Download: " + safeName);
                    emitBuildEvent(requestId, 100, "ZIP + signed APK saved", true, true, false, "Final ZIP contains source project and APK/" + sanitizeApkName(appName) + ".apk");
                } catch (Exception buildError) {
                    try {
                        saveBytesToDownloads(sourceData, safeName, "application/zip");
                        toast("Build APK gagal — source ZIP tetap disimpan: " + safeName);
                    } catch (Exception ignored) {}
                    emitBuildEvent(requestId, 0, "APK build failed; source ZIP saved", true, false, true, buildError.getMessage());
                } finally {
                    if (localBuildManager != null && finalZip != null) localBuildManager.cleanupBuildOutput(finalZip);
                }
            }, "w2a-local-apk-build").start();
        }

        @JavascriptInterface
        public void saveProject(String base64Data, String requestedFileName) {
            final String safeName = sanitizeFileName(requestedFileName);
            try {
                byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
                saveBytesToDownloads(data, safeName, "application/zip");
                toast("ZIP disimpan dalam Download: " + safeName);
            } catch (Exception e) {
                toast("Gagal simpan ZIP: " + e.getMessage());
            }
        }
    }

    private void emitToolsEvent(String requestId, int progress, String stage, boolean done, boolean success, String message) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("requestId", requestId == null ? "" : requestId);
            obj.put("progress", Math.max(0, Math.min(100, progress)));
            obj.put("stage", stage == null ? "" : stage);
            obj.put("done", done);
            obj.put("success", success);
            obj.put("arch", localBuildManager == null ? "unknown" : localBuildManager.getArchitectureLabel());
            if (message != null) obj.put("message", message);
            emitJs("__W2A_BUILD_TOOLS_EVENT__", obj);
        } catch (Exception ignored) {}
    }

    private void emitBuildEvent(String requestId, int progress, String stage, boolean done, boolean success, boolean fallback, String message) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("requestId", requestId == null ? "" : requestId);
            obj.put("progress", Math.max(0, Math.min(100, progress)));
            obj.put("stage", stage == null ? "" : stage);
            obj.put("done", done);
            obj.put("success", success);
            obj.put("fallback", fallback);
            if (message != null) obj.put("message", message);
            emitJs("__W2A_LOCAL_BUILD_EVENT__", obj);
        } catch (Exception ignored) {}
    }

    private void emitJs(String callback, JSONObject object) {
        if (webView == null) return;
        final String script = "window." + callback + " && window." + callback + "(" + object.toString() + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private String sanitizeFileName(String name) {
        String cleaned = name == null ? "Web2App_Project.zip" : name.trim();
        cleaned = cleaned.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (cleaned.isEmpty()) cleaned = "Web2App_Project.zip";
        if (!cleaned.toLowerCase().endsWith(".zip")) cleaned += ".zip";
        return cleaned;
    }

    private String sanitizeApkName(String name) {
        String cleaned = name == null ? "Web2App" : name.trim().replaceAll("[^a-zA-Z0-9._-]+", "_");
        return cleaned.isEmpty() ? "Web2App" : cleaned;
    }

    private void saveBytesToDownloads(byte[] data, String fileName, String mime) throws Exception {
        saveStreamToDownloads(new ByteArrayInputStream(data), fileName, mime);
    }

    private void saveFileToDownloads(File file, String fileName, String mime) throws Exception {
        try (InputStream in = new FileInputStream(file)) { saveStreamToDownloads(in, fileName, mime); }
    }

    private void saveStreamToDownloads(InputStream input, String fileName, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveWithMediaStore(input, fileName, mime); else saveLegacy(input, fileName);
    }

    private void saveWithMediaStore(InputStream input, String fileName, String mime) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, mime);
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("MediaStore tidak dapat cipta fail");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new Exception("Output stream gagal dibuka");
            copy(input, out);
        } catch (Exception e) {
            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            throw e;
        }
        ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(uri, done, null, null);
    }

    private void saveLegacy(InputStream input, String fileName) throws Exception {
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) throw new Exception("Kebenaran storan belum diberikan");
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloads.exists() && !downloads.mkdirs()) throw new Exception("Folder Download tidak tersedia");
        File output = new File(downloads, fileName);
        try (FileOutputStream stream = new FileOutputStream(output, false)) { copy(input, stream); }
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        out.flush();
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }
}
