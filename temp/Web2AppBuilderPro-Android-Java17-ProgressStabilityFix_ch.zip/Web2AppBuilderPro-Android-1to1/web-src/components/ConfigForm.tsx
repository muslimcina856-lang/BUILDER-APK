
import React from 'react';
import { AppConfig } from '../types';
import { Upload, X, Lock } from 'lucide-react';

interface ConfigFormProps {
  config: AppConfig;
  onChange: (config: Partial<AppConfig>) => void;
  mode: 'webview' | 'builder';
}

const ConfigForm: React.FC<ConfigFormProps> = ({ config, onChange, mode }) => {
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onChange({ iconFile: e.target.files[0] });
    }
  };

  // Improved Date Calculation to show TIME as well
  const calculateExpiryPreview = (days: number) => {
    if (!days) return null;
    const date = new Date();
    date.setDate(date.getDate() + days);
    
    // Returns "25/10/2023, 2:30 PM" format
    return date.toLocaleString('en-GB', { 
        day: 'numeric', 
        month: 'numeric', 
        year: 'numeric', 
        hour: 'numeric', 
        minute: 'numeric',
        hour12: true 
    });
  };

  const handleValidityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const valStr = e.target.value;
      if (valStr === '') {
          onChange({ expirationDays: 0 }); 
          return;
      }
      onChange({ expirationDays: parseInt(valStr) || 0 });
  };

  return (
    <div className="space-y-6">
      
      {/* Advanced Settings (Only in Builder Mode) - For setting internal limits */}
      {mode === 'builder' && (
        <div className="p-4 bg-emerald-900/20 border border-emerald-500/30 rounded-lg space-y-4">
            <div className="space-y-2">
                <div className="flex items-center gap-2 text-amber-400 mb-2">
                    <Lock className="w-4 h-4" />
                    <span className="font-semibold text-sm">Advanced Settings (Internal App Limit)</span>
                </div>
                <label className="text-sm font-medium text-slate-300 flex justify-between">
                    <span>Set Limit Day (Max Validity for Generated App)</span>
                    <span className="text-xs text-amber-500">0 = Unlimited Allowed</span>
                </label>
                <input
                    type="number"
                    min="0"
                    value={config.maxValidityDays === 0 ? '' : config.maxValidityDays}
                    onChange={(e) => {
                        const val = e.target.value;
                        onChange({ maxValidityDays: val === '' ? 0 : parseInt(val) });
                    }}
                    className="w-full bg-slate-900 border border-amber-500/50 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="e.g. 30"
                />
                <p className="text-xs text-slate-400">
                    This setting restricts the <strong>App Generator inside the APK</strong>. The APK user cannot generate apps with validity longer than this days.
                </p>
            </div>
        </div>
      )}

      {/* Basic Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">App Name</label>
          <input
            type="text"
            value={config.appName}
            onChange={(e) => onChange({ appName: e.target.value })}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            placeholder="e.g. My Web App"
          />
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Package Name</label>
          <input
            type="text"
            value={config.packageName}
            onChange={(e) => {
                const validVal = e.target.value.toLowerCase().replace(/[^a-z0-9_.]/g, '');
                onChange({ packageName: validVal });
            }}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all font-mono text-sm"
            placeholder="e.g. com.company.app"
          />
          <p className="text-[10px] text-slate-500">Only lowercase letters, numbers, dots, and underscores allowed.</p>
        </div>
      </div>

      {mode === 'webview' && (
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Target URL (WebView)</label>
          <input
            type="url"
            value={config.targetUrl}
            onChange={(e) => onChange({ targetUrl: e.target.value })}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
            placeholder="https://..."
          />
        </div>
      )}

      {/* Versions & Expiration */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Version Code</label>
          <input
            type="number"
            value={config.versionCode}
            onChange={(e) => onChange({ versionCode: parseInt(e.target.value) || 1 })}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Version Name</label>
          <input
            type="text"
            value={config.versionName}
            onChange={(e) => onChange({ versionName: e.target.value })}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300 flex justify-between">
            <span>Validity (Days)</span>
            <span className="text-xs text-slate-500">{config.expirationDays === 0 ? "Lifetime" : "Expires"}</span>
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              value={config.expirationDays === 0 ? '' : config.expirationDays}
              onChange={handleValidityChange}
              className={`w-full bg-slate-900 border rounded-lg px-4 py-2.5 text-white focus:ring-2 outline-none ${config.expirationDays > 0 ? 'border-red-500 focus:ring-red-500' : 'border-slate-700 focus:ring-blue-500'}`}
              placeholder="Leave empty for Lifetime"
            />
            {config.expirationDays > 0 && (
                <div className="absolute right-0 top-full mt-1 text-xs text-red-400 font-mono text-right">
                    Expires on: {calculateExpiryPreview(config.expirationDays)}
                </div>
            )}
          </div>
        </div>
      </div>

      {/* WebView Settings */}
      {mode === 'webview' && (
        <div className="space-y-4">
            <label className="text-sm font-medium text-slate-300 block">WebView Settings</label>
            <div className="space-y-2">
                <label className="text-xs text-slate-400">User Agent (Optional)</label>
                <textarea
                value={config.userAgent}
                onChange={(e) => onChange({ userAgent: e.target.value })}
                className="w-full h-24 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                placeholder="Leave empty for default device User Agent"
                />
            </div>
             <p className="text-[10px] text-slate-500 italic">
                * JavaScript and Zoom controls are automatically enabled by default.
            </p>
        </div>
      )}

      {/* App Icon */}
      <div className="space-y-2 border-t border-slate-700 pt-6">
        <label className="text-sm font-medium text-slate-300 block">App Icon (.png recommended)</label>
        <div className="flex items-center gap-4">
          <label className="flex-1 cursor-pointer group">
            <div className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-700 border-dashed rounded-lg bg-slate-900 hover:bg-slate-800 hover:border-blue-500 transition-all">
               {config.iconFile ? (
                 <div className="flex flex-col items-center">
                    <img 
                      src={URL.createObjectURL(config.iconFile)} 
                      alt="Preview" 
                      className="w-16 h-16 object-cover rounded mb-2"
                    />
                    <p className="text-sm text-blue-400">{config.iconFile.name}</p>
                 </div>
               ) : (
                 <div className="flex flex-col items-center pt-5 pb-6">
                   <Upload className="w-8 h-8 text-slate-500 mb-2 group-hover:text-blue-400" />
                   <p className="text-sm text-slate-500 group-hover:text-slate-300">Click to upload app icon</p>
                 </div>
               )}
               <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
            </div>
          </label>
          {config.iconFile && (
            <button
              onClick={() => onChange({ iconFile: null })}
              className="p-3 bg-red-900/50 hover:bg-red-900 text-red-200 rounded-lg transition-colors border border-red-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

    </div>
  );
};

export default ConfigForm;