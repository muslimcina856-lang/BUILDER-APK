import JSZip from 'jszip';
import saveAs from 'file-saver';
import { AppConfig } from '../types';

const jszipOfflineSource = (window as any).__JSZIP_SOURCE__ || '';

// --- HELPERS ---

const cleanVersion = (v: string) => v.split(' ')[0];

// Helper to escape XML special characters
const escapeXml = (unsafe: string) => {
    return unsafe.replace(/[<>&'"]/g, (c) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
            default: return c;
        }
    });
};

const escapeBackticks = (str: string) =>
  str
    .replace(/`/g, '\\`')
    .replace(/\$\{/g, '\\${')
    .replace(/<\/script>/gi, '<\\/script>');


// --- CONSTANTS ---

const EXPIRED_HTML_FILE = `<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACCESS DENIED - SYSTEM LOCKED</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;900&family=Rajdhani:wght@300;500;700&display=swap');

        :root {
            --neon: #ff003c;
            --neon-glow: rgba(255, 0, 60, 0.5);
            --bg: #000000;
        }

        * { box-sizing: border-box; cursor: crosshair; }

        body, html { 
            height: 100%; margin: 0; padding: 0;
            background: var(--bg);
            color: #fff; 
            font-family: 'Rajdhani', sans-serif; 
            overflow: hidden;
            display: flex; justify-content: center; align-items: center;
        }

        /* Animasi Latar Belakang Baru */
        .bg-container {
            position: fixed;
            inset: 0;
            z-index: 0;
            background: radial-gradient(circle at center, #1a0005 0%, #000 100%);
        }

        /* Kesan Laser Scanning */
        .laser-scan {
            position: absolute;
            width: 100%;
            height: 2px;
            background: var(--neon);
            box-shadow: 0 0 15px var(--neon);
            opacity: 0.3;
            animation: scan-move 4s linear infinite;
        }

        @keyframes scan-move {
            0% { top: -10%; }
            100% { top: 110%; }
        }

        /* Kesan Zarah Mengalir */
        .data-stream {
            position: absolute;
            width: 100%; height: 100%;
            background-image: radial-gradient(rgba(255, 0, 60, 0.2) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.3;
            animation: stream 10s linear infinite;
        }

        @keyframes stream {
            from { background-position: 0 0; }
            to { background-position: 0 400px; }
        }

        .container { 
            position: relative;
            width: 100vw; height: 100vh;
            display: flex; flex-direction: column;
            justify-content: center; align-items: center;
            z-index: 5;
            text-align: center;
        }

        /* H1 Glitch Klasik */
        h1 { 
            font-family: 'Orbitron', sans-serif;
            font-size: clamp(40px, 10vw, 85px);
            font-weight: 900;
            margin: 0;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: clamp(5px, 2vw, 15px);
            text-shadow: 4px 4px var(--neon), -4px -4px #00ffff;
            animation: glitch-classic 3s infinite;
        }

        @keyframes glitch-classic {
            0% { text-shadow: 4px 4px var(--neon), -4px -4px #00ffff; transform: translate(0); }
            2% { transform: translate(-3px, 3px); }
            4% { text-shadow: -4px -4px var(--neon), 4px 4px #00ffff; }
            6% { text-shadow: 4px -4px var(--neon), -4px 4px #00ffff; transform: translate(3px, -3px); }
            8% { transform: translate(0); }
        }

        p { 
            font-size: clamp(16px, 4vw, 24px); 
            color: #fff; margin: 30px 0 60px; 
            font-weight: 500; text-transform: uppercase;
            letter-spacing: 8px; opacity: 0.8;
        }

        /* Butang - Diam Secara Default, Bergetar Masa Hover */
        .btn { 
            position: relative;
            padding: 20px 60px; 
            background: transparent;
            color: var(--neon); 
            text-decoration: none; 
            border: 2px solid var(--neon);
            font-weight: 700; font-size: 18px;
            text-transform: uppercase; letter-spacing: 5px;
            box-shadow: 0 0 10px var(--neon-glow);
            transition: all 0.2s ease;
        }

        .btn:hover { 
            background: var(--neon); color: #000;
            box-shadow: 0 0 60px var(--neon);
            animation: vibrate-heavy 0.1s infinite;
        }

        @keyframes vibrate-heavy {
            0% { transform: scale(1.05) translate(2px, 2px); }
            50% { transform: scale(1.05) translate(-2px, -2px); }
            100% { transform: scale(1.05) translate(2px, -2px); }
        }

        /* Kesan Glitch Klik */
        .click-glitch {
            position: fixed;
            width: 3px; height: 12px;
            background: var(--neon);
            pointer-events: none;
            z-index: 100;
            animation: burst 0.4s ease-out forwards;
        }

        @keyframes burst {
            0% { transform: translate(0, 0) scale(1); opacity: 1; }
            100% { transform: translate(var(--dx), var(--dy)) scale(0); opacity: 0; }
        }

        .corner {
            position: absolute; width: 40px; height: 40px;
            border: 4px solid var(--neon);
            filter: drop-shadow(0 0 8px var(--neon));
            opacity: 0.4;
        }
        .top-l { top: 20px; left: 20px; border-right: 0; border-bottom: 0; }
        .top-r { top: 20px; right: 20px; border-left: 0; border-bottom: 0; }
        .bot-l { bottom: 20px; left: 20px; border-right: 0; border-top: 0; }
        .bot-r { bottom: 20px; right: 20px; border-left: 0; border-top: 0; }

    </style>
</head>
<body onmousedown="createBurst(event)">
    <div class="bg-container">
        <div class="data-stream"></div>
        <div class="laser-scan"></div>
    </div>

    <div class="container">
        <div class="corner top-l"></div>
        <div class="corner top-r"></div>
        <div class="corner bot-l"></div>
        <div class="corner bot-r"></div>
        
        <h1>ACCESS DENIED</h1>
        <p>Trial Expired Detected</p>
        
        <a href="https://t.me/earlxz" class="btn">Renew Now</a>
    </div>

    <script>
        function createBurst(e) {
            for (let i = 0; i < 12; i++) {
                const p = document.createElement('div');
                p.className = 'click-glitch';
                p.style.left = e.clientX + 'px';
                p.style.top = e.clientY + 'px';
                
                const dx = (Math.random() - 0.5) * 350;
                const dy = (Math.random() - 0.5) * 350;
                p.style.setProperty('--dx', dx + 'px');
                p.style.setProperty('--dy', dy + 'px');
                
                document.body.appendChild(p);
                setTimeout(() => p.remove(), 400);
            }
        }
    </script>
</body>
</html>
`;

// OFFLINE HTML (No Retry Button)
const OFFLINE_HTML_FILE = `<!DOCTYPE html>
<html lang="ms" style="overflow: hidden; touch-action: none;">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Offline - Nexus Terminal</title>
    <style>
        :root {
            --bg-color: #010103;
            --neon-blue: #00f3ff;
            --neon-purple: #bc13fe;
            --glass-surface: rgba(255, 255, 255, 0.02);
            --glass-border: rgba(255, 255, 255, 0.08);
        }

        * { 
            box-sizing: border-box; 
            -webkit-tap-highlight-color: transparent;
        }

        body { 
            background-color: var(--bg-color);
            color: white; 
            font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; 
            height: 100vh; 
            margin: 0; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            overflow: hidden;
            perspective: 1500px;
            touch-action: none; /* Menghalang scroll/swipe */
        }

        /* --- BACKGROUND LAYERS --- */
        .grid-bg {
            position: absolute;
            width: 200%;
            height: 200%;
            background-image: 
                linear-gradient(rgba(0, 243, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 243, 255, 0.03) 1px, transparent 1px);
            background-size: 60px 60px;
            transform: rotateX(60deg) translateZ(-200px);
            top: -50%;
            animation: gridMove 15s linear infinite;
            z-index: -3;
        }

        .particles {
            position: absolute;
            width: 100%;
            height: 100%;
            background: radial-gradient(1px 1px at 10% 20%, #fff, transparent),
                        radial-gradient(1px 1px at 40% 70%, var(--neon-blue), transparent),
                        radial-gradient(2px 2px at 80% 40%, var(--neon-purple), transparent);
            background-size: 200px 200px;
            animation: particleShift 20s linear infinite;
            opacity: 0.3;
            z-index: -2;
        }

        .orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(130px);
            opacity: 0.35;
            animation: floatOrb 12s infinite alternate ease-in-out;
            z-index: -1;
        }
        .orb-1 { width: 700px; height: 700px; background: var(--neon-purple); top: -25%; left: -15%; }
        .orb-2 { width: 600px; height: 600px; background: var(--neon-blue); bottom: -25%; right: -15%; animation-delay: -4s; }

        /* --- HYPER-GLASS CONTAINER --- */
        .container { 
            position: relative;
            padding: 70px 45px;
            width: 90%;
            max-width: 420px;
            text-align: center;
            background: var(--glass-surface);
            backdrop-filter: blur(40px) saturate(180%);
            -webkit-backdrop-filter: blur(40px) saturate(180%);
            border: 1px solid var(--glass-border);
            border-radius: 60px;
            box-shadow: 0 0 60px rgba(0,0,0,0.9), 
                        inset 0 0 20px rgba(255,255,255,0.02);
            animation: cardFloat 5s infinite ease-in-out, cardEntry 1s cubic-bezier(0.17, 0.67, 0.83, 0.67);
            overflow: hidden; /* Penting untuk scanner bar */
        }

        /* Scanner Bar Effect - Full Width */
        .scan-bar {
            position: absolute;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--neon-blue), var(--neon-purple), var(--neon-blue), transparent);
            box-shadow: 0 0 20px var(--neon-blue);
            animation: scanning 3s linear infinite;
            z-index: 5;
        }

        /* --- TRIPLE ULTRA-SPEED RINGS --- */
        .status-visual {
            position: relative;
            width: 130px;
            height: 130px;
            margin: 0 auto 45px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .ring {
            position: absolute;
            border-radius: 50%;
            border: 3px solid transparent;
            animation: spin linear infinite;
        }

        .ring-1 { inset: 0; border-top-color: var(--neon-blue); animation-duration: 0.7s; filter: drop-shadow(0 0 12px var(--neon-blue)); }
        .ring-2 { inset: 10px; border-right-color: var(--neon-purple); animation-duration: 0.5s; filter: drop-shadow(0 0 12px var(--neon-purple)); }
        .ring-3 { inset: 20px; border-bottom-color: #fff; animation-duration: 0.3s; filter: drop-shadow(0 0 6px #fff); }

        .wifi-icon {
            width: 40px;
            stroke: rgba(255, 255, 255, 0.9);
            filter: drop-shadow(0 0 5px rgba(255,255,255,0.5));
            animation: iconPulse 2s infinite ease-in-out;
        }

        /* --- TYPOGRAPHY --- */
        h1 { 
            font-size: 24px; 
            margin: 0 0 12px; 
            font-weight: 900;
            letter-spacing: 5px;
            text-transform: uppercase;
            background: linear-gradient(to bottom, #fff 30%, #444);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            filter: drop-shadow(0 0 10px rgba(255,255,255,0.2));
        }

        .instruction { 
            font-size: 13px; 
            color: rgba(255, 255, 255, 0.4); 
            line-height: 1.8;
            margin: 0;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .highlight {
            color: var(--neon-blue);
            text-shadow: 0 0 15px var(--neon-blue);
            font-weight: 800;
            animation: textGlow 1.5s infinite alternate;
        }

        /* --- ANIMATION KEYFRAMES --- */
        @keyframes gridMove {
            from { transform: rotateX(60deg) translateY(0); }
            to { transform: rotateX(60deg) translateY(60px); }
        }

        @keyframes particleShift {
            from { background-position: 0 0; }
            to { background-position: 200px 400px; }
        }

        @keyframes scanning {
            0% { top: -5%; opacity: 0; }
            15% { opacity: 1; }
            85% { opacity: 1; }
            100% { top: 105%; opacity: 0; }
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        @keyframes cardFloat {
            0%, 100% { transform: translateY(0) rotateX(2deg); }
            50% { transform: translateY(-20px) rotateX(-2deg); }
        }

        @keyframes cardEntry {
            from { opacity: 0; transform: scale(0.8) translateZ(-500px); }
            to { opacity: 1; transform: scale(1) translateZ(0); }
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.15); opacity: 0.7; }
        }

        @keyframes textGlow {
            from { opacity: 0.6; text-shadow: 0 0 5px var(--neon-blue); }
            to { opacity: 1; text-shadow: 0 0 20px var(--neon-blue), 0 0 30px var(--neon-blue); }
        }

        @keyframes floatOrb {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(100px, 50px) scale(1.1); }
        }

    </style>
</head>
<body>

    <div class="grid-bg"></div>
    <div class="particles"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="container">
        <div class="scan-bar"></div>
        
        <div class="status-visual">
            <div class="ring ring-1"></div>
            <div class="ring ring-2"></div>
            <div class="ring ring-3"></div>
            
            <svg class="wifi-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.58 9M1.42 9a16 16 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0"></path>
            </svg>
        </div>
        
        <h1>System Offline</h1>
        <p class="instruction">Network link severed.<br>Check connection & <span class="highlight">RESTART APP</span></p>
    </div>

</body>
</html>
`;


const ALL_PERMISSIONS_XML = `
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
`;

// --- FILE GENERATORS ---

const getBuildGradleProject = () => {
  return `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath "com.android.tools.build:gradle:3.6.4"
    }
}
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
task clean(type: Delete) {
    delete rootProject.buildDir
}`;
};

const getSettingsGradle = (appName: string) => {
  const safeName = appName.replace(/[^a-zA-Z0-9]/g, "_");
  return `include ':app'\nrootProject.name = "${safeName}"`;
};

const getBuildGradleApp = (config: AppConfig, mode: 'webview' | 'builder') => {
  return `apply plugin: 'com.android.application'

android {
    compileSdkVersion 29
    buildToolsVersion "30.0.3"

    defaultConfig {
        applicationId "${config.packageName}"
        minSdkVersion 26
        targetSdkVersion 29
        versionCode ${config.versionCode}
        versionName "${config.versionName}"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation fileTree(dir: "libs", include: ["*.jar"])
    implementation 'com.google.android.gms:play-services-location:19.0.1'
}`;
};

const getAndroidManifest = (config: AppConfig) => {
  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="${config.packageName}">

    ${ALL_PERMISSIONS_XML}

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true"
        android:requestLegacyExternalStorage="true"
        android:largeHeap="true"
        tools:replace="android:icon,android:theme">
        
        <activity android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;
};

const getMainActivityJava = (config: AppConfig, mode: 'webview' | 'builder') => {
    const isBuilder = mode === 'builder';
    
    const packageStatement = `package ${config.packageName};`;
    const safeUserAgent = config.userAgent ? config.userAgent.replace(/"/g, '\\"').replace(/[\r\n]+/g, ' ') : '';
    
    let expirationTimestamp = 0;
    if (config.expirationDays > 0) {
        const now = new Date();
        const future = new Date(now.getTime() + (config.expirationDays * 24 * 60 * 60 * 1000));
        expirationTimestamp = future.getTime();
    }
    
    // Default load logic (initial)
    const loadLogic = config.expirationDays > 0 ?
    `   final long EXPIRY = ${expirationTimestamp}L;
        new Thread(new Runnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                try {
                     URL url = new URL("https://www.google.com");
                     HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                     conn.setConnectTimeout(3000);
                     conn.setRequestMethod("HEAD");
                     if (conn.getDate() > 0) now = conn.getDate();
                } catch (Exception e) {}
                
                final long finalNow = now;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        if (myWebView == null) return; 
                        if (finalNow > EXPIRY) {
                            myWebView.loadUrl("file:///android_asset/expired.html");
                        } else {
                            ${isBuilder 
                                ? `myWebView.addJavascriptInterface(new WebAppInterface(MainActivity.this), "AndroidFunction"); myWebView.loadUrl("file:///android_asset/index.html");` 
                                : `myWebView.loadUrl("${config.targetUrl}");`
                            }
                        }
                    }
                });
            }
        }).start();
    ` : (isBuilder 
            ? `myWebView.addJavascriptInterface(new WebAppInterface(this), "AndroidFunction"); myWebView.loadUrl("file:///android_asset/index.html");` 
            : `myWebView.loadUrl("${config.targetUrl}");`
    );

    // UPDATED: Added Google Play Services Imports and Logic
    return `${packageStatement}

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import android.util.Base64;
import android.os.Build;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.content.pm.PackageManager;
import android.Manifest;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.location.LocationManager;
import android.provider.Settings;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.content.IntentSender;

// Google Play Services Location
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.common.api.ResolvableApiException;

public class MainActivity extends Activity {
    
    private WebView myWebView;
    private ValueCallback<Uri[]> mFilePathCallback;
    private GeolocationPermissions.Callback mGeoCallback;
    private String mGeoOrigin;
    private PermissionRequest mPendingRequest;
    private ConnectivityManager mConnectivityManager;
    private ConnectivityManager.NetworkCallback mNetworkCallback;
    
    private static final int REQ_STORAGE = 100;
    private static final int REQ_LOCATION = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_GPS_SETTINGS = 103;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            FrameLayout root = new FrameLayout(this);
            root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            setContentView(root); 

            myWebView = new WebView(this);
            myWebView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(myWebView);

            if (Build.VERSION.SDK_INT >= 23) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                     requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                }
            }

            WebSettings settings = myWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDatabaseEnabled(true);
            settings.setGeolocationEnabled(true);
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);

            ${safeUserAgent ? `settings.setUserAgentString("${safeUserAgent}");` : ''}

            myWebView.setWebChromeClient(new WebChromeClient() {
                public void onPermissionRequest(final PermissionRequest request) { 
                    mPendingRequest = request;
                    List<String> missingPermissions = new ArrayList<>();
                    for (String res : request.getResources()) {
                         if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.CAMERA); }
                         if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.RECORD_AUDIO); }
                    }
                    if (!missingPermissions.isEmpty()) {
                         if (Build.VERSION.SDK_INT >= 23) requestPermissions(missingPermissions.toArray(new String[0]), REQ_MEDIA);
                    } else {
                        request.grant(request.getResources());
                    }
                }
                
                public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) { 
                     mGeoCallback = callback; mGeoOrigin = origin;
                     if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                         requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
                    } else {
                         promptForLocation();
                    }
                }
                public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> f, FileChooserParams p) {
                    if(mFilePathCallback != null) mFilePathCallback.onReceiveValue(null);
                    mFilePathCallback = f;
                    try { startActivityForResult(p.createIntent(), 100); } catch(Exception e) { mFilePathCallback = null; return false; }
                    return true;
                }
            });

            myWebView.setWebViewClient(new WebViewClient() {
                 @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) { view.loadUrl("file:///android_asset/offline.html"); }
                 @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) { if (request.isForMainFrame()) view.loadUrl("file:///android_asset/offline.html"); }
                 @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                     if(url == null || url.startsWith("file:///android_asset/")) return false;
                     if(url.startsWith("http") || url.startsWith("file")) return false;
                     try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e) {} return true;
                 }
            });
            
            myWebView.setDownloadListener(new DownloadListener() {
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    try { Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse(url)); startActivity(i); } catch (Exception e) {}
                }
            });

            // REALTIME NETWORK MONITORING
            mConnectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 24) {
                mNetworkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override public void onLost(Network network) { runOnUiThread(new Runnable() { public void run() { if (myWebView != null) myWebView.loadUrl("file:///android_asset/offline.html"); } }); }
                    @Override public void onAvailable(Network network) {}
                };
                mConnectivityManager.registerDefaultNetworkCallback(mNetworkCallback);
            }

            if (savedInstanceState != null) myWebView.restoreState(savedInstanceState);
            else { ${loadLogic} }
        } catch (Throwable t) {}
    }

    private void promptForLocation() {
        new AlertDialog.Builder(MainActivity.this)
            .setTitle("Kebenaran Lokasi")
            .setMessage("Aplikasi ini mahu menggunakan lokasi peranti anda.")
            .setPositiveButton("Benarkan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, true, true);
                    createLocationRequest();
                }
            })
            .setNegativeButton("Jangan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false);
                }
            })
            .setCancelable(false)
            .show();
    }

    private void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { @Override public void onSuccess(LocationSettingsResponse locationSettingsResponse) {} });
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override public void onFailure(Exception e) {
                if (e instanceof ResolvableApiException) {
                    try { ((ResolvableApiException) e).startResolutionForResult(MainActivity.this, REQ_GPS_SETTINGS); } catch (IntentSender.SendIntentException sendEx) {}
                }
            }
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) { promptForLocation(); } 
            else { if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false); }
        } else if (requestCode == REQ_MEDIA) {
             if (mPendingRequest != null) {
                 boolean allGranted = true;
                 for(int res : grantResults) { if (res != PackageManager.PERMISSION_GRANTED) allGranted = false; }
                 if (allGranted) mPendingRequest.grant(mPendingRequest.getResources()); else mPendingRequest.deny();
                 mPendingRequest = null;
             }
        }
    }
    @Override protected void onDestroy() { 
        if (myWebView != null) try { myWebView.destroy(); } catch (Exception e) {}; 
        if (mConnectivityManager != null && mNetworkCallback != null && Build.VERSION.SDK_INT >= 24) { try { mConnectivityManager.unregisterNetworkCallback(mNetworkCallback); } catch(Exception e) {} }
        super.onDestroy(); 
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { if(requestCode == 100 && mFilePathCallback != null) { mFilePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); mFilePathCallback = null; } }
    @Override public void onBackPressed() { if (myWebView != null && myWebView.canGoBack()) myWebView.goBack(); else super.onBackPressed(); }
    
    ${isBuilder ? `
    public class WebAppInterface {
        Activity mActivity;
        WebAppInterface(Activity activity) { mActivity = activity; }
        @JavascriptInterface
        public void saveProject(String base64Content, String fileName) {
            try {
                byte[] data = Base64.decode(base64Content, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = mActivity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri != null) {
                        try (OutputStream out = mActivity.getContentResolver().openOutputStream(uri)) { out.write(data); }
                        mActivity.runOnUiThread(new Runnable() { public void run() { Toast.makeText(mActivity, "Saved to Downloads", Toast.LENGTH_LONG).show(); } });
                    }
                } else {
                    File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    final File file = new File(downloads, fileName);
                    FileOutputStream os = new FileOutputStream(file, false);
                    os.write(data); os.flush(); os.close();
                    mActivity.runOnUiThread(new Runnable() { public void run() { Toast.makeText(mActivity, "Saved: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show(); } });
                }
            } catch (final Exception e) {
                mActivity.runOnUiThread(new Runnable() { public void run() { Toast.makeText(mActivity, "Error Saving", Toast.LENGTH_SHORT).show(); } });
            }
        }
    }
    ` : ''}
}
`;
};


const nativeBuildCallbacks = new Map<string, { resolve: () => void; reject: (error: Error) => void }>();

const ensureNativeBuildCallback = () => {
    const w = window as any;
    if (w.__W2A_LOCAL_BUILD_EVENT__) return;
    w.__W2A_LOCAL_BUILD_EVENT__ = (event: any) => {
        if (!event?.requestId) return;
        const callback = nativeBuildCallbacks.get(event.requestId);
        if (!callback || !event.done) return;
        nativeBuildCallbacks.delete(event.requestId);
        if (event.success) callback.resolve();
        else callback.reject(new Error(event.message || 'Local APK build failed'));
    };
};

const saveGeneratedProject = async (blob: Blob, fileName: string, appName: string) => {
    const androidBridge = (window as any).AndroidFunction;
    if (androidBridge?.saveProject || androidBridge?.buildProjectWithApk) {
        const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ''));
            reader.onerror = () => reject(reader.error || new Error('Could not read ZIP output'));
            reader.readAsDataURL(blob);
        });
        const base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);

        // Android native bridge decides the path:
        // - no local toolchain -> save source ZIP exactly as before
        // - toolchain ready -> build/sign APK, append it under APK/, then save final ZIP
        if (androidBridge?.buildProjectWithApk) {
            ensureNativeBuildCallback();
            const requestId = `build-${Date.now()}-${Math.random().toString(36).slice(2)}`;
            await new Promise<void>((resolve, reject) => {
                nativeBuildCallbacks.set(requestId, { resolve, reject });
                try {
                    androidBridge.buildProjectWithApk(base64, fileName, appName, requestId);
                } catch (error) {
                    nativeBuildCallbacks.delete(requestId);
                    reject(error instanceof Error ? error : new Error('Could not start local build'));
                }
            });
            return;
        }

        androidBridge.saveProject(base64, fileName);
        return;
    }
    saveAs(blob, fileName);
};

// --- MAIN GENERATOR FUNCTION ---

const getEmbeddedBuilderHtml = (maxValidityLimit: number) => {
    // Icons SVGs
    const iconSmartphone = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>`;
    const iconDownload = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`;
    const iconSettings = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>`;

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web2App Builder Pro</title>
    <script src="jszip.min.js"></script>
    <style>
        :root {
            --bg-900: #0f172a;
            --bg-800: #1e293b;
            --border-700: #334155;
            --text-100: #f1f5f9;
            --text-300: #cbd5e1;
            --text-400: #94a3b8;
            --text-500: #64748b;
            --blue-500: #3b82f6;
            --blue-600: #2563eb;
            --indigo-500: #6366f1;
            --primary-grad: linear-gradient(to right, #2563eb, #4f46e5);
        }
        * { box-sizing: border-box; }
        body { background: var(--bg-900); color: var(--text-100); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 16px; min-height: 100vh; display: flex; flex-direction: column; }
        
        .header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border-700); }
        .header svg { color: var(--blue-500); width: 32px; height: 32px; }
        .header h1 { font-size: 1.5rem; font-weight: 700; margin: 0; background: var(--primary-grad); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        
        .card { background: var(--bg-800); border: 1px solid var(--border-700); border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
        .card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 20px; padding-bottom: 8px; border-bottom: 1px solid var(--border-700); font-weight: 600; font-size: 1.1rem; color: #fff; }
        .card-header svg { width: 20px; height: 20px; color: #818cf8; }
        
        .form-grid { display: grid; gap: 16px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        label { font-size: 0.875rem; font-weight: 500; color: var(--text-300); }
        input, select { width: 100%; background: var(--bg-900); border: 1px solid var(--border-700); padding: 10px 12px; border-radius: 8px; color: white; font-size: 1rem; transition: border-color 0.2s; }
        input:focus { outline: none; border-color: var(--blue-500); box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3); }
        .hint { font-size: 0.75rem; color: var(--text-500); margin-top: 4px; }
        
        .btn-generate {
            width: 100%; background: var(--primary-grad); color: white; border: none; padding: 16px; border-radius: 12px;
            font-size: 1.1rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2); transition: transform 0.1s, box-shadow 0.2s;
            margin-top: auto;
        }
        .btn-generate:active { transform: scale(0.98); }
        .btn-generate:disabled { opacity: 0.7; cursor: not-allowed; filter: grayscale(1); }
        .btn-generate svg { width: 24px; height: 24px; }

        .file-upload {
            border: 2px dashed var(--border-700); background: var(--bg-900); border-radius: 8px; height: 100px;
            display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; text-align: center; color: var(--text-500);
        }
        .file-upload:hover { border-color: var(--blue-500); color: var(--text-300); }
        
        .error-msg { background: rgba(239, 68, 68, 0.1); color: #f87171; padding: 12px; border-radius: 8px; margin-top: 16px; display: none; text-align: center; border: 1px solid rgba(239, 68, 68, 0.2); }
        
        @media (min-width: 768px) {
            .form-grid { grid-template-columns: 1fr 1fr; }
            .col-span-2 { grid-column: span 2; }
        }
    </style>
</head>
<body>
    <div class="header">
        ${iconSmartphone}
        <h1>Web2App Builder Pro</h1>
    </div>

    <div class="card">
        <div class="card-header">
            ${iconSettings}
            <span>WebView Configuration</span>
        </div>
        <div class="form-grid">
            <div class="form-group col-span-2">
                <label>App Name</label>
                <input type="text" id="appName" placeholder="My Web App" value="My Web App">
            </div>
            
            <div class="form-group col-span-2">
                <label>Package Name</label>
                <input type="text" id="packageName" placeholder="com.example.webapp" value="com.example.webapp">
                <p class="hint">Lowercase, numbers, dots only.</p>
            </div>
            
            <div class="form-group col-span-2">
                <label>Target URL</label>
                <input type="url" id="targetUrl" placeholder="https://www.google.com" value="https://www.google.com">
            </div>
            
            <div class="form-group">
                <label>Version Code</label>
                <input type="number" id="versionCode" value="1">
            </div>
            
            <div class="form-group">
                <label>Version Name</label>
                <input type="text" id="versionName" value="1.0.0">
            </div>
            
            <div class="form-group">
                <label>Expiration (Days) ${maxValidityLimit > 0 ? `<span style="color:#f59e0b">(Max ${maxValidityLimit})</span>` : ''}</label>
                <input type="number" id="expirationDays" placeholder="${maxValidityLimit > 0 ? 'Cannot be 0' : '0 = Lifetime'}" min="0" value="0">
                <p class="hint">${maxValidityLimit > 0 ? 'Lifetime (0) not allowed.' : '0 for Lifetime access.'}</p>
            </div>
            
            <div class="form-group col-span-2">
                <label>App Icon (Optional)</label>
                <div class="file-upload" onclick="document.getElementById('iconFile').click()">
                    <span>Click to upload PNG</span>
                    <input type="file" id="iconFile" accept="image/*" style="display:none" onchange="this.previousElementSibling.innerText = this.files[0].name">
                </div>
            </div>
        </div>
        
        <div id="errorMsg" class="error-msg"></div>
    </div>

    <button id="generateBtn" class="btn-generate" onclick="generate()">
        ${iconDownload}
        Generate APK Project
    </button>

    <script>
        // Constants injected from TS
        const MAX_LIMIT = ${maxValidityLimit};
        
        const OFFLINE_HTML = \`${escapeBackticks(OFFLINE_HTML_FILE)}\`;
        const EXPIRED_HTML = \`${escapeBackticks(EXPIRED_HTML_FILE)}\`;
        const PERMISSIONS_XML = \`${escapeBackticks(ALL_PERMISSIONS_XML)}\`;

        // Input Logic: Auto-Correction
        const expiryInput = document.getElementById('expirationDays');

        // Prevent typing '0' as the very first character if limit exists
        expiryInput.addEventListener('keydown', function(e) {
            if (MAX_LIMIT > 0 && e.key === '0' && e.target.value === '') {
                e.preventDefault();
            }
        });
        
        // Auto-correct values on input
        expiryInput.addEventListener('input', function(e) {
            let val = parseInt(e.target.value);
            
            if (isNaN(val)) return;

            // If a hard limit is set
            if (MAX_LIMIT > 0) {
                // Constraint: Cannot be 0 or less (Double check safety)
                if (val <= 0) {
                    e.target.value = 1;
                }
                // Constraint: Cannot exceed MAX_LIMIT
                else if (val > MAX_LIMIT) {
                    e.target.value = MAX_LIMIT;
                }
            }
        });
        
        // Initial check on load (to fix default 0 if limit exists)
        if (MAX_LIMIT > 0 && parseInt(expiryInput.value) === 0) {
            expiryInput.value = 1; 
        }

        // --- TEMPLATES ---
        function getBuildGradleProject() {
            return \`${escapeBackticks(getBuildGradleProject())}\`;
        }
        
        function getSettingsGradle(appName) {
            const safeName = appName.replace(/[^a-zA-Z0-9]/g, "_");
            return \`include ':app'\\nrootProject.name = "\${safeName}"\`;
        }

        function getBuildGradleApp(packageName, versionCode, versionName) {
            return \`apply plugin: 'com.android.application'

android {
    compileSdkVersion 29
    buildToolsVersion "30.0.3"

    defaultConfig {
        applicationId "\${packageName}"
        minSdkVersion 26
        targetSdkVersion 29
        versionCode \${versionCode}
        versionName "\${versionName}"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation fileTree(dir: "libs", include: ["*.jar"])
    implementation 'com.google.android.gms:play-services-location:19.0.1'
}\`;
        }

        function getAndroidManifest(packageName, appName) {
            return \`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="\${packageName}">

    \${PERMISSIONS_XML}

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true"
        android:requestLegacyExternalStorage="true"
        android:largeHeap="true"
        tools:replace="android:icon,android:theme">
        
        <activity android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>\`;
        }

        function getMainActivityJava(packageName, targetUrl, expirationDays) {
            let loadLogic = '';
            if (expirationDays > 0) {
                const now = new Date();
                const future = new Date(now.getTime() + (expirationDays * 24 * 60 * 60 * 1000));
                const expirationTimestamp = future.getTime();
                
                loadLogic = \`   final long EXPIRY = \${expirationTimestamp}L;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    long now = System.currentTimeMillis();
                    try {
                        URL url = new URL("https://www.google.com");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(3000);
                        conn.setRequestMethod("HEAD");
                        if (conn.getDate() > 0) now = conn.getDate();
                    } catch (Exception e) {}
                    
                    final long finalNow = now;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing()) return;
                            if (myWebView == null) return; 
                            if (finalNow > EXPIRY) {
                                myWebView.loadUrl("file:///android_asset/expired.html");
                            } else {
                                myWebView.loadUrl("\${targetUrl}");
                            }
                        }
                    });
                }
            }).start();\`;
            } else {
                loadLogic = \`myWebView.loadUrl("\${targetUrl}");\`;
            }

            return \`package \${packageName};

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import android.util.Base64;
import android.os.Build;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.content.pm.PackageManager;
import android.Manifest;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.location.LocationManager;
import android.provider.Settings;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.content.IntentSender;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.common.api.ResolvableApiException;

public class MainActivity extends Activity {
    
    private WebView myWebView;
    private ValueCallback<Uri[]> mFilePathCallback;
    private GeolocationPermissions.Callback mGeoCallback;
    private String mGeoOrigin;
    private PermissionRequest mPendingRequest;
    private ConnectivityManager mConnectivityManager;
    private ConnectivityManager.NetworkCallback mNetworkCallback;
    
    private static final int REQ_STORAGE = 100;
    private static final int REQ_LOCATION = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_GPS_SETTINGS = 103;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            FrameLayout root = new FrameLayout(this);
            root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            setContentView(root); 

            myWebView = new WebView(this);
            myWebView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(myWebView);

            if (Build.VERSION.SDK_INT >= 23) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                }
            }

            WebSettings settings = myWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDatabaseEnabled(true);
            settings.setGeolocationEnabled(true);
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);

            myWebView.setWebChromeClient(new WebChromeClient() {
                public void onPermissionRequest(final PermissionRequest request) { 
                    mPendingRequest = request;
                    List<String> missingPermissions = new ArrayList<>();
                    for (String res : request.getResources()) {
                        if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.CAMERA); }
                        if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.RECORD_AUDIO); }
                    }
                    if (!missingPermissions.isEmpty()) {
                        if (Build.VERSION.SDK_INT >= 23) requestPermissions(missingPermissions.toArray(new String[0]), REQ_MEDIA);
                    } else {
                        request.grant(request.getResources());
                    }
                }
                
                public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) { 
                    mGeoCallback = callback; mGeoOrigin = origin;
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
                    } else {
                        promptForLocation();
                    }
                }
                public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> f, FileChooserParams p) {
                    if(mFilePathCallback != null) mFilePathCallback.onReceiveValue(null);
                    mFilePathCallback = f;
                    try { startActivityForResult(p.createIntent(), 100); } catch(Exception e) { mFilePathCallback = null; return false; }
                    return true;
                }
            });

            myWebView.setWebViewClient(new WebViewClient() {
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) { view.loadUrl("file:///android_asset/offline.html"); }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) { if (request.isForMainFrame()) view.loadUrl("file:///android_asset/offline.html"); }
                @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    if(url == null || url.startsWith("file:///android_asset/")) return false;
                    if(url.startsWith("http") || url.startsWith("file")) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e) {} return true;
                }
            });
            
            myWebView.setDownloadListener(new DownloadListener() {
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    try { Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse(url)); startActivity(i); } catch (Exception e) {}
                }
            });

            mConnectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 24) {
                mNetworkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override public void onLost(Network network) { runOnUiThread(new Runnable() { public void run() { if (myWebView != null) myWebView.loadUrl("file:///android_asset/offline.html"); } }); }
                    @Override public void onAvailable(Network network) {}
                };
                mConnectivityManager.registerDefaultNetworkCallback(mNetworkCallback);
            }

            if (savedInstanceState != null) myWebView.restoreState(savedInstanceState);
            else { 
                \${loadLogic} 
            }
        } catch (Throwable t) {}
    }

    private void promptForLocation() {
        new AlertDialog.Builder(MainActivity.this)
            .setTitle("Kebenaran Lokasi")
            .setMessage("Aplikasi ini mahu menggunakan lokasi peranti anda.")
            .setPositiveButton("Benarkan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, true, true);
                    createLocationRequest();
                }
            })
            .setNegativeButton("Jangan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false);
                }
            })
            .setCancelable(false)
            .show();
    }

    private void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { @Override public void onSuccess(LocationSettingsResponse locationSettingsResponse) {} });
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override public void onFailure(Exception e) {
                if (e instanceof ResolvableApiException) {
                    try { ((ResolvableApiException) e).startResolutionForResult(MainActivity.this, REQ_GPS_SETTINGS); } catch (IntentSender.SendIntentException sendEx) {}
                }
            }
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) { promptForLocation(); } 
            else { if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false); }
        } else if (requestCode == REQ_MEDIA) {
            if (mPendingRequest != null) {
                boolean allGranted = true;
                for(int res : grantResults) { if (res != PackageManager.PERMISSION_GRANTED) allGranted = false; }
                if (allGranted) mPendingRequest.grant(mPendingRequest.getResources()); else mPendingRequest.deny();
                mPendingRequest = null;
            }
        }
    }
    @Override protected void onDestroy() { 
        if (myWebView != null) try { myWebView.destroy(); } catch (Exception e) {}; 
        if (mConnectivityManager != null && mNetworkCallback != null && Build.VERSION.SDK_INT >= 24) { try { mConnectivityManager.unregisterNetworkCallback(mNetworkCallback); } catch(Exception e) {} }
        super.onDestroy(); 
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { if(requestCode == 100 && mFilePathCallback != null) { mFilePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); mFilePathCallback = null; } }
    @Override public void onBackPressed() { if (myWebView != null && myWebView.canGoBack()) myWebView.goBack(); else super.onBackPressed(); }
}
\`;
        }

        // Canvas Icon Logic
        function createDefaultIcon(size, letter) {
            return new Promise((resolve) => {
                const canvas = document.createElement("canvas");
                canvas.width = size; canvas.height = size;
                const ctx = canvas.getContext("2d");
                if (ctx) {
                    ctx.fillStyle = "#3b82f6";
                    ctx.beginPath(); ctx.arc(size/2, size/2, size/2, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = "white"; ctx.font = \`bold \${size/2}px sans-serif\`;
                    ctx.textAlign = "center"; ctx.textBaseline = "middle";
                    ctx.fillText(letter, size/2, size/2);
                }
                canvas.toBlob((blob) => resolve(blob), "image/png");
            });
        }

        function processUserIcon(file, size) {
            return new Promise((resolve) => {
                const img = new Image();
                img.src = URL.createObjectURL(file);
                img.onload = () => {
                    const canvas = document.createElement("canvas");
                    canvas.width = size; canvas.height = size;
                    const ctx = canvas.getContext("2d");
                    if (ctx) ctx.drawImage(img, 0, 0, size, size);
                    canvas.toBlob((blob) => resolve(blob), "image/png");
                };
            });
        }

        async function generate() {
            const btn = document.getElementById('generateBtn');
            const errorMsg = document.getElementById('errorMsg');
            
            try {
                btn.disabled = true;
                btn.innerHTML = '<svg class="animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Generating...';
                errorMsg.style.display = 'none';

                const appName = document.getElementById('appName').value || "MyApp";
                const packageName = document.getElementById('packageName').value || "com.example.app";
                const targetUrl = document.getElementById('targetUrl').value || "https://google.com";
                let expirationDays = parseInt(document.getElementById('expirationDays').value) || 0;
                const versionCode = parseInt(document.getElementById('versionCode').value) || 1;
                const versionName = document.getElementById('versionName').value || "1.0.0";

                const iconInput = document.getElementById('iconFile');
                const file = iconInput.files[0];

                const zip = new JSZip();

                // Root
                zip.file("build.gradle", getBuildGradleProject());
                zip.file("settings.gradle", getSettingsGradle(appName));
                zip.file("gradle.properties", "android.useAndroidX=true\\nandroid.enableJetifier=true\\n# org.gradle.jvmargs=-Xmx208m -Dfile.encoding=UTF-8\\n");

                // App
                const appFolder = zip.folder("app");
                appFolder.file("build.gradle", getBuildGradleApp(packageName, versionCode, versionName));
                appFolder.file("proguard-rules.pro", "\\n");

                const mainSrc = appFolder.folder("src/main");
                
                const safeAppName = appName.replace(/[<>&'"]/g, ''); // Simple xml escape
                
                mainSrc.file("AndroidManifest.xml", getAndroidManifest(packageName, safeAppName));

                // Java
                const packagePath = packageName.replace(/\\./g, "/");
                mainSrc.file(\`java/\${packagePath}/MainActivity.java\`, getMainActivityJava(packageName, targetUrl, expirationDays));

                // Res
                const res = mainSrc.folder("res");
                const values = res.folder("values");
                values.file("strings.xml", \`<resources>\\n    <string name="app_name">\${safeAppName}</string>\\n</resources>\`);
                values.file("colors.xml", \`<resources>\\n    <color name="colorPrimary">#0F172A</color>\\n    <color name="colorPrimaryDark">#020617</color>\\n    <color name="colorAccent">#3B82F6</color>\\n</resources>\`);
                values.file("styles.xml", \`<resources>\\n    <style name="AppTheme" parent="android:Theme.DeviceDefault.Light.NoActionBar">\\n        <item name="android:colorPrimary">@color/colorPrimary</item>\\n        <item name="android:colorPrimaryDark">@color/colorPrimaryDark</item><item name="android:colorAccent">@color/colorAccent</item>\\n    </style>\\n</resources>\`);

                // Assets
                const assets = mainSrc.folder("assets");
                assets.file("offline.html", OFFLINE_HTML);
                assets.file("expired.html", EXPIRED_HTML);

                // Icons
                const iconSizes = [
                    { name: "mipmap-mdpi", size: 48 },
                    { name: "mipmap-hdpi", size: 72 },
                    { name: "mipmap-xhdpi", size: 96 },
                    { name: "mipmap-xxhdpi", size: 144 },
                    { name: "mipmap-xxxhdpi", size: 192 },
                ];

                const firstChar = appName.charAt(0).toUpperCase() || "A";

                for (const icon of iconSizes) {
                    const folder = res.folder(icon.name);
                    let blob;
                    if (file) blob = await processUserIcon(file, icon.size);
                    else blob = await createDefaultIcon(icon.size, firstChar);
                    folder.file("ic_launcher.png", blob);
                    folder.file("ic_launcher_round.png", blob);
                }

                const wrapper = zip.folder("gradle/wrapper");
                wrapper.file("gradle-wrapper.properties", \`distributionBase=GRADLE_USER_HOME\\ndistributionPath=wrapper/dists\\ndistributionUrl=https\\\\://services.gradle.org/distributions/gradle-6.1.1-bin.zip\\nzipStoreBase=GRADLE_USER_HOME\\nzipStorePath=wrapper/dists\\n\`);

                const content = await zip.generateAsync({ type: "base64" });
                
                if (window.AndroidFunction) {
                    window.AndroidFunction.saveProject(content, appName.replace(/[^a-zA-Z0-9]/g, '_') + ".zip");
                } else {
                    const a = document.createElement('a');
                    a.href = "data:application/zip;base64," + content;
                    a.download = appName + ".zip";
                    a.click();
                }

                btn.innerHTML = '${iconDownload} Generate APK Project';
                btn.disabled = false;
            } catch (e) {
                console.error(e);
                errorMsg.innerText = e.message;
                errorMsg.style.display = 'block';
                btn.innerHTML = 'Try Again';
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>`;
}

export const generateAndroidZip = async (config: AppConfig, mode: 'webview' | 'builder' = 'webview') => {
  const zip = new JSZip();

  // Root
  // HARDCODED GRADLE 6.1.1 & AGP 3.6.4 (Highly stable)
  // FIXED: Newlines added for proper parsing
  zip.file("build.gradle", getBuildGradleProject());
  zip.file("settings.gradle", getSettingsGradle(config.appName));
  zip.file("gradle.properties", `android.useAndroidX=true
android.enableJetifier=true
# org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
`);

  // App
  const appFolder = zip.folder("app");
  appFolder.file("build.gradle", getBuildGradleApp(config, mode));
  appFolder.file("proguard-rules.pro", "\n");

  const mainSrc = appFolder.folder("src/main");
  // Ensure App Name is XML safe
  const xmlSafeAppName = escapeXml(config.appName);
  // Create a config object with the safe name for the Manifest
  const safeConfig = { ...config, appName: xmlSafeAppName };
  mainSrc.file("AndroidManifest.xml", getAndroidManifest(safeConfig));

  // Java
  const packagePath = config.packageName.replace(/\./g, "/");
  mainSrc.file(`java/${packagePath}/MainActivity.java`, getMainActivityJava(config, mode));

  // Resources
  const res = mainSrc.folder("res");
  const values = res.folder("values");
  
  // STRINGS (XML Safe)
  values.file("strings.xml", `<resources>
    <string name="app_name">${xmlSafeAppName}</string>
</resources>`);

  // COLORS
  values.file("colors.xml", `<resources>
    <color name="colorPrimary">#0F172A</color>
    <color name="colorPrimaryDark">#020617</color>
    <color name="colorAccent">#3B82F6</color>
</resources>`);

  // STYLES
  // FIXED: Using Native Android Theme (No AppCompat dependency)
  values.file("styles.xml", `<resources>
    <style name="AppTheme" parent="android:Theme.DeviceDefault.Light.NoActionBar">
        <item name="android:colorPrimary">@color/colorPrimary</item>
        <item name="android:colorPrimaryDark">@color/colorPrimaryDark</item><item name="android:colorAccent">@color/colorAccent</item>
    </style>
</resources>`);

  // ASSETS - OFFLINE & EXPIRED HTML
  const assets = mainSrc.folder("assets");
  assets.file("offline.html", OFFLINE_HTML_FILE);
  assets.file("expired.html", EXPIRED_HTML_FILE);

  // Assets (Builder Mode)
  if (mode === 'builder') {
      let embeddedJsZip = false;
      // Android app ships the exact JSZip 3.10.1 source locally, so Builder Mode stays fully offline.
      if (jszipOfflineSource) {
          assets.file("jszip.min.js", jszipOfflineSource);
          embeddedJsZip = true;
      }
      if (!embeddedJsZip) {
          try {
            const jszipResponse = await fetch('https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js');
            if (jszipResponse.ok) {
                const jszipText = await jszipResponse.text();
                assets.file("jszip.min.js", jszipText);
                embeddedJsZip = true;
            }
          } catch (e) {
              console.warn("Could not fetch JSZip from CDN.");
          }
      }

      // CRITICAL UPDATE:
      // We no longer rely on self-replication via DOM.
      // We generate the index.html from the TEMPLATE function directly.
      // This ensures the offline APK has the FULL source code logic built-in.
      // NOTE: We do NOT pass role anymore, just the validity limit.
      const builderHtml = getEmbeddedBuilderHtml(config.maxValidityDays || 0);
      assets.file("index.html", builderHtml);
  }

  // Icons
  const iconSizes = [
    { name: "mipmap-mdpi", size: 48 },
    { name: "mipmap-hdpi", size: 72 },
    { name: "mipmap-xhdpi", size: 96 },
    { name: "mipmap-xxhdpi", size: 144 },
    { name: "mipmap-xxxhdpi", size: 192 },
  ];

  const createDefaultIcon = (size: number): Promise<Blob> => {
    return new Promise((resolve) => {
      const canvas = document.createElement("canvas");
      canvas.width = size; canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#3b82f6";
        ctx.beginPath(); ctx.arc(size/2, size/2, size/2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "white"; ctx.font = `bold ${size/2}px sans-serif`;
        ctx.textAlign = "center"; ctx.textBaseline = "middle";
        const firstChar = Array.from(config.appName)[0] || "A";
        ctx.fillText(firstChar.toUpperCase(), size/2, size/2);
      }
      canvas.toBlob((blob) => resolve(blob!), "image/png");
    });
  };

  const processUserIcon = (file: File, size: number): Promise<Blob> => {
      return new Promise((resolve) => {
          const img = new Image();
          img.src = URL.createObjectURL(file);
          img.onload = () => {
              const canvas = document.createElement("canvas");
              canvas.width = size; canvas.height = size;
              const ctx = canvas.getContext("2d");
              if (ctx) ctx.drawImage(img, 0, 0, size, size);
              canvas.toBlob((blob) => resolve(blob!), "image/png");
          };
      });
  };

  for (const icon of iconSizes) {
      const folder = res.folder(icon.name);
      let blob = config.iconFile ? await processUserIcon(config.iconFile, icon.size) : await createDefaultIcon(icon.size);
      folder.file("ic_launcher.png", blob);
      folder.file("ic_launcher_round.png", blob);
  }

  // Gradle Wrapper
  const wrapper = zip.folder("gradle/wrapper");
  // HARDCODED GRADLE 6.1.1
  wrapper.file("gradle-wrapper.properties", `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-6.1.1-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);

  const content = await zip.generateAsync({ type: "blob" });
  await saveGeneratedProject(content, `${config.appName.replace(/[^a-zA-Z0-9]/g, '_')}.zip`, config.appName);
};