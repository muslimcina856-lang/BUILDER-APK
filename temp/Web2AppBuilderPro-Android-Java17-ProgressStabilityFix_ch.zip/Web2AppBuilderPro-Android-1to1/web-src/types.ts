
export interface AppConfig {
  appName: string;
  packageName: string;
  versionCode: number;
  versionName: string;
  targetUrl: string;
  expirationDays: number; // 0 = lifetime
  maxValidityDays: number; // Limit for the generated APK builder (0 = no limit)
  enableJavascript: boolean;
  userAgent: string;
  iconFile: File | null;
}

export const DEFAULT_CONFIG: AppConfig = {
  appName: "My Web App",
  packageName: "com.example.webapp",
  versionCode: 1,
  versionName: "1.0.0",
  targetUrl: "https://www.google.com",
  expirationDays: 0,
  maxValidityDays: 0, // Default no limit
  enableJavascript: true,
  userAgent: "",
  iconFile: null
};