# Local Build Tools - Ringkasan

**Unlock:** tap tajuk `Web2App Builder Pro` 7 kali.

**Tanpa tools:** Generate = ZIP source biasa.

**Dengan status READY:** Generate = ZIP source + `APK/<AppName>.apk` yang telah di-zipalign, sign dan verify.

**Jika build gagal:** source ZIP tetap cuba disimpan.

**Tools:** OpenJDK 17 (Android ARM64) + Gradle 7.6.4 + Android SDK 29 + Android ARM build-tools 34.0.4.

**CPU local build:** ARM64. ARM32/x86/x86_64 menggunakan fallback ZIP biasa kerana pakej OpenJDK 17 Android yang digunakan ialah ARM64.

**Internet:** diperlukan semasa pemasangan awal toolchain dan apabila Gradle perlu mengambil dependency yang belum berada dalam cache. Selepas dependency lengkap/cached, build seterusnya boleh menggunakan cache tempatan.

**READY check:** installer melakukan self-test Gradle dan tidak menanda READY jika compiler tidak benar-benar berfungsi pada device.

**Upgrade daripada toolchain lama:** marker Java 11/Gradle 6.1.1 tidak lagi dianggap READY. Buka panel rahsia dan pilih `Repair / Reinstall Tools` untuk memasang Java 17.

**Release wrapper:** `targetSdk 28` dikekalkan untuk local executable toolchain. Release build hanya mengecualikan lint `ExpiredTargetSdkVersion`; lint lain kekal aktif.

**Java 17 compatibility:** source ZIP yang dijana tidak ditukar. Hanya salinan sementara ketika local APK build dipatch daripada AGP 3.6.4 kepada AGP 7.4.2 supaya boleh dibina dengan Java 17/Gradle 7.6.4.
