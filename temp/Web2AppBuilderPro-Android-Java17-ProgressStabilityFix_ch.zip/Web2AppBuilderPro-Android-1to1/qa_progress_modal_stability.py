import base64, json, shutil, subprocess, tempfile, time, urllib.request, websocket
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'android/app/src/main/assets'
PORT = 9359
PROFILE = Path(tempfile.mkdtemp(prefix='w2a-progress-'))
chromium = subprocess.Popen([
    '/usr/bin/chromium','--headless=new','--no-sandbox','--disable-gpu',
    f'--remote-debugging-port={PORT}',f'--user-data-dir={PROFILE}',
    '--remote-allow-origins=*','--window-size=432,640','about:blank'
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

try:
    pages = None
    for _ in range(80):
        try:
            pages = json.load(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/json/list', timeout=1))
            if pages: break
        except Exception:
            time.sleep(.1)
    if not pages:
        raise RuntimeError('Chromium DevTools did not start')

    ws = websocket.create_connection(pages[0]['webSocketDebuggerUrl'], timeout=30, origin=f'http://127.0.0.1:{PORT}')
    seq = [0]
    def call(method, params=None):
        seq[0] += 1
        i = seq[0]
        ws.send(json.dumps({'id': i, 'method': method, 'params': params or {}}))
        while True:
            msg = json.loads(ws.recv())
            if msg.get('id') == i:
                return msg

    def evaljs(expr):
        r = call('Runtime.evaluate', {'expression': expr, 'returnByValue': True})
        if r.get('result', {}).get('exceptionDetails'):
            raise RuntimeError(r['result']['exceptionDetails'])
        return r.get('result', {}).get('result', {}).get('value')

    css = (BASE/'app.css').read_text()
    jszip = (BASE/'jszip.min.js').read_text().replace('</script>', '<\\/script>')
    source = (BASE/'jszip-source.js').read_text().replace('</script>', '<\\/script>')
    bundle = (BASE/'app.bundle.js').read_text().replace('</script>', '<\\/script>')
    html = f'<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>{css}</style></head><body><div id="root"></div><script>{jszip}</script><script>{source}</script><script>{bundle}</script></body></html>'

    call('Page.enable'); call('Runtime.enable')
    frame = call('Page.getFrameTree')['result']['frameTree']['frame']['id']
    call('Page.setDocumentContent', {'frameId': frame, 'html': html})
    time.sleep(.4)

    evaljs("""window.AndroidFunction={
      getBuildToolsStatus:()=>JSON.stringify({installed:false,installing:false,arch:'arm64-v8a',message:'not installed'}),
      installBuildTools:(requestId)=>{window.__requestId=requestId;},
      saveProject:()=>{}, buildProjectWithApk:()=>{}, copyText:()=>{}
    };""")

    for _ in range(7):
        evaljs("document.querySelector('h1').click()")
    time.sleep(.2)
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Download & Install Tools')).click()")
    time.sleep(.2)

    before = evaljs("""(()=>{
      const e=document.querySelector('[data-build-tools-scroll]');
      e.scrollTop=Math.max(1,e.scrollHeight-e.clientHeight);
      window.__oldScrollNode=e;
      return {scrollTop:e.scrollTop, max:e.scrollHeight-e.clientHeight};
    })()""")
    if not before or before['max'] <= 0 or before['scrollTop'] <= 0:
        raise RuntimeError(f'Popup was not scrollable in regression setup: {before}')

    for progress in range(41, 48):
        evaljs(f"window.__W2A_BUILD_TOOLS_EVENT__({{requestId:window.__requestId,progress:{progress},stage:'Downloading OpenJDK 17...',done:false,success:false,arch:'arm64-v8a'}})")
        time.sleep(.03)
    after = evaljs("""(()=>{
      const e=document.querySelector('[data-build-tools-scroll]');
      return {
        oldConnected: window.__oldScrollNode?.isConnected === true,
        sameNode: e === window.__oldScrollNode,
        scrollTop: e?.scrollTop || 0,
        percent: document.querySelector('[data-build-tools-percent]')?.textContent || ''
      };
    })()""")

    screenshot = call('Page.captureScreenshot', {'format':'png','captureBeyondViewport':False})
    (ROOT/'preview-05-progress-stable-scrolled.png').write_bytes(base64.b64decode(screenshot['result']['data']))

    checks = {
        'repeated progress updates keep same modal DOM node': bool(after and after['oldConnected'] and after['sameNode']),
        'repeated progress updates preserve popup scroll position': bool(after and abs(after['scrollTop'] - before['scrollTop']) <= 1),
        'progress text updates through 47%': bool(after and after['percent'].strip() == '47%'),
    }
    for name, ok in checks.items():
        print(('PASS' if ok else 'FAIL') + ' - ' + name)
    if not all(checks.values()):
        raise SystemExit(2)
finally:
    try:
        chromium.terminate(); chromium.wait(timeout=3)
    except Exception:
        try: chromium.kill()
        except Exception: pass
    shutil.rmtree(PROFILE, ignore_errors=True)
