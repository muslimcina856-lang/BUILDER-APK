from pathlib import Path

root = Path(__file__).resolve().parent
app = (root/'web-src/App.tsx').read_text()
zipgen = (root/'web-src/services/zipGenerator.ts').read_text()
java_text = '\n'.join(p.read_text() for p in (root/'android/app/src/main/java').rglob('*.java'))
main = (root/'android/app/src/main/java/com/web2app/builderpro/MainActivity.java').read_text()
app_gradle = (root/'android/app/build.gradle').read_text()

checks = {
    'secret 7-tap unlock': 'SECRET_TAP_TARGET' in app and 'tapCount >= SECRET_TAP_TARGET' in app,
    'hidden build tools panel': 'Local Build Tools' in app and 'Download & Install Tools' in app,
    'status bridge': 'getBuildToolsStatus' in app and '@JavascriptInterface\n        public String getBuildToolsStatus' in main,
    'installer bridge': 'installBuildTools' in app and 'public void installBuildTools' in main,
    'local-build bridge': 'buildProjectWithApk' in zipgen and 'public void buildProjectWithApk' in main,
    'source ZIP fallback remains': 'saveProject(base64, fileName)' in zipgen,
    'native build callback': '__W2A_LOCAL_BUILD_EVENT__' in zipgen and '__W2A_LOCAL_BUILD_EVENT__' in main,
    'installer progress callback': '__W2A_BUILD_TOOLS_EVENT__' in app and '__W2A_BUILD_TOOLS_EVENT__' in main,
    'AndroidIDE SDK source': 'AndroidIDEOfficial/androidide-tools' in java_text,
    'Gradle 7.6.4 local tool': 'gradle-7.6.4-bin.zip' in java_text and 'gradle-6.1.1-bin.zip' not in java_text,
    'JDK 17 local tool': 'jdk17-arm64.tar.xz' in java_text and 'jdk11-aarch64.tar.xz' not in java_text,
    'JDK 17 ARM64 source': 'itsaky/openjdk-17-android/releases/download/01-01-2022/jdk17-arm64.tar.xz' in java_text,
    'local Java17 build compatibility patch': 'com.android.tools.build:gradle:7.4.2' in java_text and "ExpiredTargetSdkVersion" in java_text,
    'toolchain marker versioned for Java17': 'TOOLCHAIN_VERSION' in java_text and 'java17-gradle7' in java_text,
    'platform android-29 install': 'platforms;android-29' in java_text,
    'release APK signing': 'apksigner.jar' in java_text and 'keytool' in java_text,
    'APK added into final ZIP': 'APK/' in java_text and 'appendApkToZip' in java_text,
    'target sdk permits downloaded executables': 'targetSdk 28' in app_gradle,
    'wrapper release lint exception only for expired target': 'ExpiredTargetSdkVersion' in app_gradle,
    'tar.xz support': 'commons-compress' in app_gradle and "org.tukaani:xz" in app_gradle,
    'platform install progress stays monotonic': 'listener.onProgress(70, "Extracting Android platform 29...")' not in java_text,
    'ready marker only after self-test': java_text.find('runSelfTest(listener);') < java_text.find('writeText(readyMarker'),
    'build tools modal has dedicated mobile scroll area': 'data-build-tools-scroll' in app and "touchAction: 'pan-y'" in app and "overscrollBehavior: 'contain'" in app,
    'build tools modal locks background scroll': 'lockPageScroll' in app and 'unlockPageScroll' in app,
    'progress events avoid React state rerender': 'setBuildToolsProgress' not in app and 'setBuildToolsStage' not in app and 'updateBuildToolsProgressUi(event.progress, event.stage)' in app,
    'progress bar updates without layout width churn': 'data-build-tools-progress-bar' in app and "scaleX(${safeProgress / 100})" in app,
    'build tools overlay avoids Android WebView backdrop blur': 'data-build-tools-modal="true"' in app and 'p-4 bg-black/80' in app,
}

failed = [k for k,v in checks.items() if not v]
for k,v in checks.items():
    print(('PASS' if v else 'FAIL') + ' - ' + k)
if failed:
    raise SystemExit(f"\n{len(failed)} checks failed: " + ', '.join(failed))
print(f"\nAll {len(checks)} checks passed")
