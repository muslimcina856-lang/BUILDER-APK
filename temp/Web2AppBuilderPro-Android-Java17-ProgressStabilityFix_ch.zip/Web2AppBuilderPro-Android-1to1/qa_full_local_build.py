import json, urllib.request, websocket, base64, time, io, zipfile, subprocess, tempfile, shutil, os, signal
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'android/app/src/main/assets'
PORT=9347
PROFILE=Path(tempfile.mkdtemp(prefix='w2a-chromium-'))
chromium=subprocess.Popen([
    '/usr/bin/chromium','--headless=new','--no-sandbox','--disable-gpu',
    f'--remote-debugging-port={PORT}',f'--user-data-dir={PROFILE}',
    '--remote-allow-origins=*','--window-size=432,960','about:blank'
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

try:
    pages=None
    for _ in range(80):
        try:
            pages=json.load(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/json/list', timeout=1))
            if pages: break
        except Exception: time.sleep(.1)
    if not pages: raise RuntimeError('Chromium DevTools did not start')

    ws=websocket.create_connection(pages[0]['webSocketDebuggerUrl'],timeout=30,origin=f'http://127.0.0.1:{PORT}')
    seq=0
    def call(m,p=None):
        nonlocal_seq[0]+=1
        i=nonlocal_seq[0]
        ws.send(json.dumps({'id':i,'method':m,'params':p or {}}))
        while True:
            x=json.loads(ws.recv())
            if x.get('id')==i: return x
    nonlocal_seq=[0]

    def evaljs(expr, await_promise=False):
        r=call('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':await_promise})
        rr=r.get('result',{}).get('result',{})
        if r.get('result',{}).get('exceptionDetails'):
            raise RuntimeError(r['result']['exceptionDetails'])
        return rr.get('value')

    def shot(name,w=432,h=960):
        call('Emulation.setDeviceMetricsOverride',{'width':w,'height':h,'deviceScaleFactor':1,'mobile':True})
        time.sleep(.2)
        r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False})
        (ROOT/name).write_bytes(base64.b64decode(r['result']['data']))

    css=(BASE/'app.css').read_text()
    jszip=(BASE/'jszip.min.js').read_text().replace('</script>','<\\/script>')
    source=(BASE/'jszip-source.js').read_text().replace('</script>','<\\/script>')
    bundle=(BASE/'app.bundle.js').read_text().replace('</script>','<\\/script>')
    html=f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>{css}</style></head><body><div id="root"></div><script>{jszip}</script><script>{source}</script><script>{bundle}</script></body></html>'

    call('Page.enable'); call('Runtime.enable')
    frame=call('Page.getFrameTree')['result']['frameTree']['frame']['id']
    call('Page.setDocumentContent',{'frameId':frame,'html':html})
    time.sleep(.5)

    # Native bridge simulation. buildProjectWithApk captures source ZIP then reports completion.
    evaljs(r'''window.__toolInstallRequests=[]; window.__nativeBuildCalls=[];
    window.AndroidFunction={
      saveProject:(b,n)=>{window.__saved={b,n,via:'saveProject'};},
      copyText:(t)=>{window.__copied=t;},
      getBuildToolsStatus:()=>JSON.stringify({installed:false,installing:false,building:false,arch:'arm64-v8a',message:'Toolchain not installed. Generate will keep saving the source ZIP normally.'}),
      installBuildTools:(r)=>{window.__toolInstallRequests.push(r); setTimeout(()=>window.__W2A_BUILD_TOOLS_EVENT__?.({requestId:r,progress:48,stage:'Downloading OpenJDK 17...',done:false,success:false,arch:'arm64-v8a'}),20); setTimeout(()=>window.__W2A_BUILD_TOOLS_EVENT__?.({requestId:r,progress:100,stage:'Local build tools ready',done:true,success:true,arch:'arm64-v8a',message:'Installation complete. Generate can now include a signed APK.'}),80);},
      buildProjectWithApk:(b,n,a,r)=>{window.__nativeBuildCalls.push({b,n,a,r}); window.__saved={b,n,via:'buildProjectWithApk'}; setTimeout(()=>window.__W2A_LOCAL_BUILD_EVENT__?.({requestId:r,progress:100,stage:'done',done:true,success:true,fallback:false,message:'ok'}),20);}
    };''')

    results=[]
    def check(name, ok): results.append((name, bool(ok)))

    text=evaljs('document.body.innerText') or ''
    check('initial_title', 'Web2App Builder Pro' in text)
    check('standard_toggle', 'Switch to Web2App App' in text)
    check('target_url_present', 'Target URL (WebView)' in text)
    check('user_agent_present', 'User Agent (Optional)' in text)
    check('project_structure_present', 'Project Structure' in text)
    check('secret_panel_hidden_initially', 'Local Build Tools' not in text)
    shot('preview-01-normal.png')

    # Secret gesture: exactly seven title taps.
    for i in range(6):
        evaljs("document.querySelector('h1').click()")
    time.sleep(.1)
    check('secret_still_hidden_after_6', 'Local Build Tools' not in (evaljs('document.body.innerText') or ''))
    evaljs("document.querySelector('h1').click()")
    time.sleep(.25)
    secret_text=evaljs('document.body.innerText') or ''
    check('secret_unlock_after_7', 'Local Build Tools' in secret_text)
    check('secret_download_button', 'Download & Install Tools' in secret_text)
    check('secret_arch_status', 'arm64-v8a' in secret_text)
    check('java17_visible', 'OpenJDK 17' in secret_text and 'Gradle' in secret_text and '7.6.4' in secret_text)
    check('modal_locks_background_scroll', evaljs("document.body.style.overflow==='hidden'") is True)
    check('modal_has_touch_scroll_area', evaljs("(()=>{const e=document.querySelector('[data-build-tools-scroll]');if(!e)return false;const s=getComputedStyle(e);return s.overflowY==='auto'&&e.style.touchAction==='pan-y'&&e.style.overscrollBehavior==='contain';})()") is True)
    # Verify the popup itself scrolls on a short phone viewport rather than the page behind it.
    call('Emulation.setDeviceMetricsOverride',{'width':432,'height':640,'deviceScaleFactor':1,'mobile':True})
    time.sleep(.15)
    scroll_result=evaljs("(()=>{const e=document.querySelector('[data-build-tools-scroll]');if(!e)return {ok:false};const beforeY=window.scrollY;e.scrollTop=240;return {ok:e.scrollTop>0,pageY:window.scrollY,beforeY,sh:e.scrollHeight,ch:e.clientHeight};})()")
    check('modal_scrolls_independently_on_short_screen', bool(scroll_result and scroll_result.get('ok') and scroll_result.get('pageY')==scroll_result.get('beforeY') and scroll_result.get('sh',0)>scroll_result.get('ch',0)))
    shot('preview-04-popup-scrolled-mobile.png', 432, 640)
    call('Emulation.setDeviceMetricsOverride',{'width':432,'height':960,'deviceScaleFactor':1,'mobile':True})
    evaljs("(()=>{const e=document.querySelector('[data-build-tools-scroll]');if(e)e.scrollTop=0;})()")
    shot('preview-02-hidden-build-tools.png')

    # Installer callbacks update modal state.
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Download & Install Tools')).click()")
    time.sleep(.15)
    installed_text=evaljs('document.body.innerText') or ''
    check('installer_request_called', (evaljs('window.__toolInstallRequests.length') or 0)==1)
    check('installer_ready_state', 'READY' in installed_text and 'Repair / Reinstall Tools' in installed_text)
    shot('preview-03-build-tools-ready.png')

    # Close tools modal.
    # More robust: click first button inside current modal header if still visible.
    if 'Local Build Tools' in (evaljs('document.body.innerText') or ''):
        evaljs("(()=>{const modal=[...document.querySelectorAll('h3')].find(h=>h.innerText.includes('Local Build Tools'))?.closest('div.fixed'); const b=modal?.querySelector('button'); b?.click();})()")
    time.sleep(.15)
    check('modal_unlocks_background_scroll_after_close', evaljs("document.body.style.overflow!=='hidden'") is True)

    # Package sanitization.
    evaljs("(()=>{let x=[...document.querySelectorAll('input')].find(e=>e.value==='com.example.webapp');x.value='Com.Test! App';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
    time.sleep(.15)
    pkg=evaljs("[...document.querySelectorAll('input')].find(e=>e.value.includes('com.test'))?.value")
    check('package_sanitization', pkg=='com.testapp')

    # Expiration card.
    evaljs("(()=>{let labels=[...document.querySelectorAll('label')];let l=labels.find(x=>x.innerText.includes('Validity (Days)'));let x=l.parentElement.querySelector('input');x.value='7';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
    time.sleep(.15)
    check('expiration_card', 'Expiration Active' in (evaljs('document.body.innerText') or ''))

    # Icon upload/remove.
    evaljs("""(async()=>{const c=document.createElement('canvas');c.width=64;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='#3b82f6';ctx.fillRect(0,0,64,64);ctx.fillStyle='white';ctx.font='bold 36px sans-serif';ctx.fillText('Q',18,44);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const f=new File([blob],'qa-icon.png',{type:'image/png'});const dt=new DataTransfer();dt.items.add(f);const x=document.querySelector('input[type=file]');x.files=dt.files;x.dispatchEvent(new Event('change',{bubbles:true}));return true;})()""", await_promise=True)
    time.sleep(.2)
    check('icon_upload_preview', evaljs("document.body.innerText.includes('qa-icon.png')") is True)
    evaljs("document.querySelector('button[class*=\"bg-red-900\"]')?.click()")
    time.sleep(.15)
    check('icon_remove_ui', evaljs("!document.body.innerText.includes('qa-icon.png')") is True)

    # Standard generation through NEW native build bridge.
    evaljs('window.__saved=null')
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Generate WebView App')).click()")
    end=time.time()+20
    while time.time()<end and not evaljs('window.__saved ? true : false'): time.sleep(.1)
    saved=evaljs('window.__saved')
    check('standard_uses_local_build_bridge', saved and saved.get('via')=='buildProjectWithApk')
    raw=base64.b64decode(saved['b'])
    (ROOT/'qa-standard-generated.zip').write_bytes(raw)
    z=zipfile.ZipFile(io.BytesIO(raw)); names=set(z.namelist())
    main=[n for n in names if n.endswith('/MainActivity.java')][0]
    java=z.read(main).decode('utf-8')
    check('standard_zip_structure', all(x in names for x in ['build.gradle','settings.gradle','app/src/main/AndroidManifest.xml','app/src/main/assets/offline.html','app/src/main/assets/expired.html']))
    check('standard_target_url_logic', 'https://www.google.com' in java)
    check('standard_expiration_logic', 'final long EXPIRY =' in java and 'expired.html' in java)
    check('standard_custom_icon_generated', any(n.endswith('mipmap-xxxhdpi/ic_launcher.png') for n in names))

    # Builder mode + output.
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Switch to Web2App App')).click()")
    time.sleep(.2)
    text=evaljs('document.body.innerText') or ''
    check('builder_title', 'Web2App App Generator' in text)
    check('builder_advanced_setting', 'Advanced Settings (Internal App Limit)' in text)
    check('builder_target_hidden', 'Target URL (WebView)' not in text)
    check('builder_useragent_hidden', 'User Agent (Optional)' not in text)
    check('builder_assets_structure', 'app/src/main/assets (Local HTML)' in text)

    evaljs("(()=>{let x=[...document.querySelectorAll('input[type=number]')][0];x.value='30';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
    time.sleep(.1)
    evaljs('window.__saved=null')
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Generate Local App')).click()")
    end=time.time()+20
    while time.time()<end and not evaljs('window.__saved ? true : false'): time.sleep(.1)
    saved2=evaljs('window.__saved')
    raw2=base64.b64decode(saved2['b'])
    (ROOT/'qa-builder-generated.zip').write_bytes(raw2)
    z2=zipfile.ZipFile(io.BytesIO(raw2)); names2=set(z2.namelist())
    idx=z2.read('app/src/main/assets/index.html').decode('utf-8')
    check('builder_zip_structure', 'app/src/main/assets/index.html' in names2 and 'app/src/main/assets/jszip.min.js' in names2)
    check('builder_limit_injected', 'const MAX_LIMIT = 30' in idx)
    check('builder_android_bridge', 'AndroidFunction.saveProject' in idx)

    # Prompt modal/copy remains.
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Create your own')).click()")
    time.sleep(.15)
    check('prompt_modal', 'Prompt for AI Generation' in (evaljs('document.body.innerText') or ''))
    evaljs('window.__copied=null')
    evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText==='Copy to Clipboard').click()")
    time.sleep(.1)
    copied=evaljs('window.__copied') or ''
    check('prompt_copy_native', copied.startswith('Bertindak sebagai Jurutera Frontend Kanan'))

    ws.close()
    report='\n'.join(f"{'PASS' if ok else 'FAIL'}  {name}" for name,ok in results)
    (ROOT/'QA_FULL_LOCAL_BUILD.txt').write_text(report+'\n')
    print(report)
    if not all(ok for _,ok in results): raise SystemExit(2)
finally:
    try: chromium.terminate(); chromium.wait(timeout=3)
    except Exception:
        try: chromium.kill()
        except Exception: pass
    shutil.rmtree(PROFILE, ignore_errors=True)
