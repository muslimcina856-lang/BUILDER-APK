import json, urllib.request, websocket, base64, time, io, zipfile, os
from pathlib import Path

PORT=9228
BASE=Path('/mnt/data/Web2AppBuilderPro-Android-1to1/android/app/src/main/assets')
OUT=Path('/mnt/data/Web2AppBuilderPro-Android-1to1')
css=(BASE/'app.css').read_text()
jszip=(BASE/'jszip.min.js').read_text().replace('</script>','<\\/script>')
source=(BASE/'jszip-source.js').read_text().replace('</script>','<\\/script>')
bundle=(BASE/'app.bundle.js').read_text().replace('</script>','<\\/script>')
html=f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>{css}</style></head><body><div id="root"></div><script>{jszip}</script><script>{source}</script><script>{bundle}</script></body></html>'

pages=json.load(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/json/list'))
ws=websocket.create_connection(pages[0]['webSocketDebuggerUrl'],timeout=30,origin=f'http://127.0.0.1:{PORT}')
seq=0
def call(m,p=None):
    global seq
    seq+=1
    ws.send(json.dumps({'id':seq,'method':m,'params':p or {}}))
    while True:
        x=json.loads(ws.recv())
        if x.get('id')==seq: return x

def evaljs(expr, await_promise=False):
    r=call('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':await_promise})
    rr=r.get('result',{}).get('result',{})
    if 'exceptionDetails' in r.get('result',{}):
        raise RuntimeError(r['result']['exceptionDetails'])
    return rr.get('value')

def shot(name,w=412,h=915):
    call('Emulation.setDeviceMetricsOverride',{'width':w,'height':h,'deviceScaleFactor':1,'mobile':True})
    time.sleep(.25)
    r=call('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False})
    (OUT/name).write_bytes(base64.b64decode(r['result']['data']))

def wait_saved(timeout=15):
    end=time.time()+timeout
    while time.time()<end:
        v=evaljs('window.__saved ? window.__saved.n : null')
        if v: return v
        time.sleep(.25)
    raise TimeoutError('ZIP was not captured')

call('Page.enable'); call('Runtime.enable')
frame=call('Page.getFrameTree')['result']['frameTree']['frame']['id']
call('Page.setDocumentContent',{'frameId':frame,'html':html})
time.sleep(.5)
# Native bridge stub to test Android-specific adapters.
evaljs("window.AndroidFunction={saveProject:(b,n)=>{window.__saved={b:b,n:n};},copyText:(t)=>{window.__copied=t;}}")

results=[]
text=evaljs('document.body.innerText')
results.append(('initial_title', 'Web2App Builder Pro' in text))
results.append(('standard_toggle', 'Switch to Web2App App' in text))
results.append(('target_url_present', 'Target URL (WebView)' in text))
results.append(('user_agent_present', 'User Agent (Optional)' in text))
results.append(('project_structure_present', 'Project Structure' in text))
shot('preview-01-standard.png')

# Text input behavior + package sanitization.
evaljs("(()=>{let x=[...document.querySelectorAll('input')].find(e=>e.value==='com.example.webapp');x.value='Com.Test! App';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
time.sleep(.2)
pkg=evaljs("[...document.querySelectorAll('input')].find(e=>e.value.includes('com.test'))?.value")
results.append(('package_sanitization', pkg=='com.testapp'))

# Expiration card behavior.
evaljs("(()=>{let labels=[...document.querySelectorAll('label')];let l=labels.find(x=>x.innerText.includes('Validity (Days)'));let x=l.parentElement.querySelector('input');x.value='7';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
time.sleep(.2)
results.append(('expiration_card', 'Expiration Active' in evaljs('document.body.innerText')))

# File upload using a browser-generated valid PNG File.
evaljs("""(async()=>{const c=document.createElement('canvas');c.width=64;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='#3b82f6';ctx.fillRect(0,0,64,64);ctx.fillStyle='white';ctx.font='bold 36px sans-serif';ctx.fillText('Q',18,44);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const f=new File([blob],'qa-icon.png',{type:'image/png'});const dt=new DataTransfer();dt.items.add(f);const x=document.querySelector('input[type=file]');x.files=dt.files;x.dispatchEvent(new Event('change',{bubbles:true}));return true;})()""", await_promise=True)
time.sleep(.3)
results.append(('icon_upload_preview', evaljs("document.body.innerText.includes('qa-icon.png')") is True))
# Remove the uploaded icon through the same UI control before the main UI generation test.
evaljs("document.querySelector('button[class*=\"bg-red-900\"]')?.click()")
time.sleep(.2)
results.append(('icon_remove_ui', evaljs("!document.body.innerText.includes('qa-icon.png')") is True))

# Standard WebView generation.
evaljs('window.__saved=null')
evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Generate WebView App')).click()")
name=wait_saved()
b64=evaljs('window.__saved.b')
raw=base64.b64decode(b64)
(OUT/'qa-standard-generated.zip').write_bytes(raw)
z=zipfile.ZipFile(io.BytesIO(raw))
names=set(z.namelist())
main=[n for n in names if n.endswith('/MainActivity.java')][0]
java=z.read(main).decode('utf-8')
manifest=z.read('app/src/main/AndroidManifest.xml').decode('utf-8')
results.append(('standard_zip_name', name.endswith('.zip')))
results.append(('standard_zip_structure', all(x in names for x in ['build.gradle','settings.gradle','app/src/main/AndroidManifest.xml','app/src/main/assets/offline.html','app/src/main/assets/expired.html'])))
results.append(('standard_target_url_logic', 'https://www.google.com' in java))
results.append(('standard_expiration_logic', 'final long EXPIRY =' in java and 'expired.html' in java))
results.append(('standard_custom_icon_generated', any(n.endswith('mipmap-xxxhdpi/ic_launcher.png') for n in names)))

# Toggle to Builder mode.
evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Switch to Web2App App')).click()")
time.sleep(.3)
text=evaljs('document.body.innerText')
results.append(('builder_title', 'Web2App App Generator' in text))
results.append(('builder_advanced_setting', 'Advanced Settings (Internal App Limit)' in text))
results.append(('builder_target_hidden', 'Target URL (WebView)' not in text))
results.append(('builder_useragent_hidden', 'User Agent (Optional)' not in text))
results.append(('builder_assets_structure', 'app/src/main/assets (Local HTML)' in text))
shot('preview-02-builder.png')

# Set max validity to 30 and generate Builder mode output.
evaljs("(()=>{let x=[...document.querySelectorAll('input[type=number]')][0];x.value='30';x.dispatchEvent(new Event('input',{bubbles:true}));})()")
time.sleep(.2)
evaljs('window.__saved=null')
evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Generate Local App')).click()")
name2=wait_saved(20)
b642=evaljs('window.__saved.b')
raw2=base64.b64decode(b642)
(OUT/'qa-builder-generated.zip').write_bytes(raw2)
z2=zipfile.ZipFile(io.BytesIO(raw2)); names2=set(z2.namelist())
idx=z2.read('app/src/main/assets/index.html').decode('utf-8')
results.append(('builder_zip_structure', 'app/src/main/assets/index.html' in names2 and 'app/src/main/assets/jszip.min.js' in names2))
results.append(('builder_limit_injected', 'const MAX_LIMIT = 30' in idx))
results.append(('builder_android_bridge', 'AndroidFunction.saveProject' in idx))

# Open prompt modal + copy bridge test.
evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText.includes('Create your own')).click()")
time.sleep(.2)
modaltext=evaljs('document.body.innerText')
results.append(('prompt_modal', 'Prompt for AI Generation' in modaltext))
shot('preview-03-prompt-modal.png')
evaljs('window.__copied=null')
evaljs("[...document.querySelectorAll('button')].find(b=>b.innerText==='Copy to Clipboard').click()")
time.sleep(.2)
copied=evaljs('window.__copied') or ''
results.append(('prompt_copy_native', copied.startswith('Bertindak sebagai Jurutera Frontend Kanan')))

ws.close()

report='\n'.join(f"{'PASS' if ok else 'FAIL'}  {name}" for name,ok in results)
(OUT/'QA_FEATURE_PARITY.txt').write_text(report+'\n')
print(report)
if not all(ok for _,ok in results):
    raise SystemExit(2)
