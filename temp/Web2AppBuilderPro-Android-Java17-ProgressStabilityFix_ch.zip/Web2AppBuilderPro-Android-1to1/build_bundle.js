const fs = require('fs');
const path = require('path');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const projectRoot = __dirname;
const root = path.join(projectRoot, 'web-src');
const out = path.join(projectRoot, 'android/app/src/main/assets');

const sources = {
  'types': 'types.ts',
  'services/zipGenerator': 'services/zipGenerator.ts',
  'components/ConfigForm': 'components/ConfigForm.tsx',
  'App': 'App.tsx',
  'index': 'index.tsx',
};

function transpile(file) {
  const src = fs.readFileSync(path.join(root, file), 'utf8');
  return ts.transpileModule(src, {
    fileName: file,
    compilerOptions: {
      target: ts.ScriptTarget.ES2018,
      module: ts.ModuleKind.CommonJS,
      jsx: ts.JsxEmit.React,
      esModuleInterop: true,
      allowSyntheticDefaultImports: true,
      removeComments: false,
    }
  }).outputText;
}

const compiled = {};
for (const [id, file] of Object.entries(sources)) compiled[id] = transpile(file);

const runtime = String.raw`
(function(){
  'use strict';
  const modules = Object.create(null);
  const cache = Object.create(null);
  function define(id, factory){ modules[id] = factory; }
  function normalize(parts){
    if(typeof parts==='string') parts=parts.split('/');
    const out=[];
    for(const p of parts){ if(!p || p==='.') continue; if(p==='..') out.pop(); else out.push(p); }
    return out.join('/');
  }
  function resolve(id, from){
    if(!id.startsWith('.')) return id;
    const base = from.includes('/') ? from.slice(0, from.lastIndexOf('/')) : '';
    return normalize((base ? base+'/' : '') + id).replace(/\\.(tsx?|jsx?|mjs|cjs)$/,'');
  }
  function requireModule(id, from=''){
    const rid=resolve(id, from);
    if(cache[rid]) return cache[rid].exports;
    const fac=modules[rid];
    if(!fac) throw new Error('Module not found: '+rid+' (from '+from+')');
    const module={exports:{}}; cache[rid]=module;
    fac((x)=>requireModule(x,rid), module, module.exports);
    return module.exports;
  }

  // Tiny React-compatible runtime sufficient for this source tree.
  const Fragment = Symbol('Fragment');
  let hookState=[]; let hookIndex=0; let rootNode=null; let rootVNode=null; let renderQueued=false; let interactiveIndex=0;
  function flatten(arr, out=[]){ for(const x of arr){ if(Array.isArray(x)) flatten(x,out); else out.push(x); } return out; }
  function createElement(type, props, ...children){ return { type, props: Object.assign({}, props||{}, {children: flatten(children)}) }; }
  function useState(initial){
    const idx=hookIndex++;
    if(!(idx in hookState)) hookState[idx] = typeof initial==='function' ? initial() : initial;
    const setter=(next)=>{ hookState[idx] = typeof next==='function' ? next(hookState[idx]) : next; queueRender(); };
    return [hookState[idx], setter];
  }
  function queueRender(){ if(renderQueued) return; renderQueued=true; Promise.resolve().then(()=>{renderQueued=false; renderRoot();}); }
  const svgTags=new Set(['svg','path','rect','circle','line','polyline','polygon','ellipse','g']);
  function setProp(el, name, value, isSvg){
    if(name==='children'||name==='key'||name==='ref'||value==null||value===false) return;
    if(name==='className'){ el.setAttribute('class', value); return; }
    if(name==='onClick'){ el.addEventListener('click', value); return; }
    if(name==='onChange'){
      const type=(el.getAttribute('type')||'').toLowerCase();
      el.addEventListener(type==='file'||el.tagName==='SELECT' ? 'change':'input', value); return;
    }
    if(name.startsWith('on') && typeof value==='function'){
      el.addEventListener(name.slice(2).toLowerCase(), value); return;
    }
    if(name==='style' && typeof value==='object'){ Object.assign(el.style,value); return; }
    if(name==='value' && !isSvg){ try{el.value=value;}catch(e){} return; }
    if(name==='disabled' && !isSvg){ el.disabled=!!value; if(value) el.setAttribute('disabled',''); return; }
    if(name==='checked' && !isSvg){ el.checked=!!value; return; }
    const attr = isSvg ? name.replace(/[A-Z]/g,m=>'-'+m.toLowerCase()) : name;
    if(value===true) el.setAttribute(attr,''); else el.setAttribute(attr,String(value));
  }
  function makeDom(vnode, inSvg=false){
    if(vnode==null || vnode===false || vnode===true) return document.createTextNode('');
    if(typeof vnode==='string'||typeof vnode==='number') return document.createTextNode(String(vnode));
    if(Array.isArray(vnode)){ const frag=document.createDocumentFragment(); for(const c of vnode) frag.appendChild(makeDom(c,inSvg)); return frag; }
    if(typeof vnode.type==='function') return makeDom(vnode.type(vnode.props||{}),inSvg);
    if(vnode.type===Fragment || vnode.type===React.StrictMode){ const frag=document.createDocumentFragment(); for(const c of (vnode.props?.children||[])) frag.appendChild(makeDom(c,inSvg)); return frag; }
    const tag=vnode.type; const isSvg=inSvg || svgTags.has(tag);
    const el=isSvg ? document.createElementNS('http://www.w3.org/2000/svg',tag) : document.createElement(tag);
    for(const [k,v] of Object.entries(vnode.props||{})) setProp(el,k,v,isSvg);
    if(!isSvg && (tag==='input'||tag==='textarea'||tag==='button')) el.dataset.miniId=String(interactiveIndex++);
    for(const c of (vnode.props?.children||[])) el.appendChild(makeDom(c,isSvg));
    return el;
  }
  function renderRoot(){
    if(!rootNode||!rootVNode) return;
    const active=document.activeElement; let focusId=null, selStart=null, selEnd=null;
    if(active && active.dataset){ focusId=active.dataset.miniId||null; try{selStart=active.selectionStart; selEnd=active.selectionEnd;}catch(e){} }
    hookIndex=0; interactiveIndex=0;
    const dom=makeDom(rootVNode,false);
    rootNode.replaceChildren(dom);
    if(focusId!==null){
      const target=rootNode.querySelector('[data-mini-id="'+focusId+'"]');
      if(target){ target.focus(); if(selStart!=null && target.setSelectionRange){ try{target.setSelectionRange(selStart,selEnd);}catch(e){} } }
    }
  }
  const React={createElement, Fragment, StrictMode:Symbol('StrictMode'), useState};
  const ReactModule={__esModule:true, default:React, createElement, Fragment, StrictMode:React.StrictMode, useState};
  define('react',(r,m)=>{m.exports=ReactModule;});
  define('react-dom/client',(r,m)=>{m.exports={__esModule:true,default:{createRoot:(node)=>({render:(v)=>{rootNode=node;rootVNode=v;renderRoot();}})},createRoot:(node)=>({render:(v)=>{rootNode=node;rootVNode=v;renderRoot();}})};});

  // file-saver browser fallback. Android output is intercepted by AndroidFunction in zipGenerator.
  function saveAs(blob,name){ const a=document.createElement('a'); const u=URL.createObjectURL(blob); a.href=u; a.download=name||'download'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),30000); }
  define('file-saver',(r,m)=>{m.exports={__esModule:true,default:saveAs,saveAs};});
  define('jszip',(r,m)=>{m.exports={__esModule:true,default:window.JSZip};});

  function icon(children){
    return function Icon(props){
      props=props||{};
      const p=Object.assign({xmlns:'http://www.w3.org/2000/svg',width:24,height:24,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:2,strokeLinecap:'round',strokeLinejoin:'round'},props);
      return createElement('svg',p,...children.map(x=>createElement(x[0],x[1])));
    }
  }
  const icons={
    Smartphone:icon([['rect',{width:14,height:20,x:5,y:2,rx:2,ry:2}],['path',{d:'M12 18h.01'}]]),
    Download:icon([['path',{d:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'}],['polyline',{points:'7 10 12 15 17 10'}],['line',{x1:12,x2:12,y1:15,y2:3}]]),
    Settings:icon([['path',{d:'M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z'}],['circle',{cx:12,cy:12,r:3}]]),
    Layers:icon([['path',{d:'m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z'}],['path',{d:'m22 12.5-9.17 4.17a2 2 0 0 1-1.66 0L2 12.5'}],['path',{d:'m22 17.5-9.17 4.17a2 2 0 0 1-1.66 0L2 17.5'}]]),
    Calendar:icon([['path',{d:'M8 2v4'}],['path',{d:'M16 2v4'}],['rect',{width:18,height:18,x:3,y:4,rx:2}],['path',{d:'M3 10h18'}]]),
    RefreshCw:icon([['path',{d:'M3 12a9 9 0 0 1 15-6.7L21 8'}],['path',{d:'M21 3v5h-5'}],['path',{d:'M21 12a9 9 0 0 1-15 6.7L3 16'}],['path',{d:'M8 16H3v5'}]]),
    Code:icon([['polyline',{points:'16 18 22 12 16 6'}],['polyline',{points:'8 6 2 12 8 18'}]]),
    Copy:icon([['rect',{width:14,height:14,x:8,y:8,rx:2,ry:2}],['path',{d:'M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2'}]]),
    Check:icon([['path',{d:'M20 6 9 17l-5-5'}]]),
    AppWindow:icon([['rect',{width:20,height:16,x:2,y:4,rx:2}],['path',{d:'M6 8h.01'}],['path',{d:'M10 8h.01'}],['path',{d:'M14 8h.01'}]]),
    X:icon([['path',{d:'M18 6 6 18'}],['path',{d:'m6 6 12 12'}]]),
    Server:icon([['rect',{width:20,height:8,x:2,y:2,rx:2,ry:2}],['rect',{width:20,height:8,x:2,y:14,rx:2,ry:2}],['line',{x1:6,x2:6,y1:6,y2:6.01}],['line',{x1:6,x2:6,y1:18,y2:18.01}]]),
    Cpu:icon([['rect',{width:16,height:16,x:4,y:4,rx:2}],['rect',{width:6,height:6,x:9,y:9,rx:1}],['path',{d:'M9 1v3'}],['path',{d:'M15 1v3'}],['path',{d:'M9 20v3'}],['path',{d:'M15 20v3'}],['path',{d:'M20 9h3'}],['path',{d:'M20 14h3'}],['path',{d:'M1 9h3'}],['path',{d:'M1 14h3'}]]),
    Upload:icon([['path',{d:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'}],['polyline',{points:'17 8 12 3 7 8'}],['line',{x1:12,x2:12,y1:3,y2:15}]]),
    Lock:icon([['rect',{width:18,height:11,x:3,y:11,rx:2,ry:2}],['path',{d:'M7 11V7a5 5 0 0 1 10 0v4'}]])
  };
  define('lucide-react',(r,m)=>{m.exports=Object.assign({__esModule:true},icons);});

  window.__MiniReactDebug={requireModule, hookState};
`;

let bundle = runtime;
for (const [id, code] of Object.entries(compiled)) {
  bundle += `\n  define(${JSON.stringify(id)}, function(require,module,exports){\n${code}\n  });\n`;
}
bundle += `\n  requireModule('index');\n})();\n`;
fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(out,'app.bundle.js'),bundle);
console.log('bundle bytes', Buffer.byteLength(bundle));
