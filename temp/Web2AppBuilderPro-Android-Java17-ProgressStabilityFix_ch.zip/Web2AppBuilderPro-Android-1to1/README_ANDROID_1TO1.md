# Web2App Builder Pro - Android 1:1 + Optional Local APK Build

Project ini menggunakan UI/aliran daripada `web2app-builder-pro.zip` (versi kedua). UI utama bukan `getEmbeddedBuilderHtml()`.

## Apa yang dikekalkan
- Standard WebView mode
- Web2App App / Builder mode
- App Name, Package Name, Target URL
- Version Code / Version Name
- Validity (Days) + expiration preview/card
- User Agent
- App icon upload, preview, remove dan resize ke mipmap
- Advanced `maxValidityDays` dalam Builder mode
- Project Structure + System Configuration panel
- `Create your own` prompt modal + copy
- Template Android, permissions, `offline.html` dan `expired.html` daripada generator asal
- Output ZIP untuk kedua-dua mode
- Icon aplikasi W2A yang dipilih pengguna

## Hidden Local Build Tools
Panel ini sengaja tidak kelihatan dalam penggunaan biasa.

1. Buka aplikasi builder.
2. Tekan tajuk/logo **Web2App Builder Pro sebanyak 7 kali**.
3. Panel `Local Build Tools` akan muncul.
4. Tekan `Download & Install Tools`.
5. Installer memuat turun toolchain ke storan dalaman aplikasi dan menjalankan self-test build.
6. Status hanya menjadi `READY` jika APK self-test benar-benar berjaya dibina pada peranti tersebut.

Toolchain yang dipasang:
- OpenJDK 17 untuk Android ARM64
- Gradle 7.6.4
- Android Platform SDK 29
- Android ARM Build Tools 34.0.4, dengan compatibility alias 30.0.3 untuk project asal
- Dependency Gradle/Maven yang diperlukan oleh project melalui self-test pertama

## Tingkah laku butang Generate
### Build tools belum READY
Tiada perubahan kepada fungsi asal:

`Generate -> project source ZIP -> Download`

### Build tools READY
Builder akan menjalankan:

`Generate -> project source -> Gradle assembleRelease -> zipalign -> sign APK -> verify APK -> masukkan APK ke ZIP -> Download`

Contoh hasil akhir:

```text
My_App.zip
├── app/
├── build.gradle
├── settings.gradle
├── gradle.properties
└── APK/
    └── My_App.apk
```

Jika local APK build gagal, builder cuba menyimpan **source ZIP asal** supaya hasil generate tidak hilang.

## Signing
APK local ditandatangani dengan keystore yang dijana sendiri oleh aplikasi pada pemasangan toolchain pertama. Keystore disimpan dalam private app data dan digunakan semula untuk build seterusnya. Ia sesuai untuk pemasangan/sideload hasil builder. Jangan anggap key ini sebagai production release key untuk Play Store.

## Sokongan peranti
Local build toolchain Java 17 dalam versi ini menyokong:
- `arm64-v8a`

Peranti ARM32/x86/x86_64 masih boleh menggunakan builder, tetapi akan kekal pada output source ZIP biasa. Ini kerana pakej OpenJDK 17 Android yang digunakan ialah ARM64.

## Kenapa targetSdk builder ialah 28
Android menyekat aplikasi yang target API 29+ daripada mengeksekusi binary yang dimuat turun ke writable app storage. Local compiler ini perlu menjalankan JDK/aapt2/zipalign yang dipasang selepas app dipasang, jadi wrapper builder menggunakan `targetSdk 28`. Untuk release direct-install, hanya lint `ExpiredTargetSdkVersion` dikecualikan supaya `lintVitalRelease` tidak membatalkan APK; lint lain kekal aktif. Ini adalah kompromi khusus untuk fungsi build-on-device dan bukan konfigurasi project yang dijana oleh builder.


## Java 17 local build compatibility
Toolchain lokal kini menggunakan **OpenJDK 17 + Gradle 7.6.4**. Marker toolchain lama Java 11/Gradle 6.1.1 sengaja tidak diterima sebagai `READY`, jadi pemasangan lama perlu dibuat semula melalui panel rahsia.

Generator asal masih menghasilkan source project AGP 3.6.4 / Gradle 6.1.1 seperti sebelumnya. Apabila local APK build dijalankan, aplikasi mengekstrak ZIP ke workspace sementara dan hanya workspace itu dipatch kepada **AGP 7.4.2** serta lint compatibility yang diperlukan. ZIP source yang dimasukkan ke output akhir kekal source asal.

## Adapter Android
1. ZIP/output akhir disimpan ke folder Download melalui native bridge.
2. File picker WebView dibuka melalui `WebChromeClient`.
3. Copy prompt menggunakan Android Clipboard.
4. JSZip disertakan lokal; hosting Vercel tidak diperlukan.
5. UI utama dibundle sebagai aset Android lokal.
6. Native bridge mengesan status toolchain dan memilih fallback ZIP atau ZIP+APK secara automatik.

## QA
- `qa_local_build_feature.py`: semakan struktur feature local build.
- `qa_full_local_build.py`: browser integration QA untuk UI asal, 7-tap unlock, installer bridge, kedua-dua mode generator dan native build callback.
- `QA_FULL_LOCAL_BUILD.txt`: keputusan QA terakhir.

Nota: environment penyediaan project ini bukan peranti Android ARM dan tidak menjalankan toolchain Android ARM sebenar. Sebab itu installer mempunyai self-test pada device dan hanya mencipta marker `READY` selepas build ujian berjaya.

## Build wrapper app
Buka folder `android/` dalam Android Studio dan build seperti project Gradle biasa.

Keperluan build wrapper ini: Java 17 + Android SDK 35 + Gradle/AGP projek wrapper.
Ini tidak menukar template project yang dijana oleh builder; project output masih mengekalkan AGP 3.6.4 / compile SDK 29 / target SDK 29 / buildTools 30.0.3 daripada generator asal.
