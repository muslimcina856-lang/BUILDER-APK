package com.example.antigravity_patcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
