# Antigravity Patcher

App Flutter untuk patch dan launch Antigravity IDE di Android/Termux.

## Cara Build

```bash
flutter pub get
flutter build apk --release
```

APK: `build/app/outputs/flutter-apk/app-release.apk`

## Requirements
- Flutter 3.x
- Android SDK
- Termux + proot-distro (Ubuntu) mesti dah install di phone
