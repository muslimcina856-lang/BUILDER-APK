import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

class StorageService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // ---- Users ----
  static Map<String, User> getUsers() {
    final raw = _prefs.getString('users') ?? '{}';
    final map = jsonDecode(raw) as Map<String, dynamic>;
    return map.map((k, v) => MapEntry(k, User.fromJson(v)));
  }

  static Future<void> saveUsers(Map<String, User> users) async {
    final map = users.map((k, v) => MapEntry(k, v.toJson()));
    await _prefs.setString('users', jsonEncode(map));
  }

  static String? get currentUser => _prefs.getString('current_user');

  static Future<void> setCurrentUser(String? u) async {
    if (u == null) {
      await _prefs.remove('current_user');
    } else {
      await _prefs.setString('current_user', u);
    }
  }

  // ---- Transaksi ----
  static List<Transaksi> getTransaksi() {
    final key = 'tx_${currentUser ?? ''}';
    final raw = _prefs.getString(key) ?? '[]';
    final list = jsonDecode(raw) as List;
    return list.map((e) => Transaksi.fromJson(e)).toList();
  }

  static Future<void> saveTransaksi(List<Transaksi> list) async {
    final key = 'tx_${currentUser ?? ''}';
    await _prefs.setString(key, jsonEncode(list.map((e) => e.toJson()).toList()));
  }

  // ---- Anggaran ----
  static List<Anggaran> getAnggaran() {
    final key = 'budget_${currentUser ?? ''}';
    final raw = _prefs.getString(key) ?? '[]';
    final list = jsonDecode(raw) as List;
    return list.map((e) => Anggaran.fromJson(e)).toList();
  }

  static Future<void> saveAnggaran(List<Anggaran> list) async {
    final key = 'budget_${currentUser ?? ''}';
    await _prefs.setString(key, jsonEncode(list.map((e) => e.toJson()).toList()));
  }

  // ---- Target ----
  static List<Target> getTarget() {
    final key = 'goal_${currentUser ?? ''}';
    final raw = _prefs.getString(key) ?? '[]';
    final list = jsonDecode(raw) as List;
    return list.map((e) => Target.fromJson(e)).toList();
  }

  static Future<void> saveTarget(List<Target> list) async {
    final key = 'goal_${currentUser ?? ''}';
    await _prefs.setString(key, jsonEncode(list.map((e) => e.toJson()).toList()));
  }
}
