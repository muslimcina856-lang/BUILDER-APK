class User {
  final String username;
  final String nama;
  final String password;

  User({required this.username, required this.nama, required this.password});

  Map<String, dynamic> toJson() => {
        'username': username,
        'nama': nama,
        'password': password,
      };

  factory User.fromJson(Map<String, dynamic> j) => User(
        username: j['username'],
        nama: j['nama'],
        password: j['password'],
      );
}

class Transaksi {
  final String id;
  final String jenis; // pemasukan | pengeluaran
  final String kategori;
  final double jumlah;
  final String keterangan;
  final String tanggal;

  Transaksi({
    required this.id,
    required this.jenis,
    required this.kategori,
    required this.jumlah,
    required this.keterangan,
    required this.tanggal,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'jenis': jenis,
        'kategori': kategori,
        'jumlah': jumlah,
        'keterangan': keterangan,
        'tanggal': tanggal,
      };

  factory Transaksi.fromJson(Map<String, dynamic> j) => Transaksi(
        id: j['id'],
        jenis: j['jenis'],
        kategori: j['kategori'],
        jumlah: (j['jumlah'] as num).toDouble(),
        keterangan: j['keterangan'] ?? '',
        tanggal: j['tanggal'],
      );
}

class Anggaran {
  final String id;
  final String kategori;
  final double batas;
  final String bulan;

  Anggaran({
    required this.id,
    required this.kategori,
    required this.batas,
    required this.bulan,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'kategori': kategori,
        'batas': batas,
        'bulan': bulan,
      };

  factory Anggaran.fromJson(Map<String, dynamic> j) => Anggaran(
        id: j['id'],
        kategori: j['kategori'],
        batas: (j['batas'] as num).toDouble(),
        bulan: j['bulan'],
      );
}

class Target {
  final String id;
  final String nama;
  final double targetJumlah;
  double terkumpul;
  bool selesai;

  Target({
    required this.id,
    required this.nama,
    required this.targetJumlah,
    this.terkumpul = 0,
    this.selesai = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nama': nama,
        'targetJumlah': targetJumlah,
        'terkumpul': terkumpul,
        'selesai': selesai,
      };

  factory Target.fromJson(Map<String, dynamic> j) => Target(
        id: j['id'],
        nama: j['nama'],
        targetJumlah: (j['targetJumlah'] as num).toDouble(),
        terkumpul: (j['terkumpul'] as num?)?.toDouble() ?? 0,
        selesai: j['selesai'] ?? false,
      );
}
