import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/storage_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isLogin = true;
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _namaCtrl = TextEditingController();

  void _submit() async {
    final user = _userCtrl.text.trim().toLowerCase();
    final pass = _passCtrl.text;
    final nama = _namaCtrl.text.trim();

    if (user.isEmpty || pass.isEmpty) {
      _toast('Isi username & password');
      return;
    }

    final users = StorageService.getUsers();

    if (isLogin) {
      if (!users.containsKey(user) || users[user]!.password != pass) {
        _toast('Username / password salah');
        return;
      }
      await StorageService.setCurrentUser(user);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      if (nama.isEmpty) {
        _toast('Isi nama lengkap');
        return;
      }
      if (pass.length < 4) {
        _toast('Password minimal 4 karakter');
        return;
      }
      if (users.containsKey(user)) {
        _toast('Username sudah dipakai');
        return;
      }
      users[user] = User(username: user, nama: nama, password: pass);
      await StorageService.saveUsers(users);
      _toast('Berhasil daftar! Silakan login');
      setState(() => isLogin = true);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1E3A8A), Color(0xFF3B82F6)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.15),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('💰', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 8),
                    Text(
                      isLogin ? 'Masuk' : 'Daftar Akun',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isLogin ? 'Selamat datang kembali' : 'Buat akun baru gratis',
                      style: TextStyle(color: Colors.grey[600], fontSize: 13),
                    ),
                    const SizedBox(height: 28),
                    if (!isLogin) ...[
                      TextField(
                        controller: _namaCtrl,
                        decoration: _inputDeco('Nama Lengkap', Icons.person_outline),
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: _userCtrl,
                      decoration: _inputDeco('Username', Icons.alternate_email),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _passCtrl,
                      obscureText: true,
                      decoration: _inputDeco('Password', Icons.lock_outline),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2563EB),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(isLogin ? 'Masuk' : 'Daftar', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () => setState(() => isLogin = !isLogin),
                      child: Text(
                        isLogin ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Login',
                        style: const TextStyle(color: Color(0xFF2563EB)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDeco(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, size: 20),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }
}
