import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/storage_service.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final _fmt = NumberFormat.currency(locale: 'id', symbol: 'Rp ', decimalDigits: 0);
  final _uuid = const Uuid();

  List<Transaksi> _tx = [];
  List<Anggaran> _budgets = [];
  List<Target> _goals = [];
  String _nama = '';

  static const katOut = ['Makanan', 'Transportasi', 'Tagihan', 'Belanja', 'Hiburan', 'Kesehatan', 'Sewa', 'Pendidikan', 'Lainnya'];
  static const katIn = ['Gaji', 'Freelance', 'Investasi', 'Bonus', 'Lainnya'];
  static const icons = {
    'Makanan': '🍔', 'Transportasi': '🚗', 'Tagihan': '💡', 'Belanja': '🛒',
    'Hiburan': '🎮', 'Kesehatan': '💊', 'Sewa': '🏠', 'Pendidikan': '📚',
    'Lainnya': '📦', 'Gaji': '💼', 'Freelance': '💻', 'Investasi': '📈', 'Bonus': '🎁',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final users = StorageService.getUsers();
    final cur = StorageService.currentUser ?? '';
    setState(() {
      _nama = users[cur]?.nama ?? cur;
      _tx = StorageService.getTransaksi();
      _budgets = StorageService.getAnggaran();
      _goals = StorageService.getTarget();
    });
  }

  String get _bulan {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}';
  }

  double get _saldo {
    double s = 0;
    for (final t in _tx) {
      s += t.jenis == 'pemasukan' ? t.jumlah : -t.jumlah;
    }
    return s;
  }

  double _sumBulan(String jenis) {
    return _tx
        .where((t) => t.jenis == jenis && t.tanggal.startsWith(_bulan))
        .fold(0.0, (s, t) => s + t.jumlah);
  }

  void _toast(String m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)),
    );
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Yakin ingin keluar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Logout')),
        ],
      ),
    );
    if (ok == true) {
      await StorageService.setCurrentUser(null);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  // ==================== ADD TRANSACTION ====================
  void _showAddTx() {
    String jenis = 'pengeluaran';
    String kategori = katOut.first;
    final jumlahCtrl = TextEditingController();
    final ketCtrl = TextEditingController();
    DateTime tanggal = DateTime.now();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setModal) {
          final kats = jenis == 'pemasukan' ? katIn : katOut;
          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Tambah Transaksi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Pengeluaran'),
                        selected: jenis == 'pengeluaran',
                        onSelected: (_) => setModal(() {
                          jenis = 'pengeluaran';
                          kategori = katOut.first;
                        }),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Pemasukan'),
                        selected: jenis == 'pemasukan',
                        onSelected: (_) => setModal(() {
                          jenis = 'pemasukan';
                          kategori = katIn.first;
                        }),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: kategori,
                  decoration: const InputDecoration(labelText: 'Kategori', border: OutlineInputBorder()),
                  items: kats.map((k) => DropdownMenuItem(value: k, child: Text('${icons[k] ?? ''} $k'))).toList(),
                  onChanged: (v) => setModal(() => kategori = v!),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: jumlahCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Jumlah (Rp)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: ketCtrl,
                  decoration: const InputDecoration(labelText: 'Keterangan (opsional)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('Tanggal: ${DateFormat('dd MMM yyyy', 'id').format(tanggal)}'),
                  trailing: const Icon(Icons.calendar_today),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: tanggal,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now().add(const Duration(days: 1)),
                    );
                    if (d != null) setModal(() => tanggal = d);
                  },
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2563EB),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () async {
                      final j = double.tryParse(jumlahCtrl.text) ?? 0;
                      if (j <= 0) {
                        _toast('Isi jumlah');
                        return;
                      }
                      final t = Transaksi(
                        id: _uuid.v4(),
                        jenis: jenis,
                        kategori: kategori,
                        jumlah: j,
                        keterangan: ketCtrl.text.trim(),
                        tanggal: DateFormat('yyyy-MM-dd').format(tanggal),
                      );
                      final list = StorageService.getTransaksi()..insert(0, t);
                      await StorageService.saveTransaksi(list);
                      if (ctx.mounted) Navigator.pop(ctx);
                      _load();
                      _toast('Transaksi disimpan');
                    },
                    child: const Text('Simpan', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          _buildDashboard(),
          _buildRiwayat(),
          _buildAnggaran(),
          _buildTarget(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTx,
        backgroundColor: const Color(0xFF2563EB),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _navBtn(0, Icons.home_rounded, 'Home'),
            _navBtn(1, Icons.receipt_long_rounded, 'Riwayat'),
            const SizedBox(width: 48),
            _navBtn(2, Icons.pie_chart_rounded, 'Anggaran'),
            _navBtn(3, Icons.flag_rounded, 'Target'),
          ],
        ),
      ),
    );
  }

  Widget _navBtn(int i, IconData icon, String label) {
    final active = _tab == i;
    return InkWell(
      onTap: () => setState(() => _tab = i),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: active ? const Color(0xFF2563EB) : Colors.grey, size: 24),
            Text(label, style: TextStyle(fontSize: 10, color: active ? const Color(0xFF2563EB) : Colors.grey, fontWeight: active ? FontWeight.w600 : FontWeight.normal)),
          ],
        ),
      ),
    );
  }

  // ==================== DASHBOARD ====================
  Widget _buildDashboard() {
    final inc = _sumBulan('pemasukan');
    final exp = _sumBulan('pengeluaran');

    return CustomScrollView(
      slivers: [
        // App bar
        SliverAppBar(
          expandedHeight: 200,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF1E3A8A), Color(0xFF2563EB)]),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Halo, $_nama 👋', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                              Text(DateFormat('EEEE, d MMMM yyyy', 'id').format(DateTime.now()),
                                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                          IconButton(onPressed: _logout, icon: const Icon(Icons.logout, color: Colors.white70)),
                        ],
                      ),
                      const Spacer(),
                      const Text('Saldo', style: TextStyle(color: Colors.white70, fontSize: 13)),
                      Text(_fmt.format(_saldo), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          _miniStat('↓ ${_fmt.format(inc)}', 'Pemasukan', Colors.greenAccent),
                          const SizedBox(width: 24),
                          _miniStat('↑ ${_fmt.format(exp)}', 'Pengeluaran', Colors.redAccent),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        // Content
        SniverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Chart
                _card(
                  title: 'Tren 6 Bulan',
                  child: SizedBox(height: 180, child: _buildChart()),
                ),
                const SizedBox(height: 12),
                // Recent
                _card(
                  title: 'Transaksi Terbaru',
                  child: _tx.isEmpty
                      ? const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada transaksi', style: TextStyle(color: Colors.grey))))
                      : Column(children: _tx.take(6).map((t) => _txTile(t)).toList()),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _miniStat(String value, String label, Color c) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: TextStyle(color: c, fontWeight: FontWeight.w700, fontSize: 13)),
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 11)),
      ],
    );
  }

  Widget _card({required String title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _txTile(Transaksi t) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: const Color(0xFFF1F5F9),
        child: Text(icons[t.kategori] ?? '📦'),
      ),
      title: Text(t.kategori, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text('${t.tanggal}${t.keterangan.isNotEmpty ? ' · ${t.keterangan}' : ''}', style: const TextStyle(fontSize: 12)),
      trailing: Text(
        '${t.jenis == 'pemasukan' ? '+' : '-'}${_fmt.format(t.jumlah)}',
        style: TextStyle(
          fontWeight: FontWeight.w700,
          color: t.jenis == 'pemasukan' ? Colors.green : Colors.red,
        ),
      ),
      onLongPress: () async {
        final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Hapus?'),
            content: Text('Hapus transaksi ${t.kategori}?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
            ],
          ),
        );
        if (ok == true) {
          final list = StorageService.getTransaksi()..removeWhere((x) => x.id == t.id);
          await StorageService.saveTransaksi(list);
          _load();
          _toast('Dihapus');
        }
      },
    );
  }

  Widget _buildChart() {
    final now = DateTime.now();
    final labels = <String>[];
    final incData = <double>[];
    final expData = <double>[];

    for (var i = 5; i >= 0; i--) {
      final d = DateTime(now.year, now.month - i, 1);
      final key = '${d.year}-${d.month.toString().padLeft(2, '0')}';
      labels.add(DateFormat('MMM', 'id').format(d));
      incData.add(_tx.where((t) => t.jenis == 'pemasukan' && t.tanggal.startsWith(key)).fold(0.0, (s, t) => s + t.jumlah));
      expData.add(_tx.where((t) => t.jenis == 'pengeluaran' && t.tanggal.startsWith(key)).fold(0.0, (s, t) => s + t.jumlah));
    }

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: [...incData, ...expData, 1.0].reduce((a, b) => a > b ? a : b) * 1.2,
        barGroups: List.generate(6, (i) {
          return BarChartGroupData(x: i, barRods: [
            BarChartRodData(toY: incData[i], color: Colors.green, width: 8, borderRadius: BorderRadius.circular(4)),
            BarChartRodData(toY: expData[i], color: Colors.redAccent, width: 8, borderRadius: BorderRadius.circular(4)),
          ]);
        }),
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, _) => Text(labels[v.toInt()], style: const TextStyle(fontSize: 10)),
            ),
          ),
        ),
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
      ),
    );
  }

  // ==================== RIWAYAT ====================
  Widget _buildRiwayat() {
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat Transaksi'), automaticallyImplyLeading: false),
      body: _tx.isEmpty
          ? const Center(child: Text('Belum ada transaksi', style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _tx.length,
              itemBuilder: (_, i) => Card(
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: _txTile(_tx[i]),
              ),
            ),
    );
  }

  // ==================== ANGGARAN ====================
  Widget _buildAnggaran() {
    final bulanBudgets = _budgets.where((b) => b.bulan == _bulan).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Anggaran'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddBudget(),
          ),
        ],
      ),
      body: bulanBudgets.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Belum ada anggaran bulan ini', style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 12),
                  ElevatedButton(onPressed: _showAddBudget, child: const Text('Buat Anggaran')),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: bulanBudgets.length,
              itemBuilder: (_, i) {
                final b = bulanBudgets[i];
                final used = _tx
                    .where((t) => t.jenis == 'pengeluaran' && t.kategori == b.kategori && t.tanggal.startsWith(_bulan))
                    .fold(0.0, (s, t) => s + t.jumlah);
                final pct = (used / b.batas).clamp(0.0, 1.0);
                final color = pct >= 0.9 ? Colors.red : pct >= 0.7 ? Colors.orange : Colors.green;

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${icons[b.kategori] ?? ''} ${b.kategori}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text('${_fmt.format(used)} / ${_fmt.format(b.batas)}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: pct,
                            minHeight: 10,
                            backgroundColor: Colors.grey[200],
                            color: color,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text('${(pct * 100).toInt()}% terpakai', style: TextStyle(fontSize: 12, color: color)),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showAddBudget() {
    String kategori = katOut.first;
    final batasCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setModal) {
          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Atur Anggaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: kategori,
                  decoration: const InputDecoration(labelText: 'Kategori', border: OutlineInputBorder()),
                  items: katOut.map((k) => DropdownMenuItem(value: k, child: Text('${icons[k]} $k'))).toList(),
                  onChanged: (v) => setModal(() => kategori = v!),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: batasCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Batas (Rp)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), foregroundColor: Colors.white),
                    onPressed: () async {
                      final batas = double.tryParse(batasCtrl.text) ?? 0;
                      if (batas <= 0) return;
                      var list = StorageService.getAnggaran();
                      list = list.where((a) => !(a.kategori == kategori && a.bulan == _bulan)).toList();
                      list.add(Anggaran(id: _uuid.v4(), kategori: kategori, batas: batas, bulan: _bulan));
                      await StorageService.saveAnggaran(list);
                      if (ctx.mounted) Navigator.pop(ctx);
                      _load();
                      _toast('Anggaran disimpan');
                    },
                    child: const Text('Simpan'),
                  ),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  // ==================== TARGET ====================
  Widget _buildTarget() {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Target Tabungan'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: _showAddGoal),
        ],
      ),
      body: _goals.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Belum ada target', style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 12),
                  ElevatedButton(onPressed: _showAddGoal, child: const Text('Buat Target')),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _goals.length,
              itemBuilder: (_, i) {
                final g = _goals[i];
                final pct = (g.terkumpul / g.targetJumlah).clamp(0.0, 1.0);
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${g.nama}${g.selesai ? ' ✅' : ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20, color: Colors.grey),
                              onPressed: () async {
                                final list = StorageService.getTarget()..removeWhere((x) => x.id == g.id);
                                await StorageService.saveTarget(list);
                                _load();
                              },
                            ),
                          ],
                        ),
                        Text('${_fmt.format(g.terkumpul)} / ${_fmt.format(g.targetJumlah)}', style: const TextStyle(color: Colors.grey, fontSize: 13)),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(value: pct, minHeight: 10, backgroundColor: Colors.grey[200], color: Colors.green),
                        ),
                        const SizedBox(height: 4),
                        Text('${(pct * 100).toInt()}%', style: const TextStyle(fontSize: 12, color: Colors.green)),
                        if (!g.selesai) ...[
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton(
                              onPressed: () => _setorGoal(g),
                              child: const Text('+ Setor'),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showAddGoal() {
    final namaCtrl = TextEditingController();
    final targetCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Buat Target', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(controller: namaCtrl, decoration: const InputDecoration(labelText: 'Nama Target', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: targetCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Target (Rp)', border: OutlineInputBorder())),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), foregroundColor: Colors.white),
                  onPressed: () async {
                    final nama = namaCtrl.text.trim();
                    final target = double.tryParse(targetCtrl.text) ?? 0;
                    if (nama.isEmpty || target <= 0) return;
                    final list = StorageService.getTarget();
                    list.add(Target(id: _uuid.v4(), nama: nama, targetJumlah: target));
                    await StorageService.saveTarget(list);
                    if (ctx.mounted) Navigator.pop(ctx);
                    _load();
                    _toast('Target dibuat');
                  },
                  child: const Text('Buat'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _setorGoal(Target g) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Setor ke ${g.nama}'),
        content: TextField(controller: ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah (Rp)', border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          TextButton(
            onPressed: () async {
              final j = double.tryParse(ctrl.text) ?? 0;
              if (j <= 0) return;
              final list = StorageService.getTarget();
              final idx = list.indexWhere((x) => x.id == g.id);
              if (idx >= 0) {
                list[idx].terkumpul += j;
                if (list[idx].terkumpul >= list[idx].targetJumlah) {
                  list[idx].selesai = true;
                  _toast('🎉 Target tercapai!');
                } else {
                  _toast('Setoran berhasil');
                }
                await StorageService.saveTarget(list);
              }
              if (ctx.mounted) Navigator.pop(ctx);
              _load();
            },
            child: const Text('Setor'),
          ),
        ],
      ),
    );
  }
}

// Fix typo helper
class SniverToBoxAdapter extends StatelessWidget {
  final Widget child;
  const SniverToBoxAdapter({super.key, required this.child});
  @override
  Widget build(BuildContext context) => SliverToBoxAdapter(child: child);
}
