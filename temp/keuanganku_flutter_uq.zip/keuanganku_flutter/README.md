# KeuanganKu - Flutter App

Aplikasi keuangan pribadi lengkap (Flutter).

## Fitur
- Splash screen
- Login & Register
- Dashboard saldo + grafik 6 bulan (fl_chart)
- Tambah transaksi (bottom sheet)
- Riwayat transaksi
- Anggaran per kategori + progress bar
- Target tabungan + setoran
- Data tersimpan lokal (SharedPreferences)

## Build di Bot Telegram
1. Upload zip ini ke BOT BUILD APK
2. Ketik /build
3. Pilih **Flutter**
4. Tunggu APK-nya

## Tech Stack
- Flutter 3
- shared_preferences
- fl_chart
- google_fonts
- intl
- uuid
