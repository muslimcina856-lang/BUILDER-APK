import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:camera/camera.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

// ═══════════════════════════════════════════════════════
//  THEME CONSTANTS
// ═══════════════════════════════════════════════════════
const Color kBg        = Color(0xFF0D0D1A);
const Color kSurface   = Color(0xFF111127);
const Color kCard      = Color(0xFF14142B);
const Color kBorder    = Color(0xFF1E1E35);
const Color kPurple    = Color(0xFF7F77DD);
const Color kPurpleL   = Color(0xFFAFA9EC);
const Color kPurpleD   = Color(0xFF534AB7);
const Color kPurple2   = Color(0xFF3C3489);
const Color kGreen     = Color(0xFF1D9E75);
const Color kAmber     = Color(0xFFEF9F27);
const Color kRed       = Color(0xFFE24B4A);
const Color kTeal      = Color(0xFF5DCAA5);
const Color kBlue      = Color(0xFF378ADD);
const Color kText      = Color(0xFFFFFFFF);
const Color kTextMuted = Color(0xFF534AB7);
const Color kTextSub   = Color(0xFFAFA9EC);

// ═══════════════════════════════════════════════════════
//  MAIN
// ═══════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kBg,
  ));
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // Init Firebase — ganti dengan google-services.json kamu
  await Firebase.initializeApp();

  runApp(const MacxuraApp());
}

// ═══════════════════════════════════════════════════════
//  APP ROOT
// ═══════════════════════════════════════════════════════
class MacxuraApp extends StatelessWidget {
  const MacxuraApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Macxura',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(
          primary: kPurple,
          surface: kSurface,
        ),
        textTheme: GoogleFonts.outfitTextTheme(ThemeData.dark().textTheme),
      ),
      home: const SplashScreen(),
    );
  }
}

// ═══════════════════════════════════════════════════════
//  FIREBASE SERVICE
// ═══════════════════════════════════════════════════════
class FirebaseService {
  static final _db = FirebaseFirestore.instance;
  static final _storage = FirebaseStorage.instance;
  static const _deviceId = 'macxura_device_01';

  // Simpan data GPS ke Firestore
  static Future<void> saveLocation(Position pos) async {
    try {
      await _db.collection('locations').add({
        'device_id': _deviceId,
        'latitude': pos.latitude,
        'longitude': pos.longitude,
        'accuracy': pos.accuracy,
        'altitude': pos.altitude,
        'speed': pos.speed,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Firestore error: $e');
    }
  }

  // Upload foto ke Firebase Storage
  static Future<String?> uploadPhoto(String filePath, String label) async {
    try {
      final uuid = const Uuid().v4();
      final ref = _storage.ref().child('photos/$_deviceId/$label\_$uuid.jpg');
      final file = File(filePath);
      await ref.putFile(file);
      final url = await ref.getDownloadURL();
      await _db.collection('photos').add({
        'device_id': _deviceId,
        'url': url,
        'label': label,
        'timestamp': FieldValue.serverTimestamp(),
      });
      return url;
    } catch (e) {
      debugPrint('Storage error: $e');
      return null;
    }
  }

  // Simpan log aktivitas
  static Future<void> saveLog(String action, String detail) async {
    try {
      await _db.collection('activity_logs').add({
        'device_id': _deviceId,
        'action': action,
        'detail': detail,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Log error: $e');
    }
  }

  // Ambil riwayat lokasi
  static Stream<QuerySnapshot> locationStream() {
    return _db
        .collection('locations')
        .where('device_id', isEqualTo: _deviceId)
        .orderBy('timestamp', descending: true)
        .limit(20)
        .snapshots();
  }

  // Ambil riwayat foto
  static Stream<QuerySnapshot> photoStream() {
    return _db
        .collection('photos')
        .where('device_id', isEqualTo: _deviceId)
        .orderBy('timestamp', descending: true)
        .limit(20)
        .snapshots();
  }

  // Ambil log aktivitas
  static Stream<QuerySnapshot> logStream() {
    return _db
        .collection('activity_logs')
        .where('device_id', isEqualTo: _deviceId)
        .orderBy('timestamp', descending: true)
        .limit(30)
        .snapshots();
  }
}

// ═══════════════════════════════════════════════════════
//  SPLASH SCREEN
// ═══════════════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _opacity;
  late Animation<double> _progress;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2400));
    _scale = Tween<double>(begin: 0.5, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.45, curve: Curves.elasticOut)));
    _opacity = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.3, curve: Curves.easeIn)));
    _progress = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0.35, 1.0, curve: Curves.easeInOut)));
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2800), () {
      if (mounted) {
        Navigator.pushReplacement(context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => const LoginScreen(),
              transitionsBuilder: (_, a, __, child) =>
                  FadeTransition(opacity: a, child: child),
              transitionDuration: const Duration(milliseconds: 600),
            ));
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FadeTransition(
                opacity: _opacity,
                child: ScaleTransition(
                  scale: _scale,
                  child: Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(
                        color: kPurple.withOpacity(0.3 + 0.7 * _progress.value),
                        width: 1.5,
                      ),
                    ),
                    child: const Icon(Icons.shield_rounded, size: 48, color: kPurple),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              FadeTransition(
                opacity: _opacity,
                child: Text('MACXURA',
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 30, fontWeight: FontWeight.w600,
                        color: kText, letterSpacing: 5)),
              ),
              const SizedBox(height: 6),
              FadeTransition(
                opacity: _opacity,
                child: Text('ENTERPRISE DEVICE CONTROLLER',
                    style: GoogleFonts.outfit(
                        fontSize: 10, color: kPurpleD, letterSpacing: 2.5)),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: 110,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _progress.value,
                    backgroundColor: kBorder,
                    valueColor: const AlwaysStoppedAnimation<Color>(kPurple),
                    minHeight: 2,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              FadeTransition(
                opacity: _opacity,
                child: Text('v1.0.0',
                    style: GoogleFonts.outfit(fontSize: 10, color: kPurple2)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════
//  LOGIN SCREEN
// ═══════════════════════════════════════════════════════
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700))
      ..forward();
  }

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    setState(() { _error = null; _loading = true; });
    await Future.delayed(const Duration(milliseconds: 900));
    if (_userCtrl.text.trim() == 'macxura' &&
        _passCtrl.text.trim() == 'claude ai') {
      await FirebaseService.saveLog('LOGIN', 'Pengguna macxura berhasil login');
      if (mounted) {
        Navigator.pushReplacement(context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => const DashboardScreen(),
              transitionsBuilder: (_, a, __, child) => SlideTransition(
                position: Tween<Offset>(
                    begin: const Offset(1, 0), end: Offset.zero)
                    .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
                child: child,
              ),
              transitionDuration: const Duration(milliseconds: 500),
            ));
      }
    } else {
      setState(() { _error = 'Username atau password salah!'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: FadeTransition(
        opacity: CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Column(children: [
                      Container(
                        width: 76,
                        height: 76,
                        decoration: BoxDecoration(
                          color: kSurface,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: kBorder),
                        ),
                        child: const Icon(Icons.shield_rounded, size: 38, color: kPurpleL),
                      ),
                      const SizedBox(height: 14),
                      Text('MACXURA',
                          style: GoogleFonts.spaceGrotesk(
                              fontSize: 26, fontWeight: FontWeight.w600,
                              color: kText, letterSpacing: 4)),
                      const SizedBox(height: 4),
                      Text('INTERNAL USE ONLY',
                          style: GoogleFonts.outfit(
                              fontSize: 10, color: kPurpleD, letterSpacing: 2)),
                    ]),
                  ),
                  const SizedBox(height: 32),
                  Container(height: 0.5, color: kBorder),
                  const SizedBox(height: 24),
                  Text('Login Account',
                      style: GoogleFonts.outfit(
                          fontSize: 16, color: kPurpleL, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 18),
                  _label('USERNAME'),
                  const SizedBox(height: 6),
                  _input(controller: _userCtrl, hint: 'Masukkan username',
                      icon: Icons.person_outline_rounded),
                  const SizedBox(height: 14),
                  _label('PASSWORD'),
                  const SizedBox(height: 6),
                  _input(
                    controller: _passCtrl,
                    hint: 'Masukkan password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscure,
                    suffix: IconButton(
                      icon: Icon(_obscure
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                          color: kPurpleD, size: 20),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                      decoration: BoxDecoration(
                        color: kRed.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kRed.withOpacity(0.3)),
                      ),
                      child: Row(children: [
                        const Icon(Icons.error_outline, color: kRed, size: 16),
                        const SizedBox(width: 8),
                        Text(_error!,
                            style: GoogleFonts.outfit(fontSize: 12, color: kRed)),
                      ]),
                    ),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPurple,
                        foregroundColor: kText,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                      child: _loading
                          ? const SizedBox(width: 20, height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                          : Text('Masuk ke Akun',
                          style: GoogleFonts.outfit(
                              fontSize: 15, fontWeight: FontWeight.w500)),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: Text('Macxura v1.0.0 — Perangkat Pribadi',
                        style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(String t) => Text(t,
      style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD, letterSpacing: 1.5));

  Widget _input({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
  }) =>
      Container(
        decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: kBorder)),
        child: TextField(
          controller: controller,
          obscureText: obscure,
          style: GoogleFonts.outfit(color: kPurpleL, fontSize: 14),
          onSubmitted: (_) => _login(),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: GoogleFonts.outfit(color: kPurpleD, fontSize: 13),
            prefixIcon: Icon(icon, color: kPurpleD, size: 20),
            suffixIcon: suffix,
            border: InputBorder.none,
            contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
        ),
      );
}

// ═══════════════════════════════════════════════════════
//  DASHBOARD SCREEN
// ═══════════════════════════════════════════════════════
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  int _tab = 0;
  late AnimationController _ctrl;

  final _features = [
    _Feature('GPS Tracker', 'Pantau lokasi real-time', Icons.location_on_rounded, kGreen, const Color(0xFF0D1F16)),
    _Feature('Lock Screen', 'Kunci layar dengan PIN', Icons.lock_rounded, kPurple, const Color(0xFF111127)),
    _Feature('Kamera', 'Pantau depan & belakang', Icons.camera_alt_rounded, kAmber, const Color(0xFF1A1208)),
    _Feature('Layar', 'Screen recording', Icons.screen_share_rounded, kRed, const Color(0xFF1A0D0D)),
    _Feature('File Manager', 'Kelola file perangkat', Icons.folder_rounded, kTeal, const Color(0xFF0A1A1A)),
    _Feature('Activity Log', 'Riwayat aktivitas', Icons.history_rounded, kBlue, const Color(0xFF0D1226)),
  ];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500))
      ..forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _open(_Feature f) {
    Widget page;
    switch (f.title) {
      case 'GPS Tracker':    page = const GpsScreen(); break;
      case 'Lock Screen':    page = const LockPinScreen(); break;
      case 'Kamera':         page = const CameraScreen(); break;
      case 'Layar':          page = const ScreenRecordScreen(); break;
      case 'File Manager':   page = const FileManagerScreen(); break;
      case 'Activity Log':   page = const ActivityLogScreen(); break;
      default: return;
    }
    Navigator.push(context, PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, a, __, child) => SlideTransition(
        position: Tween<Offset>(
            begin: const Offset(0, 1), end: Offset.zero)
            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
        child: child,
      ),
      transitionDuration: const Duration(milliseconds: 400),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: FadeTransition(
          opacity: _ctrl,
          child: Column(children: [
            _header(),
            Expanded(child: _tab == 0
                ? _home()
                : _tab == 1
                    ? const StatusScreen()
                    : _tab == 2
                        ? const SettingsTab()
                        : _placeholder()),
            _tabBar(),
          ]),
        ),
      ),
    );
  }

  Widget _header() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    decoration: const BoxDecoration(
      color: Color(0xFF0F0F1E),
      border: Border(bottom: BorderSide(color: kBorder, width: 0.5)),
    ),
    child: Row(children: [
      Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: kBorder)),
        child: const Icon(Icons.shield_rounded, size: 20, color: kPurple),
      ),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('MACXURA',
            style: GoogleFonts.spaceGrotesk(
                fontSize: 15, fontWeight: FontWeight.w600,
                color: kText, letterSpacing: 2)),
        Text('DEVICE CONTROLLER',
            style: GoogleFonts.outfit(
                fontSize: 9, color: kPurpleD, letterSpacing: 1.5)),
      ]),
      const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: const Color(0xFF0D1F16),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kGreen.withOpacity(0.4)),
        ),
        child: Row(children: [
          Container(width: 6, height: 6,
              decoration: const BoxDecoration(color: kGreen, shape: BoxShape.circle)),
          const SizedBox(width: 5),
          Text('ONLINE',
              style: GoogleFonts.outfit(fontSize: 9, color: kGreen, letterSpacing: 0.5)),
        ]),
      ),
    ]),
  );

  Widget _home() => ListView(
    padding: const EdgeInsets.all(14),
    children: [
      _sec('PENGGUNA AKTIF'),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder, width: 0.5)),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
                color: kCard,
                shape: BoxShape.circle,
                border: Border.all(color: kBorder)),
            child: const Icon(Icons.person_rounded, color: kPurple, size: 20),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('macxura',
                style: GoogleFonts.outfit(
                    fontSize: 14, color: kText, fontWeight: FontWeight.w500)),
            Text('Administrator',
                style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF0D1226),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kBlue.withOpacity(0.4)),
            ),
            child: Text('Owner',
                style: GoogleFonts.outfit(fontSize: 10, color: kBlue)),
          ),
        ]),
      ),
      const SizedBox(height: 16),
      _sec('FITUR KONTROL'),
      const SizedBox(height: 8),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _features.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 1.05,
        ),
        itemBuilder: (_, i) =>
            _FeatureCard(item: _features[i], onTap: () => _open(_features[i])),
      ),
    ],
  );

  Widget _placeholder() => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.construction_rounded, color: kPurpleD, size: 48),
      const SizedBox(height: 12),
      Text('Segera Hadir',
          style: GoogleFonts.outfit(fontSize: 16, color: kPurpleL)),
      const SizedBox(height: 4),
      Text('Fitur dalam pengembangan',
          style: GoogleFonts.outfit(fontSize: 12, color: kPurpleD)),
    ]),
  );

  Widget _tabBar() {
    final tabs = [
      [Icons.home_rounded, 'HOME'],
      [Icons.bar_chart_rounded, 'STATUS'],
      [Icons.settings_rounded, 'SETTING'],
      [Icons.person_rounded, 'PROFIL'],
    ];
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F1E),
        border: Border(top: BorderSide(color: kBorder, width: 0.5)),
      ),
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(tabs.length, (i) {
          final on = _tab == i;
          return GestureDetector(
            onTap: () => setState(() => _tab = i),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(tabs[i][0] as IconData,
                  color: on ? kPurpleL : const Color(0xFF2A2A4A), size: 22),
              const SizedBox(height: 3),
              Text(tabs[i][1] as String,
                  style: GoogleFonts.outfit(
                      fontSize: 8,
                      color: on ? kPurple : const Color(0xFF2A2A4A),
                      letterSpacing: 0.5)),
            ]),
          );
        }),
      ),
    );
  }

  Widget _sec(String t) => Text(t,
      style: GoogleFonts.outfit(
          fontSize: 9, color: kPurpleD, letterSpacing: 2, fontWeight: FontWeight.w500));
}

class _Feature {
  final String title, desc;
  final IconData icon;
  final Color color, bg;
  const _Feature(this.title, this.desc, this.icon, this.color, this.bg);
}

class _FeatureCard extends StatefulWidget {
  final _Feature item;
  final VoidCallback onTap;
  const _FeatureCard({required this.item, required this.onTap});
  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _s;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _s = Tween<double>(begin: 1, end: 0.96)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => _c.forward(),
    onTapUp: (_) { _c.reverse(); widget.onTap(); },
    onTapCancel: () => _c.reverse(),
    child: AnimatedBuilder(
      animation: _s,
      builder: (_, child) => Transform.scale(scale: _s.value, child: child),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder, width: 0.5)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
                color: widget.item.bg,
                borderRadius: BorderRadius.circular(10)),
            child: Icon(widget.item.icon, color: widget.item.color, size: 20),
          ),
          const Spacer(),
          Text(widget.item.title,
              style: GoogleFonts.outfit(
                  fontSize: 12, color: kText, fontWeight: FontWeight.w500)),
          const SizedBox(height: 2),
          Text(widget.item.desc,
              style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD),
              maxLines: 2, overflow: TextOverflow.ellipsis),
        ]),
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════
//  GPS SCREEN
// ═══════════════════════════════════════════════════════
class GpsScreen extends StatefulWidget {
  const GpsScreen({super.key});
  @override
  State<GpsScreen> createState() => _GpsScreenState();
}

class _GpsScreenState extends State<GpsScreen> {
  Position? _pos;
  bool _loading = false;
  bool _liveTracking = false;
  StreamSubscription<Position>? _sub;
  String _status = 'Tekan tombol untuk ambil lokasi';

  Future<bool> _checkPermission() async {
    bool svc = await Geolocator.isLocationServiceEnabled();
    if (!svc) { _setStatus('GPS tidak aktif. Nyalakan GPS dahulu.'); return false; }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied) { _setStatus('Izin lokasi ditolak.'); return false; }
    }
    if (perm == LocationPermission.deniedForever) {
      _setStatus('Izin ditolak permanen. Buka Settings.'); return false;
    }
    return true;
  }

  void _setStatus(String s) => setState(() => _status = s);

  Future<void> _getOnce() async {
    setState(() { _loading = true; });
    if (!await _checkPermission()) { setState(() => _loading = false); return; }
    _setStatus('Mengambil koordinat...');
    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    await FirebaseService.saveLocation(pos);
    setState(() { _pos = pos; _status = 'Lokasi berhasil diambil & disimpan'; _loading = false; });
  }

  Future<void> _toggleLive() async {
    if (_liveTracking) {
      _sub?.cancel();
      setState(() { _liveTracking = false; _status = 'Live tracking dihentikan.'; });
      return;
    }
    if (!await _checkPermission()) return;
    setState(() { _liveTracking = true; _status = 'Live tracking aktif...'; });
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10),
    ).listen((pos) async {
      await FirebaseService.saveLocation(pos);
      if (mounted) setState(() { _pos = pos; _status = 'Live — data dikirim ke Firebase'; });
    });
  }

  @override
  void dispose() { _sub?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'GPS Tracker', icon: Icons.location_on_rounded, color: kGreen,
    child: Column(children: [
      _box([
        _row('Status', _status, _liveTracking ? kGreen : kPurpleL),
        if (_pos != null) ...[
          _row('Latitude', _pos!.latitude.toStringAsFixed(6), kPurpleL),
          _row('Longitude', _pos!.longitude.toStringAsFixed(6), kPurpleL),
          _row('Akurasi', '${_pos!.accuracy.toStringAsFixed(1)} m', kAmber),
          _row('Altitude', '${_pos!.altitude.toStringAsFixed(1)} m', kBlue),
          _row('Kecepatan', '${(_pos!.speed * 3.6).toStringAsFixed(1)} km/h', kTeal),
        ],
      ]),
      const SizedBox(height: 14),
      _btn('Ambil Lokasi Sekali', Icons.my_location_rounded, kGreen,
          _loading ? null : _getOnce),
      const SizedBox(height: 10),
      _btn(_liveTracking ? 'Stop Live Tracking' : 'Mulai Live Tracking',
          _liveTracking ? Icons.stop_circle_rounded : Icons.radio_button_checked_rounded,
          _liveTracking ? kRed : kPurpleD, _toggleLive),
      const SizedBox(height: 16),
      _firebaseNote('Lokasi tersimpan di Firebase Firestore → koleksi "locations"'),
    ]),
  );
}

// ═══════════════════════════════════════════════════════
//  LOCK PIN SCREEN
// ═══════════════════════════════════════════════════════
class LockPinScreen extends StatefulWidget {
  const LockPinScreen({super.key});
  @override
  State<LockPinScreen> createState() => _LockPinScreenState();
}

class _LockPinScreenState extends State<LockPinScreen> {
  final _pin = TextEditingController();
  final _newPin = TextEditingController();
  final _confirmPin = TextEditingController();
  bool _locked = false;
  bool _obscure = true;
  String _msg = '';

  Future<String> _getSaved() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('lock_pin') ?? '';
  }

  Future<void> _lock() async {
    final saved = await _getSaved();
    if (saved.isEmpty) { setState(() => _msg = 'Atur PIN dahulu!'); return; }
    await FirebaseService.saveLog('LOCK', 'Layar dikunci');
    setState(() { _locked = true; _msg = ''; });
  }

  Future<void> _unlock() async {
    final saved = await _getSaved();
    if (_pin.text == saved) {
      await FirebaseService.saveLog('UNLOCK', 'Layar dibuka');
      setState(() { _locked = false; _msg = 'Berhasil dibuka!'; _pin.clear(); });
    } else {
      setState(() => _msg = 'PIN salah!');
    }
  }

  Future<void> _savePin() async {
    if (_newPin.text.length < 4) { setState(() => _msg = 'PIN minimal 4 digit!'); return; }
    if (_newPin.text != _confirmPin.text) { setState(() => _msg = 'PIN tidak cocok!'); return; }
    final p = await SharedPreferences.getInstance();
    await p.setString('lock_pin', _newPin.text);
    await FirebaseService.saveLog('SET_PIN', 'PIN baru diatur');
    setState(() { _msg = 'PIN berhasil disimpan!'; _newPin.clear(); _confirmPin.clear(); });
  }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'Lock Screen', icon: Icons.lock_rounded, color: kPurple,
    child: _locked ? _lockedUI() : _unlockedUI(),
  );

  Widget _lockedUI() => Column(children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kRed.withOpacity(0.3))),
      child: Column(children: [
        const Icon(Icons.lock_rounded, color: kRed, size: 52),
        const SizedBox(height: 12),
        Text('LAYAR TERKUNCI',
            style: GoogleFonts.spaceGrotesk(
                fontSize: 16, color: kRed, letterSpacing: 2, fontWeight: FontWeight.w600)),
        const SizedBox(height: 18),
        TextField(
          controller: _pin,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          textAlign: TextAlign.center,
          style: GoogleFonts.outfit(color: kPurpleL, fontSize: 22, letterSpacing: 10),
          decoration: InputDecoration(
            counterText: '',
            hintText: '• • • •',
            hintStyle: GoogleFonts.outfit(color: kPurpleD, letterSpacing: 10, fontSize: 22),
            filled: true, fillColor: kCard,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 14),
        _btn('Buka Kunci', Icons.lock_open_rounded, kPurple, _unlock),
        if (_msg.isNotEmpty) _msgW(_msg),
      ]),
    ),
  ]);

  Widget _unlockedUI() => Column(children: [
    _box([_row('Status', 'Tidak Terkunci', kGreen)]),
    const SizedBox(height: 14),
    Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kBorder, width: 0.5)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Atur PIN Baru',
            style: GoogleFonts.outfit(fontSize: 13, color: kPurpleL, fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        _pinField(_newPin, 'PIN baru (min. 4 digit)'),
        const SizedBox(height: 8),
        _pinField(_confirmPin, 'Konfirmasi PIN'),
        const SizedBox(height: 10),
        _btn('Simpan PIN', Icons.save_rounded, kPurpleD, _savePin),
      ]),
    ),
    const SizedBox(height: 12),
    _btn('Kunci Sekarang', Icons.lock_rounded, kRed, _lock),
    if (_msg.isNotEmpty) _msgW(_msg),
  ]);

  Widget _pinField(TextEditingController c, String hint) => TextField(
    controller: c,
    keyboardType: TextInputType.number,
    obscureText: _obscure,
    maxLength: 8,
    style: GoogleFonts.outfit(color: kPurpleL, fontSize: 14),
    decoration: InputDecoration(
      counterText: '',
      hintText: hint,
      hintStyle: GoogleFonts.outfit(color: kPurpleD, fontSize: 13),
      filled: true, fillColor: kCard,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      suffixIcon: IconButton(
        icon: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
            color: kPurpleD, size: 18),
        onPressed: () => setState(() => _obscure = !_obscure),
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════
//  CAMERA SCREEN
// ═══════════════════════════════════════════════════════
class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _ctrl;
  List<CameraDescription>? _cams;
  int _camIdx = 0;
  bool _init = false;
  bool _loading = false;
  bool _uploading = false;
  String _msg = '';

  Future<void> _start() async {
    setState(() { _loading = true; _msg = ''; });
    final status = await Permission.camera.request();
    if (!status.isGranted) { setState(() { _msg = 'Izin kamera ditolak.'; _loading = false; }); return; }
    _cams = await availableCameras();
    if (_cams == null || _cams!.isEmpty) {
      setState(() { _msg = 'Tidak ada kamera.'; _loading = false; }); return;
    }
    await _setup(_camIdx);
  }

  Future<void> _setup(int idx) async {
    await _ctrl?.dispose();
    _ctrl = CameraController(_cams![idx], ResolutionPreset.high);
    await _ctrl!.initialize();
    if (mounted) setState(() { _init = true; _loading = false; });
  }

  Future<void> _flip() async {
    if (_cams == null || _cams!.length < 2) return;
    _camIdx = _camIdx == 0 ? 1 : 0;
    setState(() { _init = false; _loading = true; });
    await _setup(_camIdx);
  }

  Future<void> _capture() async {
    if (_ctrl == null || !_ctrl!.value.isInitialized) return;
    final file = await _ctrl!.takePicture();
    setState(() { _uploading = true; _msg = 'Mengunggah ke Firebase...'; });
    final label = _camIdx == 0 ? 'front' : 'back';
    final url = await FirebaseService.uploadPhoto(file.path, label);
    setState(() {
      _uploading = false;
      _msg = url != null ? 'Foto berhasil diunggah ke Firebase Storage!' : 'Upload gagal, cek koneksi.';
    });
  }

  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'Kamera', icon: Icons.camera_alt_rounded, color: kAmber,
    child: Column(children: [
      if (!_init && !_loading)
        _btn('Aktifkan Kamera', Icons.camera_alt_rounded, kAmber, _start),
      if (_loading)
        const Center(child: CircularProgressIndicator(color: kAmber)),
      if (_init && _ctrl != null) ...[
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: AspectRatio(
              aspectRatio: _ctrl!.value.aspectRatio,
              child: CameraPreview(_ctrl!)),
        ),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: _btn('Ganti', Icons.flip_camera_android_rounded, kPurpleD, _flip)),
          const SizedBox(width: 10),
          Expanded(child: _btn('Ambil Foto', Icons.camera_rounded, kAmber,
              _uploading ? null : _capture)),
        ]),
        _firebaseNote('Foto diunggah ke Firebase Storage → folder "photos"'),
      ],
      if (_msg.isNotEmpty) _msgW(_msg),
    ]),
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN RECORD SCREEN
// ═══════════════════════════════════════════════════════
class ScreenRecordScreen extends StatefulWidget {
  const ScreenRecordScreen({super.key});
  @override
  State<ScreenRecordScreen> createState() => _ScreenRecordScreenState();
}

class _ScreenRecordScreenState extends State<ScreenRecordScreen> {
  bool _rec = false;
  String _msg = 'Tekan tombol untuk memulai.\nAndroid akan menampilkan konfirmasi sistem.';

  Future<void> _toggle() async {
    if (!_rec) {
      await FirebaseService.saveLog('SCREEN_RECORD_START', 'Recording dimulai');
      setState(() { _rec = true; _msg = 'Recording aktif.\nIndikator muncul di status bar Android.'; });
    } else {
      await FirebaseService.saveLog('SCREEN_RECORD_STOP', 'Recording dihentikan');
      setState(() { _rec = false; _msg = 'Recording dihentikan.'; });
    }
  }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'Screen Recording', icon: Icons.screen_share_rounded, color: kRed,
    child: Column(children: [
      _box([_row('Status', _rec ? 'Sedang Recording' : 'Tidak Aktif', _rec ? kRed : kPurpleD)]),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: kSurface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder, width: 0.5)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.info_outline_rounded, color: kAmber, size: 16),
            const SizedBox(width: 6),
            Text('Info', style: GoogleFonts.outfit(fontSize: 12, color: kAmber, fontWeight: FontWeight.w500)),
          ]),
          const SizedBox(height: 8),
          Text(
            'Android mewajibkan konfirmasi pengguna (MediaProjection API) sebelum recording dimulai. '
            'Notifikasi sistem akan selalu terlihat selama recording aktif.',
            style: GoogleFonts.outfit(fontSize: 11, color: kPurpleD, height: 1.5),
          ),
        ]),
      ),
      const SizedBox(height: 14),
      _btn(
        _rec ? 'Hentikan Recording' : 'Mulai Recording',
        _rec ? Icons.stop_circle_rounded : Icons.fiber_manual_record_rounded,
        _rec ? kRed : kPurpleD,
        _toggle,
      ),
      if (_msg.isNotEmpty) _msgW(_msg),
    ]),
  );
}

// ═══════════════════════════════════════════════════════
//  FILE MANAGER SCREEN
// ═══════════════════════════════════════════════════════
class FileManagerScreen extends StatefulWidget {
  const FileManagerScreen({super.key});
  @override
  State<FileManagerScreen> createState() => _FileManagerScreenState();
}

class _FileManagerScreenState extends State<FileManagerScreen> {
  List<FileSystemEntity> _files = [];
  Directory? _dir;
  bool _loading = false;
  String _msg = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; });
    await Permission.storage.request();
    await Permission.manageExternalStorage.request();
    try {
      final base = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final root = base.parent.parent.parent.parent;
      _navigate(root);
    } catch (e) {
      setState(() { _msg = 'Error: $e'; _loading = false; });
    }
  }

  void _navigate(Directory d) {
    try {
      final list = d.listSync()
        ..sort((a, b) {
          if (a is Directory && b is! Directory) return -1;
          if (a is! Directory && b is Directory) return 1;
          return a.path.compareTo(b.path);
        });
      setState(() { _dir = d; _files = list; _loading = false; _msg = ''; });
    } catch (_) {
      setState(() { _msg = 'Tidak bisa membuka folder ini.'; _loading = false; });
    }
  }

  void _goUp() {
    if (_dir == null) return;
    final p = _dir!.parent;
    if (p.path != _dir!.path) _navigate(p);
  }

  String _name(FileSystemEntity e) => e.path.split('/').last;
  String _size(File f) {
    final b = f.lengthSync();
    if (b < 1024) return '$b B';
    if (b < 1048576) return '${(b / 1024).toStringAsFixed(1)} KB';
    return '${(b / 1048576).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'File Manager', icon: Icons.folder_rounded, color: kTeal,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (_dir != null) Row(children: [
        GestureDetector(
          onTap: _goUp,
          child: const Icon(Icons.arrow_upward_rounded, color: kPurpleL, size: 18),
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(_dir!.path,
            style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD),
            overflow: TextOverflow.ellipsis)),
      ]),
      const SizedBox(height: 10),
      if (_loading)
        const Center(child: CircularProgressIndicator(color: kTeal))
      else if (_files.isEmpty)
        Center(child: Text('Folder kosong',
            style: GoogleFonts.outfit(color: kPurpleD, fontSize: 13)))
      else
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _files.length,
          separatorBuilder: (_, __) => Container(height: 0.5, color: kBorder),
          itemBuilder: (_, i) {
            final f = _files[i];
            final isDir = f is Directory;
            return ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                  isDir ? Icons.folder_rounded : Icons.insert_drive_file_rounded,
                  color: isDir ? kAmber : kPurpleL, size: 20),
              title: Text(_name(f),
                  style: GoogleFonts.outfit(fontSize: 13, color: kText),
                  overflow: TextOverflow.ellipsis),
              subtitle: !isDir
                  ? Text(_size(f as File),
                  style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD))
                  : null,
              onTap: isDir ? () => _navigate(f as Directory) : null,
            );
          },
        ),
      if (_msg.isNotEmpty) _msgW(_msg),
    ]),
  );
}

// ═══════════════════════════════════════════════════════
//  ACTIVITY LOG SCREEN
// ═══════════════════════════════════════════════════════
class ActivityLogScreen extends StatelessWidget {
  const ActivityLogScreen({super.key});

  String _fmtTime(Timestamp? t) {
    if (t == null) return '-';
    final dt = t.toDate().toLocal();
    return DateFormat('dd MMM yyyy, HH:mm').format(dt);
  }

  Color _actionColor(String action) {
    if (action.contains('LOGIN')) return kGreen;
    if (action.contains('LOCK') || action.contains('UNLOCK')) return kPurple;
    if (action.contains('RECORD')) return kRed;
    if (action.contains('PIN')) return kAmber;
    return kBlue;
  }

  IconData _actionIcon(String action) {
    if (action.contains('LOGIN')) return Icons.login_rounded;
    if (action.contains('UNLOCK')) return Icons.lock_open_rounded;
    if (action.contains('LOCK')) return Icons.lock_rounded;
    if (action.contains('RECORD')) return Icons.screen_share_rounded;
    if (action.contains('PIN')) return Icons.pin_rounded;
    return Icons.info_rounded;
  }

  @override
  Widget build(BuildContext context) => _scaffold(
    title: 'Activity Log', icon: Icons.history_rounded, color: kBlue,
    child: StreamBuilder<QuerySnapshot>(
      stream: FirebaseService.logStream(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: kBlue));
        }
        if (!snap.hasData || snap.data!.docs.isEmpty) {
          return Center(child: Text('Belum ada aktivitas',
              style: GoogleFonts.outfit(color: kPurpleD)));
        }
        return ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: snap.data!.docs.length,
          separatorBuilder: (_, __) => Container(height: 0.5, color: kBorder),
          itemBuilder: (_, i) {
            final d = snap.data!.docs[i].data() as Map<String, dynamic>;
            final action = d['action'] ?? '';
            final color = _actionColor(action);
            return ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8)),
                child: Icon(_actionIcon(action), color: color, size: 16),
              ),
              title: Text(action,
                  style: GoogleFonts.outfit(
                      fontSize: 12, color: kText, fontWeight: FontWeight.w500)),
              subtitle: Text(d['detail'] ?? '',
                  style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
              trailing: Text(_fmtTime(d['timestamp'] as Timestamp?),
                  style: GoogleFonts.outfit(fontSize: 9, color: kPurpleD)),
            );
          },
        );
      },
    ),
  );
}

// ═══════════════════════════════════════════════════════
//  STATUS SCREEN (Firebase Realtime Stats)
// ═══════════════════════════════════════════════════════
class StatusScreen extends StatelessWidget {
  const StatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Text('STATUS FIREBASE',
            style: GoogleFonts.outfit(
                fontSize: 9, color: kPurpleD, letterSpacing: 2, fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        _statCard('Lokasi Tersimpan', Icons.location_on_rounded, kGreen,
            FirebaseService.locationStream()),
        const SizedBox(height: 8),
        _statCard('Foto Tersimpan', Icons.photo_rounded, kAmber,
            FirebaseService.photoStream()),
        const SizedBox(height: 8),
        _statCard('Log Aktivitas', Icons.history_rounded, kBlue,
            FirebaseService.logStream()),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kBorder, width: 0.5)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.cloud_done_rounded, color: kGreen, size: 16),
              const SizedBox(width: 6),
              Text('Firebase Connection',
                  style: GoogleFonts.outfit(
                      fontSize: 12, color: kPurpleL, fontWeight: FontWeight.w500)),
            ]),
            const SizedBox(height: 8),
            Text('Terhubung ke Firebase Project kamu.\nData tersimpan secara real-time di Firestore & Storage.',
                style: GoogleFonts.outfit(fontSize: 11, color: kPurpleD, height: 1.5)),
          ]),
        ),
      ],
    );
  }

  Widget _statCard(String label, IconData icon, Color color, Stream<QuerySnapshot> stream) {
    return StreamBuilder<QuerySnapshot>(
      stream: stream,
      builder: (_, snap) {
        final count = snap.data?.docs.length ?? 0;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kBorder, width: 0.5)),
          child: Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 12),
            Text(label,
                style: GoogleFonts.outfit(fontSize: 13, color: kText, fontWeight: FontWeight.w500)),
            const Spacer(),
            Text('$count entri',
                style: GoogleFonts.outfit(fontSize: 12, color: color, fontWeight: FontWeight.w500)),
          ]),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════
//  SETTINGS TAB
// ═══════════════════════════════════════════════════════
class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Text('PENGATURAN',
            style: GoogleFonts.outfit(
                fontSize: 9, color: kPurpleD, letterSpacing: 2, fontWeight: FontWeight.w500)),
        const SizedBox(height: 10),
        _tile(Icons.person_outline_rounded, 'Akun', 'macxura / Administrator'),
        _tile(Icons.cloud_outlined, 'Firebase', 'Terhubung ke project kamu'),
        _tile(Icons.shield_outlined, 'Keamanan', 'Ganti PIN, autentikasi'),
        _tile(Icons.notifications_outlined, 'Notifikasi', 'Atur push notification'),
        _tile(Icons.info_outline_rounded, 'Tentang', 'Macxura v1.0.0 — Internal'),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: () {
            FirebaseService.saveLog('LOGOUT', 'Pengguna logout');
            Navigator.pushAndRemoveUntil(
              context,
              PageRouteBuilder(
                pageBuilder: (_, __, ___) => const LoginScreen(),
                transitionsBuilder: (_, a, __, child) =>
                    FadeTransition(opacity: a, child: child),
                transitionDuration: const Duration(milliseconds: 500),
              ),
              (_) => false,
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kRed.withOpacity(0.3), width: 0.5),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.logout_rounded, color: kRed, size: 18),
              const SizedBox(width: 8),
              Text('Keluar / Logout',
                  style: GoogleFonts.outfit(
                      fontSize: 14, color: kRed, fontWeight: FontWeight.w500)),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _tile(IconData icon, String t, String sub) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder, width: 0.5)),
    child: Row(children: [
      Icon(icon, color: kPurpleL, size: 20),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t, style: GoogleFonts.outfit(fontSize: 13, color: kText, fontWeight: FontWeight.w500)),
        Text(sub, style: GoogleFonts.outfit(fontSize: 10, color: kPurpleD)),
      ])),
      const Icon(Icons.chevron_right_rounded, color: kPurpleD, size: 18),
    ]),
  );
}

// ═══════════════════════════════════════════════════════
//  SHARED UI HELPERS
// ═══════════════════════════════════════════════════════
Widget _scaffold({
  required String title,
  required IconData icon,
  required Color color,
  required Widget child,
}) =>
    Builder(builder: (ctx) => Scaffold(
      backgroundColor: kBg,
      body: SafeArea(child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: const BoxDecoration(
            color: Color(0xFF0F0F1E),
            border: Border(bottom: BorderSide(color: kBorder, width: 0.5)),
          ),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(ctx),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kBorder)),
                child: const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: kPurpleL),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 10),
            Text(title, style: GoogleFonts.spaceGrotesk(
                fontSize: 16, fontWeight: FontWeight.w600, color: kText)),
          ]),
        ),
        Expanded(child: SingleChildScrollView(
            padding: const EdgeInsets.all(16), child: child)),
      ])),
    ));

Widget _box(List<Widget> children) => Container(
  width: double.infinity,
  padding: const EdgeInsets.all(14),
  decoration: BoxDecoration(
      color: kSurface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: kBorder, width: 0.5)),
  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
);

Widget _row(String label, String val, Color c) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 5),
  child: Row(children: [
    Text(label, style: GoogleFonts.outfit(fontSize: 12, color: kPurpleD)),
    const Spacer(),
    Flexible(child: Text(val, style: GoogleFonts.outfit(
        fontSize: 12, color: c, fontWeight: FontWeight.w500),
        textAlign: TextAlign.right)),
  ]),
);

Widget _btn(String label, IconData icon, Color color, VoidCallback? onTap) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: color.withOpacity(onTap == null ? 0.05 : 0.12),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
              color: color.withOpacity(onTap == null ? 0.2 : 0.4), width: 0.5),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: onTap == null ? color.withOpacity(0.4) : color, size: 18),
          const SizedBox(width: 8),
          Text(label, style: GoogleFonts.outfit(
              fontSize: 13,
              color: onTap == null ? color.withOpacity(0.4) : color,
              fontWeight: FontWeight.w500)),
        ]),
      ),
    );

Widget _msgW(String msg) => Padding(
  padding: const EdgeInsets.only(top: 12),
  child: Text(msg,
      textAlign: TextAlign.center,
      style: GoogleFonts.outfit(fontSize: 11, color: kPurpleL, height: 1.5)),
);

Widget _firebaseNote(String note) => Padding(
  padding: const EdgeInsets.only(top: 12),
  child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    decoration: BoxDecoration(
        color: kGreen.withOpacity(0.06),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kGreen.withOpacity(0.2))),
    child: Row(children: [
      const Icon(Icons.cloud_done_rounded, color: kGreen, size: 14),
      const SizedBox(width: 8),
      Flexible(child: Text(note,
          style: GoogleFonts.outfit(fontSize: 10, color: kGreen, height: 1.4))),
    ]),
  ),
);
