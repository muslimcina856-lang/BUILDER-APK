# Railway Deck

Unofficial **standalone** Railway client for Android.

**Tiada Termux. Tiada embed CLI binary.**

## Architecture

- Login: AppAuth (OAuth 2.0 + PKCE) — sama konsep `railway login`
- API: Railway GraphQL Public API
- Multi-account: Encrypted storage + Keystore
- Deploy source: Deploy Bridge (server) + folder/ZIP dari telefon

## Wajib (sekali sahaja)

1. Daftar OAuth application di Railway
2. Redirect URI: `railwaydeck://oauth/callback`
3. Copy Client ID → `app/build.gradle.kts`:
   ```kotlin
   buildConfigField("String", "RAILWAY_CLIENT_ID", "\"CLIENT_ID_KAU\"")
   ```

Ini langkah **developer** sekali sahaja. User akhir cuma tekan Login.

## Ciri siap

- Icon (pilihan user)
- Multi-account
- Dark theme + navigation
- Login OAuth (AppAuth)
- Deploy UI (Folder / ZIP)
- Secure token storage
- Deploy Bridge skeleton

## Build

Android Studio → Sync → ganti Client ID → Run.
