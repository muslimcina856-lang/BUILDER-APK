package com.railway.deck.data.repository

import com.railway.deck.auth.TokenStore
import com.railway.deck.data.api.GraphQlRequest
import com.railway.deck.data.api.RailwayApi
import com.railway.deck.data.api.RailwayApiClient
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RailwayRepository @Inject constructor(
    private val tokenStore: TokenStore
) {
    private val api: RailwayApi = RailwayApiClient.create()

    private fun authHeader(accountId: String): String {
        val token = tokenStore.getAccessToken(accountId)
            ?: throw IllegalStateException("No access token for account $accountId")
        return "Bearer $token"
    }

    /**
     * Contoh query: dapatkan list project (setara `railway list`)
     */
    suspend fun getProjects(accountId: String): Result<List<Map<String, Any?>>> {
        return try {
            val query = """
                query {
                  projects {
                    edges {
                      node {
                        id
                        name
                        description
                        createdAt
                      }
                    }
                  }
                }
            """.trimIndent()

            val response = api.graphql(
                authorization = authHeader(accountId),
                body = GraphQlRequest(query = query)
            )

            if (response.errors != null) {
                Result.failure(Exception(response.errors.first().message))
            } else {
                val edges = (response.data?.get("projects") as? Map<*, *>)
                    ?.get("edges") as? List<*>
                val projects = edges?.mapNotNull { edge ->
                    (edge as? Map<*, *>)?.get("node") as? Map<String, Any?>
                } ?: emptyList()
                Result.success(projects)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Boleh tambah lagi: getServices, getDeployments, getVariables, restartService, dll
}
