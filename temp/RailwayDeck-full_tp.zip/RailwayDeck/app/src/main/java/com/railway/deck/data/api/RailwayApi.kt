package com.railway.deck.data.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

/**
 * Railway GraphQL endpoint
 * https://backboard.railway.com/graphql/v2
 */
interface RailwayApi {

    @POST("graphql/v2")
    suspend fun graphql(
        @Header("Authorization") authorization: String,
        @Body body: GraphQlRequest
    ): GraphQlResponse
}

data class GraphQlRequest(
    val query: String,
    val variables: Map<String, Any?>? = null
)

data class GraphQlResponse(
    val data: Map<String, Any?>?,
    val errors: List<GraphQlError>?
)

data class GraphQlError(
    val message: String
)

object RailwayApiClient {
    private const val BASE_URL = "https://backboard.railway.com/"

    fun create(): RailwayApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(RailwayApi::class.java)
    }
}
