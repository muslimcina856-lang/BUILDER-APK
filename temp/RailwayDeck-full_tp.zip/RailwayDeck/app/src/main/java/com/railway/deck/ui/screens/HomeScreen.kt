package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.AccountsViewModel

@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: AccountsViewModel = hiltViewModel()
) {
    val activeAccount by viewModel.activeAccount.collectAsState()
    val accounts by viewModel.accounts.collectAsState()
    var showAccountMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Railway Deck",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                // Account switcher
                Box {
                    Row(
                        modifier = Modifier
                            .clickable { showAccountMenu = true }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeAccount?.alias ?: "Belum login",
                            color = if (activeAccount != null) Accent else TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (accounts.isNotEmpty()) {
                            Icon(
                                Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showAccountMenu,
                        onDismissRequest = { showAccountMenu = false },
                        modifier = Modifier.background(CharcoalCard)
                    ) {
                        accounts.forEach { account ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (account.isActive) "✓ ${account.alias}" else account.alias,
                                        color = if (account.isActive) Accent else TextPrimary
                                    )
                                },
                                onClick = {
                                    viewModel.setActiveAccount(account.id)
                                    showAccountMenu = false
                                }
                            )
                        }
                        Divider(color = Border)
                        DropdownMenuItem(
                            text = { Text("+ Add Account", color = Accent) },
                            onClick = {
                                showAccountMenu = false
                                navController.navigate("login")
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(modifier = Modifier.weight(1f), title = "Projects", value = "—")
            StatCard(modifier = Modifier.weight(1f), title = "Running", value = "—", valueColor = GreenStatus)
            StatCard(modifier = Modifier.weight(1f), title = "Failed", value = "—", valueColor = RedStatus)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions
        Text(
            text = "Quick Actions",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickActionButton(
                modifier = Modifier.weight(1f),
                text = "Deploy from Phone",
                icon = Icons.Default.CloudUpload,
                onClick = { navController.navigate("deploy") }
            )
            QuickActionButton(
                modifier = Modifier.weight(1f),
                text = "New Project",
                icon = Icons.Default.Add,
                onClick = { /* TODO */ }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Recent Projects
        Text(
            text = "Recent Projects",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (activeAccount == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalCard, RoundedCornerShape(12.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Belum login",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tekan Accounts → Add Railway Account\nuntuk mula",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalCard, RoundedCornerShape(12.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Project akan muncul di sini selepas GraphQL diaktifkan",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, color = valueColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(text = title, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickActionButton(
    modifier: Modifier = Modifier,
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = CharcoalCard,
            contentColor = TextPrimary
        )
    ) {
        Icon(icon, contentDescription = null, tint = Accent)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontSize = 13.sp)
    }
}
