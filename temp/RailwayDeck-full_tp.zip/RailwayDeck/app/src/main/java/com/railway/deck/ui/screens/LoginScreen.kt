package com.railway.deck.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.auth.AccountManager
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.AccountsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TOKEN_HELP_URL = "https://railway.com/account/tokens"

@Composable
fun LoginScreen(
    navController: NavController,
    isFirstLaunch: Boolean = false,
    onLoginSuccess: (() -> Unit)? = null,
    viewModel: AccountsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var workspaceName by remember { mutableStateOf("") }
    var workspaceId by remember { mutableStateOf("") }
    var apiToken by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Masukkan email, workspace (optional) & API token") }
    var error by remember { mutableStateOf<String?>(null) }
    var showHelp by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = if (isFirstLaunch) "Login Railway" else "Add Railway Account",
                color = TextPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            // Tanda soal dalam bulatan
            IconButton(
                onClick = { showHelp = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = "Cara dapat API token",
                    tint = Accent,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Text(
            text = "Guna API Token dari Railway",
            color = TextSecondary,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Railway") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = textFieldColors()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = workspaceName,
            onValueChange = { workspaceName = it },
            label = { Text("Nama Workspace (optional)") },
            placeholder = { Text("Personal / Client A / Store") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = textFieldColors()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = workspaceId,
            onValueChange = { workspaceId = it },
            label = { Text("Workspace ID (optional)") },
            placeholder = { Text("Tinggal kosong jika personal") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = textFieldColors()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = apiToken,
            onValueChange = { apiToken = it },
            label = { Text("API Token") },
            placeholder = { Text("Paste token di sini") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            colors = textFieldColors()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                error = null
                if (email.isBlank() || apiToken.isBlank()) {
                    error = "Email dan API Token wajib diisi"
                    return@Button
                }
                isLoading = true
                status = "Mengesahkan token..."

                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        AccountManager.verifyToken(apiToken.trim())
                    }
                    isLoading = false

                    if (result.isSuccess) {
                        val verifiedEmail = result.getOrNull() ?: email.trim()
                        val ok = viewModel.addAccount(
                            email = verifiedEmail.ifBlank { email.trim() },
                            workspaceId = workspaceId.trim().ifBlank { null },
                            workspaceName = workspaceName.trim().ifBlank { null },
                            apiToken = apiToken.trim()
                        )
                        if (ok) {
                            status = "Akaun ditambah"
                            onLoginSuccess?.invoke()
                            if (!isFirstLaunch) {
                                navController.popBackStack()
                            }
                            // first launch: AppRoot will switch when accounts refresh
                        } else {
                            error = "Akaun ini sudah wujud (email + workspace sama)."
                            status = "Sudah wujud"
                        }
                    } else {
                        error = result.exceptionOrNull()?.message ?: "Token tidak sah"
                        status = "Gagal"
                    }
                }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.Black, strokeWidth = 2.dp)
            } else {
                Text("Login / Simpan Akaun", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(text = status, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (error != null) {
            Text(text = error!!, color = RedStatus, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }

    // Popup cara dapat API token
    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            title = { Text("Cara dapatkan API Token") },
            text = {
                Column {
                    Text(
                        text = "1. Buka laman Railway\n" +
                                "2. Login akaun kau\n" +
                                "3. Pergi ke Account Settings → Tokens\n" +
                                "4. Create Token (Account / Personal)\n" +
                                "5. Copy token → paste dalam app\n\n" +
                                "Link terus:",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = TOKEN_HELP_URL,
                        color = Accent,
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Railway Tokens", TOKEN_HELP_URL))
                        Toast.makeText(context, "Link disalin", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Salin link", color = Accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showHelp = false }) {
                    Text("Tutup")
                }
            },
            containerColor = CharcoalCard,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }
}

@Composable
private fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Border,
    focusedLabelColor = Accent,
    unfocusedLabelColor = TextSecondary,
    cursorColor = Accent,
    focusedContainerColor = CharcoalCard,
    unfocusedContainerColor = CharcoalCard
)
