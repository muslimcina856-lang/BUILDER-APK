package com.xiko.musicplayer

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MusicAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MusicAdapter()
        recyclerView.adapter = adapter

        val clientId = getString(R.string.jamendo_client_id)
        if(clientId.length < 30) {
            Toast.makeText(this, "Client ID salah bang", Toast.LENGTH_LONG).show()
            return
        }
        loadMusic(clientId)
    }

    private fun loadMusic(clientId: String) {
        val retrofit = Retrofit.Builder()
           .baseUrl("https://api.jamendo.com/v3.0/")
           .addConverterFactory(GsonConverterFactory.create())
           .build()

        val api = retrofit.create(JamendoApi::class.java)
        api.getTracks(clientId).enqueue(object : Callback<JamendoResponse> {
            override fun onResponse(call: Call<JamendoResponse>, response: Response<JamendoResponse>) {
                if(response.isSuccessful) {
                    adapter.setData(response.body()?.results?: emptyList())
                }
            }
            override fun onFailure(call: Call<JamendoResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Gagal: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

interface JamendoApi {
    @GET("tracks")
    fun getTracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 30
    ): Call<JamendoResponse>
}

data class JamendoResponse(val results: List<Track>)
data class Track(val name: String, val artist_name: String, val audio: String)

class MusicAdapter : RecyclerView.Adapter<MusicAdapter.ViewHolder>() {
    private var tracks = listOf<Track>()

    fun setData(data: List<Track>) {
        tracks = data
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
           .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val track = tracks[position]
        holder.title.text = track.name
        holder.artist.text = track.artist_name
    }

    override fun getItemCount() = tracks.size

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val title = view.findViewById<android.widget.TextView>(android.R.id.text1)
        val artist = view.findViewById<android.widget.TextView>(android.R.id.text2)
    }
}