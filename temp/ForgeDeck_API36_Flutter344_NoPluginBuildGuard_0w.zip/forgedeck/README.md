# ForgeDeck

Aplikasi Android Flutter untuk mengurus beberapa akaun GitHub menggunakan Personal Access Token (PAT). Semua fungsi tertakluk kepada jenis token, permission repository, polisi organisasi, branch protection, ruleset dan endpoint GitHub yang menyokong token tersebut.

## Fungsi yang tersedia

- Onboarding PAT pada pembukaan pertama.
- Akaun tanpa had tetap pada peringkat aplikasi.
- PAT dan metadata akaun dienkripsi dengan AES-GCM menggunakan Android Keystore.
- Paparan nama, avatar dan maklumat akaun aktif.
- Senarai repository dengan carian, penapis dan pull-to-refresh.
- Cipta, kemas kini, arkib, tukar visibility dan padam repository.
- Senarai branch, cipta branch, tukar default branch dan padam branch bukan default.
- Pelayar fail dan folder mengikut branch.
- Pratonton, edit, muat naik dan padam fail melalui Contents API.
- Isu: senarai, cipta, tutup dan buka semula.
- Pull request: senarai, cipta dan merge.
- GitHub Actions: senarai workflow, `workflow_dispatch`, run terkini, cancel dan rerun.
- Release: senarai, cipta dan padam release.
- Notifikasi akaun jika endpoint dan token membenarkan.
- Force push dari ZIP dengan Git Database API.

## Integrasi Android tanpa plugin pihak ketiga

Fungsi Android yang sebelum ini biasanya memerlukan plugin Flutter kini dilaksanakan terus melalui `MainActivity.java` dan `MethodChannel`:

- pemilih fail sistem,
- permintaan izin storan untuk Android lama,
- buka halaman tetapan aplikasi,
- penyimpanan PAT terenkripsi melalui Android Keystore.

Oleh itu projek ini tidak mempunyai Flutter plugin yang membawa kod Android pihak ketiga. Semua fungsi native berada dalam modul aplikasi sendiri, supaya hosted builder tidak mempunyai pencetus untuk menurunkan AGP dan Gradle.

## Force push ZIP

Aliran ini tidak menjalankan `git` atau shell pada telefon:

1. ZIP dipilih melalui Storage Access Framework.
2. Fail disalin ke cache peribadi aplikasi.
3. Laluan diperiksa untuk menghalang `../`, `.git`, `__MACOSX` dan metadata tidak perlu.
4. Setiap fail dimuat naik sebagai Git blob.
5. Tree penuh baharu dibina tanpa `base_tree`, jadi tree lama diganti.
6. Commit baharu dicipta.
7. Ref branch dikemas kini dengan `force: true`.

Had keselamatan lalai:

- Maksimum 3000 fail.
- Maksimum 50 MB untuk satu fail.
- Maksimum 250 MB jumlah kandungan ZIP selepas diekstrak.
- Pemilih native menolak fail sumber melebihi 512 MB.
- Bit executable dipelihara jika ZIP menyimpan Unix permissions.
- Symbolic link ditolak; folder kosong tidak boleh dijejak oleh Git.
- Git LFS dan submodule khas belum diproses secara automatik.

## Izin storan Android

- Android 13 dan lebih baharu menggunakan pemilih fail sistem. Izin storan luas tidak diperlukan dan tidak tersedia untuk fail ZIP biasa.
- Android 12 dan lebih lama meminta `READ_EXTERNAL_STORAGE` semasa aplikasi mula jika belum diberi.
- Aplikasi tidak meminta `MANAGE_EXTERNAL_STORAGE`.

## Konfigurasi binaan Android

```text
Flutter       3.44.x
Dart          3.12.x
compileSdk    36
targetSdk     36
minSdk        23
AGP           8.12.1
Gradle        8.14
Java          17 atau lebih baharu
Bahasa native Java
```

`android/gradlew` mempunyai build guard. Jika hosted builder cuba menukar AGP kepada `7.4.2`, Gradle kepada `7.5`, Java target kepada `11`, atau SDK kepada versi lain, konfigurasi API 36 dipulihkan sejurus sebelum Gradle bermula.

## Jalankan projek

Gunakan workspace baharu dan jangan campurkan dengan folder projek yang pernah diubah auto-fix:

```bash
flutter clean
rm -rf .dart_tool build android/.gradle
rm -f pubspec.lock
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

Konfigurasi `release` masih menggunakan debug signing untuk memudahkan ujian. Tukar kepada upload keystore sebelum edaran sebenar.

## Keselamatan

Jangan letakkan PAT dalam source code, `pubspec.yaml`, fail `.env` yang dibungkus, log, URL clone, screenshot atau mesej chat.

Token Telegram dan GitHub yang pernah dikongsi secara terbuka perlu direvoke dan diganti. Projek ini tidak mengandungi token contoh sebenar.

## Struktur utama

```text
lib/core/network/      GitHub REST dan Git Database API
lib/core/storage/      native bridge, secure vault, permission dan ZIP validation
lib/core/theme/        tema visual
lib/models/            model data GitHub
lib/state/             keadaan aplikasi dan multi-akaun
lib/ui/screens/        skrin utama dan fungsi repository
lib/ui/widgets/        komponen UI tersuai
android/app/src/main/java/com/earlxz/forgedeck/MainActivity.java
                       integrasi native tanpa plugin pihak ketiga
```
