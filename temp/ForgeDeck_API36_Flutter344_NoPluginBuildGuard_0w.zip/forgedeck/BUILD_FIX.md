# Build fix khusus hosted builder

Versi ini menyelesaikan laluan ralat yang menukar Gradle 8.14 kepada 7.5 selepas `pub get`.

## Perubahan struktur

- Tiada Flutter plugin yang mengandungi modul Android pihak ketiga.
- Tiada fail Kotlin atau Kotlin DSL dalam projek Android.
- Pemilih fail, izin storan lama dan secure vault dilaksanakan dalam `MainActivity.java`.
- Fail Gradle menggunakan Groovy supaya auto-fixer yang menyasarkan `settings.gradle.kts` tidak terlibat.
- `android/gradlew` memulihkan fail binaan terkunci sebelum Gradle bermula.
- `android/gradlew` tidak pernah menggunakan Gradle sistem 7.5: ia menggunakan wrapper, cache 8.14, atau muat turun 8.14 yang disahkan SHA-256.

## Baris yang patut muncul dalam log

```text
ForgeDeck build guard: API 36 | AGP 8.12.1 | Gradle 8.14 | Java 17+ | native Java bridge
```

Jika baris itu tidak muncul, platform binaan tidak menjalankan `android/gradlew` daripada ZIP ini atau masih menggunakan workspace lama.
