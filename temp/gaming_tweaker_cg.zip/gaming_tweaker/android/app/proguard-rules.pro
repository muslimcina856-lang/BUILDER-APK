# Flutter wrapper
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }
-dontwarn io.flutter.embedding.**

# Shizuku — harus dijaga total (class, method, field, dan modifier akses)
# supaya reflection/cross-package call internal Shizuku tidak rusak saat di-obfuscate.
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep interface moe.shizuku.** { *; }
-keepclassmembers class rikka.shizuku.** { *; }
-keepclassmembers class moe.shizuku.** { *; }
-dontwarn rikka.shizuku.**
-dontwarn moe.shizuku.**

# Package plugin shizuku_api (nama package Kotlin/Java pembungkus plugin ini)
# ikut di-keep total karena dia memanggil method Shizuku secara langsung.
-keep class com.shizuku_api.** { *; }
-keep class * extends io.flutter.plugin.common.MethodCallHandler { *; }

# Jangan biarkan R8 mengubah access modifier lintas package — ini akar
# penyebab IllegalAccessError pada Shizuku.newProcess() di release build.
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
