package com.aiuhdhub.app.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.data.DownloadableModel
import com.aiuhdhub.app.data.ModelsRepository
import com.aiuhdhub.app.ui.components.GlassCard
import com.aiuhdhub.app.ui.theme.*
import com.aiuhdhub.app.utils.ImageUtils
import com.aiuhdhub.app.utils.ModelDownloader
import com.aiuhdhub.app.utils.UhdUpscaleEngine
import kotlinx.coroutines.launch

/**
 * Shape khusus untuk memotong imej UHD (selepas) berdasarkan pergerakan slider.
 */
class SplitShape(private val fraction: Float) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        return Outline.Rectangle(Rect(0f, 0f, size.width * fraction, size.height))
    }
}

@Composable
fun AiStudioScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var inputBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var outputBitmap by remember { mutableStateOf<Bitmap?>(null) }
    
    var processing by remember { mutableStateOf(false) }

    // Senarai model yang sedia ada di dalam aplikasi
    val downloadedModels = remember { mutableStateListOf<DownloadableModel>() }
    var selectedModel by remember { mutableStateOf<DownloadableModel?>(null) }

    // Muatkan model yang tersedia secara luar talian
    LaunchedEffect(Unit) {
        val all = ModelsRepository.getDownloadableModels()
        val downloaded = all.filter { ModelDownloader.isModelDownloaded(context, it.filename) }
        downloadedModels.clear()
        downloadedModels.addAll(downloaded)
        if (downloaded.isNotEmpty()) {
            selectedModel = downloaded.first()
        }
    }

    // Tetapan pemprosesan
    var scaleFactor by remember { mutableStateOf(4f) } // ESRGAN TFLite adalah 4x
    var sharpenIntensity by remember { mutableStateOf(0.4f) }
    var denoiseLevel by remember { mutableStateOf(0.2f) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            imageUri = uri
            outputBitmap = null
            inputBitmap = loadBitmapFromUri(context, uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
            .verticalScroll(scrollState)
            .padding(bottom = 100.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 50.dp, start = 24.dp, end = 24.dp, bottom = 16.dp)
        ) {
            Text(
                text = "AI Studio",
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 28.sp),
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Proses gambar anda ke kualiti UHD secara lokal & offline",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        if (inputBitmap == null) {
            // Skrin Pilih Gambar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardDark.copy(alpha = 0.6f))
                    .border(2.dp, Brush.linearGradient(listOf(AccentBlue, AccentPurple)), RoundedCornerShape(24.dp))
                    .clickable { imagePickerLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Photo,
                        contentDescription = null,
                        tint = AccentBlue,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Pilih Gambar Dari Galeri",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Menyokong JPG, PNG, WEBP, dll.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        } else {
            // Paparan Gambar & Leret Sebelum/Selepas
            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                if (outputBitmap == null) {
                    // Preview Input Sementara Memproses
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(350.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .border(1.dp, DividerColor, RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = inputBitmap!!.asImageBitmap(),
                            contentDescription = "Gambar Asal",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )

                        if (processing) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.65f)),
                                contentAlignment = Alignment.Center
                            ) {
                                val infiniteTransition = rememberInfiniteTransition(label = "scan")
                                val scanLineOffset by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = 1f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(2200, easing = EaseInOutSine),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "scanLine"
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(0.015f)
                                        .align(Alignment.TopCenter)
                                        .offset(y = 350.dp * scanLineOffset)
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Transparent, AccentCyan, Color.Transparent)
                                            )
                                        )
                                )

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = AccentCyan, strokeWidth = 3.dp)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Menjalankan Model AI...",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = AccentCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Inference tempatan sedang diproses",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // SLIDER SEBELUM & SELEPAS PIXEL-PERFECT (SANGAT PREMIUM)
                    Text(
                        text = "Seret jari anda ke kiri/kanan di atas gambar untuk membandingkan",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )

                    var parentSize by remember { mutableStateOf(IntSize.Zero) }
                    var dragOffsetFraction by remember { mutableStateOf(0.5f) }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(350.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .border(2.dp, DividerColor, RoundedCornerShape(24.dp))
                            .onSizeChanged { parentSize = it }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures { change, dragAmount ->
                                    change.consume()
                                    if (parentSize.width > 0) {
                                        dragOffsetFraction = (dragOffsetFraction + dragAmount / parentSize.width).coerceIn(0f, 1f)
                                    }
                                }
                            }
                    ) {
                        // 1. Imej Asal (Sebelum) - Diletakkan di Bawah
                        Image(
                            bitmap = inputBitmap!!.asImageBitmap(),
                            contentDescription = "Sebelum",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("ASAL (SEBELUM)", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }

                        // 2. Imej UHD (Selepas) - Dipotong secara melintang mengikut pecahan slider
                        Image(
                            bitmap = outputBitmap!!.asImageBitmap(),
                            contentDescription = "Selepas",
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    clip = true
                                    shape = SplitShape(dragOffsetFraction)
                                },
                            contentScale = ContentScale.Crop
                        )

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentCyan)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("UHD AI (SELEPAS)", style = MaterialTheme.typography.labelSmall, color = PrimaryDark, fontWeight = FontWeight.Bold)
                        }

                        // 3. Garis Pembahagi & Pemegang Leret Dinamik (Pixel-aligned)
                        val density = LocalDensity.current
                        val dividerX = remember(parentSize, dragOffsetFraction) {
                            with(density) { (parentSize.width * dragOffsetFraction).toDp() }
                        }

                        // Garis Pembahagi
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(2.dp)
                                .offset(x = dividerX)
                                .background(AccentCyan)
                        )

                        // Pemegang Slider Bulat (Glow handle)
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .align(Alignment.CenterStart)
                                .offset(x = dividerX - 20.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(AccentCyan)
                                .border(2.dp, Color.White, RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SwapHoriz,
                                contentDescription = null,
                                tint = PrimaryDark,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Butang Kawalan Galeri / Tetapan semula
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            inputBitmap = null
                            outputBitmap = null
                            imageUri = null
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tukar Imej")
                    }

                    if (outputBitmap != null) {
                        Button(
                            onClick = {
                                val uri = ImageUtils.saveBitmapToGallery(context, outputBitmap!!, "AIUhdHub_${System.currentTimeMillis()}")
                                if (uri != null) {
                                    Toast.makeText(context, "Gambar UHD disimpan ke galeri!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Gagal menyimpan imej.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen, contentColor = PrimaryDark)
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan UHD", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Control Panel
        if (inputBitmap != null && !processing && outputBitmap == null) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                glowColor = AccentBlue,
                showGlow = false
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Konfigurasi Enjin AI",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Model Selector
                    Text("Model AI UHD Tersedia (Offline)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (downloadedModels.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(StatusInactive.copy(alpha = 0.1f))
                                .border(1.dp, StatusInactive.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Tiada model AI ditemui di storan peranti. Sila muat turun sekurang-kurangnya satu model di tab 'Model Hub' terlebih dahulu.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusInactive,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        var showDropdown by remember { mutableStateOf(false) }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardDark)
                                .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
                                .clickable { showDropdown = true }
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedModel?.name ?: "Pilih Model",
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = TextMuted)
                            }

                            DropdownMenu(
                                expanded = showDropdown,
                                onDismissRequest = { showDropdown = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .background(CardDark)
                            ) {
                                downloadedModels.forEach { model ->
                                    DropdownMenuItem(
                                        text = { Text(model.name, color = TextPrimary) },
                                        onClick = {
                                            selectedModel = model
                                            showDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Scale factor info (TFLite is fixed 4x, others fallback scale factor)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Skala Pemprosesan", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text(
                            text = if (selectedModel?.id?.startsWith("realesrgan_photo") == true) "4x AI Super-Resolution (TFLite)" else "${scaleFactor.toInt()}x UHD Scaling (Fallback)",
                            style = MaterialTheme.typography.labelSmall,
                            color = AccentCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (selectedModel?.id?.startsWith("realesrgan_photo") != true) {
                        Slider(
                            value = scaleFactor,
                            onValueChange = { scaleFactor = it },
                            valueRange = 2f..4f,
                            steps = 1,
                            colors = SliderDefaults.colors(thumbColor = AccentCyan, activeTrackColor = AccentCyan, inactiveTrackColor = DividerColor)
                        )
                    } else {
                        Spacer(modifier = Modifier.height(8.dp))
                        // TFLite ESRGAN is exactly 4x and cannot be changed
                        LinearProgressIndicator(
                            progress = 1.0f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = AccentCyan,
                            trackColor = DividerColor
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Denoise Level
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Denoise (Pengurangan Hingar)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("${(denoiseLevel * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AccentPurple, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = denoiseLevel,
                        onValueChange = { denoiseLevel = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = AccentPurple, activeTrackColor = AccentPurple, inactiveTrackColor = DividerColor)
                    )

                    // Sharpen Intensity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sharpen (Penajaman Sempadan)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("${(sharpenIntensity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AccentBlue, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = sharpenIntensity,
                        onValueChange = { sharpenIntensity = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = AccentBlue, activeTrackColor = AccentBlue, inactiveTrackColor = DividerColor)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Butang Mula
                    Button(
                        onClick = {
                            if (selectedModel == null) return@Button
                            processing = true
                            coroutineScope.launch {
                                try {
                                    outputBitmap = UhdUpscaleEngine.upscaleImage(
                                        context = context,
                                        inputBitmap = inputBitmap!!,
                                        scaleFactor = if (selectedModel?.id?.startsWith("realesrgan_photo") == true) 4f else scaleFactor,
                                        denoiseLevel = denoiseLevel,
                                        sharpenIntensity = sharpenIntensity,
                                        modelFilename = selectedModel?.filename
                                    )
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Ralat pemprosesan: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                } finally {
                                    processing = false
                                }
                            }
                        },
                        enabled = selectedModel != null,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentCyan,
                            contentColor = PrimaryDark,
                            disabledContainerColor = DividerColor
                        )
                    ) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Mula Proses AI UHD", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = true
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
