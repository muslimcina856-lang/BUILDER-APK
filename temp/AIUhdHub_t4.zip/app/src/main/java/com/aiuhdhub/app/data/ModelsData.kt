package com.aiuhdhub.app.data

data class DownloadableModel(
    val id: String,
    val name: String,
    val type: String,
    val size: String,
    val description: String,
    val downloadUrl: String,
    val filename: String,
    val engineType: String = "TFLite / GPU",
    val compatibility: String = "Sangat Baik (GPU)",
    val normalizeToOne: Boolean = false // Jika true, nilai input dinormalisasikan ke [0, 1]
)

object ModelsRepository {
    fun getDownloadableModels(): List<DownloadableModel> = listOf(
        DownloadableModel(
            id = "realesrgan_x4plus_qualcomm",
            name = "Real-ESRGAN x4plus (Qualcomm PRO)",
            type = "Super Resolution (Qualcomm/FP32)",
            size = "67.4 MB",
            description = "Model uncompressed (FP32) rasmi dari Qualcomm AI Hub. Dioptimumkan khas untuk GPU Adreno/Dimensity mudah alih bagi mengekalkan perincian UHD yang paling asli.",
            downloadUrl = "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/main/Real-ESRGAN-x4plus.tflite",
            filename = "realesrgan_x4plus_qualcomm.tflite",
            engineType = "TFLite / GPU (Qualcomm)",
            compatibility = "Poco X8 Pro Max (Dimensity 9500s)",
            normalizeToOne = true
        ),
        DownloadableModel(
            id = "realesrgan_photo_pro",
            name = "Real-ESRGAN UHD Photo (TFHub PRO)",
            type = "Super Resolution (Asli/FP32)",
            size = "67.2 MB",
            description = "Model penuh tanpa mampatan (FP32) terus dari TFHub. Menggunakan tensor unquantized untuk memulihkan butiran asal foto tanpa kehilangan ketepatan data.",
            downloadUrl = "https://tfhub.dev/captain-pool/esrgan-tf2/1?lite=tflite",
            filename = "realesrgan_photo_pro.tflite",
            engineType = "TFLite / GPU",
            compatibility = "Memerlukan Peranti Tinggi",
            normalizeToOne = false
        ),
        DownloadableModel(
            id = "realesrgan_photo_lite",
            name = "Real-ESRGAN UHD Photo (LITE)",
            type = "Super Resolution (Mampat/FP16)",
            size = "7.8 MB",
            description = "Model versi mampat (FP16/INT8) untuk peranti mudah alih. Dioptimumkan untuk kelajuan tinggi, penjimatan bateri, dan penggunaan RAM rendah.",
            downloadUrl = "https://github.com/tensorflow/examples/raw/master/lite/examples/super_resolution/android/app/src/main/assets/esrgan.tflite",
            filename = "realesrgan_photo_lite.tflite",
            engineType = "TFLite / GPU",
            compatibility = "Semua Peranti (Sangat Pantas)",
            normalizeToOne = false
        ),
        DownloadableModel(
            id = "waifu2x_anime",
            name = "Waifu2x Anime Ultra",
            type = "Super Resolution (Anime)",
            size = "4.2 MB",
            description = "Model khusus untuk ilustrasi anime dan seni lukisan digital. Mengurangkan artifak JPEG dan melicinkan garisan luar objek.",
            downloadUrl = "https://github.com/nihui/realcugan-ncnn-vulkan/releases/download/v0.1.0/realcugan-v0.1.0.zip",
            filename = "waifu2x_anime.bin",
            engineType = "NCNN / GPU",
            compatibility = "Sederhana (GPU)",
            normalizeToOne = true
        )
    )
}
