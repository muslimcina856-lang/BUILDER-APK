import 'app_edition.dart';

abstract final class AppConfig {
  static const String appName = 'Ai MultiAgent';
  static const String version = '1.0.0';

  static AppEdition edition = AppEdition.play;

  static void configure(AppEdition value) {
    edition = value;
  }

  static bool get isFullEdition => edition.isFull;
  static bool get isPlayEdition => edition.isPlay;
  static String get editionName => edition.displayName;
  static String get packageName =>
      isFullEdition ? 'com.aiauto.claw.full' : 'com.aiauto.claw';
  static String get launcherName =>
      isFullEdition ? 'Ai MultiAgent Full' : appName;
  static String get iconAsset => isFullEdition
      ? 'assets/images/app_icon_full.png'
      : 'assets/images/app_icon_play.png';

  /// Full membenarkan pemasangan pakej di dalam Linux Workspace peribadi.
  /// Standard hanya menggunakan pakej native yang dibundel bersama aplikasi.
  static bool get linuxWorkspaceEnabled => isFullEdition;

  /// Edisi Full sahaja menjalankan Linux PRoot dan pemasangan pakej native
  /// dalam storan dalaman private aplikasi.
  static bool get linuxPackageInstallEnabled => isFullEdition;

  /// Edisi Full menyediakan lapisan Windows local (Wine WoW64 + Box64)
  /// yang dimuat turun pada penggunaan pertama.
  static bool get windowsCompatibilityEnabled => isFullEdition;

  static int get androidTargetSdk => isFullEdition ? 28 : 36;

  /// Tiada had token atau sub-agent buatan aplikasi. Provider, Android dan
  /// sumber peranti masih boleh mengenakan had teknikal mereka sendiri.
  static const int maxAgentSteps = 0;
  static const int maxAgentDepth = 0;
  static const int maxSearchResults = 20;
  static const Duration defaultTimeout = Duration(minutes: 3);
  static const Duration browserTimeout = Duration(minutes: 2);
  // Sesi kekal merentas buka semula app supaya konteks chat tidak hilang cepat.
  // Pemadaman lama dikawal tetapan retensi sejarah (hari).
  static const Duration sessionInactivityTimeout = Duration(hours: 12);
  static const Duration backgroundExecutionLimit = Duration(minutes: 30);
  static const Duration terminalDefaultTimeout = Duration(minutes: 5);
  static const int maxToolOutputChars = 48000;
  static const int maxHtmlPreviewChars = 160000;
  static const int maxAttachmentBytes = 250 * 1024 * 1024;
  static const int maxInlineModelAttachmentBytes = 12 * 1024 * 1024;
  static const int maxDownloadBytes = 250 * 1024 * 1024;
  static const int maxSkillArchiveBytes = 50 * 1024 * 1024;
  static const String sessionHeader = 'X-Ai-MultiAgent';
}
