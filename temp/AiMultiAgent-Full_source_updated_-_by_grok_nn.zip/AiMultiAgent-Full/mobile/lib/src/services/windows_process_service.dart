import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'windows_runtime_service.dart';

class _WindowsRollingTextBuffer {
  _WindowsRollingTextBuffer(this.maxChars);

  final int maxChars;
  String _value = '';
  bool _truncated = false;

  void write(Object? chunk) {
    final text = chunk?.toString() ?? '';
    if (text.isEmpty) return;
    final combined = '$_value$text';
    if (combined.length <= maxChars) {
      _value = combined;
      return;
    }
    _value = combined.substring(combined.length - maxChars);
    _truncated = true;
  }

  @override
  String toString() =>
      _truncated ? '… output awal dipotong …\n$_value' : _value;
}

class WindowsJob {
  WindowsJob({
    required this.id,
    required this.command,
    required this.workingDirectory,
    required this.startedAt,
    required this.process,
    required this.kind,
  });

  final String id;
  final String command;
  final String workingDirectory;
  final DateTime startedAt;
  final Process process;
  final String kind;
  final _WindowsRollingTextBuffer stdout =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  final _WindowsRollingTextBuffer stderr =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  int? exitCode;
  DateTime? finishedAt;

  bool get running => exitCode == null;

  Map<String, dynamic> snapshot() => <String, dynamic>{
        'job_id': id,
        'kind': kind,
        'command': command,
        'working_directory': workingDirectory,
        'running': running,
        'exit_code': exitCode,
        'started_at': startedAt.toIso8601String(),
        'finished_at': finishedAt?.toIso8601String(),
        'stdout': stdout.toString(),
        'stderr': stderr.toString(),
      };
}

class WindowsProcessService {
  factory WindowsProcessService() => _instance;
  WindowsProcessService._();

  static final WindowsProcessService _instance = WindowsProcessService._();
  static const Uuid _uuid = Uuid();
  static const int _maxRetainedJobs = 32;
  static const int _maxConcurrentJobs = 1;
  static const Duration _gracefulStopTimeout = Duration(seconds: 3);
  static const Duration _forcedStopTimeout = Duration(seconds: 2);

  final WindowsRuntimeService _runtime = WindowsRuntimeService();
  final Map<String, WindowsJob> _jobs = <String, WindowsJob>{};

  /// Apabila true, AI tidak boleh hantar windows_ui_action (pengguna kawal).
  bool userControlActive = false;

  /// Path host frame live terakhir (private app storage).
  String? latestLiveScreenshotPath;

  Process? _liveStreamProcess;
  bool _liveStreamStarting = false;
  int liveFrameGeneration = 0;

  Iterable<WindowsJob> get jobs => _jobs.values;

  bool get hasRunningJobs => _jobs.values.any((job) => job.running);

  bool get isLiveStreaming =>
      _liveStreamProcess != null || _liveStreamStarting;

  bool isDestructiveCommand(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    const patterns = <String>[
      ' del ',
      ' erase ',
      ' rmdir ',
      ' rd /s',
      ' format ',
      ' diskpart',
      ' bcdedit',
      ' reg delete',
      ' shutdown',
      ' cipher /w',
      ' taskkill /f',
    ];
    final padded = ' $normalized ';
    return patterns.any(padded.contains);
  }

  Future<ToolResult> startCommand({
    required String command,
    String workingDirectory = '.',
  }) async {
    final text = command.trim();
    if (text.isEmpty) {
      return const ToolResult(success: false, output: 'Arahan Windows kosong.');
    }
    return _start(
      displayCommand: text,
      guestCommand: _runtime.wrapWindowsCommand(text),
      workingDirectory: workingDirectory,
      kind: 'cmd',
    );
  }

  Future<ToolResult> startExecutable({
    required String path,
    List<String> arguments = const <String>[],
    String workingDirectory = '.',
  }) async {
    try {
      final resolved = await _runtime.resolveExecutablePath(path);
      final cleanArguments = arguments
          .map((value) => value.replaceAll('\u0000', ''))
          .toList(growable: false);
      return _start(
        displayCommand: '${resolved.guestPath} ${cleanArguments.join(' ')}'.trim(),
        guestCommand: _runtime.wrapWindowsExecutable(
          resolved.guestPath,
          cleanArguments,
        ),
        workingDirectory: workingDirectory,
        kind: 'exe',
      );
    } on FileSystemException catch (error) {
      return ToolResult(success: false, output: error.message);
    }
  }

  Future<ToolResult> _start({
    required String displayCommand,
    required String guestCommand,
    required String workingDirectory,
    required String kind,
  }) async {
    if (!AppConfig.isFullEdition) {
      return const ToolResult(
        success: false,
        output: 'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final runningJobs = _jobs.values.where((job) => job.running).length;
    if (runningJobs >= _maxConcurrentJobs) {
      return const ToolResult(
        success: false,
        output: 'Satu proses Windows sedang aktif. Pantau atau hentikan job itu dahulu.',
      );
    }
    _pruneCompletedJobs();
    try {
      await _runtime.ensureReady();
      final spec = await _runtime.commandSpec(
        command: guestCommand,
        relativeWorkingDirectory: workingDirectory,
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final job = WindowsJob(
        id: _uuid.v4(),
        command: displayCommand,
        workingDirectory: workingDirectory,
        startedAt: DateTime.now(),
        process: process,
        kind: kind,
      );
      _jobs[job.id] = job;
      unawaited(startLiveStream());
      process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stdout.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stderr.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      unawaited(process.exitCode.then((code) {
        job.exitCode = code;
        job.finishedAt = DateTime.now();
      }));
      return ToolResult(
        success: true,
        output: jsonEncode(job.snapshot()),
        data: job.snapshot(),
      );
    } on FileSystemException catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows tidak dapat dimulakan: ${error.message}',
      );
    } on ProcessException catch (error) {
      return ToolResult(
        success: false,
        output: 'Proses Windows gagal dimulakan: ${error.message}',
      );
    } on TimeoutException {
      return const ToolResult(
        success: false,
        output: 'Penyediaan PC Windows tamat masa.',
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows gagal dimulakan dengan selamat: $error',
      );
    }
  }

  Future<ToolResult> poll(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    final snapshot = job.snapshot();
    return ToolResult(
      success: job.exitCode == null || job.exitCode == 0,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> stop(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    if (!job.running) return poll(jobId);
    await _stopJob(job);
    final snapshot = job.snapshot();
    return ToolResult(
      success: !job.running,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> listWindows() async {
    if (!_jobs.values.any((job) => job.running)) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk diperiksa.',
      );
    }
    const command = r'''
DISPLAY=:99
export DISPLAY
ids="$(xdotool search --onlyvisible --name '.*' 2>/dev/null || true)"
for id in $ids; do
  name="$(xdotool getwindowname "$id" 2>/dev/null || true)"
  printf '%s\t%s\n' "$id" "$name"
done
''';
    return _runControl(command, action: 'list_windows');
  }

  Future<ToolResult> uiAction({
    required String action,
    int? x,
    int? y,
    int? x2,
    int? y2,
    int? button,
    int? amount,
    int? width,
    int? height,
    String text = '',
    String key = '',
    String windowId = '',
  }) async {
    if (userControlActive) {
      return const ToolResult(
        success: false,
        output:
            'Pengguna sedang mengawal PC Windows. AI ditangguhkan sehingga pengguna lepaskan kawalan.',
      );
    }
    if (!_jobs.values.any((job) => job.running)) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk dikawal.',
      );
    }

    bool inDesktop(int? px, int? py) =>
        px != null &&
        py != null &&
        px >= 0 &&
        px < WindowsRuntimeService.desktopWidth &&
        py >= 0 &&
        py < WindowsRuntimeService.desktopHeight;

    String command;
    switch (action) {
      case 'click':
      case 'double_click':
      case 'right_click':
      case 'middle_click':
        if (!inDesktop(x, y)) {
          return const ToolResult(
            success: false,
            output: 'Koordinat mouse Windows tidak sah (0..1279, 0..719).',
          );
        }
        final safeButton = switch (action) {
          'right_click' => 3,
          'middle_click' => 2,
          _ => button ?? 1,
        };
        if (safeButton < 1 || safeButton > 5) {
          return const ToolResult(
            success: false,
            output: 'Butang mouse Windows tidak sah (1-5).',
          );
        }
        final repeat = action == 'double_click' ? 2 : 1;
        command =
            'DISPLAY=:99 xdotool mousemove --sync $x $y click --repeat $repeat --delay 40 $safeButton';
        break;

      case 'move':
        if (!inDesktop(x, y)) {
          return const ToolResult(
            success: false,
            output: 'Koordinat mouse Windows tidak sah (0..1279, 0..719).',
          );
        }
        command = 'DISPLAY=:99 xdotool mousemove --sync $x $y';
        break;

      case 'drag':
        if (!inDesktop(x, y) || !inDesktop(x2, y2)) {
          return const ToolResult(
            success: false,
            output:
                'Koordinat drag tidak sah. Berikan x,y (mula) dan x2,y2 (tamat) dalam desktop 1280x720.',
          );
        }
        final dragButton = button ?? 1;
        if (dragButton < 1 || dragButton > 3) {
          return const ToolResult(
            success: false,
            output: 'Butang drag mesti 1 (kiri), 2 (tengah) atau 3 (kanan).',
          );
        }
        command =
            'DISPLAY=:99 xdotool mousemove --sync $x $y mousedown $dragButton mousemove --sync $x2 $y2 mouseup $dragButton';
        break;

      case 'scroll':
        // amount > 0 = ke bawah (button 5), amount < 0 = ke atas (button 4)
        final delta = amount ?? 3;
        if (delta == 0 || delta.abs() > 50) {
          return const ToolResult(
            success: false,
            output: 'Jumlah scroll mesti antara -50 dan 50, bukan 0.',
          );
        }
        final wheelButton = delta > 0 ? 5 : 4;
        final clicks = delta.abs();
        final move = inDesktop(x, y) ? 'mousemove --sync $x $y ' : '';
        command =
            'DISPLAY=:99 xdotool ${move}click --repeat $clicks --delay 20 $wheelButton';
        break;

      case 'type':
        final clean = text.replaceAll('\u0000', '');
        if (clean.isEmpty || clean.length > 4000) {
          return const ToolResult(
            success: false,
            output: 'Teks untuk ditaip mesti 1 hingga 4000 aksara.',
          );
        }
        command =
            'DISPLAY=:99 xdotool type --clearmodifiers --delay 8 ${_shellQuote(clean)}';
        break;

      case 'key':
      case 'hotkey':
        final clean = key.trim();
        // Benarkan gabungan seperti ctrl+c, alt+F4, shift+Tab
        if (!RegExp(r'^[A-Za-z0-9_+:.\-]+$').hasMatch(clean) ||
            clean.length > 120) {
          return const ToolResult(
            success: false,
            output:
                'Nama kekunci/hotkey tidak sah. Contoh: Return, ctrl+c, alt+F4, Escape.',
          );
        }
        command =
            'DISPLAY=:99 xdotool key --clearmodifiers ${_shellQuote(clean)}';
        break;

      case 'focus':
        final clean = windowId.trim();
        if (!RegExp(r'^\d{1,20}$').hasMatch(clean)) {
          return const ToolResult(
            success: false,
            output: 'window_id mesti nombor daripada windows_list_windows.',
          );
        }
        command = 'DISPLAY=:99 xdotool windowactivate --sync $clean';
        break;

      case 'minimize':
      case 'maximize':
      case 'close_window':
        final clean = windowId.trim();
        if (!RegExp(r'^\d{1,20}$').hasMatch(clean)) {
          return const ToolResult(
            success: false,
            output: 'window_id mesti nombor daripada windows_list_windows.',
          );
        }
        final verb = switch (action) {
          'minimize' => 'windowminimize',
          'maximize' => 'windowmaximize',
          _ => 'windowclose',
        };
        command =
            'DISPLAY=:99 xdotool windowactivate --sync $clean $verb $clean';
        break;

      case 'move_window':
        final clean = windowId.trim();
        if (!RegExp(r'^\d{1,20}$').hasMatch(clean) || !inDesktop(x, y)) {
          return const ToolResult(
            success: false,
            output:
                'move_window memerlukan window_id dan koordinat x,y yang sah.',
          );
        }
        command =
            'DISPLAY=:99 xdotool windowactivate --sync $clean windowmove $clean $x $y';
        break;

      case 'resize_window':
        final clean = windowId.trim();
        final w = width ?? 0;
        final h = height ?? 0;
        if (!RegExp(r'^\d{1,20}$').hasMatch(clean) ||
            w < 50 ||
            h < 50 ||
            w > WindowsRuntimeService.desktopWidth ||
            h > WindowsRuntimeService.desktopHeight) {
          return const ToolResult(
            success: false,
            output:
                'resize_window memerlukan window_id, width dan height yang sah (min 50).',
          );
        }
        command =
            'DISPLAY=:99 xdotool windowactivate --sync $clean windowsize $clean $w $h';
        break;

      default:
        return const ToolResult(
          success: false,
          output:
              'Action GUI Windows tidak dikenali. Gunakan: click, double_click, right_click, middle_click, move, drag, scroll, type, key, hotkey, focus, minimize, maximize, close_window, move_window, resize_window.',
        );
    }
    return _runControl(command, action: action);
  }

  Future<ToolResult> _runControl(
    String command, {
    required String action,
  }) async {
    try {
      final spec = await _runtime.commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stdoutFuture = process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stdout = await stdoutFuture;
      final stderr = await stderrFuture;
      final data = <String, dynamic>{
        'action': action,
        'exit_code': exitCode,
        'stdout': stdout,
        'stderr': stderr,
      };
      return ToolResult(
        success: exitCode == 0,
        output: exitCode == 0
            ? (stdout.trim().isEmpty ? 'Action GUI Windows selesai.' : stdout.trim())
            : 'Action GUI Windows gagal (exit $exitCode): $stderr',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Action GUI Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Action GUI Windows gagal: $error');
    }
  }

  Future<ToolResult> screenshot() async {
    final running = _jobs.values.where((job) => job.running).isNotEmpty;
    if (!running) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk di-screenshot.',
      );
    }
    try {
      final hostPath = await _runtime.screenshotHostPath();
      final linuxRoot = (await WindowsRuntimeService().commandSpec(
        command: 'true',
        relativeWorkingDirectory: '.',
      ));
      final workspaceHost = linuxRoot.hostWorkingDirectory;
      final relative = p.relative(hostPath, from: workspaceHost).replaceAll('\\', '/');
      final guestPath = '/workspace/$relative';
      final spec = await _runtime.commandSpec(
        command: 'DISPLAY=${WindowsRuntimeService.displayName} scrot -q 100 ${_shellQuote(guestPath)}',
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stderr = await stderrFuture;
      if (exitCode != 0 || !await File(hostPath).exists()) {
        return ToolResult(
          success: false,
          output: 'Screenshot Windows gagal (exit $exitCode): $stderr',
        );
      }
      latestLiveScreenshotPath = hostPath;
      final data = <String, dynamic>{
        'path': hostPath,
        'mime': 'image/png',
        'width': WindowsRuntimeService.desktopWidth,
        'height': WindowsRuntimeService.desktopHeight,
      };
      return ToolResult(
        success: true,
        output: 'Screenshot PC Windows tersedia.',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Screenshot Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Screenshot Windows gagal: $error');
    }
  }

  /// Mula loop tangkap frame berterusan (~6–8 fps) ke live.jpg.
  Future<void> startLiveStream() async {
    if (_liveStreamProcess != null || _liveStreamStarting) return;
    _liveStreamStarting = true;
    try {
      final hostPath = await _runtime.liveFrameHostPath();
      latestLiveScreenshotPath = hostPath;
      final display = WindowsRuntimeService.displayName;
      final w = WindowsRuntimeService.desktopWidth;
      final h = WindowsRuntimeService.desktopHeight;
      final command = '''
set -eu
mkdir -p /tmp/.X11-unix /workspace/windows/screenshots
if [ ! -S /tmp/.X11-unix/X99 ]; then
  rm -f /tmp/.X99-lock
  Xvfb $display -screen 0 ${w}x${h}x24 -nolisten tcp >/tmp/ai-windows-xvfb.log 2>&1 &
  i=0
  while [ ! -S /tmp/.X11-unix/X99 ] && [ "\$i" -lt 50 ]; do
    i=\$((i + 1))
    sleep 0.1
  done
fi
LIVE=/workspace/windows/screenshots/live.jpg
TMP=\$LIVE.tmp
# Cuba ffmpeg x11grab (lebih lancar); fallback scrot ~8 fps.
if command -v ffmpeg >/dev/null 2>&1; then
  exec ffmpeg -hide_banner -loglevel error -y \\
    -f x11grab -video_size ${w}x${h} -framerate 8 -i $display \\
    -vf fps=8 -q:v 8 -update 1 "\$LIVE"
fi
while true; do
  if command -v scrot >/dev/null 2>&1; then
    DISPLAY=$display scrot -q 50 -o "\$TMP" 2>/dev/null \\
      || DISPLAY=$display scrot -q 50 "\$TMP" 2>/dev/null \\
      || true
  elif command -v import >/dev/null 2>&1; then
    DISPLAY=$display import -window root -quality 50 "\$TMP" 2>/dev/null || true
  fi
  if [ -f "\$TMP" ]; then
    mv -f "\$TMP" "\$LIVE" 2>/dev/null || cp -f "\$TMP" "\$LIVE" 2>/dev/null || true
  fi
  sleep 0.12
done
''';
      final spec = await _runtime.commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
        requireReady: false,
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      unawaited(process.stdout.drain<void>());
      unawaited(process.stderr.drain<void>());
      _liveStreamProcess = process;
      process.exitCode.then((_) {
        if (identical(_liveStreamProcess, process)) {
          _liveStreamProcess = null;
        }
      });
    } catch (_) {
      // Biarkan caller guna frame terakhir / screenshot sekali.
    } finally {
      _liveStreamStarting = false;
    }
  }

  Future<void> stopLiveStream() async {
    final process = _liveStreamProcess;
    _liveStreamProcess = null;
    if (process == null) return;
    process.kill(ProcessSignal.sigterm);
    try {
      await process.exitCode.timeout(const Duration(seconds: 2));
    } on TimeoutException {
      process.kill(ProcessSignal.sigkill);
    } catch (_) {}
  }

  /// Baca frame live semasa (tanpa scrot sekali lagi jika stream aktif).
  Future<String?> captureLivePreview() async {
    await startLiveStream();
    final path = latestLiveScreenshotPath ?? await _runtime.liveFrameHostPath();
    latestLiveScreenshotPath = path;
    final file = File(path);
    if (await file.exists()) {
      liveFrameGeneration = (await file.lastModified()).millisecondsSinceEpoch;
      return path;
    }
    // Frame pertama belum sedia — cuba satu screenshot fallback.
    if (hasRunningJobs) {
      final result = await screenshot();
      if (result.success) {
        final shot = result.data?['path']?.toString();
        if (shot != null && shot.isNotEmpty) {
          try {
            await File(shot).copy(path);
          } catch (_) {}
          liveFrameGeneration = DateTime.now().millisecondsSinceEpoch;
          return path;
        }
      }
    }
    return latestLiveScreenshotPath;
  }

  Future<void> stopAll() async {
    final running =
        _jobs.values.where((job) => job.running).toList(growable: false);
    await Future.wait(running.map(_stopJob));
    await stopLiveStream();
    if (!hasRunningJobs) {
      userControlActive = false;
    }
  }

  Future<void> _stopJob(WindowsJob job) async {
    if (!job.running) return;
    final sent = job.process.kill(ProcessSignal.sigterm);
    if (!sent) job.process.kill(ProcessSignal.sigkill);
    try {
      final code = await job.process.exitCode.timeout(_gracefulStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
      return;
    } on TimeoutException {
      job.process.kill(ProcessSignal.sigkill);
    }
    try {
      final code = await job.process.exitCode.timeout(_forcedStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
    } on TimeoutException {
      job.stderr.write('\nProses Windows tidak memberi respons selepas SIGKILL.');
    }
  }

  void _pruneCompletedJobs() {
    if (_jobs.length < _maxRetainedJobs) return;
    final completed = _jobs.values.where((job) => !job.running).toList()
      ..sort((a, b) =>
          (a.finishedAt ?? a.startedAt).compareTo(b.finishedAt ?? b.startedAt));
    while (_jobs.length >= _maxRetainedJobs && completed.isNotEmpty) {
      _jobs.remove(completed.removeAt(0).id);
    }
  }

  void dispose() => unawaited(stopAll());

  static String _shellQuote(String value) =>
      "'${value.replaceAll("'", "'\\''").replaceAll('\u0000', '')}'";
}
