import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}
val releaseSigningKeys = listOf("keyAlias", "keyPassword", "storeFile", "storePassword")
val releaseStorePath = keystoreProperties.getProperty("storeFile")?.trim()
val releaseStoreFile = releaseStorePath
    ?.takeIf { it.isNotEmpty() }
    ?.let { file(it) }
val hasReleaseSigning = keystorePropertiesFile.exists() &&
    releaseSigningKeys.all { !keystoreProperties.getProperty(it).isNullOrBlank() } &&
    releaseStoreFile?.isFile == true

android {
    namespace = "com.aiauto.claw"
    buildFeatures {
        buildConfig = true
    }
    compileSdk = 36
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.aiauto.claw.full"
        minSdk = 24
        targetSdk = 28
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        buildConfigField("boolean", "FULL_LINUX_EDITION", "true")
    }

    // Full/PRoot sengaja mengekalkan targetSdk 28 supaya executable yang
    // dipasang dalam ruang aplikasi boleh dijalankan. Builder pihak ketiga
    // memanggil assembleRelease sebagai finalizer kepada assembleDebug; hanya
    // amaran target SDK yang disengajakan ini dikecualikan. Semakan lint lain
    // kekal aktif dan masih boleh menggagalkan release.
    lint {
        disable += "ExpiredTargetSdkVersion"
    }

    signingConfigs {
        create("release") {
            if (hasReleaseSigning) {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = releaseStoreFile
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        release {
            isDebuggable = false
            isJniDebuggable = false
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            } else {
                logger.warn(
                    "Tiada key.properties lengkap atau fail keystore tidak ditemui; " +
                        "artifact buildType release menggunakan debug key untuk ujian sahaja."
                )
                signingConfig = signingConfigs.getByName("debug")
            }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.webkit:webkit:1.14.0")
}

// Flutter memproses pubspec assets di dalam task compileFlutterBuild*. Panel
// binaan yang memanggil `flutter build` secara terus tidak melalui skrip shell
// projek, jadi runtime Linux mesti disediakan sebagai dependency Gradle juga.
val flutterProjectDir = rootProject.projectDir.parentFile
val repositoryDir = flutterProjectDir.parentFile
val linuxRuntimeBuilder = repositoryDir.resolve("scripts/linux/prepare_bundled_runtime.py")
val linuxRuntimeAssetDir = flutterProjectDir.resolve("assets/linux/full")
val linuxRuntimePack = linuxRuntimeAssetDir.resolve("runtime-pack.zip")
val linuxRuntimeManifest = linuxRuntimeAssetDir.resolve("runtime-manifest.json")
val linuxRuntimeChecksum = linuxRuntimeAssetDir.resolve("runtime-pack.sha256")
val pythonExecutable = System.getenv("PYTHON")
    ?.trim()
    ?.takeIf { it.isNotEmpty() }
    ?: if (System.getProperty("os.name").lowercase().contains("windows")) {
        "python"
    } else {
        "python3"
    }

val prepareBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "build setup"
    description = "Muat turun, sahkan dan bina asset Linux ARM64 sebelum Flutter membungkus assets."
    workingDir(repositoryDir)
    commandLine(pythonExecutable, linuxRuntimeBuilder.absolutePath)
    environment("PYTHONUNBUFFERED", "1")

    inputs.file(linuxRuntimeBuilder)
    inputs.dir(repositoryDir.resolve("scripts/linux/licenses"))
    outputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }

    doFirst {
        if (!linuxRuntimeBuilder.isFile) {
            throw GradleException("Pembina runtime Linux tiada: $linuxRuntimeBuilder")
        }
        linuxRuntimeAssetDir.mkdirs()
    }
}

val verifyBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "verification"
    description = "Sahkan runtime Linux yang akan dibundel ialah ZIP Alpine/PRoot ARM64 yang lengkap."
    dependsOn(prepareBundledLinuxRuntime)
    workingDir(repositoryDir)
    commandLine(
        pythonExecutable,
        linuxRuntimeBuilder.absolutePath,
        "--verify-only",
        "--output",
        linuxRuntimePack.absolutePath,
    )
    environment("PYTHONUNBUFFERED", "1")
    inputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }
}

// Dependency terus pada compileFlutterBuild* penting: `preBuild` sahaja tidak
// menjamin runtime siap sebelum Flutter memeriksa pubspec.yaml.
tasks.configureEach {
    if (name.startsWith("compileFlutterBuild")) {
        dependsOn(verifyBundledLinuxRuntime)
    }
}

// Sesetengah panel binaan pihak ketiga memaksa `flutter build apk --debug`
// dan hanya mengambil app-debug.apk. Untuk projek edaran peribadi ini, pastikan
// permintaan tersebut tetap menghasilkan bytecode/AOT buildType release.
// app-release.apk dikekalkan, manakala app-debug.apk diganti dengan salinan
// artifact release supaya panel yang hard-code nama debug tidak menghantar
// binaan debug sebenar.
val releaseApkForForcedDebugBuilder by tasks.registering {
    group = "build"
    description = "Bina release dan salin artifactnya ke nama output debug untuk builder yang memaksa debug."
    dependsOn("assembleRelease")

    doLast {
        val appBuildDir = layout.buildDirectory.get().asFile
        val flutterApkDir = appBuildDir.resolve("outputs/flutter-apk")
        val gradleReleaseDir = appBuildDir.resolve("outputs/apk/release")

        // `assembleRelease` dipanggil terus sebagai dependency Gradle. Dalam
        // keadaan ini AGP menulis APK ke outputs/apk/release; salinan ke
        // outputs/flutter-apk biasanya hanya dibuat oleh lapisan Flutter CLI.
        val preferredReleaseApks = listOf(
            gradleReleaseDir.resolve("app-release.apk"),
            flutterApkDir.resolve("app-release.apk"),
        )
        val releaseApk = preferredReleaseApks.firstOrNull {
            it.isFile && it.length() > 0L
        } ?: appBuildDir.walkTopDown()
            .filter {
                it.isFile &&
                    it.extension.equals("apk", ignoreCase = true) &&
                    it.name.contains("release", ignoreCase = true) &&
                    !it.name.contains("debug", ignoreCase = true) &&
                    it.length() > 0L
            }
            .maxByOrNull { it.lastModified() }
            ?: throw GradleException(
                "APK release tidak dijana. Lokasi diperiksa: " +
                    preferredReleaseApks.joinToString { it.absolutePath }
            )

        val canonicalReleaseApk = flutterApkDir.resolve("app-release.apk")
        canonicalReleaseApk.parentFile.mkdirs()
        if (releaseApk.canonicalFile != canonicalReleaseApk.canonicalFile) {
            releaseApk.copyTo(canonicalReleaseApk, overwrite = true)
        }

        // Tulis ke kedua-dua lokasi supaya Flutter CLI dan panel yang membaca
        // output AGP secara terus menerima artifact release yang sama.
        val forcedDebugOutputs = listOf(
            flutterApkDir.resolve("app-debug.apk"),
            appBuildDir.resolve("outputs/apk/debug/app-debug.apk"),
        )
        forcedDebugOutputs.forEach { output ->
            output.parentFile.mkdirs()
            canonicalReleaseApk.copyTo(output, overwrite = true)
        }

        logger.lifecycle(
            "Builder meminta debug; output debug telah diganti dengan artifact buildType release: " +
                canonicalReleaseApk.absolutePath
        )
    }
}

tasks.configureEach {
    if (name == "assembleDebug") {
        finalizedBy(releaseApkForForcedDebugBuilder)
    }
}
