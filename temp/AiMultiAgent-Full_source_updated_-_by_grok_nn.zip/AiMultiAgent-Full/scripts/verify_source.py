#!/usr/bin/env python3
from pathlib import Path
import sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
def require(cond, msg):
    if not cond: errors.append(msg)

pubspec = (ROOT / "mobile/pubspec.yaml").read_text(encoding="utf-8")
build = (ROOT / "mobile/android/app/build.gradle.kts").read_text(encoding="utf-8")
manifest_path = ROOT / "mobile/android/app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")

require("version: 1.0.0+1" in pubspec, "Versi mesti 1.0.0+1")
require("assets/linux/full/runtime-pack.zip" in pubspec, "Asset runtime-pack.zip Full mesti disenaraikan secara khusus")
require("assets/linux/full/runtime-manifest.json" in pubspec, "Asset manifest runtime Full tiada")
require((ROOT / "scripts/linux/prepare_bundled_runtime.py").exists(), "Pembina runtime Linux terbina tiada")
require("prepare_bundled_runtime.py" in (ROOT / "scripts/build_full.sh").read_text(encoding="utf-8"), "Build Full tidak menyediakan runtime Linux")
require("prepareBundledLinuxRuntime" in build and
        "verifyBundledLinuxRuntime" in build and
        'name.startsWith("compileFlutterBuild")' in build and
        "dependsOn(verifyBundledLinuxRuntime)" in build,
        "Hook Gradle untuk build terus belum melengkapkan runtime Linux sebelum bundling asset")
require("--target-platform android-arm64" in (ROOT / "scripts/build_full.sh").read_text(encoding="utf-8"), "Build Full mesti dihadkan kepada ARM64")
require("compileSdk = 36" in build, "compileSdk mesti 36")
require('applicationId = "com.aiauto.claw.full"' in build, "applicationId tidak tepat")
require("targetSdk = 28" in build, "targetSdk tidak tepat")
require('FULL_LINUX_EDITION", "true"' in build, "Flag edisi tidak tepat")
require("MANAGE_EXTERNAL_STORAGE" not in manifest, "MANAGE_EXTERNAL_STORAGE tidak dibenarkan")
require("READ_EXTERNAL_STORAGE" not in manifest, "READ_EXTERNAL_STORAGE tidak dibenarkan")
require("WRITE_EXTERNAL_STORAGE" not in manifest, "WRITE_EXTERNAL_STORAGE tidak dibenarkan")
require((ROOT / "mobile/lib/main.dart").exists(), "main.dart tiada")
require((ROOT / "mobile/lib/src/services/provider_service.dart").exists(), "Provider service tiada")
require((ROOT / "mobile/lib/src/services/tool_engine.dart").exists(), "Tool engine tiada")
require((ROOT / "mobile/lib/src/services/duckduckgo_search_service.dart").exists(), "DuckDuckGo service tiada")
home_shell = (ROOT / "mobile/lib/src/ui/home_shell.dart").read_text(encoding="utf-8")
chat_screen = (ROOT / "mobile/lib/src/ui/screens/chat_screen.dart").read_text(encoding="utf-8")
app_theme = (ROOT / "mobile/lib/src/theme/app_theme.dart").read_text(encoding="utf-8")
require("../state/app_state.dart" in home_shell, "Import AppState hilang")
require("class _MediaError extends StatelessWidget" in chat_screen, "_MediaError hilang")
require("class _FullImagePreviewPage" in chat_screen and
        "InteractiveViewer(" in chat_screen and
        "fit: BoxFit.contain" in chat_screen,
        "Pratonton gambar penuh/tanpa potongan tidak lengkap")
require("class _FullVideoPreviewPage" in chat_screen and
        "VideoPlayerController.networkUrl" in chat_screen and
        "Simpan ke peranti" in chat_screen,
        "Pratonton dan simpan video tidak lengkap")
media_export = (ROOT / "mobile/lib/src/services/media_export_service.dart").read_text(encoding="utf-8")
require("class MediaExportService" in media_export,
        "Servis simpan media tiada")
require("if (await file.exists()) await file.delete();" in media_export,
        "Fail media separa tidak dibersihkan apabila muat turun gagal")
require("bool _expanded = false" in chat_screen and
        "Pratonton halaman ditutup secara lalai" in chat_screen,
        "Pratonton HTML masih dibuka besar secara automatik")
require("IconData _fileIcon(String name)" in chat_screen, "_fileIcon hilang")
require("IconData _attachmentIcon(AttachmentKind kind)" in chat_screen, "_attachmentIcon hilang")
require("static const Color error = danger;" in app_theme, "AppTheme.error hilang")
require("AppEdition.full" in (ROOT / "mobile/lib/main.dart").read_text(), "main.dart bukan Full")
require(not (ROOT / "mobile/android/app/src/play").exists(), "Resource Play masih ada")
require("android:extractNativeLibs=\"true\"" in manifest, "extractNativeLibs Full tiada")
linux_service = (ROOT / "mobile/lib/src/services/linux_workspace_service.dart").read_text(encoding="utf-8")
terminal_service = (ROOT / "mobile/lib/src/services/terminal_service.dart").read_text(encoding="utf-8")
agent_runtime = (ROOT / "mobile/lib/src/services/agent_runtime.dart").read_text(encoding="utf-8")
linux_screen = (ROOT / "mobile/lib/src/ui/screens/linux_workspace_screen.dart").read_text(encoding="utf-8")
require("FileSystemEntity.delete(" not in linux_service, "API statik FileSystemEntity.delete yang tidak sah masih digunakan")
require("Future<void> _deleteEntity(" in linux_service, "Helper pemadaman entiti Linux hilang")
require("ensureBundledRuntimeReady" in linux_service, "Auto-install runtime Linux tiada")
require("autoInstallBundledRuntime: true" in terminal_service, "Terminal AI tidak memasang runtime automatik")
require("automaticInstallOnFirstCommand" in (ROOT / "mobile/lib/src/services/tool_engine.dart").read_text(encoding="utf-8"), "Konteks Linux tidak disuntik terus kepada AI")
require("Pengurus pakej ialah apk, bukan apt/dpkg" in agent_runtime, "AI belum diajar aliran Alpine apk")
require("Kemas kini apk" in linux_screen and "apt update" not in linux_screen, "UI Linux masih menggunakan apt/Debian")
require("'PROOT_NO_SECCOMP': '1'" not in linux_service, "Shell masih memaksa PROOT_NO_SECCOMP pada semua peranti")
main_activity = (ROOT / "mobile/android/app/src/main/kotlin/com/aiauto/claw/MainActivity.kt").read_text(encoding="utf-8")
browser_engine = (ROOT / "mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt").read_text(encoding="utf-8")
require('"supportedAbis" to Build.SUPPORTED_ABIS.toList()' in main_activity, "Konteks CPU ABI native tiada")
require('com.aiauto.claw/media' in main_activity and 'Intent.ACTION_CREATE_DOCUMENT' in main_activity,
        "Pemilih simpan media native tidak lengkap")
require("mediaPlaybackRequiresUserGesture = true" in browser_engine and
        "mediaPlaybackRequiresUserGesture = false" not in browser_engine and
        "addDocumentStartJavaScript" in browser_engine and
        "AudioContext" in browser_engine,
        "Browser tersembunyi belum disenyapkan dari awal dokumen")
require("captureScreenshotTile" in browser_engine and
        '"fullPage" to true' in browser_engine,
        "Screenshot satu gambar penuh belum menggunakan tangkapan berjubin")
usage_guide = (ROOT / "mobile/lib/src/data/usage_guide.dart").read_text(encoding="utf-8")
require((ROOT / "mobile/lib/src/ui/screens/usage_guide_screen.dart").exists() and
        "Cara Guna" in (ROOT / "mobile/lib/src/ui/screens/more_screen.dart").read_text(encoding="utf-8") and
        "app_usage_guide" in (ROOT / "mobile/lib/src/services/tool_engine.dart").read_text(encoding="utf-8"),
        "Halaman/tool Cara Guna belum tersedia dalam aplikasi")
require("Terma Penggunaan" not in usage_guide and "Polisi Privasi" not in usage_guide,
        "Perubahan ini hanya boleh menambah Cara Guna, bukan halaman terma/polisi")
tool_engine = (ROOT / "mobile/lib/src/services/tool_engine.dart").read_text(encoding="utf-8")
require("Future<ToolResult> _openUrl" in tool_engine,
        "Pelaksana open_url hilang daripada ToolEngine")
require("id: 'media_preview'" in tool_engine and
        "Future<ToolResult> _mediaPreview" in tool_engine and
        "previewOnly" in tool_engine,
        "Tool pratonton media tanpa muat turun belum lengkap")
try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml tidak sah: {exc}")

if errors:
    print("SEMAKAN GAGAL")
    for item in errors: print("-", item)
    sys.exit(1)
print("SEMAKAN LULUS: Ai MultiAgent Full")
