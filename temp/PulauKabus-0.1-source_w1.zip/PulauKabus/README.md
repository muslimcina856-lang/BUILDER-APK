# Pulau Kabus

Game survival misteri 3D orang ketiga untuk Android. Projek menggunakan C++20 melalui Android NDK, NativeActivity, OpenGL ES 3.0, EGL dan AAudio tanpa enjin permainan pihak ketiga.

## Identiti aplikasi

- Nama aplikasi: **Pulau Kabus**
- Nama pakej: `com.nusaforge.pulaukabus`
- Orientasi: landskap
- Android minimum: Android 8.0 / API 26
- ABI: `arm64-v8a` dan `x86_64`
- Renderer gameplay semasa: OpenGL ES 3.0
- Vulkan: dikesan sebagai ciri pilihan pada manifest; backend khusus Vulkan boleh ditambah melalui sempadan renderer tanpa mengubah sistem gameplay.

## Kandungan versi 0.1

- Kamera orbit orang ketiga 360 darjah
- Joystick maya dan butang sentuh
- Pergerakan relatif kepada arah kamera
- Dunia pulau terbuka yang dijana secara prosedur
- Kutipan kayu, batu dan herba
- Meja kerja, binaan alatan dan naik taraf kem
- Lima makhluk dengan AI mengejar, menyerang dan muncul semula
- Pertarungan tombak dan sistem kesihatan/stamina
- Teka-teki tiga totem serta pintu runtuhan
- HUD Bahasa Melayu
- Bunyi ambien dan kesan bunyi dijana masa nyata melalui AAudio
- Simpanan atomik dalam storan dalaman aplikasi

## Kawalan

- Bahagian kiri: gerakkan watak.
- Seret pada bahagian kanan: pusing kamera 360 darjah dan ubah ketinggian pandangan.
- `SERANG`: serangan tombak.
- `AMBIL`: kutip sumber atau aktifkan totem.
- `BINA`: bina di kem apabila mempunyai 3 kayu dan 2 batu.
- `360`: pulihkan ketinggian kamera.

## Membina dalam Android Studio

Keperluan versi projek:

- Android Studio dengan JDK 17
- Android SDK Platform 36
- Android SDK Build Tools 36.0.0
- Android NDK `28.2.13676358`
- CMake 3.22.1 atau lebih baharu
- Android Gradle Plugin 9.0.1 / Gradle 9.1.0

1. Buka direktori `PulauKabus` dalam Android Studio.
2. Benarkan Android Studio memasang SDK, NDK dan CMake yang diminta.
3. Jalankan konfigurasi `app` pada telefon atau emulator landskap.
4. Untuk APK debug, gunakan **Build > Build APK(s)**.

Jika Gradle wrapper belum diwujudkan pada mesin pembangunan, jalankan:

```bash
gradle wrapper --gradle-version 9.1.0
./gradlew assembleDebug
```

APK terhasil di `app/build/outputs/apk/debug/app-debug.apk`.

## Ujian logik tanpa Android SDK

```bash
./tests/run_host_tests.sh
```

Ujian hos menyemak pergerakan, kutipan, binaan, pertarungan dan turutan teka-teki.

## Nota binaan semasa

Kod projek lengkap boleh diselaraskan oleh Android Studio, tetapi APK tidak dibina dalam persekitaran penjanaan ini kerana Android SDK, NDK, Gradle dan `javac` tidak tersedia. Logik gameplay tetap disusun supaya boleh diuji dengan pengkompil C++ hos.
