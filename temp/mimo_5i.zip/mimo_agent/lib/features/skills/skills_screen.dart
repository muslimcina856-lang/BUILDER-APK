import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/skills/skill_manager.dart';
import '../../core/plugins/plugin_manager.dart';
import '../../core/skills/skill_models.dart';

class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final skillManager = context.watch<SkillManager>();
    final pluginManager = context.watch<PluginManager>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Skills & Plugins'),
        backgroundColor: const Color(0xFF1A1A2E),
      ),
      body: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            const TabBar(
              tabs: [
                Tab(text: 'Skills', icon: Icon(Icons.extension)),
                Tab(text: 'Plugins', icon: Icon(Icons.power)),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _SkillsTab(skillManager: skillManager),
                  _PluginsTab(pluginManager: pluginManager),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SkillsTab extends StatelessWidget {
  final SkillManager skillManager;
  const _SkillsTab({required this.skillManager});

  @override
  Widget build(BuildContext context) {
    final skills = skillManager.skills;

    if (skills.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.extension_off, size: 48, color: Colors.grey),
            SizedBox(height: 16),
            Text('No skills loaded', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('Add skills to ~/.mimo-agent/skills/',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: skills.length,
      itemBuilder: (context, index) {
        final skill = skills.values.elementAt(index);
        return _SkillCard(skill: skill);
      },
    );
  }
}

class _SkillCard extends StatelessWidget {
  final Skill skill;
  const _SkillCard({required this.skill});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ExpansionTile(
        leading: const Icon(Icons.extension, color: Color(0xFF6366F1)),
        title: Text(skill.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
          skill.description.length > 100
              ? '${skill.description.substring(0, 100)}...'
              : skill.description,
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (skill.version != null)
                  Text('Version: ${skill.version}',
                      style: const TextStyle(fontSize: 12)),
                if (skill.allowedTools.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  const Text('Allowed Tools:',
                      style: TextStyle(fontSize: 12, color: Colors.grey)),
                  Wrap(
                    spacing: 4,
                    children: skill.allowedTools
                        .map((t) => Chip(
                              label: Text(t, style: const TextStyle(fontSize: 10)),
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                            ))
                        .toList(),
                  ),
                ],
                const SizedBox(height: 8),
                const Text('Content Preview:',
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F0F23),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    skill.content.length > 500
                        ? '${skill.content.substring(0, 500)}...'
                        : skill.content,
                    style: const TextStyle(
                        fontFamily: 'monospace', fontSize: 11),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PluginsTab extends StatelessWidget {
  final PluginManager pluginManager;
  const _PluginsTab({required this.pluginManager});

  @override
  Widget build(BuildContext context) {
    final plugins = pluginManager.plugins;

    if (plugins.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.power_off, size: 48, color: Colors.grey),
            SizedBox(height: 16),
            Text('No plugins loaded', style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text('Add plugins to ~/.mimo-agent/plugins/',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: plugins.length,
      itemBuilder: (context, index) {
        final plugin = plugins.values.elementAt(index);
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: const Icon(Icons.power, color: Color(0xFF6366F1)),
            title: Text(plugin.name,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(plugin.description,
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
            trailing: Text('${plugin.skills.length} skills',
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ),
        );
      },
    );
  }
}
