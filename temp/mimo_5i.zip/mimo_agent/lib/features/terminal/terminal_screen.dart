import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/tools/bash_tool.dart';
import '../../core/tools/tool_registry.dart';

/// Terminal screen for direct bash command execution
class TerminalScreen extends StatefulWidget {
  const TerminalScreen({super.key});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final List<_TerminalLine> _lines = [];
  String _workingDirectory = '/';

  @override
  void initState() {
    super.initState();
    _lines.add(_TerminalLine(
      text: 'Mimo Agent Terminal',
      type: LineType.system,
    ));
    _lines.add(_TerminalLine(
      text: 'Type commands or use AI to execute them.',
      type: LineType.system,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terminal'),
        backgroundColor: const Color(0xFF1A1A2E),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear_all),
            onPressed: () => setState(() => _lines.clear()),
            tooltip: 'Clear',
          ),
        ],
      ),
      body: Column(
        children: [
          // Working directory indicator
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: const Color(0xFF1A1A2E),
            child: Row(
              children: [
                const Icon(Icons.folder, size: 16, color: Colors.amber),
                const SizedBox(width: 8),
                Text(
                  _workingDirectory,
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 12,
                    color: Colors.amber,
                  ),
                ),
              ],
            ),
          ),

          // Terminal output
          Expanded(
            child: Container(
              color: const Color(0xFF0A0A1A),
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(8),
                itemCount: _lines.length,
                itemBuilder: (context, index) {
                  final line = _lines[index];
                  return _TerminalLineWidget(line: line);
                },
              ),
            ),
          ),

          // Input
          Container(
            padding: const EdgeInsets.all(8),
            color: const Color(0xFF1A1A2E),
            child: Row(
              children: [
                const Text('\$ ',
                    style: TextStyle(
                        fontFamily: 'monospace',
                        color: Colors.green,
                        fontWeight: FontWeight.bold)),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(
                        fontFamily: 'monospace', color: Colors.white),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Enter command...',
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                    onSubmitted: (_) => _executeCommand(),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.green),
                  onPressed: _executeCommand,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _executeCommand() async {
    final command = _controller.text.trim();
    if (command.isEmpty) return;

    setState(() {
      _lines.add(_TerminalLine(
        text: '\$ $command',
        type: LineType.command,
      ));
      _controller.clear();
    });

    try {
      final bashTool = BashTool();
      final result = await bashTool.execute({
        'command': command,
        'timeout': 30000,
      }, 'terminal');

      setState(() {
        if (result.success) {
          _lines.add(_TerminalLine(
            text: result.output,
            type: LineType.output,
          ));
        } else {
          _lines.add(_TerminalLine(
            text: result.error ?? 'Command failed',
            type: LineType.error,
          ));
        }
      });
    } catch (e) {
      setState(() {
        _lines.add(_TerminalLine(
          text: 'Error: $e',
          type: LineType.error,
        ));
      });
    }

    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 100),
          curve: Curves.easeOut,
        );
      }
    });
  }
}

enum LineType { system, command, output, error }

class _TerminalLine {
  final String text;
  final LineType type;

  _TerminalLine({required this.text, required this.type});
}

class _TerminalLineWidget extends StatelessWidget {
  final _TerminalLine line;
  const _TerminalLineWidget({required this.line});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (line.type) {
      case LineType.system:
        color = Colors.blue;
        break;
      case LineType.command:
        color = Colors.green;
        break;
      case LineType.output:
        color = Colors.white70;
        break;
      case LineType.error:
        color = Colors.red;
        break;
    }

    return SelectableText(
      line.text,
      style: TextStyle(
        fontFamily: 'monospace',
        fontSize: 12,
        color: color,
      ),
    );
  }
}
