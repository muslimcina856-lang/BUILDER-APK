import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../../core/config/app_config.dart';
import '../../core/config/config_models.dart';
import '../../core/tts/tts_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final config = context.watch<AppConfigManager>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: const Color(0xFF1A1A2E),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // API Keys Section
          _SectionHeader(title: 'API Keys'),
          _ApiKeyManagerWidget(
            config: config,
            onUpdate: () => setState(() {}),
          ),

          const SizedBox(height: 24),

          // Base URL
          _SectionHeader(title: 'API Endpoint'),
          _BaseUrlWidget(config: config, onUpdate: () => setState(() {})),

          const SizedBox(height: 24),

          // Model Selection
          _SectionHeader(title: 'Model'),
          _ModelSelector(config: config),

          const SizedBox(height: 24),

          // TTS Settings
          _SectionHeader(title: 'Text-to-Speech'),
          _TtsSettings(config: config),

          const SizedBox(height: 24),

          // Agent Settings
          _SectionHeader(title: 'Agent'),
          _AgentSettings(config: config),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title,
          style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6366F1))),
    );
  }
}

// ============ API Key Manager Widget ============

class _ApiKeyManagerWidget extends StatelessWidget {
  final AppConfigManager config;
  final VoidCallback onUpdate;

  const _ApiKeyManagerWidget({required this.config, required this.onUpdate});

  @override
  Widget build(BuildContext context) {
    final keys = config.keyManager.enabledKeys;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${keys.length} key(s) configured',
                    style: const TextStyle(color: Colors.grey)),
                FilledButton.icon(
                  onPressed: () => _showAddKeyDialog(context),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Add Key'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF6366F1),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (keys.isEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F0F23),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.withOpacity(0.3)),
                ),
                child: const Center(
                  child: Text('No API keys added yet',
                      style: TextStyle(color: Colors.grey)),
                ),
              ),

            // List of keys
            ...keys.asMap().entries.map((entry) {
              final k = entry.value;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F0F23),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: k.failCount > 0
                        ? Colors.orange.withOpacity(0.5)
                        : Colors.green.withOpacity(0.3),
                  ),
                ),
                child: ListTile(
                  dense: true,
                  leading: Icon(
                    k.failCount > 0 ? Icons.warning : Icons.vpn_key,
                    color: k.failCount > 0 ? Colors.orange : Colors.green,
                    size: 20,
                  ),
                  title: Text(k.name,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${k.key.substring(0, k.key.length > 16 ? 16 : k.key.length)}...',
                        style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 11,
                            color: Colors.grey),
                      ),
                      Row(
                        children: [
                          Text('Priority: ${k.priority}',
                              style: const TextStyle(fontSize: 10)),
                          const SizedBox(width: 12),
                          if (k.failCount > 0)
                            Text('Fails: ${k.failCount}',
                                style: const TextStyle(
                                    fontSize: 10, color: Colors.orange)),
                        ],
                      ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, size: 18),
                        onPressed: () => _showEditKeyDialog(context, k),
                        tooltip: 'Edit',
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, size: 18,
                            color: Colors.red),
                        onPressed: () => _deleteKey(context, k),
                        tooltip: 'Delete',
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showAddKeyDialog(BuildContext context) {
    final keyController = TextEditingController();
    final nameController = TextEditingController();
    int priority = config.keyManager.enabledKeys.length + 1;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A2E),
          title: const Text('Add API Key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Key Name',
                  hintText: 'e.g. Primary, Backup 1',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: keyController,
                decoration: InputDecoration(
                  labelText: 'API Key',
                  hintText: 'sk-xxxxxx',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                obscureText: true,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('Priority: '),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: priority > 1
                        ? () => setDialogState(() => priority--)
                        : null,
                  ),
                  Text('$priority',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () => setDialogState(() => priority++),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (keyController.text.isNotEmpty &&
                    nameController.text.isNotEmpty) {
                  config.keyManager.addKey(ApiKeyConfig(
                    key: keyController.text,
                    name: nameController.text,
                    priority: priority,
                  ));
                  _saveKeys(config);
                  Navigator.pop(ctx);
                  onUpdate();
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditKeyDialog(BuildContext context, ApiKeyConfig key) {
    final keyController = TextEditingController(text: key.key);
    final nameController = TextEditingController(text: key.name);
    int priority = key.priority;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A2E),
          title: const Text('Edit API Key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Key Name',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: keyController,
                decoration: InputDecoration(
                  labelText: 'API Key',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                obscureText: true,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('Priority: '),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: priority > 1
                        ? () => setDialogState(() => priority--)
                        : null,
                  ),
                  Text('$priority',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () => setDialogState(() => priority++),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                // Remove old, add updated
                config.keyManager.removeKey(key.name);
                config.keyManager.addKey(ApiKeyConfig(
                  key: keyController.text,
                  name: nameController.text,
                  priority: priority,
                ));
                _saveKeys(config);
                Navigator.pop(ctx);
                onUpdate();
              },
              child: const Text('Update'),
            ),
          ],
        ),
      ),
    );
  }

  void _deleteKey(BuildContext context, ApiKeyConfig key) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Text('Delete Key?'),
        content: Text('Remove "${key.name}" from saved keys?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              config.keyManager.removeKey(key.name);
              _saveKeys(config);
              Navigator.pop(ctx);
              onUpdate();
            },
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveKeys(AppConfigManager config) async {
    final prefs = await SharedPreferences.getInstance();
    final keys = config.keyManager.enabledKeys
        .map((k) => {'key': k.key, 'name': k.name, 'priority': k.priority})
        .toList();
    await prefs.setString('api_keys', jsonEncode(keys));
  }
}

// ============ Provider Selector Widget ============

class _BaseUrlWidget extends StatefulWidget {
  final AppConfigManager config;
  final VoidCallback onUpdate;

  const _BaseUrlWidget({required this.config, required this.onUpdate});

  @override
  State<_BaseUrlWidget> createState() => _BaseUrlWidgetState();
}

class _BaseUrlWidgetState extends State<_BaseUrlWidget> {
  static const String _mimoUrl = 'https://api.xiaomimimo.com/v1';
  bool _isCustom = false;
  final _urlController = TextEditingController();
  final _modelController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _isCustom = widget.config.config.baseUrl != _mimoUrl;
    _urlController.text = widget.config.config.baseUrl;
    _modelController.text = widget.config.config.models.defaultModel;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Provider toggle
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _setProvider(false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: !_isCustom
                            ? const Color(0xFF6366F1)
                            : const Color(0xFF0F0F23),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: !_isCustom
                              ? const Color(0xFF6366F1)
                              : Colors.grey.withOpacity(0.3),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'Mimo',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: !_isCustom ? Colors.white : Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _setProvider(true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: _isCustom
                            ? const Color(0xFF6366F1)
                            : const Color(0xFF0F0F23),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _isCustom
                              ? const Color(0xFF6366F1)
                              : Colors.grey.withOpacity(0.3),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          'Custom Provider',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _isCustom ? Colors.white : Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Mimo info (locked)
            if (!_isCustom)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F0F23),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.lock, size: 14, color: Colors.grey),
                        SizedBox(width: 4),
                        Text('Endpoint (locked)',
                            style:
                                TextStyle(color: Colors.grey, fontSize: 11)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(_mimoUrl,
                        style: const TextStyle(
                            fontFamily: 'monospace', fontSize: 13)),
                    const SizedBox(height: 8),
                    const Row(
                      children: [
                        Icon(Icons.lock, size: 14, color: Colors.grey),
                        SizedBox(width: 4),
                        Text('Models (locked)',
                            style:
                                TextStyle(color: Colors.grey, fontSize: 11)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        'mimo-v2.5',
                        'mimo-v2.5-pro',
                        'mimo-v2.5-asr',
                        'mimo-v2.5-tts',
                        'mimo-v2.5-tts-voiceclone',
                        'mimo-v2.5-tts-voicedesign',
                      ]
                          .map((m) => Chip(
                                label: Text(m,
                                    style: const TextStyle(fontSize: 10)),
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ))
                          .toList(),
                    ),
                  ],
                ),
              ),

            // Custom provider fields
            if (_isCustom) ...[
              TextField(
                controller: _urlController,
                decoration: InputDecoration(
                  labelText: 'Base URL',
                  hintText: 'https://api.example.com/v1',
                  prefixIcon: const Icon(Icons.link),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                onChanged: (_) => _saveCustom(),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _modelController,
                decoration: InputDecoration(
                  labelText: 'Model Name',
                  hintText: 'e.g. gpt-4, claude-3, deepseek-v3',
                  prefixIcon: const Icon(Icons.smart_toy),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                onChanged: (_) => _saveCustom(),
              ),
              const SizedBox(height: 8),
              const Text(
                'Must be OpenAI-compatible API format',
                style: TextStyle(color: Colors.grey, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _setProvider(bool custom) async {
    setState(() => _isCustom = custom);
    final prefs = await SharedPreferences.getInstance();
    if (!custom) {
      await prefs.setString('base_url', _mimoUrl);
      await prefs.remove('custom_model');
    } else {
      _saveCustom();
    }
    widget.onUpdate();
  }

  void _saveCustom() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('base_url', _urlController.text);
    await prefs.setString('custom_model', _modelController.text);
    widget.onUpdate();
  }
}

// ============ Model Selector ============

class _ModelSelector extends StatelessWidget {
  final AppConfigManager config;
  const _ModelSelector({required this.config});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Default Model',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 4),
            Text(config.config.models.defaultModel,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Available Models',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            Wrap(
              spacing: 8,
              children: config.config.models.available
                  .map((m) => Chip(label: Text(m)))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

// ============ TTS Settings ============

class _TtsSettings extends StatelessWidget {
  final AppConfigManager config;
  const _TtsSettings({required this.config});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Default Voice',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 4),
            Text(config.config.tts.defaultVoice,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Available Voices',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            Wrap(
              spacing: 8,
              children: TtsService.voiceList
                  .map((v) => Chip(
                        label: Text('${v.name} (${v.language})'),
                        backgroundColor: v.id == config.config.tts.defaultVoice
                            ? const Color(0xFF6366F1)
                            : null,
                      ))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

// ============ Agent Settings ============

class _AgentSettings extends StatelessWidget {
  final AppConfigManager config;
  const _AgentSettings({required this.config});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Max Iterations: ${config.config.agent.maxIterations}',
                style: const TextStyle(fontSize: 13)),
            Text('Timeout: ${config.config.agent.timeoutSeconds}s',
                style: const TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            const Text('System Prompt',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            Text(config.config.agent.systemPrompt,
                style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
