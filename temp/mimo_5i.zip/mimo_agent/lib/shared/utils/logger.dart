import 'dart:io';

/// Simple logger for the app
class Logger {
  static final Logger _instance = Logger._();
  factory Logger() => _instance;
  Logger._();

  final List<LogEntry> _entries = [];
  final String _logPath = '/tmp/mimo_agent.log';

  List<LogEntry> get entries => List.unmodifiable(_entries);

  void info(String message) => _log(LogLevel.info, message);
  void warn(String message) => _log(LogLevel.warn, message);
  void error(String message) => _log(LogLevel.error, message);
  void debug(String message) => _log(LogLevel.debug, message);

  void _log(LogLevel level, String message) {
    final entry = LogEntry(
      level: level,
      message: message,
      timestamp: DateTime.now(),
    );
    _entries.add(entry);

    // Write to file
    final line =
        '[${entry.timestamp.toIso8601String()}] ${level.name.toUpperCase()}: $message\n';
    File(_logPath).writeAsStringSync(line, mode: FileMode.append);
  }

  void clear() {
    _entries.clear();
  }
}

enum LogLevel { debug, info, warn, error }

class LogEntry {
  final LogLevel level;
  final String message;
  final DateTime timestamp;

  LogEntry({
    required this.level,
    required this.message,
    required this.timestamp,
  });
}
