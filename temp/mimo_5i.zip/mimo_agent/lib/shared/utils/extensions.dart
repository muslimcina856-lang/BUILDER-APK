/// Extension methods for common operations

extension StringExtensions on String {
  /// Truncate string to max length
  String truncate(int maxLength, {String suffix = '...'}) {
    if (length <= maxLength) return this;
    return '${substring(0, maxLength - suffix.length)}$suffix';
  }

  /// Check if string is a valid URL
  bool get isUrl {
    return startsWith('http://') || startsWith('https://');
  }

  /// Extract first N words
  String firstWords(int count) {
    final words = split(' ');
    if (words.length <= count) return this;
    return '${words.take(count).join(' ')}...';
  }
}

extension ListExtensions<T> on List<T> {
  /// Safe element access
  T? get(int index) {
    if (index < 0 || index >= length) return null;
    return this[index];
  }

  /// Chunk list into groups
  List<List<T>> chunk(int size) {
    final chunks = <List<T>>[];
    for (var i = 0; i < length; i += size) {
      chunks.add(sublist(i, i + size > length ? length : i + size));
    }
    return chunks;
  }
}

extension MapExtensions<K, V> on Map<K, V> {
  /// Get value or default
  V getOrDefault(K key, V defaultValue) {
    return containsKey(key) ? this[key]! : defaultValue;
  }
}
