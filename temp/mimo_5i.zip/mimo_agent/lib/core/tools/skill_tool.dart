import 'dart:io';
import 'tool_models.dart';

/// SkillTool - Invoke skills
class SkillTool extends BaseTool {
  @override
  String get name => 'Skill';

  @override
  String get description =>
      'Invoke a skill. Skills are packaged instructions for specific tasks. '
      'Available skills appear in the skills directory.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'skill': {
            'type': 'string',
            'description': 'Name of the skill to invoke',
          },
          'args': {
            'type': 'string',
            'description': 'Optional arguments for the skill',
          },
        },
        'required': ['skill'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final skillName = args['skill'] as String;
    final skillArgs = args['args'] as String?;

    try {
      // Look for skill file
      final skillPaths = [
        'assets/skills/$skillName/SKILL.md',
        '/root/.mimo-agent/skills/$skillName/SKILL.md',
        'skills/$skillName/SKILL.md',
      ];

      String? skillContent;
      for (final path in skillPaths) {
        final file = File(path);
        if (await file.exists()) {
          skillContent = await file.readAsString();
          break;
        }
      }

      if (skillContent == null) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Skill not found: $skillName',
        );
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Skill "$skillName" loaded:\n\n$skillContent'
            '${skillArgs != null ? '\n\nArguments: $skillArgs' : ''}',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Skill error: $e',
      );
    }
  }
}
