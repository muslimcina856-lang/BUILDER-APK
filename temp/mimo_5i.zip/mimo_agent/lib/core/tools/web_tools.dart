import 'dart:convert';
import 'package:http/http.dart' as http;
import 'tool_models.dart';

/// WebFetchTool - Fetch URL content
class WebFetchTool extends BaseTool {
  @override
  String get name => 'WebFetch';

  @override
  String get description =>
      'Fetches a URL, converts the page to markdown, and answers a prompt against it. '
      'HTTP is upgraded to HTTPS. Responses are cached.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'url': {
            'type': 'string',
            'description': 'The URL to fetch content from',
          },
          'prompt': {
            'type': 'string',
            'description': 'The prompt to run on the fetched content',
          },
        },
        'required': ['url', 'prompt'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final url = args['url'] as String;
    final prompt = args['prompt'] as String;

    try {
      final uri = Uri.parse(url.startsWith('http') ? url : 'https://$url');
      final response = await http.get(uri).timeout(
            const Duration(seconds: 30),
          );

      if (response.statusCode != 200) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'HTTP ${response.statusCode}',
        );
      }

      // Basic HTML to text conversion
      var body = response.body;
      body = _stripHtml(body);

      // Truncate if too long
      if (body.length > 50000) {
        body = '${body.substring(0, 50000)}\n... (truncated)';
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Content from $url:\n\n$body\n\nPrompt: $prompt',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Fetch error: $e',
      );
    }
  }

  String _stripHtml(String html) {
    // Remove scripts and styles
    html = html.replaceAll(
        RegExp(r'<script[^>]*>[\s\S]*?</script>', caseSensitive: false), '');
    html = html.replaceAll(
        RegExp(r'<style[^>]*>[\s\S]*?</style>', caseSensitive: false), '');
    // Remove HTML tags
    html = html.replaceAll(RegExp(r'<[^>]+>'), ' ');
    // Decode entities
    html = html
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ');
    // Collapse whitespace
    html = html.replaceAll(RegExp(r'\s+'), ' ').trim();
    return html;
  }
}

/// WebSearchTool - Search the web
class WebSearchTool extends BaseTool {
  @override
  String get name => 'WebSearch';

  @override
  String get description =>
      'Search the web. Returns result blocks with titles and URLs. '
      'Useful for finding current information.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'query': {
            'type': 'string',
            'description': 'The search query',
          },
          'allowed_domains': {
            'type': 'array',
            'items': {'type': 'string'},
            'description': 'Only include results from these domains',
          },
          'blocked_domains': {
            'type': 'array',
            'items': {'type': 'string'},
            'description': 'Never include results from these domains',
          },
        },
        'required': ['query'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final query = args['query'] as String;

    try {
      // Use DuckDuckGo HTML search (no API key needed)
      final uri = Uri.parse(
          'https://html.duckduckgo.com/html/?q=${Uri.encodeComponent(query)}');
      final response = await http.get(uri, headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; MimoAgent/1.0)',
      }).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Search failed: HTTP ${response.statusCode}',
        );
      }

      // Parse results
      final results = _parseSearchResults(response.body);

      if (results.isEmpty) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: 'No results found for: $query',
        );
      }

      final buffer = StringBuffer('Search results for: $query\n\n');
      for (int i = 0; i < results.length && i < 10; i++) {
        buffer.writeln('${i + 1}. ${results[i]['title']}');
        buffer.writeln('   ${results[i]['url']}');
        buffer.writeln('   ${results[i]['snippet']}\n');
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: buffer.toString(),
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Search error: $e',
      );
    }
  }

  List<Map<String, String>> _parseSearchResults(String html) {
    final results = <Map<String, String>>[];
    final resultPattern = RegExp(
        r'class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>.*?'
        r'class="result__snippet"[^>]*>(.*?)</(?:a|td|div)',
        dotAll: true);

    for (final match in resultPattern.allMatches(html)) {
      var url = match.group(1) ?? '';
      var title = match.group(2) ?? '';
      var snippet = match.group(3) ?? '';

      // Clean up
      title = title.replaceAll(RegExp(r'<[^>]+>'), '').trim();
      snippet = snippet.replaceAll(RegExp(r'<[^>]+>'), '').trim();

      if (url.contains('uddg=')) {
        final uddgMatch = RegExp(r'uddg=([^&]+)').firstMatch(url);
        if (uddgMatch != null) {
          url = Uri.decodeComponent(uddgMatch.group(1)!);
        }
      }

      if (url.isNotEmpty && title.isNotEmpty) {
        results.add({
          'title': title,
          'url': url,
          'snippet': snippet,
        });
      }
    }

    return results;
  }
}
