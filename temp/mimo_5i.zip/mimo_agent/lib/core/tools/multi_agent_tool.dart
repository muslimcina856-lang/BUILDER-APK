import 'dart:async';
import 'dart:convert';
import 'tool_models.dart';
import '../api/mimo_client.dart';
import '../api/mimo_models.dart';
import 'tool_registry.dart';

/// Multi-Agent Deploy Tool - Deploy banyak agent serentak
class MultiAgentTool extends BaseTool {
  final MimoClient client;
  final ToolRegistry registry;

  MultiAgentTool({required this.client, required this.registry});

  @override
  String get name => 'MultiAgent';

  @override
  String get description =>
      'Deploy multiple AI agents in parallel to handle complex tasks. '
      'Each agent runs independently with its own context and tools.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'agents': {
            'type': 'array',
            'items': {
              'type': 'object',
              'properties': {
                'name': {'type': 'string'},
                'task': {'type': 'string'},
                'model': {'type': 'string'},
              },
              'required': ['name', 'task'],
            },
            'description': 'List of agents to deploy',
          },
          'parallel': {
            'type': 'boolean',
            'description': 'Run agents in parallel (default: true)',
          },
        },
        'required': ['agents'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final agents = (args['agents'] as List).cast<Map<String, dynamic>>();
    final parallel = args['parallel'] as bool? ?? true;

    try {
      final results = <String, String>{};

      if (parallel) {
        // Run all agents in parallel
        final futures = agents.map((agent) async {
          final name = agent['name'] as String;
          final task = agent['task'] as String;
          final model = agent['model'] as String? ?? 'mimo-v2.5-pro';
          final result = await _runAgent(task, model);
          return MapEntry(name, result);
        });

        final completed = await Future.wait(futures);
        for (final entry in completed) {
          results[entry.key] = entry.value;
        }
      } else {
        // Run agents sequentially
        for (final agent in agents) {
          final name = agent['name'] as String;
          final task = agent['task'] as String;
          final model = agent['model'] as String? ?? 'mimo-v2.5-pro';
          results[name] = await _runAgent(task, model);
        }
      }

      final buffer = StringBuffer('Multi-Agent Results:\n\n');
      results.forEach((name, result) {
        buffer.writeln('=== $name ===');
        buffer.writeln(result);
        buffer.writeln();
      });

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: buffer.toString(),
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'MultiAgent error: $e',
      );
    }
  }

  Future<String> _runAgent(String task, String model) async {
    final messages = [
      MimoMessage(
        role: 'system',
        content: 'You are a helpful assistant. Complete the task and return the result.',
      ),
      MimoMessage(role: 'user', content: task),
    ];

    final tools = registry.getToolDefinitions()
        .map((t) => ToolDefinition.fromJson(t))
        .toList();

    int iterations = 0;
    String finalContent = '';

    while (iterations < 5) {
      iterations++;

      final response = await client.chatWithTools(
        messages: messages,
        tools: tools,
        model: model,
        maxTokens: 4096,
      );

      if (response.choices.isEmpty) break;

      final choice = response.choices.first;
      messages.add(choice.message);

      if (choice.message.toolCalls != null &&
          choice.message.toolCalls!.isNotEmpty) {
        for (final tc in choice.message.toolCalls!) {
          Map<String, dynamic> toolArgs;
          try {
            toolArgs = jsonDecode(tc.function.arguments);
          } catch (_) {
            toolArgs = {};
          }

          final result = await registry.executeTool(
            tc.function.name,
            toolArgs,
            tc.id,
          );

          messages.add(MimoMessage(
            role: 'tool',
            content: result.success ? result.output : 'Error: ${result.error}',
            toolCallId: tc.id,
          ));
        }
        continue;
      }

      finalContent = choice.message.content ?? '';
      break;
    }

    return finalContent;
  }
}

/// Skill Setup Tool - Setup skills untuk agent
class SkillSetupTool extends BaseTool {
  @override
  String get name => 'SkillSetup';

  @override
  String get description =>
      'Create or update a skill. Skills are reusable instructions that AI can invoke.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'skill_name': {
            'type': 'string',
            'description': 'Name of the skill',
          },
          'description': {
            'type': 'string',
            'description': 'When should this skill be used',
          },
          'content': {
            'type': 'string',
            'description': 'Full skill content (markdown)',
          },
          'directory': {
            'type': 'string',
            'description': 'Directory to save skill (default: ~/.mimo-agent/skills/)',
          },
        },
        'required': ['skill_name', 'description', 'content'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final skillName = args['skill_name'] as String;
    final description = args['description'] as String;
    final content = args['content'] as String;
    final directory =
        args['directory'] as String? ?? '/root/.mimo-agent/skills/';

    try {
      final skillDir = '$directory$skillName';
      await Directory(skillDir).create(recursive: true);

      final frontmatter = '''---
name: $skillName
description: $description
version: 1.0.0
---

$content''';

      final file = File('$skillDir/SKILL.md');
      await file.writeAsString(frontmatter);

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Skill created: $skillDir/SKILL.md',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'SkillSetup error: $e',
      );
    }
  }
}
