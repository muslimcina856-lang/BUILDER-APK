import 'dart:convert';
import 'tool_models.dart';

/// In-memory task store
class TaskStore {
  static final TaskStore _instance = TaskStore._();
  factory TaskStore() => _instance;
  TaskStore._();

  final Map<String, TaskItem> _tasks = {};

  Map<String, TaskItem> get tasks => _tasks;
}

class TaskItem {
  final String id;
  String subject;
  String description;
  String status; // pending, in_progress, completed, deleted
  String? owner;
  String? activeForm;
  final List<String> blocks;
  final List<String> blockedBy;
  final DateTime createdAt;
  DateTime updatedAt;

  TaskItem({
    required this.id,
    required this.subject,
    required this.description,
    this.status = 'pending',
    this.owner,
    this.activeForm,
    this.blocks = const [],
    this.blockedBy = const [],
  })  : createdAt = DateTime.now(),
        updatedAt = DateTime.now();
}

/// TaskCreate - Create a new task
class TaskCreateTool extends BaseTool {
  @override
  String get name => 'TaskCreate';

  @override
  String get description =>
      'Create a structured task for tracking progress. '
      'Use for complex multi-step tasks.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'subject': {'type': 'string', 'description': 'Task title'},
          'description': {'type': 'string', 'description': 'What needs to be done'},
          'active_form': {'type': 'string', 'description': 'Present continuous form for spinner'},
        },
        'required': ['subject', 'description'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final task = TaskItem(
      id: id,
      subject: args['subject'] as String,
      description: args['description'] as String,
      activeForm: args['active_form'] as String?,
    );
    TaskStore()._tasks[id] = task;

    return ToolResult(
      toolName: name,
      toolCallId: toolCallId,
      success: true,
      output: 'Task created: [$id] ${task.subject}',
    );
  }
}

/// TaskGet - Get task details
class TaskGetTool extends BaseTool {
  @override
  String get name => 'TaskGet';

  @override
  String get description => 'Retrieve a task by its ID';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'task_id': {'type': 'string', 'description': 'Task ID'},
        },
        'required': ['task_id'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final task = TaskStore()._tasks[args['task_id']];
    if (task == null) {
      return ToolResult(
        toolName: name, toolCallId: toolCallId,
        success: false, output: '', error: 'Task not found',
      );
    }

    return ToolResult(
      toolName: name, toolCallId: toolCallId, success: true,
      output: 'Subject: ${task.subject}\nStatus: ${task.status}\nDescription: ${task.description}',
    );
  }
}

/// TaskList - List all tasks
class TaskListTool extends BaseTool {
  @override
  String get name => 'TaskList';

  @override
  String get description => 'List all tasks with their status';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {},
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final tasks = TaskStore()._tasks;
    if (tasks.isEmpty) {
      return ToolResult(toolName: name, toolCallId: toolCallId, success: true, output: 'No tasks');
    }

    final buffer = StringBuffer();
    for (final task in tasks.values) {
      buffer.writeln('[${task.id}] ${task.status}: ${task.subject}');
    }

    return ToolResult(toolName: name, toolCallId: toolCallId, success: true, output: buffer.toString());
  }
}

/// TaskUpdate - Update a task
class TaskUpdateTool extends BaseTool {
  @override
  String get name => 'TaskUpdate';

  @override
  String get description => 'Update task status or details';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'task_id': {'type': 'string'},
          'status': {'type': 'string', 'enum': ['pending', 'in_progress', 'completed', 'deleted']},
          'subject': {'type': 'string'},
          'description': {'type': 'string'},
        },
        'required': ['task_id'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final task = TaskStore()._tasks[args['task_id']];
    if (task == null) {
      return ToolResult(toolName: name, toolCallId: toolCallId, success: false, output: '', error: 'Not found');
    }

    if (args['status'] != null) task.status = args['status'] as String;
    if (args['subject'] != null) task.subject = args['subject'] as String;
    if (args['description'] != null) task.description = args['description'] as String;
    task.updatedAt = DateTime.now();

    return ToolResult(toolName: name, toolCallId: toolCallId, success: true, output: 'Task updated: ${task.subject}');
  }
}

/// TaskStop - Stop/delete a task
class TaskStopTool extends BaseTool {
  @override
  String get name => 'TaskStop';

  @override
  String get description => 'Stop a running background task';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'task_id': {'type': 'string'},
        },
        'required': ['task_id'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final store = TaskStore();
    final removed = store._tasks.remove(args['task_id']);
    return ToolResult(
      toolName: name, toolCallId: toolCallId,
      success: removed != null,
      output: removed != null ? 'Task stopped' : 'Task not found',
    );
  }
}

/// TaskOutput - Get task output
class TaskOutputTool extends BaseTool {
  @override
  String get name => 'TaskOutput';

  @override
  String get description => 'Get output from a completed task';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'task_id': {'type': 'string'},
          'block': {'type': 'boolean'},
        },
        'required': ['task_id'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final task = TaskStore()._tasks[args['task_id']];
    if (task == null) {
      return ToolResult(toolName: name, toolCallId: toolCallId, success: false, output: '', error: 'Not found');
    }

    return ToolResult(
      toolName: name, toolCallId: toolCallId, success: true,
      output: 'Task ${task.id}: ${task.status}\n${task.description}',
    );
  }
}
