import 'tool_models.dart';
import 'file_tools.dart';
import 'bash_tool.dart';
import 'web_tools.dart';
import 'task_tools.dart';
import 'cron_tools.dart';
import 'agent_tool.dart';
import 'monitor_tool.dart';
import 'skill_tool.dart';
import 'tts_tools.dart';
import 'file_transfer_tools.dart';
import 'multi_agent_tool.dart';
import '../api/mimo_client.dart';

/// Registry for all available tools
class ToolRegistry {
  final Map<String, BaseTool> _tools = {};
  static ToolRegistry? _instance;

  ToolRegistry._();

  static ToolRegistry get instance {
    _instance ??= ToolRegistry._();
    return _instance!;
  }

  /// Initialize with API client (call once after MimoClient is created)
  void init(MimoClient client) {
    if (_tools.isNotEmpty) return; // Already initialized

    // Claude Code tools (20 tools)
    register(ReadTool());
    register(WriteTool());
    register(EditTool());
    register(GlobTool());
    register(GrepTool());
    register(BashTool());
    register(AgentTool());
    register(WebFetchTool());
    register(WebSearchTool());
    register(TaskCreateTool());
    register(TaskGetTool());
    register(TaskListTool());
    register(TaskUpdateTool());
    register(TaskStopTool());
    register(TaskOutputTool());
    register(CronCreateTool());
    register(CronDeleteTool());
    register(CronListTool());
    register(MonitorTool());
    register(SkillTool());

    // Mimo-specific tools (5 tools)
    register(TtsTool(client: client));
    register(AsrTool(client: client));
    register(VoiceCloneTool(client: client));

    // File transfer tools (3 tools)
    register(FileReadTool());
    register(ZipExtractTool());
    register(ZipCreateTool());

    // Multi-agent & skill setup (2 tools)
    register(MultiAgentTool(client: client, registry: this));
    register(SkillSetupTool());
  }

  /// Register a tool
  void register(BaseTool tool) {
    _tools[tool.name] = tool;
  }

  /// Get a tool by name
  BaseTool? getTool(String name) => _tools[name];

  /// Get all registered tools
  List<BaseTool> get allTools => _tools.values.toList();

  /// Get all tool definitions for API
  List<Map<String, dynamic>> getToolDefinitions() {
    return _tools.values.map((t) => t.definition.toOpenAITool()).toList();
  }

  /// Execute a tool call
  Future<ToolResult> executeTool(
      String name, Map<String, dynamic> args, String toolCallId) async {
    final tool = _tools[name];
    if (tool == null) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Tool not found: $name',
      );
    }

    try {
      return await tool.execute(args, toolCallId);
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Tool execution error: $e',
      );
    }
  }

  /// Get tool names list
  List<String> get toolNames => _tools.keys.toList();
}
