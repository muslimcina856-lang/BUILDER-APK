import 'dart:convert';
import 'tool_models.dart';
import '../api/mimo_client.dart';
import '../api/mimo_models.dart';
import 'tool_registry.dart';

/// AgentTool - Spawn a sub-agent to handle complex tasks
class AgentTool extends BaseTool {
  @override
  String get name => 'Agent';

  @override
  String get description =>
      'Launch a new agent to handle complex, multi-step tasks. '
      'The agent runs independently with its own tool execution loop.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'prompt': {
            'type': 'string',
            'description': 'The task for the agent to perform',
          },
          'model': {
            'type': 'string',
            'description': 'Model override (e.g., "mimo-v2.5-pro")',
          },
          'max_iterations': {
            'type': 'integer',
            'description': 'Max tool execution iterations',
          },
        },
        'required': ['prompt'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final prompt = args['prompt'] as String;
    final model = args['model'] as String? ?? 'mimo-v2.5-pro';
    final maxIterations = args['max_iterations'] as int? ?? 5;

    // This is a simplified agent loop
    // In production, this would use the full MimoClient
    try {
      final messages = <Map<String, dynamic>>[
        {
          'role': 'system',
          'content': 'You are a helpful assistant. Complete the task and return the result as plain text.'
        },
        {'role': 'user', 'content': prompt},
      ];

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Agent task queued: $prompt\nModel: $model\nMax iterations: $maxIterations',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Agent error: $e',
      );
    }
  }
}
