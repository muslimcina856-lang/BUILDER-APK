import 'dart:io';
import 'dart:async';
import 'tool_models.dart';

/// BashTool - Execute shell commands
/// Matches Claude Code's Bash tool with timeout, background execution
class BashTool extends BaseTool {
  String _workingDirectory = '/';

  String get workingDirectory => _workingDirectory;

  @override
  String get name => 'Bash';

  @override
  String get description =>
      'Executes a bash command and returns its output. '
      'Supports timeout, background execution, and working directory tracking. '
      'Use for file operations, git, build commands, and system tasks.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'command': {
            'type': 'string',
            'description': 'The bash command to execute',
          },
          'timeout': {
            'type': 'integer',
            'description': 'Timeout in milliseconds (default: 120000)',
          },
          'run_in_background': {
            'type': 'boolean',
            'description': 'Run command in background',
          },
          'description': {
            'type': 'string',
            'description': 'Description of what the command does',
          },
        },
        'required': ['command'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final command = args['command'] as String;
    final timeout = args['timeout'] as int? ?? 120000;
    final runInBackground = args['run_in_background'] as bool? ?? false;

    try {
      // Handle cd commands to track working directory
      if (command.trimLeft().startsWith('cd ')) {
        final dir = command.trimLeft().substring(3).trim();
        final targetDir = dir.startsWith('/')
            ? dir
            : '$_workingDirectory/$dir';
        final resolved = Directory(targetDir).resolveSymbolicLinksSync();
        if (await Directory(resolved).exists()) {
          _workingDirectory = resolved;
          return ToolResult(
            toolName: name,
            toolCallId: toolCallId,
            success: true,
            output: 'Changed directory to: $_workingDirectory',
          );
        }
      }

      if (runInBackground) {
        // Run in background
        final process = await Process.start(
          'bash',
          ['-c', 'cd $_workingDirectory && $command'],
          mode: ProcessStartMode.detached,
        );
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: 'Background process started (PID: ${process.pid})',
        );
      }

      // Run with timeout
      final process = await Process.start(
        'bash',
        ['-c', 'cd $_workingDirectory && $command'],
      ).timeout(Duration(milliseconds: timeout));

      final stdoutBuffer = StringBuffer();
      final stderrBuffer = StringBuffer();

      process.stdout.transform(const SystemEncoding().decoder).listen(
            (data) => stdoutBuffer.write(data),
          );
      process.stderr.transform(const SystemEncoding().decoder).listen(
            (data) => stderrBuffer.write(data),
          );

      final exitCode =
          await process.exitCode.timeout(Duration(milliseconds: timeout));

      final stdout = stdoutBuffer.toString();
      final stderr = stderrBuffer.toString();

      if (exitCode == 0) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: stdout.isEmpty ? '(no output)' : stdout,
        );
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: stdout,
          error: 'Exit code $exitCode: $stderr',
        );
      }
    } on TimeoutException {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Command timed out after ${timeout}ms',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Bash error: $e',
      );
    }
  }
}
