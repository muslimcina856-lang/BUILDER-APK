/// Tool definition and result models

class ToolDef {
  final String name;
  final String description;
  final Map<String, dynamic> parameters;
  final List<String> requiredPermissions;

  ToolDef({
    required this.name,
    required this.description,
    required this.parameters,
    this.requiredPermissions = const [],
  });

  /// Convert to OpenAI tool format
  Map<String, dynamic> toOpenAITool() => {
        'type': 'function',
        'function': {
          'name': name,
          'description': description,
          'parameters': parameters,
        },
      };
}

class ToolResult {
  final String toolName;
  final String toolCallId;
  final bool success;
  final String output;
  final String? error;
  final Map<String, dynamic>? metadata;

  ToolResult({
    required this.toolName,
    required this.toolCallId,
    required this.success,
    required this.output,
    this.error,
    this.metadata,
  });

  /// Convert to tool message for API
  Map<String, dynamic> toToolMessage() => {
        'role': 'tool',
        'tool_call_id': toolCallId,
        'content': output,
      };
}

/// Base class for all tools
abstract class BaseTool {
  String get name;
  String get description;
  Map<String, dynamic> get parameters;

  /// Execute the tool with given arguments
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId);

  /// Get tool definition
  ToolDef get definition => ToolDef(
        name: name,
        description: description,
        parameters: parameters,
      );
}
