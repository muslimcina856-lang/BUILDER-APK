import 'dart:convert';
import 'dart:io';
import 'tool_models.dart';
import '../tts/tts_service.dart';
import '../api/mimo_client.dart';

/// TTS Tool - Text to Speech (AI boleh panggil)
class TtsTool extends BaseTool {
  final MimoClient client;

  TtsTool({required this.client});

  @override
  String get name => 'TTS';

  @override
  String get description =>
      'Convert text to speech audio. Returns audio file path. '
      'Available voices: mimo_default, 冰糖, 茉莉, 苏打, 白桦, Mia, Chloe, Milo, Dean';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'text': {
            'type': 'string',
            'description': 'Text to convert to speech',
          },
          'voice': {
            'type': 'string',
            'description': 'Voice name (default: Mia)',
            'enum': [
              'mimo_default',
              '冰糖',
              '茉莉',
              '苏打',
              '白桦',
              'Mia',
              'Chloe',
              'Milo',
              'Dean'
            ],
          },
          'format': {
            'type': 'string',
            'description': 'Audio format',
            'enum': ['mp3', 'wav'],
          },
        },
        'required': ['text'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final text = args['text'] as String;
    final voice = args['voice'] as String? ?? 'Mia';
    final format = args['format'] as String? ?? 'mp3';

    try {
      final tts = TtsService(client: client, config: TtsConfig());
      final result = await tts.speak(text: text, voice: voice, format: format);

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Audio saved: ${result.filePath}\n'
            'Voice: $voice\n'
            'Size: ${result.audioBytes.length} bytes\n'
            '${result.transcript != null ? "Transcript: ${result.transcript}" : ""}',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'TTS error: $e',
      );
    }
  }
}

/// ASR Tool - Speech Recognition (AI boleh panggil)
class AsrTool extends BaseTool {
  final MimoClient client;

  AsrTool({required this.client});

  @override
  String get name => 'ASR';

  @override
  String get description =>
      'Transcribe audio/speech to text. Accepts audio file path or base64 audio data.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'audio_path': {
            'type': 'string',
            'description': 'Path to audio file',
          },
          'audio_base64': {
            'type': 'string',
            'description': 'Base64 encoded audio data',
          },
          'format': {
            'type': 'string',
            'description': 'Audio format',
            'enum': ['wav', 'mp3', 'm4a', 'ogg'],
          },
        },
        'required': [],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final audioPath = args['audio_path'] as String?;
    final audioBase64 = args['audio_base64'] as String?;
    final format = args['format'] as String? ?? 'wav';

    try {
      String base64Data;

      if (audioBase64 != null) {
        base64Data = audioBase64;
      } else if (audioPath != null) {
        final file = File(audioPath);
        if (!await file.exists()) {
          return ToolResult(
            toolName: name,
            toolCallId: toolCallId,
            success: false,
            output: '',
            error: 'Audio file not found: $audioPath',
          );
        }
        final bytes = await file.readAsBytes();
        base64Data = base64Encode(bytes);
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Provide audio_path or audio_base64',
        );
      }

      final transcript = await client.asr(
        audioBase64: base64Data,
        format: format,
      );

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Transcription:\n$transcript',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'ASR error: $e',
      );
    }
  }
}

/// Voice Clone Tool (AI boleh panggil)
class VoiceCloneTool extends BaseTool {
  final MimoClient client;

  VoiceCloneTool({required this.client});

  @override
  String get name => 'VoiceClone';

  @override
  String get description =>
      'Clone a voice and generate speech. Requires a reference audio file as voice sample.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'text': {
            'type': 'string',
            'description': 'Text to speak with cloned voice',
          },
          'reference_audio_path': {
            'type': 'string',
            'description': 'Path to reference audio file for voice cloning',
          },
          'reference_audio_base64': {
            'type': 'string',
            'description': 'Base64 encoded reference audio',
          },
          'format': {
            'type': 'string',
            'enum': ['mp3', 'wav'],
          },
        },
        'required': ['text'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final text = args['text'] as String;
    final refPath = args['reference_audio_path'] as String?;
    final refBase64 = args['reference_audio_base64'] as String?;
    final format = args['format'] as String? ?? 'mp3';

    try {
      String voiceDataUrl;

      if (refBase64 != null) {
        voiceDataUrl = 'data:audio/$format;base64,$refBase64';
      } else if (refPath != null) {
        final file = File(refPath);
        if (!await file.exists()) {
          return ToolResult(
            toolName: name,
            toolCallId: toolCallId,
            success: false,
            output: '',
            error: 'Reference audio not found: $refPath',
          );
        }
        final bytes = await file.readAsBytes();
        final b64 = base64Encode(bytes);
        voiceDataUrl = 'data:audio/$format;base64,$b64';
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Provide reference_audio_path or reference_audio_base64',
        );
      }

      final result = await client.voiceClone(
        text: text,
        voiceDataUrl: voiceDataUrl,
        format: format,
      );

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Voice cloned audio generated\n'
            'Size: ${base64Decode(result.data).length} bytes',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'VoiceClone error: $e',
      );
    }
  }
}
