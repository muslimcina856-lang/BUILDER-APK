import 'dart:io';
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:glob/glob.dart' as g;
import 'tool_models.dart';

/// ReadTool - Read files from filesystem
/// Matches Claude Code's Read tool with offset, limit, pages support
class ReadTool extends BaseTool {
  @override
  String get name => 'Read';

  @override
  String get description =>
      'Reads a file from the local filesystem. Supports offset, limit for text files '
      'and pages for PDF files. Returns file content with line numbers.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'file_path': {
            'type': 'string',
            'description': 'Absolute path to the file',
          },
          'offset': {
            'type': 'integer',
            'description': 'Line number to start reading from (0-indexed)',
          },
          'limit': {
            'type': 'integer',
            'description': 'Number of lines to read',
          },
          'pages': {
            'type': 'string',
            'description': 'Page range for PDF files (e.g., "1-5")',
          },
        },
        'required': ['file_path'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final filePath = args['file_path'] as String;
    final offset = args['offset'] as int? ?? 0;
    final limit = args['limit'] as int? ?? 2000;

    try {
      final file = File(filePath);
      if (!await file.exists()) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'File not found: $filePath',
        );
      }

      final lines = await file.readAsLines();
      final start = offset.clamp(0, lines.length);
      final end = (start + limit).clamp(0, lines.length);
      final selectedLines = lines.sublist(start, end);

      // Format with line numbers (cat -n style)
      final buffer = StringBuffer();
      for (int i = 0; i < selectedLines.length; i++) {
        final lineNum = start + i + 1;
        buffer.writeln('$lineNum\t${selectedLines[i]}');
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: buffer.toString(),
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Read error: $e',
      );
    }
  }
}

/// WriteTool - Write files to filesystem
class WriteTool extends BaseTool {
  @override
  String get name => 'Write';

  @override
  String get description =>
      'Writes a file to the local filesystem, overwriting if one exists. '
      'For creating new files or fully replacing existing ones.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'file_path': {
            'type': 'string',
            'description': 'Absolute path to the file',
          },
          'content': {
            'type': 'string',
            'description': 'Content to write',
          },
        },
        'required': ['file_path', 'content'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final filePath = args['file_path'] as String;
    final content = args['content'] as String;

    try {
      final file = File(filePath);
      await file.parent.create(recursive: true);
      await file.writeAsString(content);

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'File written: $filePath (${content.length} bytes)',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Write error: $e',
      );
    }
  }
}

/// EditTool - Edit files with string replacement
class EditTool extends BaseTool {
  @override
  String get name => 'Edit';

  @override
  String get description =>
      'Performs exact string replacement in a file. '
      'old_string must match the file exactly. Use replace_all for multiple occurrences.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'file_path': {
            'type': 'string',
            'description': 'Absolute path to the file',
          },
          'old_string': {
            'type': 'string',
            'description': 'Text to replace',
          },
          'new_string': {
            'type': 'string',
            'description': 'Replacement text',
          },
          'replace_all': {
            'type': 'boolean',
            'description': 'Replace all occurrences',
          },
        },
        'required': ['file_path', 'old_string', 'new_string'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final filePath = args['file_path'] as String;
    final oldString = args['old_string'] as String;
    final newString = args['new_string'] as String;
    final replaceAll = args['replace_all'] as bool? ?? false;

    try {
      final file = File(filePath);
      if (!await file.exists()) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'File not found: $filePath',
        );
      }

      var content = await file.readAsString();

      if (!content.contains(oldString)) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'old_string not found in file',
        );
      }

      if (replaceAll) {
        content = content.replaceAll(oldString, newString);
      } else {
        content = content.replaceFirst(oldString, newString);
      }

      await file.writeAsString(content);

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'File edited: $filePath',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Edit error: $e',
      );
    }
  }
}

/// GlobTool - Find files by pattern
class GlobTool extends BaseTool {
  @override
  String get name => 'Glob';

  @override
  String get description =>
      'Finds files by glob pattern. Returns matching file paths. '
      'Supports * and ** wildcards.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'pattern': {
            'type': 'string',
            'description': 'Glob pattern (e.g., "**/*.dart", "lib/*.json")',
          },
          'path': {
            'type': 'string',
            'description': 'Directory to search in (default: current)',
          },
        },
        'required': ['pattern'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final pattern = args['pattern'] as String;
    final searchPath = args['path'] as String? ?? '.';

    try {
      final glob = g.Glob(pattern);
      final results = <String>[];

      await for (final entity in glob.list(root: searchPath)) {
        results.add(entity.path);
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: results.isEmpty
            ? 'No files found matching: $pattern'
            : results.join('\n'),
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Glob error: $e',
      );
    }
  }
}

/// GrepTool - Search file contents
class GrepTool extends BaseTool {
  @override
  String get name => 'Grep';

  @override
  String get description =>
      'Searches for a pattern in file contents. Returns matching lines with file paths and line numbers. '
      'Supports regex patterns.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'pattern': {
            'type': 'string',
            'description': 'Search pattern (regex supported)',
          },
          'path': {
            'type': 'string',
            'description': 'File or directory to search in',
          },
          'include': {
            'type': 'string',
            'description': 'File pattern to include (e.g., "*.dart")',
          },
        },
        'required': ['pattern'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final pattern = args['pattern'] as String;
    final searchPath = args['path'] as String? ?? '.';
    final include = args['include'] as String?;

    try {
      final regex = RegExp(pattern);
      final results = <String>[];
      final dir = Directory(searchPath);

      if (!await dir.exists()) {
        // Try as file
        final file = File(searchPath);
        if (await file.exists()) {
          final lines = await file.readAsLines();
          for (int i = 0; i < lines.length; i++) {
            if (regex.hasMatch(lines[i])) {
              results.add('$searchPath:${i + 1}: ${lines[i]}');
            }
          }
        }
      } else {
        await for (final entity in dir.list(recursive: true)) {
          if (entity is File) {
            if (include != null) {
              final glob = g.Glob(include);
              if (!glob.matches(entity.path)) continue;
            }

            try {
              final lines = await entity.readAsLines();
              for (int i = 0; i < lines.length; i++) {
                if (regex.hasMatch(lines[i])) {
                  results.add('${entity.path}:${i + 1}: ${lines[i]}');
                  if (results.length >= 100) break;
                }
              }
            } catch (_) {
              // Skip binary files
            }
          }
          if (results.length >= 100) break;
        }
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: results.isEmpty
            ? 'No matches found for: $pattern'
            : '${results.length} matches:\n${results.join('\n')}',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Grep error: $e',
      );
    }
  }
}
