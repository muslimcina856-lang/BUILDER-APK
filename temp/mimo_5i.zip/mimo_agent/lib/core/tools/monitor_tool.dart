import 'dart:async';
import 'dart:io';
import 'tool_models.dart';

/// MonitorTool - Monitor long-running processes
class MonitorTool extends BaseTool {
  @override
  String get name => 'Monitor';

  @override
  String get description =>
      'Start a background monitor that streams events from a long-running script. '
      'Each stdout line is an event. Useful for watching logs, file changes.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'command': {
            'type': 'string',
            'description': 'Shell command to monitor',
          },
          'description': {
            'type': 'string',
            'description': 'What you are monitoring',
          },
          'timeout_ms': {
            'type': 'integer',
            'description': 'Kill after this timeout (default: 300000)',
          },
        },
        'required': ['command', 'description'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final command = args['command'] as String;
    final desc = args['description'] as String;
    final timeout = args['timeout_ms'] as int? ?? 300000;

    try {
      final process = await Process.start('bash', ['-c', command]);

      final events = <String>[];
      final completer = Completer<void>();

      process.stdout.transform(const SystemEncoding().decoder).listen(
        (data) {
          for (final line in data.split('\n')) {
            if (line.trim().isNotEmpty) {
              events.add(line.trim());
            }
          }
        },
        onDone: () => completer.complete(),
      );

      // Auto-kill after timeout
      Timer(Duration(milliseconds: timeout), () {
        process.kill(ProcessSignal.sigterm);
      });

      // Don't wait - return immediately
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'Monitor started: $desc\nCommand: $command\nPID: ${process.pid}',
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'Monitor error: $e',
      );
    }
  }
}
