import 'dart:async';
import 'tool_models.dart';

/// In-memory cron store
class CronStore {
  static final CronStore _instance = CronStore._();
  factory CronStore() => _instance;
  CronStore._();

  final Map<String, CronJob> _jobs = {};
  int _nextId = 1;

  Map<String, CronJob> get jobs => _jobs;
}

class CronJob {
  final String id;
  final String cron;
  final String prompt;
  final bool recurring;
  Timer? timer;

  CronJob({
    required this.id,
    required this.cron,
    required this.prompt,
    required this.recurring,
  });
}

/// CronCreate - Schedule a task
class CronCreateTool extends BaseTool {
  @override
  String get name => 'CronCreate';

  @override
  String get description =>
      'Schedule a prompt to be enqueued at a future time. '
      'Uses 5-field cron: minute hour day-of-month month day-of-week.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'cron': {'type': 'string', 'description': 'Cron expression (5-field)'},
          'prompt': {'type': 'string', 'description': 'Prompt to enqueue'},
          'recurring': {'type': 'boolean', 'description': 'Repeat or one-shot'},
        },
        'required': ['cron', 'prompt'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final store = CronStore();
    final id = 'cron_${store._nextId++}';
    final job = CronJob(
      id: id,
      cron: args['cron'] as String,
      prompt: args['prompt'] as String,
      recurring: args['recurring'] as bool? ?? true,
    );

    // Parse cron and set up timer (simplified)
    final parts = job.cron.split(' ');
    if (parts.length == 5) {
      final minute = int.tryParse(parts[0]) ?? 0;
      final hour = int.tryParse(parts[1]) ?? 0;

      final now = DateTime.now();
      var next = DateTime(now.year, now.month, now.day, hour, minute);
      if (next.isBefore(now)) {
        next = next.add(const Duration(days: 1));
      }
      final delay = next.difference(now);

      job.timer = Timer(delay, () {
        // Execute the prompt
        if (job.recurring) {
          // Reschedule for next day
          job.timer = Timer(const Duration(days: 1), () {});
        }
      });
    }

    store._jobs[id] = job;

    return ToolResult(
      toolName: name, toolCallId: toolCallId, success: true,
      output: 'Cron job created: $id (${job.cron})',
    );
  }
}

/// CronDelete - Cancel a cron job
class CronDeleteTool extends BaseTool {
  @override
  String get name => 'CronDelete';

  @override
  String get description => 'Cancel a cron job previously scheduled';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'id': {'type': 'string', 'description': 'Job ID'},
        },
        'required': ['id'],
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final store = CronStore();
    final job = store._jobs.remove(args['id']);
    job?.timer?.cancel();

    return ToolResult(
      toolName: name, toolCallId: toolCallId,
      success: job != null,
      output: job != null ? 'Job deleted' : 'Job not found',
    );
  }
}

/// CronList - List all cron jobs
class CronListTool extends BaseTool {
  @override
  String get name => 'CronList';

  @override
  String get description => 'List all scheduled cron jobs';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {},
      };

  @override
  Future<ToolResult> execute(Map<String, dynamic> args, String toolCallId) async {
    final jobs = CronStore()._jobs;
    if (jobs.isEmpty) {
      return ToolResult(toolName: name, toolCallId: toolCallId, success: true, output: 'No scheduled jobs');
    }

    final buffer = StringBuffer();
    for (final job in jobs.values) {
      buffer.writeln('[${job.id}] ${job.cron} - ${job.prompt} (${job.recurring ? "recurring" : "one-shot"})');
    }

    return ToolResult(toolName: name, toolCallId: toolCallId, success: true, output: buffer.toString());
  }
}
