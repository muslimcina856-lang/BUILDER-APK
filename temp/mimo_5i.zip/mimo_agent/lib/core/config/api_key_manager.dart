import 'config_models.dart';

/// Manages multiple API keys with fallback support
/// Supports round-robin, priority-based, and failure-based rotation
class ApiKeyManager {
  final List<ApiKeyConfig> _keys;
  int _currentIndex = 0;

  ApiKeyManager(this._keys) {
    _keys.sort((a, b) => a.priority.compareTo(b.priority));
  }

  /// Get the current active API key
  String get currentKey => _keys[_currentIndex].key;

  /// Get the current key config
  ApiKeyConfig get currentConfig => _keys[_currentIndex];

  /// Get all enabled keys
  List<ApiKeyConfig> get enabledKeys =>
      _keys.where((k) => k.enabled).toList();

  /// Get the next available key (for fallback)
  String? getNextKey() {
    final enabled = enabledKeys;
    if (enabled.isEmpty) return null;

    // Try to find a key that hasn't failed recently
    for (int i = 0; i < enabled.length; i++) {
      final nextIndex = (_currentIndex + 1 + i) % enabled.length;
      final key = enabled[nextIndex];
      if (key.failCount < 3) {
        _currentIndex = _keys.indexOf(key);
        return key.key;
      }
    }

    // All keys have failed, reset and try the first one
    for (var key in _keys) {
      key.failCount = 0;
      key.lastFailure = null;
    }
    _currentIndex = 0;
    return _keys[0].key;
  }

  /// Mark the current key as failed and rotate to next
  String? markFailedAndRotate() {
    _keys[_currentIndex].failCount++;
    _keys[_currentIndex].lastFailure = DateTime.now();
    return getNextKey();
  }

  /// Mark the current key as successful (reset fail count)
  void markSuccess() {
    _keys[_currentIndex].failCount = 0;
    _keys[_currentIndex].lastFailure = null;
  }

  /// Rotate to the next key (round-robin)
  String rotate() {
    final enabled = enabledKeys;
    if (enabled.isEmpty) return currentKey;
    _currentIndex = (_currentIndex + 1) % enabled.length;
    return currentKey;
  }

  /// Add a new API key
  void addKey(ApiKeyConfig key) {
    _keys.add(key);
    _keys.sort((a, b) => a.priority.compareTo(b.priority));
  }

  /// Remove an API key by name
  bool removeKey(String name) {
    final index = _keys.indexWhere((k) => k.name == name);
    if (index >= 0) {
      _keys.removeAt(index);
      if (_currentIndex >= _keys.length) {
        _currentIndex = 0;
      }
      return true;
    }
    return false;
  }

  /// Get key status summary
  Map<String, dynamic> getStatus() {
    return {
      'total_keys': _keys.length,
      'enabled_keys': enabledKeys.length,
      'current_index': _currentIndex,
      'current_key_name': currentConfig.name,
      'keys': _keys
          .map((k) => {
                'name': k.name,
                'enabled': k.enabled,
                'fail_count': k.failCount,
                'priority': k.priority,
              })
          .toList(),
    };
  }
}
