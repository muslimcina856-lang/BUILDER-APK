/// Configuration models for the Mimo Agent app

class AppConfig {
  final List<ApiKeyConfig> apiKeys;
  final ModelConfig models;
  final TtsConfig tts;
  final AgentConfig agent;
  final SkillsConfig skills;
  final PluginsConfig plugins;
  final String baseUrl;

  AppConfig({
    required this.apiKeys,
    required this.models,
    required this.tts,
    required this.agent,
    required this.skills,
    required this.plugins,
    this.baseUrl = 'https://api.xiaomimimo.com/v1',
  });

  factory AppConfig.fromMap(Map<String, dynamic> map) {
    return AppConfig(
      apiKeys: (map['api_keys'] as List?)
              ?.map((e) => ApiKeyConfig.fromMap(e))
              .toList() ??
          [],
      models: ModelConfig.fromMap(map['models'] ?? {}),
      tts: TtsConfig.fromMap(map['tts'] ?? {}),
      agent: AgentConfig.fromMap(map['agent'] ?? {}),
      skills: SkillsConfig.fromMap(map['skills'] ?? {}),
      plugins: PluginsConfig.fromMap(map['plugins'] ?? {}),
      baseUrl: map['base_url'] ?? 'https://api.xiaomimimo.com/v1',
    );
  }

  Map<String, dynamic> toMap() => {
        'api_keys': apiKeys.map((e) => e.toMap()).toList(),
        'models': models.toMap(),
        'tts': tts.toMap(),
        'agent': agent.toMap(),
        'skills': skills.toMap(),
        'plugins': plugins.toMap(),
        'base_url': baseUrl,
      };
}

class ApiKeyConfig {
  final String key;
  final String name;
  final int priority;
  final bool enabled;
  int failCount;
  DateTime? lastFailure;

  ApiKeyConfig({
    required this.key,
    required this.name,
    this.priority = 1,
    this.enabled = true,
    this.failCount = 0,
    this.lastFailure,
  });

  factory ApiKeyConfig.fromMap(Map<String, dynamic> map) {
    return ApiKeyConfig(
      key: map['key'] ?? '',
      name: map['name'] ?? 'Unnamed',
      priority: map['priority'] ?? 1,
      enabled: map['enabled'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
        'key': key,
        'name': name,
        'priority': priority,
        'enabled': enabled,
      };
}

class ModelConfig {
  final String defaultModel;
  final List<String> available;

  ModelConfig({
    this.defaultModel = 'mimo-v2.5-pro',
    this.available = const [
      'mimo-v2.5',
      'mimo-v2.5-pro',
      'mimo-v2.5-asr',
      'mimo-v2.5-tts',
      'mimo-v2.5-tts-voiceclone',
      'mimo-v2.5-tts-voicedesign',
    ],
  });

  factory ModelConfig.fromMap(Map<String, dynamic> map) {
    return ModelConfig(
      defaultModel: map['default'] ?? 'mimo-v2.5-pro',
      available:
          List<String>.from(map['available'] ?? ['mimo-v2.5', 'mimo-v2.5-pro']),
    );
  }

  Map<String, dynamic> toMap() => {
        'default': defaultModel,
        'available': available,
      };
}

class TtsConfig {
  final String defaultVoice;
  final bool autoPlay;
  final String format;

  static const List<String> availableVoices = [
    'mimo_default',
    '冰糖',
    '茉莉',
    '苏打',
    '白桦',
    'Mia',
    'Chloe',
    'Milo',
    'Dean',
  ];

  TtsConfig({
    this.defaultVoice = 'Mia',
    this.autoPlay = false,
    this.format = 'mp3',
  });

  factory TtsConfig.fromMap(Map<String, dynamic> map) {
    return TtsConfig(
      defaultVoice: map['default_voice'] ?? 'Mia',
      autoPlay: map['auto_play'] ?? false,
      format: map['format'] ?? 'mp3',
    );
  }

  Map<String, dynamic> toMap() => {
        'default_voice': defaultVoice,
        'auto_play': autoPlay,
        'format': format,
      };
}

class AgentConfig {
  final String systemPrompt;
  final int maxIterations;
  final int timeoutSeconds;

  AgentConfig({
    this.systemPrompt =
        'You are a helpful AI assistant with access to Linux system tools. '
            'You can execute bash commands, read/write files, search the web, '
            'and manage tasks. Always be precise and safe.',
    this.maxIterations = 10,
    this.timeoutSeconds = 300,
  });

  factory AgentConfig.fromMap(Map<String, dynamic> map) {
    return AgentConfig(
      systemPrompt: map['system_prompt'] ??
          'You are a helpful AI assistant with access to Linux system tools.',
      maxIterations: map['max_iterations'] ?? 10,
      timeoutSeconds: map['timeout_seconds'] ?? 300,
    );
  }

  Map<String, dynamic> toMap() => {
        'system_prompt': systemPrompt,
        'max_iterations': maxIterations,
        'timeout_seconds': timeoutSeconds,
      };
}

class SkillsConfig {
  final String directory;

  SkillsConfig({this.directory = '~/.mimo-agent/skills/'});

  factory SkillsConfig.fromMap(Map<String, dynamic> map) {
    return SkillsConfig(directory: map['directory'] ?? '~/.mimo-agent/skills/');
  }

  Map<String, dynamic> toMap() => {'directory': directory};
}

class PluginsConfig {
  final String directory;

  PluginsConfig({this.directory = '~/.mimo-agent/plugins/'});

  factory PluginsConfig.fromMap(Map<String, dynamic> map) {
    return PluginsConfig(
        directory: map['directory'] ?? '~/.mimo-agent/plugins/');
  }

  Map<String, dynamic> toMap() => {'directory': directory};
}
