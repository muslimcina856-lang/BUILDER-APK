import 'dart:async';
import 'dart:convert';
import '../api/mimo_client.dart';
import '../api/mimo_models.dart';
import '../tools/tool_registry.dart';
import '../tools/tool_models.dart';
import '../config/config_models.dart';

/// Main AI Agent - orchestrates conversation and tool execution
class AIAgent {
  final MimoClient client;
  final ToolRegistry toolRegistry;
  final AgentConfig config;
  final List<MimoMessage> _conversation = [];
  final StreamController<AgentEvent> _eventController =
      StreamController<AgentEvent>.broadcast();

  AIAgent({
    required this.client,
    required this.toolRegistry,
    required this.config,
  });

  /// Stream of agent events (for UI)
  Stream<AgentEvent> get events => _eventController.stream;

  /// Get conversation history
  List<MimoMessage> get conversation => List.unmodifiable(_conversation);

  /// Initialize with system prompt
  void init() {
    _conversation.clear();
    _conversation.add(MimoMessage(
      role: 'system',
      content: config.systemPrompt,
    ));
  }

  /// Send a message and get response (with tool execution loop)
  Future<AgentResponse> sendMessage(String userMessage) async {
    _conversation.add(MimoMessage(role: 'user', content: userMessage));
    _eventController.add(AgentEvent(type: AgentEventType.userMessage, content: userMessage));

    int iterations = 0;
    String finalContent = '';
    String reasoning = '';
    List<ToolResult> toolResults = [];

    while (iterations < config.maxIterations) {
      iterations++;

      // Get tool definitions
      final tools = toolRegistry.getToolDefinitions()
          .map((t) => ToolDefinition.fromJson(t))
          .toList();

      // Call API
      _eventController.add(AgentEvent(type: AgentEventType.thinking, content: 'Thinking...'));

      final response = await client.chatWithTools(
        messages: _conversation,
        tools: tools,
        maxTokens: 4096,
      );

      if (response.choices.isEmpty) break;

      final choice = response.choices.first;
      final assistantMsg = choice.message;

      // Add assistant message to conversation
      _conversation.add(assistantMsg);

      // Check if there are tool calls
      if (assistantMsg.toolCalls != null && assistantMsg.toolCalls!.isNotEmpty) {
        _eventController.add(AgentEvent(
          type: AgentEventType.toolCalls,
          content: '${assistantMsg.toolCalls!.length} tool(s) called',
        ));

        // Execute each tool call
        for (final toolCall in assistantMsg.toolCalls!) {
          _eventController.add(AgentEvent(
            type: AgentEventType.toolExecution,
            content: 'Executing: ${toolCall.function.name}',
          ));

          // Parse arguments
          Map<String, dynamic> args;
          try {
            args = jsonDecode(toolCall.function.arguments);
          } catch (_) {
            args = {};
          }

          // Execute tool
          final result = await toolRegistry.executeTool(
            toolCall.function.name,
            args,
            toolCall.id,
          );

          toolResults.add(result);

          // Add tool result to conversation
          _conversation.add(MimoMessage(
            role: 'tool',
            content: result.success ? result.output : 'Error: ${result.error}',
            toolCallId: toolCall.id,
          ));

          _eventController.add(AgentEvent(
            type: AgentEventType.toolResult,
            content: result.success ? result.output : 'Error: ${result.error}',
            metadata: {'tool': toolCall.function.name, 'success': result.success},
          ));
        }

        // Continue the loop - API will process tool results
        continue;
      }

      // No tool calls - we have a final response
      finalContent = assistantMsg.content ?? '';
      reasoning = assistantMsg.reasoningContent ?? '';
      break;
    }

    _eventController.add(AgentEvent(
      type: AgentEventType.response,
      content: finalContent,
    ));

    return AgentResponse(
      content: finalContent,
      reasoning: reasoning,
      toolResults: toolResults,
      iterations: iterations,
    );
  }

  /// Send with streaming
  Stream<AgentStreamEvent> sendMessageStream(String userMessage) async* {
    _conversation.add(MimoMessage(role: 'user', content: userMessage));

    final tools = toolRegistry.getToolDefinitions()
        .map((t) => ToolDefinition.fromJson(t))
        .toList();

    final request = MimoChatRequest(
      model: 'mimo-v2.5-pro',
      messages: _conversation,
      tools: tools,
      stream: true,
      maxTokens: 4096,
    );

    String contentBuffer = '';
    String reasoningBuffer = '';
    final toolCallsBuffer = <ToolCall>[];

    await for (final chunk in client.chatCompletionStream(request)) {
      for (final choice in chunk.choices) {
        if (choice.delta.content != null) {
          contentBuffer += choice.delta.content!;
          yield AgentStreamEvent(
            type: AgentStreamEventType.content,
            content: choice.delta.content!,
          );
        }

        if (choice.delta.reasoningContent != null) {
          reasoningBuffer += choice.delta.reasoningContent!;
          yield AgentStreamEvent(
            type: AgentStreamEventType.reasoning,
            content: choice.delta.reasoningContent!,
          );
        }

        if (choice.delta.toolCalls != null) {
          for (final tc in choice.delta.toolCalls!) {
            final existingIdx = toolCallsBuffer.indexWhere((t) => t.id == tc.id);
            if (existingIdx >= 0) {
              final existing = toolCallsBuffer[existingIdx];
              toolCallsBuffer[existingIdx] = ToolCall(
                id: existing.id,
                function: FunctionCall(
                  name: existing.function.name + tc.function.name,
                  arguments: existing.function.arguments + tc.function.arguments,
                ),
              );
            } else {
              toolCallsBuffer.add(tc);
            }
          }
        }

        if (choice.finishReason == 'tool_calls' && toolCallsBuffer.isNotEmpty) {
          // Execute tools
          for (final toolCall in toolCallsBuffer) {
            yield AgentStreamEvent(
              type: AgentStreamEventType.toolCall,
              content: toolCall.function.name,
            );

            Map<String, dynamic> args;
            try {
              args = jsonDecode(toolCall.function.arguments);
            } catch (_) {
              args = {};
            }

            final result = await toolRegistry.executeTool(
              toolCall.function.name,
              args,
              toolCall.id,
            );

            yield AgentStreamEvent(
              type: AgentStreamEventType.toolResult,
              content: result.success ? result.output : 'Error: ${result.error}',
              metadata: {'tool': toolCall.function.name},
            );
          }
        }
      }
    }

    // Add assistant response to conversation
    _conversation.add(MimoMessage(
      role: 'assistant',
      content: contentBuffer.isEmpty ? null : contentBuffer,
      toolCalls: toolCallsBuffer.isEmpty ? null : toolCallsBuffer,
      reasoningContent: reasoningBuffer.isEmpty ? null : reasoningBuffer,
    ));
  }

  /// Clear conversation
  void clear() {
    _conversation.clear();
    init();
  }

  /// Dispose
  void dispose() {
    _eventController.close();
  }
}

/// Agent response
class AgentResponse {
  final String content;
  final String reasoning;
  final List<ToolResult> toolResults;
  final int iterations;

  AgentResponse({
    required this.content,
    this.reasoning = '',
    this.toolResults = const [],
    this.iterations = 0,
  });
}

/// Agent event types
enum AgentEventType {
  userMessage,
  thinking,
  toolCalls,
  toolExecution,
  toolResult,
  response,
  error,
}

/// Agent event
class AgentEvent {
  final AgentEventType type;
  final String content;
  final Map<String, dynamic>? metadata;

  AgentEvent({
    required this.type,
    required this.content,
    this.metadata,
  });
}

/// Stream event types
enum AgentStreamEventType {
  content,
  reasoning,
  toolCall,
  toolResult,
  done,
}

/// Stream event
class AgentStreamEvent {
  final AgentStreamEventType type;
  final String content;
  final Map<String, dynamic>? metadata;

  AgentStreamEvent({
    required this.type,
    required this.content,
    this.metadata,
  });
}
