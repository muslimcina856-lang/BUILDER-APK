import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../api/mimo_client.dart';
import '../api/mimo_models.dart';
import '../config/config_models.dart';

/// TTS Service - Text-to-Speech using Mimo API
class TtsService {
  final MimoClient client;
  final TtsConfig config;
  final List<String> _playQueue = [];
  bool _isPlaying = false;

  TtsService({required this.client, required this.config});

  /// Available voices
  static List<String> get availableVoices => TtsConfig.availableVoices;

  /// Generate TTS audio
  Future<TtsResult> speak({
    required String text,
    String? voice,
    String? format,
  }) async {
    final audioData = await client.tts(
      text: text,
      voice: voice ?? config.defaultVoice,
      format: format ?? config.format,
    );

    // Decode base64 audio
    final audioBytes = base64Decode(audioData.data);

    // Save to temp file
    final tempDir = await getTemporaryDirectory();
    final fileName = 'tts_${DateTime.now().millisecondsSinceEpoch}.${format ?? config.format}';
    final file = File('${tempDir.path}/$fileName');
    await file.writeAsBytes(audioBytes);

    return TtsResult(
      filePath: file.path,
      audioBytes: audioBytes,
      transcript: audioData.transcript,
      voice: voice ?? config.defaultVoice,
    );
  }

  /// Speak with voice cloning
  Future<TtsResult> speakWithClone({
    required String text,
    required String voiceDataUrl,
    String format = 'mp3',
  }) async {
    final audioData = await client.voiceClone(
      text: text,
      voiceDataUrl: voiceDataUrl,
      format: format,
    );

    final audioBytes = base64Decode(audioData.data);
    final tempDir = await getTemporaryDirectory();
    final fileName = 'tts_clone_${DateTime.now().millisecondsSinceEpoch}.$format';
    final file = File('${tempDir.path}/$fileName');
    await file.writeAsBytes(audioBytes);

    return TtsResult(
      filePath: file.path,
      audioBytes: audioBytes,
      transcript: audioData.transcript,
      voice: 'clone',
    );
  }

  /// Get voice list with display names
  static List<VoiceInfo> get voiceList => [
        VoiceInfo(id: 'mimo_default', name: 'Mimo Default', language: 'zh'),
        VoiceInfo(id: '冰糖', name: 'Bing Tang (Ice Candy)', language: 'zh'),
        VoiceInfo(id: '茉莉', name: 'Mo Li (Jasmine)', language: 'zh'),
        VoiceInfo(id: '苏打', name: 'Su Da (Soda)', language: 'zh'),
        VoiceInfo(id: '白桦', name: 'Bai Hua (Birch)', language: 'zh'),
        VoiceInfo(id: 'Mia', name: 'Mia', language: 'en'),
        VoiceInfo(id: 'Chloe', name: 'Chloe', language: 'en'),
        VoiceInfo(id: 'Milo', name: 'Milo', language: 'en'),
        VoiceInfo(id: 'Dean', name: 'Dean', language: 'en'),
      ];
}

/// TTS result
class TtsResult {
  final String filePath;
  final List<int> audioBytes;
  final String? transcript;
  final String voice;

  TtsResult({
    required this.filePath,
    required this.audioBytes,
    this.transcript,
    required this.voice,
  });
}

/// Voice info
class VoiceInfo {
  final String id;
  final String name;
  final String language;

  VoiceInfo({required this.id, required this.name, required this.language});
}
