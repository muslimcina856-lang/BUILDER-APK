/// Mimo API Endpoints

class MimoEndpoints {
  // Base URLs
  static const String defaultBaseUrl = 'https://api.xiaomimimo.com/v1';
  static const String anthropicBaseUrl = 'https://api.xiaomimimo.com/anthropic';

  // Chat
  static const String chatCompletions = '/chat/completions';

  // Models
  static const String models = '/models';

  // Audio (TTS uses chat completions with modalities)
  static const String audioSpeech = '/audio/speech';

  // Available models (6 total)
  static const String modelMimoV25 = 'mimo-v2.5';
  static const String modelMimoV25Pro = 'mimo-v2.5-pro';
  static const String modelMimoV25Asr = 'mimo-v2.5-asr';
  static const String modelMimoV25Tts = 'mimo-v2.5-tts';
  static const String modelMimoV25TtsVoiceClone = 'mimo-v2.5-tts-voiceclone';
  static const String modelMimoV25TtsVoiceDesign = 'mimo-v2.5-tts-voicedesign';

  static const List<String> allModels = [
    modelMimoV25,
    modelMimoV25Pro,
    modelMimoV25Asr,
    modelMimoV25Tts,
    modelMimoV25TtsVoiceClone,
    modelMimoV25TtsVoiceDesign,
  ];

  // TTS Voices
  static const List<String> ttsVoices = [
    'mimo_default',
    '冰糖',
    '茉莉',
    '苏打',
    '白桦',
    'Mia',
    'Chloe',
    'Milo',
    'Dean',
  ];

  // Audio formats
  static const List<String> audioFormats = ['mp3', 'wav'];
}
