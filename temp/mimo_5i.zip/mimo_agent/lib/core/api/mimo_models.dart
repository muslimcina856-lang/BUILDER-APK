/// Mimo API request/response models (OpenAI-compatible format)

// ============ Chat Completion Models ============

class MimoChatRequest {
  final String model;
  final List<MimoMessage> messages;
  final bool stream;
  final int? maxTokens;
  final double? temperature;
  final List<ToolDefinition>? tools;
  final String? toolChoice;
  final List<String>? modalities;
  final AudioConfig? audio;

  MimoChatRequest({
    required this.model,
    required this.messages,
    this.stream = false,
    this.maxTokens,
    this.temperature,
    this.tools,
    this.toolChoice,
    this.modalities,
    this.audio,
  });

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{
      'model': model,
      'messages': messages.map((m) => m.toJson()).toList(),
      'stream': stream,
    };
    if (maxTokens != null) map['max_tokens'] = maxTokens;
    if (temperature != null) map['temperature'] = temperature;
    if (tools != null && tools!.isNotEmpty) {
      map['tools'] = tools!.map((t) => t.toJson()).toList();
    }
    if (toolChoice != null) map['tool_choice'] = toolChoice;
    if (modalities != null) map['modalities'] = modalities;
    if (audio != null) map['audio'] = audio!.toJson();
    return map;
  }
}

class MimoMessage {
  final String role; // "system", "user", "assistant", "tool"
  final String? content;
  final List<ToolCall>? toolCalls;
  final String? toolCallId;
  final String? reasoningContent;
  final AudioData? audio;

  MimoMessage({
    required this.role,
    this.content,
    this.toolCalls,
    this.toolCallId,
    this.reasoningContent,
    this.audio,
  });

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{'role': role};
    if (content != null) map['content'] = content;
    if (toolCalls != null) {
      map['tool_calls'] = toolCalls!.map((t) => t.toJson()).toList();
    }
    if (toolCallId != null) map['tool_call_id'] = toolCallId;
    return map;
  }

  factory MimoMessage.fromJson(Map<String, dynamic> json) {
    return MimoMessage(
      role: json['role'] ?? '',
      content: json['content'],
      toolCalls: (json['tool_calls'] as List?)
          ?.map((t) => ToolCall.fromJson(t))
          .toList(),
      toolCallId: json['tool_call_id'],
      reasoningContent: json['reasoning_content'],
    );
  }
}

class ToolDefinition {
  final String type; // "function"
  final FunctionDef function;

  ToolDefinition({this.type = 'function', required this.function});

  Map<String, dynamic> toJson() => {
        'type': type,
        'function': function.toJson(),
      };

  factory ToolDefinition.fromJson(Map<String, dynamic> json) {
    return ToolDefinition(
      type: json['type'] ?? 'function',
      function: FunctionDef.fromJson(json['function'] ?? {}),
    );
  }
}

class FunctionDef {
  final String name;
  final String description;
  final Map<String, dynamic> parameters;

  FunctionDef({
    required this.name,
    required this.description,
    required this.parameters,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'description': description,
        'parameters': parameters,
      };

  factory FunctionDef.fromJson(Map<String, dynamic> json) {
    return FunctionDef(
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      parameters: Map<String, dynamic>.from(json['parameters'] ?? {}),
    );
  }
}

class ToolCall {
  final String id;
  final String type; // "function"
  final FunctionCall function;

  ToolCall({required this.id, this.type = 'function', required this.function});

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'function': function.toJson(),
      };

  factory ToolCall.fromJson(Map<String, dynamic> json) {
    return ToolCall(
      id: json['id'] ?? '',
      type: json['type'] ?? 'function',
      function: FunctionCall.fromJson(json['function'] ?? {}),
    );
  }
}

class FunctionCall {
  final String name;
  final String arguments; // JSON string

  FunctionCall({required this.name, required this.arguments});

  Map<String, dynamic> toJson() => {
        'name': name,
        'arguments': arguments,
      };

  factory FunctionCall.fromJson(Map<String, dynamic> json) {
    return FunctionCall(
      name: json['name'] ?? '',
      arguments: json['arguments'] ?? '{}',
    );
  }
}

class AudioConfig {
  final String voice;
  final String format;

  AudioConfig({required this.voice, this.format = 'mp3'});

  Map<String, dynamic> toJson() => {
        'voice': voice,
        'format': format,
      };
}

class AudioData {
  final String id;
  final String data; // base64 encoded
  final int? expiresAt;
  final String? transcript;

  AudioData({
    required this.id,
    required this.data,
    this.expiresAt,
    this.transcript,
  });

  factory AudioData.fromJson(Map<String, dynamic> json) {
    return AudioData(
      id: json['id'] ?? '',
      data: json['data'] ?? '',
      expiresAt: json['expires_at'],
      transcript: json['transcript'],
    );
  }
}

// ============ Response Models ============

class MimoChatResponse {
  final String id;
  final List<MimoChoice> choices;
  final int created;
  final String model;
  final String object;
  final MimoUsage usage;

  MimoChatResponse({
    required this.id,
    required this.choices,
    required this.created,
    required this.model,
    required this.object,
    required this.usage,
  });

  factory MimoChatResponse.fromJson(Map<String, dynamic> json) {
    return MimoChatResponse(
      id: json['id'] ?? '',
      choices: (json['choices'] as List?)
              ?.map((c) => MimoChoice.fromJson(c))
              .toList() ??
          [],
      created: json['created'] ?? 0,
      model: json['model'] ?? '',
      object: json['object'] ?? '',
      usage: MimoUsage.fromJson(json['usage'] ?? {}),
    );
  }
}

class MimoChoice {
  final int index;
  final MimoMessage message;
  final String? finishReason;

  MimoChoice({
    required this.index,
    required this.message,
    this.finishReason,
  });

  factory MimoChoice.fromJson(Map<String, dynamic> json) {
    return MimoChoice(
      index: json['index'] ?? 0,
      message: MimoMessage.fromJson(json['message'] ?? {}),
      finishReason: json['finish_reason'],
    );
  }
}

class MimoUsage {
  final int promptTokens;
  final int completionTokens;
  final int totalTokens;
  final int? cachedTokens;
  final int? reasoningTokens;

  MimoUsage({
    required this.promptTokens,
    required this.completionTokens,
    required this.totalTokens,
    this.cachedTokens,
    this.reasoningTokens,
  });

  factory MimoUsage.fromJson(Map<String, dynamic> json) {
    final details = json['prompt_tokens_details'] ?? {};
    final compDetails = json['completion_tokens_details'] ?? {};
    return MimoUsage(
      promptTokens: json['prompt_tokens'] ?? 0,
      completionTokens: json['completion_tokens'] ?? 0,
      totalTokens: json['total_tokens'] ?? 0,
      cachedTokens: details['cached_tokens'],
      reasoningTokens: compDetails['reasoning_tokens'],
    );
  }
}

// ============ Stream Models ============

class MimoStreamChunk {
  final String id;
  final List<MimoStreamChoice> choices;
  final int created;
  final String model;

  MimoStreamChunk({
    required this.id,
    required this.choices,
    required this.created,
    required this.model,
  });

  factory MimoStreamChunk.fromJson(Map<String, dynamic> json) {
    return MimoStreamChunk(
      id: json['id'] ?? '',
      choices: (json['choices'] as List?)
              ?.map((c) => MimoStreamChoice.fromJson(c))
              .toList() ??
          [],
      created: json['created'] ?? 0,
      model: json['model'] ?? '',
    );
  }
}

class MimoStreamChoice {
  final int index;
  final MimoDelta delta;
  final String? finishReason;

  MimoStreamChoice({
    required this.index,
    required this.delta,
    this.finishReason,
  });

  factory MimoStreamChoice.fromJson(Map<String, dynamic> json) {
    return MimoStreamChoice(
      index: json['index'] ?? 0,
      delta: MimoDelta.fromJson(json['delta'] ?? {}),
      finishReason: json['finish_reason'],
    );
  }
}

class MimoDelta {
  final String? role;
  final String? content;
  final String? reasoningContent;
  final List<ToolCall>? toolCalls;

  MimoDelta({
    this.role,
    this.content,
    this.reasoningContent,
    this.toolCalls,
  });

  factory MimoDelta.fromJson(Map<String, dynamic> json) {
    return MimoDelta(
      role: json['role'],
      content: json['content'],
      reasoningContent: json['reasoning_content'],
      toolCalls: (json['tool_calls'] as List?)
          ?.map((t) => ToolCall.fromJson(t))
          .toList(),
    );
  }
}

// ============ Model List ============

class MimoModel {
  final String id;
  final String object;
  final String ownedBy;

  MimoModel({
    required this.id,
    required this.object,
    required this.ownedBy,
  });

  factory MimoModel.fromJson(Map<String, dynamic> json) {
    return MimoModel(
      id: json['id'] ?? '',
      object: json['object'] ?? '',
      ownedBy: json['owned_by'] ?? '',
    );
  }
}

// ============ TTS Models ============

class MimoTTSRequest {
  final String model;
  final List<MimoMessage> messages;
  final List<String> modalities;
  final AudioConfig audio;

  MimoTTSRequest({
    required this.model,
    required this.messages,
    this.modalities = const ['text', 'audio'],
    required this.audio,
  });

  Map<String, dynamic> toJson() => {
        'model': model,
        'messages': messages.map((m) => m.toJson()).toList(),
        'modalities': modalities,
        'audio': audio.toJson(),
      };
}
