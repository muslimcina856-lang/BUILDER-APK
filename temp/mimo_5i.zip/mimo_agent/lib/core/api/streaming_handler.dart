import 'dart:async';
import 'dart:convert';
import 'mimo_models.dart';

/// Handles Server-Sent Events (SSE) streaming from Mimo API
class MimoStreamHandler {
  /// Parse SSE stream into MimoStreamChunk objects
  static Stream<MimoStreamChunk> parseSSE(
      Stream<List<int>> byteStream) async* {
    String buffer = '';

    await for (final bytes in byteStream) {
      buffer += utf8.decode(bytes);

      // Process complete lines
      while (buffer.contains('\n')) {
        final newlineIndex = buffer.indexOf('\n');
        final line = buffer.substring(0, newlineIndex).trim();
        buffer = buffer.substring(newlineIndex + 1);

        if (line.isEmpty) continue;

        if (line.startsWith('data: ')) {
          final data = line.substring(6).trim();

          if (data == '[DONE]') {
            return;
          }

          try {
            final json = jsonDecode(data);
            yield MimoStreamChunk.fromJson(json);
          } catch (e) {
            // Skip malformed JSON
            continue;
          }
        }
      }
    }
  }

  /// Accumulate stream chunks into a complete response
  static Future<StreamAccumulator> accumulateStream(
      Stream<MimoStreamChunk> stream) async {
    final accumulator = StreamAccumulator();

    await for (final chunk in stream) {
      accumulator.addChunk(chunk);
    }

    return accumulator;
  }
}

/// Accumulates streaming chunks into a complete response
class StreamAccumulator {
  String _content = '';
  String _reasoningContent = '';
  final List<ToolCall> _toolCalls = [];
  String? _finishReason;
  String _model = '';
  String _id = '';

  String get content => _content;
  String get reasoningContent => _reasoningContent;
  List<ToolCall> get toolCalls => _toolCalls;
  String? get finishReason => _finishReason;
  String get model => _model;
  String get id => _id;

  void addChunk(MimoStreamChunk chunk) {
    _id = chunk.id;
    _model = chunk.model;

    for (final choice in chunk.choices) {
      if (choice.finishReason != null) {
        _finishReason = choice.finishReason;
      }

      if (choice.delta.content != null) {
        _content += choice.delta.content!;
      }

      if (choice.delta.reasoningContent != null) {
        _reasoningContent += choice.delta.reasoningContent!;
      }

      if (choice.delta.toolCalls != null) {
        for (final tc in choice.delta.toolCalls!) {
          // Merge tool call deltas
          final existingIndex =
              _toolCalls.indexWhere((t) => t.id == tc.id || t.id.isEmpty);
          if (existingIndex >= 0 && _toolCalls[existingIndex].id.isEmpty) {
            _toolCalls[existingIndex] = tc;
          } else if (existingIndex >= 0) {
            // Append arguments to existing tool call
            final existing = _toolCalls[existingIndex];
            _toolCalls[existingIndex] = ToolCall(
              id: existing.id,
              type: existing.type,
              function: FunctionCall(
                name: existing.function.name + tc.function.name,
                arguments:
                    existing.function.arguments + tc.function.arguments,
              ),
            );
          } else {
            _toolCalls.add(tc);
          }
        }
      }
    }
  }

  /// Convert to a MimoChatResponse-like structure
  MimoMessage toMessage() {
    return MimoMessage(
      role: 'assistant',
      content: _content.isEmpty ? null : _content,
      toolCalls: _toolCalls.isEmpty ? null : _toolCalls,
      reasoningContent: _reasoningContent.isEmpty ? null : _reasoningContent,
    );
  }
}
