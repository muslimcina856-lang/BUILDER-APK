import 'dart:io';
import 'dart:convert';
import '../skills/skill_models.dart';

/// Manages loading plugins
class PluginManager {
  final Map<String, Plugin> _plugins = {};
  final String pluginsPath;

  PluginManager({this.pluginsPath = '/root/.mimo-agent/plugins/'});

  Map<String, Plugin> get plugins => _plugins;

  /// Load all plugins from the plugins directory
  Future<void> loadAll() async {
    final dir = Directory(pluginsPath);
    if (!await dir.exists()) return;

    await for (final entity in dir.list()) {
      if (entity is Directory) {
        await _loadPlugin(entity.path);
      }
    }
  }

  /// Load a single plugin
  Future<void> _loadPlugin(String pluginPath) async {
    // Check for plugin.json
    final manifestFile = File('$pluginPath/.claude-plugin/plugin.json');
    if (!await manifestFile.exists()) return;

    try {
      final content = await manifestFile.readAsString();
      final manifest = jsonDecode(content) as Map<String, dynamic>;
      final plugin = Plugin.fromManifest(manifest, pluginPath);

      // Load skills
      final skillsDir = Directory('$pluginPath/skills');
      final skills = <Skill>[];
      if (await skillsDir.exists()) {
        await for (final entity in skillsDir.list(recursive: true)) {
          if (entity is File && entity.path.endsWith('SKILL.md')) {
            final skillContent = await entity.readAsString();
            skills.add(Skill.fromMarkdown(skillContent, entity.path));
          }
        }
      }

      // Load MCP config
      McpConfig? mcp;
      final mcpFile = File('$pluginPath/.mcp.json');
      if (await mcpFile.exists()) {
        final mcpContent = await mcpFile.readAsString();
        mcp = McpConfig.fromJson(jsonDecode(mcpContent));
      }

      _plugins[plugin.name] = Plugin(
        name: plugin.name,
        description: plugin.description,
        author: plugin.author,
        authorEmail: plugin.authorEmail,
        path: pluginPath,
        skills: skills,
        mcp: mcp,
      );
    } catch (_) {
      // Skip invalid plugins
    }
  }

  /// Get a plugin by name
  Plugin? getPlugin(String name) => _plugins[name];

  /// Get all plugin names
  List<String> get pluginNames => _plugins.keys.toList();
}
