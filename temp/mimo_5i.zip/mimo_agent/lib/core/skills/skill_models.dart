/// Skill and Plugin data models

class Skill {
  final String name;
  final String description;
  final String? version;
  final String? argumentHint;
  final List<String> allowedTools;
  final String? model;
  final String content; // Full SKILL.md content
  final String path;

  Skill({
    required this.name,
    required this.description,
    this.version,
    this.argumentHint,
    this.allowedTools = const [],
    this.model,
    required this.content,
    required this.path,
  });

  /// Parse from SKILL.md content with YAML frontmatter
  factory Skill.fromMarkdown(String content, String path) {
    String name = '';
    String description = '';
    String? version;
    String? argumentHint;
    List<String> allowedTools = [];
    String? model;
    String body = content;

    // Parse frontmatter
    if (content.startsWith('---')) {
      final endIdx = content.indexOf('---', 3);
      if (endIdx > 0) {
        final frontmatter = content.substring(3, endIdx).trim();
        body = content.substring(endIdx + 3).trim();

        for (final line in frontmatter.split('\n')) {
          final colonIdx = line.indexOf(':');
          if (colonIdx > 0) {
            final key = line.substring(0, colonIdx).trim();
            final value = line.substring(colonIdx + 1).trim();
            switch (key) {
              case 'name':
                name = value;
                break;
              case 'description':
                description = value;
                break;
              case 'version':
                version = value;
                break;
              case 'argument-hint':
                argumentHint = value;
                break;
              case 'allowed-tools':
                allowedTools = value
                    .replaceAll('[', '')
                    .replaceAll(']', '')
                    .split(',')
                    .map((e) => e.trim())
                    .toList();
                break;
              case 'model':
                model = value;
                break;
            }
          }
        }
      }
    }

    // Extract name from path if not in frontmatter
    if (name.isEmpty) {
      final parts = path.split('/');
      for (int i = parts.length - 1; i >= 0; i--) {
        if (parts[i] == 'SKILL.md' && i > 0) {
          name = parts[i - 1];
          break;
        }
      }
    }

    return Skill(
      name: name,
      description: description,
      version: version,
      argumentHint: argumentHint,
      allowedTools: allowedTools,
      model: model,
      content: body,
      path: path,
    );
  }
}

class Plugin {
  final String name;
  final String description;
  final String? author;
  final String? authorEmail;
  final String path;
  final List<Skill> skills;
  final McpConfig? mcp;

  Plugin({
    required this.name,
    required this.description,
    this.author,
    this.authorEmail,
    required this.path,
    this.skills = const [],
    this.mcp,
  });

  factory Plugin.fromManifest(Map<String, dynamic> manifest, String path) {
    return Plugin(
      name: manifest['name'] ?? '',
      description: manifest['description'] ?? '',
      author: manifest['author']?['name'],
      authorEmail: manifest['author']?['email'],
      path: path,
    );
  }
}

class McpConfig {
  final Map<String, McpServer> servers;

  McpConfig({required this.servers});

  factory McpConfig.fromJson(Map<String, dynamic> json) {
    final servers = <String, McpServer>{};
    for (final entry in json.entries) {
      servers[entry.key] = McpServer.fromJson(entry.value);
    }
    return McpConfig(servers: servers);
  }
}

class McpServer {
  final String type; // "stdio", "http", "sse"
  final String? url;
  final String? command;
  final List<String>? args;
  final Map<String, String>? env;

  McpServer({
    required this.type,
    this.url,
    this.command,
    this.args,
    this.env,
  });

  factory McpServer.fromJson(Map<String, dynamic> json) {
    return McpServer(
      type: json['type'] ?? 'http',
      url: json['url'],
      command: json['command'],
      args: (json['args'] as List?)?.cast<String>(),
      env: (json['env'] as Map?)?.cast<String, String>(),
    );
  }
}
