import 'dart:io';
import 'skill_models.dart';

/// Manages loading and registering skills
class SkillManager {
  final Map<String, Skill> _skills = {};
  final List<String> _searchPaths;

  SkillManager({
    List<String>? searchPaths,
  }) : _searchPaths = searchPaths ??
            [
              'assets/skills/',
              '/root/.mimo-agent/skills/',
              'skills/',
            ];

  /// Get all loaded skills
  Map<String, Skill> get skills => _skills;

  /// Load all skills from search paths
  Future<void> loadAll() async {
    for (final path in _searchPaths) {
      await _loadFromDirectory(path);
    }
  }

  /// Load skills from a directory
  Future<void> _loadFromDirectory(String dirPath) async {
    final dir = Directory(dirPath);
    if (!await dir.exists()) return;

    await for (final entity in dir.list(recursive: true)) {
      if (entity is File && entity.path.endsWith('SKILL.md')) {
        try {
          final content = await entity.readAsString();
          final skill = Skill.fromMarkdown(content, entity.path);
          _skills[skill.name] = skill;
        } catch (_) {
          // Skip invalid skill files
        }
      }
    }
  }

  /// Get a skill by name
  Skill? getSkill(String name) => _skills[name];

  /// Get all skill names
  List<String> get skillNames => _skills.keys.toList();

  /// Check if a skill exists
  bool hasSkill(String name) => _skills.containsKey(name);

  /// Add a skill manually
  void addSkill(Skill skill) {
    _skills[skill.name] = skill;
  }

  /// Remove a skill
  bool removeSkill(String name) {
    return _skills.remove(name) != null;
  }
}
