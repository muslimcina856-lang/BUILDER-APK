import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/config/app_config.dart';
import 'core/api/mimo_client.dart';
import 'core/tools/tool_registry.dart';
import 'core/agent/ai_agent.dart';
import 'core/tts/tts_service.dart';
import 'core/skills/skill_manager.dart';
import 'core/plugins/plugin_manager.dart';
import 'features/chat/chat_screen.dart';
import 'features/settings/settings_screen.dart';
import 'features/skills/skills_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize config
  final configManager = AppConfigManager.instance;
  await configManager.init();

  runApp(MimoAgentApp(configManager: configManager));
}

class MimoAgentApp extends StatelessWidget {
  final AppConfigManager configManager;

  const MimoAgentApp({super.key, required this.configManager});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<AppConfigManager>.value(value: configManager),
        Provider<MimoClient>(
          create: (_) => MimoClient(
            baseUrl: configManager.config.baseUrl,
            keyManager: configManager.keyManager,
          ),
        ),
        Provider<ToolRegistry>(
          create: (ctx) {
            final registry = ToolRegistry.instance;
            registry.init(ctx.read<MimoClient>());
            return registry;
          },
        ),
        Provider<SkillManager>(
          create: (_) {
            final manager = SkillManager();
            manager.loadAll();
            return manager;
          },
        ),
        Provider<PluginManager>(
          create: (_) {
            final manager = PluginManager();
            manager.loadAll();
            return manager;
          },
        ),
        ProxyProvider2<MimoClient, ToolRegistry, AIAgent>(
          create: (ctx) => AIAgent(
            client: ctx.read<MimoClient>(),
            toolRegistry: ctx.read<ToolRegistry>(),
            config: configManager.config.agent,
          )..init(),
          update: (_, client, registry, agent) => agent!,
        ),
        ProxyProvider<MimoClient, TtsService>(
          create: (ctx) => TtsService(
            client: ctx.read<MimoClient>(),
            config: configManager.config.tts,
          ),
          update: (_, client, tts) => tts!,
        ),
      ],
      child: MaterialApp(
        title: 'Mimo Agent',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF6366F1),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFF0F0F23),
          cardColor: const Color(0xFF1A1A2E),
        ),
        home: const MainNavigation(),
      ),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  final _screens = const [
    ChatScreen(),
    SkillsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        backgroundColor: const Color(0xFF1A1A2E),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(Icons.extension_outlined),
            selectedIcon: Icon(Icons.extension),
            label: 'Skills',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
