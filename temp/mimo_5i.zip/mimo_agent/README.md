# Mimo Agent - Flutter AI Assistant

A standalone Flutter application powered by Mimo v2.5 API with Claude Code-style tools integration.

## Features

### AI Models
- **Mimo v2.5** - Standard model
- **Mimo v2.5 Pro** - Advanced reasoning model
- **Mimo v2.5 ASR** - Speech recognition
- **Mimo v2.5 TTS** - Text-to-speech with 8 voices
- **Mimo v2.5 TTS Voice Clone** - Voice cloning
- **Mimo v2.5 TTS Voice Design** - Voice design

### 30 Integrated Tools (Claude Code Compatible)

| Category | Tools |
|----------|-------|
| **File Operations** | Read, Write, Edit, Glob, Grep |
| **Execution** | Bash, Agent |
| **Web** | WebFetch, WebSearch |
| **Task Management** | TaskCreate, TaskGet, TaskList, TaskUpdate, TaskStop, TaskOutput |
| **Scheduling** | CronCreate, CronDelete, CronList |
| **Monitoring** | Monitor |
| **Skills** | Skill |

### TTS Voices
- mimo_default (中文)
- 冰糖 Bing Tang (中文)
- 茉莉 Mo Li (中文)
- 苏打 Su Da (中文)
- 白桦 Bai Hua (中文)
- Mia (English)
- Chloe (English)
- Milo (English)
- Dean (English)

### Skills System
Create custom skills as SKILL.md files with YAML frontmatter:

```yaml
---
name: my-skill
description: This skill should be used when...
version: 1.0.0
---

# Skill content here
```

### Plugins System
Load plugins from `~/.mimo-agent/plugins/` with:
- `.claude-plugin/plugin.json` - Plugin metadata
- `.mcp.json` - MCP server configuration
- `skills/` - Plugin skills

## Configuration

Edit `config.yaml`:

```yaml
api_keys:
  - key: "sk-your-key-here"
    name: "Primary"
    priority: 1
  - key: "sk-backup-key"
    name: "Backup"
    priority: 2

models:
  default: "mimo-v2.5-pro"

tts:
  default_voice: "Mia"
```

## API Key Fallback

The app supports multiple API keys with automatic fallback:
- Priority-based ordering
- Auto-retry on 401/429 errors
- Round-robin rotation
- Failure tracking and recovery

## Architecture

```
lib/
├── core/
│   ├── api/          # Mimo API client
│   ├── config/       # Configuration management
│   ├── tools/        # 30 Claude Code tools
│   ├── skills/       # Skills system
│   ├── plugins/      # Plugin system
│   ├── agent/        # AI agent loop
│   └── tts/          # TTS integration
├── features/
│   ├── chat/         # Chat UI
│   ├── settings/     # Settings UI
│   ├── skills/       # Skills browser
│   └── terminal/     # Terminal UI
└── shared/           # Utilities
```

## Standalone Operation

This app runs standalone - no server needed. Just:
1. Set your Mimo API key in config
2. Run the app
3. Chat with AI that has full Linux tool access

## Building

```bash
flutter pub get
flutter run
```

## License

MIT
