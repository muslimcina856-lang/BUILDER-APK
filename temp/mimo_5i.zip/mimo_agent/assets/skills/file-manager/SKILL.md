---
name: file-manager
description: This skill should be used when the user asks to "manage files", "organize files", "copy/move files", or works with file operations. Provides safe file management patterns.
version: 1.0.0
---

# File Manager Skill

Provides safe file management operations and patterns.

## When This Skill Applies

- User asks to copy, move, or organize files
- User needs to create directory structures
- User wants to batch rename or process files

## Safe File Operations

### Before Any Destructive Operation
1. List what will be affected
2. Confirm with user
3. Create backup if needed
4. Execute with verbose output

### Common Patterns

#### Create Directory Structure
```bash
mkdir -p project/{src,test,docs}
```

#### Copy with Progress
```bash
cp -rv source/ destination/
```

#### Find and Process
```bash
find . -name "*.txt" -exec echo {} \;
```

#### Backup Before Edit
```bash
cp file.txt file.txt.bak
```

## Error Handling

- Always check exit codes
- Use `&&` to chain dependent commands
- Log operations for audit trail
