---
name: bash-helper
description: This skill should be used when the user asks to "run a command", "execute bash", "use terminal", or needs help with Linux commands. Provides guidance on safe bash execution.
version: 1.0.0
---

# Bash Helper Skill

Helps with executing bash commands safely and effectively.

## When This Skill Applies

- User asks to run shell commands
- User needs help with Linux/Unix commands
- User wants to automate tasks via bash

## Guidelines

1. Always explain what a command does before running it
2. Use `--dry-run` flags when available
3. Avoid destructive commands without confirmation
4. Quote variables properly to prevent injection
5. Use `set -e` for scripts that should fail fast

## Common Patterns

### File Operations
```bash
# List files
ls -la

# Find files
find . -name "*.dart" -type f

# Search in files
grep -r "pattern" .
```

### System Info
```bash
# Disk usage
df -h

# Memory
free -h

# Processes
ps aux
```

### Git
```bash
git status
git add .
git commit -m "message"
git push
```

## Safety Rules

- Never run `rm -rf /` or similar destructive commands
- Always backup before mass operations
- Use `sudo` only when absolutely necessary
- Check command output before piping to destructive operations
