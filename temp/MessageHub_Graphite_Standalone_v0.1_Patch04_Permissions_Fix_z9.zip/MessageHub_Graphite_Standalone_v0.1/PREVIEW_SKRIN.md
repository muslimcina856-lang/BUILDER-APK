# PREVIEW SKRIN — Graphite Tech

**Nota:** Ini wireframe berasaskan spesifikasi dan source Compose. Ia BUKAN tangkapan skrin APK yang telah diuji. Tiada imej dihasilkan kerana pengguna belum meminta imej.

## 01 — Dashboard

- Header: MESSAGE HUB, Node.js versi / engine status, pilihan akaun semasa (Semua / A / B...)
- Cards: Akaun, Connected, Group, Kempen
- Tindakan utama: `+ New Broadcast`
- Senarai akaun: alias, telefon, status sebenar
- Kad status enjin Node.js & memori proses
- Navigasi: Dashboard | Groups | Campaigns | History | Settings

## 02 — Connect WhatsApp

- Input alias dan nombor format antarabangsa tanpa +
- Tab Pairing Code / QR Code
- Status akaun / kod pairing sebenar atau QR sebenar (ketika WA connected)
- Butang Minta Kod Baharu / Sambung Semula

## 03 — Account Manager (Hybrid)

- Senarai akaun & status, butang `Switch` untuk aktif/jeda
- Pilih akaun UI berasingan daripada keadaan engine
- Tambah akaun, Unlink, Buang akaun dengan pengesahan

## 04 — Group Manager

- Search bar
- Filter All / Admin / Announcement / Dibenarkan
- Setiap group: nama, akaun penghantar, bilangan ahli, admin, announcement
- Checkbox izin = dialog pengesahan, boleh tarik balik izin
- Tap nama = butiran JID & status

## 05 — Broadcast Composer

- Tajuk & kandungan teks
- Pilih lampiran (image, video, dokumen <=15MB)
- Pilih group yang dibenarkan (merentas akaun, dedup jid)
- Pilihan masa sekarang / 5 / 15 / 60 minit
- Preview mesej, kemudian dialog Sahkan

## 06 — Campaigns

- Kad kempen DRAFT / SCHEDULED / RUNNING / PAUSED / COMPLETED / CANCELLED
- Progress (sent/failed/unknown), aksi Mula / Sambung / Jeda / Batal
- Semua perubahan berrekod dalam SQLite

## 07 — History & Logs

- Penapis akaun, tab Messages / Activity
- Setiap cubaan: nama kempen, JID, status, masa, error, message id
- Export CSV untuk mesej dan log tanpa kredensial

## 08 — Templates

- Cipta / edit / delete template
- Guna template terus di Broadcast Composer

## 09 — Settings & Diagnostics

- Account Manager & Templates
- Runtime Ready / Offline, Node version, memory, sesi aktif
- Perlindungan app PIN pilihan, nota keselamatan
- Jeda semua akaun

## Tokens design

- Background: #101418
- Surface: #1B242B
- Raised: #26313B
- Cyan: #22D3EE
- Success: #34D399
- Warning: #FBBF24
- Error: #FB7185
- Text: #F3F6F8
- Card radius: 18dp
- Touch target min: 48dp
