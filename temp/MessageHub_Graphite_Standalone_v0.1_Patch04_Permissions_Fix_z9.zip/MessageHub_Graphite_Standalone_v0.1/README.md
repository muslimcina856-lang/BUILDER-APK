# Message Hub — Graphite Tech (Android APK Standalone, Multi-Account Hybrid)

> **STATUS TEKNIKAL: SOURCE PROJECT / ENGINE IMPLEMENTED, APK BELUM DIBINA DAN BELUM DIVERIFIKASI PADA WHATSAPP SEBENAR.**
>
> Projek ini sengaja **tidak menyamar** sebagai APK yang telah diuji. Persekitaran penyediaan fail tidak mempunyai Android SDK/Gradle, akses npm, atau fail binari libnode untuk membina APK. `verifyBundledRuntime` akan menghentikan binaan sekiranya kebergantungan penting tiada.

## Ringkasan keputusan yang dikekalkan

| Perkara | Keputusan |
|---|---|
| Platform | Android native Kotlin + Jetpack Compose (bukan WebView/HTML) |
| Seni bina | APK standalone sepenuhnya, tiada VPS, tiada Vercel |
| Reka bentuk | Graphite Tech: graphite gelap, cyan, hijau, merah |
| WhatsApp | Banyak akaun, mod **Hybrid** (aktifkan/pause setiap akaun secara manual) |
| Engine | Satu proses Node.js Mobile, banyak socket Baileys berasingan |
| Versi Baileys | `@whiskeysockets/baileys: 6.7.9` **dipin sebagai calon ujian**, bukan dijamin kompatibel dengan protokol WA kini |
| Runtime Android | `nodejs-mobile v18.20.4` arm64 (binari luar projek mesti dipasang) |
| Storage | SQLite tempatan; kelayakan auth disulitkan dengan Android Keystore AES-GCM |
| Penghantaran | Hanya sasaran group yang pengguna tandakan sebagai dibenarkan |
| Background | **Best effort sahaja.** Tertakluk sekatan Android; tidak menjamin 24/7. |
| Pakej aplikasi | `com.earlxcode.messagehub`, `versionCode=1`, `versionName=0.1.0` (projek baharu) |

## Apa yang sudah ditulis dalam source

1. UI native: Dashboard, Connect WhatsApp, Account Manager, Groups, Broadcast Composer, Campaigns, History, Templates dan Settings (Graphite Tech).
2. Node runtime JNI/CMake, pengurusan aset Node ke storan private, foreground service dan bridge HTTP loopback bertoken.
3. Pengasingan akaun: Baileys Socket berasingan untuk setiap account ID, butang activate/pause/unlink, reconnect terbatas.
4. Pairing Code dan QR Code (QR dijana **daripada nilai pairing sebenar**, bukan QR palsu).
5. Cache group, pengesahan kebenaran, tempatan opt-out, broadcast teks, image, video dan dokumen maksimum 15 MB.
6. Template mesej, jadual best-effort (sekarang/5/15/60 minit), queue yang boleh dijeda atau dibatalkan, penyahduaan group JID merentas akaun.
7. Status queue: DRAFT/SCHEDULED/RUNNING/PAUSED/COMPLETED/CANCELLED dan PENDING/SENDING/SENT/FAILED/UNKNOWN untuk sasaran. Jika aplikasi tamat ketika `SENDING`, ia menjadi `UNKNOWN`, **tidak diulang hantar secara automatik**.
8. Penyulitan auth state dengan Android Keystore, sandaran dimatikan, port 127.0.0.1 dengan token sementara; PIN pilihan.
9. Node tests dengan mock socket yang boleh dijalankan tanpa akaun WhatsApp.

## Batasan yang BELUM lengkap / disahkan

- **Tiada APK yang boleh dipasang di dalam ZIP ini.** Binari Node.js Android dan npm dependencies tidak boleh dimuat turun dalam persekitaran pembinaan ini, SDK Android juga tiada. Projek belum menjalani Gradle build atau ujian peranti.
- Baileys 6.7.9 sudah lama; WhatsApp boleh mengubah protokol. Versi lama yang *boleh dipasang* tidak semestinya *boleh login* pada 2026. Jangan guna akaun utama sebelum ujian.
- Kompatibiliti `nodejs-mobile v18.20.4` terhadap Android 16, 16KB page size dan dependensi npm perlu diperiksa secara berasingan.
- Pengesahan **pairing QR/kod, group sync, penghantaran media dan reconnect sebenar belum dijalankan**. Unit test menggunakan fake Baileys sahaja.
- Engine Node mobile boleh dimulakan sekali setiap proses aplikasi; `Stop Engine` adalah **jeda socket**, bukan mematikan Node kemudian restart Node dalam proses sama.
- Ujian app screen pada emulator, AAB/Google Play policy, serta analisis aksesibiliti pada peranti belum dibuat. Ikon launcher telah ditambah, tetapi penampilannya pada peranti belum diuji.
- PIN tersedia, biometrik **belum dilaksanakan**. Eksport CSV sejarah tersedia; paparan `delivered/read` sebenar, auto-reply keyword dan penghantaran ke nombor individu belum dilaksanakan (tidak dianggap fungsi siap).
- Jadual bergantung kepada foreground service aktif. Jika Android force-stop aplikasi, jadual tidak berjalan.
- Foreground service `dataSync` tidak boleh digunakan tanpa had 24/7 dalam Android terkini, dan jenis servis serta cara penggunaan perlu dinilai terhadap polisi Google Play sebelum penerbitan.
- `targetSdk=35` ialah baseline pembangunan, bukan jaminan mematuhi syarat Google Play selepas 2026. Bump target hanya selepas keserasian diuji.
- `node_modules`, `.so`, Gradle distribution, SDK dan `gradle-wrapper.jar` **tidak termasuk** kerana memerlukan muat turun luar. Ini bukan "full offline build".

## Prasyarat developer (perlu internet komputer)

- Android Studio baharu dengan JDK 17/21, Android SDK platform 35, Android NDK, CMake 3.22.1.
- Gradle 8.7 dipasang pada komputer atau hasilkan wrapper dengan `gradle wrapper --gradle-version 8.7`. Repo mengandungi `gradle/wrapper/gradle-wrapper.properties` tetapi **belum** mengandungi `gradle-wrapper.jar`.
- Node.js + npm pada komputer, `git`, `unzip`, `python3` untuk script.
- `nodejs-mobile` Android release archive v18.20.4 daripada https://github.com/nodejs-mobile/nodejs-mobile/releases/tag/v18.20.4 (pastikan memilih aset **Android**, bukan iOS).
- Internet untuk `npm install` kerana package Baileys 6.7.9 mempunyai dependency GitHub.
- Peranti Android ARM64 untuk ujian. JANGAN anggap Android 16 atau sokongan 16KB akan berfungsi sehingga disahkan.

## Langkah build pada komputer

```bash
unzip MessageHub_Graphite_Standalone_v0.1_Patch04_Permissions_Fix.zip
cd MessageHub_Graphite_Standalone_v0.1

# 1. Pasang library Node Mobile ANDROID v18.20.4 (archive rasmi yang sudah dimuat turun).
bash scripts/install-libnode.sh /path/to/ANDROID_NODEJS_MOBILE_ARCHIVE.zip

# 2. Pasang pakej Baileys versi tetap + dependency.
bash scripts/prepare-engine.sh

# 3. Bina APK dengan Gradle 8.7 dan Android SDK.
export ANDROID_HOME=/path/to/Android/Sdk
bash scripts/build-android.sh
```

**Jika menggunakan Android Studio:** Open folder root sebagai Gradle project, pastikan Gradle 8.7 tersedia (generate wrapper jika perlu), install SDK/NDK/CMake, pastikan dua langkah prasyarat di atas telah dijalankan, kemudian Build > Build APK(s).

Hasil yang disasarkan: `app/build/outputs/apk/debug/app-debug.apk` **hanya jika binaan benar-benar berjaya.** Jangan gunakan lokasi ini sebagai bukti bahawa fail tersebut wujud dalam ZIP sekarang.

## Ujian yang boleh dijalankan sekarang

```bash
bash scripts/test.sh
```

Ini menjalankan Node.js `node:test` untuk polisi JID, had media, pengasingan akaun, bridge, auth state mock, dan `tests/static_checks.py` untuk pemeriksaan static. **Tidak memerlukan sesi WA**.

Untuk ujian Android sebenar, ikut `docs/TESTING.md`. Semua ujian device adalah *pending* sehingga dilaksanakan secara nyata.

## Cara penggunaan selepas build berjaya dan runtime benar-benar disahkan

1. Buka APK, benarkan notifikasi (pilihan) dan lihat status engine.
2. Connect WhatsApp > masukkan alias & nombor antarabangsa tanpa `+` > Pairing Code atau QR.
3. Selepas status Connected, Groups > Sync, kemudian tandakan hanya group yang benar-benar memberi izin.
4. Dari dashboard, pilih New Broadcast > teks / fail > pilih group yang dibenarkan > semak preview dan sahkan.
5. Gunakan Campaigns untuk jeda, sambung atau batal. Jika `UNKNOWN`, jangan anggap mesej tidak dihantar.
6. Gunakan Account Manager untuk mengaktifkan/pause beberapa akaun Hybrid tanpa menggugurkan sesi akaun lain.

## Keamanan dan polisi

- Node endpoint dan Android bridge hanya bind `127.0.0.1`; token rawak 256 bit dijana untuk setiap start proses. Jangan buka port pada rangkaian atau buang token check.
- Auth state individu disimpan melalui Android-side Keystore, tidak dalam folder `nodejs-project` yang mungkin ditimpa semasa update APK.
- Aplikasi menolak sasaran JID bukan group, memerlukan kebenaran group, dan memproses queue satu demi satu. Ini bukan sistem untuk spam, mengelakkan rate limit, atau menghindari ban WhatsApp.
- Baileys bukan WhatsApp Business API rasmi. Penggunaan automasi/broadcast boleh melanggar terma WhatsApp dan menyebabkan sekatan.

## Fail penting

- `app/src/main/java/com/earlxcode/messagehub/ui/` — UI native & ViewModel.
- `app/src/main/java/com/earlxcode/messagehub/data/` — SQLite, Keystore & PIN.
- `app/src/main/java/com/earlxcode/messagehub/bridge/` — Node client + Android host.
- `app/src/main/java/com/earlxcode/messagehub/service/` — Node runtime + queue.
- `app/src/main/cpp/native-lib.cpp` & `app/CMakeLists.txt` — JNI bridge.
- `app/src/main/assets/nodejs-project/` — Baileys adapter, auth & HTTP API.
- `tests/` — tests yang boleh dijalankan tanpa Android SDK.

Sila rujuk `docs/ARCHITECTURE.md`, `docs/TESTING.md`, `docs/SECURITY.md` dan `docs/BUILD_MATRIX.md` untuk penjelasan lanjut.

## Ikon Android (ditambah selepas source asal)

Ikon Graphite Tech tanpa tulisan disediakan pada `assets/MessageHub_Icon_GraphiteTech_1024.png` (1024×1024). Resource launcher telah dipasang di `app/src/main/res/mipmap-*`, `mipmap-anydpi-v26` dan `drawable-nodpi`; AndroidManifest kini merujuk `@mipmap/ic_launcher` dan `@mipmap/ic_launcher_round`. Tiada perubahan dibuat pada nama package, versionCode, versionName, fungsi WhatsApp atau kod enjin.


## Patch 02 - Auto setup runtime + UI Graphite Tech polish

`assembleDebug` kini memanggil `prepareBundledRuntime` sebelum `verifyBundledRuntime`.
Ia mengesan `libnode.so` ARM64, `node.h` dan package Baileys. Jika tiada, build cuba memuat turun **Android release rasmi nodejs-mobile v18.20.4** dari GitHub serta menjalankan `npm install` melalui `scripts/prepare-engine.sh`.

**Prasyarat di komputer build:** Python 3, Node.js/npm, git, internet ke GitHub dan npm. Jika build host tiada internet, muat turun Android ZIP daripada https://github.com/nodejs-mobile/nodejs-mobile/releases/tag/v18.20.4 dan set `NODE_MOBILE_ARCHIVE=/path/to/android.zip` sebelum build. Jangan gunakan ZIP iOS.

Auto-setup tidak memalsukan library atau memintas pemeriksaan; jika dependency gagal dimuat turun, build tetap gagal dengan arahan yang lebih jelas. Keserasian Android (terutamanya Android 16 dan memory page 16 KB) dan login WhatsApp masih memerlukan ujian pada peranti.

Peningkatan UI terhad kepada tipografi Graphite Tech, kemasan kad dan ringkasan enjin di Dashboard; skrin, fungsi, package ID dan nombor versi kekal sama.


## Patch 03 — Pembaikan pembaca arkib ARM64 (2026-10-18)

Patch 02 gagal pada `:app:prepareBundledRuntime` dengan mesej `Unexpected archive layout: libnode.so or node.h missing` walaupun ZIP Android berjaya dimuat turun. Pembaca ZIP dahulu memerlukan akhiran `/include/node/node.h` dengan slash awal; fail sebenar boleh bermula terus pada `include/node/node.h`, atau berada dalam folder tambahan. Kod baharu menggunakan segmen laluan ZIP, bukan `endswith` yang sensitif kepada kedudukan root.

- `scripts/runtime_archive.py` ialah pemasang/pengesah tunggal bagi **arkib Android ARM64**. Menerima `include/node/node.h`, `include/node.h`, folder pembungkus dan beberapa variasi root.
- `scripts/download-node-mobile.py` masih mengambil release rasmi `nodejs-mobile v18.20.4`, kemudian menggunakan pemasang sama. `scripts/install-libnode.sh` juga menggunakan pengesah sama untuk ZIP manual.
- `scripts/auto-prepare-runtime.sh` akan menguji ELF AArch64 + header sebenar dan menjalankan auto-setup jika runtime tiada atau tidak sah. Fail palsu tidak boleh meluluskan pengesahan baharu ini.
- `tests/test_runtime_archive.py` menyediakan ujian regresi tanpa internet. Jalankan `bash scripts/test.sh` untuk semua ujian.

**Cuba bina semula daripada ZIP Patch 03**; pastikan folder build tidak bercampur dengan Patch 02 lama. Jangan salin hanya `app/build.gradle.kts`, kerana pembetulan ini berada dalam `scripts/`.

Jika menggunakan arkib Android yang telah dimuat turun, pada shell Linux/macOS:

```bash
export NODE_MOBILE_ARCHIVE=/path/to/nodejs-mobile-v18.20.4-android.zip
bash scripts/auto-prepare-runtime.sh
./gradlew :app:assembleDebug
```

Jika `gradlew` tiada seperti dalam ZIP asal, gunakan wrapper yang dihasilkan oleh build host atau jalankan melalui Android Studio. Build masih memerlukan SDK/NDK/CMake dan pemasangan npm. Fail `.so` rasmi tidak disertakan dalam ZIP sumber. **Ujian parser sahaja tidak membuktikan build APK atau login WhatsApp berjaya.**


## Patch 04 — Shell permission / GitHub Actions ZIP extraction (2026-10-18)

Jika `:app:prepareBundledRuntime` melaporkan `prepare-engine.sh: Permission denied`, binaan sebenarnya sudah melepasi pemasangan Android `libnode.so`, tetapi fail `.sh` mungkin kehilangan bit executable semasa ZIP diekstrak oleh runner. Skrip utama kini menggunakan `bash` secara eksplisit ketika memanggil `scripts/prepare-engine.sh` dan `scripts/install-libnode.sh`. Ini mengelakkan kebergantungan pada `chmod +x` di GitHub Actions dan mengekalkan semakan runtime sebelum build.

Jangan buang `verifyBundledRuntime`; fail `.so` dan Baileys masih perlu wujud dan sah. Cara menjalankan secara manual tanpa permission executable:

```bash
bash scripts/auto-prepare-runtime.sh
bash scripts/test.sh
```

`tests/test_shell_permissions.py` menjalankan ujian regresi tanpa internet: kedua-dua skrip anak diset `0644` seperti apabila ZIP extractor membuang bit executable, kemudian auto-prepare dipanggil dengan `bash` menggunakan arkib ELF ARM64 dan npm tiruan. Ia **bukan** bukti Baileys telah dihubungkan dengan WhatsApp atau binaan APK penuh berjaya.
