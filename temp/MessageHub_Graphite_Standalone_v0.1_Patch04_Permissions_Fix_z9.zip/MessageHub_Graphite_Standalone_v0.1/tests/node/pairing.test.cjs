const {test}=require('node:test');
const assert=require('node:assert/strict');
const EventEmitter=require('node:events');
const {AccountRegistry}=require('../../app/src/main/assets/nodejs-project/accounts');
const A='11111111-1111-4111-8111-111111111111';
test('manual requestPairingCode on linked socket reports code only to its account',async()=>{
  const events=[];
  const host={notify:async(a,t,p)=>events.push({a,t,...p}),getAuth:async()=>({value:null}),setAuth:async()=>{}};
  const baileys={initAuthCreds:()=>({registered:false}),BufferJSON:{replacer:(k,v)=>v,reviver:(k,v)=>v},proto:{Message:{AppStateSyncKeyData:{fromObject:x=>x}}}};
  const sock={ev:new EventEmitter(),requestPairingCode:async ()=>'12345678',end:()=>{}};
  const registry=new AccountRegistry({host,baileys,logger:{},filesDir:'/tmp',makeSocket:()=>sock});
  await registry.activate(A,'60112233445');
  assert.equal((await registry.requestCode(A)).code,'12345678');
  assert.ok(events.some(e=>e.a===A&&e.code==='12345678'));
  await registry.pause(A);
});
