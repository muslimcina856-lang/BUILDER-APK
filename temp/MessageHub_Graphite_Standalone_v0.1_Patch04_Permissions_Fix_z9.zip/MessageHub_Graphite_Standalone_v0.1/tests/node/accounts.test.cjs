const {test}=require('node:test');
const assert=require('node:assert/strict');
const EventEmitter=require('node:events');
const {AccountRegistry}=require('../../app/src/main/assets/nodejs-project/accounts');
const {createServer,constantTimeEquals}=require('../../app/src/main/assets/nodejs-project/main');
const http=require('node:http');

function fixture() {
  const events=[];const saved=new Map();const sockets=[];
  const host={
    notify:async (accountId,type,info)=>{events.push({accountId,type,...info});},
    getAuth:async (accountId,key)=>({value:saved.get(`${accountId}:${key}`) || null}),
    setAuth:async (accountId,key,value)=>{saved.set(`${accountId}:${key}`,value);},
    clearAuth:async accountId=>{for(const key of saved.keys())if(key.startsWith(`${accountId}:`))saved.delete(key)}
  };
  const baileys={
    initAuthCreds:()=>({registered:true}),
    BufferJSON:{replacer:(k,v)=>v,reviver:(k,v)=>v},
    proto:{Message:{AppStateSyncKeyData:{fromObject:v=>v}}},
    default:()=>{
      const ev=new EventEmitter();
      const sock={ev,user:{id:'user@s.whatsapp.net'},end:()=>{},logout:async()=>{},
        groupFetchAllParticipating:async()=>({"12036302500000@g.us":{
          id:'12036302500000@g.us',subject:'Group Testing',participants:[{id:'user@s.whatsapp.net',admin:'admin'}]}}),
        sendMessage:async()=>({key:{id:'id123'}})
      };
      sockets.push(sock);return sock;
    }
  };
  const registry=new AccountRegistry({host,baileys,logger:{},filesDir:'/tmp'});
  return {registry,events,sockets,saved};
}
const A='11111111-1111-4111-8111-111111111111';
const B='22222222-2222-4222-8222-222222222222';
test('hybrid: activating B does not disconnect A; pausing A does not disconnect B',async()=>{
  const {registry,events,sockets}=fixture();
  await registry.activate(A);await registry.activate(B);
  assert.equal(sockets.length,2);
  sockets[0].ev.emit('connection.update',{connection:'open'});
  sockets[1].ev.emit('connection.update',{connection:'open'});
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(registry.status().filter(x=>x.status==='CONNECTED').length,2);
  await registry.pause(A);
  assert.equal(registry.status().find(x=>x.accountId===A).status,'PAUSED');
  assert.equal(registry.status().find(x=>x.accountId===B).status,'CONNECTED');
});
test('groups returned belong to active sender; send rejects non-group',async()=>{
  const {registry,sockets}=fixture();
  await registry.activate(A);
  sockets[0].ev.emit('connection.update',{connection:'open'});
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal((await registry.groups(A))[0].admin,true);
  await assert.rejects(()=>registry.sendMessage({accountId:A,jid:'person@s.whatsapp.net',text:'hello'}),/GROUP_REQUIRED/);
  assert.equal((await registry.sendMessage({accountId:A,jid:'12036302500000@g.us',text:'Test'})).messageId,'id123');
});
test('bridge rejects incorrect token and accepts valid health on loopback',async()=>{
  const {registry}=fixture();const token='a'.repeat(64);
  const server=createServer({registry,token,port:0});
  await new Promise(resolve=>server.once('listening',resolve));
  const port=server.address().port;
  async function query(value){return new Promise((resolve,reject)=>{
    http.get({host:'127.0.0.1',port,path:'/health',headers:{'X-Bridge-Token':value}},res=>{
      let data='';res.on('data',chunk=>data+=chunk);res.on('end',()=>resolve({code:res.statusCode,json:JSON.parse(data)}));
    }).on('error',reject);
  });}
  try {
    assert.equal((await query('invalid')).code,401);
    assert.equal((await query(token)).json.engine,'ready');
    assert.equal(constantTimeEquals(token,token),true);
    assert.equal(constantTimeEquals(token,'b'.repeat(64)),false);
  } finally {server.close();}
});
