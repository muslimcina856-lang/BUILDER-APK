const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createAuthState}=require('../../app/src/main/assets/nodejs-project/auth');
const A='11111111-1111-4111-8111-111111111111';
const B='22222222-2222-4222-8222-222222222222';
test('Baileys auth state persists per account separately via Android vault interface', async()=>{
  const encryptedVault=new Map();
  const host={
    getAuth:async (id,key)=>({value:encryptedVault.get(`${id}:${key}`)||null}),
    setAuth:async (id,key,value)=>{encryptedVault.set(`${id}:${key}`,value)}
  };
  const baileys={initAuthCreds:()=>({registered:false,counter:0}),
    BufferJSON:{replacer:(k,v)=>v,reviver:(k,v)=>v},
    proto:{Message:{AppStateSyncKeyData:{fromObject:v=>v}}}};
  const a=await createAuthState(baileys,host,A);
  const b=await createAuthState(baileys,host,B);
  a.state.creds.counter=42;
  await a.saveCreds();
  await a.state.keys.set({session:{abc:{secret:99}}});
  assert.equal((await createAuthState(baileys,host,A)).state.creds.counter,42);
  assert.equal((await createAuthState(baileys,host,B)).state.creds.counter,0);
  assert.deepEqual((await a.state.keys.get('session',['abc'])).abc,{secret:99});
});
