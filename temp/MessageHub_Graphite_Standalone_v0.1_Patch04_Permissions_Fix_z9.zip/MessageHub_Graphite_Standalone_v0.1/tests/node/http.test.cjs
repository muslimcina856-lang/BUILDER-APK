const {test}=require('node:test');
const assert=require('node:assert/strict');
const http=require('node:http');
const {createServer}=require('../../app/src/main/assets/nodejs-project/main');
const token='z'.repeat(64);
async function withServer(fn){
 const registry={status:()=>[],pauseAll:async()=>({status:'PAUSED'}),sendMessage:async input=>{
   if(!input.jid.endsWith('@g.us'))throw Error('GROUP_REQUIRED');return {messageId:'id123'};
 }};
 const server=createServer({registry,token,port:0});
 await new Promise(r=>server.once('listening',r));
 try{await fn(server.address().port)}finally{server.close()}
}
async function post(port,path,body,headToken=token){
 return new Promise((resolve,reject)=>{
  const data=JSON.stringify(body);
  const req=http.request({hostname:'127.0.0.1',port,method:'POST',path,headers:{
   'X-Bridge-Token':headToken,'Content-Type':'application/json','Content-Length':Buffer.byteLength(data)
  }},res=>{let result='';res.on('data',d=>result+=d);res.on('end',()=>resolve({code:res.statusCode,body:JSON.parse(result)}));});
  req.on('error',reject);req.end(data);
 });
}
test('rejects unauthenticated POST and unrecognized routes',async()=>{
 await withServer(async port=>{
  assert.equal((await post(port,'/accounts/pause-all',{},'wrong')).code,401);
  assert.equal((await post(port,'/unknown',{})).code,404);
  assert.equal((await post(port,'/accounts/pause-all',{})).body.status,'PAUSED');
 });
});
test('invalid WhatsApp group send fails validation with HTTP 400',async()=>{
 await withServer(async port=>{
  const res=await post(port,'/messages/send',{jid:'123@s.whatsapp.net',text:'Hello'});
  assert.equal(res.code,400);
  assert.equal(res.body.error,'GROUP_REQUIRED');
 });
});
