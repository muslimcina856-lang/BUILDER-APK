const { test } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const policy = require('../../app/src/main/assets/nodejs-project/policy');

test('phone numbers accept international digits only', () => {
  assert.equal(policy.validatePhone('60123456789'), '60123456789');
  assert.throws(() => policy.validatePhone('+60123456789'));
  assert.throws(() => policy.validatePhone('123'));
  assert.throws(() => policy.validatePhone('601233333;rm -rf'));
});
test('recipient must be an approved group, never an arbitrary JID', () => {
  assert.equal(policy.validateGroupJid('12036302500000@g.us'), '12036302500000@g.us');
  assert.throws(() => policy.validateGroupJid('60123456789@s.whatsapp.net'));
  assert.throws(() => policy.validateGroupJid('../etc/passwd'));
});
test('attachment must reside inside private folder', () => {
  const root='/data/user/0/com.earlxcode.messagehub/files/attachments';
  assert.equal(policy.resolveAttachment(root,'image', path.join(root,'a.jpg')).startsWith(root),true);
  assert.throws(() => policy.resolveAttachment(root,'image','/sdcard/Download/secret.jpg'));
  assert.throws(() => policy.resolveAttachment(root,'image',path.join(root,'..','bridge.token')));
});
test('text or attachment is required and text has limit', () => {
  assert.throws(() => policy.validatePayload({ text: '' }));
  assert.equal(policy.validatePayload({text:'hello'}).text, 'hello');
  assert.throws(() => policy.validatePayload({text:'x'.repeat(16385)}));
});
test('deduplicates group targets without adding sender accounts', () => {
  const input=[{accountId:'A',jid:'120001@g.us'},{accountId:'B',jid:'120001@g.us'}, {accountId:'B',jid:'120002@g.us'}];
  assert.deepEqual(policy.dedupeTargets(input).map(x=>x.jid),['120001@g.us','120002@g.us']);
});
