from pathlib import Path
import json, re, sys
root=Path(__file__).resolve().parents[1]
fail=[]
checks={
  'node binary build gate': 'verifyBundledRuntime' in (root/'app/build.gradle.kts').read_text(),
  'no exported local bridge': 'android:exported="false"' in (root/'app/src/main/AndroidManifest.xml').read_text(),
  'backup disabled': 'android:allowBackup="false"' in (root/'app/src/main/AndroidManifest.xml').read_text(),
  'node loopback binding': "'127.0.0.1'" in (root/'app/src/main/assets/nodejs-project/main.js').read_text(),
  'bridge access token': 'timingSafeEqual' in (root/'app/src/main/assets/nodejs-project/main.js').read_text(),
  'no auto retry UNKNOWN': "'UNKNOWN'" in (root/'app/src/main/java/com/earlxcode/messagehub/data/LocalDb.kt').read_text(),
  'Baileys pinned 6.7.9': json.loads((root/'app/src/main/assets/nodejs-project/package.json').read_text())['dependencies']['@whiskeysockets/baileys']=='6.7.9',
  'encrypted auth at rest': 'AndroidKeyStore' in (root/'app/src/main/java/com/earlxcode/messagehub/data/SecureVault.kt').read_text(),
  'no included sensitive data': not list(root.rglob('bridge.token')),
}
for name,passed in checks.items():
    print(('PASS' if passed else 'FAIL')+' '+name)
    if not passed: fail.append(name)
if fail: sys.exit(1)
