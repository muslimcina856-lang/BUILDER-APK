"""Regression for ZIP/GitHub Actions extraction that strips executable bits.

The build task invokes the top-level script with `bash`, but that script
must also invoke its child shell scripts with `bash` to survive mode 0644.
All dependencies are local synthetic fixtures; no network or WhatsApp used.
"""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from test_runtime_archive import archive_at

ROOT = Path(__file__).resolve().parent.parent


class ZipExtractedScriptPermissionTests(unittest.TestCase):
    def _fixture(self, temp: Path):
        project = temp / "extracted"
        scripts = project / "scripts"
        scripts.mkdir(parents=True)
        for name in ("auto-prepare-runtime.sh", "prepare-engine.sh", "install-libnode.sh", "runtime_archive.py"):
            shutil.copy2(ROOT / "scripts" / name, scripts / name)
            if name.endswith(".sh"):
                (scripts / name).chmod(0o644)  # ZIP extraction without executable bit
        engine = project / "app/src/main/assets/nodejs-project"
        engine.mkdir(parents=True)
        shutil.copy2(ROOT / "app/src/main/assets/nodejs-project/package.json", engine / "package.json")
        stub = temp / "bin"
        stub.mkdir()
        npm = stub / "npm"
        npm.write_text(
            "#!/bin/sh\n"
            "mkdir -p node_modules/@whiskeysockets/baileys/lib\n"
            "printf '// test only\\n' > node_modules/@whiskeysockets/baileys/lib/index.js\n"
        )
        npm.chmod(0o755)
        env = dict(os.environ, PATH=f"{stub}{os.pathsep}{os.environ['PATH']}")
        return project, engine, env

    def _run(self, project: Path, env: dict):
        return subprocess.run(
            ["bash", str(project / "scripts/auto-prepare-runtime.sh")],
            cwd=project,
            env=env,
            capture_output=True,
            text=True,
            timeout=30,
        )

    def test_prepare_engine_with_no_executable_permission(self):
        with tempfile.TemporaryDirectory() as td:
            temp = Path(td)
            project, engine, env = self._fixture(temp)
            archive = temp / "official-layout.zip"
            archive_at(archive)
            installed = subprocess.run(
                [sys.executable, str(project / "scripts/runtime_archive.py"), "install", str(archive), str(project / "app/libnode")],
                capture_output=True, text=True,
            )
            self.assertEqual(installed.returncode, 0, installed.stderr)
            result = self._run(project, env)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertTrue((engine / "node_modules/@whiskeysockets/baileys/lib/index.js").is_file())

    def test_install_runtime_and_engine_with_no_executable_permission(self):
        with tempfile.TemporaryDirectory() as td:
            temp = Path(td)
            project, engine, env = self._fixture(temp)
            archive = temp / "official-layout.zip"
            archive_at(archive)
            env["NODE_MOBILE_ARCHIVE"] = str(archive)
            result = self._run(project, env)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            self.assertTrue((project / "app/libnode/bin/arm64-v8a/libnode.so").is_file())
            self.assertTrue((engine / "node_modules/@whiskeysockets/baileys/lib/index.js").is_file())


if __name__ == "__main__":
    unittest.main()
