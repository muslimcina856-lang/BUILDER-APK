"""Regression cases for Android Node Mobile release ZIP installers (no network)."""
import importlib
import pathlib
import struct
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))


def fake_elf(machine=183):
    data = bytearray(120_000)
    data[:4] = b"\x7fELF"
    data[4] = 2  # ELFCLASS64
    data[5] = 1  # little endian
    struct.pack_into("<H", data, 18, machine)
    return bytes(data)


def archive_at(path, prefix="", *, header="include/node/node.h", machine=183, missing_header=False, malicious=False):
    files = {f"{prefix}bin/arm64-v8a/libnode.so": fake_elf(machine=machine)}
    if not missing_header:
        files[f"{prefix}{header}"] = b"// Test Android Node header\n"
        uv_path = "include/uv.h" if header == "include/node.h" else "include/node/uv.h"
        files[f"{prefix}{uv_path}"] = b"// Test dependency\n"
    if malicious:
        files[f"{prefix}include/node/../escape.txt"] = b"invalid zip path"
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_STORED) as bundle:
        for name, data in files.items():
            bundle.writestr(name, data)


class AndroidArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This module deliberately must exist in the updated project.
        cls.mod = importlib.import_module("runtime_archive")

    def test_headers_at_archive_root(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip")
            self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.mod.verify_install(temp / "libnode")
            self.assertEqual((temp / "libnode/bin/arm64-v8a/libnode.so").read_bytes()[:4], b"\x7fELF")
            self.assertTrue((temp / "libnode/include/node/node.h").is_file())
            self.assertTrue((temp / "libnode/include/node/uv.h").is_file())

    def test_single_wrapping_folder(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip", prefix="nodejs-mobile-v18.20.4-android/")
            self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.assertTrue((temp / "libnode/include/node/node.h").exists())

    def test_flat_include_node_h_layout(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip", header="include/node.h")
            self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.assertTrue((temp / "libnode/include/node/node.h").exists())
            self.assertTrue((temp / "libnode/include/node/uv.h").exists())

    def test_missing_header_is_rejected_without_partial_install(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip", missing_header=True)
            with self.assertRaisesRegex(self.mod.ArchiveError, "node.h"):
                self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.assertFalse((temp / "libnode/bin/arm64-v8a/libnode.so").exists())

    def test_wrong_architecture_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip", machine=62)
            with self.assertRaisesRegex(self.mod.ArchiveError, "AArch64"):
                self.mod.install_archive(temp / "android.zip", temp / "libnode")

    def test_unsafe_header_path_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip", malicious=True)
            with self.assertRaisesRegex(self.mod.ArchiveError, "Unsafe"):
                self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.assertFalse((temp / "escape.txt").exists())

    def test_binary_and_headers_can_have_separate_wrapping_directories(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            with zipfile.ZipFile(temp / "android.zip", "w") as zf:
                zf.writestr("android/bin/arm64-v8a/libnode.so", fake_elf())
                zf.writestr("include/node/node.h", b"// header\n")
            self.mod.install_archive(temp / "android.zip", temp / "libnode")
            self.mod.verify_install(temp / "libnode")

    def test_cli_install_and_verify(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip")
            target = temp / "libnode"
            install = subprocess.run([sys.executable, str(ROOT / "scripts/runtime_archive.py"),
                                      "install", str(temp / "android.zip"), str(target)],
                                     text=True, capture_output=True)
            self.assertEqual(install.returncode, 0, install.stderr)
            verify = subprocess.run([sys.executable, str(ROOT / "scripts/runtime_archive.py"),
                                     "verify", str(target)], text=True, capture_output=True)
            self.assertEqual(verify.returncode, 0, verify.stderr)

    def test_file_type_missing_cannot_be_passed_as_elf(self):
        with tempfile.TemporaryDirectory() as td:
            temp = pathlib.Path(td)
            archive_at(temp / "android.zip")
            with zipfile.ZipFile(temp / "android.zip") as bundle:
                contents = {n: bundle.read(n) for n in bundle.namelist()}
            contents["bin/arm64-v8a/libnode.so"] = b"NOT_AN_ELF"
            with zipfile.ZipFile(temp / "bad.zip", "w") as bundle:
                for n, b in contents.items():
                    bundle.writestr(n, b)
            with self.assertRaisesRegex(self.mod.ArchiveError, "ELF"):
                self.mod.install_archive(temp / "bad.zip", temp / "libnode")


if __name__ == "__main__":
    unittest.main()
