'use strict';
const fs = require('node:fs');
const http = require('node:http');
const crypto = require('node:crypto');
const path = require('node:path');
const { AndroidHost } = require('./host');
const { AccountRegistry } = require('./accounts');

function parseArguments(args) {
  const opts={};
  for(let i=0;i<args.length;i+=2) {
    if (!args[i]?.startsWith('--') || !args[i+1]) throw Error('INVALID_ARGUMENTS');
    opts[args[i].slice(2)]=args[i+1];
  }
  if(!opts['token-file'] || !opts['data-dir'] || opts.port!=='38741') throw Error('MISSING_CONFIGURATION');
  return opts;
}
function constantTimeEquals(a,b) {
  if (typeof a!=='string' || typeof b!=='string') return false;
  const x=Buffer.from(a),y=Buffer.from(b);
  return x.length===y.length && crypto.timingSafeEqual(x,y);
}
function createServer({ registry,token,port=38741 }) {
  const routes={
    '/accounts/activate': async b => registry.activate(b.accountId,b.phone),
    '/accounts/pause': async b => registry.pause(b.accountId),
    '/accounts/request-code': async b => registry.requestCode(b.accountId),
    '/accounts/pause-all': async () => registry.pauseAll(),
    '/accounts/unlink': async b => registry.unlink(b.accountId),
    '/groups/sync': async b => ({groups:await registry.groups(b.accountId)}),
    '/messages/send': async b => registry.sendMessage(b)
  };
  return http.createServer(async (req,res) => {
    res.setHeader('Content-Type','application/json; charset=utf-8');
    res.setHeader('Cache-Control','no-store');
    res.setHeader('X-Content-Type-Options','nosniff');
    const respond=(code,obj)=>{res.writeHead(code);res.end(JSON.stringify(obj));};
    if(!constantTimeEquals(req.headers['x-bridge-token'],token)) return respond(401,{ok:false,error:'UNAUTHORIZED'});
    if(req.method==='GET' && req.url==='/health') {
      return respond(200,{ok:true,engine:'ready',node:process.versions.node,accounts:registry.status(),memory:process.memoryUsage().rss});
    }
    if(req.method!=='POST' || !Object.hasOwn(routes,req.url)) return respond(404,{ok:false,error:'NOT_FOUND'});
    const chunks=[];let total=0;
    try {
      for await (const chunk of req) {
        total+=chunk.length;
        if(total>1_048_576) throw Error('PAYLOAD_TOO_LARGE');
        chunks.push(chunk);
      }
      const body=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if(!body || Array.isArray(body) || typeof body!=='object') throw Error('INVALID_BODY');
      const data=await routes[req.url](body);
      respond(200,{ok:true,...data});
    } catch(err) {
      const error=String(err?.message || 'UNKNOWN').slice(0,150);
      const validation=/INVALID_|GROUP_REQUIRED|ACCOUNT_NOT_CONNECTED|EMPTY_|MEDIA_TYPE|ATTACHMENT_|PAIRING_/.test(error);
      respond(validation?400:503,{ok:false,error});
    }
  }).listen(port,'127.0.0.1');
}
if(require.main===module) {
  (async()=>{
    const opts=parseArguments(process.argv.slice(2));
    const token=fs.readFileSync(opts['token-file'],'utf8').trim();
    if(token.length!==64) throw Error('INVALID_BRIDGE_SECRET');
    // Do not start a fake WhatsApp backend if npm dependencies are missing.
    const baileys=require('@whiskeysockets/baileys');
    const pino=require('pino');
    const host=new AndroidHost(token);
    const registry=new AccountRegistry({host,baileys,filesDir:opts['data-dir'],logger:pino({level:'silent'})});
    const server=createServer({registry,token,port:Number(opts.port)});
    server.on('error',err=>{ process.stderr.write('Bridge: '+err.message+'\n'); });
  })().catch(e=>{
    process.stderr.write('Engine launch failed: '+e.message+'\n');
    process.exitCode=1;
  });
}
module.exports={createServer,constantTimeEquals,parseArguments};
