'use strict';
const http = require('node:http');
class AndroidHost {
  constructor(token) { this.token = token; }
  async request(path, data = {}) {
    const payload = Buffer.from(JSON.stringify(data));
    if (payload.length > 900000) throw Error('HOST_PAYLOAD_TOO_LARGE');
    return new Promise((resolve, reject) => {
      const req = http.request({
        host: '127.0.0.1', port: 38742, path, method: 'POST',
        timeout: 7000,
        headers: {
          'Content-Type': 'application/json',
          'X-Bridge-Token': this.token,
          'Content-Length': String(payload.length)
        }
      }, res => {
        const chunks=[]; let size=0;
        res.on('data',chunk => {
          size += chunk.length;
          if (size > 1_048_576) { req.destroy(Error('HOST_RESPONSE_TOO_LARGE')); return; }
          chunks.push(chunk);
        });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            if (res.statusCode !== 200 || parsed.ok !== true) reject(Error(parsed.error || 'HOST_ERROR'));
            else resolve(parsed);
          } catch (e) { reject(e); }
        });
      });
      req.on('error',reject);
      req.on('timeout', () => req.destroy(Error('HOST_TIMEOUT')));
      req.end(payload);
    });
  }
  getAuth(accountId, key) { return this.request('/vault/get',{accountId,key}); }
  setAuth(accountId, key, value) { return this.request('/vault/set',{accountId,key,value}); }
  clearAuth(accountId) { return this.request('/vault/clear',{accountId}); }
  notify(accountId, type, info={}) {
    return this.request('/event',{accountId,type,...info}).catch(() => {});
  }
}
module.exports = { AndroidHost };
