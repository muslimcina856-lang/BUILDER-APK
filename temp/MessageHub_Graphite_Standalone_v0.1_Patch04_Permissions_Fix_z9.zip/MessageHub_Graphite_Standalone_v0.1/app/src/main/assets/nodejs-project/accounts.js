'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createAuthState } = require('./auth');
const policy = require('./policy');

class AccountRegistry {
  constructor({host,baileys,logger,filesDir,makeSocket}) {
    this.host=host;
    this.baileys=baileys;
    this.logger=logger;
    this.filesDir=filesDir;
    this.makeSocket=makeSocket || (opts => baileys.default(opts));
    this.accounts=new Map();
  }
  _id(value) {
    if (typeof value !== 'string' || !/^[a-f0-9-]{20,45}$/.test(value)) throw Error('INVALID_ACCOUNT_ID');
    return value;
  }
  status() {
    return [...this.accounts.values()].map(x => ({ accountId:x.id, status:x.status, desired:x.desired }));
  }
  async activate(accountId, phone='') {
    this._id(accountId);
    if (phone) policy.validatePhone(phone);
    const existing=this.accounts.get(accountId);
    if(existing) {
      existing.desired=true;
      if (existing.socket && existing.status !== 'PAUSED' && existing.status !== 'OFFLINE') return {status:existing.status};
      if (existing.connecting) return {status:'CONNECTING'};
    }
    const entry=existing || { id:accountId, attempt:0, timer:null, socket:null, status:'OFFLINE',desired:true,phone:'',connecting:false,generation:0,pairTimer:null };
    entry.desired=true;
    entry.phone=phone || entry.phone;
    this.accounts.set(accountId,entry);
    await this._connect(entry);
    return {status:entry.status};
  }
  async _connect(entry) {
    if (!entry.desired || entry.connecting) return;
    entry.connecting=true;
    entry.generation++;
    const generation=entry.generation;
    entry.status='CONNECTING';
    await this.host.notify(entry.id,'status',{state:'CONNECTING'});
    try {
      const {state,saveCreds} = await createAuthState(this.baileys,this.host,entry.id);
      if (!entry.desired || generation !== entry.generation) return;
      // One Node runtime, one Baileys socket per enabled account.
      const opts = {
        auth: state,
        logger:this.logger,
        printQRInTerminal:false,
        syncFullHistory:false,
        markOnlineOnConnect:false,
        generateHighQualityLinkPreview:false,
        browser:['MessageHub','Chrome','1.0.0']
      };
      const sock=this.makeSocket(opts);
      entry.socket=sock;
      let codeRequested=false;
      const askCode = async () => {
        if(generation!==entry.generation || !entry.desired || codeRequested || !entry.phone || state.creds.registered) return;
        codeRequested=true;
        try {
          const code=await sock.requestPairingCode(entry.phone);
          await this.host.notify(entry.id,'status',{state:'PAIRING_REQUIRED',code});
        } catch(e) {
          await this.host.notify(entry.id,'log',{level:'WARN',message:'Pairing code gagal: '+String(e.message).slice(0,120)});
        }
      };
      if(entry.phone && !state.creds.registered) entry.pairTimer=setTimeout(askCode,3000);
      sock.ev.on('creds.update',() => { saveCreds().catch(() => {}); });
      sock.ev.on('connection.update', async update => {
        if(generation !== entry.generation) return;
        if(update.qr) {
          entry.status='PAIRING_REQUIRED';
          await this.host.notify(entry.id,'status',{state:'PAIRING_REQUIRED',qr:update.qr});
          if(entry.phone && !state.creds.registered) askCode().catch(() => {});
        }
        if(update.connection==='open') {
          entry.attempt=0;
          entry.status='CONNECTED';
          await this.host.notify(entry.id,'status',{state:'CONNECTED'});
        }
        if(update.connection==='close') {
          entry.socket=null;
          const reason=update.lastDisconnect?.error?.output?.statusCode;
          const loggedOut = reason===401 || reason===this.baileys.DisconnectReason?.loggedOut;
          entry.status=loggedOut?'PAIRING_REQUIRED':'OFFLINE';
          await this.host.notify(entry.id,'status',{state:entry.status});
          if(entry.desired && !loggedOut) this._scheduleReconnect(entry);
        }
      });
    } catch(e) {
      entry.status='ERROR';
      await this.host.notify(entry.id,'status',{state:'ERROR'});
      await this.host.notify(entry.id,'log',{level:'ERROR',message:'Engine: '+String(e.message).slice(0,180)});
      if(entry.desired) this._scheduleReconnect(entry);
    } finally { entry.connecting=false; }
  }
  _scheduleReconnect(entry) {
    if (!entry.desired || entry.timer) return;
    const ms=Math.min(60000,1000 * 2 ** Math.min(6,entry.attempt++));
    entry.timer=setTimeout(() => {
      entry.timer=null;
      if(entry.desired) this._connect(entry).catch(() => {});
    },ms);
  }
  async requestCode(accountId) {
    this._id(accountId);
    const entry=this.accounts.get(accountId);
    if (!entry?.socket || !entry.desired || !entry.phone) throw Error('PAIRING_SOCKET_NOT_READY');
    const code=await entry.socket.requestPairingCode(entry.phone);
    await this.host.notify(accountId,'status',{state:'PAIRING_REQUIRED',code});
    return {code};
  }
  async pause(accountId) {
    this._id(accountId);
    const entry=this.accounts.get(accountId);
    if(entry) {
      entry.desired=false;
      entry.generation++;
      clearTimeout(entry.timer);entry.timer=null;
      clearTimeout(entry.pairTimer);entry.pairTimer=null;
      const old=entry.socket;entry.socket=null;
      try { old?.end(new Error('Paused locally')); } catch (_) {}
      entry.status='PAUSED';
    }
    await this.host.notify(accountId,'status',{state:'PAUSED'});
    return {status:'PAUSED'};
  }
  async pauseAll() {
    for(const id of this.accounts.keys()) await this.pause(id);
    return {status:'PAUSED'};
  }
  async unlink(accountId) {
    this._id(accountId);
    const entry=this.accounts.get(accountId);
    if(entry) {
      entry.desired=false;entry.generation++;clearTimeout(entry.timer);entry.timer=null;
      clearTimeout(entry.pairTimer);entry.pairTimer=null;
      try { await entry.socket?.logout(); } catch (_) { /* WhatsApp may already be logged out */ }
      try { entry.socket?.end(new Error('Unlinked')) } catch (_) {}
      this.accounts.delete(accountId);
    }
    await this.host.clearAuth(accountId);
    await this.host.notify(accountId,'status',{state:'PAIRING_REQUIRED'});
    return {status:'PAIRING_REQUIRED'};
  }
  _connected(accountId) {
    this._id(accountId);
    const entry=this.accounts.get(accountId);
    if (!entry || entry.status!=='CONNECTED' || !entry.socket) throw Error('ACCOUNT_NOT_CONNECTED');
    return entry.socket;
  }
  async groups(accountId) {
    const sock=this._connected(accountId);
    const groupMap=await sock.groupFetchAllParticipating();
    return Object.values(groupMap).filter(g => g && g.id).map(g => ({
      jid:g.id, name:(g.subject || g.id).slice(0,140),
      members:Array.isArray(g.participants)?g.participants.length:0,
      admin:!!(g.participants || []).find(p => {
        const own=(sock.user?.id || '').replace(/:\d+@/, '@');
        return (p.id===sock.user?.id || p.id===own) && p.admin;
      }),
      announcement:!!g.announce
    }));
  }
  async sendMessage(input) {
    const sock=this._connected(input.accountId);
    const jid=policy.validateGroupJid(input.jid);
    const {text,attachment}=policy.validatePayload(input);
    let content={text};
    if (attachment) {
      const mime=String(input.mime||'');
      const kind=mime.startsWith('image/')?'image':mime.startsWith('video/')?'video':'document';
      const safe=policy.resolveAttachment(path.join(this.filesDir,'attachments'),kind,attachment);
      const stat=fs.statSync(safe);
      if(!stat.isFile() || stat.size>15*1024*1024) throw Error('ATTACHMENT_SIZE_LIMIT');
      if(kind==='image') content={image:{url:safe},caption:text};
      else if(kind==='video') content={video:{url:safe},caption:text};
      else content={document:{url:safe},mimetype:mime||'application/octet-stream',fileName:String(input.fileName||'document').slice(0,120),caption:text};
    }
    const result=await sock.sendMessage(jid,content);
    return {messageId:result?.key?.id || ''};
  }
}
module.exports={AccountRegistry};
