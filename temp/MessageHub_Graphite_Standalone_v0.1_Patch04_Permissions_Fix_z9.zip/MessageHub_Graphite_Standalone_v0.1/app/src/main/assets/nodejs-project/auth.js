'use strict';
/** Baileys 6.7.x auth key store, persisted encrypted via Android Keystore / SQLite. */
async function createAuthState(baileys, host, accountId) {
  const { initAuthCreds, BufferJSON, proto } = baileys;
  if (!initAuthCreds || !BufferJSON || !proto) throw Error('UNSUPPORTED_BAILEYS_AUTH_API');
  const decode = value => JSON.parse(value, BufferJSON.reviver);
  const encode = value => JSON.stringify(value, BufferJSON.replacer);
  const response = await host.getAuth(accountId, 'creds');
  const creds = response.value ? decode(response.value) : initAuthCreds();
  const state = {
    creds,
    keys: {
      get: async (type, ids) => {
        const data = {};
        for (const id of ids) {
          const found = await host.getAuth(accountId, `key:${type}:${id}`);
          if (!found.value) continue;
          let value = decode(found.value);
          if (type === 'app-state-sync-key') value = proto.Message.AppStateSyncKeyData.fromObject(value);
          data[id] = value;
        }
        return data;
      },
      set: async data => {
        for (const type of Object.keys(data)) {
          for (const id of Object.keys(data[type])) {
            const value = data[type][id];
            await host.setAuth(accountId, `key:${type}:${id}`, value == null ? null : encode(value));
          }
        }
      }
    }
  };
  let saveQueue = Promise.resolve();
  return { state, saveCreds: () => {
    const snapshot = encode(state.creds);
    saveQueue = saveQueue.catch(() => {}).then(() => host.setAuth(accountId, 'creds', snapshot));
    return saveQueue;
  } };
}
module.exports = { createAuthState };
