'use strict';
const path = require('node:path');

function validatePhone(value) {
  if (typeof value !== 'string' || !/^[0-9]{7,15}$/.test(value)) throw Error('INVALID_PHONE');
  return value;
}
function validateGroupJid(jid) {
  if (typeof jid !== 'string' || !/^[0-9-]{5,60}@g\.us$/.test(jid)) throw Error('GROUP_REQUIRED');
  return jid;
}
function validatePayload({ text = '', attachment = '' } = {}) {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > 16384) throw Error('INVALID_MESSAGE');
  if (typeof attachment !== 'string' || attachment.length > 1024) throw Error('INVALID_ATTACHMENT');
  if (!text.trim() && !attachment) throw Error('EMPTY_MESSAGE');
  return { text, attachment };
}
function resolveAttachment(root, kind, filePath) {
  if (!['image','video','document'].includes(kind)) throw Error('MEDIA_TYPE_UNSUPPORTED');
  if (typeof filePath !== 'string' || !filePath) throw Error('INVALID_ATTACHMENT');
  const rootResolved = path.resolve(root);
  const resolved = path.resolve(filePath);
  if (!resolved.startsWith(rootResolved + path.sep)) throw Error('INVALID_ATTACHMENT_LOCATION');
  return resolved;
}
function dedupeTargets(targets) {
  const seen = new Set();
  return targets.filter(item => {
    validateGroupJid(item.jid);
    if (seen.has(item.jid)) return false;
    seen.add(item.jid);
    return true;
  });
}
module.exports = { validatePhone, validateGroupJid, validatePayload, resolveAttachment, dedupeTargets };
