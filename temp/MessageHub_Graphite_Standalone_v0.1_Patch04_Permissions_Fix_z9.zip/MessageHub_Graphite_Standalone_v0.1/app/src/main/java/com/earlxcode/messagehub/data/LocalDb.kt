package com.earlxcode.messagehub.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "messagehub.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE accounts (
            id TEXT PRIMARY KEY, alias TEXT NOT NULL, phone TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PAUSED', desired INTEGER NOT NULL DEFAULT 0,
            code TEXT NOT NULL DEFAULT '', qr TEXT NOT NULL DEFAULT ''
        )""")
        db.execSQL("""CREATE TABLE secure_kv (
            account_id TEXT NOT NULL, item_key TEXT NOT NULL, cipher TEXT NOT NULL,
            PRIMARY KEY(account_id, item_key)
        )""")
        db.execSQL("""CREATE TABLE groups_cache (
            account_id TEXT NOT NULL, jid TEXT NOT NULL, name TEXT NOT NULL,
            members INTEGER NOT NULL DEFAULT 0, admin INTEGER NOT NULL DEFAULT 0,
            announcement INTEGER NOT NULL DEFAULT 0, approved INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(account_id, jid)
        )""")
        db.execSQL("""CREATE TABLE optouts (
            account_id TEXT NOT NULL, jid TEXT NOT NULL, reason TEXT NOT NULL,
            opted_at INTEGER NOT NULL, PRIMARY KEY(account_id,jid)
        )""")
        db.execSQL("""CREATE TABLE templates (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE campaigns (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, scope TEXT NOT NULL,
            status TEXT NOT NULL, scheduled_at INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE targets (
            id TEXT PRIMARY KEY, campaign_id TEXT NOT NULL, account_id TEXT NOT NULL,
            jid TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
            attachment TEXT NOT NULL DEFAULT '', mime TEXT NOT NULL DEFAULT '',
            file_name TEXT NOT NULL DEFAULT '', message_id TEXT NOT NULL DEFAULT '',
            error TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL,
            UNIQUE(campaign_id, jid)
        )""")
        db.execSQL("CREATE INDEX targets_queue ON targets(status, campaign_id)")
        db.execSQL("""CREATE TABLE logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL,
            account_id TEXT NOT NULL DEFAULT '', level TEXT NOT NULL, message TEXT NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        error("Unsupported database upgrade; add a non-destructive migration")
    }
    private fun Cursor.text(index: Int): String = getString(index) ?: ""
    @Synchronized fun addAccount(alias: String, phone: String): Account {
        require(alias.trim().length in 2..40)
        require(phone.matches(Regex("^[0-9]{7,15}$")))
        require(accounts().none { it.phone==phone }) { "Nombor ini sudah ditambah" }
        val account = Account(UUID.randomUUID().toString(), alias.trim(), phone)
        val values = ContentValues().apply {
            put("id", account.id); put("alias", account.alias); put("phone", account.phone)
        }
        writableDatabase.insertOrThrow("accounts", null, values)
        log(account.id, "INFO", "Akaun dicipta")
        return account
    }
    @Synchronized fun accounts(): List<Account> {
        val result = mutableListOf<Account>()
        readableDatabase.rawQuery("SELECT id,alias,phone,status,desired,code,qr FROM accounts ORDER BY rowid", null).use { c ->
            while (c.moveToNext()) result += Account(c.text(0),c.text(1),c.text(2),c.text(3),c.getInt(4) == 1,c.text(5),c.text(6))
        }
        return result
    }
    @Synchronized fun account(id: String): Account? = accounts().find { it.id == id }
    @Synchronized fun setDesired(id: String, enabled: Boolean) {
        writableDatabase.execSQL("UPDATE accounts SET desired=? WHERE id=?", arrayOf(if (enabled) 1 else 0, id))
    }
    @Synchronized fun setAccountState(id: String, status: String, code: String = "", qr: String = "") {
        require(status in setOf("PAUSED","CONNECTED","CONNECTING","RECONNECTING","OFFLINE","PAIRING_REQUIRED","ERROR"))
        writableDatabase.execSQL("UPDATE accounts SET status=?, code=?, qr=? WHERE id=?", arrayOf(status,code,qr,id))
    }
    @Synchronized fun removeAccount(id: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // No campaign history is deleted; history stays auditable with accountId.
            db.delete("groups_cache","account_id=?", arrayOf(id))
            db.delete("optouts","account_id=?", arrayOf(id))
            db.delete("secure_kv","account_id=?", arrayOf(id))
            db.execSQL("UPDATE targets SET status='FAILED',error='Akaun dibuang' WHERE account_id=? AND status='PENDING'",arrayOf(id))
            db.delete("accounts","id=?", arrayOf(id))
            db.execSQL("""UPDATE campaigns SET status='COMPLETED' WHERE status='RUNNING'
                AND NOT EXISTS(SELECT 1 FROM targets t WHERE t.campaign_id=campaigns.id AND t.status IN ('PENDING','SENDING'))""")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    @Synchronized fun putCipher(accountId: String, key: String, encrypted: String?) {
        if (encrypted == null) writableDatabase.delete("secure_kv","account_id=? AND item_key=?",arrayOf(accountId,key))
        else {
            val values = ContentValues().apply { put("account_id",accountId);put("item_key",key);put("cipher",encrypted) }
            writableDatabase.insertWithOnConflict("secure_kv",null,values,SQLiteDatabase.CONFLICT_REPLACE)
        }
    }
    @Synchronized fun getCipher(accountId: String, key: String): String? {
        readableDatabase.rawQuery("SELECT cipher FROM secure_kv WHERE account_id=? AND item_key=?", arrayOf(accountId,key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }
    @Synchronized fun clearAuth(accountId: String) { writableDatabase.delete("secure_kv","account_id=?",arrayOf(accountId)) }
    @Synchronized fun upsertGroups(accountId: String, json: JSONArray) {
        require(account(accountId) != null) { "Akaun tidak wujud" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val currentJids = mutableSetOf<String>()
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                val jid = obj.optString("jid")
                if (!jid.endsWith("@g.us")) continue
                currentJids.add(jid)
                val insert = ContentValues().apply {
                    put("account_id", accountId); put("jid", jid); put("name", obj.optString("name", jid))
                    put("members", obj.optInt("members", 0)); put("admin", if (obj.optBoolean("admin")) 1 else 0)
                    put("announcement", if (obj.optBoolean("announcement")) 1 else 0)
                }
                db.insertWithOnConflict("groups_cache",null,insert,SQLiteDatabase.CONFLICT_IGNORE)
                db.execSQL("UPDATE groups_cache SET name=?, members=?, admin=?, announcement=? WHERE account_id=? AND jid=?", arrayOf(
                    insert.getAsString("name"), insert.getAsInteger("members"),insert.getAsInteger("admin"),
                    insert.getAsInteger("announcement"), accountId,jid))
            }
            // Capture stale JIDs before mutating the table; do not delete while a cursor is open.
            val staleJids = mutableListOf<String>()
            db.rawQuery("SELECT jid FROM groups_cache WHERE account_id=?",arrayOf(accountId)).use { old ->
                while (old.moveToNext()) {
                    val jid = old.getString(0)
                    if (jid !in currentJids) staleJids.add(jid)
                }
            }
            for (jid in staleJids) {
                db.delete("groups_cache","account_id=? AND jid=?",arrayOf(accountId,jid))
                db.execSQL("UPDATE targets SET status='FAILED',error='Group tidak lagi disertai' WHERE account_id=? AND jid=? AND status='PENDING'",arrayOf(accountId,jid))
            }
            db.execSQL("""UPDATE campaigns SET status='COMPLETED' WHERE status='RUNNING'
                AND NOT EXISTS(SELECT 1 FROM targets t WHERE t.campaign_id=campaigns.id AND t.status IN ('PENDING','SENDING'))""")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    @Synchronized fun groups(accountId: String? = null): List<GroupInfo> {
        val result = mutableListOf<GroupInfo>()
        val selection = if (accountId == null) "" else " WHERE account_id=?"
        val args = if (accountId == null) null else arrayOf(accountId)
        readableDatabase.rawQuery("""SELECT g.account_id,g.jid,g.name,g.members,g.admin,g.announcement,
          CASE WHEN EXISTS(SELECT 1 FROM optouts o WHERE o.jid=g.jid) THEN 0 ELSE g.approved END
          FROM groups_cache g$selection ORDER BY g.name COLLATE NOCASE""",args).use { c ->
            while (c.moveToNext()) result += GroupInfo(c.text(0),c.text(1),c.text(2),c.getInt(3),c.getInt(4)==1,c.getInt(5)==1,c.getInt(6)==1)
        }
        return result
    }
    @Synchronized fun allowGroup(accountId: String, jid: String, allowed: Boolean) {
        val db=writableDatabase
        db.execSQL("UPDATE groups_cache SET approved=? WHERE account_id=? AND jid=?", arrayOf(if(allowed) 1 else 0,accountId,jid))
        if(allowed) db.delete("optouts","account_id=? AND jid=?",arrayOf(accountId,jid))
        else db.execSQL("INSERT OR REPLACE INTO optouts(account_id,jid,reason,opted_at) VALUES (?,?,?,?)",
            arrayOf(accountId,jid,"Kebenaran ditarik balik",System.currentTimeMillis()))
        if(!allowed) {
            db.execSQL("""UPDATE targets SET status='FAILED',error='Kebenaran penerima ditarik balik'
                WHERE jid=? AND status='PENDING'""",arrayOf(jid))
            db.execSQL("""UPDATE campaigns SET status='COMPLETED' WHERE status='RUNNING'
                AND NOT EXISTS(SELECT 1 FROM targets t WHERE t.campaign_id=campaigns.id AND t.status IN ('PENDING','SENDING'))""")
        }
    }
    @Synchronized fun saveTemplate(title: String, body: String, existingId: String? = null): String {
        require(title.isNotBlank() && body.isNotBlank())
        val id = existingId ?: UUID.randomUUID().toString()
        val row = ContentValues().apply {put("id",id);put("title",title.take(80));put("body",body.take(8192));put("updated_at",System.currentTimeMillis())}
        writableDatabase.insertWithOnConflict("templates",null,row,SQLiteDatabase.CONFLICT_REPLACE)
        return id
    }
    @Synchronized fun templates(): List<MessageTemplate> {
        val list = mutableListOf<MessageTemplate>()
        readableDatabase.rawQuery("SELECT id,title,body FROM templates ORDER BY updated_at DESC",null).use { c ->
            while(c.moveToNext()) list += MessageTemplate(c.text(0),c.text(1),c.text(2))
        }
        return list
    }
    @Synchronized fun deleteTemplate(id: String) { writableDatabase.delete("templates","id=?",arrayOf(id)) }
    @Synchronized fun createCampaign(title: String, text: String, keys: Set<String>, attachment: String="", mime: String="", fileName: String=""): String {
        require(title.isNotBlank() && (text.isNotBlank() || attachment.isNotBlank()))
        require(keys.isNotEmpty())
        val all = groups().filter { it.approved && (!it.announcement || it.admin) && keys.contains(it.key) }
        require(all.isNotEmpty()) { "Tiada sasaran dengan kebenaran penghantaran" }
        val unique = all.distinctBy { it.jid } // Deduplicate group across multiple sender accounts
        val id = UUID.randomUUID().toString()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val scope = if (unique.map { it.accountId }.distinct().size > 1) "MULTI" else "SINGLE"
            db.execSQL("INSERT INTO campaigns(id,title,body,scope,status,created_at) VALUES (?,?,?,?,?,?)", arrayOf(
                id,title.take(80),text.take(16384),scope,"DRAFT",System.currentTimeMillis()))
            unique.forEach { g ->
                db.execSQL("INSERT INTO targets(id,campaign_id,account_id,jid,attachment,mime,file_name,updated_at) VALUES (?,?,?,?,?,?,?,?)", arrayOf(
                    UUID.randomUUID().toString(),id,g.accountId,g.jid,attachment,mime,fileName,System.currentTimeMillis()))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return id
    }
    @Synchronized fun campaigns(): List<Campaign> {
        val list = mutableListOf<Campaign>()
        readableDatabase.rawQuery("""SELECT c.id,c.title,c.body,c.status,c.scope,
           COUNT(t.id),SUM(CASE WHEN t.status='SENT' THEN 1 ELSE 0 END),
           SUM(CASE WHEN t.status='FAILED' THEN 1 ELSE 0 END),
           SUM(CASE WHEN t.status='UNKNOWN' THEN 1 ELSE 0 END)
           FROM campaigns c LEFT JOIN targets t ON t.campaign_id=c.id
           GROUP BY c.id ORDER BY c.created_at DESC""",null).use { c ->
            while(c.moveToNext()) list += Campaign(c.text(0),c.text(1),c.text(2),c.text(3),c.text(4),c.getInt(5),c.getInt(6),c.getInt(7),c.getInt(8))
        }
        return list
    }
    @Synchronized fun setCampaignStatus(id: String, value: String) {
        require(value in setOf("DRAFT","RUNNING","SCHEDULED","PAUSED","CANCELLED","COMPLETED"))
        writableDatabase.execSQL("UPDATE campaigns SET status=? WHERE id=?", arrayOf(value,id))
        if(value=="CANCELLED") writableDatabase.execSQL("UPDATE targets SET status='CANCELLED' WHERE campaign_id=? AND status='PENDING'",arrayOf(id))
    }
    @Synchronized fun scheduleCampaign(id: String, minutesFromNow: Int) {
        require(minutesFromNow in 0..10080)
        if (minutesFromNow == 0) setCampaignStatus(id,"RUNNING")
        else writableDatabase.execSQL("UPDATE campaigns SET status='SCHEDULED', scheduled_at=? WHERE id=? AND status='DRAFT'",arrayOf(System.currentTimeMillis()+minutesFromNow*60_000L,id))
    }
    @Synchronized fun activateScheduled() {
        writableDatabase.execSQL("UPDATE campaigns SET status='RUNNING' WHERE status='SCHEDULED' AND scheduled_at<=?",arrayOf(System.currentTimeMillis()))
    }
    @Synchronized fun markInterruptedUnknown() {
        writableDatabase.execSQL("UPDATE targets SET status='UNKNOWN',error='Proses terhenti semasa cubaan penghantaran',updated_at=? WHERE status='SENDING'",arrayOf(System.currentTimeMillis()))
    }
    @Synchronized fun nextTarget(): CampaignTarget? {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val sql = """SELECT t.id,t.campaign_id,t.account_id,t.jid,c.body,t.attachment,t.mime,t.file_name
                FROM targets t JOIN campaigns c ON c.id=t.campaign_id
                JOIN accounts a ON a.id=t.account_id
                JOIN groups_cache g ON g.account_id=t.account_id AND g.jid=t.jid
                WHERE t.status='PENDING' AND c.status='RUNNING' AND a.desired=1
                  AND a.status='CONNECTED' AND g.approved=1
                  AND (g.announcement=0 OR g.admin=1)
                  AND NOT EXISTS (SELECT 1 FROM optouts o WHERE o.jid=t.jid)
                ORDER BY c.created_at, t.rowid LIMIT 1"""
            val target = db.rawQuery(sql,null).use { c -> if(c.moveToFirst()) CampaignTarget(c.text(0),c.text(1),c.text(2),c.text(3),c.text(4),c.text(5),c.text(6),c.text(7)) else null }
            if (target != null) db.execSQL("UPDATE targets SET status='SENDING',updated_at=? WHERE id=? AND status='PENDING'", arrayOf(System.currentTimeMillis(),target.id))
            db.setTransactionSuccessful()
            return target
        } finally { db.endTransaction() }
    }
    @Synchronized fun finishTarget(id: String, status: String, messageId: String = "", error: String = "") {
        require(status in setOf("SENT","FAILED","UNKNOWN"))
        writableDatabase.execSQL("UPDATE targets SET status=?,message_id=?,error=?,updated_at=? WHERE id=? AND status='SENDING'", arrayOf(status,messageId,error.take(400),System.currentTimeMillis(),id))
        writableDatabase.execSQL("""UPDATE campaigns SET status='COMPLETED'
            WHERE status='RUNNING' AND id=(SELECT campaign_id FROM targets WHERE id=?)
              AND NOT EXISTS (SELECT 1 FROM targets t WHERE t.campaign_id=campaigns.id AND t.status IN ('PENDING','SENDING'))""",arrayOf(id))
    }
    @Synchronized fun log(accountId: String, level: String, message: String) {
        writableDatabase.execSQL("INSERT INTO logs(created_at,account_id,level,message) VALUES (?,?,?,?)",arrayOf(System.currentTimeMillis(),accountId,level.take(12),message.take(300)))
        writableDatabase.execSQL("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 2000)")
    }
    @Synchronized fun targetHistory(limit: Int = 100): List<TargetHistory> {
        val rows=mutableListOf<TargetHistory>()
        readableDatabase.rawQuery("""SELECT t.updated_at,t.account_id,c.title,t.jid,t.status,t.message_id,t.error
            FROM targets t JOIN campaigns c ON c.id=t.campaign_id
            ORDER BY t.updated_at DESC LIMIT ${limit.coerceIn(1,500)}""",null).use { cursor ->
            while(cursor.moveToNext()) rows += TargetHistory(cursor.getLong(0),cursor.text(1),cursor.text(2),
                cursor.text(3),cursor.text(4),cursor.text(5),cursor.text(6))
        }
        return rows
    }
    @Synchronized fun logs(limit: Int = 80): List<LogEntry> {
        val rows = mutableListOf<LogEntry>()
        readableDatabase.rawQuery("SELECT created_at,account_id,level,message FROM logs ORDER BY id DESC LIMIT ${limit.coerceIn(1,500)}",null).use { c ->
            while(c.moveToNext()) rows += LogEntry(c.getLong(0),c.text(1),c.text(2),c.text(3))
        }
        return rows
    }
}
