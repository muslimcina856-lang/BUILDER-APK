package com.earlxcode.messagehub.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.earlxcode.messagehub.data.*
import com.earlxcode.messagehub.service.NodeEngineService
import androidx.core.content.ContextCompat

private val tabs=listOf("Dashboard","Groups","Campaigns","History","Settings")

@Composable fun MessageHubApp(model:AppModel) {
    val snapshot by model.state.collectAsStateWithLifecycle()
    var route by rememberSaveable { mutableStateOf("Dashboard") }
    var selected by rememberSaveable { mutableStateOf("") } // blank means all accounts
    var selectMenu by remember { mutableStateOf(false) }
    var templateText by remember { mutableStateOf("") }
    val snackbar=remember { SnackbarHostState() }
    val context=LocalContext.current
    val pinStore=remember(context) { PinStore(context) }
    var unlocked by remember { mutableStateOf(!pinStore.enabled()) }
    if(!unlocked) {
        PinLockScreen(pinStore,onSuccess={unlocked=true})
        return
    }
    LaunchedEffect(snapshot.notice) {
        if(snapshot.notice.isNotBlank()) { snackbar.showSnackbar(snapshot.notice);model.clearNotice() }
    }
    val current=snapshot.accounts.firstOrNull { it.id==selected }
    Scaffold(
        containerColor=Graphite.bg,
        snackbarHost={ SnackbarHost(snackbar) },
        topBar={
            Row(Modifier.fillMaxWidth().background(Graphite.bg).padding(horizontal=16.dp,vertical=10.dp),
                verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("MESSAGE HUB",color=Graphite.cyan,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text(if(snapshot.engineReady) "Enjin aktif • ${snapshot.nodeVersion}" else "Enjin offline / starting",
                        color=if(snapshot.engineReady) Graphite.green else Graphite.yellow,
                        style=MaterialTheme.typography.labelSmall)
                }
                Box {
                    OutlinedButton(onClick={selectMenu=true},contentPadding=PaddingValues(horizontal=10.dp)) {
                        Icon(Icons.Filled.Person,contentDescription=null,modifier=Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(current?.alias ?: "Semua",maxLines=1,overflow=TextOverflow.Ellipsis)
                        Icon(Icons.Filled.ArrowDropDown,contentDescription=null)
                    }
                    DropdownMenu(expanded=selectMenu,onDismissRequest={selectMenu=false}) {
                        DropdownMenuItem(text={Text("Semua akaun")},onClick={selected="";selectMenu=false})
                        snapshot.accounts.forEach { account ->
                            DropdownMenuItem(text={Text("${account.alias} • ${account.status}")},
                                onClick={selected=account.id;selectMenu=false})
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text={Text("+ Tambah akaun")},onClick={selectMenu=false;route="Connect"})
                    }
                }
            }
        },
        bottomBar={
            NavigationBar(containerColor=Graphite.surface) {
                tabs.forEach { tab ->
                    val icon=when(tab){
                        "Dashboard"->Icons.Filled.Home
                        "Groups"->Icons.Filled.Group
                        "Campaigns"->Icons.Filled.Send
                        "History"->Icons.Filled.History
                        else->Icons.Filled.Settings
                    }
                    NavigationBarItem(selected=route==tab,onClick={route=tab},icon={Icon(icon,contentDescription=tab)},
                        label={Text(tab,style=MaterialTheme.typography.labelSmall)},alwaysShowLabel=true)
                }
            }
        }
    ) { insets ->
        Column(Modifier.fillMaxSize().padding(insets)) {
            when(route) {
                "Dashboard" -> DashboardScreen(snapshot,selected,onConnect={route="Connect"},onAccounts={route="Accounts"},onNew={route="Composer"})
                "Connect" -> ConnectScreen(snapshot,current,model,onBack={route="Dashboard"},onSelected={selected=it})
                "Accounts" -> AccountsScreen(snapshot,model,onBack={route="Settings"},onAdd={route="Connect"},onSelected={selected=it})
                "Groups" -> GroupsScreen(snapshot,selected,model)
                "Composer" -> ComposerScreen(snapshot,selected,templateText,model,onBack={route="Campaigns"},onSaved={templateText="";route="Campaigns"})
                "Campaigns" -> CampaignsScreen(snapshot,model,onNew={route="Composer"})
                "History" -> HistoryScreen(snapshot)
                "Templates" -> TemplatesScreen(snapshot,model,onBack={route="Settings"},onUse={templateText=it;route="Composer"})
                "Settings" -> SettingsScreen(snapshot,model,onAccounts={route="Accounts"},onTemplates={route="Templates"},onRetry={
                    ContextCompat.startForegroundService(context,Intent(context,NodeEngineService::class.java).setAction(NodeEngineService.ACTION_START))
                })
                else -> DashboardScreen(snapshot,selected,onConnect={route="Connect"},onAccounts={route="Accounts"},onNew={route="Composer"})
            }
        }
    }
}

@Composable private fun ScreenHeader(title:String,subtitle:String="",right:(@Composable ()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            if(subtitle.isNotBlank()) Text(subtitle,color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
        }
        right?.invoke()
    }
}
@Composable private fun ActionButton(label:String,onClick:()->Unit,modifier:Modifier=Modifier) {
    Button(onClick=onClick,modifier=modifier.heightIn(min=48.dp),shape=RoundedCornerShape(13.dp)) { Text(label) }
}
@Composable private fun BlankState(title:String,description:String,action:String?=null,onClick:(()->Unit)?=null) {
    Column(Modifier.fillMaxWidth().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,
        verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Filled.Info,null,tint=Graphite.muted,modifier=Modifier.size(38.dp))
        SectionTitle(title)
        Text(description,color=Graphite.muted,style=MaterialTheme.typography.bodyMedium)
        if(action!=null && onClick!=null) ActionButton(action,onClick)
    }
}
@Composable private fun AccountRow(account:Account,onClick:()->Unit,onToggle:(Boolean)->Unit) {
    GraphiteCard(Modifier.fillMaxWidth().padding(bottom=10.dp)) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(onClick=onClick)) {
                Text(account.alias,fontWeight=FontWeight.SemiBold)
                Text("+${account.phone}",color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                StatusPill(account.status)
            }
            Switch(checked=account.desired,onCheckedChange=onToggle)
        }
    }
}
@Composable private fun DashboardScreen(state:UiSnapshot,filter:String,onConnect:()->Unit,onAccounts:()->Unit,onNew:()->Unit) {
    val accounts=state.accounts.filter { filter.isBlank() || it.id==filter }
    val accountIds=accounts.map { it.id }.toSet()
    val groups=state.groups.filter { it.accountId in accountIds }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Text("OVERVIEW  /  LIVE",color=Graphite.cyan,style=MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            Text("Dashboard",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Kawal semua akaun WhatsApp daripada peranti ini",color=Graphite.muted)
            Spacer(Modifier.height(14.dp))
            GraphiteCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Filled.Hub,contentDescription=null,tint=Graphite.cyan,modifier=Modifier.size(30.dp))
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text("LOCAL ENGINE",style=MaterialTheme.typography.labelSmall,color=Graphite.muted)
                        Text(if(state.engineReady) "Sambungan bersedia" else "Menunggu enjin",fontWeight=FontWeight.SemiBold)
                    }
                    StatusPill(if(state.engineReady) "CONNECTED" else "OFFLINE")
                }
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Akaun",accounts.size.toString(),Modifier.weight(1f))
                StatCard("Connected",accounts.count { it.status=="CONNECTED" }.toString(),Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Group",groups.size.toString(),Modifier.weight(1f))
                StatCard("Kempen",state.campaigns.size.toString(),Modifier.weight(1f))
            }
        }
        item { ActionButton("+ New Broadcast",onNew,Modifier.fillMaxWidth()) }
        item {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                SectionTitle("Akaun WhatsApp",Modifier.weight(1f))
                TextButton(onClick=onAccounts) { Text("Urus") }
            }
        }
        if(accounts.isEmpty()) item { BlankState("Tiada akaun", "Pautkan akaun WhatsApp terlebih dahulu.","Tambah akaun",onConnect) }
        items(accounts,key={it.id}) { account ->
            GraphiteCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(account.alias,fontWeight=FontWeight.SemiBold)
                        Text("+${account.phone}",color=Graphite.muted,style=MaterialTheme.typography.labelMedium)
                    }
                    StatusPill(account.status)
                }
            }
        }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("Enjin setempat",fontWeight=FontWeight.Bold)
                    Text(if(state.engineReady) "Node.js ${state.nodeVersion} • RAM proses ±${state.memoryMb} MB" else "Enjin belum bersedia",
                        color=Graphite.muted)
                    Text("Tiada VPS • Pelaksanaan background mengikut had Android",color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier) {
    GraphiteCard(modifier) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(label,color=Graphite.muted,style=MaterialTheme.typography.labelMedium)
            Text(value,color=Graphite.cyan,style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable private fun ConnectScreen(state:UiSnapshot,current:Account?,model:AppModel,onBack:()->Unit,onSelected:(String)->Unit) {
    var alias by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var showQr by rememberSaveable { mutableStateOf(false) }
    var linking by remember { mutableStateOf<Account?>(null) }
    val target=linking?.let { linked -> state.accounts.find{it.id==linked.id} } ?: current
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item { ScreenHeader("Connect WhatsApp","Pairing code atau QR Code") }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Pautkan akaun baharu")
                    OutlinedTextField(value=alias,onValueChange={alias=it.take(40)},label={Text("Nama / Alias")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(value=phone,onValueChange={phone=it.filter(Char::isDigit).take(15)},label={Text("Nombor WhatsApp")},
                        placeholder={Text("60123456789")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Text("Gunakan format antarabangsa tanpa + atau ruang.",color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                    ActionButton("Tambah & sambung",{
                        model.addAccount(alias,phone) { id -> onSelected(id);linking=state.accounts.find { it.id==id } }
                    },Modifier.fillMaxWidth())
                }
            }
        }
        if(target!=null) item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                        Text(target.alias,fontWeight=FontWeight.SemiBold)
                        StatusPill(target.status)
                    }
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        SegmentedButton(selected=!showQr,onClick={showQr=false},shape=SegmentedButtonDefaults.itemShape(0,2),label={Text("Pairing Code")})
                        SegmentedButton(selected=showQr,onClick={showQr=true},shape=SegmentedButtonDefaults.itemShape(1,2),label={Text("QR Code")})
                    }
                    if (!showQr) {
                        Text("Kod pairing",color=Graphite.muted)
                        Text(if(target.pairingCode.isNotBlank()) target.pairingCode else "Menunggu kod...",
                            color=Graphite.cyan,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                        Text("WhatsApp > Peranti tertaut > Tautkan peranti > Tautkan dengan nombor telefon",
                            color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                    } else {
                        if(target.qr.isBlank()) Text("Menunggu QR daripada WhatsApp...",color=Graphite.muted)
                        else QrForPairing(target.qr)
                        Text("Imbas menggunakan WhatsApp pada peranti utama.",color=Graphite.muted)
                    }
                    OutlinedButton(onClick={model.requestCode(target.id)},modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Link,null);Spacer(Modifier.width(8.dp));Text("Minta kod pairing baharu")
                    }
                    OutlinedButton(onClick={model.activate(target.id)},modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Refresh,null);Spacer(Modifier.width(8.dp));Text("Cuba sambung semula")
                    }
                }
            }
        }
        item { TextButton(onClick=onBack) { Text("Kembali ke Dashboard") } }
    }
}

@Composable private fun QrForPairing(value:String) {
    val bitmap=remember(value) {
        runCatching {
            val matrix=com.google.zxing.qrcode.QRCodeWriter().encode(value,com.google.zxing.BarcodeFormat.QR_CODE,480,480)
            android.graphics.Bitmap.createBitmap(480,480,android.graphics.Bitmap.Config.ARGB_8888).apply {
                for (y in 0 until 480) for (x in 0 until 480) setPixel(x,y,if(matrix[x,y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }.getOrNull()
    }
    if(bitmap!=null) {
        androidx.compose.foundation.Image(bitmap=bitmap.asImageBitmap(),contentDescription="QR Code pairing WhatsApp",
            modifier=Modifier.size(244.dp).background(Color.White).padding(8.dp))
    }
}

@Composable private fun AccountsScreen(state:UiSnapshot,model:AppModel,onBack:()->Unit,onAdd:()->Unit,onSelected:(String)->Unit) {
    var unlinkId by remember { mutableStateOf<String?>(null) }
    var removeId by remember { mutableStateOf<String?>(null) }
    if(unlinkId!=null) AlertDialog(onDismissRequest={unlinkId=null},title={Text("Unlink WhatsApp?")},
        text={Text("Peranti WhatsApp akan dinyahpautkan dan kelayakan sesi setempat dipadam. Ini tidak memadam sejarah kempen.")},
        confirmButton={TextButton(onClick={model.unlink(unlinkId!!);unlinkId=null}) { Text("Unlink") }},
        dismissButton={TextButton(onClick={unlinkId=null}) { Text("Batal") }})
    if(removeId!=null) AlertDialog(onDismissRequest={removeId=null},title={Text("Buang akaun?")},
        text={Text("Sesi setempat dibuang. Sejarah kempen dikekalkan. Jika perlu, unlink WhatsApp terlebih dahulu.")},
        confirmButton={TextButton(onClick={model.remove(removeId!!);removeId=null}) { Text("Buang",color=Graphite.red) }},
        dismissButton={TextButton(onClick={removeId=null}) { Text("Batal") }})
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("Account Manager","Mod Hybrid — akaun aktif dipilih sendiri") }
        item { ActionButton("+ Tambah WhatsApp",onAdd,Modifier.fillMaxWidth()) }
        if(state.accounts.isEmpty()) item { BlankState("Belum ada akaun","Tambah akaun pertama untuk mula") }
        items(state.accounts,key={it.id}) { account ->
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(account.alias,fontWeight=FontWeight.SemiBold)
                            Text("+${account.phone}",color=Graphite.muted)
                            StatusPill(account.status)
                        }
                        Switch(checked=account.desired,onCheckedChange={ enabled ->
                            if(enabled) model.activate(account.id) else model.pause(account.id)
                        })
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick={onSelected(account.id);onBack()}) { Text("Pilih") }
                        TextButton(onClick={unlinkId=account.id}) { Text("Unlink") }
                        TextButton(onClick={removeId=account.id}) { Text("Buang",color=Graphite.red) }
                    }
                }
            }
        }
        item { Text("Memilih akaun untuk dipaparkan tidak mengubah keadaan sambungannya.",color=Graphite.muted,
            style=MaterialTheme.typography.bodySmall) }
        item { TextButton(onClick=onBack) { Text("Kembali") } }
    }
}

@Composable private fun GroupsScreen(state:UiSnapshot,filter:String,model:AppModel) {
    var query by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<GroupInfo?>(null) }
    var details by remember { mutableStateOf<GroupInfo?>(null) }
    var groupType by remember { mutableStateOf("All") }
    val groups=state.groups.filter {
        (filter.isBlank() || it.accountId==filter) && it.name.contains(query,true) &&
        when(groupType){"Admin"->it.admin;"Announcement"->it.announcement;"Dibenarkan"->it.approved;else->true}
    }
    val displayName=state.accounts.associate { it.id to it.alias }
    if(pending!=null) AlertDialog(onDismissRequest={pending=null},title={Text("Sahkan kebenaran group")},
        text={Text("Tandakan sebagai dibenarkan hanya jika pentadbir/peserta group bersetuju menerima mesej ini. Ini bukan kebenaran automatik daripada WhatsApp.")},
        confirmButton={TextButton(onClick={model.approveGroup(pending!!.accountId,pending!!.jid,true);pending=null}){Text("Saya sahkan")}},
        dismissButton={TextButton(onClick={pending=null}) {Text("Batal")}})
    if(details!=null) AlertDialog(onDismissRequest={details=null},title={Text(details!!.name)},
        text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text("ID: ${details!!.jid}")
            Text("Ahli: ${details!!.memberCount}")
            Text("Status admin: ${if(details!!.admin) "Ya" else "Tidak"}")
            Text("Announcement: ${if(details!!.announcement) "Ya" else "Tidak"}")
            Text("Izin kempen: ${if(details!!.approved) "Disahkan" else "Tidak disahkan"}")
        }},confirmButton={TextButton(onClick={details=null}){Text("Tutup")}})
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Group Manager","${groups.size} group • tanda izin sebelum kempen") {
            IconButton(onClick={
                state.accounts.filter { it.status=="CONNECTED" && (filter.isBlank() || it.id==filter) }.forEach { model.refreshGroups(it.id) }
            }) { Icon(Icons.Filled.Refresh,contentDescription="Sync group") }
        }
        OutlinedTextField(value=query,onValueChange={query=it},label={Text("Cari group")},singleLine=true,
            modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp),leadingIcon={Icon(Icons.Filled.Search,null)})
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=16.dp,vertical=8.dp),
            horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("All","Admin","Announcement","Dibenarkan").forEach { option ->
                FilterChip(selected=groupType==option,onClick={groupType=option},label={Text(option)})
            }
        }
        Spacer(Modifier.height(5.dp))
        if(groups.isEmpty()) BlankState("Belum ada group", "Hubungkan WhatsApp, kemudian tekan Sync Group di kanan atas.")
        else LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(groups,key={it.key}) { group ->
                GraphiteCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { details=group }) {
                            Text(group.name,fontWeight=FontWeight.SemiBold)
                            Text("${displayName[group.accountId] ?: "Akaun"} • ${group.memberCount} ahli",color=Graphite.muted,
                                style=MaterialTheme.typography.bodySmall)
                            if(group.announcement) Text("Group announcement${if(!group.admin) " • perlu admin" else ""}",color=Graphite.yellow,style=MaterialTheme.typography.labelSmall)
                            if(group.admin) Text("Pentadbir",color=Graphite.cyan,style=MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Checkbox(checked=group.approved,onCheckedChange={allowed ->
                                if(allowed) pending=group else model.approveGroup(group.accountId,group.jid,false)
                            })
                            Text("Izin",style=MaterialTheme.typography.labelSmall,color=Graphite.muted)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun ComposerScreen(state:UiSnapshot,filter:String,initialText:String,model:AppModel,onBack:()->Unit,onSaved:()->Unit) {
    val context=LocalContext.current
    var title by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable(initialText) { mutableStateOf(initialText) }
    val selected=remember { mutableStateListOf<String>() }
    var minutes by rememberSaveable { mutableIntStateOf(0) }
    var scheduleMenu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var attachment by remember { mutableStateOf("") }
    var mime by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("") }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if(uri!=null) model.importMedia(uri,context.contentResolver) { path,type,name ->
            attachment=path;mime=type;fileName=name
        }
    }
    // Only sender accounts with known permission appear in the recipient selector.
    val enabled=state.accounts.filter { it.desired && it.status=="CONNECTED" }.map { it.id }.toSet()
    val available=state.groups.filter { it.approved && (!it.announcement || it.admin) && it.accountId in enabled && (filter.isBlank() || it.accountId==filter) }
        .distinctBy { it.jid }
    val accountNames=state.accounts.associate { it.id to it.alias }
    if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("Sahkan kempen")},
        text={Text("Hantar kepada ${selected.size} group yang ditanda dibenarkan? Anda bertanggungjawab memastikan penerima bersetuju. Tiada percubaan semula automatik untuk status tidak pasti.")},
        confirmButton={TextButton(onClick={
            model.createCampaign(title,message,selected.toSet(),minutes,attachment,mime,fileName,onSaved)
            confirm=false
        }) { Text("Sahkan") }},
        dismissButton={TextButton(onClick={confirm=false}) {Text("Semak semula")}})
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("New Broadcast","Pratonton & pengesahan sebelum hantar") }
        item {
            OutlinedTextField(value=title,onValueChange={title=it.take(80)},label={Text("Nama kempen")},
                modifier=Modifier.fillMaxWidth(),singleLine=true)
        }
        item {
            OutlinedTextField(value=message,onValueChange={if(it.toByteArray().size<=16384) message=it},
                label={Text("Kandungan mesej")},modifier=Modifier.fillMaxWidth().heightIn(min=140.dp),minLines=4,maxLines=9)
        }
        item {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                OutlinedButton(onClick={picker.launch("*/*")}) {
                    Icon(Icons.Filled.AttachFile,null);Spacer(Modifier.width(8.dp));Text("Lampiran")
                }
                if(fileName.isNotBlank()) Text(fileName,modifier=Modifier.weight(1f).padding(start=12.dp),maxLines=1,
                    overflow=TextOverflow.Ellipsis,color=Graphite.muted)
                if(attachment.isNotBlank()) IconButton(onClick={attachment="";fileName="";mime=""}) {
                    Icon(Icons.Filled.Close,"Buang lampiran")
                }
            }
        }
        item {
            SectionTitle("Pilih group dibenarkan (${selected.size})")
            Text("Group merentas akaun didedup mengikut ID group.",color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
        }
        if(available.isEmpty()) item { BlankState("Tiada sasaran", "Aktifkan akaun, sync group dan sahkan kebenaran group di Group Manager.") }
        items(available,key={it.key}) { group ->
            Row(Modifier.fillMaxWidth().clickable {
                if(group.key in selected) selected.remove(group.key) else selected.add(group.key)
            }.padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                Checkbox(checked=group.key in selected,onCheckedChange={yes ->
                    if(yes && group.key !in selected) selected.add(group.key)
                    if(!yes) selected.remove(group.key)
                })
                Column(Modifier.padding(start=8.dp)) {
                    Text(group.name,fontWeight=FontWeight.Medium)
                    Text(accountNames[group.accountId] ?: "Akaun",color=Graphite.muted,
                        style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            SectionTitle("Jadual penghantaran")
            Box {
                OutlinedButton(onClick={scheduleMenu=true}) { Text(when(minutes){0->"Sekarang";else->"Selepas $minutes minit"}) }
                DropdownMenu(expanded=scheduleMenu,onDismissRequest={scheduleMenu=false}) {
                    listOf(0,5,15,60).forEach { n ->
                        DropdownMenuItem(text={Text(if(n==0) "Sekarang" else "Selepas $n minit")},onClick={minutes=n;scheduleMenu=false})
                    }
                }
            }
            Text("Jadual setempat hanya diproses apabila enjin aplikasi berjalan.",color=Graphite.yellow,
                style=MaterialTheme.typography.bodySmall)
        }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("Preview",color=Graphite.cyan,fontWeight=FontWeight.SemiBold)
                    Text(message.ifBlank { "[Tiada teks]" })
                    if(fileName.isNotBlank()) Text("Lampiran: $fileName",color=Graphite.muted)
                    Text("${selected.size} group terpilih",color=Graphite.muted)
                }
            }
        }
        item {
            ActionButton("Semak & Cipta Kempen",{ confirm=true },Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            TextButton(onClick=onBack) { Text("Kembali") }
        }
    }
}

@Composable private fun CampaignsScreen(state:UiSnapshot,model:AppModel,onNew:()->Unit) {
    var action by remember { mutableStateOf<Pair<Campaign,String>?>(null) }
    if(action!=null) {
        val (campaign,status)=action!!
        AlertDialog(onDismissRequest={action=null},title={Text("Tindakan kempen")},
            text={Text("${campaign.title}: ${status.lowercase()}? Tugasan penghantaran yang sedang diproses mungkin selesai sebelum arahan berkuat kuasa.")},
            confirmButton={TextButton(onClick={model.campaignAction(campaign.id,status);action=null}) {Text("Sahkan")}},
            dismissButton={TextButton(onClick={action=null}) {Text("Batal")}})
    }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("Campaigns","Kempen satu akaun atau multi-account") }
        item { ActionButton("+ New Broadcast",onNew,Modifier.fillMaxWidth()) }
        if(state.campaigns.isEmpty()) item { BlankState("Tiada kempen", "Kempen akan dipaparkan di sini selepas dicipta.") }
        items(state.campaigns,key={it.id}) { campaign ->
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(campaign.title,fontWeight=FontWeight.SemiBold)
                            Text(campaign.scope,color=Graphite.muted,style=MaterialTheme.typography.labelSmall)
                        }
                        StatusPill(campaign.status)
                    }
                    Text("${campaign.sent} sent • ${campaign.failed} failed • ${campaign.unknown} unknown • ${campaign.total} sasaran",
                        color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(progress={if(campaign.total==0) 0f else
                        (campaign.sent+campaign.failed+campaign.unknown).toFloat()/campaign.total},
                        modifier=Modifier.fillMaxWidth(),color=Graphite.cyan,trackColor=Graphite.raised)
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        if(campaign.status in setOf("DRAFT","PAUSED","SCHEDULED")) TextButton(onClick={action=campaign to "RUNNING"}){Text("Mula / Sambung")}
                        if(campaign.status=="RUNNING") TextButton(onClick={action=campaign to "PAUSED"}){Text("Jeda")}
                        if(campaign.status !in setOf("CANCELLED","COMPLETED")) TextButton(onClick={action=campaign to "CANCELLED"}){Text("Batal",color=Graphite.red)}
                    }
                }
            }
        }
    }
}

@Composable private fun HistoryScreen(state:UiSnapshot) {
    var filter by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Messages") }
    val context=LocalContext.current
    val exportLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if(uri!=null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { out ->
                out.appendLine("kind,time,account,campaign,group,status,message_id,error")
                state.history.forEach { row ->
                    fun esc(v:String)="\""+v.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\""
                    out.appendLine(listOf("MESSAGE",row.time.toString(),row.accountId,row.campaignTitle,row.jid,row.status,row.messageId,row.error)
                        .joinToString(","){esc(it)})
                }
                state.logs.forEach { log ->
                    fun esc(v:String)="\""+v.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\""
                    out.appendLine(listOf("LOG",log.time.toString(),log.accountId,"","",log.level,"",log.message)
                        .joinToString(","){esc(it)})
                }
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("History & Logs","Status sebenar dan diagnostik setempat") {
            IconButton(onClick={exportLauncher.launch("messagehub-history.csv")}) {
                Icon(Icons.Filled.SaveAlt,"Eksport CSV")
            }
        }
        Row(Modifier.padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            listOf("Messages","Activity").forEach { choice -> FilterChip(selected=tab==choice,
                onClick={tab=choice},label={Text(choice)}) }
        }
        if(state.accounts.isNotEmpty()) {
            ScrollableTabRow(selectedTabIndex=(state.accounts.indexOfFirst{it.id==filter}+1).coerceAtLeast(0),
                edgePadding=16.dp,containerColor=Graphite.bg) {
                Tab(selected=filter.isBlank(),onClick={filter=""},text={Text("Semua")})
                state.accounts.forEach { item -> Tab(selected=filter==item.id,onClick={filter=item.id},text={Text(item.alias)}) }
            }
        }
        if(tab=="Messages") {
            val rows=state.history.filter { filter.isBlank() || it.accountId==filter }
            if(rows.isEmpty()) BlankState("Tiada rekod mesej","Percubaan penghantaran muncul di sini apabila kempen bermula.")
            else LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(rows) { row ->
                    GraphiteCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                Text(row.campaignTitle,Modifier.weight(1f),fontWeight=FontWeight.Medium)
                                StatusPill(row.status)
                            }
                            Text(row.jid,color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                            Text(java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault())
                                .format(java.util.Date(row.time)),color=Graphite.muted,style=MaterialTheme.typography.labelSmall)
                            if(row.error.isNotBlank()) Text("Ralat: ${row.error}",color=Graphite.yellow)
                            if(row.messageId.isNotBlank()) Text("Message ID: ${row.messageId}",color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        } else {
            val logs=state.logs.filter { filter.isBlank() || it.accountId==filter }
            if(logs.isEmpty()) BlankState("Tiada log", "Log akan direkodkan apabila aplikasi digunakan.")
            else LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(logs) { entry ->
                    GraphiteCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                Text(entry.level,color=when(entry.level){"ERROR"->Graphite.red;"WARN"->Graphite.yellow;else->Graphite.cyan},
                                    style=MaterialTheme.typography.labelMedium)
                                Text(java.text.SimpleDateFormat("dd/MM HH:mm",java.util.Locale.getDefault())
                                    .format(java.util.Date(entry.time)),color=Graphite.muted,style=MaterialTheme.typography.labelSmall)
                            }
                            Text(entry.message)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun TemplatesScreen(state:UiSnapshot,model:AppModel,onBack:()->Unit,onUse:(String)->Unit) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    if(deleting!=null) AlertDialog(onDismissRequest={deleting=null},title={Text("Padam template?")},
        text={Text("Tindakan ini tidak boleh dibatalkan.")},
        confirmButton={TextButton(onClick={model.deleteTemplate(deleting!!);deleting=null}){Text("Padam",color=Graphite.red)}},
        dismissButton={TextButton(onClick={deleting=null}) {Text("Batal")}})
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("Templates","Simpan teks yang kerap digunakan") }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title,{title=it.take(80)},label={Text("Nama template")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(message,{message=it.take(8192)},label={Text("Mesej")},modifier=Modifier.fillMaxWidth(),minLines=3)
                    ActionButton(if(editing==null) "Simpan template" else "Kemas kini",{
                        model.saveTemplate(title,message,editing);title="";message="";editing=null
                    },Modifier.fillMaxWidth())
                }
            }
        }
        items(state.templates,key={it.id}) { temp ->
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text(temp.title,fontWeight=FontWeight.SemiBold)
                    Text(temp.body,maxLines=3,overflow=TextOverflow.Ellipsis,color=Graphite.muted)
                    Row {
                        TextButton(onClick={onUse(temp.body)}) {Text("Guna")}
                        TextButton(onClick={title=temp.title;message=temp.body;editing=temp.id}) {Text("Edit")}
                        TextButton(onClick={deleting=temp.id}) {Text("Padam",color=Graphite.red)}
                    }
                }
            }
        }
        item { TextButton(onClick=onBack) { Text("Kembali") } }
    }
}

@Composable private fun SettingsScreen(state:UiSnapshot,model:AppModel,onAccounts:()->Unit,onTemplates:()->Unit,onRetry:()->Unit) {
    var confirmPause by remember { mutableStateOf(false) }
    if(confirmPause) AlertDialog(onDismissRequest={confirmPause=false},title={Text("Jeda semua akaun?")},
        text={Text("Semua socket WhatsApp aktif akan dihentikan sementara. Sesi dan kempen disimpan.")},
        confirmButton={TextButton(onClick={model.pauseAll();confirmPause=false}) {Text("Jeda semua")}},
        dismissButton={TextButton(onClick={confirmPause=false}) {Text("Batal")}})
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("Settings & Diagnostics","Semua data utama disimpan di telefon") }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Pengurusan")
                    OutlinedButton(onClick=onAccounts,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Filled.Group,null);Spacer(Modifier.width(8.dp));Text("Account Manager") }
                    OutlinedButton(onClick=onTemplates,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Filled.Description,null);Spacer(Modifier.width(8.dp));Text("Message Templates") }
                    OutlinedButton(onClick=onRetry,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Filled.Refresh,null);Spacer(Modifier.width(8.dp));Text("Mulakan / Semak enjin") }
                }
            }
        }
        item { PinSettings() }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    SectionTitle("Diagnostik enjin")
                    Text("Runtime: ${if(state.engineReady) "Ready" else "Offline / starting"}")
                    Text("Node.js: ${state.nodeVersion}")
                    Text("Memori proses: ±${state.memoryMb} MB")
                    Text("Sesi aktif: ${state.accounts.count{it.status=="CONNECTED"}}")
                    Text("Baileys: 6.7.9 (pin, perlu sahkan pada peranti)",color=Graphite.muted)
                    if(state.memoryMb > 256) Text("Amaran: Penggunaan RAM tinggi. Jeda beberapa akaun.",color=Graphite.yellow)
                }
            }
        }
        item {
            GraphiteCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Keselamatan & operasi")
                    Text("Sesi WhatsApp disulitkan menggunakan Android Keystore. Backup sesi dimatikan.",color=Graphite.muted)
                    Text("Sambungan Node melalui 127.0.0.1 dengan token sementara.",color=Graphite.muted)
                    Text("Tanpa VPS: background tertakluk pada had Android dan bateri.",color=Graphite.muted)
                    OutlinedButton(onClick={confirmPause=true},modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Pause,null);Spacer(Modifier.width(8.dp));Text("Jeda semua akaun")
                    }
                }
            }
        }
    }
}


@Composable private fun PinLockScreen(pinStore: PinStore,onSuccess:()->Unit) {
    var pin by remember {mutableStateOf("")}
    var error by remember {mutableStateOf("")}
    Column(Modifier.fillMaxSize().background(Graphite.bg).padding(30.dp),
        verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Filled.Lock,null,tint=Graphite.cyan,modifier=Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Kunci Aplikasi",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value=pin,onValueChange={pin=it.filter(Char::isDigit).take(8)},
            label={Text("PIN")},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),
            keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.NumberPassword),
            modifier=Modifier.fillMaxWidth(),singleLine=true)
        if(error.isNotBlank()) Text(error,color=Graphite.red,modifier=Modifier.padding(top=8.dp))
        Spacer(Modifier.height(14.dp))
        ActionButton("Buka aplikasi", {
            if(pinStore.unlock(pin)) {pin="";onSuccess()}
            else {error="PIN salah. ${pinStore.cooldownSeconds()} saat menunggu jika disekat";pin=""}
        },Modifier.fillMaxWidth())
    }
}

@Composable private fun PinSettings() {
    val context=LocalContext.current
    val pinStore=remember(context){PinStore(context)}
    var enabled by remember {mutableStateOf(pinStore.enabled())}
    var pin by remember {mutableStateOf("")}
    var feedback by remember {mutableStateOf("")}
    GraphiteCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            SectionTitle("Kunci aplikasi (PIN pilihan)")
            Text(if(enabled) "PIN aktif • masukkan PIN untuk mematikannya" else "PIN 4–8 digit untuk melindungi akses aplikasi",
                color=Graphite.muted,style=MaterialTheme.typography.bodySmall)
            OutlinedTextField(value=pin,onValueChange={pin=it.filter(Char::isDigit).take(8)},label={Text("PIN")},
                visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),
                keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedButton(onClick={
                if(!enabled) {
                    runCatching {pinStore.set(pin)}.onSuccess {enabled=true;feedback="PIN diaktifkan"}
                        .onFailure {feedback=it.message ?: "PIN tidak sah"}
                } else {
                    if(pinStore.disable(pin)) {enabled=false;feedback="PIN dimatikan"}
                    else feedback="PIN salah"
                }
                pin=""
            },modifier=Modifier.fillMaxWidth()) {
                Text(if(enabled) "Matikan PIN" else "Aktifkan PIN")
            }
            if(feedback.isNotBlank()) Text(feedback,color=Graphite.muted)
        }
    }
}
