package com.earlxcode.messagehub.data

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Optional local app PIN. Salted PBKDF2; separate from WhatsApp pairing. */
class PinStore(context: Context) {
    private val prefs = context.getSharedPreferences("app_lock", Context.MODE_PRIVATE)
    fun enabled()=prefs.contains("hash")
    private fun hash(pin:String,salt:ByteArray):ByteArray {
        val spec=PBEKeySpec(pin.toCharArray(),salt,180000,256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
    fun set(pin:String) {
        require(pin.matches(Regex("^[0-9]{4,8}$"))) { "PIN mesti 4 hingga 8 digit" }
        val salt=ByteArray(16).also {SecureRandom().nextBytes(it)}
        prefs.edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
            .putString("hash",Base64.encodeToString(hash(pin,salt),Base64.NO_WRAP)).apply()
    }
    fun unlock(pin:String):Boolean {
        val now=System.currentTimeMillis()
        if(now<prefs.getLong("until",0)) return false
        val salt=Base64.decode(prefs.getString("salt","") ?: "",Base64.DEFAULT)
        val expected=Base64.decode(prefs.getString("hash","") ?: "",Base64.DEFAULT)
        val valid=runCatching { MessageDigest.isEqual(hash(pin,salt),expected) }.getOrDefault(false)
        if(valid) prefs.edit().putInt("failures",0).putLong("until",0).apply()
        else {
            val failed=prefs.getInt("failures",0)+1
            val duration=if(failed>=5) 60_000L else 0L
            prefs.edit().putInt("failures",failed).putLong("until",now+duration).apply()
        }
        return valid
    }
    fun disable(correctPin:String):Boolean {
        if(!unlock(correctPin)) return false
        prefs.edit().clear().apply();return true
    }
    fun cooldownSeconds():Long=((prefs.getLong("until",0)-System.currentTimeMillis()).coerceAtLeast(0)+999)/1000
}
