package com.earlxcode.messagehub.bridge

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Every connection is loopback-only and uses a per-launch 256-bit capability token. */
class NodeClient(private val getToken: () -> String) {
    suspend fun get(path: String): JSONObject = request("GET",path,null)
    suspend fun post(path: String, body: JSONObject = JSONObject()): JSONObject = request("POST",path,body)
    suspend fun request(method: String, path: String, body: JSONObject?): JSONObject = withContext(Dispatchers.IO) {
        require(path.startsWith("/") && !path.startsWith("//"))
        val con = URL("http://127.0.0.1:38741$path").openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 2500
            con.readTimeout = 18000
            con.requestMethod = method
            con.setRequestProperty("X-Bridge-Token",getToken())
            con.setRequestProperty("Accept","application/json")
            if (body != null) {
                con.doOutput = true
                con.setRequestProperty("Content-Type","application/json")
                con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val response = (if (con.responseCode in 200..299) con.inputStream else con.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            val parsed = JSONObject(response)
            if (con.responseCode !in 200..299 || !parsed.optBoolean("ok",true)) {
                throw IOException(parsed.optString("error", "HTTP ${con.responseCode}"))
            }
            parsed
        } finally { con.disconnect() }
    }
}
