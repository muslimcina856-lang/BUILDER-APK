package com.earlxcode.messagehub.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import android.app.PendingIntent
import com.earlxcode.messagehub.MainActivity
import com.earlxcode.messagehub.data.LocalDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.SocketTimeoutException

/** User-visible foreground work. Not a claim of unlimited 24/7 background execution. */
class NodeEngineService : Service() {
    companion object { const val ACTION_START="messagehub.START"; const val ACTION_STOP="messagehub.STOP" }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var db: LocalDb
    override fun onCreate() {
        super.onCreate()
        db = LocalDb(this)
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("engine","Enjin WhatsApp",NotificationManager.IMPORTANCE_LOW))
        val intent=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this,"engine")
            .setContentTitle("Message Hub")
            .setContentText("Enjin WhatsApp sedang dijalankan pada telefon")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(intent).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(19,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(19,notification)
        try { EngineRuntime.start(this) } catch (e: Throwable) { db.log("","ERROR","Node initialization: ${e.javaClass.simpleName}") }
        scope.launch { dispatcherLoop() }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action==ACTION_STOP) {
            // Do not cancel the coroutine before Node sockets receive pause-all.
            scope.launch {
                try {
                    db.accounts().forEach {
                        db.setDesired(it.id,false)
                        db.setAccountState(it.id,"PAUSED")
                    }
                    runCatching { EngineRuntime.client.post("/accounts/pause-all") }
                } finally {
                    stopSelf(startId)
                }
            }
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }
    private suspend fun dispatcherLoop() {
        // Start/resume only explicitly enabled accounts. Each account is isolated.
        val requested = mutableSetOf<String>()
        while(scope.isActive) {
            try {
                EngineRuntime.client.get("/health")
                for (account in db.accounts()) {
                    if (account.desired && account.id !in requested) {
                        EngineRuntime.client.post("/accounts/activate",JSONObject().put("accountId",account.id).put("phone",account.phone))
                        requested += account.id
                    }
                    if (!account.desired) requested.remove(account.id)
                }
                db.activateScheduled()
                val target = db.nextTarget()
                if (target != null) {
                    try {
                        val body = JSONObject()
                            .put("accountId",target.accountId)
                            .put("jid",target.jid)
                            .put("text",target.text)
                            .put("attachment",target.attachment)
                            .put("mime",target.mime)
                            .put("fileName",target.fileName)
                        val result=EngineRuntime.client.post("/messages/send",body)
                        db.finishTarget(target.id,"SENT",result.optString("messageId"))
                    } catch (e: Exception) {
                        // Timeout can mean WhatsApp actually received it. NEVER auto retry.
                        val unclear = e is SocketTimeoutException || e.message?.contains("timed out",true)==true
                        db.finishTarget(target.id,if (unclear) "UNKNOWN" else "FAILED",error=e.message ?: "Transmission error")
                    }
                }
            } catch (_: Exception) { /* engine starting or network interrupted; retry */ }
            delay(1500)
        }
    }
    override fun onTimeout(startId: Int, fgsType: Int) {
        db.log("","WARN","Android mengakhiri servis foreground (had masa)")
        stopSelf()
    }
    override fun onDestroy() {
        scope.cancel()
        // Node remains within this process until the OS exits; Android Mobile cannot restart it.
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
