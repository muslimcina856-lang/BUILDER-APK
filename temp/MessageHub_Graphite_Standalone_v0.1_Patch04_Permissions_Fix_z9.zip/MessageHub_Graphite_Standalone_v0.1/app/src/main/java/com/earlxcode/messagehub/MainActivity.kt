package com.earlxcode.messagehub

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.earlxcode.messagehub.service.NodeEngineService
import com.earlxcode.messagehub.ui.AppModel
import com.earlxcode.messagehub.ui.MessageHubApp
import com.earlxcode.messagehub.ui.MessageHubTheme

class MainActivity : ComponentActivity() {
    private val appModel:AppModel by viewModels()
    private val notifications=registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=android.graphics.Color.rgb(16,20,24)
        window.navigationBarColor=android.graphics.Color.rgb(16,20,24)
        // Service is started by a visible, user-initiated app launch.
        try {
            ContextCompat.startForegroundService(this,Intent(this,NodeEngineService::class.java).setAction(NodeEngineService.ACTION_START))
        } catch (ignored: Exception) {
            // UI displays 'Engine offline' and permits retry.
        }
        if(Build.VERSION.SDK_INT>=33) notifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MessageHubTheme { MessageHubApp(appModel) } }
    }
}
