package com.earlxcode.messagehub.bridge

object NativeNodeBridge {
    init {
        System.loadLibrary("node")
        System.loadLibrary("nodebridge")
    }
    external fun startNode(args: Array<String>): Int
}
