package com.earlxcode.messagehub.data

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts Baileys auth blobs at rest. Never log contents or export by default. */
class SecureVault(private val db: LocalDb) {
    private val alias = "messagehub_auth_v1"
    private val store: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private fun getOrCreate(): SecretKey {
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build())
        }.generateKey()
    }
    @Synchronized fun read(accountId: String, key: String): String? {
        val ciphertext = db.getCipher(accountId,key) ?: return null
        val bytes = Base64.decode(ciphertext,Base64.NO_WRAP)
        require(bytes.size >= 29)
        val iv = bytes.copyOfRange(0,12)
        val encrypted = bytes.copyOfRange(12,bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,getOrCreate(),GCMParameterSpec(128,iv))
        cipher.updateAAD("$accountId:$key".toByteArray(Charsets.UTF_8))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }
    @Synchronized fun write(accountId: String, key: String, plaintext: String?) {
        if (plaintext == null) { db.putCipher(accountId,key,null); return }
        require(plaintext.toByteArray().size <= 1_048_576) { "Auth blob too large" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE,getOrCreate(),GCMParameterSpec(128,iv))
        cipher.updateAAD("$accountId:$key".toByteArray(Charsets.UTF_8))
        val data = iv + cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        db.putCipher(accountId,key,Base64.encodeToString(data,Base64.NO_WRAP))
    }
    @Synchronized fun clear(accountId: String) = db.clearAuth(accountId)
}
