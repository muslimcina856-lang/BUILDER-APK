package com.earlxcode.messagehub.bridge

import com.earlxcode.messagehub.data.LocalDb
import com.earlxcode.messagehub.data.SecureVault
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors

/** Tiny private Android-side host for Node -> encrypted Android Keystore vault & events. */
class LocalHostServer(
    private val db: LocalDb,
    private val vault: SecureVault,
    private val token: String
) {
    @Volatile private var started = false
    private var server: ServerSocket? = null
    private val pool = Executors.newFixedThreadPool(3)
    fun start() {
        if (started) return
        server = ServerSocket(38742,12,InetAddress.getByName("127.0.0.1"))
        started = true
        Thread({
            while (started) {
                val client = try { server?.accept() } catch (_: Exception) { null } ?: break
                pool.execute { client.use { handle(it) } }
            }
        }, "android-bridge-http").apply { isDaemon = true; start() }
    }
    fun stop() { started = false; server?.close(); pool.shutdownNow() }

    private fun readLineBounded(input: InputStream, max: Int=8192): String {
        val out = StringBuilder()
        while (out.length < max) {
            val b = input.read()
            if (b < 0) break
            if (b == 10) return out.toString().trimEnd('\r')
            out.append(b.toChar())
        }
        throw IllegalArgumentException("HTTP header too large")
    }
    private fun send(out: OutputStream, code: Int, response: JSONObject) {
        val bytes = response.toString().toByteArray(Charsets.UTF_8)
        val status = when(code){ 200->"OK";401->"Unauthorized";404->"Not Found";else->"Bad Request" }
        val head = "HTTP/1.1 $code $status\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII));out.write(bytes);out.flush()
    }
    private fun handle(socket: Socket) {
        socket.soTimeout = 8000
        try {
            val input = BufferedInputStream(socket.getInputStream())
            val output = BufferedOutputStream(socket.getOutputStream())
            val first = readLineBounded(input).split(' ')
            require(first.size >= 2)
            val method = first[0]; val path = first[1]
            val headers = mutableMapOf<String,String>()
            for (i in 0 until 35) {
                val line = readLineBounded(input)
                if(line.isEmpty()) break
                val idx=line.indexOf(':')
                if(idx>0) headers[line.substring(0,idx).trim().lowercase()] = line.substring(idx+1).trim()
            }
            // Reject other local applications without the random token.
            val provided = headers["x-bridge-token"] ?: ""
            if(!MessageDigest.isEqual(provided.toByteArray(),token.toByteArray())) {
                send(output,401,JSONObject().put("ok",false).put("error","Unauthorized"));return
            }
            if(method!="POST") {send(output,404,JSONObject().put("ok",false).put("error","POST required"));return}
            val size = headers["content-length"]?.toIntOrNull() ?: 0
            require(size in 0..1_048_576) { "Invalid Content-Length" }
            val body = ByteArray(size)
            var pos=0
            while(pos<size) {
                val n = input.read(body,pos,size-pos)
                if(n<0) error("Short HTTP body")
                pos+=n
            }
            val json = JSONObject(String(body,Charsets.UTF_8))
            val id = json.optString("accountId")
            val key = json.optString("key")
            val result = when(path) {
                "/vault/get" -> {
                    require(id.isNotBlank() && key.length in 1..200)
                    JSONObject().put("ok",true).put("value",vault.read(id,key))
                }
                "/vault/set" -> {
                    require(id.isNotBlank() && key.length in 1..200)
                    vault.write(id,key,if (json.isNull("value")) null else json.getString("value"))
                    JSONObject().put("ok",true)
                }
                "/vault/clear" -> {
                    require(id.isNotBlank());vault.clear(id);JSONObject().put("ok",true)
                }
                "/event" -> {
                    require(id.isNotBlank() && db.account(id)!=null)
                    when(json.optString("type")) {
                        "status" -> {
                            val state = json.optString("state", "ERROR")
                            db.setAccountState(id,state,json.optString("code"),json.optString("qr"))
                        }
                        "log" -> db.log(id,json.optString("level","INFO"),json.optString("message",""))
                    }
                    JSONObject().put("ok",true)
                }
                else -> {send(output,404,JSONObject().put("ok",false).put("error","Unknown route"));return}
            }
            send(output,200,result)
        } catch (_: Exception) {
            try { send(socket.getOutputStream(),400,JSONObject().put("ok",false).put("error","Invalid request")) } catch (_: Exception) {}
        }
    }
}
