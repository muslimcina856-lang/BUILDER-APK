package com.earlxcode.messagehub.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.earlxcode.messagehub.data.*
import com.earlxcode.messagehub.service.EngineRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class UiSnapshot(
    val accounts: List<Account> = emptyList(),
    val groups: List<GroupInfo> = emptyList(),
    val campaigns: List<Campaign> = emptyList(),
    val templates: List<MessageTemplate> = emptyList(),
    val logs: List<LogEntry> = emptyList(),
    val history: List<TargetHistory> = emptyList(),
    val engineReady: Boolean = false,
    val nodeVersion: String = "—",
    val memoryMb: Long = 0,
    val notice: String = ""
)

class AppModel(app: Application):AndroidViewModel(app) {
    private val db = LocalDb(app)
    private val _state = MutableStateFlow(UiSnapshot())
    val state: StateFlow<UiSnapshot> = _state
    init {
        viewModelScope.launch {
            while(isActive) {
                refresh()
                delay(1500)
            }
        }
    }
    private suspend fun refresh() {
        val snapshot = withContext(Dispatchers.IO) {
            val health = runCatching { EngineRuntime.client.get("/health") }.getOrNull()
            UiSnapshot(db.accounts(),db.groups(),db.campaigns(),db.templates(),db.logs(),db.targetHistory(),
                health != null,health?.optString("node") ?: "—",
                health?.optLong("memory",0L)?.div(1024L*1024L) ?: 0L,
                _state.value.notice)
        }
        _state.value=snapshot
    }
    fun clearNotice() { _state.value = _state.value.copy(notice="") }
    private fun work(label:String, action:suspend ()->Unit) {
        viewModelScope.launch {
            try { action();refresh(); _state.value = _state.value.copy(notice="$label berjaya") }
            catch(e:Exception) { _state.value = _state.value.copy(notice="$label gagal: ${e.message ?: "Ralat"}") }
        }
    }
    fun addAccount(alias:String, phone:String, onCreated:(String)->Unit) = work("Tambah akaun") {
        val result=withContext(Dispatchers.IO) { db.addAccount(alias,phone) }
        onCreated(result.id)
        activate(result.id)
    }
    fun activate(id:String) = work("Aktifkan akaun") {
        val account=db.account(id) ?: error("Akaun tiada")
        withContext(Dispatchers.IO) { db.setDesired(id,true);db.setAccountState(id,"CONNECTING") }
        EngineRuntime.client.post("/accounts/activate",JSONObject().put("accountId",id).put("phone",account.phone))
    }
    fun requestCode(id:String) = work("Minta kod pairing") {
        EngineRuntime.client.post("/accounts/request-code",JSONObject().put("accountId",id))
    }
    fun pause(id:String) = work("Jeda akaun") {
        withContext(Dispatchers.IO) { db.setDesired(id,false);db.setAccountState(id,"PAUSED") }
        EngineRuntime.client.post("/accounts/pause",JSONObject().put("accountId",id))
    }
    fun unlink(id:String) = work("Unlink akaun") {
        withContext(Dispatchers.IO) { db.setDesired(id,false) }
        EngineRuntime.client.post("/accounts/unlink",JSONObject().put("accountId",id))
    }
    fun remove(id:String) = work("Buang akaun") {
        val acc=db.account(id) ?: return@work
        if(acc.desired) EngineRuntime.client.post("/accounts/pause",JSONObject().put("accountId",id))
        withContext(Dispatchers.IO) { db.removeAccount(id) }
    }
    fun refreshGroups(id:String) = work("Segar semula group") {
        val response=EngineRuntime.client.post("/groups/sync",JSONObject().put("accountId",id))
        withContext(Dispatchers.IO) { db.upsertGroups(id,response.getJSONArray("groups")) }
    }
    fun approveGroup(accountId:String,jid:String,approved:Boolean) = work(if(approved) "Benarkan group" else "Batalkan kebenaran") {
        withContext(Dispatchers.IO) { db.allowGroup(accountId,jid,approved) }
    }
    fun saveTemplate(title:String,body:String,existing:String?=null) = work("Simpan template") {
        withContext(Dispatchers.IO) { db.saveTemplate(title,body,existing) }
    }
    fun deleteTemplate(id:String) = work("Padam template") { withContext(Dispatchers.IO) { db.deleteTemplate(id) } }
    fun createCampaign(title:String,text:String,keys:Set<String>,minutes:Int,attachment:String="",mime:String="",name:String="",done:()->Unit) = work("Cipta kempen") {
        val id=withContext(Dispatchers.IO) { db.createCampaign(title,text,keys,attachment,mime,name) }
        withContext(Dispatchers.IO) { db.scheduleCampaign(id,minutes) }
        done()
    }
    fun campaignAction(id:String,status:String) = work("Kempen") {
        withContext(Dispatchers.IO) { db.setCampaignStatus(id,status) }
    }
    fun pauseAll() = work("Jeda semua akaun") {
        val list = db.accounts()
        withContext(Dispatchers.IO) { list.forEach { db.setDesired(it.id,false) } }
        EngineRuntime.client.post("/accounts/pause-all")
    }
    fun importMedia(uri:Uri, resolver:ContentResolver, onSuccess:(String,String,String)->Unit) = work("Lampiran") {
        val mime=resolver.getType(uri) ?: "application/octet-stream"
        require(mime.startsWith("image/") || mime.startsWith("video/") || mime=="application/pdf" || mime.startsWith("text/") || mime=="application/octet-stream") {
            "Jenis media tidak disokong"
        }
        val originalName=resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "document"
        val name=originalName.replace(Regex("[^a-zA-Z0-9._-]"),"_").takeLast(100)
        val target=File(getApplication<Application>().filesDir,"attachments/${UUID.randomUUID()}_${name}")
        withContext(Dispatchers.IO) {
            target.parentFile?.mkdirs()
            try {
              resolver.openInputStream(uri)?.use { source ->
                target.outputStream().use { output ->
                    val buffer=ByteArray(32768)
                    var copied=0L
                    while(true) {
                        val n=source.read(buffer)
                        if(n<0) break
                        copied+=n
                        require(copied<=15*1024*1024) { "Lampiran maksimum 15 MB" }
                        output.write(buffer,0,n)
                    }
                }
              } ?: error("Fail tidak dapat dibaca")
            } catch (e:Exception) {
                target.delete()
                throw e
            }
        }
        onSuccess(target.absolutePath,mime,name)
    }
}
