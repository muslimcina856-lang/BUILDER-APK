package com.earlxcode.messagehub.service

import android.content.Context
import com.earlxcode.messagehub.bridge.LocalHostServer
import com.earlxcode.messagehub.bridge.NativeNodeBridge
import com.earlxcode.messagehub.bridge.NodeClient
import com.earlxcode.messagehub.data.LocalDb
import com.earlxcode.messagehub.data.SecureVault
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom

/** App-process singleton: Node.js Mobile cannot be restarted inside the same process. */
object EngineRuntime {
    @Volatile private var started = false
    @Volatile private var ready = false
    private lateinit var db: LocalDb
    private var host: LocalHostServer? = null
    private var secret: String = ""
    val client: NodeClient = NodeClient { secret }
    fun isStarted(): Boolean = started
    fun isReady(): Boolean = ready
    @Synchronized fun start(context: Context) {
        if (started) return
        val app = context.applicationContext
        db = LocalDb(app)
        db.markInterruptedUnknown()
        secret = ByteArray(32).also { SecureRandom().nextBytes(it) }
            .joinToString("") { "%02x".format(it) }
        val tokenFile = File(app.filesDir,"bridge.token")
        tokenFile.writeText(secret)
        tokenFile.setReadable(false,false)
        tokenFile.setReadable(true,true)
        host = LocalHostServer(db,SecureVault(db),secret).also { it.start() }
        val target = File(app.filesDir,"node-engine")
        copyAssets(app,target)
        started = true
        Thread({
            try {
                val code = NativeNodeBridge.startNode(arrayOf(
                    "node",File(target,"main.js").absolutePath,
                    "--token-file",tokenFile.absolutePath,
                    "--data-dir",app.filesDir.absolutePath,
                    "--port","38741"
                ))
                db.log("","ERROR","Enjin Node.js tamat dengan kod $code")
            } catch (error: Throwable) {
                db.log("","ERROR","Gagal memulakan enjin: ${error.javaClass.simpleName}")
            } finally { ready=false }
        },"nodejs-mobile-engine").start()
        // Node reports its status through /health. No false "connected" state assumed here.
    }
    private fun copyAssets(context: Context, target: File) {
        val assetVersion=context.assets.open("nodejs-project/version.txt").bufferedReader().use { it.readText().trim() }
        val marker=File(target,".assets-version")
        if (target.exists() && File(target,"main.js").exists() && marker.exists() && marker.readText().trim()==assetVersion) return
        if(target.exists()) target.deleteRecursively()
        target.mkdirs()
        fun copyDir(assetDir: String, dir: File) {
            val children = context.assets.list(assetDir) ?: emptyArray()
            if (children.isEmpty()) {
                context.assets.open(assetDir).use { source ->
                    dir.parentFile?.mkdirs()
                    FileOutputStream(dir).use { targetStream -> source.copyTo(targetStream) }
                }
            } else {
                dir.mkdirs()
                for (child in children) copyDir("$assetDir/$child",File(dir,child))
            }
        }
        copyDir("nodejs-project",target)
        marker.writeText(assetVersion)
    }
}
