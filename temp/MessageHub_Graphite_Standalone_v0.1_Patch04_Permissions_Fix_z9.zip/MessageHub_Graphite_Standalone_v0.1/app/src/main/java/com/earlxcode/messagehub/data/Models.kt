package com.earlxcode.messagehub.data

data class Account(
    val id: String,
    val alias: String,
    val phone: String,
    val status: String = "PAUSED",
    val desired: Boolean = false,
    val pairingCode: String = "",
    val qr: String = ""
)

data class GroupInfo(
    val accountId: String,
    val jid: String,
    val name: String,
    val memberCount: Int,
    val admin: Boolean,
    val announcement: Boolean,
    val approved: Boolean
) {
    val key: String get() = "$accountId|$jid"
}

data class Campaign(
    val id: String,
    val title: String,
    val text: String,
    val status: String,
    val scope: String,
    val total: Int,
    val sent: Int,
    val failed: Int,
    val unknown: Int
)

data class CampaignTarget(
    val id: String,
    val campaignId: String,
    val accountId: String,
    val jid: String,
    val text: String,
    val attachment: String,
    val mime: String,
    val fileName: String
)

data class MessageTemplate(val id: String, val title: String, val body: String)
data class LogEntry(val time: Long, val accountId: String, val level: String, val message: String)


data class TargetHistory(
    val time: Long, val accountId: String, val campaignTitle: String,
    val jid: String, val status: String, val messageId: String, val error: String
)
