package com.earlxcode.messagehub.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

object Graphite {
    val bg=Color(0xFF101418)
    val surface=Color(0xFF1B242B)
    val raised=Color(0xFF26313B)
    val cyan=Color(0xFF22D3EE)
    val green=Color(0xFF34D399)
    val red=Color(0xFFFB7185)
    val yellow=Color(0xFFFBBF24)
    val text=Color(0xFFF3F6F8)
    val muted=Color(0xFFBCC7D0)
    val border=Color(0xFF394652)
}

@Composable fun MessageHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme=darkColorScheme(
            primary=Graphite.cyan,onPrimary=Graphite.bg,
            secondary=Graphite.green,onSecondary=Graphite.bg,
            background=Graphite.bg,onBackground=Graphite.text,
            surface=Graphite.surface,onSurface=Graphite.text,
            surfaceVariant=Graphite.raised,onSurfaceVariant=Graphite.muted,
            outline=Graphite.border,error=Graphite.red
        ),
        typography=Typography(
            headlineMedium=TextStyle(fontSize=27.sp,fontWeight=FontWeight.Bold,letterSpacing=(-0.5).sp),
            headlineSmall=TextStyle(fontSize=23.sp,fontWeight=FontWeight.Bold,letterSpacing=(-0.25).sp),
            titleLarge=TextStyle(fontSize=21.sp,fontWeight=FontWeight.Bold),
            titleMedium=TextStyle(fontSize=17.sp,fontWeight=FontWeight.SemiBold),
            bodyMedium=TextStyle(fontSize=15.sp,lineHeight=22.sp),
            labelMedium=TextStyle(fontSize=13.sp,fontWeight=FontWeight.Medium)
        ),
        content=content
    )
}

@Composable fun SectionTitle(title:String, modifier:Modifier=Modifier) {
    Text(title,modifier=modifier,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)
}

@Composable fun GraphiteCard(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Card(modifier=modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Graphite.surface),
        border=BorderStroke(1.dp,Graphite.border.copy(alpha=0.70f)), content=content)
}

@Composable fun StatusPill(status:String) {
    val color=when(status) {
        "CONNECTED","SENT","COMPLETED" -> Graphite.green
        "CONNECTING","RECONNECTING","RUNNING","SCHEDULED" -> Graphite.cyan
        "ERROR","FAILED","UNKNOWN" -> Graphite.red
        else -> Graphite.yellow
    }
    Surface(shape=RoundedCornerShape(30.dp),color=color.copy(alpha=0.12f)) {
        Text(status,color=color,style=MaterialTheme.typography.labelSmall,
            modifier=Modifier.padding(horizontal=10.dp,vertical=6.dp))
    }
}
