#include <jni.h>
#include <node.h>
#include <vector>
#include <string>
#include <cstring>
#include <memory>

extern "C" JNIEXPORT jint JNICALL
Java_com_earlxcode_messagehub_bridge_NativeNodeBridge_startNode(
    JNIEnv* env, jobject, jobjectArray arguments) {
    if (!arguments) return -1;
    const jsize count = env->GetArrayLength(arguments);
    if (count < 2 || count > 24) return -2;
    std::vector<std::string> strings;
    strings.reserve(count);
    for (jsize i = 0; i < count; ++i) {
        auto arg = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        if (!arg) return -3;
        const char* chars = env->GetStringUTFChars(arg, nullptr);
        if (!chars) { env->DeleteLocalRef(arg); return -4; }
        strings.emplace_back(chars);
        env->ReleaseStringUTFChars(arg, chars);
        env->DeleteLocalRef(arg);
    }
    // node::Start requires stable mutable argument bytes. Each string is NUL terminated.
    std::vector<std::unique_ptr<char[]>> backing;
    std::vector<char*> argv;
    backing.reserve(strings.size());
    argv.reserve(strings.size());
    for (const auto& value : strings) {
        auto ptr = std::make_unique<char[]>(value.size() + 1);
        std::memcpy(ptr.get(), value.c_str(), value.size() + 1);
        argv.push_back(ptr.get());
        backing.push_back(std::move(ptr));
    }
    return static_cast<jint>(node::Start(static_cast<int>(argv.size()), argv.data()));
}
