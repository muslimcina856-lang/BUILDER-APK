plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.earlxcode.messagehub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.earlxcode.messagehub"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { arguments += "-DANDROID_STL=c++_shared" } }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    externalNativeBuild { cmake { path = file("CMakeLists.txt"); version = "3.22.1" } }
    sourceSets.getByName("main").jniLibs.srcDirs("libnode/bin")
    packaging { jniLibs { useLegacyPackaging = true } }
}

// Download required native runtime and npm packages before checking the bundle.
// This task never installs placeholders: a missing download remains a build error.
tasks.register("prepareBundledRuntime") {
    group = "build setup"
    description = "Install Android arm64 Node.js Mobile and pinned Baileys locally"
    doLast {
        val script = rootProject.file("scripts/auto-prepare-runtime.sh")
        val result = project.exec {
            commandLine("bash", script.absolutePath)
            workingDir = rootProject.projectDir
            isIgnoreExitValue = true
        }
        check(result.exitValue == 0) {
            "Runtime setup failed. Read the messages above. You may download the official Android archive and run scripts/install-libnode.sh manually."
        }
    }
}

// Keep a strict check: never ship a disconnected mock runtime as a working APK.
tasks.register("verifyBundledRuntime") {
    dependsOn("prepareBundledRuntime")
    doLast {
        val so = file("libnode/bin/arm64-v8a/libnode.so")
        val header = file("libnode/include/node/node.h")
        val baileys = file("src/main/assets/nodejs-project/node_modules/@whiskeysockets/baileys/lib/index.js")
        check(so.isFile && so.length() > 100_000L && header.isFile && header.length() > 0L) {
            "Node Mobile Android arm64 binary/header missing or invalid. See README -> Automatic prerequisites."
        }
        check(baileys.isFile) {
            "Baileys package missing. Run scripts/prepare-engine.sh or inspect npm failure in log."
        }
    }
}
tasks.named("preBuild") { dependsOn("verifyBundledRuntime") }

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.02"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.zxing:core:3.5.3")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
