# No obfuscation is enabled in the prototype until Android runtime verification.
