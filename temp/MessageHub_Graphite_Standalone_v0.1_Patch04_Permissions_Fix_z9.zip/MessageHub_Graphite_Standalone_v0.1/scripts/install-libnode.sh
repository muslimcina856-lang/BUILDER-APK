#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ "$#" -ne 1 ]; then
  echo 'Usage: ./scripts/install-libnode.sh /path/to/nodejs-mobile-v18.20.4-android.zip'
  echo 'Get the official Android archive from https://github.com/nodejs-mobile/nodejs-mobile/releases/tag/v18.20.4'
  exit 2
fi
command -v python3 >/dev/null || { echo 'Python 3 is required to verify the Node Mobile archive'; exit 2; }
python3 "$ROOT/scripts/runtime_archive.py" install "$1" "$ROOT/app/libnode"
