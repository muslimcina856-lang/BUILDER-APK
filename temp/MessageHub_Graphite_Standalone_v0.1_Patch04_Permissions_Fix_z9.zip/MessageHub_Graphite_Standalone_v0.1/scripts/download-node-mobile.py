#!/usr/bin/env python3
"""Download the pinned official Android release, then validate/install it."""
from pathlib import Path
import json
import shutil
import sys
import tempfile
import urllib.request

from runtime_archive import ArchiveError, install_archive

ROOT = Path(__file__).resolve().parent.parent
API = "https://api.github.com/repos/nodejs-mobile/nodejs-mobile/releases/tags/v18.20.4"
USER_AGENT = "MessageHub-Android-Build"


def download_and_install() -> None:
    req = urllib.request.Request(API, headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=40) as response:
        release = json.load(response)
    assets = release.get("assets", [])
    candidates = [item for item in assets if "android" in item.get("name", "").lower()
                  and item.get("name", "").lower().endswith(".zip")]
    if len(candidates) != 1:
        raise ArchiveError("Official release must contain exactly one Android ZIP, assets: "
                           + ", ".join(a.get("name", "") for a in assets))
    asset = candidates[0]
    url = asset["browser_download_url"]
    if not url.startswith("https://github.com/nodejs-mobile/nodejs-mobile/releases/download/v18.20.4/"):
        raise ArchiveError("Unexpected release download URL: " + url)
    with tempfile.TemporaryDirectory(prefix="messagehub-node-") as td:
        archive = Path(td) / "nodejs-mobile-android.zip"
        print(f"[MessageHub] Downloading official asset: {asset['name']}", flush=True)
        request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(request, timeout=180) as response, archive.open("wb") as output:
            shutil.copyfileobj(response, output)
        install_archive(archive, ROOT / "app/libnode")


if __name__ == "__main__":
    try:
        download_and_install()
    except Exception as e:
        print("[MessageHub] Could not obtain Android runtime:", e, file=sys.stderr)
        print("Use NODE_MOBILE_ARCHIVE with the official ANDROID ZIP from "
              "https://github.com/nodejs-mobile/nodejs-mobile/releases/tag/v18.20.4", file=sys.stderr)
        sys.exit(1)
