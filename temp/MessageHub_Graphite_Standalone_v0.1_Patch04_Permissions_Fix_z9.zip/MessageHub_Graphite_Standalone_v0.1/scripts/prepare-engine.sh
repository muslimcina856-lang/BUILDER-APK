#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENGINE="$ROOT/app/src/main/assets/nodejs-project"
command -v npm >/dev/null || { echo 'npm not found; install Node.js 18/20+'; exit 2; }
cd "$ENGINE"
echo '[1/2] Install pinned Baileys 6.7.9 engine dependencies (requires network and git)'
# Version is exact in package.json.  Avoid pulling optional image bindings unnecessarily.
npm install --omit=optional --legacy-peer-deps --no-audit --no-fund
[ -f node_modules/@whiskeysockets/baileys/lib/index.js ] || { echo 'Baileys package not present'; exit 3; }
echo '[2/2] Engine present; Android build will bundle node_modules assets.'
