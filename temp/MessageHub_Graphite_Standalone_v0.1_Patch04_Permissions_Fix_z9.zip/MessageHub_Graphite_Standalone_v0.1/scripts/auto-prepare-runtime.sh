#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LIB="$ROOT/app/libnode/bin/arm64-v8a/libnode.so"
HEADER="$ROOT/app/libnode/include/node/node.h"
BAILEYS="$ROOT/app/src/main/assets/nodejs-project/node_modules/@whiskeysockets/baileys/lib/index.js"
command -v python3 >/dev/null || { echo '[MessageHub] Python 3 required to validate the ARM64 runtime.'; exit 2; }
if ! python3 "$ROOT/scripts/runtime_archive.py" verify "$ROOT/app/libnode" >/dev/null 2>&1; then
  echo '[MessageHub] Android ARM64 Node Mobile missing. Preparing official v18.20.4 release...'
  if [[ -n "${NODE_MOBILE_ARCHIVE:-}" ]]; then
    bash "$ROOT/scripts/install-libnode.sh" "$NODE_MOBILE_ARCHIVE"
  else
    command -v python3 >/dev/null || { echo 'Python 3 required for automatic GitHub release download. Or set NODE_MOBILE_ARCHIVE to a previously downloaded Android archive.'; exit 2; }
    python3 "$ROOT/scripts/download-node-mobile.py"
  fi
fi
if [[ ! -s "$BAILEYS" ]]; then
  echo '[MessageHub] Bundling pinned Baileys engine...'
  bash "$ROOT/scripts/prepare-engine.sh"
fi
python3 "$ROOT/scripts/runtime_archive.py" verify "$ROOT/app/libnode"
echo '[MessageHub] Native runtime and Baileys prerequisites present.'
