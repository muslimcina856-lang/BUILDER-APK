#!/usr/bin/env python3
"""Validate and install official Android Node.js Mobile archives (arm64-v8a).

Unlike the previous strict endswith('/include/node/node.h'), this accepts
include/node/node.h at ZIP root, wrapped roots, and include/node.h layouts.
It never invents a runtime when the archive is incomplete.
"""
from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
import shutil
import struct
import sys
import tempfile
import zipfile

MAX_MEMBER_SIZE = 700 * 1024 * 1024
MAX_HEADERS_SIZE = 500 * 1024 * 1024


class ArchiveError(ValueError):
    """The archive is not a supported Android Node Mobile release."""


def _parts(name: str) -> tuple[str, ...]:
    if name.startswith(("/", "\\")) or "\\" in name:
        raise ArchiveError(f"Unsafe archive entry: {name!r}")
    parts = PurePosixPath(name).parts
    if any(part in (".", "..") for part in name.split("/")):
        raise ArchiveError(f"Unsafe archive entry: {name!r}")
    return parts


def _locate(zf: zipfile.ZipFile):
    binaries = []
    headers = []
    entries = []
    for info in zf.infolist():
        parts = _parts(info.filename)
        if not parts or info.is_dir() or parts[0] == "__MACOSX":
            continue
        # Deny symlink entries: they are not regular files and must not be extracted.
        file_type = (info.external_attr >> 16) & 0o170000
        if file_type == 0o120000:
            raise ArchiveError(f"Unsafe archive symlink: {info.filename}")
        if info.file_size > MAX_MEMBER_SIZE:
            raise ArchiveError(f"Archive member exceeds safe size: {info.filename}")
        entries.append((parts, info))
        if len(parts) >= 2 and parts[-2:] == ("arm64-v8a", "libnode.so"):
            binaries.append((parts, info))
        for i, piece in enumerate(parts):
            if piece == "include" and parts[i + 1:] in (("node", "node.h"), ("node.h",)):
                headers.append((parts, info, i))
    if not binaries or not headers:
        sample = ", ".join("/".join(parts) for parts, _ in entries[:12])
        related = ", ".join("/".join(parts) for parts, _ in entries
                            if parts[-1] in ("libnode.so", "node.h"))
        raise ArchiveError(
            "Android arm64-v8a/libnode.so or include/[node/]node.h missing; "
            f"ZIP candidates: {related[:600] or '(none)'}; "
            f"first 12 entries: {sample[:600] or '(empty)'}"
        )

    # Prefer a matching root folder for the binary and header. A directory
    # named 'bin' is optional, but the ABI and filename must be exact.
    matches = []
    for bparts, binfo in binaries:
        root = bparts[:-3] if len(bparts) >= 3 and bparts[-3] == "bin" else bparts[:-2]
        for hparts, hinfo, hi in headers:
            if hparts[:hi] == root:
                matches.append((bparts, binfo, hparts, hinfo, hi, root))
    if not matches and len(binaries) == len(headers) == 1:
        # Some archives wrap platform binaries but keep the include tree at root.
        bparts, binfo = binaries[0]
        hparts, hinfo, hi = headers[0]
        matches = [(bparts, binfo, hparts, hinfo, hi, hparts[:hi])]
    if len(matches) != 1:
        raise ArchiveError(
            "Ambiguous Android archive roots; expected one arm64 binary "
            "and include/node.h pair"
        )
    _, binfo, hparts, _, include_pos, _ = matches[0]
    nested_header = hparts[include_pos + 1:] == ("node", "node.h")
    include_prefix = hparts[:include_pos] + (("include", "node") if nested_header else ("include",))
    related = []
    used = set()
    total = 0
    for parts, info in entries:
        if parts[:len(include_prefix)] != include_prefix:
            continue
        relative = parts[len(include_prefix):]
        if not relative:
            continue
        if relative in used:
            raise ArchiveError(f"Duplicate header: {'/'.join(relative)}")
        used.add(relative)
        total += info.file_size
        if total > MAX_HEADERS_SIZE:
            raise ArchiveError("Header directory exceeds safe size")
        related.append((relative, info))
    if ("node.h",) not in used:
        raise ArchiveError("node.h missing in selected headers")
    return binfo, related


def _validate_arm64_binary(path: Path) -> None:
    with path.open("rb") as file:
        data = file.read(64)
    if path.stat().st_size < 100_000 or data[:4] != b"\x7fELF":
        raise ArchiveError("Android runtime is not a plausible ELF shared library")
    if data[4] != 2 or data[5] != 1 or struct.unpack_from("<H", data, 18)[0] != 183:
        raise ArchiveError("Android runtime ELF is not AArch64 (arm64-v8a)")


def verify_install(destination: str | Path) -> None:
    destination = Path(destination)
    header = destination / "include/node/node.h"
    library = destination / "bin/arm64-v8a/libnode.so"
    if not header.is_file() or header.stat().st_size == 0:
        raise ArchiveError("Android Node header missing: " + str(header))
    if not library.is_file():
        raise ArchiveError("Android Node ARM64 shared library missing: " + str(library))
    _validate_arm64_binary(library)


def install_archive(archive_path: str | Path, destination: str | Path) -> None:
    archive_path = Path(archive_path).expanduser().resolve()
    destination = Path(destination).resolve()
    if not archive_path.is_file():
        raise ArchiveError(f"Archive does not exist: {archive_path}")
    if not zipfile.is_zipfile(archive_path):
        raise ArchiveError("Downloaded file is not a ZIP archive")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path) as zf:
        binary, headers = _locate(zf)
        with tempfile.TemporaryDirectory(prefix="node-mobile-install-", dir=destination.parent) as td:
            stage = Path(td)
            stage_lib = stage / "libnode.so"
            with zf.open(binary) as source, stage_lib.open("wb") as output:
                shutil.copyfileobj(source, output)
            _validate_arm64_binary(stage_lib)
            stage_headers = stage / "include/node"
            for relative, info in headers:
                path = stage_headers.joinpath(*relative)
                path.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as source, path.open("wb") as output:
                    shutil.copyfileobj(source, output)
            if not (stage_headers / "node.h").is_file():
                raise ArchiveError("node.h missing after extraction")
            # Commit headers first and binary last. If extraction fails, nothing
            # is installed. If header copy fails, no valid libnode.so is placed.
            dest_headers = destination / "include/node"
            dest_headers.mkdir(parents=True, exist_ok=True)
            for source in stage_headers.rglob("*"):
                if source.is_file():
                    relative = source.relative_to(stage_headers)
                    target = dest_headers / relative
                    target.parent.mkdir(parents=True, exist_ok=True)
                    os.replace(source, target)
            target_lib = destination / "bin/arm64-v8a/libnode.so"
            target_lib.parent.mkdir(parents=True, exist_ok=True)
            os.replace(stage_lib, target_lib)
    print(f"[MessageHub] Installed verified ARM64 runtime and Node headers from {archive_path.name}", flush=True)


if __name__ == "__main__":
    if not ((len(sys.argv) == 4 and sys.argv[1] == "install") or
            (len(sys.argv) == 3 and sys.argv[1] == "verify")):
        print("Usage: runtime_archive.py install archive.zip app/libnode | verify app/libnode", file=sys.stderr)
        sys.exit(2)
    try:
        if sys.argv[1] == "verify":
            verify_install(sys.argv[2])
        else:
            install_archive(sys.argv[2], sys.argv[3])
    except (ArchiveError, OSError, zipfile.BadZipFile) as e:
        print(f"[MessageHub] Runtime archive rejected: {e}", file=sys.stderr)
        sys.exit(1)
