#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v gradle >/dev/null || { echo 'Gradle 8.7 is required. Install it or use Android Studio (see README).'; exit 2; }
[ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo 'Android SDK path not defined (ANDROID_HOME / ANDROID_SDK_ROOT).'; exit 2; }
gradle --no-daemon --stacktrace :app:assembleDebug
printf '\nAPK: %s\n' "$ROOT/app/build/outputs/apk/debug/app-debug.apk"
