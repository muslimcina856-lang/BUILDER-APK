#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 -m unittest discover -s "$ROOT/tests" -p 'test_*.py' -v
node --test "$ROOT"/tests/node/*.test.cjs
python3 "$ROOT/tests/static_checks.py"
