# Keselamatan, privasi dan batasan

## Sudah diprogram

- Android Keystore AES-GCM untuk semua `creds` dan Signal keys; encryption AAD terikat pada `accountId:itemKey`.
- Android backup/digital device transfer dimatikan oleh Manifest + Data Extraction Rules.
- Bridge menggunakan token sementara, port loopback 127.0.0.1, had saiz request, constant-time compare di Node (Android uses MessageDigest.isEqual).
- Android activity exported untuk launcher sahaja; foreground service tidak exported.
- Node API tidak menerima media path di luar `files/attachments` (path traversal rejected).
- Tidak membaca semua kontak telefon dan tidak menyimpan isi semua chat.
- Group destination @g.us sahaja, group opt-in secara manual, opt-out menghalang pending queue.
- Satu percubaan penghantaran per target; masa tamat tidak menjadi automatic retry.
- Kunci aplikasi PIN pilihan: salted PBKDF2-HMAC-SHA256 180k iterations, lockout selepas beberapa gagal.

## Belum diverifikasi

- WhatsApp protocol semasa; kekangan login/sesi akaun jika WhatsApp berubah.
- Android 16KB native page alignment dan Google Play foreground service declarations.
- Keamanan transitive dependency versi Baileys lama terhadap vulnerability baharu.
- Penetration test, static Android lint, dynamic MITM test; kunci PIN boleh terdedah jika telefon di-root.

## Perkara yang perlu diuji sebelum release

1. Jangan log pairing code/QR/creds dalam logcat, SQL export, screenshots atau analytics.
2. Semak bahagian `data` untuk akses sistem selepas reinstall; bila Keystore direset, kunci lama tidak boleh dinyahenkripsi.
3. Audit hak app, data extraction, `targetSdk` dan izin foreground service versi Android sebenar.
4. Semak library pihak ketiga sebelum APK dipasang sebagai daily driver.
5. Semak WhatsApp Business policies untuk broadcast. Sistem ini bukan API rasmi WhatsApp.
