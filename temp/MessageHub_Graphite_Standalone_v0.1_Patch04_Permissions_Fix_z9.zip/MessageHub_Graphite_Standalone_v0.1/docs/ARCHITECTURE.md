# Architektur sistem (Malay specification)

## Context

APK native Kotlin+Compose mengendalikan UI, SQLite, AES-GCM Keystore, queue dan foreground service. Node.js Mobile (satu runtime **per process**) menjalankan Baileys 6.7.9, dengan satu WebSocket/socket per akaun yang pengguna aktifkan. Tidak ada VPS atau API awan di bawah kawalan kami.

## Dataflow login

1. Pengguna Add Account -> Android SQLite `accounts.id` UUID rawak, nombor WhatsApp + alias.
2. Toggle Active -> SQLite desired=1, Android -> Node `POST /accounts/activate` melalui loopback port 38741 + token.
3. Node membina `auth` menggunakan `initAuthCreds`, `BufferJSON`, custom Signal key store yang berkomunikasi dengan Android host port 38742 + token.
4. Android host mengurus `secure_kv`: setiap kredensial dan signal key disulitkan dengan AES-256-GCM Android Keystore (AAD=accountId:key).
5. Baileys menghasilkan QR/pair code, Node -> Android host `/event`, SQLite account status dikemas kini, UI polling DB.
6. Pairing confirmed -> `connection.update=open` -> Android status CONNECTED.
7. Sebarang update `creds.update` diserialkan; key updates dipersist oleh `auth.keys.set`.

## Group sync

Android UI -> Node `/groups/sync` -> sock.groupFetchAllParticipating -> array `{jid,name,members,admin,announcement}`. Android menyimpan metadata sahaja, bukan isi chat. Persetujuan (`approved`) kekal apabila metadata diperbaharui. Group `announcement` tanpa hak admin dikecualikan daripada pilihan kempen.

## Campaign lifecycle

UI menyemak `approved` dan selected group keys. `createCampaign` menyimpan `campaigns` + `targets` secara atomik; dedup unik `campaign_id,jid`. `scheduleCampaign`: `0` = RUNNING, >0 = SCHEDULED. Dalam loop service, `activateScheduled()` menukar status apabila waktu sudah tiba **selagi service aktif**. Query pending target mensyaratkan account desired=1, status CONNECTED, approved=1 dan TIADA opt-out. Sasaran dipindah PENDING -> SENDING sebelum network send. Node menerima `POST /messages/send` dan memulangkan message ID. Android menukar SENDING -> SENT jika berjaya, FAILED untuk ralat pasti, UNKNOWN untuk timeout yang mungkin sudah diterima. Pada proses baru, semua SENDING lama menjadi UNKNOWN. Tidak ada auto retry UNKNOWN. UI membolehkan pause/resume/cancel.

## Multi-account Hybrid

`selected account` hanya pemboleh ubah UI, `desired` dikawal dengan switch akaun. Menukar UI tidak me-reconnect akaun lain. Node AccountRegistry mengekalkan `Map<accountId, socket>` dan `generation` untuk mengabaikan event sesi lama. Reconnect menggunakan exponential backoff apabila desire=active dan bukan logged-out. Pausing menutup socket dan mematikan timer akaun itu sahaja.

## Sasaran fail / folder

Auth state & keys: `SQLite.secure_kv` (encrypted). Group & campaign: `SQLite`. Lampiran: `files/attachments` private. Node modules: diekstrak dari APK assets ke `files/node-engine`. Bridge token rawak: `files/bridge.token`, boleh dibaca aplikasi sahaja. `nodejs-project` tidak mengandungi data pengguna.

## Android lifecycle

Node diboot sekali sahaja selepas pelancaran Activity yang kelihatan, oleh foreground service `dataSync`. Android mungkin menghentikan service pada had waktu atau sebab memori/bateri. Aplikasi **tidak menjanjikan uptime 24/7**. Restart proses membina semula socket yang desired=1 selepas menerima arahan dispatcher. Jadual sementara tidak berjalan semasa engine dihentikan.

## ADR / keputusan reka bentuk

- Tidak menggunakan localhost terbuka atau HTTP terbuka pada `0.0.0.0`.
- Tidak menggunakan `useMultiFileAuthState` sebagai storan produksi.
- Satu Node runtime, banyak socket, kerana overhead proses Android.
- Tiada 'anti-ban', account rotation atau penghantaran spam.
- Tidak menggunakan cloud atau remote DB.
- Baileys v6.7.9 dipin sahaja sebagai **calon ujian** Node Mobile 18, boleh ditukar hanya selepas matriks keserasian diuji dan ada kebenaran pengguna.
