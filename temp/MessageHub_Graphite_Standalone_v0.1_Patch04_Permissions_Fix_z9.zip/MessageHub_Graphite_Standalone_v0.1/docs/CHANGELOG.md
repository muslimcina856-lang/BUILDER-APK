# Changelog

## 0.1.0 — Initial source (2026-10-18)
- Projek Android Kotlin/Compose Graphite Tech; 9 paparan termasuk Account Manager.
- Node.js Mobile JNI integration source, persediaan libnode arm64.
- Baileys 6.7.9 sebagai pinned candidate, bukan versi disahkan berfungsi.
- Multi-account Hybrid, encrypted per-account auth, local group metadata, campaign queue, media & templates.
- PIN pilihan, logs, best-effort scheduled send, failure state UNKNOWN, opt-out.
- Node unit tests; tiada APK binaan dalam artefak ini.


## Patch 03 — Runtime archive detection (2026-10-18)
- Baiki padanan `node.h` di root ZIP serta folder pembungkus; installer auto dan manual kini guna pemeriksa bersama.
- Tambah semakan identiti ELF AArch64, penolakan laluan ZIP berbahaya dan diagnostik arkib yang boleh dibaca.
- Tambah 9 regression tests tanpa internet untuk archive structure, invalid binary dan CLI.
- Tiada perubahan UI, engine Baileys, package ID, `versionCode` atau `versionName` berbanding Patch 02.
- Belum mengesahkan Gradle/Android native build dan login WhatsApp sebenar.

## Patch 04
- Fixed `Permission denied` on GitHub Actions when ZIP extraction removes executable bits from nested runtime setup scripts.
- `auto-prepare-runtime.sh` invokes `install-libnode.sh` and `prepare-engine.sh` using `bash`.
- Added shell-permission regression coverage; all other app behavior and version identifiers unchanged.
