# Pelan ujian peranti selepas build

Semua langkah bawah ialah **ujian dicadangkan, belum dilakukan**.

1. **Android runtime**: install APK pada ARM64 Android 13/14/15/16, lihat Node `/health`, pastikan libnode 18 berjalan dan tidak crash.
2. **2 akaun**: tambah dua nombor WA milik tester, pairing code/QR code (linked devices). Verify reconnect selepas proses dimatikan.
3. **Pengasingan**: Akaun A dan B masing-masing dalam group berbeza. Sync groups A dan B, tukar filter, pastikan tiada campuran.
4. **Hybrid**: Jeda A, pastikan sambungan B masih aktif. Aktifkan semula A. Ulang 10 kali untuk memory leak.
5. **Auth**: update credentials, proses restart, periksa sesi kekal; Android Keystore tidak bocor ke log.
6. **Queue**: hantar 1 mesej kepada satu group ujian yang memberi kebenaran; uji text/image/video/document di bawah 15 MB.
7. **Kegagalan**: putus internet semasa sending. Sasaran bertanda UNKNOWN tidak auto resend; user boleh semak di WhatsApp.
8. **Opt-out**: tarik balik izin group selepas create kempen, pastikan target pending disekat.
9. **Scheduling**: jadual 5 min ketika aplikasi foreground; tutup/force-stop app untuk mengesahkan paparan batasan.
10. **Battery & OS**: biar engine aktif, kunci skrin dan jalankan Doze; semak service timeout dan status reconnect.
11. **Security**: cuba POST ke port 38741/38742 tanpa token dari app lain; pastikan Unauthorized. `AndroidKeyStore` decrypted data tidak masuk screenshot log.
12. **Build**: Android Gradle lint, unit tests, NDK native linking, APK alignment 16KB, install/uninstall/update flow, dark theme accessibility.

**Kriteria keluaran:** jangan anggap WhatsApp selesai selepas `node --test`. Release hanya selepas dua akaun sebenar dan penghantaran ujian lulus.
