# Proguard rules untuk sqflite & SQLite (penyimpanan senarai profil suara)
-keep class org.sqlite.** { *; }
-keep class com.tekartik.sqflite.** { *; }
-dontwarn org.sqlite.**
-dontwarn com.tekartik.sqflite.**
