import 'dart:io';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';
import '../models/player_data.dart';

class SaveGameService {
  static const String _saveFileName = 'mokka_save.json';
  static const String _autoSaveFileName = 'mokka_autosave.json';

  Future<Directory> _getGameDirectory() async {
    final directory = await getApplicationDocumentsDirectory();
    final gameDir = Directory('${directory.path}/kedai_mokka_3d');
    if (!gameDir.existsSync()) {
      gameDir.createSync(recursive: true);
    }
    return gameDir;
  }

  Future<File> _getSaveFile({bool autoSave = false}) async {
    final dir = await _getGameDirectory();
    final fileName = autoSave ? _autoSaveFileName : _saveFileName;
    return File('${dir.path}/$fileName');
  }

  Future<bool> saveGame(PlayerData playerData, {bool autoSave = false}) async {
    try {
      final file = await _getSaveFile(autoSave: autoSave);
      final jsonData = playerData.toJson();
      final jsonString = jsonEncode(jsonData);
      final encoded = base64Encode(utf8.encode(jsonString));
      await file.writeAsString(encoded);
      
      if (kDebugMode) {
        print('✓ Game saved${autoSave ? ' (auto)' : ''}');
      }
      return true;
    } catch (e) {
      if (kDebugMode) {
        print('✗ Save failed: $e');
      }
      return false;
    }
  }

  Future<PlayerData?> loadGame({bool autoSave = false}) async {
    try {
      final file = await _getSaveFile(autoSave: autoSave);
      if (!file.existsSync()) return null;

      final encoded = await file.readAsString();
      final jsonString = utf8.decode(base64Decode(encoded));
      final json = jsonDecode(jsonString) as Map<String, dynamic>;
      final playerData = PlayerData.fromJson(json);

      if (kDebugMode) {
        print('✓ Game loaded${autoSave ? ' (auto)' : ''}');
      }
      return playerData;
    } catch (e) {
      if (kDebugMode) {
        print('✗ Load failed: $e');
      }
      return null;
    }
  }

  Future<bool> saveExists({bool autoSave = false}) async {
    try {
      final file = await _getSaveFile(autoSave: autoSave);
      return file.existsSync();
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteSave({bool autoSave = false}) async {
    try {
      final file = await _getSaveFile(autoSave: autoSave);
      if (file.existsSync()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
