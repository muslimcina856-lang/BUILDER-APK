import 'dart:async';
import 'dart:math' as math;
import '../models/player_data.dart'; // Di-import mrene ben kenal Vector3!
import '../models/world_data.dart';

class MapService {
  // Simulasi manggil data OSM (OpenStreetMap) soko sekitar Kedai Mokka Malang
  Future<WorldState> buildWorld() async {
    // Simulasi loading 1 detik ben ketok realistik
    await Future.delayed(const Duration(seconds: 1));

    // 1. Generate Fake Buildings
    final buildings = <Building>[
      Building(
        id: 'b1',
        name: 'Kedai Mokka (Origin)',
        vertices: _generateBuildingVertices(4, centerX: 0, centerZ: 0, size: 8),
        height: 6.0,
        type: 'cafe',
        address: 'Jl. Soekarno Hatta No. 99, Malang',
        latitude: -7.976195,
        longitude: 112.723395,
      ),
      Building(
        id: 'b2',
        name: 'Ruko Suhat A1',
        vertices: _generateBuildingVertices(4, centerX: 25, centerZ: -40, size: 12),
        height: 12.0,
        type: 'shop',
        address: 'Jl. Soekarno Hatta, Malang',
        latitude: -7.975830,
        longitude: 112.723620,
      ),
      Building(
        id: 'b3',
        name: 'Kos Mahasiswa Nyaman',
        vertices: _generateBuildingVertices(4, centerX: -35, centerZ: 30, size: 15),
        height: 9.0,
        type: 'residential',
        address: 'Jl. Lowokwaru Gg. 2, Malang',
        latitude: -7.976465,
        longitude: 112.723080,
      ),
      Building(
        id: 'b4',
        name: 'Masjid Al-Ikhlas',
        vertices: _generateBuildingVertices(6, centerX: 50, centerZ: 45, size: 10),
        height: 8.0,
        type: 'place_of_worship',
        address: 'Jl. Lowokwaru, Malang',
        latitude: -7.976600,
        longitude: 112.723850,
      ),
    ];

    // 2. Generate Fake Roads
    final roads = <Road>[
      Road(
        id: 'r1',
        name: 'Jl. Soekarno Hatta (Utama)',
        path: _generateRoadPath([
          Vector3(x: -200, y: 0, z: -100),
          Vector3(x: 0, y: 0, z: 0),
          Vector3(x: 200, y: 0, z: 100),
        ]),
        width: 12.0,
        type: 'primary',
      ),
      Road(
        id: 'r2',
        name: 'Gang Senggol Lowokwaru',
        path: _generateRoadPath([
          Vector3(x: 0, y: 0, z: 0),
          Vector3(x: -50, y: 0, z: 80),
          Vector3(x: -150, y: 0, z: 120),
        ]),
        width: 5.0,
        type: 'residential',
      ),
    ];

    // 3. Generate Fake Collectibles
    final collectibles = <WorldCollectible>[
      WorldCollectible(
        id: 'c1',
        position: Vector3(x: 10, y: 1.8, z: 15),
        type: 'bean',
        name: 'Biji Kopi Arabika',
      ),
      WorldCollectible(
        id: 'c2',
        position: Vector3(x: -20, y: 1.8, z: -10),
        type: 'coin',
        name: 'Koin Mokka',
      ),
      WorldCollectible(
        id: 'c3',
        position: Vector3(x: 40, y: 1.8, z: -35),
        type: 'coin',
        name: 'Koin Mokka',
      ),
      WorldCollectible(
        id: 'c4',
        position: Vector3(x: -15, y: 1.8, z: 45),
        type: 'artifact',
        name: 'Cangkir Antik Malang',
      ),
    ];

    // 4. Generate Flat/Simple Terrain
    const int res = 20;
    final hMap = List.generate(res, (_) => List.generate(res, (_) => 0.0));
    
    final terrain = Terrain(
      heightMap: hMap,
      gridSize: 10.0,
      resolution: res,
      origin: Vector3(x: -100, y: 0, z: -100),
    );

    return WorldState(
      buildings: buildings,
      roads: roads,
      collectibles: collectibles,
      terrain: terrain,
    );
  }

  // Helper gawe nggawe footprint bangunan
  List<Vector3> _generateBuildingVertices(int nodeCount, 
      {required double centerX, required double centerZ, required double size}) {
    final List<Vector3> vertices = [];
    final double radius = size / 2;

    for (int i = 0; i < nodeCount; i++) {
      double angle = (i * 2 * math.pi) / nodeCount;
      vertices.add(Vector3(
        x: centerX + radius * math.cos(angle),
        y: 0,
        z: centerZ + radius * math.sin(angle),
      ));
    }
    return vertices;
  }

  // Helper gawe path dalan
  List<Vector3> _generateRoadPath(List<Vector3> points) {
    return points;
  }
}
