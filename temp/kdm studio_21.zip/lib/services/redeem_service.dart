import '../models/player_data.dart';

class RedeemableCode {
  final String code;
  final String description;
  final Reward reward;
  final DateTime? expiryDate;

  RedeemableCode({
    required this.code,
    required this.description,
    required this.reward,
    this.expiryDate,
  });

  bool isExpired() {
    if (expiryDate == null) return false;
    return DateTime.now().isAfter(expiryDate!);
  }
}

class Reward {
  final int coins;
  final int score;
  final List<InventoryItem> items;

  Reward({
    this.coins = 0,
    this.score = 0,
    this.items = const [],
  });
}

class RedeemService {
  static final List<RedeemableCode> _validCodes = [
    RedeemableCode(
      code: 'MOKKA-START',
      description: 'Kedai Mokka Welcome - 100 coins',
      reward: Reward(coins: 100, score: 100),
    ),
    RedeemableCode(
      code: 'MALANG-EXPLORE',
      description: 'Explorer Bonus - 200 coins + Premium Bean',
      reward: Reward(
        coins: 200,
        score: 150,
        items: [
          InventoryItem(
            id: 'premium_bean',
            name: 'Premium Mokka Bean',
            quantity: 5,
            type: 'item',
          ),
        ],
      ),
    ),
    RedeemableCode(
      code: 'JATIMULYO-50',
      description: 'Jatimulyo Landmark - 50 coins',
      reward: Reward(coins: 50, score: 50),
    ),
    RedeemableCode(
      code: 'COFFEE-LOVER',
      description: 'Coffee Enthusiast - 300 coins + 10 beans',
      reward: Reward(
        coins: 300,
        score: 200,
        items: [
          InventoryItem(
            id: 'mokka_bean_bulk',
            name: 'Mokka Bean Bulk',
            quantity: 10,
            type: 'item',
          ),
        ],
      ),
    ),
    RedeemableCode(
      code: 'REMUJUNG-JAY',
      description: 'Jalan Remujung Traveler - 150 coins',
      reward: Reward(coins: 150, score: 100),
    ),
  ];

  Future<RedeemResult> redeemCode(
    String code,
    PlayerData playerData,
  ) async {
    final sanitizedCode = code.trim().toUpperCase();

    if (playerData.isCodeRedeemed(sanitizedCode)) {
      return RedeemResult(
        success: false,
        message: 'Kode sudah pernah ditebus!',
        code: sanitizedCode,
      );
    }

    final codeIndex = _validCodes.indexWhere((c) => c.code == sanitizedCode);

    if (codeIndex == -1) {
      return RedeemResult(
        success: false,
        message: 'Kode tidak valid',
        code: sanitizedCode,
      );
    }

    final redeemableCode = _validCodes[codeIndex];

    if (redeemableCode.isExpired()) {
      return RedeemResult(
        success: false,
        message: 'Kode sudah kadaluarsa',
        code: sanitizedCode,
      );
    }

    try {
      final reward = redeemableCode.reward;

      if (reward.coins > 0) {
        playerData.addCoins(reward.coins);
      }

      if (reward.score > 0) {
        playerData.score += reward.score;
      }

      for (var item in reward.items) {
        playerData.addInventoryItem(item);
      }

      playerData.markCodeRedeemed(sanitizedCode);

      return RedeemResult(
        success: true,
        message: '✓ ${redeemableCode.description}',
        code: sanitizedCode,
        reward: reward,
      );
    } catch (e) {
      return RedeemResult(
        success: false,
        message: 'Error: $e',
        code: sanitizedCode,
      );
    }
  }

  bool isValidCodeFormat(String code) {
    final sanitized = code.trim();
    final pattern = RegExp(r'^[A-Z0-9-]{5,20}$', caseSensitive: false);
    return pattern.hasMatch(sanitized);
  }

  List<RedeemableCode> getAllCodes() => _validCodes;

  RedeemableCode? getCodeInfo(String code) {
    final sanitized = code.trim().toUpperCase();
    try {
      return _validCodes.firstWhere((c) => c.code == sanitized);
    } catch (e) {
      return null;
    }
  }
}

class RedeemResult {
  final bool success;
  final String message;
  final String code;
  final Reward? reward;

  RedeemResult({
    required this.success,
    required this.message,
    required this.code,
    this.reward,
  });

  @override
  String toString() => 'RedeemResult(success: $success, code: $code)';
}
