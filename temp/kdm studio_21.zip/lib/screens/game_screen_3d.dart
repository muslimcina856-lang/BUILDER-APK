import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'dart:math';
import '../models/player_data.dart';
import '../models/world_data.dart';
import '../services/map_service.dart';
import '../services/save_game_service.dart';
import '../services/redeem_service.dart';
import '../widgets/hud_3d.dart';
import '../widgets/redeem_dialog.dart';

/// Main game screen - 3D-like world using Canvas 2D
class GameScreen3D extends StatefulWidget {
  const GameScreen3D({Key? key}) : super(key: key);

  @override
  State<GameScreen3D> createState() => _GameScreen3DState();
}

class _GameScreen3DState extends State<GameScreen3D>
    with SingleTickerProviderStateMixin {
  late PlayerData _playerData;
  late SaveGameService _saveService;
  late RedeemService _redeemService;
  late MapService _mapService;

  // World data
  WorldState? _worldState;
  bool _worldLoaded = false;

  // Player movement
  final Set<String> _pressedKeys = {};
  Vector3 _playerPos = Vector3(x: 0, y: 1.8, z: 0);
  Vector3 _playerVel = Vector3.zero();

  static const double MOVE_SPEED = 8.0;
  static const double GRAVITY = 9.8;
  static const double JUMP_POWER = 6.0;

  bool _isPaused = false;
  double _fps = 60;
  int _frameCount = 0;
  Stopwatch _fpsTimer = Stopwatch();

  late AnimationController _gameLoopController;
  Stopwatch _frameTimer = Stopwatch();
  double _deltaTime = 0.016;

  @override
  void initState() {
    super.initState();
    _initializeGame();
  }

  Future<void> _initializeGame() async {
    _playerData = context.read<PlayerData>();
    _saveService = SaveGameService();
    _redeemService = RedeemService();
    _mapService = MapService();

    final savedData = await _saveService.loadGame();
    if (savedData != null) {
      _playerData = savedData;
      _playerPos = savedData.position;
    } else {
      _playerPos = Vector3(x: 0, y: 1.8, z: 0);
    }

    _buildWorld();

    _frameTimer.start();
    _fpsTimer.start();

    _gameLoopController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 16),
    )..repeat();

    _gameLoopController.addListener(_gameLoop);
    _scheduleAutoSave();

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _buildWorld() async {
    try {
      _worldState = await _mapService.buildWorld();
      setState(() => _worldLoaded = true);
      print('✅ World loaded! Buildings: ${_worldState!.buildings.length}');
    } catch (e) {
      print('❌ Error: $e');
      setState(() => _worldLoaded = true);
    }
  }

  void _gameLoop() {
    if (_isPaused || !_worldLoaded) return;

    _deltaTime = (_frameTimer.elapsedMilliseconds / 1000).toDouble();
    _frameTimer.reset();

    _handlePlayerMovement();
    _updatePlayerPhysics();
    _checkCollectibles();

    _frameCount++;
    if (_fpsTimer.elapsedMilliseconds >= 1000) {
      _fps = _frameCount.toDouble();
      _frameCount = 0;
      _fpsTimer.reset();
    }

    setState(() {});
  }

  void _handlePlayerMovement() {
    const moveAmount = MOVE_SPEED;

    if (_pressedKeys.contains('W') || _pressedKeys.contains('ArrowUp')) {
      _playerPos.z -= moveAmount * _deltaTime;
    }
    if (_pressedKeys.contains('S') || _pressedKeys.contains('ArrowDown')) {
      _playerPos.z += moveAmount * _deltaTime;
    }
    if (_pressedKeys.contains('A') || _pressedKeys.contains('ArrowLeft')) {
      _playerPos.x -= moveAmount * _deltaTime;
    }
    if (_pressedKeys.contains('D') || _pressedKeys.contains('ArrowRight')) {
      _playerPos.x += moveAmount * _deltaTime;
    }

    if (_pressedKeys.contains('Space') && _playerPos.y <= 1.85) {
      _playerVel.y = JUMP_POWER;
      _pressedKeys.remove('Space');
    }
  }

  void _updatePlayerPhysics() {
    _playerVel.y -= GRAVITY * _deltaTime;
    _playerPos.y += _playerVel.y * _deltaTime;

    if (_playerPos.y <= 1.8) {
      _playerPos.y = 1.8;
      _playerVel.y = 0;
    }

    const maxDistance = 1500.0;
    double distance = sqrt(_playerPos.x * _playerPos.x + _playerPos.z * _playerPos.z);
    if (distance > maxDistance) {
      double angle = atan2(_playerPos.z, _playerPos.x);
      _playerPos.x = maxDistance * cos(angle);
      _playerPos.z = maxDistance * sin(angle);
    }

    _playerData.setPosition(_playerPos.x, _playerPos.y, _playerPos.z);
  }

  void _checkCollectibles() {
    if (_worldState == null) return;

    for (var collectible in _worldState!.collectibles) {
      if (!collectible.collected &&
          _playerPos.distance(collectible.position) < 2) {
        _collectItem(collectible);
      }
    }
  }

  void _collectItem(WorldCollectible collectible) {
    _worldState!.collectItem(collectible.id);
    _playerData.addCoins(10);
    _playerData.addInventoryItem(
      InventoryItem(
        id: collectible.id,
        name: collectible.name,
        quantity: 1,
        type: 'item',
      ),
    );
    print('✓ Collected ${collectible.name}');
  }

  void _scheduleAutoSave() {
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted && !_isPaused) {
        _autoSave();
      }
    });
  }

  Future<void> _autoSave() async {
    await _saveService.saveGame(_playerData, autoSave: true);
    _scheduleAutoSave();
  }

  void _showRedeemDialog() {
    showDialog(
      context: context,
      builder: (context) => RedeemCodeDialog(playerData: _playerData),
    );
  }

  void _showPauseMenu() {
    _isPaused = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('⏸ Lerem Dhisik'),
        content: const Text('Kene kate lapo saiki?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _isPaused = false;
            },
            child: const Text('Lanjut Nglayap'),
          ),
          TextButton(
            onPressed: () async {
              await _saveService.saveGame(_playerData);
              if (mounted) Navigator.pop(context);
            },
            child: const Text('Simpen Data'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Metu Game'),
          ),
        ],
      ),
    ).then((_) {
      if (mounted) _isPaused = false;
    });
  }

  @override
  void dispose() {
    _gameLoopController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        onKeyEvent: (node, event) {
          final key = event.logicalKey.keyLabel;
          if (event is KeyDownEvent) {
            _pressedKeys.add(key);
          } else if (event is KeyUpEvent) {
            _pressedKeys.remove(key);
          }
          return KeyEventResult.handled;
        },
        child: !_worldLoaded
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 16),
                    const Text(
                      '🌍 Ngenteni Sekedap, Sik Ngemot Kota Malang...',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              )
            : Stack(
                children: [
                  Container(
                    color: Colors.black87,
                    child: const Center(
                      child: Text(
                        'Kedai Mokka - Malang 3D',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 24,
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    child: IgnorePointer(
                      child: GameHUD3D(
                        playerData: _playerData,
                        fps: _fps,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 16,
                    right: 16,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        ElevatedButton(
                          onPressed: _showRedeemDialog,
                          child: const Text('💳 Ijol Kode'),
                        ),
                        const SizedBox(height: 8),
                        ElevatedButton(
                          onPressed: _showPauseMenu,
                          child: const Text('⏸ Lerem'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
