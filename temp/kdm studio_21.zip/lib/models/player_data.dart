import 'package:flutter/foundation.dart';
import 'dart:math' as math; // Tambah iki

/// 3D World Vector
class Vector3 {
  double x, y, z;

  Vector3({required this.x, required this.y, required this.z});

  factory Vector3.zero() => Vector3(x: 0, y: 0, z: 0);

  // Method iki sing dibutuhno game_screen_3d.dart
  double distance(Vector3 other) {
    double dx = x - other.x;
    double dy = y - other.y;
    double dz = z - other.z;
    return math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  factory Vector3.fromJson(Map<String, dynamic> json) {
    return Vector3(
      x: (json['x'] as num).toDouble(),
      y: (json['y'] as num).toDouble(),
      z: (json['z'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {'x': x, 'y': y, 'z': z};

  @override
  String toString() => 'Vector3($x, $y, $z)';
}

/// Inventory Item (kode liyane tetep, gak usah diubah)
class InventoryItem {
  final String id;
  final String name;
  final int quantity;
  final String type;

  InventoryItem({required this.id, required this.name, this.quantity = 1, this.type = 'item'});

  factory InventoryItem.fromJson(Map<String, dynamic> json) {
    return InventoryItem(
      id: json['id'] as String,
      name: json['name'] as String,
      quantity: json['quantity'] as int? ?? 1,
      type: json['type'] as String? ?? 'item',
    );
  }

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'quantity': quantity, 'type': type};

  InventoryItem copyWith({int? quantity}) {
    return InventoryItem(id: id, name: name, quantity: quantity ?? this.quantity, type: type);
  }
}

/// Main Player Data Model
class PlayerData extends ChangeNotifier {
  Vector3 position;
  int score;
  int coins;
  int level;
  DateTime lastSaveTime;
  List<InventoryItem> inventory;
  Set<String> redeemedCodes;
  String playerName;
  String location;

  PlayerData({
    Vector3? position,
    this.score = 0,
    this.coins = 0,
    this.level = 1,
    DateTime? lastSaveTime,
    List<InventoryItem>? inventory,
    Set<String>? redeemedCodes,
    this.playerName = 'Explorer',
    this.location = 'Kedai Mokka',
  })  : position = position ?? Vector3(x: 0, y: 1.8, z: 0),
        lastSaveTime = lastSaveTime ?? DateTime.now(),
        inventory = inventory ?? [],
        redeemedCodes = redeemedCodes ?? {};

  factory PlayerData.fromJson(Map<String, dynamic> json) {
    return PlayerData(
      position: Vector3.fromJson(json['position'] as Map<String, dynamic>),
      score: json['score'] as int? ?? 0,
      coins: json['coins'] as int? ?? 0,
      level: json['level'] as int? ?? 1,
      lastSaveTime: DateTime.parse(json['lastSaveTime'] as String? ?? DateTime.now().toIso8601String()),
      inventory: (json['inventory'] as List<dynamic>?)?.map((item) => InventoryItem.fromJson(item as Map<String, dynamic>)).toList() ?? [],
      redeemedCodes: Set<String>.from(json['redeemedCodes'] as List<dynamic>? ?? []),
      playerName: json['playerName'] as String? ?? 'Explorer',
      location: json['location'] as String? ?? 'Kedai Mokka',
    );
  }

  Map<String, dynamic> toJson() => {
    'position': position.toJson(),
    'score': score,
    'coins': coins,
    'level': level,
    'lastSaveTime': lastSaveTime.toIso8601String(),
    'inventory': inventory.map((item) => item.toJson()).toList(),
    'redeemedCodes': redeemedCodes.toList(),
    'playerName': playerName,
    'location': location,
  };

  void setPosition(double x, double y, double z) {
    position = Vector3(x: x, y: y, z: z);
    notifyListeners();
  }

  void addCoins(int amount) {
    coins += amount;
    score += amount;
    notifyListeners();
  }

  void addInventoryItem(InventoryItem item) {
    final existingIndex = inventory.indexWhere((i) => i.id == item.id);
    if (existingIndex >= 0) {
      inventory[existingIndex] = inventory[existingIndex].copyWith(quantity: inventory[existingIndex].quantity + item.quantity);
    } else {
      inventory.add(item);
    }
    notifyListeners();
  }

  void markCodeRedeemed(String code) { redeemedCodes.add(code); notifyListeners(); }
  bool isCodeRedeemed(String code) => redeemedCodes.contains(code);
  void setLocation(String newLocation) { location = newLocation; notifyListeners(); }
}
