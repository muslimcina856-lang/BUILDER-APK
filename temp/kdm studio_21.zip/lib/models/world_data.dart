import 'package:latlong2/latlong.dart';
import 'player_data.dart';
import 'dart:math' as dartMath;

/// Geographic coordinates with elevation
class GeoPoint {
  final double latitude;
  final double longitude;
  final double elevation; // meters above sea level

  GeoPoint({
    required this.latitude,
    required this.longitude,
    this.elevation = 0,
  });

  /// Convert geographic coordinates to local 3D world space
  /// Origin (0,0,0) = center point (Kedai Mokka)
  static const LatLng KEDAI_MOKKA = LatLng(-7.976195, 112.723395);

  Vector3 toWorldSpace() {
    const distance = const Distance();
    
    // Calculate distance from origin
    double distMeters = distance(KEDAI_MOKKA, LatLng(latitude, longitude));
    
    // RUMUS BEARING MANUAL GAWE NGGANTI bearingTo() SING EROR
    double lat1 = KEDAI_MOKKA.latitude * dartMath.pi / 180;
    double lon1 = KEDAI_MOKKA.longitude * dartMath.pi / 180;
    double lat2 = latitude * dartMath.pi / 180;
    double lon2 = longitude * dartMath.pi / 180;

    double dLon = lon2 - lon1;
    double yDeg = dartMath.sin(dLon) * dartMath.cos(lat2);
    double xDeg = dartMath.cos(lat1) * dartMath.sin(lat2) -
        dartMath.sin(lat1) * dartMath.cos(lat2) * dartMath.cos(dLon);
    
    double radians = dartMath.atan2(yDeg, xDeg);

    // Convert to 3D coordinates
    double x = distMeters * dartMath.sin(radians);
    double z = distMeters * dartMath.cos(radians);
    double y = elevation; // Height = elevation

    return Vector3(x: x, y: y, z: z);
  }
}

/// Building in the world (from OSM data)
class Building {
  final String id;
  final String name;
  final List<Vector3> vertices; // Base footprint
  final double height;
  final String? type; // 'house', 'shop', 'office', etc.
  final String? address;
  final double latitude;
  final double longitude;

  Building({
    required this.id,
    required this.name,
    required this.vertices,
    required this.height,
    this.type,
    this.address,
    required this.latitude,
    required this.longitude,
  });

  /// Get center position
  Vector3 getCenter() {
    if (vertices.isEmpty) return Vector3.zero();
    
    double sumX = 0, sumY = 0, sumZ = 0;
    for (var v in vertices) {
      sumX += v.x;
      sumY += v.y;
      sumZ += v.z;
    }
    return Vector3(
      x: sumX / vertices.length,
      y: sumY / vertices.length,
      z: sumZ / vertices.length,
    );
  }

  /// Check if point is inside building footprint (simplified)
  bool contains(Vector3 point) {
    if (vertices.isEmpty) return false;
    
    double minX = vertices[0].x, maxX = vertices[0].x;
    double minZ = vertices[0].z, maxZ = vertices[0].z;

    for (var v in vertices) {
      if (v.x < minX) minX = v.x;
      if (v.x > maxX) maxX = v.x;
      if (v.z < minZ) minZ = v.z;
      if (v.z > maxZ) maxZ = v.z;
    }

    return point.x >= minX && point.x <= maxX &&
        point.z >= minZ && point.z <= maxZ;
  }
}

/// Road/Street in the world
class Road {
  final String id;
  final String name;
  final List<Vector3> path; // Centerline points
  final double width; // meters
  final String? type; // 'primary', 'secondary', 'residential'

  Road({
    required this.id,
    required this.name,
    required this.path,
    this.width = 5,
    this.type,
  });

  /// Check if point is near road
  bool isNear(Vector3 point, double distance) {
    if (path.isEmpty) return false;

    for (int i = 0; i < path.length - 1; i++) {
      Vector3 a = path[i];
      Vector3 b = path[i + 1];

      double dist = _pointToSegmentDistance(point, a, b);
      if (dist <= distance) return true;
    }
    return false;
  }

  double _pointToSegmentDistance(Vector3 p, Vector3 a, Vector3 b) {
    double dx = b.x - a.x;
    double dz = b.z - a.z;
    
    double lengthSq = dx * dx + dz * dz;
    if (lengthSq == 0) return _calculateDistance(p, a);
    
    double t = ((p.x - a.x) * dx + (p.z - a.z) * dz) / lengthSq;

    if (t < 0) return _calculateDistance(p, a);
    if (t > 1) return _calculateDistance(p, b);

    Vector3 closest = Vector3(
      x: a.x + t * dx,
      y: a.y,
      z: a.z + t * dz,
    );
    return _calculateDistance(p, closest);
  }

  double _calculateDistance(Vector3 v1, Vector3 v2) {
    double dx = v1.x - v2.x;
    double dy = v1.y - v2.y;
    double dz = v1.z - v2.z;
    return dartMath.sqrt(dx * dx + dy * dy + dz * dz);
  }
}

/// Collectible item in the world
class WorldCollectible {
  final String id;
  final Vector3 position;
  final String type; // 'coin', 'bean', 'artifact'
  final String name;
  bool collected;
  final DateTime spawnTime;

  WorldCollectible({
    required this.id,
    required this.position,
    required this.type,
    required this.name,
    this.collected = false,
    DateTime? spawnTime,
  }) : spawnTime = spawnTime ?? DateTime.now();

  /// Check if collected by player
  bool isCollectedBy(Vector3 playerPos, double radius) {
    double dx = playerPos.x - position.x;
    double dy = playerPos.y - position.y;
    double dz = playerPos.z - position.z;
    double dist = dartMath.sqrt(dx * dx + dy * dy + dz * dz);
    return !collected && dist <= radius;
  }
}

/// Terrain data (heightmap)
class Terrain {
  final List<List<double>> heightMap; // 2D array of elevations
  final double gridSize; // meters between points
  final int resolution; // points per side
  final Vector3 origin; // World space origin

  Terrain({
    required this.heightMap,
    required this.gridSize,
    required this.resolution,
    required this.origin,
  });

  /// Get height at world position
  double getHeightAt(double x, double z) {
    double localX = (x - origin.x) / gridSize;
    double localZ = (z - origin.z) / gridSize;

    int ix = localX.toInt();
    int iz = localZ.toInt();

    if (ix < 0 || ix >= resolution - 1 || iz < 0 || iz >= resolution - 1) {
      return 0;
    }

    double fx = localX - ix;
    double fz = localZ - iz;

    double h00 = heightMap[iz][ix];
    double h10 = heightMap[iz][ix + 1];
    double h01 = heightMap[iz + 1][ix];
    double h11 = heightMap[iz + 1][ix + 1];

    double h0 = h00 * (1 - fx) + h10 * fx;
    double h1 = h01 * (1 - fx) + h11 * fx;

    return h0 * (1 - fz) + h1 * fz;
  }
}

/// Complete world state
class WorldState {
  final List<Building> buildings;
  final List<Road> roads;
  final List<WorldCollectible> collectibles;
  final Terrain terrain;
  final DateTime lastUpdate;

  WorldState({
    required this.buildings,
    required this.roads,
    required this.collectibles,
    required this.terrain,
    DateTime? lastUpdate,
  }) : lastUpdate = lastUpdate ?? DateTime.now();

  /// Get all buildings near position
  List<Building> getBuildingsNear(Vector3 position, double radius) {
    return buildings
        .where((b) => _calculateDistance(b.getCenter(), position) <= radius)
        .toList();
  }

  /// Get all roads near position
  List<Road> getRoadsNear(Vector3 position, double radius) {
    return roads
        .where((r) => r.isNear(position, radius))
        .toList();
  }

  /// Get nearby collectibles
  List<WorldCollectible> getCollectiblesNear(Vector3 position, double radius) {
    return collectibles
        .where((c) => !c.collected && _calculateDistance(c.position, position) <= radius)
        .toList();
  }

  /// Mark collectible as collected
  void collectItem(String collectibleId) {
    final index = collectibles.indexWhere((c) => c.id == collectibleId);
    if (index >= 0) {
      collectibles[index].collected = true;
    }
  }

  /// Respawn collected items
  void respawnItems({Duration duration = const Duration(seconds: 30)}) {
    final now = DateTime.now();
    for (var item in collectibles) {
      if (item.collected) {
        if (now.difference(item.spawnTime).inSeconds >= duration.inSeconds) {
          item.collected = false;
        }
      }
    }
  }

  double _calculateDistance(Vector3 v1, Vector3 v2) {
    double dx = v1.x - v2.x;
    double dy = v1.y - v2.y;
    double dz = v1.z - v2.z;
    return dartMath.sqrt(dx * dx + dy * dy + dz * dz);
  }
}
