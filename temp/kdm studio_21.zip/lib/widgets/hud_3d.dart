import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/player_data.dart';

class GameHUD3D extends StatelessWidget {
  final PlayerData playerData;
  final double fps;
  final bool showDebugInfo;

  const GameHUD3D({
    Key? key,
    required this.playerData,
    this.fps = 60,
    this.showDebugInfo = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PlayerData>(
      builder: (context, player, child) {
        return Stack(
          children: [
            // Top-left: Stats
            Positioned(
              top: 20,
              left: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _StatBox('🪙 Coins', '${player.coins}', Colors.amber),
                  SizedBox(height: 8),
                  _StatBox('⭐ Score', '${player.score}', Colors.yellow),
                  SizedBox(height: 8),
                  _StatBox('📊 Level', '${player.level}', Colors.blue),
                ],
              ),
            ),

            // Top-right: Position
            Positioned(
              top: 20,
              right: 20,
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.cyan, width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '📍 Position',
                      style: TextStyle(
                        color: Colors.cyan,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'X: ${player.position.x.toStringAsFixed(1)}',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                    Text(
                      'Y: ${player.position.y.toStringAsFixed(1)}',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                    Text(
                      'Z: ${player.position.z.toStringAsFixed(1)}',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),

            // Bottom-left: Inventory
            Positioned(
              bottom: 20,
              left: 20,
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '🎒 Inventory (${player.inventory.length})',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: 8),
                    ...player.inventory.take(4).map(
                      (item) => Text(
                        '• ${item.name} x${item.quantity}',
                        style: TextStyle(color: Colors.lime, fontSize: 11),
                      ),
                    ),
                    if (player.inventory.length > 4)
                      Text(
                        '+${player.inventory.length - 4} more',
                        style: TextStyle(color: Colors.amber, fontSize: 10),
                      ),
                  ],
                ),
              ),
            ),

            // Center: Location
            Positioned(
              top: MediaQuery.of(context).size.height / 2 - 60,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.cyan, width: 2),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '📍 ${player.location}',
                        style: TextStyle(
                          color: Colors.cyan,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Jl. Remujung, Jatimulyo, Malang',
                        style: TextStyle(color: Colors.white70, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Debug info
            if (showDebugInfo)
              Positioned(
                top: 20,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: Colors.lime),
                    ),
                    child: Text(
                      'FPS: ${fps.toStringAsFixed(1)}',
                      style: TextStyle(
                        color: Colors.lime,
                        fontFamily: 'monospace',
                        fontSize: 11,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _StatBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatBox(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '$label: ',
            style: TextStyle(color: Colors.white70, fontSize: 11),
          ),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
