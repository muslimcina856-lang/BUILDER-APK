import 'package:flutter/material.dart';
import '../models/player_data.dart';
import '../services/redeem_service.dart';

class RedeemCodeDialog extends StatefulWidget {
  final PlayerData playerData;

  const RedeemCodeDialog({
    Key? key,
    required this.playerData,
  }) : super(key: key);

  @override
  State<RedeemCodeDialog> createState() => _RedeemCodeDialogState();
}

class _RedeemCodeDialogState extends State<RedeemCodeDialog> {
  late TextEditingController _codeController;
  late FocusNode _focusNode;
  final RedeemService _redeemService = RedeemService();
  RedeemResult? _lastResult;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _codeController = TextEditingController();
    _focusNode = FocusNode();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _codeController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _handleRedeem() async {
    final code = _codeController.text.trim();

    if (code.isEmpty) {
      _showMessage('Masukkan kode', error: true);
      return;
    }

    if (!_redeemService.isValidCodeFormat(code)) {
      _showMessage('Format kode salah', error: true);
      return;
    }

    setState(() => _isLoading = true);
    await Future.delayed(Duration(milliseconds: 500));

    final result = await _redeemService.redeemCode(code, widget.playerData);

    setState(() {
      _isLoading = false;
      _lastResult = result;
    });

    if (result.success) {
      _codeController.clear();
      await Future.delayed(Duration(seconds: 2));
      if (mounted) Navigator.pop(context);
    }
  }

  void _showMessage(String message, {bool error = false}) {
    setState(() {
      _lastResult = RedeemResult(
        success: !error,
        message: message,
        code: _codeController.text,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Center(
        child: Container(
          width: MediaQuery.of(context).size.width * 0.85,
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.purple.withOpacity(0.5), width: 2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '💳 Tukar Kode',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Icon(Icons.close, color: Colors.white70),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Text(
                'Masukkan kode untuk mendapatkan hadiah',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _codeController,
                focusNode: _focusNode,
                enabled: !_isLoading,
                textCapitalization: TextCapitalization.characters,
                decoration: InputDecoration(
                  hintText: 'e.g., MOKKA-START',
                  hintStyle: TextStyle(color: Colors.white30),
                  filled: true,
                  fillColor: Colors.black26,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide:
                        BorderSide(color: Colors.purple.withOpacity(0.3)),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                style: TextStyle(color: Colors.white, fontSize: 14),
                onSubmitted: (_) => _handleRedeem(),
              ),
              SizedBox(height: 12),
              if (_lastResult != null)
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _lastResult!.success
                        ? Colors.green.withOpacity(0.15)
                        : Colors.red.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _lastResult!.success
                          ? Colors.green.withOpacity(0.5)
                          : Colors.red.withOpacity(0.5),
                    ),
                  ),
                  child: Text(
                    _lastResult!.message,
                    style: TextStyle(
                      color: _lastResult!.success
                          ? Colors.green[300]
                          : Colors.red[300],
                      fontSize: 12,
                    ),
                  ),
                ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _isLoading ? null : () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey[800],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'Batal',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white70),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: _isLoading ? null : _handleRedeem,
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.purple[600]!, Colors.purple[400]!],
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: _isLoading
                            ? SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : Text(
                                'Tukar',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kode Tersedia:',
                      style: TextStyle(
                        color: Colors.blue[300],
                        fontWeight: FontWeight.bold,
                        fontSize: 11,
                      ),
                    ),
                    SizedBox(height: 6),
                    ..._redeemService.getAllCodes().take(3).map(
                      (code) => Text(
                        '• ${code.code} — ${code.description}',
                        style: TextStyle(color: Colors.blue[200], fontSize: 10),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
