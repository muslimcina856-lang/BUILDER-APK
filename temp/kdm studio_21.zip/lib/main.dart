import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/player_data.dart';
import 'screens/game_screen_3d.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => PlayerData(
            playerName: 'Traveler',
            location: 'Kedai Mokka - Malang',
          ),
        ),
      ],
      child: const KedaiMokkaApp(),
    ),
  );
}

class KedaiMokkaApp extends StatelessWidget {
  const KedaiMokkaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kedai Mokka 3D — Malang Explorer',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.purple,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const GameScreen3D(),
      debugShowCheckedModeBanner: false,
    );
  }
}
