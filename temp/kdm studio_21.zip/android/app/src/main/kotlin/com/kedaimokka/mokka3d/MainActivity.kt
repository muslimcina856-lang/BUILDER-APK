package com.kedaimokka.mokka3d

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
