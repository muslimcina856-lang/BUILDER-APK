# 🎮 Kedai Mokka 3D — Malang Explorer

Aplikasi mobile 3D explorer yang berjalan di Malang, Indonesia. Jelajahi kota secara real-time dengan grafis 3D, kumpulkan item, dan tukar kode.

**Location:** Jl. Remujung No. 24, Jatimulyo, Malang  
**Map Scale:** 1.5 km radius  
**Built with:** Flutter + Three.dart

---

## 🚀 Setup Cepat

### 1. Syarat
- Flutter SDK >= 3.0.0
- Dart SDK
- Android SDK (untuk APK) atau Xcode (untuk iOS)

### 2. Clone/Extract Project
```bash
unzip kedai_mokka_3d.zip
cd kedai_mokka_3d
```

### 3. Install Dependencies
```bash
flutter pub get
```

### 4. Jalankan di Device/Emulator
```bash
# Android Emulator
flutter run

# Device Android
flutter run -d [device_id]

# Web
flutter run -d chrome

# iOS
flutter run -d ios
```

### 5. Build APK untuk Production
```bash
flutter build apk --release
```

**APK akan tersimpan di:** `build/app/outputs/flutter-apk/app-release.apk`

---

## 🎮 Kontrol Permainan

| Input | Aksi |
|-------|------|
| **W** / **↑** | Maju |
| **A** / **←** | Kiri |
| **S** / **↓** | Mundur |
| **D** / **→** | Kanan |
| **Space** | Lompat |
| **Mouse/Touch** | Lihat sekitar (FPS view) |
| **⏸ Pause** | Menu |
| **💳 Redeem** | Tukar kode |

---

## 💾 Sistem Simpan

- **Auto-save:** Setiap 30 detik
- **Manual save:** Via menu Pause
- **Format:** JSON + Base64 encoding
- **Lokasi:** `Documents/kedai_mokka_3d/`

---

## 💳 Kode Redemption

| Kode | Hadiah |
|------|--------|
| `MOKKA-START` | 100 coins |
| `MALANG-EXPLORE` | 200 coins + 5 Premium Beans |
| `JATIMULYO-50` | 50 coins |
| `COFFEE-LOVER` | 300 coins + 10 beans |
| `REMUJUNG-JAY` | 150 coins |

**Cara:**
1. Tap **💳 Redeem Code**
2. Masukkan kode (uppercase)
3. Tap **Tukar**
4. Dapatkan hadiah!

---

## 📊 Fitur

✅ **3D Real-World Mapping**
- Jalan & bangunan dari OpenStreetMap
- Skala akurat 1:1
- Malang, Indonesia

✅ **First-Person Exploration**
- FPS camera view
- Physics realistis
- Pergerakan smooth

✅ **Collectibles & Items**
- Kumpulkan coin, bean, artifact
- Inventory system
- Auto-respawn

✅ **Save/Load System**
- Auto-save 30 detik
- Manual save via menu
- Cloud-compatible (future)

✅ **Code Redemption**
- 5+ kode aktif
- Flexible rewards
- One-time use

✅ **Multi-Platform**
- Android ✅
- iOS ✅
- Web ✅
- Desktop ✅

---

## 🏗️ Struktur Project

```
kedai_mokka_3d/
├── lib/
│   ├── main.dart                    # Entry point
│   ├── models/
│   │   ├── player_data.dart         # Player state
│   │   └── world_data.dart          # World objects
│   ├── services/
│   │   ├── save_game_service.dart   # File I/O
│   │   ├── redeem_service.dart      # Code validation
│   │   └── map_service.dart         # OSM data
│   ├── screens/
│   │   └── game_screen_3d.dart      # Main game
│   └── widgets/
│       ├── hud_3d.dart              # UI overlay
│       └── redeem_dialog.dart       # Dialog
├── pubspec.yaml                     # Dependencies
├── README.md                        # Ini
└── .gitignore
```

---

## 🔧 Customization

### Tambah Kode Baru
Edit `lib/services/redeem_service.dart`:
```dart
RedeemableCode(
  code: 'MY-CODE',
  description: 'My Reward',
  reward: Reward(coins: 100, score: 50),
),
```

### Ubah Spawn Point
Edit `lib/screens/game_screen_3d.dart`:
```dart
Vector3 _playerPos = Vector3(x: 0, y: 1.8, z: 0);
```

### Ubah Speed/Physics
```dart
const double MOVE_SPEED = 8.0;    // ← ubah ke 10.0 lebih cepat
const double GRAVITY = 9.8;
const double JUMP_POWER = 6.0;
```

---

## 🐛 Troubleshooting

**"Flutter command not found"**
```bash
export PATH="$PATH:/path/to/flutter/bin"
```

**"No devices found"**
```bash
flutter devices
# atau jalankan Android emulator terlebih dahulu
```

**"Error: failed to find build tools"**
```bash
flutter doctor
# Follow instructions to install missing tools
```

**"APK build failed"**
```bash
flutter clean
flutter pub get
flutter build apk --release
```

**Performa lambat?**
- Kurangi world item count di `map_service.dart`
- Disable debug info
- Pastikan device punya RAM cukup

---

## 📱 Release APK

### Build Signed APK (Production)
```bash
# Generate key (first time only)
keytool -genkey -v -keystore kedai-mokka-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias kedai-mokka-key

# Build signed APK
flutter build apk --release

# APK tersimpan di:
# build/app/outputs/flutter-apk/app-release.apk
```

### Install ke Device
```bash
adb install build/app/outputs/flutter-apk/app-release.apk
```

---

## 📊 Tech Stack

- **Framework:** Flutter
- **Language:** Dart 3.0+
- **3D Rendering:** Three.dart
- **Maps:** OpenStreetMap + Overpass API
- **State:** Provider
- **Storage:** path_provider + JSON

---

## 🤝 Dependencies

```yaml
provider: ^6.0.0              # State management
three_dart: ^0.7.0            # 3D rendering
geolocator: ^9.0.2            # GPS
latlong2: ^0.9.1              # Coordinates
http: ^1.1.0                  # API requests
path_provider: ^2.1.0         # File storage
```

---

## 🎯 Roadmap

- [ ] Real 3D building models
- [ ] Weather system
- [ ] Multiplayer sync
- [ ] Cloud save backup
- [ ] Achievements
- [ ] Sound effects
- [ ] Minimap
- [ ] NPC interactions

---

## 📝 License

Personal use only. 

---

## ❓ Help

**Dokumentasi resmi:**
- [Flutter Docs](https://flutter.dev/docs)
- [Dart Docs](https://dart.dev)
- [OpenStreetMap](https://www.openstreetmap.org)

---

**Nikmati jelajah Malang! 🌍☕**

*Made with ❤️ by [Name]*
