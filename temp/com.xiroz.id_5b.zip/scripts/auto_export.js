/**
 * Pull latest user.json from gist, save to local file.
 * Run: node auto_export.js
 * Cron: 0 * * * * node /path/to/auto_export.js
 */
const https = require('https');
const fs = require('fs');
const path = require('path');

const GIST_ID = 'a4a515e84d2865f246b8074661ee76d4';
const GH_TOKEN = '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';
const OUT_DIR = './exports';

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const ts = new Date().toISOString().replace(/[:.]/g, '-');
const outFile = path.join(OUT_DIR, `user_${ts}.json`);

// Fetch via API for authenticated access
const opts = {
  hostname: 'api.github.com',
  path: `/gists/${GIST_ID}`,
  headers: {
    'Authorization': `Bearer ${GH_TOKEN}`,
    'Accept': 'application/vnd.github+json',
    'User-Agent': 'GhostNote-Export/2.0',
  },
};

https.get(opts, (res) => {
  let data = '';
  res.on('data', c => data += c);
  res.on('end', () => {
    const gist = JSON.parse(data);
    const content = gist.files['user.json']?.content;
    if (!content) {
      console.error('No user.json in gist.');
      process.exit(1);
    }
    const pretty = JSON.stringify(JSON.parse(content), null, 2);
    fs.writeFileSync(outFile, pretty);
    console.log(`[${new Date().toISOString()}] Exported to ${outFile} (${pretty.length} bytes)`);

    // Keep last 72 exports
    const files = fs.readdirSync(OUT_DIR)
      .filter(f => f.startsWith('user_'))
      .sort().reverse();
    files.slice(72).forEach(f => {
      fs.unlinkSync(path.join(OUT_DIR, f));
      console.log(`  Pruned: ${f}`);
    });
  });
}).on('error', e => {
  console.error(`Export failed: ${e.message}`);
  process.exit(1);
});