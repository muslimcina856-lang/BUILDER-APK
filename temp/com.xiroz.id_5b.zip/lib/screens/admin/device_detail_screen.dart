import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/user_database.dart';

class DeviceDetailScreen extends StatelessWidget {
  final DeviceEntry device;
  const DeviceDetailScreen({super.key, required this.device});

  @override
  Widget build(BuildContext context) {
    final logs = device.logs.reversed.toList();
    final fmt = DateFormat('MM/dd HH:mm:ss');

    return Scaffold(
      appBar: AppBar(title: Text(device.model)),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: const Color(0xFF161B22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${device.manufacturer} ${device.model}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text(
                    'Android ${device.osVersion} · ID: ${device.id.substring(0, device.id.length > 12 ? 12 : device.id.length)}...',
                    style:
                        const TextStyle(color: Colors.grey, fontSize: 12)),
                if (device.lastLatitude != null) ...[
                  const SizedBox(height: 4),
                  Text(
                      '📍 ${device.lastLatitude!.toStringAsFixed(4)}, ${device.lastLongitude!.toStringAsFixed(4)}',
                      style: const TextStyle(color: Colors.green, fontSize: 12)),
                ],
              ],
            ),
          ),
          Expanded(
            child: logs.isEmpty
                ? const Center(
                    child: Text('No logs yet.',
                        style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: logs.length,
                    itemBuilder: (_, i) {
                      final log = logs[i];
                      IconData icon;
                      Color color;
                      switch (log.type) {
                        case 'location':
                          icon = Icons.location_on;
                          color = Colors.green;
                          break;
                        case 'device_info':
                          icon = Icons.info;
                          color = Colors.blue;
                          break;
                        default:
                          icon = Icons.list;
                          color = Colors.grey;
                      }
                      return Card(
                        color: const Color(0xFF161B22),
                        margin: const EdgeInsets.only(bottom: 6),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: color.withOpacity(0.2),
                            radius: 16,
                            child: Icon(icon, size: 16, color: color),
                          ),
                          title: Text(log.type.toUpperCase(),
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: color)),
                          subtitle: Text(
                            '${fmt.format(log.dt)}\n${_summarize(log.data)}',
                            style: const TextStyle(
                                fontSize: 11, color: Colors.grey),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _summarize(Map<String, dynamic> d) {
    if (d.containsKey('latitude')) {
      return '📍 ${d['latitude']?.toStringAsFixed(4)}, ${d['longitude']?.toStringAsFixed(4)}';
    }
    if (d.containsKey('brand')) {
      return '📱 ${d['brand']} ${d['device']}';
    }
    return d.keys.take(3).join(', ');
  }
}