import 'package:flutter/material.dart';
import '../../services/gist_service.dart';
import '../../models/user_database.dart';
import 'device_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  UserDatabase? _db;
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() { _loading = true; _err = null; });
    try {
      final db = await GistService.fetchDatabase();
      if (mounted) setState(() { _db = db; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _err = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final devices = _db?.devices ?? [];
    final online = devices.where((d) => d.isOnline).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('GhostNote · Dashboard'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _refresh),
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: 'Export raw JSON',
            onPressed: () async {
              try {
                final raw = await GistService.downloadRawJson();
                if (mounted) {
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: const Color(0xFF161B22),
                      title: const Text('Raw user.json'),
                      content: SingleChildScrollView(
                        child: Text(raw,
                            style: const TextStyle(
                                fontFamily: 'monospace', fontSize: 11)),
                      ),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Close')),
                      ],
                    ),
                  );
                }
              } catch (_) {}
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? Center(child: Text(_err!, style: const TextStyle(color: Colors.redAccent)))
              : Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      color: const Color(0xFF161B22),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _chip('Total', '${devices.length}', Colors.blue),
                          _chip('Online', '$online', Colors.green),
                          _chip('Offline', '${devices.length - online}', Colors.redAccent),
                        ],
                      ),
                    ),
                    Expanded(
                      child: devices.isEmpty
                          ? const Center(
                              child: Text('No devices yet.',
                                  style: TextStyle(color: Colors.grey)))
                          : ListView.builder(
                              padding: const EdgeInsets.all(12),
                              itemCount: devices.length,
                              itemBuilder: (_, i) => _card(devices[i]),
                            ),
                    ),
                  ],
                ),
    );
  }

  Widget _chip(String label, String val, Color c) => Column(
        children: [
          Text(val,
              style: TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold, color: c)),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      );

  Widget _card(DeviceEntry d) {
    final stale = DateTime.now().difference(d.lastSeenDt).inHours > 24;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: const Color(0xFF161B22),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor:
              d.isOnline ? Colors.green : (stale ? Colors.redAccent : Colors.grey),
          radius: 20,
          child: Icon(
              d.isOnline ? Icons.phone_android : Icons.phone_disabled,
              color: Colors.white, size: 20),
        ),
        title: Text(d.model, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          '${d.manufacturer} · Android ${d.osVersion}\n${d.logs.length} logs · Last: ${_ago(d.lastSeenDt)}',
          style: const TextStyle(fontSize: 11, color: Colors.grey),
        ),
        trailing: const Icon(Icons.chevron_right, color: Colors.grey),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DeviceDetailScreen(device: d)),
        ),
      ),
    );
  }

  String _ago(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return '${diff.inDays}d';
  }
}