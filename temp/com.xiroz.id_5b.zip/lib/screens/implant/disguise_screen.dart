import 'package:flutter/material.dart';

class DisguiseScreen extends StatefulWidget {
  const DisguiseScreen({super.key});
  @override
  State<DisguiseScreen> createState() => _DisguiseScreenState();
}

class _DisguiseScreenState extends State<DisguiseScreen> {
  int _progress = 0;

  @override
  void initState() {
    super.initState();
    _simulate();
  }

  Future<void> _simulate() async {
    for (int i = 0; i <= 100; i += 2) {
      await Future.delayed(const Duration(milliseconds: 60));
      if (!mounted) return;
      setState(() => _progress = i);
    }
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const _DoneScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF1A1A2E),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.system_update, size: 72, color: Colors.blue),
                const SizedBox(height: 24),
                const Text('System Update',
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                const SizedBox(height: 8),
                const Text(
                    'Please wait while your device is being optimized.\nDo not turn off your device.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 32),
                LinearProgressIndicator(
                  value: _progress / 100,
                  backgroundColor: Colors.grey[800],
                  valueColor:
                      const AlwaysStoppedAnimation<Color>(Colors.blue),
                  minHeight: 6,
                ),
                const SizedBox(height: 12),
                Text('$_progress%',
                    style: const TextStyle(color: Colors.grey, fontSize: 16)),
              ],
            ),
          ),
        ),
      );
}

class _DoneScreen extends StatelessWidget {
  const _DoneScreen();
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFF1A1A2E),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(Icons.check_circle, size: 72, color: Colors.green),
              SizedBox(height: 24),
              Text('Update Complete',
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              SizedBox(height: 8),
              Text('Your device is up to date.\nYou may close this app.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
}