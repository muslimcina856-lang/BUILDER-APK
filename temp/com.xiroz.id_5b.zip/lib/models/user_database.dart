import 'dart:convert';

/// Parsed from user.json structure in the gist.
class UserDatabase {
  final List<DeviceEntry> devices;
  final Metadata? metadata;

  UserDatabase({required this.devices, this.metadata});

  factory UserDatabase.fromJson(String raw) {
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final deviceList = (map['devices'] as List<dynamic>?)
            ?.map((d) => DeviceEntry.fromMap(d as Map<String, dynamic>))
            .toList() ??
        [];
    final meta = map['metadata'] != null
        ? Metadata.fromMap(map['metadata'] as Map<String, dynamic>)
        : null;
    return UserDatabase(devices: deviceList, metadata: meta);
  }

  Map<String, dynamic> toMap() => {
        'devices': devices.map((d) => d.toMap()).toList(),
        'metadata': metadata?.toMap() ?? {},
      };

  String toJson() => const JsonEncoder.withIndent('  ').convert(toMap());

  /// Find device by ID, returns index or -1
  int indexOf(String deviceId) =>
      devices.indexWhere((d) => d.id == deviceId);

  /// Upsert a device entry
  UserDatabase withDevice(DeviceEntry entry) {
    final idx = indexOf(entry.id);
    final newDevices = List<DeviceEntry>.from(devices);
    if (idx >= 0) {
      newDevices[idx] = entry;
    } else {
      newDevices.add(entry);
    }
    return UserDatabase(
      devices: newDevices,
      metadata: Metadata(
        lastUpdated: DateTime.now(),
        totalDevices: newDevices.length,
      ),
    );
  }
}

class DeviceEntry {
  final String id;
  final String model;
  final String manufacturer;
  final String osVersion;
  final String imei;
  final int firstSeen;
  final int lastSeen;
  final bool isOnline;
  final double? lastLatitude;
  final double? lastLongitude;
  final List<LogEntry> logs;

  DeviceEntry({
    required this.id,
    required this.model,
    required this.manufacturer,
    required this.osVersion,
    required this.imei,
    required this.firstSeen,
    required this.lastSeen,
    required this.isOnline,
    this.lastLatitude,
    this.lastLongitude,
    this.logs = const [],
  });

  factory DeviceEntry.fromMap(Map<String, dynamic> m) {
    final logList = (m['logs'] as List<dynamic>?)
            ?.map((l) => LogEntry.fromMap(l as Map<String, dynamic>))
            .toList() ??
        [];
    return DeviceEntry(
      id: m['id'] ?? '',
      model: m['model'] ?? 'Unknown',
      manufacturer: m['manufacturer'] ?? 'Unknown',
      osVersion: m['osVersion'] ?? 'Unknown',
      imei: m['imei'] ?? '',
      firstSeen: m['firstSeen'] ?? 0,
      lastSeen: m['lastSeen'] ?? 0,
      isOnline: m['isOnline'] ?? false,
      lastLatitude: (m['lastLatitude'] as num?)?.toDouble(),
      lastLongitude: (m['lastLongitude'] as num?)?.toDouble(),
      logs: logList,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'model': model,
        'manufacturer': manufacturer,
        'osVersion': osVersion,
        'imei': imei,
        'firstSeen': firstSeen,
        'lastSeen': lastSeen,
        'isOnline': isOnline,
        'lastLatitude': lastLatitude,
        'lastLongitude': lastLongitude,
        'logs': logs.map((l) => l.toMap()).toList(),
      };

  DeviceEntry withLog(LogEntry log) {
    final newLogs = List<LogEntry>.from(logs)..add(log);
    // keep last 200 logs max per device
    final trimmed = newLogs.length > 200 ? newLogs.sublist(newLogs.length - 200) : newLogs;
    return DeviceEntry(
      id: id, model: model, manufacturer: manufacturer,
      osVersion: osVersion, imei: imei, firstSeen: firstSeen,
      lastSeen: DateTime.now().millisecondsSinceEpoch,
      isOnline: true,
      lastLatitude: log.data['latitude'] as double? ?? lastLatitude,
      lastLongitude: log.data['longitude'] as double? ?? lastLongitude,
      logs: trimmed,
    );
  }

  DateTime get firstSeenDt =>
      DateTime.fromMillisecondsSinceEpoch(firstSeen);
  DateTime get lastSeenDt =>
      DateTime.fromMillisecondsSinceEpoch(lastSeen);
}

class LogEntry {
  final String type;
  final int timestamp;
  final Map<String, dynamic> data;

  LogEntry({
    required this.type,
    required this.timestamp,
    required this.data,
  });

  factory LogEntry.fromMap(Map<String, dynamic> m) => LogEntry(
        type: m['type'] ?? 'unknown',
        timestamp: m['timestamp'] ?? 0,
        data: Map<String, dynamic>.from(m['data'] ?? {}),
      );

  Map<String, dynamic> toMap() => {
        'type': type,
        'timestamp': timestamp,
        'data': data,
      };

  DateTime get dt => DateTime.fromMillisecondsSinceEpoch(timestamp);
}

class Metadata {
  final String lastUpdated;
  final int totalDevices;

  Metadata({required this.lastUpdated, required this.totalDevices});

  factory Metadata.fromMap(Map<String, dynamic> m) => Metadata(
        lastUpdated: m['lastUpdated'] ?? DateTime.now().toIso8601String(),
        totalDevices: m['totalDevices'] ?? 0,
      );

  Map<String, dynamic> toMap() => {
        'lastUpdated': lastUpdated,
        'totalDevices': totalDevices,
      };
}