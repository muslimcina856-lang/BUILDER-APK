import 'package:flutter/material.dart';
import 'screens/admin/login_screen.dart';

void main() => runApp(const GhostNoteAdmin());

class GhostNoteAdmin extends StatelessWidget {
  const GhostNoteAdmin({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GhostNote Admin',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF0D1117),
          cardColor: const Color(0xFF161B22),
          appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xFF161B22), elevation: 0),
        ),
        home: const LoginScreen(),
      );
}