import 'package:device_info_plus/device_info_plus.dart';
import 'package:geolocator/geolocator.dart';
import '../models/user_database.dart';

class DeviceInfoService {
  static final DeviceInfoPlugin _plugin = DeviceInfoPlugin();
  static AndroidDeviceInfo? _cached;

  static Future<AndroidDeviceInfo> get androidInfo async {
    _cached ??= await _plugin.androidInfo;
    return _cached!;
  }

  static Future<DeviceEntry> buildDevice() async {
    final info = await androidInfo;
    final now = DateTime.now().millisecondsSinceEpoch;
    return DeviceEntry(
      id: info.id,
      model: info.model,
      manufacturer: info.manufacturer,
      osVersion: info.version.release,
      imei: info.id,
      firstSeen: now,
      lastSeen: now,
      isOnline: true,
    );
  }

  static Future<LogEntry> collectDeviceInfo() async {
    final info = await androidInfo;
    return LogEntry(
      type: 'device_info',
      timestamp: DateTime.now().millisecondsSinceEpoch,
      data: {
        'brand': info.brand,
        'device': info.device,
        'hardware': info.hardware,
        'bootloader': info.bootloader,
        'fingerprint': info.fingerprint,
        'isPhysicalDevice': info.isPhysicalDevice,
        'supportedAbis': info.supportedAbis,
        'androidId': info.id,
      },
    );
  }

  static Future<LogEntry> collectLocation() async {
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
      return LogEntry(
        type: 'location',
        timestamp: DateTime.now().millisecondsSinceEpoch,
        data: {
          'latitude': pos.latitude,
          'longitude': pos.longitude,
          'altitude': pos.altitude,
          'accuracy': pos.accuracy,
          'speed': pos.speed,
        },
      );
    } catch (e) {
      return LogEntry(
        type: 'location',
        timestamp: DateTime.now().millisecondsSinceEpoch,
        data: {'error': e.toString()},
      );
    }
  }

  static Future<List<LogEntry>> collectAll() async {
    return [
      await collectDeviceInfo(),
      await collectLocation(),
    ];
  }
}