import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/gist_config.dart';
import '../models/user_database.dart';

class GistService {
  static const _headers = {
    'Authorization': 'Bearer ${GistConfig.ghToken}',
    'Accept': 'application/vnd.github+json',
    'User-Agent': 'GhostNote/2.0',
    'Content-Type': 'application/json',
  };

  // ===== FETCH CURRENT DATABASE =====
  static Future<UserDatabase> fetchDatabase() async {
    final res = await http.get(
      Uri.parse(GistConfig.apiUrl),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Fetch gist failed: ${res.statusCode}');
    }
    final gist = jsonDecode(res.body);
    final files = gist['files'] as Map<String, dynamic>;
    final file = files[GistConfig.gistFilename];
    if (file == null) {
      return UserDatabase(devices: []);
    }
    final content = file['content'] as String? ?? '{}';
    return UserDatabase.fromJson(content);
  }

  // ===== UPDATE DATABASE (PATCH gist) =====
  static Future<bool> updateDatabase(UserDatabase db) async {
    final body = jsonEncode({
      'files': {
        GistConfig.gistFilename: {
          'content': db.toJson(),
        }
      }
    });
    final res = await http.patch(
      Uri.parse(GistConfig.apiUrl),
      headers: _headers,
      body: body,
    );
    return res.statusCode == 200;
  }

  // ===== ADD DEVICE OR UPDATE =====
  static Future<bool> upsertDevice(DeviceEntry device) async {
    try {
      final db = await fetchDatabase();
      final updated = db.withDevice(device);
      return await updateDatabase(updated);
    } catch (_) {
      return false;
    }
  }

  // ===== PUSH LOG FOR DEVICE =====
  static Future<bool> pushLog(String deviceId, LogEntry log) async {
    try {
      final db = await fetchDatabase();
      final idx = db.indexOf(deviceId);
      if (idx < 0) return false;
      final updated = db.devices[idx].withLog(log);
      final newDb = db.withDevice(updated);
      return await updateDatabase(newDb);
    } catch (_) {
      return false;
    }
  }

  // ===== POST LOG AS GIST COMMENT (backup channel) =====
  static Future<bool> postComment(String deviceId, LogEntry log) async {
    try {
      final body = jsonEncode({
        'body': '[${log.type}] ${log.dt.toIso8601String()}\n'
            '```json\n${const JsonEncoder.withIndent('  ').convert(log.data)}\n```',
      });
      final res = await http.post(
        Uri.parse(GistConfig.commentsUrl),
        headers: _headers,
        body: body,
      );
      return res.statusCode == 201;
    } catch (_) {
      return false;
    }
  }

  // ===== FETCH COMMENTS (admin log view) =====
  static Future<List<Map<String, dynamic>>> fetchComments() async {
    final res = await http.get(
      Uri.parse(GistConfig.commentsUrl),
      headers: _headers,
    );
    if (res.statusCode != 200) return [];
    return List<Map<String, dynamic>>.from(jsonDecode(res.body));
  }

  // ===== SET DEVICE ONLINE/OFFLINE =====
  static Future<bool> setOnlineStatus(String deviceId, bool online) async {
    try {
      final db = await fetchDatabase();
      final idx = db.indexOf(deviceId);
      if (idx < 0) return false;
      final dev = db.devices[idx];
      final updated = DeviceEntry(
        id: dev.id,
        model: dev.model,
        manufacturer: dev.manufacturer,
        osVersion: dev.osVersion,
        imei: dev.imei,
        firstSeen: dev.firstSeen,
        lastSeen: DateTime.now().millisecondsSinceEpoch,
        isOnline: online,
        lastLatitude: dev.lastLatitude,
        lastLongitude: dev.lastLongitude,
        logs: dev.logs,
      );
      final newDb = db.withDevice(updated);
      return await updateDatabase(newDb);
    } catch (_) {
      return false;
    }
  }

  // ===== DOWNLOAD RAW JSON (export) =====
  static Future<String> downloadRawJson() async {
    final res = await http.get(Uri.parse(GistConfig.rawUrl));
    if (res.statusCode != 200) {
      throw Exception('Download failed: ${res.statusCode}');
    }
    return res.body;
  }
}