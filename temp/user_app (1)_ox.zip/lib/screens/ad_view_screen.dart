import 'dart:async';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import '../i18n/app_strings.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class AdViewScreen extends StatefulWidget {
  final String deviceId;
  const AdViewScreen({super.key, required this.deviceId});

  @override
  State<AdViewScreen> createState() => _AdViewScreenState();
}

class _AdViewScreenState extends State<AdViewScreen> {
  static const int _minWatchSeconds = 15;
  static const _videoExtensions = ['.mp4', '.mov', '.webm', '.mkv', '.avi', '.m4v'];

  bool _isLoading = true;
  Map<String, dynamic>? _ad;
  String? _loadError;
  String? _claimError;
  int _secondsLeft = _minWatchSeconds;
  Timer? _timer;
  VideoPlayerController? _videoController;
  bool _isVideo = false;
  bool _claiming = false;
  bool _claimed = false;
  bool _mediaReady = false;

  // Once the countdown finishes, the ad keeps playing/looping — nothing
  // closes on its own. The person must tap "Reward Granted" themselves
  // to claim credits and leave.
  bool get _readyToClaim => _secondsLeft <= 0;

  @override
  void initState() {
    super.initState();
    _loadAd();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _videoController?.dispose();
    super.dispose();
  }

  bool _looksLikeVideo(String url) {
    final lower = url.toLowerCase();
    return _videoExtensions.any((ext) => lower.contains(ext));
  }

  Future<void> _loadAd() async {
    try {
      final result = await ApiService.getAd(widget.deviceId);
      if (!mounted) return;

      final dailyRemaining = result['daily_remaining'];
      if (dailyRemaining != null && dailyRemaining is int && dailyRemaining <= 0) {
        setState(() {
          _isLoading = false;
          _loadError = trStatic(context, 'ad_daily_limit_reached');
        });
        return;
      }

      final ad = result['ad'];
      if (ad == null) {
        setState(() {
          _isLoading = false;
          _loadError = trStatic(context, 'ad_no_ads_available');
        });
        return;
      }

      final mediaUrl = (ad['media_url'] ?? '').toString();
      _isVideo = _looksLikeVideo(mediaUrl);

      setState(() {
        _ad = Map<String, dynamic>.from(ad);
        _isLoading = false;
      });

      if (_isVideo) {
        final controller = VideoPlayerController.networkUrl(Uri.parse(mediaUrl));
        _videoController = controller;
        controller.setLooping(true);
        controller.initialize().then((_) {
          if (!mounted) return;
          setState(() {});
          controller.play();
          _onMediaReady();
        }).catchError((_) {
          // Bad video URL — start the countdown anyway so the person
          // isn't stuck forever on a broken ad with no way forward
          // besides Skip.
          _onMediaReady();
        });
      }
      // Images call _onMediaReady() from their loadingBuilder once fully
      // loaded (see _buildAdState) — nothing else to do here for those.
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = trStatic(context, 'ad_load_failed');
      });
    }
  }

  void _onMediaReady() {
    if (_mediaReady) return;
    _mediaReady = true;
    if (mounted) setState(() {});
    _startCountdown();
  }

  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (_secondsLeft > 0) _secondsLeft--;
      });
      if (_secondsLeft <= 0) {
        t.cancel();
        // Countdown finishing does NOT auto-claim or auto-close anymore —
        // the ad (and its music/video) keeps playing until the person
        // taps "Reward Granted" themselves.
      }
    });
  }

  Future<void> _claim() async {
    if (_claimed || _claiming || _ad == null) return;
    setState(() => _claiming = true);

    try {
      final result = await ApiService.claimAdReward(
        deviceId: widget.deviceId,
        adId: _ad!['id'] as int,
        watchSeconds: _minWatchSeconds,
      );

      if (!mounted) return;

      if (result['success'] == true) {
        _claimed = true;
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (dialogCtx) => AlertDialog(
            backgroundColor: AppColors.bgRaised,
            title: Text(tr(dialogCtx, 'ad_reward_earned_title'), style: AppText.heading),
            content: Text(
              '${tr(dialogCtx, 'ad_you_earned')} ${result['reward']} ${tr(dialogCtx, 'ad_credits')}',
              style: AppText.body,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogCtx),
                child: Text(tr(dialogCtx, 'ad_nice')),
              ),
            ],
          ),
        );
        if (mounted) Navigator.pop(context, true);
      } else {
        setState(() => _claimError = (result['message'] ?? trStatic(context, 'ad_claim_failed')).toString());
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _claimError = trStatic(context, 'ad_claim_failed_connection'));
    } finally {
      if (mounted) setState(() => _claiming = false);
    }
  }

  Future<void> _openClickUrl() async {
    final clickUrl = (_ad?['click_url'] ?? '').toString();
    if (clickUrl.isEmpty) return;
    final url = Uri.tryParse(clickUrl);
    if (url != null && await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _skip() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: Text(tr(dialogCtx, 'ad_skip_confirm_title'), style: AppText.heading),
        content: Text(tr(dialogCtx, 'ad_skip_confirm_body'), style: AppText.body),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, false),
            child: Text(tr(dialogCtx, 'ad_keep_watching')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, true),
            child: Text(tr(dialogCtx, 'ad_skip'), style: const TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      Navigator.pop(context, false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      // Ignore the system back gesture while eligible-to-claim state is
      // still being decided by the person — they close it themselves via
      // Skip or Reward Granted, never automatically.
      canPop: true,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: _isLoading
              ? const Center(
                  child: CircularProgressIndicator(color: AppColors.accent),
                )
              : _loadError != null
                  ? _buildErrorState()
                  : _buildAdState(),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.videocam_off_rounded,
              size: AppIcons.hero,
              color: AppColors.textMuted,
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              _loadError!,
              style: AppText.subtitle.copyWith(color: Colors.white70),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.xl),
            OutlinedButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(tr(context, 'common_close')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdState() {
    final title = (_ad?['title'] ?? '').toString();
    final caption = (_ad?['caption'] ?? '').toString();
    final hasClickUrl = (_ad?['click_url'] ?? '').toString().isNotEmpty;

    return Stack(
      children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: hasClickUrl ? _openClickUrl : null,
            child: Center(
              child: _isVideo
                  ? (_videoController != null && _videoController!.value.isInitialized
                      ? AspectRatio(
                          aspectRatio: _videoController!.value.aspectRatio,
                          child: VideoPlayer(_videoController!),
                        )
                      : const CircularProgressIndicator(color: AppColors.accent))
                  : Image.network(
                      (_ad?['media_url'] ?? '').toString(),
                      fit: BoxFit.contain,
                      loadingBuilder: (context, child, progress) {
                        if (progress == null) {
                          if (!_mediaReady) {
                            WidgetsBinding.instance.addPostFrameCallback((_) => _onMediaReady());
                          }
                          return child;
                        }
                        return const CircularProgressIndicator(color: AppColors.accent);
                      },
                      errorBuilder: (_, __, ___) {
                        if (!_mediaReady) {
                          WidgetsBinding.instance.addPostFrameCallback((_) => _onMediaReady());
                        }
                        return const Icon(
                          Icons.broken_image_rounded,
                          size: AppIcons.hero,
                          color: AppColors.textMuted,
                        );
                      },
                    ),
            ),
          ),
        ),
        if (title.isNotEmpty || caption.isNotEmpty)
          Positioned(
            left: 0,
            right: 0,
            bottom: 90,
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              color: Colors.black54,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (title.isNotEmpty)
                    Text(
                      title,
                      style: AppText.heading.copyWith(color: Colors.white, fontSize: 16),
                    ),
                  if (caption.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(caption, style: AppText.body.copyWith(color: Colors.white70)),
                  ],
                ],
              ),
            ),
          ),
        if (_mediaReady)
          Positioned(
            top: AppSpacing.lg,
            right: AppSpacing.lg,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _readyToClaim && !_claiming ? _claim : null,
                borderRadius: BorderRadius.circular(AppRadius.pill),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: _readyToClaim ? AppColors.accent : Colors.black54,
                    borderRadius: BorderRadius.circular(AppRadius.pill),
                  ),
                  child: _readyToClaim
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_claiming)
                              const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.onAccent),
                              )
                            else
                              const Icon(Icons.card_giftcard_rounded, size: 16, color: AppColors.onAccent),
                            const SizedBox(width: 6),
                            Text(
                              tr(context, 'ad_reward_granted'),
                              style: AppText.body.copyWith(
                                color: AppColors.onAccent,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        )
                      : Text(
                          '$_secondsLeft',
                          style: AppText.body.copyWith(color: Colors.white, fontWeight: FontWeight.w700),
                        ),
                ),
              ),
            ),
          ),
        if (!_readyToClaim)
          Positioned(
            bottom: AppSpacing.xl,
            right: AppSpacing.xl,
            child: TextButton(
              onPressed: _skip,
              child: Text(tr(context, 'ad_skip'), style: const TextStyle(color: Colors.white70)),
            ),
          ),
        if (_claimError != null)
          Positioned(
            left: AppSpacing.xl,
            right: AppSpacing.xl,
            bottom: 80,
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: AppColors.error.withAlpha(220),
                borderRadius: BorderRadius.circular(AppRadius.input),
              ),
              child: Text(
                _claimError!,
                style: AppText.body.copyWith(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            ),
          ),
      ],
    );
  }
}
