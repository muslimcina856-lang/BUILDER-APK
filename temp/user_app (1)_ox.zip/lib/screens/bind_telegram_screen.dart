import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../i18n/app_strings.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class BindTelegramScreen extends StatefulWidget {
  final String deviceId;
  final String? currentTelegramId;

  const BindTelegramScreen({
    super.key,
    required this.deviceId,
    this.currentTelegramId,
  });

  @override
  State<BindTelegramScreen> createState() => _BindTelegramScreenState();
}

class _BindTelegramScreenState extends State<BindTelegramScreen> {
  late String? _boundTelegramId = widget.currentTelegramId;

  final _telegramIdController = TextEditingController();
  final _codeController = TextEditingController();

  bool _codeSent = false;
  bool _isSubmitting = false;
  bool _isUnbinding = false;
  String? _error;
  String? _info;
  String? _guidance;

  // The bot's @username is no longer hardcoded in the app — it's fetched
  // from the server (which reads it straight from the bot token) each
  // time a verification code is requested.
  String? _botUsername;

  // The verification code only lives 5 minutes server-side; this mirrors
  // that with a visible countdown so the person knows when it's expired.
  int _secondsLeft = 0;
  Timer? _countdownTimer;

  Future<void> _openBot() async {
    if (_botUsername == null || _botUsername!.isEmpty) return;
    final url = Uri.parse('https://t.me/$_botUsername');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void _startCountdown(int seconds) {
    _countdownTimer?.cancel();
    setState(() => _secondsLeft = seconds);
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (_secondsLeft > 0) _secondsLeft--;
      });
      if (_secondsLeft <= 0) {
        t.cancel();
      }
    });
  }

  @override
  void dispose() {
    _telegramIdController.dispose();
    _codeController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  Future<void> _confirmUnbind() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: Text(tr(context, 'bind_unbind_confirm_title'), style: AppText.heading),
        content: Text(
          tr(context, 'bind_unbind_confirm_body'),
          style: AppText.body,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr(context, 'common_cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr(context, 'bind_unbind'), style: const TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() {
      _isUnbinding = true;
      _error = null;
      _info = null;
    });

    try {
      final result = await ApiService.unbindTelegram(widget.deviceId);
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _boundTelegramId = null;
          _info = trStatic(context, 'bind_unbind_success');
        });
      } else {
        setState(() => _error = (result['message'] ?? trStatic(context, 'bind_unbind_failed')).toString());
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = trStatic(context, 'common_server_error'));
    } finally {
      if (mounted) setState(() => _isUnbinding = false);
    }
  }

  Future<void> _requestCode() async {
    final telegramId = _telegramIdController.text.trim();
    if (telegramId.isEmpty || !RegExp(r'^\d{5,}$').hasMatch(telegramId)) {
      setState(() => _error = trStatic(context, 'bind_telegram_id_invalid'));
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
      _info = null;
      _guidance = null;
    });

    try {
      final result = await ApiService.requestBindTelegram(widget.deviceId, telegramId);
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _codeSent = true;
          _info = (result['message'] ?? trStatic(context, 'bind_code_sent')).toString();
          _guidance = result['guidance']?.toString();
          _botUsername = result['bot_username']?.toString();
        });
        final expiresIn = result['expires_in_seconds'];
        if (expiresIn is int) {
          _startCountdown(expiresIn);
        } else if (expiresIn is num) {
          _startCountdown(expiresIn.toInt());
        }
      } else {
        setState(() => _error = (result['message'] ?? trStatic(context, 'bind_code_send_failed')).toString());
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = trStatic(context, 'common_server_error'));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _confirmCode() async {
    final code = _codeController.text.trim();
    if (code.isEmpty) {
      setState(() => _error = trStatic(context, 'bind_enter_code_received'));
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
      _info = null;
    });

    try {
      final result = await ApiService.confirmBindTelegram(widget.deviceId, code);
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() => _boundTelegramId = _telegramIdController.text.trim());
        if (mounted) Navigator.pop(context);
      } else {
        setState(() => _error = (result['message'] ?? trStatic(context, 'bind_code_wrong')).toString());
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = trStatic(context, 'common_server_error'));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'bind_title'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.xxl),
          children: [
            if (_boundTelegramId != null) ...[
              _buildBoundCard(context),
            ] else ...[
              if (!_codeSent) _buildRequestForm(context) else _buildConfirmForm(context),
            ],
            if (_info != null) ...[
              const SizedBox(height: AppSpacing.lg),
              _ResultBanner(isSuccess: true, message: _info!),
            ],
            if (_guidance != null) ...[
              const SizedBox(height: AppSpacing.lg),
              _GuidanceCard(
                message: _guidance!,
                onOpenBot: _botUsername == null || _botUsername!.isEmpty
                    ? null
                    : _openBot,
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: AppSpacing.lg),
              _ResultBanner(isSuccess: false, message: _error!),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBoundCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xxl),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.check_circle_rounded, color: AppColors.success, size: AppIcons.hero),
          const SizedBox(height: AppSpacing.lg),
          Text(tr(context, 'bind_already_linked_title'), style: AppText.heading),
          const SizedBox(height: AppSpacing.sm),
          Text('${tr(context, 'bind_linked_with')} $_boundTelegramId', style: AppText.body),
          const SizedBox(height: AppSpacing.xl),
          Text(
            tr(context, 'bind_to_link_another'),
            style: AppText.subtitle,
          ),
          const SizedBox(height: AppSpacing.lg),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _isUnbinding ? null : _confirmUnbind,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.error,
                side: const BorderSide(color: AppColors.error),
              ),
              child: _isUnbinding
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(tr(context, 'bind_unbind')),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequestForm(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr(context, 'bind_enter_telegram_id'), style: AppText.heading),
        const SizedBox(height: AppSpacing.sm),
        Text(
          tr(context, 'bind_code_will_be_sent'),
          style: AppText.subtitle,
        ),
        const SizedBox(height: AppSpacing.xl),
        TextField(
          controller: _telegramIdController,
          keyboardType: TextInputType.number,
          autocorrect: false,
          style: AppText.body,
          decoration: InputDecoration(
            labelText: tr(context, 'bind_telegram_id_label'),
            hintText: 'e.g. 123456789',
            prefixIcon: const Icon(
              Icons.tag_rounded,
              size: AppIcons.md,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _isSubmitting ? null : _requestCode,
            child: _isSubmitting
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(tr(context, 'bind_send_code')),
          ),
        ),
      ],
    );
  }

  Widget _buildConfirmForm(BuildContext context) {
    final expired = _secondsLeft <= 0;
    final minutes = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    final seconds = (_secondsLeft % 60).toString().padLeft(2, '0');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr(context, 'bind_enter_code_title'), style: AppText.heading),
        const SizedBox(height: AppSpacing.sm),
        Text(
          tr(context, 'bind_check_telegram_message'),
          style: AppText.subtitle,
        ),
        const SizedBox(height: AppSpacing.md),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.sm),
          decoration: BoxDecoration(
            color: (expired ? AppColors.error : AppColors.accent).withAlpha(20),
            borderRadius: BorderRadius.circular(AppRadius.input),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                expired ? Icons.timer_off_rounded : Icons.timer_rounded,
                size: AppIcons.sm,
                color: expired ? AppColors.error : AppColors.accent,
              ),
              const SizedBox(width: AppSpacing.sm),
              Text(
                expired ? tr(context, 'bind_code_expired') : '$minutes:$seconds',
                style: AppText.body.copyWith(
                  fontWeight: FontWeight.w700,
                  color: expired ? AppColors.error : AppColors.accent,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
        TextField(
          controller: _codeController,
          keyboardType: TextInputType.number,
          enabled: !expired,
          decoration: InputDecoration(
            labelText: tr(context, 'bind_verification_code_label'),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: (_isSubmitting || expired) ? null : _confirmCode,
            child: _isSubmitting
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(tr(context, 'bind_confirm_and_link')),
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        TextButton(
          onPressed: _isSubmitting
              ? null
              : () => setState(() {
                    _countdownTimer?.cancel();
                    _secondsLeft = 0;
                    _codeSent = false;
                    _error = null;
                    _info = null;
                    _guidance = null;
                  }),
          child: Text(tr(context, expired ? 'bind_request_new_code' : 'bind_use_different_id')),
        ),
      ],
    );
  }
}

class _ResultBanner extends StatelessWidget {
  final bool isSuccess;
  final String message;

  const _ResultBanner({required this.isSuccess, required this.message});

  @override
  Widget build(BuildContext context) {
    final color = isSuccess ? AppColors.success : AppColors.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
            size: AppIcons.md,
            color: color,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(
              message,
              style: AppText.body.copyWith(color: color),
            ),
          ),
        ],
      ),
    );
  }
}

class _GuidanceCard extends StatelessWidget {
  final String message;
  final VoidCallback? onOpenBot;
  const _GuidanceCard({required this.message, required this.onOpenBot});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.warning.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: AppColors.warning.withAlpha(60)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.info_rounded,
                size: AppIcons.md,
                color: AppColors.warning,
              ),
              const SizedBox(width: AppSpacing.md),
              Text(
                tr(context, 'bind_important'),
                style: AppText.heading.copyWith(
                  color: AppColors.warning,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Text(message, style: AppText.subtitle),
          if (onOpenBot != null) ...[
            const SizedBox(height: AppSpacing.md),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: onOpenBot,
                icon: const Icon(Icons.open_in_new_rounded, size: AppIcons.sm),
                label: Text(tr(context, 'bind_open_telegram_bot')),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.warning,
                  side: BorderSide(color: AppColors.warning.withAlpha(80)),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
