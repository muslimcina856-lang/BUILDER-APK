# User App — Map

The public-facing app: pick a project ZIP, it gets built into an APK.
Also has a small credits/ads system. This is the one meant for Play
Store distribution, so this doc leans toward what a reviewer (or you,
setting up the listing) would want to know.

## What it does

Talks to the Next.js API deployed on Vercel to register the device,
submit a validated project ZIP or project link, track credits, link a
Telegram account for build notifications, redeem codes, and watch ads
for extra credits. Data is stored in Turso; no Python server or
Cloudflare Tunnel is used.

## Screens

| Screen | File | Does |
|---|---|---|
| Home | `home_screen.dart` | Stats, upload entry point, Free Credits / ad-watching, maintenance overlay |
| Upload | `upload_screen.dart` | Validate a project; upload ZIP files up to 3 MB directly or request a project link for larger files |
| Link Telegram | `bind_telegram_screen.dart` | Two-step bind (code sent via Telegram, 5-min countdown to enter it), unbind |
| Redeem Code | `claim_code_screen.dart` | Enter an owner-issued credit code |
| Watch Ad | `ad_view_screen.dart` | Image/video ad, 15s minimum watch, tap to claim |
| About / Settings | `about_screen.dart` | App info + **Language** (English/Malay/Indonesian) |
| Language picker | `language_select_screen.dart` | Shown once, on first launch |

## Permissions requested — and why

| Permission | Why | Play Store sensitivity |
|---|---|---|
| `INTERNET` | Every screen talks to the backend | none |
| `ACCESS_NETWORK_STATE` | Detect connectivity before showing network errors | none |
| `POST_NOTIFICATIONS` | Local notifications related to background audio during maintenance | low |
| `WAKE_LOCK` | Keep that background audio running | low |

Project ZIP selection uses Android's Storage Access Framework through
`file_picker`, so no broad storage or all-files permission is requested.

## Data collected (for Play Console's Data Safety form)

| Data | Collected? | Shared with | Purpose |
|---|---|---|---|
| Device identifier (`device_id`, generated locally via `android_id`) | Yes | Your own backend only | Identify the installation for credits/history — no account/sign-up |
| Telegram ID | Only if the user chooses to link Telegram | Your own backend + Telegram (to send messages) | Build-completion notifications |
| Files (the project ZIP being built) | Yes, temporarily | Your Vercel backend → GitHub (for the build) | The core function of the app |
| Project link | Only for projects over 3 MB | Your Vercel backend → GitHub build worker | Allow the worker to retrieve a larger project |
| Credits / usage counts | Yes | Your own backend only | App functionality (not real currency) |

No location, contacts, camera, microphone, or advertising ID is
collected or requested anywhere in this app.

## Third-party network destinations

- Your own Vercel API deployment
- `api.telegram.org` (only for users who link Telegram)
- External ad media URLs configured by the owner — only loaded inside
  `ad_view_screen.dart` when watching an ad
- The project URL supplied by the user, downloaded temporarily only to
  validate the project before submission

## R8 / release build

`minifyEnabled true` + `shrinkResources true` are enabled for release builds.
Keep rules are limited to Flutter plugin entry points and native libraries
that need reflection; whole Flutter/OkHttp packages are no longer excluded
from R8. Dart code is obfuscated separately with `--obfuscate` and
`--split-debug-info` during the release build.

## Dependencies (`pubspec.yaml`)

`dio` (HTTP and temporary project-link download), `file_picker` (ZIP selection),
`archive` (streamed ZIP inspection), `shared_preferences`, `provider` (language state),
`path_provider`, `url_launcher`, `android_id` (device identifier),
`just_audio` (maintenance-screen music), `video_player` (ads), plus the
ZIP-reading dependency used by the in-app project validator.

## Updating this app

1. `lib/config.dart` → `baseUrl` should point at the Vercel deployment,
   without a trailing `/`.
2. Translations live in `lib/i18n/app_strings.dart` — add a key there
   (all 3 languages) before using `tr(context, 'your_key')` anywhere new.
3. Build release with `--obfuscate --split-debug-info=build/symbols` and retain
   the generated symbol files securely.
4. Signing files are private and are not included in the project ZIP; use
   `android/key.properties.example` as the setup template.
