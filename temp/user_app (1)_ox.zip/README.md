# Earl Builder — User App

Aplikasi Flutter untuk menghantar projek Android kepada backend Vercel dan
menerima hasil build melalui Telegram.

## Backend

Aplikasi menggunakan backend **Next.js/Vercel + Turso**. Python server,
SQLite tempatan dan Cloudflare Tunnel tidak digunakan.

Tetapkan URL deployment dalam `lib/config.dart`:

```dart
static const String baseUrl = 'https://domain-vercel-anda.vercel.app';
```

Gunakan URL tanpa `/` di hujung. Username bot Telegram tidak dihardcode;
aplikasi mendapatkannya daripada respons backend semasa proses bind.

## Penghantaran projek

Aplikasi menyokong Flutter, Native Android, Smali/APKTool, React Native,
Cordova, Ionic dan Capacitor.

### Fail sehingga 3 MB

- Aplikasi mengesahkan kandungan ZIP dan jenis projek.
- ZIP dihantar terus kepada Vercel dalam satu request.
- Tiada chunked upload.

### Fail melebihi 3 MB

- Aplikasi memaparkan notifikasi had 3 MB.
- Pengguna diminta memasukkan **pautan projek**.
- Aplikasi memuat turun projek ke cache sementara untuk pengesahan.
- Fail sementara dipadam selepas semakan, termasuk apabila download gagal
  atau dibatalkan.
- Selepas projek disahkan, hanya pautan asal dihantar kepada Vercel.

Nama penyedia fail dan kaedah download tidak dipaparkan dalam UI.

## Kredit

Kredit dipotong selepas projek dan akaun pengguna disahkan, sebelum penghantaran
ke repo build dimulakan. Tiada refund automatik selepas percubaan penghantaran
bermula.

## Telegram

Pengguna perlu mengikat Telegram sebelum menghantar projek. Backend menghantar
username bot dan tempoh sah kod kepada aplikasi. Kod pengesahan sah selama
lima minit dan aplikasi memaparkan countdown.

## Konfigurasi tetap

Nilai berikut berada dalam `lib/config.dart`:

| Pembolehubah | Tujuan |
|---|---|
| `baseUrl` | URL deployment Vercel |
| `ownerLink` | Pautan owner |
| `channelLink` | Pautan channel |

Credential Turso, GitHub dan Telegram hanya disimpan sebagai environment
variables backend. Ia tidak boleh dimasukkan dalam aplikasi.

## Setup dan build

```bash
flutter pub get
flutter build apk --debug
```

Untuk release:

```bash
flutter build apk --release \
  --obfuscate \
  --split-debug-info=build/symbols
```

Fail signing sebenar tidak disertakan dalam ZIP. Salin
`android/key.properties.example` kepada `android/key.properties`, isi nilai
sendiri dan letakkan keystore pada laluan yang dinyatakan. Tanpa fail tersebut,
build release tempatan menggunakan debug signing dan tidak sesuai diterbitkan.

Output debug berada di `build/app/outputs/flutter-apk/app-debug.apk`.

## Struktur utama

```text
lib/
├── config.dart
├── main.dart
├── i18n/
│   └── app_strings.dart
├── models/
│   └── upload_history.dart
├── screens/
│   ├── home_screen.dart
│   ├── upload_screen.dart
│   ├── bind_telegram_screen.dart
│   ├── claim_code_screen.dart
│   ├── ad_view_screen.dart
│   └── about_screen.dart
└── services/
    ├── api_service.dart
    ├── project_validator.dart
    └── storage_service.dart
```

Semua teks UI baharu mesti mempunyai terjemahan Inggeris, Melayu dan
Indonesia dalam `lib/i18n/app_strings.dart`.
