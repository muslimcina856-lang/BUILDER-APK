# Seni Bina Ai MultiAgent 2.1

```text
Flutter UI
├── Chat premium + media/HTML preview
├── Provider & model
├── Automasi
├── Skills
└── Tetapan / memori / log
        │
        ▼
AppState + Session Lifecycle
├── SQLite local
├── Secure API Key Vault
├── Attachment workspace
├── Permission rules
└── Observable run events
        │
        ├── ProviderService
        │   ├── OpenAI Chat / Responses
        │   ├── Anthropic Messages
        │   ├── Gemini
        │   └── Custom REST
        │
        └── AgentRuntime
            ├── Root model orchestrator
            ├── Dynamic sub-agents
            ├── ToolEngine
            │   ├── DuckDuckGo
            │   ├── Hidden browser
            │   ├── Files / memory
            │   ├── Terminal
            │   ├── Skills / Skill Creator
            │   └── MCP local
            └── PermissionManager
                    │
                    ▼
Android native Kotlin
└── Hidden Android System WebView/Chromium
    ├── DOM/text/HTML snapshot
    ├── Links/forms extraction
    ├── Click/fill/submit
    └── Local cookies
```

## Prinsip reka bentuk

1. **Tiada backend aplikasi.** Semua provider call dibuat terus melalui `ProviderService`.
2. **Provider dikawal pengguna.** Model tidak menukar provider atau model sendiri.
3. **Satu root orchestrator.** Tiada General Agent yang perlu dipilih; model aktif boleh mencipta sub-agent mengikut tugasan.
4. **Operasi boleh diperhatikan.** UI memaparkan status tool, browser dan sub-agent tanpa mendedahkan chain-of-thought dalaman model.
5. **Browser tidak mengganggu UI.** WebView native berada di belakang skrin dan hanya mengembalikan hasil terstruktur/HTML kepada runtime.
6. **Local-first.** Chat, provider, skills, automasi, fail dan log disimpan pada peranti.
7. **Kelulusan berasaskan risiko.** Tindakan biasa terus berjalan; tindakan destruktif meminta kelulusan.

## Background automation

WorkManager memulakan runtime local dengan provider/model yang telah dipilih. Tugasan biasa berjalan sebagai background work; tugas panjang boleh dinaikkan kepada notifikasi ongoing. Tool yang memerlukan Android WebView perlu dijalankan ketika proses aplikasi mempunyai enjin Flutter/native yang tersedia; laluan HTTP digunakan sebagai fallback bagi pembacaan halaman dalam worker.
