# Manifest Sumber Ai MultiAgent 2.1.0+7

## Identiti

| Perkara | Nilai |
|---|---|
| Nama | Ai MultiAgent |
| Package ID | `com.aiauto.claw` |
| Versi | `2.1.0+7` |
| Platform | Android / Google Play |
| Framework | Flutter + Kotlin Android |
| Mod | Local/BYOK tanpa login/backend |
| Compile/Target SDK | 36 |
| Minimum SDK | 24 |

## Kandungan

| Komponen | Pelaksanaan |
|---|---|
| Provider | 52 preset + Custom Provider |
| Protokol | OpenAI Chat/Responses, Anthropic, Gemini, Custom REST |
| Root AI | Model pilihan pengguna sebagai orchestrator |
| Sub-agent | Dinamik, dicipta mengikut tugasan |
| Tools | 29 definisi web, browser, fail, memory, terminal, skills, MCP dan utiliti |
| Search | DuckDuckGo HTML + Lite fallback |
| Browser | Android System WebView/Chromium tersembunyi |
| Chat | Markdown, proses live/collapsed, media, HTML dan fail |
| Skills | Skill Creator default, ZIP/URL dan script sandbox |
| Automasi | WorkManager + notifikasi ongoing |
| Kelulusan | Risiko sahaja; sekali, sesi dan persistent |
| Android | API 36, Java 17, R8; tiada Accessibility |

## Fail penting

- `mobile/lib/src/ui/screens/chat_screen.dart` — UI premium, Markdown, proses dan media.
- `mobile/lib/src/ui/screens/providers_screen.dart` — provider ringkas/custom.
- `mobile/lib/src/state/app_state.dart` — chat, lampiran, sesi dan observable events.
- `mobile/lib/src/services/provider_service.dart` — adapter serta ujian provider.
- `mobile/lib/src/services/agent_runtime.dart` — orchestrator dan sub-agent dinamik.
- `mobile/lib/src/services/tool_engine.dart` — registry/pelaksanaan tools.
- `mobile/lib/src/services/browser_session_service.dart` — bridge browser dan fallback HTTP.
- `mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt` — WebView tersembunyi.
- `mobile/lib/src/services/attachment_service.dart` — import/workspace lampiran.
- `mobile/lib/src/services/permission_manager.dart` — sekali/sesi/sentiasa.
- `mobile/lib/src/services/skill_service.dart` — Skill Creator, install dan sandbox.
- `mobile/lib/src/services/terminal_service.dart` — job shell latar belakang.
- `.github/workflows/android-release-check.yml` — analyze, test dan release APK.
- `scripts/verify_source.py` — semakan statik projek.

## Semakan sumber

```bash
./scripts/check_project.sh
```

Dalam persekitaran Flutter lengkap, skrip turut menjalankan pemeriksaan Flutter. Build release dijalankan melalui `./scripts/build_release.sh` selepas upload keystore disediakan.
