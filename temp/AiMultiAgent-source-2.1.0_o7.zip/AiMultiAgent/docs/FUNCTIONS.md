# Spesifikasi Fungsi Ai MultiAgent 2.1

## Identiti dan operasi

| Bahagian | Pelaksanaan |
|---|---|
| Nama | Ai MultiAgent |
| Package | `com.aiauto.claw` |
| Login/backend | Tiada |
| Data | Local pada peranti |
| API key | Secure storage / Android Keystore |
| Root AI | Provider dan model pilihan pengguna |
| Agent tetap pada UI | Tiada |
| Accessibility Service | Tidak digunakan |
| Compile/Target SDK | API 36 |

## Chat premium

- Header ringkas menunjukkan provider dan model aktif.
- Tiada dropdown provider/agent besar di bawah perbualan.
- Markdown sebenar untuk tajuk, bold, list, link, quote dan code block.
- Composer responsif dengan lampiran, suara, hantar dan berhenti.
- Proses operasi dipaparkan selepas mesej terakhir semasa tugas berjalan.
- Selepas selesai, proses dilipat sebagai ringkasan yang boleh dibuka semula.
- Paparan proses hanya menunjukkan status operasi, tool dan sub-agent; bukan chain-of-thought dalaman.

## Lampiran dan kandungan chat

| Jenis | Sokongan |
|---|---|
| Imej | Pilih, hantar jika provider menyokong, paparan local/remote |
| Video | Kad dan pemain video |
| Audio | Kad dan pemain audio |
| HTML | Preview interaktif terkawal dalam chat |
| PDF/dokumen | Kad fail, metadata dan buka melalui aplikasi Android |
| Kod/teks | Baca/rujuk melalui tool fail |
| ZIP/arkib | Kad fail; pemprosesan melalui tools/skills |
| Fail umum | Disalin ke workspace private dan dipaparkan sebagai kad |

Had saiz ditetapkan oleh `AppConfig`; provider mungkin mempunyai had yang lebih kecil.

## Provider dan model

### Provider biasa

UI hanya meminta API key jika perlu, Model ID/pilihan model, kemudian **Uji & simpan**. Base URL, auth dan endpoint menggunakan preset.

### Provider local

Ollama, LM Studio dan preset local seumpamanya memaparkan model dan ujian sambungan. API key hanya muncul jika konfigurasi itu memerlukannya.

### Custom Provider

Custom Provider menyediakan Base URL, protokol, chat/models endpoint, autentikasi, header, request template, response JSON path, parameter model dan capability flags.

Semasa simpan, aplikasi menguji sambungan, menyimpan latency/status dan mengambil senarai model apabila endpoint tersedia. Model manual sentiasa dibenarkan.

## Orchestrator dan sub-agent

- Model aktif ialah orchestrator utama.
- Model menentukan bila tools, skills atau sub-agent diperlukan.
- Sub-agent dicipta menggunakan peranan, tugasan dan output yang dijangka; tiada senarai agent tetap pada UI.
- Sub-agent menggunakan provider dan model yang sama seperti pilihan pengguna.
- Aplikasi tidak menetapkan had bilangan/kedalaman tetap; pengguna masih boleh menghentikan larian.

## Browser tersembunyi

Browser native menggunakan Android System WebView/Chromium dan tidak membuka skrin browser kepada pengguna.

| Keupayaan | Hasil |
|---|---|
| Buka URL | Muat halaman dalam WebView tersembunyi |
| Baca | Teks, tajuk, URL, pautan dan borang |
| HTML | Snapshot `outerHTML` sehingga had local |
| Klik | CSS selector atau teks elemen |
| Isi | Input/textarea dengan event `input` dan `change` |
| Submit | `requestSubmit()` atau submit form |
| Cookies | Disimpan local oleh profil WebView aplikasi |
| Download | Fail dimuat turun ke workspace aplikasi |
| Chat preview | Kad halaman, hasil search dan HTML boleh dipaparkan dalam chat |

DuckDuckGo menggunakan endpoint HTML dengan Lite fallback dan menghasilkan ranking, tajuk, URL sebenar, domain, petikan, endpoint serta latency.

## Skills

- `Skill Creator` tersedia secara default.
- Tiada trigger manual wajib pada UI.
- Model memilih skill berdasarkan nama, tujuan, arahan dan tools yang tersedia.
- Skill boleh dipasang daripada ZIP/URL atau dicipta local.
- Skrip skill dijalankan dalam salinan workspace sandbox aplikasi.
- Pemasangan arkib memeriksa path traversal dan had saiz.

## Terminal

- Terminal berjalan sebagai job latar belakang dari workspace private aplikasi.
- Model boleh memulakan, poll dan menghentikan job.
- Hasil mengandungi status, `stdout`, `stderr` dan exit code.
- Sandbox ialah sekatan workspace/proses aplikasi, bukan mesin maya keselamatan penuh.

## Kelulusan

### Berjalan terus

Search, baca web, buka URL, klik, isi/hantar borang, muat turun, baca fail, cipta fail baharu, tambah memori, skill biasa dan arahan terminal yang tidak dikesan destruktif.

### Meminta kelulusan

Pemadaman fail/memori, overwrite fail, arahan terminal destruktif, HTTP `DELETE` dan MCP/tool remote yang dikesan destruktif.

| Pilihan | Kesan |
|---|---|
| Sekali | Tindakan semasa sahaja |
| Sesi ini | Semua tindakan berisiko hingga sesi tamat |
| Sentiasa | Simpan rule local bagi tool/skop |
| Tolak | Batalkan tindakan |

Kelulusan kekal boleh diurus dalam Tetapan. Sesi tamat selepas 30 minit tidak aktif atau apabila proses aplikasi tamat tanpa tugasan background yang dibenarkan.

## Automasi

- WorkManager untuk tugasan background.
- Notifikasi ongoing untuk tugas panjang apabila diperlukan.
- Automasi menggunakan root orchestrator dan provider/model pilihan pengguna.
- Tiada pemilih agent tetap dalam editor automasi.

## MCP

MCP disediakan untuk server local/localhost. Tool yang dikesan destruktif menggunakan polisi kelulusan yang sama.
