# Keselamatan Ai MultiAgent 2.1

## Model ancaman ringkas

Ai MultiAgent ialah klien BYOK. Provider, Base URL, laman web, skill dan MCP yang dipilih pengguna berada di luar kawalan aplikasi. Pengguna perlu menganggap kandungan web, arahan dalam dokumen dan skill pihak ketiga sebagai tidak dipercayai.

## API key dan data local

- API key disimpan melalui secure storage yang menggunakan Android Keystore.
- SQLite menyimpan konfigurasi bukan rahsia, chat, memory, skills, automasi dan log.
- `android:allowBackup="false"` digunakan.
- Log tool menapis corak authorization, API key, token, secret dan password.
- API key tetap dihantar kepada Base URL mengikut kaedah auth provider; gunakan endpoint dipercayai.

## Kelulusan berasaskan risiko

Tool biasa tidak memaparkan dialog. Pemeriksaan risiko meminta kelulusan bagi pemadaman, overwrite, arahan terminal destruktif, HTTP `DELETE` dan operasi MCP yang dikesan destruktif.

Pengesanan ialah pertahanan praktikal, bukan bukti mutlak bahawa sesuatu arahan selamat. Rule **Sentiasa benarkan** perlu diberikan hanya kepada tool/skop yang dipercayai dan boleh ditarik balik dalam Tetapan.

## Browser tersembunyi

- WebView menjalankan JavaScript dan menyimpan cookies local.
- `allowFileAccess` dan `allowContentAccess` dimatikan pada enjin native.
- HTML/teks dipotong kepada had local sebelum dihantar kepada model.
- Kandungan halaman tidak patut dianggap arahan sistem.
- Borang boleh dihantar terus mengikut spesifikasi produk; akaun dan laman sensitif perlu digunakan dengan berhati-hati.
- Cleartext HTTP dibenarkan untuk provider local/LAN. Provider awam sepatutnya menggunakan HTTPS.

## Lampiran dan media

- Fail dipindahkan ke workspace private aplikasi sebelum diproses.
- Provider menerima kandungan/metadata lampiran hanya apabila runtime menghantarnya.
- Fail tidak dipercayai tidak dijalankan secara automatik.
- Membuka fail menggunakan aplikasi pihak ketiga tertakluk kepada keselamatan aplikasi tersebut.

## Terminal dan skill sandbox

- Terminal bermula dalam workspace private aplikasi.
- Skrip skill dijalankan daripada salinan workspace sandbox.
- Ini bukan VM, container atau sandbox kernel; arahan masih berjalan dengan permission proses aplikasi.
- Pemeriksaan arahan destruktif dan kelulusan tidak menggantikan semakan sumber skill.
- Arkib skill memeriksa path traversal serta had saiz sebelum ekstrak.

## MCP

MCP dihadkan kepada localhost, loopback atau `.local`. Server MCP masih boleh melakukan tindakan mengikut implementasinya; hanya tambah server yang dipercayai.

## Prompt

Aplikasi menambah arahan operasi untuk tools, skills, format dan koordinasi sub-agent. Ia tidak menambah prompt penapisan topik. Polisi dan guardrail provider/model tetap terpakai.

## Release hardening

- R8 dan resource shrinking aktif pada release.
- Keystore production tidak disertakan dalam sumber.
- Tanpa `key.properties`, APK release menggunakan debug signing untuk ujian sahaja dan AAB tidak dibina oleh skrip.
- Uji redaction, WebView, skill ZIP, terminal, provider error dan persistent permission sebelum penerbitan.
