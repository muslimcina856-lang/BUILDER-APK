# Checklist Google Play — Ai MultiAgent 2.1

## Toolchain dan build

- [ ] Java 17 tersedia.
- [ ] Flutter stable yang serasi dipasang.
- [ ] Android SDK Platform 36 dan Build Tools tersedia.
- [ ] `./scripts/check_project.sh` lulus.
- [ ] `dart format --output=none --set-exit-if-changed lib test` lulus.
- [ ] `flutter analyze` tanpa error.
- [ ] `flutter test` lulus.
- [ ] Upload keystore dibuat mengikut `docs/KEYSTORE.md`.
- [ ] `mobile/android/key.properties` tidak dimasukkan ke repository/ZIP awam.
- [ ] `./scripts/build_release.sh` menghasilkan AAB production.
- [ ] APK release diuji pada peranti sebenar sebelum upload.

## Ujian UI premium

- [ ] Tiada overflow pada telefon kecil, font besar dan keyboard terbuka.
- [ ] Markdown tajuk, bold, list, link dan code block dirender kemas.
- [ ] Process timeline berada di bawah chat dan dilipat selepas selesai.
- [ ] Provider/model picker tidak menutup composer.
- [ ] Buffer, stop dan error state berfungsi.
- [ ] Tema gelap/kontras serta TalkBack label diperiksa.

## Provider dan orchestrator

- [ ] Provider biasa hanya meminta API key + model.
- [ ] Provider local berfungsi tanpa API key apabila sesuai.
- [ ] Custom Provider memaparkan semua tetapan lanjutan.
- [ ] Uji OpenAI-compatible, Anthropic, Gemini dan Custom REST.
- [ ] Uji Xiaomi MiMo dengan model yang tersedia pada akaun.
- [ ] Uji senarai model, model manual, latency dan error auth.
- [ ] Uji delegasi sub-agent serta stop larian.

## Browser, search dan media

- [ ] DuckDuckGo HTML dan Lite fallback diuji pada rangkaian sebenar.
- [ ] WebView tersembunyi boleh open/read/click/fill/submit.
- [ ] Cookies, redirect, JavaScript SPA dan error TLS diuji.
- [ ] HTML preview tidak membekukan UI.
- [ ] Imej, video, audio, PDF, dokumen, ZIP dan fail umum diuji.
- [ ] Fail melebihi had ditolak dengan mesej jelas.
- [ ] Download dan buka fail diuji pada Android 7 hingga Android 16.

## Kelulusan dan tools

- [ ] Tool biasa berjalan tanpa dialog.
- [ ] Delete, overwrite dan arahan terminal destruktif meminta kelulusan.
- [ ] Sekali, Sesi ini, Sentiasa dan Tolak berfungsi.
- [ ] Rule kekal boleh ditarik balik.
- [ ] Sesi tamat selepas 30 minit tidak aktif.
- [ ] Terminal start/poll/stop dan redaction diuji.
- [ ] Skill Creator, ZIP/URL dan script sandbox diuji.
- [ ] MCP localhost/.local diuji.

## Background dan release

- [ ] WorkManager diuji dengan Doze dan battery saver.
- [ ] Notifikasi ongoing/tamat diuji.
- [ ] App process kill dan resume diuji.
- [ ] R8 release diuji, bukan debug sahaja.
- [ ] Crash-free smoke test dilakukan pada Pixel, Samsung dan sekurang-kurangnya satu vendor lain.

## Google Play

- [ ] Polisi Privasi dihoskan pada HTTPS awam.
- [ ] Maklumat sokongan penerbit dilengkapkan.
- [ ] Data Safety menerangkan provider pihak ketiga, WebView/cookies, mikrofon, fail dan local storage.
- [ ] Tiada Accessibility Service.
- [ ] Permission mikrofon, notifikasi dan foreground service diterangkan.
- [ ] Screenshot sebenar build release digunakan.
- [ ] Content rating, kategori dan Play App Signing diselesaikan.
