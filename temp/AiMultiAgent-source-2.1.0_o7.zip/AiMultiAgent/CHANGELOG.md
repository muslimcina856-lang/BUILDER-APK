# Changelog

## 2.1.0+7 — Premium local orchestrator

- Menggantikan UI chat padat dengan susun atur premium dan responsif.
- Membuang pemilih General Agent serta tab Agent daripada pengalaman pengguna.
- Menjadikan provider/model pilihan pengguna sebagai orchestrator utama.
- Menambah delegasi sub-agent dinamik yang dicipta mengikut tugasan.
- Memindahkan status operasi ke bawah chat dan melipatnya selepas jawapan akhir.
- Menambah renderer Markdown sebenar supaya tajuk, bold, senarai dan code block tidak dipaparkan sebagai sintaks mentah.
- Menambah lampiran serta paparan imej, video, audio, HTML, dokumen dan fail umum dalam chat.
- Menggantikan browser UI lama dengan Android System WebView/Chromium tersembunyi yang boleh membaca DOM/HTML, klik, isi dan hantar borang.
- Memudahkan provider biasa kepada API key dan model; tetapan lanjutan hanya untuk Custom Provider.
- Menambah Skill Creator sebagai skill lalai dan membuang keperluan trigger manual pada UI.
- Mengekalkan terminal latar belakang dengan output yang boleh dibaca model.
- Mengemas kini automasi supaya menggunakan orchestrator utama, bukan profil agent tetap.
- Mengemas kini Gradle 8.14.3, AGP 8.11.1 dan Kotlin 2.2.20.
- Mengukuhkan R8, skrip release, semakan sumber dan workflow CI release APK.

## 2.0.1 — Android resource fix

- Membetulkan `launch_background.xml` supaya `android:drawable` menggunakan resource warna dan bukan warna literal.

## 2.0.0+4 — Local/BYOK

- Menukar aplikasi kepada local/BYOK sepenuhnya tanpa login dan backend.
- Menambah katalog provider, Xiaomi MiMo, model dinamik dan Custom Provider.
- Menambah DuckDuckGo, browser, terminal, skills, MCP local, automasi dan polisi kelulusan risiko.
- Mengunci `compileSdk` dan `targetSdk` kepada API 36.
