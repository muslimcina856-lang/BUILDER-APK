import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:just_audio/just_audio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _composer = TextEditingController();
  final _scroll = ScrollController();
  final _speech = SpeechToText();

  bool _listening = false;
  int _lastMessageCount = 0;
  int _lastEventCount = 0;

  @override
  void dispose() {
    _composer.dispose();
    _scroll.dispose();
    _speech.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.messages.length != _lastMessageCount ||
        state.activeRunEvents.length != _lastEventCount) {
      _lastMessageCount = state.messages.length;
      _lastEventCount = state.activeRunEvents.length;
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }

    return SafeArea(
      child: Column(
        children: <Widget>[
          _ChatHeader(
            provider: state.selectedProvider,
            onTapModel: () => _showProviderModelPicker(context),
            onNewSession: () => state.newSession(reason: 'Sesi baharu dimulakan.'),
          ),
          Expanded(
            child: Stack(
              children: <Widget>[
                CustomScrollView(
                  controller: _scroll,
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  slivers: <Widget>[
                    if (state.messages.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _EmptyChat(
                          hasProvider: state.hasProvider,
                          sessionNotice: state.sessionNotice,
                          onOpenProvider: () => state.selectTab(1),
                          onSuggestion: (value) {
                            _composer.text = value;
                            _composer.selection = TextSelection.collapsed(
                              offset: value.length,
                            );
                          },
                        ),
                      )
                    else
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                        sliver: SliverList.separated(
                          itemCount: state.messages.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 14),
                          itemBuilder: (context, index) => _MessageCard(
                            message: state.messages[index],
                          ),
                        ),
                      ),
                    if (state.isSending)
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 2, 14, 18),
                        sliver: SliverToBoxAdapter(
                          child: _LiveProcessCard(
                            events: state.activeRunEvents,
                            detail: state.runDetail,
                          ),
                        ),
                      ),
                    const SliverToBoxAdapter(child: SizedBox(height: 8)),
                  ],
                ),
                if (state.runStatus == RunStatus.failed &&
                    state.runDetail.isNotEmpty &&
                    !state.isSending)
                  Positioned(
                    left: 14,
                    right: 14,
                    top: 6,
                    child: _ErrorToast(text: state.runDetail),
                  ),
              ],
            ),
          ),
          _Composer(
            controller: _composer,
            attachments: state.pendingAttachments,
            listening: _listening,
            sending: state.isSending,
            onAttach: () => _pickAttachments(context),
            onRemoveAttachment: state.removePendingAttachment,
            onVoice: _toggleListening,
            onSend: () => _submit(context),
            onStop: state.stopCurrentRun,
          ),
        ],
      ),
    );
  }

  Future<void> _pickAttachments(BuildContext context) async {
    try {
      await AppScope.of(context).pickAttachments();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  Future<void> _submit(BuildContext context) async {
    final state = AppScope.of(context);
    final text = _composer.text;
    if (text.trim().isEmpty && state.pendingAttachments.isEmpty) return;
    _composer.clear();
    await state.sendMessage(text);
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    final ready = await _speech.initialize(
      onError: (_) {
        if (mounted) setState(() => _listening = false);
      },
      onStatus: (status) {
        if (mounted && status == 'notListening') {
          setState(() => _listening = false);
        }
      },
    );
    if (!ready) return;
    if (mounted) setState(() => _listening = true);
    await _speech.listen(
      localeId: 'ms_MY',
      partialResults: true,
      onResult: (result) {
        _composer.text = result.recognizedWords;
        _composer.selection = TextSelection.collapsed(
          offset: _composer.text.length,
        );
        if (result.finalResult && mounted) {
          setState(() => _listening = false);
        }
      },
    );
  }

  Future<void> _showProviderModelPicker(BuildContext context) async {
    final state = AppScope.of(context);
    if (state.providers.isEmpty) {
      state.selectTab(1);
      return;
    }
    var providerId = state.selectedProviderId;
    final manual = TextEditingController();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final provider = state.providers.firstWhere(
            (item) => item.id == providerId,
            orElse: () => state.providers.first,
          );
          final models = <String>{
            if (provider.model.isNotEmpty) provider.model,
            ...provider.availableModels,
          }.toList()
            ..sort();
          return FractionallySizedBox(
            heightFactor: .8,
            child: Padding(
              padding: EdgeInsets.only(
                left: 18,
                right: 18,
                bottom: MediaQuery.viewInsetsOf(context).bottom + 18,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    'Provider & model',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'Model yang dipilih menjadi orchestrator dan boleh menggunakan tools, skills serta sub-agent secara automatik.',
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: provider.id,
                    decoration: const InputDecoration(
                      labelText: 'Provider',
                      prefixIcon: Icon(Icons.key_rounded),
                    ),
                    isExpanded: true,
                    items: state.providers
                        .map(
                          (item) => DropdownMenuItem<String>(
                            value: item.id,
                            child: Text(
                              item.name,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) async {
                      if (value == null) return;
                      providerId = value;
                      await state.selectProvider(value);
                      setSheetState(() {});
                    },
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: models.isEmpty
                        ? const Center(
                            child: Text(
                              'Tiada senarai model. Masukkan Model ID secara manual di bawah.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          )
                        : ListView.separated(
                            itemCount: models.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 6),
                            itemBuilder: (context, index) {
                              final model = models[index];
                              final selected = model == provider.model;
                              return ListTile(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  side: BorderSide(
                                    color: selected
                                        ? AppTheme.purple
                                        : AppTheme.outline,
                                  ),
                                ),
                                tileColor: selected
                                    ? AppTheme.purple.withValues(alpha: .1)
                                    : AppTheme.surfaceHigh,
                                leading: Icon(
                                  selected
                                      ? Icons.check_circle_rounded
                                      : Icons.circle_outlined,
                                  color: selected
                                      ? AppTheme.purpleLight
                                      : AppTheme.textSecondary,
                                ),
                                title: Text(
                                  model,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                onTap: () async {
                                  await state.updateSelectedModel(model);
                                  if (sheetContext.mounted) {
                                    Navigator.pop(sheetContext);
                                  }
                                },
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: TextField(
                          controller: manual,
                          textInputAction: TextInputAction.done,
                          decoration: const InputDecoration(
                            labelText: 'Model ID manual',
                            hintText: 'contoh: model-versi-terkini',
                          ),
                          onSubmitted: (value) async {
                            if (value.trim().isEmpty) return;
                            await state.updateSelectedModel(value);
                            if (sheetContext.mounted) {
                              Navigator.pop(sheetContext);
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton.filled(
                        tooltip: 'Gunakan model',
                        onPressed: () async {
                          if (manual.text.trim().isEmpty) return;
                          await state.updateSelectedModel(manual.text);
                          if (sheetContext.mounted) {
                            Navigator.pop(sheetContext);
                          }
                        },
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    manual.dispose();
  }

  void _scrollToBottom() {
    if (!_scroll.hasClients) return;
    _scroll.animateTo(
      _scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 340),
      curve: Curves.easeOutCubic,
    );
  }
}

class _ChatHeader extends StatelessWidget {
  const _ChatHeader({
    required this.provider,
    required this.onTapModel,
    required this.onNewSession,
  });

  final ProviderConfig? provider;
  final VoidCallback onTapModel;
  final VoidCallback onNewSession;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 10, 8),
      child: Row(
        children: <Widget>[
          Container(
            width: 46,
            height: 46,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF332653), Color(0xFF141728)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: AppTheme.purple.withValues(alpha: .18),
                  blurRadius: 22,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                'assets/images/app_icon.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTapModel,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'Ai MultiAgent',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -.35,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            provider == null
                                ? 'Pilih provider & model'
                                : '${provider!.name} · ${provider!.model.isEmpty ? 'pilih model' : provider!.model}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          size: 17,
                          color: AppTheme.textSecondary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Sesi baharu',
            onPressed: onNewSession,
            icon: const Icon(Icons.add_comment_outlined),
          ),
        ],
      ),
    );
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat({
    required this.hasProvider,
    required this.sessionNotice,
    required this.onOpenProvider,
    required this.onSuggestion,
  });

  final bool hasProvider;
  final String sessionNotice;
  final VoidCallback onOpenProvider;
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    final suggestions = <(IconData, String, String)>[
      (
        Icons.travel_explore_rounded,
        'Selidik web',
        'Cari maklumat terkini dan ringkaskan sumber penting.',
      ),
      (
        Icons.download_rounded,
        'Proses pautan',
        'Buka pautan ini di browser latar, analisis kandungan dan berikan hasil.',
      ),
      (
        Icons.description_outlined,
        'Analisis fail',
        'Analisis fail yang saya lampirkan dan sediakan ringkasan teratur.',
      ),
      (
        Icons.auto_awesome_rounded,
        'Bina skill',
        'Cipta satu skill local yang boleh membantu tugasan berulang ini.',
      ),
    ];
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 78,
                height: 78,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF40306A), Color(0xFF111522)],
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.purple.withValues(alpha: .22),
                      blurRadius: 34,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(21),
                  child: Image.asset(
                    'assets/images/app_icon.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Apa yang mahu diselesaikan?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.55,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Satu model utama menyelaras carian, browser latar, fail, terminal, skills dan sub-agent secara automatik.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  height: 1.5,
                ),
              ),
              if (sessionNotice.isNotEmpty) ...<Widget>[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceHigh,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    sessionNotice,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
              if (!hasProvider) ...<Widget>[
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: onOpenProvider,
                  icon: const Icon(Icons.key_rounded),
                  label: const Text('Tambah provider'),
                ),
              ],
              const SizedBox(height: 24),
              LayoutBuilder(
                builder: (context, constraints) {
                  final oneColumn = constraints.maxWidth < 500;
                  final width = oneColumn
                      ? constraints.maxWidth
                      : (constraints.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: suggestions
                        .map(
                          (item) => SizedBox(
                            width: width,
                            child: _SuggestionCard(
                              icon: item.$1,
                              title: item.$2,
                              prompt: item.$3,
                              onTap: () => onSuggestion(item.$3),
                            ),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({
    required this.icon,
    required this.title,
    required this.prompt,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String prompt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFF202638)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icon, size: 20, color: AppTheme.purpleLight),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      prompt,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    if (message.role == MessageRole.tool ||
        message.role == MessageRole.system) {
      return const SizedBox.shrink();
    }
    final isUser = message.role == MessageRole.user;
    final maxWidth = MediaQuery.sizeOf(context).width * (isUser ? .84 : .94);
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: maxWidth.clamp(280.0, 760.0).toDouble(),
        ),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: isUser
                ? const LinearGradient(
                    colors: <Color>[Color(0xFF7650EC), Color(0xFF9256FF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            color: isUser ? null : AppTheme.surface,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(21),
              topRight: const Radius.circular(21),
              bottomLeft: Radius.circular(isUser ? 21 : 7),
              bottomRight: Radius.circular(isUser ? 7 : 21),
            ),
            border: isUser
                ? null
                : Border.all(color: const Color(0xFF202638), width: .8),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.black.withValues(alpha: .1),
                blurRadius: 18,
                offset: const Offset(0, 7),
              ),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              isUser ? 15 : 17,
              14,
              isUser ? 15 : 17,
              13,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                if (message.attachments.isNotEmpty)
                  _AttachmentGrid(
                    attachments: message.attachments,
                    compact: isUser,
                  ),
                if (message.attachments.isNotEmpty &&
                    message.content.trim().isNotEmpty)
                  const SizedBox(height: 10),
                if (message.content.trim().isNotEmpty)
                  if (isUser)
                    SelectableText(
                      message.content,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15.5,
                        height: 1.45,
                      ),
                    )
                  else
                    _MarkdownAnswer(data: message.content),
                if (message.artifacts.isNotEmpty) ...<Widget>[
                  if (message.content.trim().isNotEmpty)
                    const SizedBox(height: 14),
                  _ArtifactList(artifacts: message.artifacts),
                ],
                if (!isUser && message.runEvents.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 12),
                  _CompletedProcessCard(events: message.runEvents),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MarkdownAnswer extends StatelessWidget {
  const _MarkdownAnswer({required this.data});

  final String data;

  @override
  Widget build(BuildContext context) {
    final base = MarkdownStyleSheet.fromTheme(Theme.of(context));
    return MarkdownBody(
      data: data,
      selectable: true,
      styleSheet: base.copyWith(
        p: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 15.5,
          height: 1.52,
        ),
        h1: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 23,
          fontWeight: FontWeight.w900,
          height: 1.25,
        ),
        h2: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          height: 1.3,
        ),
        h3: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 17.5,
          fontWeight: FontWeight.w800,
          height: 1.35,
        ),
        strong: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
        ),
        em: const TextStyle(
          color: AppTheme.textPrimary,
          fontStyle: FontStyle.italic,
        ),
        a: const TextStyle(
          color: AppTheme.cyan,
          decoration: TextDecoration.none,
          fontWeight: FontWeight.w700,
        ),
        code: const TextStyle(
          color: Color(0xFFD9CEFF),
          backgroundColor: AppTheme.surfaceHigh,
          fontFamily: 'monospace',
          fontSize: 13.2,
        ),
        codeblockPadding: const EdgeInsets.all(14),
        codeblockDecoration: BoxDecoration(
          color: const Color(0xFF0B0E16),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: AppTheme.outline),
        ),
        blockquotePadding: const EdgeInsets.fromLTRB(14, 10, 12, 10),
        blockquoteDecoration: BoxDecoration(
          color: AppTheme.purple.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(12),
          border: const Border(
            left: BorderSide(color: AppTheme.purpleLight, width: 3),
          ),
        ),
        horizontalRuleDecoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: AppTheme.outline, width: .8),
          ),
        ),
        listBullet: const TextStyle(
          color: AppTheme.purpleLight,
          fontWeight: FontWeight.w900,
        ),
      ),
      onTapLink: (text, href, title) async {
        if (href == null) return;
        final uri = Uri.tryParse(href);
        if (uri != null) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
    );
  }
}

class _AttachmentGrid extends StatelessWidget {
  const _AttachmentGrid({
    required this.attachments,
    required this.compact,
  });

  final List<ChatAttachment> attachments;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: attachments
          .map(
            (attachment) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _AttachmentPreview(
                attachment: attachment,
                compact: compact,
              ),
            ),
          )
          .toList(),
    );
  }
}

class _AttachmentPreview extends StatelessWidget {
  const _AttachmentPreview({
    required this.attachment,
    required this.compact,
  });

  final ChatAttachment attachment;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return switch (attachment.kind) {
      AttachmentKind.image => _ImagePreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
        ),
      AttachmentKind.video => _VideoPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
        ),
      AttachmentKind.audio => _AudioPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
        ),
      _ => _FileCard(
          title: attachment.name,
          subtitle:
              '${attachment.mimeType} · ${_formatBytes(attachment.sizeBytes)}',
          path: attachment.path,
          url: attachment.sourceUrl ?? '',
          compact: compact,
        ),
    };
  }
}

class _ArtifactList extends StatelessWidget {
  const _ArtifactList({required this.artifacts});

  final List<ChatArtifact> artifacts;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: artifacts
          .map(
            (artifact) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _ArtifactCard(artifact: artifact),
            ),
          )
          .toList(),
    );
  }
}

class _ArtifactCard extends StatelessWidget {
  const _ArtifactCard({required this.artifact});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    return switch (artifact.kind) {
      ArtifactKind.image => _ImagePreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
        ),
      ArtifactKind.video => _VideoPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
        ),
      ArtifactKind.audio => _AudioPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
        ),
      ArtifactKind.webpage || ArtifactKind.html => _HtmlPreview(
          title: artifact.title,
          subtitle: artifact.subtitle,
          html: artifact.html,
          url: artifact.url,
        ),
      ArtifactKind.searchResults => _SearchResultsCard(artifact: artifact),
      ArtifactKind.file => _FileCard(
          title: artifact.title,
          subtitle: artifact.subtitle.isEmpty
              ? artifact.mimeType
              : artifact.subtitle,
          path: artifact.localPath,
          url: artifact.url,
          compact: false,
        ),
    };
  }
}

class _ImagePreview extends StatelessWidget {
  const _ImagePreview({
    required this.path,
    required this.url,
    required this.title,
  });

  final String path;
  final String? url;
  final String title;

  @override
  Widget build(BuildContext context) {
    final localFile = path.isNotEmpty ? File(path) : null;
    final hasLocal = localFile?.existsSync() ?? false;
    final remoteUri = Uri.tryParse(url ?? '');
    final hasRemote = remoteUri != null &&
        <String>{'http', 'https'}.contains(remoteUri.scheme) &&
        remoteUri.host.isNotEmpty;
    if (!hasLocal && !hasRemote) {
      return _MediaError(title: title);
    }

    final provider = hasLocal
        ? FileImage(localFile!) as ImageProvider
        : NetworkImage(remoteUri.toString());
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        children: <Widget>[
          ConstrainedBox(
            constraints: const BoxConstraints(
              minHeight: 120,
              maxHeight: 360,
              minWidth: double.infinity,
            ),
            child: Image(
              image: provider,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _MediaError(title: title),
            ),
          ),
          Positioned(
            left: 8,
            right: 8,
            bottom: 8,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: .58),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VideoPreview extends StatefulWidget {
  const _VideoPreview({
    required this.path,
    required this.url,
    required this.title,
  });

  final String path;
  final String? url;
  final String title;

  @override
  State<_VideoPreview> createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<_VideoPreview> {
  VideoPlayerController? _controller;
  Future<void>? _initialize;
  String? _error;

  @override
  void initState() {
    super.initState();
    final localFile = widget.path.isNotEmpty ? File(widget.path) : null;
    if (localFile?.existsSync() ?? false) {
      _controller = VideoPlayerController.file(localFile!);
    } else {
      final uri = Uri.tryParse(widget.url ?? '');
      if (uri == null ||
          !<String>{'http', 'https'}.contains(uri.scheme) ||
          uri.host.isEmpty) {
        _error = 'Sumber video tidak sah.';
        return;
      }
      _controller = VideoPlayerController.networkUrl(uri);
    }
    _initialize = _controller!.initialize().then((_) {
      _controller?.setLooping(false);
      if (mounted) setState(() {});
    }).catchError((Object error) {
      if (mounted) setState(() => _error = error.toString());
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || _error != null) {
      return _MediaError(title: widget.title);
    }
    return FutureBuilder<void>(
      future: _initialize,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _MediaError(title: widget.title);
        }
        if (snapshot.connectionState != ConnectionState.done ||
            !controller.value.isInitialized) {
          return Container(
            height: 180,
            decoration: BoxDecoration(
              color: const Color(0xFF090C13),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(child: _BufferOrb()),
          );
        }
        final ratio = controller.value.aspectRatio > 0
            ? controller.value.aspectRatio
            : 16 / 9;
        return ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: ColoredBox(
            color: Colors.black,
            child: Column(
              children: <Widget>[
                AspectRatio(
                  aspectRatio: ratio,
                  child: Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      VideoPlayer(controller),
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () async {
                            if (controller.value.isPlaying) {
                              await controller.pause();
                            } else {
                              await controller.play();
                            }
                            if (mounted) setState(() {});
                          },
                          child: Center(
                            child: AnimatedOpacity(
                              opacity: controller.value.isPlaying ? 0 : 1,
                              duration: const Duration(milliseconds: 180),
                              child: Container(
                                width: 58,
                                height: 58,
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .58),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.play_arrow_rounded,
                                  color: Colors.white,
                                  size: 34,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                VideoProgressIndicator(
                  controller,
                  allowScrubbing: true,
                  colors: const VideoProgressColors(
                    playedColor: AppTheme.purpleLight,
                    bufferedColor: Color(0xFF7A7290),
                    backgroundColor: Color(0xFF252937),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _AudioPreview extends StatefulWidget {
  const _AudioPreview({
    required this.path,
    required this.url,
    required this.title,
  });

  final String path;
  final String? url;
  final String title;

  @override
  State<_AudioPreview> createState() => _AudioPreviewState();
}

class _AudioPreviewState extends State<_AudioPreview> {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<Duration?>? _durationSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<PlayerState>? _stateSub;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  bool _playing = false;
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _durationSub = _player.durationStream.listen((value) {
      if (mounted && value != null) setState(() => _duration = value);
    });
    _positionSub = _player.positionStream.listen((value) {
      if (mounted) setState(() => _position = value);
    });
    _stateSub = _player.playerStateStream.listen((value) {
      if (!mounted) return;
      setState(() {
        _playing = value.playing;
        if (value.processingState == ProcessingState.completed) {
          _playing = false;
        }
      });
    });
    _load();
  }

  Future<void> _load() async {
    try {
      if (widget.path.isNotEmpty && File(widget.path).existsSync()) {
        await _player.setFilePath(widget.path);
      } else {
        final uri = Uri.tryParse(widget.url ?? '');
        if (uri == null ||
            !<String>{'http', 'https'}.contains(uri.scheme) ||
            uri.host.isEmpty) {
          throw const FormatException('Sumber audio tidak sah.');
        }
        await _player.setUrl(uri.toString());
      }
      if (mounted) setState(() => _ready = true);
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  @override
  void dispose() {
    _durationSub?.cancel();
    _positionSub?.cancel();
    _stateSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final maxMs = _duration.inMilliseconds <= 0
        ? 1.0
        : _duration.inMilliseconds.toDouble();
    final value = _position.inMilliseconds
        .clamp(0, maxMs.toInt())
        .toDouble();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Row(
        children: <Widget>[
          IconButton.filled(
            onPressed: !_ready || _error != null
                ? null
                : () async {
                    if (_playing) {
                      await _player.pause();
                    } else {
                      if (_position >= _duration &&
                          _duration > Duration.zero) {
                        await _player.seek(Duration.zero);
                      }
                      await _player.play();
                    }
                  },
            icon: Icon(
              _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                if (_error != null)
                  const Text(
                    'Audio tidak dapat dimainkan.',
                    style: TextStyle(
                      color: AppTheme.danger,
                      fontSize: 12,
                    ),
                  )
                else
                  Slider(
                    value: value,
                    max: maxMs,
                    min: 0,
                    onChanged: _ready
                        ? (next) => _player.seek(
                              Duration(milliseconds: next.round()),
                            )
                        : null,
                  ),
                Text(
                  '${_formatDuration(_position)} / ${_formatDuration(_duration)}',
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FileCard extends StatelessWidget {
  const _FileCard({
    required this.title,
    required this.subtitle,
    required this.path,
    required this.url,
    required this.compact,
  });

  final String title;
  final String subtitle;
  final String path;
  final String url;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: compact
          ? Colors.white.withValues(alpha: .1)
          : const Color(0xFF0B0E16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(
          color: compact
              ? Colors.white.withValues(alpha: .15)
              : AppTheme.outline,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () async {
          if (path.isNotEmpty && File(path).existsSync()) {
            await OpenFilex.open(path);
            return;
          }
          final uri = Uri.tryParse(url);
          if (uri != null) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: compact
                      ? Colors.white.withValues(alpha: .12)
                      : AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  _fileIcon(title),
                  color: compact ? Colors.white : AppTheme.purpleLight,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    if (subtitle.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: compact
                              ? Colors.white70
                              : AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(
                Icons.open_in_new_rounded,
                size: 18,
                color: compact ? Colors.white70 : AppTheme.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HtmlPreview extends StatefulWidget {
  const _HtmlPreview({
    required this.title,
    required this.subtitle,
    required this.html,
    required this.url,
  });

  final String title;
  final String subtitle;
  final String html;
  final String url;

  @override
  State<_HtmlPreview> createState() => _HtmlPreviewState();
}

class _HtmlPreviewState extends State<_HtmlPreview> {
  WebViewController? _controller;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    if (widget.html.trim().isNotEmpty) {
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.disabled)
        ..setBackgroundColor(const Color(0xFFFCFCFC))
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (_) => NavigationDecision.prevent,
            onPageFinished: (_) {
              if (mounted) setState(() => _loaded = true);
            },
          ),
        )
        ..loadHtmlString(_document(widget.html));
      _controller = controller;
    }
  }

  String _document(String content) => '''
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,Roboto,Arial,sans-serif;margin:16px;color:#171923;background:#fff;line-height:1.5;overflow-wrap:anywhere}
img,video{max-width:100%;height:auto} table{border-collapse:collapse;max-width:100%;display:block;overflow:auto} td,th{border:1px solid #ddd;padding:7px} a{color:#5d36c9} pre{white-space:pre-wrap;background:#f4f3f8;padding:12px;border-radius:10px} button,input,textarea,select{display:none!important}
</style>
</head>
<body>$content</body>
</html>
''';

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(13, 11, 9, 10),
            child: Row(
              children: <Widget>[
                const Icon(
                  Icons.language_rounded,
                  size: 20,
                  color: AppTheme.cyan,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (widget.subtitle.isNotEmpty)
                        Text(
                          widget.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                    ],
                  ),
                ),
                if (widget.url.isNotEmpty)
                  IconButton(
                    tooltip: 'Buka di browser luar',
                    onPressed: () async {
                      final uri = Uri.tryParse(widget.url);
                      if (uri != null) {
                        await launchUrl(
                          uri,
                          mode: LaunchMode.externalApplication,
                        );
                      }
                    },
                    icon: const Icon(Icons.open_in_new_rounded, size: 19),
                  ),
              ],
            ),
          ),
          if (_controller != null)
            SizedBox(
              height: 310,
              child: Stack(
                children: <Widget>[
                  WebViewWidget(controller: _controller!),
                  if (!_loaded)
                    const Positioned.fill(
                      child: ColoredBox(
                        color: Color(0xFF0B0E16),
                        child: Center(child: _BufferOrb()),
                      ),
                    ),
                ],
              ),
            )
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Text(
                widget.url.isEmpty
                    ? 'Pratonton HTML tidak tersedia.'
                    : widget.url,
                style: const TextStyle(color: AppTheme.textSecondary),
              ),
            ),
        ],
      ),
    );
  }
}

class _SearchResultsCard extends StatelessWidget {
  const _SearchResultsCard({required this.artifact});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    final results = (artifact.data['results'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .take(8)
        .toList();
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(
                Icons.travel_explore_rounded,
                color: AppTheme.cyan,
                size: 21,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  artifact.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          if (artifact.subtitle.isNotEmpty) ...<Widget>[
            const SizedBox(height: 3),
            Text(
              artifact.subtitle,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 12,
              ),
            ),
          ],
          if (results.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            ...results.map(
              (result) => InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () async {
                  final uri = Uri.tryParse(result['url']?.toString() ?? '');
                  if (uri != null) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: 25,
                        height: 25,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceHigh,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${result['rank'] ?? ''}',
                          style: const TextStyle(
                            color: AppTheme.purpleLight,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              result['title']?.toString() ?? 'Hasil',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              result['display_url']?.toString() ??
                                  result['url']?.toString() ??
                                  '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.cyan,
                                fontSize: 11,
                              ),
                            ),
                            if ((result['snippet']?.toString() ?? '')
                                .isNotEmpty) ...<Widget>[
                              const SizedBox(height: 3),
                              Text(
                                result['snippet'].toString(),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CompletedProcessCard extends StatefulWidget {
  const _CompletedProcessCard({required this.events});

  final List<RunEvent> events;

  @override
  State<_CompletedProcessCard> createState() => _CompletedProcessCardState();
}

class _CompletedProcessCardState extends State<_CompletedProcessCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final failed = widget.events.any(
      (item) => item.state == RunEventState.failed,
    );
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        children: <Widget>[
          InkWell(
            borderRadius: BorderRadius.circular(15),
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              child: Row(
                children: <Widget>[
                  Icon(
                    failed
                        ? Icons.info_outline_rounded
                        : Icons.check_circle_outline_rounded,
                    size: 18,
                    color: failed ? AppTheme.warning : AppTheme.success,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Proses · ${widget.events.length} langkah',
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _expanded ? .5 : 0,
                    duration: const Duration(milliseconds: 180),
                    child: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      size: 19,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 220),
            crossFadeState: _expanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: const SizedBox(width: double.infinity),
            secondChild: Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: _RunTimeline(events: widget.events),
            ),
          ),
        ],
      ),
    );
  }
}

class _LiveProcessCard extends StatelessWidget {
  const _LiveProcessCard({
    required this.events,
    required this.detail,
  });

  final List<RunEvent> events;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.purple.withValues(alpha: .36),
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: AppTheme.purple.withValues(alpha: .08),
            blurRadius: 28,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const _BufferOrb(size: 30),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'Sedang bekerja',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    if (detail.isNotEmpty)
                      Text(
                        detail,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          if (events.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            _RunTimeline(events: events),
          ],
        ],
      ),
    );
  }
}

class _RunTimeline extends StatelessWidget {
  const _RunTimeline({required this.events});

  final List<RunEvent> events;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: events
          .map(
            (event) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: _RunEventIcon(event: event),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          event.title,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        if (event.detail.isNotEmpty)
                          Text(
                            event.detail,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 11.5,
                              height: 1.35,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}

class _RunEventIcon extends StatelessWidget {
  const _RunEventIcon({required this.event});

  final RunEvent event;

  @override
  Widget build(BuildContext context) {
    return switch (event.state) {
      RunEventState.running => const SizedBox(
          width: 15,
          height: 15,
          child: CircularProgressIndicator(strokeWidth: 1.8),
        ),
      RunEventState.success => const Icon(
          Icons.check_circle_rounded,
          size: 16,
          color: AppTheme.success,
        ),
      RunEventState.failed => const Icon(
          Icons.error_rounded,
          size: 16,
          color: AppTheme.danger,
        ),
      RunEventState.waiting => const Icon(
          Icons.hourglass_top_rounded,
          size: 16,
          color: AppTheme.warning,
        ),
      RunEventState.info => const Icon(
          Icons.circle_rounded,
          size: 9,
          color: AppTheme.cyan,
        ),
    };
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.attachments,
    required this.listening,
    required this.sending,
    required this.onAttach,
    required this.onRemoveAttachment,
    required this.onVoice,
    required this.onSend,
    required this.onStop,
  });

  final TextEditingController controller;
  final List<ChatAttachment> attachments;
  final bool listening;
  final bool sending;
  final VoidCallback onAttach;
  final Future<void> Function(ChatAttachment attachment) onRemoveAttachment;
  final VoidCallback onVoice;
  final VoidCallback onSend;
  final VoidCallback onStop;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        decoration: const BoxDecoration(
          color: Color(0xFF090C14),
          border: Border(
            top: BorderSide(color: Color(0xFF171D2A), width: .8),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (attachments.isNotEmpty) ...<Widget>[
              SizedBox(
                height: 68,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: attachments.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final item = attachments[index];
                    return Container(
                      width: 190,
                      padding: const EdgeInsets.fromLTRB(9, 8, 5, 8),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceHigh,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: AppTheme.outline),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: AppTheme.purple.withValues(alpha: .12),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: Icon(
                              _attachmentIcon(item.kind),
                              size: 19,
                              color: AppTheme.purpleLight,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            tooltip: 'Buang',
                            onPressed: sending
                                ? null
                                : () => onRemoveAttachment(item),
                            icon: const Icon(Icons.close_rounded, size: 18),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
            Container(
              decoration: BoxDecoration(
                color: AppTheme.surfaceHigh,
                borderRadius: BorderRadius.circular(23),
                border: Border.all(color: const Color(0xFF282F41)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.black.withValues(alpha: .14),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: IconButton(
                      tooltip: 'Lampirkan fail',
                      onPressed: sending ? null : onAttach,
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 6,
                      textCapitalization: TextCapitalization.sentences,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      enabled: !sending,
                      decoration: const InputDecoration(
                        hintText: 'Tulis arahan…',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.fromLTRB(5, 15, 8, 15),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: IconButton(
                      tooltip: listening ? 'Henti suara' : 'Input suara',
                      onPressed: sending ? null : onVoice,
                      icon: Icon(
                        listening
                            ? Icons.graphic_eq_rounded
                            : Icons.mic_none_rounded,
                        color: listening
                            ? AppTheme.danger
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 4, 5, 4),
                    child: IconButton.filled(
                      tooltip: sending ? 'Hentikan' : 'Hantar',
                      onPressed: sending ? onStop : onSend,
                      style: IconButton.styleFrom(
                        backgroundColor: sending
                            ? const Color(0xFFD8C5FF)
                            : AppTheme.purple,
                        foregroundColor: sending
                            ? const Color(0xFF24153C)
                            : Colors.white,
                      ),
                      icon: Icon(
                        sending ? Icons.stop_rounded : Icons.arrow_upward_rounded,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BufferOrb extends StatefulWidget {
  const _BufferOrb({this.size = 40});

  final double size;

  @override
  State<_BufferOrb> createState() => _BufferOrbState();
}

class _BufferOrbState extends State<_BufferOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _OrbPainter(progress: _controller.value),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  const _OrbPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.shortestSide * .34;
    final glow = Paint()
      ..shader = const RadialGradient(
        colors: <Color>[
          Color(0xFFB9A2FF),
          Color(0x668E63FF),
          Color(0x008E63FF),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius * 1.5));
    canvas.drawCircle(center, radius * 1.5, glow);

    for (var i = 0; i < 3; i++) {
      final phase = (progress + i / 3) % 1;
      final angle = phase * 6.283185307179586;
      final point = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );
      final dot = Paint()
        ..color = Color.lerp(
              AppTheme.purpleLight,
              AppTheme.cyan,
              i / 2,
            ) ??
            AppTheme.purpleLight;
      canvas.drawCircle(point, size.shortestSide * .09, dot);
    }
    canvas.drawCircle(
      center,
      size.shortestSide * .12,
      Paint()..color = Colors.white.withValues(alpha: .9),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter oldDelegate) =>
      oldDelegate.progress != progress;
}


class _ErrorToast extends StatelessWidget {
  const _ErrorToast({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surfaceHighest,
      elevation: 8,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            const Icon(Icons.error_outline_rounded, color: AppTheme.danger),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                text,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MediaError extends StatelessWidget {
  const _MediaError({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(
              Icons.broken_image_outlined,
              color: AppTheme.textSecondary,
            ),
            const SizedBox(height: 7),
            Text(
              title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

IconData _attachmentIcon(AttachmentKind kind) => switch (kind) {
      AttachmentKind.image => Icons.image_outlined,
      AttachmentKind.video => Icons.movie_outlined,
      AttachmentKind.audio => Icons.audio_file_outlined,
      AttachmentKind.document => Icons.description_outlined,
      AttachmentKind.archive => Icons.archive_outlined,
      AttachmentKind.code => Icons.code_rounded,
      AttachmentKind.other => Icons.insert_drive_file_outlined,
    };

IconData _fileIcon(String name) {
  final lower = name.toLowerCase();
  if (lower.endsWith('.pdf')) return Icons.picture_as_pdf_outlined;
  if (lower.endsWith('.zip') ||
      lower.endsWith('.rar') ||
      lower.endsWith('.7z')) {
    return Icons.archive_outlined;
  }
  if (lower.endsWith('.html') || lower.endsWith('.htm')) {
    return Icons.language_rounded;
  }
  if (lower.endsWith('.json') ||
      lower.endsWith('.dart') ||
      lower.endsWith('.kt') ||
      lower.endsWith('.py') ||
      lower.endsWith('.js')) {
    return Icons.code_rounded;
  }
  return Icons.insert_drive_file_outlined;
}

String _formatBytes(int bytes) {
  if (bytes >= 1024 * 1024 * 1024) {
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
  if (bytes >= 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '$bytes B';
}

String _formatDuration(Duration value) {
  final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
  if (value.inHours > 0) {
    return '${value.inHours}:$minutes:$seconds';
  }
  return '$minutes:$seconds';
}
