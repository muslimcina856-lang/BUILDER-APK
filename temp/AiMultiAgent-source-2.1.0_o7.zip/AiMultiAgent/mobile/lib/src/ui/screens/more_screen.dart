import 'package:flutter/material.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../theme/app_theme.dart';
import 'memory_screen.dart';
import 'mcp_servers_screen.dart';
import 'settings_screen.dart';
import 'tool_logs_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Lain-lain')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 120),
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: <Color>[Color(0xFF21143C), Color(0xFF111A29)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: AppTheme.outline),
              ),
              child: Row(
                children: <Widget>[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset(
                      'assets/images/app_icon.png',
                      width: 64,
                      height: 64,
                    ),
                  ),
                  const SizedBox(width: 15),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          AppConfig.appName,
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Local · BYOK · model sebagai orchestrator',
                          style: TextStyle(color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _MoreTile(
              icon: Icons.psychology_alt_rounded,
              title: 'Memori local',
              subtitle: 'Urus fakta dan konteks yang disimpan pada peranti',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const MemoryScreen()),
              ),
            ),
            _MoreTile(
              icon: Icons.hub_rounded,
              title: 'MCP local',
              subtitle: '${state.mcpServers.length} server dikonfigurasi',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const McpServersScreen(),
                ),
              ),
            ),
            _MoreTile(
              icon: Icons.receipt_long_rounded,
              title: 'Aktiviti tools',
              subtitle: 'Log operasi dengan token dan rahsia ditapis',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const ToolLogsScreen()),
              ),
            ),
            _MoreTile(
              icon: Icons.security_rounded,
              title: 'Tetapan & kelulusan',
              subtitle:
                  '${state.permissionRules.length} peraturan risiko disimpan',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
              ),
            ),
            const SizedBox(height: 18),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                'Browser Chromium berjalan di latar belakang dan tidak membuka skrin berasingan. Chat, provider, API key, skills, automasi dan memori disimpan secara local.',
                style: TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppTheme.purple.withValues(alpha: .13),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(icon, color: AppTheme.purpleLight),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}
