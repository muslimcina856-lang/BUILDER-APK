import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Skills'),
        actions: <Widget>[
          IconButton(onPressed: () => _installUrl(context), icon: const Icon(Icons.download_rounded), tooltip: 'Pasang dari URL'),
          IconButton(onPressed: () => _import(context), icon: const Icon(Icons.file_upload_outlined), tooltip: 'Import ZIP'),
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SkillEditorScreen())), icon: const Icon(Icons.add_rounded), tooltip: 'Skill baharu'),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 40),
        itemCount: state.skills.length,
        itemBuilder: (context, index) {
          final skill = state.skills[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: <Widget>[
                  CircleAvatar(
                    backgroundColor: AppTheme.purple.withValues(alpha: .14),
                    child: const Icon(Icons.extension_rounded, color: AppTheme.purpleLight),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(skill.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        const SizedBox(height: 3),
                        Text(skill.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 5),
                        Text('${skill.toolIds.length} tools • dipilih automatik oleh model', style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                  Switch.adaptive(value: skill.enabled, onChanged: (value) => state.saveSkill(skill.copyWith(enabled: value))),
                  IconButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => SkillEditorScreen(skill: skill))),
                    icon: const Icon(Icons.edit_outlined),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SkillEditorScreen())),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Skill'),
      ),
    );
  }

  Future<void> _import(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const <String>['zip']);
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;
    try {
      await AppScope.of(context).importSkill(path);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Skill berjaya dipasang dan diaktifkan.')));
    } catch (error) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal memasang skill: $error')));
    }
  }

  Future<void> _installUrl(BuildContext context) async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pasang skill dari URL'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'URL arkib ZIP'),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Pasang')),
        ],
      ),
    );
    controller.dispose();
    if (url == null || url.isEmpty || !context.mounted) return;
    try {
      await AppScope.of(context).installSkillFromUrl(url);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Skill dimuat turun, disahkan dan dipasang.')));
    } catch (error) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal memasang skill: $error')));
    }
  }
}

class SkillEditorScreen extends StatefulWidget {
  const SkillEditorScreen({this.skill, super.key});
  final SkillDefinition? skill;

  @override
  State<SkillEditorScreen> createState() => _SkillEditorScreenState();
}

class _SkillEditorScreenState extends State<SkillEditorScreen> {
  static const _uuid = Uuid();
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _instructions;
  late bool _enabled;
  late Set<String> _tools;

  @override
  void initState() {
    super.initState();
    final skill = widget.skill;
    _name = TextEditingController(text: skill?.name ?? 'Skill Baharu');
    _description = TextEditingController(text: skill?.description ?? 'Penerangan ringkas skill.');
    _instructions = TextEditingController(text: skill?.instructions ?? 'Terangkan langkah kerja skill di sini.');
    _enabled = skill?.enabled ?? true;
    _tools = skill?.toolIds.toSet() ?? <String>{};
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _instructions.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.skill == null ? 'Skill Baharu' : 'Edit Skill'),
        actions: <Widget>[
          if (widget.skill != null && widget.skill!.sourcePath.isNotEmpty)
            IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded), tooltip: 'Padam'),
          TextButton(onPressed: _save, child: const Text('Simpan')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nama skill'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(controller: _description, decoration: const InputDecoration(labelText: 'Penerangan'), maxLines: 2, validator: _required),
            const SizedBox(height: 10),
            TextFormField(
              controller: _instructions,
              decoration: const InputDecoration(labelText: 'Arahan skill', alignLabelWithHint: true),
              minLines: 8,
              maxLines: 24,
              validator: _required,
            ),
            const SizedBox(height: 10),
            const Card(
              child: ListTile(
                leading: Icon(Icons.auto_awesome_rounded, color: AppTheme.purpleLight),
                title: Text('Pemilihan automatik'),
                subtitle: Text('Model menentukan sendiri bila skill ini sesuai berdasarkan nama, penerangan dan arahan.'),
              ),
            ),
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, value: _enabled, onChanged: (value) => setState(() => _enabled = value), title: const Text('Skill aktif')),
            const Divider(height: 28),
            const Text('Tools yang diperlukan', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.purpleLight)),
            const SizedBox(height: 4),
            ...state.toolEngine.definitions.map((tool) => CheckboxListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  value: _tools.contains(tool.id),
                  onChanged: (value) => setState(() => value == true ? _tools.add(tool.id) : _tools.remove(tool.id)),
                  title: Text(tool.name),
                  subtitle: Text(tool.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                )),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final old = widget.skill;
    final skill = SkillDefinition(
      id: old?.id ?? _uuid.v4(),
      name: _name.text.trim(),
      description: _description.text.trim(),
      instructions: _instructions.text.trim(),
      triggers: const <String>[],
      toolIds: _tools.toList(),
      enabled: _enabled,
      sourcePath: old?.sourcePath ?? '',
      isBuiltIn: old?.isBuiltIn ?? false,
    );
    await AppScope.of(context).saveSkill(skill);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final skill = widget.skill;
    if (skill == null) return;
    final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam skill?'),
            content: Text('${skill.name} dan fail importnya akan dipadam.'),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Padam')),
            ],
          ),
        ) ??
        false;
    if (!ok || !mounted) return;
    await AppScope.of(context).deleteSkill(skill);
    if (mounted) Navigator.pop(context);
  }
}
