import 'dart:async';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import '../services/agent_runtime.dart';
import '../services/attachment_service.dart';
import '../services/automation_service.dart';
import '../services/browser_session_service.dart';
import '../services/local_database.dart';
import '../services/mcp_service.dart';
import '../services/permission_manager.dart';
import '../services/provider_service.dart';
import '../services/secure_vault.dart';
import '../services/skill_service.dart';
import '../services/terminal_service.dart';
import '../services/tool_engine.dart';

class AppState extends ChangeNotifier with WidgetsBindingObserver {
  AppState() {
    WidgetsBinding.instance.addObserver(this);
    browserSession.addListener(_notifyFromBrowser);
  }

  static const _uuid = Uuid();

  final LocalDatabase database = LocalDatabase();
  final SecureVault vault = SecureVault();
  final ProviderService providerService = ProviderService();
  final BrowserSessionService browserSession = BrowserSessionService();
  final TerminalService terminalService = TerminalService();
  final McpService mcpService = McpService();
  final AttachmentService attachmentService = AttachmentService();

  late final SkillService skillService = SkillService(database);
  late final ToolEngine toolEngine = ToolEngine(
        database,
        browserSession: browserSession,
        terminalService: terminalService,
        skillService: skillService,
        mcpService: mcpService,
      );
  late final PermissionManager permissionManager =
      PermissionManager(database)..onChanged = notifyListeners;
  late final AutomationService automationService = AutomationService(database);
  late final AgentRuntime runtime = AgentRuntime(
        providerService: providerService,
        toolEngine: toolEngine,
        permissionManager: permissionManager,
        database: database,
      );

  bool initialized = false;
  bool isSending = false;
  bool backgroundExecutionAllowed = false;
  RunStatus runStatus = RunStatus.idle;
  String runDetail = '';
  int selectedTab = 0;
  String sessionId = _uuid.v4();
  String selectedProviderId = '';
  String selectedAgentId = 'orchestrator';
  DateTime lastActivityAt = DateTime.now();
  DateTime? runStartedAt;

  List<ProviderConfig> providers = <ProviderConfig>[];
  List<AgentProfile> agents = <AgentProfile>[];
  List<SkillDefinition> skills = <SkillDefinition>[];
  List<AutomationDefinition> automations = <AutomationDefinition>[];
  List<McpServerConfig> mcpServers = <McpServerConfig>[];
  List<ChatMessage> messages = <ChatMessage>[];
  List<RunEvent> currentRunEvents = <RunEvent>[];
  final List<ChatAttachment> pendingAttachments = <ChatAttachment>[];
  String sessionNotice = '';

  Timer? _inactivityTimer;
  RunControl? _runControl;
  DateTime _lastPersistedActivity = DateTime.fromMillisecondsSinceEpoch(0);

  PermissionRequest? get pendingPermission => permissionManager.pending;
  ProviderConfig? get selectedProvider => _providerById(selectedProviderId);
  AgentProfile get selectedAgent => agents.firstWhere(
        (item) => item.id == selectedAgentId,
        orElse: () => rootAgent,
      );
  AgentProfile get rootAgent => agents.firstWhere(
        (item) => item.id == 'orchestrator',
        orElse: () => _builtInAgents().first,
      );
  bool get hasProvider => providers.isNotEmpty;
  bool get sessionAllowsAllRisky =>
      permissionManager.allowAllRiskyForSession;
  List<RunEvent> get activeRunEvents =>
      List<RunEvent>.unmodifiable(currentRunEvents);

  void _notifyFromBrowser() => notifyListeners();

  Future<void> initialize() async {
    _inactivityTimer?.cancel();
    await permissionManager.initialize();
    agents = await _loadAgents();
    skills = await skillService.loadSkills();
    providers = (await database.listObjects('provider'))
        .map(ProviderConfig.fromJson)
        .toList();
    automations = await automationService.load();
    mcpServers = (await database.listObjects('mcp_server'))
        .map(McpServerConfig.fromJson)
        .toList();

    selectedProviderId = await database.getSetting('selectedProviderId') ??
        (providers.isEmpty ? '' : providers.first.id);
    if (_providerById(selectedProviderId) == null && providers.isNotEmpty) {
      selectedProviderId = providers.first.id;
      await database.setSetting('selectedProviderId', selectedProviderId);
    }
    selectedAgentId =
        await database.getSetting('selectedAgentId') ?? 'orchestrator';
    if (!agents.any((item) => item.id == selectedAgentId)) {
      selectedAgentId = 'orchestrator';
      await database.setSetting('selectedAgentId', selectedAgentId);
    }
    backgroundExecutionAllowed =
        (await database.getSetting('backgroundExecutionAllowed')) == 'true';

    final storedSession = await database.getSetting('activeSessionId');
    final previousLifecycle = await database.getSetting('lastLifecycleState');
    final storedActivity = DateTime.tryParse(
      await database.getSetting('lastActivityAt') ?? '',
    );
    final inactiveTooLong = storedActivity == null ||
        DateTime.now().difference(storedActivity) >=
            AppConfig.sessionInactivityTimeout;
    final freshProcessAfterBackground =
        previousLifecycle == 'background' && !backgroundExecutionAllowed;

    if (storedSession == null ||
        inactiveTooLong ||
        freshProcessAfterBackground) {
      sessionId = _uuid.v4();
      await database.setSetting('activeSessionId', sessionId);
      if (inactiveTooLong && storedSession != null) {
        sessionNotice = 'Sesi sebelumnya tamat selepas 30 minit tanpa aktiviti.';
      } else if (freshProcessAfterBackground) {
        sessionNotice = 'Sesi baharu dimulakan selepas aplikasi ditutup.';
      }
    } else {
      sessionId = storedSession;
    }

    lastActivityAt = DateTime.now();
    await database.setSetting('lastLifecycleState', 'foreground');
    await _persistActivity(force: true);
    messages = await database.listMessages(sessionId);

    selectedTab = int.tryParse(
          await database.getSetting('selectedTab') ?? '0',
        ) ??
        0;
    selectedTab = selectedTab.clamp(0, 4).toInt();

    _inactivityTimer = Timer.periodic(
      const Duration(minutes: 1),
      (_) => _checkInactivity(),
    );
    initialized = true;
    notifyListeners();
  }

  void recordActivity() {
    lastActivityAt = DateTime.now();
    unawaited(_persistActivity());
  }

  Future<void> _persistActivity({bool force = false}) async {
    if (!force &&
        DateTime.now().difference(_lastPersistedActivity) <
            const Duration(seconds: 15)) {
      return;
    }
    _lastPersistedActivity = DateTime.now();
    await database.setSetting(
      'lastActivityAt',
      lastActivityAt.toIso8601String(),
    );
  }

  Future<void> _checkInactivity() async {
    if (!initialized || isSending) return;
    if (DateTime.now().difference(lastActivityAt) >=
        AppConfig.sessionInactivityTimeout) {
      await newSession(reason: 'Sesi tamat selepas 30 minit tanpa aktiviti.');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!initialized) return;
    if (state == AppLifecycleState.resumed) {
      final elapsed = DateTime.now().difference(lastActivityAt);
      if (elapsed >= AppConfig.sessionInactivityTimeout) {
        unawaited(
          newSession(reason: 'Sesi tamat selepas 30 minit di latar belakang.'),
        );
      }
      unawaited(database.setSetting('lastLifecycleState', 'foreground'));
      recordActivity();
      return;
    }
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      unawaited(database.setSetting('lastLifecycleState', 'background'));
      unawaited(_persistActivity(force: true));
    }
  }

  void selectTab(int value) {
    recordActivity();
    selectedTab = value.clamp(0, 4).toInt();
    unawaited(database.setSetting('selectedTab', selectedTab.toString()));
    notifyListeners();
  }

  Future<void> selectProvider(String id) async {
    recordActivity();
    selectedProviderId = id;
    await database.setSetting('selectedProviderId', id);
    notifyListeners();
  }

  Future<void> selectAgent(String id) async {
    recordActivity();
    selectedAgentId = id;
    await database.setSetting('selectedAgentId', id);
    notifyListeners();
  }

  Future<void> setBackgroundExecutionAllowed(bool value) async {
    backgroundExecutionAllowed = value;
    await database.setSetting('backgroundExecutionAllowed', value.toString());
    notifyListeners();
  }

  ProviderConfig createProviderFromPreset(ProviderPreset preset) {
    return ProviderConfig(
      id: _uuid.v4(),
      name: preset.name,
      presetId: preset.id,
      protocol: preset.protocol,
      baseUrl: preset.baseUrl,
      chatPath: preset.chatPath,
      modelsPath: preset.modelsPath,
      authStyle: preset.authStyle,
      apiKeyHeader: preset.apiKeyHeader,
      apiKeyPrefix: preset.apiKeyPrefix,
      model: preset.defaultModels.isEmpty ? '' : preset.defaultModels.first,
      availableModels: preset.defaultModels,
      extraHeaders: preset.defaultHeaders,
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: preset.id == 'gemini' ||
          preset.id == 'openai' ||
          preset.id == 'openai_chat' ||
          preset.id == 'mimo',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  Future<void> saveProvider(
    ProviderConfig provider, {
    String? apiKey,
  }) async {
    final index = providers.indexWhere((item) => item.id == provider.id);
    if (index < 0) {
      providers.insert(0, provider);
    } else {
      providers[index] = provider;
    }
    await database.saveObject('provider', provider.id, provider.toJson());
    if (apiKey != null) {
      await vault.writeProviderKey(provider.id, apiKey);
    }
    if (selectedProviderId.isEmpty) {
      await selectProvider(provider.id);
    }
    notifyListeners();
  }

  Future<void> updateProviderModel(
    ProviderConfig provider,
    String model,
  ) async {
    final normalized = model.trim();
    if (normalized.isEmpty) return;
    final available = <String>{...provider.availableModels, normalized}.toList()
      ..sort();
    await saveProvider(
      provider.copyWith(
        model: normalized,
        availableModels: available,
        updatedAt: DateTime.now(),
      ),
    );
  }

  Future<void> updateSelectedModel(String model) async {
    final provider = selectedProvider;
    if (provider == null) return;
    await updateProviderModel(provider, model);
  }

  Future<String> providerKey(String providerId) =>
      vault.readProviderKey(providerId);

  Future<void> deleteProvider(ProviderConfig provider) async {
    providers.removeWhere((item) => item.id == provider.id);
    await database.deleteObject('provider', provider.id);
    await vault.deleteProviderKey(provider.id);
    if (selectedProviderId == provider.id) {
      selectedProviderId = providers.isEmpty ? '' : providers.first.id;
      await database.setSetting('selectedProviderId', selectedProviderId);
    }
    notifyListeners();
  }

  Future<List<String>> refreshModels(
    ProviderConfig provider,
    String key,
  ) async {
    final models = await providerService.listModels(provider, key);
    return <String>{...provider.availableModels, ...models}.toList()..sort();
  }

  Future<ProviderTestResult> testProvider(
    ProviderConfig provider,
    String key,
  ) {
    final testing = provider.copyWith(
      testStatus: ProviderTestStatus.testing,
      lastTestMessage: 'Menguji sambungan…',
    );
    return providerService.test(testing, key);
  }

  Future<void> pickAttachments() async {
    recordActivity();
    final imported = await attachmentService.pickAndImport(sessionId);
    if (imported.isEmpty) return;
    pendingAttachments.addAll(imported);
    notifyListeners();
  }

  Future<void> removePendingAttachment(ChatAttachment attachment) async {
    pendingAttachments.removeWhere((item) => item.id == attachment.id);
    await attachmentService.delete(attachment);
    notifyListeners();
  }

  Future<void> sendMessage(
    String value, {
    List<ChatAttachment> attachments = const <ChatAttachment>[],
  }) async {
    recordActivity();
    final text = value.trim();
    final outgoingAttachments = attachments.isNotEmpty
        ? List<ChatAttachment>.from(attachments)
        : List<ChatAttachment>.from(pendingAttachments);
    if ((text.isEmpty && outgoingAttachments.isEmpty) || isSending) return;

    final provider = selectedProvider;
    if (provider == null) {
      runStatus = RunStatus.failed;
      runDetail = 'Tambah dan pilih provider terlebih dahulu.';
      notifyListeners();
      return;
    }
    if (provider.model.trim().isEmpty) {
      runStatus = RunStatus.failed;
      runDetail = 'Pilih model untuk provider ${provider.name}.';
      notifyListeners();
      return;
    }

    final apiKey = await vault.readProviderKey(provider.id);
    if (provider.authStyle != AuthStyle.none && apiKey.isEmpty) {
      runStatus = RunStatus.failed;
      runDetail = 'API key provider belum disimpan.';
      notifyListeners();
      return;
    }

    final history = List<ChatMessage>.from(messages);
    final userMessage = ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.user,
      content: text,
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{
        if (outgoingAttachments.isNotEmpty)
          'attachments': outgoingAttachments.map((item) => item.toJson()).toList(),
      },
    );
    messages.add(userMessage);
    await database.saveMessage(userMessage);
    pendingAttachments.clear();
    sessionNotice = '';

    isSending = true;
    _runControl = RunControl();
    runStatus = RunStatus.planning;
    runDetail = 'Memahami permintaan';
    runStartedAt = DateTime.now();
    currentRunEvents = <RunEvent>[];
    notifyListeners();

    try {
      final assistant = await runtime.run(
        sessionId: sessionId,
        provider: provider,
        apiKey: apiKey,
        agent: rootAgent,
        agents: agents,
        providers: providers,
        apiKeyResolver: vault.readProviderKey,
        skills: skills,
        history: history,
        userInput: text,
        userAttachments: outgoingAttachments,
        control: _runControl,
        onProgress: (status, detail) {
          runStatus = status;
          runDetail = detail;
          notifyListeners();
        },
        onEvent: _upsertRunEvent,
      );
      final metadata = <String, dynamic>{
        ...assistant.metadata,
        if (currentRunEvents.isNotEmpty)
          'runEvents': currentRunEvents.map((item) => item.toJson()).toList(),
        if (runStartedAt != null)
          'durationMs':
              DateTime.now().difference(runStartedAt!).inMilliseconds,
      };
      final completed = assistant.copyWith(metadata: metadata);
      messages.add(completed);
      await database.saveMessage(completed);
      if (runStatus != RunStatus.cancelled) {
        runStatus = RunStatus.completed;
        runDetail = 'Selesai';
      }
    } catch (error) {
      runStatus = RunStatus.failed;
      runDetail = error.toString();
      final event = RunEvent(
        id: 'runtime-error',
        title: 'Tugasan gagal',
        detail: error.toString(),
        state: RunEventState.failed,
        createdAt: DateTime.now(),
      );
      _upsertRunEvent(event);
      final failure = ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.assistant,
        content: 'Tugasan gagal: ${_friendlyError(error)}',
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          'providerId': provider.id,
          'model': provider.model,
          'runEvents': currentRunEvents.map((item) => item.toJson()).toList(),
          'failed': true,
        },
      );
      messages.add(failure);
      await database.saveMessage(failure);
    } finally {
      isSending = false;
      _runControl = null;
      runStartedAt = null;
      notifyListeners();
    }
  }

  void _upsertRunEvent(RunEvent event) {
    final index = currentRunEvents.indexWhere((item) => item.id == event.id);
    if (index < 0) {
      currentRunEvents.add(event);
    } else {
      currentRunEvents[index] = event;
    }
    runDetail = event.title;
    notifyListeners();
  }

  String _friendlyError(Object error) {
    final value = error.toString().replaceFirst('Exception: ', '').trim();
    if (value.length <= 500) return value;
    return '${value.substring(0, 500)}…';
  }

  void stopCurrentRun() {
    _runControl?.cancel();
    permissionManager.cancelPending();
    runStatus = RunStatus.cancelled;
    runDetail = 'Menghentikan tugasan';
    _upsertRunEvent(
      RunEvent(
        id: 'cancel-request',
        title: 'Menghentikan tugasan',
        detail: 'Menunggu proses aktif berhenti dengan selamat.',
        state: RunEventState.info,
        createdAt: DateTime.now(),
      ),
    );
  }

  void resolvePermission(PermissionDecision decision) {
    permissionManager.resolve(decision);
  }

  void grantSessionRiskPermission() {
    permissionManager.grantSessionAllRisky();
  }

  List<PermissionRule> get permissionRules => permissionManager.rules;

  Future<void> setToolPermission(
    String toolId,
    PermissionPolicy policy, {
    String scope = '*',
  }) {
    return permissionManager.setPolicy(
      toolId,
      scope: scope,
      policy: policy,
    );
  }

  Future<void> setGlobalRiskPermission(PermissionPolicy policy) {
    return permissionManager.setPolicy('*', scope: '*', policy: policy);
  }

  Future<void> revokePermission(String ruleId) =>
      permissionManager.revoke(ruleId);

  Future<void> newSession({
    String reason = 'Sesi baharu dimulakan.',
  }) async {
    _runControl?.cancel();
    permissionManager.clearSessionPermissions();
    sessionId = _uuid.v4();
    await database.setSetting('activeSessionId', sessionId);
    lastActivityAt = DateTime.now();
    await _persistActivity(force: true);
    messages = <ChatMessage>[];
    currentRunEvents = <RunEvent>[];
    pendingAttachments.clear();
    runStatus = RunStatus.idle;
    runDetail = '';
    sessionNotice = reason;
    notifyListeners();
  }

  Future<void> saveAgent(AgentProfile agent) async {
    final index = agents.indexWhere((item) => item.id == agent.id);
    if (index < 0) {
      agents.add(agent);
    } else {
      agents[index] = agent;
    }
    await database.saveObject('agent', agent.id, agent.toJson());
    notifyListeners();
  }

  Future<void> deleteAgent(AgentProfile agent) async {
    if (agent.isBuiltIn) return;
    agents.removeWhere((item) => item.id == agent.id);
    await database.deleteObject('agent', agent.id);
    if (selectedAgentId == agent.id) {
      await selectAgent('orchestrator');
    }
    notifyListeners();
  }

  Future<void> saveSkill(SkillDefinition skill) async {
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    await skillService.save(skill);
    notifyListeners();
  }

  Future<void> importSkill(String path) async {
    final skill = await skillService.importZip(path);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> installSkillFromUrl(String url) async {
    final skill = await skillService.importUrl(url);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> deleteSkill(SkillDefinition skill) async {
    if (skill.isBuiltIn) return;
    skills.removeWhere((item) => item.id == skill.id);
    await skillService.delete(skill);
    notifyListeners();
  }

  Future<void> saveAutomation(AutomationDefinition automation) async {
    final index = automations.indexWhere((item) => item.id == automation.id);
    if (index < 0) {
      automations.add(automation);
    } else {
      automations[index] = automation;
    }
    await automationService.save(automation);
    notifyListeners();
  }

  Future<void> deleteAutomation(AutomationDefinition automation) async {
    automations.removeWhere((item) => item.id == automation.id);
    await automationService.delete(automation);
    notifyListeners();
  }

  Future<void> saveMcpServer(McpServerConfig server) async {
    final index = mcpServers.indexWhere((item) => item.id == server.id);
    if (index < 0) {
      mcpServers.add(server);
    } else {
      mcpServers[index] = server;
    }
    await database.saveObject('mcp_server', server.id, server.toJson());
    notifyListeners();
  }

  Future<Map<String, dynamic>> testMcpServer(McpServerConfig server) async {
    try {
      final result = await mcpService.test(server);
      await saveMcpServer(
        server.copyWith(
          lastTestMessage: 'Berjaya',
          lastTestAt: DateTime.now(),
        ),
      );
      return result;
    } catch (error) {
      await saveMcpServer(
        server.copyWith(
          lastTestMessage: error.toString(),
          lastTestAt: DateTime.now(),
        ),
      );
      rethrow;
    }
  }

  Future<void> deleteMcpServer(McpServerConfig server) async {
    mcpServers.removeWhere((item) => item.id == server.id);
    await database.deleteObject('mcp_server', server.id);
    notifyListeners();
  }

  Future<List<MemoryRecord>> memories() async {
    return (await database.listObjects('memory'))
        .map(MemoryRecord.fromJson)
        .toList();
  }

  Future<void> saveMemory(MemoryRecord memory) async {
    await database.saveObject('memory', memory.id, memory.toJson());
    notifyListeners();
  }

  Future<void> deleteMemory(MemoryRecord memory) async {
    await database.deleteObject('memory', memory.id);
    notifyListeners();
  }

  Future<List<ToolLogRecord>> toolLogs({int limit = 200}) {
    return database.listToolLogs(limit: limit);
  }

  Future<void> deleteAllLocalData() async {
    _inactivityTimer?.cancel();
    _runControl?.cancel();
    permissionManager.cancelPending();
    await automationService.cancelAll();
    await vault.deleteAll();
    await database.deleteAllLocalData();
    providers.clear();
    automations.clear();
    skills.clear();
    mcpServers.clear();
    messages.clear();
    currentRunEvents.clear();
    pendingAttachments.clear();
    sessionNotice = '';
    initialized = false;
    notifyListeners();
    await initialize();
  }

  ProviderConfig? _providerById(String id) {
    for (final provider in providers) {
      if (provider.id == id) return provider;
    }
    return null;
  }

  Future<List<AgentProfile>> _loadAgents() async {
    // Profil agent lama dibersihkan daripada UI/data. Model yang dipilih ialah
    // orchestrator tunggal dan mencipta sub-agent dinamik apabila diperlukan.
    for (final saved in await database.listObjects('agent')) {
      final id = saved['id']?.toString() ?? '';
      if (id.isNotEmpty && id != 'orchestrator') {
        await database.deleteObject('agent', id);
      }
    }
    final root = _builtInAgents().first;
    await database.saveObject('agent', root.id, root.toJson());
    return <AgentProfile>[root];
  }

  List<AgentProfile> _builtInAgents() => const <AgentProfile>[
        AgentProfile(
          id: 'orchestrator',
          name: 'Ai MultiAgent',
          description:
              'Model utama yang memilih tools, skills dan sub-agent secara automatik.',
          systemPrompt:
              'Selesaikan tugasan pengguna secara menyeluruh. Cipta sub-agent dinamik di latar belakang apabila pembahagian kerja meningkatkan hasil, kemudian gabungkan semua hasil.',
          iconCode: 0xf1b3,
          isBuiltIn: true,
        ),
      ];

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    browserSession.removeListener(_notifyFromBrowser);
    _inactivityTimer?.cancel();
    _runControl?.cancel();
    providerService.dispose();
    toolEngine.dispose();
    unawaited(database.close());
    super.dispose();
  }
}
