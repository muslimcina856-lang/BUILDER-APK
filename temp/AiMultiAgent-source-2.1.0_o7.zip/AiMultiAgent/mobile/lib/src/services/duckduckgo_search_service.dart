import 'dart:convert';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class DuckDuckGoSearchResult {
  const DuckDuckGoSearchResult({
    required this.rank,
    required this.title,
    required this.url,
    required this.snippet,
    required this.displayUrl,
    required this.source,
  });

  final int rank;
  final String title;
  final String url;
  final String snippet;
  final String displayUrl;
  final String source;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'rank': rank,
        'title': title,
        'url': url,
        'display_url': displayUrl,
        'snippet': snippet,
        'source': source,
      };
}

class DuckDuckGoSearchResponse {
  const DuckDuckGoSearchResponse({
    required this.query,
    required this.endpoint,
    required this.results,
    required this.elapsedMs,
  });

  final String query;
  final String endpoint;
  final List<DuckDuckGoSearchResult> results;
  final int elapsedMs;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'query': query,
        'engine': 'DuckDuckGo',
        'endpoint': endpoint,
        'count': results.length,
        'elapsed_ms': elapsedMs,
        'results': results.map((item) => item.toJson()).toList(),
      };

  String prettyJson() => const JsonEncoder.withIndent('  ').convert(toJson());
}

class DuckDuckGoSearchService {
  DuckDuckGoSearchService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const Map<String, String> _headers = <String, String>{
    'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 AiMultiAgent/2.1',
    'Accept': 'text/html,application/xhtml+xml',
    'Accept-Language': 'ms-MY,ms;q=0.9,en;q=0.8',
  };

  Future<DuckDuckGoSearchResponse> search({
    required String query,
    int maxResults = 10,
    String region = 'wt-wt',
    String safeSearch = 'moderate',
    String timeRange = '',
  }) async {
    final normalized = query.trim();
    if (normalized.isEmpty) throw const FormatException('Query carian kosong.');
    final limit = maxResults.clamp(1, AppConfig.maxSearchResults).toInt();
    final watch = Stopwatch()..start();

    final parameters = <String, String>{
      'q': normalized,
      'kl': region.trim().isEmpty ? 'wt-wt' : region.trim(),
      if (safeSearch == 'off') 'kp': '-2',
      if (safeSearch == 'strict') 'kp': '1',
      if (safeSearch == 'moderate') 'kp': '-1',
      if (timeRange.trim().isNotEmpty) 'df': timeRange.trim(),
    };

    final htmlUri = Uri.https('html.duckduckgo.com', '/html/', parameters);
    final htmlResponse = await _client.get(htmlUri, headers: _headers).timeout(AppConfig.defaultTimeout);
    if (htmlResponse.statusCode >= 200 && htmlResponse.statusCode < 300) {
      final values = parseHtmlResults(htmlResponse.body, limit: limit, source: 'html');
      if (values.isNotEmpty) {
        watch.stop();
        return DuckDuckGoSearchResponse(
          query: normalized,
          endpoint: htmlUri.toString(),
          results: values,
          elapsedMs: watch.elapsedMilliseconds,
        );
      }
    }

    final liteUri = Uri.https('lite.duckduckgo.com', '/lite/', parameters);
    final liteResponse = await _client.get(liteUri, headers: _headers).timeout(AppConfig.defaultTimeout);
    if (liteResponse.statusCode < 200 || liteResponse.statusCode >= 300) {
      throw HttpExceptionLike('DuckDuckGo gagal: HTML ${htmlResponse.statusCode}, Lite ${liteResponse.statusCode}.');
    }
    final values = parseLiteResults(liteResponse.body, limit: limit);
    watch.stop();
    if (values.isEmpty) throw const FormatException('DuckDuckGo tidak memulangkan hasil yang boleh dibaca.');
    return DuckDuckGoSearchResponse(
      query: normalized,
      endpoint: liteUri.toString(),
      results: values,
      elapsedMs: watch.elapsedMilliseconds,
    );
  }

  static List<DuckDuckGoSearchResult> parseHtmlResults(
    String body, {
    required int limit,
    String source = 'html',
  }) {
    final document = html_parser.parse(body);
    final values = <DuckDuckGoSearchResult>[];
    final seen = <String>{};

    for (final element in document.querySelectorAll('.result, .web-result')) {
      final anchor = element.querySelector('.result__a, a.result-link, h2 a');
      if (anchor == null) continue;
      final url = _decodeRedirect(anchor.attributes['href'] ?? '');
      if (!_isHttpUrl(url) || !seen.add(url)) continue;
      final title = _clean(anchor.text);
      final snippet = _clean(element.querySelector('.result__snippet, .result-snippet')?.text ?? '');
      final display = _clean(element.querySelector('.result__url, .result-url')?.text ?? Uri.parse(url).host);
      values.add(DuckDuckGoSearchResult(
        rank: values.length + 1,
        title: title.isEmpty ? url : title,
        url: url,
        snippet: snippet,
        displayUrl: display,
        source: source,
      ));
      if (values.length >= limit) break;
    }
    return values;
  }

  static List<DuckDuckGoSearchResult> parseLiteResults(String body, {required int limit}) {
    final document = html_parser.parse(body);
    final values = <DuckDuckGoSearchResult>[];
    final seen = <String>{};
    final resultAnchors = document.querySelectorAll('a.result-link');
    final anchors = resultAnchors.isNotEmpty ? resultAnchors : document.querySelectorAll('a[href]');
    for (final anchor in anchors) {
      final raw = anchor.attributes['href'] ?? '';
      final url = _decodeRedirect(raw);
      final host = Uri.tryParse(url)?.host.toLowerCase() ?? '';
      if (!_isHttpUrl(url) || host.endsWith('duckduckgo.com') || !seen.add(url)) continue;
      final title = _clean(anchor.text);
      if (title.isEmpty || title.toLowerCase() == 'next page') continue;
      final row = anchor.parent?.parent;
      final nextRow = row?.nextElementSibling;
      final snippetNode = nextRow?.querySelector('.result-snippet, .result__snippet');
      final nearbyText = _clean(snippetNode?.text ?? nextRow?.text ?? row?.text ?? '');
      var snippet = nearbyText.replaceFirst(title, '').replaceFirst(RegExp(r'^\d+[.]?\s*'), '').trim();
      if (snippet.length > 700) snippet = snippet.substring(0, 700);
      values.add(DuckDuckGoSearchResult(
        rank: values.length + 1,
        title: title,
        url: url,
        snippet: snippet,
        displayUrl: Uri.parse(url).host,
        source: 'lite',
      ));
      if (values.length >= limit) break;
    }
    return values;
  }

  static String _decodeRedirect(String raw) {
    final normalized = raw.startsWith('//') ? 'https:$raw' : raw;
    final parsed = Uri.tryParse(normalized);
    final redirected = parsed?.queryParameters['uddg'];
    return redirected == null ? normalized : redirected;
  }

  static bool _isHttpUrl(String value) {
    final uri = Uri.tryParse(value);
    return uri != null && <String>{'http', 'https'}.contains(uri.scheme) && uri.host.isNotEmpty;
  }

  static String _clean(String value) => value.replaceAll(RegExp(r'\s+'), ' ').trim();

  void dispose() => _client.close();
}

class HttpExceptionLike implements Exception {
  const HttpExceptionLike(this.message);
  final String message;
  @override
  String toString() => message;
}
