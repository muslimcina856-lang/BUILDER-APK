import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';

class ProviderException implements Exception {
  ProviderException(this.message, {this.statusCode, this.body});

  final String message;
  final int? statusCode;
  final String? body;

  @override
  String toString() => message;
}

class ProviderService {
  ProviderService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const _uuid = Uuid();

  Future<ProviderTestResult> test(ProviderConfig config, String apiKey) async {
    final watch = Stopwatch()..start();
    try {
      var models = <String>[];
      try {
        models = await listModels(config, apiKey);
      } catch (_) {
        models = config.availableModels;
      }
      final chosenModel = config.model.isNotEmpty
          ? config.model
          : (models.isNotEmpty ? models.first : '');
      if (chosenModel.isEmpty) {
        throw ProviderException(
          'Model belum dipilih dan provider tidak memulangkan senarai model.',
        );
      }
      final turn = await complete(
        config: config,
        apiKey: apiKey,
        modelOverride: chosenModel,
        messages: <ChatMessage>[
          ChatMessage(
            id: _uuid.v4(),
            sessionId: 'provider-test',
            role: MessageRole.user,
            content: 'Jawab tepat dengan perkataan OK.',
            createdAt: DateTime.now(),
          ),
        ],
        tools: const <ToolDefinition>[],
      );
      watch.stop();
      final ok = turn.text.trim().isNotEmpty;
      return ProviderTestResult(
        success: ok,
        message: ok
            ? 'Sambungan berjaya. Respons: ${turn.text.trim()}'
            : 'Provider tidak memulangkan teks.',
        latencyMs: watch.elapsedMilliseconds,
        models: models,
      );
    } catch (error) {
      watch.stop();
      return ProviderTestResult(
        success: false,
        message: error.toString(),
        latencyMs: watch.elapsedMilliseconds,
      );
    }
  }

  Future<List<String>> listModels(
    ProviderConfig config,
    String apiKey,
  ) async {
    if (config.modelsPath.trim().isEmpty) return config.availableModels;
    final uri = _uri(config, config.modelsPath, apiKey: apiKey);
    final response = await _client
        .get(uri, headers: _headers(config, apiKey))
        .timeout(Duration(seconds: config.timeoutSeconds));
    _ensureSuccess(response);
    final decoded = jsonDecode(response.body);
    final values = <String>[];
    if (decoded is Map && decoded['data'] is List) {
      for (final item in decoded['data'] as List) {
        if (item is Map && item['id'] != null) values.add(item['id'].toString());
      }
    } else if (decoded is Map && decoded['models'] is List) {
      for (final item in decoded['models'] as List) {
        if (item is Map) {
          final name = item['name'] ?? item['id'] ?? item['model'];
          if (name != null) values.add(name.toString().replaceFirst('models/', ''));
        } else {
          values.add(item.toString());
        }
      }
    }
    values.sort();
    return values.toSet().toList();
  }

  Future<ModelTurn> complete({
    required ProviderConfig config,
    required String apiKey,
    required List<ChatMessage> messages,
    required List<ToolDefinition> tools,
    String? modelOverride,
  }) async {
    final model = modelOverride?.trim().isNotEmpty == true
        ? modelOverride!.trim()
        : config.model.trim();
    if (model.isEmpty) throw ProviderException('Model belum dipilih.');

    return switch (config.protocol) {
      ProviderProtocol.openAiChat =>
        _openAiChat(config, apiKey, messages, tools, model),
      ProviderProtocol.openAiResponses =>
        _openAiResponses(config, apiKey, messages, tools, model),
      ProviderProtocol.anthropic =>
        _anthropic(config, apiKey, messages, tools, model),
      ProviderProtocol.gemini =>
        _gemini(config, apiKey, messages, tools, model),
      ProviderProtocol.customRest =>
        _customRest(config, apiKey, messages, tools, model),
    };
  }

  Future<ModelTurn> _openAiChat(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final preparedMessages = <Map<String, dynamic>>[];
    for (final message in messages) {
      preparedMessages.add(await _openAiMessage(message));
    }
    final payload = <String, dynamic>{
      'model': model,
      'messages': preparedMessages,
      'temperature': config.temperature,
      'max_tokens': config.maxTokens,
      'stream': false,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools.map((item) => item.toOpenAiJson()).toList(),
      if (tools.isNotEmpty && config.supportsTools) 'tool_choice': 'auto',
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final choices = data['choices'] as List?;
    if (choices == null || choices.isEmpty) {
      throw ProviderException(
        'Respons provider tiada choices.',
        body: response.body,
      );
    }
    final message = Map<String, dynamic>.from(
      (choices.first as Map)['message'] as Map? ?? const <String, dynamic>{},
    );
    final text = _contentToText(message['content']);
    final calls = <ToolCall>[];
    for (final raw in message['tool_calls'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      final function = Map<String, dynamic>.from(
        item['function'] as Map? ?? const <String, dynamic>{},
      );
      calls.add(
        ToolCall(
          id: item['id']?.toString() ?? _uuid.v4(),
          name: function['name']?.toString() ?? '',
          arguments: _decodeArguments(function['arguments']),
        ),
      );
    }
    return ModelTurn(text: text, toolCalls: calls, raw: data);
  }

  Future<ModelTurn> _openAiResponses(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final input = <Map<String, dynamic>>[];
    for (final message in messages) {
      if (message.role == MessageRole.tool) {
        input.add(<String, dynamic>{
          'type': 'function_call_output',
          'call_id': message.toolCallId,
          'output': message.content,
        });
        continue;
      }
      if (message.metadata['toolCalls'] is List) {
        if (message.content.trim().isNotEmpty) {
          input.add(<String, dynamic>{
            'role': 'assistant',
            'content': <Map<String, dynamic>>[
              <String, dynamic>{'type': 'output_text', 'text': message.content},
            ],
          });
        }
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          input.add(<String, dynamic>{
            'type': 'function_call',
            'call_id': call['id'],
            'name': call['name'],
            'arguments': jsonEncode(
              call['arguments'] ?? const <String, dynamic>{},
            ),
          });
        }
        continue;
      }
      final content = await _responsesContent(message);
      input.add(<String, dynamic>{
        'role': _apiRole(message.role),
        'content': content,
      });
    }
    final payload = <String, dynamic>{
      'model': model,
      'input': input,
      'temperature': config.temperature,
      'max_output_tokens': config.maxTokens,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map(
              (item) => <String, dynamic>{
                'type': 'function',
                'name': item.id,
                'description': item.description,
                'parameters': item.parameters,
              },
            )
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final output = data['output'] as List? ?? const <dynamic>[];
    final textParts = <String>[];
    final calls = <ToolCall>[];
    for (final raw in output) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (item['type'] == 'function_call') {
        calls.add(
          ToolCall(
            id: item['call_id']?.toString() ??
                item['id']?.toString() ??
                _uuid.v4(),
            name: item['name']?.toString() ?? '',
            arguments: _decodeArguments(item['arguments']),
          ),
        );
      }
      final content = item['content'];
      if (content is List) {
        for (final block in content) {
          if (block is Map &&
              (block['type'] == 'output_text' || block['type'] == 'text')) {
            textParts.add(block['text']?.toString() ?? '');
          }
        }
      }
    }
    final fallback = data['output_text']?.toString() ?? '';
    final text = textParts.join('\n').trim();
    return ModelTurn(
      text: text.isEmpty ? fallback : text,
      toolCalls: calls,
      raw: data,
    );
  }

  Future<ModelTurn> _anthropic(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final system = messages
        .where((item) => item.role == MessageRole.system)
        .map((item) => item.content)
        .join('\n\n');
    final anthropicMessages = <Map<String, dynamic>>[];
    for (final message in messages.where(
      (item) => item.role != MessageRole.system,
    )) {
      if (message.role == MessageRole.tool) {
        anthropicMessages.add(<String, dynamic>{
          'role': 'user',
          'content': <Map<String, dynamic>>[
            <String, dynamic>{
              'type': 'tool_result',
              'tool_use_id': message.toolCallId,
              'content': message.content,
            },
          ],
        });
        continue;
      }
      final blocks = await _anthropicContent(message);
      if (message.metadata['toolCalls'] is List) {
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          blocks.add(<String, dynamic>{
            'type': 'tool_use',
            'id': call['id'],
            'name': call['name'],
            'input': call['arguments'] ?? const <String, dynamic>{},
          });
        }
      }
      anthropicMessages.add(<String, dynamic>{
        'role': message.role == MessageRole.assistant ? 'assistant' : 'user',
        'content': blocks,
      });
    }
    final payload = <String, dynamic>{
      'model': model,
      'max_tokens': config.maxTokens,
      'temperature': config.temperature,
      if (system.isNotEmpty) 'system': system,
      'messages': anthropicMessages,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map(
              (item) => <String, dynamic>{
                'name': item.id,
                'description': item.description,
                'input_schema': item.parameters,
              },
            )
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final content = data['content'] as List? ?? const <dynamic>[];
    final text = <String>[];
    final calls = <ToolCall>[];
    for (final raw in content) {
      if (raw is! Map) continue;
      final block = Map<String, dynamic>.from(raw);
      if (block['type'] == 'text') text.add(block['text']?.toString() ?? '');
      if (block['type'] == 'tool_use') {
        calls.add(
          ToolCall(
            id: block['id']?.toString() ?? _uuid.v4(),
            name: block['name']?.toString() ?? '',
            arguments: Map<String, dynamic>.from(
              block['input'] as Map? ?? const <String, dynamic>{},
            ),
          ),
        );
      }
    }
    return ModelTurn(text: text.join('\n'), toolCalls: calls, raw: data);
  }

  Future<ModelTurn> _gemini(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final systemText = messages
        .where((item) => item.role == MessageRole.system)
        .map((item) => item.content)
        .join('\n\n');
    final contents = <Map<String, dynamic>>[];
    for (final message in messages.where(
      (item) => item.role != MessageRole.system,
    )) {
      if (message.role == MessageRole.tool) {
        contents.add(<String, dynamic>{
          'role': 'user',
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{
              'functionResponse': <String, dynamic>{
                'name': message.name ?? 'tool',
                'response': _safeJsonValue(message.content),
              },
            },
          ],
        });
        continue;
      }
      final parts = await _geminiContent(message);
      if (message.metadata['toolCalls'] is List) {
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          parts.add(<String, dynamic>{
            'functionCall': <String, dynamic>{
              'name': call['name'],
              'args': call['arguments'] ?? const <String, dynamic>{},
            },
          });
        }
      }
      contents.add(<String, dynamic>{
        'role': message.role == MessageRole.assistant ? 'model' : 'user',
        'parts': parts,
      });
    }
    final payload = <String, dynamic>{
      if (systemText.isNotEmpty)
        'systemInstruction': <String, dynamic>{
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{'text': systemText},
          ],
        },
      'contents': contents,
      'generationConfig': <String, dynamic>{
        'temperature': config.temperature,
        'maxOutputTokens': config.maxTokens,
      },
      if (tools.isNotEmpty && config.supportsTools)
        'tools': <Map<String, dynamic>>[
          <String, dynamic>{
            'functionDeclarations': tools
                .map(
                  (item) => <String, dynamic>{
                    'name': item.id,
                    'description': item.description,
                    'parameters': item.parameters,
                  },
                )
                .toList(),
          },
        ],
    };
    final path = config.chatPath.replaceAll('{model}', model);
    final response = await _post(config, apiKey, path, payload);
    final data = _decodeMap(response.body);
    final candidates = data['candidates'] as List? ?? const <dynamic>[];
    if (candidates.isEmpty) {
      throw ProviderException(
        'Gemini tidak memulangkan candidates.',
        body: response.body,
      );
    }
    final candidate = Map<String, dynamic>.from(candidates.first as Map);
    final content = Map<String, dynamic>.from(
      candidate['content'] as Map? ?? const <String, dynamic>{},
    );
    final text = <String>[];
    final calls = <ToolCall>[];
    for (final raw in content['parts'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final part = Map<String, dynamic>.from(raw);
      if (part['text'] != null) text.add(part['text'].toString());
      if (part['functionCall'] is Map) {
        final call = Map<String, dynamic>.from(part['functionCall'] as Map);
        calls.add(
          ToolCall(
            id: _uuid.v4(),
            name: call['name']?.toString() ?? '',
            arguments: Map<String, dynamic>.from(
              call['args'] as Map? ?? const <String, dynamic>{},
            ),
          ),
        );
      }
    }
    return ModelTurn(text: text.join('\n'), toolCalls: calls, raw: data);
  }

  Future<ModelTurn> _customRest(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final serialisedMessages = <Map<String, dynamic>>[];
    for (final message in messages) {
      serialisedMessages.add(await _openAiMessage(message));
    }
    Map<String, dynamic> payload;
    if (config.customRequestTemplate.trim().isEmpty) {
      payload = <String, dynamic>{
        'model': model,
        'messages': serialisedMessages,
        if (tools.isNotEmpty) 'tools': tools.map((item) => item.toOpenAiJson()).toList(),
      };
    } else {
      var template = config.customRequestTemplate;
      template = template
          .replaceAll('{{model}}', jsonEncode(model))
          .replaceAll('{{messages}}', jsonEncode(serialisedMessages))
          .replaceAll(
            '{{tools}}',
            jsonEncode(tools.map((item) => item.toOpenAiJson()).toList()),
          );
      final decoded = jsonDecode(template);
      if (decoded is! Map) {
        throw ProviderException('Custom request template mesti objek JSON.');
      }
      payload = Map<String, dynamic>.from(decoded);
    }
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final value = _readJsonPath(data, config.customResponsePath);
    final text = value is String ? value : jsonEncode(value);
    return ModelTurn(text: text, raw: data);
  }

  Future<Map<String, dynamic>> _openAiMessage(ChatMessage message) async {
    if (message.role == MessageRole.tool) {
      return <String, dynamic>{
        'role': 'tool',
        'tool_call_id': message.toolCallId,
        'content': message.content,
      };
    }
    final output = <String, dynamic>{'role': _apiRole(message.role)};
    if (message.metadata['toolCalls'] is List) {
      output['content'] = message.content.isEmpty ? null : message.content;
      output['tool_calls'] = (message.metadata['toolCalls'] as List)
          .whereType<Map>()
          .map(
            (raw) => <String, dynamic>{
              'id': raw['id'],
              'type': 'function',
              'function': <String, dynamic>{
                'name': raw['name'],
                'arguments': jsonEncode(
                  raw['arguments'] ?? const <String, dynamic>{},
                ),
              },
            },
          )
          .toList();
      return output;
    }

    if (message.attachments.isEmpty) {
      output['content'] = message.content;
      return output;
    }
    final blocks = <Map<String, dynamic>>[];
    if (message.content.trim().isNotEmpty) {
      blocks.add(<String, dynamic>{
        'type': 'text',
        'text': message.content,
      });
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
        continue;
      }
      if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'image_url',
          'image_url': <String, dynamic>{'url': inline.dataUri},
        });
      } else if (attachment.kind == AttachmentKind.audio &&
          !inline.isRemote &&
          inline.base64.isNotEmpty) {
        blocks.add(<String, dynamic>{
          'type': 'input_audio',
          'input_audio': <String, dynamic>{
            'data': inline.base64,
            'format': _audioFormat(attachment.name),
          },
        });
      } else if (inline.text != null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': 'Fail ${attachment.name}:\n${inline.text}',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      }
    }
    output['content'] = blocks;
    return output;
  }

  Future<List<Map<String, dynamic>>> _responsesContent(
    ChatMessage message,
  ) async {
    final blocks = <Map<String, dynamic>>[];
    if (message.content.trim().isNotEmpty) {
      blocks.add(<String, dynamic>{
        'type': 'input_text',
        'text': message.content,
      });
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'input_text',
          'text': _attachmentNotice(attachment),
        });
      } else if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'input_image',
          'image_url': inline.dataUri,
        });
      } else if (inline.isRemote) {
        blocks.add(<String, dynamic>{
          'type': 'input_text',
          'text': '[Lampiran URL: ${attachment.name} — ${inline.sourceUrl}]',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'input_file',
          'filename': attachment.name,
          'file_data': inline.dataUri,
        });
      }
    }
    return blocks;
  }

  Future<List<Map<String, dynamic>>> _anthropicContent(
    ChatMessage message,
  ) async {
    final blocks = <Map<String, dynamic>>[];
    if (message.content.isNotEmpty) {
      blocks.add(<String, dynamic>{'type': 'text', 'text': message.content});
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      } else if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'image',
          'source': inline.isRemote
              ? <String, dynamic>{
                  'type': 'url',
                  'url': inline.sourceUrl,
                }
              : <String, dynamic>{
                  'type': 'base64',
                  'media_type': attachment.mimeType,
                  'data': inline.base64,
                },
        });
      } else if (inline.isRemote) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': '[Lampiran URL: ${attachment.name} — ${inline.sourceUrl}]',
        });
      } else if (attachment.mimeType == 'application/pdf') {
        blocks.add(<String, dynamic>{
          'type': 'document',
          'source': <String, dynamic>{
            'type': 'base64',
            'media_type': attachment.mimeType,
            'data': inline.base64,
          },
          'title': attachment.name,
        });
      } else if (inline.text != null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': 'Fail ${attachment.name}:\n${inline.text}',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      }
    }
    return blocks;
  }

  Future<List<Map<String, dynamic>>> _geminiContent(
    ChatMessage message,
  ) async {
    final parts = <Map<String, dynamic>>[];
    if (message.content.isNotEmpty) {
      parts.add(<String, dynamic>{'text': message.content});
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        parts.add(<String, dynamic>{'text': _attachmentNotice(attachment)});
      } else if (inline.isRemote) {
        parts.add(<String, dynamic>{
          'fileData': <String, dynamic>{
            'mimeType': attachment.mimeType,
            'fileUri': inline.sourceUrl,
          },
        });
      } else {
        parts.add(<String, dynamic>{
          'inlineData': <String, dynamic>{
            'mimeType': attachment.mimeType,
            'data': inline.base64,
          },
        });
      }
    }
    return parts;
  }

  Future<_InlineAttachment?> _inlineAttachment(
    ChatAttachment attachment,
  ) async {
    if (attachment.sourceUrl?.isNotEmpty == true) {
      return _InlineAttachment(
        base64: '',
        dataUri: attachment.sourceUrl!,
        sourceUrl: attachment.sourceUrl!,
      );
    }
    if (attachment.path.isEmpty) return null;
    final file = File(attachment.path);
    if (!await file.exists()) return null;
    final size = await file.length();
    if (size > AppConfig.maxInlineModelAttachmentBytes) return null;
    final bytes = await file.readAsBytes();
    String? text;
    if (_isTextMime(attachment.mimeType, attachment.name)) {
      try {
        text = utf8.decode(bytes, allowMalformed: true);
        if (text.length > AppConfig.maxToolOutputChars) {
          text = '${text.substring(0, AppConfig.maxToolOutputChars)}…';
        }
      } catch (_) {
        text = null;
      }
    }
    final encoded = base64Encode(bytes);
    return _InlineAttachment(
      base64: encoded,
      dataUri: 'data:${attachment.mimeType};base64,$encoded',
      text: text,
    );
  }

  String _attachmentNotice(ChatAttachment attachment) =>
      '[Lampiran: ${attachment.name}, ${attachment.mimeType}, ${attachment.sizeBytes} bait. '
      'Format/saiz ini tidak boleh diinlin secara langsung oleh protokol provider ini.]';

  bool _isTextMime(String mimeType, String name) {
    final extension = p.extension(name).toLowerCase();
    return mimeType.startsWith('text/') ||
        mimeType.contains('json') ||
        mimeType.contains('xml') ||
        mimeType.contains('yaml') ||
        <String>{
          '.md',
          '.txt',
          '.csv',
          '.json',
          '.xml',
          '.yaml',
          '.yml',
          '.dart',
          '.kt',
          '.java',
          '.js',
          '.ts',
          '.py',
          '.sh',
          '.html',
          '.css',
          '.sql',
          '.log',
        }.contains(extension);
  }

  String _audioFormat(String filename) {
    final extension = p.extension(filename).toLowerCase().replaceFirst('.', '');
    return switch (extension) {
      'wav' => 'wav',
      'mp3' => 'mp3',
      'm4a' => 'm4a',
      'ogg' => 'ogg',
      _ => 'wav',
    };
  }

  Future<http.Response> _post(
    ProviderConfig config,
    String apiKey,
    String path,
    Map<String, dynamic> payload,
  ) async {
    final uri = _uri(config, path, apiKey: apiKey);
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
          },
          body: jsonEncode(payload),
        )
        .timeout(Duration(seconds: config.timeoutSeconds));
    _ensureSuccess(response);
    return response;
  }

  Uri _uri(
    ProviderConfig config,
    String path, {
    required String apiKey,
  }) {
    final base = config.baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final suffix = path.trim().isEmpty
        ? ''
        : (path.startsWith('/') || path.startsWith('?') ? path : '/$path');
    final parsed = Uri.parse('$base$suffix');
    if (config.authStyle == AuthStyle.queryParameter && apiKey.isNotEmpty) {
      return parsed.replace(
        queryParameters: <String, String>{
          ...parsed.queryParameters,
          config.apiKeyHeader: apiKey,
        },
      );
    }
    return parsed;
  }

  Map<String, String> _headers(ProviderConfig config, String apiKey) {
    final headers = <String, String>{
      'Accept': 'application/json',
      AppConfig.sessionHeader: AppConfig.version,
      ...config.extraHeaders,
    };
    if (apiKey.isEmpty || config.authStyle == AuthStyle.none) return headers;
    if (config.authStyle == AuthStyle.bearer ||
        config.authStyle == AuthStyle.apiKeyHeader ||
        config.authStyle == AuthStyle.xApiKey) {
      headers[config.apiKeyHeader] = '${config.apiKeyPrefix}$apiKey';
    }
    return headers;
  }

  void _ensureSuccess(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) return;
    var message = 'HTTP ${response.statusCode}';
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map) {
          message = error['message']?.toString() ?? message;
        } else if (error != null) {
          message = error.toString();
        } else if (decoded['message'] != null) {
          message = decoded['message'].toString();
        }
      }
    } catch (_) {
      if (response.body.trim().isNotEmpty) {
        message = response.body.trim();
      }
    }
    if (message.length > 800) message = '${message.substring(0, 800)}…';
    throw ProviderException(
      message,
      statusCode: response.statusCode,
      body: response.body,
    );
  }

  Map<String, dynamic> _decodeMap(String body) {
    final decoded = jsonDecode(body);
    if (decoded is! Map) {
      throw ProviderException('Respons provider bukan objek JSON.', body: body);
    }
    return Map<String, dynamic>.from(decoded);
  }

  Map<String, dynamic> _decodeArguments(Object? value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    if (value == null) return <String, dynamic>{};
    try {
      final decoded = jsonDecode(value.toString());
      return decoded is Map
          ? Map<String, dynamic>.from(decoded)
          : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{'value': value.toString()};
    }
  }

  String _contentToText(Object? value) {
    if (value == null) return '';
    if (value is String) return value;
    if (value is List) {
      return value
          .whereType<Map>()
          .map((item) => item['text']?.toString() ?? '')
          .where((item) => item.isNotEmpty)
          .join('\n');
    }
    return value.toString();
  }

  String _apiRole(MessageRole role) => switch (role) {
        MessageRole.system => 'system',
        MessageRole.user => 'user',
        MessageRole.assistant => 'assistant',
        MessageRole.tool => 'tool',
      };

  Object _safeJsonValue(String value) {
    try {
      return jsonDecode(value);
    } catch (_) {
      return <String, dynamic>{'content': value};
    }
  }

  Object? _readJsonPath(Object? value, String path) {
    Object? current = value;
    for (final segment in path.split('.').where((item) => item.isNotEmpty)) {
      if (current is Map) {
        current = current[segment];
      } else if (current is List) {
        final index = int.tryParse(segment);
        if (index == null || index < 0 || index >= current.length) return null;
        current = current[index];
      } else {
        return null;
      }
    }
    return current;
  }

  void dispose() => _client.close();
}

class _InlineAttachment {
  const _InlineAttachment({
    required this.base64,
    required this.dataUri,
    this.sourceUrl = '',
    this.text,
  });

  final String base64;
  final String dataUri;
  final String sourceUrl;
  final String? text;

  bool get isRemote => sourceUrl.isNotEmpty;
}
