import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../models/app_models.dart';
import 'local_database.dart';
import 'permission_manager.dart';
import 'provider_service.dart';
import 'tool_engine.dart';

class RunControl {
  bool _cancelled = false;
  bool get cancelled => _cancelled;
  void cancel() => _cancelled = true;
}

/// Menyelaras model, tools, skills dan sub-agent dinamik.
///
/// UI hanya menerima status operasi yang boleh diperhati (model, tool,
/// sub-agent, hasil). Pemikiran dalaman model tidak direkod atau dipaparkan.
class AgentRuntime {
  AgentRuntime({
    required this.providerService,
    required this.toolEngine,
    required this.permissionManager,
    required this.database,
  });

  final ProviderService providerService;
  final ToolEngine toolEngine;
  final PermissionManager permissionManager;
  final LocalDatabase database;

  static const Uuid _uuid = Uuid();

  Future<ChatMessage> run({
    required String sessionId,
    required ProviderConfig provider,
    required String apiKey,
    required AgentProfile agent,
    required List<SkillDefinition> skills,
    required List<ChatMessage> history,
    required String userInput,
    List<ChatAttachment> userAttachments = const <ChatAttachment>[],
    List<AgentProfile> agents = const <AgentProfile>[],
    List<ProviderConfig> providers = const <ProviderConfig>[],
    Future<String> Function(String providerId)? apiKeyResolver,
    RunControl? control,
    int depth = 0,
    void Function(RunStatus status, String detail)? onProgress,
    void Function(RunEvent event)? onEvent,
  }) async {
    // Parameter legacy ini dikekalkan supaya data lama/worker lama masih serasi.
    // Sub-agent baharu sentiasa menggunakan provider/model yang dipilih pengguna.
    final _ = (agents, providers, apiKeyResolver);
    final runControl = control ?? RunControl();
    final activeSkills = skills.where((item) => item.enabled).toList();
    final selectedTools = _selectTools(agent, activeSkills)
      ..add(_delegateAgentDefinition());
    final artifacts = <ChatArtifact>[];

    final messages = <ChatMessage>[
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.system,
        content: _systemPrompt(agent, activeSkills, selectedTools),
        createdAt: DateTime.now(),
      ),
      ...history.where((message) => message.role != MessageRole.system),
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.user,
        content: userInput,
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          if (userAttachments.isNotEmpty)
            'attachments':
                userAttachments.map((item) => item.toJson()).toList(),
        },
      ),
    ];

    var step = 0;
    while (!runControl.cancelled) {
      final modelEventId = 'model:$depth:$step';
      final firstTurn = step == 0;
      final modelTitle = firstTurn
          ? (depth == 0
              ? 'Memahami permintaan'
              : '${agent.name} memproses subtugas')
          : 'Menyusun hasil';
      _emit(
        onEvent,
        RunEvent(
          id: modelEventId,
          title: modelTitle,
          detail: '${provider.name} · ${agent.modelOverride ?? provider.model}',
          state: RunEventState.running,
          createdAt: DateTime.now(),
          agentRole: agent.name,
        ),
      );
      onProgress?.call(
        firstTurn ? RunStatus.planning : RunStatus.runningTool,
        modelTitle,
      );

      ModelTurn turn;
      try {
        turn = await providerService.complete(
          config: provider,
          apiKey: apiKey,
          messages: messages,
          tools: selectedTools,
          modelOverride: agent.modelOverride,
        );
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: turn.toolCalls.isEmpty
                ? 'Respons akhir diterima'
                : '${turn.toolCalls.length} tindakan dipilih',
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
      } catch (error) {
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: error.toString(),
            state: RunEventState.failed,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        rethrow;
      }

      if (runControl.cancelled) break;
      if (turn.toolCalls.isEmpty) {
        final text = turn.text.trim().isEmpty
            ? 'Model tidak memulangkan jawapan teks.'
            : turn.text.trim();
        _emit(
          onEvent,
          RunEvent(
            id: 'final:$depth',
            title: depth == 0 ? 'Jawapan siap' : '${agent.name} selesai',
            detail: artifacts.isEmpty
                ? 'Selesai'
                : '${artifacts.length} hasil dilampirkan',
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        onProgress?.call(RunStatus.completed, 'Selesai');
        return ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'agentId': agent.id,
            'agentName': agent.name,
            'providerId': provider.id,
            'model': agent.modelOverride ?? provider.model,
            'steps': step + 1,
            'delegationDepth': depth,
            if (artifacts.isNotEmpty)
              'artifacts': artifacts.map((item) => item.toJson()).toList(),
          },
        );
      }

      messages.add(
        ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: turn.text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'toolCalls': turn.toolCalls
                .map(
                  (call) => <String, dynamic>{
                    'id': call.id,
                    'name': call.name,
                    'arguments': call.arguments,
                  },
                )
                .toList(),
          },
        ),
      );

      for (final call in turn.toolCalls) {
        if (runControl.cancelled) break;
        final definition = call.name == 'delegate_agent'
            ? selectedTools.firstWhereOrNull(
                (item) => item.id == 'delegate_agent',
              )
            : toolEngine.definition(call.name);
        if (definition == null ||
            !selectedTools.any((item) => item.id == call.name)) {
          final unavailable = ToolResult(
            success: false,
            output: 'Tool ${call.name} tidak tersedia.',
          );
          messages.add(_toolMessage(sessionId, call, unavailable));
          _emitToolResult(
            onEvent: onEvent,
            eventId: 'tool:${call.id}',
            title: call.name,
            result: unavailable,
            agentName: agent.name,
          );
          continue;
        }

        final isDelegation = call.name == 'delegate_agent';
        final eventId = isDelegation ? 'agent:${call.id}' : 'tool:${call.id}';
        final title = isDelegation
            ? (call.arguments['role']?.toString().trim().isNotEmpty == true
                ? call.arguments['role'].toString().trim()
                : 'Sub-agent')
            : definition.name;
        _emit(
          onEvent,
          RunEvent(
            id: eventId,
            title: title,
            detail: _eventDetail(call.name, call.arguments),
            state: RunEventState.running,
            createdAt: DateTime.now(),
            toolId: call.name,
            agentRole: agent.name,
          ),
        );

        late ToolResult result;
        if (isDelegation) {
          onProgress?.call(RunStatus.runningTool, '$title sedang bekerja');
          result = await _delegate(
            sessionId: sessionId,
            call: call,
            provider: provider,
            apiKey: apiKey,
            skills: activeSkills,
            control: runControl,
            depth: depth,
            onProgress: onProgress,
            onEvent: onEvent,
          );
        } else {
          final scope = toolEngine.permissionScope(call.name, call.arguments);
          if (await toolEngine.requiresPermission(call.name, call.arguments)) {
            _emit(
              onEvent,
              RunEvent(
                id: eventId,
                title: title,
                detail: 'Menunggu kelulusan tindakan berisiko',
                state: RunEventState.waiting,
                createdAt: DateTime.now(),
                toolId: call.name,
                agentRole: agent.name,
              ),
            );
            onProgress?.call(
              RunStatus.waitingPermission,
              'Menunggu kelulusan untuk ${definition.name}',
            );
            final decision = await permissionManager.request(
              tool: definition,
              scope: scope,
              description:
                  toolEngine.permissionDescription(call.name, call.arguments),
            );
            if (decision == PermissionDecision.deny) {
              result = const ToolResult(
                success: false,
                output: 'Pengguna menolak tindakan berisiko ini.',
              );
              messages.add(_toolMessage(sessionId, call, result));
              await _logTool(
                sessionId: sessionId,
                toolId: call.name,
                scope: scope,
                result: result,
              );
              _emitToolResult(
                onEvent: onEvent,
                eventId: eventId,
                title: title,
                result: result,
                agentName: agent.name,
                toolId: call.name,
              );
              continue;
            }
          }
          onProgress?.call(RunStatus.runningTool, title);
          result = await toolEngine.execute(call.name, call.arguments);
          await _logTool(
            sessionId: sessionId,
            toolId: call.name,
            scope: scope,
            result: result,
          );
        }

        _collectArtifacts(result.data, artifacts);
        messages.add(_toolMessage(sessionId, call, result));
        _emitToolResult(
          onEvent: onEvent,
          eventId: eventId,
          title: title,
          result: result,
          agentName: agent.name,
          toolId: call.name,
        );
      }
      step++;
    }

    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.assistant,
      content: 'Tugasan dihentikan.',
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{
        'cancelled': true,
        if (artifacts.isNotEmpty)
          'artifacts': artifacts.map((item) => item.toJson()).toList(),
      },
    );
  }

  Future<ToolResult> _delegate({
    required String sessionId,
    required ToolCall call,
    required ProviderConfig provider,
    required String apiKey,
    required List<SkillDefinition> skills,
    required RunControl control,
    required int depth,
    required void Function(RunStatus status, String detail)? onProgress,
    required void Function(RunEvent event)? onEvent,
  }) async {
    final role = call.arguments['role']?.toString().trim() ?? '';
    final task = call.arguments['task']?.toString().trim() ?? '';
    final expected =
        call.arguments['expected_output']?.toString().trim() ?? '';
    final requestedTools = (call.arguments['tool_ids'] as List? ??
            const <dynamic>[])
        .map((item) => item.toString())
        .where((item) => toolEngine.definition(item) != null)
        .toList();
    if (task.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Subtugas tidak boleh kosong.',
      );
    }

    final name = role.isEmpty ? 'Sub-agent' : role;
    final subAgent = AgentProfile(
      id: 'sub_${_uuid.v4()}',
      name: name,
      description: 'Sub-agent dinamik untuk satu subtugas.',
      systemPrompt: [
        'Fokus hanya pada subtugas yang diberikan.',
        if (expected.isNotEmpty) 'Hasil yang diperlukan: $expected',
        'Pulangkan dapatan yang padat kepada orchestrator utama.',
      ].join('\n'),
      iconCode: 0xf1b3,
      toolIds: requestedTools,
      enabled: true,
      isBuiltIn: false,
    );

    final response = await run(
      sessionId: '$sessionId/sub/${_uuid.v4()}',
      provider: provider,
      apiKey: apiKey,
      agent: subAgent,
      skills: skills,
      history: const <ChatMessage>[],
      userInput: task,
      control: control,
      depth: depth + 1,
      onProgress: onProgress,
      onEvent: onEvent,
    );
    return ToolResult(
      success: !control.cancelled,
      output: response.content,
      data: <String, dynamic>{
        'role': name,
        'provider_id': provider.id,
        'model': provider.model,
        'depth': depth + 1,
        if (response.artifacts.isNotEmpty)
          'artifacts': response.artifacts.map((item) => item.toJson()).toList(),
      },
    );
  }

  ToolDefinition _delegateAgentDefinition() {
    return const ToolDefinition(
      id: 'delegate_agent',
      name: 'Cipta sub-agent',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Cipta sub-agent dinamik di latar belakang untuk menyelesaikan satu subtugas menggunakan provider dan model yang sama.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'role': <String, dynamic>{
            'type': 'string',
            'description':
                'Nama peranan khusus, contoh Penyelidik Web atau Penganalisis Dokumen.',
          },
          'task': <String, dynamic>{
            'type': 'string',
            'description': 'Subtugas lengkap beserta konteks penting.',
          },
          'expected_output': <String, dynamic>{
            'type': 'string',
            'description': 'Bentuk hasil yang perlu dipulangkan.',
          },
          'tool_ids': <String, dynamic>{
            'type': 'array',
            'items': <String, dynamic>{'type': 'string'},
            'description':
                'Pilihan tool khusus. Kosong bermaksud semua tool tersedia.',
          },
        },
        'required': <String>['role', 'task'],
      },
    );
  }

  List<ToolDefinition> _selectTools(
    AgentProfile agent,
    List<SkillDefinition> skills,
  ) {
    final ids = <String>{...agent.toolIds};
    for (final skill in skills) {
      ids.addAll(skill.toolIds);
    }
    if (ids.isEmpty || agent.id == 'orchestrator') {
      return <ToolDefinition>[...toolEngine.definitions];
    }
    return toolEngine.definitions
        .where((item) => ids.contains(item.id))
        .toList(growable: true);
  }

  String _systemPrompt(
    AgentProfile agent,
    List<SkillDefinition> skills,
    List<ToolDefinition> tools,
  ) {
    final skillText = skills.isEmpty
        ? 'Tiada skill aktif.'
        : skills
            .map(
              (skill) =>
                  'SKILL ${skill.name}\nTujuan: ${skill.description}\nArahan:\n${skill.instructions}\nTools: ${skill.toolIds.join(', ')}',
            )
            .join('\n\n');
    return '''
Anda ialah ${agent.name} dalam Ai MultiAgent.

Peranan:
${agent.systemPrompt}

Arahan operasi:
- Jawab dalam bahasa pengguna kecuali diminta sebaliknya.
- Tentukan sendiri bila tool, skill atau sub-agent diperlukan; tiada kata kunci pemicu.
- Gunakan hasil tool sebenar dan jangan mendakwa tindakan berjaya sebelum hasil diterima.
- Untuk web, gunakan web_search kemudian browser_open/browser_read bagi sumber penting. Browser berjalan sepenuhnya di latar belakang.
- Untuk terminal, gunakan terminal_start dan terminal_poll supaya stdout, stderr dan status dapat diperiksa.
- Gunakan delegate_agent untuk membahagikan kerja kompleks. Gabungkan hasil sub-agent dalam jawapan akhir.
- Jangan tukar provider atau model; gunakan pilihan pengguna.
- Hanya operasi destruktif akan dikendalikan oleh dialog kelulusan aplikasi.
- Jangan keluarkan chain-of-thought. UI memaparkan status operasi secara berasingan.

Tools tersedia: ${tools.map((item) => item.id).join(', ')}

Skills aktif:
$skillText
'''.trim();
  }

  ChatMessage _toolMessage(
    String sessionId,
    ToolCall call,
    ToolResult result,
  ) {
    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.tool,
      name: call.name,
      toolCallId: call.id,
      content: result.toModelText(),
      createdAt: DateTime.now(),
    );
  }

  Future<void> _logTool({
    required String sessionId,
    required String toolId,
    required String scope,
    required ToolResult result,
  }) async {
    await database.logTool(
      sessionId: sessionId,
      toolId: toolId,
      scope: scope,
      success: result.success,
      summary: _redactedSummary(result.output),
    );
  }

  String _redactedSummary(String value) {
    var text = value
        .replaceAll(
          RegExp(
            r'(api[_-]?key|authorization|token|secret|password)["\s:=]+[^,\s"}]+',
            caseSensitive: false,
          ),
          r'$1=[REDACTED]',
        )
        .replaceAll(
          RegExp(
            r'bearer\s+[A-Za-z0-9._~+/-]+=*',
            caseSensitive: false,
          ),
          'Bearer [REDACTED]',
        );
    if (text.length > 1200) text = '${text.substring(0, 1200)}…';
    return text;
  }

  void _collectArtifacts(
    Map<String, dynamic> data,
    List<ChatArtifact> output,
  ) {
    final rawArtifact = data['artifact'];
    if (rawArtifact is Map) {
      _addArtifact(
        ChatArtifact.fromJson(Map<String, dynamic>.from(rawArtifact)),
        output,
      );
    }
    for (final raw in data['artifacts'] as List? ?? const <dynamic>[]) {
      if (raw is Map) {
        _addArtifact(
          ChatArtifact.fromJson(Map<String, dynamic>.from(raw)),
          output,
        );
      }
    }
  }

  void _addArtifact(ChatArtifact artifact, List<ChatArtifact> output) {
    if (artifact.id.isEmpty || output.any((item) => item.id == artifact.id)) {
      return;
    }
    output.add(artifact);
  }

  void _emit(
    void Function(RunEvent event)? callback,
    RunEvent event,
  ) {
    callback?.call(event);
  }

  void _emitToolResult({
    required void Function(RunEvent event)? onEvent,
    required String eventId,
    required String title,
    required ToolResult result,
    required String agentName,
    String? toolId,
  }) {
    final detail = result.output.replaceAll(RegExp(r'\s+'), ' ').trim();
    _emit(
      onEvent,
      RunEvent(
        id: eventId,
        title: title,
        detail: detail.isEmpty
            ? (result.success ? 'Selesai' : 'Gagal')
            : (detail.length > 150 ? '${detail.substring(0, 150)}…' : detail),
        state: result.success ? RunEventState.success : RunEventState.failed,
        createdAt: DateTime.now(),
        toolId: toolId,
        agentRole: agentName,
      ),
    );
  }

  String _eventDetail(String toolId, Map<String, dynamic> arguments) {
    switch (toolId) {
      case 'web_search':
        return arguments['query']?.toString() ?? 'Carian web';
      case 'browser_open':
      case 'open_url':
        return arguments['url']?.toString() ?? 'Membuka halaman';
      case 'browser_download':
        return arguments['filename']?.toString() ??
            arguments['url']?.toString() ??
            'Memuat turun fail';
      case 'file_read':
      case 'file_write':
      case 'file_delete':
        return arguments['path']?.toString() ?? 'Workspace local';
      case 'terminal_start':
        final command = arguments['command']?.toString() ?? '';
        return command.length > 90 ? '${command.substring(0, 90)}…' : command;
      case 'delegate_agent':
        final task = arguments['task']?.toString() ?? '';
        return task.length > 120 ? '${task.substring(0, 120)}…' : task;
      default:
        return 'Berjalan di latar belakang';
    }
  }
}

extension _FirstWhereOrNull<E> on Iterable<E> {
  E? firstWhereOrNull(bool Function(E item) test) {
    for (final item in this) {
      if (test(item)) return item;
    }
    return null;
  }
}
