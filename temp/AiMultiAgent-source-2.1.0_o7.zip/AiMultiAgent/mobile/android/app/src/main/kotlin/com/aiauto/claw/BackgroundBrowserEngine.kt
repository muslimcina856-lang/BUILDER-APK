package com.aiauto.claw

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.atomic.AtomicBoolean

class BackgroundBrowserEngine(
    private val activity: Activity,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var pendingResult: MethodChannel.Result? = null
    private var pendingDone = AtomicBoolean(false)
    private var timeoutRunnable: Runnable? = null

    fun handle(call: MethodCall, result: MethodChannel.Result) {
        activity.runOnUiThread {
            try {
                when (call.method) {
                    "open" -> open(call.argument<String>("url").orEmpty(), result)
                    "read", "snapshot" -> snapshot(result)
                    "click" -> click(
                        selector = call.argument<String>("selector").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        result = result,
                    )
                    "fill" -> fill(
                        selector = call.argument<String>("selector").orEmpty(),
                        value = call.argument<String>("value").orEmpty(),
                        result = result,
                    )
                    "submit" -> submit(
                        selector = call.argument<String>("selector").orEmpty(),
                        result = result,
                    )
                    "back" -> navigate("back", result)
                    "forward" -> navigate("forward", result)
                    "reload" -> navigate("reload", result)
                    "clearCookies" -> clearCookies(result)
                    else -> result.notImplemented()
                }
            } catch (error: Throwable) {
                result.error("browser_error", error.message ?: error.javaClass.simpleName, null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView {
        val existing = webView
        if (existing != null) return existing

        val created = WebView(activity)
        created.setBackgroundColor(Color.TRANSPARENT)
        created.alpha = 0.01f
        created.translationX = -10000f
        created.translationY = -10000f
        created.layoutParams = ViewGroup.LayoutParams(2, 2)
        created.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            blockNetworkImage = false
            allowContentAccess = false
            allowFileAccess = false
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = "$userAgentString AiMultiAgent/2.1"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(created, true)
        }
        created.webChromeClient = WebChromeClient()
        created.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
            ): Boolean = false

            override fun onPageFinished(view: WebView, url: String) {
                if (pendingResult != null) {
                    mainHandler.postDelayed({ snapshotPending() }, 450L)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError,
            ) {
                if (request.isForMainFrame) {
                    finishError("load_error", error.description?.toString() ?: "Gagal memuat halaman")
                }
            }
        }
        val root = activity.window.decorView as? ViewGroup
        root?.addView(created)
        webView = created
        return created
    }

    private fun open(url: String, result: MethodChannel.Result) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            result.error("invalid_url", "URL HTTP/HTTPS tidak sah.", null)
            return
        }
        beginPending(result, 45_000L)
        ensureWebView().loadUrl(url)
    }

    private fun snapshot(result: MethodChannel.Result) {
        val view = ensureWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif dalam browser latar belakang.", null)
            return
        }
        beginPending(result, 20_000L)
        snapshotPending()
    }

    private fun click(selector: String, text: String, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val textJson = JSONObject.quote(text)
        val script = """
            (() => {
              const selector = $selectorJson;
              const wanted = $textJson.trim().toLowerCase();
              let element = selector ? document.querySelector(selector) : null;
              if (!element && wanted) {
                const nodes = Array.from(document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button]'));
                element = nodes.find((node) => ((node.innerText || node.value || node.getAttribute('aria-label') || '').trim().toLowerCase()).includes(wanted));
              }
              if (!element) return JSON.stringify({success:false,error:'Elemen tidak ditemui'});
              element.scrollIntoView({block:'center',inline:'center'});
              element.click();
              return JSON.stringify({success:true,action:'click'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 700L)
    }

    private fun fill(selector: String, value: String, result: MethodChannel.Result) {
        if (selector.isBlank()) {
            result.error("missing_selector", "CSS selector diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val valueJson = JSONObject.quote(value)
        val script = """
            (() => {
              const element = document.querySelector($selectorJson);
              if (!element) return JSON.stringify({success:false,error:'Input tidak ditemui'});
              const value = $valueJson;
              const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
              if (descriptor && descriptor.set) descriptor.set.call(element, value); else element.value = value;
              element.dispatchEvent(new Event('input', {bubbles:true}));
              element.dispatchEvent(new Event('change', {bubbles:true}));
              return JSON.stringify({success:true,action:'fill'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 150L)
    }

    private fun submit(selector: String, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val script = """
            (() => {
              const selector = $selectorJson;
              let form = selector ? document.querySelector(selector) : document.querySelector('form');
              if (form && form.tagName !== 'FORM') form = form.closest('form');
              if (!form) return JSON.stringify({success:false,error:'Borang tidak ditemui'});
              if (form.requestSubmit) form.requestSubmit(); else form.submit();
              return JSON.stringify({success:true,action:'submit'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 900L)
    }

    private fun navigate(action: String, result: MethodChannel.Result) {
        val view = ensureWebView()
        beginPending(result, 25_000L)
        when (action) {
            "back" -> if (view.canGoBack()) view.goBack() else snapshotPending()
            "forward" -> if (view.canGoForward()) view.goForward() else snapshotPending()
            else -> view.reload()
        }
    }

    private fun clearCookies(result: MethodChannel.Result) {
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            result.success(mapOf("success" to true))
        }
    }

    private fun evaluateAction(
        script: String,
        result: MethodChannel.Result,
        waitAfterMs: Long,
    ) {
        val view = ensureWebView()
        view.evaluateJavascript(script) { raw ->
            try {
                val actionResult = decodeJavascriptObject(raw)
                if (actionResult.optBoolean("success", false)) {
                    beginPending(result, 25_000L)
                    mainHandler.postDelayed({ snapshotPending() }, waitAfterMs)
                } else {
                    result.success(jsonObjectToMap(actionResult))
                }
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    private fun beginPending(result: MethodChannel.Result, timeoutMs: Long) {
        if (pendingResult != null) {
            finishError("browser_busy", "Browser sedang menyelesaikan tindakan sebelumnya.")
        }
        pendingResult = result
        pendingDone = AtomicBoolean(false)
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = Runnable {
            finishError("browser_timeout", "Browser latar belakang melebihi had masa.")
        }.also { mainHandler.postDelayed(it, timeoutMs) }
    }

    private fun snapshotPending() {
        val result = pendingResult ?: return
        val view = webView ?: run {
            finishError("browser_missing", "Enjin browser belum tersedia.")
            return
        }
        view.evaluateJavascript(SNAPSHOT_SCRIPT) { raw ->
            if (pendingDone.getAndSet(true)) return@evaluateJavascript
            try {
                val objectValue = decodeJavascriptObject(raw)
                val map = jsonObjectToMap(objectValue).toMutableMap()
                map["success"] = true
                map["engine"] = "android-system-webview-chromium"
                map["canGoBack"] = view.canGoBack()
                map["canGoForward"] = view.canGoForward()
                clearPending()
                result.success(map)
            } catch (error: Throwable) {
                clearPending()
                result.error("snapshot_error", error.message, null)
            }
        }
    }

    private fun finishError(code: String, message: String) {
        val result = pendingResult ?: return
        if (pendingDone.getAndSet(true)) return
        clearPending()
        result.error(code, message, null)
    }

    private fun clearPending() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        pendingResult = null
    }

    private fun decodeJavascriptObject(raw: String?): JSONObject {
        if (raw.isNullOrBlank() || raw == "null") return JSONObject()
        val first = JSONTokener(raw).nextValue()
        val jsonText = when (first) {
            is String -> first
            is JSONObject -> return first
            else -> first.toString()
        }
        return JSONObject(jsonText)
    }

    private fun jsonObjectToMap(value: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = jsonValue(value.opt(key))
        }
        return output
    }

    private fun jsonValue(value: Any?): Any? = when (value) {
        null, JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { jsonValue(value.opt(it)) }
        else -> value
    }

    fun destroy() {
        activity.runOnUiThread {
            timeoutRunnable?.let(mainHandler::removeCallbacks)
            timeoutRunnable = null
            pendingResult = null
            webView?.let { view ->
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.clearHistory()
                view.removeAllViews()
                view.destroy()
            }
            webView = null
        }
    }

    companion object {
        private val SNAPSHOT_SCRIPT = """
            (() => {
              const clean = (value) => (value || '').replace(/\s+/g, ' ').trim();
              const links = Array.from(document.querySelectorAll('a[href]')).slice(0, 160).map((node, index) => ({
                index,
                text: clean(node.innerText || node.getAttribute('aria-label') || ''),
                url: node.href || ''
              })).filter((item) => item.url);
              const forms = Array.from(document.forms).slice(0, 30).map((form, index) => ({
                index,
                id: form.id || '',
                name: form.name || '',
                action: form.action || location.href,
                method: (form.method || 'get').toUpperCase(),
                fields: Array.from(form.elements).slice(0, 80).map((field) => ({
                  tag: field.tagName ? field.tagName.toLowerCase() : '',
                  type: field.type || '',
                  name: field.name || '',
                  id: field.id || '',
                  placeholder: field.placeholder || '',
                  value: field.type === 'password' ? '[REDACTED]' : (field.value || '')
                }))
              }));
              const text = clean(document.body ? document.body.innerText : '').slice(0, 48000);
              const html = (document.documentElement ? document.documentElement.outerHTML : '').slice(0, 160000);
              return JSON.stringify({
                url: location.href,
                title: document.title || '',
                text,
                html,
                links,
                forms
              });
            })();
        """.trimIndent()
    }
}
