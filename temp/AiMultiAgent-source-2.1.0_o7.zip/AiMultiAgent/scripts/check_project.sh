#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

python3 scripts/verify_source.py
python3 scripts/test_duckduckgo_fixtures.py
python3 -m compileall -q scripts

for script in scripts/*.sh; do
  bash -n "$script"
done

if command -v flutter >/dev/null 2>&1; then
  pushd mobile >/dev/null
  flutter pub get
  dart format --output=none --set-exit-if-changed lib test
  flutter analyze
  flutter test
  popd >/dev/null
else
  echo "Flutter SDK tidak tersedia; analisis/build Flutter sebenar dilaksanakan oleh workflow CI yang disertakan."
fi
