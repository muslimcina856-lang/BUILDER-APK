#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if ! command -v flutter >/dev/null 2>&1; then
  echo "Ralat: Flutter SDK tidak ditemui." >&2
  exit 1
fi
"$ROOT/scripts/check_project.sh"
cd "$ROOT/mobile"
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
printf 'APK debug: %s\n' "$ROOT/mobile/build/app/outputs/flutter-apk/app-debug.apk"
