#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MOBILE="$ROOT/mobile"
DIST="$ROOT/dist"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Ralat: Flutter SDK tidak ditemui. Gunakan Flutter stable 3.44.x atau lebih baharu." >&2
  exit 1
fi

"$ROOT/scripts/check_project.sh"
mkdir -p "$DIST"
rm -f "$DIST"/*.apk "$DIST"/*.aab

pushd "$MOBILE" >/dev/null
flutter clean
flutter pub get
dart format --output=none --set-exit-if-changed lib test
flutter analyze
flutter test

# APK release sentiasa boleh dibina. Tanpa key.properties, Gradle menggunakan
# debug signing hanya untuk ujian pemasangan dan BUKAN untuk Play Store.
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk \
  "$DIST/AiMultiAgent-2.1.0-release.apk"

if [[ -f android/key.properties ]]; then
  flutter build appbundle --release
  cp build/app/outputs/bundle/release/app-release.aab \
    "$DIST/AiMultiAgent-2.1.0-release.aab"
  echo "AAB bertandatangan production turut dihasilkan."
else
  echo "Amaran: android/key.properties tiada. APK release ditandatangani dengan debug key untuk ujian sahaja." >&2
  echo "AAB Play Store dilangkau. Rujuk docs/KEYSTORE.md." >&2
fi
popd >/dev/null

(
  cd "$DIST"
  sha256sum ./* > SHA256SUMS.txt
)

echo "Build release selesai. Output: $DIST"
