# Room
-keep class androidx.room.** { *; }
-keep @androidx.room.Entity class * { *; }

# Compose
-keep class androidx.compose.** { *; }

# Google Play Services / Maps
-keep class com.google.android.gms.** { *; }

# Data models (dipakai untuk serialisasi sederhana)
-keep class com.ayonz.wifiinspector.domain.model.** { *; }
-keep class com.ayonz.wifiinspector.data.local.** { *; }
