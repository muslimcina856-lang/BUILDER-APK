package com.ayonz.wifiinspector.presentation.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Grafik garis ringan (Canvas manual, tanpa library berat) untuk memvisualisasikan
 * riwayat kekuatan sinyal (dBm) secara langsung dari waktu ke waktu.
 */
@Composable
fun SignalStrengthChart(
    values: List<Int>,
    modifier: Modifier = Modifier,
    lineColor: Color = MaterialTheme.colorScheme.primary,
    minDbm: Int = -100,
    maxDbm: Int = -30
) {
    val animatedProgress by animateFloatAsState(
        targetValue = if (values.isNotEmpty()) 1f else 0f,
        animationSpec = tween(600),
        label = "chartProgress"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(120.dp)) {
        if (values.size < 2) return@Canvas
        val w = size.width
        val h = size.height
        val stepX = w / (values.size - 1)

        fun yFor(v: Int): Float {
            val clamped = v.coerceIn(minDbm, maxDbm)
            val ratio = (clamped - minDbm).toFloat() / (maxDbm - minDbm)
            return h - (ratio * h)
        }

        // Garis grid horizontal halus
        val gridColor = lineColor.copy(alpha = 0.08f)
        for (i in 0..3) {
            val y = h * (i / 3f)
            drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
        }

        val path = Path()
        val fillPath = Path()
        values.forEachIndexed { index, v ->
            val x = index * stepX
            val y = yFor(v)
            if (index == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(w, h)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(listOf(lineColor.copy(alpha = 0.25f), Color.Transparent)),
            alpha = animatedProgress
        )
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.5.dp.toPx()),
            alpha = animatedProgress
        )

        // Titik terakhir menyala
        val lastX = (values.size - 1) * stepX
        val lastY = yFor(values.last())
        drawCircle(lineColor, radius = 4.dp.toPx(), center = Offset(lastX, lastY))
        drawCircle(lineColor.copy(alpha = 0.3f), radius = 9.dp.toPx(), center = Offset(lastX, lastY))
    }
}
