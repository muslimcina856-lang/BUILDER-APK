package com.ayonz.wifiinspector.presentation.navigation

sealed class Screen(val route: String, val label: String) {
    data object Scan : Screen("scan", "Scan")
    data object Connected : Screen("connected", "Koneksi")
    data object Map : Screen("map", "Peta")
    data object Tools : Screen("tools", "Alat")
    data object History : Screen("history", "Riwayat")
    data object Settings : Screen("settings", "Pengaturan")
    data object Detail : Screen("detail/{bssid}", "Detail") {
        fun createRoute(bssid: String) = "detail/${android.net.Uri.encode(bssid)}"
    }
    data object SpeedTest : Screen("speedtest", "Speed Test")
    data object PingTest : Screen("pingtest", "Ping Test")
}
