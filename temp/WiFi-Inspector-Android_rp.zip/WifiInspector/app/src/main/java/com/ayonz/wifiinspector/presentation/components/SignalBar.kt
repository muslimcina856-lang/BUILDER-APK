package com.ayonz.wifiinspector.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.domain.model.SignalQuality
import com.ayonz.wifiinspector.presentation.theme.qualityColor

/**
 * Ikon 4-bar bergaya sinyal WiFi, jumlah bar aktif ditentukan oleh persentase sinyal.
 */
@Composable
fun SignalBars(
    percent: Int,
    quality: SignalQuality,
    modifier: Modifier = Modifier,
    barCount: Int = 4
) {
    val activeColor = qualityColor(quality)
    val inactiveColor = activeColor.copy(alpha = 0.18f)
    val activeBars = ((percent / 100f) * barCount).let {
        if (percent > 0 && it < 1f) 1 else it.toInt()
    }.coerceIn(0, barCount)

    Canvas(modifier = modifier.width((barCount * 7).dp).height(20.dp)) {
        val barWidth = 4.dp.toPx()
        val gap = 3.dp.toPx()
        val maxHeight = size.height
        for (i in 0 until barCount) {
            val barHeight = maxHeight * ((i + 1) / barCount.toFloat())
            val color = if (i < activeBars) activeColor else inactiveColor
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (barWidth + gap), maxHeight - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }
    }
}

/**
 * Cincin melingkar menampilkan persentase sinyal (dipakai di layar detail/koneksi aktif).
 */
@Composable
fun SignalRing(
    percent: Int,
    color: Color,
    modifier: Modifier = Modifier,
    strokeWidth: androidx.compose.ui.unit.Dp = 8.dp
) {
    Canvas(modifier = modifier) {
        val stroke = Stroke(width = strokeWidth.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        drawArc(
            color = color.copy(alpha = 0.15f),
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            style = stroke
        )
        drawArc(
            color = color,
            startAngle = -90f,
            sweepAngle = 360f * (percent / 100f),
            useCenter = false,
            style = stroke
        )
    }
}
