package com.ayonz.wifiinspector.presentation.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.data.local.ThemeMode
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard

@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val themeMode by viewModel.themeMode.collectAsState()
    val autoRefresh by viewModel.autoRefreshEnabled.collectAsState()

    AnimatedBackground {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp, 24.dp, 20.dp, 24.dp)
        ) {
            Text("Pengaturan", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(
                "Sesuaikan tampilan dan perilaku aplikasi",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))

            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 4.dp) {
                Column {
                    Text(
                        "Tema Tampilan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 4.dp)
                    )
                    Column(Modifier.selectableGroup()) {
                        ThemeOption("Ikuti Sistem", ThemeMode.SYSTEM, themeMode, viewModel::setThemeMode)
                        ThemeOption("Mode Terang", ThemeMode.LIGHT, themeMode, viewModel::setThemeMode)
                        ThemeOption("Mode Gelap", ThemeMode.DARK, themeMode, viewModel::setThemeMode)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Refresh Otomatis", fontWeight = FontWeight.Medium)
                        Text(
                            "Perbarui daftar WiFi secara berkala",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = autoRefresh, onCheckedChange = viewModel::setAutoRefresh)
                }
            }

            Spacer(Modifier.height(14.dp))

            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
                Column {
                    Text("Tentang Aplikasi", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "WiFi Inspector v1.0.0 — dibangun dengan Kotlin & Jetpack Compose. " +
                            "Aplikasi ini hanya menggunakan API resmi Android untuk memindai WiFi dan " +
                            "tidak pernah mencoba meretas jaringan atau mengambil kata sandi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeOption(
    label: String,
    value: ThemeMode,
    selected: ThemeMode,
    onSelect: (ThemeMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(
                selected = selected == value,
                onClick = { onSelect(value) },
                role = Role.RadioButton
            )
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected == value, onClick = { onSelect(value) })
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}
