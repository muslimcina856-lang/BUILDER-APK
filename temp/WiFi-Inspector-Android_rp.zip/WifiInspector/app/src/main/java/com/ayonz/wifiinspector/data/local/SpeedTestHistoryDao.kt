package com.ayonz.wifiinspector.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SpeedTestHistoryDao {

    @Insert
    suspend fun insert(entity: SpeedTestHistoryEntity)

    @Query("SELECT * FROM speed_test_history ORDER BY timestampMillis DESC LIMIT 100")
    fun observeAll(): Flow<List<SpeedTestHistoryEntity>>

    @Query("DELETE FROM speed_test_history")
    suspend fun clearAll()
}
