package com.ayonz.wifiinspector.di

import android.content.Context
import com.ayonz.wifiinspector.data.local.PreferencesManager
import com.ayonz.wifiinspector.data.local.ScanHistoryDatabase
import com.ayonz.wifiinspector.data.repository.WifiRepositoryImpl
import com.ayonz.wifiinspector.data.source.ConnectedNetworkDataSource
import com.ayonz.wifiinspector.data.source.LocationDataSource
import com.ayonz.wifiinspector.data.source.PingDataSource
import com.ayonz.wifiinspector.data.source.SpeedTestDataSource
import com.ayonz.wifiinspector.data.source.WifiScanDataSource
import com.ayonz.wifiinspector.domain.repository.WifiRepository
import com.ayonz.wifiinspector.domain.usecase.ClearScanHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.ClearSpeedTestHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.GetConnectedNetworkUseCase
import com.ayonz.wifiinspector.domain.usecase.GetUserLocationUseCase
import com.ayonz.wifiinspector.domain.usecase.ObserveScanHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.ObserveSpeedTestHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.RunPingTestUseCase
import com.ayonz.wifiinspector.domain.usecase.RunSpeedTestUseCase
import com.ayonz.wifiinspector.domain.usecase.ScanWifiNetworksUseCase
import com.ayonz.wifiinspector.domain.usecase.SearchNetworksUseCase
import com.ayonz.wifiinspector.domain.usecase.SortNetworksBySignalUseCase

/**
 * Container dependency injection manual & ringan (menghindari kompleksitas Hilt/Dagger
 * yang tidak diperlukan untuk skala aplikasi ini, demi build yang stabil dan mudah dipahami).
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    private val wifiScanDataSource by lazy { WifiScanDataSource(appContext) }
    private val connectedNetworkDataSource by lazy { ConnectedNetworkDataSource(appContext) }
    private val locationDataSource by lazy { LocationDataSource(appContext) }
    private val speedTestDataSource by lazy { SpeedTestDataSource() }
    private val pingDataSource by lazy { PingDataSource() }
    private val scanHistoryDao by lazy { ScanHistoryDatabase.getInstance(appContext).scanHistoryDao() }
    private val speedTestHistoryDao by lazy { ScanHistoryDatabase.getInstance(appContext).speedTestHistoryDao() }

    val preferencesManager by lazy { PreferencesManager(appContext) }

    val wifiRepository: WifiRepository by lazy {
        WifiRepositoryImpl(
            wifiScanDataSource = wifiScanDataSource,
            connectedNetworkDataSource = connectedNetworkDataSource,
            locationDataSource = locationDataSource,
            speedTestDataSource = speedTestDataSource,
            pingDataSource = pingDataSource,
            scanHistoryDao = scanHistoryDao,
            speedTestHistoryDao = speedTestHistoryDao
        )
    }

    // Use cases
    val scanWifiNetworksUseCase by lazy { ScanWifiNetworksUseCase(wifiRepository) }
    val getConnectedNetworkUseCase by lazy { GetConnectedNetworkUseCase(wifiRepository) }
    val getUserLocationUseCase by lazy { GetUserLocationUseCase(wifiRepository) }
    val runSpeedTestUseCase by lazy { RunSpeedTestUseCase(wifiRepository) }
    val observeSpeedTestHistoryUseCase by lazy { ObserveSpeedTestHistoryUseCase(wifiRepository) }
    val clearSpeedTestHistoryUseCase by lazy { ClearSpeedTestHistoryUseCase(wifiRepository) }
    val runPingTestUseCase by lazy { RunPingTestUseCase(wifiRepository) }
    val observeScanHistoryUseCase by lazy { ObserveScanHistoryUseCase(wifiRepository) }
    val clearScanHistoryUseCase by lazy { ClearScanHistoryUseCase(wifiRepository) }
    val sortNetworksBySignalUseCase by lazy { SortNetworksBySignalUseCase() }
    val searchNetworksUseCase by lazy { SearchNetworksUseCase() }

    fun isWifiEnabled(): Boolean = wifiScanDataSource.isWifiEnabled()
}
