package com.ayonz.wifiinspector.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.ScanHistoryEntry
import com.ayonz.wifiinspector.domain.usecase.ClearScanHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.ObserveScanHistoryUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(
    observeScanHistoryUseCase: ObserveScanHistoryUseCase,
    private val clearScanHistoryUseCase: ClearScanHistoryUseCase
) : ViewModel() {

    val history: StateFlow<List<ScanHistoryEntry>> = observeScanHistoryUseCase()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun clearHistory() {
        viewModelScope.launch { clearScanHistoryUseCase() }
    }

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return HistoryViewModel(container.observeScanHistoryUseCase, container.clearScanHistoryUseCase) as T
            }
        }
    }
}
