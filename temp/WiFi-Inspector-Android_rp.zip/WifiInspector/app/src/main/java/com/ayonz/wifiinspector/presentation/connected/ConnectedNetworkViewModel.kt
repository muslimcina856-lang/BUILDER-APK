package com.ayonz.wifiinspector.presentation.connected

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.domain.usecase.GetConnectedNetworkUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class ConnectedNetworkViewModel(
    getConnectedNetworkUseCase: GetConnectedNetworkUseCase
) : ViewModel() {

    val connectedNetwork: StateFlow<ConnectedNetworkInfo?> = getConnectedNetworkUseCase()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ConnectedNetworkViewModel(container.getConnectedNetworkUseCase) as T
            }
        }
    }
}
