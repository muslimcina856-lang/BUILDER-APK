package com.ayonz.wifiinspector.domain.model

/**
 * Representasi bersih dari satu hasil scan jaringan WiFi.
 * Semua nilai berasal murni dari API resmi Android (android.net.wifi.ScanResult).
 */
data class WifiNetworkInfo(
    val ssid: String,
    val bssid: String,
    val signalLevelDbm: Int,
    val signalPercent: Int,
    val frequencyMhz: Int,
    val band: WifiBand,
    val channel: Int,
    val standard: WifiStandard,
    val security: SecurityType,
    val quality: SignalQuality,
    val isHiddenSsid: Boolean,
    val timestampMillis: Long
)

enum class WifiBand(val label: String) {
    GHZ_2_4("2.4 GHz"),
    GHZ_5("5 GHz"),
    GHZ_6("6 GHz"),
    UNKNOWN("Tidak diketahui")
}

enum class WifiStandard(val label: String) {
    LEGACY("802.11 a/b/g"),
    N("802.11n"),
    AC("802.11ac"),
    AX("802.11ax (WiFi 6)"),
    BE("802.11be (WiFi 7)"),
    UNKNOWN("Tidak diketahui")
}

enum class SecurityType(val label: String) {
    OPEN("Terbuka"),
    WEP("WEP"),
    WPA("WPA"),
    WPA2("WPA2"),
    WPA3("WPA3"),
    WPA2_WPA3("WPA2/WPA3"),
    ENTERPRISE("Enterprise (802.1x)"),
    UNKNOWN("Tidak diketahui")
}

enum class SignalQuality(val label: String) {
    SANGAT_LEMAH("Sangat Lemah"),
    LEMAH("Lemah"),
    SEDANG("Sedang"),
    BAIK("Baik"),
    SANGAT_BAIK("Sangat Baik");

    companion object {
        /**
         * Klasifikasi standar industri berbasis RSSI (dBm).
         */
        fun fromDbm(dbm: Int): SignalQuality = when {
            dbm >= -50 -> SANGAT_BAIK
            dbm >= -60 -> BAIK
            dbm >= -70 -> SEDANG
            dbm >= -80 -> LEMAH
            else -> SANGAT_LEMAH
        }
    }
}
