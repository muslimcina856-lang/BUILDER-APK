package com.ayonz.wifiinspector.domain.model

data class SpeedTestResult(
    val id: Long = 0,
    val downloadMbps: Double,
    val uploadMbps: Double,
    val pingMs: Long,
    val jitterMs: Long,
    val latencyMs: Long,
    val timestampMillis: Long
) {
    val downloadMBps: Double get() = downloadMbps / 8.0
    val uploadMBps: Double get() = uploadMbps / 8.0
}

/**
 * Event progres real-time yang dipancarkan selama speed test berjalan,
 * dipakai untuk animasi jarum speedometer & progress bar di UI.
 */
sealed class SpeedTestPhase {
    data object Idle : SpeedTestPhase()
    data object MeasuringPing : SpeedTestPhase()
    data class Downloading(val progress: Float, val currentMbps: Double) : SpeedTestPhase()
    data class Uploading(val progress: Float, val currentMbps: Double) : SpeedTestPhase()
    data class Completed(val result: SpeedTestResult) : SpeedTestPhase()
    data class Failed(val message: String) : SpeedTestPhase()
}

data class PingResult(
    val host: String,
    val successCount: Int,
    val failCount: Int,
    val minMs: Long,
    val maxMs: Long,
    val avgMs: Double,
    val packetLossPercent: Double,
    val samples: List<Long>
)

data class ScanHistoryEntry(
    val id: Long = 0,
    val timestampMillis: Long,
    val networkCount: Int,
    val strongestSsid: String?,
    val strongestDbm: Int?
)

data class UserLocation(
    val latitude: Double,
    val longitude: Double
)
