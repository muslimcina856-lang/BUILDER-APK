package com.ayonz.wifiinspector

import android.app.Application
import com.ayonz.wifiinspector.di.AppContainer

class WifiInspectorApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
