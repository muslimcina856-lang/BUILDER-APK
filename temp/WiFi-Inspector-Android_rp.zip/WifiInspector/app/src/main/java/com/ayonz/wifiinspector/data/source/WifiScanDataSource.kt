package com.ayonz.wifiinspector.data.source

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.ayonz.wifiinspector.data.mapper.WifiMapper
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Sumber data tunggal untuk memindai WiFi menggunakan android.net.wifi.WifiManager,
 * satu-satunya API resmi Android untuk keperluan ini. Tidak menggunakan reflection,
 * root, atau API tidak resmi apa pun.
 */
class WifiScanDataSource(private val context: Context) {

    private val wifiManager: WifiManager by lazy {
        context.applicationContext.getSystemService()!!
    }

    fun isWifiEnabled(): Boolean = wifiManager.isWifiEnabled

    /**
     * Memicu satu kali scan dan menunggu broadcast SCAN_RESULTS_AVAILABLE_ACTION resmi dari sistem,
     * lalu mengembalikan daftar hasil yang sudah dipetakan ke model domain.
     */
    suspend fun requestScan(): Result<List<WifiNetworkInfo>> = suspendCancellableCoroutine { cont ->
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val success = intent?.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) ?: false
                try {
                    context.applicationContext.unregisterReceiver(this)
                } catch (_: Exception) { /* sudah unregister */ }
                if (cont.isActive) {
                    cont.resume(readCurrentScanResults())
                }
            }
        }

        ContextCompat.registerReceiver(
            context.applicationContext,
            receiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        cont.invokeOnCancellation {
            try {
                context.applicationContext.unregisterReceiver(receiver)
            } catch (_: Exception) { }
        }

        val started = try {
            @Suppress("DEPRECATION")
            wifiManager.startScan()
        } catch (e: Exception) {
            false
        }

        if (!started) {
            // Beberapa perangkat membatasi frekuensi scan (throttling resmi Android).
            // Tetap kembalikan hasil scan terakhir yang tersedia di sistem.
            try {
                context.applicationContext.unregisterReceiver(receiver)
            } catch (_: Exception) { }
            if (cont.isActive) cont.resume(readCurrentScanResults())
        }
    }

    private fun readCurrentScanResults(): Result<List<WifiNetworkInfo>> {
        return try {
            val results = wifiManager.scanResults.orEmpty().map { WifiMapper.toDomain(it) }
            Result.success(results)
        } catch (e: SecurityException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Stream hasil scan yang otomatis diperbarui setiap kali sistem menyiarkan
     * SCAN_RESULTS_AVAILABLE_ACTION (misal karena scan berkala oleh OS).
     */
    fun observeScanResults(): Flow<List<WifiNetworkInfo>> = callbackFlow {
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                readCurrentScanResults().onSuccess { trySend(it) }
            }
        }
        ContextCompat.registerReceiver(
            context.applicationContext,
            receiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // Kirim hasil awal yang sudah ada di cache sistem.
        readCurrentScanResults().onSuccess { trySend(it) }

        awaitClose {
            try {
                context.applicationContext.unregisterReceiver(receiver)
            } catch (_: Exception) { }
        }
    }
}
