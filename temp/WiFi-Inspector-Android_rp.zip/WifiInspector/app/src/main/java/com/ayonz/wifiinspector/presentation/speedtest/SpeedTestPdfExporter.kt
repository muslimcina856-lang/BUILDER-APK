package com.ayonz.wifiinspector.presentation.speedtest

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Membuat laporan PDF sederhana dari hasil speed test memakai android.graphics.pdf.PdfDocument
 * (API resmi Android, tanpa library eksternal), lalu membagikannya lewat FileProvider.
 */
object SpeedTestPdfExporter {

    fun export(context: Context, result: SpeedTestResult): File {
        val pageWidth = 595 // A4 @ 72dpi
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.rgb(10, 14, 39)
            textSize = 24f
            isFakeBoldText = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(90, 90, 110)
            textSize = 12f
        }
        val labelPaint = Paint().apply {
            color = Color.rgb(60, 60, 80)
            textSize = 14f
        }
        val valuePaint = Paint().apply {
            color = Color.rgb(0, 150, 180)
            textSize = 14f
            isFakeBoldText = true
        }
        val linePaint = Paint().apply {
            color = Color.rgb(220, 220, 230)
            strokeWidth = 1f
        }

        var y = 60f
        canvas.drawText("WiFi Inspector — Laporan Speed Test", 40f, y, titlePaint)
        y += 22f
        val formatter = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID"))
        canvas.drawText("Dibuat pada ${formatter.format(Date(result.timestampMillis))}", 40f, y, subtitlePaint)
        y += 30f
        canvas.drawLine(40f, y, pageWidth - 40f, y, linePaint)
        y += 30f

        val rows = listOf(
            "Kecepatan Download" to "%.2f Mbps (%.2f MB/s)".format(result.downloadMbps, result.downloadMBps),
            "Kecepatan Upload" to "%.2f Mbps (%.2f MB/s)".format(result.uploadMbps, result.uploadMBps),
            "Ping" to "${result.pingMs} ms",
            "Jitter" to "${result.jitterMs} ms",
            "Latency" to "${result.latencyMs} ms"
        )

        rows.forEach { (label, value) ->
            canvas.drawText(label, 40f, y, labelPaint)
            canvas.drawText(value, 260f, y, valuePaint)
            y += 26f
        }

        y += 20f
        canvas.drawLine(40f, y, pageWidth - 40f, y, linePaint)
        y += 24f
        canvas.drawText(
            "Dibuat dengan WiFi Inspector oleh AYONZ",
            40f,
            y,
            subtitlePaint
        )

        document.finishPage(page)

        val fileName = "SpeedTest_${System.currentTimeMillis()}.pdf"
        val outputDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outputFile = File(outputDir, fileName)
        FileOutputStream(outputFile).use { document.writeTo(it) }
        document.close()

        return outputFile
    }

    fun getShareableUri(context: Context, file: File) =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
