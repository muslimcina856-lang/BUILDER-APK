package com.ayonz.wifiinspector.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = NeonCyan,
    onPrimary = SpaceBlack,
    secondary = NeonPurple,
    onSecondary = Color.White,
    tertiary = NeonPink,
    background = SpaceBlack,
    onBackground = Color(0xFFE8ECFB),
    surface = SurfaceDark1,
    onSurface = Color(0xFFE8ECFB),
    surfaceVariant = SurfaceDark2,
    onSurfaceVariant = Color(0xFFB8BFDE),
    error = NeonRed,
    outline = GlassStrokeDark
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0091B3),
    onPrimary = Color.White,
    secondary = Color(0xFF5B3DE0),
    onSecondary = Color.White,
    tertiary = Color(0xFFD6299E),
    background = CloudWhite,
    onBackground = Color(0xFF14172B),
    surface = SurfaceLight1,
    onSurface = Color(0xFF14172B),
    surfaceVariant = SurfaceLight2,
    onSurfaceVariant = Color(0xFF484F6E),
    error = Color(0xFFD1304B),
    outline = GlassStrokeLight
)

/**
 * Gradasi latar futuristik yang dipakai di seluruh layar (menyesuaikan tema).
 */
@Composable
fun backgroundGradient(darkTheme: Boolean): Brush {
    return if (darkTheme) {
        Brush.verticalGradient(listOf(SpaceBlack, DeepNavy, SurfaceDark1))
    } else {
        Brush.verticalGradient(listOf(CloudWhite, SurfaceLight2, CloudWhite))
    }
}

@Composable
fun glassStroke(darkTheme: Boolean): Color = if (darkTheme) GlassStrokeDark else GlassStrokeLight

/** Warna representatif untuk setiap level kualitas sinyal. */
fun qualityColor(quality: com.ayonz.wifiinspector.domain.model.SignalQuality): Color =
    when (quality) {
        com.ayonz.wifiinspector.domain.model.SignalQuality.SANGAT_BAIK -> QualitySangatBaik
        com.ayonz.wifiinspector.domain.model.SignalQuality.BAIK -> QualityBaik
        com.ayonz.wifiinspector.domain.model.SignalQuality.SEDANG -> QualitySedang
        com.ayonz.wifiinspector.domain.model.SignalQuality.LEMAH -> QualityLemah
        com.ayonz.wifiinspector.domain.model.SignalQuality.SANGAT_LEMAH -> QualitySangatLemah
    }

/** Warna representatif untuk jenis keamanan jaringan. */
fun securityColor(security: com.ayonz.wifiinspector.domain.model.SecurityType): Color =
    when (security) {
        com.ayonz.wifiinspector.domain.model.SecurityType.OPEN -> SecurityOpenColor
        com.ayonz.wifiinspector.domain.model.SecurityType.WEP,
        com.ayonz.wifiinspector.domain.model.SecurityType.WPA -> SecurityWeakColor
        else -> SecurityStrongColor
    }

@Composable
fun WifiInspectorTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colorScheme,
        typography = WifiInspectorTypography,
        shapes = WifiInspectorShapes,
        content = content
    )
}
