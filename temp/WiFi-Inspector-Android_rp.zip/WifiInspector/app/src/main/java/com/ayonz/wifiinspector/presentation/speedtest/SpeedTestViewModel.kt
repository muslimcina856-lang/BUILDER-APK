package com.ayonz.wifiinspector.presentation.speedtest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.SpeedTestPhase
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.domain.usecase.ClearSpeedTestHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.ObserveSpeedTestHistoryUseCase
import com.ayonz.wifiinspector.domain.usecase.RunSpeedTestUseCase
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SpeedTestStage { IDLE, PING, DOWNLOAD, UPLOAD, DONE, ERROR }

data class SpeedTestUiState(
    val stage: SpeedTestStage = SpeedTestStage.IDLE,
    val currentMbps: Double = 0.0,
    val progress: Float = 0f,
    val result: SpeedTestResult? = null,
    val errorMessage: String? = null
) {
    val isRunning: Boolean get() = stage != SpeedTestStage.IDLE && stage != SpeedTestStage.DONE && stage != SpeedTestStage.ERROR
}

class SpeedTestViewModel(
    private val runSpeedTestUseCase: RunSpeedTestUseCase,
    observeSpeedTestHistoryUseCase: ObserveSpeedTestHistoryUseCase,
    private val clearSpeedTestHistoryUseCase: ClearSpeedTestHistoryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpeedTestUiState())
    val uiState: StateFlow<SpeedTestUiState> = _uiState.asStateFlow()

    val history: StateFlow<List<SpeedTestResult>> = observeSpeedTestHistoryUseCase()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var testJob: Job? = null

    fun runTest() {
        if (_uiState.value.isRunning) return
        testJob?.cancel()
        testJob = viewModelScope.launch {
            runSpeedTestUseCase().collect { phase ->
                _uiState.update { current ->
                    when (phase) {
                        SpeedTestPhase.MeasuringPing -> current.copy(
                            stage = SpeedTestStage.PING,
                            currentMbps = 0.0,
                            progress = 0f,
                            errorMessage = null
                        )
                        is SpeedTestPhase.Downloading -> current.copy(
                            stage = SpeedTestStage.DOWNLOAD,
                            currentMbps = phase.currentMbps,
                            progress = phase.progress
                        )
                        is SpeedTestPhase.Uploading -> current.copy(
                            stage = SpeedTestStage.UPLOAD,
                            currentMbps = phase.currentMbps,
                            progress = phase.progress
                        )
                        is SpeedTestPhase.Completed -> current.copy(
                            stage = SpeedTestStage.DONE,
                            currentMbps = phase.result.downloadMbps,
                            progress = 1f,
                            result = phase.result
                        )
                        is SpeedTestPhase.Failed -> current.copy(
                            stage = SpeedTestStage.ERROR,
                            errorMessage = phase.message
                        )
                        SpeedTestPhase.Idle -> current.copy(stage = SpeedTestStage.IDLE)
                    }
                }
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch { clearSpeedTestHistoryUseCase() }
    }

    override fun onCleared() {
        super.onCleared()
        testJob?.cancel()
    }

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return SpeedTestViewModel(
                    container.runSpeedTestUseCase,
                    container.observeSpeedTestHistoryUseCase,
                    container.clearSpeedTestHistoryUseCase
                ) as T
            }
        }
    }
}
