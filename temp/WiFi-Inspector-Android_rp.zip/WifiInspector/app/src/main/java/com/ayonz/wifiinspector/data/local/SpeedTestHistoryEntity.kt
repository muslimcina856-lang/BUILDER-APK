package com.ayonz.wifiinspector.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.ayonz.wifiinspector.domain.model.SpeedTestResult

@Entity(tableName = "speed_test_history")
data class SpeedTestHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val downloadMbps: Double,
    val uploadMbps: Double,
    val pingMs: Long,
    val jitterMs: Long,
    val latencyMs: Long,
    val timestampMillis: Long
)

fun SpeedTestHistoryEntity.toDomain() = SpeedTestResult(
    id = id,
    downloadMbps = downloadMbps,
    uploadMbps = uploadMbps,
    pingMs = pingMs,
    jitterMs = jitterMs,
    latencyMs = latencyMs,
    timestampMillis = timestampMillis
)

fun SpeedTestResult.toEntity() = SpeedTestHistoryEntity(
    downloadMbps = downloadMbps,
    uploadMbps = uploadMbps,
    pingMs = pingMs,
    jitterMs = jitterMs,
    latencyMs = latencyMs,
    timestampMillis = timestampMillis
)
