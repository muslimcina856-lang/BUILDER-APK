package com.ayonz.wifiinspector.presentation.theme

import androidx.compose.ui.graphics.Color

// Palet futuristik utama — aksen cyan & ungu neon di atas latar gelap nyaris hitam.
val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF7C4DFF)
val NeonPink = Color(0xFFFF4FD8)
val NeonGreen = Color(0xFF00FFA3)
val NeonAmber = Color(0xFFFFC247)
val NeonRed = Color(0xFFFF5470)

// Dark theme surfaces
val SpaceBlack = Color(0xFF060714)
val DeepNavy = Color(0xFF0A0E27)
val SurfaceDark1 = Color(0xFF12162E)
val SurfaceDark2 = Color(0xFF1A1F3B)
val GlassStrokeDark = Color(0x33FFFFFF)

// Light theme surfaces
val CloudWhite = Color(0xFFF5F7FC)
val SurfaceLight1 = Color(0xFFFFFFFF)
val SurfaceLight2 = Color(0xFFEDF0F9)
val GlassStrokeLight = Color(0x33000000)

// Signal quality colors
val QualitySangatBaik = NeonGreen
val QualityBaik = Color(0xFF7CFFB2)
val QualitySedang = NeonAmber
val QualityLemah = Color(0xFFFF8A5C)
val QualitySangatLemah = NeonRed

// Security colors
val SecurityOpenColor = NeonRed
val SecurityWeakColor = NeonAmber
val SecurityStrongColor = NeonGreen
