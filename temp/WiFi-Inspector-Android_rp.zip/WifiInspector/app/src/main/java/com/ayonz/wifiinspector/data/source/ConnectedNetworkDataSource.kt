package com.ayonz.wifiinspector.data.source

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.getSystemService
import com.ayonz.wifiinspector.data.mapper.WifiMapper
import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.domain.model.WifiBand
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Membaca informasi jaringan WiFi yang sedang tersambung, murni memakai
 * WifiManager & ConnectivityManager resmi Android. Tidak ada akses ke perangkat lain.
 */
class ConnectedNetworkDataSource(private val context: Context) {

    private val wifiManager: WifiManager by lazy {
        context.applicationContext.getSystemService()!!
    }
    private val connectivityManager: ConnectivityManager by lazy {
        context.applicationContext.getSystemService()!!
    }

    fun observeConnectedNetwork(): Flow<ConnectedNetworkInfo> = callbackFlow {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(buildInfo(network))
            }

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                trySend(buildInfo(network))
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                trySend(buildInfo(network))
            }

            override fun onLost(network: Network) {
                trySend(disconnectedInfo())
            }
        }

        connectivityManager.registerDefaultNetworkCallback(callback)
        // Kirim status awal
        trySend(currentSnapshot())

        awaitClose { connectivityManager.unregisterNetworkCallback(callback) }
    }

    fun currentSnapshot(): ConnectedNetworkInfo {
        val network = connectivityManager.activeNetwork ?: return disconnectedInfo()
        return buildInfo(network)
    }

    private fun buildInfo(network: Network): ConnectedNetworkInfo {
        val capabilities = connectivityManager.getNetworkCapabilities(network)
        val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        if (!isWifi) return disconnectedInfo()

        val linkProperties = connectivityManager.getLinkProperties(network)
        val ipAddress = linkProperties?.linkAddresses
            ?.firstOrNull { it.address.hostAddress?.contains(":") == false }
            ?.address?.hostAddress
        val gateway = linkProperties?.routes
            ?.firstOrNull { it.isDefaultRoute }
            ?.gateway?.hostAddress
        val dnsServers = linkProperties?.dnsServers?.mapNotNull { it.hostAddress }.orEmpty()

        @Suppress("DEPRECATION")
        val wifiInfo = wifiManager.connectionInfo
        @Suppress("DEPRECATION")
        val rawSsid = wifiInfo?.ssid?.trim('"')
        val ssid = rawSsid?.takeIf { it.isNotBlank() && it != WifiManager.UNKNOWN_SSID }

        @Suppress("DEPRECATION")
        val bssid = wifiInfo?.bssid?.takeIf { it != "02:00:00:00:00:00" }
        @Suppress("DEPRECATION")
        val linkSpeed = wifiInfo?.linkSpeed
        @Suppress("DEPRECATION")
        val frequency = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) wifiInfo?.frequency else null
        @Suppress("DEPRECATION")
        val rssi = wifiInfo?.rssi

        return ConnectedNetworkInfo(
            isConnected = ssid != null,
            ssid = ssid,
            bssid = bssid,
            localIpAddress = ipAddress,
            gateway = gateway,
            dnsServers = dnsServers,
            linkSpeedMbps = linkSpeed,
            frequencyMhz = frequency,
            band = frequency?.let { WifiMapper.bandFromFrequency(it) } ?: WifiBand.UNKNOWN,
            signalLevelDbm = rssi,
            signalPercent = rssi?.let { WifiMapper.calculateSignalPercent(it) },
            quality = rssi?.let { com.ayonz.wifiinspector.domain.model.SignalQuality.fromDbm(it) }
        )
    }

    private fun disconnectedInfo() = ConnectedNetworkInfo(
        isConnected = false,
        ssid = null,
        bssid = null,
        localIpAddress = null,
        gateway = null,
        dnsServers = emptyList(),
        linkSpeedMbps = null,
        frequencyMhz = null,
        band = WifiBand.UNKNOWN,
        signalLevelDbm = null,
        signalPercent = null,
        quality = null
    )
}
