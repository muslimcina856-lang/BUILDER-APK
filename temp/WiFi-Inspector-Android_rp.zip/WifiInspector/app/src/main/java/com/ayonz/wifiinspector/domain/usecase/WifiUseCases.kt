package com.ayonz.wifiinspector.domain.usecase

import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.domain.model.PingResult
import com.ayonz.wifiinspector.domain.model.ScanHistoryEntry
import com.ayonz.wifiinspector.domain.model.SpeedTestPhase
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.domain.model.UserLocation
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.domain.repository.WifiRepository
import kotlinx.coroutines.flow.Flow

class ScanWifiNetworksUseCase(private val repository: WifiRepository) {
    suspend operator fun invoke(): Result<List<WifiNetworkInfo>> {
        val result = repository.scanNetworks()
        result.getOrNull()?.let { repository.saveScanToHistory(it) }
        return result
    }
}

class ObserveScanResultsUseCase(private val repository: WifiRepository) {
    operator fun invoke(): Flow<List<WifiNetworkInfo>> = repository.observeScanResults()
}

class GetConnectedNetworkUseCase(private val repository: WifiRepository) {
    operator fun invoke(): Flow<ConnectedNetworkInfo> = repository.observeConnectedNetwork()
}

class GetUserLocationUseCase(private val repository: WifiRepository) {
    suspend operator fun invoke(): Result<UserLocation> = repository.getUserLocation()
}

class RunSpeedTestUseCase(private val repository: WifiRepository) {
    operator fun invoke(): Flow<SpeedTestPhase> = repository.runSpeedTest()
}

class ObserveSpeedTestHistoryUseCase(private val repository: WifiRepository) {
    operator fun invoke(): Flow<List<SpeedTestResult>> = repository.observeSpeedTestHistory()
}

class ClearSpeedTestHistoryUseCase(private val repository: WifiRepository) {
    suspend operator fun invoke() = repository.clearSpeedTestHistory()
}

class RunPingTestUseCase(private val repository: WifiRepository) {
    suspend operator fun invoke(host: String, count: Int = 10): Result<PingResult> =
        repository.runPingTest(host, count)
}

class ObserveScanHistoryUseCase(private val repository: WifiRepository) {
    operator fun invoke(): Flow<List<ScanHistoryEntry>> = repository.observeScanHistory()
}

class ClearScanHistoryUseCase(private val repository: WifiRepository) {
    suspend operator fun invoke() = repository.clearHistory()
}

/**
 * Mengurutkan daftar jaringan berdasarkan sinyal terkuat (dBm tertinggi = terkuat).
 */
class SortNetworksBySignalUseCase {
    operator fun invoke(networks: List<WifiNetworkInfo>): List<WifiNetworkInfo> =
        networks.sortedByDescending { it.signalLevelDbm }
}

/**
 * Filter pencarian real-time berdasarkan SSID atau BSSID.
 */
class SearchNetworksUseCase {
    operator fun invoke(networks: List<WifiNetworkInfo>, query: String): List<WifiNetworkInfo> {
        if (query.isBlank()) return networks
        val q = query.trim().lowercase()
        return networks.filter {
            it.ssid.lowercase().contains(q) || it.bssid.lowercase().contains(q)
        }
    }
}
