package com.ayonz.wifiinspector.presentation.connected

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SignalWifiOff
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard
import com.ayonz.wifiinspector.presentation.components.SignalRing
import com.ayonz.wifiinspector.presentation.theme.qualityColor

@Composable
fun ConnectedNetworkScreen(viewModel: ConnectedNetworkViewModel) {
    val info by viewModel.connectedNetwork.collectAsState()

    AnimatedBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp, 24.dp, 20.dp, 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    "Jaringan Aktif",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Informasi WiFi yang sedang Anda gunakan",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            val current = info
            if (current == null || !current.isConnected) {
                item { NotConnectedCard() }
            } else {
                item { ConnectedHeaderCard(current) }
                item { ConnectionDetailsCard(current) }
            }
        }
    }
}

@Composable
private fun NotConnectedCard() {
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 28.dp) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.SignalWifiOff,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Text("Tidak Terhubung ke WiFi", style = MaterialTheme.typography.titleMedium)
            Text(
                "Sambungkan perangkat ke jaringan WiFi untuk melihat detailnya di sini.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ConnectedHeaderCard(info: ConnectedNetworkInfo) {
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 20.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val quality = info.quality
            val color = quality?.let { qualityColor(it) } ?: MaterialTheme.colorScheme.primary
            androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                SignalRing(percent = info.signalPercent ?: 0, color = color, modifier = Modifier.size(72.dp))
                Icon(Icons.Filled.Wifi, contentDescription = null, tint = color)
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    info.ssid ?: "-",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    quality?.label ?: "Kualitas tidak diketahui",
                    style = MaterialTheme.typography.bodyMedium,
                    color = color
                )
                info.signalLevelDbm?.let {
                    Text(
                        "$it dBm • ${info.signalPercent}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ConnectionDetailsCard(info: ConnectedNetworkInfo) {
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 4.dp) {
        Column {
            InfoRow("BSSID", info.bssid ?: "-")
            InfoRow("Alamat IP Lokal", info.localIpAddress ?: "-")
            InfoRow("Gateway", info.gateway ?: "-")
            InfoRow("DNS", if (info.dnsServers.isNotEmpty()) info.dnsServers.joinToString(", ") else "-")
            InfoRow("Kecepatan Link", info.linkSpeedMbps?.let { "$it Mbps" } ?: "-")
            InfoRow("Frekuensi", info.frequencyMhz?.let { "$it MHz" } ?: "-")
            InfoRow("Band WiFi", info.band.label, isLast = true)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, isLast: Boolean = false) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            Text(
                value,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.End,
                modifier = Modifier.padding(start = 12.dp)
            )
        }
        if (!isLast) HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    }
}
