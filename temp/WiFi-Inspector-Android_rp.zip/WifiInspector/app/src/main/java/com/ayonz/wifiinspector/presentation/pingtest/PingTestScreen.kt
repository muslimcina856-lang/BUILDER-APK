package com.ayonz.wifiinspector.presentation.pingtest

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard

private val quickHosts = listOf("8.8.8.8" to "Google DNS", "1.1.1.1" to "Cloudflare", "9.9.9.9" to "Quad9")

@Composable
fun PingTestScreen(viewModel: PingTestViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    AnimatedBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp, 24.dp, 20.dp, 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Ping Test", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    "Ukur latensi koneksi ke server pilihan",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                OutlinedTextField(
                    value = uiState.host,
                    onValueChange = viewModel::onHostChange,
                    label = { Text("Alamat Host / IP") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = MaterialTheme.shapes.large
                )
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(quickHosts) { (host, label) ->
                        androidx.compose.material3.AssistChip(
                            onClick = { viewModel.onHostChange(host) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = { viewModel.runTest() },
                    enabled = !uiState.isRunning,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(if (uiState.isRunning) "Mengirim paket..." else "Mulai Ping Test")
                }
            }

            if (uiState.errorMessage != null) {
                item {
                    Text(uiState.errorMessage.orEmpty(), color = MaterialTheme.colorScheme.error)
                }
            }

            uiState.result?.let { result ->
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 18.dp) {
                        Column {
                            Text(
                                "Hasil untuk ${result.host}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(10.dp))
                            StatRow("Rata-rata", "%.0f ms".format(result.avgMs))
                            StatRow("Minimum", "${result.minMs} ms")
                            StatRow("Maksimum", "${result.maxMs} ms")
                            StatRow("Paket Berhasil", "${result.successCount}/${result.successCount + result.failCount}")
                            StatRow("Packet Loss", "%.0f%%".format(result.packetLossPercent))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
