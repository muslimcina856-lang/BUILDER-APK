package com.ayonz.wifiinspector.presentation.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.ayonz.wifiinspector.presentation.pingtest.PingTestScreen
import com.ayonz.wifiinspector.presentation.pingtest.PingTestViewModel
import com.ayonz.wifiinspector.presentation.speedtest.SpeedTestScreen
import com.ayonz.wifiinspector.presentation.speedtest.SpeedTestViewModel

@Composable
fun ToolsScreen(
    speedTestViewModel: SpeedTestViewModel,
    pingTestViewModel: PingTestViewModel
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val titles = listOf("Speed Test", "Ping Test")

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ) {
            titles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }
        if (selectedTab == 0) SpeedTestScreen(speedTestViewModel) else PingTestScreen(pingTestViewModel)
    }
}
