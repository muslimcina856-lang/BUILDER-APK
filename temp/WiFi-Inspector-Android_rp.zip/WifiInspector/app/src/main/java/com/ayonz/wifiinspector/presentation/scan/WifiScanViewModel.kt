package com.ayonz.wifiinspector.presentation.scan

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.domain.usecase.ScanWifiNetworksUseCase
import com.ayonz.wifiinspector.domain.usecase.SearchNetworksUseCase
import com.ayonz.wifiinspector.domain.usecase.SortNetworksBySignalUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WifiScanUiState(
    val isScanning: Boolean = false,
    val networks: List<WifiNetworkInfo> = emptyList(),
    val filteredNetworks: List<WifiNetworkInfo> = emptyList(),
    val query: String = "",
    val errorMessage: String? = null,
    val hasScannedOnce: Boolean = false,
    val isWifiEnabled: Boolean = true
)

class WifiScanViewModel(
    private val scanWifiNetworksUseCase: ScanWifiNetworksUseCase,
    private val sortNetworksBySignalUseCase: SortNetworksBySignalUseCase,
    private val searchNetworksUseCase: SearchNetworksUseCase,
    private val isWifiEnabled: () -> Boolean
) : ViewModel() {

    private val _uiState = MutableStateFlow(WifiScanUiState())
    val uiState: StateFlow<WifiScanUiState> = _uiState.asStateFlow()

    /** Riwayat sinyal jaringan terpilih untuk grafik langsung (SSID -> daftar dBm). */
    private val signalHistory = mutableMapOf<String, MutableList<Int>>()

    fun scan() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true, errorMessage = null, isWifiEnabled = isWifiEnabled()) }
            val result = scanWifiNetworksUseCase()
            result.onSuccess { networks ->
                val sorted = sortNetworksBySignalUseCase(networks)
                sorted.forEach { net ->
                    val history = signalHistory.getOrPut(net.bssid) { mutableListOf() }
                    history.add(net.signalLevelDbm)
                    if (history.size > 20) history.removeAt(0)
                }
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        networks = sorted,
                        filteredNetworks = searchNetworksUseCase(sorted, it.query),
                        hasScannedOnce = true
                    )
                }
            }.onFailure { e ->
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        hasScannedOnce = true,
                        errorMessage = e.message ?: "Gagal memindai jaringan WiFi."
                    )
                }
            }
        }
    }

    fun onQueryChange(query: String) {
        _uiState.update {
            it.copy(query = query, filteredNetworks = searchNetworksUseCase(it.networks, query))
        }
    }

    fun signalHistoryFor(bssid: String): List<Int> = signalHistory[bssid].orEmpty()

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return WifiScanViewModel(
                    container.scanWifiNetworksUseCase,
                    container.sortNetworksBySignalUseCase,
                    container.searchNetworksUseCase,
                    container::isWifiEnabled
                ) as T
            }
        }
    }
}
