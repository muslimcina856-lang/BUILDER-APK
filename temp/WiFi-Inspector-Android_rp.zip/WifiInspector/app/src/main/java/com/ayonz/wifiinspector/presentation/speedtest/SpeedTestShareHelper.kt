package com.ayonz.wifiinspector.presentation.speedtest

import android.content.Context
import android.content.Intent
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import java.io.File

object SpeedTestShareHelper {

    fun shareSummary(context: Context, result: SpeedTestResult) {
        val text = buildString {
            appendLine("📶 Hasil Speed Test — WiFi Inspector")
            appendLine("Download: %.2f Mbps (%.2f MB/s)".format(result.downloadMbps, result.downloadMBps))
            appendLine("Upload: %.2f Mbps (%.2f MB/s)".format(result.uploadMbps, result.uploadMBps))
            appendLine("Ping: ${result.pingMs} ms")
            appendLine("Jitter: ${result.jitterMs} ms")
            appendLine("Latency: ${result.latencyMs} ms")
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Hasil Speed Test"))
    }

    fun sharePdf(context: Context, file: File) {
        val uri = SpeedTestPdfExporter.getShareableUri(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Laporan PDF"))
    }
}
