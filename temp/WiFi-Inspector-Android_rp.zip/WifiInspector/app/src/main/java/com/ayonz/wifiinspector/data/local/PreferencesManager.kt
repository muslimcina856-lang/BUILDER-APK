package com.ayonz.wifiinspector.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "wifi_inspector_prefs")

enum class ThemeMode { LIGHT, DARK, SYSTEM }

class PreferencesManager(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val autoRefreshKey = booleanPreferencesKey("auto_refresh")

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        when (prefs[themeKey]) {
            ThemeMode.LIGHT.name -> ThemeMode.LIGHT
            ThemeMode.DARK.name -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    val autoRefreshEnabled: Flow<Boolean> = context.dataStore.data.map { it[autoRefreshKey] ?: true }

    suspend fun setAutoRefresh(enabled: Boolean) {
        context.dataStore.edit { it[autoRefreshKey] = enabled }
    }
}
