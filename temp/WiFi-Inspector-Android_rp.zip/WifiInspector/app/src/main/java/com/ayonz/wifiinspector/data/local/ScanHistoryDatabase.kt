package com.ayonz.wifiinspector.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [ScanHistoryEntity::class, SpeedTestHistoryEntity::class],
    version = 2,
    exportSchema = false
)
abstract class ScanHistoryDatabase : RoomDatabase() {
    abstract fun scanHistoryDao(): ScanHistoryDao
    abstract fun speedTestHistoryDao(): SpeedTestHistoryDao

    companion object {
        @Volatile private var instance: ScanHistoryDatabase? = null

        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `speed_test_history` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `downloadMbps` REAL NOT NULL,
                        `uploadMbps` REAL NOT NULL,
                        `pingMs` INTEGER NOT NULL,
                        `jitterMs` INTEGER NOT NULL,
                        `latencyMs` INTEGER NOT NULL,
                        `timestampMillis` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): ScanHistoryDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    ScanHistoryDatabase::class.java,
                    "wifi_inspector_history.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    // Cadangan jika migrasi gagal pada perangkat lama agar aplikasi tidak crash.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
