package com.ayonz.wifiinspector.presentation.pingtest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.PingResult
import com.ayonz.wifiinspector.domain.usecase.RunPingTestUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PingTestUiState(
    val host: String = "8.8.8.8",
    val isRunning: Boolean = false,
    val result: PingResult? = null,
    val errorMessage: String? = null
)

class PingTestViewModel(
    private val runPingTestUseCase: RunPingTestUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(PingTestUiState())
    val uiState: StateFlow<PingTestUiState> = _uiState.asStateFlow()

    fun onHostChange(host: String) {
        _uiState.update { it.copy(host = host) }
    }

    fun runTest() {
        if (_uiState.value.isRunning) return
        val host = _uiState.value.host.trim().ifBlank { "8.8.8.8" }
        viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, errorMessage = null) }
            runPingTestUseCase(host, 10)
                .onSuccess { result -> _uiState.update { it.copy(isRunning = false, result = result) } }
                .onFailure { e ->
                    _uiState.update {
                        it.copy(isRunning = false, errorMessage = e.message ?: "Ping test gagal dijalankan.")
                    }
                }
        }
    }

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return PingTestViewModel(container.runPingTestUseCase) as T
            }
        }
    }
}
