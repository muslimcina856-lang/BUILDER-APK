package com.ayonz.wifiinspector.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Kartu bergaya glassmorphism: latar semi-transparan berlapis gradasi tipis + border halus.
 * Dipakai sebagai fondasi visual di hampir semua layar aplikasi.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    contentPadding: Dp = 16.dp,
    content: @Composable () -> Unit
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val shape = RoundedCornerShape(cornerRadius)

    val fillBrush = if (dark) {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.02f)))
    } else {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.45f)))
    }
    val borderColor = if (dark) Color.White.copy(alpha = 0.14f) else Color.White.copy(alpha = 0.6f)

    Box(
        modifier = modifier
            .clip(shape)
            .background(fillBrush)
            .border(1.dp, borderColor, shape)
            .padding(contentPadding)
    ) {
        content()
    }
}

@Composable
fun sectionTitleColor() = MaterialTheme.colorScheme.onSurfaceVariant
