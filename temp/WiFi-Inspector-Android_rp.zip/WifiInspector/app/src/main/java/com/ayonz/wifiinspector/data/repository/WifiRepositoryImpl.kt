package com.ayonz.wifiinspector.data.repository

import com.ayonz.wifiinspector.data.local.ScanHistoryDao
import com.ayonz.wifiinspector.data.local.ScanHistoryEntity
import com.ayonz.wifiinspector.data.local.SpeedTestHistoryDao
import com.ayonz.wifiinspector.data.local.toDomain
import com.ayonz.wifiinspector.data.local.toEntity
import com.ayonz.wifiinspector.data.source.ConnectedNetworkDataSource
import com.ayonz.wifiinspector.data.source.LocationDataSource
import com.ayonz.wifiinspector.data.source.PingDataSource
import com.ayonz.wifiinspector.data.source.SpeedTestDataSource
import com.ayonz.wifiinspector.data.source.WifiScanDataSource
import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.domain.model.PingResult
import com.ayonz.wifiinspector.domain.model.ScanHistoryEntry
import com.ayonz.wifiinspector.domain.model.SpeedTestPhase
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.domain.model.UserLocation
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.domain.repository.WifiRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach

class WifiRepositoryImpl(
    private val wifiScanDataSource: WifiScanDataSource,
    private val connectedNetworkDataSource: ConnectedNetworkDataSource,
    private val locationDataSource: LocationDataSource,
    private val speedTestDataSource: SpeedTestDataSource,
    private val pingDataSource: PingDataSource,
    private val scanHistoryDao: ScanHistoryDao,
    private val speedTestHistoryDao: SpeedTestHistoryDao
) : WifiRepository {

    override suspend fun scanNetworks(): Result<List<WifiNetworkInfo>> =
        wifiScanDataSource.requestScan()

    override fun observeScanResults(): Flow<List<WifiNetworkInfo>> =
        wifiScanDataSource.observeScanResults()

    override fun observeConnectedNetwork(): Flow<ConnectedNetworkInfo> =
        connectedNetworkDataSource.observeConnectedNetwork()

    override suspend fun getUserLocation(): Result<UserLocation> =
        locationDataSource.getCurrentLocation()

    override fun runSpeedTest(): Flow<SpeedTestPhase> =
        speedTestDataSource.runSpeedTest().onEach { phase ->
            if (phase is SpeedTestPhase.Completed) {
                speedTestHistoryDao.insert(phase.result.toEntity())
            }
        }

    override fun observeSpeedTestHistory(): Flow<List<SpeedTestResult>> =
        speedTestHistoryDao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun clearSpeedTestHistory() = speedTestHistoryDao.clearAll()

    override suspend fun runPingTest(host: String, count: Int): Result<PingResult> =
        pingDataSource.ping(host, count)

    override fun observeScanHistory(): Flow<List<ScanHistoryEntry>> =
        scanHistoryDao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun saveScanToHistory(networks: List<WifiNetworkInfo>) {
        if (networks.isEmpty()) return
        val strongest = networks.maxByOrNull { it.signalLevelDbm }
        scanHistoryDao.insert(
            ScanHistoryEntity(
                timestampMillis = System.currentTimeMillis(),
                networkCount = networks.size,
                strongestSsid = strongest?.ssid,
                strongestDbm = strongest?.signalLevelDbm
            )
        )
    }

    override suspend fun clearHistory() = scanHistoryDao.clearAll()
}
