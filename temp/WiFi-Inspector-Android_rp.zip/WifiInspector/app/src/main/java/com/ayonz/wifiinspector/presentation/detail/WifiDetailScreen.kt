package com.ayonz.wifiinspector.presentation.detail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard
import com.ayonz.wifiinspector.presentation.components.SignalRing
import com.ayonz.wifiinspector.presentation.components.SignalStrengthChart
import com.ayonz.wifiinspector.presentation.theme.qualityColor
import com.ayonz.wifiinspector.presentation.theme.securityColor

@Composable
fun WifiDetailScreen(
    network: WifiNetworkInfo?,
    signalHistory: List<Int>,
    onBack: () -> Unit
) {
    AnimatedBackground {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.padding(12.dp, 16.dp, 12.dp, 0.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                }
                Text(
                    "Detail Jaringan",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (network == null) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Jaringan tidak ditemukan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                return@AnimatedBackground
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp, 12.dp, 20.dp, 40.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 20.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                                SignalRing(
                                    percent = network.signalPercent,
                                    color = qualityColor(network.quality),
                                    modifier = Modifier.size(120.dp)
                                )
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "${network.signalPercent}%",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        network.quality.label,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = qualityColor(network.quality)
                                    )
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text(
                                network.ssid,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                network.bssid,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item {
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
                        Column {
                            Text(
                                "Grafik Sinyal Langsung",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(8.dp))
                            if (signalHistory.size >= 2) {
                                SignalStrengthChart(
                                    values = signalHistory,
                                    lineColor = qualityColor(network.quality)
                                )
                            } else {
                                Text(
                                    "Pindai beberapa kali untuk melihat tren sinyal dari waktu ke waktu.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                item {
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 4.dp) {
                        Column {
                            DetailRow("Kekuatan Sinyal", "${network.signalLevelDbm} dBm (${network.signalPercent}%)")
                            DetailRow("Frekuensi", "${network.frequencyMhz} MHz (${network.band.label})")
                            DetailRow("Channel", network.channel.takeIf { it > 0 }?.toString() ?: "-")
                            DetailRow("Standar WiFi", network.standard.label)
                            DetailRow(
                                "Keamanan",
                                network.security.label,
                                valueColor = securityColor(network.security)
                            )
                            DetailRow("SSID Tersembunyi", if (network.isHiddenSsid) "Ya" else "Tidak", isLast = true)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
    isLast: Boolean = false
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            Text(value, color = valueColor, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
        }
        if (!isLast) {
            androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        }
    }
}
