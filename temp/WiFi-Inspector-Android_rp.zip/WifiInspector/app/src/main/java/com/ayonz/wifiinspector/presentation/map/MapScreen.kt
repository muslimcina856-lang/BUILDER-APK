package com.ayonz.wifiinspector.presentation.map

import android.Manifest
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MapScreen(container: AppContainer) {
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)
    val scope = rememberCoroutineScope()

    var userLatLng by remember { mutableStateOf<LatLng?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-2.5, 118.0), 4f) // default: tengah Indonesia
    }

    fun loadLocation() {
        scope.launch {
            isLoading = true
            errorMessage = null
            container.getUserLocationUseCase().onSuccess { loc ->
                val latLng = LatLng(loc.latitude, loc.longitude)
                userLatLng = latLng
                cameraPositionState.position = CameraPosition.fromLatLngZoom(latLng, 16f)
            }.onFailure {
                errorMessage = it.message ?: "Gagal mendapatkan lokasi."
            }
            isLoading = false
        }
    }

    LaunchedEffect(locationPermission.status.isGranted) {
        if (locationPermission.status.isGranted) loadLocation()
    }

    AnimatedBackground {
        if (!locationPermission.status.isGranted) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 24.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.MyLocation, contentDescription = null, modifier = Modifier.size(48.dp))
                        Text(
                            "Izin lokasi diperlukan untuk menampilkan posisi Anda di peta.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                        androidx.compose.material3.Button(
                            onClick = { locationPermission.launchPermissionRequest() },
                            modifier = Modifier.padding(top = 16.dp).fillMaxWidth()
                        ) { Text("Izinkan Lokasi") }
                    }
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                GoogleMap(
                    modifier = Modifier.fillMaxSize(),
                    cameraPositionState = cameraPositionState,
                    properties = MapProperties(isMyLocationEnabled = true),
                    uiSettings = MapUiSettings(zoomControlsEnabled = false, myLocationButtonEnabled = false)
                ) {
                    userLatLng?.let {
                        Marker(state = MarkerState(position = it), title = "Lokasi Anda")
                    }
                }

                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }

                errorMessage?.let { msg ->
                    Box(modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)) {
                        GlassCard { Text(msg, color = MaterialTheme.colorScheme.error) }
                    }
                }

                FloatingActionButton(
                    onClick = { loadLocation() },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
                ) {
                    Icon(Icons.Filled.MyLocation, contentDescription = "Lokasi Saya")
                }
            }
        }
    }
}
