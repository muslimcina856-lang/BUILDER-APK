package com.ayonz.wifiinspector.data.source

import android.annotation.SuppressLint
import android.content.Context
import com.ayonz.wifiinspector.domain.model.UserLocation
import com.google.android.gms.location.CurrentLocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Mengambil lokasi pengguna melalui FusedLocationProviderClient (Google Play Services,
 * API resmi). Hanya dipanggil setelah izin lokasi diberikan pengguna.
 */
class LocationDataSource(private val context: Context) {

    private val client by lazy { LocationServices.getFusedLocationProviderClient(context.applicationContext) }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): Result<UserLocation> = suspendCancellableCoroutine { cont ->
        val request = CurrentLocationRequest.Builder()
            .setPriority(Priority.PRIORITY_BALANCED_POWER_ACCURACY)
            .build()
        client.getCurrentLocation(request, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    cont.resume(Result.success(UserLocation(location.latitude, location.longitude)))
                } else {
                    cont.resume(Result.failure(IllegalStateException("Lokasi tidak tersedia. Pastikan GPS aktif.")))
                }
            }
            .addOnFailureListener { e ->
                cont.resume(Result.failure(e))
            }
    }
}
