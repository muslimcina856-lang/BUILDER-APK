package com.ayonz.wifiinspector.data.source

import com.ayonz.wifiinspector.domain.model.PingResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Ping test tanpa root: mengukur waktu tempuh koneksi TCP (connect latency) ke host tujuan,
 * pendekatan standar untuk aplikasi non-root karena ICMP mentah butuh hak akses khusus di Android.
 * Hanya menghubungi host yang secara eksplisit dipilih pengguna (mis. 8.8.8.8 / server publik),
 * tidak pernah mengakses perangkat lain di jaringan lokal tanpa izin.
 */
class PingDataSource {

    suspend fun ping(host: String, count: Int = 10, port: Int = 443): Result<PingResult> =
        withContext(Dispatchers.IO) {
            val samples = mutableListOf<Long>()
            var success = 0
            var fail = 0

            repeat(count) {
                val time = pingOnce(host, port)
                if (time >= 0) {
                    samples.add(time)
                    success++
                } else {
                    fail++
                }
            }

            if (samples.isEmpty()) {
                return@withContext Result.failure(
                    IllegalStateException("Tidak dapat menjangkau $host. Periksa koneksi internet.")
                )
            }

            Result.success(
                PingResult(
                    host = host,
                    successCount = success,
                    failCount = fail,
                    minMs = samples.min(),
                    maxMs = samples.max(),
                    avgMs = samples.average(),
                    packetLossPercent = (fail.toDouble() / count) * 100,
                    samples = samples
                )
            )
        }

    private fun pingOnce(host: String, port: Int): Long {
        return try {
            val socket = Socket()
            val start = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), 3000)
            val elapsed = (System.nanoTime() - start) / 1_000_000
            socket.close()
            elapsed
        } catch (e: Exception) {
            -1L
        }
    }
}
