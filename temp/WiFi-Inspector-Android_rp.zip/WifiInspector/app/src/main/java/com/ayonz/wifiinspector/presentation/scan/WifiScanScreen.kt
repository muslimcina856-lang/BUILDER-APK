package com.ayonz.wifiinspector.presentation.scan

import android.Manifest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard
import com.ayonz.wifiinspector.presentation.components.NetworkListItem
import com.ayonz.wifiinspector.presentation.components.WifiSearchBar
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.shouldShowRationale

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WifiScanScreen(
    viewModel: WifiScanViewModel,
    onNetworkClick: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    LaunchedEffect(permissionsState.allPermissionsGranted) {
        if (permissionsState.allPermissionsGranted && !uiState.hasScannedOnce) {
            viewModel.scan()
        }
    }

    AnimatedBackground {
        if (!permissionsState.allPermissionsGranted) {
            PermissionRequestContent(
                showRationale = permissionsState.shouldShowRationale,
                onRequestPermission = { permissionsState.launchMultiplePermissionRequest() }
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.padding(20.dp, 20.dp, 20.dp, 8.dp)) {
                        Text(
                            "WiFi Inspector",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            "${uiState.filteredNetworks.size} jaringan ditemukan di sekitar Anda",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(14.dp))
                        WifiSearchBar(query = uiState.query, onQueryChange = viewModel::onQueryChange)
                    }

                    if (uiState.errorMessage != null) {
                        GlassCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                            Text(
                                uiState.errorMessage.orEmpty(),
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    when {
                        uiState.isScanning && uiState.networks.isEmpty() -> LoadingState()
                        uiState.filteredNetworks.isEmpty() && uiState.hasScannedOnce -> EmptyState(uiState.query.isNotEmpty())
                        else -> {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(20.dp, 4.dp, 20.dp, 100.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(uiState.filteredNetworks, key = { it.bssid }) { network ->
                                    NetworkListItem(network = network, onClick = { onNetworkClick(network.bssid) })
                                }
                            }
                        }
                    }
                }

                ExtendedFloatingActionButton(
                    onClick = { viewModel.scan() },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
                    icon = {
                        if (uiState.isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Wifi, contentDescription = null)
                        }
                    },
                    text = { Text(if (uiState.isScanning) "Memindai..." else "Pindai Ulang") }
                )
            }
        }
    }
}

@Composable
private fun LoadingState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("Memindai jaringan WiFi di sekitar...", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun EmptyState(isSearching: Boolean) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Filled.WifiOff,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Text(
                if (isSearching) "Tidak ada jaringan yang cocok" else "Belum ada jaringan ditemukan",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
private fun PermissionRequestContent(showRationale: Boolean, onRequestPermission: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 24.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Filled.Wifi,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "Izin Lokasi Diperlukan",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (showRationale)
                        "Android mewajibkan izin lokasi agar aplikasi dapat membaca daftar jaringan WiFi di sekitar. Data lokasi Anda tidak dikirim ke server mana pun."
                    else
                        "WiFi Inspector membutuhkan izin lokasi untuk memindai jaringan WiFi di sekitar, sesuai kebijakan resmi Android.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(20.dp))
                androidx.compose.material3.Button(onClick = onRequestPermission, modifier = Modifier.fillMaxWidth()) {
                    Text("Izinkan Akses Lokasi")
                }
            }
        }
    }
}
