package com.ayonz.wifiinspector.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.ayonz.wifiinspector.domain.model.ScanHistoryEntry

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val networkCount: Int,
    val strongestSsid: String?,
    val strongestDbm: Int?
)

fun ScanHistoryEntity.toDomain() = ScanHistoryEntry(
    id = id,
    timestampMillis = timestampMillis,
    networkCount = networkCount,
    strongestSsid = strongestSsid,
    strongestDbm = strongestDbm
)
