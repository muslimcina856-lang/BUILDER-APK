package com.ayonz.wifiinspector

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.ayonz.wifiinspector.data.local.PreferencesManager
import com.ayonz.wifiinspector.data.local.ThemeMode
import com.ayonz.wifiinspector.presentation.navigation.WifiInspectorNavGraph
import com.ayonz.wifiinspector.presentation.theme.WifiInspectorTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as WifiInspectorApp).container

        setContent {
            WifiInspectorRoot(preferencesManager = container.preferencesManager) {
                WifiInspectorNavGraph(container = container)
            }
        }
    }
}

@Composable
private fun WifiInspectorRoot(
    preferencesManager: PreferencesManager,
    content: @Composable () -> Unit
) {
    val themeMode by preferencesManager.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
    val systemDark = isSystemInDarkTheme()
    val darkTheme = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }

    WifiInspectorTheme(darkTheme = darkTheme) {
        content()
    }
}
