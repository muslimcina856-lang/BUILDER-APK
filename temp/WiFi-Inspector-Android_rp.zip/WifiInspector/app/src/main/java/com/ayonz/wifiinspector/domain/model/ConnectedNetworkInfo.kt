package com.ayonz.wifiinspector.domain.model

/**
 * Informasi jaringan WiFi yang sedang aktif digunakan oleh perangkat.
 * Diambil murni dari WifiManager, ConnectivityManager, dan LinkProperties (API resmi Android).
 */
data class ConnectedNetworkInfo(
    val isConnected: Boolean,
    val ssid: String?,
    val bssid: String?,
    val localIpAddress: String?,
    val gateway: String?,
    val dnsServers: List<String>,
    val linkSpeedMbps: Int?,
    val frequencyMhz: Int?,
    val band: WifiBand,
    val signalLevelDbm: Int?,
    val signalPercent: Int?,
    val quality: SignalQuality?
)
