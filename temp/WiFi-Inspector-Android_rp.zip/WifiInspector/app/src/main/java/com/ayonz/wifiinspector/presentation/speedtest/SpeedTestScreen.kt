package com.ayonz.wifiinspector.presentation.speedtest

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard
import com.ayonz.wifiinspector.presentation.components.SignalStrengthChart
import com.ayonz.wifiinspector.presentation.components.SpeedGauge
import com.ayonz.wifiinspector.presentation.theme.NeonCyan
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SpeedTestScreen(viewModel: SpeedTestViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val history by viewModel.history.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isExporting by remember { mutableStateOf(false) }

    AnimatedBackground {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(20.dp, 20.dp, 20.dp, 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        item {
            Text("Speed Test", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(
                stageLabel(uiState.stage, uiState.errorMessage),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                SpeedGauge(
                    currentMbps = if (uiState.stage == SpeedTestStage.DONE) uiState.result?.downloadMbps ?: 0.0 else uiState.currentMbps,
                    modifier = Modifier.size(240.dp)
                )
                Spacer(Modifier.height(16.dp))
                if (uiState.isRunning) {
                    LinearProgressIndicator(
                        progress = { uiState.progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp)
                    )
                }
            }
        }

        if (uiState.errorMessage != null) {
            item {
                Text(uiState.errorMessage.orEmpty(), color = MaterialTheme.colorScheme.error)
            }
        }

        uiState.result?.let { result ->
            item { ResultGrid(result) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { SpeedTestShareHelper.shareSummary(context, result) },
                        modifier = Modifier.weight(1f)
                    ) {
                        androidx.compose.material3.Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Bagikan")
                    }
                    OutlinedButton(
                        onClick = {
                            isExporting = true
                            scope.launch {
                                val file = SpeedTestPdfExporter.export(context, result)
                                SpeedTestShareHelper.sharePdf(context, file)
                                isExporting = false
                            }
                        },
                        enabled = !isExporting,
                        modifier = Modifier.weight(1f)
                    ) {
                        androidx.compose.material3.Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isExporting) "Membuat..." else "Export PDF")
                    }
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.runTest() },
                enabled = !uiState.isRunning,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (uiState.isRunning) "Mengukur..." else "Mulai Speed Test")
            }
        }

        if (history.isNotEmpty()) {
            item {
                Text(
                    "Grafik Kecepatan Download (Riwayat)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
                    val values = history.reversed().map { it.downloadMbps.toInt() }
                    val maxVal = (values.maxOrNull() ?: 100).coerceAtLeast(10)
                    SignalStrengthChart(values = values, lineColor = NeonCyan, minDbm = 0, maxDbm = maxVal)
                }
            }

            item {
                Text("Riwayat Speed Test", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            items(history.take(10), key = { it.id }) { entry ->
                HistoryRow(entry)
            }
        }
        }
    }
}

private fun stageLabel(stage: SpeedTestStage, error: String?): String = when (stage) {
    SpeedTestStage.IDLE -> "Tekan tombol di bawah untuk memulai pengujian"
    SpeedTestStage.PING -> "Mengukur ping & jitter..."
    SpeedTestStage.DOWNLOAD -> "Mengukur kecepatan download..."
    SpeedTestStage.UPLOAD -> "Mengukur kecepatan upload..."
    SpeedTestStage.DONE -> "Pengujian selesai"
    SpeedTestStage.ERROR -> error ?: "Terjadi kesalahan"
}

@Composable
private fun ResultGrid(result: SpeedTestResult) {
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 18.dp) {
        Column {
            GridRow("Download", "%.2f Mbps".format(result.downloadMbps), "%.2f MB/s".format(result.downloadMBps))
            Spacer(Modifier.height(12.dp))
            GridRow("Upload", "%.2f Mbps".format(result.uploadMbps), "%.2f MB/s".format(result.uploadMBps))
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MiniStat("Ping", "${result.pingMs} ms")
                MiniStat("Jitter", "${result.jitterMs} ms")
                MiniStat("Latency", "${result.latencyMs} ms")
            }
        }
    }
}

@Composable
private fun GridRow(label: String, primary: String, secondary: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(horizontalAlignment = Alignment.End) {
            Text(primary, fontWeight = FontWeight.Bold)
            Text(secondary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.SemiBold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HistoryRow(entry: SpeedTestResult) {
    val formatter = remember { SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")) }
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 14.dp) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(formatter.format(Date(entry.timestampMillis)), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("↓ %.1f".format(entry.downloadMbps), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Text("↑ %.1f".format(entry.uploadMbps), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Text("${entry.pingMs}ms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
