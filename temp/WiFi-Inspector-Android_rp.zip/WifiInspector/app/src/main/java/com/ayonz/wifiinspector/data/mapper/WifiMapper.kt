package com.ayonz.wifiinspector.data.mapper

import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import com.ayonz.wifiinspector.domain.model.SecurityType
import com.ayonz.wifiinspector.domain.model.SignalQuality
import com.ayonz.wifiinspector.domain.model.WifiBand
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.domain.model.WifiStandard

/**
 * Semua fungsi di sini hanya membaca data dari android.net.wifi.ScanResult (API resmi Android).
 * Tidak ada dekripsi, brute-force, atau upaya mengakses jaringan tanpa izin.
 */
object WifiMapper {

    fun toDomain(scanResult: ScanResult): WifiNetworkInfo {
        val ssid = extractSsid(scanResult)
        val level = scanResult.level
        val percent = calculateSignalPercent(level)
        val frequency = scanResult.frequency
        return WifiNetworkInfo(
            ssid = ssid.ifBlank { "(Tersembunyi)" },
            bssid = scanResult.BSSID ?: "-",
            signalLevelDbm = level,
            signalPercent = percent,
            frequencyMhz = frequency,
            band = bandFromFrequency(frequency),
            channel = frequencyToChannel(frequency),
            standard = extractStandard(scanResult),
            security = extractSecurity(scanResult.capabilities),
            quality = SignalQuality.fromDbm(level),
            isHiddenSsid = ssid.isBlank(),
            timestampMillis = System.currentTimeMillis()
        )
    }

    @Suppress("DEPRECATION")
    private fun extractSsid(scanResult: ScanResult): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                scanResult.wifiSsid?.toString()?.trim('"').orEmpty()
            } else {
                scanResult.SSID.orEmpty()
            }
        } catch (e: Exception) {
            scanResult.SSID.orEmpty()
        }
    }

    /**
     * Formula standar industri untuk mengubah RSSI (dBm) menjadi persentase 0-100%.
     * -50 dBm atau lebih kuat = 100%, -100 dBm atau lebih lemah = 0%.
     */
    fun calculateSignalPercent(dbm: Int): Int {
        val minRssi = -100
        val maxRssi = -50
        val clamped = dbm.coerceIn(minRssi, maxRssi)
        return ((clamped - minRssi).toFloat() / (maxRssi - minRssi) * 100).toInt().coerceIn(0, 100)
    }

    fun bandFromFrequency(freqMhz: Int): WifiBand = when {
        freqMhz in 2400..2500 -> WifiBand.GHZ_2_4
        freqMhz in 4900..5900 -> WifiBand.GHZ_5
        freqMhz in 5925..7125 -> WifiBand.GHZ_6
        else -> WifiBand.UNKNOWN
    }

    fun frequencyToChannel(freqMhz: Int): Int {
        return when {
            freqMhz == 2484 -> 14
            freqMhz in 2412..2472 -> (freqMhz - 2407) / 5
            freqMhz in 5170..5895 -> (freqMhz - 5000) / 5
            freqMhz in 5955..7115 -> (freqMhz - 5950) / 5
            else -> -1
        }
    }

    private fun extractStandard(scanResult: ScanResult): WifiStandard {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return WifiStandard.UNKNOWN
        return try {
            @Suppress("DEPRECATION")
            when (scanResult.wifiStandard) {
                ScanResult.WIFI_STANDARD_11N -> WifiStandard.N
                ScanResult.WIFI_STANDARD_11AC -> WifiStandard.AC
                ScanResult.WIFI_STANDARD_11AX -> WifiStandard.AX
                ScanResult.WIFI_STANDARD_LEGACY -> WifiStandard.LEGACY
                11 /* WIFI_STANDARD_11BE, API 34 */ -> WifiStandard.BE
                else -> WifiStandard.UNKNOWN
            }
        } catch (e: Exception) {
            WifiStandard.UNKNOWN
        }
    }

    fun extractSecurity(capabilities: String?): SecurityType {
        val caps = capabilities.orEmpty().uppercase()
        return when {
            caps.contains("WPA3") && caps.contains("WPA2") -> SecurityType.WPA2_WPA3
            caps.contains("WPA3") || caps.contains("SAE") -> SecurityType.WPA3
            caps.contains("EAP") || caps.contains("802.1X") -> SecurityType.ENTERPRISE
            caps.contains("WPA2") -> SecurityType.WPA2
            caps.contains("WPA") -> SecurityType.WPA
            caps.contains("WEP") -> SecurityType.WEP
            caps.contains("OWE") -> SecurityType.OPEN
            caps.isBlank() || caps == "[ESS]" || !caps.contains("[") -> SecurityType.OPEN
            else -> SecurityType.OPEN
        }
    }
}
