package com.ayonz.wifiinspector.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.presentation.connected.ConnectedNetworkScreen
import com.ayonz.wifiinspector.presentation.connected.ConnectedNetworkViewModel
import com.ayonz.wifiinspector.presentation.detail.WifiDetailScreen
import com.ayonz.wifiinspector.presentation.history.HistoryScreen
import com.ayonz.wifiinspector.presentation.history.HistoryViewModel
import com.ayonz.wifiinspector.presentation.map.MapScreen
import com.ayonz.wifiinspector.presentation.pingtest.PingTestViewModel
import com.ayonz.wifiinspector.presentation.scan.WifiScanScreen
import com.ayonz.wifiinspector.presentation.scan.WifiScanViewModel
import com.ayonz.wifiinspector.presentation.settings.SettingsScreen
import com.ayonz.wifiinspector.presentation.settings.SettingsViewModel
import com.ayonz.wifiinspector.presentation.speedtest.SpeedTestViewModel

private val bottomItems = listOf(
    Screen.Scan to Icons.Filled.Wifi,
    Screen.Connected to Icons.Filled.WifiTethering,
    Screen.Map to Icons.Filled.Map,
    Screen.Tools to Icons.Filled.Build,
    Screen.History to Icons.Filled.History,
    Screen.Settings to Icons.Filled.Settings
)

@Composable
fun WifiInspectorNavGraph(container: AppContainer) {
    val navController = rememberNavController()

    // ViewModel di-scope pada NavGraph agar state (mis. hasil scan) bertahan antar navigasi.
    val scanViewModel: WifiScanViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = WifiScanViewModel.factory(container)
    )
    val connectedViewModel: ConnectedNetworkViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = ConnectedNetworkViewModel.factory(container)
    )
    val historyViewModel: HistoryViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = HistoryViewModel.factory(container)
    )
    val settingsViewModel: SettingsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = SettingsViewModel.factory(container)
    )
    val speedTestViewModel: SpeedTestViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = SpeedTestViewModel.factory(container)
    )
    val pingTestViewModel: PingTestViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = PingTestViewModel.factory(container)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            // Sembunyikan bottom bar saat berada di layar detail agar lebih immersive.
            val showBottomBar = currentDestination?.route?.startsWith("detail/") != true

            if (showBottomBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)) {
                    bottomItems.forEach { (screen, icon) ->
                        val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = screen.label) },
                            label = { Text(screen.label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Scan.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Scan.route) {
                WifiScanScreen(
                    viewModel = scanViewModel,
                    onNetworkClick = { bssid -> navController.navigate(Screen.Detail.createRoute(bssid)) }
                )
            }
            composable(Screen.Connected.route) {
                ConnectedNetworkScreen(viewModel = connectedViewModel)
            }
            composable(Screen.Map.route) {
                MapScreen(container = container)
            }
            composable(Screen.Tools.route) {
                ToolsScreen(speedTestViewModel = speedTestViewModel, pingTestViewModel = pingTestViewModel)
            }
            composable(Screen.History.route) {
                HistoryScreen(viewModel = historyViewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = settingsViewModel)
            }
            composable(Screen.Detail.route) { backStackEntry ->
                val bssid = backStackEntry.arguments?.getString("bssid").orEmpty()
                val scanState by scanViewModel.uiState.collectAsState()
                val network = scanState.networks.firstOrNull { it.bssid == bssid }
                WifiDetailScreen(
                    network = network,
                    signalHistory = scanViewModel.signalHistoryFor(bssid),
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
