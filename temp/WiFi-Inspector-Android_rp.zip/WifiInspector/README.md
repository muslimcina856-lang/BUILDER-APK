# WiFi Inspector

Aplikasi Android modern untuk memindai dan menganalisis jaringan WiFi di sekitar, dibangun dengan **Kotlin**, **Jetpack Compose**, **Material 3**, arsitektur **MVVM + Clean Architecture**, dan tampilan **glassmorphism futuristik**.

## ⚠️ Prinsip Etika & Keamanan

Aplikasi ini **hanya** menggunakan API resmi Android (`WifiManager`, `ConnectivityManager`, `FusedLocationProviderClient`). Aplikasi ini **tidak**:
- Meretas, mendekripsi, atau menebak kata sandi WiFi apa pun
- Mengakses perangkat lain di jaringan tanpa izin
- Menggunakan root, reflection tersembunyi, atau API tidak resmi

## Fitur

| Fitur | Layar | Keterangan |
|---|---|---|
| Scan WiFi sekitar | Scan | SSID, BSSID, dBm, %, frekuensi, channel, standar 802.11, keamanan |
| Urutkan sinyal terkuat | Scan | Otomatis, `SortNetworksBySignalUseCase` |
| Pencarian real-time | Scan | Filter SSID/BSSID langsung saat mengetik |
| Grafik sinyal langsung | Detail | Riwayat dBm per BSSID digambar via Canvas |
| Info koneksi aktif | Koneksi | SSID, BSSID, IP lokal, gateway, DNS, link speed, band |
| Lokasi pengguna di peta | Peta | Google Maps Compose + FusedLocationProviderClient |
| Kualitas sinyal | Scan/Koneksi | 5 tingkat: Sangat Lemah → Sangat Baik |
| Speed Test | Alat | Download throughput via endpoint publik Cloudflare |
| Ping Test | Alat | Latensi TCP-connect (tanpa root) ke host pilihan |
| Riwayat scan | Riwayat | Tersimpan lokal via Room database |
| Mode gelap/terang | Pengaturan | DataStore Preferences, 3 opsi (Sistem/Terang/Gelap) |
| UI glassmorphism | Semua layar | `GlassCard` + `AnimatedBackground` custom Canvas |

## Arsitektur

```
presentation/  → Compose UI + ViewModel (MVVM)
domain/        → Model murni Kotlin + UseCase + interface Repository
data/          → Implementasi Repository + DataSource (WifiManager, Room, DataStore, Retrofit-less HTTP)
di/            → AppContainer (DI manual & ringan, tanpa Hilt)
```

Layer `presentation` dan `domain` tidak pernah bergantung langsung pada kelas Android seperti `WifiManager` — semua akses sistem terisolasi di `data/source`, sehingga mudah diuji dan dipelihara.

## Cara Membuka & Menjalankan

1. Buka Android Studio (disarankan versi **Koala/2024.1** ke atas).
2. `File → Open` dan pilih folder proyek ini.
3. Android Studio akan membuat file `local.properties` secara otomatis (isi `sdk.dir` sesuai lokasi Android SDK di komputer Anda — lihat `local.properties.example` sebagai referensi).
4. Jika `gradlew` belum memiliki `gradle-wrapper.jar`, biarkan Android Studio menyinkronkan proyek — IDE akan otomatis melengkapi wrapper menggunakan versi Gradle bawaan (proyek sudah menargetkan **Gradle 8.7** & **AGP 8.5.2**).
5. **Wajib** — tambahkan Google Maps API Key Anda sendiri di `app/build.gradle.kts`:
   ```kotlin
   manifestPlaceholders["MAPS_API_KEY"] = "ISI_API_KEY_ANDA"
   ```
   Dapatkan API key di [Google Cloud Console](https://console.cloud.google.com/google/maps-apis) (aktifkan **Maps SDK for Android**). Tanpa key valid, hanya fitur Peta yang tidak berfungsi — fitur lain tetap normal.
6. Klik **Run ▶** pada perangkat/emulator dengan **Android 8.0 (API 26)** ke atas.

## Izin yang Digunakan

| Izin | Alasan |
|---|---|
| `ACCESS_FINE_LOCATION` / `ACCESS_COARSE_LOCATION` | Wajib oleh kebijakan Android agar hasil scan WiFi terisi, dan untuk fitur Peta |
| `ACCESS_WIFI_STATE` / `CHANGE_WIFI_STATE` | Memindai jaringan WiFi resmi via `WifiManager` |
| `ACCESS_NETWORK_STATE` | Mendeteksi status & properti koneksi aktif |
| `INTERNET` | Speed test, ping test, dan tampilan peta |

## Catatan Teknis

- **Ping Test** menggunakan pengukuran latensi TCP-connect (bukan ICMP mentah), karena Android non-root tidak mengizinkan raw socket ICMP tanpa hak istimewa — ini pendekatan standar di aplikasi jaringan non-root.
- **Speed Test** mengunduh berkas uji dari endpoint publik Cloudflare yang memang disediakan untuk keperluan pengujian kecepatan.
- **Standar WiFi (802.11ax/ac/n)** hanya tersedia mulai Android 10 (API 29) karena keterbatasan API resmi Android (`ScanResult.getWifiStandard()`); pada versi lebih lama akan ditampilkan "Tidak diketahui".
- Sejak Android 9 (Pie), sistem **membatasi frekuensi `startScan()`** (maksimal beberapa kali per beberapa menit) untuk aplikasi non-sistem — ini kebijakan resmi Android, bukan bug. Saat throttling terjadi, aplikasi tetap menampilkan hasil scan terakhir yang tersimpan di sistem.
- Proyek ini **tidak menggunakan Hilt/Dagger** — DI dilakukan manual lewat `AppContainer` untuk menjaga build tetap ringan dan minim risiko kegagalan kompilasi.

## Struktur Modul Penting

```
app/src/main/java/com/ayonz/wifiinspector/
├── MainActivity.kt
├── WifiInspectorApp.kt
├── di/AppContainer.kt
├── domain/
│   ├── model/
│   ├── repository/WifiRepository.kt
│   └── usecase/
├── data/
│   ├── mapper/WifiMapper.kt
│   ├── source/ (WifiScan, ConnectedNetwork, Location, SpeedTest, Ping)
│   ├── local/ (Room + DataStore)
│   └── repository/WifiRepositoryImpl.kt
└── presentation/
    ├── theme/
    ├── components/ (GlassCard, SignalChart, dll)
    ├── navigation/ (NavGraph, ToolsScreen)
    └── scan/ detail/ connected/ map/ speedtest/ pingtest/ history/ settings/
```

## Lisensi & Tanggung Jawab

Gunakan aplikasi ini hanya untuk menganalisis jaringan yang Anda miliki atau yang berizin Anda akses. Pengembang tidak bertanggung jawab atas penyalahgunaan di luar tujuan tersebut.
