plugins {
    id("com.android.application")
    id("dev.flutter.flutter-gradle-plugin")  // ← INI WAJIB
}

android {
    namespace = "com.nullx.pp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nullx.pp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

flutter {
    source = "../.."
}