package com.nullx.pp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
    // Kosongin aja – Flutter yang handle semuanya
}