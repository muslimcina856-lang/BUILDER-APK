# Cyber Basic — ALZZXNXX (Flutter FIXED)

This archive is rebuilt around the modern Flutter Android Gradle plugin layout.

Brand:
- App: Cyber Basic
- Author: ALZZXNXX
- Telegram: @alzzxnxx

Logo:
- assets/cyber_basic_logo.png — in-app branding
- assets/cyber_basic_icon.png — in-app icon
- Android mipmap launcher icons are included

Build requirements:
- Flutter stable
- Java 17
- Android SDK installed

The Android project intentionally does not contain a machine-specific
android/local.properties file; Flutter/build tooling should generate it for
the build environment.

Security note:
File analysis is local/explicit and heuristic. It is not a guaranteed antivirus
verdict. File vault functionality is for legitimate file protection/integrity.
