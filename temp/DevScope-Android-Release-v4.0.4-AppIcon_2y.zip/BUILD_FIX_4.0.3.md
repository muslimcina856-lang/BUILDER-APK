# v4.0.3 keyboard/editor fix

This patch addresses the Android IME covering the CODEGEN/AUTOMATE editor.

Implemented:
- `android:windowSoftInputMode="adjustResize|stateAlwaysHidden"`
- runtime `SOFT_INPUT_ADJUST_RESIZE`
- automatic TOOLS-only editor mode while IME is visible
- cursor visibility via `EditText.bringPointIntoView()`
- vertical code scrolling remains available
- `flagNoExtractUi` on multi-line editors for landscape
- previous split state restored after keyboard closes
