# v4.0.4 App Icon Update

The existing approved image `lencana_teknologi_neon_ds.png` was used directly as the source artwork. No new artwork was generated.

Android launcher resources were created by resizing that image for standard mipmap densities:
- mdpi 48x48
- hdpi 72x72
- xhdpi 96x96
- xxhdpi 144x144
- xxxhdpi 192x192

Manifest:
- android:icon=@mipmap/ic_launcher
- android:roundIcon=@mipmap/ic_launcher_round
