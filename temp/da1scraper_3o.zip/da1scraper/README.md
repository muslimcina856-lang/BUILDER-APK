# Da1scraper

Web Snippet Extractor Flutter App by FATEzou

## Fitur
- **Login/Register** — sistem autentikasi lokal dengan email & password
- **4 Mode Scraper:**
  - `Web Snippet` — judul, deskripsi, gambar utama, link
  - `Meta Extractor` — semua meta tag (OG, Twitter Card, SEO)
  - `Text Extractor` — heading, paragraf, word count
  - `Media Finder` — semua URL gambar, video, audio
- **Export Hasil** — JSON / TXT / CSV via share sheet
- **Riwayat** — semua hasil tersimpan, bisa swipe-to-delete
- **Profil** — foto profil, info akun, logout

## Struktur File
```
lib/
├── main.dart               # Entry point + AuthGate
├── login_page.dart         # Login & Register
├── dashboard_page.dart     # Bottom nav container
├── scraper_page.dart       # Halaman utama scraper
├── scraper_service.dart    # Logic HTTP fetch + HTML parser
├── result_detail_page.dart # Detail hasil + export
├── history_page.dart       # Riwayat scraping
└── profile_page.dart       # Profil user + logout
```

## Dependencies
```yaml
http: ^0.13.5
shared_preferences: ^2.2.2
image_picker: ^1.0.7
share_plus: ^7.0.1
path_provider: ^2.1.1
font_awesome_flutter: ^11.0.0
url_launcher: ^6.2.6
```

## Font (taruh di fonts/)
- `Orbitron-Regular.ttf`
- `ShareTechMono-Regular.ttf`

Download dari Google Fonts: https://fonts.google.com

## Setup
```bash
flutter pub get
flutter run
```

## Android Permission
`INTERNET`, `CAMERA`, `READ/WRITE_EXTERNAL_STORAGE` sudah ada di AndroidManifest.xml

---
© 2026 Da1scraper — FATEzou | t.me/FATEzou
