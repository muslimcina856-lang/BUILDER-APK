import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final emailController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  bool _isRegisterMode = false;
  final nameController = TextEditingController();

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // Tema warna — dari base Dq
  final Color bgDark = const Color(0xFF050D1A);
  final Color bgSecondary = const Color(0xFF0A1628);
  final Color primaryBlue = const Color(0xFF0062CC);
  final Color accentCyan = const Color(0xFF00FBFF);
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _controller.dispose();
    emailController.dispose();
    passController.dispose();
    nameController.dispose();
    super.dispose();
  }

  // Simpan user ke SharedPreferences (simulasi local auth)
  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final email = emailController.text.trim();
    final password = passController.text.trim();
    final name = nameController.text.trim();

    // Cek apakah email sudah terdaftar
    final existingUsers = prefs.getString('users_db') ?? '{}';
    final Map<String, dynamic> users = jsonDecode(existingUsers);

    if (users.containsKey(email)) {
      _showSnack('Email sudah terdaftar.', Colors.orange);
      setState(() => isLoading = false);
      return;
    }

    users[email] = {'password': password, 'name': name};
    await prefs.setString('users_db', jsonEncode(users));

    _showSnack('Akun berhasil dibuat! Silakan login.', accentCyan);
    setState(() {
      isLoading = false;
      _isRegisterMode = false;
    });
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final email = emailController.text.trim();
    final password = passController.text.trim();

    final existingUsers = prefs.getString('users_db') ?? '{}';
    final Map<String, dynamic> users = jsonDecode(existingUsers);

    await Future.delayed(const Duration(milliseconds: 600));

    if (!users.containsKey(email)) {
      _showSnack('Email tidak ditemukan.', Colors.redAccent);
      setState(() => isLoading = false);
      return;
    }

    if (users[email]['password'] != password) {
      _showSnack('Password salah.', Colors.redAccent);
      setState(() => isLoading = false);
      return;
    }

    // Simpan sesi
    await prefs.setString('email', email);
    await prefs.setString('name', users[email]['name']);

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => DashboardPage(
            email: email,
            name: users[email]['name'],
          ),
        ),
      );
    }
    setState(() => isLoading = false);
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [bgDark, bgSecondary, Colors.black],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo glow — diambil dari pola login_page Dq
                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: accentCyan, width: 2),
                          color: bgSecondary,
                          boxShadow: [
                            BoxShadow(
                              color: accentCyan.withOpacity(0.35),
                              blurRadius: 28,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Icon(
                              Icons.code,
                              color: accentCyan,
                              size: 40,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),

                      // Judul
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [accentCyan, Colors.white],
                        ).createShader(bounds),
                        child: Text(
                          'DA1SCRAPER',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            color: Colors.white,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(
                                color: accentCyan.withOpacity(0.5),
                                blurRadius: 15,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _isRegisterMode
                            ? 'Buat akun baru'
                            : 'Web Snippet Extractor',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 13,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 36),

                      // Form
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            if (_isRegisterMode) ...[
                              _buildInput(
                                controller: nameController,
                                label: 'Nama',
                                icon: Icons.person_outline,
                              ),
                              const SizedBox(height: 16),
                            ],
                            _buildInput(
                              controller: emailController,
                              label: 'Email',
                              icon: Icons.email_outlined,
                              keyboardType: TextInputType.emailAddress,
                              validator: (v) {
                                if (v == null || v.isEmpty) return 'Email wajib diisi';
                                if (!v.contains('@')) return 'Format email tidak valid';
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildInput(
                              controller: passController,
                              label: 'Password',
                              icon: Icons.lock_outline,
                              isPassword: true,
                              validator: (v) {
                                if (v == null || v.length < 6) {
                                  return 'Password minimal 6 karakter';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 28),
                            _buildSubmitButton(),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Toggle register/login
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _isRegisterMode = !_isRegisterMode;
                            _formKey.currentState?.reset();
                          });
                        },
                        child: RichText(
                          text: TextSpan(
                            style: const TextStyle(
                              fontSize: 13,
                              fontFamily: 'ShareTechMono',
                            ),
                            children: [
                              TextSpan(
                                text: _isRegisterMode
                                    ? 'Sudah punya akun? '
                                    : 'Belum punya akun? ',
                                style: const TextStyle(color: Colors.white54),
                              ),
                              TextSpan(
                                text: _isRegisterMode ? 'Login' : 'Daftar',
                                style: TextStyle(
                                  color: accentCyan,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 30),
                      Text(
                        '© 2026 Da1scraper by FATEzou',
                        style: TextStyle(
                          color: Colors.white24,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Container(
      height: 55,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: bgSecondary,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        keyboardType: keyboardType,
        style: const TextStyle(color: Colors.white, fontSize: 15),
        validator: validator,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.white54, fontSize: 13),
          prefixIcon: Icon(icon, color: accentCyan, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: Colors.white38,
                    size: 20,
                  ),
                  onPressed: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                )
              : null,
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
        ),
      ),
    );
  }

  Widget _buildSubmitButton() {
    final double fullWidth = MediaQuery.of(context).size.width - 56;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isLoading ? 60 : fullWidth,
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryBlue, accentCyan],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentCyan.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading
              ? null
              : (_isRegisterMode ? _register : _login),
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    _isRegisterMode ? 'DAFTAR' : 'MASUK',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      fontFamily: 'Orbitron',
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
