import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'result_detail_page.dart';

class HistoryPage extends StatefulWidget {
  final String email;
  const HistoryPage({super.key, required this.email});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage>
    with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> _history = [];
  bool _isLoading = true;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;

  final Color bgDark = const Color(0xFF050D1A);
  final Color cardBg = const Color(0xFF0A1628);
  final Color accentCyan = const Color(0xFF00FBFF);
  final Color primaryBlue = const Color(0xFF0062CC);
  final Color cardGlass = const Color(0x0DFFFFFF);
  final Color borderGlass = const Color(0x1AFFFFFF);

  final Map<String, Color> _modeColors = {
    'snippet': const Color(0xFF00FBFF),
    'meta': const Color(0xFF7B61FF),
    'text': const Color(0xFF00E676),
    'media': const Color(0xFFFF9100),
  };

  final Map<String, IconData> _modeIcons = {
    'snippet': Icons.web_outlined,
    'meta': Icons.info_outline,
    'text': Icons.article_outlined,
    'media': Icons.download_outlined,
  };

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _loadHistory();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'history_${widget.email}';
    final raw = prefs.getString(key) ?? '[]';
    final List list = jsonDecode(raw);
    setState(() {
      _history = list.cast<Map<String, dynamic>>();
      _isLoading = false;
    });
  }

  Future<void> _clearHistory() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Hapus Semua Riwayat?',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            fontSize: 15,
          ),
        ),
        content: const Text(
          'Semua riwayat scraping akan dihapus.',
          style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white38)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Hapus', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('history_${widget.email}');
      setState(() => _history = []);
    }
  }

  Future<void> _deleteItem(int index) async {
    final prefs = await SharedPreferences.getInstance();
    _history.removeAt(index);
    await prefs.setString(
      'history_${widget.email}',
      jsonEncode(_history),
    );
    setState(() {});
  }

  String _formatTime(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}/'
          '${dt.month.toString().padLeft(2, '0')}/'
          '${dt.year} '
          '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    primaryBlue.withOpacity(0.25),
                    accentCyan.withOpacity(0.1),
                    primaryBlue.withOpacity(0.2),
                  ],
                ),
                border: Border(
                  bottom: BorderSide(color: accentCyan.withOpacity(0.15)),
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.history, color: accentCyan, size: 22),
                  const SizedBox(width: 12),
                  Text(
                    'RIWAYAT',
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: accentCyan.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  if (_history.isNotEmpty)
                    GestureDetector(
                      onTap: _clearHistory,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.redAccent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: Colors.redAccent.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.delete_outline,
                                color: Colors.redAccent, size: 14),
                            SizedBox(width: 4),
                            Text(
                              'Hapus',
                              style: TextStyle(
                                color: Colors.redAccent,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Konten
            Expanded(
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(color: accentCyan))
                  : _history.isEmpty
                      ? _buildEmpty()
                      : FadeTransition(
                          opacity: _fadeAnim,
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                            itemCount: _history.length,
                            itemBuilder: (_, i) => _buildHistoryCard(i),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.history_toggle_off,
              color: Colors.white12, size: 64),
          const SizedBox(height: 16),
          Text(
            'Belum ada riwayat',
            style: TextStyle(
              color: Colors.white24,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Jalankan scraper untuk melihat riwayat',
            style: TextStyle(
              color: Colors.white12,
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(int index) {
    final item = _history[index];
    final String url = item['url'] ?? '-';
    final String mode = item['mode'] ?? 'snippet';
    final String time = _formatTime(item['timestamp'] ?? '');
    final Map<String, dynamic> data =
        (item['data'] as Map?)?.cast<String, dynamic>() ?? {};

    final Color modeColor = _modeColors[mode] ?? accentCyan;
    final IconData modeIcon = _modeIcons[mode] ?? Icons.code;

    return Dismissible(
      key: Key('$index-$url'),
      direction: DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.only(bottom: 10),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colors.redAccent.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Icon(Icons.delete_outline,
            color: Colors.redAccent, size: 24),
      ),
      onDismissed: (_) => _deleteItem(index),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ResultDetailPage(
                result: data,
                url: url,
                mode: mode,
              ),
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderGlass),
          ),
          child: Row(
            children: [
              // Mode icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: modeColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: modeColor.withOpacity(0.3)),
                ),
                child: Icon(modeIcon, color: modeColor, size: 18),
              ),
              const SizedBox(width: 12),

              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      url,
                      style: const TextStyle(
                        color: Colors.white87,
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: modeColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            mode.toUpperCase(),
                            style: TextStyle(
                              color: modeColor,
                              fontSize: 9,
                              fontFamily: 'Orbitron',
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          time,
                          style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              Icon(Icons.chevron_right,
                  color: Colors.white24, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
