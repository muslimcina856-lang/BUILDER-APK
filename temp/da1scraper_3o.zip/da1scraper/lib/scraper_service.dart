import 'dart:convert';
import 'package:http/http.dart' as http;

class ScraperService {
  static const String _userAgent =
      'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  static Future<Map<String, dynamic>> scrape({
    required String url,
    required String mode,
    required void Function(String) onStatus,
  }) async {
    switch (mode) {
      case 'snippet':
        return await _scrapeSnippet(url, onStatus);
      case 'meta':
        return await _scrapeMeta(url, onStatus);
      case 'text':
        return await _scrapeText(url, onStatus);
      case 'media':
        return await _scrapeMedia(url, onStatus);
      default:
        return await _scrapeSnippet(url, onStatus);
    }
  }

  // ─── SNIPPET: judul + deskripsi + gambar utama + link ───────────────────────
  static Future<Map<String, dynamic>> _scrapeSnippet(
    String url,
    void Function(String) onStatus,
  ) async {
    onStatus('Fetching halaman...');
    final html = await _fetchHtml(url);

    onStatus('Mengekstrak snippet...');
    final title = _extractTag(html, 'title') ??
        _extractMeta(html, 'og:title') ??
        _extractMeta(html, 'twitter:title') ??
        '(tidak ditemukan)';

    final description = _extractMeta(html, 'og:description') ??
        _extractMeta(html, 'description') ??
        _extractMeta(html, 'twitter:description') ??
        _extractFirstParagraph(html);

    final image = _extractMeta(html, 'og:image') ??
        _extractMeta(html, 'twitter:image') ??
        _extractFirstImage(html);

    final siteName = _extractMeta(html, 'og:site_name') ?? _extractDomain(url);
    final canonical = _extractCanonical(html) ?? url;
    final links = _extractLinks(html, url);

    return {
      'url': url,
      'title': _cleanText(title),
      'description': _cleanText(description ?? '-'),
      'image': image ?? '-',
      'site': siteName,
      'canonical': canonical,
      'links_count': links.length.toString(),
      'links_sample': links.take(5).toList(),
    };
  }

  // ─── META: semua meta tag ────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> _scrapeMeta(
    String url,
    void Function(String) onStatus,
  ) async {
    onStatus('Fetching halaman...');
    final html = await _fetchHtml(url);
    onStatus('Mengekstrak meta tags...');

    final result = <String, dynamic>{'url': url};

    // Standard meta
    final metaNames = [
      'description', 'keywords', 'author', 'robots',
      'viewport', 'theme-color', 'generator',
    ];
    for (final name in metaNames) {
      final val = _extractMeta(html, name);
      if (val != null) result[name] = _cleanText(val);
    }

    // Open Graph
    final ogProps = ['title', 'description', 'image', 'url', 'type', 'site_name', 'locale'];
    for (final prop in ogProps) {
      final val = _extractMeta(html, 'og:$prop');
      if (val != null) result['og:$prop'] = _cleanText(val);
    }

    // Twitter Card
    final twitterProps = ['card', 'title', 'description', 'image', 'site', 'creator'];
    for (final prop in twitterProps) {
      final val = _extractMeta(html, 'twitter:$prop');
      if (val != null) result['twitter:$prop'] = _cleanText(val);
    }

    // Title tag
    final title = _extractTag(html, 'title');
    if (title != null) result['title'] = _cleanText(title);

    // Canonical
    final canonical = _extractCanonical(html);
    if (canonical != null) result['canonical'] = canonical;

    // H1
    final h1 = _extractTag(html, 'h1');
    if (h1 != null) result['h1'] = _cleanText(h1);

    return result;
  }

  // ─── TEXT: ekstrak teks bersih dari konten ───────────────────────────────────
  static Future<Map<String, dynamic>> _scrapeText(
    String url,
    void Function(String) onStatus,
  ) async {
    onStatus('Fetching halaman...');
    final html = await _fetchHtml(url);
    onStatus('Membersihkan HTML...');

    final title = _extractTag(html, 'title') ?? '';

    // Ambil semua heading
    final h1s = _extractAllTags(html, 'h1');
    final h2s = _extractAllTags(html, 'h2');
    final h3s = _extractAllTags(html, 'h3');

    // Ambil paragraf
    final paragraphs = _extractAllTags(html, 'p')
        .map(_cleanText)
        .where((t) => t.length > 30)
        .take(20)
        .toList();

    // Word count estimasi
    final plainText = _stripHtml(html);
    final wordCount = plainText.split(RegExp(r'\s+')).length;

    return {
      'url': url,
      'title': _cleanText(title),
      'h1': h1s.map(_cleanText).where((t) => t.isNotEmpty).toList(),
      'h2': h2s.map(_cleanText).where((t) => t.isNotEmpty).take(10).toList(),
      'h3': h3s.map(_cleanText).where((t) => t.isNotEmpty).take(10).toList(),
      'paragraphs': paragraphs,
      'word_count': wordCount.toString(),
      'char_count': plainText.length.toString(),
    };
  }

  // ─── MEDIA: cari semua URL gambar/video/audio ────────────────────────────────
  static Future<Map<String, dynamic>> _scrapeMedia(
    String url,
    void Function(String) onStatus,
  ) async {
    onStatus('Fetching halaman...');
    final html = await _fetchHtml(url);
    onStatus('Mencari media...');

    final baseUri = Uri.parse(url);

    // Images dari tag <img src>
    final imgRegex = RegExp(r'<img[^>]+src=["\']([^"\']+)["\']', caseSensitive: false);
    final images = imgRegex
        .allMatches(html)
        .map((m) => _resolveUrl(m.group(1) ?? '', baseUri))
        .where((u) => u.isNotEmpty)
        .toSet()
        .toList();

    // Videos dari tag <video src> / <source src>
    final videoRegex = RegExp(
        r'(?:<video|<source)[^>]+src=["\']([^"\']+\.(?:mp4|webm|ogg|m3u8))["\']',
        caseSensitive: false);
    final videos = videoRegex
        .allMatches(html)
        .map((m) => _resolveUrl(m.group(1) ?? '', baseUri))
        .where((u) => u.isNotEmpty)
        .toSet()
        .toList();

    // Audio
    final audioRegex = RegExp(
        r'<(?:audio|source)[^>]+src=["\']([^"\']+\.(?:mp3|ogg|wav|flac|aac))["\']',
        caseSensitive: false);
    final audios = audioRegex
        .allMatches(html)
        .map((m) => _resolveUrl(m.group(1) ?? '', baseUri))
        .where((u) => u.isNotEmpty)
        .toSet()
        .toList();

    // og:image sebagai bonus
    final ogImage = _extractMeta(html, 'og:image');

    return {
      'url': url,
      'images_count': images.length.toString(),
      'images': images.take(20).toList(),
      'videos_count': videos.length.toString(),
      'videos': videos,
      'audios_count': audios.length.toString(),
      'audios': audios,
      if (ogImage != null) 'og_image': ogImage,
    };
  }

  // ─── HTTP FETCH ──────────────────────────────────────────────────────────────
  static Future<String> _fetchHtml(String url) async {
    final response = await http
        .get(
          Uri.parse(url),
          headers: {
            'User-Agent': _userAgent,
            'Accept': 'text/html,application/xhtml+xml,*/*;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
          },
        )
        .timeout(const Duration(seconds: 20));

    if (response.statusCode >= 400) {
      throw Exception('HTTP ${response.statusCode}');
    }
    return response.body;
  }

  // ─── HELPER PARSERS ──────────────────────────────────────────────────────────

  static String? _extractTag(String html, String tag) {
    final regex = RegExp(
      '<$tag[^>]*>(.*?)</$tag>',
      caseSensitive: false,
      dotAll: true,
    );
    final match = regex.firstMatch(html);
    return match?.group(1);
  }

  static List<String> _extractAllTags(String html, String tag) {
    final regex = RegExp(
      '<$tag[^>]*>(.*?)</$tag>',
      caseSensitive: false,
      dotAll: true,
    );
    return regex.allMatches(html).map((m) => m.group(1) ?? '').toList();
  }

  static String? _extractMeta(String html, String nameOrProp) {
    // name= atau property=
    final patterns = [
      RegExp(
        '<meta[^>]+(?:name|property)=["\']${RegExp.escape(nameOrProp)}["\'][^>]+content=["\']([^"\']*)["\']',
        caseSensitive: false,
      ),
      RegExp(
        '<meta[^>]+content=["\']([^"\']*)["\'][^>]+(?:name|property)=["\']${RegExp.escape(nameOrProp)}["\']',
        caseSensitive: false,
      ),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(html);
      if (m != null && m.group(1) != null && m.group(1)!.isNotEmpty) {
        return m.group(1);
      }
    }
    return null;
  }

  static String? _extractCanonical(String html) {
    final regex = RegExp(
      r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']',
      caseSensitive: false,
    );
    return regex.firstMatch(html)?.group(1);
  }

  static String? _extractFirstImage(String html) {
    final regex = RegExp(r'<img[^>]+src=["\']([^"\']+)["\']', caseSensitive: false);
    final match = regex.firstMatch(html);
    return match?.group(1);
  }

  static String? _extractFirstParagraph(String html) {
    final regex = RegExp(r'<p[^>]*>(.*?)</p>', caseSensitive: false, dotAll: true);
    for (final m in regex.allMatches(html)) {
      final text = _cleanText(m.group(1) ?? '');
      if (text.length > 40) return text.length > 200 ? '${text.substring(0, 200)}...' : text;
    }
    return null;
  }

  static List<String> _extractLinks(String html, String baseUrl) {
    final baseUri = Uri.parse(baseUrl);
    final regex = RegExp(r'<a[^>]+href=["\']([^"\'#][^"\']*)["\']', caseSensitive: false);
    return regex
        .allMatches(html)
        .map((m) => _resolveUrl(m.group(1) ?? '', baseUri))
        .where((u) => u.startsWith('http'))
        .toSet()
        .toList();
  }

  static String _resolveUrl(String href, Uri base) {
    if (href.isEmpty) return '';
    if (href.startsWith('http')) return href;
    if (href.startsWith('//')) return '${base.scheme}:$href';
    if (href.startsWith('/')) return '${base.scheme}://${base.host}$href';
    return '${base.scheme}://${base.host}/${href}';
  }

  static String _extractDomain(String url) {
    try {
      return Uri.parse(url).host;
    } catch (_) {
      return url;
    }
  }

  static String _cleanText(String html) {
    return html
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static String _stripHtml(String html) {
    return html
        .replaceAll(RegExp(r'<script[^>]*>.*?</script>', dotAll: true, caseSensitive: false), '')
        .replaceAll(RegExp(r'<style[^>]*>.*?</style>', dotAll: true, caseSensitive: false), '')
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }
}
