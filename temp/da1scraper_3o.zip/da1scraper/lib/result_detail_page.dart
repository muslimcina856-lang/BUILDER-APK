import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ResultDetailPage extends StatelessWidget {
  final Map<String, dynamic> result;
  final String url;
  final String mode;

  const ResultDetailPage({
    super.key,
    required this.result,
    required this.url,
    required this.mode,
  });

  final Color bgDark = const Color(0xFF050D1A);
  final Color cardBg = const Color(0xFF0A1628);
  final Color accentCyan = const Color(0xFF00FBFF);
  final Color primaryBlue = const Color(0xFF0062CC);
  final Color cardGlass = const Color(0x0DFFFFFF);
  final Color borderGlass = const Color(0x1AFFFFFF);

  Future<void> _exportJson(BuildContext context) async {
    try {
      final json = const JsonEncoder.withIndent('  ').convert(result);
      final dir = await getApplicationDocumentsDirectory();
      final ts = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/da1scraper_$ts.json');
      await file.writeAsString(json);
      await Share.shareXFiles([XFile(file.path)], subject: 'Da1scraper JSON');
    } catch (e) {
      _showSnack(context, 'Gagal export JSON: $e', Colors.redAccent);
    }
  }

  Future<void> _exportTxt(BuildContext context) async {
    try {
      final buf = StringBuffer();
      buf.writeln('=== DA1SCRAPER RESULT ===');
      buf.writeln('URL  : $url');
      buf.writeln('Mode : $mode');
      buf.writeln('Time : ${DateTime.now()}');
      buf.writeln('');
      result.forEach((k, v) {
        if (k == 'url') return;
        if (v is List) {
          buf.writeln('[$k]');
          for (final item in v) buf.writeln('  • $item');
          buf.writeln('');
        } else {
          buf.writeln('[$k]\n$v\n');
        }
      });
      final dir = await getApplicationDocumentsDirectory();
      final ts = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/da1scraper_$ts.txt');
      await file.writeAsString(buf.toString());
      await Share.shareXFiles([XFile(file.path)], subject: 'Da1scraper TXT');
    } catch (e) {
      _showSnack(context, 'Gagal export TXT: $e', Colors.redAccent);
    }
  }

  Future<void> _exportCsv(BuildContext context) async {
    try {
      final buf = StringBuffer();
      buf.writeln('key,value');
      result.forEach((k, v) {
        final val = v is List ? v.join(' | ') : v.toString();
        final escaped = val.replaceAll('"', '""');
        buf.writeln('"$k","$escaped"');
      });
      final dir = await getApplicationDocumentsDirectory();
      final ts = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/da1scraper_$ts.csv');
      await file.writeAsString(buf.toString());
      await Share.shareXFiles([XFile(file.path)], subject: 'Da1scraper CSV');
    } catch (e) {
      _showSnack(context, 'Gagal export CSV: $e', Colors.redAccent);
    }
  }

  void _copyAll(BuildContext context) {
    final json = const JsonEncoder.withIndent('  ').convert(result);
    Clipboard.setData(ClipboardData(text: json));
    _showSnack(context, 'Semua data disalin', accentCyan);
  }

  void _showSnack(BuildContext context, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentCyan, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'DETAIL HASIL',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            fontSize: 14,
            letterSpacing: 1.5,
            shadows: [Shadow(color: accentCyan.withOpacity(0.5), blurRadius: 10)],
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.copy_all, color: accentCyan, size: 20),
            onPressed: () => _copyAll(context),
            tooltip: 'Copy semua',
          ),
        ],
      ),
      body: Column(
        children: [
          // Info bar
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: cardGlass,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: borderGlass),
            ),
            child: Row(
              children: [
                Icon(Icons.link, color: accentCyan.withOpacity(0.6), size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    url,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: accentCyan.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: accentCyan.withOpacity(0.3)),
                  ),
                  child: Text(
                    mode.toUpperCase(),
                    style: TextStyle(
                      color: accentCyan,
                      fontSize: 10,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Export buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              children: [
                Text(
                  'EXPORT SEBAGAI:',
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(width: 12),
                _exportChip(context, 'JSON', Icons.data_object, () => _exportJson(context)),
                const SizedBox(width: 8),
                _exportChip(context, 'TXT', Icons.text_snippet_outlined, () => _exportTxt(context)),
                const SizedBox(width: 8),
                _exportChip(context, 'CSV', Icons.table_chart_outlined, () => _exportCsv(context)),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Data list
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: result.entries
                  .map((e) => _buildEntry(context, e.key, e.value))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _exportChip(BuildContext context, String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryBlue.withOpacity(0.3), accentCyan.withOpacity(0.2)],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: accentCyan.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: accentCyan, size: 13),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: accentCyan,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEntry(BuildContext context, String key, dynamic value) {
    final bool isList = value is List;
    final List<String> listItems =
        isList ? value.map((e) => e.toString()).toList() : [];
    final String displayValue = isList ? '' : value.toString();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGlass),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            final copyText = isList ? listItems.join('\n') : displayValue;
            Clipboard.setData(ClipboardData(text: copyText));
            _showSnack(context, '$key disalin', accentCyan);
          },
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: primaryBlue.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        key.toUpperCase(),
                        style: TextStyle(
                          color: accentCyan,
                          fontSize: 10,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Icon(Icons.copy, color: Colors.white24, size: 14),
                  ],
                ),
                const SizedBox(height: 8),
                if (isList) ...[
                  if (listItems.isEmpty)
                    const Text('(kosong)',
                        style: TextStyle(color: Colors.white38, fontSize: 12))
                  else
                    ...listItems.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('• ',
                                style: TextStyle(
                                    color: accentCyan.withOpacity(0.5),
                                    fontSize: 12)),
                            Expanded(
                              child: Text(
                                item,
                                style: const TextStyle(
                                  color: Colors.white87,
                                  fontSize: 12,
                                  fontFamily: 'ShareTechMono',
                                  height: 1.4,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ] else
                  Text(
                    displayValue.isEmpty ? '(kosong)' : displayValue,
                    style: TextStyle(
                      color: displayValue.isEmpty ? Colors.white38 : Colors.white87,
                      fontSize: 13,
                      fontFamily: 'ShareTechMono',
                      height: 1.5,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
