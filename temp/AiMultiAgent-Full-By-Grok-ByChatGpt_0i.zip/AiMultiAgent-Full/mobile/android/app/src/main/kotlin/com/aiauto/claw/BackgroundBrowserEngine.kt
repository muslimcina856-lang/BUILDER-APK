package com.aiauto.claw

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class BackgroundBrowserEngine(
    private val activity: Activity,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tabs = linkedMapOf<Int, BrowserTab>()
    private var nextTabId = 1
    private var activeTabId = 0
    private val maxTabs = 5
    private var pendingResult: MethodChannel.Result? = null
    private var pendingDone = AtomicBoolean(true)
    private var pendingGen: Int = 0
    private var timeoutRunnable: Runnable? = null
    private var desktopMode: Boolean = true
    @Volatile private var currentSessionId: String = "default"
    private val sessionStates = linkedMapOf<String, BrowserSessionState>()
    @Volatile private var activeAdblockEnabled: Boolean = false

    private var workspacePanel: FrameLayout? = null
    private var workspaceContent: FrameLayout? = null
    private var workspaceTitle: TextView? = null
    private var workspaceFullscreenButton: TextView? = null
    private var workspaceTabScroll: HorizontalScrollView? = null
    private var workspaceTabStrip: LinearLayout? = null
    private var browserAudioButton: TextView? = null
    private var workspaceBubble: ImageView? = null
    private var cursorView: View? = null
    private var appForeground: Boolean = true

    private data class SavedTab(
        val url: String,
        val title: String,
    )

    private data class BrowserSessionState(
        var savedTabs: List<SavedTab> = emptyList(),
        var activeIndex: Int = 0,
        var panelVisible: Boolean = false,
        var panelMinimized: Boolean = false,
        var panelFullscreen: Boolean = false,
        var panelLeft: Int = -1,
        var panelTop: Int = -1,
        var bubbleLeft: Int = -1,
        var bubbleTop: Int = -1,
        var adblockEnabled: Boolean = false,
        var browserAudioEnabled: Boolean = true,
    )

    private data class BrowserTab(
        val id: Int,
        val webView: WebView,
        val sessionId: String,
        var title: String = "",
        var url: String = "",
    )

    fun handle(call: MethodCall, result: MethodChannel.Result) {
        activity.runOnUiThread {
            try {
                when (call.method) {
                    "open" -> open(
                        url = call.argument<String>("url").orEmpty(),
                        desktop = call.argument<Boolean>("desktopMode") ?: true,
                        newTab = call.argument<Boolean>("newTab") ?: false,
                        result = result,
                    )
                    "read", "snapshot" -> snapshot(result)
                    "click" -> click(
                        selector = call.argument<String>("selector").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        result = result,
                    )
                    "fill" -> fill(
                        selector = call.argument<String>("selector").orEmpty(),
                        value = call.argument<String>("value").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        typeMode = call.argument<Boolean>("type_mode") ?: false,
                        result = result,
                    )
                    "selectOption" -> selectOption(
                        selector = call.argument<String>("selector").orEmpty(),
                        optionText = call.argument<String>("option_text").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        label = call.argument<String>("label").orEmpty(),
                        result = result,
                    )
                    "pressKey" -> pressKey(
                        selector = call.argument<String>("selector").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        key = call.argument<String>("key").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        repeat = (call.argument<Number>("repeat"))?.toInt() ?: 1,
                        result = result,
                    )
                    "submit" -> submit(
                        selector = call.argument<String>("selector").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        result = result,
                    )
                    "nativeGesture" -> nativeGesture(
                        action = call.argument<String>("action") ?: "click",
                        selector = call.argument<String>("selector").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        x = (call.argument<Number>("x"))?.toFloat(),
                        y = (call.argument<Number>("y"))?.toFloat(),
                        toX = (call.argument<Number>("toX"))?.toFloat(),
                        toY = (call.argument<Number>("toY"))?.toFloat(),
                        deltaY = (call.argument<Number>("deltaY"))?.toFloat(),
                        durationMs = (call.argument<Number>("durationMs"))?.toLong() ?: 320L,
                        result = result,
                    )
                    "back" -> navigate("back", result)
                    "forward" -> navigate("forward", result)
                    "reload" -> navigate("reload", result)
                    "bindSession" -> bindSession(
                        sessionId = call.argument<String>("sessionId").orEmpty(),
                        fresh = call.argument<Boolean>("fresh") ?: false,
                        result = result,
                    )
                    "workspaceShow" -> showWorkspace(
                        fullscreen = call.argument<Boolean>("fullscreen"),
                        result = result,
                    )
                    "workspaceHide" -> hideWorkspace(
                        dismiss = call.argument<Boolean>("dismiss") ?: false,
                        result = result,
                    )
                    "workspaceStatus" -> workspaceStatus(result)
                    "setAdblock" -> setAdblock(
                        enabled = call.argument<Boolean>("enabled") ?: false,
                        result = result,
                    )
                    "setBrowserAudio" -> setBrowserAudio(
                        enabled = call.argument<Boolean>("enabled") ?: true,
                        result = result,
                    )
                    "clearCookies" -> clearCookies(result)
                    "clearSession" -> clearSession(result)
                    "sessionStatus" -> sessionStatus(
                        url = call.argument<String>("url").orEmpty(),
                        result = result,
                    )
                    "setCookie" -> setCookie(
                        url = call.argument<String>("url").orEmpty(),
                        name = call.argument<String>("name").orEmpty(),
                        value = call.argument<String>("value").orEmpty(),
                        path = call.argument<String>("path") ?: "/",
                        secure = call.argument<Boolean>("secure") ?: true,
                        httpOnly = call.argument<Boolean>("httpOnly") ?: true,
                        sameSite = call.argument<String>("sameSite") ?: "Lax",
                        result = result,
                    )
                    "deleteCookie" -> deleteCookie(
                        url = call.argument<String>("url").orEmpty(),
                        name = call.argument<String>("name").orEmpty(),
                        path = call.argument<String>("path") ?: "/",
                        result = result,
                    )
                    "injectSession" -> injectSession(
                        url = call.argument<String>("url").orEmpty(),
                        cookies = call.argument<List<Any?>>("cookies") ?: emptyList(),
                        localStorage = call.argument<Map<String, Any?>>("localStorage")
                            ?: emptyMap(),
                        sessionStorage = call.argument<Map<String, Any?>>("sessionStorage")
                            ?: emptyMap(),
                        result = result,
                    )
                    "screenshot" -> screenshot(result)
                    "tabs" -> listTabs(result)
                    "switchTab" -> switchTab(
                        tabId = (call.argument<Number>("tabId"))?.toInt(),
                        result = result,
                    )
                    "closeTab" -> closeTab(
                        tabId = (call.argument<Number>("tabId"))?.toInt(),
                        result = result,
                    )
                    "cancel" -> cancelPendingWork(result)
                    else -> result.notImplemented()
                }
            } catch (error: Throwable) {
                result.error("browser_error", error.message ?: error.javaClass.simpleName, null)
            }
        }
    }

    private fun tabSummaryList(): List<Map<String, Any?>> =
        tabs.values.map { tab ->
            mapOf(
                "id" to tab.id,
                "url" to (tab.webView.url ?: tab.url),
                "title" to (tab.webView.title ?: tab.title),
                "active" to (tab.id == activeTabId),
            )
        }

    private fun listTabs(result: MethodChannel.Result) {
        result.success(
            mapOf(
                "success" to true,
                "activeTabId" to activeTabId,
                "maxTabs" to maxTabs,
                "count" to tabs.size,
                "tabs" to tabSummaryList(),
            ),
        )
    }

    private fun switchTab(tabId: Int?, result: MethodChannel.Result) {
        val id = tabId ?: run {
            result.error("invalid_tab", "tabId diperlukan.", null)
            return
        }
        var tab = tabs[id]
        var recovered = false
        // Tab lama sering di-evict (max 5) — jangan gagal keras; guna tab aktif.
        if (tab == null) {
            tab = tabs[activeTabId] ?: tabs.values.lastOrNull()
            recovered = true
            if (tab == null) {
                result.success(
                    mapOf(
                        "success" to false,
                        "recovered" to false,
                        "message" to
                            "Tab $id tidak wujud dan tiada tab lain. Buka URL baru dengan browser_open.",
                        "requestedTabId" to id,
                        "activeTabId" to activeTabId,
                        "tabs" to tabSummaryList(),
                        "maxTabs" to maxTabs,
                    ),
                )
                return
            }
        }
        activeTabId = tab.id
        syncBrowserAudioState()
        refreshWorkspaceContentIfVisible()
        refreshWorkspaceTabs()
        try {
            tab.webView.requestFocus()
            applyTabAudioState(tab.webView)
        } catch (_: Throwable) {
        }
        result.success(
            mapOf(
                "success" to true,
                "recovered" to recovered,
                "message" to if (recovered) {
                    "Tab $id sudah ditutup/evict (max $maxTabs). Beralih ke tab aktif ${tab.id}."
                } else {
                    "Tab ${tab.id} aktif."
                },
                "requestedTabId" to id,
                "activeTabId" to activeTabId,
                "url" to (tab.webView.url ?: tab.url),
                "title" to (tab.webView.title ?: tab.title),
                "tabs" to tabSummaryList(),
                "maxTabs" to maxTabs,
            ),
        )
    }

    private fun closeTab(tabId: Int?, result: MethodChannel.Result) {
        val id = tabId ?: activeTabId
        val tab = tabs.remove(id)
        if (tab == null) {
            result.error("invalid_tab", "Tab $id tidak wujud.", null)
            return
        }
        destroyWebView(tab.webView)
        if (activeTabId == id) {
            activeTabId = tabs.keys.lastOrNull() ?: 0
        }
        syncBrowserAudioState()
        refreshWorkspaceContentIfVisible()
        refreshWorkspaceTabs()
        result.success(
            mapOf(
                "success" to true,
                "closedTabId" to id,
                "activeTabId" to activeTabId,
                "tabs" to tabSummaryList(),
            ),
        )
    }

    private fun destroyWebView(view: WebView) {
        try {
            (view.parent as? ViewGroup)?.removeView(view)
        } catch (_: Throwable) {
        }
        try {
            view.stopLoading()
            view.loadUrl("about:blank")
            view.webChromeClient = null
            view.destroy()
        } catch (_: Throwable) {
        }
    }

    private fun activeWebView(): WebView = ensureActiveTab().webView

    private fun ensureActiveTab(): BrowserTab {
        tabs[activeTabId]?.let { return it }
        return createTab(makeActive = true)
    }

    /** Tutup tab tertua yang bukan aktif (atau mana-mana jika terpaksa). */
    private fun evictOldestInactiveTab(): Boolean {
        val victim = tabs.entries.firstOrNull { it.key != activeTabId }
            ?: tabs.entries.firstOrNull()
            ?: return false
        tabs.remove(victim.key)
        destroyWebView(victim.value.webView)
        if (activeTabId == victim.key) {
            activeTabId = tabs.keys.lastOrNull() ?: 0
        }
        return true
    }

    private fun createTab(makeActive: Boolean = true): BrowserTab {
        if (tabs.size >= maxTabs) {
            if (!evictOldestInactiveTab()) {
                throw IllegalStateException(
                    "Had $maxTabs tab dicapai. Tutup satu tab (browser_close_tab) dahulu.",
                )
            }
        }
        val id = nextTabId++
        val view = buildWebView(id)
        val tab = BrowserTab(
            id = id,
            webView = view,
            sessionId = currentSessionId,
        )
        tabs[id] = tab
        if (makeActive || activeTabId == 0) {
            activeTabId = id
        }
        syncBrowserAudioState()
        refreshWorkspaceContentIfVisible()
        refreshWorkspaceTabs()
        return tab
    }

    private fun sessionState(id: String = currentSessionId): BrowserSessionState =
        sessionStates.getOrPut(id) { BrowserSessionState() }

    private fun supportsProfiles(): Boolean =
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)

    private fun profileName(sessionId: String): String {
        val safe = sessionId.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(96)
        return "ai_chat_${safe.ifEmpty { "default" }}"
    }

    private fun cookieManagerForSession(sessionId: String): CookieManager {
        if (!supportsProfiles()) return CookieManager.getInstance()
        return ProfileStore.getInstance()
            .getOrCreateProfile(profileName(sessionId))
            .cookieManager
    }

    private fun webStorageForSession(sessionId: String): WebStorage {
        if (!supportsProfiles()) return WebStorage.getInstance()
        return ProfileStore.getInstance()
            .getOrCreateProfile(profileName(sessionId))
            .webStorage
    }

    /**
     * Satu chat menggunakan satu profil WebView. Hanya tab sesi aktif hidup;
     * sesi lain menyimpan URL/tajuk sahaja supaya RAM tidak bertambah mengikut
     * bilangan chat.
     */
    private fun bindSession(
        sessionId: String,
        fresh: Boolean,
        result: MethodChannel.Result,
    ) {
        val target = sessionId.trim()
        if (target.isEmpty()) {
            result.error("invalid_session", "sessionId diperlukan.", null)
            return
        }
        if (target == currentSessionId && !fresh) {
            restoreWorkspaceVisibility()
            result.success(workspacePayload())
            return
        }

        saveCurrentSessionState()
        hideWorkspaceInternal(remember = false)
        destroyActiveTabs()
        currentSessionId = target
        if (fresh) {
            sessionStates[target] = BrowserSessionState()
        }
        activeAdblockEnabled = sessionState(target).adblockEnabled

        val finish = {
            restoreCurrentSession()
            restoreWorkspaceVisibility()
            result.success(workspacePayload())
        }

        if (supportsProfiles()) {
            if (fresh) {
                val manager = cookieManagerForSession(target)
                webStorageForSession(target).deleteAllData()
                manager.removeAllCookies {
                    manager.flush()
                    finish()
                }
            } else {
                finish()
            }
            return
        }

        // Fallback peranti lama: profil berasingan tiada. Bersihkan profil
        // default pada setiap pertukaran supaya login chat lain tidak terbawa.
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            finish()
        }
    }

    private fun saveCurrentSessionState() {
        val state = sessionState()
        state.savedTabs = tabs.values.map { tab ->
            SavedTab(
                url = tab.webView.url ?: tab.url,
                title = tab.webView.title ?: tab.title,
            )
        }
        state.activeIndex = tabs.keys.indexOf(activeTabId).coerceAtLeast(0)
    }

    private fun restoreCurrentSession() {
        val state = sessionState()
        val saved = state.savedTabs.take(maxTabs)
        state.savedTabs = emptyList()
        for (item in saved) {
            val tab = createTab(makeActive = false)
            tab.url = item.url
            tab.title = item.title
            if (item.url.startsWith("http://") || item.url.startsWith("https://")) {
                tab.webView.loadUrl(item.url)
            }
        }
        if (tabs.isNotEmpty()) {
            val index = state.activeIndex.coerceIn(0, tabs.size - 1)
            activeTabId = tabs.keys.elementAt(index)
        }
        syncBrowserAudioState()
    }

    private fun restoreWorkspaceVisibility() {
        val state = sessionState()
        if (state.panelVisible) {
            showWorkspaceInternal()
        } else if (state.panelMinimized) {
            showWorkspaceBubbleInternal()
        }
    }

    private fun destroyActiveTabs() {
        val all = tabs.values.toList()
        tabs.clear()
        activeTabId = 0
        nextTabId = 1
        for (tab in all) destroyWebView(tab.webView)
    }

    private fun buildWorkspacePanel(): FrameLayout {
        workspacePanel?.let { return it }
        val root = activity.window.decorView as? ViewGroup
            ?: throw IllegalStateException("Paparan aplikasi tidak tersedia.")
        val screen = activity.resources.displayMetrics
        val width = min(max(1, screen.widthPixels - dp(12)), dp(280))
        val height = min(max(1, screen.heightPixels - dp(82)), dp(220))

        val panel = FrameLayout(activity).apply {
            elevation = dp(14).toFloat()
            visibility = View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.rgb(10, 14, 24))
                setStroke(dp(1), Color.rgb(56, 66, 88))
            }
        }
        val panelParams = FrameLayout.LayoutParams(width, height).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(12)
            topMargin = dp(82)
        }
        root.addView(panel, panelParams)

        val header = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(6), 0)
            setBackgroundColor(Color.rgb(20, 26, 40))
        }
        panel.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48),
            ),
        )

        val title = TextView(activity).apply {
            text = "Browser AI"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setTypeface(typeface, Typeface.BOLD)
        }
        header.addView(
            title,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f),
        )
        workspaceTitle = title
        val fullscreen = TextView(activity).apply {
            text = "□"
            contentDescription = "Skrin penuh"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setOnClickListener { toggleWorkspaceFullscreen() }
        }
        header.addView(fullscreen, LinearLayout.LayoutParams(dp(42), dp(48)))
        workspaceFullscreenButton = fullscreen
        val close = TextView(activity).apply {
            text = "×"
            contentDescription = "Minimumkan panel"
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
            setOnClickListener { minimizeWorkspaceInternal(remember = true) }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(48)))

        val tabScroll = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(14, 19, 31))
            visibility = View.VISIBLE
        }
        val tabStrip = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        tabScroll.addView(
            tabStrip,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        panel.addView(
            tabScroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(44),
            ).apply { topMargin = dp(48) },
        )
        workspaceTabScroll = tabScroll
        workspaceTabStrip = tabStrip

        val content = FrameLayout(activity).apply {
            setBackgroundColor(Color.BLACK)
        }
        panel.addView(
            content,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ).apply {
                topMargin = dp(92)
            },
        )
        workspaceContent = content

        val cursor = WorkspaceCursorView(activity).apply {
            visibility = View.GONE
            isClickable = false
            isFocusable = false
        }
        content.addView(cursor, FrameLayout.LayoutParams(dp(26), dp(34)))
        cursorView = cursor

        var dragStartX = 0f
        var dragStartY = 0f
        var startLeft = 0
        var startTop = 0
        var dragMoved = false
        val dragSlop = ViewConfiguration.get(activity).scaledTouchSlop
        val workspaceDragTouchListener = View.OnTouchListener { view, event ->
            val params = panel.layoutParams as FrameLayout.LayoutParams
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX
                    dragStartY = event.rawY
                    startLeft = params.leftMargin
                    startTop = params.topMargin
                    dragMoved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - dragStartX
                    val dy = event.rawY - dragStartY
                    if (sqrt(dx * dx + dy * dy) > dragSlop) dragMoved = true
                    if (!sessionState().panelFullscreen && dragMoved) {
                        val maxLeft = max(0, root.width - panel.width)
                        val minTop = safeTopInset()
                        val maxTop = max(minTop, root.height - safeBottomInset() - panel.height)
                        params.leftMargin = (startLeft + dx).roundToInt().coerceIn(0, maxLeft)
                        params.topMargin = (startTop + dy).roundToInt().coerceIn(minTop, maxTop)
                        panel.layoutParams = params
                        rememberWindowedBounds(params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragMoved) view.performClick()
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        listOf(header, title, fullscreen, close).forEach { view ->
            view.setOnTouchListener(workspaceDragTouchListener)
        }
        workspacePanel = panel
        return panel
    }

    private fun rememberWindowedBounds(params: FrameLayout.LayoutParams) {
        val state = sessionState()
        if (state.panelFullscreen) return
        state.panelLeft = params.leftMargin
        state.panelTop = params.topMargin
    }

    private fun toggleWorkspaceFullscreen() {
        val state = sessionState()
        val panel = workspacePanel
        if (!state.panelFullscreen && panel != null) {
            rememberWindowedBounds(panel.layoutParams as FrameLayout.LayoutParams)
        }
        state.panelFullscreen = !state.panelFullscreen
        applyWorkspaceLayout()
    }

    private fun applyWorkspaceLayout() {
        val panel = workspacePanel ?: return
        val root = activity.window.decorView as? ViewGroup ?: return
        val state = sessionState()
        val params = panel.layoutParams as FrameLayout.LayoutParams
        val screen = activity.resources.displayMetrics
        val topInset = safeTopInset()
        val bottomInset = safeBottomInset()
        val boundsWidth = if (root.width > 0) root.width else screen.widthPixels
        val boundsHeight = if (root.height > 0) root.height else screen.heightPixels
        val availableHeight = max(1, boundsHeight - topInset - bottomInset)
        if (state.panelFullscreen) {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = availableHeight
            params.leftMargin = 0
            params.topMargin = topInset
        } else {
            val compactWidth = min(boundsWidth, dp(280))
            val compactHeight = min(availableHeight, dp(220))
            params.width = compactWidth
            params.height = compactHeight
            params.leftMargin = (if (state.panelLeft >= 0) state.panelLeft else dp(12))
                .coerceIn(0, max(0, boundsWidth - compactWidth))
            params.topMargin = (if (state.panelTop >= 0) state.panelTop else dp(82))
                .coerceIn(topInset, max(topInset, boundsHeight - bottomInset - compactHeight))
        }
        panel.layoutParams = params
        workspaceFullscreenButton?.text = if (state.panelFullscreen) "↙" else "□"
        workspaceFullscreenButton?.contentDescription =
            if (state.panelFullscreen) "Kembali terapung" else "Skrin penuh"
    }

    private fun systemBarSize(name: String): Int {
        val resourceId = activity.resources.getIdentifier(name, "dimen", "android")
        return if (resourceId > 0) activity.resources.getDimensionPixelSize(resourceId) else 0
    }

    private fun safeTopInset(): Int = max(dp(24), systemBarSize("status_bar_height"))

    private fun safeBottomInset(): Int = max(0, systemBarSize("navigation_bar_height"))

    private fun showWorkspace(
        fullscreen: Boolean?,
        result: MethodChannel.Result,
    ) {
        val state = sessionState()
        state.panelVisible = true
        state.panelMinimized = false
        if (fullscreen != null && fullscreen != state.panelFullscreen) {
            val panel = workspacePanel
            if (fullscreen && panel != null && !state.panelFullscreen) {
                rememberWindowedBounds(panel.layoutParams as FrameLayout.LayoutParams)
            }
            state.panelFullscreen = fullscreen
        }
        showWorkspaceInternal()
        result.success(workspacePayload())
    }

    private fun showWorkspaceInternal() {
        val state = sessionState()
        state.panelVisible = true
        state.panelMinimized = false
        workspaceBubble?.visibility = View.GONE
        val panel = buildWorkspacePanel()
        applyWorkspaceLayout()
        panel.visibility = View.VISIBLE
        panel.bringToFront()
        workspaceTitle?.text = "Browser AI"
        workspaceTabScroll?.visibility = View.VISIBLE
        updateWorkspaceContentTopMargin(dp(92))
        attachWorkspaceView(activeWebView())
        refreshWorkspaceTabs()
        syncBrowserAudioState()
    }

    private fun hideWorkspace(
        dismiss: Boolean,
        result: MethodChannel.Result,
    ) {
        if (dismiss) dismissWorkspaceInternal(remember = true)
        else minimizeWorkspaceInternal(remember = true)
        result.success(workspacePayload())
    }

    private fun hideWorkspaceInternal(remember: Boolean) {
        dismissWorkspaceInternal(remember)
    }

    private fun minimizeWorkspaceInternal(remember: Boolean) {
        if (remember) {
            sessionState().panelVisible = false
            sessionState().panelMinimized = true
        }
        cursorView?.visibility = View.GONE
        val active = tabs[activeTabId]?.webView
        if (active != null) placeWebViewOffscreen(active)
        workspacePanel?.visibility = View.GONE
        showWorkspaceBubbleInternal()
        syncBrowserAudioState()
    }

    private fun dismissWorkspaceInternal(remember: Boolean) {
        if (remember) {
            sessionState().panelVisible = false
            sessionState().panelMinimized = false
        }
        cursorView?.visibility = View.GONE
        val active = tabs[activeTabId]?.webView
        if (active != null) placeWebViewOffscreen(active)
        workspacePanel?.visibility = View.GONE
        workspaceBubble?.visibility = View.GONE
        syncBrowserAudioState()
    }

    private fun workspaceStatus(result: MethodChannel.Result) {
        result.success(workspacePayload())
    }

    private fun workspacePayload(): Map<String, Any?> {
        val state = sessionState()
        val active = tabs[activeTabId]
        return mapOf(
            "success" to true,
            "sessionId" to currentSessionId,
            "visible" to state.panelVisible,
            "minimized" to state.panelMinimized,
            "mode" to "browser",
            "fullscreen" to state.panelFullscreen,
            "adblockEnabled" to state.adblockEnabled,
            "browserAudioEnabled" to state.browserAudioEnabled,
            "activeTabId" to activeTabId,
            "tabCount" to tabs.size,
            "url" to (active?.webView?.url ?: active?.url.orEmpty()),
            "title" to (active?.webView?.title ?: active?.title.orEmpty()),
            "multiProfile" to supportsProfiles(),
        )
    }

    private fun refreshWorkspaceContentIfVisible() {
        val state = sessionState()
        if (!state.panelVisible || workspacePanel?.visibility != View.VISIBLE) return
        if (tabs.isNotEmpty()) {
            attachWorkspaceView(tabs[activeTabId]?.webView ?: return)
        }
    }

    private fun updateWorkspaceContentTopMargin(top: Int) {
        val content = workspaceContent ?: return
        val params = content.layoutParams as? FrameLayout.LayoutParams ?: return
        if (params.topMargin == top) return
        params.topMargin = top
        content.layoutParams = params
    }

    private fun refreshWorkspaceTabs() {
        val strip = workspaceTabStrip ?: return
        strip.removeAllViews()
        val state = sessionState()
        val audio = TextView(activity).apply {
            text = if (state.browserAudioEnabled) "🔊" else "🔇"
            contentDescription = if (state.browserAudioEnabled) {
                "Matikan audio Browser"
            } else {
                "Hidupkan audio Browser"
            }
            textSize = 17f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(45, 53, 73))
                setStroke(dp(1), Color.rgb(77, 88, 116))
            }
            setOnClickListener {
                state.browserAudioEnabled = !state.browserAudioEnabled
                syncBrowserAudioState()
                refreshWorkspaceTabs()
            }
        }
        browserAudioButton = audio
        strip.addView(
            audio,
            LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(8) },
        )
        for (tab in tabs.values) {
            val selected = tab.id == activeTabId
            val pill = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, if (selected) dp(2) else dp(10), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(13).toFloat()
                    setColor(if (selected) Color.rgb(82, 61, 144) else Color.rgb(27, 34, 50))
                    setStroke(dp(1), if (selected) Color.rgb(190, 166, 255) else Color.rgb(54, 64, 84))
                }
                setOnClickListener { switchTabFromUi(tab.id) }
            }
            val label = TextView(activity).apply {
                val raw = (tab.webView.title ?: tab.title).ifBlank {
                    (tab.webView.url ?: tab.url).ifBlank { "Tab ${tab.id}" }
                }
                text = raw.replace(Regex("\\s+"), " ").take(24)
                setTextColor(Color.WHITE)
                textSize = 12f
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
            }
            pill.addView(label, LinearLayout.LayoutParams(dp(118), dp(34)))
            if (selected) {
                val close = TextView(activity).apply {
                    text = "×"
                    contentDescription = "Tutup tab ${tab.id}"
                    setTextColor(Color.rgb(224, 216, 255))
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setOnClickListener { closeTabFromUi(tab.id) }
                }
                pill.addView(close, LinearLayout.LayoutParams(dp(34), dp(34)))
            }
            strip.addView(
                pill,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    dp(34),
                ).apply { marginEnd = dp(6) },
            )
        }
        val add = TextView(activity).apply {
            text = "+"
            contentDescription = "Tab baru"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(45, 53, 73))
            }
            setOnClickListener {
                val tab = createTab(makeActive = true)
                tab.webView.loadUrl("about:blank")
                refreshWorkspaceTabs()
            }
        }
        strip.addView(add, LinearLayout.LayoutParams(dp(34), dp(34)))
    }

    private fun switchTabFromUi(tabId: Int) {
        val tab = tabs[tabId] ?: return
        activeTabId = tabId
        syncBrowserAudioState()
        refreshWorkspaceContentIfVisible()
        refreshWorkspaceTabs()
        tab.webView.requestFocus()
    }

    private fun closeTabFromUi(tabId: Int) {
        val tab = tabs.remove(tabId) ?: return
        destroyWebView(tab.webView)
        if (activeTabId == tabId) activeTabId = tabs.keys.lastOrNull() ?: 0
        if (tabs.isEmpty()) createTab(makeActive = true).webView.loadUrl("about:blank")
        syncBrowserAudioState()
        refreshWorkspaceContentIfVisible()
        refreshWorkspaceTabs()
    }

    private fun showWorkspaceBubbleInternal() {
        val root = activity.window.decorView as? ViewGroup ?: return
        val state = sessionState()
        val bubble = workspaceBubble ?: ImageView(activity).apply {
            setImageResource(R.mipmap.ic_launcher)
            contentDescription = "Buka semula Browser"
            setPadding(dp(6), dp(6), dp(6), dp(6))
            elevation = dp(16).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(25, 29, 43))
                setStroke(dp(2), Color.rgb(173, 151, 255))
            }
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            val slop = ViewConfiguration.get(activity).scaledTouchSlop
            setOnTouchListener { view, event ->
                val params = view.layoutParams as FrameLayout.LayoutParams
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = params.leftMargin
                        startY = params.topMargin
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (sqrt(dx * dx + dy * dy) > slop) moved = true
                        params.leftMargin = (startX + dx).roundToInt()
                            .coerceIn(0, max(0, root.width - view.width))
                        params.topMargin = (startY + dy).roundToInt()
                            .coerceIn(safeTopInset(), max(safeTopInset(), root.height - safeBottomInset() - view.height))
                        view.layoutParams = params
                        sessionState().bubbleLeft = params.leftMargin
                        sessionState().bubbleTop = params.topMargin
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            showWorkspaceInternal()
                        }
                        true
                    }
                    else -> true
                }
            }
        }.also {
            workspaceBubble = it
            root.addView(
                it,
                FrameLayout.LayoutParams(dp(58), dp(58)).apply {
                    leftMargin = if (state.bubbleLeft >= 0) state.bubbleLeft else max(0, root.width - dp(76))
                    topMargin = if (state.bubbleTop >= 0) state.bubbleTop else max(safeTopInset(), root.height / 2)
                },
            )
        }
        bubble.contentDescription = "Buka semula Browser"
        val params = bubble.layoutParams as? FrameLayout.LayoutParams
        if (params != null) {
            params.leftMargin = (if (state.bubbleLeft >= 0) state.bubbleLeft else max(0, root.width - dp(76)))
                .coerceIn(0, max(0, root.width - dp(58)))
            params.topMargin = (if (state.bubbleTop >= 0) state.bubbleTop else max(safeTopInset(), root.height / 2))
                .coerceIn(safeTopInset(), max(safeTopInset(), root.height - safeBottomInset() - dp(58)))
            bubble.layoutParams = params
        }
        bubble.visibility = View.VISIBLE
        bubble.bringToFront()
    }

    private fun attachWorkspaceView(view: WebView) {
        val content = workspaceContent ?: return
        val displacedViews = (0 until content.childCount)
            .mapNotNull { content.getChildAt(it) as? WebView }
            .filter { it !== view }
        for (displaced in displacedViews) {
            content.removeView(displaced)
            placeWebViewOffscreen(displaced)
        }
        (view.parent as? ViewGroup)?.removeView(view)
        view.alpha = 1f
        view.translationX = 0f
        view.translationY = 0f
        view.visibility = View.VISIBLE
        content.addView(
            view,
            0,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        cursorView?.bringToFront()
        view.requestFocus()
    }

    private fun placeWebViewOffscreen(view: WebView) {
        val root = activity.window.decorView as? ViewGroup ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        view.alpha = 0.01f
        view.translationX = -10000f
        view.translationY = -10000f
        view.visibility = View.VISIBLE
        root.addView(view, ViewGroup.LayoutParams(1080, 1920))
    }

    private fun dp(value: Int): Int =
        (value * activity.resources.displayMetrics.density).roundToInt()

    private fun setAdblock(enabled: Boolean, result: MethodChannel.Result) {
        val state = sessionState()
        state.adblockEnabled = enabled
        activeAdblockEnabled = enabled
        for (tab in tabs.values) applyAdblock(tab.webView)
        result.success(
            workspacePayload() + mapOf(
                "message" to if (enabled) {
                    "Adblock hidup untuk chat ini sahaja."
                } else {
                    "Adblock dimatikan untuk chat ini."
                },
            ),
        )
    }

    private fun setBrowserAudio(enabled: Boolean, result: MethodChannel.Result) {
        val state = sessionState()
        state.browserAudioEnabled = enabled
        syncBrowserAudioState()
        refreshWorkspaceTabs()
        result.success(
            workspacePayload() + mapOf(
                "message" to if (enabled) {
                    "Audio Browser hidup. Hanya tab aktif yang terlihat boleh berbunyi."
                } else {
                    "Audio Browser dimatikan untuk chat ini."
                },
            ),
        )
    }

    private fun applyAdblock(view: WebView) {
        val owner = tabs.values.firstOrNull { it.webView === view }?.sessionId
            ?: currentSessionId
        val enabled = sessionState(owner).adblockEnabled
        val script = if (enabled) ENABLE_ADBLOCK_SCRIPT else DISABLE_ADBLOCK_SCRIPT
        try {
            view.evaluateJavascript(script, null)
        } catch (_: Throwable) {
        }
    }

    private fun shouldBlockRequest(host: String): Boolean {
        val normalized = host.lowercase().trimEnd('.')
        if (normalized.isEmpty()) return false
        return ADBLOCK_HOSTS.any { blocked ->
            normalized == blocked || normalized.endsWith(".$blocked")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(tabId: Int): WebView {
        val tabSessionId = currentSessionId
        val created = WebView(activity)
        if (supportsProfiles()) {
            WebViewCompat.setProfile(created, profileName(currentSessionId))
        }
        created.setBackgroundColor(Color.TRANSPARENT)
        created.alpha = 0.01f
        created.translationX = -10000f
        created.translationY = -10000f
        created.layoutParams = ViewGroup.LayoutParams(1080, 1920)
        created.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            blockNetworkImage = false
            allowContentAccess = false
            allowFileAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                offscreenPreRaster = true
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        cookieManagerForSession(currentSessionId).apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(created, true)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                created,
                MUTE_MEDIA_SCRIPT,
                setOf("*"),
            )
        }
        created.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?,
            ): Boolean {
                if (resultMsg == null) return false
                return try {
                    // createTab auto-evict jika had 5 penuh.
                    val tab = createTab(makeActive = true)
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                        ?: return false
                    transport.webView = tab.webView
                    resultMsg.sendToTarget()
                    true
                } catch (_: Throwable) {
                    false
                }
            }

            override fun onCloseWindow(window: WebView?) {
                if (window == null) return
                val entry = tabs.entries.firstOrNull { it.value.webView === window } ?: return
                tabs.remove(entry.key)
                destroyWebView(window)
                if (activeTabId == entry.key) {
                    activeTabId = tabs.keys.lastOrNull() ?: 0
                }
                if (tabs.isEmpty()) createTab(makeActive = true).webView.loadUrl("about:blank")
                syncBrowserAudioState()
                refreshWorkspaceContentIfVisible()
                refreshWorkspaceTabs()
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (view == null) return
                tabs.entries.firstOrNull { it.value.webView === view }?.value?.title =
                    title.orEmpty()
                refreshWorkspaceTabs()
            }
        }
        created.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                applyTabAudioState(view)
                tabs[tabId]?.let {
                    it.url = url.orEmpty()
                }
                refreshWorkspaceTabs()
            }

            override fun onPageCommitVisible(view: WebView, url: String) {
                applyTabAudioState(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
            ): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?,
            ): WebResourceResponse? {
                val host = request?.url?.host.orEmpty()
                if (tabSessionId == currentSessionId && activeAdblockEnabled &&
                    shouldBlockRequest(host)
                ) {
                    return WebResourceResponse(
                        "text/plain",
                        "utf-8",
                        ByteArrayInputStream(ByteArray(0)),
                    )
                }
                return null
            }

            override fun onPageFinished(view: WebView, url: String) {
                applyTabAudioState(view)
                applyAdblock(view)
                tabs[tabId]?.let {
                    it.url = url
                    it.title = view.title.orEmpty()
                }
                refreshWorkspaceTabs()
                // Snapshot pending hanya untuk tab aktif
                if (tabId == activeTabId && pendingResult != null && !pendingDone.get()) {
                    // SPA (GitHub dsb.): tunggu render sebelum snapshot untuk AI
                    val gen = pendingGen
                    mainHandler.postDelayed({ snapshotPending(gen) }, 1200L)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError,
            ) {
                if (request.isForMainFrame && tabId == activeTabId) {
                    finishError("load_error", error.description?.toString() ?: "Gagal memuat halaman")
                }
            }
        }
        val root = activity.window.decorView as? ViewGroup
        root?.addView(created)
        return created
    }

    private fun open(
        url: String,
        desktop: Boolean,
        newTab: Boolean,
        result: MethodChannel.Result,
    ) {
        var normalized = url.trim()
        if (normalized.startsWith("//")) {
            normalized = "https:$normalized"
        } else if (!normalized.startsWith("http://") &&
            !normalized.startsWith("https://")
        ) {
            // domain.com/path → https://domain.com/path
            if (normalized.contains(".") && !normalized.contains(" ")) {
                normalized = "https://$normalized"
            } else {
                result.error(
                    "invalid_url",
                    "URL HTTP/HTTPS tidak sah: ${url.take(120)}",
                    null,
                )
                return
            }
        }
        desktopMode = desktop
        val tab = try {
            when {
                tabs.isEmpty() -> ensureActiveTab()
                newTab -> {
                    // new_tab eksplisit: evict auto dalam createTab jika penuh
                    createTab(makeActive = true)
                }
                else -> ensureActiveTab()
            }
        } catch (error: Throwable) {
            result.error(
                "tab_limit",
                error.message,
                mapOf("tabs" to tabSummaryList(), "maxTabs" to maxTabs),
            )
            return
        }
        val view = tab.webView
        view.settings.userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
        applyTabAudioState(view)
        if (!beginPending(result, 120_000L)) return
        view.loadUrl(normalized)
    }

    private fun snapshot(result: MethodChannel.Result) {
        val view = activeWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif dalam browser latar belakang.", null)
            return
        }
        if (!beginPending(result, 60_000L)) return
        snapshotPending(pendingGen)
    }

    private fun click(selector: String, text: String, index: Int?, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val textJson = JSONObject.quote(text)
        val indexJs = index?.toString() ?: "null"
        // Self-heal: cuba index → text → selector dalam satu tindakan.
        val script = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, $textJson, $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Elemen tidak ditemui. Panggil browser_read semula untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const before = document.activeElement;
              CLAW.realClick(el);
              const expanded = el.getAttribute('aria-expanded');
              return JSON.stringify({
                success:true,
                action:'click',
                strategy:found.strategy,
                index: $indexJs,
                tag: (el.tagName || '').toLowerCase(),
                role: el.getAttribute('role') || '',
                aria_expanded: expanded === null ? '' : expanded,
                opened_popup: expanded === 'true',
                focus_moved: before !== document.activeElement
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 700L)
    }

    private fun fill(
        selector: String,
        value: String,
        index: Int?,
        typeMode: Boolean,
        result: MethodChannel.Result,
    ) {
        if (selector.isBlank() && index == null) {
            result.error("missing_target", "Index atau CSS selector diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val valueJson = JSONObject.quote(value)
        val indexJs = index?.toString() ?: "null"
        val typeJs = if (typeMode) "true" else "false"
        val script = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, '', $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Input tidak ditemui. Panggil browser_read semula untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const value = $valueJson;
              const tag = (el.tagName || '').toLowerCase();
              const role = el.getAttribute('role') || '';
              const popup = el.getAttribute('aria-haspopup') || '';

              // Dropdown tersuai bukan medan teks — set value tidak akan berkesan.
              const isCustomSelect = tag !== 'select' && tag !== 'input' && tag !== 'textarea' &&
                !el.isContentEditable &&
                (role === 'combobox' || role === 'listbox' || popup === 'listbox' || popup === 'menu' || popup === 'true');
              if (isCustomSelect) {
                return JSON.stringify({
                  success:false,
                  error:'Elemen ini dropdown tersuai (role=' + (role || popup) + '), bukan input teks. Guna browser_select_option dengan option_text.',
                  use_tool:'browser_select_option'
                });
              }

              try { el.scrollIntoView({block:'center',inline:'center'}); } catch (e) { }

              if (el.isContentEditable) {
                try { el.focus(); } catch (e) { }
                el.textContent = value;
                CLAW.notify(el);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'contenteditable'});
              }

              if (tag === 'select') {
                const opts = Array.from(el.options || []);
                const target = CLAW.clean(value).toLowerCase();
                let opt = opts.find(function (o) { return o.value === value; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase() === target; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase().indexOf(target) === 0; });
                if (!opt) {
                  return JSON.stringify({
                    success:false,
                    error:'Pilihan tidak wujud dalam select.',
                    available: opts.slice(0, 40).map(function (o) { return CLAW.clean(o.text); })
                  });
                }
                CLAW.setNativeValue(el, opt.value);
                CLAW.notify(el);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'select',selected:CLAW.clean(opt.text)});
              }

              // Input bertopeng (DD/MM/YYYY, nombor kad) menolak set value terus.
              if ($typeJs) {
                CLAW.setNativeValue(el, '');
                CLAW.typeText(el, value);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'type',value_now:el.value || ''});
              }

              try { el.focus({preventScroll:true}); } catch (e) { try { el.focus(); } catch (e2) { } }
              CLAW.setNativeValue(el, value);
              CLAW.notify(el);
              return JSON.stringify({
                success:true,
                action:'fill',
                strategy:found.strategy,
                mode:'value',
                value_now: el.value || '',
                accepted: (el.value || '') === value
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 200L)
    }

    /**
     * Pilih satu nilai daripada dropdown — native `<select>` ATAU komponen
     * tersuai React (Radix, Headless UI, MUI, react-select).
     *
     * Dropdown tersuai tidak boleh diselesaikan dalam satu skrip: senarai
     * pilihan hanya wujud dalam DOM SELEPAS pencetus dibuka, dan selalunya
     * dirender ke portal di hujung <body>. Jadi ia dijalankan dua fasa dengan
     * jeda sebenar di antaranya supaya React sempat render.
     *
     *   Fasa 1 — buka pencetus (atau selesai terus jika <select> native).
     *   Fasa 2 — cari pilihan yang baru muncul, klik dengan urutan pointer.
     */
    private fun selectOption(
        selector: String,
        optionText: String,
        index: Int?,
        label: String,
        result: MethodChannel.Result,
    ) {
        if (optionText.isBlank()) {
            result.error("missing_option", "option_text diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val optionJson = JSONObject.quote(optionText)
        val labelJson = JSONObject.quote(label)
        val indexJs = index?.toString() ?: "null"

        val openScript = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, $labelJson, $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Dropdown tidak ditemui. Panggil browser_read untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const wanted = $optionJson;

              // Native <select>: selesai terus, tiada fasa kedua.
              if ((el.tagName || '').toLowerCase() === 'select') {
                const opts = Array.from(el.options || []);
                const target = CLAW.clean(wanted).toLowerCase();
                let opt = opts.find(function (o) { return o.value === wanted; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase() === target; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase().indexOf(target) === 0; });
                if (!opt) {
                  return JSON.stringify({
                    success:false,
                    error:'Pilihan tidak wujud.',
                    available: opts.slice(0, 60).map(function (o) { return CLAW.clean(o.text); })
                  });
                }
                CLAW.setNativeValue(el, opt.value);
                CLAW.notify(el);
                return JSON.stringify({success:true,done:true,mode:'native-select',selected:CLAW.clean(opt.text)});
              }

              // Rekod pilihan sedia ada supaya fasa 2 tahu mana yang BARU muncul.
              window.__clawBefore = CLAW.deepAll(CLAW_OPTION_SELECTOR).filter(CLAW.isVisible).length;
              window.__clawTrigger = el;
              CLAW.realClick(el);
              return JSON.stringify({
                success:true,
                done:false,
                mode:'custom',
                strategy:found.strategy,
                role: el.getAttribute('role') || '',
                options_before: window.__clawBefore
              });
            })();
        """.trimIndent()

        val pickScript = """
            (() => {
              $CLAW_PRELUDE
              const wanted = $optionJson;
              const trigger = window.__clawTrigger || null;

              // Utamakan listbox yang dikawal pencetus (aria-controls / aria-owns).
              let scope = null;
              if (trigger) {
                const owns = trigger.getAttribute('aria-controls') || trigger.getAttribute('aria-owns');
                if (owns) {
                  try { scope = document.getElementById(owns); } catch (e) { scope = null; }
                }
              }

              let nodes = [];
              if (scope) {
                nodes = Array.from(scope.querySelectorAll(CLAW_OPTION_SELECTOR)).filter(CLAW.isVisible);
              }
              if (!nodes.length) {
                nodes = CLAW.deepAll(CLAW_OPTION_SELECTOR).filter(CLAW.isVisible);
              }
              if (!nodes.length) {
                return JSON.stringify({
                  success:false,
                  error:'Dropdown tidak membuka sebarang pilihan. Cuba browser_press_key(key="ArrowDown") pada pencetus, atau browser_screenshot untuk lihat keadaan.',
                  options_before: window.__clawBefore || 0
                });
              }

              const hit = CLAW.matchOption(nodes, wanted);
              if (!hit) {
                return JSON.stringify({
                  success:false,
                  error:'Pilihan "' + wanted + '" tidak ditemui dalam senarai yang terbuka.',
                  available: nodes.slice(0, 60).map(function (n) { return CLAW.clean(n.innerText || n.textContent || ''); }).filter(function (t) { return t; })
                });
              }

              CLAW.realClick(hit);
              const chosen = CLAW.clean(hit.innerText || hit.textContent || '');
              window.__clawTrigger = null;
              return JSON.stringify({
                success:true,
                done:true,
                mode:'custom',
                selected: chosen,
                option_count: nodes.length,
                scoped: !!scope
              });
            })();
        """.trimIndent()

        val view = activeWebView()
        view.evaluateJavascript(openScript) { rawOpen ->
            try {
                val openResult = decodeJavascriptObject(rawOpen)
                if (!openResult.optBoolean("success", false)) {
                    result.success(jsonObjectToMap(openResult))
                    return@evaluateJavascript
                }
                if (!beginPending(result, 60_000L)) return@evaluateJavascript
                val gen = pendingGen
                if (openResult.optBoolean("done", false)) {
                    mainHandler.postDelayed({ snapshotPending(gen) }, 250L)
                    return@evaluateJavascript
                }
                // Beri React masa render portal sebelum mencari pilihan.
                mainHandler.postDelayed({
                    if (gen != pendingGen) return@postDelayed
                    activeWebView().evaluateJavascript(pickScript) { rawPick ->
                        try {
                            val pickResult = decodeJavascriptObject(rawPick)
                            if (pickResult.optBoolean("success", false)) {
                                mainHandler.postDelayed({ snapshotPending(gen) }, 300L)
                            } else {
                                finishError(
                                    "option_not_found",
                                    pickResult.optString("error", "Pilihan tidak ditemui.") +
                                        (pickResult.optJSONArray("available")?.let {
                                            " Pilihan tersedia: $it"
                                        } ?: ""),
                                    gen,
                                )
                            }
                        } catch (error: Throwable) {
                            finishError("javascript_error", error.message ?: "pick gagal", gen)
                        }
                    }
                }, 450L)
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    /**
     * Hantar kekunci sebenar ke elemen. Perlu untuk combobox yang hanya
     * bertindak balas kepada papan kekunci (ArrowDown/Enter) dan untuk input
     * bertopeng yang menolak set value terus.
     */
    private fun pressKey(
        selector: String,
        index: Int?,
        key: String,
        text: String,
        repeat: Int,
        result: MethodChannel.Result,
    ) {
        val selectorJson = JSONObject.quote(selector)
        val keyJson = JSONObject.quote(key)
        val textJson = JSONObject.quote(text)
        val indexJs = index?.toString() ?: "null"
        val repeatJs = repeat.coerceIn(1, 40).toString()
        val script = """
            (() => {
              $CLAW_PRELUDE
              let el = null;
              const found = CLAW.resolve($indexJs, '', $selectorJson);
              el = found.el || document.activeElement || document.body;
              if (!el) {
                return JSON.stringify({success:false,error:'Tiada elemen sasaran.'});
              }
              try { el.focus({preventScroll:true}); } catch (e) { try { el.focus(); } catch (e2) { } }
              const text = $textJson;
              const key = $keyJson;
              if (text) {
                CLAW.typeText(el, text);
                return JSON.stringify({success:true,action:'type',typed:text,value_now:el.value || ''});
              }
              if (!key) {
                return JSON.stringify({success:false,error:'Perlu key atau text.'});
              }
              for (let i = 0; i < $repeatJs; i++) { CLAW.pressKey(el, key); }
              return JSON.stringify({
                success:true,
                action:'key',
                key:key,
                repeat:$repeatJs,
                strategy:found.strategy,
                value_now: el.value || ''
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 350L)
    }

    private fun submit(selector: String, index: Int?, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val indexJs = index?.toString() ?: "null"
        val script = """
            (() => {
              const collect = () => Array.from(document.querySelectorAll(
                'a[href],button,input,textarea,select,[role="button"],[role="link"],[role="textbox"],[role="checkbox"],[role="radio"],[role="menuitem"],[contenteditable="true"]'
              )).filter((node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              });
              const index = $indexJs;
              const selector = $selectorJson;
              let form = null;
              if (index !== null && index !== undefined && !Number.isNaN(index)) {
                const el = collect()[index];
                if (el) form = el.tagName === 'FORM' ? el : el.closest('form');
              }
              if (!form && selector) {
                const el = document.querySelector(selector);
                form = el && el.tagName === 'FORM' ? el : (el ? el.closest('form') : null);
              }
              if (!form) form = document.querySelector('form');
              if (!form) return JSON.stringify({success:false,error:'Borang tidak ditemui'});
              if (form.requestSubmit) form.requestSubmit(); else form.submit();
              return JSON.stringify({success:true,action:'submit'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 900L)
    }

    /**
     * Laluan kedua selepas DOM/index: MotionEvent sebenar dihantar kepada
     * WebView sendiri. Ini membantu canvas, peta dan slider.
     */
    private fun nativeGesture(
        action: String,
        selector: String,
        text: String,
        index: Int?,
        x: Float?,
        y: Float?,
        toX: Float?,
        toY: Float?,
        deltaY: Float?,
        durationMs: Long,
        result: MethodChannel.Result,
    ) {
        val normalizedAction = action.lowercase()
        if (normalizedAction !in setOf("click", "long_press", "swipe", "scroll")) {
            result.error(
                "invalid_gesture",
                "action mesti click, long_press, swipe atau scroll.",
                null,
            )
            return
        }
        val view = activeWebView()

        val dispatchAt: (Float, Float) -> Unit = { resolvedX, resolvedY ->
            val width = max(2, view.width)
            val height = max(2, view.height)
            val startX = resolvedX.coerceIn(1f, width - 1f)
            val startY = resolvedY.coerceIn(1f, height - 1f)
            val finalX = (toX ?: startX).coerceIn(1f, width - 1f)
            val finalY = when (normalizedAction) {
                "scroll" -> {
                    val amount = deltaY ?: (height * 0.62f)
                    (startY - amount).coerceIn(1f, height - 1f)
                }
                else -> (toY ?: startY).coerceIn(1f, height - 1f)
            }
            dispatchNativeGesture(
                view = view,
                action = normalizedAction,
                startX = startX,
                startY = startY,
                endX = finalX,
                endY = finalY,
                durationMs = durationMs,
                result = result,
            )
        }

        if (index != null || selector.isNotBlank() || text.isNotBlank()) {
            val selectorJson = JSONObject.quote(selector)
            val textJson = JSONObject.quote(text)
            val indexJs = index?.toString() ?: "null"
            val script = """
                (() => {
                  $CLAW_PRELUDE
                  const found = CLAW.resolve($indexJs, $textJson, $selectorJson);
                  if (!found.el) {
                    return JSON.stringify({
                      success:false,
                      error:'Elemen tidak ditemui. Panggil browser_read semula.',
                      available_count:found.total
                    });
                  }
                  try { found.el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
                  const r = found.el.getBoundingClientRect();
                  return JSON.stringify({
                    success:true,
                    x:r.left + r.width / 2,
                    y:r.top + r.height / 2,
                    viewportWidth:Math.max(1, window.innerWidth),
                    viewportHeight:Math.max(1, window.innerHeight),
                    strategy:found.strategy
                  });
                })();
            """.trimIndent()
            view.evaluateJavascript(script) { raw ->
                try {
                    val point = decodeJavascriptObject(raw)
                    if (!point.optBoolean("success", false)) {
                        result.success(jsonObjectToMap(point))
                        return@evaluateJavascript
                    }
                    val viewportWidth = point.optDouble("viewportWidth", 1.0)
                    val viewportHeight = point.optDouble("viewportHeight", 1.0)
                    val px = (
                        point.optDouble("x", 0.0) /
                            viewportWidth * max(1, view.width)
                        ).toFloat()
                    val py = (
                        point.optDouble("y", 0.0) /
                            viewportHeight * max(1, view.height)
                        ).toFloat()
                    dispatchAt(px, py)
                } catch (error: Throwable) {
                    result.error("gesture_target_error", error.message, null)
                }
            }
            return
        }

        val startX = x ?: (max(2, view.width) / 2f)
        val startY = y ?: (max(2, view.height) / 2f)
        dispatchAt(startX, startY)
    }

    private fun dispatchNativeGesture(
        view: WebView,
        action: String,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
        result: MethodChannel.Result,
    ) {
        val duration = when (action) {
            "click" -> 70L
            "long_press" -> max(650L, durationMs)
            else -> durationMs.coerceIn(120L, 1600L)
        }
        if (!beginPending(result, 60_000L)) return
        val gestureGeneration = pendingGen
        val downTime = SystemClock.uptimeMillis()

        fun send(actionCode: Int, px: Float, py: Float, at: Long) {
            val event = MotionEvent.obtain(
                downTime,
                at,
                actionCode,
                px,
                py,
                0,
            )
            try {
                view.dispatchTouchEvent(event)
            } finally {
                event.recycle()
            }
            moveVisibleCursor(px, py, actionCode != MotionEvent.ACTION_UP)
        }

        send(MotionEvent.ACTION_DOWN, startX, startY, downTime)
        val steps = if (action == "swipe" || action == "scroll") {
            max(2, (duration / 24L).toInt())
        } else {
            0
        }
        for (step in 1..steps) {
            val delay = duration * step / (steps + 1)
            mainHandler.postDelayed({
                if (gestureGeneration != pendingGen || pendingDone.get()) {
                    return@postDelayed
                }
                val fraction = step.toFloat() / (steps + 1).toFloat()
                val px = startX + (endX - startX) * fraction
                val py = startY + (endY - startY) * fraction
                send(
                    MotionEvent.ACTION_MOVE,
                    px,
                    py,
                    SystemClock.uptimeMillis(),
                )
            }, delay)
        }
        mainHandler.postDelayed({
            if (gestureGeneration != pendingGen || pendingDone.get()) {
                return@postDelayed
            }
            send(
                MotionEvent.ACTION_UP,
                endX,
                endY,
                SystemClock.uptimeMillis(),
            )
            mainHandler.postDelayed({ snapshotPending(gestureGeneration) }, 500L)
        }, duration)
    }

    private fun moveVisibleCursor(
        x: Float,
        y: Float,
        pressed: Boolean,
    ) {
        val state = sessionState()
        val cursor = cursorView ?: return
        if (!state.panelVisible) {
            cursor.visibility = View.GONE
            return
        }
        cursor.visibility = View.VISIBLE
        cursor.translationX = x - dp(2)
        cursor.translationY = y - dp(2)
        cursor.alpha = if (pressed) 0.72f else 1f
        cursor.bringToFront()
    }

    private fun navigate(action: String, result: MethodChannel.Result) {
        val view = activeWebView()
        if (!beginPending(result, 60_000L)) return
        when (action) {
            "back" -> if (view.canGoBack()) view.goBack() else snapshotPending(pendingGen)
            "forward" -> if (view.canGoForward()) view.goForward() else snapshotPending(pendingGen)
            else -> view.reload()
        }
    }

    private fun clearCookies(result: MethodChannel.Result) {
        val manager = cookieManagerForSession(currentSessionId)
        manager.removeAllCookies {
            manager.flush()
            result.success(mapOf("success" to true))
        }
    }

    /**
     * Reset penuh untuk sempadan sesi chat. Berbeza daripada clearCookies lama,
     * operasi ini turut memusnahkan tab dan storan asal supaya login lama tidak
     * boleh terbawa ke sesi baharu.
     */
    private fun clearSession(result: MethodChannel.Result) {
        stopPendingWork()
        val all = tabs.values.toList()
        tabs.clear()
        activeTabId = 0
        nextTabId = 1
        for (tab in all) {
            try {
                tab.webView.clearCache(true)
                tab.webView.clearHistory()
                tab.webView.clearFormData()
            } catch (_: Throwable) {
            }
            destroyWebView(tab.webView)
        }
        hideWorkspaceInternal(remember = true)
        sessionStates[currentSessionId] = BrowserSessionState()
        activeAdblockEnabled = false
        if (supportsProfiles()) {
            webStorageForSession(currentSessionId).deleteAllData()
        } else {
            WebStorage.getInstance().deleteAllData()
        }
        WebViewDatabase.getInstance(activity).apply {
            clearHttpAuthUsernamePassword()
            clearFormData()
        }
        val manager = cookieManagerForSession(currentSessionId)
        manager.removeAllCookies {
            manager.flush()
            result.success(
                mapOf(
                    "success" to true,
                    "cleared" to listOf(
                        "tabs",
                        "cookies",
                        "webStorage",
                        "cache",
                        "history",
                        "formData",
                        "httpAuth",
                    ),
                ),
            )
        }
    }

    private fun sessionUrl(raw: String): String {
        val candidate = raw.trim().ifEmpty {
            tabs[activeTabId]?.webView?.url
                ?: tabs[activeTabId]?.url
                ?: ""
        }
        val uri = android.net.Uri.parse(candidate)
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (candidate.isEmpty() ||
            (scheme != "http" && scheme != "https") ||
            uri.host.isNullOrBlank()
        ) {
            throw IllegalArgumentException(
                "URL HTTP/HTTPS diperlukan, atau buka halaman dengan browser_open dahulu.",
            )
        }
        return uri.toString()
    }

    private fun originOf(raw: String): String {
        val uri = android.net.Uri.parse(raw)
        val scheme = uri.scheme?.lowercase().orEmpty()
        val host = uri.host?.lowercase().orEmpty()
        val port = when {
            uri.port > 0 -> ":${uri.port}"
            else -> ""
        }
        return "$scheme://$host$port"
    }

    private fun sameOrigin(first: String, second: String): Boolean =
        try {
            fun key(raw: String): String {
                val uri = android.net.Uri.parse(raw)
                val scheme = uri.scheme?.lowercase().orEmpty()
                val defaultPort = if (scheme == "https") 443 else 80
                val port = if (uri.port > 0) uri.port else defaultPort
                return "$scheme://${uri.host?.lowercase().orEmpty()}:$port"
            }
            key(first) == key(second)
        } catch (_: Throwable) {
            false
        }

    private fun cookieNamesFor(url: String): List<String> {
        val header = cookieManagerForSession(currentSessionId).getCookie(url).orEmpty()
        return header.split(';')
            .mapNotNull { part ->
                val name = part.substringBefore('=', "").trim()
                name.ifEmpty { null }
            }
            .distinct()
            .sorted()
    }

    /** Nilai rahsia tidak pernah dimasukkan dalam hasil status. */
    private fun sessionStatus(url: String, result: MethodChannel.Result) {
        val resolved = sessionUrl(url)
        val cookieNames = cookieNamesFor(resolved)
        val view = tabs[activeTabId]?.webView
        val activeUrl = view?.url.orEmpty()
        if (view == null || activeUrl.isEmpty() || !sameOrigin(activeUrl, resolved)) {
            result.success(
                mapOf(
                    "success" to true,
                    "url" to resolved,
                    "origin" to originOf(resolved),
                    "cookieNames" to cookieNames,
                    "localStorageKeys" to emptyList<String>(),
                    "sessionStorageKeys" to emptyList<String>(),
                    "storageAvailable" to false,
                ),
            )
            return
        }
        val script = """
            (() => JSON.stringify({
              localStorageKeys: Object.keys(window.localStorage).sort(),
              sessionStorageKeys: Object.keys(window.sessionStorage).sort()
            }))();
        """.trimIndent()
        view.evaluateJavascript(script) { raw ->
            try {
                val storage = decodeJavascriptObject(raw)
                fun names(key: String): List<String> {
                    val values = storage.optJSONArray(key) ?: JSONArray()
                    return (0 until values.length())
                        .mapNotNull { values.optString(it, "").ifEmpty { null } }
                }
                result.success(
                    mapOf(
                        "success" to true,
                        "url" to resolved,
                        "origin" to originOf(resolved),
                        "cookieNames" to cookieNames,
                        "localStorageKeys" to names("localStorageKeys"),
                        "sessionStorageKeys" to names("sessionStorageKeys"),
                        "storageAvailable" to true,
                    ),
                )
            } catch (error: Throwable) {
                result.error("session_status_error", error.message, null)
            }
        }
    }

    private fun validCookieName(name: String): Boolean =
        Regex("[A-Za-z0-9_!#%&'*+.^|~-]{1,256}").matches(name)

    private fun validCookiePart(value: String): Boolean =
        !value.contains('\r') && !value.contains('\n') && !value.contains(';')

    private fun cookieLine(
        name: String,
        value: String,
        path: String,
        secure: Boolean,
        httpOnly: Boolean,
        sameSite: String,
    ): String {
        if (!validCookieName(name)) {
            throw IllegalArgumentException("Nama cookie tidak sah.")
        }
        if (!validCookiePart(value)) {
            throw IllegalArgumentException("Nilai cookie mengandungi aksara kawalan.")
        }
        if (!path.startsWith('/') || !validCookiePart(path)) {
            throw IllegalArgumentException("Path cookie mesti bermula dengan / dan tidak mengandungi aksara kawalan.")
        }
        val normalizedSameSite = when (sameSite.lowercase()) {
            "strict" -> "Strict"
            "none" -> "None"
            else -> "Lax"
        }
        return buildString {
            append(name)
            append('=')
            append(value)
            append("; Path=")
            append(path)
            append("; SameSite=")
            append(normalizedSameSite)
            if (secure || normalizedSameSite == "None") append("; Secure")
            if (httpOnly) append("; HttpOnly")
        }
    }

    private fun setCookie(
        url: String,
        name: String,
        value: String,
        path: String,
        secure: Boolean,
        httpOnly: Boolean,
        sameSite: String,
        result: MethodChannel.Result,
    ) {
        val resolved = sessionUrl(url)
        val line = cookieLine(name, value, path, secure, httpOnly, sameSite)
        val manager = cookieManagerForSession(currentSessionId)
        manager.setCookie(resolved, line) { accepted ->
            manager.flush()
            result.success(
                mapOf(
                    "success" to accepted,
                    "name" to name,
                    "origin" to originOf(resolved),
                    "path" to path,
                    "secure" to secure,
                    "httpOnly" to httpOnly,
                    "sameSite" to sameSite,
                ),
            )
        }
    }

    private fun deleteCookie(
        url: String,
        name: String,
        path: String,
        result: MethodChannel.Result,
    ) {
        val resolved = sessionUrl(url)
        if (!validCookieName(name) || !path.startsWith('/') || !validCookiePart(path)) {
            throw IllegalArgumentException("Nama atau path cookie tidak sah.")
        }
        val expired = "$name=; Path=$path; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT"
        val manager = cookieManagerForSession(currentSessionId)
        manager.setCookie(resolved, expired) { accepted ->
            manager.flush()
            result.success(
                mapOf(
                    "success" to accepted,
                    "name" to name,
                    "origin" to originOf(resolved),
                    "path" to path,
                    "deleted" to accepted,
                ),
            )
        }
    }

    /**
     * Suntik cookies serta Web Storage untuk origin yang sedang dibuka.
     * Hasil hanya mengandungi bilangan dan nama kunci; nilai tidak dipantulkan.
     */
    private fun injectSession(
        url: String,
        cookies: List<Any?>,
        localStorage: Map<String, Any?>,
        sessionStorage: Map<String, Any?>,
        result: MethodChannel.Result,
    ) {
        val resolved = sessionUrl(url)
        val manager = cookieManagerForSession(currentSessionId)
        val injectedCookieNames = mutableListOf<String>()
        for (raw in cookies) {
            val entry = raw as? Map<*, *>
                ?: throw IllegalArgumentException("Setiap cookie mesti berbentuk objek.")
            val name = entry["name"]?.toString().orEmpty()
            val value = entry["value"]?.toString().orEmpty()
            val path = entry["path"]?.toString()?.ifEmpty { "/" } ?: "/"
            val secure = entry["secure"] as? Boolean ?: true
            val httpOnly = entry["http_only"] as? Boolean
                ?: entry["httpOnly"] as? Boolean
                ?: true
            val sameSite = entry["same_site"]?.toString()
                ?: entry["sameSite"]?.toString()
                ?: "Lax"
            manager.setCookie(
                resolved,
                cookieLine(name, value, path, secure, httpOnly, sameSite),
            )
            injectedCookieNames.add(name)
        }
        manager.flush()

        val localKeys = localStorage.keys.filter { it.isNotBlank() }.distinct().sorted()
        val sessionKeys = sessionStorage.keys.filter { it.isNotBlank() }.distinct().sorted()
        if (localKeys.isEmpty() && sessionKeys.isEmpty()) {
            result.success(
                mapOf(
                    "success" to true,
                    "origin" to originOf(resolved),
                    "cookieNames" to injectedCookieNames.distinct().sorted(),
                    "localStorageKeys" to localKeys,
                    "sessionStorageKeys" to sessionKeys,
                    "cookieCount" to injectedCookieNames.size,
                    "localStorageCount" to 0,
                    "sessionStorageCount" to 0,
                ),
            )
            return
        }

        val view = tabs[activeTabId]?.webView
        val activeUrl = view?.url.orEmpty()
        if (view == null || activeUrl.isEmpty() || !sameOrigin(activeUrl, resolved)) {
            result.success(
                mapOf(
                    "success" to false,
                    "error" to "origin_not_open",
                    "message" to "Buka origin sasaran dengan browser_open sebelum menyuntik localStorage/sessionStorage.",
                    "origin" to originOf(resolved),
                    "cookieNames" to injectedCookieNames.distinct().sorted(),
                    "localStorageKeys" to localKeys,
                    "sessionStorageKeys" to sessionKeys,
                ),
            )
            return
        }

        val script = buildString {
            append("(() => { try {")
            for (key in localKeys) {
                append("localStorage.setItem(")
                append(JSONObject.quote(key))
                append(',')
                append(JSONObject.quote(localStorage[key]?.toString().orEmpty()))
                append(");")
            }
            for (key in sessionKeys) {
                append("sessionStorage.setItem(")
                append(JSONObject.quote(key))
                append(',')
                append(JSONObject.quote(sessionStorage[key]?.toString().orEmpty()))
                append(");")
            }
            append("return JSON.stringify({success:true});")
            append("} catch (error) { return JSON.stringify({success:false,error:String(error)}); } })();")
        }
        view.evaluateJavascript(script) { raw ->
            try {
                val injected = decodeJavascriptObject(raw)
                val success = injected.optBoolean("success", false)
                val payload = mutableMapOf<String, Any?>(
                    "success" to success,
                    "origin" to originOf(resolved),
                    "cookieNames" to injectedCookieNames.distinct().sorted(),
                    "localStorageKeys" to localKeys,
                    "sessionStorageKeys" to sessionKeys,
                    "cookieCount" to injectedCookieNames.size,
                    "localStorageCount" to localKeys.size,
                    "sessionStorageCount" to sessionKeys.size,
                )
                if (!success) {
                    payload["error"] = injected.optString(
                        "error",
                        "storage_injection_failed",
                    )
                }
                result.success(payload)
            } catch (error: Throwable) {
                result.error("session_injection_error", error.message, null)
            }
        }
    }

    private fun screenshot(result: MethodChannel.Result) {
        val view = activeWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif untuk screenshot.", null)
            return
        }
        applyTabAudioState(view)
        // Tunggu page stabil (JS/SPA render) sebelum ambil screenshot —
        // elak pratonton putih (GitHub dsb. siap shell dulu, kandungan kemudian).
        waitForPageRenderStable(view, attempt = 0, lastHeight = -1, stableCount = 0) {
            view.evaluateJavascript(FULL_PAGE_SIZE_SCRIPT) { raw ->
                try {
                    val dimensions = decodeJavascriptObject(raw)
                    captureFullPageScreenshot(view, dimensions, result)
                } catch (error: Throwable) {
                    result.error("screenshot_dimensions_error", error.message, null)
                }
            }
        }
    }

    /**
     * Poll readyState + scrollHeight + text length sampai stabil ~2x,
     * atau timeout ~6.5s. Elak snapshot terlalu awal pada SPA.
     */
    private fun waitForPageRenderStable(
        view: WebView,
        attempt: Int,
        lastHeight: Int,
        stableCount: Int,
        onReady: () -> Unit,
    ) {
        val maxAttempts = 16 // ~16 * 400ms = 6.4s
        if (attempt >= maxAttempts) {
            onReady()
            return
        }
        val script = """
            (function(){
              var body = document.body;
              var doc = document.documentElement;
              var h = Math.max(
                body ? body.scrollHeight : 0,
                doc ? doc.scrollHeight : 0,
                body ? body.offsetHeight : 0
              );
              var text = (body && body.innerText) ? body.innerText.replace(/\s+/g,' ').trim() : '';
              return JSON.stringify({
                h: h,
                textLen: text.length,
                ready: document.readyState,
                hasContent: text.length > 40 || document.querySelectorAll('img,article,main,[role=main]').length > 0
              });
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { raw ->
            try {
                val obj = decodeJavascriptObject(raw)
                val h = obj.optInt("h", 0)
                val textLen = obj.optInt("textLen", 0)
                val ready = obj.optString("ready", "") == "complete"
                val hasContent = obj.optBoolean("hasContent", false)
                val heightStable = lastHeight > 0 && kotlin.math.abs(h - lastHeight) < 12
                val nextStable = if (ready && heightStable && (hasContent || textLen > 40)) {
                    stableCount + 1
                } else {
                    0
                }
                // Min 2 cubaan (~800ms) + 2 bacaan stabil, atau kandungan jelas selepas 1s
                if (nextStable >= 2 && attempt >= 2) {
                    onReady()
                    return@evaluateJavascript
                }
                if (attempt >= 3 && ready && hasContent && textLen > 120 && heightStable) {
                    onReady()
                    return@evaluateJavascript
                }
                mainHandler.postDelayed({
                    waitForPageRenderStable(
                        view = view,
                        attempt = attempt + 1,
                        lastHeight = h,
                        stableCount = nextStable,
                        onReady = onReady,
                    )
                }, 400L)
            } catch (_: Throwable) {
                mainHandler.postDelayed({
                    waitForPageRenderStable(
                        view = view,
                        attempt = attempt + 1,
                        lastHeight = lastHeight,
                        stableCount = 0,
                        onReady = onReady,
                    )
                }, 400L)
            }
        }
    }

    private fun captureFullPageScreenshot(
        view: WebView,
        dimensions: JSONObject,
        result: MethodChannel.Result,
    ) {
        val originalScrollX = view.scrollX
        val originalScrollY = view.scrollY
        val viewportWidth = max(1, view.width)
        val viewportHeight = max(1, view.height)
        val documentWidthCss = max(1, dimensions.optInt("width", viewportWidth))
        val documentHeightCss = max(1, dimensions.optInt("height", viewportHeight))
        val viewportWidthCss = max(
            1,
            dimensions.optInt("viewportWidth", documentWidthCss),
        )
        val heightFromWebView = max(
            viewportHeight,
            ceil(view.contentHeight.toDouble() * view.scale.toDouble()).toInt(),
        )
        val heightFromJavascript = max(
            viewportHeight,
            ceil(
                documentHeightCss.toDouble() * viewportWidth.toDouble() /
                    viewportWidthCss.toDouble(),
            ).toInt(),
        )
        val contentHeightPx = max(heightFromWebView, heightFromJavascript)
        val preferredWidth = 1080
        val maxOutputHeight = 16_000
        val maxOutputPixels = 16_000_000L

        var outputScale = min(1.0, preferredWidth.toDouble() / viewportWidth.toDouble())
        outputScale = min(
            outputScale,
            maxOutputHeight.toDouble() / contentHeightPx.toDouble(),
        )
        outputScale = min(
            outputScale,
            sqrt(
                maxOutputPixels.toDouble() /
                    (viewportWidth.toDouble() * contentHeightPx.toDouble()),
            ),
        )
        val outputWidth = max(1, (viewportWidth * outputScale).roundToInt())
        val outputHeight = max(1, (contentHeightPx * outputScale).roundToInt())

        val outputBitmap = try {
            Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        } catch (error: Throwable) {
            result.error("screenshot_memory_error", error.message, null)
            return
        }
        val outputCanvas = Canvas(outputBitmap).apply { drawColor(Color.WHITE) }
        val scrollPositions = mutableListOf<Int>()
        var offset = 0
        while (offset < contentHeightPx) {
            scrollPositions.add(offset)
            if (offset + viewportHeight >= contentHeightPx) break
            offset = min(offset + viewportHeight, max(0, contentHeightPx - viewportHeight))
            if (scrollPositions.last() == offset) break
        }

        captureScreenshotTile(
            view = view,
            outputBitmap = outputBitmap,
            outputCanvas = outputCanvas,
            outputScale = outputScale,
            scrollPositions = scrollPositions,
            index = 0,
            originalScrollX = originalScrollX,
            originalScrollY = originalScrollY,
            documentWidthCss = documentWidthCss,
            documentHeightCss = documentHeightCss,
            result = result,
        )
    }

    private fun captureScreenshotTile(
        view: WebView,
        outputBitmap: Bitmap,
        outputCanvas: Canvas,
        outputScale: Double,
        scrollPositions: List<Int>,
        index: Int,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        if (index >= scrollPositions.size) {
            finishFullPageScreenshot(
                view = view,
                bitmap = outputBitmap,
                originalScrollX = originalScrollX,
                originalScrollY = originalScrollY,
                documentWidthCss = documentWidthCss,
                documentHeightCss = documentHeightCss,
                result = result,
            )
            return
        }

        val scrollY = scrollPositions[index]
        view.scrollTo(0, scrollY)
        applyTabAudioState(view)
        mainHandler.postDelayed({
            try {
                val tileWidth = max(1, view.width)
                val tileHeight = max(1, view.height)
                val tile = Bitmap.createBitmap(
                    tileWidth,
                    tileHeight,
                    Bitmap.Config.ARGB_8888,
                )
                val tileCanvas = Canvas(tile).apply { drawColor(Color.WHITE) }
                view.draw(tileCanvas)

                val destinationTop = (scrollY * outputScale).roundToInt()
                    .coerceIn(0, outputBitmap.height)
                val destinationBottom = ((scrollY + tileHeight) * outputScale)
                    .roundToInt()
                    .coerceIn(destinationTop, outputBitmap.height)
                if (destinationBottom > destinationTop) {
                    val sourceHeight = min(
                        tileHeight,
                        ceil(
                            (destinationBottom - destinationTop).toDouble() /
                                outputScale,
                        ).toInt(),
                    )
                    outputCanvas.drawBitmap(
                        tile,
                        android.graphics.Rect(0, 0, tileWidth, sourceHeight),
                        android.graphics.Rect(
                            0,
                            destinationTop,
                            outputBitmap.width,
                            destinationBottom,
                        ),
                        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG),
                    )
                }
                tile.recycle()
                captureScreenshotTile(
                    view = view,
                    outputBitmap = outputBitmap,
                    outputCanvas = outputCanvas,
                    outputScale = outputScale,
                    scrollPositions = scrollPositions,
                    index = index + 1,
                    originalScrollX = originalScrollX,
                    originalScrollY = originalScrollY,
                    documentWidthCss = documentWidthCss,
                    documentHeightCss = documentHeightCss,
                    result = result,
                )
            } catch (error: Throwable) {
                outputBitmap.recycle()
                restoreBrowserViewport(view, originalScrollX, originalScrollY)
                result.error("screenshot_error", error.message, null)
            }
        }, 280L) // lebih lama supaya tile sempat paint selepas scroll
    }

    private fun finishFullPageScreenshot(
        view: WebView,
        bitmap: Bitmap,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        // Screenshot untuk user = BERSIH (tiada kotak index).
        // Index + bbox hanya untuk AI melalui browser_read → interactive_elements.
        try {
            saveScreenshotFile(
                view = view,
                bitmap = bitmap,
                originalScrollX = originalScrollX,
                originalScrollY = originalScrollY,
                documentWidthCss = documentWidthCss,
                documentHeightCss = documentHeightCss,
                result = result,
                annotated = false,
            )
        } catch (error: Throwable) {
            bitmap.recycle()
            restoreBrowserViewport(view, originalScrollX, originalScrollY)
            result.error("screenshot_error", error.message, null)
        }
    }

    private fun drawElementBoxes(
        bitmap: Bitmap,
        boxes: JSONArray,
        documentWidthCss: Int,
        documentHeightCss: Int,
    ) {
        val canvas = Canvas(bitmap)
        val scaleX = bitmap.width.toFloat() / documentWidthCss.toFloat()
        val scaleY = bitmap.height.toFloat() / documentHeightCss.toFloat()
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(2f, 2f * scaleX)
            color = Color.argb(220, 124, 58, 237) // ungu
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(200, 124, 58, 237)
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = max(12f, 11f * scaleX)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val maxDraw = min(boxes.length(), 40)
        for (i in 0 until maxDraw) {
            val item = boxes.optJSONObject(i) ?: continue
            val x = (item.optDouble("x", 0.0) * scaleX).toFloat()
            val y = (item.optDouble("y", 0.0) * scaleY).toFloat()
            val w = (item.optDouble("w", 0.0) * scaleX).toFloat()
            val h = (item.optDouble("h", 0.0) * scaleY).toFloat()
            if (w < 2f || h < 2f) continue
            canvas.drawRect(x, y, x + w, y + h, stroke)
            val label = item.optInt("index", i).toString()
            val tw = textPaint.measureText(label)
            val th = textPaint.textSize
            val pad = 3f * scaleX
            val lx = x
            val ly = max(0f, y - th - pad)
            canvas.drawRect(lx, ly, lx + tw + pad * 2, ly + th + pad, fill)
            canvas.drawText(label, lx + pad, ly + th, textPaint)
        }
    }

    private fun saveScreenshotFile(
        view: WebView,
        bitmap: Bitmap,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
        annotated: Boolean,
    ) {
        try {
            val directory = File(activity.filesDir, "browser-captures")
            if (!directory.exists() && !directory.mkdirs()) {
                throw IllegalStateException("Folder screenshot tidak dapat dibuat.")
            }
            val file = File(directory, "web-${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    throw IllegalStateException("Gagal mengekod screenshot browser.")
                }
            }
            result.success(
                mapOf(
                    "success" to true,
                    "path" to file.absolutePath,
                    "mime" to "image/png",
                    "width" to bitmap.width,
                    "height" to bitmap.height,
                    "documentWidth" to documentWidthCss,
                    "documentHeight" to documentHeightCss,
                    "fullPage" to true,
                    "annotated" to annotated,
                    "scaled" to (
                        bitmap.width != view.width ||
                            bitmap.height != max(view.height, documentHeightCss)
                        ),
                    "url" to (view.url ?: ""),
                    "title" to view.title.orEmpty(),
                ),
            )
        } catch (error: Throwable) {
            result.error("screenshot_error", error.message, null)
        } finally {
            bitmap.recycle()
            restoreBrowserViewport(view, originalScrollX, originalScrollY)
        }
    }

    private fun stopPendingWork() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        if (pendingResult != null && pendingDone.compareAndSet(false, true)) {
            safeError(pendingResult, "cancelled", "Browser dihentikan kerana agent dibatalkan.")
        }
        pendingResult = null
        pendingDone.set(true)
        pendingGen += 1
        for (tab in tabs.values) {
            try {
                tab.webView.stopLoading()
                applyTabAudioState(tab.webView)
            } catch (_: Throwable) {
            }
        }
    }

    /** Hentikan kerja browser yang sedang pending (bila agent dibatalkan). */
    private fun cancelPendingWork(result: MethodChannel.Result) {
        stopPendingWork()
        result.success(mapOf("success" to true, "cancelled" to true))
    }

    private fun restoreBrowserViewport(view: WebView, scrollX: Int, scrollY: Int) {
        view.scrollTo(scrollX, scrollY)
        applyTabAudioState(view)
    }

    private fun evaluateAction(
        script: String,
        result: MethodChannel.Result,
        waitAfterMs: Long,
    ) {
        val view = activeWebView()
        view.evaluateJavascript(script) { raw ->
            try {
                val actionResult = decodeJavascriptObject(raw)
                if (actionResult.optBoolean("success", false)) {
                    if (!beginPending(result, 60_000L)) return@evaluateJavascript
                    val gen = pendingGen
                    mainHandler.postDelayed({ snapshotPending(gen) }, waitAfterMs)
                } else {
                    result.success(jsonObjectToMap(actionResult))
                }
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    /**
     * Mula operasi async tunggal. Jika masih ada pending:
     * **tolak request BARU sahaja** — jangan finishError pending lama (bug lama).
     * @return false jika sibuk (caller mesti return terus).
     */
    private fun beginPending(result: MethodChannel.Result, timeoutMs: Long): Boolean {
        // pendingResult ialah sumber kebenaran. Walaupun callback lama sudah
        // menukar pendingDone, jangan benarkan result baharu mengambil slot
        // sebelum clearPending benar-benar selesai.
        if (pendingResult != null) {
            result.error(
                "browser_busy",
                "Browser sedang menyelesaikan tindakan sebelumnya. Tunggu, atau jangan parallel browser tools.",
                null,
            )
            return false
        }
        pendingGen += 1
        pendingResult = result
        pendingDone.set(false)
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        val gen = pendingGen
        timeoutRunnable = Runnable {
            finishError("browser_timeout", "Browser latar belakang melebihi had masa.", gen)
        }.also { mainHandler.postDelayed(it, timeoutMs) }
        return true
    }

    private fun snapshotPending(expectedGen: Int = pendingGen) {
        if (expectedGen != pendingGen) return
        val result = pendingResult ?: return
        val view = try {
            activeWebView()
        } catch (_: Throwable) {
            finishError("browser_missing", "Enjin browser belum tersedia.", expectedGen)
            return
        }
        applyTabAudioState(view)
        view.evaluateJavascript(SNAPSHOT_SCRIPT) { raw ->
            if (expectedGen != pendingGen) return@evaluateJavascript
            if (!pendingDone.compareAndSet(false, true)) return@evaluateJavascript
            try {
                val objectValue = decodeJavascriptObject(raw)
                val map = jsonObjectToMap(objectValue).toMutableMap()
                map["success"] = true
                map["engine"] = "android-system-webview-chromium"
                map["canGoBack"] = view.canGoBack()
                map["canGoForward"] = view.canGoForward()
                map["desktopMode"] = desktopMode
                map["activeTabId"] = activeTabId
                map["tabCount"] = tabs.size
                map["maxTabs"] = maxTabs
                map["tabs"] = tabSummaryList()
                clearPending()
                safeSuccess(result, map)
            } catch (error: Throwable) {
                clearPending()
                safeError(result, "snapshot_error", error.message)
            }
        }
    }

    private fun finishError(code: String, message: String, expectedGen: Int = pendingGen) {
        if (expectedGen != pendingGen) return
        val result = pendingResult ?: return
        if (!pendingDone.compareAndSet(false, true)) return
        clearPending()
        safeError(result, code, message)
    }

    private fun finishSuccess(
        payload: Any?,
        expectedGen: Int = pendingGen,
    ) {
        if (expectedGen != pendingGen) return
        val result = pendingResult ?: return
        if (!pendingDone.compareAndSet(false, true)) return
        clearPending()
        safeSuccess(result, payload)
    }

    private fun clearPending() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        pendingResult = null
        pendingDone.set(true)
    }

    private fun safeSuccess(result: MethodChannel.Result?, payload: Any?) {
        if (result == null) return
        try {
            result.success(payload)
        } catch (_: Throwable) {
        }
    }

    private fun safeError(result: MethodChannel.Result?, code: String, message: String?) {
        if (result == null) return
        try {
            result.error(code, message, null)
        } catch (_: Throwable) {
        }
    }

    private fun decodeJavascriptObject(raw: String?): JSONObject {
        if (raw.isNullOrBlank() || raw == "null") return JSONObject()
        val first = JSONTokener(raw).nextValue()
        val jsonText = when (first) {
            is String -> first
            is JSONObject -> return first
            else -> first.toString()
        }
        return JSONObject(jsonText)
    }

    private fun jsonObjectToMap(value: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = jsonValue(value.opt(key))
        }
        return output
    }

    private fun jsonValue(value: Any?): Any? = when (value) {
        null, JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { jsonValue(value.opt(it)) }
        else -> value
    }

    fun setAppForeground(foreground: Boolean) {
        activity.runOnUiThread {
            appForeground = foreground
            syncBrowserAudioState()
        }
    }

    private fun syncBrowserAudioState() {
        for (tab in tabs.values) applyTabAudioState(tab.webView)
    }

    private fun applyTabAudioState(view: WebView) {
        val tab = tabs.values.firstOrNull { it.webView === view }
        val state = sessionState()
        val audible = appForeground &&
            state.panelVisible &&
            state.browserAudioEnabled &&
            tab?.id == activeTabId
        try {
            view.evaluateJavascript(audioControlScript(audible), null)
        } catch (_: Throwable) {
            // Halaman mungkin belum mempunyai konteks JavaScript. Percubaan seterusnya
            // dibuat pada onPageFinished atau apabila tab aktif berubah.
        }
    }

    fun destroy() {
        stopPendingWork()
        val all = tabs.values.toList()
        tabs.clear()
        activeTabId = 0
        for (tab in all) {
            destroyWebView(tab.webView)
        }
        try {
            val panel = workspacePanel
            if (panel != null) {
                (panel.parent as? ViewGroup)?.removeView(panel)
            }
            val bubble = workspaceBubble
            if (bubble != null) {
                (bubble.parent as? ViewGroup)?.removeView(bubble)
            }
        } catch (_: Throwable) {
        }
        workspacePanel = null
        workspaceContent = null
        workspaceTitle = null
        workspaceTabScroll = null
        workspaceTabStrip = null
        browserAudioButton = null
        workspaceBubble = null
        cursorView = null
        sessionStates.clear()
    }

    private fun desktopUserAgent(): String =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0"

    private fun mobileUserAgent(): String =
        "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}; ${android.os.Build.MODEL}) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 AiMultiAgent/1.0.0"

    private class WorkspaceCursorView(activity: Activity) : View(activity) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(92, 66, 174)
            style = Paint.Style.STROKE
            strokeWidth = activity.resources.displayMetrics.density * 1.8f
            strokeJoin = Paint.Join.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val sx = width / 26f
            val sy = height / 34f
            val cursorPath = Path().apply {
                moveTo(2f * sx, 1f * sy)
                lineTo(2f * sx, 26f * sy)
                lineTo(8.4f * sx, 20f * sy)
                lineTo(12.7f * sx, 31f * sy)
                lineTo(17.4f * sx, 29f * sy)
                lineTo(13.1f * sx, 18.2f * sy)
                lineTo(22f * sx, 18.2f * sy)
                close()
            }
            canvas.drawPath(cursorPath, fill)
            canvas.drawPath(cursorPath, outline)
        }
    }

    companion object {
        private val ADBLOCK_HOSTS = setOf(
            "2mdn.net",
            "adnxs.com",
            "adsrvr.org",
            "amazon-adsystem.com",
            "doubleclick.net",
            "googleadservices.com",
            "googlesyndication.com",
            "googletagservices.com",
            "outbrain.com",
            "taboola.com",
        )

        private val ENABLE_ADBLOCK_SCRIPT = """
            (() => {
              let style = document.getElementById('__ai_multiagent_adblock');
              if (!style) {
                style = document.createElement('style');
                style.id = '__ai_multiagent_adblock';
                style.textContent = [
                  '[id*="google_ads"]','[id^="ad-"]','[class^="ad-"]',
                  '[class*=" ad-"]','[aria-label="Advertisement"]',
                  'iframe[src*="doubleclick"]','iframe[src*="googlesyndication"]'
                ].join(',') + '{display:none!important;visibility:hidden!important;}';
                (document.head || document.documentElement).appendChild(style);
              }
              return true;
            })();
        """.trimIndent()

        private val DISABLE_ADBLOCK_SCRIPT = """
            (() => {
              const style = document.getElementById('__ai_multiagent_adblock');
              if (style) style.remove();
              return true;
            })();
        """.trimIndent()

        private fun audioControlScript(enabled: Boolean): String = """
            (() => {
              const requested = ${if (enabled) "true" else "false"};
              if (!window.__aiMultiAgentSetAudioEnabled) {
                window.__aiMultiAgentAudioEnabled = false;
                window.__aiMultiAgentAudioContexts = [];

                const applyMedia = (node) => {
                  if (!node) return;
                  if (!window.__aiMultiAgentAudioEnabled) {
                    if (!node.__aiMultiAgentSavedAudio) {
                      try {
                        Object.defineProperty(node, '__aiMultiAgentSavedAudio', {
                          value: {muted: !!node.muted, volume: Number(node.volume)},
                          configurable: true,
                          writable: true
                        });
                      } catch (_) {
                        node.__aiMultiAgentSavedAudio = {
                          muted: !!node.muted,
                          volume: Number(node.volume)
                        };
                      }
                    }
                    try { node.muted = true; } catch (_) {}
                    try { node.volume = 0; } catch (_) {}
                    return;
                  }
                  const saved = node.__aiMultiAgentSavedAudio;
                  if (!saved) return;
                  try { node.muted = saved.muted; } catch (_) {}
                  try {
                    node.volume = Number.isFinite(saved.volume) ? saved.volume : 1;
                  } catch (_) {}
                  try { delete node.__aiMultiAgentSavedAudio; } catch (_) {
                    node.__aiMultiAgentSavedAudio = null;
                  }
                };

                window.__aiMultiAgentSetAudioEnabled = (enabledNow) => {
                  window.__aiMultiAgentAudioEnabled = !!enabledNow;
                  document.querySelectorAll('video,audio').forEach(applyMedia);
                  for (const context of window.__aiMultiAgentAudioContexts || []) {
                    try {
                      if (window.__aiMultiAgentAudioEnabled) {
                        if (context.__aiMultiAgentSuspendedByApp && context.state !== 'closed') {
                          context.__aiMultiAgentSuspendedByApp = false;
                          Promise.resolve(context.resume()).catch(() => {});
                        }
                      } else if (context.state !== 'closed' && context.state !== 'suspended') {
                        context.__aiMultiAgentSuspendedByApp = true;
                        Promise.resolve(context.suspend()).catch(() => {});
                      }
                    } catch (_) {}
                  }
                  return window.__aiMultiAgentAudioEnabled;
                };

                for (const key of ['AudioContext', 'webkitAudioContext']) {
                  const NativeContext = window[key];
                  if (!NativeContext || NativeContext.__aiMultiAgentWrapped) continue;
                  const ManagedContext = function(...args) {
                    const context = new NativeContext(...args);
                    window.__aiMultiAgentAudioContexts.push(context);
                    if (!window.__aiMultiAgentAudioEnabled) {
                      context.__aiMultiAgentSuspendedByApp = true;
                      try { Promise.resolve(context.suspend()).catch(() => {}); } catch (_) {}
                    }
                    return context;
                  };
                  ManagedContext.prototype = NativeContext.prototype;
                  Object.setPrototypeOf(ManagedContext, NativeContext);
                  Object.defineProperty(ManagedContext, '__aiMultiAgentWrapped', {value:true});
                  try { window[key] = ManagedContext; } catch (_) {}
                }

                if (document.documentElement) {
                  window.__aiMultiAgentAudioObserver = new MutationObserver((records) => {
                    for (const record of records) {
                      for (const node of record.addedNodes || []) {
                        if (!node || node.nodeType !== 1) continue;
                        if (node.matches && node.matches('video,audio')) applyMedia(node);
                        if (node.querySelectorAll) {
                          node.querySelectorAll('video,audio').forEach(applyMedia);
                        }
                      }
                    }
                  });
                  window.__aiMultiAgentAudioObserver.observe(
                    document.documentElement,
                    {childList:true,subtree:true}
                  );
                  document.addEventListener('play', (event) => applyMedia(event.target), true);
                  document.addEventListener(
                    'volumechange',
                    (event) => applyMedia(event.target),
                    true
                  );
                }
              }
              return window.__aiMultiAgentSetAudioEnabled(requested);
            })();
        """.trimIndent()

        private val MUTE_MEDIA_SCRIPT = audioControlScript(false)

        private val FULL_PAGE_SIZE_SCRIPT = """
            (() => {
              const root = document.documentElement;
              const body = document.body;
              const width = Math.max(
                root ? root.scrollWidth : 0,
                root ? root.offsetWidth : 0,
                body ? body.scrollWidth : 0,
                body ? body.offsetWidth : 0,
                window.innerWidth || 0
              );
              const height = Math.max(
                root ? root.scrollHeight : 0,
                root ? root.offsetHeight : 0,
                body ? body.scrollHeight : 0,
                body ? body.offsetHeight : 0,
                window.innerHeight || 0
              );
              return JSON.stringify({
                width,
                height,
                viewportWidth: window.innerWidth || width,
                viewportHeight: window.innerHeight || height
              });
            })();
        """.trimIndent()

        /**
         * Selector elemen interaktif.
         *
         * Versi lama hanya melihat elemen native + beberapa role. Komponen React
         * tersuai (Radix, Headless UI, MUI, react-select) merender dropdown
         * sebagai div dengan role="combobox"/"listbox" dan bukan <select>, jadi
         * ia langsung tidak dikumpul — sebab itu "elemen tidak ditemui".
         */
        private const val INTERACTIVE_SELECTOR =
            "a[href],button,input,textarea,select,summary,label[for]," +
                "[role=\"button\"],[role=\"link\"],[role=\"textbox\"],[role=\"searchbox\"]," +
                "[role=\"checkbox\"],[role=\"radio\"],[role=\"switch\"]," +
                "[role=\"menuitem\"],[role=\"menuitemradio\"],[role=\"menuitemcheckbox\"]," +
                "[role=\"combobox\"],[role=\"listbox\"],[role=\"tab\"]," +
                "[role=\"spinbutton\"],[role=\"slider\"],[role=\"treeitem\"]," +
                "[contenteditable=\"true\"],[aria-haspopup],[tabindex]:not([tabindex=\"-1\"])"

        /** Selector khusus pilihan dropdown (dipisahkan supaya tidak membanjiri snapshot). */
        private const val OPTION_SELECTOR =
            "[role=\"option\"],[role=\"menuitem\"],[role=\"menuitemradio\"]," +
                "[role=\"treeitem\"],[role=\"tab\"],option,li"

        /**
         * Pustaka JS kongsi yang disuntik sebelum setiap skrip tindakan.
         *
         * Menyelesaikan tiga sebab utama komponen React tak boleh diinteraksi:
         *   1. element.click() sahaja — banyak widget bertindak pada
         *      pointerdown/mousedown, bukan click. realClick() hantar
         *      keseluruhan urutan pointer + mouse dengan koordinat sebenar.
         *   2. element.value = x — React controlled input mengabaikannya.
         *      setNativeValue() guna setter prototaip supaya React nampak.
         *   3. querySelectorAll tidak menembusi shadow DOM. deepAll() menyusur
         *      setiap shadowRoot terbuka.
         */
        private const val CLAW_JS = """
            const CLAW = (function () {
              const clean = function (v) { return (v || '').replace(/\s+/g, ' ').trim(); };

              const deepAll = function (sel) {
                const out = [];
                const seen = [];
                const walk = function (root) {
                  if (!root || seen.indexOf(root) !== -1) return;
                  seen.push(root);
                  let list = [];
                  try { list = root.querySelectorAll(sel); } catch (e) { list = []; }
                  for (let i = 0; i < list.length; i++) out.push(list[i]);
                  let all = [];
                  try { all = root.querySelectorAll('*'); } catch (e) { all = []; }
                  for (let j = 0; j < all.length; j++) {
                    if (all[j].shadowRoot) walk(all[j].shadowRoot);
                  }
                };
                walk(document);
                return out;
              };

              const isVisible = function (node) {
                if (!node || !node.getBoundingClientRect) return false;
                let style;
                try { style = window.getComputedStyle(node); } catch (e) { return false; }
                if (!style) return false;
                if (style.display === 'none') return false;
                if (style.visibility === 'hidden') return false;
                if (style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };

              const labelOf = function (node) {
                let text = '';
                try {
                  text = node.getAttribute('aria-label') ||
                    (node.labels && node.labels[0] ? node.labels[0].innerText : '') ||
                    node.innerText || node.value ||
                    node.getAttribute('placeholder') || node.getAttribute('title') ||
                    node.getAttribute('name') || node.id || '';
                } catch (e) { text = ''; }
                return clean(text).toLowerCase();
              };

              const collect = function () { return deepAll(CLAW_SELECTOR).filter(isVisible); };

              const fire = function (el, type, init) {
                let ev = null;
                const Pointer = window.PointerEvent;
                try {
                  if (Pointer && type.indexOf('pointer') === 0) {
                    ev = new Pointer(type, init);
                  } else {
                    ev = new MouseEvent(type, init);
                  }
                } catch (e) {
                  try { ev = new MouseEvent(type, init); } catch (e2) { return; }
                }
                try { el.dispatchEvent(ev); } catch (e) { }
              };

              /* Urutan penuh seperti jari sebenar. Radix/MUI buka pada
                 pointerdown, react-select pada mousedown. */
              const realClick = function (el) {
                try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { }
                const r = el.getBoundingClientRect();
                const cx = Math.round(r.left + r.width / 2);
                const cy = Math.round(r.top + r.height / 2);
                const base = {
                  bubbles: true, cancelable: true, composed: true, view: window,
                  clientX: cx, clientY: cy, screenX: cx, screenY: cy,
                  detail: 1, button: 0
                };
                const hover = Object.assign({}, base, {
                  buttons: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true
                });
                const down = Object.assign({}, base, {
                  buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true
                });
                fire(el, 'pointerover', hover);
                fire(el, 'pointerenter', hover);
                fire(el, 'mouseover', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'mousemove', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'pointerdown', down);
                fire(el, 'mousedown', Object.assign({}, base, { buttons: 1 }));
                try { el.focus({ preventScroll: true }); } catch (e) {
                  try { el.focus(); } catch (e2) { }
                }
                fire(el, 'pointerup', hover);
                fire(el, 'mouseup', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'click', Object.assign({}, base, { buttons: 0 }));
                return true;
              };

              /* React memintas setter value. Guna setter prototaip supaya
                 state React benar-benar dikemas kini. */
              const setNativeValue = function (el, value) {
                let proto = null;
                if (window.HTMLTextAreaElement && el instanceof window.HTMLTextAreaElement) {
                  proto = window.HTMLTextAreaElement.prototype;
                } else if (window.HTMLSelectElement && el instanceof window.HTMLSelectElement) {
                  proto = window.HTMLSelectElement.prototype;
                } else if (window.HTMLInputElement) {
                  proto = window.HTMLInputElement.prototype;
                }
                let desc = null;
                if (proto) {
                  try { desc = Object.getOwnPropertyDescriptor(proto, 'value'); } catch (e) { }
                }
                if (desc && desc.set) { desc.set.call(el, value); } else { el.value = value; }
              };

              const notify = function (el) {
                try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
                try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { }
              };

              const KEYMAP = {
                Enter: 13, Tab: 9, Escape: 27, Backspace: 8, Delete: 46, ' ': 32,
                ArrowDown: 40, ArrowUp: 38, ArrowLeft: 37, ArrowRight: 39,
                Home: 36, End: 35, PageUp: 33, PageDown: 34
              };

              const pressKey = function (el, k) {
                const code = KEYMAP[k] || (k.length === 1 ? k.toUpperCase().charCodeAt(0) : 0);
                const name = k.length === 1
                  ? (/[a-z]/i.test(k) ? 'Key' + k.toUpperCase() : 'Digit' + k)
                  : k;
                const init = {
                  bubbles: true, cancelable: true, composed: true,
                  key: k, code: name, keyCode: code, which: code
                };
                try { el.dispatchEvent(new KeyboardEvent('keydown', init)); } catch (e) { }
                if (k.length === 1) {
                  try { el.dispatchEvent(new KeyboardEvent('keypress', init)); } catch (e) { }
                }
                try { el.dispatchEvent(new KeyboardEvent('keyup', init)); } catch (e) { }
              };

              /* Menaip aksara demi aksara. Wajib untuk input bertopeng
                 (cth. DD/MM/YYYY) yang menolak set value terus. */
              const typeText = function (el, text) {
                try { el.focus({ preventScroll: true }); } catch (e) {
                  try { el.focus(); } catch (e2) { }
                }
                for (let i = 0; i < text.length; i++) {
                  const ch = text[i];
                  const current = (el.value || '') + ch;
                  setNativeValue(el, current);
                  pressKey(el, ch);
                  try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
                }
                notify(el);
              };

              const matchOption = function (nodes, wanted) {
                const target = clean(wanted).toLowerCase();
                if (!target) return null;
                let exact = null;
                let starts = null;
                let loose = null;
                for (let i = 0; i < nodes.length; i++) {
                  const t = clean(nodes[i].innerText || nodes[i].textContent || '').toLowerCase();
                  const v = clean(nodes[i].getAttribute ? (nodes[i].getAttribute('data-value') || nodes[i].value || '') : '').toLowerCase();
                  if (t === target || v === target) { exact = nodes[i]; break; }
                  if (!starts && (t.indexOf(target) === 0 || v.indexOf(target) === 0)) starts = nodes[i];
                  if (!loose && t.indexOf(target) !== -1) loose = nodes[i];
                }
                return exact || starts || loose;
              };

              /* Cari elemen mengikut keutamaan: index → label teks → selector. */
              const resolve = function (index, text, selector) {
                const nodes = collect();
                if (index !== null && index !== undefined && !Number.isNaN(index) && nodes[index]) {
                  return { el: nodes[index], strategy: 'index', total: nodes.length };
                }
                const wanted = clean(text || '').toLowerCase();
                if (wanted) {
                  for (let i = 0; i < nodes.length; i++) {
                    if (labelOf(nodes[i]).indexOf(wanted) !== -1) {
                      return { el: nodes[i], strategy: 'text', total: nodes.length };
                    }
                  }
                }
                if (selector) {
                  const hit = deepAll(selector)[0];
                  if (hit) return { el: hit, strategy: 'selector', total: nodes.length };
                }
                return { el: null, strategy: '', total: nodes.length };
              };

              return {
                clean: clean, deepAll: deepAll, isVisible: isVisible, labelOf: labelOf,
                collect: collect, realClick: realClick, setNativeValue: setNativeValue,
                notify: notify, pressKey: pressKey, typeText: typeText,
                matchOption: matchOption, resolve: resolve
              };
            })();
        """

        /** Prelude lengkap: pemalar selector + pustaka CLAW. */
        private val CLAW_PRELUDE: String =
            "const CLAW_SELECTOR = " + JSONObject.quote(INTERACTIVE_SELECTOR) + ";\n" +
                "const CLAW_OPTION_SELECTOR = " + JSONObject.quote(OPTION_SELECTOR) + ";\n" +
                CLAW_JS

        /** Koordinat absolut page untuk lukisan kotak pada full-page screenshot. */
        private val ANNOTATE_ELEMENTS_SCRIPT = """
            (() => {
              const isVisible = (node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };
              const sel = 'a[href],button,input,textarea,select,[role="button"],[role="link"],[role="textbox"],[role="checkbox"],[role="radio"],[role="menuitem"],[contenteditable="true"]';
              const sx = window.scrollX || window.pageXOffset || 0;
              const sy = window.scrollY || window.pageYOffset || 0;
              const elements = Array.from(document.querySelectorAll(sel))
                .filter(isVisible)
                .slice(0, 40)
                .map((node, index) => {
                  const r = node.getBoundingClientRect();
                  return {
                    index,
                    x: r.left + sx,
                    y: r.top + sy,
                    w: r.width,
                    h: r.height
                  };
                });
              return JSON.stringify({ elements });
            })();
        """.trimIndent()

        private val SNAPSHOT_SCRIPT = """
            (() => {
              $CLAW_PRELUDE
              const clean = (value) => (value || '').replace(/\s+/g, ' ').trim();
              const isVisible = (node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };
              const interactiveSelector = CLAW_SELECTOR;
              const interactive = CLAW.deepAll(interactiveSelector)
                .filter(isVisible)
                .slice(0, 150)
                .map((node, index) => {
                  const tag = (node.tagName || '').toLowerCase();
                  const type = (node.getAttribute('type') || node.type || '').toLowerCase();
                  const role = node.getAttribute('role') || '';
                  const popup = node.getAttribute('aria-haspopup') || '';
                  const expanded = node.getAttribute('aria-expanded');
                  const rect = node.getBoundingClientRect();
                  const label = clean(
                    node.getAttribute('aria-label') ||
                    node.getAttribute('title') ||
                    (node.labels && node.labels[0] ? node.labels[0].innerText : '') ||
                    node.innerText ||
                    node.value ||
                    node.getAttribute('placeholder') ||
                    node.getAttribute('name') ||
                    node.id ||
                    ''
                  ).slice(0, 120);
                  const item = {
                    index,
                    tag,
                    type: type || role || tag,
                    text: label,
                    name: node.getAttribute('name') || '',
                    id: node.id || '',
                    placeholder: node.getAttribute('placeholder') || '',
                    href: node.href || '',
                    value: type === 'password' ? '[REDACTED]' : clean(node.value || '').slice(0, 80),
                    checked: !!(node.checked),
                    disabled: !!(node.disabled),
                    role: role,
                    haspopup: popup,
                    expanded: expanded === null ? '' : expanded,
                    /* widget=true bermakna komponen tersuai (bukan <select>) —
                       guna browser_select_option, bukan browser_fill. */
                    widget: tag !== 'select' && tag !== 'input' && tag !== 'textarea' &&
                      (role === 'combobox' || role === 'listbox' ||
                       popup === 'listbox' || popup === 'menu' || popup === 'true'),
                    bbox: {
                      x: Math.round(rect.x),
                      y: Math.round(rect.y),
                      width: Math.round(rect.width),
                      height: Math.round(rect.height)
                    }
                  };
                  return item;
                });
              const links = Array.from(document.querySelectorAll('a[href]')).slice(0, 80).map((node, index) => ({
                index,
                text: clean(node.innerText || node.getAttribute('aria-label') || ''),
                url: node.href || ''
              })).filter((item) => item.url);
              const forms = Array.from(document.forms).slice(0, 15).map((form, index) => ({
                index,
                id: form.id || '',
                name: form.name || '',
                action: form.action || location.href,
                method: (form.method || 'get').toUpperCase(),
                fields: Array.from(form.elements).slice(0, 30).map((field) => ({
                  tag: field.tagName ? field.tagName.toLowerCase() : '',
                  type: field.type || '',
                  name: field.name || '',
                  id: field.id || '',
                  placeholder: field.placeholder || '',
                  value: field.type === 'password' ? '[REDACTED]' : (field.value || '')
                }))
              }));
              const text = clean(document.body ? document.body.innerText : '').slice(0, 32000);
              const html = (document.documentElement ? document.documentElement.outerHTML : '').slice(0, 80000);
              return JSON.stringify({
                url: location.href,
                title: document.title || '',
                text,
                html,
                interactive_elements: interactive,
                links,
                forms
              });
            })();
        """.trimIndent()
    }
}
