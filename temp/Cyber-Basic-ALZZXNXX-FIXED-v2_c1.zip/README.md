# Cyber Basic — ALZZXNXX (fixed build)

Flutter Android project with the original UI/tools plus build compatibility fixes.

## Build
1. Install Flutter stable and Android SDK.
2. Use Java 17.
3. Run `flutter clean`
4. Run `flutter pub get`
5. Run `flutter build apk --release`

The Android Gradle wrapper is set to Gradle 8.14.0 to avoid the Flutter warning about Gradle 8.11.1 being deprecated.

## Included
- Password generator and strength checker
- ASCII tools
- SHA-256, Base64, Hex
- JSON formatter
- URL analyzer
- UUID/token/timestamp tools
- Local file analyzer
- Local integrity fingerprint tool
- Cybersecurity learning pages
- CTF checklist
- Device info
- Local notes
- Settings/About

File analysis is heuristic and is not an antivirus verdict. Use security tools only on files and systems you are authorized to inspect.
