/// Centralized configuration for Earl Builder Owner App.
///
/// ╔═══════════════════════════════════════════════════════╗
/// ║  ISI HARDCODED — Tukar nilai di bawah sebelum build  ║
/// ╚═══════════════════════════════════════════════════════╝
class OwnerConfig {
  /// URL Vercel deployment awak (TIADA slash di hujung)
  /// Contoh: 'https://earl-builder.vercel.app'
  static const String baseUrl = 'https://your-project.vercel.app';

  /// ═══════════════════════════════════════════════════════
  ///  TAK PERLU TUKAR — Link tetap ke owner & channel
  /// ═══════════════════════════════════════════════════════
  static const String ownerLink = 'https://t.me/earlxz';
  static const String channelLink = 'https://t.me/earlstore2004';

  /// ═══════════════════════════════════════════════════════
  ///  INTERNAL — Jangan ubah
  /// ═══════════════════════════════════════════════════════
  static const String appName = 'Earl Builder - Owner';
  static const String appTagline = 'Panel Pengurusan';
}
