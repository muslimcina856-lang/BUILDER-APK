import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';

class AddCreditScreen extends StatefulWidget {
  final VoidCallback? onDone;
  const AddCreditScreen({super.key, this.onDone});

  @override
  State<AddCreditScreen> createState() => _AddCreditScreenState();
}

class _AddCreditScreenState extends State<AddCreditScreen> {
  final _targetController = TextEditingController();
  final _amountController = TextEditingController();
  bool _isLoading = false;
  String? _result;
  bool _isSuccess = false;

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _addCredits() async {
    final target = _targetController.text.trim();
    final amount = int.tryParse(_amountController.text.trim());

    if (target.isEmpty || amount == null || amount <= 0) {
      setState(() {
        _result = 'Masukkan ID dan jumlah yang sah.';
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final result = await OwnerApiService.addCredits(target: target, amount: amount);

      setState(() {
        _isSuccess = result['success'] == true;
        _result = result['message'];

        if (_isSuccess) {
          _targetController.clear();
          _amountController.clear();
          widget.onDone?.call();
        }
      });
    } catch (e) {
      setState(() {
        _isSuccess = false;
        _result = 'Gagal: $e';
      });
    }

    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Kredit')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1D2832)),
                color: const Color(0xFF11181F),
              ),
              child: Column(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFF34E0A1), Color(0xFF19C2C8)],
                      ),
                    ),
                    child: const Icon(Icons.add_rounded, color: Color(0xFF04120D), size: 26),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Tambah Kredit ke User',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFE7F0F2),
                    ),
                  ),
                  Text(
                    'Masukkan device ID atau Telegram ID pengguna.',
                    style: TextStyle(fontSize: 12, color: Colors.grey[400]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _targetController,
              decoration: const InputDecoration(
                labelText: 'Device ID / Telegram ID',
                hintText: 'device_xxx atau ID Telegram',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Jumlah Kredit',
                hintText: 'contoh: 50',
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _addCredits,
                child: _isLoading
                    ? const SizedBox(
                        width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF1A1410)),
                      )
                    : const Text('TAMBAH KREDIT'),
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _isSuccess
                        ? const Color(0xFF34E0A1).withAlpha(80)
                        : const Color(0xFFFF5A5A).withAlpha(80),
                  ),
                  color: _isSuccess
                      ? const Color(0xFF34E0A1).withAlpha(10)
                      : const Color(0xFFFF5A5A).withAlpha(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
                      color: _isSuccess ? const Color(0xFF34E0A1) : const Color(0xFFFF5A5A),
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _result!,
                        style: TextStyle(
                          fontSize: 13,
                          color: _isSuccess ? const Color(0xFF34E0A1) : const Color(0xFFFF5A5A),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
