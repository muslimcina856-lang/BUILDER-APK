import 'package:flutter/material.dart';
import 'package:earl_builder_owner/config.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/screens/user_list_screen.dart';
import 'package:earl_builder_owner/screens/add_credit_screen.dart';
import 'package:earl_builder_owner/screens/generate_code_screen.dart';
import 'package:earl_builder_owner/screens/code_list_screen.dart';
import 'package:earl_builder_owner/screens/server_toggle_screen.dart';
import 'package:earl_builder_owner/screens/about_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _totalUsers = 0;
  int _activeCodes = 0;
  String _serverMode = 'off';
  String _serverTitle = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final results = await Future.wait([
        OwnerApiService.getUsers(),
        OwnerApiService.getCodes(),
        OwnerApiService.getServerStatus(),
      ]);

      setState(() {
        _totalUsers = results[0]['total'] ?? 0;
        _activeCodes = results[1]['total'] ?? 0;
        _serverMode = results[2]['maintenance_mode'] ?? 'off';
        _serverTitle = results[2]['maintenance_title'] ?? '';
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadData,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              if (_isLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(40),
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Color(0xFFF4C44A),
                    ),
                  ),
                )
              else ...[
                _buildStatsGrid(),
                const SizedBox(height: 24),
                _buildServerStatus(),
                const SizedBox(height: 24),
                _buildActionGrid(),
              ],
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(
              colors: [Color(0xFFF4C44A), Color(0xFFE08A28)],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFF4C44A).withAlpha(80),
                blurRadius: 18,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Icon(Icons.admin_panel_settings_rounded,
              color: Color(0xFF1A1410), size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Panel Owner',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFE7F0F2),
                ),
              ),
              Text(
                'Earl Builder',
                style: TextStyle(
                  fontSize: 11,
                  color: Color(0xFF7F8E98),
                  letterSpacing: 0.4,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          onPressed: _loadData,
          icon: const Icon(Icons.refresh_rounded, size: 20),
          color: Colors.grey[500],
        ),
      ],
    );
  }

  Widget _buildStatsGrid() {
    return Row(
      children: [
        Expanded(child: _buildStatCard('Jumlah User', '$_totalUsers', Icons.people_rounded, const Color(0xFF5AA9FF))),
        const SizedBox(width: 10),
        Expanded(child: _buildStatCard('Kod Aktif', '$_activeCodes', Icons.redeem_rounded, const Color(0xFFF4C44A))),
        const SizedBox(width: 10),
        Expanded(child: _buildStatCard(
          'Server',
          _serverMode == 'on' ? 'OFFLINE' : 'ONLINE',
          Icons.dns_rounded,
          _serverMode == 'on' ? const Color(0xFFFF5A5A) : const Color(0xFF34E0A1),
        )),
      ],
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withAlpha(50)),
        color: const Color(0xFF11181F),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: color),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(fontSize: 10, color: Colors.grey[500], letterSpacing: 0.4),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildServerStatus() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: _serverMode == 'on'
              ? const Color(0xFFFF5A5A).withAlpha(60)
              : const Color(0xFF34E0A1).withAlpha(60),
        ),
        color: _serverMode == 'on'
            ? const Color(0xFFFF5A5A).withAlpha(8)
            : const Color(0xFF34E0A1).withAlpha(5),
      ),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _serverMode == 'on' ? const Color(0xFFFF5A5A) : const Color(0xFF34E0A1),
              boxShadow: [
                BoxShadow(
                  color: _serverMode == 'on'
                      ? const Color(0xFFFF5A5A).withAlpha(100)
                      : const Color(0xFF34E0A1).withAlpha(100),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _serverMode == 'on' ? 'Server Offline' : 'Server Online',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: _serverMode == 'on'
                        ? const Color(0xFFFF5A5A)
                        : const Color(0xFF34E0A1),
                  ),
                ),
                if (_serverMode == 'on' && _serverTitle.isNotEmpty)
                  Text(
                    'Mesej: $_serverTitle',
                    style: TextStyle(fontSize: 11, color: Colors.grey[400]),
                  ),
              ],
            ),
          ),
          Icon(
            Icons.chevron_right_rounded,
            color: Colors.grey[600],
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildActionGrid() {
    final actions = [
      _OwnerAction(
        icon: Icons.people_rounded,
        label: 'Senarai User',
        subtitle: 'Lihat semua pengguna berdaftar',
        color: const Color(0xFF5AA9FF),
        screen: const UserListScreen(),
      ),
      _OwnerAction(
        icon: Icons.add_circle_rounded,
        label: 'Tambah Kredit',
        subtitle: 'Tambah kredit ke user',
        color: const Color(0xFF34E0A1),
        screen: AddCreditScreen(onDone: _loadData),
      ),
      _OwnerAction(
        icon: Icons.redeem_rounded,
        label: 'Jana Kod',
        subtitle: 'Buat kod kredit untuk user',
        color: const Color(0xFFF4C44A),
        screen: const GenerateCodeScreen(),
      ),
      _OwnerAction(
        icon: Icons.list_alt_rounded,
        label: 'Senarai Kod',
        subtitle: 'Kod kredit yang masih aktif',
        color: const Color(0xFF818CF8),
        screen: const CodeListScreen(),
      ),
      _OwnerAction(
        icon: Icons.toggle_on_rounded,
        label: 'Toggle Server',
        subtitle: 'ON/OFF + custom message',
        color: const Color(0xFFFF5A5A),
        screen: ServerToggleScreen(onChanged: _loadData),
      ),
      _OwnerAction(
        icon: Icons.info_outline_rounded,
        label: 'Tentang',
        subtitle: 'Info aplikasi',
        color: const Color(0xFF7F8E98),
        screen: const AboutScreen(),
      ),
    ];

    return Column(
      children: actions.map((a) => _buildActionTile(a)).toList(),
    );
  }

  Widget _buildActionTile(_OwnerAction action) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1D2832)),
        color: const Color(0xFF11181F),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => action.screen),
            ).then((_) => _loadData());
          },
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: action.color.withAlpha(15),
                    border: Border.all(color: action.color.withAlpha(50)),
                  ),
                  child: Icon(action.icon, color: action.color, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        action.label,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          color: Color(0xFFE7F0F2),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        action.subtitle,
                        style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: Colors.grey[600], size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OwnerAction {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final Widget screen;
  _OwnerAction({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.screen,
  });
}
