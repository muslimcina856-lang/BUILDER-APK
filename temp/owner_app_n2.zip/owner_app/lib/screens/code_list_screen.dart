import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';

class CodeListScreen extends StatefulWidget {
  const CodeListScreen({super.key});

  @override
  State<CodeListScreen> createState() => _CodeListScreenState();
}

class _CodeListScreenState extends State<CodeListScreen> {
  List<Map<String, dynamic>> _codes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getCodes();
      setState(() {
        _codes = List<Map<String, dynamic>>.from(result['codes'] ?? []);
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Senarai Kod Aktif')),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(strokeWidth: 2.5, color: Color(0xFFF4C44A)))
          : _codes.isEmpty
              ? Center(
                  child: Text('Tiada kod aktif.', style: TextStyle(fontSize: 13, color: Colors.grey[600])))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _codes.length,
                    padding: const EdgeInsets.all(16),
                    itemBuilder: (_, i) {
                      final c = _codes[i];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFF1D2832)),
                          color: const Color(0xFF11181F),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.vpn_key_rounded, color: Color(0xFFF4C44A), size: 18),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(c['code'] ?? '',
                                      style: const TextStyle(fontFamily: 'monospace',
                                          fontSize: 13, fontWeight: FontWeight.w700,
                                          color: Color(0xFFF4C44A))),
                                  Text('${c['amount']} kredit - ${c['created_at'] ?? ""}',
                                      style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(999),
                                color: const Color(0xFF34E0A1).withAlpha(15),
                                border: Border.all(color: const Color(0xFF34E0A1).withAlpha(80)),
                              ),
                              child: const Text('ACTIVE',
                                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700,
                                      color: Color(0xFF34E0A1), letterSpacing: 0.8)),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
