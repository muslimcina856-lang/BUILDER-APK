import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUsers();
    _searchController.addListener(_filterUsers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUsers() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getUsers();
      setState(() {
        _users = List<Map<String, dynamic>>.from(result['users'] ?? []);
        _filterUsers();
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  void _filterUsers() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      _filtered = query.isEmpty
          ? _users
          : _users.where((u) {
              final devId = (u['device_id'] ?? '').toString().toLowerCase();
              final tgId = (u['telegram_id'] ?? '').toString().toLowerCase();
              return devId.contains(query) || tgId.contains(query);
            }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Senarai User')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Cari device ID atau Telegram ID...',
                prefixIcon: Icon(Icons.search_rounded, size: 20),
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Color(0xFF5AA9FF),
                    ),
                  )
                : _filtered.isEmpty
                    ? Center(
                        child: Text(
                          _searchController.text.isNotEmpty
                              ? 'Tiada hasil carian.'
                              : 'Belum ada pengguna berdaftar.',
                          style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadUsers,
                        child: ListView.builder(
                          itemCount: _filtered.length,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemBuilder: (_, i) => _buildUserCard(_filtered[i]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard(Map<String, dynamic> user) {
    final deviceId = user['device_id'] ?? '';
    final telegramId = user['telegram_id'];
    final credits = user['credits'] ?? 0;
    final uploads = user['total_uploads'] ?? 0;
    final createdAt = user['created_at'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1D2832)),
        color: const Color(0xFF11181F),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                telegramId != null ? Icons.link_rounded : Icons.link_off_rounded,
                color: telegramId != null ? const Color(0xFF34E0A1) : Colors.grey[600],
                size: 16,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  deviceId,
                  style: const TextStyle(
                    fontSize: 12,
                    fontFamily: 'monospace',
                    color: Color(0xFF7F8E98),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _buildMiniStat('Kredit', '$credits', const Color(0xFF34E0A1)),
              const SizedBox(width: 16),
              _buildMiniStat('Upload', '$uploads', const Color(0xFF5AA9FF)),
              const SizedBox(width: 16),
              _buildMiniStat('TG', telegramId ?? '-', const Color(0xFF818CF8)),
            ],
          ),
          if (createdAt.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              'Sejak: $createdAt',
              style: TextStyle(fontSize: 10, color: Colors.grey[700]),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMiniStat(String label, String value, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(fontSize: 10, color: Colors.grey[500]),
        ),
      ],
    );
  }
}
