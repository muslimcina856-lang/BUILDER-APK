import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:earl_builder_owner/config.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tentang')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 30),
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: const LinearGradient(
                  colors: [Color(0xFFF4C44A), Color(0xFFE08A28)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFF4C44A).withAlpha(80),
                    blurRadius: 24,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: const Icon(Icons.admin_panel_settings_rounded,
                  color: Color(0xFF1A1410), size: 34),
            ),
            const SizedBox(height: 16),
            const Text(
              'Earl Builder',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFFE7F0F2)),
            ),
            const SizedBox(height: 4),
            Text(
              'Panel Owner',
              style: TextStyle(fontSize: 13, color: Colors.grey[400]),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1D2832)),
                color: const Color(0xFF11181F),
              ),
              child: Text(
                'Panel pengurusan untuk aplikasi Earl Builder. '
                'Gunakan panel ini untuk mengurus pengguna, menambah kredit, '
                'menjana kod tebus, dan mengawal status server.',
                style: TextStyle(fontSize: 13, color: Colors.grey[300], height: 1.6),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFF4C44A).withAlpha(40)),
                color: const Color(0xFFF4C44A).withAlpha(5),
              ),
              child: Column(
                children: [
                  const Text('Built by Earl',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFFF4C44A))),
                  const SizedBox(height: 6),
                  Text(
                    'Aplikasi panel owner untuk mengurus sistem build APK.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.grey[400], height: 1.5),
                  ),
                  const SizedBox(height: 16),
                  Divider(color: const Color(0xFFF4C44A).withAlpha(30)),
                  const SizedBox(height: 12),
                  _buildLinkButton(
                    icon: Icons.person_rounded,
                    label: 'Owner',
                    subtitle: 'Hubungi pembangun',
                    color: const Color(0xFFF4C44A),
                    onTap: () => _openLink(OwnerConfig.ownerLink),
                  ),
                  const SizedBox(height: 10),
                  _buildLinkButton(
                    icon: Icons.campaign_rounded,
                    label: 'Channel',
                    subtitle: 'Ikuti update terkini',
                    color: const Color(0xFF5AA9FF),
                    onTap: () => _openLink(OwnerConfig.channelLink),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('v1.0.0', style: TextStyle(fontSize: 11, color: Colors.grey[700])),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildLinkButton({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withAlpha(40)),
            color: color.withAlpha(8),
          ),
          child: Row(
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: color)),
                    Text(subtitle,
                        style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                  ],
                ),
              ),
              Icon(Icons.open_in_new_rounded, color: color.withAlpha(120), size: 16),
            ],
          ),
        ),
      ),
    );
  }
}
