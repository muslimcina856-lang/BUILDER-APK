import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';

class ServerToggleScreen extends StatefulWidget {
  final VoidCallback? onChanged;
  const ServerToggleScreen({super.key, this.onChanged});

  @override
  State<ServerToggleScreen> createState() => _ServerToggleScreenState();
}

class _ServerToggleScreenState extends State<ServerToggleScreen> {
  bool _isOn = false;
  bool _isLoading = true;
  bool _isSaving = false;
  final _titleController = TextEditingController();
  final _messageController = TextEditingController();
  String? _result;
  bool _isSuccess = false;

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _loadStatus() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getServerStatus();
      setState(() {
        _isOn = result['maintenance_mode'] == 'on';
        _titleController.text = result['maintenance_title'] ?? '';
        _messageController.text = result['maintenance_message'] ?? '';
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  Future<void> _toggle() async {
    setState(() {
      _isSaving = true;
      _result = null;
    });

    final newMode = _isOn ? 'off' : 'on';
    final title = _titleController.text.trim();
    final message = _messageController.text.trim();

    try {
      final result = await OwnerApiService.toggleServer(
        mode: newMode,
        title: title.isEmpty ? null : title,
        message: message.isEmpty ? null : message,
      );

      setState(() {
        _isOn = newMode == 'on';
        _isSuccess = true;
        _result = result['message'];
      });

      widget.onChanged?.call();
    } catch (e) {
      setState(() {
        _isSuccess = false;
        _result = 'Gagal: $e';
      });
    }

    setState(() => _isSaving = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Toggle Server')),
        body: const Center(child: CircularProgressIndicator(strokeWidth: 2.5, color: Color(0xFFF4C44A))),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Toggle Server')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Toggle card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _isOn
                      ? const Color(0xFFFF5A5A).withAlpha(60)
                      : const Color(0xFF34E0A1).withAlpha(60),
                ),
                color: _isOn
                    ? const Color(0xFFFF5A5A).withAlpha(8)
                    : const Color(0xFF34E0A1).withAlpha(5),
              ),
              child: Column(
                children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isOn ? const Color(0xFFFF5A5A) : const Color(0xFF34E0A1),
                      boxShadow: [
                        BoxShadow(
                          color: (_isOn ? const Color(0xFFFF5A5A) : const Color(0xFF34E0A1)).withAlpha(100),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _isOn ? 'SERVER OFFLINE' : 'SERVER ONLINE',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: _isOn ? const Color(0xFFFF5A5A) : const Color(0xFF34E0A1),
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isOn
                        ? 'Pengguna tidak boleh menghantar projek.'
                        : 'Semua fungsi berjalan seperti biasa.',
                    style: TextStyle(fontSize: 12, color: Colors.grey[400]),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Custom message
            const Text(
              'MESEJ MAINTENANCE (PILIHAN)',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                  color: Color(0xFF7F8E98), letterSpacing: 0.8),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Tajuk (pilihan)',
                hintText: 'Server Sedang Maintenance',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _messageController,
              decoration: const InputDecoration(
                labelText: 'Penerangan (pilihan)',
                hintText: 'Sila cuba lagi nanti...',
              ),
              maxLines: 3,
            ),

            const SizedBox(height: 24),

            // Toggle button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _toggle,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isOn ? const Color(0xFF34E0A1) : const Color(0xFFFF5A5A),
                  foregroundColor: _isOn ? const Color(0xFF04120D) : Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isSaving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_isOn ? 'HIDUPKAN SERVER' : 'MATIKAN SERVER'),
              ),
            ),

            if (_result != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _isSuccess
                        ? const Color(0xFF34E0A1).withAlpha(80)
                        : const Color(0xFFFF5A5A).withAlpha(80),
                  ),
                  color: _isSuccess
                      ? const Color(0xFF34E0A1).withAlpha(10)
                      : const Color(0xFFFF5A5A).withAlpha(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
                      color: _isSuccess ? const Color(0xFF34E0A1) : const Color(0xFFFF5A5A),
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _result!,
                        style: TextStyle(
                          fontSize: 13,
                          color: _isSuccess ? const Color(0xFF34E0A1) : const Color(0xFFFF5A5A),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 14),
            Text(
              'Nota: Owner App TIDAK akan terjejas oleh toggle ini.',
              style: TextStyle(fontSize: 11, color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}
