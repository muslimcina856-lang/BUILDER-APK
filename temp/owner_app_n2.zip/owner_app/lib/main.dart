import 'package:flutter/material.dart';
import 'package:earl_builder_owner/screens/dashboard_screen.dart';

void main() {
  runApp(const EarlOwnerApp());
}

class EarlOwnerApp extends StatelessWidget {
  const EarlOwnerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Earl Builder - Owner',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080B0E),
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFFF4C44A),
          secondary: const Color(0xFF34E0A1),
          surface: const Color(0xFF11181F),
          onPrimary: const Color(0xFF1A1410),
          onSecondary: const Color(0xFF04120D),
          onSurface: const Color(0xFFE7F0F2),
        ),
        cardColor: const Color(0xFF11181F),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0D1217),
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Color(0xFFE7F0F2),
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFF4C44A),
            foregroundColor: const Color(0xFF1A1410),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(11),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 14,
              letterSpacing: 0.4,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0C1116),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: const BorderSide(color: Color(0xFF263441)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: const BorderSide(color: Color(0xFF263441)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: const BorderSide(color: Color(0xFFF4C44A), width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}
