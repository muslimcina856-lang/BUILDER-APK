import 'package:dio/dio.dart';
import 'package:earl_builder_owner/config.dart';

/// API service for all owner backend communication.
class OwnerApiService {
  static final Dio _dio = Dio(BaseOptions(
    baseUrl: OwnerConfig.baseUrl,
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 30),
  ));

  // ─── Users ──────────────────────────────────────────────────

  /// Get all users list.
  static Future<Map<String, dynamic>> getUsers() async {
    final res = await _dio.get('/api/owner/users');
    return res.data;
  }

  // ─── Credits ────────────────────────────────────────────────

  /// Add credit to user by device_id or telegram_id.
  static Future<Map<String, dynamic>> addCredits({
    required String target,
    required int amount,
  }) async {
    final res = await _dio.post('/api/owner/add-credit', data: {
      'target': target,
      'amount': amount,
    });
    return res.data;
  }

  // ─── Codes ──────────────────────────────────────────────────

  /// Generate credit codes.
  static Future<Map<String, dynamic>> generateCodes({
    required int amount,
    required int count,
  }) async {
    final res = await _dio.post('/api/owner/generate-code', data: {
      'amount': amount,
      'count': count,
    });
    return res.data;
  }

  /// Get active codes list.
  static Future<Map<String, dynamic>> getCodes() async {
    final res = await _dio.get('/api/owner/codes');
    return res.data;
  }

  // ─── Server ─────────────────────────────────────────────────

  /// Toggle maintenance mode.
  static Future<Map<String, dynamic>> toggleServer({
    required String mode,
    String? title,
    String? message,
  }) async {
    final res = await _dio.post('/api/owner/toggle-server', data: {
      'mode': mode,
      if (title != null) 'title': title,
      if (message != null) 'message': message,
    });
    return res.data;
  }

  /// Get server status.
  static Future<Map<String, dynamic>> getServerStatus() async {
    final res = await _dio.get('/api/owner/server-status');
    return res.data;
  }
}
