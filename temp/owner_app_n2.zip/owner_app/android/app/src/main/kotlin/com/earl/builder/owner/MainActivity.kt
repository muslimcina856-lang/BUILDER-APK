package com.earl.builder.owner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
