package com.earl.earl_builder_owner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
