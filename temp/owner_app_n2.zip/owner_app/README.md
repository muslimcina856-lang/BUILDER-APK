# Earl Builder - Owner App

Aplikasi Flutter untuk owner mengurus pengguna, kredit, kod tebus, dan status server.

## Konfigurasi

### ════════════════════════════════════════
###  ISI HARDCODED (tukar sebelum build)
### ════════════════════════════════════════

Fail: **`lib/config.dart`**

| Baris | Pembolehubah | Tujuan |
|-------|-------------|--------|
| 9 | `baseUrl` | URL Vercel deployment — **WAJIB TUKAR** |

### ════════════════════════════════════════
###  TAK PERLU TUKAR — Link tetap
### ════════════════════════════════════════

Fail: **`lib/config.dart`**

| Baris | Pembolehubah | Nilai |
|-------|-------------|-------|
| 14 | `ownerLink` | `https://t.me/earlxz` |
| 15 | `channelLink` | `https://t.me/earlstore2004` |

### ════════════════════════════════════════
###  DI VERCEL ENV — Server side
### ════════════════════════════════════════

Fail: **`vercel-api/.env.example`**

| Variable | Penerangan |
|----------|-----------|
| `TURSO_URL` | URL database Turso |
| `TURSO_AUTH_TOKEN` | Auth token Turso JWT |
| `GITHUB_TOKEN` | GitHub Personal Access Token |
| `GITHUB_REPO_OWNER` | Nama owner repo GitHub |
| `GITHUB_REPO_NAME` | Nama repo untuk push ZIP |
| `GITHUB_WORKFLOW_ID` | Nama workflow file (default: build.yml) |
| `BOT_TOKEN` | Token bot Telegram |
| `BOT_USERNAME` | Username bot Telegram (tanpa @) |

## Setup

```bash
# Generate platform files
flutter create --project-name earl_builder_owner --org com.earl .

# Install dependencies
flutter pub get

# Build APK (jangan run, build je)
flutter build apk --debug
```

## Build

APK akan dihasilkan di `build/app/outputs/flutter-apk/app-debug.apk`.

## Struktur

```
lib/
├── config.dart              # Konfigurasi (isi hardcoded)
├── main.dart                # Entry point
├── screens/
│   ├── dashboard_screen.dart    # Dashboard utama + statistik
│   ├── user_list_screen.dart    # Senarai semua pengguna
│   ├── add_credit_screen.dart   # Tambah kredit ke user
│   ├── generate_code_screen.dart # Jana kod tebus
│   ├── code_list_screen.dart    # Senarai kod aktif
│   ├── server_toggle_screen.dart # ON/OFF server + custom message
│   └── about_screen.dart        # Info aplikasi
└── services/
    └── api_service.dart    # API call ke Vercel
```
