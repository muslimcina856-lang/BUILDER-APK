import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class WorkersScreen extends StatefulWidget {
  const WorkersScreen({super.key});

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  List<dynamic> workers = [];
  List<dynamic> pages = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final w = await api.getWorkers().catchError((_) => <dynamic>[]);
      final p = await api.getPagesProjects().catchError((_) => <dynamic>[]);
      setState(() {
        workers = w;
        pages = p;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.parse(url);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  Future<void> _openWorker(String name) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final api = CloudflareApi(account);
      final code = await api.getWorkerScript(name);
      if (!mounted) return;
      Navigator.pop(context);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => _WorkerCodeScreen(name: name, code: code, accountId: account.id),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context);
      // Fallback: open dashboard
      _openExternal('https://dash.cloudflare.com/${account.id}/workers/services/view/$name/production');
    }
  }

  Future<void> _openPage(String name, String? subdomain) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    // Prefer live pages.dev URL if available, else dashboard
    if (subdomain != null && subdomain.isNotEmpty) {
      final url = subdomain.startsWith('http') ? subdomain : 'https://$subdomain';
      await _openExternal(url);
    } else {
      await _openExternal('https://dash.cloudflare.com/${account.id}/pages/view/$name');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final account = app.activeAccount;

    if (loading) return const Center(child: CircularProgressIndicator());

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Workers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              TextButton.icon(
                onPressed: () {
                  final id = account?.id ?? '';
                  _openExternal('https://dash.cloudflare.com/$id/workers-and-pages');
                },
                icon: const Icon(Icons.open_in_new, size: 16),
                label: const Text('Dashboard'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (workers.isEmpty)
            const Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Text('Tiada Workers', style: TextStyle(color: AppColors.muted)),
            )
          else
            ...workers.map((w) {
              final name = (w['id'] ?? w['name'] ?? '-').toString();
              final modified = w['modified_on']?.toString() ?? '-';
              final short = modified.length > 19 ? modified.substring(0, 19) : modified;
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.code, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text('Modified: $short'),
                  trailing: const Icon(Icons.chevron_right, color: AppColors.muted),
                  onTap: () => _openWorker(name),
                ),
              );
            }),
          const SizedBox(height: 24),
          const Text('Pages Projects', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          if (pages.isEmpty)
            const Text('Tiada Pages project', style: TextStyle(color: AppColors.muted))
          else
            ...pages.map((p) {
              final name = (p['name'] ?? '-').toString();
              final subdomain = p['subdomain']?.toString();
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.web, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text(subdomain ?? ''),
                  trailing: const Icon(Icons.open_in_new, size: 18, color: AppColors.muted),
                  onTap: () => _openPage(name, subdomain),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _WorkerCodeScreen extends StatelessWidget {
  final String name;
  final String code;
  final String accountId;

  const _WorkerCodeScreen({
    required this.name,
    required this.code,
    required this.accountId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(name, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.open_in_new),
            tooltip: 'Buka di Dashboard',
            onPressed: () async {
              final uri = Uri.parse(
                'https://dash.cloudflare.com/$accountId/workers/services/view/$name/production',
              );
              try {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } catch (_) {
                await launchUrl(uri, mode: LaunchMode.platformDefault);
              }
            },
          ),
        ],
      ),
      body: code.isEmpty
          ? const Center(child: Text('Tiada kod / tidak dapat dimuat', style: TextStyle(color: AppColors.muted)))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: SelectableText(
                code,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
            ),
    );
  }
}
