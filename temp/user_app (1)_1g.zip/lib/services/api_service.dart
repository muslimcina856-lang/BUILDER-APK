import 'package:dio/dio.dart';
import 'package:earl_builder/config.dart';

/// API service for all Vercel backend communication.
class ApiService {
  static final Dio _dio = Dio(BaseOptions(
    baseUrl: AppConfig.baseUrl,
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 60),
    sendTimeout: const Duration(seconds: 120),
  ));

  // ─── Robust response parsing ─────────────────────────────────
  // Some endpoints may return non-JSON on error; we guarantee a Map.

  static Map<String, dynamic> _asMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return <String, dynamic>{};
  }

  // ─── User Endpoints ──────────────────────────────────────────

  /// Register/get user by device ID. Returns user info + is_new flag.
  static Future<Map<String, dynamic>> registerUser(String deviceId) async {
    final res = await _dio.post('/api/user/register', data: {
      'device_id': deviceId,
    });
    return _asMap(res.data);
  }

  /// Get user info and credits.
  static Future<Map<String, dynamic>> getUserInfo(String deviceId) async {
    final res = await _dio.get('/api/user/me', queryParameters: {
      'device_id': deviceId,
    });
    return _asMap(res.data);
  }

  /// Step 1 — request a verification code to be sent to this Telegram ID.
  static Future<Map<String, dynamic>> requestBindTelegram(
    String deviceId,
    String telegramId,
  ) async {
    try {
      final res = await _dio.post('/api/user/bind-telegram', data: {
        'device_id': deviceId,
        'telegram_id': telegramId,
      });
      return _asMap(res.data);
    } on DioException catch (error) {
      if (error.response?.data != null) return _asMap(error.response!.data);
      rethrow;
    }
  }

  /// Step 2 — submit the verification code received via Telegram to
  /// complete the bind.
  static Future<Map<String, dynamic>> confirmBindTelegram(
    String deviceId,
    String code,
  ) async {
    try {
      final res = await _dio.post('/api/user/bind-telegram/confirm', data: {
        'device_id': deviceId,
        'code': code,
      });
      return _asMap(res.data);
    } on DioException catch (error) {
      if (error.response?.data != null) return _asMap(error.response!.data);
      rethrow;
    }
  }

  /// Unbind the Telegram ID currently linked to this device. Required
  /// before starting a new bind.
  static Future<Map<String, dynamic>> unbindTelegram(String deviceId) async {
    final res = await _dio.post('/api/user/unbind-telegram', data: {
      'device_id': deviceId,
    });
    return _asMap(res.data);
  }

  /// Claim a credit code.
  static Future<Map<String, dynamic>> claimCode(
    String deviceId,
    String code,
  ) async {
    final res = await _dio.post('/api/user/claim-code', data: {
      'device_id': deviceId,
      'code': code,
    });
    return _asMap(res.data);
  }

  // ─── Ads ─────────────────────────────────────────────────────

  /// Get one randomly selected active ad, if any.
  static Future<Map<String, dynamic>> getAd(String deviceId) async {
    final res = await _dio.get('/api/user/ads', queryParameters: {
      'device_id': deviceId,
    });
    return _asMap(res.data);
  }

  /// Get ads owned by this user for read-only progress monitoring.
  static Future<Map<String, dynamic>> getMyAds(String deviceId) async {
    final res = await _dio.get('/api/user/my-ads', queryParameters: {
      'device_id': deviceId,
    });
    return _asMap(res.data);
  }

  /// Start a server-side watch session after the media is ready.
  static Future<Map<String, dynamic>> startAdWatch({
    required String deviceId,
    required int adId,
  }) async {
    try {
      final res = await _dio.post('/api/user/start-ad-watch', data: {
        'device_id': deviceId,
        'ad_id': adId,
      });
      return _asMap(res.data);
    } on DioException catch (error) {
      if (error.response?.data != null) return _asMap(error.response!.data);
      rethrow;
    }
  }

  /// Claim credits with the server-issued watch token.
  static Future<Map<String, dynamic>> claimAdReward({
    required String deviceId,
    required int adId,
    required String watchToken,
  }) async {
    try {
      final res = await _dio.post('/api/user/claim-ad-reward', data: {
        'device_id': deviceId,
        'ad_id': adId,
        'watch_token': watchToken,
      });
      return _asMap(res.data);
    } on DioException catch (error) {
      if (error.response?.data != null) return _asMap(error.response!.data);
      rethrow;
    }
  }

  // ─── Health / Maintenance ────────────────────────────────────

  /// Check server health and maintenance status.
  /// Returns status: 'ok' | 'unavailable' — 'unavailable' means the
  /// backend could not even reach its database, which must never be
  /// treated the same as a confirmed online/off state.
  static Future<Map<String, dynamic>> checkHealth() async {
    try {
      final res = await _dio.get('/api/health');
      return _asMap(res.data);
    } on DioException catch (e) {
      if (e.response?.data != null) return _asMap(e.response!.data);
      return {
        'status': 'unavailable',
        'is_maintenance': false,
        'title': '',
        'message': '',
        'music_url': '',
      };
    }
  }

  // ─── Submission Endpoints ────────────────────────────────────

  /// Submit a project URL. The backend only stores this URL in a .txt file;
  /// the GitHub worker will download, detect and build the project later.
  static Future<Map<String, dynamic>> submitProjectLink({
    required String deviceId,
    required String projectUrl,
    String? fileName,
  }) async {
    final res = await _dio.post('/api/upload/link', data: {
      'device_id': deviceId,
      'project_url': projectUrl,
      if (fileName != null && fileName.trim().isNotEmpty)
        'file_name': fileName.trim(),
    });
    return _asMap(res.data);
  }

  // ─── Build Status ────────────────────────────────────────────

  /// Get current GitHub Actions build queue.
  static Future<Map<String, dynamic>> getBuildStatus() async {
    final res = await _dio.get('/api/build/status');
    return _asMap(res.data);
  }
}
