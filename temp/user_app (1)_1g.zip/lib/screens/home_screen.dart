import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:earl_builder/services/api_service.dart';
import 'package:earl_builder/services/storage_service.dart';
import 'package:earl_builder/screens/upload_screen.dart';
import 'package:earl_builder/screens/bind_telegram_screen.dart';
import 'package:earl_builder/screens/claim_code_screen.dart';
import 'package:earl_builder/screens/my_ads_screen.dart';
import 'package:earl_builder/screens/ad_view_screen.dart';
import 'package:earl_builder/screens/about_screen.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _deviceId = '';
  String? _telegramId;
  int _credits = 0;
  int _totalUploads = 0;
  bool _isLoading = true;
  bool _isMaintenance = false;
  bool _isUnavailable = false;
  String _maintenanceTitle = '';
  String _maintenanceMessage = '';
  Timer? _healthTimer;

  // True while the app should not let the user start any action —
  // either the server is in maintenance mode, or it's unreachable.
  // Kept as one flag so a modified client can't bypass the lock by
  // hiding just the maintenance banner: every action tap below checks
  // this same flag, and the backend independently rejects requests too.
  bool get _isLocked => _isMaintenance || _isUnavailable;
  String _musicUrl = '';
  final AudioPlayer _musicPlayer = AudioPlayer();
  String? _musicPlayingUrl;
  int _buildQueue = 0;
  int _buildEstimatedMin = 0;
  Timer? _buildStatusTimer;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    setState(() => _isLoading = true);
    try {
      final deviceId = await StorageService.getDeviceId();
      _deviceId = deviceId;

      final health = await ApiService.checkHealth();
      _isUnavailable = (health['status'] ?? 'ok').toString() == 'unavailable';
      _isMaintenance = health['is_maintenance'] == true;
      _maintenanceTitle = (health['title'] ?? '').toString();
      _maintenanceMessage = (health['message'] ?? '').toString();
      _musicUrl = (health['music_url'] ?? '').toString();
      _syncMusicPlayback();

      try {
        final userData = await ApiService.registerUser(deviceId);
        _credits = userData['user']?['credits'] ?? 0;
        _telegramId = userData['user']?['telegram_id']?.toString();
        _totalUploads = userData['user']?['total_uploads'] ?? 0;
      } catch (_) {
        // user may not exist yet — silently use defaults
      }

      // Fetch build queue without delaying the home screen.
      _fetchBuildStatus();
    } catch (e) {
      debugPrint('HomeScreen init error: $e');
    }
    if (!mounted) return;
    setState(() => _isLoading = false);
    _startBuildStatusPolling();
  }

  Future<void> _refreshCredits() async {
    if (_deviceId.isEmpty) return;
    try {
      final userData = await ApiService.getUserInfo(_deviceId);
      if (!mounted) return;
      setState(() {
        _credits = userData['credits'] ?? _credits;
        _telegramId = userData['telegram_id']?.toString();
        _totalUploads = userData['total_uploads'] ?? _totalUploads;
      });
    } catch (_) {}
    _fetchBuildStatus();
  }

  Future<void> _showFreeCreditsInfo() async {
    final statusFuture = ApiService.getAd(_deviceId);

    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (dialogCtx) => _FreeCreditsDialog(
        statusFuture: statusFuture,
        onWatch: (ad) {
          Navigator.pop(dialogCtx);
          _openAdView(ad);
        },
      ),
    );
  }

  Future<void> _openAdView(Map<String, dynamic> ad) async {
    final earned = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => AdViewScreen(deviceId: _deviceId, ad: ad),
      ),
    );
    if (earned == true) {
      _refreshCredits();
    }
  }

  Future<void> _fetchBuildStatus() async {
    try {
      final status = await ApiService.getBuildStatus();
      if (!mounted) return;
      setState(() {
        _buildQueue = (status['in_progress'] ?? 0) as int;
        _buildEstimatedMin = (status['estimated_minutes'] ?? 0) as int;
      });
    } catch (_) {}
  }

  void _startBuildStatusPolling() {
    _buildStatusTimer?.cancel();
    _buildStatusTimer = Timer.periodic(
      const Duration(seconds: 15),
      (_) => _fetchBuildStatus(),
    );
    _healthTimer?.cancel();
    _healthTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => _checkHealth(),
    );
  }

  Future<void> _checkHealth() async {
    try {
      final health = await ApiService.checkHealth();
      if (!mounted) return;
      setState(() {
        _isUnavailable = (health['status'] ?? 'ok').toString() == 'unavailable';
        _isMaintenance = health['is_maintenance'] == true;
        _maintenanceTitle = (health['title'] ?? '').toString();
        _maintenanceMessage = (health['message'] ?? '').toString();
        _musicUrl = (health['music_url'] ?? '').toString();
      });
      _syncMusicPlayback();
    } catch (_) {
      if (!mounted) return;
      setState(() => _isUnavailable = true);
      _syncMusicPlayback();
    }
  }

  // Plays the owner-configured maintenance music on a loop for as long as
  // the full-screen lock is showing, and nothing else — no player UI is
  // exposed to the user. Safe to call repeatedly; it only touches the
  // player when something actually needs to change.
  Future<void> _syncMusicPlayback() async {
    final shouldPlay = _isLocked && _musicUrl.isNotEmpty;

    if (!shouldPlay) {
      if (_musicPlayingUrl != null) {
        if (mounted) {
          setState(() => _musicPlayingUrl = null);
        } else {
          _musicPlayingUrl = null;
        }
        try {
          await _musicPlayer.stop();
        } catch (_) {}
      }
      return;
    }

    if (_musicPlayingUrl == _musicUrl) return; // already playing this track

    try {
      await _musicPlayer.setLoopMode(LoopMode.one);
      await _musicPlayer.setUrl(_musicUrl);
      // Do NOT await play() — with looping audio, its Future only
      // resolves when playback completes or is paused, i.e. never. That
      // was blocking this function forever, so the setState below never
      // ran (wave visual stuck hidden) and every 5s poll re-entered this
      // still-blocked call, calling setUrl() again and restarting the
      // track — which sounded like the music kept cutting itself off.
      unawaited(_musicPlayer.play());
      if (mounted) {
        setState(() => _musicPlayingUrl = _musicUrl);
      } else {
        _musicPlayingUrl = _musicUrl;
      }
    } catch (_) {
      // Bad/unreachable URL — fail silently, this is background ambience,
      // not something worth surfacing an error for.
      _musicPlayingUrl = null;
    }
  }

  @override
  void dispose() {
    _buildStatusTimer?.cancel();
    _healthTimer?.cancel();
    _musicPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const _LoadingScaffold();

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            RefreshIndicator(
              color: AppColors.accent,
              backgroundColor: AppColors.bgElevated,
              onRefresh: _refreshCredits,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.xxl,
                  AppSpacing.xl,
                  AppSpacing.xxl,
                  AppSpacing.huge,
                ),
                children: [
                  _Header(
                    onFreeCredits: _showFreeCreditsInfo,
                  ),
                  const SizedBox(height: AppSpacing.xxxl),
                  _StatsCard(
                    credits: _credits,
                    uploads: _totalUploads,
                    telegramBound: _telegramId != null,
                  ),
                  const SizedBox(height: AppSpacing.md),
              if (_deviceId.isNotEmpty)
                _DeviceIdCard(deviceId: _deviceId),
              if (_buildQueue > 0) ...[
                const SizedBox(height: AppSpacing.md),
                _BuildProgressCard(
                  inProgress: _buildQueue,
                  estimatedMin: _buildEstimatedMin,
                  onRefresh: _fetchBuildStatus,
                ),
              ],
              const SizedBox(height: AppSpacing.xxxl),
              _PrimaryAction(
                disabled: _isLocked,
                onTap: () async {
                  if (_isLocked) return;
                  if (_telegramId == null) {
                    final shouldBind = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => _TelegramRequiredDialog(),
                    );
                    if (!mounted) return;
                    if (shouldBind == true) {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BindTelegramScreen(
                            deviceId: _deviceId,
                            currentTelegramId: _telegramId,
                          ),
                        ),
                      );
                      if (!mounted) return;
                      _refreshCredits();
                    }
                    return;
                  }
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => UploadScreen(deviceId: _deviceId),
                    ),
                  );
                  if (!mounted) return;
                  _refreshCredits();
                },
              ),
              const SizedBox(height: AppSpacing.xxl),
              _SectionLabel(label: tr(context, 'home_section_activity')),
              const SizedBox(height: AppSpacing.md),
              _ActionTile(
                icon: Icons.campaign_outlined,
                title: tr(context, 'home_my_ads_title'),
                subtitle: tr(context, 'home_my_ads_subtitle'),
                disabled: _isLocked,
                onTap: () async {
                  if (_isLocked) return;
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MyAdsScreen(deviceId: _deviceId),
                    ),
                  );
                },
              ),
              const SizedBox(height: AppSpacing.sm),
              _ActionTile(
                icon: Icons.link_rounded,
                title: tr(context, 'home_link_telegram_title'),
                subtitle: _telegramId != null
                    ? '${tr(context, 'home_linked_to')} $_telegramId'
                    : tr(context, 'home_link_telegram_subtitle'),
                trailing: _telegramId != null
                    ? _StatusBadge(tr(context, 'home_linked_badge'), AppColors.success)
                    : const Icon(Icons.chevron_right_rounded,
                        size: AppIcons.lg, color: AppColors.textMuted),
                disabled: _isLocked,
                onTap: () async {
                  if (_isLocked) return;
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BindTelegramScreen(
                        deviceId: _deviceId,
                        currentTelegramId: _telegramId,
                      ),
                    ),
                  );
                  if (!mounted) return;
                  _refreshCredits();
                },
              ),
              const SizedBox(height: AppSpacing.sm),
              _ActionTile(
                icon: Icons.redeem_rounded,
                title: tr(context, 'home_redeem_code_title'),
                subtitle: tr(context, 'home_redeem_code_subtitle'),
                disabled: _isLocked,
                onTap: () async {
                  if (_isLocked) return;
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ClaimCodeScreen(deviceId: _deviceId),
                    ),
                  );
                  if (!mounted) return;
                  _refreshCredits();
                },
              ),
              const SizedBox(height: AppSpacing.xxxl),
              _ActionTile(
                icon: Icons.info_outline_rounded,
                title: tr(context, 'home_about_title'),
                subtitle: tr(context, 'home_about_subtitle'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AboutScreen()),
                  );
                },
              ),
                ],
              ),
            ),
            if (_isLocked)
              _MaintenanceOverlay(
                isUnavailable: _isUnavailable,
                title: _isUnavailable ? tr(context, 'home_unavailable_title') : _maintenanceTitle,
                message: _isUnavailable
                    ? tr(context, 'home_unavailable_message')
                    : _maintenanceMessage,
                isMusicPlaying: _musicPlayingUrl != null,
              ),
          ],
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Header
// ──────────────────────────────────────────────────────────────────
class _Header extends StatelessWidget {
  final VoidCallback onFreeCredits;
  const _Header({required this.onFreeCredits});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.accent,
            borderRadius: BorderRadius.circular(AppRadius.input),
          ),
          alignment: Alignment.center,
          child: const Icon(
            Icons.build_rounded,
            color: AppColors.onAccent,
            size: AppIcons.lg,
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                tr(context, 'app_name'),
                style: AppText.title.copyWith(fontSize: 19),
              ),
              const SizedBox(height: 2),
              Text(tr(context, 'app_tagline'), style: AppText.caption),
            ],
          ),
        ),
        IconButton(
          onPressed: onFreeCredits,
          icon: const Icon(Icons.card_giftcard_rounded, size: AppIcons.md),
          color: AppColors.textMuted,
          tooltip: tr(context, 'home_free_credits_tooltip'),
          splashRadius: 22,
        ),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Free credits dialog — opens immediately, then loads availability inside.
// ──────────────────────────────────────────────────────────────────
class _FreeCreditsDialog extends StatelessWidget {
  final Future<Map<String, dynamic>> statusFuture;
  final ValueChanged<Map<String, dynamic>> onWatch;

  const _FreeCreditsDialog({
    required this.statusFuture,
    required this.onWatch,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.bgRaised,
      title: Text(
        tr(context, 'home_free_credits_dialog_title'),
        style: AppText.heading,
      ),
      content: FutureBuilder<Map<String, dynamic>>(
        future: statusFuture,
        builder: (context, snapshot) {
          final data = snapshot.data;
          final remaining = (data?['daily_remaining'] as num?)?.toInt();
          final limit = (data?['daily_limit'] as num?)?.toInt();
          final rawAd = data?['ad'];
          final ad = rawAd is Map ? Map<String, dynamic>.from(rawAd) : null;
          final hasAd = ad != null;

          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                tr(context, 'home_free_credits_dialog_body'),
                style: AppText.body,
              ),
              if (snapshot.connectionState == ConnectionState.waiting && data == null) ...[
                const SizedBox(height: AppSpacing.lg),
                const Center(
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              ] else if (remaining != null && limit != null) ...[
                const SizedBox(height: AppSpacing.lg),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppSpacing.md,
                    vertical: AppSpacing.sm,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.bgElevated,
                    borderRadius: BorderRadius.circular(AppRadius.input),
                  ),
                  child: Text(
                    tr(context, 'home_ads_left_today')
                        .replaceAll('{n}', '$remaining')
                        .replaceAll('{limit}', '$limit'),
                    style: AppText.body.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppColors.accent,
                    ),
                  ),
                ),
                if (hasAd && remaining > 0) ...[
                  const SizedBox(height: AppSpacing.md),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => onWatch(ad!),
                      icon: const Icon(
                        Icons.play_circle_outline_rounded,
                        size: AppIcons.md,
                      ),
                      label: Text(tr(context, 'home_watch_ads')),
                    ),
                  ),
                ],
              ],
            ],
          );
        },
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(tr(context, 'home_got_it')),
        ),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Loading state
// ──────────────────────────────────────────────────────────────────
class _LoadingScaffold extends StatelessWidget {
  const _LoadingScaffold();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                valueColor: AlwaysStoppedAnimation(AppColors.accent),
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(tr(context, 'home_loading'), style: AppText.caption),
          ],
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Maintenance banner
// ──────────────────────────────────────────────────────────────────
class _MaintenanceOverlay extends StatelessWidget {
  final bool isUnavailable;
  final String title;
  final String message;
  final bool isMusicPlaying;

  const _MaintenanceOverlay({
    required this.isUnavailable,
    required this.title,
    required this.message,
    required this.isMusicPlaying,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgBase, Color(0xFF141922)],
          ),
        ),
        child: Stack(
          children: [
            const Positioned.fill(child: _FloatingOrbs()),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.xxl),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _GlassIconBox(
                      icon: isUnavailable ? Icons.cloud_off_rounded : Icons.build_circle_rounded,
                    ),
                    const SizedBox(height: AppSpacing.xxl),
                    Text(
                      title.isNotEmpty
                          ? title
                          : (isUnavailable ? tr(context, 'home_unavailable_title') : tr(context, 'home_maintenance_title')),
                      style: AppText.heading.copyWith(fontSize: 21),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Text(
                      message.isNotEmpty ? message : tr(context, 'home_maintenance_default_message'),
                      style: AppText.subtitle,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: AppSpacing.xxl),
                    if (isMusicPlaying) ...[
                      const _AudioWaveBars(),
                      const SizedBox(height: AppSpacing.xl),
                    ] else ...[
                      const _PulsingDot(),
                      const SizedBox(height: AppSpacing.md),
                    ],
                    Text(
                      tr(context, 'home_maintenance_auto_unlock'),
                      style: AppText.caption,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Glassmorphism icon container — blurred, semi-transparent, soft border.
class _GlassIconBox extends StatelessWidget {
  final IconData icon;
  const _GlassIconBox({required this.icon});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            color: AppColors.error.withAlpha(20),
            border: Border.all(color: Colors.white.withAlpha(30), width: 1),
          ),
          child: Icon(icon, size: 44, color: AppColors.error),
        ),
      ),
    );
  }
}

// Slow-drifting soft blurred circles behind the card — purely decorative
// "something moving" ambience, no interaction.
class _FloatingOrbs extends StatefulWidget {
  const _FloatingOrbs();

  @override
  State<_FloatingOrbs> createState() => _FloatingOrbsState();
}

class _FloatingOrbsState extends State<_FloatingOrbs> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 14),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = _controller.value * 2 * 3.14159265;
        return Stack(
          children: [
            _orb(top: 60 + 20 * math.sin(t), left: -40 + 10 * math.cos(t), size: 180, color: AppColors.accent),
            _orb(bottom: 100 + 24 * math.cos(t), right: -30 + 12 * math.sin(t), size: 220, color: AppColors.error),
          ],
        );
      },
    );
  }

  Widget _orb({double? top, double? bottom, double? left, double? right, required double size, required Color color}) {
    return Positioned(
      top: top,
      bottom: bottom,
      left: left,
      right: right,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 60, sigmaY: 60),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withAlpha(15),
            ),
          ),
        ),
      ),
    );
  }
}

// Mini animated bars, purely decorative — reflects that maintenance
// music is playing in the background. No controls, nothing tappable.
class _AudioWaveBars extends StatefulWidget {
  const _AudioWaveBars();

  @override
  State<_AudioWaveBars> createState() => _AudioWaveBarsState();
}

class _AudioWaveBarsState extends State<_AudioWaveBars> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat();

  static const _phases = [0.0, 0.6, 0.2, 0.8, 0.4];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 28,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: _phases.map((phase) {
              final t = (_controller.value + phase) % 1.0;
              final height = 6 + 20 * (0.5 + 0.5 * math.sin(t * 2 * 3.14159265));
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Container(
                  width: 4,
                  height: height,
                  decoration: BoxDecoration(
                    color: AppColors.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  const _PulsingDot();

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 1, milliseconds: 200),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween(begin: 0.25, end: 0.9).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
      ),
      child: Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Stats card — hero numbers
// ──────────────────────────────────────────────────────────────────
class _StatsCard extends StatelessWidget {
  final int credits;
  final int uploads;
  final bool telegramBound;

  const _StatsCard({
    required this.credits,
    required this.uploads,
    required this.telegramBound,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.xxl,
        vertical: AppSpacing.xxl,
      ),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.hero),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr(context, 'home_stats_credits'), style: AppText.sectionLabel),
          const SizedBox(height: AppSpacing.sm),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text('$credits', style: AppText.display),
              const SizedBox(width: AppSpacing.sm),
              Text(tr(context, 'claim_credits'), style: AppText.subtitle),
            ],
          ),
          const SizedBox(height: AppSpacing.xl),
          Divider(color: AppColors.bgOverlay, height: 1),
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              _MiniStat(
                icon: Icons.upload_file_rounded,
                label: tr(context, 'home_stats_submits'),
                value: '$uploads',
              ),
              const SizedBox(width: AppSpacing.xxl),
              _MiniStat(
                icon: Icons.send_rounded,
                label: tr(context, 'home_stats_telegram'),
                value: telegramBound ? tr(context, 'home_linked_badge') : tr(context, 'home_not_set'),
                highlight: telegramBound,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final bool highlight;

  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: AppIcons.sm,
          color: highlight ? AppColors.accent : AppColors.textMuted,
        ),
        const SizedBox(width: AppSpacing.sm),
        Text(
          value,
          style: AppText.body.copyWith(
            fontWeight: FontWeight.w600,
            color: highlight ? AppColors.accent : AppColors.textPrimary,
          ),
        ),
        const SizedBox(width: AppSpacing.xs),
        Text(label, style: AppText.caption),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Primary "Hantar Projek" CTA
// ──────────────────────────────────────────────────────────────────
class _PrimaryAction extends StatelessWidget {
  final bool disabled;
  final VoidCallback onTap;

  const _PrimaryAction({required this.disabled, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: disabled ? null : onTap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_upload_rounded, size: AppIcons.md),
            const SizedBox(width: AppSpacing.sm),
            Text(tr(context, 'home_submit_project'), style: const TextStyle(fontSize: 15)),
          ],
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Section label
// ──────────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String label;
  final Widget? trailing;
  const _SectionLabel({required this.label, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(label, style: AppText.sectionLabel),
        const Spacer(),
        if (trailing != null) trailing!,
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Action tile (secondary)
// ──────────────────────────────────────────────────────────────────
class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback onTap;
  final bool disabled;

  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Opacity(
          opacity: disabled ? 0.4 : 1,
          child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.lg,
          ),
          child: Row(
            children: [
              Icon(icon, size: AppIcons.lg, color: AppColors.textPrimary),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppText.heading.copyWith(fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: AppText.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              trailing ??
                  const Icon(
                    Icons.chevron_right_rounded,
                    size: AppIcons.lg,
                    color: AppColors.textMuted,
                  ),
            ],
          ),
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Status badge
// ──────────────────────────────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;

  const _StatusBadge(this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm + 2,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: color.withAlpha(20),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Text(
        label,
        style: AppText.caption.copyWith(
          color: color,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
          fontSize: 11,
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Device ID card — shows the unique device identifier with copy button
// ──────────────────────────────────────────────────────────────────
class _DeviceIdCard extends StatelessWidget {
  final String deviceId;
  const _DeviceIdCard({required this.deviceId});

  @override
  Widget build(BuildContext context) {
    final shortId = deviceId.length > 24
        ? '${deviceId.substring(0, 12)}…${deviceId.substring(deviceId.length - 8)}'
        : deviceId;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.md + 2,
      ),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.phone_android_rounded,
            size: AppIcons.sm + 2,
            color: AppColors.textSecondary,
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr(context, 'home_device_id_label'), style: AppText.sectionLabel),
                const SizedBox(height: 2),
                Text(
                  shortId,
                  style: AppText.caption.copyWith(
                    fontFamily: 'monospace',
                    letterSpacing: 0.3,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: deviceId));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(tr(context, 'home_device_id_copied')),
                  duration: const Duration(seconds: 1),
                ),
              );
            },
            icon: const Icon(Icons.copy_rounded, size: AppIcons.sm + 2),
            color: AppColors.textSecondary,
            splashRadius: 20,
            tooltip: tr(context, 'home_copy_device_id'),
          ),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Telegram required dialog — shown when user tries to upload without binding
// ──────────────────────────────────────────────────────────────────
class _TelegramRequiredDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      backgroundColor: AppColors.bgElevated,
      title: Row(
        children: [
          const Icon(Icons.send_rounded, color: AppColors.accent, size: AppIcons.md),
          const SizedBox(width: AppSpacing.sm),
          Text(tr(context, 'home_telegram_required_title'), style: AppText.heading.copyWith(fontSize: 17)),
        ],
      ),
      content: Text(
        tr(context, 'home_telegram_required_body'),
        style: AppText.subtitle.copyWith(height: 1.5),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text(tr(context, 'common_cancel')),
        ),
        ElevatedButton.icon(
          onPressed: () => Navigator.pop(context, true),
          icon: const Icon(Icons.link_rounded, size: AppIcons.sm),
          label: Text(tr(context, 'home_link_now')),
        ),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Build progress card — shows GitHub Actions queue status
// ──────────────────────────────────────────────────────────────────
class _BuildProgressCard extends StatelessWidget {
  final int inProgress;
  final int estimatedMin;
  final VoidCallback onRefresh;

  const _BuildProgressCard({
    required this.inProgress,
    required this.estimatedMin,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.warning.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: AppColors.warning.withAlpha(60), width: 1),
      ),
      child: Row(
        children: [
          const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation(AppColors.warning),
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$inProgress ${tr(context, inProgress > 1 ? 'home_builds_running' : 'home_build_running')}',
                  style: AppText.body.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppColors.warning,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  tr(context, 'home_estimated_minutes').replaceAll('{n}', '$estimatedMin'),
                  style: AppText.caption.copyWith(
                    color: AppColors.warning.withAlpha(180),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onRefresh,
            icon: const Icon(Icons.refresh_rounded, size: AppIcons.sm),
            color: AppColors.warning,
            splashRadius: 18,
            tooltip: tr(context, 'home_refresh_status_tooltip'),
          ),
        ],
      ),
    );
  }
}
