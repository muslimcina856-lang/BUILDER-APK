import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/services/api_service.dart';
import 'package:earl_builder/theme/app_theme.dart';

class MyAdsScreen extends StatefulWidget {
  final String deviceId;

  const MyAdsScreen({super.key, required this.deviceId});

  @override
  State<MyAdsScreen> createState() => _MyAdsScreenState();
}

class _MyAdsScreenState extends State<MyAdsScreen> {
  List<Map<String, dynamic>> _ads = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final result = await ApiService.getMyAds(widget.deviceId);
      if (!mounted) return;
      setState(() {
        _ads = List<Map<String, dynamic>>.from(
          result['ads'] ?? <dynamic>[],
        );
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = trStatic(context, 'my_ads_load_error'));
    }

    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, 'my_ads_title')),
        actions: [
          IconButton(
            onPressed: _isLoading ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
            tooltip: tr(context, 'common_retry'),
          ),
        ],
      ),
      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(AppColors.accent),
                  ),
                ),
              )
            : _error != null
                ? _MyAdsError(message: _error!, onRetry: _load)
                : RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.bgElevated,
                    onRefresh: _load,
                    child: _ads.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.all(AppSpacing.xxl),
                            children: const [_MyAdsEmpty()],
                          )
                        : ListView.separated(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(
                              AppSpacing.xxl,
                              AppSpacing.xl,
                              AppSpacing.xxl,
                              AppSpacing.huge,
                            ),
                            itemCount: _ads.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: AppSpacing.md),
                            itemBuilder: (_, index) =>
                                _MyAdCard(ad: _ads[index]),
                          ),
                  ),
      ),
    );
  }
}

class _MyAdsError extends StatelessWidget {
  final String message;
  final Future<void> Function() onRetry;

  const _MyAdsError({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.cloud_off_rounded,
              size: AppIcons.hero,
              color: AppColors.error,
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              message,
              style: AppText.subtitle,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.lg),
            OutlinedButton(
              onPressed: onRetry,
              child: Text(tr(context, 'common_retry')),
            ),
          ],
        ),
      ),
    );
  }
}

class _MyAdsEmpty extends StatelessWidget {
  const _MyAdsEmpty();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: AppSpacing.huge * 2),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.campaign_outlined,
            size: AppIcons.hero,
            color: AppColors.textMuted,
          ),
          const SizedBox(height: AppSpacing.md),
          Text(tr(context, 'my_ads_empty_title'), style: AppText.heading),
          const SizedBox(height: AppSpacing.xs),
          Text(
            tr(context, 'my_ads_empty_subtitle'),
            style: AppText.subtitle,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _MyAdCard extends StatelessWidget {
  final Map<String, dynamic> ad;

  const _MyAdCard({required this.ad});

  static int _intValue(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static DateTime? _parseUtc(dynamic value) {
    final raw = value?.toString().trim() ?? '';
    if (raw.isEmpty) return null;
    final normalized = raw.contains('T') ? raw : raw.replaceFirst(' ', 'T');
    return DateTime.tryParse(normalized.endsWith('Z') ? normalized : '${normalized}Z')
        ?.toUtc();
  }

  static String _formatDate(DateTime date) {
    final malaysia = date.toUtc().add(const Duration(hours: 8));
    final day = malaysia.day.toString().padLeft(2, '0');
    final month = malaysia.month.toString().padLeft(2, '0');
    return '$day/$month/${malaysia.year}';
  }

  @override
  Widget build(BuildContext context) {
    final title = (ad['title'] ?? '').toString().trim();
    final caption = (ad['caption'] ?? '').toString().trim();
    final limitType = (ad['limit_type'] ?? 'views').toString();
    final limitValue =
        math.max(1, _intValue(ad['limit_value'], fallback: 1)).toInt();
    final viewsCount = math.max(0, _intValue(ad['views_count'])).toInt();

    late final double progress;
    late final String progressText;
    late final String remainingText;
    String? startDate;
    String? endDate;

    if (limitType == 'days') {
      final created = _parseUtc(ad['created_at']);
      final now = DateTime.now().toUtc();
      final expires = created?.add(Duration(days: limitValue));
      final elapsedDays = created == null || now.isBefore(created)
          ? 0
          : now.difference(created).inDays;
      final currentDay =
          math.min(limitValue, math.max(1, elapsedDays + 1)).toInt();
      final totalMilliseconds = Duration(days: limitValue).inMilliseconds;
      final elapsedMilliseconds = created == null
          ? 0
          : math.max(0, now.difference(created).inMilliseconds).toInt();
      progress = totalMilliseconds <= 0
          ? 0.0
          : (elapsedMilliseconds / totalMilliseconds)
              .clamp(0.0, 1.0)
              .toDouble();

      final remainingSeconds = expires == null
          ? 0
          : math.max(0, expires.difference(now).inSeconds).toInt();
      final remainingDays = (remainingSeconds / (24 * 60 * 60)).ceil();

      progressText = tr(context, 'my_ads_day_progress')
          .replaceAll('{current}', '$currentDay')
          .replaceAll('{limit}', '$limitValue');
      remainingText = tr(context, 'my_ads_days_remaining')
          .replaceAll('{n}', '$remainingDays');
      if (created != null && expires != null) {
        startDate = _formatDate(created);
        endDate = _formatDate(expires);
      }
    } else {
      final currentViews = math.min(viewsCount, limitValue).toInt();
      final remainingViews = math.max(0, limitValue - currentViews).toInt();
      progress = (currentViews / limitValue).clamp(0.0, 1.0).toDouble();
      progressText = tr(context, 'my_ads_views_progress')
          .replaceAll('{current}', '$currentViews')
          .replaceAll('{limit}', '$limitValue');
      remainingText = tr(context, 'my_ads_views_remaining')
          .replaceAll('{n}', '$remainingViews');
    }

    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title.isEmpty ? tr(context, 'my_ads_untitled') : title,
                  style: AppText.heading.copyWith(fontSize: 16),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.sm,
                  vertical: AppSpacing.xs,
                ),
                decoration: BoxDecoration(
                  color: AppColors.accent.withAlpha(18),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
                child: Text(
                  tr(context, 'my_ads_active'),
                  style: AppText.caption.copyWith(color: AppColors.accent),
                ),
              ),
            ],
          ),
          if (caption.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.xs),
            Text(
              caption,
              style: AppText.subtitle,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              Icon(
                limitType == 'days'
                    ? Icons.calendar_today_rounded
                    : Icons.visibility_rounded,
                size: AppIcons.sm,
                color: AppColors.accent,
              ),
              const SizedBox(width: AppSpacing.sm),
              Text(
                limitType == 'days'
                    ? tr(context, 'my_ads_limit_days')
                    : tr(context, 'my_ads_limit_views'),
                style: AppText.caption.copyWith(color: AppColors.textSecondary),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.pill),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 7,
              backgroundColor: AppColors.bgOverlay,
              valueColor: const AlwaysStoppedAnimation(AppColors.accent),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Row(
            children: [
              Expanded(
                child: Text(
                  progressText,
                  style: AppText.body.copyWith(fontWeight: FontWeight.w600),
                ),
              ),
              Text(remainingText, style: AppText.caption),
            ],
          ),
          if (startDate != null && endDate != null) ...[
            const SizedBox(height: AppSpacing.md),
            const Divider(),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: [
                Expanded(
                  child: _DateValue(
                    label: tr(context, 'my_ads_started'),
                    value: startDate,
                  ),
                ),
                const SizedBox(width: AppSpacing.lg),
                Expanded(
                  child: _DateValue(
                    label: tr(context, 'my_ads_ends'),
                    value: endDate,
                    alignEnd: true,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _DateValue extends StatelessWidget {
  final String label;
  final String value;
  final bool alignEnd;

  const _DateValue({
    required this.label,
    required this.value,
    this.alignEnd = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
          alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(label, style: AppText.caption),
        const SizedBox(height: 2),
        Text(
          value,
          style: AppText.body.copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
