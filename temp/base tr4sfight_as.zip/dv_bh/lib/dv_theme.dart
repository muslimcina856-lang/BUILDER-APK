// dv_theme.dart — DarkVerse v8.0 SINGULARITY EDITION
import 'package:flutter/material.dart';
import 'dart:ui' as ui;

class DV {
  static const Color bg0    = Color(0xFF000000);
  static const Color bg1    = Color(0xFF04020A);
  static const Color bg2    = Color(0xFF090415);
  static const Color bg3    = Color(0xFF0F061E);
  static const Color bgCard = Color(0xFF060210);
  static const Color diskCore  = Color(0xFFFF2200);
  static const Color diskMid   = Color(0xFFFF6600);
  static const Color diskOuter = Color(0xFFFFAA00);
  static const Color diskGold  = Color(0xFFFFCC44);
  static const Color radHot    = Color(0xFFFF4400);
  static const Color radWarm   = Color(0xFFFF8800);
  static const Color radSoft   = Color(0xFFFFBB55);
  static const Color jetBlue   = Color(0xFF00CCFF);
  static const Color jetCore   = Color(0xFF0088FF);
  static const Color jetSoft   = Color(0xFF66DDFF);
  static const Color lensViolet = Color(0xFFAA44FF);
  static const Color lensLight  = Color(0xFFCC88FF);
  static const Color success = Color(0xFF00FF88);
  static const Color error   = Color(0xFFFF2244);
  static const Color warning = Color(0xFFFFAA00);
  static const Color info    = Color(0xFF44AAFF);
  static const Color textPrimary   = Color(0xFFFFF8F0);
  static const Color textSecondary = Color(0xFFAA8866);
  static const Color textHint      = Color(0xFF3D2211);
  static const Color textGlow      = Color(0xFFFFBB66);
  static const Color textJet       = Color(0xFF88DDFF);

  static Color get glassCard   => diskMid.withOpacity(0.04);
  static Color get glassHover  => diskMid.withOpacity(0.11);
  static Color get glassBorder => Colors.white.withOpacity(0.06);
  static Color get purpleBorder => diskMid.withOpacity(0.45);
  static Color get purpleGlow   => diskMid.withOpacity(0.35);
  static Color get pinkGlow     => lensViolet.withOpacity(0.22);
  static Color get blueGlow     => jetBlue.withOpacity(0.28);
  static Color get cyanGlow     => jetBlue.withOpacity(0.28);
  static Color get cyanBorder   => diskMid.withOpacity(0.45);
  static Color get tealGlow     => jetBlue.withOpacity(0.28);
  static Color get orangeBorder => diskMid.withOpacity(0.45);
  static Color get orangeGlow   => diskMid.withOpacity(0.35);
  static Color get emberGlow    => diskOuter.withOpacity(0.30);

  static const Color purple      = lensViolet;
  static const Color purpleLight = lensLight;
  static const Color purpleDark  = Color(0xFF7700CC);
  static const Color violet      = lensViolet;
  static const Color pink        = radHot;
  static const Color neonGreen   = success;
  static const Color neonCyan    = jetBlue;
  static const Color neonPink    = radHot;
  static const Color cyan        = jetBlue;
  static const Color cyanLight   = jetSoft;
  static const Color cyanDark    = jetCore;
  static const Color cyanDeep    = Color(0xFF004488);
  static const Color teal        = success;
  static const Color textNeon    = textGlow;
  static const Color textCyan    = textJet;
  static const Color orange      = diskMid;
  static const Color orangeLight = diskOuter;
  static const Color orangeDark  = diskCore;
  static const Color orangeEmber = radHot;
  static const Color amber       = diskGold;
  static const Color textOrange  = textGlow;

  static LinearGradient get bgGradient => const LinearGradient(
    begin: Alignment.topLeft, end: Alignment.bottomRight,
    colors: [Color(0xFF000000), Color(0xFF04020A), Color(0xFF020005)]);

  static const LinearGradient fireGradient = LinearGradient(
    colors: [Color(0xFFFF2200), Color(0xFFFF6600), Color(0xFFFFAA00)],
    begin: Alignment.centerLeft, end: Alignment.centerRight);

  static const LinearGradient diskGradient = LinearGradient(
    colors: [Color(0xFFFF2200), Color(0xFFFF5500), Color(0xFFFFAA00), Color(0xFFFFCC44)],
    begin: Alignment.centerLeft, end: Alignment.centerRight);

  static const LinearGradient jetGradient = LinearGradient(
    colors: [Color(0xFF0044AA), Color(0xFF00AAFF), Color(0xFF44DDFF)],
    begin: Alignment.bottomCenter, end: Alignment.topCenter);

  static const LinearGradient lensGradient = LinearGradient(
    colors: [Color(0xFF6600CC), Color(0xFFAA44FF), Color(0xFFFF6600)],
    begin: Alignment.topLeft, end: Alignment.bottomRight);

  static const LinearGradient holoGradient     = jetGradient;
  static const LinearGradient coldGradient     = jetGradient;
  static const LinearGradient hotGradient      = fireGradient;
  static const LinearGradient electricGradient = jetGradient;

  static LinearGradient get cyanGradient  => const LinearGradient(
    colors: [jetBlue, jetSoft], begin: Alignment.topLeft, end: Alignment.bottomRight);
  static LinearGradient get amberGradient => const LinearGradient(
    colors: [diskMid, diskGold], begin: Alignment.topLeft, end: Alignment.bottomRight);

  static BoxDecoration card({double r=20, bool glow=false, bool fire=false, bool holo=false}) =>
    BoxDecoration(
      color: fire ? diskMid.withOpacity(0.10) : diskMid.withOpacity(0.04),
      borderRadius: BorderRadius.circular(r),
      border: Border.all(
        color: holo ? jetBlue.withOpacity(0.45) : (fire ? diskMid.withOpacity(0.45) : Colors.white.withOpacity(0.06)),
        width: fire || holo ? 1.2 : 1.0),
      boxShadow: glow
        ? [BoxShadow(color: holo ? jetBlue.withOpacity(0.28) : diskMid.withOpacity(0.35),
            blurRadius: 36, offset: const Offset(0, 8), spreadRadius: -4)]
        : [BoxShadow(color: Colors.black.withOpacity(0.85), blurRadius: 18, offset: const Offset(0, 6))]);

  static InputDecoration input({required String label, required IconData icon, Widget? suffix}) =>
    InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: textSecondary, fontSize: 14),
      prefixIcon: Icon(icon, color: textSecondary, size: 20),
      suffixIcon: suffix,
      filled: true, fillColor: bgCard,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      border: _ob(Colors.transparent),
      enabledBorder: _ob(Colors.white.withOpacity(0.06)),
      focusedBorder: _ob(diskMid, width: 1.5),
      errorBorder: _ob(error.withOpacity(0.6)),
      focusedErrorBorder: _ob(error, width: 1.5));

  static OutlineInputBorder _ob(Color c, {double width=1.0}) =>
    OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c, width: width));

  static ThemeData themeData() => ThemeData(
    brightness: Brightness.dark, fontFamily: 'ShareTechMono',
    scaffoldBackgroundColor: bg0,
    colorScheme: const ColorScheme.dark().copyWith(primary: diskMid, secondary: diskOuter),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, foregroundColor: textPrimary),
    drawerTheme: const DrawerThemeData(backgroundColor: bg0));
}

class DVCard extends StatelessWidget {
  final Widget child; final double radius; final bool glow, fire, holo; final EdgeInsets? padding;
  const DVCard({super.key, required this.child, this.radius=18, this.glow=false, this.fire=false, this.holo=false, this.padding});
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: DV.card(r: radius, glow: glow, fire: fire, holo: holo),
    child: ClipRRect(borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12), child: child)));
}

class DVButton extends StatelessWidget {
  final String label; final IconData? icon; final VoidCallback? onTap;
  final bool isLoading, outline, holo;
  const DVButton({super.key, required this.label, this.icon, this.onTap,
    this.isLoading=false, this.outline=false, this.holo=false});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: isLoading ? null : onTap,
    child: AnimatedContainer(duration: const Duration(milliseconds: 250), height: 54,
      decoration: BoxDecoration(
        gradient: outline ? null : (holo ? DV.jetGradient : DV.fireGradient),
        color: outline ? DV.glassCard : null,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: holo ? DV.jetBlue.withOpacity(0.5) : DV.diskMid.withOpacity(0.45)),
        boxShadow: outline ? [] : [BoxShadow(
          color: holo ? DV.jetBlue.withOpacity(0.28) : DV.diskMid.withOpacity(0.35),
          blurRadius: 22, offset: const Offset(0, 6))]),
      child: Center(child: isLoading
        ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: DV.diskOuter))
        : Row(mainAxisAlignment: MainAxisAlignment.center, mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, color: Colors.white, size: 18), const SizedBox(width: 8)],
            Text(label, style: TextStyle(color: outline ? DV.textGlow : Colors.white,
                fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2, fontFamily: 'Orbitron')),
          ]))));
}

class DVFireDivider extends StatelessWidget {
  final String? label;
  const DVFireDivider({super.key, this.label});
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Container(height: 1, decoration: BoxDecoration(
      gradient: LinearGradient(colors: [Colors.transparent, DV.glassBorder, DV.diskMid.withOpacity(0.3)])))),
    if (label != null) ...[
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(border: Border.all(color: DV.diskMid.withOpacity(0.35)),
          borderRadius: BorderRadius.circular(20), color: DV.glassCard),
        child: Text(label!, style: const TextStyle(color: DV.textHint, fontSize: 10, letterSpacing: 2)))),
      Expanded(child: Container(height: 1, decoration: BoxDecoration(
        gradient: LinearGradient(colors: [DV.diskMid.withOpacity(0.3), DV.glassBorder, Colors.transparent])))),
    ],
  ]);
}

PreferredSizeWidget dvAppBar(BuildContext context, String title, {List<Widget>? actions}) => AppBar(
  backgroundColor: DV.bg0.withOpacity(0.95), elevation: 0,
  leading: Container(margin: const EdgeInsets.all(8),
    decoration: BoxDecoration(color: DV.glassCard, borderRadius: BorderRadius.circular(10),
      border: Border.all(color: DV.glassBorder)),
    child: IconButton(padding: EdgeInsets.zero,
      icon: const Icon(Icons.arrow_back_ios_rounded, color: DV.diskMid, size: 18),
      onPressed: () => Navigator.pop(context))),
  title: ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
    child: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron',
        fontWeight: FontWeight.w800, fontSize: 14, letterSpacing: 2))),
  centerTitle: true, actions: actions,
  flexibleSpace: Container(decoration: BoxDecoration(
    border: Border(bottom: BorderSide(color: DV.diskMid.withOpacity(0.18))))));
