// splash.dart — DarkVerse v8.0 SINGULARITY
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dv_theme.dart';
import 'bh_painter.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;
  const SplashScreen({super.key,
    required this.username, required this.password, required this.role,
    required this.expiredDate, required this.sessionKey,
    required this.listBug, required this.listDoos, required this.news});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late VideoPlayerController _vid;
  AnimationController? _fade, _text, _pulse;
  bool _fadeDone = false, _navDone = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
    _vid = VideoPlayerController.asset('assets/videos/splash.mp4');
    _vid.initialize().then((_) {
      if (!mounted) return;
      _fade = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
      _text = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..forward();
      setState(() {});
      _vid.setLooping(false); _vid.play();
      _vid.addListener(_vidListener);
    }).catchError((_) { if (mounted) Future.delayed(const Duration(seconds: 3), _go); });
  }

  void _vidListener() {
    if (_navDone || !mounted) return;
    final pos = _vid.value.position, dur = _vid.value.duration;
    if (dur > Duration.zero) {
      if (dur - pos <= const Duration(seconds: 1) && !_fadeDone) { _fadeDone = true; _fade?.forward(); }
      if (pos >= dur - const Duration(milliseconds: 100)) _go();
    }
  }

  void _go() {
    if (_navDone || !mounted) return;
    _navDone = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      pageBuilder: (_, a, __) => DashboardPage(
        username: widget.username, password: widget.password,
        role: widget.role, expiredDate: widget.expiredDate,
        sessionKey: widget.sessionKey, listBug: widget.listBug,
        listDoos: widget.listDoos, news: widget.news),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      transitionDuration: const Duration(milliseconds: 700)));
  }

  @override
  void dispose() {
    _navDone = true;
    _vid.removeListener(_vidListener); _vid.dispose();
    _fade?.dispose(); _text?.dispose(); _pulse?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: DV.bg0,
    body: Stack(children: [
      // Video
      if (_vid.value.isInitialized)
        Positioned.fill(child: FittedBox(fit: BoxFit.cover,
          child: SizedBox(width: _vid.value.size.width, height: _vid.value.size.height, child: VideoPlayer(_vid))))
      else
        Positioned.fill(child: Container(color: DV.bg0)),

      // Heavy dark overlay so BH is visible
      Positioned.fill(child: Container(decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Colors.black.withOpacity(0.70), DV.bg0.withOpacity(0.80), DV.bg0.withOpacity(0.96)],
          stops: const [0.0, 0.5, 1.0])))),

      // Black hole centered
      Positioned.fill(child: Center(child: const BlackHoleWidget(size: 320, scale: 1.0))),

      // Radiant glow behind BH
      Positioned.fill(child: Center(child: AnimatedBuilder(
        animation: _pulse ?? const AlwaysStoppedAnimation(0.5),
        builder: (_, __) {
          final p = _pulse?.value ?? 0.5;
          return Container(width: 340, height: 340, decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              Colors.transparent,
              DV.diskCore.withOpacity(0.04 + p * 0.03),
              DV.diskMid.withOpacity(0.06 + p * 0.04),
              Colors.transparent,
            ], stops: const [0.0, 0.5, 0.7, 1.0])));
        }))),

      // Branding
      Positioned(bottom: 72, left: 0, right: 0,
        child: AnimatedBuilder(animation: _text ?? const AlwaysStoppedAnimation(1.0), builder: (_, __) {
          final t = _text?.value ?? 1.0;
          return Opacity(opacity: t, child: Transform.translate(offset: Offset(0, (1-t) * 28),
            child: Column(children: [
              ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
                child: const Text('DarkVerse', style: TextStyle(
                  fontSize: 44, fontWeight: FontWeight.w900,
                  color: Colors.white, letterSpacing: 6, fontFamily: 'Orbitron'))),
              const SizedBox(height: 10),
              AnimatedBuilder(animation: _pulse ?? const AlwaysStoppedAnimation(0.5), builder: (_, __) {
                final p = _pulse?.value ?? 0.5;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: DV.diskMid.withOpacity(0.3 + p * 0.2), width: 1.2),
                    color: DV.diskMid.withOpacity(0.06),
                    boxShadow: [BoxShadow(color: DV.diskMid.withOpacity(0.15 + p * 0.10), blurRadius: 22)]),
                  child: ShaderMask(shaderCallback: (b) => DV.diskGradient.createShader(b),
                    child: const Text('SINGULARITY v8.0', style: TextStyle(
                      color: Colors.white, fontSize: 10, letterSpacing: 4.5, fontFamily: 'Orbitron'))));
              }),
            ])));
        })),

      if (_fadeDone && _fade != null)
        AnimatedBuilder(animation: _fade!, builder: (_, __) =>
          Opacity(opacity: _fade!.value, child: Container(color: DV.bg0))),
    ]),
  );
}
