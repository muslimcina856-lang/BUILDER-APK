package com.virtual.devicelization.core.image

import android.content.Context
import android.net.Uri
import com.virtual.devicelization.R
import com.virtual.devicelization.core.model.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * Local Android guest image format used by Multi Device.
 *
 * A bundle is a .mdvm/.zip archive containing manifest.json plus the image files referenced by it.
 * The application never downloads proprietary images implicitly. Users can import their own AOSP/
 * legally distributable guest bundle and every profile references a local image id.
 */
data class GuestDrive(
    val id: String,
    val file: String,
    val format: String = "raw",
    val readOnly: Boolean = false,
    val profileScoped: Boolean = !readOnly,
    val qemuIf: String = "none",
    val device: String? = null,
    val bootIndex: Int? = null,
)

data class GuestImageManifest(
    val id: String,
    val name: String,
    val androidVersion: Int,
    val apiLevel: Int,
    val architecture: String = "ARM64",
    val machine: String = "virt",
    val cpu: String = "max",
    val kernel: String? = null,
    val initrd: String? = null,
    val kernelCmdline: String? = null,
    val firmwareCode: String? = null,
    val firmwareVars: String? = null,
    val drives: List<GuestDrive> = emptyList(),
    val extraArgs: List<String> = emptyList(),
    val sha256: String? = null,
    val directory: File,
) {
    fun resolve(relative: String): File {
        val base = directory.canonicalFile
        val target = File(base, relative).canonicalFile
        val prefix = base.path + File.separator
        require(target.path.startsWith(prefix)) { "Guest image path escapes its bundle: $relative" }
        return target
    }
}

data class ImageImportResult(val manifest: GuestImageManifest?, val error: String? = null)
data class ProfileSnapshotInfo(val id: String, val createdAtEpochMs: Long, val imageId: String?)

class GuestImageStore(private val context: Context) {
    private val root = File(context.filesDir, "guest_images").apply { mkdirs() }
    private val profileRoot = File(context.filesDir, "profile_data").apply { mkdirs() }
    private val snapshotRoot = File(context.filesDir, "profile_snapshots").apply { mkdirs() }

    fun list(): List<GuestImageManifest> = root.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { readManifest(it) }
        ?.sortedByDescending { it.androidVersion }
        ?: emptyList()

    fun findFor(profile: Profile): GuestImageManifest? {
        val images = list()
        val exact = profile.imageId?.let { id -> images.firstOrNull { it.id == id } }
        if (exact != null) return exact
        return images.firstOrNull {
            it.androidVersion == profile.androidVersion &&
                it.architecture.equals(profile.architecture, ignoreCase = true)
        }
    }

    fun get(id: String): GuestImageManifest? = list().firstOrNull { it.id == id }

    suspend fun importBundle(uri: Uri): ImageImportResult = withContext(Dispatchers.IO) {
        val temp = File(root, ".import-${UUID.randomUUID()}")
        temp.mkdirs()
        try {
            val initialFree = root.usableSpace
            val maxExtractBytes = (initialFree - MIN_FREE_BYTES).coerceAtLeast(0L).coerceAtMost(MAX_EXTRACT_BYTES)
            require(maxExtractBytes > 0) { "Not enough free storage to import a guest image." }
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input.buffered()).use { zip ->
                    var totalWritten = 0L
                    var entries = 0
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        entries++
                        require(entries <= MAX_ARCHIVE_ENTRIES) { "Image bundle contains too many files." }
                        require(entry.name.length <= MAX_ARCHIVE_PATH_CHARS) { "Image bundle path is too long." }
                        val safe = safeDestination(temp, entry.name)
                        if (entry.isDirectory) {
                            safe.mkdirs()
                        } else {
                            safe.parentFile?.mkdirs()
                            FileOutputStream(safe).use { out ->
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count <= 0) break
                                    totalWritten += count
                                    require(totalWritten <= maxExtractBytes) { "Image bundle is larger than available safe storage." }
                                    out.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()
                    }
                }
            } ?: return@withContext ImageImportResult(null, "Unable to open selected image bundle.")

            val manifest = readManifest(temp)
                ?: return@withContext ImageImportResult(null, "manifest.json is missing or invalid.")
            val validation = validate(manifest)
            if (validation != null) return@withContext ImageImportResult(null, validation)

            val target = File(root, sanitizeId(manifest.id))
            if (target.exists()) {
                return@withContext ImageImportResult(null, "An image with id '${manifest.id}' is already installed. Delete it first before replacing it.")
            }
            if (!temp.renameTo(target)) {
                copyDirectory(temp, target)
                temp.deleteRecursively()
            }
            val installed = readManifest(target)
                ?: return@withContext ImageImportResult(null, "Imported image could not be reopened.")
            ImageImportResult(installed)
        } catch (t: Throwable) {
            ImageImportResult(null, t.message ?: t.javaClass.simpleName)
        } finally {
            if (temp.exists()) temp.deleteRecursively()
        }
    }

    /**
     * Install an ARM64 LineageOS UTM/QEMU release ZIP directly.
     *
     * Do not hardcode vda.qcow2 here. LineageOS' UTM template allows the vda disk filename to be
     * replaced by the build, so config.plist inside the downloaded .utm bundle is the source of
     * truth. Only the configured disk files and UEFI vars are extracted.
     */
    suspend fun importLineageUtmZip(
        zipFile: File,
        remote: RemoteGuestImage,
    ): ImageImportResult = withContext(Dispatchers.IO) {
        val imageId = sanitizeId(remote.id)
        val target = File(root, imageId)
        if (target.exists()) {
            val existing = readManifest(target)
            if (existing != null && validate(existing) == null) {
                // Idempotent retry: if installation actually completed before the UI/process died,
                // report success instead of forcing a download/install cycle again.
                return@withContext ImageImportResult(existing)
            }
            // A prior interrupted commit must never poison every future Retry Install attempt.
            target.deleteRecursively()
        }
        val temp = File(root, ".lineage-${UUID.randomUUID()}").apply { mkdirs() }
        try {
            val maxExtractBytes = (root.usableSpace - MIN_FREE_BYTES).coerceAtLeast(0L).coerceAtMost(MAX_EXTRACT_BYTES)
            require(maxExtractBytes > 0L) { "Not enough free storage to install this Android image." }

            // Preflight the engine firmware before spending time/storage extracting the guest ZIP.
            // If this ever fails, the problem is the APK package itself, not the downloaded image.
            installBundledFirmware(File(temp, "edk2-aarch64-code.fd"))

            val extractedDrives = mutableListOf<GuestDrive>()
            var totalWritten = 0L
            ZipFile(zipFile).use { archive ->
                val zipEntries = mutableListOf<java.util.zip.ZipEntry>()
                val layoutEntries = mutableListOf<UtmArchiveEntry>()
                val normalizedNames = mutableSetOf<String>()
                val enumeration = archive.entries()
                var entryCount = 0
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    entryCount++
                    require(entryCount <= MAX_ARCHIVE_ENTRIES) { "Downloaded UTM image contains too many files." }
                    require(entry.name.length <= MAX_ARCHIVE_PATH_CHARS) { "Downloaded UTM image contains an overlong path." }
                    val normalized = normalizeArchivePath(entry.name)
                    validateArchivePath(normalized)
                    if (!entry.isDirectory) {
                        require(normalizedNames.add(normalized.lowercase())) { "Downloaded UTM image contains duplicate paths." }
                        zipEntries += entry
                        layoutEntries += UtmArchiveEntry(normalized, entry.size)
                    }
                }

                // jqssun's documented qemu-system launch contract uses Data/vda.qcow2,
                // Data/vdb.qcow2 and Data/efi_vars.fd. Prefer that stable release layout directly.
                // Only fall back to config.plist parsing for non-standard/older bundles. This avoids
                // failing all current releases merely because UTM changes plist encoding/fields.
                val layout = UtmConfigParser.resolveDocumentedLineageLayout(layoutEntries) ?: run {
                    val configName = UtmConfigParser.findConfigEntryName(layoutEntries)
                    val configEntry = zipEntries.firstOrNull {
                        normalizeArchivePath(it.name).equals(configName, ignoreCase = true)
                    } ?: error("Downloaded UTM image is missing config.plist.")
                    require(configEntry.size < 0L || configEntry.size in 1..MAX_UTM_CONFIG_BYTES) {
                        "UTM config.plist is missing or unexpectedly large."
                    }
                    val configText = archive.getInputStream(configEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    UtmConfigParser.resolve(configText, layoutEntries)
                }

                fun findEntry(normalizedName: String): java.util.zip.ZipEntry = zipEntries.firstOrNull {
                    normalizeArchivePath(it.name).equals(normalizedName, ignoreCase = true)
                } ?: error("Downloaded UTM image changed while it was being installed: $normalizedName")

                val requiredEntries = layout.drives.map { findEntry(it.archiveEntryName) } +
                    findEntry(layout.firmwareVarsEntryName)
                val requiredBytes = requiredEntries.map { it.size }.filter { it > 0L }.sum()
                if (requiredBytes > 0L) {
                    val safeAvailable = (root.usableSpace - MIN_FREE_BYTES).coerceAtLeast(0L)
                    require(safeAvailable >= requiredBytes) {
                        "Not enough free storage to install this Android image. " +
                            "Need about ${requiredBytes / (1024L * 1024L)} MB free for extracted VM disks."
                    }
                }

                fun extract(entry: java.util.zip.ZipEntry, output: File) {
                    output.parentFile?.mkdirs()
                    archive.getInputStream(entry).buffered(1024 * 1024).use { input ->
                        FileOutputStream(output).buffered(1024 * 1024).use { out ->
                            val buffer = ByteArray(1024 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count <= 0) break
                                totalWritten += count
                                require(totalWritten <= maxExtractBytes) { "Android image is larger than available safe storage." }
                                out.write(buffer, 0, count)
                            }
                        }
                    }
                    require(output.isFile && output.length() > 0L) { "Extracted image file is empty: ${output.name}" }
                }

                layout.drives.forEachIndexed { index, resolved ->
                    val spec = resolved.spec
                    require(spec.interfaceName.isBlank() || spec.interfaceName.equals("VirtIO", ignoreCase = true)) {
                        "Unsupported UTM drive interface '${spec.interfaceName}' for ${spec.identifier}."
                    }
                    val sourceEntry = findEntry(resolved.archiveEntryName)
                    val sourceExtension = UtmConfigParser.supportedDiskExtension(resolved.archiveEntryName)
                        ?: error("Unsupported UTM disk format: ${resolved.archiveEntryName.substringAfterLast('/')}")
                    val localExtension = if (sourceExtension == "raw") "raw" else sourceExtension
                    val localName = "${sanitizeId(spec.identifier)}.$localExtension"
                    extract(sourceEntry, File(temp, localName))
                    extractedDrives += GuestDrive(
                        id = sanitizeId(spec.identifier),
                        file = localName,
                        format = UtmConfigParser.qemuFormat(resolved.archiveEntryName),
                        readOnly = spec.readOnly,
                        profileScoped = !spec.readOnly,
                        qemuIf = "none",
                        device = "virtio-blk-pci",
                        bootIndex = index,
                    )
                }
                require(extractedDrives.isNotEmpty()) { "Downloaded UTM image does not contain any configured VM disks." }

                extract(findEntry(layout.firmwareVarsEntryName), File(temp, "efi_vars.fd"))
            }

            val manifestJson = JSONObject().apply {
                put("id", imageId)
                put("name", "${remote.name} ${remote.releaseTag}")
                put("androidVersion", remote.androidVersion)
                put("apiLevel", remote.apiLevel)
                put("architecture", "ARM64")
                put("machine", "virt")
                put("cpu", "max,pauth-impdef=on")
                put("firmwareCode", "edk2-aarch64-code.fd")
                put("firmwareVars", "efi_vars.fd")
                put("drives", JSONArray().apply {
                    extractedDrives.forEach { drive ->
                        put(JSONObject().apply {
                            put("id", drive.id)
                            put("file", drive.file)
                            put("format", drive.format)
                            put("readOnly", drive.readOnly)
                            put("profileScoped", drive.profileScoped)
                            put("if", drive.qemuIf)
                            drive.device?.let { put("device", it) }
                            drive.bootIndex?.let { put("bootIndex", it) }
                        })
                    }
                })
                put("extraArgs", JSONArray().apply {
                    listOf(
                        "-device", "virtio-gpu-pci",
                        "-device", "usb-ehci,id=usb-bus",
                        "-device", "usb-tablet,bus=usb-bus.0",
                        "-device", "usb-mouse,bus=usb-bus.0",
                        "-device", "usb-kbd,bus=usb-bus.0",
                        "-device", "virtio-serial",
                        "-device", "virtio-rng-pci",
                    ).forEach(::put)
                })
            }
            File(temp, "manifest.json").writeText(manifestJson.toString(2))
            val manifest = readManifest(temp) ?: error("Generated image manifest could not be read.")
            validate(manifest)?.let { error(it) }

            if (!temp.renameTo(target)) {
                copyDirectory(temp, target)
                temp.deleteRecursively()
            }
            val installed = readManifest(target) ?: error("Installed image could not be reopened.")
            ImageImportResult(installed)
        } catch (t: Throwable) {
            // Keep only a fully valid final install directory. Interrupted copies/commits are
            // removed so Retry Install can work from the already-downloaded ZIP immediately.
            if (target.exists()) {
                val existing = readManifest(target)
                if (existing == null || validate(existing) != null) target.deleteRecursively()
            }
            ImageImportResult(null, t.message ?: t.javaClass.simpleName)
        } finally {
            if (temp.exists()) temp.deleteRecursively()
        }
    }

    fun delete(id: String): Boolean {
        val target = File(root, sanitizeId(id))
        return target.exists() && target.deleteRecursively()
    }

    /**
     * Resolve drives for one profile. Read-only drives can be shared, while every writable drive is
     * copied into profile-private storage on first boot. This is deliberately conservative: it uses
     * more storage than qcow2 overlays but guarantees that Profile A can never modify Profile B's
     * userdata merely because both reference the same base image bundle.
     */
    suspend fun prepareProfileDrives(profile: Profile, manifest: GuestImageManifest): Map<String, File> =
        withContext(Dispatchers.IO) {
            val drivesDir = File(profileDirectory(profile.id), "drives").apply { mkdirs() }
            buildMap {
                for (drive in manifest.drives) {
                    val source = manifest.resolve(drive.file)
                    if (drive.readOnly || !drive.profileScoped) {
                        put(drive.id, source)
                    } else {
                        val extension = source.extension.takeIf { it.isNotBlank() }?.let { ".$it" } ?: ""
                        val target = File(drivesDir, "${sanitizeId(drive.id)}$extension")
                        if (!target.isFile || target.length() == 0L) {
                            target.parentFile?.mkdirs()
                            source.inputStream().buffered(1024 * 1024).use { input ->
                                target.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) }
                            }
                        }
                        put(drive.id, target)
                    }
                }
            }
        }


    /**
     * Prepare writable UEFI variable storage for one profile when an image uses pflash firmware.
     *
     * Lineage/UTM intentionally ships a compact efi_vars.fd template (about 327 KiB). QEMU's ARM
     * `virt` CFI pflash device, however, requires the block backend to match the complete flash
     * geometry. The bundled code flash is the authoritative size (currently 64 MiB), so expand the
     * profile-private vars store to that exact length and fill the unused NOR area with 0xFF.
     *
     * Existing profiles from older builds are migrated in place on the next Prepare/Start and their
     * current variable contents are preserved.
     */
    suspend fun prepareProfileFirmwareVars(profile: Profile, manifest: GuestImageManifest): File? =
        withContext(Dispatchers.IO) {
            val varsRelative = manifest.firmwareVars ?: return@withContext null
            val codeRelative = manifest.firmwareCode
                ?: error("Guest image declares UEFI vars without a firmware code image.")
            val varsTemplate = manifest.resolve(varsRelative)
            val code = manifest.resolve(codeRelative)
            require(code.isFile && code.length() > 0L) { "UEFI firmware code is missing or empty." }

            val firmwareDir = File(profileDirectory(profile.id), "firmware").apply { mkdirs() }
            val target = File(firmwareDir, "vars.fd")
            PflashStorage.ensureWritableVars(
                seed = varsTemplate,
                target = target,
                expectedSize = code.length(),
            )
        }

    suspend fun cloneProfileData(sourceProfileId: String, targetProfileId: String) = withContext(Dispatchers.IO) {
        val source = profileDirectory(sourceProfileId)
        val target = profileDirectory(targetProfileId)
        if (target.exists()) target.deleteRecursively()
        if (source.exists()) copyDirectory(source, target) else target.mkdirs()
    }

    suspend fun deleteProfileData(profileId: String): Boolean = withContext(Dispatchers.IO) {
        val dir = profileDirectory(profileId)
        val snapshots = File(snapshotRoot, sanitizeId(profileId))
        (!dir.exists() || dir.deleteRecursively()) && (!snapshots.exists() || snapshots.deleteRecursively())
    }

    suspend fun createProfileSnapshot(profile: Profile): ProfileSnapshotInfo = withContext(Dispatchers.IO) {
        val created = System.currentTimeMillis()
        val id = "snap-$created"
        val dir = File(File(snapshotRoot, sanitizeId(profile.id)), id)
        val dataTarget = File(dir, "profile_data")
        dir.mkdirs()
        val source = profileDirectory(profile.id)
        if (source.exists()) copyDirectory(source, dataTarget) else dataTarget.mkdirs()
        JSONObject().apply {
            put("id", id)
            put("createdAt", created)
            put("imageId", profile.imageId ?: JSONObject.NULL)
        }.also { File(dir, "snapshot.json").writeText(it.toString()) }
        ProfileSnapshotInfo(id, created, profile.imageId)
    }

    fun listProfileSnapshots(profileId: String): List<ProfileSnapshotInfo> {
        val base = File(snapshotRoot, sanitizeId(profileId))
        return base.listFiles()?.filter { it.isDirectory }?.mapNotNull { dir ->
            runCatching {
                val json = JSONObject(File(dir, "snapshot.json").readText())
                ProfileSnapshotInfo(
                    id = json.getString("id"),
                    createdAtEpochMs = json.getLong("createdAt"),
                    imageId = if (json.isNull("imageId")) null else json.optString("imageId", null),
                )
            }.getOrNull()
        }?.sortedByDescending { it.createdAtEpochMs }.orEmpty()
    }

    suspend fun restoreLatestProfileSnapshot(profile: Profile): Boolean = withContext(Dispatchers.IO) {
        val latest = listProfileSnapshots(profile.id).firstOrNull() ?: return@withContext false
        if (latest.imageId != profile.imageId) {
            throw IllegalStateException("Latest snapshot belongs to a different Android image. Switch the profile back to that image before restoring it.")
        }
        val source = File(File(File(snapshotRoot, sanitizeId(profile.id)), latest.id), "profile_data")
        if (!source.isDirectory) return@withContext false
        val target = profileDirectory(profile.id)
        val temp = File(profileRoot, ".restore-${sanitizeId(profile.id)}-${UUID.randomUUID()}")
        if (temp.exists()) temp.deleteRecursively()
        copyDirectory(source, temp)
        if (target.exists() && !target.deleteRecursively()) {
            temp.deleteRecursively()
            throw IllegalStateException("Unable to replace current profile disk data.")
        }
        if (!temp.renameTo(target)) {
            copyDirectory(temp, target)
            temp.deleteRecursively()
        }
        true
    }

    fun profileDirectory(profileId: String): File = File(profileRoot, sanitizeId(profileId))

    fun validate(manifest: GuestImageManifest): String? = runCatching {
        if (!manifest.architecture.equals("ARM64", true)) return@runCatching "Only ARM64 guest bundles are supported by the local engine."
        if (manifest.androidVersion !in 8..30) return@runCatching "Invalid Android version in manifest."
        if (manifest.apiLevel !in 26..100) return@runCatching "Invalid Android API level in manifest."
        if (!manifest.id.matches(Regex("[A-Za-z0-9._-]{1,96}"))) return@runCatching "Invalid image id."
        if (manifest.kernel != null && !manifest.resolve(manifest.kernel).isFile) return@runCatching "Kernel file is missing: ${manifest.kernel}"
        if (manifest.initrd != null && !manifest.resolve(manifest.initrd).isFile) return@runCatching "Initrd file is missing: ${manifest.initrd}"
        if (manifest.firmwareCode != null && !manifest.resolve(manifest.firmwareCode).isFile) return@runCatching "Firmware code file is missing: ${manifest.firmwareCode}"
        if (manifest.firmwareVars != null && !manifest.resolve(manifest.firmwareVars).isFile) return@runCatching "Firmware vars file is missing: ${manifest.firmwareVars}"
        if ((manifest.firmwareCode == null) != (manifest.firmwareVars == null)) return@runCatching "UEFI firmwareCode and firmwareVars must be provided together."
        if (!manifest.machine.matches(Regex("[A-Za-z0-9._=,+-]{1,160}"))) return@runCatching "Unsafe QEMU machine string."
        if (!manifest.cpu.matches(Regex("[A-Za-z0-9._=,+-]{1,160}"))) return@runCatching "Unsafe QEMU CPU string."
        if ((manifest.kernelCmdline?.length ?: 0) > 4096 || manifest.kernelCmdline?.contains('\u0000') == true) return@runCatching "Invalid kernel command line."
        if (manifest.drives.map { it.id }.distinct().size != manifest.drives.size) return@runCatching "Duplicate drive ids are not allowed."
        val bootIndices = manifest.drives.mapNotNull { it.bootIndex }
        if (bootIndices.distinct().size != bootIndices.size) return@runCatching "Duplicate drive boot indexes are not allowed."
        for (drive in manifest.drives) {
            if (!drive.id.matches(Regex("[A-Za-z0-9._-]{1,64}"))) return@runCatching "Invalid drive id: ${drive.id}"
            if (drive.format !in setOf("raw", "qcow2")) return@runCatching "Unsupported drive format: ${drive.format}"
            if (drive.qemuIf !in setOf("none", "virtio", "scsi", "ide")) return@runCatching "Unsupported drive interface: ${drive.qemuIf}"
            if (!manifest.resolve(drive.file).isFile) return@runCatching "Drive file is missing: ${drive.file}"
            val device = drive.device
            if (device != null && !device.matches(Regex("[A-Za-z0-9._-]+"))) return@runCatching "Unsafe QEMU device name: $device"
            if (drive.bootIndex != null && drive.bootIndex !in 0..255) return@runCatching "Invalid boot index for ${drive.id}: ${drive.bootIndex}"
        }
        validateExtraArgs(manifest.extraArgs)?.let { return@runCatching it }
        null
    }.getOrElse { it.message ?: "Invalid guest image manifest." }

    fun directorySizeBytes(manifest: GuestImageManifest): Long = manifest.directory.walkTopDown()
        .filter { it.isFile }
        .sumOf { it.length() }

    private fun installBundledFirmware(output: File) {
        output.parentFile?.mkdirs()
        try {
            context.resources.openRawResource(R.raw.edk2_aarch64_code_fd).use { raw ->
                GZIPInputStream(raw.buffered(1024 * 1024)).use { input ->
                    FileOutputStream(output).buffered(1024 * 1024).use { out ->
                        input.copyTo(out, 1024 * 1024)
                    }
                }
            }
        } catch (t: Throwable) {
            output.delete()
            throw IllegalStateException(
                "Bundled ARM64 UEFI firmware could not be opened or decompressed. " +
                    "Rebuild Multi Device with res/raw/edk2_aarch64_code_fd.gz included.",
                t,
            )
        }

        require(output.isFile && output.length() == BUNDLED_FIRMWARE_BYTES) {
            output.delete()
            "Bundled ARM64 UEFI firmware has an invalid size."
        }
        val actualSha = sha256(output)
        require(actualSha.equals(BUNDLED_FIRMWARE_SHA256, ignoreCase = true)) {
            output.delete()
            "Bundled ARM64 UEFI firmware failed its SHA-256 integrity check."
        }
    }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                md.update(buffer, 0, read)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun readManifest(dir: File): GuestImageManifest? = runCatching {
        val file = File(dir, "manifest.json")
        if (!file.isFile) return@runCatching null
        val json = JSONObject(file.readText())
        val drivesJson = json.optJSONArray("drives") ?: JSONArray()
        val drives = buildList {
            for (i in 0 until drivesJson.length()) {
                val d = drivesJson.getJSONObject(i)
                add(
                    GuestDrive(
                        id = d.optString("id", "drive$i"),
                        file = d.getString("file"),
                        format = d.optString("format", "raw"),
                        readOnly = d.optBoolean("readOnly", false),
                        profileScoped = if (d.has("profileScoped")) d.optBoolean("profileScoped") else !d.optBoolean("readOnly", false),
                        qemuIf = d.optString("if", "none"),
                        device = d.optString("device").takeIf { it.isNotBlank() },
                        bootIndex = if (d.has("bootIndex") && !d.isNull("bootIndex")) d.optInt("bootIndex") else null,
                    )
                )
            }
        }
        val argsJson = json.optJSONArray("extraArgs") ?: JSONArray()
        val args = buildList { for (i in 0 until argsJson.length()) add(argsJson.getString(i)) }
        GuestImageManifest(
            id = sanitizeId(json.getString("id")),
            name = json.optString("name", json.getString("id")),
            androidVersion = json.getInt("androidVersion"),
            apiLevel = json.getInt("apiLevel"),
            architecture = json.optString("architecture", "ARM64"),
            machine = json.optString("machine", "virt"),
            cpu = json.optString("cpu", "max"),
            kernel = json.optString("kernel").takeIf { it.isNotBlank() },
            initrd = json.optString("initrd").takeIf { it.isNotBlank() },
            kernelCmdline = json.optString("kernelCmdline").takeIf { it.isNotBlank() },
            firmwareCode = json.optString("firmwareCode").takeIf { it.isNotBlank() },
            firmwareVars = json.optString("firmwareVars").takeIf { it.isNotBlank() },
            drives = drives,
            extraArgs = args,
            sha256 = json.optString("sha256").takeIf { it.isNotBlank() },
            directory = dir,
        )
    }.getOrNull()

    private fun validateExtraArgs(args: List<String>): String? {
        var i = 0
        while (i < args.size) {
            val option = args[i]
            if (option in SAFE_FLAG_OPTIONS) {
                i++
                continue
            }
            if (option !in SAFE_VALUE_OPTIONS || i + 1 >= args.size) {
                return "Guest manifest contains unsupported QEMU option: $option"
            }
            val value = args[i + 1]
            if (UNSAFE_EXTRA_VALUE_PARTS.any { value.contains(it, ignoreCase = true) }) {
                return "Guest manifest contains unsafe host-facing QEMU option value."
            }
            i += 2
        }
        return null
    }

    private fun normalizeArchivePath(name: String): String = name.replace('\\', '/')

    private fun validateArchivePath(normalized: String) {
        require(normalized.isNotBlank()) { "Downloaded UTM image contains an empty path." }
        require(!normalized.startsWith('/')) { "Absolute archive path is not allowed." }
        require(normalized.split('/').none { it == ".." }) { "Unsafe archive path: $normalized" }
    }

    private fun safeDestination(root: File, name: String): File {
        val normalized = name.replace('\\', '/')
        require(!normalized.startsWith('/')) { "Absolute archive path is not allowed." }
        val out = File(root, normalized)
        val rootPath = root.canonicalPath + File.separator
        require(out.canonicalPath.startsWith(rootPath)) { "Unsafe archive path: $name" }
        return out
    }

    private fun copyDirectory(source: File, target: File) {
        source.walkTopDown().forEach { f ->
            val rel = f.relativeTo(source)
            val dest = File(target, rel.path)
            if (f.isDirectory) dest.mkdirs() else {
                dest.parentFile?.mkdirs()
                f.inputStream().use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
            }
        }
    }

    companion object {
        private const val BUNDLED_FIRMWARE_BYTES = 67_108_864L
        private const val BUNDLED_FIRMWARE_SHA256 = "47765fe344818cbc464b1c14ae658fb4b854f5c2ceffa982411731eb4865594d"
        private const val MIN_FREE_BYTES = 512L * 1024L * 1024L
        private const val MAX_EXTRACT_BYTES = 128L * 1024L * 1024L * 1024L
        private const val MAX_ARCHIVE_ENTRIES = 2048
        private const val MAX_ARCHIVE_PATH_CHARS = 512
        private const val MAX_UTM_CONFIG_BYTES = 2L * 1024L * 1024L
        private val SAFE_FLAG_OPTIONS = setOf("-nodefaults", "-no-shutdown")
        private val SAFE_VALUE_OPTIONS = setOf("-device", "-global", "-boot", "-rtc")
        private val UNSAFE_EXTRA_VALUE_PARTS = setOf("/", "..", "file=", "path=", "host=", "port=", "socket=", "fd=")

        fun sanitizeId(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)
    }
}
