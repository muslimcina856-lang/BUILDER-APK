package com.virtual.devicelization.core.image

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Normalizes a small UEFI variable-store template into the full pflash backing size required by
 * QEMU's ARM `virt` machine. Some UTM/Lineage templates ship only the populated variable-store
 * payload (hundreds of KiB), while QEMU's CFI pflash device requires a backing file matching the
 * complete flash geometry (64 MiB for the runtime currently bundled by Multi Device).
 *
 * The unused flash area must represent erased NOR flash, i.e. 0xFF, not zero-filled bytes.
 */
object PflashStorage {
    private const val BUFFER_SIZE = 1024 * 1024
    private val ERASED_CHUNK = ByteArray(BUFFER_SIZE) { 0xFF.toByte() }

    fun ensureWritableVars(seed: File, target: File, expectedSize: Long): File {
        require(seed.isFile && seed.length() > 0L) { "UEFI variable template is missing or empty: ${seed.name}" }
        require(expectedSize > 0L) { "UEFI pflash size is invalid: $expectedSize" }

        if (target.isFile && target.length() == expectedSize) return target

        // Preserve an already-created per-profile store when upgrading from an older Multi Device
        // build. If it is still undersized, expand that exact content rather than resetting NVRAM.
        val source = target.takeIf { it.isFile && it.length() > 0L } ?: seed
        require(source.length() <= expectedSize) {
            "UEFI variable store (${source.length()} bytes) is larger than pflash (${expectedSize} bytes)."
        }

        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, ".${target.name}.normalize-${UUID.randomUUID()}")
        try {
            FileOutputStream(temp).use { fileOut ->
                val out = BufferedOutputStream(fileOut, BUFFER_SIZE)
                source.inputStream().buffered(BUFFER_SIZE).use { input ->
                    input.copyTo(out, BUFFER_SIZE)
                }
                var remaining = expectedSize - source.length()
                while (remaining > 0L) {
                    val count = minOf(remaining, ERASED_CHUNK.size.toLong()).toInt()
                    out.write(ERASED_CHUNK, 0, count)
                    remaining -= count
                }
                out.flush()
                fileOut.fd.sync()
            }
            require(temp.length() == expectedSize) {
                "Failed to create full-size UEFI pflash vars: ${temp.length()} / $expectedSize bytes."
            }

            if (target.exists() && !target.delete()) {
                error("Unable to replace old UEFI variable store for this profile.")
            }
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            require(target.isFile && target.length() == expectedSize) {
                "UEFI variable store size is invalid after normalization."
            }
            return target
        } finally {
            if (temp.exists()) temp.delete()
        }
    }
}
