# ARM64 pflash geometry fix

Observed on-device QEMU error:

```
pflash01 device '/machine/virt.flash1' requires 67108864 bytes,
flash1 block backend provides 334848 bytes
```

The LineageOS/UTM template ships a compact `efi_vars.fd` (~327 KiB), while the QEMU ARM `virt`
CFI pflash used by the bundled runtime requires its backing file to match the full flash geometry.
The firmware code packaged by Multi Device is 64 MiB, so each profile now gets a private 64 MiB
vars flash generated from the compact template. Template bytes are preserved at offset zero and the
rest is filled with `0xFF`, the erased NOR-flash state.

The normalization runs on every Prepare/Start and is idempotent. Existing old profile vars files
that are undersized are automatically expanded without resetting their current prefix contents.
A backend preflight checks that code and vars pflash files have identical lengths before QEMU is
launched, turning this class of failure into a readable preflight error instead of a QEMU crash.
