package com.example.voiceclone_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
