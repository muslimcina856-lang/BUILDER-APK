import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'api_config.dart';

/// Menguruskan penyimpanan selamat untuk [ApiConfig] (kunci API + Base URL).
///
/// Kedua-dua nilai disimpan sebagai satu unit JSON supaya sentiasa
/// konsisten bersama — mengelakkan keadaan di mana kunci API baharu
/// disimpan tetapi Base URL lama (tidak sepadan) kekal digunakan.
class SecureConfigStore {
  static const String _storageKey = 'mimo_api_config_v1';

  final FlutterSecureStorage _storage;

  SecureConfigStore({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(encryptedSharedPreferences: true),
            );

  /// Memulangkan konfigurasi tersimpan, atau [ApiConfig.empty] jika
  /// belum pernah disimpan.
  Future<ApiConfig> getConfig() async {
    final String? raw = await _storage.read(key: _storageKey);
    if (raw == null || raw.isEmpty) return ApiConfig.empty;

    try {
      final Map<String, dynamic> decoded =
          jsonDecode(raw) as Map<String, dynamic>;
      return ApiConfig.fromJson(decoded);
    } catch (_) {
      return ApiConfig.empty;
    }
  }

  /// Menyimpan konfigurasi baharu.
  Future<void> saveConfig(ApiConfig config) async {
    await _storage.write(key: _storageKey, value: jsonEncode(config.toJson()));
  }

  /// Memadam konfigurasi tersimpan.
  Future<void> clearConfig() async {
    await _storage.delete(key: _storageKey);
  }
}
