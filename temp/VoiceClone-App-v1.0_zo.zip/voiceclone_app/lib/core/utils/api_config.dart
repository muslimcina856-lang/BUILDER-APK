import 'package:equatable/equatable.dart';

/// Konfigurasi API MiMo AI: kunci API dan Base URL yang berkaitan.
///
/// Kedua-dua nilai ini disimpan BERSAMA (bukan berasingan) kerana kunci
/// Token Plan (`tp-xxxxx`) dan kunci pay-as-you-go (`sk-xxxxx`) memerlukan
/// Base URL yang berbeza dan tidak boleh dicampur — menyimpan kunci API
/// tanpa Base URL yang sepadan adalah punca biasa ralat "kunci API tidak
/// digunakan/tidak sah" apabila pengguna Token Plan cuba menggunakan
/// Base URL lalai yang sebenarnya untuk pay-as-you-go.
class ApiConfig extends Equatable {
  final String apiKey;

  /// Base URL API. Kosong bermaksud guna Base URL lalai
  /// ([kMimoDefaultBaseUrl] dalam mimo_voiceclone_client.dart), yang
  /// sesuai untuk kunci `sk-xxxxx`. Untuk kunci `tp-xxxxx`, pengguna
  /// WAJIB mengisi Base URL yang disalin daripada halaman Token Plan
  /// mereka sendiri.
  final String baseUrl;

  const ApiConfig({
    required this.apiKey,
    this.baseUrl = '',
  });

  bool get hasKey => apiKey.trim().isNotEmpty;

  /// `true` jika kunci kelihatan seperti format Token Plan (`tp-`),
  /// digunakan untuk memaparkan amaran/panduan yang relevan di UI
  /// tentang keperluan Base URL tersuai.
  bool get looksLikeTokenPlanKey => apiKey.trim().toLowerCase().startsWith('tp-');

  ApiConfig copyWith({String? apiKey, String? baseUrl}) {
    return ApiConfig(
      apiKey: apiKey ?? this.apiKey,
      baseUrl: baseUrl ?? this.baseUrl,
    );
  }

  factory ApiConfig.fromJson(Map<String, dynamic> json) {
    return ApiConfig(
      apiKey: json['apiKey'] as String? ?? '',
      baseUrl: json['baseUrl'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'apiKey': apiKey,
      'baseUrl': baseUrl,
    };
  }

  static const empty = ApiConfig(apiKey: '', baseUrl: '');

  @override
  List<Object?> get props => [apiKey, baseUrl];

  @override
  bool get stringify => true;
}
