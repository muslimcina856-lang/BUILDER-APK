/// Rentetan teks yang digunakan merentasi aplikasi Klon Suara.
abstract final class AppStrings {
  static const String appName = 'Klon Suara';
  static const String appTagline = 'Klon Suara Anda dengan MiMo AI';

  // ─── Splash ─────────────────────────────────────────────────────────
  static const String splashLoading = 'Memulakan...';

  // ─── Settings ───────────────────────────────────────────────────────
  static const String titleSettings = 'Tetapan';
  static const String labelApiKey = 'Kunci API MiMo AI';
  static const String hintApiKey = 'Masukkan kunci API MiMo AI anda...';
  static const String labelBaseUrl = 'Base URL API';
  static const String hintBaseUrlPayAsYouGo =
      'https://api.xiaomimimo.com/v1 (lalai untuk sk-xxxxx)';
  static const String hintBaseUrlTokenPlan =
      'Untuk kunci tp-xxxxx (Token Plan), salin Base URL dari halaman Token Plan anda';

  // ─── Voice Profiles ─────────────────────────────────────────────────
  static const String titleVoiceProfiles = 'Profil Suara';
  static const String emptyProfilesTitle = 'Belum Ada Profil Suara';
  static const String emptyProfilesSubtitle =
      'Rekod suara anda terus dalam app, atau muat naik fail audio '
      '(.mp3 / .wav) untuk mula menjana pertuturan menggunakan suara klon.';
  static const String buttonAddProfile = 'Profil Suara Baharu';

  // ─── Generate ───────────────────────────────────────────────────────
  static const String titleGenerate = 'Jana Suara';
  static const String labelTextToSpeak = 'Teks Untuk Disebut';
  static const String hintTextToSpeak =
      'Taip ayat yang mahu disebut menggunakan suara klon ini...';
  static const String labelStyleInstruction = 'Arahan Gaya (Pilihan)';
  static const String hintStyleInstruction =
      'cth: Sebut dengan nada gembira dan pantas...';
  static const String buttonGenerate = 'Jana Suara';
  static const String buttonGenerating = 'Sedang Menjana...';
}
