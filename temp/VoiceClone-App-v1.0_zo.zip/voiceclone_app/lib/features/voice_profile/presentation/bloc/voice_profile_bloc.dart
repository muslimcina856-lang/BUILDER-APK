import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../../../../core/utils/api_config.dart';
import '../../../../core/utils/mimo_voiceclone_client.dart';
import '../../../../core/utils/secure_config_store.dart';
import '../../../../services/database_service.dart';
import '../../domain/entities/voice_profile.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class VoiceProfileEvent extends Equatable {
  const VoiceProfileEvent();
  @override
  List<Object?> get props => [];
}

class LoadVoiceProfiles extends VoiceProfileEvent {}

class SaveVoiceProfile extends VoiceProfileEvent {
  final String name;
  final String audioBase64;
  final String mimeType;
  final VoiceProfileSource source;

  const SaveVoiceProfile({
    required this.name,
    required this.audioBase64,
    required this.mimeType,
    required this.source,
  });

  @override
  List<Object?> get props => [name, audioBase64, mimeType, source];
}

class DeleteVoiceProfile extends VoiceProfileEvent {
  final String profileId;
  const DeleteVoiceProfile(this.profileId);
  @override
  List<Object?> get props => [profileId];
}

class GenerateVoiceClone extends VoiceProfileEvent {
  final String profileId;
  final String text;
  final String styleInstruction;

  const GenerateVoiceClone({
    required this.profileId,
    required this.text,
    this.styleInstruction = '',
  });

  @override
  List<Object?> get props => [profileId, text, styleInstruction];
}

class DeleteVoiceCloneResult extends VoiceProfileEvent {
  final String resultId;
  final String outputFilePath;
  const DeleteVoiceCloneResult({required this.resultId, required this.outputFilePath});
  @override
  List<Object?> get props => [resultId, outputFilePath];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class VoiceProfileState extends Equatable {
  const VoiceProfileState();
  @override
  List<Object?> get props => [];
}

class VoiceProfileInitial extends VoiceProfileState {}

class VoiceProfilesLoaded extends VoiceProfileState {
  final List<VoiceProfile> profiles;
  final List<VoiceCloneResult> results;
  final bool isGenerating;

  const VoiceProfilesLoaded({
    required this.profiles,
    required this.results,
    this.isGenerating = false,
  });

  VoiceProfilesLoaded copyWith({
    List<VoiceProfile>? profiles,
    List<VoiceCloneResult>? results,
    bool? isGenerating,
  }) {
    return VoiceProfilesLoaded(
      profiles: profiles ?? this.profiles,
      results: results ?? this.results,
      isGenerating: isGenerating ?? this.isGenerating,
    );
  }

  @override
  List<Object?> get props => [profiles, results, isGenerating];
}

class VoiceProfileError extends VoiceProfileState {
  final String message;
  const VoiceProfileError(this.message);
  @override
  List<Object?> get props => [message];
}

class VoiceCloneGenerated extends VoiceProfileState {
  final VoiceCloneResult result;
  const VoiceCloneGenerated(this.result);
  @override
  List<Object?> get props => [result];
}

// -----------------------------------------------------------------------------
// BLOC
// -----------------------------------------------------------------------------
class VoiceProfileBloc extends Bloc<VoiceProfileEvent, VoiceProfileState> {
  final DatabaseService _dbService;
  final SecureConfigStore _configStore;
  final Uuid _uuid = const Uuid();

  VoiceProfileBloc({
    DatabaseService? dbService,
    SecureConfigStore? configStore,
  })  : _dbService = dbService ?? DatabaseService(),
        _configStore = configStore ?? SecureConfigStore(),
        super(VoiceProfileInitial()) {
    on<LoadVoiceProfiles>(_onLoadVoiceProfiles);
    on<SaveVoiceProfile>(_onSaveVoiceProfile);
    on<DeleteVoiceProfile>(_onDeleteVoiceProfile);
    on<GenerateVoiceClone>(_onGenerateVoiceClone);
    on<DeleteVoiceCloneResult>(_onDeleteVoiceCloneResult);
  }

  Future<void> _onLoadVoiceProfiles(
      LoadVoiceProfiles event, Emitter<VoiceProfileState> emit) async {
    try {
      final List<VoiceProfile> profiles = await _loadProfiles();
      final List<VoiceCloneResult> results = await _loadResults();
      emit(VoiceProfilesLoaded(profiles: profiles, results: results));
    } catch (e) {
      emit(VoiceProfileError('Gagal memuatkan profil suara: $e'));
    }
  }

  Future<List<VoiceProfile>> _loadProfiles() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllVoiceProfiles();
    return rows.map((row) {
      return VoiceProfile.fromJson({
        'id': row['id'],
        'name': row['name'],
        'audioBase64': row['audio_base64'],
        'mimeType': row['mime_type'],
        'source': row['source'],
        'createdAt': row['created_at'],
      });
    }).toList();
  }

  Future<List<VoiceCloneResult>> _loadResults() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllVoiceCloneResults();
    return rows.map((row) {
      return VoiceCloneResult.fromJson({
        'id': row['id'],
        'voiceProfileId': row['voice_profile_id'],
        'text': row['text'],
        'outputFilePath': row['output_file_path'],
        'createdAt': row['created_at'],
      });
    }).toList();
  }

  Future<void> _onSaveVoiceProfile(
      SaveVoiceProfile event, Emitter<VoiceProfileState> emit) async {
    try {
      final VoiceProfile profile = VoiceProfile(
        id: _uuid.v4(),
        name: event.name,
        audioBase64: event.audioBase64,
        mimeType: event.mimeType,
        source: event.source,
        createdAt: DateTime.now(),
      );

      await _dbService.saveVoiceProfile({
        'id': profile.id,
        'name': profile.name,
        'audio_base64': profile.audioBase64,
        'mime_type': profile.mimeType,
        'source': profile.source.name,
        'created_at': profile.createdAt.toIso8601String(),
      });

      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceProfileError('Gagal menyimpan profil suara: $e'));
      add(LoadVoiceProfiles());
    }
  }

  Future<void> _onDeleteVoiceProfile(
      DeleteVoiceProfile event, Emitter<VoiceProfileState> emit) async {
    try {
      await _dbService.deleteVoiceProfile(event.profileId);
      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceProfileError('Gagal memadam profil suara: $e'));
      add(LoadVoiceProfiles());
    }
  }

  Future<void> _onGenerateVoiceClone(
      GenerateVoiceClone event, Emitter<VoiceProfileState> emit) async {
    final VoiceProfileState currentState = state;
    if (currentState is! VoiceProfilesLoaded) {
      emit(const VoiceProfileError(
        'Sila tunggu sebentar — profil suara sedang dimuatkan. Cuba lagi.',
      ));
      add(LoadVoiceProfiles());
      return;
    }

    emit(currentState.copyWith(isGenerating: true));

    final String trimmedText = event.text.trim();
    if (trimmedText.isEmpty) {
      emit(const VoiceProfileError('Teks untuk disebut tidak boleh kosong.'));
      emit(currentState.copyWith(isGenerating: false));
      return;
    }

    final VoiceProfile? profile = currentState.profiles
        .cast<VoiceProfile?>()
        .firstWhere((p) => p?.id == event.profileId, orElse: () => null);

    if (profile == null) {
      emit(const VoiceProfileError('Profil suara tidak dijumpai.'));
      emit(currentState.copyWith(isGenerating: false));
      return;
    }

    final ApiConfig config = await _configStore.getConfig();
    if (!config.hasKey) {
      emit(const VoiceProfileError(
        'Kunci API MiMo AI belum dimasukkan. Sila pergi ke Tetapan.',
      ));
      emit(currentState.copyWith(isGenerating: false));
      return;
    }

    final MimoVoiceCloneClient client = MimoVoiceCloneClient(
      apiKey: config.apiKey,
      baseUrl: config.baseUrl,
    );

    try {
      final List<int> audioBytes = await client.synthesize(
        text: trimmedText,
        referenceAudioBase64: profile.audioBase64,
        referenceMimeType: profile.mimeType,
        styleInstruction: event.styleInstruction,
      );

      final Directory appDir = await getApplicationDocumentsDirectory();
      final Directory voiceDir = Directory('${appDir.path}/voice_clone_outputs');
      if (!await voiceDir.exists()) {
        await voiceDir.create(recursive: true);
      }

      final String resultId = _uuid.v4();
      final String outputPath = '${voiceDir.path}/$resultId.wav';
      final File outputFile = File(outputPath);
      await outputFile.writeAsBytes(audioBytes);

      final VoiceCloneResult result = VoiceCloneResult(
        id: resultId,
        voiceProfileId: event.profileId,
        text: trimmedText,
        outputFilePath: outputPath,
        createdAt: DateTime.now(),
      );

      await _dbService.saveVoiceCloneResult({
        'id': result.id,
        'voice_profile_id': result.voiceProfileId,
        'text': result.text,
        'output_file_path': result.outputFilePath,
        'created_at': result.createdAt.toIso8601String(),
      });

      emit(VoiceCloneGenerated(result));

      final List<VoiceProfile> profiles = await _loadProfiles();
      final List<VoiceCloneResult> results = await _loadResults();
      emit(VoiceProfilesLoaded(profiles: profiles, results: results, isGenerating: false));
    } on MimoVoiceCloneException catch (e) {
      emit(VoiceProfileError(e.message));
      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceProfileError('Ralat menjana suara klon: $e'));
      add(LoadVoiceProfiles());
    } finally {
      client.dispose();
    }
  }

  Future<void> _onDeleteVoiceCloneResult(
      DeleteVoiceCloneResult event, Emitter<VoiceProfileState> emit) async {
    try {
      await _dbService.deleteVoiceCloneResult(event.resultId);

      final File outputFile = File(event.outputFilePath);
      if (await outputFile.exists()) {
        await outputFile.delete();
      }

      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceProfileError('Gagal memadam hasil: $e'));
      add(LoadVoiceProfiles());
    }
  }
}
