import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/utils/api_config.dart';
import '../../../../core/utils/secure_config_store.dart';
import '../../../../core/utils/mimo_voiceclone_client.dart';
import '../../../../services/database_service.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override
  List<Object?> get props => [];
}

class LoadSettings extends SettingsEvent {}

class SaveApiConfig extends SettingsEvent {
  final String apiKey;
  final String baseUrl;
  const SaveApiConfig({required this.apiKey, required this.baseUrl});
  @override
  List<Object?> get props => [apiKey, baseUrl];
}

class TestApiConnection extends SettingsEvent {}

class ClearAllData extends SettingsEvent {}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class SettingsState extends Equatable {
  const SettingsState();
  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final ApiConfig config;
  final bool isTesting;

  const SettingsLoaded({required this.config, this.isTesting = false});

  SettingsLoaded copyWith({ApiConfig? config, bool? isTesting}) {
    return SettingsLoaded(
      config: config ?? this.config,
      isTesting: isTesting ?? this.isTesting,
    );
  }

  @override
  List<Object?> get props => [config, isTesting];
}

class SettingsError extends SettingsState {
  final String message;
  const SettingsError(this.message);
  @override
  List<Object?> get props => [message];
}

class ApiTestResult extends SettingsState {
  final bool success;
  final String message;
  const ApiTestResult({required this.success, required this.message});
  @override
  List<Object?> get props => [success, message];
}

class DataCleared extends SettingsState {}

// -----------------------------------------------------------------------------
// BLOC
// -----------------------------------------------------------------------------
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  final SecureConfigStore _configStore;
  final DatabaseService _dbService;

  SettingsBloc({
    SecureConfigStore? configStore,
    DatabaseService? dbService,
  })  : _configStore = configStore ?? SecureConfigStore(),
        _dbService = dbService ?? DatabaseService(),
        super(SettingsInitial()) {
    on<LoadSettings>(_onLoadSettings);
    on<SaveApiConfig>(_onSaveApiConfig);
    on<TestApiConnection>(_onTestApiConnection);
    on<ClearAllData>(_onClearAllData);
  }

  Future<void> _onLoadSettings(
      LoadSettings event, Emitter<SettingsState> emit) async {
    try {
      final ApiConfig config = await _configStore.getConfig();
      emit(SettingsLoaded(config: config));
    } catch (e) {
      emit(SettingsError('Gagal memuatkan tetapan: $e'));
    }
  }

  Future<void> _onSaveApiConfig(
      SaveApiConfig event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    try {
      final ApiConfig newConfig = ApiConfig(
        apiKey: event.apiKey.trim(),
        baseUrl: event.baseUrl.trim(),
      );
      await _configStore.saveConfig(newConfig);
      emit(currentState.copyWith(config: newConfig));
    } catch (e) {
      emit(SettingsError('Gagal menyimpan kunci API: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onTestApiConnection(
      TestApiConnection event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    if (!currentState.config.hasKey) {
      emit(const ApiTestResult(
        success: false,
        message: 'Sila masukkan kunci API terlebih dahulu.',
      ));
      emit(currentState);
      return;
    }

    emit(currentState.copyWith(isTesting: true));

    final MimoVoiceCloneClient client = MimoVoiceCloneClient(
      apiKey: currentState.config.apiKey,
      baseUrl: currentState.config.baseUrl,
    );

    try {
      final MimoTestResult result = await client.testConnection();
      emit(ApiTestResult(success: result.success, message: result.message));
    } finally {
      client.dispose();
      emit(currentState.copyWith(isTesting: false));
    }
  }

  Future<void> _onClearAllData(
      ClearAllData event, Emitter<SettingsState> emit) async {
    try {
      await _configStore.clearConfig();
      await _dbService.clearAllData();
      emit(DataCleared());
      add(LoadSettings());
    } catch (e) {
      emit(SettingsError('Gagal memadam semua data: $e'));
      add(LoadSettings());
    }
  }
}
