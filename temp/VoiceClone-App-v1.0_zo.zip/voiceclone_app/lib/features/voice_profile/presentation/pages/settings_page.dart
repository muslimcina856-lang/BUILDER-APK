import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../bloc/settings_bloc.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _baseUrlController = TextEditingController();
  bool _obscureApiKey = true;
  bool _hasInitializedFromState = false;

  @override
  void dispose() {
    _apiKeyController.dispose();
    _baseUrlController.dispose();
    super.dispose();
  }

  void _confirmDeleteAll(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: AppColors.error),
              SizedBox(width: 8),
              Text('Padam Semua Data?'),
            ],
          ),
          content: const Text(
            'Ini akan memadam kunci API, Base URL, semua profil suara, dan '
            'hasil penjanaan secara kekal. Tindakan ini tidak boleh diundurkan.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<SettingsBloc>().add(ClearAllData());
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Ya, Padam Semua'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SettingsBloc, SettingsState>(
      listener: (context, state) {
        if (state is ApiTestResult) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: state.success ? AppColors.success : AppColors.error,
              duration: const Duration(seconds: 6),
            ),
          );
        } else if (state is DataCleared) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Semua data telah dipadamkan secara kekal.'),
              backgroundColor: AppColors.error,
            ),
          );
        } else if (state is SettingsError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
          );
        }
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            tooltip: 'Kembali',
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppStrings.titleSettings,
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppColors.scaffold.withOpacity(0.9),
                  AppColors.scaffold.withOpacity(0.0),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
          child: BlocBuilder<SettingsBloc, SettingsState>(
            builder: (context, state) {
              bool isTesting = false;

              if (state is SettingsLoaded) {
                isTesting = state.isTesting;
                // Isi field sekali sahaja bila data pertama kali dimuatkan,
                // supaya taipan pengguna tidak ditimpa semula pada rebuild.
                if (!_hasInitializedFromState) {
                  _apiKeyController.text = state.config.apiKey;
                  _baseUrlController.text = state.config.baseUrl;
                  _hasInitializedFromState = true;
                }
              }

              return SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSectionHeader('Kunci API MiMo AI', Icons.vpn_key_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextField(
                              controller: _apiKeyController,
                              obscureText: _obscureApiKey,
                              style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
                              decoration: InputDecoration(
                                labelText: AppStrings.labelApiKey,
                                hintText: AppStrings.hintApiKey,
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    _obscureApiKey ? Icons.visibility_off : Icons.visibility,
                                    color: AppColors.textMuted,
                                  ),
                                  onPressed: () => setState(() => _obscureApiKey = !_obscureApiKey),
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: _baseUrlController,
                              style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
                              decoration: const InputDecoration(
                                labelText: AppStrings.labelBaseUrl,
                                hintText: AppStrings.hintBaseUrlPayAsYouGo,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppColors.accent.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: AppColors.accent.withOpacity(0.25)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.info_outline_rounded, size: 16, color: AppColors.accent),
                                      const SizedBox(width: 6),
                                      Text(
                                        'Penting: Kunci sk-xxxxx vs tp-xxxxx',
                                        style: GoogleFonts.inter(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                          color: AppColors.accent,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'Kunci "sk-xxxxx" (pay-as-you-go) boleh dibiarkan medan Base '
                                    'URL kosong (guna lalai). Kunci "tp-xxxxx" (Token Plan) WAJIB '
                                    'diisi dengan Base URL yang disalin daripada halaman Token '
                                    'Plan anda di Console MiMo AI — mencampur kunci dengan Base '
                                    'URL yang salah adalah punca biasa ralat "kunci tidak sah".',
                                    style: GoogleFonts.inter(fontSize: 11, color: AppColors.textMuted, height: 1.4),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton.icon(
                                    icon: const Icon(Icons.save_rounded),
                                    label: const Text('Simpan'),
                                    onPressed: () {
                                      context.read<SettingsBloc>().add(
                                            SaveApiConfig(
                                              apiKey: _apiKeyController.text,
                                              baseUrl: _baseUrlController.text,
                                            ),
                                          );
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Konfigurasi disimpan!')),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: OutlinedButton.icon(
                                    icon: isTesting
                                        ? const SizedBox(
                                            width: 16,
                                            height: 16,
                                            child: CircularProgressIndicator(strokeWidth: 2),
                                          )
                                        : const Icon(Icons.network_ping),
                                    label: Text(isTesting ? 'Menguji...' : 'Uji Sambungan'),
                                    onPressed: isTesting
                                        ? null
                                        : () {
                                            context.read<SettingsBloc>().add(TestApiConnection());
                                          },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      _buildSectionHeader('Danger Zone', Icons.report_problem_outlined, color: AppColors.error),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        borderColor: AppColors.error.withOpacity(0.3),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Padamkan semua profil suara, hasil, dan konfigurasi API dari peranti secara kekal.',
                                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                              ),
                            ),
                            const SizedBox(width: 16),
                            ElevatedButton(
                              onPressed: () => _confirmDeleteAll(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.error,
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              ),
                              child: const Text('Padam Semua'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, {Color color = AppColors.textPrimary}) {
    return Row(
      children: [
        Icon(icon, color: color == AppColors.textPrimary ? AppColors.accent : color, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w700, color: color, letterSpacing: 0.5),
        ),
      ],
    );
  }

  Widget _buildGlassCard({required Widget child, Color borderColor = AppColors.cardBorder}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: child,
    );
  }
}
