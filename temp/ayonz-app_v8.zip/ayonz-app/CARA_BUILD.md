# Cara Build Ayonz Jadi APK Android

Project ini sudah disiapkan dalam bentuk **Capacitor**, yaitu pembungkus
resmi yang mengubah web app (HTML/CSS/JS) jadi aplikasi Android asli.
Karena proses build APK butuh Android SDK yang berat, prosesnya harus
dijalankan di **komputer kamu sendiri**, bukan di sini.

## Yang harus disiapkan dulu di komputer kamu

1. **Node.js** (versi 18 ke atas) — unduh di https://nodejs.org
2. **Android Studio** — unduh di https://developer.android.com/studio
   (saat instalasi pertama, biarkan Android Studio mengunduh Android SDK-nya)
3. **Java JDK 17** (biasanya sudah ikut terpasang bersama Android Studio)

## Langkah build

1. Ekstrak ZIP ini, lalu buka folder hasil ekstrak di terminal/command prompt.

2. Install dependency:
   ```
   npm install
   ```

3. Tambahkan platform Android ke project:
   ```
   npx cap add android
   ```

4. Sinkronkan file web ke project Android:
   ```
   npx cap sync
   ```

5. Buka project di Android Studio:
   ```
   npx cap open android
   ```
   (Android Studio akan terbuka otomatis dengan project "Ayonz")

6. Di Android Studio, tunggu proses "Gradle Sync" selesai (di pojok kanan
   bawah ada progress bar). Ini bisa makan waktu beberapa menit di
   percobaan pertama.

7. Setelah selesai, klik menu:
   **Build → Build Bundle(s) / APK(s) → Build APK(s)**

8. Tunggu sampai muncul notifikasi "APK(s) generated successfully".
   Klik "locate" pada notifikasi itu untuk membuka folder APK-nya.
   Biasanya ada di:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

9. Salin file `app-debug.apk` itu ke HP Android kamu (lewat kabel USB,
   Google Drive, atau cara apa pun), lalu install seperti install APK biasa.
   (Kamu mungkin perlu mengizinkan "Install dari sumber tidak dikenal"
   di pengaturan HP.)

## Catatan tentang fitur

- **Auto-scroll & auto-clicker** di dalam aplikasi ini hanya bekerja pada
  konten yang ditampilkan *di dalam aplikasi Ayonz sendiri* (lewat area
  pratinjau / WebView), bukan pada aplikasi TikTok/Instagram asli yang
  terpisah di HP. Android tidak mengizinkan satu aplikasi mengontrol
  aplikasi lain secara langsung tanpa izin "Accessibility Service" khusus
  yang harus diaktifkan manual oleh pengguna di Pengaturan HP — ini
  di luar cakupan project sederhana ini.
- **Bookmarklet** (bagian 05 di app) hanya relevan untuk browser, jadi di
  versi APK ini bagian itu bisa diabaikan atau dihapus dari index.html.
- **Penerjemah** akan tetap butuh koneksi internet karena memanggil
  layanan terjemahan online.

## Mengganti ikon & nama aplikasi

- Nama aplikasi: edit `appName` di `capacitor.config.json`.
- Ikon aplikasi: ganti file-file di
  `android/app/src/main/res/mipmap-*/ic_launcher.png` setelah langkah
  `npx cap add android` dijalankan (atau gunakan menu
  **Image Asset Studio** di Android Studio: klik kanan folder `res` →
  New → Image Asset).
