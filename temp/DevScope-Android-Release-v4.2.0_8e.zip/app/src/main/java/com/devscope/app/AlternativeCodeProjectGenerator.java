package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;

/** Real Playwright/Puppeteer targets for languages that have strong alternatives to Selenium. */
public final class AlternativeCodeProjectGenerator {
    public static final String PYTHON_PLAYWRIGHT = "Python / Playwright";
    public static final String JS_PLAYWRIGHT = "JavaScript / Playwright";
    public static final String JS_PUPPETEER = "JavaScript / Puppeteer";
    public static final String TS_PLAYWRIGHT = "TypeScript / Playwright";
    public static final String TS_PUPPETEER = "TypeScript / Puppeteer";
    public static final String JAVA_PLAYWRIGHT = "Java / Playwright";
    public static final String CSHARP_PLAYWRIGHT = "C# (C+) / Playwright";

    private AlternativeCodeProjectGenerator() {}

    public static boolean supports(String target) {
        return PYTHON_PLAYWRIGHT.equals(target) || JS_PLAYWRIGHT.equals(target) || JS_PUPPETEER.equals(target)
                || TS_PLAYWRIGHT.equals(target) || TS_PUPPETEER.equals(target)
                || JAVA_PLAYWRIGHT.equals(target) || CSHARP_PLAYWRIGHT.equals(target);
    }

    public static CodeProjectGenerator.GeneratedProject generate(String target, JSONObject flow) throws Exception {
        JSONArray steps = flow.optJSONArray("steps");
        if (steps == null) throw new IllegalArgumentException("steps array is required");
        String ua = flow.optString("userAgent", "");
        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("flow.json", flow.toString(2));

        if (PYTHON_PLAYWRIGHT.equals(target)) {
            files.put("requirements.txt", "playwright==1.62.0\n");
            files.put("bot.py", pythonPlaywright(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "bot.py", ".py", "Playwright Chromium", files);
        }
        if (JS_PLAYWRIGHT.equals(target) || TS_PLAYWRIGHT.equals(target)) {
            boolean ts = TS_PLAYWRIGHT.equals(target);
            files.put("package.json", nodePackage(ts ? "tsx main.ts" : "node main.js", "playwright", "1.62.1", ts));
            if (ts) files.put("tsconfig.json", tsConfig());
            files.put(ts ? "main.ts" : "main.js", jsPlaywright(steps, ts, ua));
            return new CodeProjectGenerator.GeneratedProject(target, ts ? "main.ts" : "main.js", ts ? ".ts" : ".js", "Playwright Chromium", files);
        }
        if (JS_PUPPETEER.equals(target) || TS_PUPPETEER.equals(target)) {
            boolean ts = TS_PUPPETEER.equals(target);
            files.put("package.json", nodePackage(ts ? "tsx main.ts" : "node main.js", "puppeteer", "25.8.0", ts));
            if (ts) files.put("tsconfig.json", tsConfig());
            files.put(ts ? "main.ts" : "main.js", jsPuppeteer(steps, ts, ua));
            return new CodeProjectGenerator.GeneratedProject(target, ts ? "main.ts" : "main.js", ts ? ".ts" : ".js", "Puppeteer Chromium", files);
        }
        if (JAVA_PLAYWRIGHT.equals(target)) {
            files.put("pom.xml", javaPom());
            files.put("src/main/java/DevScopeGenerated.java", javaPlaywright(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "src/main/java/DevScopeGenerated.java", ".java", "Playwright Chromium", files);
        }
        if (CSHARP_PLAYWRIGHT.equals(target)) {
            files.put("DevScopeGenerated.csproj", csharpProject());
            files.put("Program.cs", csharpPlaywright(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "Program.cs", ".cs", "Playwright Chromium", files);
        }
        throw new IllegalArgumentException("Unknown alternative target: " + target);
    }

    private static String pythonPlaywright(JSONArray steps, String ua) {
        StringBuilder b = new StringBuilder();
        b.append("import os, re, time\nfrom playwright.sync_api import sync_playwright\n\n")
         .append("vars = {}\ndef resolve(v):\n    s=str(v)\n    return re.sub(r'\\{\\{([^}]+)\\}\\}', lambda m: vars.get(m.group(1), m.group(0)), s)\n\n")
         .append("with sync_playwright() as p:\n    browser=p.chromium.launch(headless=False)\n    context=browser.new_context(user_agent=").append(py(ua)).append(")\n    page=context.new_page()\n    try:\n");
        for (int i=0;i<steps.length();i++) emitPythonPw(b, steps.optJSONObject(i), i);
        b.append("        print('DEV//SCOPE PASS')\n    finally:\n        context.close()\n        browser.close()\n");
        return b.toString();
    }

    private static void emitPythonPw(StringBuilder b, JSONObject s, int i) {
        if (s == null) return;
        String t=s.optString("type",""); String p="        "; String sel=py(s.optString("selector",""));
        b.append(p).append("# step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open" -> b.append(p).append("page.goto(resolve(").append(py(s.optString("url",""))).append("))\n");
            case "back" -> b.append(p).append("page.go_back()\n");
            case "forward" -> b.append(p).append("page.go_forward()\n");
            case "reload" -> b.append(p).append("page.reload()\n");
            case "click" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.click()\n");
            case "input","content" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.fill(resolve(").append(secretPy(s,i)).append("))\n");
            case "select" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.select_option(value=resolve(").append(py(s.optString("value",""))).append("))\n");
            case "check" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.").append(s.optBoolean("checked",true)?"check()":"uncheck()").append("\n");
            case "submit" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e)=>e.requestSubmit?e.requestSubmit():e.submit()')\n");
            case "scroll" -> b.append(p).append("page.evaluate('(p)=>window.scrollTo(p.x,p.y)', {'x':").append(s.optInt("x",0)).append(",'y':").append(s.optInt("y",0)).append("})\n");
            case "focus" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.focus()\n");
            case "wait" -> b.append(p).append("page.wait_for_timeout(").append(Math.max(0,s.optLong("ms",1000))).append(")\n");
            case "waitFor" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.wait_for(state='attached', timeout=").append(timeoutMs(s)).append(")\n");
            case "waitUrl" -> b.append(p).append("_end=time.time()+").append(timeoutMs(s)/1000.0).append("\n").append(p).append("while resolve(").append(py(s.optString("contains",""))).append(") not in page.url:\n").append(p).append("    if time.time()>_end: raise TimeoutError('URL wait timed out')\n").append(p).append("    page.wait_for_timeout(200)\n");
            case "assertExists" -> b.append(p).append("assert page.locator(resolve(").append(sel).append(")).count()>0, 'missing selector'\n");
            case "assertText" -> b.append(p).append("assert resolve(").append(py(expectedText(s))).append(") in page.locator(resolve(").append(sel).append(")).first.inner_text(), 'text assertion failed'\n");
            case "assertUrl" -> b.append(p).append("assert resolve(").append(py(s.optString("contains",""))).append(") in page.url, 'URL assertion failed'\n");
            case "extractText" -> b.append(p).append("vars[").append(py(storeAs(s))).append("]=page.locator(resolve(").append(sel).append(")).first.inner_text()\n");
            case "extractValue" -> b.append(p).append("vars[").append(py(storeAs(s))).append("]=page.locator(resolve(").append(sel).append(")).first.input_value()\n");
            case "setText" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e,v)=>e.textContent=v', resolve(").append(py(s.optString("value",""))).append("))\n");
            case "setHtml" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e,v)=>e.innerHTML=v', resolve(").append(py(s.optString("value",""))).append("))\n");
            case "setAttr" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e,p)=>e.setAttribute(p.n,p.v)', {'n':").append(py(s.optString("name",""))).append(",'v':resolve(").append(py(s.optString("value",""))).append(")})\n");
            case "removeAttr" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e,n)=>e.removeAttribute(n)', ").append(py(s.optString("name",""))).append(")\n");
            case "setStyle" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e,p)=>e.style.setProperty(p.n,p.v)', {'n':").append(py(s.optString("name",""))).append(",'v':resolve(").append(py(s.optString("value",""))).append(")})\n");
            case "remove" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.evaluate('(e)=>e.remove()')\n");
            case "storageSet" -> b.append(p).append("page.evaluate('(p)=>window[p.s].setItem(p.k,p.v)', {'s':").append(py(storageName(s))).append(",'k':").append(py(s.optString("key",""))).append(",'v':resolve(").append(py(s.optString("value",""))).append(")})\n");
            case "storageRemove" -> b.append(p).append("page.evaluate('(p)=>window[p.s].removeItem(p.k)', {'s':").append(py(storageName(s))).append(",'k':").append(py(s.optString("key",""))).append("})\n");
            case "js" -> b.append(p).append("page.evaluate(resolve(").append(py(s.optString("code",s.optString("value","")))).append("))\n");
            case "dispatch" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.dispatch_event(").append(py(s.optString("event","change"))).append(")\n");
            case "fileInput" -> b.append(p).append("page.locator(resolve(").append(sel).append(")).first.set_input_files(os.environ[").append(py("DEVSCOPE_FILE_"+(i+1))).append("])\n");
            case "clearCookies" -> b.append(p).append("context.clear_cookies()\n");
            default -> throw new IllegalArgumentException("Playwright Python unsupported action: "+t);
        }
    }

    private static String jsPlaywright(JSONArray steps, boolean ts, String ua) {
        StringBuilder b=new StringBuilder("import { chromium } from 'playwright';\n\n")
                .append("const browser=await chromium.launch({headless:false});\nconst context=await browser.newContext({userAgent:").append(js(ua)).append("});\nconst page=await context.newPage();\nconst vars=new Map();\nconst resolve=(v").append(ts?": unknown":"").append(")=>String(v??'').replace(/\\{\\{([^}]+)\\}\\}/g,(_,k)=>vars.get(k)??`{{${k}}}`);\ntry {\n");
        for(int i=0;i<steps.length();i++) emitJsPw(b,steps.optJSONObject(i),i);
        b.append("  console.log('DEV//SCOPE PASS');\n} finally { await context.close(); await browser.close(); }\n");
        return b.toString();
    }

    private static void emitJsPw(StringBuilder b, JSONObject s, int i){
        if(s==null)return;String t=s.optString("type","");String p="  ";String sel=js(s.optString("selector",""));
        b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("await page.goto(resolve(").append(js(s.optString("url",""))).append("));\n");
            case "back"->b.append(p).append("await page.goBack();\n"); case "forward"->b.append(p).append("await page.goForward();\n"); case "reload"->b.append(p).append("await page.reload();\n");
            case "click"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().click();\n");
            case "input","content"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().fill(resolve(").append(secretJs(s,i)).append("));\n");
            case "select"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().selectOption(resolve(").append(js(s.optString("value",""))).append("));\n");
            case "check"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().").append(s.optBoolean("checked",true)?"check()":"uncheck()").append(";\n");
            case "submit"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate(e=>e.requestSubmit?e.requestSubmit():e.submit());\n");
            case "scroll"->b.append(p).append("await page.evaluate(p=>window.scrollTo(p.x,p.y),{x:").append(s.optInt("x",0)).append(",y:").append(s.optInt("y",0)).append("});\n");
            case "focus"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().focus();\n");
            case "wait"->b.append(p).append("await page.waitForTimeout(").append(Math.max(0,s.optLong("ms",1000))).append(");\n");
            case "waitFor"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().waitFor({state:'attached',timeout:").append(timeoutMs(s)).append("});\n");
            case "waitUrl"->b.append(p).append("{const end=Date.now()+").append(timeoutMs(s)).append(";while(!page.url().includes(resolve(").append(js(s.optString("contains",""))).append("))){if(Date.now()>end)throw new Error('URL wait timed out');await page.waitForTimeout(200);}}\n");
            case "assertExists"->b.append(p).append("if(await page.locator(resolve(").append(sel).append(")).count()===0)throw new Error('missing selector');\n");
            case "assertText"->b.append(p).append("if(!(await page.locator(resolve(").append(sel).append(")).first().innerText()).includes(resolve(").append(js(expectedText(s))).append(")))throw new Error('text assertion failed');\n");
            case "assertUrl"->b.append(p).append("if(!page.url().includes(resolve(").append(js(s.optString("contains",""))).append(")))throw new Error('URL assertion failed');\n");
            case "extractText"->b.append(p).append("vars.set(").append(js(storeAs(s))).append(",await page.locator(resolve(").append(sel).append(")).first().innerText());\n");
            case "extractValue"->b.append(p).append("vars.set(").append(js(storeAs(s))).append(",await page.locator(resolve(").append(sel).append(")).first().inputValue());\n");
            case "setText"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate((e,v)=>e.textContent=v,resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setHtml"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate((e,v)=>e.innerHTML=v,resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setAttr"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate((e,p)=>e.setAttribute(p.n,p.v),{n:").append(js(s.optString("name",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "removeAttr"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate((e,n)=>e.removeAttribute(n),").append(js(s.optString("name",""))).append(");\n");
            case "setStyle"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate((e,p)=>e.style.setProperty(p.n,p.v),{n:").append(js(s.optString("name",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "remove"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().evaluate(e=>e.remove());\n");
            case "storageSet"->b.append(p).append("await page.evaluate(p=>window[p.s].setItem(p.k,p.v),{s:").append(js(storageName(s))).append(",k:").append(js(s.optString("key",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "storageRemove"->b.append(p).append("await page.evaluate(p=>window[p.s].removeItem(p.k),{s:").append(js(storageName(s))).append(",k:").append(js(s.optString("key",""))).append("});\n");
            case "js"->b.append(p).append("await page.evaluate(resolve(").append(js(s.optString("code",s.optString("value","")))).append("));\n");
            case "dispatch"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().dispatchEvent(").append(js(s.optString("event","change"))).append(");\n");
            case "fileInput"->b.append(p).append("await page.locator(resolve(").append(sel).append(")).first().setInputFiles(process.env[").append(js("DEVSCOPE_FILE_"+(i+1))).append("]??(()=>{throw new Error('missing file env')})());\n");
            case "clearCookies"->b.append(p).append("await context.clearCookies();\n");
            default->throw new IllegalArgumentException("Playwright JS unsupported action: "+t);
        }
    }

    private static String jsPuppeteer(JSONArray steps, boolean ts, String ua){
        StringBuilder b=new StringBuilder("import puppeteer from 'puppeteer';\n\nconst browser=await puppeteer.launch({headless:false});\nconst page=await browser.newPage();\nawait page.setUserAgent(").append(js(ua)).append(");\nconst vars=new Map();\nconst resolve=(v").append(ts?": unknown":"").append(")=>String(v??'').replace(/\\{\\{([^}]+)\\}\\}/g,(_,k)=>vars.get(k)??`{{${k}}}`);\nconst waitEl=async(css").append(ts?": string":"").append(",ms=10000)=>{const e=await page.waitForSelector(resolve(css),{timeout:ms});if(!e)throw new Error('missing selector');return e;};\ntry {\n");
        for(int i=0;i<steps.length();i++) emitPuppeteer(b,steps.optJSONObject(i),i);
        b.append("  console.log('DEV//SCOPE PASS');\n} finally { await browser.close(); }\n");return b.toString();
    }

    private static void emitPuppeteer(StringBuilder b,JSONObject s,int i){
        if(s==null)return;String t=s.optString("type","");String p="  ";String sel=js(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("await page.goto(resolve(").append(js(s.optString("url",""))).append("),{waitUntil:'domcontentloaded'});\n");
            case "back"->b.append(p).append("await page.goBack();\n");case "forward"->b.append(p).append("await page.goForward();\n");case "reload"->b.append(p).append("await page.reload();\n");
            case "click"->b.append(p).append("await page.click(resolve(").append(sel).append("));\n");
            case "input","content"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,v)=>{e.value='';e.dispatchEvent(new Event('input',{bubbles:true}));e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));},resolve(").append(secretJs(s,i)).append("));\n");
            case "select"->b.append(p).append("await page.select(resolve(").append(sel).append("),resolve(").append(js(s.optString("value",""))).append("));\n");
            case "check"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,w)=>{if(e.checked!==w)e.click();},").append(s.optBoolean("checked",true)).append(");\n");
            case "submit"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),e=>e.requestSubmit?e.requestSubmit():e.submit());\n");
            case "scroll"->b.append(p).append("await page.evaluate(p=>window.scrollTo(p.x,p.y),{x:").append(s.optInt("x",0)).append(",y:").append(s.optInt("y",0)).append("});\n");
            case "focus"->b.append(p).append("await page.focus(resolve(").append(sel).append("));\n");
            case "wait"->b.append(p).append("await new Promise(r=>setTimeout(r,").append(Math.max(0,s.optLong("ms",1000))).append("));\n");
            case "waitFor"->b.append(p).append("await page.waitForSelector(resolve(").append(sel).append("),{timeout:").append(timeoutMs(s)).append("});\n");
            case "waitUrl"->b.append(p).append("{const end=Date.now()+").append(timeoutMs(s)).append(";while(!page.url().includes(resolve(").append(js(s.optString("contains",""))).append("))){if(Date.now()>end)throw new Error('URL wait timed out');await new Promise(r=>setTimeout(r,200));}}\n");
            case "assertExists"->b.append(p).append("if(!(await page.$(resolve(").append(sel).append("))))throw new Error('missing selector');\n");
            case "assertText"->b.append(p).append("if(!(await page.$eval(resolve(").append(sel).append("),e=>e.innerText||e.textContent||'')).includes(resolve(").append(js(expectedText(s))).append(")))throw new Error('text assertion failed');\n");
            case "assertUrl"->b.append(p).append("if(!page.url().includes(resolve(").append(js(s.optString("contains",""))).append(")))throw new Error('URL assertion failed');\n");
            case "extractText"->b.append(p).append("vars.set(").append(js(storeAs(s))).append(",await page.$eval(resolve(").append(sel).append("),e=>e.innerText||e.textContent||''));\n");
            case "extractValue"->b.append(p).append("vars.set(").append(js(storeAs(s))).append(",await page.$eval(resolve(").append(sel).append("),e=>String(e.value??'')));\n");
            case "setText"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,v)=>e.textContent=v,resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setHtml"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,v)=>e.innerHTML=v,resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setAttr"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,p)=>e.setAttribute(p.n,p.v),{n:").append(js(s.optString("name",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "removeAttr"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,n)=>e.removeAttribute(n),").append(js(s.optString("name",""))).append(");\n");
            case "setStyle"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,p)=>e.style.setProperty(p.n,p.v),{n:").append(js(s.optString("name",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "remove"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),e=>e.remove());\n");
            case "storageSet"->b.append(p).append("await page.evaluate(p=>window[p.s].setItem(p.k,p.v),{s:").append(js(storageName(s))).append(",k:").append(js(s.optString("key",""))).append(",v:resolve(").append(js(s.optString("value",""))).append(")});\n");
            case "storageRemove"->b.append(p).append("await page.evaluate(p=>window[p.s].removeItem(p.k),{s:").append(js(storageName(s))).append(",k:").append(js(s.optString("key",""))).append("});\n");
            case "js"->b.append(p).append("await page.evaluate(resolve(").append(js(s.optString("code",s.optString("value","")))).append("));\n");
            case "dispatch"->b.append(p).append("await page.$eval(resolve(").append(sel).append("),(e,n)=>e.dispatchEvent(new Event(n,{bubbles:true})),").append(js(s.optString("event","change"))).append(");\n");
            case "fileInput"->b.append(p).append("{const e=await waitEl(").append(sel).append(");await e.uploadFile(process.env[").append(js("DEVSCOPE_FILE_"+(i+1))).append("]??(()=>{throw new Error('missing file env')})());}\n");
            case "clearCookies"->b.append(p).append("{const cookies=await page.cookies();if(cookies.length)await page.deleteCookie(...cookies);}\n");
            default->throw new IllegalArgumentException("Puppeteer unsupported action: "+t);
        }
    }

    private static String javaPom(){
        return "<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\n<modelVersion>4.0.0</modelVersion><groupId>devscope</groupId><artifactId>generated</artifactId><version>1.0</version><properties><maven.compiler.source>17</maven.compiler.source><maven.compiler.target>17</maven.compiler.target></properties><dependencies><dependency><groupId>com.microsoft.playwright</groupId><artifactId>playwright</artifactId><version>1.62.0</version></dependency></dependencies></project>\n";
    }

    private static String javaPlaywright(JSONArray steps,String ua){
        StringBuilder b=new StringBuilder("import com.microsoft.playwright.*;\nimport java.nio.file.Paths;\nimport java.util.*;\n\npublic class DevScopeGenerated {\n static Map<String,String> vars=new HashMap<>(); static Page page; static BrowserContext context;\n static String r(String s){for(var e:vars.entrySet())s=s.replace(\"{{\"+e.getKey()+\"}}\",e.getValue());return s;}\n static Locator el(String css){return page.locator(r(css)).first();}\n public static void main(String[] a)throws Exception{try(Playwright pw=Playwright.create()){Browser browser=pw.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));context=browser.newContext(new Browser.NewContextOptions().setUserAgent(").append(j(ua)).append("));page=context.newPage();try{\n");
        for(int i=0;i<steps.length();i++)emitJavaPw(b,steps.optJSONObject(i),i);b.append(" System.out.println(\"DEV//SCOPE PASS\");}finally{context.close();browser.close();}}}\n}\n");return b.toString();
    }

    private static void emitJavaPw(StringBuilder b,JSONObject s,int i){
        if(s==null)return;String t=s.optString("type","");String p=" ";String sel=j(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("page.navigate(r(").append(j(s.optString("url",""))).append("));\n");case "back"->b.append(p).append("page.goBack();\n");case "forward"->b.append(p).append("page.goForward();\n");case "reload"->b.append(p).append("page.reload();\n");case "click"->b.append(p).append("el(").append(sel).append(").click();\n");
            case "input","content"->b.append(p).append("el(").append(sel).append(").fill(r(").append(secretJava(s,i)).append("));\n");case "select"->b.append(p).append("el(").append(sel).append(").selectOption(r(").append(j(s.optString("value",""))).append("));\n");case "check"->b.append(p).append("el(").append(sel).append(").").append(s.optBoolean("checked",true)?"check()":"uncheck()").append(";\n");case "submit"->b.append(p).append("el(").append(sel).append(").evaluate(\"e=>e.requestSubmit?e.requestSubmit():e.submit()\");\n");
            case "scroll"->b.append(p).append("page.evaluate(\"p=>window.scrollTo(p.x,p.y)\",Map.of(\"x\",").append(s.optInt("x",0)).append(",\"y\",").append(s.optInt("y",0)).append("));\n");case "focus"->b.append(p).append("el(").append(sel).append(").focus();\n");case "wait"->b.append(p).append("page.waitForTimeout(").append(Math.max(0,s.optLong("ms",1000))).append(");\n");case "waitFor"->b.append(p).append("el(").append(sel).append(").waitFor(new Locator.WaitForOptions().setTimeout(").append((double)timeoutMs(s)).append("));\n");
            case "waitUrl"->b.append(p).append("{long end=System.currentTimeMillis()+").append(timeoutMs(s)).append(";while(!page.url().contains(r(").append(j(s.optString("contains",""))).append("))){if(System.currentTimeMillis()>end)throw new RuntimeException(\"URL wait timed out\");page.waitForTimeout(200);}}\n");case "assertExists"->b.append(p).append("if(page.locator(r(").append(sel).append(")).count()==0)throw new RuntimeException(\"missing selector\");\n");case "assertText"->b.append(p).append("if(!el(").append(sel).append(").innerText().contains(r(").append(j(expectedText(s))).append(")))throw new RuntimeException(\"text assertion failed\");\n");case "assertUrl"->b.append(p).append("if(!page.url().contains(r(").append(j(s.optString("contains",""))).append(")))throw new RuntimeException(\"URL assertion failed\");\n");
            case "extractText"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",el(").append(sel).append(").innerText());\n");case "extractValue"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",el(").append(sel).append(").inputValue());\n");
            case "setText"->b.append(p).append("el(").append(sel).append(").evaluate(\"(e,v)=>e.textContent=v\",r(").append(j(s.optString("value",""))).append("));\n");case "setHtml"->b.append(p).append("el(").append(sel).append(").evaluate(\"(e,v)=>e.innerHTML=v\",r(").append(j(s.optString("value",""))).append("));\n");case "setAttr"->b.append(p).append("el(").append(sel).append(").evaluate(\"(e,p)=>e.setAttribute(p.n,p.v)\",Map.of(\"n\",").append(j(s.optString("name",""))).append(",\"v\",r(").append(j(s.optString("value",""))).append(")));\n");case "removeAttr"->b.append(p).append("el(").append(sel).append(").evaluate(\"(e,n)=>e.removeAttribute(n)\",").append(j(s.optString("name",""))).append(");\n");case "setStyle"->b.append(p).append("el(").append(sel).append(").evaluate(\"(e,p)=>e.style.setProperty(p.n,p.v)\",Map.of(\"n\",").append(j(s.optString("name",""))).append(",\"v\",r(").append(j(s.optString("value",""))).append(")));\n");case "remove"->b.append(p).append("el(").append(sel).append(").evaluate(\"e=>e.remove()\");\n");
            case "storageSet"->b.append(p).append("page.evaluate(\"p=>window[p.s].setItem(p.k,p.v)\",Map.of(\"s\",").append(j(storageName(s))).append(",\"k\",").append(j(s.optString("key",""))).append(",\"v\",r(").append(j(s.optString("value",""))).append(")));\n");case "storageRemove"->b.append(p).append("page.evaluate(\"p=>window[p.s].removeItem(p.k)\",Map.of(\"s\",").append(j(storageName(s))).append(",\"k\",").append(j(s.optString("key",""))).append("));\n");case "js"->b.append(p).append("page.evaluate(r(").append(j(s.optString("code",s.optString("value","")))).append("));\n");case "dispatch"->b.append(p).append("el(").append(sel).append(").dispatchEvent(").append(j(s.optString("event","change"))).append(");\n");case "fileInput"->b.append(p).append("el(").append(sel).append(").setInputFiles(Paths.get(Optional.ofNullable(System.getenv(").append(j("DEVSCOPE_FILE_"+(i+1))).append(")).orElseThrow()));\n");case "clearCookies"->b.append(p).append("context.clearCookies();\n");default->throw new IllegalArgumentException("Playwright Java unsupported action: "+t);
        }
    }

    private static String csharpProject(){return "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup><ItemGroup><PackageReference Include=\"Microsoft.Playwright\" Version=\"1.62.0\" /></ItemGroup></Project>\n";}

    private static String csharpPlaywright(JSONArray steps,String ua){
        StringBuilder b=new StringBuilder("using Microsoft.Playwright;\nusing System.Text.RegularExpressions;\n\nvar vars=new Dictionary<string,string>();\nstring R(string s)=>Regex.Replace(s,@\"\\{\\{([^}]+)\\}\\}\",m=>vars.TryGetValue(m.Groups[1].Value,out var v)?v:m.Value);\nusing var pw=await Playwright.CreateAsync();\nvar browser=await pw.Chromium.LaunchAsync(new(){Headless=false});\nvar context=await browser.NewContextAsync(new(){UserAgent=").append(cs(ua)).append("});\nvar page=await context.NewPageAsync();\ntry{\n");
        for(int i=0;i<steps.length();i++)emitCsPw(b,steps.optJSONObject(i),i);b.append(" Console.WriteLine(\"DEV//SCOPE PASS\");\n}finally{await context.CloseAsync();await browser.CloseAsync();}\n");return b.toString();
    }

    private static void emitCsPw(StringBuilder b,JSONObject s,int i){
        if(s==null)return;String t=s.optString("type","");String p=" ";String sel=cs(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("await page.GotoAsync(R(").append(cs(s.optString("url",""))).append("));\n");case "back"->b.append(p).append("await page.GoBackAsync();\n");case "forward"->b.append(p).append("await page.GoForwardAsync();\n");case "reload"->b.append(p).append("await page.ReloadAsync();\n");case "click"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.ClickAsync();\n");
            case "input","content"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.FillAsync(R(").append(secretCs(s,i)).append("));\n");case "select"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.SelectOptionAsync(R(").append(cs(s.optString("value",""))).append("));\n");case "check"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.").append(s.optBoolean("checked",true)?"CheckAsync()":"UncheckAsync()").append(";\n");case "submit"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"e=>e.requestSubmit?e.requestSubmit():e.submit()\");\n");
            case "scroll"->b.append(p).append("await page.EvaluateAsync(\"p=>window.scrollTo(p.x,p.y)\",new{x=").append(s.optInt("x",0)).append(",y=").append(s.optInt("y",0)).append("});\n");case "focus"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.FocusAsync();\n");case "wait"->b.append(p).append("await page.WaitForTimeoutAsync(").append(Math.max(0,s.optLong("ms",1000))).append(");\n");case "waitFor"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.WaitForAsync(new(){Timeout=").append((double)timeoutMs(s)).append("});\n");
            case "waitUrl"->b.append(p).append("{var end=DateTime.UtcNow.AddMilliseconds(").append(timeoutMs(s)).append(");while(!page.Url.Contains(R(").append(cs(s.optString("contains",""))).append("))){if(DateTime.UtcNow>end)throw new Exception(\"URL wait timed out\");await page.WaitForTimeoutAsync(200);}}\n");case "assertExists"->b.append(p).append("if(await page.Locator(R(").append(sel).append(")).CountAsync()==0)throw new Exception(\"missing selector\");\n");case "assertText"->b.append(p).append("if(!(await page.Locator(R(").append(sel).append(")).First.InnerTextAsync()).Contains(R(").append(cs(expectedText(s))).append(")))throw new Exception(\"text assertion failed\");\n");case "assertUrl"->b.append(p).append("if(!page.Url.Contains(R(").append(cs(s.optString("contains",""))).append(")))throw new Exception(\"URL assertion failed\");\n");
            case "extractText"->b.append(p).append("vars[").append(cs(storeAs(s))).append("]=await page.Locator(R(").append(sel).append(")).First.InnerTextAsync();\n");case "extractValue"->b.append(p).append("vars[").append(cs(storeAs(s))).append("]=await page.Locator(R(").append(sel).append(")).First.InputValueAsync();\n");
            case "setText"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"(e,v)=>e.textContent=v\",R(").append(cs(s.optString("value",""))).append("));\n");case "setHtml"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"(e,v)=>e.innerHTML=v\",R(").append(cs(s.optString("value",""))).append("));\n");case "setAttr"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"(e,p)=>e.setAttribute(p.n,p.v)\",new{n=").append(cs(s.optString("name",""))).append(",v=R(").append(cs(s.optString("value",""))).append(")});\n");case "removeAttr"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"(e,n)=>e.removeAttribute(n)\",").append(cs(s.optString("name",""))).append(");\n");case "setStyle"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"(e,p)=>e.style.setProperty(p.n,p.v)\",new{n=").append(cs(s.optString("name",""))).append(",v=R(").append(cs(s.optString("value",""))).append(")});\n");case "remove"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.EvaluateAsync(\"e=>e.remove()\");\n");
            case "storageSet"->b.append(p).append("await page.EvaluateAsync(\"p=>window[p.s].setItem(p.k,p.v)\",new{s=").append(cs(storageName(s))).append(",k=").append(cs(s.optString("key",""))).append(",v=R(").append(cs(s.optString("value",""))).append(")});\n");case "storageRemove"->b.append(p).append("await page.EvaluateAsync(\"p=>window[p.s].removeItem(p.k)\",new{s=").append(cs(storageName(s))).append(",k=").append(cs(s.optString("key",""))).append("});\n");case "js"->b.append(p).append("await page.EvaluateAsync(R(").append(cs(s.optString("code",s.optString("value","")))).append("));\n");case "dispatch"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.DispatchEventAsync(").append(cs(s.optString("event","change"))).append(");\n");case "fileInput"->b.append(p).append("await page.Locator(R(").append(sel).append(")).First.SetInputFilesAsync(Environment.GetEnvironmentVariable(").append(cs("DEVSCOPE_FILE_"+(i+1))).append(")??throw new Exception(\"missing file env\"));\n");case "clearCookies"->b.append(p).append("await context.ClearCookiesAsync();\n");default->throw new IllegalArgumentException("Playwright C# unsupported action: "+t);
        }
    }

    private static String nodePackage(String command,String dependency,String version,boolean ts){
        String dev=ts?",\n    \"tsx\": \"^4.20.0\",\n    \"typescript\": \"^5.9.0\"":"";
        return "{\n  \"name\": \"devscope-generated\",\n  \"private\": true,\n  \"type\": \"module\",\n  \"scripts\": {\"test\": \""+command+"\"},\n  \"dependencies\": {\""+dependency+"\": \""+version+"\"}"+(ts?",\n  \"devDependencies\": {\"tsx\": \"^4.20.0\", \"typescript\": \"^5.9.0\"}":"")+"\n}\n";
    }
    private static String tsConfig(){return "{\n  \"compilerOptions\": {\"target\": \"ES2022\", \"module\": \"NodeNext\", \"moduleResolution\": \"NodeNext\", \"strict\": true, \"skipLibCheck\": true}\n}\n";}
    private static long timeoutMs(JSONObject s){return s.optLong("timeoutMs",s.optLong("timeout",10000));}
    private static String expectedText(JSONObject s){return s.optString("contains",s.optString("text",""));}
    private static String storeAs(JSONObject s){String v=s.optString("storeAs",s.optString("var","value"));return v==null||v.trim().isEmpty()?"value":v.trim();}
    private static String storageName(JSONObject s){String raw=s.optString("store",s.optString("storage",s.optString("area","local")));return ("session".equals(raw)||"sessionStorage".equals(raw))?"sessionStorage":"localStorage";}
    private static String secretPy(JSONObject s,int i){return s.optBoolean("secret",false)?"os.environ["+py("DEVSCOPE_SECRET_"+(i+1))+"]":py(s.optString("value",""));}
    private static String secretJs(JSONObject s,int i){return s.optBoolean("secret",false)?"(process.env["+js("DEVSCOPE_SECRET_"+(i+1))+"]??(()=>{throw new Error('missing secret env')})())":js(s.optString("value",""));}
    private static String secretJava(JSONObject s,int i){return s.optBoolean("secret",false)?"Optional.ofNullable(System.getenv("+j("DEVSCOPE_SECRET_"+(i+1))+")).orElseThrow()":j(s.optString("value",""));}
    private static String secretCs(JSONObject s,int i){return s.optBoolean("secret",false)?"Environment.GetEnvironmentVariable("+cs("DEVSCOPE_SECRET_"+(i+1))+")??throw new Exception(\"missing secret env\")":cs(s.optString("value",""));}
    private static String py(String s){return "'"+safe(s).replace("'","\\'")+"'";}
    private static String js(String s){return JSONObject.quote(s==null?"":s);}
    private static String j(String s){return JSONObject.quote(s==null?"":s);}
    private static String cs(String s){return "\""+safe(s).replace("\"","\\\"")+"\"";}
    private static String safe(String s){return (s==null?"":s).replace("\\","\\\\").replace("\r","\\r").replace("\n","\\n");}
}
