package com.devscope.app;

import org.json.JSONObject;

import java.util.Locale;

/** Detects DevScope Action Script or common generated automation source without guessing success. */
public final class ScriptLanguageDetector {
    public enum Kind { ACTION_SCRIPT, WEBVIEW_JAVASCRIPT, EXTERNAL_SOURCE, UNKNOWN }

    public static final class Result {
        public final Kind kind;
        public final String language;
        public final String method;
        public final String extension;
        public final int confidence;

        Result(Kind kind, String language, String method, String extension, int confidence) {
            this.kind = kind; this.language = language; this.method = method; this.extension = extension; this.confidence = confidence;
        }
        public String label() { return language + (method.isEmpty() ? "" : " / " + method); }
    }

    private ScriptLanguageDetector() {}

    public static Result detect(String source, String fileName) {
        String s = source == null ? "" : source.trim();
        String n = fileName == null ? "" : fileName.toLowerCase(Locale.US);
        if (s.isEmpty()) return new Result(Kind.UNKNOWN, "Unknown", "", "", 0);

        if (s.startsWith("{")) {
            try {
                JSONObject o = new JSONObject(s);
                if (o.optJSONArray("steps") != null || o.optString("engine", "").startsWith("devscope.action"))
                    return new Result(Kind.ACTION_SCRIPT, "DevScope Action", "Native WebView Runner", ".json", 100);
            } catch (Exception ignored) {}
            String compact = s.replace(" ", "").replace("\n", "").replace("\r", "").replace("\t", "");
            if (compact.contains("\"steps\":[") || compact.contains("\"engine\":\"devscope.action"))
                return new Result(Kind.ACTION_SCRIPT, "DevScope Action", "Native WebView Runner", ".json", 98);
        }

        String l = s.toLowerCase(Locale.US);
        if (n.endsWith(".py") || l.contains("from playwright") || l.contains("import selenium") || l.contains("from pyppeteer")) {
            String m = l.contains("pyppeteer") ? "Pyppeteer" : (l.contains("playwright") ? "Playwright" : (l.contains("selenium") ? "Selenium WebDriver" : "Python"));
            return new Result(Kind.EXTERNAL_SOURCE, "Python", m, ".py", 96);
        }
        boolean cypressSignature = n.endsWith(".cy.js") || n.endsWith(".cy.ts") || l.contains("cypress") || l.contains("cy.visit(") || l.contains("cy.get(");
        boolean wdioSignature = l.contains("webdriverio");
        boolean playwrightJsSignature = l.contains("from 'playwright'") || l.contains("from \"playwright\"") || l.contains("require('playwright") || l.contains("require(\"playwright");
        boolean puppeteerSignature = l.contains("puppeteer");
        boolean seleniumJsSignature = l.contains("selenium-webdriver");

        if (n.endsWith(".ts") || wdioSignature || playwrightJsSignature || puppeteerSignature || cypressSignature) {
            boolean ts = n.endsWith(".ts") || n.endsWith(".cy.ts") || l.contains(": record<") || l.contains("interface ");
            String m = wdioSignature ? "WebdriverIO" : (cypressSignature ? "Cypress" : (puppeteerSignature ? "Puppeteer" : (seleniumJsSignature ? "Selenium WebDriver" : "Playwright")));
            return new Result(Kind.EXTERNAL_SOURCE, ts ? "TypeScript" : "JavaScript", m, ts ? ".ts" : ".js", 93);
        }
        if (seleniumJsSignature)
            return new Result(Kind.EXTERNAL_SOURCE, "JavaScript", "Selenium WebDriver", ".js", 94);
        if (looksLikeJavascript(s))
            return new Result(Kind.WEBVIEW_JAVASCRIPT, "JavaScript", "Current WebView", ".js", n.endsWith(".js") ? 88 : 75);
        if (n.endsWith(".js"))
            return new Result(Kind.EXTERNAL_SOURCE, "JavaScript", "Node.js", ".js", 80);
        if (n.endsWith(".kt") || l.contains("fun main(") || l.contains("kotlin(")) {
            String m = l.contains("selenide") ? "Selenide" : "Selenium WebDriver";
            return new Result(Kind.EXTERNAL_SOURCE, "Kotlin", m, ".kt", n.endsWith(".kt") ? 97 : 85);
        }
        if (n.endsWith(".java") || l.contains("org.openqa.selenium") || l.contains("com.microsoft.playwright") || l.contains("com.codeborne.selenide")) {
            String m = l.contains("selenide") ? "Selenide" : (l.contains("microsoft.playwright") ? "Playwright" : "Selenium WebDriver");
            return new Result(Kind.EXTERNAL_SOURCE, "Java", m, ".java", 96);
        }
        if (n.endsWith(".cs") || l.contains("using microsoft.playwright") || l.contains("openqa.selenium")) {
            String m = l.contains("microsoft.playwright") ? "Playwright" : "Selenium WebDriver";
            return new Result(Kind.EXTERNAL_SOURCE, "C#", m, ".cs", 96);
        }
        if (n.endsWith(".go") || l.contains("github.com/chromedp/chromedp") || l.contains("github.com/go-rod/rod")) {
            String m = l.contains("go-rod/rod") ? "Rod" : "chromedp";
            return new Result(Kind.EXTERNAL_SOURCE, "Go", m, ".go", 96);
        }
        if (n.endsWith(".rs") || l.contains("thirtyfour") || l.contains("fantoccini")) {
            String m = l.contains("fantoccini") ? "Fantoccini" : "thirtyfour WebDriver";
            return new Result(Kind.EXTERNAL_SOURCE, "Rust", m, ".rs", 95);
        }
        if (n.endsWith(".rb") || l.contains("capybara") || l.contains("selenium-webdriver")) {
            String m = l.contains("capybara") ? "Capybara" : "Selenium WebDriver";
            return new Result(Kind.EXTERNAL_SOURCE, "Ruby", m, ".rb", 90);
        }
        if (n.endsWith(".php") || l.startsWith("<?php") || l.contains("symfony\\component\\panther") || l.contains("facebook\\webdriver")) {
            String m = l.contains("panther") ? "Symfony Panther" : "php-webdriver";
            return new Result(Kind.EXTERNAL_SOURCE, "PHP", m, ".php", 94);
        }
        if (n.endsWith(".cpp") || l.contains("#include <iostream>") || l.contains("std::")) return new Result(Kind.EXTERNAL_SOURCE, "C++", "Native/W3C", ".cpp", 82);
        if (n.endsWith(".c") || l.contains("#include <stdio.h>") || l.contains("curl/curl.h")) return new Result(Kind.EXTERNAL_SOURCE, "C", "Native/W3C", ".c", 82);

        return new Result(Kind.UNKNOWN, "Unknown", "", extensionFromName(n), 20);
    }

    private static boolean looksLikeJavascript(String s) {
        String l=s.toLowerCase(Locale.US);
        return l.contains("document.") || l.contains("window.") || l.contains("queryselector") || l.startsWith("(()=>") || l.startsWith("function ") || l.startsWith("const ") || l.startsWith("let ");
    }

    private static String extensionFromName(String n) {
        int i=n.lastIndexOf('.'); return i>=0 ? n.substring(i) : "";
    }
}
