package com.devscope.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.print.PrintManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.Cursor;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.URLUtil;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class MainActivity extends Activity {
    private static final int REQ_EXPORT_TEXT = 2001;
    private static final int REQ_SAVE_MHTML = 2002;
    private static final int REQ_FILE_CHOOSER = 2003;
    private static final int REQ_IMPORT_SCRIPT = 2004;
    private static final int REQ_SCREENSHOT = 2005;
    private static final int REQ_EXPORT_CODE = 2006;
    private static final int REQ_EXPORT_CODE_PROJECT = 2007;
    private static final int REQ_EXPORT_BOOTSTRAP = 2008;

    private static final String TAB_FLOW = "TRACE";
    private static final String TAB_DOM = "DOM";
    private static final String TAB_NETWORK = "NETWORK";
    private static final String TAB_CONSOLE = "CONSOLE";
    private static final String TAB_STORAGE = "STORAGE";
    private static final String TAB_SOURCE = "SOURCE";
    private static final String TAB_RUNTIME = "RUNTIME";
    private static final String TAB_SCRIPT = "AUTOMATE";
    private static final String TAB_CODE = "CODEGEN";
    private static final String TAB_DEPS = "DEPS";
    private static final String TAB_DOWNLOADS = "DOWNLOADS";

    private WebView webView;
    private View rootContainer;
    private EditText urlInput;
    private EditText runtimeInput;
    private EditText scriptEditor;
    private EditText codeEditor;
    private Spinner codeLanguageSpinner;
    private TextView pageTitleText;
    private TextView stateText;
    private TextView domMetricText;
    private TextView netMetricText;
    private TextView consoleMetricText;
    private TextView resourceMetricText;
    private TextView panelTitleText;
    private TextView outputText;
    private TextView footerText;
    private ScrollView outputScroll;
    private ScrollView flowScroll;
    private FlowTimelineView flowView;
    private LinearLayout runtimeBar;
    private HorizontalScrollView automationBar;
    private HorizontalScrollView codegenBar;
    private HorizontalScrollView dependencyBar;
    private LinearLayout downloadBar;
    private FrameLayout browserContainer;
    private LinearLayout toolsContainer;

    private Button debugButton;
    private Button splitButton;
    private Button pickButton;
    private Button mhtmlButton;
    private Button screenshotButton;
    private Button pdfButton;
    private Button scriptRecordButton;
    private Button scriptRunButton;
    private Button scriptStopButton;
    private Button codeGenerateButton;
    private Button codeMethodButton;
    private Button codeExportButton;
    private Button codeProjectButton;
    private Button dependencyAnalyzeButton;
    private Button dependencyVerifyButton;
    private Button dependencyExportButton;
    private Button[] tabButtons;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TelemetryStore telemetry = new TelemetryStore();
    private InspectorEngine inspector;
    private AutomationEngine automation;
    private DownloadManager downloadManager;
    private SharedPreferences prefs;

    private String currentTab = TAB_FLOW;
    private JSONObject lastPerformance;
    private StringBuilder runtimeHistory = new StringBuilder();
    private final JSONArray recordedSteps = new JSONArray();
    private final HashMap<String, String> runnerVars = new HashMap<>();
    private boolean recording = false;
    private boolean runnerActive = false;
    private boolean runnerNavigationPending = false;
    private int runnerIndex = 0;
    private int runnerToken = 0;
    private JSONArray runnerSteps = new JSONArray();
    private long waitForDeadline = 0L;
    private long lastDownloadId = -1L;
    private boolean webDebugEnabled = false;
    private int splitMode = 0;
    private boolean keyboardVisible = false;
    private boolean keyboardEditorMode = false;
    private int splitModeBeforeKeyboard = 0;
    private String footerBeforeKeyboard = "";
    private boolean telemetryRefreshPending = false;
    private int pickerGeneration = 0;
    private ValueCallback<Uri[]> fileChooserCallback;
    private Uri pendingMhtmlUri;
    private Uri pendingExportUri;
    private Uri pendingScreenshotUri;
    private CodeProjectGenerator.GeneratedProject generatedCodeProject;
    private DependencyBootstrapEngine.Plan dependencyPlan;
    private String selectedCodeMethod = CodegenCatalog.PLAYWRIGHT;
    private String importedScriptName = "";
    private String lastCodeLanguage = null;

    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private final SimpleDateFormat fileTime = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("devscope", MODE_PRIVATE);
        bindViews();
        inspector = new InspectorEngine(webView);
        automation = new AutomationEngine(webView);
        downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        configureWebView();
        configureServiceWorkerCapture();
        configureDownloadHandling();
        wireActions();
        configureKeyboardAwareEditors();
        scriptEditor.setText(prefs.getString("saved_script", defaultAutomationScript()));
        configureCodegen();
        selectTab(TAB_FLOW);
        restoreSession();
    }

    private void bindViews() {
        rootContainer = findViewById(R.id.rootContainer);
        webView = findViewById(R.id.webView);
        urlInput = findViewById(R.id.urlInput);
        runtimeInput = findViewById(R.id.runtimeInput);
        scriptEditor = findViewById(R.id.scriptEditor);
        codeEditor = findViewById(R.id.codeEditor);
        codeLanguageSpinner = findViewById(R.id.codeLanguageSpinner);
        pageTitleText = findViewById(R.id.pageTitleText);
        stateText = findViewById(R.id.stateText);
        domMetricText = findViewById(R.id.domMetricText);
        netMetricText = findViewById(R.id.netMetricText);
        consoleMetricText = findViewById(R.id.consoleMetricText);
        resourceMetricText = findViewById(R.id.resourceMetricText);
        panelTitleText = findViewById(R.id.panelTitleText);
        outputText = findViewById(R.id.outputText);
        footerText = findViewById(R.id.footerText);
        outputScroll = findViewById(R.id.outputScroll);
        flowScroll = findViewById(R.id.flowScroll);
        flowView = findViewById(R.id.flowView);
        runtimeBar = findViewById(R.id.runtimeBar);
        automationBar = findViewById(R.id.automationBar);
        codegenBar = findViewById(R.id.codegenBar);
        dependencyBar = findViewById(R.id.dependencyBar);
        downloadBar = findViewById(R.id.downloadBar);
        browserContainer = findViewById(R.id.browserContainer);
        toolsContainer = findViewById(R.id.toolsContainer);
        debugButton = findViewById(R.id.debugButton);
        splitButton = findViewById(R.id.splitButton);
        pickButton = findViewById(R.id.pickButton);
        mhtmlButton = findViewById(R.id.mhtmlButton);
        screenshotButton = findViewById(R.id.screenshotButton);
        pdfButton = findViewById(R.id.pdfButton);
        scriptRecordButton = findViewById(R.id.scriptRecordButton);
        scriptRunButton = findViewById(R.id.scriptRunButton);
        scriptStopButton = findViewById(R.id.scriptStopButton);
        codeGenerateButton = findViewById(R.id.codeGenerateButton);
        codeMethodButton = findViewById(R.id.codeMethodButton);
        codeExportButton = findViewById(R.id.codeExportButton);
        codeProjectButton = findViewById(R.id.codeProjectButton);
        dependencyAnalyzeButton = findViewById(R.id.dependencyAnalyzeButton);
        dependencyVerifyButton = findViewById(R.id.dependencyVerifyButton);
        dependencyExportButton = findViewById(R.id.dependencyExportButton);
        tabButtons = new Button[]{
                findViewById(R.id.tabFlow), findViewById(R.id.tabDom), findViewById(R.id.tabNetwork),
                findViewById(R.id.tabConsole), findViewById(R.id.tabStorage), findViewById(R.id.tabSource),
                findViewById(R.id.tabRuntime), findViewById(R.id.tabScript), findViewById(R.id.tabCode), findViewById(R.id.tabDeps), findViewById(R.id.tabDownloads)
        };
    }

    private void configureCodegen() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.code_spinner_item, CodegenCatalog.LANGUAGES);
        adapter.setDropDownViewResource(R.layout.code_spinner_item);
        codeLanguageSpinner.setAdapter(adapter);

        String savedLanguage = prefs.getString("code_language", "Python");
        int savedIndex = CodegenCatalog.languageIndex(savedLanguage);
        codeLanguageSpinner.setSelection(savedIndex);
        selectedCodeMethod = savedMethodFor(CodegenCatalog.LANGUAGES[savedIndex]);
        updateCodeMethodButton();

        codeLanguageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String language = selectedCodeLanguage();
                boolean languageChanged = lastCodeLanguage != null && !lastCodeLanguage.equals(language);
                lastCodeLanguage = language;
                selectedCodeMethod = savedMethodFor(language);
                updateCodeMethodButton();
                generatedCodeProject = null;
                dependencyPlan = null;
                prefs.edit().putString("code_language", language).apply();
                if (languageChanged && CodegenCatalog.methodsFor(language).length > 1) {
                    handler.post(() -> showCodeMethodDialog(language));
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        lastCodeLanguage = CodegenCatalog.LANGUAGES[savedIndex];
        codeEditor.setText("// CODEGEN READY\n// Current WebView URL is injected automatically when the flow has no OPEN step.\n// Choose a language; if multiple real engines exist, DevScope will ask which method to use.\n// PROJECT ZIP includes source + manifest + flow + metadata + dependency bootstrap files.");
    }

    private String selectedCodeLanguage() {
        Object selected = codeLanguageSpinner.getSelectedItem();
        return selected == null ? "Python" : selected.toString();
    }

    private String selectedCodeTarget() {
        return CodegenCatalog.targetFor(selectedCodeLanguage(), selectedCodeMethod);
    }

    private String savedMethodFor(String language) {
        String recommended = CodegenCatalog.recommended(language);
        String saved = prefs.getString("code_method_" + language, recommended);
        for (String method : CodegenCatalog.methodsFor(language)) if (method.equals(saved)) return saved;
        return recommended;
    }

    private void updateCodeMethodButton() {
        if (codeMethodButton == null) return;
        String label = selectedCodeMethod == null ? "METHOD" : selectedCodeMethod.toUpperCase(Locale.US);
        if (label.length() > 18) label = label.substring(0, 18);
        codeMethodButton.setText(label);
    }

    private void showCodeMethodDialog(String language) {
        String[] methods = CodegenCatalog.methodsFor(language);
        if (methods.length <= 1) {
            selectedCodeMethod = methods[0];
            prefs.edit().putString("code_method_" + language, selectedCodeMethod).apply();
            updateCodeMethodButton();
            return;
        }
        String[] labels = new String[methods.length];
        for (int i = 0; i < methods.length; i++) {
            labels[i] = (i == 0 ? "★ " : "") + methods[i] + "\n" + CodegenCatalog.methodDescription(language, methods[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle("METHOD // " + language)
                .setItems(labels, (dialog, which) -> {
                    selectedCodeMethod = methods[which];
                    prefs.edit().putString("code_language", language)
                            .putString("code_method_" + language, selectedCodeMethod).apply();
                    generatedCodeProject = null;
                    dependencyPlan = null;
                    updateCodeMethodButton();
                    footerText.setText("CODEGEN // " + language + " // " + selectedCodeMethod + " // URL+UA from live WebView");
                    toast("Method: " + selectedCodeMethod);
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private boolean generateCodeFromActionScript() {
        try {
            JSONObject root = new JSONObject(scriptEditor.getText() == null ? "" : scriptEditor.getText().toString());
            JSONArray steps = root.optJSONArray("steps");
            if (steps == null) throw new Exception("steps array is required");
            String language = selectedCodeLanguage();
            String method = selectedCodeMethod;
            String target = selectedCodeTarget();
            String liveUrl = webView.getUrl();
            String liveUa = webView.getSettings().getUserAgentString();
            generatedCodeProject = CodegenFacade.generate(language, method, root, liveUrl, liveUa);
            dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
            DependencyBootstrapEngine.verifyBundle(generatedCodeProject, dependencyPlan);
            codeEditor.setText(generatedCodeProject.mainSource());
            codeEditor.setSelection(0);
            prefs.edit().putString("code_language", language).putString("code_method_" + language, method).apply();
            telemetry.addFlow("CODEGEN", target + " // " + steps.length() + " recorded steps // " + generatedCodeProject.files.size() + " files", liveUrl);
            selectTab(TAB_CODE);
            footerText.setText("CODEGEN // " + language + " // " + method + " // " + safeUrl(liveUrl) + " // files=" + generatedCodeProject.files.size());
            return true;
        } catch (Exception e) {
            generatedCodeProject = null;
            dependencyPlan = null;
            toast("Code generation gagal: " + e.getMessage());
            if (TAB_CODE.equals(currentTab)) {
                codeEditor.setText("// GENERATION BLOCKED\n// " + String.valueOf(e.getMessage()).replace("\n", "\n// "));
            }
            return false;
        }
    }

    private boolean ensureGeneratedProject() {
        String target = selectedCodeTarget();
        if (generatedCodeProject == null || !target.equals(generatedCodeProject.target)) return generateCodeFromActionScript();
        return true;
    }

    private void renderCodegen() {
        if (generatedCodeProject == null) {
            if (codeEditor.getText() == null || codeEditor.getText().length() == 0) {
                codeEditor.setText("// CODEGEN READY\n// Language: " + selectedCodeLanguage() + "\n// Method: " + selectedCodeMethod + "\n// Live URL and WebView User-Agent will be injected automatically on GENERATE.");
            }
            footerText.setText("CODEGEN // " + selectedCodeLanguage() + " // " + selectedCodeMethod + " // GENERATE // full PROJECT ZIP");
        } else {
            footerText.setText("CODEGEN // " + generatedCodeProject.target + " // main=" + generatedCodeProject.mainFile + " // files=" + generatedCodeProject.files.size());
        }
    }

    private void copyGeneratedCode() {
        if (!ensureGeneratedProject()) return;
        String text = codeEditor.getText() == null ? "" : codeEditor.getText().toString();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("DevScope generated code", text));
        toast("Generated code copied: " + text.length() + " chars");
    }

    private void requestExportGeneratedCode() {
        if (!ensureGeneratedProject()) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        String exportName = generatedCodeProject.mainFile == null ? "generated" + generatedCodeProject.extension : generatedCodeProject.mainFile.replace('\\', '/');
        int slash = exportName.lastIndexOf('/');
        if (slash >= 0) exportName = exportName.substring(slash + 1);
        intent.putExtra(Intent.EXTRA_TITLE, exportName);
        startActivityForResult(intent, REQ_EXPORT_CODE);
    }

    private void requestExportGeneratedProject() {
        if (!ensureGeneratedProject()) return;
        try {
            if (dependencyPlan == null) dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
            DependencyBootstrapEngine.verifyBundle(generatedCodeProject, dependencyPlan);
        } catch (Exception e) {
            toast("Project bundle tidak lengkap: " + e.getMessage());
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, "devscope-" + targetSlug(generatedCodeProject.target) + "-project-" + fileTime.format(new Date()) + ".zip");
        startActivityForResult(intent, REQ_EXPORT_CODE_PROJECT);
    }

    private void exportGeneratedCodeTo(Uri uri) {
        if (!ensureGeneratedProject()) return;
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new Exception("Destination stream unavailable");
            byte[] bytes = (codeEditor.getText() == null ? "" : codeEditor.getText().toString()).getBytes(java.nio.charset.StandardCharsets.UTF_8);
            out.write(bytes);
            out.flush();
            telemetry.addFlow("CODE_EXPORT", generatedCodeProject.target + " // " + bytes.length + " bytes", webView.getUrl());
            toast("Source code exported.");
        } catch (Exception e) {
            toast("Code export error: " + e.getMessage());
        }
    }

    private void exportGeneratedProjectTo(Uri uri) {
        if (!ensureGeneratedProject()) return;
        try (OutputStream raw = getContentResolver().openOutputStream(uri);
             ZipOutputStream zip = raw == null ? null : new ZipOutputStream(raw)) {
            if (zip == null) throw new Exception("Destination stream unavailable");
            for (Map.Entry<String, String> entry : generatedCodeProject.files.entrySet()) {
                String path = entry.getKey().replace('\\', '/');
                while (path.startsWith("/")) path = path.substring(1);
                if (path.contains("../")) throw new Exception("Unsafe project path: " + path);
                String content = entry.getKey().equals(generatedCodeProject.mainFile)
                        ? (codeEditor.getText() == null ? "" : codeEditor.getText().toString())
                        : entry.getValue();
                ZipEntry ze = new ZipEntry(path);
                zip.putNextEntry(ze);
                byte[] bytes = content.getBytes(java.nio.charset.StandardCharsets.UTF_8);
                zip.write(bytes);
                zip.closeEntry();
            }
            zip.finish();
            telemetry.addFlow("CODE_PROJECT_ZIP", generatedCodeProject.target + " // " + generatedCodeProject.files.size() + " files", webView.getUrl());
            toast("Full project ZIP exported: " + generatedCodeProject.files.size() + " files + manifests/bootstrap");
        } catch (Exception e) {
            toast("Project ZIP export error: " + e.getMessage());
        }
    }

    private String targetSlug(String target) {
        return target.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webDebugEnabled = prefs.getBoolean("web_debug", false);
        WebView.setWebContentsDebuggingEnabled(webDebugEnabled);
        updateDebugButton();

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                String message = consoleMessage == null || consoleMessage.message() == null ? "" : consoleMessage.message();
                if (message.startsWith("__DEVSCOPE_REC__")) {
                    if (recording) {
                        try {
                            JSONObject step = new JSONObject(message.substring("__DEVSCOPE_REC__".length()));
                            appendRecordedStep(step);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                TelemetryStore.ConsoleEntry entry = telemetry.addConsole(consoleMessage);
                if (!"LOG".equals(entry.level) || currentTab.equals(TAB_CONSOLE)) {
                    telemetry.addFlow("CONSOLE_" + entry.level, clip(entry.message, 140), entry.source);
                }
                scheduleTelemetryRefresh();
                return true;
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    setState("LOAD " + newProgress + "%", Color.rgb(34, 211, 238));
                    footerText.setText("LOADING // " + newProgress + "% // " + safeUrl(view.getUrl()));
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                pageTitleText.setText((title == null || title.isEmpty()) ? "untitled document" : title);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    toast("File picker tidak tersedia: " + e.getMessage());
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                urlInput.setText(url == null ? "" : url);
                telemetry.addFlow("NAV_START", hostOf(url), url);
                if (runnerActive) {
                    runnerNavigationPending = true;
                    runnerToken++;
                }
                setState("LOADING", Color.rgb(139, 92, 246));
                scheduleTelemetryRefresh();
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                telemetry.addFlow("NAV_COMMIT", hostOf(url), url);
                scheduleTelemetryRefresh();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                if (url != null) {
                    urlInput.setText(url);
                    prefs.edit().putString("last_url", url).apply();
                }
                telemetry.addFlow("PAGE_FINISH", hostOf(url), url);
                setState("READY", Color.rgb(74, 222, 128));
                inspectPageSummary(true);
                if (recording) installAutomationRecorder();
                if (TAB_NETWORK.equals(currentTab)) refreshNetwork();
                else refreshCurrentTab();
                if (runnerActive && runnerNavigationPending) {
                    runnerNavigationPending = false;
                    handler.postDelayed(MainActivity.this::resumeRunnerAfterNavigation, 350);
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                TelemetryStore.NetworkEntry entry = telemetry.addNetwork(request);
                telemetry.addFlow(entry.mainFrame ? "REQ_DOC" : "REQ", entry.method + " " + resourceKind(entry.url, entry.headers), entry.url);
                scheduleTelemetryRefresh();
                return null;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    String description = error == null || error.getDescription() == null ? "WebView load error" : error.getDescription().toString();
                    telemetry.addFlow("ERROR", description, request.getUrl() == null ? "" : request.getUrl().toString());
                    setState("ERROR", Color.rgb(251, 113, 133));
                    if (runnerActive) failAutomation("main-frame load error: " + description);
                }
                scheduleTelemetryRefresh();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request != null && errorResponse != null) {
                    telemetry.addFlow("HTTP_" + errorResponse.getStatusCode(), errorResponse.getReasonPhrase(), request.getUrl() == null ? "" : request.getUrl().toString());
                    scheduleTelemetryRefresh();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                telemetry.addFlow("TLS_ERROR", error == null ? "SSL certificate error" : String.valueOf(error.getPrimaryError()), view.getUrl());
                handler.cancel();
                setState("TLS ERROR", Color.rgb(251, 113, 133));
                scheduleTelemetryRefresh();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request == null ? null : request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) {
                    telemetry.addFlow("SCHEME_BLOCK", scheme == null ? "unknown" : scheme, uri.toString());
                }
                return true;
            }
        });
    }

    private void configureServiceWorkerCapture() {
        try {
            ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                    TelemetryStore.NetworkEntry entry = telemetry.addNetwork(request);
                    telemetry.addFlow("SW_REQ", entry.method + " " + resourceKind(entry.url, entry.headers), entry.url);
                    scheduleTelemetryRefresh();
                    return null;
                }
            });
        } catch (Throwable error) {
            telemetry.addFlow("SW_UNAVAILABLE", error.getClass().getSimpleName(), "");
        }
    }

    private void configureDownloadHandling() {
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                toast("Download URL tidak disokong.");
                return;
            }
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
            String detail = fileName + (contentLength > 0 ? "\n" + formatBytes(contentLength) : "") + "\n" + hostOf(url);
            new AlertDialog.Builder(this)
                    .setTitle("Download file")
                    .setMessage(detail)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Download", (dialog, which) -> enqueueDownload(url, userAgent, mimeType, fileName))
                    .show();
        });
    }

    private void enqueueDownload(String url, String userAgent, String mimeType, String fileName) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
            request.setTitle(fileName);
            request.setDescription(hostOf(url));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            if (userAgent != null && !userAgent.isEmpty()) request.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName);
            long id = downloadManager.enqueue(request);
            lastDownloadId = id;
            rememberDownloadId(id);
            telemetry.addFlow("DOWNLOAD", "queued #" + id + " " + fileName, url);
            toast("Download queued: " + fileName);
            if (TAB_DOWNLOADS.equals(currentTab)) renderDownloads();
        } catch (Exception e) {
            toast("Download gagal: " + e.getMessage());
        }
    }

    private void rememberDownloadId(long id) {
        String raw = prefs.getString("download_ids", "");
        ArrayList<String> ids = new ArrayList<>();
        if (raw != null && !raw.isEmpty()) {
            for (String part : raw.split(",")) if (!part.trim().isEmpty()) ids.add(part.trim());
        }
        ids.remove(String.valueOf(id));
        ids.add(0, String.valueOf(id));
        while (ids.size() > 60) ids.remove(ids.size() - 1);
        StringBuilder joined = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) { if (i > 0) joined.append(','); joined.append(ids.get(i)); }
        prefs.edit().putString("download_ids", joined.toString()).apply();
    }

    private long[] storedDownloadIds() {
        String raw = prefs.getString("download_ids", "");
        if (raw == null || raw.isEmpty()) return new long[0];
        ArrayList<Long> ids = new ArrayList<>();
        for (String part : raw.split(",")) {
            try { ids.add(Long.parseLong(part.trim())); } catch (Exception ignored) {}
        }
        long[] out = new long[ids.size()];
        for (int i = 0; i < ids.size(); i++) out[i] = ids.get(i);
        return out;
    }

    private void renderDownloads() {
        long[] ids = storedDownloadIds();
        if (ids.length == 0) {
            outputText.setText("DOWNLOAD CENTER\n\nNo downloads started by this DevScope installation.\nWebsite-triggered downloads are handed to Android DownloadManager with the active WebView Cookie and User-Agent headers.");
            return;
        }
        StringBuilder out = new StringBuilder("DOWNLOAD CENTER // Android DownloadManager\n\n");
        boolean hasActive = false;
        try (Cursor c = downloadManager.query(new DownloadManager.Query().setFilterById(ids))) {
            if (c == null) {
                outputText.setText(out.append("DownloadManager query unavailable.").toString());
                return;
            }
            int idCol = c.getColumnIndex(DownloadManager.COLUMN_ID);
            int titleCol = c.getColumnIndex(DownloadManager.COLUMN_TITLE);
            int statusCol = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
            int reasonCol = c.getColumnIndex(DownloadManager.COLUMN_REASON);
            int soFarCol = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
            int totalCol = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
            int uriCol = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);
            int sourceCol = c.getColumnIndex(DownloadManager.COLUMN_URI);
            while (c.moveToNext()) {
                long id = idCol >= 0 ? c.getLong(idCol) : -1;
                String title = titleCol >= 0 ? c.getString(titleCol) : "download";
                int status = statusCol >= 0 ? c.getInt(statusCol) : 0;
                int reason = reasonCol >= 0 ? c.getInt(reasonCol) : 0;
                long soFar = soFarCol >= 0 ? c.getLong(soFarCol) : 0;
                long total = totalCol >= 0 ? c.getLong(totalCol) : -1;
                String local = uriCol >= 0 ? c.getString(uriCol) : null;
                String source = sourceCol >= 0 ? c.getString(sourceCol) : null;
                String label = downloadStatus(status);
                if (status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING || status == DownloadManager.STATUS_PAUSED) hasActive = true;
                if (status == DownloadManager.STATUS_SUCCESSFUL) lastDownloadId = id;
                out.append('#').append(id).append("  [").append(label).append("]  ").append(title == null ? "download" : title).append('\n');
                out.append("  ").append(formatBytes(soFar));
                if (total > 0) out.append(" / ").append(formatBytes(total)).append("  ").append(Math.min(100, Math.round(soFar * 100f / total))).append('%');
                if (reason != 0 && status != DownloadManager.STATUS_RUNNING) out.append("  reason=").append(reason);
                out.append('\n');
                if (source != null) out.append("  src   ").append(source).append('\n');
                if (local != null) out.append("  local ").append(local).append('\n');
                out.append('\n');
            }
        } catch (Exception e) {
            out.append("QUERY ERROR // ").append(e.getMessage()).append('\n');
        }
        outputText.setText(out.toString());
        if (hasActive && TAB_DOWNLOADS.equals(currentTab)) handler.postDelayed(() -> { if (TAB_DOWNLOADS.equals(currentTab)) renderDownloads(); }, 1000);
    }

    private String downloadStatus(int status) {
        if (status == DownloadManager.STATUS_PENDING) return "PENDING";
        if (status == DownloadManager.STATUS_RUNNING) return "RUNNING";
        if (status == DownloadManager.STATUS_PAUSED) return "PAUSED";
        if (status == DownloadManager.STATUS_SUCCESSFUL) return "DONE";
        if (status == DownloadManager.STATUS_FAILED) return "FAILED";
        return "UNKNOWN";
    }

    private void openLastDownload() {
        if (lastDownloadId < 0) { toast("Tiada download siap untuk dibuka."); return; }
        Uri uri = downloadManager.getUriForDownloadedFile(lastDownloadId);
        if (uri == null) { toast("Download belum siap atau fail sudah tiada."); return; }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            toast("Tiada app yang boleh buka fail ini.");
        }
    }

    private void shareLastDownload() {
        if (lastDownloadId < 0) { toast("Tiada download siap untuk dikongsi."); return; }
        Uri uri = downloadManager.getUriForDownloadedFile(lastDownloadId);
        if (uri == null) { toast("Download belum siap atau fail sudah tiada."); return; }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("*/*");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Share download"));
    }

    private void wireActions() {
        findViewById(R.id.backButton).setOnClickListener(v -> {
            if (webView.canGoBack()) {
                if (recording) appendRecordedStep(step("back"));
                webView.goBack();
            }
        });
        findViewById(R.id.forwardButton).setOnClickListener(v -> {
            if (webView.canGoForward()) {
                if (recording) appendRecordedStep(step("forward"));
                webView.goForward();
            }
        });
        findViewById(R.id.reloadButton).setOnClickListener(v -> {
            if (recording) appendRecordedStep(step("reload"));
            webView.reload();
        });
        findViewById(R.id.goButton).setOnClickListener(v -> navigateFromInput());

        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            navigateFromInput();
            return true;
        });

        debugButton.setOnClickListener(v -> toggleWebDebug());
        splitButton.setOnClickListener(v -> cycleSplitMode());

        findViewById(R.id.tabFlow).setOnClickListener(v -> selectTab(TAB_FLOW));
        findViewById(R.id.tabDom).setOnClickListener(v -> selectTab(TAB_DOM));
        findViewById(R.id.tabNetwork).setOnClickListener(v -> selectTab(TAB_NETWORK));
        findViewById(R.id.tabConsole).setOnClickListener(v -> selectTab(TAB_CONSOLE));
        findViewById(R.id.tabStorage).setOnClickListener(v -> selectTab(TAB_STORAGE));
        findViewById(R.id.tabSource).setOnClickListener(v -> selectTab(TAB_SOURCE));
        findViewById(R.id.tabRuntime).setOnClickListener(v -> selectTab(TAB_RUNTIME));
        findViewById(R.id.tabScript).setOnClickListener(v -> selectTab(TAB_SCRIPT));
        findViewById(R.id.tabCode).setOnClickListener(v -> selectTab(TAB_CODE));
        findViewById(R.id.tabDeps).setOnClickListener(v -> selectTab(TAB_DEPS));
        findViewById(R.id.tabDownloads).setOnClickListener(v -> selectTab(TAB_DOWNLOADS));

        findViewById(R.id.refreshButton).setOnClickListener(v -> refreshCurrentTab());
        findViewById(R.id.clearButton).setOnClickListener(v -> clearCurrentTab());
        pickButton.setOnClickListener(v -> armNodePicker());
        mhtmlButton.setOnClickListener(v -> requestSaveMhtml());
        screenshotButton.setOnClickListener(v -> requestScreenshot());
        pdfButton.setOnClickListener(v -> printCurrentPage());
        findViewById(R.id.copyButton).setOnClickListener(v -> copyCurrentOutput());
        findViewById(R.id.exportButton).setOnClickListener(v -> requestExportText());
        findViewById(R.id.runtimeRunButton).setOnClickListener(v -> evaluateRuntime());
        scriptRecordButton.setOnClickListener(v -> toggleRecording());
        scriptRunButton.setOnClickListener(v -> runAutomationScript());
        scriptStopButton.setOnClickListener(v -> stopAutomation("stopped by user"));
        findViewById(R.id.scriptSaveButton).setOnClickListener(v -> saveScriptLocal());
        findViewById(R.id.scriptImportButton).setOnClickListener(v -> requestImportScript());
        findViewById(R.id.scriptWaitButton).setOnClickListener(v -> appendManualWaitStep());
        codeMethodButton.setOnClickListener(v -> showCodeMethodDialog(selectedCodeLanguage()));
        codeGenerateButton.setOnClickListener(v -> generateCodeFromActionScript());
        codeExportButton.setOnClickListener(v -> requestExportGeneratedCode());
        codeProjectButton.setOnClickListener(v -> requestExportGeneratedProject());
        findViewById(R.id.codeCopyButton).setOnClickListener(v -> copyGeneratedCode());
        dependencyAnalyzeButton.setOnClickListener(v -> analyzeDependencies());
        dependencyVerifyButton.setOnClickListener(v -> verifyDependencyBundle());
        dependencyExportButton.setOnClickListener(v -> requestExportBootstrap());
        findViewById(R.id.dependencyCopyButton).setOnClickListener(v -> copyCurrentOutput());
        findViewById(R.id.downloadOpenButton).setOnClickListener(v -> openLastDownload());
        findViewById(R.id.downloadShareButton).setOnClickListener(v -> shareLastDownload());

        runtimeInput.setOnEditorActionListener((v, actionId, event) -> {
            evaluateRuntime();
            return true;
        });
    }

    private void restoreSession() {
        String last = prefs.getString("last_url", "");
        if (last != null && (last.startsWith("https://") || last.startsWith("http://"))) {
            urlInput.setText(last);
            webView.loadUrl(last);
            footerText.setText("RESTORE // " + last);
        } else {
            webView.loadUrl("about:blank");
            outputText.setText("DEV//SCOPE 4.1\n\nEnter an http(s) URL above. Capture starts from the real Android WebView session.\n\nCore modules:\n  TRACE       navigation + request + error timeline\n  DOM         live rendered DOM + picker\n  NETWORK     request + PerformanceResourceTiming\n  CONSOLE     JavaScript console\n  STORAGE     cookies + local/session storage\n  SOURCE      rendered DOM + MHTML + screenshot + PDF\n  RUNTIME     live JavaScript evaluator\n  AUTOMATE    record -> auto-build editable action script -> replay\n  CODEGEN     live URL+UA -> multi-method projects: Playwright/Selenium/Puppeteer + language-native engines\n  DEPS        dependency manifests + bootstrap installers + verify/repair scripts\n  DOWNLOADS   Android DownloadManager queue/history\n\nNo sample telemetry, fake requests, or seeded automation steps are included.");
            footerText.setText("READY // no session loaded");
        }
    }

    private void navigateFromInput() {
        String raw = urlInput.getText().toString().trim();
        if (raw.isEmpty()) return;
        String normalized = raw;
        if (!normalized.contains("://")) normalized = "https://" + normalized;
        Uri uri;
        try {
            uri = Uri.parse(normalized);
        } catch (Exception e) {
            toast("URL tidak sah");
            return;
        }
        if (uri.getHost() == null || !("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))) {
            toast("DevScope hanya membuka URL http/https dalam inspector.");
            return;
        }
        telemetry.addFlow("NAVIGATE", "address bar", normalized);
        if (recording) {
            JSONObject open = step("open");
            try { open.put("url", normalized); } catch (Exception ignored) {}
            appendRecordedStep(open);
        }
        webView.loadUrl(normalized);
    }

    private void toggleWebDebug() {
        webDebugEnabled = !webDebugEnabled;
        WebView.setWebContentsDebuggingEnabled(webDebugEnabled);
        prefs.edit().putBoolean("web_debug", webDebugEnabled).apply();
        telemetry.addFlow("ADB_DEBUG", webDebugEnabled ? "enabled" : "disabled", webView.getUrl());
        updateDebugButton();
        toast(webDebugEnabled ? "ADB WebView debugging ON" : "ADB WebView debugging OFF");
    }

    private void updateDebugButton() {
        debugButton.setText(webDebugEnabled ? "ADB DBG ON" : "ADB DBG OFF");
        debugButton.setTextColor(webDebugEnabled ? Color.rgb(74, 222, 128) : Color.rgb(139, 147, 167));
    }

    private void cycleSplitMode() {
        if (keyboardEditorMode && keyboardVisible) {
            toast("Editor keyboard mode aktif. Tutup keyboard untuk ubah SPLIT/WEB/TOOLS.");
            return;
        }
        splitMode = (splitMode + 1) % 3;
        applySplitMode();
    }

    private void applySplitMode() {
        if (keyboardEditorMode && keyboardVisible && isKeyboardEditorFocused()) {
            browserContainer.setVisibility(View.GONE);
            toolsContainer.setVisibility(View.VISIBLE);
            splitButton.setText("EDIT");
            return;
        }
        if (splitMode == 0) {
            browserContainer.setVisibility(View.VISIBLE);
            toolsContainer.setVisibility(View.VISIBLE);
            splitButton.setText("SPLIT");
        } else if (splitMode == 1) {
            browserContainer.setVisibility(View.VISIBLE);
            toolsContainer.setVisibility(View.GONE);
            splitButton.setText("WEB");
        } else {
            browserContainer.setVisibility(View.GONE);
            toolsContainer.setVisibility(View.VISIBLE);
            splitButton.setText("TOOLS");
        }
    }

    private void configureKeyboardAwareEditors() {
        if (rootContainer == null) return;

        scriptEditor.setScrollContainer(true);
        codeEditor.setScrollContainer(true);
        scriptEditor.setVerticalScrollBarEnabled(true);
        codeEditor.setVerticalScrollBarEnabled(true);

        View.OnFocusChangeListener focusListener = (view, hasFocus) -> {
            if (!hasFocus || !(view instanceof EditText)) return;
            EditText editor = (EditText) view;
            handler.postDelayed(() -> {
                if (keyboardVisible) enterKeyboardEditorMode();
                ensureEditorCursorVisible(editor);
            }, 120L);
        };
        scriptEditor.setOnFocusChangeListener(focusListener);
        codeEditor.setOnFocusChangeListener(focusListener);
        scriptEditor.setOnClickListener(v -> ensureEditorCursorVisible(scriptEditor));
        codeEditor.setOnClickListener(v -> ensureEditorCursorVisible(codeEditor));

        rootContainer.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Rect visibleFrame = new Rect();
                rootContainer.getWindowVisibleDisplayFrame(visibleFrame);
                int rootHeight = rootContainer.getRootView().getHeight();
                if (rootHeight <= 0) return;
                int obscuredHeight = Math.max(0, rootHeight - visibleFrame.bottom);
                boolean nowVisible = obscuredHeight > (int) (rootHeight * 0.18f);

                if (nowVisible != keyboardVisible) {
                    keyboardVisible = nowVisible;
                    if (keyboardVisible && isKeyboardEditorFocused()) {
                        enterKeyboardEditorMode();
                    } else if (!keyboardVisible) {
                        exitKeyboardEditorMode();
                    }
                }

                if (keyboardVisible && isKeyboardEditorFocused()) {
                    EditText active = codeEditor.hasFocus() ? codeEditor : scriptEditor;
                    ensureEditorCursorVisible(active);
                }
            }
        });
    }

    private boolean isKeyboardEditorFocused() {
        return codeEditor != null && codeEditor.hasFocus() || scriptEditor != null && scriptEditor.hasFocus();
    }

    private void enterKeyboardEditorMode() {
        if (!isKeyboardEditorFocused()) return;
        if (!keyboardEditorMode) {
            keyboardEditorMode = true;
            splitModeBeforeKeyboard = splitMode;
            footerBeforeKeyboard = footerText.getText() == null ? "" : footerText.getText().toString();
        }
        browserContainer.setVisibility(View.GONE);
        toolsContainer.setVisibility(View.VISIBLE);
        splitButton.setText("EDIT");
        footerText.setText("EDITOR // keyboard-aware // swipe code vertically // cursor kept visible");
        EditText active = codeEditor.hasFocus() ? codeEditor : scriptEditor;
        ensureEditorCursorVisible(active);
    }

    private void exitKeyboardEditorMode() {
        if (!keyboardEditorMode) return;
        keyboardEditorMode = false;
        splitMode = splitModeBeforeKeyboard;
        applySplitMode();
        if (!footerBeforeKeyboard.isEmpty()) footerText.setText(footerBeforeKeyboard);
    }

    private void ensureEditorCursorVisible(EditText editor) {
        if (editor == null || !editor.hasFocus()) return;
        editor.post(() -> {
            int selection = Math.max(0, editor.getSelectionStart());
            editor.bringPointIntoView(selection);
        });
    }

    private void selectTab(String tab) {
        currentTab = tab;
        String[] names = {TAB_FLOW, TAB_DOM, TAB_NETWORK, TAB_CONSOLE, TAB_STORAGE, TAB_SOURCE, TAB_RUNTIME, TAB_SCRIPT, TAB_CODE, TAB_DEPS, TAB_DOWNLOADS};
        for (int i = 0; i < tabButtons.length; i++) tabButtons[i].setSelected(names[i].equals(tab));

        pickButton.setVisibility(TAB_DOM.equals(tab) ? View.VISIBLE : View.GONE);
        mhtmlButton.setVisibility(TAB_SOURCE.equals(tab) ? View.VISIBLE : View.GONE);
        screenshotButton.setVisibility(TAB_SOURCE.equals(tab) ? View.VISIBLE : View.GONE);
        pdfButton.setVisibility(TAB_SOURCE.equals(tab) ? View.VISIBLE : View.GONE);
        runtimeBar.setVisibility(TAB_RUNTIME.equals(tab) ? View.VISIBLE : View.GONE);
        automationBar.setVisibility(TAB_SCRIPT.equals(tab) ? View.VISIBLE : View.GONE);
        codegenBar.setVisibility(TAB_CODE.equals(tab) ? View.VISIBLE : View.GONE);
        dependencyBar.setVisibility(TAB_DEPS.equals(tab) ? View.VISIBLE : View.GONE);
        downloadBar.setVisibility(TAB_DOWNLOADS.equals(tab) ? View.VISIBLE : View.GONE);
        flowScroll.setVisibility(TAB_FLOW.equals(tab) ? View.VISIBLE : View.GONE);
        scriptEditor.setVisibility(TAB_SCRIPT.equals(tab) ? View.VISIBLE : View.GONE);
        codeEditor.setVisibility(TAB_CODE.equals(tab) ? View.VISIBLE : View.GONE);
        outputScroll.setVisibility((TAB_FLOW.equals(tab) || TAB_SCRIPT.equals(tab) || TAB_CODE.equals(tab)) ? View.GONE : View.VISIBLE);

        switch (tab) {
            case TAB_FLOW -> panelTitleText.setText("TRACE // event stream");
            case TAB_DOM -> panelTitleText.setText("DOM // rendered structure");
            case TAB_NETWORK -> panelTitleText.setText("NETWORK // request + performance telemetry");
            case TAB_CONSOLE -> panelTitleText.setText("CONSOLE // JavaScript messages");
            case TAB_STORAGE -> panelTitleText.setText("STORAGE // origin state");
            case TAB_SOURCE -> panelTitleText.setText("SOURCE // live DOM snapshot");
            case TAB_RUNTIME -> panelTitleText.setText("RUNTIME // JavaScript evaluator");
            case TAB_SCRIPT -> panelTitleText.setText("AUTOMATE // record -> build -> edit -> replay");
            case TAB_CODE -> panelTitleText.setText("CODEGEN // one test flow -> multi-language project");
            case TAB_DEPS -> panelTitleText.setText("DEPS // auto module bootstrap + verification");
            case TAB_DOWNLOADS -> panelTitleText.setText("DOWNLOADS // Android DownloadManager");
        }
        refreshCurrentTab();
    }

    private void clearCurrentTab() {
        switch (currentTab) {
            case TAB_FLOW -> { telemetry.clearFlow(); renderFlow(); }
            case TAB_NETWORK -> { telemetry.clearNetwork(); lastPerformance = null; renderNetwork(null); }
            case TAB_CONSOLE -> { telemetry.clearConsole(); renderConsole(); }
            case TAB_RUNTIME -> { runtimeHistory = new StringBuilder(); renderRuntime(); }
            case TAB_SCRIPT -> {
                if (!runnerActive) {
                    while (recordedSteps.length() > 0) recordedSteps.remove(recordedSteps.length() - 1);
                    scriptEditor.setText(defaultAutomationScript());
                    prefs.edit().remove("saved_script").apply();
                }
            }
            case TAB_CODE -> { codeEditor.setText(""); generatedCodeProject = null; dependencyPlan = null; }
            case TAB_DEPS -> { outputText.setText("// dependency view cleared; press ANALYZE to rebuild from current CODEGEN target."); }
            case TAB_DOWNLOADS -> { prefs.edit().remove("download_ids").apply(); renderDownloads(); }
            default -> outputText.setText("// panel cleared; press REFRESH to inspect again.");
        }
        netMetricText.setText("REQ " + telemetry.networkCount());
        consoleMetricText.setText("CON " + telemetry.consoleCount());
    }

    private void refreshCurrentTab() {
        switch (currentTab) {
            case TAB_FLOW -> renderFlow();
            case TAB_DOM -> refreshDom();
            case TAB_NETWORK -> refreshNetwork();
            case TAB_CONSOLE -> renderConsole();
            case TAB_STORAGE -> refreshStorage();
            case TAB_SOURCE -> refreshSource();
            case TAB_RUNTIME -> renderRuntime();
            case TAB_SCRIPT -> renderAutomation();
            case TAB_CODE -> renderCodegen();
            case TAB_DEPS -> renderDependencies();
            case TAB_DOWNLOADS -> renderDownloads();
        }
    }

    private void analyzeDependencies() {
        if (!ensureGeneratedProject()) return;
        try {
            dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
            DependencyBootstrapEngine.verifyBundle(generatedCodeProject, dependencyPlan);
            telemetry.addFlow("DEPS_ANALYZE", generatedCodeProject.target + " // bootstrap=" + dependencyPlan.bootstrapFiles.size(), webView.getUrl());
            renderDependencies();
            footerText.setText("DEPS // bootstrap attached // " + dependencyPlan.bootstrapFiles.size() + " files // project=" + generatedCodeProject.files.size());
        } catch (Exception e) {
            outputText.setText("DEPENDENCY ANALYZE ERROR\n\n" + e.getMessage());
            toast("Dependency analyze gagal: " + e.getMessage());
        }
    }

    private void renderDependencies() {
        if (generatedCodeProject == null) {
            outputText.setText("DEPENDENCY BOOTSTRAP\n\nGenerate a CODEGEN project first. DevScope will attach setup.sh/setup.ps1, toolchain installers, verify scripts, env.example and bootstrap metadata.\n\nAndroid does not fake external Python/Node/Go/Rust/.NET/C/C++ installations; exported bootstrap scripts perform the real module installation in the target environment.");
            footerText.setText("DEPS // waiting for generated project");
            return;
        }
        try {
            if (dependencyPlan == null || !dependencyPlan.target.equals(generatedCodeProject.target)) dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
            outputText.setText(DependencyBootstrapEngine.renderReport(dependencyPlan, generatedCodeProject));
            footerText.setText("DEPS // " + dependencyPlan.target + " // auto-install modules // verify scripts ready");
        } catch (Exception e) {
            outputText.setText("DEPENDENCY ERROR\n\n" + e.getMessage());
        }
    }

    private void verifyDependencyBundle() {
        if (!ensureGeneratedProject()) return;
        try {
            if (dependencyPlan == null) dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
            DependencyBootstrapEngine.verifyBundle(generatedCodeProject, dependencyPlan);
            telemetry.addFlow("DEPS_VERIFY", generatedCodeProject.target + " // bundle OK", webView.getUrl());
            renderDependencies();
            toast("Bootstrap bundle verified: manifests + setup + verify files lengkap.");
        } catch (Exception e) {
            toast("Bootstrap verify gagal: " + e.getMessage());
            outputText.setText("BOOTSTRAP VERIFY FAILED\n\n" + e.getMessage());
        }
    }

    private void requestExportBootstrap() {
        if (!ensureGeneratedProject()) return;
        try {
            if (dependencyPlan == null) dependencyPlan = DependencyBootstrapEngine.attach(generatedCodeProject);
        } catch (Exception e) {
            toast("Bootstrap gagal: " + e.getMessage());
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, "devscope-" + targetSlug(generatedCodeProject.target) + "-bootstrap-" + fileTime.format(new Date()) + ".zip");
        startActivityForResult(intent, REQ_EXPORT_BOOTSTRAP);
    }

    private void exportBootstrapTo(Uri uri) {
        if (generatedCodeProject == null || dependencyPlan == null) return;
        try (OutputStream raw = getContentResolver().openOutputStream(uri);
             ZipOutputStream zip = raw == null ? null : new ZipOutputStream(raw)) {
            if (zip == null) throw new Exception("Destination stream unavailable");
            for (Map.Entry<String, String> entry : dependencyPlan.bootstrapFiles.entrySet()) {
                String path = entry.getKey().replace('\\', '/');
                ZipEntry ze = new ZipEntry(path);
                zip.putNextEntry(ze);
                zip.write(entry.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                zip.closeEntry();
            }
            for (String manifest : dependencyPlan.manifests) {
                String value = generatedCodeProject.files.get(manifest);
                if (value == null) continue;
                ZipEntry ze = new ZipEntry(manifest);
                zip.putNextEntry(ze);
                zip.write(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                zip.closeEntry();
            }
            zip.finish();
            telemetry.addFlow("DEPS_EXPORT", dependencyPlan.target + " // bootstrap zip", webView.getUrl());
            toast("Dependency bootstrap ZIP exported.");
        } catch (Exception e) {
            toast("Bootstrap export error: " + e.getMessage());
        }
    }

    private void renderFlow() {
        List<TelemetryStore.FlowEvent> events = telemetry.flowSnapshot();
        flowView.setEvents(events);
        if (!events.isEmpty()) handler.post(() -> flowScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void refreshDom() {
        if (isBlankPage()) {
            outputText.setText("No document loaded.");
            return;
        }
        outputText.setText("// inspecting rendered DOM...\n");
        inspector.inspectDom(new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                StringBuilder out = new StringBuilder();
                out.append("DOM SNAPSHOT // live\n");
                out.append("nodes_total     ").append(object.optInt("total")).append('\n');
                out.append("nodes_emitted   ").append(object.optInt("emitted"));
                if (object.optBoolean("truncated")) out.append("  [TRUNCATED]");
                out.append('\n');
                out.append("scripts         ").append(object.optInt("scripts")).append('\n');
                out.append("stylesheets     ").append(object.optInt("styles")).append('\n');
                out.append("forms           ").append(object.optInt("forms")).append('\n');
                out.append("iframes         ").append(object.optInt("iframes")).append('\n');
                out.append("shadow_hosts    ").append(object.optInt("shadowHosts")).append("\n\n");
                JSONArray tech = object.optJSONArray("tech");
                out.append("FRAMEWORK SIGNALS\n");
                if (tech == null || tech.length() == 0) out.append("  none detected by runtime heuristics\n");
                else for (int i = 0; i < tech.length(); i++) out.append("  + ").append(tech.optString(i)).append('\n');
                out.append("\nTREE\n");
                out.append(object.optString("tree"));
                outputText.setText(out.toString());
                domMetricText.setText("DOM " + object.optInt("total"));
            }

            @Override
            public void onError(String error) {
                outputText.setText("DOM inspector error\n" + error);
            }
        });
    }

    private void armNodePicker() {
        if (isBlankPage()) return;
        int generation = ++pickerGeneration;
        inspector.installPicker(new InspectorEngine.TextCallback() {
            @Override
            public void onResult(String value) {
                telemetry.addFlow("NODE_PICK", "picker armed", webView.getUrl());
                setState("PICK NODE", Color.rgb(139, 92, 246));
                toast("Tap elemen dalam preview web.");
                pollNodePicker(generation, 0);
            }

            @Override
            public void onError(String error) {
                outputText.setText("Node picker error\n" + error);
            }
        });
    }

    private void pollNodePicker(int generation, int attempt) {
        if (generation != pickerGeneration || attempt > 180) return;
        inspector.pollPicker(new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                String selector = object.optString("selector", "");
                if (selector.isEmpty()) {
                    handler.postDelayed(() -> pollNodePicker(generation, attempt + 1), 300);
                    return;
                }
                setState("NODE", Color.rgb(74, 222, 128));
                telemetry.addFlow("NODE_SELECTED", selector, webView.getUrl());
                StringBuilder out = new StringBuilder();
                out.append("SELECTED NODE\n");
                out.append("selector   ").append(selector).append('\n');
                out.append("tag        ").append(object.optString("tag")).append('\n');
                out.append("id         ").append(object.optString("id")).append('\n');
                out.append("class      ").append(object.optString("className")).append("\n\n");
                out.append("RECT\n").append(pretty(object.optJSONObject("rect"))).append("\n\n");
                out.append("COMPUTED STYLE\n").append(pretty(object.optJSONObject("styles"))).append("\n\n");
                out.append("ATTRIBUTES\n").append(pretty(object.optJSONObject("attributes"))).append("\n\n");
                out.append("TEXT\n").append(object.optString("text")).append("\n\n");
                out.append("OUTER HTML\n").append(object.optString("outerHTML"));
                outputText.setText(out.toString());
            }

            @Override
            public void onError(String error) {
                handler.postDelayed(() -> pollNodePicker(generation, attempt + 1), 400);
            }
        });
    }

    private void refreshNetwork() {
        renderNetwork(null);
        if (isBlankPage()) return;
        inspector.inspectPerformance(new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                lastPerformance = object;
                renderNetwork(object);
            }

            @Override
            public void onError(String error) {
                renderNetwork(null);
            }
        });
    }

    private void renderNetwork(JSONObject performance) {
        List<TelemetryStore.NetworkEntry> entries = telemetry.networkSnapshot();
        StringBuilder out = new StringBuilder();
        out.append("NATIVE REQUEST CAPTURE // WebViewClient + ServiceWorkerClient\n");
        out.append("captured=").append(entries.size()).append("  body_capture=not_exposed_by_WebResourceRequest\n\n");

        JSONObject nav = performance == null ? null : performance.optJSONObject("navigation");
        if (nav != null) {
            out.append("NAVIGATION TIMING\n");
            out.append("  protocol           ").append(nav.optString("protocol", "n/a")).append('\n');
            out.append("  duration           ").append(nav.optDouble("duration")).append(" ms\n");
            out.append("  domInteractive     ").append(nav.optDouble("domInteractive")).append(" ms\n");
            out.append("  DOMContentLoaded   ").append(nav.optDouble("domContentLoaded")).append(" ms\n");
            out.append("  loadEventEnd       ").append(nav.optDouble("loadEventEnd")).append(" ms\n");
            out.append("  transfer           ").append(formatBytes(nav.optLong("transfer"))).append("\n\n");
        }

        int start = Math.max(0, entries.size() - 260);
        for (int i = start; i < entries.size(); i++) {
            TelemetryStore.NetworkEntry e = entries.get(i);
            out.append('[').append(timeFormat.format(new Date(e.timeMs))).append("] ");
            out.append(String.format(Locale.US, "#%-4d %-7s %-10s ", e.seq, e.method, resourceKind(e.url, e.headers)));
            if (e.mainFrame) out.append("[DOC] ");
            out.append(e.url).append('\n');
            if (e.mainFrame && !e.headers.isEmpty()) {
                for (Map.Entry<String, String> h : e.headers.entrySet()) {
                    out.append("       > ").append(h.getKey()).append(": ").append(clip(h.getValue(), 180)).append('\n');
                }
            }
        }

        if (performance != null) {
            JSONArray resources = performance.optJSONArray("resources");
            if (resources != null) {
                out.append("\nRESOURCE TIMING // performance.getEntriesByType('resource')\n");
                int rs = Math.max(0, resources.length() - 220);
                for (int i = rs; i < resources.length(); i++) {
                    JSONObject r = resources.optJSONObject(i);
                    if (r == null) continue;
                    out.append(String.format(Locale.US, "  %8.2fms  %8.2fms  %-10s %-5s %9s  %s\n",
                            r.optDouble("start"), r.optDouble("duration"), r.optString("type"),
                            r.optString("protocol", "-"), formatBytes(r.optLong("transfer")), r.optString("name")));
                }
                resourceMetricText.setText("RES " + resources.length());
            }
        }
        outputText.setText(out.toString());
        netMetricText.setText("REQ " + entries.size());
    }

    private void renderConsole() {
        List<TelemetryStore.ConsoleEntry> entries = telemetry.consoleSnapshot();
        StringBuilder out = new StringBuilder();
        out.append("JAVASCRIPT CONSOLE // WebChromeClient.onConsoleMessage\n");
        out.append("messages=").append(entries.size()).append("\n\n");
        int start = Math.max(0, entries.size() - 320);
        for (int i = start; i < entries.size(); i++) {
            TelemetryStore.ConsoleEntry e = entries.get(i);
            out.append('[').append(timeFormat.format(new Date(e.timeMs))).append("] ");
            out.append(String.format(Locale.US, "#%-4d %-8s ", e.seq, e.level));
            out.append(e.message).append('\n');
            if (!e.source.isEmpty()) out.append("       @ ").append(e.source).append(':').append(e.line).append('\n');
        }
        outputText.setText(out.toString());
        consoleMetricText.setText("CON " + entries.size());
    }

    private void refreshStorage() {
        if (isBlankPage()) {
            outputText.setText("No origin loaded.");
            return;
        }
        String cookies = CookieManager.getInstance().getCookie(webView.getUrl());
        outputText.setText("// reading origin storage...\n");
        inspector.inspectStorage(cookies, new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                outputText.setText("ORIGIN STORAGE // live\n\n" + pretty(object));
            }

            @Override
            public void onError(String error) {
                outputText.setText("Storage inspector error\n" + error);
            }
        });
    }

    private void refreshSource() {
        if (isBlankPage()) {
            outputText.setText("No document loaded.");
            return;
        }
        outputText.setText("// serializing current rendered DOM...\n");
        inspector.inspectSource(new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                StringBuilder out = new StringBuilder();
                out.append("LIVE DOM HTML\n");
                out.append("characters  ").append(object.optInt("length")).append('\n');
                out.append("truncated   ").append(object.optBoolean("truncated")).append("\n");
                out.append("note        this is rendered DOM outerHTML, not the raw transport body\n\n");
                out.append(object.optString("html"));
                outputText.setText(out.toString());
            }

            @Override
            public void onError(String error) {
                outputText.setText("Source inspector error\n" + error);
            }
        });
    }

    private void renderRuntime() {
        if (runtimeHistory.length() == 0) {
            outputText.setText("RUNTIME JS\n\nExpressions execute inside the currently loaded page via WebView.evaluateJavascript().\nResult serialization follows the WebView JavaScript bridge.\n\nExample:\n  [...document.querySelectorAll('script')].map(x => x.src).filter(Boolean)\n");
        } else {
            outputText.setText(runtimeHistory.toString());
        }
    }

    private void evaluateRuntime() {
        String code = runtimeInput.getText().toString().trim();
        if (code.isEmpty()) return;
        final String command = code;
        runtimeInput.setText("");
        runtimeHistory.append(">>> ").append(command).append('\n');
        outputText.setText(runtimeHistory.toString() + "... evaluating\n");
        telemetry.addFlow("RUNTIME_EVAL", clip(command, 120), webView.getUrl());
        if (recording) {
            JSONObject js = step("js");
            try { js.put("code", command); } catch (Exception ignored) {}
            appendRecordedStep(js);
        }
        inspector.evaluateRuntime(command, new InspectorEngine.TextCallback() {
            @Override
            public void onResult(String value) {
                runtimeHistory.append(clipLarge(value, 60000)).append("\n\n");
                renderRuntime();
            }

            @Override
            public void onError(String error) {
                runtimeHistory.append("ERROR: ").append(error).append("\n\n");
                renderRuntime();
            }
        });
    }

    private JSONObject step(String type) {
        JSONObject step = new JSONObject();
        try { step.put("type", type); } catch (Exception ignored) {}
        return step;
    }

    private String defaultAutomationScript() {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 1);
            root.put("engine", "devscope.action/1");
            root.put("name", "untitled-flow");
            root.put("steps", new JSONArray());
            return root.toString(2);
        } catch (Exception e) {
            return "{\"version\":1,\"engine\":\"devscope.action/1\",\"steps\":[]}";
        }
    }

    private String recordedScriptText() {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 1);
            root.put("engine", "devscope.action/1");
            root.put("name", "recording-" + fileTime.format(new Date()));
            root.put("recordedAt", System.currentTimeMillis());
            root.put("startUrl", isBlankPage() ? JSONObject.NULL : webView.getUrl());
            root.put("steps", new JSONArray(recordedSteps.toString()));
            return root.toString(2);
        } catch (Exception e) {
            return defaultAutomationScript();
        }
    }

    private void appendRecordedStep(JSONObject raw) {
        if (!recording || raw == null) return;
        try {
            JSONObject copy = new JSONObject(raw.toString());
            String type = copy.optString("type", "");
            if (type.isEmpty()) return;
            if ("scroll".equals(type) && recordedSteps.length() > 0) {
                JSONObject last = recordedSteps.optJSONObject(recordedSteps.length() - 1);
                if (last != null && "scroll".equals(last.optString("type"))) recordedSteps.remove(recordedSteps.length() - 1);
            }
            recordedSteps.put(copy);
            scriptEditor.setText(recordedScriptText());
            scriptEditor.setSelection(scriptEditor.getText().length());
            telemetry.addFlow("REC_" + type.toUpperCase(Locale.US), clip(copy.optString("selector", copy.optString("text", "")), 120), webView.getUrl());
            footerText.setText("REC // " + recordedSteps.length() + " steps // " + safeUrl(webView.getUrl()));
        } catch (Exception e) {
            telemetry.addFlow("REC_ERROR", e.getMessage(), webView.getUrl());
        }
    }

    private void toggleRecording() {
        if (recording) stopRecording();
        else startRecording();
    }

    private void startRecording() {
        if (runnerActive) stopAutomation("interrupted by recorder");
        while (recordedSteps.length() > 0) recordedSteps.remove(recordedSteps.length() - 1);
        importedScriptName = "automation.json";
        recording = true;
        if (!isBlankPage()) {
            JSONObject open = step("open");
            try { open.put("url", webView.getUrl()); } catch (Exception ignored) {}
            recordedSteps.put(open);
        }
        scriptRecordButton.setText("STOP REC");
        scriptRecordButton.setTextColor(Color.rgb(251, 113, 133));
        setState("REC", Color.rgb(251, 113, 133));
        installAutomationRecorder();
        scriptEditor.setText(recordedScriptText());
        telemetry.addFlow("REC_START", "automation recorder", webView.getUrl());
        footerText.setText("REC // interact with the live WebView");
    }

    private void installAutomationRecorder() {
        if (!recording || isBlankPage()) return;
        automation.installRecorder(new AutomationEngine.TextCallback() {
            @Override public void onResult(String value) { footerText.setText("REC // " + recordedSteps.length() + " steps // live listeners armed"); }
            @Override public void onError(String error) { telemetry.addFlow("REC_INSTALL_ERROR", error, webView.getUrl()); }
        });
    }

    private void stopRecording() {
        if (!recording) return;
        recording = false;
        automation.pauseRecorder(new AutomationEngine.TextCallback() {
            @Override public void onResult(String value) {}
            @Override public void onError(String error) {}
        });
        scriptRecordButton.setText("REC");
        scriptRecordButton.setTextColor(Color.rgb(251, 113, 133));
        setState("READY", Color.rgb(74, 222, 128));
        String script = recordedScriptText();
        scriptEditor.setText(script);
        importedScriptName = "automation.json";
        prefs.edit().putString("saved_script", script).putString("saved_script_name", importedScriptName).apply();
        telemetry.addFlow("REC_STOP", recordedSteps.length() + " steps", webView.getUrl());
        footerText.setText("AUTOMATE // recorded " + recordedSteps.length() + " real interaction steps");
    }

    private void renderAutomation() {
        if (scriptEditor.getText() == null || scriptEditor.getText().toString().trim().isEmpty()) {
            scriptEditor.setText(prefs.getString("saved_script", defaultAutomationScript()));
            importedScriptName = prefs.getString("saved_script_name", "");
        }
        if (recording) footerText.setText("REC // " + recordedSteps.length() + " steps // interact with WebView");
        else if (runnerActive) footerText.setText("RUN // step " + (runnerIndex + 1) + "/" + runnerSteps.length());
        else {
            ScriptLanguageDetector.Result d = ScriptLanguageDetector.detect(scriptEditor.getText().toString(), importedScriptName);
            footerText.setText("AUTOMATE // AUTO DETECT: " + d.label() + " // confidence=" + d.confidence + "%");
        }
    }

    private void saveScriptLocal() {
        String text = scriptEditor.getText() == null ? "" : scriptEditor.getText().toString().trim();
        if (text.isEmpty()) { toast("Script kosong."); return; }
        ScriptLanguageDetector.Result d = ScriptLanguageDetector.detect(text, importedScriptName);
        try {
            if (d.kind == ScriptLanguageDetector.Kind.ACTION_SCRIPT) {
                JSONObject root = new JSONObject(text);
                if (!(root.opt("steps") instanceof JSONArray)) throw new Exception("steps array is required");
                text = root.toString(2);
                scriptEditor.setText(text);
                importedScriptName = "automation.json";
            }
            prefs.edit().putString("saved_script", text).putString("saved_script_name", importedScriptName).apply();
            toast("Script disimpan: " + d.label());
            footerText.setText("AUTOMATE // saved // " + d.label());
        } catch (Exception e) {
            toast("Script tidak dapat disimpan: " + e.getMessage());
        }
    }

    private void requestImportScript() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "text/x-python", "text/javascript", "application/javascript", "text/x-java-source", "text/x-c", "text/x-c++", "text/x-ruby", "application/x-httpd-php"});
        startActivityForResult(intent, REQ_IMPORT_SCRIPT);
    }

    private void appendManualWaitStep() {
        try {
            JSONObject root = new JSONObject(scriptEditor.getText().toString());
            JSONArray steps = root.optJSONArray("steps");
            if (steps == null) { steps = new JSONArray(); root.put("steps", steps); }
            JSONObject wait = step("wait");
            wait.put("ms", 1000);
            steps.put(wait);
            scriptEditor.setText(root.toString(2));
            scriptEditor.setSelection(scriptEditor.getText().length());
        } catch (Exception e) {
            toast("Betulkan JSON script dahulu.");
        }
    }

    private void runAutomationScript() {
        if (recording) stopRecording();
        String source = scriptEditor.getText() == null ? "" : scriptEditor.getText().toString();
        ScriptLanguageDetector.Result detected = ScriptLanguageDetector.detect(source, importedScriptName);
        telemetry.addFlow("SCRIPT_DETECT", detected.label() + " // confidence=" + detected.confidence, webView.getUrl());

        if (detected.kind == ScriptLanguageDetector.Kind.ACTION_SCRIPT) {
            runNativeActionScript(source);
            return;
        }
        if (detected.kind == ScriptLanguageDetector.Kind.WEBVIEW_JAVASCRIPT) {
            if (isBlankPage()) { toast("Buka halaman dahulu untuk JavaScript WebView."); return; }
            footerText.setText("AUTOMATE // detected JavaScript // running in current WebView");
            webView.evaluateJavascript("(()=>{try{const __r=eval(" + JSONObject.quote(source) + ");return JSON.stringify({ok:true,value:__r===undefined?null:__r});}catch(e){return JSON.stringify({ok:false,error:String(e),stack:e&&e.stack?String(e.stack):''});}})()", value -> {
                telemetry.addFlow("SCRIPT_WEBVIEW_JS", "executed // " + detected.confidence + "%", webView.getUrl());
                toast("JavaScript selesai dalam WebView.");
                footerText.setText("AUTOMATE // JavaScript // WebView execution complete");
            });
            return;
        }
        if (detected.kind == ScriptLanguageDetector.Kind.EXTERNAL_SOURCE) {
            showExternalRunDialog(detected, source);
            return;
        }
        toast("Bahasa script tidak dapat dikesan. Import fail dengan extension atau guna DevScope Action JSON.");
        footerText.setText("AUTOMATE // DETECT UNKNOWN // execution blocked");
    }

    private void runNativeActionScript(String source) {
        try {
            JSONObject root = new JSONObject(source);
            JSONArray steps = root.optJSONArray("steps");
            if (steps == null) throw new Exception("steps array is required");
            runnerSteps = new JSONArray(steps.toString());
            runnerIndex = 0;
            runnerToken++;
            runnerVars.clear();
            runnerActive = true;
            runnerNavigationPending = false;
            telemetry.addFlow("SCRIPT_START", runnerSteps.length() + " steps // native Action Script", webView.getUrl());
            setState("RUN", Color.rgb(34, 211, 238));
            runNextAutomationStep();
        } catch (Exception e) {
            toast("Action Script tidak boleh dijalankan: " + e.getMessage());
        }
    }

    private void showExternalRunDialog(ScriptLanguageDetector.Result detected, String source) {
        boolean termux = TermuxRunner.installed(this);
        String message = "Detected: " + detected.label() + "\nConfidence: " + detected.confidence + "%\n\n" +
                "DevScope Android tidak memalsukan compiler/runtime desktop. External source dijalankan melalui Termux RUN_COMMAND bila tersedia. Dependency/browser/WebDriver yang diperlukan oleh framework mesti tersedia; untuk current Android WebView gunakan DevScope Action Script native." +
                (termux ? "\n\nTermux detected: READY TO DISPATCH\nRequirement: grant Run commands in Termux permission + set allow-external-apps=true in ~/.termux/termux.properties." : "\n\nTermux: NOT INSTALLED");
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("AUTO DETECT // " + detected.language)
                .setMessage(message)
                .setNegativeButton("CANCEL", null);
        if (termux) {
            b.setPositiveButton("RUN TERMUX", (dialog, which) -> {
                try {
                    TermuxRunner.runSource(this, detected, source);
                    telemetry.addFlow("SCRIPT_EXTERNAL_RUN", detected.label() + " // Termux RUN_COMMAND", webView.getUrl());
                    footerText.setText("AUTOMATE // " + detected.label() + " // dispatched to Termux");
                    toast("Dihantar ke Termux: " + detected.label());
                } catch (Exception e) {
                    toast("External run gagal: " + e.getMessage());
                    footerText.setText("AUTOMATE // external run blocked // " + e.getMessage());
                }
            });
        }
        b.show();
    }

    private JSONObject resolveStep(JSONObject original) throws Exception {
        JSONObject out = new JSONObject(original.toString());
        JSONArray names = out.names();
        if (names == null) return out;
        for (int i = 0; i < names.length(); i++) {
            String key = names.optString(i);
            Object value = out.opt(key);
            if (value instanceof String) out.put(key, resolveVariables((String) value));
        }
        return out;
    }

    private String resolveVariables(String value) {
        String out = value == null ? "" : value;
        for (Map.Entry<String, String> e : runnerVars.entrySet()) out = out.replace("{{" + e.getKey() + "}}", e.getValue());
        return out;
    }

    private void runNextAutomationStep() {
        if (!runnerActive || runnerNavigationPending) return;
        if (runnerIndex >= runnerSteps.length()) {
            finishAutomation();
            return;
        }
        JSONObject raw = runnerSteps.optJSONObject(runnerIndex);
        if (raw == null) { failAutomation("step " + (runnerIndex + 1) + " is not an object"); return; }
        final JSONObject step;
        try { step = resolveStep(raw); }
        catch (Exception e) { failAutomation("step decode: " + e.getMessage()); return; }
        String type = step.optString("type", "");
        footerText.setText("RUN // " + (runnerIndex + 1) + "/" + runnerSteps.length() + " // " + type);
        telemetry.addFlow("SCRIPT_" + type.toUpperCase(Locale.US), "step " + (runnerIndex + 1), webView.getUrl());

        if ("open".equals(type)) {
            String url = step.optString("url", "");
            if (!(url.startsWith("http://") || url.startsWith("https://"))) { failAutomation("open requires http(s) url"); return; }
            runnerIndex++;
            runnerNavigationPending = true;
            runnerToken++;
            webView.loadUrl(url);
            return;
        }
        if ("reload".equals(type)) {
            runnerIndex++; runnerNavigationPending = true; runnerToken++; webView.reload(); return;
        }
        if ("back".equals(type)) {
            if (!webView.canGoBack()) { failAutomation("cannot go back"); return; }
            runnerIndex++; runnerNavigationPending = true; runnerToken++; webView.goBack(); return;
        }
        if ("forward".equals(type)) {
            if (!webView.canGoForward()) { failAutomation("cannot go forward"); return; }
            runnerIndex++; runnerNavigationPending = true; runnerToken++; webView.goForward(); return;
        }
        if ("userAgent".equals(type)) {
            String ua = step.optString("value", "");
            webView.getSettings().setUserAgentString(ua.isEmpty() ? null : ua);
            automationStepSucceeded(80);
            return;
        }
        if ("setCookie".equals(type)) {
            String url = step.optString("url", webView.getUrl());
            String cookie = step.optString("value", "");
            if (url == null || cookie.isEmpty()) { failAutomation("setCookie requires url/value"); return; }
            CookieManager.getInstance().setCookie(url, cookie, value -> {
                CookieManager.getInstance().flush();
                if (Boolean.TRUE.equals(value)) automationStepSucceeded(80); else failAutomation("setCookie rejected");
            });
            return;
        }
        if ("clearCookies".equals(type)) {
            CookieManager.getInstance().removeAllCookies(value -> { CookieManager.getInstance().flush(); automationStepSucceeded(80); });
            return;
        }
        if ("download".equals(type)) {
            String url = step.optString("url", "");
            if (!(url.startsWith("http://") || url.startsWith("https://"))) { failAutomation("download requires http(s) url"); return; }
            String mime = step.optString("mime", "");
            String fileName = step.optString("fileName", URLUtil.guessFileName(url, null, mime));
            enqueueDownload(url, webView.getSettings().getUserAgentString(), mime, fileName);
            automationStepSucceeded(100);
            return;
        }
        if ("assertUrl".equals(type)) {
            String contains = step.optString("contains", "");
            String current = safeUrl(webView.getUrl());
            if (!current.contains(contains)) { failAutomation("assertUrl failed; current=" + current); return; }
            automationStepSucceeded(50);
            return;
        }
        if ("waitUrl".equals(type)) {
            waitForDeadline = System.currentTimeMillis() + Math.max(250, Math.min(120000, step.optLong("timeoutMs", 10000)));
            pollWaitUrl(step.optString("contains", ""));
            return;
        }
        if ("wait".equals(type)) {
            long ms = Math.max(0, Math.min(120000, step.optLong("ms", 1000)));
            automationStepSucceeded(ms);
            return;
        }
        if ("waitFor".equals(type)) {
            waitForDeadline = System.currentTimeMillis() + Math.max(250, Math.min(120000, step.optLong("timeoutMs", 10000)));
            pollWaitFor(step.optString("selector", ""));
            return;
        }
        if ("assertExists".equals(type)) {
            automation.selectorExists(step.optString("selector", ""), new AutomationEngine.JsonCallback() {
                @Override public void onResult(JSONObject value) {
                    if (value.optBoolean("ok") && value.optBoolean("exists")) automationStepSucceeded(80);
                    else failAutomation("assertExists failed: " + step.optString("selector"));
                }
                @Override public void onError(String error) { failAutomation(error); }
            });
            return;
        }
        if ("assertText".equals(type) || "extractText".equals(type) || "extractValue".equals(type)) {
            automation.inspectSelector(step.optString("selector", ""), new AutomationEngine.JsonCallback() {
                @Override public void onResult(JSONObject value) {
                    if (!value.optBoolean("ok")) { failAutomation(value.optString("error", "selector inspection failed")); return; }
                    if ("assertText".equals(type)) {
                        String actual = value.optString("text", "");
                        String expected = step.optString("contains", "");
                        if (!actual.contains(expected)) { failAutomation("assertText failed; expected contains: " + expected); return; }
                    } else {
                        String storeAs = step.optString("storeAs", "").trim();
                        if (storeAs.isEmpty()) { failAutomation(type + " requires storeAs"); return; }
                        runnerVars.put(storeAs, "extractValue".equals(type) ? value.optString("value", "") : value.optString("text", ""));
                    }
                    automationStepSucceeded(80);
                }
                @Override public void onError(String error) { failAutomation(error); }
            });
            return;
        }

        automation.performDomStep(step, new AutomationEngine.JsonCallback() {
            @Override public void onResult(JSONObject value) {
                if (!value.optBoolean("ok", false)) { failAutomation(value.optString("error", "step failed")); return; }
                String storeAs = step.optString("storeAs", "").trim();
                if (!storeAs.isEmpty() && value.has("result")) runnerVars.put(storeAs, value.optString("result", ""));
                automationStepSucceeded("click".equals(type) || "submit".equals(type) ? 500 : 100);
            }
            @Override public void onError(String error) { failAutomation(error); }
        });
    }

    private void pollWaitUrl(String contains) {
        if (!runnerActive) return;
        String current = safeUrl(webView.getUrl());
        if (current.contains(contains)) { automationStepSucceeded(50); return; }
        if (System.currentTimeMillis() >= waitForDeadline) { failAutomation("waitUrl timeout: " + contains); return; }
        handler.postDelayed(() -> pollWaitUrl(contains), 250);
    }

    private void pollWaitFor(String selector) {
        if (!runnerActive) return;
        if (selector == null || selector.isEmpty()) { failAutomation("waitFor selector is required"); return; }
        automation.selectorExists(selector, new AutomationEngine.JsonCallback() {
            @Override public void onResult(JSONObject value) {
                if (!runnerActive) return;
                if (value.optBoolean("ok") && value.optBoolean("exists")) { automationStepSucceeded(80); return; }
                if (System.currentTimeMillis() >= waitForDeadline) { failAutomation("waitFor timeout: " + selector); return; }
                handler.postDelayed(() -> pollWaitFor(selector), 250);
            }
            @Override public void onError(String error) {
                if (System.currentTimeMillis() >= waitForDeadline) failAutomation(error);
                else handler.postDelayed(() -> pollWaitFor(selector), 250);
            }
        });
    }

    private void automationStepSucceeded(long delayMs) {
        runnerIndex++;
        int token = ++runnerToken;
        handler.postDelayed(() -> {
            if (runnerActive && !runnerNavigationPending && token == runnerToken) runNextAutomationStep();
        }, delayMs);
    }

    private void resumeRunnerAfterNavigation() {
        if (runnerActive && !runnerNavigationPending) runNextAutomationStep();
    }

    private void finishAutomation() {
        runnerActive = false;
        runnerNavigationPending = false;
        runnerToken++;
        setState("READY", Color.rgb(74, 222, 128));
        telemetry.addFlow("SCRIPT_DONE", runnerSteps.length() + " steps", webView.getUrl());
        footerText.setText("AUTOMATE // completed " + runnerSteps.length() + " steps // vars=" + runnerVars.size());
        toast("Automation selesai.");
    }

    private void failAutomation(String error) {
        runnerActive = false;
        runnerNavigationPending = false;
        runnerToken++;
        setState("SCRIPT ERROR", Color.rgb(251, 113, 133));
        telemetry.addFlow("SCRIPT_ERROR", clip(error, 180), webView.getUrl());
        footerText.setText("SCRIPT ERROR // " + error);
        toast("Automation berhenti: " + error);
    }

    private void stopAutomation(String reason) {
        if (!runnerActive) return;
        runnerActive = false;
        runnerNavigationPending = false;
        runnerToken++;
        setState("READY", Color.rgb(74, 222, 128));
        telemetry.addFlow("SCRIPT_STOP", reason, webView.getUrl());
        footerText.setText("AUTOMATE // " + reason);
    }

    private void requestScreenshot() {
        if (isBlankPage()) { toast("Tiada halaman untuk capture."); return; }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE, "devscope-viewport-" + fileTime.format(new Date()) + ".png");
        startActivityForResult(intent, REQ_SCREENSHOT);
    }

    private void saveScreenshotTo(Uri destination) {
        try {
            int width = webView.getWidth();
            int height = webView.getHeight();
            if (width <= 0 || height <= 0) throw new Exception("WebView has no drawable viewport");
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            webView.draw(canvas);
            try (OutputStream out = getContentResolver().openOutputStream(destination)) {
                if (out == null) throw new Exception("Destination stream unavailable");
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new Exception("PNG encoder failed");
                out.flush();
            }
            bitmap.recycle();
            telemetry.addFlow("SCREENSHOT", width + "x" + height, webView.getUrl());
            toast("Viewport PNG disimpan.");
        } catch (Exception e) {
            toast("Screenshot gagal: " + e.getMessage());
        }
    }

    private void printCurrentPage() {
        if (isBlankPage()) { toast("Tiada halaman untuk print."); return; }
        try {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            String jobName = "DevScope-" + hostOf(webView.getUrl());
            printManager.print(jobName, webView.createPrintDocumentAdapter(jobName), null);
            telemetry.addFlow("PRINT_PDF", "system print dialog", webView.getUrl());
        } catch (Exception e) {
            toast("Print/PDF tidak tersedia: " + e.getMessage());
        }
    }

    private void inspectPageSummary(boolean addTrace) {
        if (isBlankPage()) return;
        inspector.pageSummary(new InspectorEngine.JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                int dom = object.optInt("dom");
                int res = object.optInt("resources");
                domMetricText.setText("DOM " + dom);
                resourceMetricText.setText("RES " + res);
                netMetricText.setText("REQ " + telemetry.networkCount());
                consoleMetricText.setText("CON " + telemetry.consoleCount());
                if (addTrace) telemetry.addFlow("DOM_STATE", object.optString("ready") + " nodes=" + dom + " resources=" + res, object.optString("url"));
                scheduleTelemetryRefresh();
            }

            @Override
            public void onError(String error) {
                domMetricText.setText("DOM ?");
            }
        });
    }

    private void scheduleTelemetryRefresh() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post(this::scheduleTelemetryRefresh);
            return;
        }
        if (telemetryRefreshPending) return;
        telemetryRefreshPending = true;
        handler.postDelayed(() -> {
            telemetryRefreshPending = false;
            netMetricText.setText("REQ " + telemetry.networkCount());
            consoleMetricText.setText("CON " + telemetry.consoleCount());
            if (TAB_FLOW.equals(currentTab)) renderFlow();
            else if (TAB_CONSOLE.equals(currentTab)) renderConsole();
            else if (TAB_NETWORK.equals(currentTab)) renderNetwork(lastPerformance);
        }, 180);
    }

    private void requestExportText() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        boolean script = TAB_SCRIPT.equals(currentTab);
        boolean code = TAB_CODE.equals(currentTab);
        String suffix;
        if (script) {
            ScriptLanguageDetector.Result d = ScriptLanguageDetector.detect(currentOutput(), importedScriptName);
            suffix = d.kind == ScriptLanguageDetector.Kind.ACTION_SCRIPT ? ".json" : (d.extension.isEmpty() ? ".txt" : d.extension);
            intent.setType(d.kind == ScriptLanguageDetector.Kind.ACTION_SCRIPT ? "application/json" : "text/plain");
        } else {
            intent.setType("text/plain");
            suffix = code && generatedCodeProject != null ? generatedCodeProject.extension : ".txt";
        }
        intent.putExtra(Intent.EXTRA_TITLE, "devscope-" + currentTab.toLowerCase(Locale.US) + "-" + fileTime.format(new Date()) + suffix);
        startActivityForResult(intent, REQ_EXPORT_TEXT);
    }

    private void copyCurrentOutput() {
        String text = currentOutput();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("DevScope " + currentTab, text));
        toast("Copied " + text.length() + " chars");
    }

    private String currentOutput() {
        if (TAB_FLOW.equals(currentTab)) return formatFlowText(telemetry.flowSnapshot());
        if (TAB_SCRIPT.equals(currentTab)) return scriptEditor.getText() == null ? "" : scriptEditor.getText().toString();
        if (TAB_CODE.equals(currentTab)) return codeEditor.getText() == null ? "" : codeEditor.getText().toString();
        return outputText.getText() == null ? "" : outputText.getText().toString();
    }

    private void requestSaveMhtml() {
        if (isBlankPage()) {
            toast("Tiada halaman untuk disimpan.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("multipart/related");
        intent.putExtra(Intent.EXTRA_TITLE, "devscope-page-" + fileTime.format(new Date()) + ".mht");
        startActivityForResult(intent, REQ_SAVE_MHTML);
    }

    private void saveMhtmlTo(Uri destination) {
        File target = new File(getCacheDir(), "devscope-" + System.currentTimeMillis() + ".mht");
        webView.saveWebArchive(target.getAbsolutePath(), false, savedPath -> {
            if (savedPath == null) {
                toast("MHTML gagal dijana.");
                return;
            }
            try (FileInputStream in = new FileInputStream(savedPath);
                 OutputStream out = getContentResolver().openOutputStream(destination)) {
                if (out == null) throw new Exception("Destination stream unavailable");
                byte[] buffer = new byte[32 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
                telemetry.addFlow("MHTML_SAVE", new File(savedPath).length() + " bytes", webView.getUrl());
                toast("MHTML disimpan.");
            } catch (Exception e) {
                toast("MHTML export error: " + e.getMessage());
            } finally {
                new File(savedPath).delete();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            if (fileChooserCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_SCRIPT) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8))) {
                if (in == null) throw new Exception("Input stream unavailable");
                StringBuilder text = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) text.append(line).append('\n');
                importedScriptName = displayName(uri);
                String raw = text.toString();
                ScriptLanguageDetector.Result detected = ScriptLanguageDetector.detect(raw, importedScriptName);
                if (detected.kind == ScriptLanguageDetector.Kind.ACTION_SCRIPT) {
                    JSONObject root = new JSONObject(raw);
                    scriptEditor.setText(root.toString(2));
                    prefs.edit().putString("saved_script", root.toString(2)).apply();
                } else {
                    scriptEditor.setText(raw);
                }
                prefs.edit().putString("saved_script", scriptEditor.getText().toString()).putString("saved_script_name", importedScriptName).apply();
                selectTab(TAB_SCRIPT);
                footerText.setText("AUTOMATE // detected " + detected.label() + " // confidence=" + detected.confidence + "%");
                toast("Imported: " + detected.label());
            } catch (Exception e) {
                toast("Import script gagal: " + e.getMessage());
            }
        } else if (requestCode == REQ_SCREENSHOT) {
            pendingScreenshotUri = uri;
            saveScreenshotTo(pendingScreenshotUri);
        } else if (requestCode == REQ_EXPORT_CODE) {
            exportGeneratedCodeTo(uri);
        } else if (requestCode == REQ_EXPORT_CODE_PROJECT) {
            exportGeneratedProjectTo(uri);
        } else if (requestCode == REQ_EXPORT_BOOTSTRAP) {
            exportBootstrapTo(uri);
        } else if (requestCode == REQ_EXPORT_TEXT) {
            pendingExportUri = uri;
            try (OutputStream out = getContentResolver().openOutputStream(pendingExportUri)) {
                if (out == null) throw new Exception("Destination stream unavailable");
                byte[] bytes = currentOutput().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                out.write(bytes);
                out.flush();
                toast("Exported " + bytes.length + " bytes");
            } catch (Exception e) {
                toast("Export error: " + e.getMessage());
            }
        } else if (requestCode == REQ_SAVE_MHTML) {
            pendingMhtmlUri = uri;
            saveMhtmlTo(pendingMhtmlUri);
        }
    }

    private String displayName(Uri uri) {
        if (uri == null) return "";
        try (Cursor c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (i >= 0) return c.getString(i); }
        } catch (Exception ignored) {}
        return uri.getLastPathSegment() == null ? "" : uri.getLastPathSegment();
    }

    private String formatFlowText(List<TelemetryStore.FlowEvent> events) {
        StringBuilder out = new StringBuilder("TRACE // DevScope event stream\n\n");
        if (events.isEmpty()) return out.append("No events.\n").toString();
        long base = events.get(0).timeMs;
        for (TelemetryStore.FlowEvent e : events) {
            out.append('[').append(timeFormat.format(new Date(e.timeMs))).append("] +")
                    .append(e.timeMs - base).append("ms #").append(e.seq).append(' ')
                    .append(e.type).append("  ").append(e.detail);
            if (!e.url.isEmpty()) out.append("\n    ").append(e.url);
            out.append('\n');
        }
        return out.toString();
    }

    private void setState(String state, int color) {
        stateText.setText(state);
        stateText.setTextColor(color);
    }

    private boolean isBlankPage() {
        String url = webView.getUrl();
        return url == null || url.isEmpty() || "about:blank".equals(url);
    }

    private String pretty(JSONObject object) {
        if (object == null) return "{}";
        try {
            return object.toString(2);
        } catch (org.json.JSONException e) {
            // Pretty-printing is optional; compact JSON remains valid and preserves the data.
            return object.toString();
        }
    }

    private String hostOf(String url) {
        try {
            Uri uri = Uri.parse(url);
            return uri.getHost() == null ? safeUrl(url) : uri.getHost();
        } catch (Exception e) {
            return safeUrl(url);
        }
    }

    private String safeUrl(String url) {
        return url == null || url.isEmpty() ? "about:blank" : url;
    }

    private String resourceKind(String url, Map<String, String> headers) {
        String lower = url == null ? "" : url.toLowerCase(Locale.US);
        String accept = "";
        if (headers != null) {
            for (Map.Entry<String, String> h : headers.entrySet()) {
                if ("accept".equalsIgnoreCase(h.getKey())) {
                    accept = h.getValue() == null ? "" : h.getValue().toLowerCase(Locale.US);
                    break;
                }
            }
        }
        if (accept.contains("text/html")) return "document";
        if (accept.contains("application/json")) return "json/api";
        if (accept.contains("text/css") || lower.matches(".*\\.css([?#].*)?$")) return "stylesheet";
        if (accept.contains("javascript") || lower.matches(".*\\.(js|mjs)([?#].*)?$")) return "script";
        if (accept.startsWith("image/") || lower.matches(".*\\.(png|jpe?g|gif|webp|svg|ico)([?#].*)?$")) return "image";
        if (lower.matches(".*\\.(woff2?|ttf|otf)([?#].*)?$")) return "font";
        if (lower.matches(".*\\.(mp4|webm|mp3|m4a|ogg)([?#].*)?$")) return "media";
        if (lower.startsWith("ws:") || lower.startsWith("wss:")) return "websocket";
        return "resource";
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 B";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0));
    }

    private String clip(String value, int max) {
        if (value == null) return "";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(1, max - 1)) + "…";
    }

    private String clipLarge(String value, int max) {
        if (value == null) return "null";
        if (value.length() <= max) return value;
        return value.substring(0, max) + "\n...[runtime result truncated at " + max + " chars]";
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pickerGeneration++;
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }
}
