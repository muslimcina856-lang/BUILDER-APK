package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Builds reproducible dependency bootstrap files for CodeProjectGenerator projects.
 * The Android app does not pretend to install desktop toolchains locally. Instead,
 * every exported project receives executable setup/verify scripts that install the
 * project's real language modules in the target environment and fail loudly when
 * the required external toolchain is unavailable.
 */
public final class DependencyBootstrapEngine {
    private DependencyBootstrapEngine() {}

    public static final class Plan {
        public final String target;
        public final String engine;
        public final String runtime;
        public final List<String> requiredTools;
        public final List<String> manifests;
        public final String installCommand;
        public final String verifyCommand;
        public final boolean externalToolchainRequired;
        public final LinkedHashMap<String, String> bootstrapFiles;

        Plan(String target, String engine, String runtime, List<String> requiredTools,
             List<String> manifests, String installCommand, String verifyCommand,
             boolean externalToolchainRequired, LinkedHashMap<String, String> bootstrapFiles) {
            this.target = target;
            this.engine = engine;
            this.runtime = runtime;
            this.requiredTools = requiredTools;
            this.manifests = manifests;
            this.installCommand = installCommand;
            this.verifyCommand = verifyCommand;
            this.externalToolchainRequired = externalToolchainRequired;
            this.bootstrapFiles = bootstrapFiles;
        }
    }

    public static Plan attach(CodeProjectGenerator.GeneratedProject project) throws Exception {
        if (project == null) throw new IllegalArgumentException("Generated project is required");
        Plan plan = create(project);
        for (Map.Entry<String, String> e : plan.bootstrapFiles.entrySet()) {
            project.files.put(e.getKey(), e.getValue());
        }
        return plan;
    }

    public static Plan create(CodeProjectGenerator.GeneratedProject project) throws Exception {
        String target = project.target;
        String runtime = runtimeName(target);
        List<String> tools = requiredTools(target);
        List<String> manifests = manifests(project);
        String install = installCommand(target);
        String verify = verifyCommand(target);

        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("devscope/setup.sh", setupSh(target, tools));
        files.put("devscope/verify.sh", verifySh(target));
        files.put("devscope/repair.sh", repairSh(target));
        files.put("devscope/install-toolchain.sh", installToolchainSh(target));
        files.put("devscope/setup.ps1", setupPs1(target, tools));
        files.put("devscope/verify.ps1", verifyPs1(target));
        files.put("devscope/repair.ps1", repairPs1(target));
        files.put("devscope/install-toolchain.ps1", installToolchainPs1(target));
        files.put("devscope/env.example", envExample(project));
        files.put("devscope/bootstrap.json", bootstrapJson(project, runtime, tools, manifests, install, verify).toString(2));
        files.put("devscope/DEPENDENCIES.md", dependenciesReadme(project, runtime, tools, manifests, install, verify));

        return new Plan(target, project.engine, runtime, tools, manifests, install, verify, true, files);
    }

    public static String renderReport(Plan plan, CodeProjectGenerator.GeneratedProject project) {
        StringBuilder b = new StringBuilder();
        b.append("DEPENDENCY BOOTSTRAP // REAL PROJECT\n\n");
        b.append("target             ").append(plan.target).append('\n');
        b.append("engine             ").append(plan.engine).append('\n');
        b.append("runtime/toolchain  ").append(plan.runtime).append('\n');
        b.append("execution          EXTERNAL TOOLCHAIN REQUIRED\n");
        b.append("android behavior   generate + verify bundle metadata; no fake local install\n\n");
        b.append("REQUIRED TOOLS\n");
        for (String t : plan.requiredTools) b.append("  + ").append(t).append('\n');
        b.append("\nMANIFESTS\n");
        if (plan.manifests.isEmpty()) b.append("  none\n");
        else for (String m : plan.manifests) b.append("  + ").append(m).append('\n');
        b.append("\nAUTO MODULE INSTALL\n  ").append(plan.installCommand).append('\n');
        b.append("\nVERIFY / COMPILE\n  ").append(plan.verifyCommand).append('\n');
        b.append("\nBOOTSTRAP FILES\n");
        for (String name : plan.bootstrapFiles.keySet()) b.append("  + ").append(name).append('\n');
        b.append("\nONE COMMAND\n");
        b.append("  Linux/macOS/Termux:  DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1 sh devscope/setup.sh\n");
        b.append("  Windows PowerShell:   $env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN='1'; ./devscope/setup.ps1\n");
        b.append("\nPROJECT FILES          ").append(project.files.size()).append('\n');
        b.append("BOOTSTRAP FILES        ").append(plan.bootstrapFiles.size()).append('\n');
        b.append("\nNOTE\n");
        b.append("The setup scripts install language modules using the target package manager.\n");
        b.append("repair.sh/repair.ps1 can clear broken build/module state and rerun setup + verification.\n");
        b.append("If the runtime/compiler is missing they can invoke the generated toolchain installer\n");
        b.append("when DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1. Unsupported host/package-manager paths fail\n");
        b.append("with a real error instead of reporting a fake READY state.\n");
        return b.toString();
    }

    public static void verifyBundle(CodeProjectGenerator.GeneratedProject project, Plan plan) throws Exception {
        if (project == null || plan == null) throw new IllegalArgumentException("Generate a project first");
        for (String file : plan.manifests) {
            if (!project.files.containsKey(file)) throw new IllegalStateException("Missing dependency manifest: " + file);
            String text = project.files.get(file);
            if (text == null || text.trim().isEmpty()) throw new IllegalStateException("Empty dependency manifest: " + file);
        }
        for (String file : plan.bootstrapFiles.keySet()) {
            if (!project.files.containsKey(file)) throw new IllegalStateException("Missing bootstrap file: " + file);
            String text = project.files.get(file);
            if (text == null || text.trim().isEmpty()) throw new IllegalStateException("Empty bootstrap file: " + file);
        }
        if (!project.files.containsKey(project.mainFile)) throw new IllegalStateException("Missing main source: " + project.mainFile);
        if (!project.files.containsKey("flow.json")) throw new IllegalStateException("Missing flow.json");
        if (!project.files.containsKey("devscope-project.json")) throw new IllegalStateException("Missing devscope-project.json");
    }

    private static List<String> manifests(CodeProjectGenerator.GeneratedProject project) {
        String[] candidates = {"requirements.txt", "package.json", "pom.xml", "build.gradle.kts", "DevScopeGenerated.csproj", "go.mod", "CMakeLists.txt", "Cargo.toml", "Gemfile", "composer.json"};
        ArrayList<String> out = new ArrayList<>();
        for (String c : candidates) if (project.files.containsKey(c)) out.add(c);
        return out;
    }

    private static boolean isPython(String t) { return t != null && t.startsWith("Python /"); }
    private static boolean isJavaScript(String t) { return t != null && t.startsWith("JavaScript /"); }
    private static boolean isTypeScript(String t) { return t != null && t.startsWith("TypeScript /"); }
    private static boolean isNode(String t) { return isJavaScript(t) || isTypeScript(t); }
    private static boolean isJava(String t) { return t != null && t.startsWith("Java /"); }
    private static boolean isCsharp(String t) { return t != null && t.startsWith("C# (C+) /"); }
    private static boolean isPlaywright(String t) { return t != null && t.endsWith("/ Playwright"); }
    private static boolean isPuppeteer(String t) { return t != null && t.endsWith("/ Puppeteer"); }
    private static boolean isPyppeteer(String t) { return t != null && t.endsWith("/ Pyppeteer"); }
    private static boolean isWebdriverIo(String t) { return t != null && t.endsWith("/ WebdriverIO"); }
    private static boolean isCypress(String t) { return t != null && t.endsWith("/ Cypress"); }
    private static boolean isSelenide(String t) { return t != null && t.endsWith("/ Selenide"); }
    private static boolean isRod(String t) { return t != null && t.endsWith("/ Rod"); }
    private static boolean isFantoccini(String t) { return t != null && t.endsWith("/ Fantoccini"); }
    private static boolean isCapybara(String t) { return t != null && t.endsWith("/ Capybara"); }
    private static boolean isPanther(String t) { return t != null && t.endsWith("/ Symfony Panther"); }
    private static boolean isKotlin(String t) { return t != null && t.startsWith("Kotlin /"); }
    private static boolean isGo(String t) { return t != null && t.startsWith("Go /"); }
    private static boolean isRust(String t) { return t != null && t.startsWith("Rust /"); }
    private static boolean isRuby(String t) { return t != null && t.startsWith("Ruby /"); }
    private static boolean isPhp(String t) { return t != null && t.startsWith("PHP /"); }
    private static String pythonPackage(String t) { return isPlaywright(t) ? "playwright" : (isPyppeteer(t) ? "pyppeteer" : "selenium"); }
    private static String nodePackageName(String t) {
        if (isPlaywright(t)) return "playwright";
        if (isPuppeteer(t)) return "puppeteer";
        if (isWebdriverIo(t)) return "webdriverio";
        if (isCypress(t)) return "cypress";
        return "selenium-webdriver";
    }
    private static String jsMainFile(String t) {
        if (ExtraCodeProjectGenerator.JS_WEBDRIVERIO.equals(t)) return "bot.js";
        if (ExtraCodeProjectGenerator.JS_CYPRESS.equals(t)) return "cypress/e2e/bot.cy.js";
        return "main.js";
    }
    private static String rubyMainFile(String t) { return isCapybara(t) ? "bot.rb" : "main.rb"; }
    private static String phpMainFile(String t) { return isPanther(t) ? "bot.php" : "main.php"; }

    private static String runtimeName(String target) {
        if (isPython(target)) return "Python 3 + pip";
        if (isNode(target)) return "Node.js + npm";
        if (isJava(target)) return "JDK 17+ + Maven";
        if (isKotlin(target)) return "JDK 17+ + Gradle";
        if (isCsharp(target)) return ".NET SDK";
        if (isGo(target)) return "Go toolchain";
        if (CodeProjectGenerator.C.equals(target)) return "C compiler + CMake + libcurl";
        if (CodeProjectGenerator.CPP.equals(target)) return "C++17 compiler + CMake + libcurl";
        if (isRust(target)) return "Rust + Cargo";
        if (isRuby(target)) return "Ruby + Bundler";
        if (isPhp(target)) return "PHP + Composer";
        return "external toolchain";
    }

    private static List<String> requiredTools(String target) {
        ArrayList<String> out = new ArrayList<>();
        if (isPython(target)) { out.add("python3|python"); out.add("pip"); }
        else if (isNode(target)) { out.add("node"); out.add("npm"); }
        else if (isJava(target)) { out.add("java"); out.add("mvn"); }
        else if (isKotlin(target)) { out.add("java"); out.add("gradle"); }
        else if (isCsharp(target)) out.add("dotnet");
        else if (isGo(target)) out.add("go");
        else if (CodeProjectGenerator.C.equals(target)) { out.add("cc|clang|gcc"); out.add("cmake"); out.add("libcurl development package"); }
        else if (CodeProjectGenerator.CPP.equals(target)) { out.add("c++|clang++|g++"); out.add("cmake"); out.add("libcurl development package"); }
        else if (isRust(target)) { out.add("rustc"); out.add("cargo"); }
        else if (isRuby(target)) { out.add("ruby"); out.add("bundle"); }
        else if (isPhp(target)) { out.add("php"); out.add("composer"); }
        if (isPlaywright(target)) out.add("Playwright-managed Chromium (installed by generated setup script)");
        else if (isPuppeteer(target)) out.add("Puppeteer-managed Chromium (installed by npm package setup)");
        else out.add("Chrome/Chromium + compatible WebDriver where required by generated engine");
        return out;
    }

    private static String installCommand(String target) {
        if (isPython(target)) return isPlaywright(target) ? "python -m pip install -r requirements.txt && python -m playwright install chromium" : "python -m pip install -r requirements.txt";
        if (isNode(target)) return isPlaywright(target) ? "npm install && npx playwright install chromium" : "npm install";
        if (isJava(target)) return isPlaywright(target) ? "mvn -DskipTests dependency:go-offline && mvn -q exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args=\"install chromium\"" : "mvn -DskipTests dependency:go-offline";
        if (isKotlin(target)) return "gradle --no-daemon dependencies";
        if (isCsharp(target)) return isPlaywright(target) ? "dotnet restore && dotnet build" : "dotnet restore";
        if (isGo(target)) return "go mod download && go mod verify";
        if (CodeProjectGenerator.C.equals(target) || CodeProjectGenerator.CPP.equals(target)) return "cmake -S . -B build && cmake --build build";
        if (isRust(target)) return "cargo fetch";
        if (isRuby(target)) return "bundle install";
        if (isPhp(target)) return "composer install --no-interaction";
        return "unsupported target";
    }

    private static String verifyCommand(String target) {
        if (isPython(target)) return "python -m py_compile bot.py && python -c \"import " + pythonPackage(target) + "\"";
        if (isJavaScript(target)) {
            String pkg = nodePackageName(target);
            String base = "node --check " + jsMainFile(target) + " && node -e \"require.resolve('" + pkg + "')\"";
            return isCypress(target) ? base + " && npx cypress verify" : base;
        }
        if (isTypeScript(target)) return "npx tsc --noEmit";
        if (isJava(target)) return isSelenide(target) ? "mvn -DskipTests test-compile" : "mvn -DskipTests package";
        if (isKotlin(target)) return isSelenide(target) ? "gradle --no-daemon testClasses" : "gradle --no-daemon compileKotlin";
        if (isCsharp(target)) return "dotnet build --no-restore";
        if (isGo(target)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(target) || CodeProjectGenerator.CPP.equals(target)) return "cmake --build build";
        if (isRust(target)) return "cargo build";
        if (isRuby(target)) return "ruby -c " + rubyMainFile(target) + " && bundle check";
        if (isPhp(target)) return "php -l " + phpMainFile(target) + " && composer validate --no-check-publish";
        return "unsupported target";
    }

    private static String setupSh(String target, List<String> tools) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" +
                "echo '[DevScope] target: " + sh(target) + "'\n" +
                shellToolCheck(target) +
                "if [ \"${DEVSCOPE_AUTO_INSTALL_TOOLCHAIN:-0}\" = \"1\" ] && [ \"${DEVSCOPE_TOOLCHAIN_MISSING:-0}\" = \"1\" ]; then\n  sh devscope/install-toolchain.sh\nfi\n" +
                shellFinalToolCheck(target) +
                shellInstall(target) +
                "echo '[DevScope] module installation complete'\nsh devscope/verify.sh\n";
    }

    private static String verifySh(String target) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" + shellVerify(target) + "\necho '[DevScope] verification complete'\n";
    }


    private static String repairSh(String target) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" + shellRepair(target) + "\nsh devscope/setup.sh\n";
    }

    private static String installToolchainSh(String target) {
        String apt = aptPackages(target), brew = brewPackages(target), pkg = termuxPackages(target);
        return "#!/usr/bin/env sh\nset -eu\n" +
                "echo '[DevScope] attempting host toolchain install for " + sh(target) + "'\n" +
                "if command -v pkg >/dev/null 2>&1; then pkg update -y; pkg install -y " + pkg + "; exit 0; fi\n" +
                "if command -v apt-get >/dev/null 2>&1; then SUDO=''; if [ \"$(id -u)\" != 0 ]; then command -v sudo >/dev/null 2>&1 || { echo 'sudo/root required for apt'; exit 31; }; SUDO=sudo; fi; $SUDO apt-get update; $SUDO apt-get install -y " + apt + "; exit 0; fi\n" +
                "if command -v brew >/dev/null 2>&1; then brew install " + brew + "; exit 0; fi\n" +
                "echo 'No supported package manager found (Termux pkg, apt-get, Homebrew).' >&2\nexit 32\n";
    }

    private static String setupPs1(String target, List<String> tools) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" +
                "Write-Host '[DevScope] target: " + ps(target) + "'\n" +
                powerShellToolCheck(target) +
                "if ($env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN -eq '1' -and $script:MissingToolchain) { & (Join-Path $PSScriptRoot 'install-toolchain.ps1') }\n" +
                powerShellFinalToolCheck(target) +
                powerShellInstall(target) +
                "Write-Host '[DevScope] module installation complete'\n& (Join-Path $PSScriptRoot 'verify.ps1')\n";
    }

    private static String verifyPs1(String target) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" + powerShellVerify(target) + "\nWrite-Host '[DevScope] verification complete'\n";
    }


    private static String repairPs1(String target) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" + powerShellRepair(target) + "\n& (Join-Path $PSScriptRoot 'setup.ps1')\n";
    }

    private static String installToolchainPs1(String target) {
        String winget = wingetId(target);
        return "$ErrorActionPreference='Stop'\n" +
                "if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'winget not available; install the required toolchain manually.' }\n" +
                (winget.isEmpty()
                        ? "throw 'Automatic Windows toolchain install is not safely defined for this target. Install the compiler/runtime manually, then rerun setup.ps1.'\n"
                        : "winget install --id " + winget + " --exact --accept-package-agreements --accept-source-agreements\n") ;
    }

    private static String shellToolCheck(String t) {
        String check = shellCheckExpr(t);
        return "DEVSCOPE_TOOLCHAIN_MISSING=0\nif ! (" + check + "); then DEVSCOPE_TOOLCHAIN_MISSING=1; export DEVSCOPE_TOOLCHAIN_MISSING; echo '[DevScope] toolchain missing'; fi\n";
    }

    private static String shellFinalToolCheck(String t) {
        return "if ! (" + shellCheckExpr(t) + "); then echo '[DevScope] required toolchain still unavailable' >&2; exit 33; fi\n";
    }

    private static String shellCheckExpr(String t) {
        if (isPython(t)) return "command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1";
        if (isNode(t)) return "command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1";
        if (isJava(t)) return "command -v java >/dev/null 2>&1 && command -v mvn >/dev/null 2>&1";
        if (isKotlin(t)) return "command -v java >/dev/null 2>&1 && command -v gradle >/dev/null 2>&1";
        if (isCsharp(t)) return "command -v dotnet >/dev/null 2>&1";
        if (isGo(t)) return "command -v go >/dev/null 2>&1";
        if (CodeProjectGenerator.C.equals(t)) return "(command -v cc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1 || command -v gcc >/dev/null 2>&1) && command -v cmake >/dev/null 2>&1";
        if (CodeProjectGenerator.CPP.equals(t)) return "(command -v c++ >/dev/null 2>&1 || command -v clang++ >/dev/null 2>&1 || command -v g++ >/dev/null 2>&1) && command -v cmake >/dev/null 2>&1";
        if (isRust(t)) return "command -v rustc >/dev/null 2>&1 && command -v cargo >/dev/null 2>&1";
        if (isRuby(t)) return "command -v ruby >/dev/null 2>&1 && command -v bundle >/dev/null 2>&1";
        if (isPhp(t)) return "command -v php >/dev/null 2>&1 && command -v composer >/dev/null 2>&1";
        return "false";
    }

    private static String shellInstall(String t) {
        if (isPython(t)) {
            String browser = isPlaywright(t) ? "\n\"$PY\" -m playwright install chromium" : "";
            return "PY=$(command -v python3 || command -v python)\n\"$PY\" -m pip install --upgrade pip\n\"$PY\" -m pip install -r requirements.txt" + browser + "\n\"$PY\" -m pip freeze > devscope/requirements.lock.txt\n";
        }
        if (isNode(t)) {
            String browser = isPlaywright(t) ? "npx playwright install chromium\n" : "";
            return "npm install\n" + browser + "npm ls --all > devscope/npm-tree.txt || true\n";
        }
        if (isJava(t)) {
            String browser = isPlaywright(t) ? "mvn -q exec:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args='install chromium'\n" : "";
            return "mvn -q -DskipTests dependency:go-offline\n" + browser + "mvn -q dependency:tree -DoutputFile=devscope/maven-dependency-tree.txt\n";
        }
        if (isKotlin(t)) return "gradle --no-daemon dependencies > devscope/gradle-dependency-tree.txt\n";
        if (isCsharp(t)) {
            String browser = isPlaywright(t) ? "dotnet build\nif command -v pwsh >/dev/null 2>&1; then pwsh -NoProfile -File bin/Debug/net8.0/playwright.ps1 install chromium; else echo '[DevScope] pwsh required to install Playwright browser for C#' >&2; exit 36; fi\n" : "";
            return "dotnet restore\n" + browser;
        }
        if (isGo(t)) return "go mod download\ngo mod tidy\ngo mod verify\n";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake -S . -B build\ncmake --build build\n{ cmake --version; (cc --version 2>/dev/null || c++ --version 2>/dev/null || clang --version 2>/dev/null || true); (curl-config --version 2>/dev/null || true); } > devscope/toolchain-lock.txt\n";
        if (isRust(t)) return "cargo fetch\ncargo generate-lockfile\n";
        if (isRuby(t)) return "bundle install\nbundle lock\n";
        if (isPhp(t)) return "composer install --no-interaction --prefer-dist\n";
        return "echo 'unsupported target' >&2; exit 34\n";
    }

    private static String shellVerify(String t) {
        if (isPython(t)) return "PY=$(command -v python3 || command -v python)\n\"$PY\" -m py_compile bot.py\n\"$PY\" -c 'import " + pythonPackage(t) + "; print(\"" + pythonPackage(t) + " ok\")'";
        if (isJavaScript(t)) { String pkg=nodePackageName(t); String base="node --check " + jsMainFile(t) + "\nnode -e \"require.resolve('" + pkg + "'); console.log('" + pkg + " ok')\""; return isCypress(t) ? base + "\nnpx cypress verify" : base; }
        if (isTypeScript(t)) return "npx tsc --noEmit";
        if (isJava(t)) return isSelenide(t) ? "mvn -q -DskipTests test-compile" : "mvn -q -DskipTests package";
        if (isKotlin(t)) return isSelenide(t) ? "gradle --no-daemon testClasses" : "gradle --no-daemon compileKotlin";
        if (isCsharp(t)) return "dotnet build --no-restore";
        if (isGo(t)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake --build build";
        if (isRust(t)) return "cargo build";
        if (isRuby(t)) return "ruby -c " + rubyMainFile(t) + "\nbundle check";
        if (isPhp(t)) return "php -l " + phpMainFile(t) + "\ncomposer validate --no-check-publish";
        return "exit 35";
    }

    private static String powerShellToolCheck(String t) {
        return "$script:MissingToolchain = -not (" + psCheckExpr(t) + ")\nif ($script:MissingToolchain) { Write-Warning '[DevScope] toolchain missing' }\n";
    }

    private static String powerShellFinalToolCheck(String t) {
        return "if (-not (" + psCheckExpr(t) + ")) { throw '[DevScope] required toolchain still unavailable' }\n";
    }

    private static String psCheckExpr(String t) {
        if (isPython(t)) return "(Get-Command python -ErrorAction SilentlyContinue) -or (Get-Command py -ErrorAction SilentlyContinue)";
        if (isNode(t)) return "(Get-Command node -ErrorAction SilentlyContinue) -and (Get-Command npm -ErrorAction SilentlyContinue)";
        if (isJava(t)) return "(Get-Command java -ErrorAction SilentlyContinue) -and (Get-Command mvn -ErrorAction SilentlyContinue)";
        if (isKotlin(t)) return "(Get-Command java -ErrorAction SilentlyContinue) -and (Get-Command gradle -ErrorAction SilentlyContinue)";
        if (isCsharp(t)) return "Get-Command dotnet -ErrorAction SilentlyContinue";
        if (isGo(t)) return "Get-Command go -ErrorAction SilentlyContinue";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "Get-Command cmake -ErrorAction SilentlyContinue";
        if (isRust(t)) return "(Get-Command rustc -ErrorAction SilentlyContinue) -and (Get-Command cargo -ErrorAction SilentlyContinue)";
        if (isRuby(t)) return "(Get-Command ruby -ErrorAction SilentlyContinue) -and (Get-Command bundle -ErrorAction SilentlyContinue)";
        if (isPhp(t)) return "(Get-Command php -ErrorAction SilentlyContinue) -and (Get-Command composer -ErrorAction SilentlyContinue)";
        return "$false";
    }

    private static String powerShellInstall(String t) {
        if (isPython(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m pip install --upgrade pip\n& $Py -m pip install -r requirements.txt\n" + (isPlaywright(t) ? "& $Py -m playwright install chromium\n" : "") + "& $Py -m pip freeze | Set-Content devscope/requirements.lock.txt\n";
        if (isNode(t)) return "npm install\n" + (isPlaywright(t) ? "npx playwright install chromium\n" : "") + "npm ls --all | Set-Content devscope/npm-tree.txt\n";
        if (isJava(t)) return "mvn -q -DskipTests dependency:go-offline\n" + (isPlaywright(t) ? "mvn -q exec:java '-Dexec.mainClass=com.microsoft.playwright.CLI' '-Dexec.args=install chromium'\n" : "") + "mvn -q dependency:tree '-DoutputFile=devscope/maven-dependency-tree.txt'\n";
        if (isKotlin(t)) return "gradle --no-daemon dependencies | Set-Content devscope/gradle-dependency-tree.txt\n";
        if (isCsharp(t)) return "dotnet restore\n" + (isPlaywright(t) ? "dotnet build\n$Pw = Join-Path (Get-Location) 'bin/Debug/net8.0/playwright.ps1'\nif (-not (Test-Path $Pw)) { throw 'Playwright installer script not found after build' }\n& $Pw install chromium\n" : "");
        if (isGo(t)) return "go mod download\ngo mod tidy\ngo mod verify\n";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake -S . -B build\ncmake --build build\ncmake --version | Set-Content devscope/toolchain-lock.txt\n";
        if (isRust(t)) return "cargo fetch\ncargo generate-lockfile\n";
        if (isRuby(t)) return "bundle install\nbundle lock\n";
        if (isPhp(t)) return "composer install --no-interaction --prefer-dist\n";
        return "throw 'unsupported target'\n";
    }

    private static String powerShellVerify(String t) {
        if (isPython(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m py_compile bot.py\n& $Py -c \"import " + pythonPackage(t) + "; print('" + pythonPackage(t) + " ok')\"";
        if (isJavaScript(t)) { String pkg=nodePackageName(t); String base="node --check " + jsMainFile(t) + "\nnode -e \"require.resolve('" + pkg + "'); console.log('" + pkg + " ok')\""; return isCypress(t) ? base + "\nnpx cypress verify" : base; }
        if (isTypeScript(t)) return "npx tsc --noEmit";
        if (isJava(t)) return isSelenide(t) ? "mvn -q -DskipTests test-compile" : "mvn -q -DskipTests package";
        if (isKotlin(t)) return isSelenide(t) ? "gradle --no-daemon testClasses" : "gradle --no-daemon compileKotlin";
        if (isCsharp(t)) return "dotnet build --no-restore";
        if (isGo(t)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake --build build";
        if (isRust(t)) return "cargo build";
        if (isRuby(t)) return "ruby -c " + rubyMainFile(t) + "\nbundle check";
        if (isPhp(t)) return "php -l " + phpMainFile(t) + "\ncomposer validate --no-check-publish";
        return "throw 'unsupported target'";
    }

    private static String shellRepair(String t) {
        if (isPython(t)) return "PY=$(command -v python3 || command -v python || true)\n[ -n \"$PY\" ] && \"$PY\" -m pip install --force-reinstall -r requirements.txt || true";
        if (isNode(t)) return "rm -rf node_modules";
        if (isJava(t)) return "rm -rf target ~/.m2/repository/org/seleniumhq/selenium ~/.m2/repository/com/microsoft/playwright 2>/dev/null || true";
        if (isKotlin(t)) return "rm -rf build .gradle 2>/dev/null || true";
        if (isCsharp(t)) return "rm -rf bin obj 2>/dev/null || true";
        if (isGo(t)) return "go clean -cache 2>/dev/null || true";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "rm -rf build";
        if (isRust(t)) return "cargo clean 2>/dev/null || true";
        if (isRuby(t)) return "bundle clean --force 2>/dev/null || true";
        if (isPhp(t)) return "composer clear-cache 2>/dev/null || true";
        return "true";
    }

    private static String powerShellRepair(String t) {
        if (isPython(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m pip install --force-reinstall -r requirements.txt";
        if (isNode(t)) return "if (Test-Path node_modules) { Remove-Item node_modules -Recurse -Force }";
        if (isJava(t)) return "if (Test-Path target) { Remove-Item target -Recurse -Force }";
        if (isKotlin(t)) return "if (Test-Path build) { Remove-Item build -Recurse -Force }; if (Test-Path .gradle) { Remove-Item .gradle -Recurse -Force }";
        if (isCsharp(t)) return "foreach ($d in @('bin','obj')) { if (Test-Path $d) { Remove-Item $d -Recurse -Force } }";
        if (isGo(t)) return "go clean -cache";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "if (Test-Path build) { Remove-Item build -Recurse -Force }";
        if (isRust(t)) return "cargo clean";
        if (isRuby(t)) return "bundle clean --force";
        if (isPhp(t)) return "composer clear-cache";
        return "Write-Host 'nothing to repair'";
    }

    private static String aptPackages(String t) {
        if (isPython(t)) return "python3 python3-pip";
        if (isNode(t)) return "nodejs npm";
        if (isJava(t)) return "openjdk-17-jdk maven";
        if (isKotlin(t)) return "openjdk-17-jdk gradle";
        if (isCsharp(t)) return "dotnet-sdk-8.0";
        if (isGo(t)) return "golang-go";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "build-essential cmake libcurl4-openssl-dev";
        if (isRust(t)) return "rustc cargo";
        if (isRuby(t)) return "ruby ruby-dev bundler";
        if (isPhp(t)) return "php-cli composer";
        return "";
    }

    private static String brewPackages(String t) {
        if (isPython(t)) return "python";
        if (isNode(t)) return "node";
        if (isJava(t)) return "openjdk@17 maven";
        if (isKotlin(t)) return "openjdk@17 gradle";
        if (isCsharp(t)) return "dotnet";
        if (isGo(t)) return "go";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake curl";
        if (isRust(t)) return "rustup-init";
        if (isRuby(t)) return "ruby";
        if (isPhp(t)) return "php composer";
        return "";
    }

    private static String termuxPackages(String t) {
        if (isPython(t)) return "python";
        if (isNode(t)) return "nodejs";
        if (isJava(t)) return "openjdk-17 maven";
        if (isKotlin(t)) return "openjdk-17 gradle";
        if (isCsharp(t)) return "dotnet-sdk-8.0";
        if (isGo(t)) return "golang";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "clang cmake libcurl";
        if (isRust(t)) return "rust";
        if (isRuby(t)) return "ruby";
        if (isPhp(t)) return "php composer";
        return "";
    }

    private static String wingetId(String t) {
        if (isPython(t)) return "Python.Python.3.12";
        if (isNode(t)) return "OpenJS.NodeJS.LTS";
        if (isJava(t)) return "EclipseAdoptium.Temurin.17.JDK";
        if (isCsharp(t)) return "Microsoft.DotNet.SDK.8";
        if (isGo(t)) return "GoLang.Go";
        if (isRust(t)) return "Rustlang.Rustup";
        if (isPhp(t)) return "PHP.PHP";
        return "";
    }

    private static JSONObject bootstrapJson(CodeProjectGenerator.GeneratedProject p, String runtime, List<String> tools,
                                            List<String> manifests, String install, String verify) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "devscope-bootstrap-v1");
        root.put("target", p.target);
        root.put("engine", p.engine);
        root.put("runtime", runtime);
        root.put("externalToolchainRequired", true);
        root.put("requiredTools", new JSONArray(tools));
        root.put("manifests", new JSONArray(manifests));
        root.put("installCommand", install);
        root.put("verifyCommand", verify);
        root.put("autoInstallToolchainFlag", "DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1");
        root.put("generatedBy", "DevScope Android 4.2.0");
        return root;
    }

    private static String dependenciesReadme(CodeProjectGenerator.GeneratedProject p, String runtime, List<String> tools,
                                             List<String> manifests, String install, String verify) {
        StringBuilder b = new StringBuilder();
        b.append("# DevScope Dependency Bootstrap\n\n");
        b.append("Target: **").append(p.target).append("**  \nEngine: **").append(p.engine).append("**  \nRuntime: **").append(runtime).append("**\n\n");
        b.append("## One-command setup\n\n```sh\nDEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1 sh devscope/setup.sh\n```\n\n");
        b.append("Windows PowerShell:\n\n```powershell\n$env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN='1'\n./devscope/setup.ps1\n```\n\n");
        b.append("The setup script installs project modules with the real package manager and then executes the verify script. If a compiler/runtime is missing, the optional generated toolchain installer is invoked. Unsupported host setups fail explicitly.\n\n");
        b.append("## Required tools\n\n");
        for (String t : tools) b.append("- ").append(t).append('\n');
        b.append("\n## Dependency manifests\n\n");
        for (String m : manifests) b.append("- `").append(m).append("`\n");
        b.append("\nInstall: `").append(install).append("`  \nVerify: `").append(verify).append("`\n\n");
        b.append("## Android note\n\nDevScope is an Android application. It generates and validates these bootstrap files but does not claim that standard Android contains Python, Node, Go, Rust, .NET, desktop WebDriver, or C/C++ toolchains. Run the exported setup script in the target host/toolchain (including Termux where supported).\n");
        return b.toString();
    }

    private static String envExample(CodeProjectGenerator.GeneratedProject p) {
        StringBuilder out = new StringBuilder("# Copy to your preferred secret manager or shell environment.\n# Recorder secrets are never embedded in generated source.\n");
        try {
            JSONObject flow = new JSONObject(p.files.get("flow.json"));
            JSONArray steps = flow.optJSONArray("steps");
            if (steps != null) {
                for (int i = 0; i < steps.length(); i++) {
                    JSONObject s = steps.optJSONObject(i);
                    if (s == null) continue;
                    if (s.optBoolean("secret", false)) out.append("DEVSCOPE_SECRET_").append(i + 1).append("=\n");
                    if ("fileInput".equals(s.optString("type"))) out.append("DEVSCOPE_FILE_").append(i + 1).append("=\n");
                }
            }
        } catch (Exception ignored) {}
        out.append("WEBDRIVER_URL=http://127.0.0.1:9515\n");
        return out.toString();
    }

    private static String sh(String s) { return s.replace("'", "'\\''"); }
    private static String ps(String s) { return s.replace("'", "''"); }
}
