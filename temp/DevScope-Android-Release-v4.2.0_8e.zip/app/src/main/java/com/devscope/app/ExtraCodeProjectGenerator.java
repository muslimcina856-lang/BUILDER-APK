package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

/** Additional real browser-automation project targets exposed by CODEGEN. */
public final class ExtraCodeProjectGenerator {
    public static final String PYTHON_PYPPETEER = "Python / Pyppeteer";
    public static final String JS_WEBDRIVERIO = "JavaScript / WebdriverIO";
    public static final String TS_WEBDRIVERIO = "TypeScript / WebdriverIO";
    public static final String JS_CYPRESS = "JavaScript / Cypress";
    public static final String TS_CYPRESS = "TypeScript / Cypress";
    public static final String JAVA_SELENIDE = "Java / Selenide";
    public static final String KOTLIN_SELENIDE = "Kotlin / Selenide";
    public static final String GO_ROD = "Go / Rod";
    public static final String RUST_FANTOCCINI = "Rust / Fantoccini";
    public static final String RUBY_CAPYBARA = "Ruby / Capybara";
    public static final String PHP_PANTHER = "PHP / Symfony Panther";

    private static final Set<String> BASE = setOf(
            "open", "back", "forward", "reload", "click", "input", "content", "select", "check",
            "submit", "scroll", "focus", "wait", "waitFor", "waitUrl", "assertExists", "assertText",
            "assertUrl", "extractText", "extractValue", "setText", "setHtml", "setAttr", "removeAttr",
            "setStyle", "remove", "storageSet", "storageRemove", "js", "dispatch", "fileInput", "clearCookies"
    );

    private ExtraCodeProjectGenerator() {}

    public static boolean supports(String target) {
        return PYTHON_PYPPETEER.equals(target) || JS_WEBDRIVERIO.equals(target) || TS_WEBDRIVERIO.equals(target)
                || JS_CYPRESS.equals(target) || TS_CYPRESS.equals(target) || JAVA_SELENIDE.equals(target)
                || KOTLIN_SELENIDE.equals(target) || GO_ROD.equals(target) || RUST_FANTOCCINI.equals(target)
                || RUBY_CAPYBARA.equals(target) || PHP_PANTHER.equals(target);
    }

    public static CodeProjectGenerator.GeneratedProject generate(String target, JSONObject flow) throws Exception {
        JSONArray steps = flow.optJSONArray("steps");
        if (steps == null) throw new IllegalArgumentException("steps array is required");
        validate(target, steps);
        String ua = flow.optString("userAgent", "");
        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("flow.json", flow.toString(2));

        if (PYTHON_PYPPETEER.equals(target)) {
            files.put("requirements.txt", "pyppeteer>=2,<3\n");
            files.put("bot.py", pythonPyppeteer(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "bot.py", ".py", "Pyppeteer Chromium", files);
        }
        if (JS_WEBDRIVERIO.equals(target) || TS_WEBDRIVERIO.equals(target)) {
            boolean ts = TS_WEBDRIVERIO.equals(target);
            files.put("package.json", wdioPackage(ts));
            if (ts) files.put("tsconfig.json", tsConfig());
            files.put(ts ? "bot.ts" : "bot.js", webdriverIo(steps, ua, ts));
            return new CodeProjectGenerator.GeneratedProject(target, ts ? "bot.ts" : "bot.js", ts ? ".ts" : ".js", "WebdriverIO", files);
        }
        if (JS_CYPRESS.equals(target) || TS_CYPRESS.equals(target)) {
            boolean ts = TS_CYPRESS.equals(target);
            files.put("package.json", cypressPackage(ts));
            files.put("cypress.config." + (ts ? "ts" : "js"), cypressConfig(ts, ua));
            if (ts) files.put("tsconfig.json", tsConfig());
            String main = "cypress/e2e/bot.cy." + (ts ? "ts" : "js");
            files.put(main, cypress(steps));
            return new CodeProjectGenerator.GeneratedProject(target, main, ts ? ".ts" : ".js", "Cypress E2E", files);
        }
        if (JAVA_SELENIDE.equals(target)) {
            files.put("pom.xml", selenidePom());
            files.put("src/test/java/DevScopeGeneratedTest.java", javaSelenide(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "src/test/java/DevScopeGeneratedTest.java", ".java", "Selenide", files);
        }
        if (KOTLIN_SELENIDE.equals(target)) {
            files.put("settings.gradle.kts", "rootProject.name = \"devscope-selenide\"\n");
            files.put("build.gradle.kts", kotlinSelenideGradle());
            files.put("src/test/kotlin/DevScopeGeneratedTest.kt", kotlinSelenide(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "src/test/kotlin/DevScopeGeneratedTest.kt", ".kt", "Selenide", files);
        }
        if (GO_ROD.equals(target)) {
            files.put("go.mod", "module devscope-generated\n\ngo 1.22\n\nrequire github.com/go-rod/rod v0.116.2\n");
            files.put("main.go", goRod(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "main.go", ".go", "Rod CDP", files);
        }
        if (RUST_FANTOCCINI.equals(target)) {
            files.put("Cargo.toml", "[package]\nname=\"devscope-generated\"\nversion=\"0.1.0\"\nedition=\"2021\"\n\n[dependencies]\nfantoccini=\"0.22\"\ntokio={version=\"1\",features=[\"macros\",\"rt-multi-thread\",\"time\"]}\nserde_json=\"1\"\n");
            files.put("src/main.rs", rustFantoccini(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "src/main.rs", ".rs", "Fantoccini WebDriver", files);
        }
        if (RUBY_CAPYBARA.equals(target)) {
            files.put("Gemfile", "source 'https://rubygems.org'\ngem 'capybara', '~> 3.40'\ngem 'selenium-webdriver', '~> 4.0'\n");
            files.put("bot.rb", rubyCapybara(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "bot.rb", ".rb", "Capybara + Selenium", files);
        }
        if (PHP_PANTHER.equals(target)) {
            files.put("composer.json", "{\n  \"require\": {\"symfony/panther\": \"^2.2\"}\n}\n");
            files.put("bot.php", phpPanther(steps, ua));
            return new CodeProjectGenerator.GeneratedProject(target, "bot.php", ".php", "Symfony Panther", files);
        }
        throw new IllegalArgumentException("Unknown extra target: " + target);
    }

    private static void validate(String target, JSONArray steps) {
        LinkedHashSet<String> bad = new LinkedHashSet<>();
        for (int i = 0; i < steps.length(); i++) {
            JSONObject s = steps.optJSONObject(i);
            if (s == null) { bad.add("invalid step #" + (i + 1)); continue; }
            String t = s.optString("type", "");
            if (!BASE.contains(t)) bad.add(t.isEmpty() ? "missing type" : t);
            if ((JS_CYPRESS.equals(target) || TS_CYPRESS.equals(target)) &&
                    ("extractText".equals(t) || "extractValue".equals(t) || hasVariables(s))) {
                bad.add(t + " (Cypress generator does not serialize runtime variables across queued commands)");
            }
            if (GO_ROD.equals(target) && ("select".equals(t) || "fileInput".equals(t) || "clearCookies".equals(t))) {
                bad.add(t + " (Rod target)");
            }
        }
        if (!bad.isEmpty()) throw new IllegalArgumentException(target + " cannot faithfully generate: " + String.join(", ", bad));
    }

    private static boolean hasVariables(JSONObject s) {
        String[] keys = {"selector", "value", "url", "text", "contains", "code", "name", "key"};
        for (String key : keys) if (s.optString(key, "").contains("{{")) return true;
        return false;
    }

    private static String pythonPyppeteer(JSONArray steps, String ua) {
        StringBuilder b = new StringBuilder();
        b.append("import asyncio, os, re, time\nfrom pyppeteer import launch\n\nvars = {}\ndef r(v):\n    s=str(v)\n    return re.sub(r'\\{\\{([^}]+)\\}\\}', lambda m: vars.get(m.group(1), m.group(0)), s)\n\nasync def main():\n")
         .append("    browser = await launch(headless=False, args=['--no-sandbox'])\n    page = await browser.newPage()\n")
         .append("    await page.setUserAgent(").append(py(ua)).append(")\n    try:\n");
        for (int i = 0; i < steps.length(); i++) emitPyppeteer(b, steps.optJSONObject(i), i);
        b.append("        print('DEV//SCOPE PASS')\n    finally:\n        await browser.close()\n\nasyncio.run(main())\n");
        return b.toString();
    }

    private static void emitPyppeteer(StringBuilder b, JSONObject s, int i) {
        if (s == null) return;
        String p = "        "; String t = s.optString("type", ""); String sel = py(s.optString("selector", ""));
        b.append(p).append("# step ").append(i + 1).append(" // ").append(t).append('\n');
        switch (t) {
            case "open" -> b.append(p).append("await page.goto(r(").append(py(s.optString("url", ""))).append("), {'waitUntil':'domcontentloaded'})\n");
            case "back" -> b.append(p).append("await page.goBack()\n");
            case "forward" -> b.append(p).append("await page.goForward()\n");
            case "reload" -> b.append(p).append("await page.reload()\n");
            case "click" -> b.append(p).append("await page.click(r(").append(sel).append("))\n");
            case "input", "content" -> b.append(p).append("await page.focus(r(").append(sel).append(")); await page.evaluate('(s)=>document.querySelector(s).value=\\\"\\\"', r(").append(sel).append(")); await page.type(r(").append(sel).append("), r(").append(secretPy(s, i)).append("))\n");
            case "select" -> b.append(p).append("await page.select(r(").append(sel).append("), r(").append(py(s.optString("value", ""))).append("))\n");
            case "check" -> b.append(p).append("await page.evaluate('(p)=>{const e=document.querySelector(p.s); if(e){e.checked=p.v; e.dispatchEvent(new Event(\\\"change\\\",{bubbles:true}));}}', {'s':r(").append(sel).append("),'v':").append(s.optBoolean("checked", true)).append("})\n");
            case "submit" -> b.append(p).append("await page.evaluate('(s)=>{const e=document.querySelector(s); if(e) (e.requestSubmit?e.requestSubmit():e.submit())}', r(").append(sel).append("))\n");
            case "scroll" -> b.append(p).append("await page.evaluate('(p)=>window.scrollTo(p.x,p.y)', {'x':").append(s.optInt("x", 0)).append(",'y':").append(s.optInt("y", 0)).append("})\n");
            case "focus" -> b.append(p).append("await page.focus(r(").append(sel).append("))\n");
            case "wait" -> b.append(p).append("await asyncio.sleep(").append(Math.max(0, s.optLong("ms", 1000)) / 1000.0).append(")\n");
            case "waitFor" -> b.append(p).append("await page.waitForSelector(r(").append(sel).append("), {'timeout':").append(timeout(s)).append("})\n");
            case "waitUrl" -> b.append(p).append("_end=time.time()+").append(timeout(s) / 1000.0).append("\n").append(p).append("while r(").append(py(s.optString("contains", ""))).append(") not in page.url:\n").append(p).append("    if time.time()>_end: raise TimeoutError('URL wait timed out')\n").append(p).append("    await asyncio.sleep(.2)\n");
            case "assertExists" -> b.append(p).append("assert await page.querySelector(r(").append(sel).append(")) is not None, 'missing selector'\n");
            case "assertText" -> b.append(p).append("assert r(").append(py(expected(s))).append(") in await page.Jeval(r(").append(sel).append("), '(e)=>e.innerText'), 'text assertion failed'\n");
            case "assertUrl" -> b.append(p).append("assert r(").append(py(s.optString("contains", ""))).append(") in page.url, 'URL assertion failed'\n");
            case "extractText" -> b.append(p).append("vars[").append(py(storeAs(s))).append("] = await page.Jeval(r(").append(sel).append("), '(e)=>e.innerText')\n");
            case "extractValue" -> b.append(p).append("vars[").append(py(storeAs(s))).append("] = await page.Jeval(r(").append(sel).append("), '(e)=>e.value')\n");
            case "setText" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s).textContent=p.v', {'s':r(").append(sel).append("),'v':r(").append(py(s.optString("value", ""))).append(")})\n");
            case "setHtml" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s).innerHTML=p.v', {'s':r(").append(sel).append("),'v':r(").append(py(s.optString("value", ""))).append(")})\n");
            case "setAttr" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s).setAttribute(p.n,p.v)', {'s':r(").append(sel).append("),'n':").append(py(s.optString("name", ""))).append(",'v':r(").append(py(s.optString("value", ""))).append(")})\n");
            case "removeAttr" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s).removeAttribute(p.n)', {'s':r(").append(sel).append("),'n':").append(py(s.optString("name", ""))).append("})\n");
            case "setStyle" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s).style.setProperty(p.n,p.v)', {'s':r(").append(sel).append("),'n':").append(py(s.optString("name", ""))).append(",'v':r(").append(py(s.optString("value", ""))).append(")})\n");
            case "remove" -> b.append(p).append("await page.evaluate('(s)=>document.querySelector(s)?.remove()', r(").append(sel).append("))\n");
            case "storageSet" -> b.append(p).append("await page.evaluate('(p)=>window[p.a].setItem(p.k,p.v)', {'a':").append(py(storage(s))).append(",'k':").append(py(s.optString("key", ""))).append(",'v':r(").append(py(s.optString("value", ""))).append(")})\n");
            case "storageRemove" -> b.append(p).append("await page.evaluate('(p)=>window[p.a].removeItem(p.k)', {'a':").append(py(storage(s))).append(",'k':").append(py(s.optString("key", ""))).append("})\n");
            case "js" -> b.append(p).append("await page.evaluate(r(").append(py(s.optString("code", s.optString("value", "")))).append("))\n");
            case "dispatch" -> b.append(p).append("await page.evaluate('(p)=>document.querySelector(p.s)?.dispatchEvent(new Event(p.e,{bubbles:true}))', {'s':r(").append(sel).append("),'e':").append(py(s.optString("event", "change"))).append("})\n");
            case "fileInput" -> b.append(p).append("_el=await page.querySelector(r(").append(sel).append(")); await _el.uploadFile(os.environ[").append(py("DEVSCOPE_FILE_" + (i + 1))).append("])\n");
            case "clearCookies" -> b.append(p).append("await page.deleteCookie(*await page.cookies())\n");
            default -> throw new IllegalArgumentException("Pyppeteer unsupported action: " + t);
        }
    }

    private static String webdriverIo(JSONArray steps, String ua, boolean ts) {
        StringBuilder b = new StringBuilder();
        b.append("import { remote } from 'webdriverio'\n\nconst vars").append(ts ? ": Record<string,string>" : "").append(" = {}\nconst r=(v").append(ts ? ": any" : "").append(")=>String(v).replace(/\\{\\{([^}]+)\\}\\}/g,(_,k)=>vars[k]??`{{${k}}}`)\n")
         .append("const browser=await remote({logLevel:'error',capabilities:{browserName:'chrome','goog:chromeOptions':{args:[").append(js("--user-agent=" + ua)).append("]}}})\ntry {\n");
        for (int i = 0; i < steps.length(); i++) emitWdio(b, steps.optJSONObject(i), i);
        b.append("  console.log('DEV//SCOPE PASS')\n} finally { await browser.deleteSession() }\n");
        return b.toString();
    }

    private static void emitWdio(StringBuilder b, JSONObject s, int i) {
        if (s == null) return; String t=s.optString("type",""); String p="  "; String sel=js(s.optString("selector",""));
        b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t) {
            case "open" -> b.append(p).append("await browser.url(r(").append(js(s.optString("url",""))).append("))\n");
            case "back" -> b.append(p).append("await browser.back()\n");
            case "forward" -> b.append(p).append("await browser.forward()\n");
            case "reload" -> b.append(p).append("await browser.refresh()\n");
            case "click" -> b.append(p).append("await (await browser.$(r(").append(sel).append("))).click()\n");
            case "input", "content" -> b.append(p).append("await (await browser.$(r(").append(sel).append("))).setValue(r(").append(secretJs(s,i)).append("))\n");
            case "select" -> b.append(p).append("await (await browser.$(r(").append(sel).append("))).selectByAttribute('value',r(").append(js(s.optString("value",""))).append("))\n");
            case "check" -> b.append(p).append("{const e=await browser.$(r(").append(sel).append(")); const v=await e.isSelected(); if(v!==").append(s.optBoolean("checked",true)).append(") await e.click()}\n");
            case "submit" -> b.append(p).append("await browser.execute((s)=>{const e=document.querySelector(s); if(e) (e.requestSubmit?e.requestSubmit():e.submit())},r(").append(sel).append("))\n");
            case "scroll" -> b.append(p).append("await browser.execute((x,y)=>scrollTo(x,y),").append(s.optInt("x",0)).append(',').append(s.optInt("y",0)).append(")\n");
            case "focus" -> b.append(p).append("await browser.execute((s)=>document.querySelector(s)?.focus(),r(").append(sel).append("))\n");
            case "wait" -> b.append(p).append("await browser.pause(").append(Math.max(0,s.optLong("ms",1000))).append(")\n");
            case "waitFor" -> b.append(p).append("await (await browser.$(r(").append(sel).append("))).waitForExist({timeout:").append(timeout(s)).append("})\n");
            case "waitUrl" -> b.append(p).append("await browser.waitUntil(async()=>String(await browser.getUrl()).includes(r(").append(js(s.optString("contains",""))).append(")),{timeout:").append(timeout(s)).append("})\n");
            case "assertExists" -> b.append(p).append("if(!(await browser.$(r(").append(sel).append("))).isExisting()) throw new Error('missing selector')\n");
            case "assertText" -> b.append(p).append("if(!(await (await browser.$(r(").append(sel).append("))).getText()).includes(r(").append(js(expected(s))).append("))) throw new Error('text assertion failed')\n");
            case "assertUrl" -> b.append(p).append("if(!String(await browser.getUrl()).includes(r(").append(js(s.optString("contains",""))).append("))) throw new Error('URL assertion failed')\n");
            case "extractText" -> b.append(p).append("vars[").append(js(storeAs(s))).append("]=await (await browser.$(r(").append(sel).append("))).getText()\n");
            case "extractValue" -> b.append(p).append("vars[").append(js(storeAs(s))).append("]=String(await (await browser.$(r(").append(sel).append("))).getValue())\n");
            case "setText" -> b.append(p).append("await browser.execute((s,v)=>{const e=document.querySelector(s); if(e)e.textContent=v},r(").append(sel).append("),r(").append(js(s.optString("value",""))).append("))\n");
            case "setHtml" -> b.append(p).append("await browser.execute((s,v)=>{const e=document.querySelector(s); if(e)e.innerHTML=v},r(").append(sel).append("),r(").append(js(s.optString("value",""))).append("))\n");
            case "setAttr" -> b.append(p).append("await browser.execute((s,n,v)=>document.querySelector(s)?.setAttribute(n,v),r(").append(sel).append("),").append(js(s.optString("name",""))).append(",r(").append(js(s.optString("value",""))).append("))\n");
            case "removeAttr" -> b.append(p).append("await browser.execute((s,n)=>document.querySelector(s)?.removeAttribute(n),r(").append(sel).append("),").append(js(s.optString("name",""))).append(")\n");
            case "setStyle" -> b.append(p).append("await browser.execute((s,n,v)=>document.querySelector(s)?.style.setProperty(n,v),r(").append(sel).append("),").append(js(s.optString("name",""))).append(",r(").append(js(s.optString("value",""))).append("))\n");
            case "remove" -> b.append(p).append("await browser.execute((s)=>document.querySelector(s)?.remove(),r(").append(sel).append("))\n");
            case "storageSet" -> b.append(p).append("await browser.execute((a,k,v)=>window[a].setItem(k,v),").append(js(storage(s))).append(',').append(js(s.optString("key",""))).append(",r(").append(js(s.optString("value",""))).append("))\n");
            case "storageRemove" -> b.append(p).append("await browser.execute((a,k)=>window[a].removeItem(k),").append(js(storage(s))).append(',').append(js(s.optString("key",""))).append(")\n");
            case "js" -> b.append(p).append("await browser.execute(new Function(r(").append(js(s.optString("code",s.optString("value","")))).append(")))\n");
            case "dispatch" -> b.append(p).append("await browser.execute((s,e)=>document.querySelector(s)?.dispatchEvent(new Event(e,{bubbles:true})),r(").append(sel).append("),").append(js(s.optString("event","change"))).append(")\n");
            case "fileInput" -> b.append(p).append("await (await browser.$(r(").append(sel).append("))).setValue(process.env[").append(js("DEVSCOPE_FILE_"+(i+1))).append("]??'')\n");
            case "clearCookies" -> b.append(p).append("await browser.deleteCookies()\n");
            default -> throw new IllegalArgumentException("WebdriverIO unsupported action: "+t);
        }
    }

    private static String cypress(JSONArray steps) {
        StringBuilder b = new StringBuilder("describe('DevScope generated flow',()=>{\n  it('replays the recorded flow',()=>{\n");
        for (int i=0;i<steps.length();i++) emitCypress(b,steps.optJSONObject(i),i);
        b.append("  })\n})\n"); return b.toString();
    }

    private static void emitCypress(StringBuilder b, JSONObject s, int i) {
        if(s==null)return; String t=s.optString("type",""); String p="    "; String sel=js(s.optString("selector",""));
        b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("cy.visit(").append(js(s.optString("url",""))).append(")\n");
            case "back"->b.append(p).append("cy.go('back')\n"); case "forward"->b.append(p).append("cy.go('forward')\n"); case "reload"->b.append(p).append("cy.reload()\n");
            case "click"->b.append(p).append("cy.get(").append(sel).append(").first().click()\n");
            case "input","content"->b.append(p).append("cy.get(").append(sel).append(").first().clear().type(").append(s.optBoolean("secret",false)?"Cypress.env("+js("DEVSCOPE_SECRET_"+(i+1))+")":js(s.optString("value",""))).append(")\n");
            case "select"->b.append(p).append("cy.get(").append(sel).append(").first().select(").append(js(s.optString("value",""))).append(")\n");
            case "check"->b.append(p).append("cy.get(").append(sel).append(").first().").append(s.optBoolean("checked",true)?"check()":"uncheck()").append("\n");
            case "submit"->b.append(p).append("cy.get(").append(sel).append(").first().submit()\n");
            case "scroll"->b.append(p).append("cy.window().then(w=>w.scrollTo(").append(s.optInt("x",0)).append(',').append(s.optInt("y",0)).append("))\n");
            case "focus"->b.append(p).append("cy.get(").append(sel).append(").first().focus()\n");
            case "wait"->b.append(p).append("cy.wait(").append(Math.max(0,s.optLong("ms",1000))).append(")\n");
            case "waitFor","assertExists"->b.append(p).append("cy.get(").append(sel).append(", {timeout:").append(timeout(s)).append("}).should('exist')\n");
            case "waitUrl"->b.append(p).append("cy.url({timeout:").append(timeout(s)).append("}).should('include',").append(js(s.optString("contains",""))).append(")\n");
            case "assertText"->b.append(p).append("cy.get(").append(sel).append(").first().should('contain.text',").append(js(expected(s))).append(")\n");
            case "assertUrl"->b.append(p).append("cy.url().should('include',").append(js(s.optString("contains",""))).append(")\n");
            case "setText"->b.append(p).append("cy.get(").append(sel).append(").first().invoke('text',").append(js(s.optString("value",""))).append(")\n");
            case "setHtml"->b.append(p).append("cy.get(").append(sel).append(").first().invoke('html',").append(js(s.optString("value",""))).append(")\n");
            case "setAttr"->b.append(p).append("cy.get(").append(sel).append(").first().invoke('attr',").append(js(s.optString("name",""))).append(',').append(js(s.optString("value",""))).append(")\n");
            case "removeAttr"->b.append(p).append("cy.get(").append(sel).append(").first().invoke('removeAttr',").append(js(s.optString("name",""))).append(")\n");
            case "setStyle"->b.append(p).append("cy.get(").append(sel).append(").first().invoke('css',").append(js(s.optString("name",""))).append(',').append(js(s.optString("value",""))).append(")\n");
            case "remove"->b.append(p).append("cy.get(").append(sel).append(").first().then($e=>$e.remove())\n");
            case "storageSet"->b.append(p).append("cy.window().then(w=>w[").append(js(storage(s))).append("].setItem(").append(js(s.optString("key",""))).append(',').append(js(s.optString("value",""))).append("))\n");
            case "storageRemove"->b.append(p).append("cy.window().then(w=>w[").append(js(storage(s))).append("].removeItem(").append(js(s.optString("key",""))).append("))\n");
            case "js"->b.append(p).append("cy.window().then(w=>w.eval(").append(js(s.optString("code",s.optString("value","")))).append("))\n");
            case "dispatch"->b.append(p).append("cy.get(").append(sel).append(").first().trigger(").append(js(s.optString("event","change"))).append(")\n");
            case "fileInput"->b.append(p).append("cy.get(").append(sel).append(").first().selectFile(Cypress.env(").append(js("DEVSCOPE_FILE_"+(i+1))).append("))\n");
            case "clearCookies"->b.append(p).append("cy.clearCookies()\n");
            default->throw new IllegalArgumentException("Cypress unsupported action: "+t);
        }
    }

    private static String javaSelenide(JSONArray steps,String ua){
        StringBuilder b=new StringBuilder("import com.codeborne.selenide.*;\nimport org.junit.jupiter.api.*;\nimport java.util.*;\nimport static com.codeborne.selenide.Selenide.*;\nimport static com.codeborne.selenide.Condition.*;\n\npublic class DevScopeGeneratedTest {\n  final Map<String,String> vars=new HashMap<>();\n  String r(String s){for(var e:vars.entrySet())s=s.replace(\"{{\"+e.getKey()+\"}}\",e.getValue());return s;}\n  @Test void run() throws Exception {\n    Configuration.browser=\"chrome\"; Configuration.browserCapabilities.setCapability(\"goog:chromeOptions\",Map.of(\"args\",List.of(").append(j("--user-agent="+ua)).append(")));\n");
        for(int i=0;i<steps.length();i++)emitSelenideJava(b,steps.optJSONObject(i),i); b.append("    System.out.println(\"DEV//SCOPE PASS\");\n    closeWebDriver();\n  }\n}\n"); return b.toString();
    }
    private static void emitSelenideJava(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String p="    ";String sel=j(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){
        case"open"->b.append(p).append("open(r(").append(j(s.optString("url",""))).append("));\n");case"back"->b.append(p).append("back();\n");case"forward"->b.append(p).append("forward();\n");case"reload"->b.append(p).append("refresh();\n");case"click"->b.append(p).append("$(r(").append(sel).append(")).click();\n");
        case"input","content"->b.append(p).append("$(r(").append(sel).append(")).setValue(r(").append(secretJava(s,i)).append("));\n");case"select"->b.append(p).append("$(r(").append(sel).append(")).selectOptionByValue(r(").append(j(s.optString("value",""))).append("));\n");case"check"->b.append(p).append("if($(r(").append(sel).append(")).isSelected()!=").append(s.optBoolean("checked",true)).append(")$(r(").append(sel).append(")).click();\n");case"submit"->b.append(p).append("executeJavaScript(\"const e=document.querySelector(arguments[0]);if(e)(e.requestSubmit?e.requestSubmit():e.submit())\",r(").append(sel).append("));\n");
        case"scroll"->b.append(p).append("executeJavaScript(\"scrollTo(arguments[0],arguments[1])\",").append(s.optInt("x",0)).append(',').append(s.optInt("y",0)).append(");\n");case"focus"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0])?.focus()\",r(").append(sel).append("));\n");case"wait"->b.append(p).append("Thread.sleep(").append(Math.max(0,s.optLong("ms",1000))).append(");\n");case"waitFor"->b.append(p).append("$(r(").append(sel).append(")).should(exist,Duration.ofMillis(").append(timeout(s)).append("));\n");
        case"waitUrl"->b.append(p).append("{long e=System.currentTimeMillis()+").append(timeout(s)).append(";while(!WebDriverRunner.url().contains(r(").append(j(s.optString("contains",""))).append("))){if(System.currentTimeMillis()>e)throw new RuntimeException(\"URL wait timeout\");Thread.sleep(200);}}\n");case"assertExists"->b.append(p).append("$(r(").append(sel).append(")).should(exist);\n");case"assertText"->b.append(p).append("$(r(").append(sel).append(")).shouldHave(text(r(").append(j(expected(s))).append(")));\n");case"assertUrl"->b.append(p).append("if(!WebDriverRunner.url().contains(r(").append(j(s.optString("contains",""))).append(")))throw new RuntimeException(\"URL assertion failed\");\n");
        case"extractText"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",$(r(").append(sel).append(")).getText());\n");case"extractValue"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",$(r(").append(sel).append(")).getValue());\n");
        case"setText"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0]).textContent=arguments[1]\",r(").append(sel).append("),r(").append(j(s.optString("value",""))).append("));\n");case"setHtml"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0]).innerHTML=arguments[1]\",r(").append(sel).append("),r(").append(j(s.optString("value",""))).append("));\n");case"setAttr"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0]).setAttribute(arguments[1],arguments[2])\",r(").append(sel).append("),").append(j(s.optString("name",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");case"removeAttr"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0]).removeAttribute(arguments[1])\",r(").append(sel).append("),").append(j(s.optString("name",""))).append(");\n");case"setStyle"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0]).style.setProperty(arguments[1],arguments[2])\",r(").append(sel).append("),").append(j(s.optString("name",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");case"remove"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0])?.remove()\",r(").append(sel).append("));\n");
        case"storageSet"->b.append(p).append("executeJavaScript(\"window[arguments[0]].setItem(arguments[1],arguments[2])\",").append(j(storage(s))).append(',').append(j(s.optString("key",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");case"storageRemove"->b.append(p).append("executeJavaScript(\"window[arguments[0]].removeItem(arguments[1])\",").append(j(storage(s))).append(',').append(j(s.optString("key",""))).append(");\n");case"js"->b.append(p).append("executeJavaScript(r(").append(j(s.optString("code",s.optString("value","")))).append("));\n");case"dispatch"->b.append(p).append("executeJavaScript(\"document.querySelector(arguments[0])?.dispatchEvent(new Event(arguments[1],{bubbles:true}))\",r(").append(sel).append("),").append(j(s.optString("event","change"))).append(");\n");case"fileInput"->b.append(p).append("$(r(").append(sel).append(")).uploadFile(new java.io.File(Optional.ofNullable(System.getenv(").append(j("DEVSCOPE_FILE_"+(i+1))).append(")).orElseThrow()));\n");case"clearCookies"->b.append(p).append("WebDriverRunner.getWebDriver().manage().deleteAllCookies();\n");default->throw new IllegalArgumentException("Selenide unsupported action: "+t);}}

    private static String kotlinSelenide(JSONArray steps,String ua){
        StringBuilder b=new StringBuilder("import com.codeborne.selenide.*\nimport org.junit.jupiter.api.Test\nimport java.time.Duration\nimport java.io.File\nimport com.codeborne.selenide.Selenide.*\nimport com.codeborne.selenide.Condition.*\n\nclass DevScopeGeneratedTest {\n private val vars=mutableMapOf<String,String>()\n private fun r(s:String):String{var o=s;vars.forEach{(k,v)->o=o.replace(\"{{$k}}\",v)};return o}\n @Test fun run(){\n  Configuration.browser=\"chrome\"\n  Configuration.browserCapabilities.setCapability(\"goog:chromeOptions\",mapOf(\"args\" to listOf(").append(k("--user-agent="+ua)).append(")))\n");
        for(int i=0;i<steps.length();i++)emitSelenideKotlin(b,steps.optJSONObject(i),i);b.append("  println(\"DEV//SCOPE PASS\")\n  closeWebDriver()\n }\n}\n");return b.toString();
    }
    private static void emitSelenideKotlin(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String p="  ";String sel=k(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){case"open"->b.append(p).append("open(r(").append(k(s.optString("url",""))).append("))\n");case"back"->b.append(p).append("back()\n");case"forward"->b.append(p).append("forward()\n");case"reload"->b.append(p).append("refresh()\n");case"click"->b.append(p).append("`$`(r(").append(sel).append(")).click()\n");case"input","content"->b.append(p).append("`$`(r(").append(sel).append(")).setValue(r(").append(s.optBoolean("secret",false)?"System.getenv("+k("DEVSCOPE_SECRET_"+(i+1))+") ?: error(\"missing secret\")":k(s.optString("value",""))).append("))\n");case"select"->b.append(p).append("`$`(r(").append(sel).append(")).selectOptionByValue(r(").append(k(s.optString("value",""))).append("))\n");case"check"->b.append(p).append("if(`$`(r(").append(sel).append(")).isSelected != ").append(s.optBoolean("checked",true)).append(") `$`(r(").append(sel).append(")).click()\n");case"wait"->b.append(p).append("Thread.sleep(").append(Math.max(0,s.optLong("ms",1000))).append(")\n");case"waitFor","assertExists"->b.append(p).append("`$`(r(").append(sel).append(")).should(exist,Duration.ofMillis(").append(timeout(s)).append("))\n");case"assertText"->b.append(p).append("`$`(r(").append(sel).append(")).shouldHave(text(r(").append(k(expected(s))).append(")))\n");case"assertUrl"->b.append(p).append("check(WebDriverRunner.url().contains(r(").append(k(s.optString("contains",""))).append(")))\n");case"extractText"->b.append(p).append("vars[").append(k(storeAs(s))).append("]=`$`(r(").append(sel).append(")).text\n");case"extractValue"->b.append(p).append("vars[").append(k(storeAs(s))).append("]=`$`(r(").append(sel).append(")).value ?: \"\"\n");case"fileInput"->b.append(p).append("`$`(r(").append(sel).append(")).uploadFile(File(System.getenv(").append(k("DEVSCOPE_FILE_"+(i+1))).append(") ?: error(\"missing file env\")))\n");case"clearCookies"->b.append(p).append("WebDriverRunner.getWebDriver().manage().deleteAllCookies()\n");case"submit","scroll","focus","waitUrl","setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->emitKotlinJs(b,s,t,p,sel);default->throw new IllegalArgumentException("Selenide Kotlin unsupported action: "+t);}}
    private static void emitKotlinJs(StringBuilder b,JSONObject s,String t,String p,String sel){switch(t){case"submit"->b.append(p).append("executeJavaScript<Any>(\"const e=document.querySelector(arguments[0]);if(e)(e.requestSubmit?e.requestSubmit():e.submit())\",r(").append(sel).append("))\n");case"scroll"->b.append(p).append("executeJavaScript<Any>(\"scrollTo(arguments[0],arguments[1])\",").append(s.optInt("x",0)).append(',').append(s.optInt("y",0)).append(")\n");case"focus"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0])?.focus()\",r(").append(sel).append("))\n");case"waitUrl"->b.append(p).append("run{val e=System.currentTimeMillis()+").append(timeout(s)).append(";while(!WebDriverRunner.url().contains(r(").append(k(s.optString("contains",""))).append("))){if(System.currentTimeMillis()>e)error(\"URL wait timeout\");Thread.sleep(200)}}\n");case"setText"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0]).textContent=arguments[1]\",r(").append(sel).append("),r(").append(k(s.optString("value",""))).append("))\n");case"setHtml"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0]).innerHTML=arguments[1]\",r(").append(sel).append("),r(").append(k(s.optString("value",""))).append("))\n");case"setAttr"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0]).setAttribute(arguments[1],arguments[2])\",r(").append(sel).append("),").append(k(s.optString("name",""))).append(",r(").append(k(s.optString("value",""))).append("))\n");case"removeAttr"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0]).removeAttribute(arguments[1])\",r(").append(sel).append("),").append(k(s.optString("name",""))).append(")\n");case"setStyle"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0]).style.setProperty(arguments[1],arguments[2])\",r(").append(sel).append("),").append(k(s.optString("name",""))).append(",r(").append(k(s.optString("value",""))).append("))\n");case"remove"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0])?.remove()\",r(").append(sel).append("))\n");case"storageSet"->b.append(p).append("executeJavaScript<Any>(\"window[arguments[0]].setItem(arguments[1],arguments[2])\",").append(k(storage(s))).append(',').append(k(s.optString("key",""))).append(",r(").append(k(s.optString("value",""))).append("))\n");case"storageRemove"->b.append(p).append("executeJavaScript<Any>(\"window[arguments[0]].removeItem(arguments[1])\",").append(k(storage(s))).append(',').append(k(s.optString("key",""))).append(")\n");case"js"->b.append(p).append("executeJavaScript<Any>(r(").append(k(s.optString("code",s.optString("value","")))).append("))\n");case"dispatch"->b.append(p).append("executeJavaScript<Any>(\"document.querySelector(arguments[0])?.dispatchEvent(new Event(arguments[1],{bubbles:true}))\",r(").append(sel).append("),").append(k(s.optString("event","change"))).append(")\n");}}

    private static String goRod(JSONArray steps,String ua){StringBuilder b=new StringBuilder("package main\n\nimport(\"fmt\";\"os\";\"strings\";\"time\";\"github.com/go-rod/rod\";\"github.com/go-rod/rod/lib/launcher\")\nvar vars=map[string]string{}\nfunc r(s string)string{for k,v:=range vars{s=strings.ReplaceAll(s,\"{{\"+k+\"}}\",v)};return s}\nfunc main(){u:=launcher.New().Headless(false).MustLaunch(); b:=rod.New().ControlURL(u).MustConnect(); defer b.MustClose(); p:=b.MustPage(); p.MustSetUserAgent(&proto.NetworkSetUserAgentOverride{UserAgent:").append(goq(ua)).append("})\n");
        // Rod's direct UA API varies by version; use JS navigator override fallback plus launcher arg for reproducibility.
        b=new StringBuilder("package main\n\nimport(\"fmt\";\"os\";\"strings\";\"time\";\"github.com/go-rod/rod\";\"github.com/go-rod/rod/lib/launcher\")\nvar vars=map[string]string{}\nfunc r(s string)string{for k,v:=range vars{s=strings.ReplaceAll(s,\"{{\"+k+\"}}\",v)};return s}\nfunc main(){u:=launcher.New().Headless(false).Set(\"user-agent\",").append(goq(ua)).append(").MustLaunch(); br:=rod.New().ControlURL(u).MustConnect(); defer br.MustClose(); p:=br.MustPage()\n");
        for(int i=0;i<steps.length();i++)emitRod(b,steps.optJSONObject(i),i);b.append("fmt.Println(\"DEV//SCOPE PASS\")\n}\n");return b.toString();}
    private static void emitRod(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String p="";String sel=goq(s.optString("selector",""));b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){case"open"->b.append("p.MustNavigate(r(").append(goq(s.optString("url",""))).append(")).MustWaitLoad()\n");case"back"->b.append("p.MustEval(`history.back()`) ; time.Sleep(500*time.Millisecond)\n");case"forward"->b.append("p.MustEval(`history.forward()`) ; time.Sleep(500*time.Millisecond)\n");case"reload"->b.append("p.MustReload().MustWaitLoad()\n");case"click"->b.append("p.MustElement(r(").append(sel).append(")).MustClick()\n");case"input","content"->b.append("p.MustElement(r(").append(sel).append(")).MustSelectAllText().MustInput(r(").append(s.optBoolean("secret",false)?"os.Getenv("+goq("DEVSCOPE_SECRET_"+(i+1))+")":goq(s.optString("value",""))).append("))\n");case"check"->b.append("p.MustEval(`(p)=>{const e=document.querySelector(p.s); if(e&&e.checked!==p.v)e.click()}`,map[string]any{\"s\":r(").append(sel).append("),\"v\":").append(s.optBoolean("checked",true)).append("})\n");case"submit"->b.append("p.MustEval(`s=>{const e=document.querySelector(s);if(e)(e.requestSubmit?e.requestSubmit():e.submit())}`,r(").append(sel).append("))\n");case"scroll"->b.append("p.MustEval(`p=>scrollTo(p.x,p.y)`,map[string]int{\"x\":").append(s.optInt("x",0)).append(",\"y\":").append(s.optInt("y",0)).append("})\n");case"focus"->b.append("p.MustElement(r(").append(sel).append(")).MustFocus()\n");case"wait"->b.append("time.Sleep(").append(Math.max(0,s.optLong("ms",1000))).append("*time.Millisecond)\n");case"waitFor","assertExists"->b.append("p.Timeout(").append(timeout(s)).append("*time.Millisecond).MustElement(r(").append(sel).append("))\n");case"waitUrl"->b.append("for end:=time.Now().Add(").append(timeout(s)).append("*time.Millisecond);!strings.Contains(p.MustInfo().URL,r(").append(goq(s.optString("contains",""))).append("));{if time.Now().After(end){panic(\"URL wait timeout\")};time.Sleep(200*time.Millisecond)}\n");case"assertText"->b.append("if !strings.Contains(p.MustElement(r(").append(sel).append(")).MustText(),r(").append(goq(expected(s))).append(")){panic(\"text assertion failed\")}\n");case"assertUrl"->b.append("if !strings.Contains(p.MustInfo().URL,r(").append(goq(s.optString("contains",""))).append(")){panic(\"URL assertion failed\")}\n");case"extractText"->b.append("vars[").append(goq(storeAs(s))).append("]=p.MustElement(r(").append(sel).append(")).MustText()\n");case"extractValue"->b.append("vars[").append(goq(storeAs(s))).append("]=p.MustElement(r(").append(sel).append(")).MustProperty(\"value\").Str()\n");case"setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->emitRodJs(b,s,t,sel);default->throw new IllegalArgumentException("Rod unsupported action: "+t);}}
    private static void emitRodJs(StringBuilder b,JSONObject s,String t,String sel){switch(t){case"setText"->b.append("p.MustEval(`p=>document.querySelector(p.s).textContent=p.v`,map[string]any{\"s\":r(").append(sel).append("),\"v\":r(").append(goq(s.optString("value",""))).append(")})\n");case"setHtml"->b.append("p.MustEval(`p=>document.querySelector(p.s).innerHTML=p.v`,map[string]any{\"s\":r(").append(sel).append("),\"v\":r(").append(goq(s.optString("value",""))).append(")})\n");case"setAttr"->b.append("p.MustEval(`p=>document.querySelector(p.s).setAttribute(p.n,p.v)`,map[string]any{\"s\":r(").append(sel).append("),\"n\":").append(goq(s.optString("name",""))).append(",\"v\":r(").append(goq(s.optString("value",""))).append(")})\n");case"removeAttr"->b.append("p.MustEval(`p=>document.querySelector(p.s).removeAttribute(p.n)`,map[string]any{\"s\":r(").append(sel).append("),\"n\":").append(goq(s.optString("name",""))).append("})\n");case"setStyle"->b.append("p.MustEval(`p=>document.querySelector(p.s).style.setProperty(p.n,p.v)`,map[string]any{\"s\":r(").append(sel).append("),\"n\":").append(goq(s.optString("name",""))).append(",\"v\":r(").append(goq(s.optString("value",""))).append(")})\n");case"remove"->b.append("p.MustEval(`s=>document.querySelector(s)?.remove()`,r(").append(sel).append("))\n");case"storageSet"->b.append("p.MustEval(`p=>window[p.a].setItem(p.k,p.v)`,map[string]any{\"a\":").append(goq(storage(s))).append(",\"k\":").append(goq(s.optString("key",""))).append(",\"v\":r(").append(goq(s.optString("value",""))).append(")})\n");case"storageRemove"->b.append("p.MustEval(`p=>window[p.a].removeItem(p.k)`,map[string]any{\"a\":").append(goq(storage(s))).append(",\"k\":").append(goq(s.optString("key",""))).append("})\n");case"js"->b.append("p.MustEval(r(").append(goq(s.optString("code",s.optString("value","")))).append("))\n");case"dispatch"->b.append("p.MustEval(`p=>document.querySelector(p.s)?.dispatchEvent(new Event(p.e,{bubbles:true}))`,map[string]any{\"s\":r(").append(sel).append("),\"e\":").append(goq(s.optString("event","change"))).append("})\n");}}

    private static String rustFantoccini(JSONArray steps,String ua){StringBuilder b=new StringBuilder("use fantoccini::{ClientBuilder,Locator};\nuse serde_json::json;\nuse std::{collections::HashMap,env,time::{Duration,Instant}};\nfn r(mut s:String,v:&HashMap<String,String>)->String{for(k,x)in v{s=s.replace(&format!(\"{{{{{}}}}}\",k),x)}s}\n#[tokio::main] async fn main()->Result<(),Box<dyn std::error::Error>>{let mut caps=serde_json::Map::new();caps.insert(\"goog:chromeOptions\".into(),json!({\"args\":[").append(rs("--user-agent="+ua)).append("]}));let mut c=ClientBuilder::native().capabilities(caps).connect(&env::var(\"WEBDRIVER_URL\").unwrap_or(\"http://localhost:9515\".into())).await?;let mut vars=HashMap::new();\n");for(int i=0;i<steps.length();i++)emitFantoccini(b,steps.optJSONObject(i),i);b.append("println!(\"DEV//SCOPE PASS\");c.close().await?;Ok(())}\n");return b.toString();}
    private static void emitFantoccini(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String sel=rs(s.optString("selector",""));b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){case"open"->b.append("c.goto(&r(").append(rs(s.optString("url",""))).append(".into(),&vars)).await?;\n");case"back"->b.append("c.back().await?;\n");case"forward"->b.append("c.forward().await?;\n");case"reload"->b.append("c.refresh().await?;\n");case"click"->b.append("c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await?.click().await?;\n");case"input","content"->b.append("{let e=c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await?;e.clear().await?;e.send_keys(&r(").append(s.optBoolean("secret",false)?"env::var("+rs("DEVSCOPE_SECRET_"+(i+1))+")?":rs(s.optString("value",""))+".into()").append(",&vars)).await?;}\n");case"wait"->b.append("tokio::time::sleep(Duration::from_millis(").append(Math.max(0,s.optLong("ms",1000))).append(")).await;\n");case"waitFor","assertExists"->b.append("{let end=Instant::now()+Duration::from_millis(").append(timeout(s)).append(");loop{if c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await.is_ok(){break}if Instant::now()>end{return Err(\"selector timeout\".into())}tokio::time::sleep(Duration::from_millis(200)).await;}}\n");case"assertText"->b.append("if !c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await?.text().await?.contains(&r(").append(rs(expected(s))).append(".into(),&vars)){return Err(\"text assertion failed\".into())}\n");case"assertUrl"->b.append("if !c.current_url().await?.as_str().contains(&r(").append(rs(s.optString("contains",""))).append(".into(),&vars)){return Err(\"URL assertion failed\".into())}\n");case"extractText"->b.append("vars.insert(").append(rs(storeAs(s))).append(".into(),c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await?.text().await?);\n");case"extractValue"->b.append("vars.insert(").append(rs(storeAs(s))).append(".into(),c.find(Locator::Css(&r(").append(sel).append(".into(),&vars))).await?.prop(\"value\").await?.unwrap_or_default());\n");case"select","check","submit","scroll","focus","waitUrl","setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch","fileInput","clearCookies"->b.append("c.execute(").append(rs(fantocciniJs(t,s))).append(",vec![]).await?;\n");default->throw new IllegalArgumentException("Fantoccini unsupported action: "+t);}}
    private static String fantocciniJs(String t,JSONObject s){String sel=s.optString("selector","").replace("'","\\'");return switch(t){case"check"->"const e=document.querySelector('"+sel+"');if(e&&e.checked!=="+s.optBoolean("checked",true)+")e.click();";case"submit"->"const e=document.querySelector('"+sel+"');if(e)(e.requestSubmit?e.requestSubmit():e.submit());";case"scroll"->"scrollTo("+s.optInt("x",0)+","+s.optInt("y",0)+");";case"focus"->"document.querySelector('"+sel+"')?.focus();";case"waitUrl"->"return location.href;";case"setText"->"document.querySelector('"+sel+"').textContent="+JSONObject.quote(s.optString("value",""))+";";case"setHtml"->"document.querySelector('"+sel+"').innerHTML="+JSONObject.quote(s.optString("value",""))+";";case"setAttr"->"document.querySelector('"+sel+"').setAttribute("+JSONObject.quote(s.optString("name",""))+","+JSONObject.quote(s.optString("value",""))+");";case"removeAttr"->"document.querySelector('"+sel+"').removeAttribute("+JSONObject.quote(s.optString("name",""))+");";case"setStyle"->"document.querySelector('"+sel+"').style.setProperty("+JSONObject.quote(s.optString("name",""))+","+JSONObject.quote(s.optString("value",""))+");";case"remove"->"document.querySelector('"+sel+"')?.remove();";case"storageSet"->storage(s)+".setItem("+JSONObject.quote(s.optString("key",""))+","+JSONObject.quote(s.optString("value",""))+");";case"storageRemove"->storage(s)+".removeItem("+JSONObject.quote(s.optString("key",""))+");";case"js"->s.optString("code",s.optString("value",""));case"dispatch"->"document.querySelector('"+sel+"')?.dispatchEvent(new Event("+JSONObject.quote(s.optString("event","change"))+",{bubbles:true}));";case"select"->"const e=document.querySelector('"+sel+"');e.value="+JSONObject.quote(s.optString("value",""))+";e.dispatchEvent(new Event('change',{bubbles:true}));";case"fileInput"->"throw new Error('fileInput requires WebDriver element file API; edit generated target for environment');";case"clearCookies"->"document.cookie.split(';').forEach(c=>document.cookie=c.replace(/^ +/,'').replace(/=.*/,'=;expires='+new Date(0).toUTCString()+';path=/'));";default->"";};}

    private static String rubyCapybara(JSONArray steps,String ua){StringBuilder b=new StringBuilder("require 'capybara'\nrequire 'capybara/dsl'\nrequire 'selenium-webdriver'\ninclude Capybara::DSL\nCapybara.default_driver=:selenium_chrome\nCapybara.register_driver :selenium_chrome do |app|\n o=Selenium::WebDriver::Chrome::Options.new\n o.add_argument(").append(rb("--user-agent="+ua)).append(")\n Capybara::Selenium::Driver.new(app,browser: :chrome,options:o)\nend\nvars={}\ndef r(s,vars); vars.reduce(s.to_s){|o,(k,v)|o.gsub(\"{{#{k}}}\",v)}; end\n");for(int i=0;i<steps.length();i++)emitCapybara(b,steps.optJSONObject(i),i);b.append("puts 'DEV//SCOPE PASS'\n");return b.toString();}
    private static void emitCapybara(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String sel=rb(s.optString("selector",""));b.append("# step ").append(i+1).append(" // ").append(t).append('\n');switch(t){case"open"->b.append("visit r(").append(rb(s.optString("url",""))).append(",vars)\n");case"back"->b.append("page.go_back\n");case"forward"->b.append("page.go_forward\n");case"reload"->b.append("page.refresh\n");case"click"->b.append("find(r(").append(sel).append(",vars)).click\n");case"input","content"->b.append("find(r(").append(sel).append(",vars)).set(r(").append(s.optBoolean("secret",false)?"ENV.fetch("+rb("DEVSCOPE_SECRET_"+(i+1))+ ")":rb(s.optString("value",""))).append(",vars))\n");case"select"->b.append("find(r(").append(sel).append(",vars)).find(:option,r(").append(rb(s.optString("value",""))).append(",vars)).select_option\n");case"check"->b.append("e=find(r(").append(sel).append(",vars)); e.click if e.checked? != ").append(s.optBoolean("checked",true)).append("\n");case"wait"->b.append("sleep ").append(Math.max(0,s.optLong("ms",1000))/1000.0).append("\n");case"waitFor","assertExists"->b.append("find(r(").append(sel).append(",vars),wait:").append(timeout(s)/1000.0).append(")\n");case"assertText"->b.append("raise 'text assertion failed' unless find(r(").append(sel).append(",vars)).text.include?(r(").append(rb(expected(s))).append(",vars))\n");case"assertUrl"->b.append("raise 'URL assertion failed' unless current_url.include?(r(").append(rb(s.optString("contains",""))).append(",vars))\n");case"extractText"->b.append("vars[").append(rb(storeAs(s))).append("]=find(r(").append(sel).append(",vars)).text\n");case"extractValue"->b.append("vars[").append(rb(storeAs(s))).append("]=find(r(").append(sel).append(",vars)).value.to_s\n");case"fileInput"->b.append("attach_file(r(").append(sel).append(",vars),ENV.fetch(").append(rb("DEVSCOPE_FILE_"+(i+1))).append("),make_visible:true)\n");case"clearCookies"->b.append("page.driver.browser.manage.delete_all_cookies\n");case"submit","scroll","focus","waitUrl","setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->b.append("page.execute_script(").append(rb(capybaraJs(t,s))).append(")\n");default->throw new IllegalArgumentException("Capybara unsupported action: "+t);}}
    private static String capybaraJs(String t,JSONObject s){String sel=s.optString("selector","").replace("'","\\'");return switch(t){case"submit"->"const e=document.querySelector('"+sel+"');if(e)(e.requestSubmit?e.requestSubmit():e.submit());";case"scroll"->"scrollTo("+s.optInt("x",0)+","+s.optInt("y",0)+");";case"focus"->"document.querySelector('"+sel+"')?.focus();";case"waitUrl"->"return location.href;";case"setText"->"document.querySelector('"+sel+"').textContent="+JSONObject.quote(s.optString("value",""))+";";case"setHtml"->"document.querySelector('"+sel+"').innerHTML="+JSONObject.quote(s.optString("value",""))+";";case"setAttr"->"document.querySelector('"+sel+"').setAttribute("+JSONObject.quote(s.optString("name",""))+","+JSONObject.quote(s.optString("value",""))+");";case"removeAttr"->"document.querySelector('"+sel+"').removeAttribute("+JSONObject.quote(s.optString("name",""))+");";case"setStyle"->"document.querySelector('"+sel+"').style.setProperty("+JSONObject.quote(s.optString("name",""))+","+JSONObject.quote(s.optString("value",""))+");";case"remove"->"document.querySelector('"+sel+"')?.remove();";case"storageSet"->storage(s)+".setItem("+JSONObject.quote(s.optString("key",""))+","+JSONObject.quote(s.optString("value",""))+");";case"storageRemove"->storage(s)+".removeItem("+JSONObject.quote(s.optString("key",""))+");";case"js"->s.optString("code",s.optString("value",""));case"dispatch"->"document.querySelector('"+sel+"')?.dispatchEvent(new Event("+JSONObject.quote(s.optString("event","change"))+",{bubbles:true}));";default->"";};}

    private static String phpPanther(JSONArray steps,String ua){StringBuilder b=new StringBuilder("<?php\nrequire __DIR__.'/vendor/autoload.php';\nuse Symfony\\Component\\Panther\\Client;\n$vars=[];\n$r=function($s)use(&$vars){foreach($vars as $k=>$v)$s=str_replace('{{'.$k.'}}',$v,$s);return $s;};\n$client=Client::createChromeClient(null,['--user-agent=' . ").append(php(ua)).append("]);\n");for(int i=0;i<steps.length();i++)emitPanther(b,steps.optJSONObject(i),i);b.append("echo \"DEV//SCOPE PASS\\n\";\n?>\n");return b.toString();}
    private static void emitPanther(StringBuilder b,JSONObject s,int i){if(s==null)return;String t=s.optString("type","");String sel=php(s.optString("selector",""));b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){case"open"->b.append("$crawler=$client->request('GET',$r(").append(php(s.optString("url",""))).append("));\n");case"back"->b.append("$client->getWebDriver()->navigate()->back();\n");case"forward"->b.append("$client->getWebDriver()->navigate()->forward();\n");case"reload"->b.append("$client->getWebDriver()->navigate()->refresh();\n");case"click"->b.append("$client->getWebDriver()->findElement(Facebook\\WebDriver\\WebDriverBy::cssSelector($r(").append(sel).append(")))->click();\n");case"input","content"->b.append("$e=$client->getWebDriver()->findElement(Facebook\\WebDriver\\WebDriverBy::cssSelector($r(").append(sel).append(")));$e->clear();$e->sendKeys($r(").append(s.optBoolean("secret",false)?"getenv("+php("DEVSCOPE_SECRET_"+(i+1))+") ?: throw new RuntimeException('missing secret')":php(s.optString("value",""))).append("));\n");case"wait"->b.append("usleep(").append(Math.max(0,s.optLong("ms",1000))*1000).append(");\n");case"waitFor","assertExists"->b.append("$client->waitFor(").append(sel).append(",").append(Math.max(1,timeout(s)/1000)).append(");\n");case"assertText"->b.append("if(strpos($client->getWebDriver()->findElement(Facebook\\WebDriver\\WebDriverBy::cssSelector($r(").append(sel).append(")))->getText(),$r(").append(php(expected(s))).append("))===false)throw new RuntimeException('text assertion failed');\n");case"assertUrl"->b.append("if(strpos($client->getCurrentURL(),$r(").append(php(s.optString("contains",""))).append("))===false)throw new RuntimeException('URL assertion failed');\n");case"extractText"->b.append("$vars[").append(php(storeAs(s))).append("]=$client->getWebDriver()->findElement(Facebook\\WebDriver\\WebDriverBy::cssSelector($r(").append(sel).append(")))->getText();\n");case"extractValue"->b.append("$vars[").append(php(storeAs(s))).append("]=$client->getWebDriver()->findElement(Facebook\\WebDriver\\WebDriverBy::cssSelector($r(").append(sel).append(")))->getAttribute('value') ?? '';\n");case"select","check","submit","scroll","focus","waitUrl","setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch","fileInput","clearCookies"->b.append("$client->executeScript(").append(php(pantherJs(t,s))).append(");\n");default->throw new IllegalArgumentException("Panther unsupported action: "+t);}}
    private static String pantherJs(String t,JSONObject s){String sel=s.optString("selector","").replace("'","\\'");return capybaraJs(t,s).replace("\\'","\\'");}

    private static String wdioPackage(boolean ts){return "{\n  \"name\":\"devscope-wdio\",\n  \"private\":true,\n  \"type\":\"module\",\n  \"scripts\":{\"run\":\""+(ts?"tsx bot.ts":"node bot.js")+"\"},\n  \"dependencies\":{\"webdriverio\":\"^9.0.0\"}"+(ts?",\n  \"devDependencies\":{\"tsx\":\"^4.20.0\",\"typescript\":\"^5.9.0\"}":"")+"\n}\n";}
    private static String cypressPackage(boolean ts){return "{\n  \"name\":\"devscope-cypress\",\n  \"private\":true,\n  \"scripts\":{\"test\":\"cypress run\"},\n  \"devDependencies\":{\"cypress\":\"^15.0.0\""+(ts?",\"typescript\":\"^5.9.0\"":"")+"}\n}\n";}
    private static String cypressConfig(boolean ts,String ua){return (ts?"import { defineConfig } from 'cypress'\nexport default defineConfig({":"const { defineConfig } = require('cypress')\nmodule.exports = defineConfig({")+"\n  e2e: { setupNodeEvents(on, config) { return config } },\n  userAgent: "+js(ua)+"\n})\n";}
    private static String tsConfig(){return "{\n  \"compilerOptions\":{\"target\":\"ES2022\",\"module\":\"NodeNext\",\"moduleResolution\":\"NodeNext\",\"strict\":true,\"skipLibCheck\":true}\n}\n";}
    private static String selenidePom(){return "<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\"><modelVersion>4.0.0</modelVersion><groupId>devscope</groupId><artifactId>generated</artifactId><version>1.0</version><properties><maven.compiler.source>17</maven.compiler.source><maven.compiler.target>17</maven.compiler.target></properties><dependencies><dependency><groupId>com.codeborne</groupId><artifactId>selenide</artifactId><version>7.17.0</version><scope>test</scope></dependency><dependency><groupId>org.junit.jupiter</groupId><artifactId>junit-jupiter</artifactId><version>5.13.4</version><scope>test</scope></dependency></dependencies><build><plugins><plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-surefire-plugin</artifactId><version>3.5.3</version></plugin></plugins></build></project>\n";}
    private static String kotlinSelenideGradle(){return "plugins { kotlin(\"jvm\") version \"2.2.20\" }\nrepositories { mavenCentral() }\ndependencies { testImplementation(\"com.codeborne:selenide:7.17.0\"); testImplementation(kotlin(\"test\")); testImplementation(\"org.junit.jupiter:junit-jupiter:5.13.4\") }\ntasks.test { useJUnitPlatform() }\n";}

    private static Set<String> setOf(String...v){LinkedHashSet<String>s=new LinkedHashSet<>();for(String x:v)s.add(x);return s;}
    private static long timeout(JSONObject s){return s.optLong("timeoutMs",s.optLong("timeout",10000));}
    private static String expected(JSONObject s){return s.optString("contains",s.optString("text",""));}
    private static String storeAs(JSONObject s){String x=s.optString("storeAs",s.optString("var","value"));return x==null||x.trim().isEmpty()?"value":x.trim();}
    private static String storage(JSONObject s){String x=s.optString("store",s.optString("storage",s.optString("area","local")));return ("session".equals(x)||"sessionStorage".equals(x))?"sessionStorage":"localStorage";}
    private static String secretPy(JSONObject s,int i){return s.optBoolean("secret",false)?"os.environ["+py("DEVSCOPE_SECRET_"+(i+1))+"]":py(s.optString("value",""));}
    private static String secretJs(JSONObject s,int i){return s.optBoolean("secret",false)?"(process.env["+js("DEVSCOPE_SECRET_"+(i+1))+"]??(()=>{throw new Error('missing secret')})())":js(s.optString("value",""));}
    private static String secretJava(JSONObject s,int i){return s.optBoolean("secret",false)?"Optional.ofNullable(System.getenv("+j("DEVSCOPE_SECRET_"+(i+1))+")).orElseThrow()":j(s.optString("value",""));}
    private static String py(String s){return "'"+safe(s).replace("'","\\'")+"'";}
    private static String js(String s){return JSONObject.quote(s==null?"":s);}
    private static String j(String s){return JSONObject.quote(s==null?"":s);}
    private static String k(String s){return JSONObject.quote(s==null?"":s);}
    private static String goq(String s){return JSONObject.quote(s==null?"":s);}
    private static String rs(String s){return JSONObject.quote(s==null?"":s);}
    private static String rb(String s){return "'"+safe(s).replace("'","\\\\'")+"'";}
    private static String php(String s){return "'"+safe(s).replace("\\","\\\\").replace("'","\\'")+"'";}
    private static String safe(String s){return s==null?"":s.replace("\\","\\\\").replace("\r","\\r").replace("\n","\\n");}
}
