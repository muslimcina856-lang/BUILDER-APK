package com.devscope.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

/** Optional Android external-toolchain bridge using Termux RUN_COMMAND. */
public final class TermuxRunner {
    public static final String PACKAGE = "com.termux";
    private static final String SERVICE = "com.termux.app.RunCommandService";
    private static final String ACTION = "com.termux.RUN_COMMAND";
    private static final String PATH = "com.termux.RUN_COMMAND_PATH";
    private static final String ARGS = "com.termux.RUN_COMMAND_ARGUMENTS";
    private static final String STDIN = "com.termux.RUN_COMMAND_STDIN";
    private static final String WORKDIR = "com.termux.RUN_COMMAND_WORKDIR";
    private static final String BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND";
    private static final String SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION";
    private static final String LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL";
    private static final String DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION";

    private TermuxRunner() {}

    @SuppressWarnings("deprecation")
    public static boolean installed(Context context) {
        try { context.getPackageManager().getPackageInfo(PACKAGE, 0); return true; }
        catch (Throwable ignored) { return false; }
    }

    public static void runSource(Context context, ScriptLanguageDetector.Result detected, String source) throws Exception {
        if (!installed(context)) throw new IllegalStateException("Termux tidak dipasang. External source tidak boleh dijalankan oleh Android standard tanpa toolchain.");
        if (source == null || source.isEmpty()) throw new IllegalArgumentException("Source kosong");
        if (source.length() > 400000) throw new IllegalArgumentException("Source melebihi had selamat RUN_COMMAND (~400KB payload)");
        String command = shellCommand(detected);
        Intent i = new Intent();
        i.setClassName(PACKAGE, SERVICE);
        i.setAction(ACTION);
        i.putExtra(PATH, "$PREFIX/bin/bash");
        i.putExtra(ARGS, new String[]{"-lc", command});
        i.putExtra(STDIN, source);
        i.putExtra(WORKDIR, "~/");
        i.putExtra(BACKGROUND, false);
        i.putExtra(SESSION_ACTION, "0");
        i.putExtra(LABEL, "DevScope " + detected.label());
        i.putExtra(DESCRIPTION, "Auto-detected by DevScope. Runs in Termux with the installed external toolchain; browser frameworks may require their declared browser/WebDriver/remote endpoint.");
        context.startService(i);
    }

    private static String shellCommand(ScriptLanguageDetector.Result d) {
        String dir="${TMPDIR:-$HOME}/devscope-auto";
        String ext=d.extension == null || d.extension.isEmpty() ? ".txt" : d.extension;
        String file="bot"+ext;
        String prep="set -eu; mkdir -p \""+dir+"\"; cd \""+dir+"\"; cat > \""+file+"\"; ";
        return switch (d.language) {
            case "Python" -> prep + "PY=$(command -v python3 || command -v python); \"$PY\" \""+file+"\"";
            case "JavaScript" -> prep + "node \""+file+"\"";
            case "TypeScript" -> prep + "npx --yes tsx \""+file+"\"";
            case "Ruby" -> prep + "ruby \""+file+"\"";
            case "PHP" -> prep + "php \""+file+"\"";
            case "Go" -> prep + "go run \""+file+"\"";
            case "C" -> prep + "cc \""+file+"\" -lcurl -o devscope-run && ./devscope-run";
            case "C++" -> prep + "c++ -std=c++17 \""+file+"\" -lcurl -o devscope-run && ./devscope-run";
            case "Java" -> "set -eu; d=\""+dir+"\"; mkdir -p \"$d\"; cd \"$d\"; cat > DevScopeGenerated.java; javac DevScopeGenerated.java; java DevScopeGenerated";
            case "Kotlin" -> prep + "kotlinc \""+file+"\" -include-runtime -d devscope.jar && java -jar devscope.jar";
            case "Rust" -> prep + "rustc \""+file+"\" -o devscope-run && ./devscope-run";
            case "C#" -> prep + "if command -v dotnet-script >/dev/null 2>&1; then dotnet-script \""+file+"\"; else echo 'dotnet-script required for single-file C# run; use PROJECT ZIP + dotnet restore/build' >&2; exit 44; fi";
            default -> "echo 'Unsupported detected language: " + escape(d.language) + "' >&2; exit 45";
        };
    }

    private static String escape(String s) { return s == null ? "" : s.replace("'", "_").replace("\n", " "); }
}
