package com.devscope.app;

/** Language -> curated, real automation engines exposed by CODEGEN. */
public final class CodegenCatalog {
    public static final String[] LANGUAGES = {
            "Python", "JavaScript", "TypeScript", "Java", "Kotlin", "C# (C+)",
            "Go", "C", "C++", "Rust", "Ruby", "PHP"
    };

    public static final String PLAYWRIGHT = "Playwright";
    public static final String SELENIUM = "Selenium WebDriver";
    public static final String PUPPETEER = "Puppeteer";
    public static final String PYPPETEER = "Pyppeteer";
    public static final String WEBDRIVERIO = "WebdriverIO";
    public static final String CYPRESS = "Cypress";
    public static final String SELENIDE = "Selenide";
    public static final String CHROMEDP = "chromedp";
    public static final String ROD = "Rod";
    public static final String W3C = "W3C WebDriver + libcurl";
    public static final String THIRTYFOUR = "thirtyfour WebDriver";
    public static final String FANTOCCINI = "Fantoccini";
    public static final String CAPYBARA = "Capybara";
    public static final String PHP_WEBDRIVER = "php-webdriver";
    public static final String PANTHER = "Symfony Panther";

    private CodegenCatalog() {}

    public static String[] methodsFor(String language) {
        if ("Python".equals(language)) return new String[]{PLAYWRIGHT, SELENIUM, PYPPETEER};
        if ("JavaScript".equals(language) || "TypeScript".equals(language))
            return new String[]{PLAYWRIGHT, PUPPETEER, WEBDRIVERIO, SELENIUM, CYPRESS};
        if ("Java".equals(language)) return new String[]{PLAYWRIGHT, SELENIUM, SELENIDE};
        if ("Kotlin".equals(language)) return new String[]{SELENIUM, SELENIDE};
        if ("C# (C+)".equals(language)) return new String[]{PLAYWRIGHT, SELENIUM};
        if ("Go".equals(language)) return new String[]{CHROMEDP, ROD};
        if ("C".equals(language) || "C++".equals(language)) return new String[]{W3C};
        if ("Rust".equals(language)) return new String[]{THIRTYFOUR, FANTOCCINI};
        if ("Ruby".equals(language)) return new String[]{SELENIUM, CAPYBARA};
        if ("PHP".equals(language)) return new String[]{PHP_WEBDRIVER, PANTHER};
        return new String[]{SELENIUM};
    }

    public static String recommended(String language) { return methodsFor(language)[0]; }

    public static String targetFor(String language, String method) {
        if ("Python".equals(language)) {
            if (PLAYWRIGHT.equals(method)) return AlternativeCodeProjectGenerator.PYTHON_PLAYWRIGHT;
            if (PYPPETEER.equals(method)) return ExtraCodeProjectGenerator.PYTHON_PYPPETEER;
            return CodeProjectGenerator.PYTHON;
        }
        if ("JavaScript".equals(language)) {
            if (PLAYWRIGHT.equals(method)) return AlternativeCodeProjectGenerator.JS_PLAYWRIGHT;
            if (PUPPETEER.equals(method)) return AlternativeCodeProjectGenerator.JS_PUPPETEER;
            if (WEBDRIVERIO.equals(method)) return ExtraCodeProjectGenerator.JS_WEBDRIVERIO;
            if (CYPRESS.equals(method)) return ExtraCodeProjectGenerator.JS_CYPRESS;
            return CodeProjectGenerator.JAVASCRIPT;
        }
        if ("TypeScript".equals(language)) {
            if (PLAYWRIGHT.equals(method)) return AlternativeCodeProjectGenerator.TS_PLAYWRIGHT;
            if (PUPPETEER.equals(method)) return AlternativeCodeProjectGenerator.TS_PUPPETEER;
            if (WEBDRIVERIO.equals(method)) return ExtraCodeProjectGenerator.TS_WEBDRIVERIO;
            if (CYPRESS.equals(method)) return ExtraCodeProjectGenerator.TS_CYPRESS;
            return CodeProjectGenerator.TYPESCRIPT;
        }
        if ("Java".equals(language)) {
            if (PLAYWRIGHT.equals(method)) return AlternativeCodeProjectGenerator.JAVA_PLAYWRIGHT;
            if (SELENIDE.equals(method)) return ExtraCodeProjectGenerator.JAVA_SELENIDE;
            return CodeProjectGenerator.JAVA;
        }
        if ("Kotlin".equals(language)) return SELENIDE.equals(method) ? ExtraCodeProjectGenerator.KOTLIN_SELENIDE : CodeProjectGenerator.KOTLIN;
        if ("C# (C+)".equals(language)) return PLAYWRIGHT.equals(method) ? AlternativeCodeProjectGenerator.CSHARP_PLAYWRIGHT : CodeProjectGenerator.CSHARP;
        if ("Go".equals(language)) return ROD.equals(method) ? ExtraCodeProjectGenerator.GO_ROD : CodeProjectGenerator.GO;
        if ("C".equals(language)) return CodeProjectGenerator.C;
        if ("C++".equals(language)) return CodeProjectGenerator.CPP;
        if ("Rust".equals(language)) return FANTOCCINI.equals(method) ? ExtraCodeProjectGenerator.RUST_FANTOCCINI : CodeProjectGenerator.RUST;
        if ("Ruby".equals(language)) return CAPYBARA.equals(method) ? ExtraCodeProjectGenerator.RUBY_CAPYBARA : CodeProjectGenerator.RUBY;
        if ("PHP".equals(language)) return PANTHER.equals(method) ? ExtraCodeProjectGenerator.PHP_PANTHER : CodeProjectGenerator.PHP;
        throw new IllegalArgumentException("Unsupported language: " + language);
    }

    public static String methodDescription(String language, String method) {
        if (PLAYWRIGHT.equals(method)) return "Recommended for modern web apps: auto-waiting, strong locators, Chromium/Firefox/WebKit.";
        if (PUPPETEER.equals(method)) return "Chromium/Firefox-oriented DevTools automation; strong JS/TS choice.";
        if (PYPPETEER.equals(method)) return "Python port of Puppeteer-style Chromium automation; useful for async Python workflows.";
        if (WEBDRIVERIO.equals(method)) return "Node.js WebDriver/CDP automation with a modern async API and strong test ecosystem.";
        if (CYPRESS.equals(method)) return "E2E test runner with command timeline and retryable assertions; best for test-style flows.";
        if (SELENIUM.equals(method)) return "Mature W3C WebDriver ecosystem with broad browser/grid compatibility.";
        if (SELENIDE.equals(method)) return "Concise Java/Kotlin UI testing layer powered by Selenium WebDriver.";
        if (CHROMEDP.equals(method)) return "Native Go control over Chrome DevTools Protocol; no Selenium server required.";
        if (ROD.equals(method)) return "High-level Go CDP automation with auto-waiting and direct browser instrumentation.";
        if (W3C.equals(method)) return "Raw WebDriver HTTP protocol project using libcurl; requires a compatible WebDriver.";
        if (THIRTYFOUR.equals(method)) return "Async Rust WebDriver client using thirtyfour + Tokio.";
        if (FANTOCCINI.equals(method)) return "Rust WebDriver client with async navigation and element APIs.";
        if (CAPYBARA.equals(method)) return "Ruby high-level web acceptance automation, generated with Selenium driver.";
        if (PHP_WEBDRIVER.equals(method)) return "PHP client for W3C WebDriver/Selenium with browser capabilities.";
        if (PANTHER.equals(method)) return "Symfony browser testing/scraping client built around real Chrome/Firefox WebDriver.";
        return method;
    }

    public static int languageIndex(String language) {
        for (int i = 0; i < LANGUAGES.length; i++) if (LANGUAGES[i].equals(language)) return i;
        return 0;
    }
}
