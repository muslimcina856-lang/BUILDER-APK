package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Enriches a live Android WebView recording and emits a complete external code project. */
public final class CodegenFacade {
    private CodegenFacade() {}

    public static CodeProjectGenerator.GeneratedProject generate(
            String language, String method, JSONObject originalFlow, String currentUrl, String userAgent) throws Exception {
        if (originalFlow == null) throw new IllegalArgumentException("Action Script is required");
        JSONObject flow = new JSONObject(originalFlow.toString());
        String startUrl = validHttpUrl(currentUrl) ? currentUrl : flow.optString("startUrl", "");
        if (validHttpUrl(startUrl)) {
            flow.put("startUrl", startUrl);
            flow.put("sourceUrl", startUrl);
        }
        flow.put("userAgent", userAgent == null ? "" : userAgent);
        flow.put("language", language);
        flow.put("method", method);
        flow.put("generatedAt", System.currentTimeMillis());
        flow.put("steps", normalizeSteps(flow.optJSONArray("steps"), startUrl));

        String target = CodegenCatalog.targetFor(language, method);
        CodeProjectGenerator.GeneratedProject project;
        if (ExtraCodeProjectGenerator.supports(target)) project = ExtraCodeProjectGenerator.generate(target, flow);
        else if (AlternativeCodeProjectGenerator.supports(target)) project = AlternativeCodeProjectGenerator.generate(target, flow);
        else project = CodeProjectGenerator.generate(target, flow);

        if (!AlternativeCodeProjectGenerator.supports(target) && !ExtraCodeProjectGenerator.supports(target)) {
            patchLegacyUserAgent(project, userAgent == null ? "" : userAgent);
        }

        JSONObject meta = new JSONObject();
        meta.put("format", "devscope.generated-project/2");
        meta.put("language", language);
        meta.put("method", method);
        meta.put("target", target);
        meta.put("engine", project.engine);
        meta.put("sourceUrl", validHttpUrl(startUrl) ? startUrl : JSONObject.NULL);
        meta.put("userAgent", userAgent == null ? "" : userAgent);
        meta.put("mainFile", project.mainFile);
        meta.put("stepCount", flow.getJSONArray("steps").length());
        meta.put("generatedAt", System.currentTimeMillis());
        project.files.put("flow.json", flow.toString(2));
        project.files.put("devscope-project.json", meta.toString(2));
        project.files.put("README.md", projectReadme(language, method, project, startUrl, userAgent, flow.getJSONArray("steps").length()));
        return project;
    }

    private static JSONArray normalizeSteps(JSONArray input, String startUrl) throws Exception {
        JSONArray out = new JSONArray();
        if (input != null) {
            for (int i = 0; i < input.length(); i++) {
                JSONObject step = input.optJSONObject(i);
                if (step != null) out.put(new JSONObject(step.toString()));
            }
        }
        if (!validHttpUrl(startUrl)) return out;
        if (out.length() == 0) {
            JSONObject open = new JSONObject();
            open.put("type", "open");
            open.put("url", startUrl);
            out.put(open);
            return out;
        }
        JSONObject first = out.optJSONObject(0);
        if (first == null || !"open".equals(first.optString("type", ""))) {
            JSONArray prefixed = new JSONArray();
            JSONObject open = new JSONObject();
            open.put("type", "open");
            open.put("url", startUrl);
            prefixed.put(open);
            for (int i = 0; i < out.length(); i++) prefixed.put(out.get(i));
            return prefixed;
        }
        if (!validHttpUrl(first.optString("url", ""))) first.put("url", startUrl);
        return out;
    }

    private static boolean validHttpUrl(String value) {
        if (value == null) return false;
        String v = value.trim().toLowerCase(Locale.US);
        return v.startsWith("http://") || v.startsWith("https://");
    }

    private static String projectReadme(String language, String method, CodeProjectGenerator.GeneratedProject project,
                                        String startUrl, String userAgent, int steps) {
        return "# DevScope Generated Project\n\n" +
                "- Language: **" + language + "**\n" +
                "- Method: **" + method + "**\n" +
                "- Engine: **" + project.engine + "**\n" +
                "- Start URL: `" + (validHttpUrl(startUrl) ? startUrl : "not captured") + "`\n" +
                "- Recorded User-Agent: `" + (userAgent == null ? "" : userAgent.replace("`", "'")) + "`\n" +
                "- Steps: **" + steps + "**\n\n" +
                "The start URL is automatically inserted from the live Android WebView when the recorded flow has no initial `open` step.\n" +
                "The generated browser is configured to reuse the recorded WebView User-Agent where the target engine supports browser UA configuration.\n\n" +
                "## Project contents\n\n" +
                "`flow.json` is the canonical DevScope recording. `devscope-project.json` contains generation metadata.\n" +
                "The language dependency manifest and the `devscope/` setup, verify, repair and toolchain scripts are attached before PROJECT ZIP export.\n\n" +
                "Secrets and file-input values are never embedded; use the environment variables listed in `devscope/env.example`.\n" +
                "Human verification/CAPTCHA is not bypassed by generated code.\n";
    }

    private static void patchLegacyUserAgent(CodeProjectGenerator.GeneratedProject project, String ua) {
        if (project == null || ua == null || ua.isEmpty()) return;
        String src = project.mainSource();
        if (src == null || src.isEmpty()) return;
        String target = project.target;

        if (CodeProjectGenerator.PYTHON.equals(target)) {
            src = src.replace("driver = webdriver.Chrome()",
                    "options = webdriver.ChromeOptions()\noptions.add_argument(\"--user-agent=\" + " + py(ua) + ")\ndriver = webdriver.Chrome(options=options)");
        } else if (CodeProjectGenerator.JAVASCRIPT.equals(target) || CodeProjectGenerator.TYPESCRIPT.equals(target)) {
            src = src.replace("import { Builder, By } from 'selenium-webdriver';",
                    "import { Builder, By } from 'selenium-webdriver';\nimport chrome from 'selenium-webdriver/chrome.js';");
            src = src.replace("const driver = await new Builder().forBrowser('chrome').build();",
                    "const chromeOptions = new chrome.Options().addArguments('--user-agent=' + " + js(ua) + ");\nconst driver = await new Builder().forBrowser('chrome').setChromeOptions(chromeOptions).build();");
        } else if (CodeProjectGenerator.JAVA.equals(target)) {
            src = src.replace("import org.openqa.selenium.chrome.ChromeDriver;",
                    "import org.openqa.selenium.chrome.ChromeDriver;\nimport org.openqa.selenium.chrome.ChromeOptions;");
            src = src.replace("d=new ChromeDriver(); try{",
                    "ChromeOptions options=new ChromeOptions(); options.addArguments(\"--user-agent=\"+" + j(ua) + "); d=new ChromeDriver(options); try{");
        } else if (CodeProjectGenerator.KOTLIN.equals(target)) {
            src = src.replace("import org.openqa.selenium.chrome.ChromeDriver",
                    "import org.openqa.selenium.chrome.ChromeDriver\nimport org.openqa.selenium.chrome.ChromeOptions");
            src = src.replace("fun main(){d=ChromeDriver();try{",
                    "fun main(){val options=ChromeOptions();options.addArguments(\"--user-agent=\"+" + kt(ua) + ");d=ChromeDriver(options);try{");
        } else if (CodeProjectGenerator.CSHARP.equals(target)) {
            src = src.replace("var d=new ChromeDriver();",
                    "var options=new ChromeOptions(); options.AddArgument(\"--user-agent=\" + " + cs(ua) + ");\nvar d=new ChromeDriver(options);");
        } else if (CodeProjectGenerator.GO.equals(target)) {
            src = src.replace("ctx,cancel:=chromedp.NewContext(context.Background());defer cancel();",
                    "opts:=append(chromedp.DefaultExecAllocatorOptions[:],chromedp.UserAgent(" + go(ua) + "));alloc,cancelAlloc:=chromedp.NewExecAllocator(context.Background(),opts...);defer cancelAlloc();ctx,cancel:=chromedp.NewContext(alloc);defer cancel();");
        } else if (CodeProjectGenerator.CPP.equals(target)) {
            String oldCaps = "{\"capabilities\":{\"alwaysMatch\":{\"browserName\":\"chrome\"}}}";
            String newCaps = "{\"capabilities\":{\"alwaysMatch\":{\"browserName\":\"chrome\",\"goog:chromeOptions\":{\"args\":[\"--user-agent=" + json(ua) + "\"]}}}}";
            src = src.replace(oldCaps, newCaps);
        } else if (CodeProjectGenerator.C.equals(target)) {
            String oldCaps = "{\\\"capabilities\\\":{\\\"alwaysMatch\\\":{\\\"browserName\\\":\\\"chrome\\\"}}}";
            String newCaps = "{\\\"capabilities\\\":{\\\"alwaysMatch\\\":{\\\"browserName\\\":\\\"chrome\\\",\\\"goog:chromeOptions\\\":{\\\"args\\\":[\\\"--user-agent=" + cStringJson(ua) + "\\\"]}}}}";
            src = src.replace(oldCaps, newCaps);
        } else if (CodeProjectGenerator.RUST.equals(target)) {
            src = src.replace("let caps=DesiredCapabilities::chrome();let d=WebDriver::new(\"http://localhost:4444\",caps).await?;",
                    "let caps=DesiredCapabilities::chrome();let d=WebDriver::builder(\"http://localhost:4444\",caps).user_agent(" + rust(ua) + ").await?;");
        } else if (CodeProjectGenerator.RUBY.equals(target)) {
            src = src.replace("d=Selenium::WebDriver.for :chrome",
                    "options=Selenium::WebDriver::Options.chrome\noptions.add_argument('--user-agent=' + " + rb(ua) + ")\nd=Selenium::WebDriver.for :chrome, options: options");
        } else if (CodeProjectGenerator.PHP.equals(target)) {
            src = src.replace("use Facebook\\WebDriver\\Remote\\DesiredCapabilities;",
                    "use Facebook\\WebDriver\\Remote\\DesiredCapabilities;\nuse Facebook\\WebDriver\\Chrome\\ChromeOptions;");
            src = src.replace("$d=RemoteWebDriver::create(getenv('WEBDRIVER_URL')?:'http://localhost:4444',DesiredCapabilities::chrome());$vars=[];",
                    "$options=new ChromeOptions();$options->addArguments(['--user-agent=' . " + php(ua) + "]);$caps=DesiredCapabilities::chrome();$caps->setCapability(ChromeOptions::CAPABILITY,$options);$d=RemoteWebDriver::create(getenv('WEBDRIVER_URL')?:'http://localhost:4444',$caps);$vars=[];");
        }
        project.files.put(project.mainFile, src);
    }

    private static String py(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r")+"'";}
    private static String js(String s){return JSONObject.quote(s);}
    private static String j(String s){return JSONObject.quote(s);}
    private static String kt(String s){return JSONObject.quote(s).replace("$","\\$");}
    private static String cs(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n")+"\"";}
    private static String go(String s){return JSONObject.quote(s);}
    private static String rust(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    private static String rb(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
    private static String php(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
    private static String json(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n");}
    private static String cStringJson(String s){return json(s).replace("\\","\\\\").replace("\"","\\\"");}
}
