# DevScope Android v4.2.0

- Python generated primary source is now always `bot.py` for Playwright, Selenium and Pyppeteer.
- Single-file Python EXPORT CODE suggests `bot.py`.
- Expanded CODEGEN to 30 curated language/method combinations with real generators and dependency manifests.
- Added Pyppeteer, WebdriverIO, Cypress, Selenide, Rod, Fantoccini, Capybara and Symfony Panther generator families.
- AUTOMATE RUN now detects DevScope Action JSON, page JavaScript, language and common automation framework signatures.
- DevScope Action JSON runs natively against the current Android WebView.
- Plain page JavaScript runs directly in the current WebView.
- External source can be dispatched through the real Termux RUN_COMMAND bridge when Termux is installed/configured; unsupported/missing toolchains fail visibly instead of returning fake success.
- Added Termux package visibility and RUN_COMMAND permission declaration.
- Fixed Kotlin Selenium/Selenide detection precedence so Kotlin imports are not mislabeled Java.
- Retains live WebView URL/User-Agent injection, full verified PROJECT ZIP, dependency bootstrap, keyboard-aware editor, build fixes and launcher icon.

# DevScope v4.0.4

- Set approved DevScope artwork as the real Android launcher icon.
- Added mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi launcher resources.
- Added normal and round launcher icon manifest references.
- No other app functionality changed.

# DevScope v4.0.3

- Keyboard-aware CODEGEN/AUTOMATE editors on Android.
- Activity now uses `adjustResize` so the IME resizes the app instead of covering the editor.
- When the keyboard opens while editing code/action scripts, DevScope temporarily expands TOOLS and hides the WebView to maximize editable space.
- The active cursor is automatically brought into the visible viewport; code remains vertically swipeable while typing.
- Added `flagNoExtractUi` so landscape keyboards do not replace DevScope with a full-screen IME editor.
- Closing the keyboard restores the previous SPLIT/WEB/TOOLS state.
- No unrelated DevScope features changed.

# DevScope Android v4.0.2

## Build fixes
- Fixed Android checked `JSONException` handling for `JSONObject.toString(2)` in live Storage rendering and the shared pretty-printer.
- Pretty JSON now falls back to compact valid JSON if indentation encoding fails; no storage data is discarded.
- Retains the v4.0.1 `android.print.PrintManager` namespace fix.
- No feature behavior removed.
- Version bumped to 4.0.2 / versionCode 6.

# DevScope Android v4.0.1

## Build fix
- Fixed Android print API import: `android.print.PrintManager` (previously incorrectly imported from `android.app`).
- No feature behavior changed.
- Version bumped to 4.0.1 / versionCode 5.

# Changelog

## 4.0.0

- Added DEPS workspace for generated-project dependency analysis.
- Added real bootstrap setup scripts for Linux/macOS/Termux and PowerShell.
- Added optional toolchain installers with explicit failure on unsupported hosts.
- Added module installation/lock generation for Python, JS/TS, Java, Kotlin, C#, Go, C/C++, Rust, Ruby and PHP.
- Added verify/compile scripts per generated language.
- Added bootstrap-only ZIP export and project-bundle validation.
- Added `env.example` generation for recorder secrets/file inputs.
- Project ZIP now automatically contains dependency bootstrap files.

# DevScope Android v3.0.0

## Added

- CODEGEN tab for generating editable external automation projects from the current DevScope Action Script.
- 12 code-generation targets: Python, JavaScript, TypeScript, Java, Kotlin, C#, Go, C, C++, Rust, Ruby, and PHP.
- Strict target compatibility validation: unsupported recorded actions block generation instead of emitting placeholder behavior.
- Secret/file-input handling via environment variables where the selected target supports them.
- Source editor for generated main source.
- Export generated source through Android Storage Access Framework.
- Export full project ZIP through Android Storage Access Framework, including dependency/build files, canonical `flow.json`, and README.
- CODEGEN telemetry events.

## Unchanged core

Browser WebView, TRACE, DOM picker, NETWORK, CONSOLE, STORAGE, SOURCE, RUNTIME, AUTOMATE, Downloads, screenshot/MHTML/PDF export and ADB WebView debugging remain Android-native features from v2.

## 4.1.0
- Auto-inject live WebView URL into generated automation when no OPEN step exists.
- Reuse live Android WebView User-Agent in generated browser configuration.
- Added real method chooser after language selection (Playwright / Selenium / Puppeteer where implemented).
- Added Playwright generators for Python, JavaScript, TypeScript, Java and C#.
- Added Puppeteer generators for JavaScript and TypeScript.
- PROJECT ZIP now performs strict bundle verification for source, dependency manifest, flow metadata and bootstrap files before export.
