# CODEGEN Update 4.1.0

## Live URL
The URL currently loaded in the Android WebView is passed to CODEGEN. If the Action Script has no initial `open` step, DevScope inserts one before generation. An intentional valid recorded `open` step is preserved.

## Live User-Agent
CODEGEN reads `webView.getSettings().getUserAgentString()` at generation time and configures the selected external browser engine to use that User-Agent where supported. The value is also written to `flow.json` and `devscope-project.json`.

## Language -> method chooser
Only implemented generators are shown.
- Python: Playwright, Selenium WebDriver
- JavaScript: Playwright, Puppeteer, Selenium WebDriver
- TypeScript: Playwright, Puppeteer, Selenium WebDriver
- Java: Playwright, Selenium WebDriver
- C#: Playwright, Selenium WebDriver
- Kotlin: Selenium WebDriver
- Go: chromedp
- C/C++: W3C WebDriver + libcurl
- Rust: thirtyfour
- Ruby: Selenium WebDriver
- PHP: php-webdriver

## Full PROJECT ZIP
Before export, DevScope verifies the generated main source, language dependency manifest, `flow.json`, `devscope-project.json`, and the generated `devscope/` bootstrap files. Missing/empty required files block export.
