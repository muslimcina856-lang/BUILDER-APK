# CODEGEN / AUTOMATE Update 4.2.0

## Python
Primary file: `bot.py` for Playwright, Selenium WebDriver and Pyppeteer.

## Method matrix
30 curated language/method combinations are exposed. The chooser only lists engines with implemented project generators.

## AUTOMATE detection
RUN detects Action JSON, current-page JavaScript, or external source language/framework. Action JSON runs in the native WebView runner; JavaScript runs in the current WebView; external source can dispatch through Termux RUN_COMMAND when a real external toolchain is available.

## Project ZIP
Exports full verified project files, dependency/build manifest, flow metadata and DevScope setup/verify/repair/toolchain scripts.
