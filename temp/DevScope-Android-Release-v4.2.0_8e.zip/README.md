# DevScope Android v4.2.0

DevScope is an Android-native WebView runtime laboratory for experienced developers. Runtime inspection, recording and Android replay operate against the current real WebView session. External CODEGEN projects are generated from the canonical DevScope Action Script and contain real dependency/build metadata; no runtime result is fabricated.

## Android-only application

The application is Android Native (`com.devscope.app`). Python, JavaScript, TypeScript, Java, Kotlin, C#, Go, C, C++, Rust, Ruby and PHP are automation/source targets generated or detected by the Android app; they are not alternate app implementations.

## Core modules

- TRACE: navigation, request, service-worker, console, errors, automation and codegen events.
- DOM: rendered DOM tree and tap-to-pick element inspection.
- NETWORK: WebView request metadata plus PerformanceResourceTiming where exposed.
- CONSOLE: live page console messages.
- STORAGE: current-origin cookies, localStorage and sessionStorage.
- SOURCE: rendered DOM, MHTML, PNG and Android print/PDF.
- RUNTIME: JavaScript evaluator against the current page.
- AUTOMATE: recorder, editable Action Script, language/framework detection and real execution routing.
- CODEGEN: multi-language/multi-engine external automation project generation.
- DEPS: setup, verify, repair, toolchain and dependency bootstrap assets.
- DOWNLOADS: Android DownloadManager queue using current WebView session headers where available.

## AUTOMATE — auto detect + run

AUTOMATE accepts DevScope Action JSON or imported/pasted source. RUN performs detection first:

- DevScope Action JSON -> native Android WebView runner.
- Plain page JavaScript -> executes in the current WebView with `evaluateJavascript`.
- Python/JavaScript/TypeScript/Java/Kotlin/C#/Go/C/C++/Rust/Ruby/PHP source -> detects language/framework and offers the real external runner bridge through Termux when Termux is installed and configured.
- Unknown source -> execution is blocked with a clear message.

External source is not falsely reported as locally executable by standard Android. Termux RUN_COMMAND requires the Termux permission/configuration described in the app dialog. Browser frameworks still require the browser/WebDriver/runtime supported by that external environment.

Recorder passwords remain `secret:true` without storing the password value. File inputs remain explicit file steps. Failed selectors/assertions/secrets stop the native runner with an error.

## CODEGEN — one recording, multiple real methods

Current curated generator matrix (30 language/method combinations):

- Python: Playwright, Selenium WebDriver, Pyppeteer. Main file is always `bot.py`.
- JavaScript: Playwright, Puppeteer, WebdriverIO, Selenium WebDriver, Cypress.
- TypeScript: Playwright, Puppeteer, WebdriverIO, Selenium WebDriver, Cypress.
- Java: Playwright, Selenium WebDriver, Selenide.
- Kotlin: Selenium WebDriver, Selenide.
- C#: Playwright, Selenium WebDriver.
- Go: chromedp, Rod.
- C: W3C WebDriver + libcurl.
- C++: W3C WebDriver + libcurl.
- Rust: thirtyfour WebDriver, Fantoccini.
- Ruby: Selenium WebDriver, Capybara.
- PHP: php-webdriver, Symfony Panther.

The method chooser only exposes methods with an implemented project generator. DevScope does not claim this is every automation library ever published; it is a practical curated set with real dependency/project output.

### Live URL and User-Agent

On GENERATE, DevScope reads the currently open WebView URL and `WebSettings.getUserAgentString()`. If the Action Script has no initial `open`, the live URL is inserted as the first step. Where the selected engine supports it, generated browser configuration receives the captured User-Agent.

### Python naming

All Python engines export their primary source as exactly:

`bot.py`

Single-file EXPORT CODE also suggests `bot.py`; PROJECT ZIP uses `bot.py` as the project main file.

## Full PROJECT ZIP

PROJECT ZIP is verified before export. It contains the generated main source, canonical `flow.json`, `devscope-project.json`, README, the ecosystem dependency/build manifest, and the `devscope/` bootstrap bundle.

Depending on target this includes files such as `requirements.txt`, `package.json`, `tsconfig.json`, `pom.xml`, Gradle files, `.csproj`, `go.mod`, `CMakeLists.txt`, `Cargo.toml`, `Gemfile` or `composer.json`.

The bootstrap bundle contains:

- `devscope/setup.sh` / `setup.ps1`
- `devscope/install-toolchain.sh` / `install-toolchain.ps1`
- `devscope/verify.sh` / `verify.ps1`
- `devscope/repair.sh` / `repair.ps1`
- `devscope/env.example`
- `devscope/bootstrap.json`
- `devscope/DEPENDENCIES.md`

If a mandatory project/bootstrap file is missing or empty, PROJECT ZIP export is blocked instead of creating a misleading partial project.

## Deliberate limits

DevScope does not invent data that Android WebView does not expose. Browser/security/cross-origin restrictions still apply. Human verification/CAPTCHA is not automatically bypassed. Some generated external frameworks are not host-supported on stock Android; generated projects remain valid external projects and AUTOMATE only dispatches them to a real configured external toolchain when available.

## Build

- Android Native
- namespace/applicationId: `com.devscope.app`
- minSdk 24
- compileSdk/targetSdk 35
- Java 17 target
- Android Gradle Plugin 8.7.3
- Gradle distribution configured for 8.9
- versionCode 10 / versionName 4.2.0

Previous build fixes are retained: correct `android.print.PrintManager`, checked `JSONException` handling, keyboard-aware CODEGEN/AUTOMATE editors, and the approved DevScope launcher icon.
