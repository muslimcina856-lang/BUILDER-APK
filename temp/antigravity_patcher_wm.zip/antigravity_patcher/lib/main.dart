import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive_io.dart';

void main() {
  runApp(const AntigravityPatcherApp());
}

class AntigravityPatcherApp extends StatelessWidget {
  const AntigravityPatcherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Antigravity Patcher',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5FF),
          secondary: Color(0xFF1DE9B6),
          surface: Color(0xFF0D1117),
        ),
        scaffoldBackgroundColor: const Color(0xFF0D1117),
        cardColor: const Color(0xFF161B22),
      ),
      home: const PatcherHome(),
    );
  }
}

enum PatchStatus { idle, picking, extracting, installing, patching, ready, error }

class PatcherHome extends StatefulWidget {
  const PatcherHome({super.key});

  @override
  State<PatcherHome> createState() => _PatcherHomeState();
}

class _PatcherHomeState extends State<PatcherHome> with SingleTickerProviderStateMixin {
  PatchStatus _status = PatchStatus.idle;
  String _log = '';
  String? _selectedFile;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;

  final String termuxHome = '/data/data/com.termux/files/home';
  final String termuxBin = '/data/data/com.termux/files/usr/bin';
  final String ubuntuLib = '/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/ubuntu/usr/lib/aarch64-linux-gnu';
  final String ubuntuLib2 = '/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/ubuntu/usr/lib';
  final String termuxLib = '/data/data/com.termux/files/usr/lib';

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.6, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _addLog(String msg) {
    setState(() => _log += '${DateTime.now().toString().substring(11, 19)} $msg\n');
  }

  Future<void> _runShell(String cmd) async {
    _addLog('→ $cmd');
    final result = await Process.run('/data/data/com.termux/files/usr/bin/bash', ['-c', cmd]);
    if (result.stdout.toString().trim().isNotEmpty) _addLog(result.stdout.toString().trim());
    if (result.stderr.toString().trim().isNotEmpty) _addLog('! ${result.stderr.toString().trim()}');
  }

  Future<void> _pickFile() async {
    await Permission.storage.request();
    await Permission.manageExternalStorage.request();

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['gz', 'tar'],
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = result.files.single.path;
        _status = PatchStatus.idle;
        _log = '';
      });
    }
  }

  Future<void> _startPatch() async {
    if (_selectedFile == null) {
      _addLog('✗ Pilih fail dulu!');
      return;
    }

    setState(() { _status = PatchStatus.extracting; _log = ''; });

    try {
      // Step 1: Copy to termux home
      _addLog('━━━ STEP 1: Copy fail ke Termux ━━━');
      setState(() => _status = PatchStatus.extracting);
      final destTar = '$termuxHome/Antigravity IDE.tar.gz';
      await _runShell('cp "${_selectedFile!}" "$destTar"');

      // Step 2: Extract
      _addLog('━━━ STEP 2: Extract ━━━');
      final ideDir = '$termuxHome/Antigravity IDE';
      if (!Directory(ideDir).existsSync()) {
        await _runShell('cd "$termuxHome" && tar -xzf "Antigravity IDE.tar.gz"');
      } else {
        _addLog('✓ Folder dah ada — skip extract');
      }
      await _runShell('chmod +x "$ideDir/antigravity-ide" "$ideDir/chrome-sandbox" "$ideDir/chrome_crashpad_handler"');

      // Step 3: Install Ubuntu libs
      _addLog('━━━ STEP 3: Install libraries ━━━');
      setState(() => _status = PatchStatus.installing);
      await _runShell('$termuxBin/proot-distro login ubuntu -- bash -c "'
          'apt-get update -qq 2>/dev/null; '
          'apt-get install -y -qq libglib2.0-0t64 libnspr4 libnss3 libdbus-1-3 '
          'libatk1.0-0t64 libatk-bridge2.0-0t64 libcups2t64 libcairo2 libgtk-3-0t64 '
          'libpango-1.0-0 libx11-6 libxcomposite1 libxdamage1 libxext6 libxfixes3 '
          'libxrandr2 libgbm1 libexpat1 libxcb1 libxkbcommon0 libudev1 libasound2t64 '
          'libatspi2.0-0t64 libgcc-s1 2>/dev/null || true; '
          'ln -sf /usr/lib/aarch64-linux-gnu/libc.so.6 /usr/lib/aarch64-linux-gnu/libc.so 2>/dev/null; '
          'ln -sf /usr/lib/aarch64-linux-gnu/libm.so.6 /usr/lib/aarch64-linux-gnu/libm.so 2>/dev/null'
          '"');

      // Step 4: Patch binary
      _addLog('━━━ STEP 4: Patch binary ━━━');
      setState(() => _status = PatchStatus.patching);
      final linker = '$ubuntuLib2/ld-linux-aarch64.so.1';
      await _runShell('$termuxBin/patchelf --set-interpreter "$linker" "$ideDir/antigravity-ide"');
      await _runShell('$termuxBin/patchelf --set-rpath "/system/lib64:$ubuntuLib:$ubuntuLib2:$termuxLib:$ideDir" "$ideDir/antigravity-ide"');

      // Step 5: Create launcher
      _addLog('━━━ STEP 5: Buat launcher ━━━');
      final launcher = '''#!/data/data/com.termux/files/usr/bin/bash
termux-x11 :0 &
sleep 3
export DISPLAY=:0
export LD_LIBRARY_PATH=/system/lib64:$ubuntuLib:$ubuntuLib2:$termuxLib:"$ideDir"
cd "$ideDir"
./antigravity-ide --no-sandbox --disable-gpu-sandbox --disable-seccomp-filter-sandbox 2>/tmp/antigravity.log
''';
      File('$termuxHome/start-antigravity.sh').writeAsStringSync(launcher);
      await _runShell('chmod +x "$termuxHome/start-antigravity.sh"');

      _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━');
      _addLog('✓ SELESAI! Run: ~/start-antigravity.sh');
      setState(() => _status = PatchStatus.ready);

    } catch (e) {
      _addLog('✗ Error: $e');
      setState(() => _status = PatchStatus.error);
    }
  }

  Future<void> _launch() async {
    await _runShell('/data/data/com.termux/files/usr/bin/bash $termuxHome/start-antigravity.sh &');
  }

  Color get _statusColor {
    switch (_status) {
      case PatchStatus.ready: return const Color(0xFF1DE9B6);
      case PatchStatus.error: return const Color(0xFFFF5252);
      case PatchStatus.idle: return const Color(0xFF00E5FF);
      default: return const Color(0xFFFFD740);
    }
  }

  String get _statusText {
    switch (_status) {
      case PatchStatus.idle: return 'SEDIA';
      case PatchStatus.picking: return 'PILIH FAIL...';
      case PatchStatus.extracting: return 'EXTRACTING...';
      case PatchStatus.installing: return 'INSTALL LIBS...';
      case PatchStatus.patching: return 'PATCHING...';
      case PatchStatus.ready: return 'SIAP! BOLEH LAUNCH';
      case PatchStatus.error: return 'ERROR';
    }
  }

  bool get _isProcessing => [
    PatchStatus.extracting,
    PatchStatus.installing,
    PatchStatus.patching,
  ].contains(_status);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  AnimatedBuilder(
                    animation: _pulse,
                    builder: (_, __) => Opacity(
                      opacity: _isProcessing ? _pulse.value : 1.0,
                      child: Container(
                        width: 10, height: 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _statusColor,
                          boxShadow: [BoxShadow(color: _statusColor.withOpacity(0.5), blurRadius: 8, spreadRadius: 2)],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text('ANTIGRAVITY PATCHER',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF00E5FF),
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 6),
              Text('Android Binary Translator',
                style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12, letterSpacing: 1),
              ),

              const SizedBox(height: 24),

              // Status badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: _statusColor.withOpacity(0.4)),
                  borderRadius: BorderRadius.circular(6),
                  color: _statusColor.withOpacity(0.08),
                ),
                child: Text(_statusText,
                  style: TextStyle(color: _statusColor, fontFamily: 'monospace', fontSize: 13, letterSpacing: 1),
                ),
              ),

              const SizedBox(height: 20),

              // File picker
              GestureDetector(
                onTap: _isProcessing ? null : _pickFile,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: _selectedFile != null
                        ? const Color(0xFF1DE9B6).withOpacity(0.5)
                        : Colors.white.withOpacity(0.15),
                      style: BorderStyle.solid,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    color: const Color(0xFF161B22),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _selectedFile != null ? Icons.check_circle_outline : Icons.folder_open,
                        color: _selectedFile != null ? const Color(0xFF1DE9B6) : Colors.white54,
                        size: 20,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _selectedFile != null
                            ? _selectedFile!.split('/').last
                            : 'Pilih Antigravity IDE.tar.gz',
                          style: TextStyle(
                            color: _selectedFile != null ? Colors.white : Colors.white38,
                            fontFamily: 'monospace',
                            fontSize: 13,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Patch button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isProcessing ? null : _startPatch,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00E5FF),
                    foregroundColor: const Color(0xFF0D1117),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    disabledBackgroundColor: Colors.white12,
                  ),
                  child: Text(
                    _isProcessing ? 'PROCESSING...' : 'PATCH & SETUP',
                    style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, letterSpacing: 2),
                  ),
                ),
              ),

              if (_status == PatchStatus.ready) ...[
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _launch,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1DE9B6),
                      foregroundColor: const Color(0xFF0D1117),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('LAUNCH IDE',
                      style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, letterSpacing: 2),
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 16),

              // Log viewer
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0E14),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: SingleChildScrollView(
                    reverse: true,
                    child: Text(
                      _log.isEmpty ? '// log akan muncul di sini...' : _log,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11,
                        color: _log.isEmpty ? Colors.white24 : const Color(0xFF8BC34A),
                        height: 1.6,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
