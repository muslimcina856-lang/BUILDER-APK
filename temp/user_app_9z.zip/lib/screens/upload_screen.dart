import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/services/api_service.dart';
import 'package:earl_builder/services/storage_service.dart';
import 'package:earl_builder/models/upload_history.dart';
import 'package:earl_builder/theme/app_theme.dart';

class UploadScreen extends StatefulWidget {
  final String deviceId;
  const UploadScreen({super.key, required this.deviceId});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final TextEditingController _linkController = TextEditingController();
  final TextEditingController _fileNameController = TextEditingController();

  bool _isUploading = false;
  bool _isProcessing = false;
  String _statusKey = 'upload_ready';
  String? _statusParam;
  bool _isDone = false;
  final AudioPlayer _successPlayer = AudioPlayer();
  late final Future<void> _successSoundReady;

  @override
  void initState() {
    super.initState();
    _successSoundReady = _prepareSuccessSound();
  }

  Future<void> _prepareSuccessSound() async {
    await _successPlayer.setAsset('assets/sounds/success_ting.mp3');
  }

  Future<void> _playSuccessSound() async {
    try {
      await _successSoundReady;
      await _successPlayer.seek(Duration.zero);
      await _successPlayer.play();
    } catch (_) {
      // Bunyi kejayaan tidak boleh mengganggu aliran penghantaran.
    }
  }

  Future<void> _showFailureDialog(String errorMsg) async {
    final failureTitle =
        tr(context, 'upload_failed_colon').replaceAll(':', '').trim();

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: AppSpacing.xxl),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.xxl),
            decoration: BoxDecoration(
              color: AppColors.bgElevated,
              borderRadius: BorderRadius.circular(AppRadius.hero),
              border: Border.all(
                color: AppColors.error.withAlpha(90),
                width: 1,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.error.withAlpha(24),
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.error, width: 2),
                  ),
                  alignment: Alignment.center,
                  child: const Icon(
                    Icons.close_rounded,
                    size: 36,
                    color: AppColors.error,
                  ),
                ),
                const SizedBox(height: AppSpacing.lg),
                Text(
                  failureTitle,
                  style: AppText.title,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSpacing.sm),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 220),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      errorMsg,
                      style: AppText.subtitle.copyWith(
                        color: AppColors.textSecondary,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                const SizedBox(height: AppSpacing.xl),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.error,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => Navigator.of(dialogContext).pop(),
                    child: Text(tr(dialogContext, 'common_ok')),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _linkController.dispose();
    _fileNameController.dispose();
    _successPlayer.dispose();
    super.dispose();
  }

  String _historyName(String link) {
    final uri = Uri.tryParse(link);
    if (uri != null && uri.pathSegments.isNotEmpty) {
      final lastSegment = uri.pathSegments.last.trim();
      if (lastSegment.isNotEmpty) {
        try {
          return Uri.decodeComponent(lastSegment);
        } catch (_) {
          return lastSegment;
        }
      }
    }
    return 'project-link.txt';
  }

  void _resetSelection() {
    _linkController.clear();
    _fileNameController.clear();
    setState(() {
      _isUploading = false;
      _isProcessing = false;
      _statusKey = 'upload_ready';
      _statusParam = null;
      _isDone = false;
    });
  }

  void _onLinkChanged(String value) {
    if (_isUploading || _isProcessing) return;
    setState(() {
      _statusKey = value.trim().isEmpty ? 'upload_ready' : 'upload_link_ready';
      _statusParam = null;
      _isDone = false;
    });
  }

  Future<void> _startUpload() async {
    final projectUrl = _linkController.text.trim();
    if (projectUrl.isEmpty) return;

    final optionalFileName = _fileNameController.text.trim();
    final historyName = optionalFileName.isNotEmpty
        ? optionalFileName
        : _historyName(projectUrl);
    setState(() {
      _isUploading = true;
      _isProcessing = true;
      _statusKey = 'upload_processing';
      _statusParam = null;
    });

    try {
      final completeResult = await ApiService.submitProjectLink(
        deviceId: widget.deviceId,
        projectUrl: projectUrl,
        fileName: optionalFileName.isEmpty ? null : optionalFileName,
      );

      await StorageService.addHistory(UploadHistory(
        fileName: historyName,
        fileSize: projectUrl.length,
        status: 'building',
        uniqueName: completeResult['unique_name']?.toString() ?? '',
        timestamp: DateTime.now().toIso8601String(),
        creditsUsed: 1,
        frameworkType: 'Link',
      ));

      if (!mounted) return;
      _linkController.clear();
      _fileNameController.clear();
      setState(() {
        _isUploading = false;
        _isProcessing = false;
        _statusKey = 'upload_success_queued';
        _statusParam = null;
        _isDone = true;
      });
      await _playSuccessSound();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${tr(context, 'upload_success')}: ${completeResult['unique_name']}',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      var errorMsg = e.toString();
      var creditsCharged = false;
      if (e is DioException) {
        final data = e.response?.data;
        if (data is Map) {
          creditsCharged = data['charged'] == true;
          if (data['error'] != null) errorMsg = data['error'].toString();
        } else if (e.type == DioExceptionType.connectionError ||
            e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          errorMsg = trStatic(context, 'common_server_error');
        }
      }

      await StorageService.addHistory(UploadHistory(
        fileName: historyName,
        fileSize: projectUrl.length,
        status: 'failed',
        uniqueName: '',
        timestamp: DateTime.now().toIso8601String(),
        creditsUsed: creditsCharged ? 1 : 0,
        frameworkType: 'Link',
      ));

      if (!mounted) return;
      setState(() {
        _isUploading = false;
        _isProcessing = false;
        _statusKey = 'upload_failed_colon';
        _statusParam = errorMsg;
      });
      await _showFailureDialog(errorMsg);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasLink = _linkController.text.trim().isNotEmpty;
    final statusText = _statusParam != null
        ? '${tr(context, _statusKey)} $_statusParam'
        : tr(context, _statusKey);

    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'upload_title'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            const SizedBox(height: AppSpacing.md),
            _LinkInputCard(
              controller: _linkController,
              fileNameController: _fileNameController,
              disabled: _isUploading || _isProcessing,
              onChanged: _onLinkChanged,
            ),
            const SizedBox(height: AppSpacing.xl),
            if (_isUploading || _isProcessing || _isDone)
              _ProgressSection(statusText: statusText, isDone: _isDone),
            if (_isUploading || _isProcessing || _isDone)
              const SizedBox(height: AppSpacing.xl),
            _ActionButton(
              hasLink: hasLink,
              isUploading: _isUploading,
              isProcessing: _isProcessing,
              isDone: _isDone,
              onUpload: _startUpload,
              onReset: _resetSelection,
            ),
          ],
        ),
      ),
    );
  }
}

class _LinkInputCard extends StatelessWidget {
  final TextEditingController controller;
  final TextEditingController fileNameController;
  final bool disabled;
  final ValueChanged<String> onChanged;

  const _LinkInputCard({
    required this.controller,
    required this.fileNameController,
    required this.disabled,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.hero),
        border: Border.all(color: AppColors.bgOverlay),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: AppColors.bgRaised,
              borderRadius: BorderRadius.circular(AppRadius.input),
            ),
            alignment: Alignment.center,
            child: const Icon(
              Icons.link_rounded,
              size: AppIcons.hero,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Text(tr(context, 'upload_enter_project_link'), style: AppText.heading),
          const SizedBox(height: AppSpacing.xs),
          Text(
            tr(context, 'upload_supports'),
            style: AppText.subtitle,
          ),
          const SizedBox(height: AppSpacing.lg),
          TextField(
            controller: controller,
            enabled: !disabled,
            keyboardType: TextInputType.url,
            autocorrect: false,
            enableSuggestions: false,
            minLines: 2,
            maxLines: 4,
            onChanged: onChanged,
            decoration: InputDecoration(
              labelText: tr(context, 'upload_link_label'),
              hintText: 'https://example.com/project.zip',
              prefixIcon: const Icon(Icons.language_rounded),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          TextField(
            controller: fileNameController,
            enabled: !disabled,
            autocorrect: false,
            enableSuggestions: false,
            maxLength: 80,
            decoration: InputDecoration(
              labelText: tr(context, 'upload_file_name_optional'),
              hintText: tr(context, 'upload_file_name_hint'),
              helperText: tr(context, 'upload_file_name_helper'),
              prefixIcon: const Icon(Icons.drive_file_rename_outline_rounded),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressSection extends StatelessWidget {
  final String statusText;
  final bool isDone;

  const _ProgressSection({required this.statusText, required this.isDone});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              switchInCurve: Curves.easeOutBack,
              switchOutCurve: Curves.easeIn,
              child: isDone
                  ? Container(
                      key: const ValueKey('success'),
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: AppColors.accentMuted,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppColors.accent,
                          width: 3,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.check_rounded,
                        size: 38,
                        color: AppColors.accent,
                      ),
                    )
                  : const SizedBox(
                      key: ValueKey('loading'),
                      width: 64,
                      height: 64,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        strokeCap: StrokeCap.round,
                        valueColor: AlwaysStoppedAnimation(AppColors.accent),
                        backgroundColor: AppColors.bgRaised,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Text(
            statusText,
            style: AppText.heading.copyWith(fontSize: 15),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final bool hasLink;
  final bool isUploading;
  final bool isProcessing;
  final bool isDone;
  final VoidCallback onUpload;
  final VoidCallback onReset;

  const _ActionButton({
    required this.hasLink,
    required this.isUploading,
    required this.isProcessing,
    required this.isDone,
    required this.onUpload,
    required this.onReset,
  });

  @override
  Widget build(BuildContext context) {
    if (isDone) {
      return Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(tr(context, 'upload_back')),
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: ElevatedButton(
              onPressed: onReset,
              child: Text(tr(context, 'upload_submit_another')),
            ),
          ),
        ],
      );
    }
    final disabled = !hasLink || isUploading || isProcessing;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: disabled ? null : onUpload,
        icon: const Icon(Icons.send_rounded, size: AppIcons.md),
        label: Text(
          hasLink
              ? tr(context, 'upload_submit_project')
              : tr(context, 'upload_select_file_first'),
        ),
      ),
    );
  }
}
