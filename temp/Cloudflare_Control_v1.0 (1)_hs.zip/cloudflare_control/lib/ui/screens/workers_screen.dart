import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:file_picker/file_picker.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'dart:typed_data';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class WorkersScreen extends StatefulWidget {
  const WorkersScreen({super.key});

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  List<dynamic> workers = [];
  List<dynamic> pages = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final w = await api.getWorkers().catchError((_) => <dynamic>[]);
      final p = await api.getPagesProjects().catchError((_) => <dynamic>[]);
      setState(() {
        workers = w;
        pages = p;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.parse(url);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  Future<void> _openWorker(String name) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final api = CloudflareApi(account);
      final code = await api.getWorkerScript(name);
      if (!mounted) return;
      Navigator.pop(context);

      final changed = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => WorkerCodeScreen(
            name: name,
            code: code,
            accountId: account.id,
            canEdit: true,
          ),
        ),
      );
      if (changed == true) _load();
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context);
      _openExternal(
        'https://dash.cloudflare.com/${account.id}/workers/services/view/$name/production',
      );
    }
  }

  Future<void> _createWorker() async {
    final nameCtrl = TextEditingController();
    final codeCtrl = TextEditingController(
      text: '''export default {
  async fetch(request, env, ctx) {
    return new Response("Hello from Cloudflare Control!");
  },
};''',
    );

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta Worker'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Nama Worker',
                    hintText: 'my-worker',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: codeCtrl,
                  maxLines: 10,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  decoration: const InputDecoration(
                    labelText: 'Kod (JS/TS)',
                    alignLabelWithHint: true,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Deploy')),
        ],
      ),
    );

    if (result != true) return;
    final name = nameCtrl.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9-_]'), '-');
    final code = codeCtrl.text;
    if (name.isEmpty || code.trim().isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createWorkerScript(name, code);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Worker berjaya di-deploy'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deleteWorker(String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Worker?'),
        content: Text('Padam "$name"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteWorkerScript(name);
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _createPage() async {
    final nameCtrl = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta Pages Project'),
        content: TextField(
          controller: nameCtrl,
          decoration: const InputDecoration(
            labelText: 'Nama project',
            hintText: 'my-site',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
        ],
      ),
    );
    if (result != true) return;
    final name = nameCtrl.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9-]'), '-');
    if (name.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createPagesProject(name);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pages project dicipta. Upload fail di Dashboard.'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deletePage(String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Pages?'),
        content: Text('Padam project "$name"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deletePagesProject(name);
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }


  Future<void> _uploadPages(String projectName) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: true,
      type: FileType.any,
    );
    if (result == null || result.files.isEmpty) return;

    // Preview as directory tree before deploy
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Upload ke $projectName'),
        content: SizedBox(
          width: double.maxFinite,
          height: 320,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${result.files.length} fail dipilih',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  itemCount: result.files.length,
                  itemBuilder: (_, i) {
                    final f = result.files[i];
                    final size = f.size;
                    final sizeLabel = size > 1024 * 1024
                        ? '${(size / (1024 * 1024)).toStringAsFixed(1)} MB'
                        : size > 1024
                            ? '${(size / 1024).toStringAsFixed(1)} KB'
                            : '$size B';
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.insert_drive_file_outlined, size: 20),
                      title: Text(f.name, overflow: TextOverflow.ellipsis),
                      subtitle: Text(sizeLabel),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Deploy')),
        ],
      ),
    );
    if (confirmed != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(
        content: Row(
          children: [
            CircularProgressIndicator(),
            SizedBox(width: 16),
            Expanded(child: Text('Memuat naik & deploy...')),
          ],
        ),
      ),
    );

    try {
      final api = CloudflareApi(account);
      final jwt = await api.getPagesUploadToken(projectName);
      if (jwt.isEmpty) throw Exception('Gagal dapat upload token');

      final manifest = <String, String>{};
      final assets = <Map<String, dynamic>>[];

      for (final f in result.files) {
        if (f.bytes == null) continue;
        final bytes = f.bytes!;
        final hash = md5.convert(bytes).toString();
        final pathName = f.name;
        manifest[pathName] = hash;
        assets.add({
          'key': hash,
          'value': base64Encode(bytes),
          'contentType': _guessMime(f.name),
        });
      }

      if (assets.isEmpty) throw Exception('Tiada fail sah (bytes null)');

      for (var i = 0; i < assets.length; i += 20) {
        final endIdx = (i + 20 > assets.length) ? assets.length : i + 20;
        final batch = assets.sublist(i, endIdx);
        await api.uploadPagesAssets(jwt, batch);
      }

      await api.createPagesDeployment(projectName, manifest);

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${assets.length} fail di-deploy ke $projectName'),
            backgroundColor: AppColors.success,
          ),
        );
        _load();
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal upload: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  String _guessMime(String name) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'text/html';
    if (lower.endsWith('.css')) return 'text/css';
    if (lower.endsWith('.js')) return 'application/javascript';
    if (lower.endsWith('.json')) return 'application/json';
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    if (lower.endsWith('.svg')) return 'image/svg+xml';
    if (lower.endsWith('.txt')) return 'text/plain';
    if (lower.endsWith('.webp')) return 'image/webp';
    if (lower.endsWith('.woff2')) return 'font/woff2';
    return 'application/octet-stream';
  }

  Future<void> _openPage(String name, String? subdomain) async {
    if (subdomain != null && subdomain.isNotEmpty) {
      final url = subdomain.startsWith('http') ? subdomain : 'https://$subdomain';
      await _openExternal(url);
    } else {
      final app = context.read<AppController>();
      final id = app.activeAccount?.id ?? '';
      await _openExternal('https://dash.cloudflare.com/$id/pages/view/$name');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Workers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              FilledButton.icon(
                onPressed: _createWorker,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Cipta'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (workers.isEmpty)
            const Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Text('Tiada Workers', style: TextStyle(color: AppColors.muted)),
            )
          else
            ...workers.map((w) {
              final name = (w['id'] ?? w['name'] ?? '-').toString();
              final modified = w['modified_on']?.toString() ?? '-';
              final short = modified.length > 19 ? modified.substring(0, 19) : modified;
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.code, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text('Modified: $short'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                        onPressed: () => _deleteWorker(name),
                      ),
                      const Icon(Icons.chevron_right, color: AppColors.muted),
                    ],
                  ),
                  onTap: () => _openWorker(name),
                ),
              );
            }),
          const SizedBox(height: 24),
          Row(
            children: [
              const Expanded(
                child: Text('Pages Projects', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              FilledButton.icon(
                onPressed: _createPage,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Cipta'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (pages.isEmpty)
            const Text('Tiada Pages project', style: TextStyle(color: AppColors.muted))
          else
            ...pages.map((p) {
              final name = (p['name'] ?? '-').toString();
              final subdomain = p['subdomain']?.toString();
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.web, color: AppColors.primary),
                  title: Text(name),
                  subtitle: Text(subdomain ?? ''),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.upload_file, color: AppColors.primary, size: 20),
                        tooltip: 'Upload fail',
                        onPressed: () => _uploadPages(name),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                        onPressed: () => _deletePage(name),
                      ),
                      const Icon(Icons.open_in_new, size: 18, color: AppColors.muted),
                    ],
                  ),
                  onTap: () => _openPage(name, subdomain),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class WorkerCodeScreen extends StatefulWidget {
  final String name;
  final String code;
  final String accountId;
  final bool canEdit;

  const WorkerCodeScreen({
    super.key,
    required this.name,
    required this.code,
    required this.accountId,
    this.canEdit = false,
  });

  @override
  State<WorkerCodeScreen> createState() => _WorkerCodeScreenState();
}

class _WorkerCodeScreenState extends State<WorkerCodeScreen> {
  late TextEditingController _codeCtrl;
  bool editing = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _codeCtrl = TextEditingController(text: widget.code);
  }

  @override
  void dispose() {
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() => saving = true);
    try {
      final api = CloudflareApi(account);
      await api.createWorkerScript(widget.name, _codeCtrl.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Worker dikemaskini'), backgroundColor: AppColors.success),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _openDash() async {
    final uri = Uri.parse(
      'https://dash.cloudflare.com/${widget.accountId}/workers/services/view/${widget.name}/production',
    );
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name, overflow: TextOverflow.ellipsis),
        actions: [
          if (widget.canEdit)
            IconButton(
              icon: Icon(editing ? Icons.visibility_outlined : Icons.edit_outlined),
              tooltip: editing ? 'View' : 'Edit',
              onPressed: () => setState(() => editing = !editing),
            ),
          IconButton(
            icon: const Icon(Icons.open_in_new),
            tooltip: 'Dashboard',
            onPressed: _openDash,
          ),
        ],
      ),
      body: widget.code.isEmpty && !editing
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.code_off, size: 48, color: AppColors.muted),
                    const SizedBox(height: 12),
                    const Text(
                      'Kod tidak dapat dimuat',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Worker module/complex format mungkin tidak disokong baca terus. '
                      'Tekan Edit untuk tulis semula, atau buka Dashboard.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.muted, fontSize: 13),
                    ),
                    const SizedBox(height: 16),
                    if (widget.canEdit)
                      FilledButton.icon(
                        onPressed: () => setState(() => editing = true),
                        icon: const Icon(Icons.edit),
                        label: const Text('Edit / Tulis kod'),
                      ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: editing
                      ? Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _codeCtrl,
                            maxLines: null,
                            expands: true,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              alignLabelWithHint: true,
                            ),
                          ),
                        )
                      : _ModuleTreeView(code: _codeCtrl.text),
                ),
                if (editing)
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: saving ? null : _save,
                          child: saving
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                              : const Text('Deploy / Simpan'),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}

class _ModuleTreeView extends StatelessWidget {
  final String code;
  const _ModuleTreeView({required this.code});

  @override
  Widget build(BuildContext context) {
    final modules = _splitModules(code);
    if (modules.length <= 1) {
      return SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: SelectableText(
          code.isEmpty ? 'Tiada kod' : code,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 12, height: 1.4),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: modules.length,
      itemBuilder: (_, i) {
        final m = modules[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ExpansionTile(
            leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.primary),
            title: Text(m.key, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            subtitle: Text('${m.value.length} chars', style: const TextStyle(fontSize: 11)),
            children: [
              Container(
                width: double.infinity,
                color: Colors.black.withOpacity(0.03),
                padding: const EdgeInsets.all(12),
                child: SelectableText(
                  m.value,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 11, height: 1.4),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  List<MapEntry<String, String>> _splitModules(String code) {
    final re = RegExp(r'^// ===== (.+?) =====\s*$', multiLine: true);
    final matches = re.allMatches(code).toList();
    if (matches.isEmpty) {
      return [MapEntry('script', code)];
    }
    final result = <MapEntry<String, String>>[];
    for (var i = 0; i < matches.length; i++) {
      final name = matches[i].group(1) ?? 'module';
      final start = matches[i].end;
      final end = i + 1 < matches.length ? matches[i + 1].start : code.length;
      result.add(MapEntry(name, code.substring(start, end).trim()));
    }
    return result;
  }
}
