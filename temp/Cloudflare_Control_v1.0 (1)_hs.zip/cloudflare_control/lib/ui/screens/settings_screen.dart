import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const _channelUrl = 'https://t.me/earlstore2004';
  static const _contactUrl = 'https://t.me/earlxz';
  static const _privacyUrl = 'https://app.earlstore.online/privacy';

  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) {
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      }
    } catch (_) {
      try {
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      } catch (e) {
        // ignore
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final isMalay = app.locale?.languageCode == 'ms';

    return Scaffold(
      appBar: AppBar(
        title: Text(isMalay ? 'Tetapan' : 'Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Language
          Text(isMalay ? 'Bahasa' : 'Language', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                RadioListTile<String>(
                  title: const Text('Bahasa Melayu'),
                  value: 'ms',
                  groupValue: app.locale?.languageCode,
                  onChanged: (v) => app.setLocale(const Locale('ms')),
                ),
                RadioListTile<String>(
                  title: const Text('English'),
                  value: 'en',
                  groupValue: app.locale?.languageCode,
                  onChanged: (v) => app.setLocale(const Locale('en')),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Channel & Contact
          Text(isMalay ? 'Sokongan' : 'Support', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _openLink(_channelUrl),
                  icon: const Icon(Icons.campaign_outlined),
                  label: Text(isMalay ? 'Saluran Saya' : 'My Channel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _openLink(_contactUrl),
                  icon: const Icon(Icons.support_agent_rounded),
                  label: Text(isMalay ? 'Hubungi Kami' : 'Contact Us'),
                ),
              ),
            ],
          ),

          const SizedBox(height: 28),

          // Dangerous zone
          Text(isMalay ? 'Zon Sensitif' : 'Danger Zone', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text(isMalay ? 'Padam semua akaun?' : 'Delete all accounts?'),
                  content: Text(isMalay
                      ? 'Semua Global API Key akan dipadam dari peranti ini.'
                      : 'All Global API Keys will be removed from this device.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(isMalay ? 'Batal' : 'Cancel')),
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                      child: Text(isMalay ? 'Padam' : 'Delete'),
                    ),
                  ],
                ),
              );
              if (confirm == true && context.mounted) {
                await app.clearAllAccounts();
                Navigator.pop(context);
              }
            },
            icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.danger),
            label: Text(
              isMalay ? 'Padam semua akaun' : 'Delete all accounts',
              style: const TextStyle(color: AppColors.danger),
            ),
          ),

          const SizedBox(height: 40),
          Center(
            child: TextButton(
              onPressed: () => _openLink(_privacyUrl),
              child: const Text(
                '© 2026 Earlxz. All rights reserved.',
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
