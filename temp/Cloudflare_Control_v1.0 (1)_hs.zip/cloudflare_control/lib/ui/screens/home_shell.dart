import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_controller.dart';
import 'settings_screen.dart';
import 'token_screen.dart';
import 'dns_screen.dart';
import 'email_routing_screen.dart';
import 'dashboard_screen.dart';
import 'workers_screen.dart';
import 'storage_screen.dart';
import 'account_screen.dart';
import 'security_screen.dart';
import 'notifications_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;

  final List<_MenuItem> _menu = [
    _MenuItem(Icons.dashboard_outlined, 'Dashboard', 'Dashboard'),
    _MenuItem(Icons.language, 'Domain & DNS', 'Domain & DNS'),
    _MenuItem(Icons.email_outlined, 'Email Routing', 'Email Routing'),
    _MenuItem(Icons.code, 'Workers & Pages', 'Workers & Pages'),
    _MenuItem(Icons.storage_outlined, 'Storage', 'Storage'),
    _MenuItem(Icons.security_outlined, 'Security', 'Security'),
    _MenuItem(Icons.account_circle_outlined, 'Account', 'Account'),
    _MenuItem(Icons.notifications_outlined, 'Notifikasi', 'Notifications'),
  ];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final account = app.activeAccount;

    return Scaffold(
      appBar: AppBar(
        title: Text(account?.email ?? 'Cloudflare Control'),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Tukar / Urus Akaun',
            onSelected: (id) {
              if (id == '__add__') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const TokenScreen()));
              } else {
                app.setActiveAccount(id);
              }
            },
            itemBuilder: (ctx) => [
              ...app.accounts.map((a) => PopupMenuItem(
                    value: a.id,
                    child: Row(
                      children: [
                        Icon(
                          a.id == app.activeAccountId ? Icons.check_circle : Icons.account_circle_outlined,
                          size: 18,
                          color: a.id == app.activeAccountId ? AppColors.primary : AppColors.muted,
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: Text(a.email, overflow: TextOverflow.ellipsis)),
                      ],
                    ),
                  )),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: '__add__',
                child: Row(
                  children: [
                    Icon(Icons.person_add_outlined, size: 18),
                    SizedBox(width: 8),
                    Text('Tambah Akaun'),
                  ],
                ),
              ),
            ],
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Icon(Icons.swap_horiz),
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipOval(
                      child: Image.asset('assets/icon/app_icon.png', width: 52, height: 52, fit: BoxFit.cover),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Cloudflare Control',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (account != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        account.email,
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ],
                ),
              ),

              // Menu items
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    for (int i = 0; i < _menu.length; i++)
                      ListTile(
                        leading: Icon(
                          _menu[i].icon,
                          color: _selectedIndex == i ? AppColors.primary : AppColors.muted,
                        ),
                        title: Text(
                          _menu[i].ms,
                          style: TextStyle(
                            fontWeight: _selectedIndex == i ? FontWeight.w600 : FontWeight.w400,
                            color: _selectedIndex == i ? AppColors.primary : AppColors.text,
                          ),
                        ),
                        selected: _selectedIndex == i,
                        onTap: () {
                          setState(() => _selectedIndex = i);
                          Navigator.pop(context);
                        },
                      ),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.person_add_outlined),
                      title: const Text('Tambah Akaun'),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const TokenScreen()),
                        );
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.settings_outlined),
                      title: const Text('Tetapan'),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SettingsScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ),

              // Footer - tappable copyright
              Padding(
                padding: const EdgeInsets.all(16),
                child: GestureDetector(
                  onTap: () async {
                    final uri = Uri.parse('https://app.earlstore.online/privacy');
                    try {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    } catch (_) {
                      await launchUrl(uri, mode: LaunchMode.platformDefault);
                    }
                  },
                  child: const Text(
                    '© 2026 Earlxz. All rights reserved.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 11, color: AppColors.muted),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return const DashboardScreen();
      case 1:
        return const DnsScreen();
      case 2:
        return const EmailRoutingScreen();
      case 3:
        return const WorkersScreen();
      case 4:
        return const StorageScreen();
      case 5:
        return const SecurityScreen();
      case 6:
        return const AccountScreen();
      case 7:
        return const NotificationsScreen();
      default:
        return const Center(child: Text('Coming soon'));
    }
  }
}





class _MenuItem {
  final IconData icon;
  final String ms;
  final String en;
  const _MenuItem(this.icon, this.ms, this.en);
}
