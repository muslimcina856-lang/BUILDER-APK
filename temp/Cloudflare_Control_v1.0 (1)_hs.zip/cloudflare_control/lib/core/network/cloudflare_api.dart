import 'package:dio/dio.dart';
import '../../models/cloudflare_account.dart';

class CloudflareApi {
  final Dio _dio;
  final CloudflareAccount account;

  CloudflareApi(this.account)
      : _dio = Dio(BaseOptions(
          baseUrl: 'https://api.cloudflare.com/client/v4',
          headers: {
            'X-Auth-Email': account.email,
            'X-Auth-Key': account.token,
            'Content-Type': 'application/json',
          },
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 30),
        ));

  // ==================== ACCOUNT ====================
  Future<Map<String, dynamic>> getUser() async {
    final res = await _dio.get('/user');
    return res.data['result'] ?? {};
  }

  Future<List<dynamic>> getAccounts() async {
    final res = await _dio.get('/accounts');
    return res.data['result'] ?? [];
  }

  // ==================== ZONES ====================
  Future<List<dynamic>> getZones() async {
    final res = await _dio.get('/zones', queryParameters: {'per_page': 50});
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> getZone(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> createZone(String name, {bool jumpStart = true}) async {
    final res = await _dio.post('/zones', data: {
      'name': name,
      'account': {'id': account.id},
      'jump_start': jumpStart,
      'type': 'full',
    });
    return res.data['result'] ?? {};
  }

  Future<void> deleteZone(String zoneId) async {
    await _dio.delete('/zones/$zoneId');
  }

  // ==================== DNS RECORDS ====================
  Future<List<dynamic>> getDnsRecords(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/dns_records', queryParameters: {'per_page': 100});
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createDnsRecord(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.post('/zones/$zoneId/dns_records', data: data);
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateDnsRecord(String zoneId, String recordId, Map<String, dynamic> data) async {
    final res = await _dio.put('/zones/$zoneId/dns_records/$recordId', data: data);
    return res.data['result'] ?? {};
  }

  Future<void> deleteDnsRecord(String zoneId, String recordId) async {
    await _dio.delete('/zones/$zoneId/dns_records/$recordId');
  }

  // ==================== ZONE SETTINGS ====================
  Future<Map<String, dynamic>> getZoneSetting(String zoneId, String settingId) async {
    final res = await _dio.get('/zones/$zoneId/settings/$settingId');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateZoneSetting(String zoneId, String settingId, dynamic value) async {
    final res = await _dio.patch('/zones/$zoneId/settings/$settingId', data: {'value': value});
    return res.data['result'] ?? {};
  }

  // ==================== PURGE CACHE ====================
  Future<void> purgeEverything(String zoneId) async {
    await _dio.post('/zones/$zoneId/purge_cache', data: {'purge_everything': true});
  }

  Future<void> purgeUrls(String zoneId, List<String> urls) async {
    await _dio.post('/zones/$zoneId/purge_cache', data: {'files': urls});
  }

  // ==================== EMAIL ROUTING ====================
  Future<Map<String, dynamic>> getEmailRoutingSettings(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing');
    return res.data['result'] ?? {};
  }

  Future<List<dynamic>> getEmailRoutingRules(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing/rules');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createEmailRoutingRule(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.post('/zones/$zoneId/email/routing/rules', data: data);
    return res.data['result'] ?? {};
  }

  Future<void> deleteEmailRoutingRule(String zoneId, String ruleId) async {
    await _dio.delete('/zones/$zoneId/email/routing/rules/$ruleId');
  }

  Future<List<dynamic>> getEmailDestinationAddresses() async {
    final res = await _dio.get('/accounts/${account.id}/email/routing/addresses');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createEmailDestinationAddress(String email) async {
    final res = await _dio.post('/accounts/${account.id}/email/routing/addresses', data: {
      'email': email,
    });
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> getCatchAll(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing/rules/catch_all');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateCatchAll(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.put('/zones/$zoneId/email/routing/rules/catch_all', data: data);
    return res.data['result'] ?? {};
  }

  // ==================== WORKERS ====================
  Future<List<dynamic>> getWorkers() async {
    final res = await _dio.get('/accounts/${account.id}/workers/scripts');
    return res.data['result'] ?? [];
  }

  // ==================== PAGES ====================
  Future<List<dynamic>> getPagesProjects() async {
    final res = await _dio.get('/accounts/${account.id}/pages/projects');
    return res.data['result'] ?? [];
  }

  // ==================== R2 ====================
  Future<List<dynamic>> getR2Buckets() async {
    final res = await _dio.get('/accounts/${account.id}/r2/buckets');
    return res.data['result']?['buckets'] ?? [];
  }

  Future<Map<String, dynamic>> createR2Bucket(String name) async {
    final res = await _dio.post('/accounts/${account.id}/r2/buckets', data: {'name': name});
    return res.data['result'] ?? {};
  }

  Future<void> deleteR2Bucket(String name) async {
    await _dio.delete('/accounts/${account.id}/r2/buckets/$name');
  }

  // ==================== KV ====================
  Future<List<dynamic>> getKvNamespaces() async {
    final res = await _dio.get('/accounts/${account.id}/storage/kv/namespaces');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createKvNamespace(String title) async {
    final res = await _dio.post('/accounts/${account.id}/storage/kv/namespaces', data: {'title': title});
    return res.data['result'] ?? {};
  }

  // ==================== FIREWALL IP ACCESS RULES ====================

  Future<List<dynamic>> getIpAccessRules(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/firewall/access_rules/rules');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createIpAccessRule(String zoneId, String mode, String value, {String? notes}) async {
    final res = await _dio.post('/zones/$zoneId/firewall/access_rules/rules', data: {
      'mode': mode,
      'configuration': {'target': 'ip', 'value': value},
      if (notes != null) 'notes': notes,
    });
    return res.data['result'] ?? {};
  }

  Future<void> deleteIpAccessRule(String zoneId, String ruleId) async {
    await _dio.delete('/zones/$zoneId/firewall/access_rules/rules/$ruleId');
  }

  Future<List<dynamic>> getKvKeys(String namespaceId) async {
    final res = await _dio.get(
      '/accounts/${account.id}/storage/kv/namespaces/$namespaceId/keys',
      queryParameters: {'limit': 100},
    );
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> updateEmailRoutingSettings(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.patch('/zones/$zoneId/email/routing', data: data);
    return res.data['result'] ?? {};
  }

  /// content/v2 = official "Fetch script content only"
  /// GET /scripts/{name} = full download (module workers often multipart)
  Future<String> getWorkerScript(String scriptName) async {
    // 1) content/v2
    try {
      final res = await _dio.get(
        '/accounts/${account.id}/workers/scripts/$scriptName/content/v2',
        options: Options(responseType: ResponseType.bytes),
      );
      final text = _bytesToUsefulText(res.data);
      if (text.isNotEmpty) return text;
    } catch (_) {}

    // 2) Full download (plain or multipart)
    try {
      final res = await _dio.get(
        '/accounts/${account.id}/workers/scripts/$scriptName',
        options: Options(
          responseType: ResponseType.bytes,
          headers: {'Accept': '*/*'},
        ),
      );
      final contentType = (res.headers.value('content-type') ?? '').toLowerCase();
      final raw = res.data;
      if (raw == null) return '';

      if (contentType.contains('multipart') && raw is List<int>) {
        final parsed = _parseMultipartModules(List<int>.from(raw), contentType);
        if (parsed.isNotEmpty) return parsed;
      }

      final text = _bytesToUsefulText(raw);
      if (text.isNotEmpty) return text;
    } catch (_) {}

    return '';
  }

  String _bytesToUsefulText(dynamic data) {
    if (data == null) return '';
    final String s =
        data is List<int> ? String.fromCharCodes(data) : data.toString();
    final t = s.trim();
    if (t.isEmpty) return '';
    if (t.startsWith('{') &&
        (t.contains('"success"') || t.contains('"errors"'))) {
      return '';
    }
    return s;
  }

  String _parseMultipartModules(List<int> bytes, String contentType) {
    final body = String.fromCharCodes(bytes);
    String? boundary;
    final bMatch = RegExp(
      r'boundary=(?:"([^"]+)"|([^\s;]+))',
      caseSensitive: false,
    ).firstMatch(contentType);
    if (bMatch != null) {
      boundary = bMatch.group(1) ?? bMatch.group(2);
    }
    if (boundary == null || boundary.isEmpty) {
      final line = RegExp(r'^--([^\r\n]+)').firstMatch(body);
      if (line != null) boundary = line.group(1);
    }
    if (boundary == null || boundary.isEmpty) return '';

    final sep = '--$boundary';
    final parts = body.split(sep);
    final modules = <String>[];

    for (final part in parts) {
      final p = part.trim();
      if (p.isEmpty || p == '--' || p.startsWith('--')) continue;

      final headerEnd = p.indexOf('\r\n\r\n');
      final headerEnd2 = p.indexOf('\n\n');
      final int idx;
      if (headerEnd >= 0 && (headerEnd2 < 0 || headerEnd <= headerEnd2)) {
        idx = headerEnd + 4;
      } else if (headerEnd2 >= 0) {
        idx = headerEnd2 + 2;
      } else {
        continue;
      }

      final headers = p.substring(0, idx).toLowerCase();
      var bodyPart = p.substring(idx).trim();
      if (bodyPart.endsWith('--')) {
        bodyPart = bodyPart.substring(0, bodyPart.length - 2).trim();
      }

      final isJs = headers.contains('javascript') ||
          headers.contains('text/plain') ||
          headers.contains('.js') ||
          headers.contains('.mjs') ||
          headers.contains('.ts') ||
          headers.contains('filename=');

      final looksMeta = bodyPart.trimLeft().startsWith('{') &&
          (bodyPart.contains('main_module') || bodyPart.contains('body_part'));

      if (isJs && !looksMeta && bodyPart.isNotEmpty) {
        final fn = RegExp(
          r'filename="?([^";\r\n]+)"?',
          caseSensitive: false,
        ).firstMatch(headers);
        final name = fn?.group(1) ?? 'module';
        modules.add('// ===== $name =====\n$bodyPart');
      }
    }

    return modules.join('\n\n');
  }

  /// ES module Workers need multipart (metadata + main_module file)
  Future<void> createWorkerScript(String scriptName, String code) async {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    const fileName = 'worker.js';
    final metaJson =
        '{"main_module":"$fileName","compatibility_date":"$today"}';

    final formData = FormData.fromMap({
      'metadata': MultipartFile.fromString(
        metaJson,
        filename: 'metadata.json',
        contentType: DioMediaType('application', 'json'),
      ),
      fileName: MultipartFile.fromString(
        code,
        filename: fileName,
        contentType: DioMediaType('application', 'javascript+module'),
      ),
    });

    await _dio.put(
      '/accounts/${account.id}/workers/scripts/$scriptName',
      data: formData,
    );
  }

  Future<void> deleteWorkerScript(String scriptName) async {
    await _dio.delete('/accounts/${account.id}/workers/scripts/$scriptName');
  }

  Future<Map<String, dynamic>> createPagesProject(String name, {String productionBranch = 'main'}) async {
    final res = await _dio.post('/accounts/${account.id}/pages/projects', data: {
      'name': name,
      'production_branch': productionBranch,
    });
    return res.data['result'] ?? {};
  }

  Future<void> deletePagesProject(String name) async {
    await _dio.delete('/accounts/${account.id}/pages/projects/$name');
  }

  Future<String> getPagesUploadToken(String projectName) async {
    final res = await _dio.get('/accounts/${account.id}/pages/projects/$projectName/upload-token');
    return (res.data['result']?['jwt'] ?? '').toString();
  }

  Future<void> uploadPagesAssets(String jwt, List<Map<String, dynamic>> assets) async {
    final body = assets
        .map((a) => {
              'key': a['key'],
              'value': a['value'],
              'base64': true,
              'metadata': {'contentType': a['contentType'] ?? 'application/octet-stream'},
            })
        .toList();
    // Use a clean Dio so Global API Key headers do not conflict with JWT
    final uploadDio = Dio(BaseOptions(
      baseUrl: 'https://api.cloudflare.com/client/v4',
      headers: {
        'Authorization': 'Bearer $jwt',
        'Content-Type': 'application/json',
      },
    ));
    await uploadDio.post('/pages/assets/upload', data: body);
  }

  Future<Map<String, dynamic>> createPagesDeployment(
    String projectName,
    Map<String, String> manifest, {
    String branch = 'main',
  }) async {
    final parts = <String>[];
    manifest.forEach((k, v) {
      parts.add('"$k": "$v"');
    });
    final manifestJson = '{${parts.join(',')}}';
    final formData = FormData.fromMap({
      'manifest': manifestJson,
      'branch': branch,
    });
    final res = await _dio.post(
      '/accounts/${account.id}/pages/projects/$projectName/deployments',
      data: formData,
    );
    return res.data['result'] ?? {};
  }
}
