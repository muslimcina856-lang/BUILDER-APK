package com.cloudflare.manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
