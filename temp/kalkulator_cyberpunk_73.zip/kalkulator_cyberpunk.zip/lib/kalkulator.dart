import 'package:flutter/material.dart';

class KalkulatorScreen extends StatefulWidget {
  const KalkulatorScreen({super.key});

  @override
  State<KalkulatorScreen> createState() => _KalkulatorScreenState();
}

class _KalkulatorScreenState extends State<KalkulatorScreen> {
  String _output = "0";
  String _expression = "";
  double num1 = 0;
  double num2 = 0;
  String operand = "";

  // 🧠 LOGIKA BERHITUNG KALKULATOR
  void _buttonPressed(String buttonText) {
    if (buttonText == "CLEAR") {
      _output = "0";
      _expression = "";
      num1 = 0;
      num2 = 0;
      operand = "";
    } else if (buttonText == "+" || buttonText == "-" || buttonText == "×" || buttonText == "÷") {
      num1 = double.parse(_output);
      operand = buttonText;
      _expression = num1.toStringAsFixed(num1 % 1 == 0 ? 0 : 1) + " " + operand + " ";
      _output = "0";
    } else if (buttonText == "=") {
      num2 = double.parse(_output);
      _expression += num2.toStringAsFixed(num2 % 1 == 0 ? 0 : 1);
      
      if (operand == "+") _output = (num1 + num2).toString();
      if (operand == "-") _output = (num1 - num2).toString();
      if (operand == "×") _output = (num1 * num2).toString();
      if (operand == "÷") _output = num2 != 0 ? (num1 / num2).toString() : "ERROR";

      // Merapikan format angka desimal agar tidak burik
      double result = double.tryParse(_output) ?? 0;
      _output = result % 1 == 0 ? result.toStringAsFixed(0) : result.toStringAsFixed(2);
      operand = "";
    } else {
      if (_output == "0") {
        _output = buttonText;
      } else {
        _output = _output + buttonText;
      }
    }

    setState(() {});
  }

  // 🎨 WIDGET TEMPLATE TOMBOL BIAR KODE GA KEPANJANGAN
  Widget _buildButton(String text, Color color) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF151D2A),
            padding: const EdgeInsets.all(22),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(color: color, width: 1.5), // Efek Garis Neon
            ),
            shadowColor: color,
            elevation: 5,
          ),
          onPressed: () => _buttonPressed(text),
          child: Text(
            text,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color, fontFamily: 'monospace'),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E14), // Hitam Cyberpunk
      appBar: AppBar(
        backgroundColor: const Color(0xFF151D2A),
        title: const Text(
          'FANZ CYBER CALC',
          style: TextStyle(color: Color(0xFF00FF66), fontFamily: 'monospace', fontWeight: FontWeight.bold, letterSpacing: 2),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: <Widget>[
          // LAYAR DISPLAY UTAMA
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              alignment: Alignment.bottomRight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(_expression, style: const TextStyle(fontSize: 24, color: Colors.grey, fontFamily: 'monospace')),
                  const SizedBox(height: 10),
                  Text(_output, style: const TextStyle(fontSize: 50, fontWeight: FontWeight.bold, color: Color(0xFF00FF66), fontFamily: 'monospace')),
                ],
              ),
            ),
          ),
          const Divider(color: Color(0xFF00FF66), thickness: 1),
          
          // SUSUNAN TOMBOL-TOMBOL
          Column(
            children: [
              Row(children: [_buildButton("7", Colors.white), _buildButton("8", Colors.white), _buildButton("9", Colors.white), _buildButton("÷", const Color(0xFFFF9100))]),
              Row(children: [_buildButton("4", Colors.white), _buildButton("5", Colors.white), _buildButton("6", Colors.white), _buildButton("×", const Color(0xFFFF9100))]),
              Row(children: [_buildButton("1", Colors.white), _buildButton("2", Colors.white), _buildButton("3", Colors.white), _buildButton("-", const Color(0xFFFF9100))]),
              Row(children: [_buildButton(".", Colors.white), _buildButton("0", Colors.white), _buildButton("00", Colors.white), _buildButton("+", const Color(0xFFFF9100))]),
              Row(children: [_buildButton("CLEAR", const Color(0xFFFF1744)), _buildButton("=", const Color(0xFF00E5FF))]),
              const SizedBox(height: 15),
            ],
          )
        ],
      ),
    );
  }
}
