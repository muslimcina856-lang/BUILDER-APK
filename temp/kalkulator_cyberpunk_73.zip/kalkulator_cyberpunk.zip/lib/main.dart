import 'package:flutter/material.dart';
import 'kalkulator.dart'; // 🎯 Di sini kita manggil file kalkulatornya!

void main() {
  runApp(const KalkulatorApp());
}

class KalkulatorApp extends StatelessWidget {
  const KalkulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cyber Calc',
      theme: ThemeData.dark(), // Menggunakan tema dasar gelap
      home: const KalkulatorScreen(), // 🎯 Menampilkan halaman utama dari file kalkulator.dart
    );
  }
}
