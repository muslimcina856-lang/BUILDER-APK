# AetherRun – Premium Endless Runner

## Spesifikasi (selepas audit)

| Item              | Nilai                          | Nota |
|-------------------|--------------------------------|------|
| compileSdk        | **35**                         | Selamat & stabil |
| targetSdk         | **35**                         | Selamat & stabil |
| minSdk            | 26                             | |
| AGP               | 8.7.2                          | |
| Kotlin            | 2.0.21                         | |
| Gradle            | 8.9                            | |

## Masalah yang telah dibetulkan (Audit)

1. **compileSdk / targetSdk 36** → diturunkan ke **35**  
   (API 36 masih terlalu baru, ramai mesin belum ada SDK 36 → error "Failed to find target")

2. **Icon APK**  
   Fail PNG sebenarnya adalah JPEG → akan cause **aapt2 error** "Not a PNG".  
   Diganti dengan **Vector Adaptive Icon** yang sah (tiada bitmap).

3. **gradle-wrapper.jar** tiada  
   Ini normal. Android Studio akan generate sendiri bila project dibuka.

4. Dependency `datastore` ada tapi tak digunakan → tak cause error, hanya unused.

## Sistem yang ada

- Particle Physics System penuh (drag, gravity, angular, glow)
- ScreenShake (trauma)
- Floating Score Text
- 6 Character selectable
- Parallax background
- Object pooling
- SoundManager (ready)
- High score persistent

## Cara Run (paling stabil)

1. Extract zip
2. Buka folder **AetherRun** dalam Android Studio (Iguana / Koala / Ladybug+)
3. Biarkan Android Studio sync & download Gradle + SDK 35
4. Run

Jika masih ada error berkaitan SDK, pastikan di SDK Manager:
- Android 15.0 (API 35) sudah installed
