import 'dart:convert';
import 'dart:io';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:math_expressions/math_expressions.dart';
import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../data/usage_guide.dart';
import '../models/app_models.dart';
import 'browser_session_service.dart';
import 'duckduckgo_search_service.dart';
import 'linux_workspace_service.dart';
import 'local_database.dart';
import 'mcp_service.dart';
import 'platform_bridge_service.dart';
import 'skill_service.dart';
import 'terminal_service.dart';

class _BrowserPage {
  const _BrowserPage({
    required this.id,
    required this.url,
    required this.title,
    required this.text,
    required this.html,
    required this.links,
  });

  final String id;
  final String url;
  final String title;
  final String text;
  final String html;
  final List<Map<String, String>> links;
}

class ToolEngine {
  ToolEngine(
    this.database, {
    http.Client? client,
    BrowserSessionService? browserSession,
    TerminalService? terminalService,
    LinuxWorkspaceService? linuxWorkspaceService,
    SkillService? skillService,
    McpService? mcpService,
    PlatformBridgeService? platformBridge,
    this.backgroundMode = false,
  })  : _client = client ?? http.Client(),
        browserSession = browserSession ?? BrowserSessionService(),
        terminalService = terminalService ?? TerminalService(),
        linuxWorkspaceService = linuxWorkspaceService ?? LinuxWorkspaceService(),
        skillService = skillService ?? SkillService(database),
        mcpService = mcpService ?? McpService(),
        platformBridge = platformBridge ?? PlatformBridgeService() {
    _searchService = DuckDuckGoSearchService(client: _client);
  }

  final LocalDatabase database;
  final http.Client _client;
  final BrowserSessionService browserSession;
  final TerminalService terminalService;
  final LinuxWorkspaceService linuxWorkspaceService;
  final SkillService skillService;
  final McpService mcpService;
  final PlatformBridgeService platformBridge;
  final bool backgroundMode;
  late final DuckDuckGoSearchService _searchService;
  static const _uuid = Uuid();
  final Map<String, _BrowserPage> _pages = <String, _BrowserPage>{};

  List<ToolDefinition> get definitions => <ToolDefinition>[
        const ToolDefinition(
          id: 'web_search',
          name: 'DuckDuckGo Search',
          category: 'Web',
          risk: ToolRisk.readOnly,
          description: 'Cari web menggunakan DuckDuckGo. Pulangkan hasil penuh dengan ranking, tajuk, URL, domain dan petikan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'query': <String, dynamic>{'type': 'string'},
              'max_results': <String, dynamic>{'type': 'integer', 'minimum': 1, 'maximum': 20},
              'region': <String, dynamic>{'type': 'string', 'description': 'Contoh wt-wt, my-en, us-en.'},
              'safe_search': <String, dynamic>{'type': 'string', 'enum': <String>['off', 'moderate', 'strict']},
              'time_range': <String, dynamic>{'type': 'string', 'description': 'Kosong, d, w, m atau y.'},
            },
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'browser_open',
          name: 'Buka Browser Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Buka URL dalam WebView tersembunyi (JS sentiasa ON). '
              'new_tab=true buka tab baharu (max 5). window.open/target=_blank auto-cipta tab.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = desktop; false = mudah alih.',
              },
              'new_tab': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = tab baharu (max 5); false = tab aktif.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'browser_tabs',
          name: 'Senarai Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Senarai tab terbuka (max 5): id, url, title, active. '
              'Guna selepas login/OTP yang buka tab lain.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'browser_switch_tab',
          name: 'Tukar Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Tukar tab aktif mengikut tab_id dari browser_tabs. '
              'click/fill/read/screenshot seterusnya pada tab itu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'tab_id': <String, dynamic>{
                'type': 'integer',
                'description': 'ID tab dari browser_tabs.',
              },
            },
            'required': <String>['tab_id'],
          },
        ),
        const ToolDefinition(
          id: 'browser_close_tab',
          name: 'Tutup Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Tutup tab mengikut tab_id (atau tab aktif jika tiada). '
              'Wajib bila had 5 tab penuh.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'tab_id': <String, dynamic>{
                'type': 'integer',
                'description': 'ID tab; kosong = tab aktif.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_read',
          name: 'Baca Halaman Aktif',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Baca keadaan halaman browser aktif: URL, tajuk, teks, senarai elemen interaktif (dengan index), pautan dan borang. '
              'Sentiasa panggil ini sebelum click/fill. Gunakan index dari interactive_elements untuk tindakan seterusnya.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'browser_screenshot',
          name: 'Screenshot Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Ambil screenshot PNG daripada halaman browser latar dan paparkannya sebagai artifact imej dalam chat.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'browser_follow_link',
          name: 'Ikut Pautan',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka pautan daripada page_id dan indeks hasil browser.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'page_id': <String, dynamic>{'type': 'string'},
              'link_index': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['page_id', 'link_index'],
          },
        ),
        const ToolDefinition(
          id: 'browser_click',
          name: 'Klik Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Klik elemen pada halaman browser. UTAMAKAN parameter index dari interactive_elements (hasil browser_read). '
              'Alternatif: text (teks butang/pautan) atau selector CSS.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{
                'type': 'integer',
                'description': 'Index elemen dari interactive_elements (disyorkan).',
              },
              'selector': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_fill',
          name: 'Isi Input Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Isi input/textarea/select pada halaman browser. UTAMAKAN parameter index dari interactive_elements. '
              'Alternatif: selector CSS. Wajib sertakan value.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{
                'type': 'integer',
                'description': 'Index elemen input dari interactive_elements (disyorkan).',
              },
              'selector': <String, dynamic>{'type': 'string'},
              'value': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['value'],
          },
        ),
        const ToolDefinition(
          id: 'browser_submit_form',
          name: 'Hantar Borang Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Hantar borang dalam browser. Boleh guna index elemen (butang submit / input dalam form) atau selector CSS form.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{'type': 'integer'},
              'selector': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_download',
          name: 'Muat Turun Fail',
          category: 'Browser',
          risk: ToolRisk.localWrite,
          description: 'Muat turun URL ke folder workspace tempatan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'filename': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'media_preview',
          name: 'Pratonton Media',
          category: 'Media',
          risk: ToolRisk.readOnly,
          description:
              'Hantar gambar, video atau audio ke chat sebagai pratonton. '
              'Sumber: (1) URL HTTP/HTTPS, atau (2) path fail dalam workspace sesi '
              '(contoh: foto.jpg, output/video.mp4, /workspace/a.png, /attachments/x.jpg). '
              'Gunakan selepas file_write/browser_download/screenshot untuk tunjuk media local.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description':
                    'URL http(s) ATAU path workspace/lampiran (relatif atau /workspace/...).',
              },
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Alias path workspace jika tidak guna url.',
              },
              'kind': <String, dynamic>{
                'type': 'string',
                'enum': <String>['image', 'video', 'audio'],
              },
              'title': <String, dynamic>{'type': 'string'},
              'mime_type': <String, dynamic>{'type': 'string'},
            },
            'required': <String>[],
          },
        ),
        const ToolDefinition(
          id: 'open_url',
          name: 'Buka URL Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka URL dalam browser latar dan pulangkan ringkasan halaman kepada chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true untuk emulasi browser desktop/PC.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'http_request',
          name: 'HTTP Request',
          category: 'Web',
          risk: ToolRisk.externalWrite,
          description: 'Hantar permintaan HTTP. Hanya operasi yang dikesan destruktif akan meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'method': <String, dynamic>{'type': 'string'},
              'url': <String, dynamic>{'type': 'string'},
              'headers': <String, dynamic>{'type': 'object'},
              'body': <String, dynamic>{},
            },
            'required': <String>['method', 'url'],
          },
        ),
        const ToolDefinition(
          id: 'file_list',
          name: 'Senarai Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan fail dalam workspace tempatan aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{'path': <String, dynamic>{'type': 'string'}}},
        ),
        const ToolDefinition(
          id: 'file_read',
          name: 'Baca Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description: 'Baca kandungan fail teks daripada workspace tempatan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'path': <String, dynamic>{'type': 'string'}},
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'file_write',
          name: 'Tulis Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Tulis fail dalam workspace. Fail baharu terus ditulis; penimpaan fail sedia ada meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'file_replace',
          name: 'Ganti Teks dalam Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Cari dan ganti teks dalam fail workspace tanpa menulis semula seluruh fail secara manual. '
              'Sokong plain text atau regex. Lalai ganti semua padanan; set replace_all=false untuk sekali sahaja.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Path fail relatif workspace.',
              },
              'find': <String, dynamic>{
                'type': 'string',
                'description': 'Teks atau corak yang dicari.',
              },
              'replace': <String, dynamic>{
                'type': 'string',
                'description': 'Teks gantian (boleh kosong untuk padam padanan).',
              },
              'regex': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = interpret find sebagai RegExp Dart.',
              },
              'replace_all': <String, dynamic>{
                'type': 'boolean',
                'description': 'true (lalai) = ganti semua; false = ganti padanan pertama sahaja.',
              },
              'case_sensitive': <String, dynamic>{
                'type': 'boolean',
                'description': 'true (lalai) = sensitif huruf; false = abaikan case.',
              },
            },
            'required': <String>['path', 'find', 'replace'],
          },
        ),
        const ToolDefinition(
          id: 'file_copy',
          name: 'Salin Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Salin fail dalam workspace. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_move',
          name: 'Pindah Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Pindah atau namakan semula fail. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_delete',
          name: 'Padam Fail',
          category: 'Fail',
          risk: ToolRisk.sensitive,
          description: 'Padam fail atau folder dalam workspace. Tindakan ini sentiasa dianggap berisiko.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'recursive': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'memory_search',
          name: 'Cari Memori',
          category: 'Memori',
          risk: ToolRisk.readOnly,
          description: 'Cari rekod memori tempatan berdasarkan kata kunci.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'query': <String, dynamic>{'type': 'string'}},
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'memory_add',
          name: 'Tambah Memori',
          category: 'Memori',
          risk: ToolRisk.localWrite,
          description: 'Simpan fakta atau nota ke memori tempatan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'title': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{'type': 'string'},
              'tags': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['title', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'memory_delete',
          name: 'Padam Memori',
          category: 'Memori',
          risk: ToolRisk.sensitive,
          description: 'Padam satu rekod memori tempatan menggunakan ID.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'id': <String, dynamic>{'type': 'string'}},
            'required': <String>['id'],
          },
        ),
        const ToolDefinition(
          id: 'linux_workspace_status',
          name: 'Status Linux Workspace',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Semak pemasangan automatik Alpine Linux ARM64 melalui PRoot, versi manifest, status kesihatan, storan private dan pengurus pakej apk.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'terminal_start',
          name: 'Terminal Latar Belakang',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Pasang runtime Alpine ARM64 bawaan jika perlu, jalankan arahan shell melalui PRoot dalam /workspace, dan pulangkan job_id. '
              'Gunakan apk untuk pakej (contoh: apk add --no-cache wine). '
              'Untuk menjalankan fail .exe: pasang wine terlebih dahulu, kemudian gunakan wine /workspace/fail.exe atau tool run_exe. '
              'Semua arahan dibenarkan automatik (tiada dialog kelulusan).',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'command': <String, dynamic>{'type': 'string'},
              'working_directory': <String, dynamic>{'type': 'string'},
              'environment': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['command'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_poll',
          name: 'Pantau Terminal',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Baca stdout, stderr, status dan exit code job terminal supaya AI boleh melihat proses latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_stop',
          name: 'Hentikan Terminal',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description: 'Hentikan job terminal latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_stdin',
          name: 'Input Terminal',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Hantar teks ke stdin job terminal yang sedang berjalan. '
              'Pengguna juga boleh taip terus dalam konsol chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'job_id': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
              'newline': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['job_id', 'text'],
          },
        ),
        const ToolDefinition(
          id: 'run_exe',
          name: 'Jalankan EXE (via Wine)',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Jalankan fail .exe dalam Linux Workspace menggunakan Wine. '
              'Tool ini akan cuba pastikan Wine tersedia (apk add --no-cache wine jika perlu), kemudian jalankan wine <path> [args]. '
              'Path relatif kepada /workspace atau path absolute guest. '
              'Nota: keserasian terhad pada aarch64; bukan semua aplikasi Windows serasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Path ke fail .exe (contoh: /workspace/app.exe atau relative path).',
              },
              'arguments': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'working_directory': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'skill_create',
          name: 'Cipta Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description: 'Cipta atau kemas kini skill local daripada nama, penerangan, arahan dan senarai tools. Skill Creator terbina dalam menggunakan tool ini apabila pengguna meminta kebolehan baharu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string', 'description': 'ID pilihan. Kosongkan untuk jana ID.'},
              'name': <String, dynamic>{'type': 'string'},
              'description': <String, dynamic>{'type': 'string'},
              'instructions': <String, dynamic>{'type': 'string'},
              'tool_ids': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['name', 'description', 'instructions'],
          },
        ),
        const ToolDefinition(
          id: 'skill_install_url',
          name: 'Pasang Skill dari URL atau Fail',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Pasang skill dari URL HTTP(S) ATAU fail ZIP lampiran/workspace. '
              'ZIP mesti ada skill.json ATAU SKILL.md (auto-convert). '
              'Repo GitHub biasa tanpa kedua-dua → JANGAN paksa; baca README/SKILL.md lalu skill_create. '
              'Path: nama.zip, /attachments/nama.zip, atau path workspace.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string', 'description': 'URL HTTP(S) arkib skill (pilihan jika path diberi)'},
              'path': <String, dynamic>{
                'type': 'string',
                'description':
                    'Path fail ZIP tempatan: nama lampiran, /attachments/nama.zip, atau path workspace relatif',
              },
            },
            'required': <String>[],
          },
        ),
        const ToolDefinition(
          id: 'archive_unzip',
          name: 'Unzip Arkib',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Extract fail ZIP ke folder workspace. Sumber boleh dari lampiran chat '
              '(/attachments/nama.zip atau nama fail) atau path workspace relatif.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string', 'description': 'Fail ZIP sumber'},
              'destination': <String, dynamic>{
                'type': 'string',
                'description': 'Folder destinasi dalam workspace (lalai: nama arkib tanpa .zip)',
              },
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'archive_zip',
          name: 'Zip Folder/Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Cipta fail ZIP dari path workspace relatif.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string', 'description': 'Fail atau folder sumber dalam workspace'},
              'destination': <String, dynamic>{
                'type': 'string',
                'description': 'Nama fail ZIP output dalam workspace (pilihan)',
              },
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'skill_run_script',
          name: 'Jalankan Skrip Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Jalankan skrip dari pakej skill yang dipasang (ZIP/SKILL.md dengan folder). '
              'JANGAN guna untuk skill dari skill_create (arahan sahaja, tiada folder skrip) — '
              'untuk itu guna terminal_start. Gagal dengan mesej jelas jika skill tiada sourcePath.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'skill_id': <String, dynamic>{'type': 'string'},
              'script': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['skill_id', 'script'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_list_tools',
          name: 'Senarai Tools MCP Local',
          category: 'MCP',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan tools daripada server MCP local yang telah dikonfigurasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'server_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['server_id'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_call',
          name: 'Panggil Tool MCP Local',
          category: 'MCP',
          risk: ToolRisk.externalWrite,
          description: 'Panggil tool pada server MCP local. Nama/argumen destruktif meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'server_id': <String, dynamic>{'type': 'string'},
              'tool_name': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['server_id', 'tool_name'],
          },
        ),
        const ToolDefinition(
          id: 'calculator',
          name: 'Kalkulator',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Kira ungkapan matematik asas dengan tepat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'expression': <String, dynamic>{'type': 'string'}},
            'required': <String>['expression'],
          },
        ),
        const ToolDefinition(
          id: 'app_usage_guide',
          name: 'Cara Guna Aplikasi',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Baca panduan rasmi cara menggunakan chat, browser, media, Linux Workspace, fail dan sub-agent dalam aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'runtime_info',
          name: 'Konteks Peranti dan Browser',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan konteks sebenar peranti Android, edisi, target API, enjin browser terbina dalam dan sempadan akses PC jauh.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'current_time',
          name: 'Masa Semasa',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan tarikh dan masa semasa pada peranti.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
      ];

  ToolDefinition? definition(String id) {
    for (final item in definitions) {
      if (item.id == id) return item;
    }
    return null;
  }

  Future<bool> requiresPermission(String toolId, Map<String, dynamic> arguments) async {
    // Semua tool dibenarkan — tiada dialog kebenaran.
    return false;
  }

  String permissionScope(String toolId, Map<String, dynamic> arguments) {
    if (toolId == 'http_request') {
      return Uri.tryParse(arguments['url']?.toString() ?? '')?.host.toLowerCase() ?? 'web';
    }
    if (toolId.startsWith('file_')) {
      return arguments['path']?.toString() ?? arguments['destination']?.toString() ?? 'workspace';
    }
    if (toolId.startsWith('memory_')) return 'local-memory';
    if (toolId.startsWith('terminal_') || toolId == 'run_exe') return 'terminal-sandbox';
    if (toolId.startsWith('mcp_')) return arguments['server_id']?.toString() ?? 'mcp-local';
    return '*';
  }

  String permissionDescription(String toolId, Map<String, dynamic> arguments) {
    switch (toolId) {
      case 'file_write':
        return 'Fail ${arguments['path']} sudah wujud dan akan ditimpa.';
      case 'file_copy':
      case 'file_move':
        return 'Destinasi ${arguments['destination']} sudah wujud dan akan diganti.';
      case 'file_delete':
        return 'Padam ${arguments['path']} daripada workspace tempatan.';
      case 'memory_delete':
        return 'Padam memori ${arguments['id']}.';
      case 'terminal_start':
        return 'Jalankan arahan terminal berisiko: ${arguments['command']}';
      case 'run_exe':
        return 'Jalankan fail EXE melalui Wine: ${arguments['path']}';
      case 'http_request':
        return 'Hantar operasi HTTP destruktif ${arguments['method']} ke ${arguments['url']}.';
      case 'mcp_call':
        return 'Panggil tool MCP yang dikesan berisiko: ${arguments['tool_name']}.';
      default:
        return 'Jalankan tindakan berisiko $toolId.';
    }
  }

  Future<ToolResult> execute(String toolId, Map<String, dynamic> arguments) async {
    try {
      return switch (toolId) {
        'web_search' => _webSearch(arguments),
        'browser_open' => _browserOpen(
            arguments['url']?.toString() ?? '',
            desktopMode: arguments['desktop_mode'] as bool? ?? true,
            newTab: arguments['new_tab'] as bool? ?? false,
          ),
        'browser_tabs' => _browserTabs(),
        'browser_switch_tab' => _browserSwitchTab(arguments),
        'browser_close_tab' => _browserCloseTab(arguments),
        'browser_read' => _browserRead(),
        'browser_screenshot' => _browserScreenshot(),
        'browser_follow_link' => _browserFollow(arguments),
        'browser_click' => _browserAction('click', arguments),
        'browser_fill' => _browserAction('fill', arguments),
        'browser_submit_form' => _browserAction('submit', arguments),
        'browser_download' => _browserDownload(arguments),
        'media_preview' => _mediaPreview(arguments),
        'open_url' => _openUrl(arguments),
        'http_request' => _httpRequest(arguments),
        'file_list' => _fileList(arguments),
        'file_read' => _fileRead(arguments),
        'file_write' => _fileWrite(arguments),
        'file_replace' => _fileReplace(arguments),
        'file_copy' => _fileCopy(arguments),
        'file_move' => _fileMove(arguments),
        'file_delete' => _fileDelete(arguments),
        'memory_search' => _memorySearch(arguments),
        'memory_add' => _memoryAdd(arguments),
        'memory_delete' => _memoryDelete(arguments),
        'linux_workspace_status' => _linuxWorkspaceStatus(),
        'terminal_start' => terminalService.start(
            command: arguments['command']?.toString() ?? '',
            workingDirectory: (() {
              final raw = arguments['working_directory']?.toString();
              if (raw == null || raw.trim().isEmpty) return '.';
              return raw.trim();
            })(),
            environment: Map<String, String>.from(arguments['environment'] as Map? ?? const <String, String>{}),
          ),
        'terminal_poll' => terminalService.poll(arguments['job_id']?.toString() ?? ''),
        'terminal_stop' => terminalService.stop(arguments['job_id']?.toString() ?? ''),
        'terminal_stdin' => terminalService.writeStdin(
            arguments['job_id']?.toString() ?? '',
            arguments['text']?.toString() ?? '',
            newline: arguments['newline'] as bool? ?? true,
          ),
        'run_exe' => _runExe(arguments),
        'skill_create' => _skillCreate(arguments),
        'skill_install_url' => _skillInstall(arguments),
        'archive_unzip' => _archiveUnzip(arguments),
        'archive_zip' => _archiveZip(arguments),
        'skill_run_script' => _skillRunScript(arguments),
        'mcp_list_tools' => _mcpListTools(arguments),
        'mcp_call' => _mcpCall(arguments),
        'calculator' => _calculator(arguments),
        'app_usage_guide' => Future<ToolResult>.value(
            ToolResult(
              success: true,
              output: UsageGuide.asPlainText(),
              data: UsageGuide.toMap(),
            ),
          ),
        'runtime_info' => _runtimeInfo(),
        'current_time' => Future<ToolResult>.value(ToolResult(success: true, output: DateTime.now().toIso8601String())),
        _ => Future<ToolResult>.value(ToolResult(success: false, output: 'Tool tidak dikenali: $toolId')),
      };
    } catch (error) {
      // Jangan dedahkan path host Android kepada model/pengguna.
      var message = error.toString();
      message = message.replaceAllMapped(
        RegExp(
          r'''/(?:data/(?:user/\d+/|data/)|storage|sdcard|mnt)[^\s"')\]]*''',
          caseSensitive: false,
        ),
        (_) => '[path-host-disembunyikan]',
      );
      if (message.contains('Permission denied') ||
          message.contains('PathAccess') ||
          message.contains('errno = 13')) {
        message =
            'Akses folder itu tidak dibenarkan. Gunakan path dalam /workspace sahaja '
            '(contoh: "." atau "projek/saya"). Jangan cuba path host Android.';
      }
      return ToolResult(success: false, output: message);
    }
  }

  Future<Map<String, dynamic>> runtimeContextSnapshot() async {
    // Konteks untuk model: Shell Linux (Alpine PRoot) + browser tersembunyi.
    // Maklumat peranti sebenar (manufacturer, model, SDK, path host Android)
    // TIDAK dihantar supaya model tidak cuba akses path host.
    final linux = await linuxWorkspaceService.status();
    final mcpServers = (await database.listObjects('mcp_server'))
        .map(McpServerConfig.fromJson)
        .where((server) => server.enabled)
        .map(
          (server) => <String, dynamic>{
            'id': server.id,
            'name': server.name,
            'baseUrl': server.baseUrl,
            'transport': server.transport.name,
          },
        )
        .toList();
    return <String, dynamic>{
      'platform': 'android',
      'edition': AppConfig.editionName,
      'packageName': AppConfig.packageName,
      'fullEdition': AppConfig.isFullEdition,
      'embeddedBrowserAvailable': true,
      'embeddedBrowserEngine': 'Android System WebView/Chromium',
      'browserDefaultMode': 'desktop-emulation',
      'embeddedBrowserSessionActive': browserSession.isRunning,
      'embeddedBrowserCurrentUrl': browserSession.currentUrl,
      'embeddedBrowserDesktopMode': browserSession.desktopMode,
      'embeddedBrowserCompletedActions': browserSession.completedActions,
      'configuredMcpServers': mcpServers,
      'remotePcAccess': false,
      'androidRootAccess': false,
      'hostFilesystemAccess': false,
      'allowedWorkspaces': <String>[
        'linux_guest:/workspace',
        'linux_guest:/root',
      ],
      'linuxWorkspace': <String, dynamic>{
        'availableInEdition': AppConfig.isFullEdition,
        'ready': linux.ready,
        'healthStatus': linux.healthStatus,
        'installedRuntimeVersion': linux.runtimeVersion,
        'expectedRuntimeVersion': AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedRuntimeVersion
            : null,
        'distribution': linux.distribution.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedDistribution
            : linux.distribution,
        'distributionVersion':
            linux.distributionVersion.isEmpty && AppConfig.isFullEdition
                ? LinuxWorkspaceService.expectedDistributionVersion
                : linux.distributionVersion,
        'guestArchitecture': linux.architecture.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedArchitecture
            : linux.architecture,
        'packageManager': linux.packageManager.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedPackageManager
            : linux.packageManager,
        'automaticInstallOnFirstCommand': AppConfig.isFullEdition,
        'workspacePath': '/workspace',
        'homePath': '/root',
        'persistentWorkspace': true,
        'interactiveStdin': false,
        'maxConcurrentJobs': 8,
        'maxRetainedJobs': 64,
        'sudoRequired': false,
        'androidRootAccess': false,
        'remotePcAccess': false,
        'exeSupport': 'via Wine (apk add --no-cache wine, then wine file.exe or tool run_exe)',
      },
    };
  }

  Future<ToolResult> _runtimeInfo() async {
    final data = await runtimeContextSnapshot();
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  /// Jalankan fail .exe melalui Wine di dalam Linux Workspace.
  /// Cubaan automatik pasang wine jika belum wujud.
  Future<ToolResult> _runExe(Map<String, dynamic> arguments) async {
    final path = arguments['path']?.toString().trim() ?? '';
    if (path.isEmpty) {
      return ToolResult(success: false, output: 'Path fail .exe diperlukan.');
    }
    final args = (arguments['arguments'] as List? ?? const <dynamic>[])
        .map((item) => item.toString())
        .toList(growable: false);
    final workDir = arguments['working_directory']?.toString() ?? '.';

    // Pastikan Wine tersedia (pasang sekali jika perlu)
    final ensureWine = await terminalService.start(
      command: 'command -v wine >/dev/null 2>&1 || apk add --no-cache wine',
      workingDirectory: workDir,
      environment: const <String, String>{},
    );
    if (!ensureWine.success) {
      // teruskan juga; mungkin wine sudah ada atau apk gagal sementara
    }

    final quotedPath = path.contains(' ') ? '"$path"' : path;
    final argStr = args.map((a) => a.contains(' ') ? '"$a"' : a).join(' ');
    final command = 'wine $quotedPath${argStr.isEmpty ? '' : ' $argStr'}';

    return terminalService.start(
      command: command,
      workingDirectory: workDir,
      environment: const <String, String>{},
    );
  }

  Future<ToolResult> _linuxWorkspaceStatus() async {
    final status = await linuxWorkspaceService.status();
    final data = <String, dynamic>{
      'edition': AppConfig.editionName,
      'package': AppConfig.packageName,
      'runtime_ready': status.runtimeReady,
      'rootfs_ready': status.rootfsReady,
      'manifest_valid': status.manifestValid,
      'ready': status.ready,
      'health_status': status.healthStatus,
      'runtime_version': status.runtimeVersion,
      'distribution': status.distribution,
      'distribution_version': status.distributionVersion,
      'guest_architecture': status.architecture,
      'package_manager': status.packageManager,
      'shell': '/bin/sh',
      'workspace_path': '/workspace',
      'home_path': '/root',
      'persistent_workspace': true,
      'interactive_stdin': false,
      'sudo_required': false,
      'automatic_install': AppConfig.isFullEdition,
      'bundled_asset': AppConfig.isFullEdition
          ? LinuxWorkspaceService.bundledRuntimeAsset
          : null,
      'used_bytes': status.usedBytes,
      'package_install_enabled': status.packageInstallEnabled,
      'storage': 'private_app_storage',
      'external_storage_bound': false,
      'android_root_access': false,
      'remote_pc_access': false,
    };
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  Future<ToolResult> _webSearch(Map<String, dynamic> arguments) async {
    final query = arguments['query']?.toString() ?? '';
    try {
      final response = await _searchService.search(
        query: query,
        maxResults: (arguments['max_results'] as num?)?.toInt() ?? 10,
        region: arguments['region']?.toString() ?? 'wt-wt',
        safeSearch: arguments['safe_search']?.toString() ?? 'moderate',
        timeRange: arguments['time_range']?.toString() ?? '',
      );
      final raw = response.toJson();
      final artifact = ChatArtifact(
        id: _uuid.v4(),
        kind: ArtifactKind.searchResults,
        title: 'Hasil carian: $query',
        subtitle: '${response.results.length} hasil DuckDuckGo',
        data: raw,
      );
      return ToolResult(
        success: true,
        output: response.prettyJson(),
        data: <String, dynamic>{...raw, 'artifact': artifact.toJson()},
      );
    } catch (error) {
      // Jangan jatuhkan seluruh tugasan — AI boleh cuba query lain / browser.
      return ToolResult(
        success: false,
        output:
            'Carian gagal untuk "$query": $error. '
            'Cuba query lebih pendek, tunggu sekejap, atau guna browser_open pada URL yang diketahui.',
      );
    }
  }

  Future<ToolResult> _browserOpen(
    String rawUrl, {
    bool desktopMode = true,
    bool newTab = false,
  }) async {
    final uri = _validatedHttpUri(rawUrl);
    if (backgroundMode) {
      return _browserOpenHttp(uri, desktopMode: desktopMode);
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'open',
        arguments: <String, dynamic>{
          'url': uri.toString(),
          'desktopMode': desktopMode,
          'newTab': newTab,
        },
      ),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserTabs() async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Senarai tab hanya untuk browser WebView (bukan background HTTP).',
      );
    }
    final result = await browserSession.execute(
      const BrowserAction(type: 'tabs', arguments: <String, dynamic>{}),
    );
    return ToolResult(
      success: result['success'] == true,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  Future<ToolResult> _browserSwitchTab(Map<String, dynamic> arguments) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Tukar tab tidak tersedia dalam background HTTP.',
      );
    }
    final tabId = (arguments['tab_id'] as num?)?.toInt();
    if (tabId == null) {
      return const ToolResult(success: false, output: 'tab_id diperlukan. Panggil browser_tabs dulu.');
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'switchTab',
        arguments: <String, dynamic>{'tabId': tabId},
      ),
    );
    final ok = result['success'] == true;
    final recovered = result['recovered'] == true;
    final msg = result['message']?.toString() ??
        (ok ? 'Tab $tabId aktif.' : 'Gagal tukar tab $tabId.');
    return ToolResult(
      success: ok,
      output: recovered
          ? '$msg\n${const JsonEncoder.withIndent('  ').convert(result)}'
          : const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  Future<ToolResult> _browserCloseTab(Map<String, dynamic> arguments) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Tutup tab tidak tersedia dalam background HTTP.',
      );
    }
    final tabId = (arguments['tab_id'] as num?)?.toInt();
    final result = await browserSession.execute(
      BrowserAction(
        type: 'closeTab',
        arguments: <String, dynamic>{
          if (tabId != null) 'tabId': tabId,
        },
      ),
    );
    return ToolResult(
      success: result['success'] == true,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  Future<ToolResult> _browserRead() async {
    if (backgroundMode) {
      if (_pages.isEmpty) {
        return const ToolResult(
          success: false,
          output: 'Tiada halaman aktif dalam automasi background. Gunakan browser_open dengan URL.',
        );
      }
      final page = _pages.values.last;
      return _pageResult(page, mode: 'background-cache');
    }
    final result = await browserSession.execute(
      BrowserAction(type: 'read', arguments: const <String, dynamic>{}),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserScreenshot() async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Screenshot WebView memerlukan proses aplikasi aktif.',
      );
    }
    final result = await browserSession.execute(
      const BrowserAction(type: 'screenshot', arguments: <String, dynamic>{}),
    );
    final path = result['path']?.toString() ?? '';
    if (path.isEmpty) {
      return ToolResult(
        success: false,
        output: result['error']?.toString() ?? 'Screenshot browser gagal.',
        data: result,
      );
    }
    final title = result['title']?.toString().trim() ?? '';
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.image,
      title: title.isEmpty ? 'Screenshot halaman web' : title,
      subtitle: result['url']?.toString() ?? '',
      localPath: path,
      mimeType: result['mime']?.toString() ?? 'image/png',
      data: <String, dynamic>{
        'width': result['width'],
        'height': result['height'],
      },
    );
    final data = <String, dynamic>{
      ...result,
      'artifact': artifact.toJson(),
    };
    return ToolResult(
      success: true,
      output: 'Screenshot penuh halaman telah disediakan sebagai gambar PNG.',
      data: data,
    );
  }

  Future<ToolResult> _browserAction(
    String type,
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) {
      return ToolResult(
        success: false,
        output: 'Interaksi DOM memerlukan proses aplikasi aktif. Browser masih tidak dipaparkan kepada pengguna.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(type: type, arguments: arguments),
    );
    if (result['url'] != null || result['html'] != null) {
      return _storeBrowserPage(result);
    }
    final success = result['success'] != false;
    // Self-heal: bila gagal, baca semula page. Tiada max retry hardcoded —
    // agent loop (while !cancelled) juga tiada had step; AI boleh terus cuba.
    if (!success && result['self_heal_hint'] == true) {
      try {
        final fresh = await browserSession.execute(
          const BrowserAction(type: 'read', arguments: <String, dynamic>{}),
        );
        final pageResult = _storeBrowserPage(fresh);
        return ToolResult(
          success: false,
          output:
              '${result['error'] ?? 'Tindakan browser gagal'}. '
              'Page dibaca semula — guna index baharu dari interactive_elements.\n'
              '${pageResult.output}',
          data: <String, dynamic>{
            ...result,
            'healed_page': pageResult.data,
          },
        );
      } catch (_) {
        // pulangkan ralat asal
      }
    }
    return ToolResult(
      success: success,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  ToolResult _storeBrowserPage(Map<String, dynamic> result) {
    final url = result['url']?.toString() ?? browserSession.currentUrl;
    final links = (result['links'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map(
          (item) => <String, String>{
            'text': item['text']?.toString() ?? '',
            'url': item['url']?.toString() ?? '',
          },
        )
        .where((item) => item['url']!.isNotEmpty)
        .toList();
    final interactive = (result['interactive_elements'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    final html = _sanitizeHtmlPreview(result['html']?.toString() ?? '', url);
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: url,
      title: result['title']?.toString() ?? '',
      text: _clip(result['text']?.toString() ?? ''),
      html: html,
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: result['mode']?.toString() ??
          result['engine']?.toString() ??
          'headless-webview',
      extra: <String, dynamic>{
        if (result['forms'] is List) 'forms': result['forms'],
        'interactive_elements': interactive,
      },
    );
  }

  ToolResult _pageResult(
    _BrowserPage page, {
    required String mode,
    Map<String, dynamic> extra = const <String, dynamic>{},
  }) {
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.webpage,
      title: page.title.isEmpty ? Uri.parse(page.url).host : page.title,
      subtitle: page.url,
      url: page.url,
      mimeType: 'text/html',
      html: page.html,
      data: <String, dynamic>{'pageId': page.id, 'mode': mode},
    );
    final interactive = (extra['interactive_elements'] as List? ?? const <dynamic>[]);
    final elementSummary = interactive.isEmpty
        ? ''
        : '\n\nElemen interaktif (guna index untuk click/fill; bbox = x,y,w,h):\n${interactive.take(40).map((e) {
            final m = e is Map ? e : <String, dynamic>{};
            final idx = m['index'] ?? '?';
            final tag = m['tag'] ?? '';
            final type = m['type'] ?? '';
            final text = (m['text'] ?? m['placeholder'] ?? '').toString();
            final href = (m['href'] ?? '').toString();
            final short = text.length > 60 ? '${text.substring(0, 60)}…' : text;
            final extraHref = href.isNotEmpty ? ' → $href' : '';
            final bbox = m['bbox'];
            var bboxStr = '';
            if (bbox is Map) {
              bboxStr =
                  ' @(${bbox['x']},${bbox['y']} ${bbox['width']}x${bbox['height']})';
            }
            return '[$idx] <$tag/$type> $short$extraHref$bboxStr';
          }).join('\n')}';
    final data = <String, dynamic>{
      'page_id': page.id,
      'url': page.url,
      'title': page.title,
      'text': page.text,
      'links': page.links,
      'mode': mode,
      'artifact': artifact.toJson(),
      ...extra,
    };
    final titleLine = page.title.isEmpty
        ? 'Halaman browser berjaya dibaca: ${page.url}'
        : 'Halaman browser berjaya dibaca: ${page.title} · ${page.url}';
    return ToolResult(
      success: true,
      output: '$titleLine$elementSummary',
      data: data,
    );
  }

  Future<ToolResult> _browserFollow(Map<String, dynamic> arguments) async {
    final page = _pages[arguments['page_id']?.toString()];
    if (page == null) {
      return const ToolResult(
        success: false,
        output: 'Page ID tidak ditemui atau sesi browser telah tamat.',
      );
    }
    final index = (arguments['link_index'] as num?)?.toInt() ?? -1;
    if (index < 0 || index >= page.links.length) {
      return ToolResult(
        success: false,
        output: 'Indeks pautan tidak sah. Julat 0-${page.links.length - 1}.',
      );
    }
    return _browserOpen(
      page.links[index]['url']!,
      desktopMode: browserSession.desktopMode,
    );
  }

  Future<ToolResult> _browserOpenHttp(
    Uri uri, {
    bool desktopMode = true,
  }) async {
    final response = await _client
        .get(uri, headers: _browserHeaders(desktop: desktopMode))
        .timeout(AppConfig.browserTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${response.statusCode}',
      );
    }
    final contentType = response.headers['content-type'] ?? '';
    if (!contentType.contains('html')) {
      final body = _clip(response.body);
      return ToolResult(
        success: true,
        output: body,
        data: <String, dynamic>{
          'url': uri.toString(),
          'contentType': contentType,
        },
      );
    }
    final document = html_parser.parse(response.body);
    for (final node in document.querySelectorAll(
      'script,style,noscript,svg,object,embed,template',
    )) {
      node.remove();
    }
    final title = document.querySelector('title')?.text.trim() ?? uri.host;
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final links = <Map<String, String>>[];
    for (final anchor in document.querySelectorAll('a[href]')) {
      final href = anchor.attributes['href'];
      if (href == null || href.startsWith('#') || href.startsWith('javascript:')) {
        continue;
      }
      final resolved = uri.resolve(href);
      if (!<String>{'http', 'https'}.contains(resolved.scheme)) continue;
      final label = anchor.text.replaceAll(RegExp(r'\s+'), ' ').trim();
      links.add(<String, String>{
        'text': label.isEmpty ? resolved.toString() : label,
        'url': resolved.toString(),
      });
      if (links.length >= 160) break;
    }
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: uri.toString(),
      title: title,
      text: _clip(text),
      html: _sanitizeHtmlPreview(document.outerHtml, uri.toString()),
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: desktopMode ? 'background-http-desktop' : 'background-http-mobile',
      extra: <String, dynamic>{'desktopMode': desktopMode},
    );
  }

  Future<ToolResult> _browserDownload(
    Map<String, dynamic> arguments,
  ) async {
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final request = http.Request('GET', uri);
    request.headers.addAll(
      _browserHeaders(desktop: browserSession.desktopMode),
    );
    final streamed = await _client.send(request).timeout(AppConfig.browserTimeout);
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${streamed.statusCode}',
      );
    }
    final declared = streamed.contentLength;
    if (declared != null && declared > AppConfig.maxDownloadBytes) {
      return const ToolResult(
        success: false,
        output: 'Fail melebihi had muat turun 250 MB.',
      );
    }
    final filename = _safeFilename(
      arguments['filename']?.toString().trim().isNotEmpty == true
          ? arguments['filename'].toString()
          : p.basename(uri.path).isEmpty
              ? 'download.bin'
              : p.basename(uri.path),
    );
    final root = await _workspace();
    final file = File(p.join(root.path, filename));
    await file.parent.create(recursive: true);
    final sink = file.openWrite();
    var received = 0;
    try {
      await for (final chunk in streamed.stream) {
        received += chunk.length;
        if (received > AppConfig.maxDownloadBytes) {
          throw const FileSystemException(
            'Fail melebihi had muat turun 250 MB.',
          );
        }
        sink.add(chunk);
      }
      await sink.flush();
    } catch (_) {
      await sink.close();
      if (await file.exists()) await file.delete();
      rethrow;
    }
    await sink.close();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: filename,
      subtitle: '$received bait',
      localPath: file.path,
      mimeType: streamed.headers['content-type'] ?? _mimeForPath(file.path),
      url: uri.toString(),
    );
    return ToolResult(
      success: true,
      output: 'Fail disimpan: ${p.relative(file.path, from: root.path)}',
      data: <String, dynamic>{
        'path': file.path,
        'bytes': received,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _mediaPreview(Map<String, dynamic> arguments) async {
    final rawUrl = arguments['url']?.toString().trim() ?? '';
    final rawPath = arguments['path']?.toString().trim() ?? '';
    final rawLocation = rawUrl.isNotEmpty ? rawUrl : rawPath;
    final requestedKind = arguments['kind']?.toString().trim().toLowerCase() ?? '';
    var mimeType = arguments['mime_type']?.toString().trim() ?? '';
    final requestedTitle = arguments['title']?.toString().trim() ?? '';
    ArtifactKind? kind = switch (requestedKind) {
      'image' => ArtifactKind.image,
      'video' => ArtifactKind.video,
      'audio' => ArtifactKind.audio,
      _ => null,
    };

    if (rawLocation.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Berikan url (http/https) atau path fail workspace/lampiran.',
      );
    }

    final parsedLocation = Uri.tryParse(rawLocation);
    final isHttpLocation = parsedLocation != null &&
        <String>{'http', 'https'}.contains(parsedLocation.scheme) &&
        parsedLocation.host.isNotEmpty;

    // --- Local / workspace / attachments ---
    if (!isHttpLocation) {
      final local = await _resolveLocalMediaFile(rawLocation);
      if (local == null) {
        return ToolResult(
          success: false,
          output:
              'Path media tidak ditemui dalam workspace/lampiran: $rawLocation. '
              'Guna path relatif (cth. foto.jpg, output/a.mp4) atau URL http(s).',
        );
      }

      if (kind == null && mimeType.isNotEmpty) {
        if (mimeType.startsWith('image/')) kind = ArtifactKind.image;
        if (mimeType.startsWith('video/')) kind = ArtifactKind.video;
        if (mimeType.startsWith('audio/')) kind = ArtifactKind.audio;
      }
      final inferred = _artifactKindForPath(local.path);
      if (kind == null &&
          <ArtifactKind>{
            ArtifactKind.image,
            ArtifactKind.video,
            ArtifactKind.audio,
          }.contains(inferred)) {
        kind = inferred;
      }
      if (kind == null) {
        return const ToolResult(
          success: false,
          output:
              'Jenis media tidak dikenali. Berikan kind: image, video atau audio.',
        );
      }
      if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
        mimeType = _mimeForPath(local.path);
      }

      final rel = local.relative;
      final title = requestedTitle.isNotEmpty
          ? requestedTitle
          : p.basename(local.path);
      final artifact = ChatArtifact(
        id: _uuid.v4(),
        kind: kind,
        title: title,
        subtitle: 'Dari workspace · $rel',
        localPath: local.path,
        mimeType: mimeType,
        data: <String, dynamic>{
          'previewOnly': false,
          'fromWorkspace': true,
          'relativePath': rel,
        },
      );
      return ToolResult(
        success: true,
        output: 'Pratonton ${kind.name} dari workspace dihantar ke chat: $rel',
        data: <String, dynamic>{
          'path': rel,
          'localPath': local.path,
          'kind': kind.name,
          'mimeType': mimeType,
          'artifact': artifact.toJson(),
        },
      );
    }

    // --- HTTP / HTTPS ---
    final uri = parsedLocation!;
    if (kind == null && mimeType.isNotEmpty) {
      if (mimeType.startsWith('image/')) kind = ArtifactKind.image;
      if (mimeType.startsWith('video/')) kind = ArtifactKind.video;
      if (mimeType.startsWith('audio/')) kind = ArtifactKind.audio;
    }
    if (kind == null) {
      final inferred = _artifactKindForPath(uri.path);
      if (<ArtifactKind>{
        ArtifactKind.image,
        ArtifactKind.video,
        ArtifactKind.audio,
      }.contains(inferred)) {
        kind = inferred;
      }
    }
    if (kind == null) {
      return const ToolResult(
        success: false,
        output:
            'Jenis media tidak dapat dikenal pasti. Berikan kind image, video atau audio bersama URL media langsung.',
      );
    }

    if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
      mimeType = _mimeForPath(uri.path);
      if (mimeType == 'application/octet-stream') {
        mimeType = switch (kind) {
          ArtifactKind.image => 'image/jpeg',
          ArtifactKind.video => 'video/mp4',
          ArtifactKind.audio => 'audio/mpeg',
          _ => 'application/octet-stream',
        };
      }
    }
    final basename = p.basename(uri.path).trim();
    final title = requestedTitle.isNotEmpty
        ? requestedTitle
        : basename.isNotEmpty
            ? basename
            : 'Media daripada ${uri.host}';
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: kind,
      title: title,
      subtitle: 'Pratonton URL · belum disimpan ke peranti',
      url: uri.toString(),
      mimeType: mimeType,
      data: const <String, dynamic>{'previewOnly': true},
    );
    return ToolResult(
      success: true,
      output:
          'Pratonton ${kind.name} telah dihantar tanpa memuat turun fail ke storan.',
      data: <String, dynamic>{
        'url': uri.toString(),
        'kind': kind.name,
        'mimeType': mimeType,
        'previewOnly': true,
        'artifact': artifact.toJson(),
      },
    );
  }

  /// Resolve path relative workspace, /workspace/..., /attachments/..., or absolute internal.
  Future<({String path, String relative})?> _resolveLocalMediaFile(
    String raw,
  ) async {
    var value = raw.trim();
    if (value.isEmpty) return null;

    // file:// URI
    final uri = Uri.tryParse(value);
    if (uri != null && uri.scheme == 'file') {
      try {
        value = uri.toFilePath();
      } catch (_) {}
    }

    final root = await _workspace();
    final attachmentsRoot = Directory(
      p.join((await getApplicationSupportDirectory()).path, 'attachments'),
    );

    // Guest-style prefixes
    if (value == '/workspace' || value == '/workspace/') {
      return null;
    }
    if (value.startsWith('/workspace/')) {
      value = value.substring('/workspace/'.length);
    }
    if (value.startsWith('workspace/')) {
      value = value.substring('workspace/'.length);
    }
    if (value.startsWith('/attachments/')) {
      value = value.substring('/attachments/'.length);
      final file = File(p.normalize(p.join(attachmentsRoot.path, value)));
      if (await file.exists()) {
        return (path: file.path, relative: 'attachments/$value');
      }
      return null;
    }
    if (value.startsWith('attachments/')) {
      final name = value.substring('attachments/'.length);
      final file = File(p.normalize(p.join(attachmentsRoot.path, name)));
      if (await file.exists()) {
        return (path: file.path, relative: value);
      }
    }

    // Absolute path inside app storage
    if (p.isAbsolute(value)) {
      final file = File(p.normalize(value));
      if (!await file.exists()) return null;
      final resolved = await file.resolveSymbolicLinks();
      final allowedRoots = <String>[
        p.normalize(root.path),
        p.normalize((await getApplicationSupportDirectory()).path),
        p.normalize((await getApplicationDocumentsDirectory()).path),
        p.normalize((await getTemporaryDirectory()).path),
      ];
      final ok = allowedRoots.any(
        (r) => resolved == r || p.isWithin(r, resolved),
      );
      if (!ok) return null;
      final rel = p.isWithin(root.path, resolved)
          ? p.relative(resolved, from: root.path)
          : p.basename(resolved);
      return (path: resolved, relative: rel);
    }

    // Relative workspace path
    try {
      final file = _safeWorkspaceFile(root, value);
      if (await file.exists()) {
        return (
          path: file.path,
          relative: p.relative(file.path, from: root.path),
        );
      }
    } catch (_) {
      return null;
    }

    // Basename-only: try attachments then workspace
    final attach = File(p.join(attachmentsRoot.path, p.basename(value)));
    if (await attach.exists()) {
      return (path: attach.path, relative: 'attachments/${p.basename(value)}');
    }
    return null;
  }

  Future<ToolResult> _openUrl(Map<String, dynamic> arguments) async {
    return _browserOpen(
      arguments['url']?.toString() ?? '',
      desktopMode: arguments['desktop_mode'] as bool? ?? true,
    );
  }

  Future<ToolResult> _httpRequest(Map<String, dynamic> arguments) async {
    final method = arguments['method']?.toString().toUpperCase() ?? 'GET';
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final headers = Map<String, String>.from(arguments['headers'] as Map? ?? const <String, String>{});
    final bodyValue = arguments['body'];
    final body = bodyValue is String ? bodyValue : bodyValue == null ? null : jsonEncode(bodyValue);
    final request = http.Request(method, uri)..headers.addAll(headers);
    if (body != null) request.body = body;
    final streamed = await _client.send(request).timeout(AppConfig.defaultTimeout);
    final response = await http.Response.fromStream(streamed);
    final output = _clip(response.body);
    return ToolResult(
      success: response.statusCode >= 200 && response.statusCode < 400,
      output: output,
      data: <String, dynamic>{'statusCode': response.statusCode, 'headers': response.headers, 'body': output},
    );
  }

  Future<ToolResult> _fileList(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final requested = arguments['path']?.toString() ?? '.';
    final directory = _safeWorkspaceDirectory(root, requested);
    if (!await directory.exists()) {
      return const ToolResult(success: false, output: 'Folder tidak ditemui.');
    }
    final values = <Map<String, dynamic>>[];
    try {
      await for (final entity in directory.list(followLinks: false)) {
        final stat = await entity.stat();
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': p.relative(entity.path, from: root.path),
          'type': entity is Directory ? 'directory' : 'file',
          'bytes': stat.size,
          'modified': stat.modified.toIso8601String(),
        });
      }
    } on PathAccessException {
      return const ToolResult(
        success: false,
        output:
            'Folder itu tidak boleh disenaraikan. Gunakan path relatif dalam /workspace sahaja.',
      );
    } on FileSystemException {
      return const ToolResult(
        success: false,
        output:
            'Folder itu tidak boleh disenaraikan. Gunakan path relatif dalam /workspace sahaja.',
      );
    }
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(values),
      data: <String, dynamic>{'items': values},
    );
  }

  Future<ToolResult> _fileRead(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final file = _safeWorkspaceFile(root, arguments['path']?.toString() ?? '');
    if (!await file.exists()) return const ToolResult(success: false, output: 'Fail tidak ditemui.');
    if (await file.length() > 4 * 1024 * 1024) return const ToolResult(success: false, output: 'Fail melebihi had bacaan teks 4 MB.');
    final content = await file.readAsString();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: p.relative(file.path, from: root.path),
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: content,
      data: <String, dynamic>{
        'path': p.relative(file.path, from: root.path),
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _fileWrite(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final file = _safeWorkspaceFile(root, arguments['path']?.toString() ?? 'output.txt');
    await file.parent.create(recursive: true);
    await file.writeAsString(arguments['content']?.toString() ?? '', flush: true);
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: p.relative(file.path, from: root.path),
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: 'Fail disimpan: ${p.relative(file.path, from: root.path)}',
      data: <String, dynamic>{
        'path': file.path,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _fileReplace(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final relative = arguments['path']?.toString() ?? '';
    final find = arguments['find']?.toString() ?? '';
    final replacement = arguments['replace']?.toString() ?? '';
    final useRegex = arguments['regex'] == true;
    final replaceAll = arguments['replace_all'] != false;
    final caseSensitive = arguments['case_sensitive'] != false;

    if (relative.trim().isEmpty) {
      return const ToolResult(success: false, output: 'Path fail kosong.');
    }
    if (find.isEmpty) {
      return const ToolResult(success: false, output: 'Parameter find kosong.');
    }

    final file = _safeWorkspaceFile(root, relative);
    if (!await file.exists()) {
      return const ToolResult(success: false, output: 'Fail tidak ditemui.');
    }
    if (await file.length() > 8 * 1024 * 1024) {
      return const ToolResult(
        success: false,
        output: 'Fail melebihi had replace 8 MB. Guna file_read/file_write untuk fail besar.',
      );
    }

    final original = await file.readAsString();
    late final String updated;
    late final int count;

    try {
      if (useRegex) {
        final pattern = RegExp(
          find,
          caseSensitive: caseSensitive,
          multiLine: true,
          dotAll: true,
        );
        final matches = pattern.allMatches(original).length;
        if (matches == 0) {
          return ToolResult(
            success: false,
            output: 'Tiada padanan regex dalam ${p.relative(file.path, from: root.path)}.',
            data: <String, dynamic>{
              'path': p.relative(file.path, from: root.path),
              'replacements': 0,
            },
          );
        }
        if (replaceAll) {
          updated = original.replaceAll(pattern, replacement);
          count = matches;
        } else {
          updated = original.replaceFirst(pattern, replacement);
          count = 1;
        }
      } else {
        if (caseSensitive) {
          if (!original.contains(find)) {
            return ToolResult(
              success: false,
              output: 'Tiada padanan teks dalam ${p.relative(file.path, from: root.path)}.',
              data: <String, dynamic>{
                'path': p.relative(file.path, from: root.path),
                'replacements': 0,
              },
            );
          }
          if (replaceAll) {
            count = find.allMatches(original).length;
            updated = original.replaceAll(find, replacement);
          } else {
            count = 1;
            updated = original.replaceFirst(find, replacement);
          }
        } else {
          final pattern = RegExp(RegExp.escape(find), caseSensitive: false);
          final matches = pattern.allMatches(original).length;
          if (matches == 0) {
            return ToolResult(
              success: false,
              output: 'Tiada padanan teks (ignore case) dalam ${p.relative(file.path, from: root.path)}.',
              data: <String, dynamic>{
                'path': p.relative(file.path, from: root.path),
                'replacements': 0,
              },
            );
          }
          if (replaceAll) {
            updated = original.replaceAll(pattern, replacement);
            count = matches;
          } else {
            updated = original.replaceFirst(pattern, replacement);
            count = 1;
          }
        }
      }
    } on FormatException catch (error) {
      return ToolResult(
        success: false,
        output: 'Regex tidak sah: $error',
      );
    }

    await file.writeAsString(updated, flush: true);
    final rel = p.relative(file.path, from: root.path);
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: '$count gantian · $rel',
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: 'Diganti $count padanan dalam $rel.',
      data: <String, dynamic>{
        'path': rel,
        'replacements': count,
        'regex': useRegex,
        'replace_all': replaceAll,
        'bytes_before': original.length,
        'bytes_after': updated.length,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _fileCopy(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    await source.copy(destination.path);
    return ToolResult(success: true, output: 'Fail disalin ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileMove(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    if (await destination.exists()) await destination.delete();
    await source.rename(destination.path);
    return ToolResult(success: true, output: 'Fail dipindah ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileDelete(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final relative = arguments['path']?.toString() ?? '';
    final normalized = _resolveWorkspaceRelative(root, relative);
    if (normalized == root.path) {
      return const ToolResult(
        success: false,
        output: 'Pemadaman root workspace tidak dibenarkan.',
      );
    }
    final type = await FileSystemEntity.type(normalized, followLinks: false);
    if (type == FileSystemEntityType.notFound) {
      return const ToolResult(
        success: false,
        output: 'Fail atau folder tidak ditemui.',
      );
    }
    if (type == FileSystemEntityType.directory) {
      await Directory(normalized).delete(
        recursive: arguments['recursive'] as bool? ?? false,
      );
    } else {
      await File(normalized).delete();
    }
    return ToolResult(success: true, output: '$relative telah dipadam.');
  }

  Future<ToolResult> _memorySearch(Map<String, dynamic> arguments) async {
    final query = arguments['query']?.toString().toLowerCase() ?? '';
    final values = (await database.listObjects('memory'))
        .map(MemoryRecord.fromJson)
        .where((item) => '${item.title} ${item.content} ${item.tags.join(' ')}'.toLowerCase().contains(query))
        .take(50)
        .map((item) => item.toJson())
        .toList();
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(values), data: <String, dynamic>{'results': values});
  }

  Future<ToolResult> _memoryAdd(Map<String, dynamic> arguments) async {
    final record = MemoryRecord(
      id: _uuid.v4(),
      title: arguments['title']?.toString() ?? 'Memori',
      content: arguments['content']?.toString() ?? '',
      createdAt: DateTime.now(),
      tags: (arguments['tags'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
    );
    await database.saveObject('memory', record.id, record.toJson());
    return ToolResult(success: true, output: 'Memori disimpan dengan ID ${record.id}.', data: record.toJson());
  }

  Future<ToolResult> _memoryDelete(Map<String, dynamic> arguments) async {
    final id = arguments['id']?.toString() ?? '';
    final existing = await database.getObject('memory', id);
    if (existing == null) return const ToolResult(success: false, output: 'Memori tidak ditemui.');
    await database.deleteObject('memory', id);
    return ToolResult(success: true, output: 'Memori $id dipadam.');
  }

  Future<ToolResult> _skillCreate(Map<String, dynamic> arguments) async {
    final skill = await skillService.createFromTool(arguments);
    return ToolResult(
      success: true,
      output: 'Skill ${skill.name} telah disimpan dan tersedia kepada model.',
      data: <String, dynamic>{
        ...skill.toJson(),
        'artifact': ChatArtifact(
          id: _uuid.v4(),
          kind: ArtifactKind.file,
          title: skill.name,
          subtitle: 'Skill local',
          data: skill.toJson(),
        ).toJson(),
      },
    );
  }

  Future<ToolResult> _skillInstall(Map<String, dynamic> arguments) async {
    final url = arguments['url']?.toString().trim() ?? '';
    final path = arguments['path']?.toString().trim() ?? '';
    if (url.isEmpty && path.isEmpty) {
      return const ToolResult(
        success: false,
        output:
            'Berikan url ATAU path. Untuk lampiran chat: path="strix-main.zip" atau path="/attachments/strix-main.zip".',
      );
    }
    final SkillDefinition skill;
    if (path.isNotEmpty) {
      final file = await _resolveReadableFile(path);
      if (!await file.exists()) {
        return ToolResult(success: false, output: 'Fail skill tidak jumpa: $path');
      }
      skill = await skillService.importZip(file.path);
    } else {
      skill = await skillService.importUrl(url);
    }
    return ToolResult(
      success: true,
      output: 'Skill ${skill.name} dipasang dan diaktifkan.',
      data: skill.toJson(),
    );
  }

  Future<ToolResult> _archiveUnzip(Map<String, dynamic> arguments) async {
    final src = arguments['path']?.toString().trim() ?? '';
    if (src.isEmpty) {
      return const ToolResult(success: false, output: 'path ZIP diperlukan.');
    }
    final file = await _resolveReadableFile(src);
    if (!await file.exists()) {
      return ToolResult(success: false, output: 'ZIP tidak jumpa: $src');
    }
    final bytes = await file.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    final root = await _workspace();
    var destRel = arguments['destination']?.toString().trim() ?? '';
    if (destRel.isEmpty) {
      final base = p.basename(file.path);
      destRel = base.toLowerCase().endsWith('.zip')
          ? base.substring(0, base.length - 4)
          : '${base}_extracted';
    }
    destRel = destRel.replaceAll('\\', '/');
    if (destRel.startsWith('/workspace/')) {
      destRel = destRel.substring('/workspace/'.length);
    }
    if (p.isAbsolute(destRel) || destRel.contains('..')) {
      return const ToolResult(success: false, output: 'destination mesti relatif dalam workspace.');
    }
    final destDir = Directory(p.join(root.path, destRel));
    await destDir.create(recursive: true);
    var count = 0;
    for (final entry in archive) {
      final name = p.normalize(entry.name.replaceAll('\\', '/'));
      if (name.startsWith('../') || p.isAbsolute(name) || name.contains('/../')) {
        continue;
      }
      final outPath = p.join(destDir.path, name);
      if (!p.isWithin(destDir.path, outPath) && outPath != destDir.path) continue;
      if (entry.isDirectory) {
        await Directory(outPath).create(recursive: true);
      } else {
        await File(outPath).parent.create(recursive: true);
        await File(outPath).writeAsBytes(entry.content as List<int>);
        count += 1;
      }
    }
    return ToolResult(
      success: true,
      output: 'Extract $count fail ke /workspace/$destRel',
      data: <String, dynamic>{'destination': destRel, 'files': count},
    );
  }

  Future<ToolResult> _archiveZip(Map<String, dynamic> arguments) async {
    final src = arguments['path']?.toString().trim() ?? '';
    if (src.isEmpty) {
      return const ToolResult(success: false, output: 'path sumber diperlukan.');
    }
    final root = await _workspace();
    final sourcePath = _resolveWorkspaceRelative(root, src);
    final entityType = FileSystemEntity.typeSync(sourcePath, followLinks: false);
    if (entityType == FileSystemEntityType.notFound) {
      return ToolResult(success: false, output: 'Sumber tidak jumpa: $src');
    }
    var destRel = arguments['destination']?.toString().trim() ?? '';
    if (destRel.isEmpty) {
      final base = p.basename(sourcePath);
      destRel = base.endsWith('.zip') ? base : '$base.zip';
    }
    destRel = destRel.replaceAll('\\', '/');
    if (destRel.startsWith('/workspace/')) destRel = destRel.substring('/workspace/'.length);
    if (p.isAbsolute(destRel) || destRel.contains('..')) {
      return const ToolResult(success: false, output: 'destination mesti relatif workspace.');
    }
    final outPath = _resolveWorkspaceRelative(root, destRel);
    final archive = Archive();
    if (entityType == FileSystemEntityType.file) {
      final data = await File(sourcePath).readAsBytes();
      archive.addFile(ArchiveFile(p.basename(sourcePath), data.length, data));
    } else {
      final dir = Directory(sourcePath);
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        final rel = p.relative(entity.path, from: sourcePath);
        final data = await entity.readAsBytes();
        archive.addFile(ArchiveFile(rel.replaceAll('\\', '/'), data.length, data));
      }
    }
    final encoded = ZipEncoder().encode(archive);
    if (encoded.isEmpty) {
      return const ToolResult(success: false, output: 'Gagal encode ZIP (kosong).');
    }
    await File(outPath).parent.create(recursive: true);
    await File(outPath).writeAsBytes(encoded, flush: true);
    return ToolResult(
      success: true,
      output: 'ZIP dicipta: /workspace/$destRel (${encoded.length} bait)',
      data: <String, dynamic>{'destination': destRel, 'bytes': encoded.length},
    );
  }


  Future<ToolResult> _skillRunScript(Map<String, dynamic> arguments) async {
    final skillId = arguments['skill_id']?.toString() ?? '';
    final script = arguments['script']?.toString() ?? '';
    if (skillId.trim().isEmpty) {
      return const ToolResult(
        success: false,
        output:
            'skill_id diperlukan. Skill dari skill_create (arahan sahaja) tiada folder skrip — guna terminal_start.',
      );
    }
    if (p.isAbsolute(script) || p.normalize(script).startsWith('../')) {
      return const ToolResult(success: false, output: 'Path skrip di luar sandbox tidak dibenarkan.');
    }
    try {
      final cwd = await skillService.prepareScriptSandbox(skillId);
      final args = (arguments['arguments'] as List? ?? const <dynamic>[])
          .map((item) => _shellQuote(item.toString()))
          .join(' ');
      final command = '${_shellQuote(script)}${args.isEmpty ? '' : ' $args'}';
      return terminalService.start(command: command, workingDirectory: cwd);
    } on StateError catch (e) {
      // Skill skill_create / tiada sourcePath → bukan pakej skrip.
      return ToolResult(
        success: false,
        output:
            '${e.message}\n'
            'Skill arahan-sahaja (skill_create) tiada folder skrip. '
            'Guna terminal_start untuk jalan perintah, atau pasang ZIP skill yang ada skrip.',
      );
    }
  }

  Future<ToolResult> _mcpListTools(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final tools = await mcpService.listTools(server);
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(tools), data: <String, dynamic>{'server': server.toJson(), 'tools': tools});
  }

  Future<ToolResult> _mcpCall(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final result = await mcpService.callTool(
      server,
      name: arguments['tool_name']?.toString() ?? '',
      arguments: Map<String, dynamic>.from(arguments['arguments'] as Map? ?? const <String, dynamic>{}),
    );
    return ToolResult(success: result['isError'] != true, output: const JsonEncoder.withIndent('  ').convert(result), data: result);
  }

  Future<McpServerConfig> _mcpServer(String id) async {
    final json = await database.getObject('mcp_server', id);
    if (json == null) throw StateError('Server MCP $id tidak ditemui.');
    final server = McpServerConfig.fromJson(json);
    if (!server.enabled) throw StateError('Server MCP ${server.name} tidak aktif.');
    return server;
  }

  Future<ToolResult> _calculator(Map<String, dynamic> arguments) async {
    final expression = arguments['expression']?.toString() ?? '';
    final parsed = Parser().parse(expression);
    final value = parsed.evaluate(EvaluationType.REAL, ContextModel());
    return ToolResult(success: true, output: value.toString());
  }

  Future<bool> _workspaceEntityExists(String relative) async {
    if (relative.trim().isEmpty) return false;
    final root = await _workspace();
    final normalized = p.normalize(p.join(root.path, relative));
    if (normalized == root.path || !p.isWithin(root.path, normalized)) return true;
    return FileSystemEntity.type(normalized, followLinks: false).then((type) => type != FileSystemEntityType.notFound);
  }

  bool _looksDestructive(String value) {
    final text = value.toLowerCase();
    return <String>['delete', 'remove', 'destroy', 'drop', 'erase', 'wipe', 'reset', 'revoke', 'uninstall', 'truncate', 'padam', 'hapus']
        .any(text.contains);
  }

  Uri _validatedHttpUri(String raw) {
    var text = raw.trim();
    // Buang quotes / whitespace yang model sering letak.
    if ((text.startsWith('"') && text.endsWith('"')) ||
        (text.startsWith("'") && text.endsWith("'"))) {
      text = text.substring(1, text.length - 1).trim();
    }
    text = text.replaceAll(RegExp(r'\s+'), '');
    if (text.isEmpty) {
      throw const FormatException('URL kosong — berikan http(s)://…');
    }
    final lower = text.toLowerCase();
    if (lower.startsWith('javascript:') ||
        lower.startsWith('data:') ||
        lower.startsWith('about:blank') && text.length < 20 ||
        lower == 'about:blank') {
      throw FormatException(
        'URL tidak dilayari: "$text". Guna http(s) sahaja, bukan javascript:/data:.',
      );
    }
    // //example.com → https://example.com
    if (text.startsWith('//')) {
      text = 'https:$text';
    }
    // example.com/path tanpa skema → https://
    final hasScheme = RegExp(r'^[a-zA-Z][a-zA-Z0-9+.-]*:').hasMatch(text);
    if (!hasScheme && text.contains('.')) {
      text = 'https://$text';
    }
    final uri = Uri.tryParse(text);
    if (uri == null ||
        !<String>{'http', 'https'}.contains(uri.scheme) ||
        (uri.host.isEmpty && uri.path.isEmpty)) {
      throw FormatException(
        'URL HTTP/HTTPS tidak sah: "${raw.length > 120 ? '${raw.substring(0, 120)}…' : raw}". '
        'Guna bentuk penuh cth. https://example.com/path',
      );
    }
    if (uri.host.isEmpty) {
      throw FormatException(
        'URL tiada host: "$text". Contoh sah: https://example.com',
      );
    }
    return uri;
  }

  Future<Directory> _workspace() async {
    final directory = Directory(p.join((await getApplicationSupportDirectory()).path, 'linux', 'workspace'));
    await directory.create(recursive: true);
    return directory;
  }

  /// Tolak path host Android / absolute luar workspace supaya model tidak
  /// boleh list/read path seperti /data/user/0/.../rootfs/dev/pts.
  bool _looksLikeForbiddenHostPath(String raw) {
    final normalized = raw.replaceAll('\\', '/').trim();
    if (normalized.isEmpty) return false;
    final lower = normalized.toLowerCase();
    const blockedPrefixes = <String>[
      '/data/',
      '/storage/',
      '/sdcard',
      '/mnt/',
      '/proc/',
      '/sys/',
      '/dev/',
      '/system/',
      '/vendor/',
      '/apex/',
    ];
    if (blockedPrefixes.any(
      (prefix) =>
          lower == prefix.replaceAll('/', '') || lower.startsWith(prefix),
    )) {
      return true;
    }
    // Path relatif yang cuba keluar ke rootfs host / pts.
    if (lower.contains('com.aiauto.claw') ||
        lower.contains('/files/linux') ||
        lower.contains('rootfs/dev') ||
        lower.contains('/dev/pts') ||
        lower.contains('../rootfs') ||
        lower.contains('..\\rootfs')) {
      return true;
    }
    // Path absolute lain di luar guest workspace juga ditolak.
    if (p.isAbsolute(normalized) &&
        !lower.startsWith('/workspace') &&
        !lower.startsWith('/root') &&
        !lower.startsWith('/tmp') &&
        !lower.startsWith('/attachments')) {
      return true;
    }
    return false;
  }

  String _resolveWorkspaceRelative(Directory root, String relative) {
    final raw = relative.trim().replaceAll('\\', '/');
    if (raw.isEmpty) {
      throw const FileSystemException('Path kosong tidak dibenarkan.');
    }
    if (_looksLikeForbiddenHostPath(raw)) {
      throw const FileSystemException(
        'Akses path host Android atau path di luar workspace tidak dibenarkan. '
        'Gunakan path relatif dalam workspace, atau nama fail lampiran.',
      );
    }

    var rel = raw;
    if (rel.startsWith('/workspace/')) {
      rel = rel.substring('/workspace/'.length);
    } else if (rel == '/workspace') {
      rel = '.';
    } else if (rel.startsWith('/attachments/') ||
        rel.startsWith('attachments/') ||
        rel == '/attachments') {
      throw const FileSystemException(
        'Path /attachments diselesaikan melalui tool skill_install_url (path) atau archive_unzip.',
      );
    } else if (p.isAbsolute(rel)) {
      throw const FileSystemException(
        'Path mutlak host tidak dibenarkan. Gunakan path relatif dalam workspace.',
      );
    }

    final path = p.normalize(p.join(root.path, rel));
    if (path != root.path && !p.isWithin(root.path, path)) {
      throw const FileSystemException(
        'Akses di luar workspace tidak dibenarkan.',
      );
    }
    return path;
  }

  Future<File> _resolveReadableFile(String rawPath) async {
    final raw = rawPath.trim().replaceAll('\\', '/');
    if (raw.isEmpty) {
      throw const FileSystemException('Path fail kosong.');
    }

    // Path host chat_attachments dari metadata mesej — dibenarkan.
    if (raw.contains('/chat_attachments/')) {
      final file = File(raw);
      if (await file.exists()) return file;
    }

    String? fileName;
    final lower = raw.toLowerCase();
    if (lower.startsWith('/attachments/')) {
      fileName = raw.substring('/attachments/'.length);
    } else if (lower.startsWith('attachments/')) {
      fileName = raw.substring('attachments/'.length);
    } else if (!raw.contains('/') && raw.contains('.')) {
      fileName = raw;
    }

    if (fileName != null &&
        fileName.isNotEmpty &&
        !fileName.contains('..') &&
        !fileName.startsWith('/')) {
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory(p.join(docs.path, 'chat_attachments'));
      if (await dir.exists()) {
        await for (final entity in dir.list(recursive: true, followLinks: false)) {
          if (entity is! File) continue;
          final base = p.basename(entity.path);
          if (base == fileName ||
              base.endsWith('_$fileName') ||
              base.endsWith(fileName)) {
            return entity;
          }
        }
      }
    }

    final root = await _workspace();
    return File(_resolveWorkspaceRelative(root, raw));
  }


  Directory _safeWorkspaceDirectory(Directory root, String relative) {
    return Directory(_resolveWorkspaceRelative(root, relative));
  }

  File _safeWorkspaceFile(Directory root, String relative) {
    return File(_resolveWorkspaceRelative(root, relative));
  }

  String _sanitizeHtmlPreview(String rawHtml, String baseUrl) {
    if (rawHtml.trim().isEmpty) return '';
    final document = html_parser.parse(rawHtml);
    for (final node in document.querySelectorAll(
      'script,noscript,iframe,object,embed,template,canvas,form,input,textarea,select,button,video,audio,source,track,meta[http-equiv="refresh"]',
    )) {
      node.remove();
    }
    final base = Uri.tryParse(baseUrl);
    for (final element in document.querySelectorAll('*')) {
      final unsafe = element.attributes.keys.where((name) {
        final normalizedName = name.toString().toLowerCase();
        return normalizedName.startsWith('on') || normalizedName == 'srcdoc';
      }).toList();
      for (final name in unsafe) {
        element.attributes.remove(name);
      }
      element.attributes.remove('autoplay');
      element.attributes.remove('srcdoc');
      if (base != null) {
        for (final attribute in const <String>['href', 'src', 'poster']) {
          final value = element.attributes[attribute];
          if (value == null || value.trim().isEmpty || value.startsWith('data:') || value.startsWith('#')) continue;
          final resolved = base.resolve(value);
          if (<String>{'http', 'https'}.contains(resolved.scheme)) {
            element.attributes[attribute] = resolved.toString();
          }
        }
      }
    }
    final output = document.outerHtml;
    if (output.length <= AppConfig.maxHtmlPreviewChars) return output;
    final title = document.querySelector('title')?.text.trim() ?? 'Pratonton halaman';
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final clipped = text.length <= AppConfig.maxHtmlPreviewChars
        ? text
        : '${text.substring(0, AppConfig.maxHtmlPreviewChars)}…';
    return '<article><h2>${const HtmlEscape().convert(title)}</h2><p>${const HtmlEscape().convert(clipped)}</p></article>';
  }

  ArtifactKind _artifactKindForPath(String path) {
    final extension = p.extension(path).toLowerCase();
    if (<String>{'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.heic', '.svg'}.contains(extension)) {
      return ArtifactKind.image;
    }
    if (<String>{'.mp4', '.mkv', '.mov', '.webm', '.m4v', '.avi'}.contains(extension)) {
      return ArtifactKind.video;
    }
    if (<String>{'.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac', '.opus'}.contains(extension)) {
      return ArtifactKind.audio;
    }
    if (<String>{'.html', '.htm'}.contains(extension)) return ArtifactKind.html;
    return ArtifactKind.file;
  }

  String _mimeForPath(String path) {
    return switch (p.extension(path).toLowerCase()) {
      '.png' => 'image/png',
      '.jpg' || '.jpeg' => 'image/jpeg',
      '.gif' => 'image/gif',
      '.webp' => 'image/webp',
      '.svg' => 'image/svg+xml',
      '.mp4' || '.m4v' => 'video/mp4',
      '.webm' => 'video/webm',
      '.mp3' => 'audio/mpeg',
      '.wav' => 'audio/wav',
      '.m4a' => 'audio/mp4',
      '.ogg' || '.opus' => 'audio/ogg',
      '.pdf' => 'application/pdf',
      '.json' => 'application/json',
      '.html' || '.htm' => 'text/html',
      '.md' => 'text/markdown',
      '.txt' || '.log' => 'text/plain',
      '.csv' => 'text/csv',
      _ => 'application/octet-stream',
    };
  }

  String _safeFilename(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
  String _clip(String value) => value.length <= AppConfig.maxToolOutputChars ? value : '${value.substring(0, AppConfig.maxToolOutputChars)}…';
  String _shellQuote(String value) => "'${value.replaceAll("'", "'\\''")}'";

  Map<String, String> _browserHeaders({bool desktop = true}) =>
      <String, String>{
        'User-Agent': desktop
            ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0'
            : 'Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 '
                'AiMultiAgent/1.0.0',
        'Accept':
            'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      };

  void dispose() {
    browserSession.dispose();
    terminalService.dispose();
    skillService.dispose();
    mcpService.dispose();
    _client.close();
  }
}
