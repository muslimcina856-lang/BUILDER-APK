import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../theme/app_theme.dart';
import 'artifacts_library_screen.dart';
import 'tool_logs_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with WidgetsBindingObserver {
  bool _notifGranted = false;
  bool _batteryUnrestricted = false;
  bool _checkingPerms = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshPermissionState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshPermissionState();
    }
  }

  Future<void> _refreshPermissionState() async {
    if (_checkingPerms) return;
    _checkingPerms = true;
    try {
      final plugin = FlutterLocalNotificationsPlugin();
      final android = plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final enabled = await android?.areNotificationsEnabled() ?? false;
      final app = AppScope.read(context);
      final batteryOk = await app.platformBridge.isBatteryUnrestricted();
      if (!mounted) return;
      setState(() {
        _notifGranted = enabled;
        _batteryUnrestricted = batteryOk;
      });

      // Auto-untick jika notifikasi ATAU bateri bukan "Tiada sekatan".
      if (app.backgroundExecutionAllowed && (!enabled || !batteryOk)) {
        await app.setBackgroundExecutionAllowed(false);
        if (mounted) {
          final reason = !enabled && !batteryOk
              ? 'Notifikasi dimatikan dan bateri masih disekat'
              : !enabled
                  ? 'Notifikasi dimatikan'
                  : 'Bateri bukan "Tiada sekatan"';
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                '$reason — tugas latar belakang dinyahaktifkan.',
              ),
            ),
          );
        }
      }
    } finally {
      _checkingPerms = false;
    }
  }

  Future<void> _onBackgroundToggle(bool value) async {
    final app = AppScope.read(context);
    if (!value) {
      await app.setBackgroundExecutionAllowed(false);
      return;
    }

    // 1) Minta notifikasi
    final plugin = FlutterLocalNotificationsPlugin();
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final granted = await android?.requestNotificationsPermission() ?? false;
    if (mounted) setState(() => _notifGranted = granted);

    // 2) Buka page bateri APP ini (bukan "pengoptimuman bateri" global).
    await app.platformBridge.openBatteryOptimizationSettings();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Pilih "Tiada sekatan". Jika page salah: Info apl → Kuasa → Tiada sekatan.',
          ),
          duration: Duration(seconds: 6),
        ),
      );
    }

    if (!granted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Dayakan notifikasi, kemudian pilih "Tiada sekatan" pada bateri app.',
            ),
          ),
        );
      }
      await app.setBackgroundExecutionAllowed(false);
      return;
    }

    // Semak semula selepas user kembali (onResume juga semak).
    final batteryOk = await app.platformBridge.isBatteryUnrestricted();
    if (mounted) setState(() => _batteryUnrestricted = batteryOk);

    if (!batteryOk) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Pilih "Tiada sekatan" / Unrestricted pada penjimat bateri app ini, kemudian tick semula.',
            ),
            duration: Duration(seconds: 5),
          ),
        );
      }
      await app.setBackgroundExecutionAllowed(false);
      return;
    }

    await app.setBackgroundExecutionAllowed(true);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Latar belakang aktif. Notif hanya bila anda keluar app.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Tetapan')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 40),
        children: <Widget>[
          const _SectionTitle('Data & artifact'),
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.folder_copy_outlined,
                color: AppTheme.purpleLight,
              ),
              title: const Text(
                'Perpustakaan Artifact',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'Imej, zip, skrip mengikut sesi. Chat baru tidak akses artifact sesi lain.',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const ArtifactsLibraryScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Latar belakang'),
          Card(
            child: SwitchListTile.adaptive(
              value: state.backgroundExecutionAllowed &&
                  _notifGranted &&
                  _batteryUnrestricted,
              onChanged: _onBackgroundToggle,
              secondary: Icon(
                Icons.sync_rounded,
                color: state.backgroundExecutionAllowed &&
                        _notifGranted &&
                        _batteryUnrestricted
                    ? AppTheme.success
                    : AppTheme.purpleLight,
              ),
              title: const Text(
                'Tugas latar belakang',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                state.backgroundExecutionAllowed &&
                        _notifGranted &&
                        _batteryUnrestricted
                    ? 'Aktif · notif hanya bila keluar app'
                    : 'Mati · tick untuk dayakan (bateri: Tiada sekatan)',
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 4, 4, 10),
            child: Text(
              'Semua tool agent dibenarkan automatik.',
              style: TextStyle(color: Colors.white60),
            ),
          ),
          const _SectionTitle('Audit local'),
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.receipt_long_outlined,
                color: AppTheme.purpleLight,
              ),
              title: const Text('Log tool'),
              subtitle: const Text(
                'Metadata dan ringkasan disimpan local; token dan API key ditapis.',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const ToolLogsScreen(),
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Privasi dan data local'),
          const Card(
            child: ListTile(
              leading: Icon(Icons.key_rounded, color: AppTheme.purpleLight),
              title: Text('API key dalam secure storage'),
              subtitle: Text(
                'API key tidak disimpan bersama chat atau konfigurasi SQLite.',
              ),
            ),
          ),
          const Card(
            child: ListTile(
              leading: Icon(Icons.cloud_off_rounded, color: AppTheme.purpleLight),
              title: Text('Tiada backend Ai MultiAgent'),
              subtitle: Text(
                'Permintaan dihantar terus kepada Base URL provider yang dipilih.',
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.delete_sweep_outlined,
                color: AppTheme.danger,
              ),
              title: const Text('Padam semua data local'),
              subtitle: const Text(
                'Provider, API key, chat, memori, skills, automasi dan MCP akan dipadam.',
              ),
              onTap: () => _deleteAll(context),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Tentang aplikasi'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: Text(AppConfig.launcherName),
              subtitle: Text(
                '${AppConfig.packageName}\nVersi ${AppConfig.version}\nEdisi ${AppConfig.editionName} · Target API ${AppConfig.androidTargetSdk} · Local BYOK',
              ),
              isThreeLine: true,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteAll(BuildContext context) async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            icon: const Icon(Icons.warning_amber_rounded, color: Colors.amber),
            title: const Text('Padam semua data?'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'Tindakan ini tidak boleh dipulihkan. Taip PADAM untuk meneruskan.',
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  decoration: const InputDecoration(labelText: 'Pengesahan'),
                ),
              ],
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Batal'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(
                  context,
                  controller.text.trim().toUpperCase() == 'PADAM',
                ),
                child: const Text('Padam semua'),
              ),
            ],
          ),
        ) ??
        false;
    controller.dispose();
    if (!confirmed || !context.mounted) return;
    await AppScope.read(context).deleteAllLocalData();
    if (context.mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Semua data local telah dipadam.')),
      );
    }
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w900,
            color: AppTheme.purpleLight,
          ),
        ),
      );
}
