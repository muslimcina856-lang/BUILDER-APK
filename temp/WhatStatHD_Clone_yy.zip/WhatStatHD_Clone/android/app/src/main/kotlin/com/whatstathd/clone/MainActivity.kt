package com.whatstathd.clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
