import 'package:flutter_test/flutter_test.dart';
import 'package:whatstathd_clone/main.dart';

void main() {
  testWidgets('App launches', (WidgetTester tester) async {
    await tester.pumpWidget(const WhatStatHDApp());
    expect(find.text('WhatStatHD'), findsOneWidget);
  });
}
