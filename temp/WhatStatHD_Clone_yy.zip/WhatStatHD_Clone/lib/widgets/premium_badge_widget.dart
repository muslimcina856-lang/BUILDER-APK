import 'package:flutter/material.dart';

class PremiumBadgeWidget extends StatelessWidget {
  final bool showActive;
  final double fontSize;
  final double iconSize;

  const PremiumBadgeWidget({
    super.key,
    this.showActive = true,
    this.fontSize = 12,
    this.iconSize = 16,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF128C7E), Color(0xFF075E54)],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF128C7E).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star, color: const Color(0xFFFFD700), size: iconSize),
          const SizedBox(width: 4),
          Text(
            'PREMIUM${showActive ? ' ACTIVE' : ''}',
            style: TextStyle(
              color: Colors.white,
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}
