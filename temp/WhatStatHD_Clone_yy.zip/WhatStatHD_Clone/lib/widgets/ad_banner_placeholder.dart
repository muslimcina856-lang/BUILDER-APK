import 'package:flutter/material.dart';

/// Ad banner placeholder — removed for premium users.
/// Returns an empty widget. No ad SDKs are loaded.
class AdBannerPlaceholder extends StatelessWidget {
  const AdBannerPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}
