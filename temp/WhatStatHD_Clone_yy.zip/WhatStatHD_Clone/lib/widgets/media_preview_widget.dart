import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

class MediaPreviewWidget extends StatelessWidget {
  final String filePath;
  final String fileName;
  final String fileSize;
  final String? duration;
  final String? resolution;
  final bool isVideo;

  const MediaPreviewWidget({
    super.key,
    required this.filePath,
    required this.fileName,
    required this.fileSize,
    this.duration,
    this.resolution,
    this.isVideo = false,
  });

  @override
  Widget build(BuildContext context) {
    final ext = p.extension(filePath).toLowerCase();
    final isVideoFile = isVideo || ['.mp4', '.mov', '.avi', '.mkv'].contains(ext);

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(12),
              topRight: Radius.circular(12),
            ),
            child: Container(
              height: 160,
              width: double.infinity,
              color: const Color(0xFF2A3942),
              child: Center(
                child: Icon(
                  isVideoFile ? Icons.videocam : Icons.image,
                  size: 48,
                  color: Colors.white38,
                ),
              ),
            ),
          ),
          // Info
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fileName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  fileSize,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
                if (duration != null) ...[
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      const Icon(Icons.timer, size: 12, color: Colors.white38),
                      const SizedBox(width: 4),
                      Text(
                        duration!,
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
                if (resolution != null) ...[
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      const Icon(Icons.aspect_ratio, size: 12, color: Colors.white38),
                      const SizedBox(width: 4),
                      Text(
                        resolution!,
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
