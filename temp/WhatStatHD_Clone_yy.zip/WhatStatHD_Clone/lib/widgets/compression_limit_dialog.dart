import 'package:flutter/material.dart';

class CompressionLimitDialog {
  /// Shows the premium unlimited dialog.
  static Future<void> show(BuildContext context) async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F2C34),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Row(
          children: [
            Icon(Icons.star, color: Color(0xFFFFD700), size: 28),
            SizedBox(width: 12),
            Text(
              'Premium Unlimited',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: const Text(
          'You have unlimited compressions as a Premium user.

'
          'No limits. No restrictions. Compress as much as you want!',
          style: TextStyle(color: Colors.white70, fontSize: 15),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text(
              'Got it',
              style: TextStyle(
                color: Color(0xFF128C7E),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
