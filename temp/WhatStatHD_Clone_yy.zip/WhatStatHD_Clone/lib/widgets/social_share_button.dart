import 'package:flutter/material.dart';

class SocialShareButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onPressed;

  const SocialShareButton({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
    this.onPressed,
  });

  factory SocialShareButton.whatsApp({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.chat,
      label: 'WhatsApp
Status',
      color: const Color(0xFF25D366),
      onPressed: onPressed,
    );
  }

  factory SocialShareButton.instagram({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.camera_alt,
      label: 'Instagram
Story',
      color: const Color(0xFFE1306C),
      onPressed: onPressed,
    );
  }

  factory SocialShareButton.facebook({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.facebook,
      label: 'Facebook
Story',
      color: const Color(0xFF1877F2),
      onPressed: onPressed,
    );
  }

  factory SocialShareButton.snapchat({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.send,
      label: 'Snapchat',
      color: const Color(0xFFFFFC00),
      onPressed: onPressed,
    );
  }

  factory SocialShareButton.save({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.download,
      label: 'Save to
Gallery',
      color: const Color(0xFF128C7E),
      onPressed: onPressed,
    );
  }

  factory SocialShareButton.share({VoidCallback? onPressed}) {
    return SocialShareButton(
      icon: Icons.share,
      label: 'Share
via...',
      color: Colors.white70,
      onPressed: onPressed,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 72,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color.withOpacity(0.9),
                fontSize: 10,
                fontWeight: FontWeight.w500,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
