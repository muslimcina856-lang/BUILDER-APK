import 'package:flutter/material.dart';

class FeatureRowWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool isPremium;

  const FeatureRowWidget({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.isPremium = true,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF128C7E).withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: const Color(0xFF128C7E), size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.white54,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: isPremium
                  ? const Color(0xFF128C7E).withOpacity(0.2)
                  : Colors.white12,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              isPremium ? Icons.check_circle : Icons.lock,
              color: isPremium ? const Color(0xFF128C7E) : Colors.white38,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }
}
