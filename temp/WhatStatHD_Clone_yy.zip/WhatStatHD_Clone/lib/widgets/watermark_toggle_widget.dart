import 'package:flutter/material.dart';

class WatermarkToggleWidget extends StatefulWidget {
  final bool initialValue;
  final String label;
  final ValueChanged<bool> onChanged;

  const WatermarkToggleWidget({
    super.key,
    this.initialValue = false,
    this.label = 'Add Watermark',
    required this.onChanged,
  });

  @override
  State<WatermarkToggleWidget> createState() => _WatermarkToggleWidgetState();
}

class _WatermarkToggleWidgetState extends State<WatermarkToggleWidget> {
  late bool _value;

  @override
  void initState() {
    super.initState();
    _value = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF2A3942),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.water_drop, color: Color(0xFF128C7E), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              widget.label,
              style: const TextStyle(
                fontSize: 15,
                color: Colors.white,
              ),
            ),
          ),
          Switch(
            value: _value,
            onChanged: (val) {
              setState(() => _value = val);
              widget.onChanged(val);
            },
            activeColor: const Color(0xFF128C7E),
            inactiveThumbColor: Colors.white38,
            inactiveTrackColor: Colors.white12,
          ),
        ],
      ),
    );
  }
}
