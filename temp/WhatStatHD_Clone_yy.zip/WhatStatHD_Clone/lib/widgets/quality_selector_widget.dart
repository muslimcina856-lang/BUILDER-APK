import 'package:flutter/material.dart';

class QualityOption {
  final String label;
  final int height;
  final int bitrate;

  const QualityOption(this.label, this.height, this.bitrate);
}

class QualitySelectorWidget extends StatelessWidget {
  final String selectedQuality;
  final ValueChanged<String> onQualityChanged;
  final List<QualityOption> options;

  const QualitySelectorWidget({
    super.key,
    required this.selectedQuality,
    required this.onQualityChanged,
    this.options = const [
      QualityOption('1080p', 1080, 16000),
      QualityOption('720p', 720, 8000),
      QualityOption('480p', 480, 4000),
      QualityOption('360p', 360, 2000),
    ],
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Quality',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.white70,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((option) {
            final isSelected = selectedQuality == option.label;
            return ChoiceChip(
              label: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    option.label,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.white70,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  Text(
                    '${option.bitrate ~/ 1000} Mbps',
                    style: TextStyle(
                      fontSize: 10,
                      color: isSelected ? Colors.white70 : Colors.white38,
                    ),
                  ),
                ],
              ),
              selected: isSelected,
              selectedColor: const Color(0xFF075E54),
              backgroundColor: const Color(0xFF2A3942),
              onSelected: (selected) {
                if (selected) onQualityChanged(option.label);
              },
            );
          }).toList(),
        ),
      ],
    );
  }
}
