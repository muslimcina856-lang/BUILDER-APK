import 'package:flutter/material.dart';
import 'preferences_service.dart';

class RatingService {
  final PreferencesService _prefs;

  RatingService(this._prefs);

  /// Returns true if rating dialog can be shown.
  /// Shows after 3 compressions if not already shown/dismissed.
  bool canShowRating() {
    if (_prefs.ratingShown) return false;
    return _prefs.compressionCount >= 3;
  }

  /// Marks that the rating prompt has been shown.
  Future<void> markRatingShown() async {
    await _prefs.setRatingShown(true);
  }

  /// Marks that the user has rated the app.
  Future<void> markRated() async {
    await _prefs.setRatingShown(true);
  }

  /// Opens the Play Store for rating.
  /// In this premium unlock version, just shows a thank you message.
  void openPlayStore(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Thanks for rating! ⭐'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  /// Shows rating dialog.
  Future<void> showRatingDialog(BuildContext context) async {
    if (!canShowRating()) return;
    await markRatingShown();

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F2C34),
        title: const Row(
          children: [
            Icon(Icons.star_rate_rounded, color: Color(0xFFFFD700), size: 28),
            SizedBox(width: 8),
            Text('Rate WhatStatHD', style: TextStyle(color: Colors.white)),
          ],
        ),
        content: const Text(
          'If you enjoy using WhatStatHD Premium, please take a moment to rate us!',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Later', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Rate Now', style: TextStyle(color: Color(0xFF128C7E))),
          ),
        ],
      ),
    );

    if (result == true) {
      openPlayStore(context);
    }
  }
}
