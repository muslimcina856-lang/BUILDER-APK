/// Ad service stub — all ads are removed for premium users.
/// No ad SDKs are loaded. All methods return instantly.
class AdService {
  bool _initialized = false;

  Future<void> init() async {
    _initialized = true;
  }

  /// Returns null — no banner ad available (premium).
  dynamic loadBannerAd() => null;

  /// Returns null — no interstitial ad available (premium).
  dynamic loadInterstitialAd() => null;

  /// Returns null — no rewarded ad available (premium).
  dynamic loadRewardedAd() => null;

  /// No-op. Banner ads are disabled.
  void showBannerAd() {}

  /// Returns true immediately — no ad to show.
  bool showInterstitialAd() => true;

  /// Returns true immediately — no ad to show.
  bool showRewardedAd() => true;

  /// Cleans up any resources (none in stub).
  void dispose() {
    _initialized = false;
  }

  bool get isInitialized => _initialized;
}
