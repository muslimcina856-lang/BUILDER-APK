class UpdateCheckService {
  /// Checks for app updates. Always returns that the current version is latest.
  Future<Map<String, dynamic>> checkForUpdate() async {
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 500));

    return {
      'hasUpdate': false,
      'latestVersion': '2026.07.01',
      'forceUpdate': false,
      'updateUrl': '',
      'releaseNotes': [],
    };
  }

  /// Returns current app version.
  String getCurrentVersion() => '2026.07.01';

  /// Returns true if the app is up to date.
  bool isLatestVersion() => true;
}
