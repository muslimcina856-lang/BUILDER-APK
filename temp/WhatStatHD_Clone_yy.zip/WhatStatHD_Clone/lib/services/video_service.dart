import 'dart:async';
import 'dart:convert';
import 'dart:io';

class VideoInfo {
  final double duration;
  final int width;
  final int height;
  final int size;
  final String codec;
  final int rotation;

  VideoInfo({
    required this.duration,
    required this.width,
    required this.height,
    required this.size,
    required this.codec,
    this.rotation = 0,
  });

  factory VideoInfo.fromMap(Map<String, dynamic> map) {
    return VideoInfo(
      duration: (map['duration'] ?? 0.0).toDouble(),
      width: (map['width'] ?? 0).toInt(),
      height: (map['height'] ?? 0).toInt(),
      size: (map['size'] ?? 0).toInt(),
      codec: map['codec'] ?? 'unknown',
      rotation: (map['rotation'] ?? 0).toInt(),
    );
  }
}

class VideoCompressionResult {
  final String path;
  final int originalSize;
  final int compressedSize;
  final double compressionRatio;
  final double duration;

  VideoCompressionResult({
    required this.path,
    required this.originalSize,
    required this.compressedSize,
    required this.compressionRatio,
    required this.duration,
  });
}

class VideoService {
  bool _isCancelled = false;
  Process? _currentProcess;

  Future<VideoInfo> getVideoInfo(String path) async {
    final result = await Process.run('ffprobe', [
      '-v',
      'quiet',
      '-print_format',
      'json',
      '-show_streams',
      '-show_format',
      path,
    ]);

    if (result.exitCode != 0) {
      throw Exception('Failed to get video info: ${result.stderr}');
    }

    final Map<String, dynamic> data = json.decode(result.stdout as String);
    final streams = data['streams'] as List<dynamic>? ?? [];
    final format = data['format'] as Map<String, dynamic>? ?? {};

    Map<String, dynamic>? videoStream;
    for (final stream in streams) {
      if (stream is Map<String, dynamic> && stream['codec_type'] == 'video') {
        videoStream = stream;
        break;
      }
    }

    return VideoInfo(
      duration: double.tryParse(format['duration']?.toString() ?? '0') ?? 0.0,
      width: videoStream?['width'] ?? 0,
      height: videoStream?['height'] ?? 0,
      size: int.tryParse(format['size']?.toString() ?? '0') ?? 0,
      codec: videoStream?['codec_name'] ?? 'unknown',
      rotation: videoStream?['rotation'] ?? 0,
    );
  }

  Future<VideoCompressionResult> compressFast({
    required String inputPath,
    required String outputPath,
    int targetHeight = 1080,
    int bitrateKbps = 16000,
    bool enableWatermark = false,
    String? watermarkPath,
    double? trimStart,
    double? trimEnd,
    String audioMode = 'original',
    bool enableUnsharp = true,
    Function(double progress)? onProgress,
  }) async {
    _isCancelled = false;

    final originalSize = await File(inputPath).length();
    final info = await getVideoInfo(inputPath);

    // Calculate scale to maintain aspect ratio
    final scaleHeight = targetHeight;
    final scaleWidth = (info.width * targetHeight / info.height).round();
    final evenWidth = scaleWidth.isEven ? scaleWidth : scaleWidth + 1;

    // Build FFmpeg command matching original app standards:
    // H.264, main profile, level 4.0, yuv420p, faststart
    final filters = <String>[];

    // Scale filter
    filters.add(
        'scale=$evenWidth:$scaleHeight:force_original_aspect_ratio=decrease');

    // Pad for non-standard aspect ratios (like original)
    filters.add(
        'pad=$evenWidth:$scaleHeight:(ow-iw)/2:(oh-ih)/2:color=black');

    // Unsharp filter (matching original)
    if (enableUnsharp) {
      filters.add('unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount=0.5');
    }

    // Watermark overlay
    if (enableWatermark && watermarkPath != null) {
      filters.add('overlay=W-w-10:H-h-10');
    }

    final filterComplex = filters.join(',');

    // Build command arguments
    final List<String> cmdArgs = [
      '-i',
      inputPath,
      '-c:v',
      'libx264',
      '-preset',
      'medium',
      '-profile:v',
      'main',
      '-level:v',
      '4.0',
      '-pix_fmt',
      'yuv420p',
      '-vf',
      filterComplex,
      '-b:v',
      '${bitrateKbps}k',
      '-maxrate',
      '${bitrateKbps}k',
      '-bufsize',
      '${(bitrateKbps * 2)}k',
      '-movflags',
      '+faststart',
    ];

    // Audio handling
    if (audioMode == 'mute') {
      cmdArgs.addAll(['-an']);
    } else if (audioMode == 'replace' && watermarkPath != null) {
      cmdArgs.addAll([
        '-i',
        watermarkPath,
        '-c:a',
        'aac',
        '-b:a',
        '128k',
        '-map',
        '0:v:0',
        '-map',
        '1:a:0',
        '-shortest',
      ]);
    } else {
      cmdArgs.addAll(['-c:a', 'aac', '-b:a', '128k', '-map', '0']);
    }

    // Trim support
    if (trimStart != null && trimStart > 0) {
      cmdArgs.addAll(['-ss', trimStart.toString()]);
    }
    if (trimEnd != null && trimEnd > 0) {
      cmdArgs.addAll(['-t', (trimEnd - (trimStart ?? 0)).toString()]);
    }

    cmdArgs.add('-y');
    cmdArgs.add(outputPath);

    // Execute FFmpeg command using Process.start for progress tracking
    _currentProcess = await Process.start('ffmpeg', cmdArgs);
    final stderrLines = <String>[];

    // Parse progress from stderr
    _currentProcess!.stderr
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) {
      stderrLines.add(line);
      if (line.contains('time=')) {
        final timeMatch =
            RegExp(r'time=(\d+):(\d+):(\d+)\.(\d+)').firstMatch(line);
        if (timeMatch != null && info.duration > 0) {
          final hours = int.parse(timeMatch.group(1)!);
          final minutes = int.parse(timeMatch.group(2)!);
          final seconds = int.parse(timeMatch.group(3)!);
          final totalSeconds =
              hours * 3600 + minutes * 60 + seconds.toDouble();
          final progress = totalSeconds / info.duration;
          onProgress?.call(progress.clamp(0.0, 1.0));
        }
      }
    });

    final exitCode = await _currentProcess!.exitCode;

    if (_isCancelled) {
      throw Exception('Compression cancelled by user');
    }

    if (exitCode != 0) {
      throw Exception('Compression failed: ${stderrLines.join('
')}');
    }

    final compressedSize = await File(outputPath).length();
    final compressionRatio = originalSize > 0
        ? ((originalSize - compressedSize) / originalSize * 100)
        : 0.0;

    return VideoCompressionResult(
      path: outputPath,
      originalSize: originalSize,
      compressedSize: compressedSize,
      compressionRatio: compressionRatio,
      duration: info.duration,
    );
  }

  void cancelCompression() {
    _isCancelled = true;
    _currentProcess?.kill();
    _currentProcess = null;
  }
}
