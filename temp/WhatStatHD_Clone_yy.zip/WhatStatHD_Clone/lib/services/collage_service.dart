import 'dart:async';
import 'dart:convert';
import 'dart:io';

enum CollageLayout {
  grid2x2,
  grid1x2,
  grid2x1,
  pictureInPicture,
  vertical1x3,
  horizontal3x1,
  grid2x2WithAudio,
}

class CollageResult {
  final String path;
  final int size;
  final double duration;
  final CollageLayout layout;

  CollageResult({
    required this.path,
    required this.size,
    required this.duration,
    required this.layout,
  });
}

class CollageService {
  bool _isCancelled = false;
  Process? _currentProcess;

  Future<CollageResult> createCollage(
    List<String> inputPaths,
    String outputPath, {
    CollageLayout layout = CollageLayout.grid2x2,
    int targetHeight = 1080,
    int bitrateKbps = 16000,
    Function(double progress)? onProgress,
  }) async {
    _isCancelled = false;

    if (inputPaths.isEmpty || inputPaths.length > 4) {
      throw Exception('Need 1-4 input files');
    }

    String filterComplex;
    final maps = <String>[];

    switch (layout) {
      case CollageLayout.grid2x2:
        filterComplex = _buildGrid2x2(inputPaths);
        break;
      case CollageLayout.grid1x2:
        filterComplex = _buildGrid1x2(inputPaths);
        break;
      case CollageLayout.grid2x1:
        filterComplex = _buildGrid2x1(inputPaths);
        break;
      case CollageLayout.pictureInPicture:
        filterComplex = _buildPip(inputPaths);
        break;
      case CollageLayout.vertical1x3:
        filterComplex = _buildVertical1x3(inputPaths);
        break;
      case CollageLayout.horizontal3x1:
        filterComplex = _buildHorizontal3x1(inputPaths);
        break;
      case CollageLayout.grid2x2WithAudio:
        filterComplex = _buildGrid2x2WithAudio(inputPaths);
        break;
    }

    // Build arguments
    final args = <String>[];

    // Input files
    for (final path in inputPaths) {
      args.addAll(['-i', path]);
    }

    // Filter complex
    args.addAll(['-filter_complex', filterComplex]);

    // Map arguments
    if (layout == CollageLayout.grid2x2WithAudio) {
      args.addAll(['-map', '[v]', '-map', '0:a?', '-c:a', 'aac', '-b:a', '128k']);
    } else {
      args.addAll(['-map', '[v]', '-an']);
    }

    // Video encoding
    args.addAll([
      '-c:v',
      'libx264',
      '-preset',
      'medium',
      '-profile:v',
      'main',
      '-level:v',
      '4.0',
      '-pix_fmt',
      'yuv420p',
      '-b:v',
      '${bitrateKbps}k',
      '-maxrate',
      '${bitrateKbps}k',
      '-bufsize',
      '${bitrateKbps * 2}k',
      '-movflags',
      '+faststart',
      '-y',
      outputPath,
    ]);

    // Execute FFmpeg
    _currentProcess = await Process.start('ffmpeg', args);
    final stderrLines = <String>[];

    _currentProcess!.stderr
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) {
      stderrLines.add(line);
    });

    final exitCode = await _currentProcess!.exitCode;

    if (_isCancelled) throw Exception('Collage creation cancelled');
    if (exitCode != 0) {
      throw Exception('Collage creation failed: ${stderrLines.join('
')}');
    }

    final file = File(outputPath);
    final size = await file.length();

    return CollageResult(
      path: outputPath,
      size: size,
      duration: 0,
      layout: layout,
    );
  }

  String _buildGrid2x2(List<String> inputs) {
    final w = inputs.length >= 4 ? 960 : 1280;
    final h = 540;
    return inputs.asMap().entries.map((e) {
      final i = e.key;
      return '[${i}:v]scale=$w:$h:force_original_aspect_ratio=decrease,pad=$w:$h:(ow-iw)/2:(oh-ih)/2:color=black[v$i]';
    }).join(';') +
        ';${inputs.asMap().entries.take(4).map((e) => '[v${e.key}]').join('')}' +
        'xstack=inputs=${inputs.length < 4 ? inputs.length : 4}:layout=0_0|w0_0|0_h0|w0_h0[v]';
  }

  String _buildGrid1x2(List<String> inputs) {
    return '[0:v]scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2:color=black[v0];'
        '[1:v]scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2:color=black[v1];'
        '[v0][v1]vstack=inputs=2[v]';
  }

  String _buildGrid2x1(List<String> inputs) {
    return '[0:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=black[v0];'
        '[1:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=black[v1];'
        '[v0][v1]hstack=inputs=2[v]';
  }

  String _buildPip(List<String> inputs) {
    return '[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black[bg];'
        '[1:v]scale=480:270[overlay];'
        '[bg][overlay]overlay=W-w-20:H-h-20[v]';
  }

  String _buildVertical1x3(List<String> inputs) {
    String filter = '';
    for (int i = 0; i < inputs.length && i < 3; i++) {
      filter +=
          '[$i:v]scale=720:480:force_original_aspect_ratio=decrease,pad=720:480:(ow-iw)/2:(oh-ih)/2:color=black[v$i];';
    }
    final streams =
        List.generate(inputs.length < 3 ? inputs.length : 3, (i) => '[v$i]').join('');
    filter +=
        '${streams}vstack=inputs=${inputs.length < 3 ? inputs.length : 3}[v]';
    return filter;
  }

  String _buildHorizontal3x1(List<String> inputs) {
    String filter = '';
    for (int i = 0; i < inputs.length && i < 3; i++) {
      filter +=
          '[$i:v]scale=640:720:force_original_aspect_ratio=decrease,pad=640:720:(ow-iw)/2:(oh-ih)/2:color=black[v$i];';
    }
    final streams =
        List.generate(inputs.length < 3 ? inputs.length : 3, (i) => '[v$i]').join('');
    filter +=
        '${streams}hstack=inputs=${inputs.length < 3 ? inputs.length : 3}[v]';
    return filter;
  }

  String _buildGrid2x2WithAudio(List<String> inputs) {
    return _buildGrid2x2(inputs);
  }

  void cancel() {
    _isCancelled = true;
    _currentProcess?.kill();
    _currentProcess = null;
  }
}
