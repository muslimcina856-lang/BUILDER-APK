/// Monetization service — always returns premium status.
/// No actual billing or subscription checks are performed.
class MonetizationService {
  bool _initialized = false;

  Future<void> init() async {
    _initialized = true;
  }

  /// Always returns true — all features unlocked.
  bool isPremium() => true;

  /// Always returns true — subscription is always active.
  bool isSubscriptionActive() => true;

  /// Returns 'lifetime' — the forever plan.
  String getCurrentPlan() => 'lifetime';

  /// Returns a future DateTime far in the future.
  DateTime getExpiryDate() => DateTime(2099, 12, 31);

  /// No-op — no purchase flow needed.
  Future<bool> purchasePremium() async => true;

  /// No-op — no subscription to restore.
  Future<bool> restorePurchases() async => true;

  bool get isInitialized => _initialized;
}
