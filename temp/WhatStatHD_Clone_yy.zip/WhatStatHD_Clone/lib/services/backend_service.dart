/// Backend service stub — returns premium responses.
/// No actual network requests are made.
class BackendService {
  bool _initialized = false;

  Future<void> init() async {
    _initialized = true;
  }

  /// Checks app version — always says latest.
  Future<Map<String, dynamic>> checkAppVersion() async {
    return {
      'latest': true,
      'version': '2026.07.01',
      'forceUpdate': false,
      'updateUrl': '',
    };
  }

  /// Syncs data — always succeeds.
  Future<bool> syncData() async => true;

  /// Reports analytics — always succeeds.
  Future<bool> reportAnalytics() async => true;

  /// Returns empty remote config.
  Future<Map<String, dynamic>> getRemoteConfig() async => {};

  /// Checks license — always valid.
  Future<Map<String, dynamic>> checkLicense() async {
    return {
      'valid': true,
      'type': 'premium_lifetime',
      'device_limit': 999,
    };
  }

  bool get isInitialized => _initialized;
}
