import 'dart:io';
import 'package:share_plus/share_plus.dart';

class SocialShareService {
  Future<bool> shareToWhatsAppStatus(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Share to WhatsApp',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToInstagramStory(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Share to Instagram',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToFacebookStory(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Share to Facebook',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToSnapchat(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Share to Snapchat',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToOtherApps(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Shared from WhatStatHD',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareMultipleToWhatsApp(List<String> filePaths) async {
    try {
      for (final path in filePaths) {
        await shareToWhatsAppStatus(path);
      }
      return true;
    } catch (e) {
      return false;
    }
  }
}
