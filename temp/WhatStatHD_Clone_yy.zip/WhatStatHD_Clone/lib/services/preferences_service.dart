import 'package:shared_preferences/shared_preferences.dart';

class PreferencesService {
  static const _keyOnboardingComplete = 'onboarding_complete';
  static const _keyDefaultQuality = 'default_quality';
  static const _keyDefaultBitrate = 'default_bitrate';
  static const _keyWatermarkEnabled = 'watermark_enabled';
  static const _keyCompressionCount = 'compression_count';
  static const _keyDeviceId = 'device_id';
  static const _keyRatingShown = 'rating_shown';
  static const _keyRecentCompressions = 'recent_compressions';
  static const _keyThemeMode = 'theme_mode';

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  bool get isOnboardingComplete =>
      _prefs?.getBool(_keyOnboardingComplete) ?? false;
  Future<void> setOnboardingComplete(bool value) async =>
      await _prefs?.setBool(_keyOnboardingComplete, value);

  String get defaultQuality =>
      _prefs?.getString(_keyDefaultQuality) ?? '1080p';
  Future<void> setDefaultQuality(String value) async =>
      await _prefs?.setString(_keyDefaultQuality, value);

  int get defaultBitrateKbps =>
      _prefs?.getInt(_keyDefaultBitrate) ?? 16000;
  Future<void> setDefaultBitrateKbps(int value) async =>
      await _prefs?.setInt(_keyDefaultBitrate, value);

  bool get watermarkEnabled =>
      _prefs?.getBool(_keyWatermarkEnabled) ?? false;
  Future<void> setWatermarkEnabled(bool value) async =>
      await _prefs?.setBool(_keyWatermarkEnabled, value);

  int get compressionCount =>
      _prefs?.getInt(_keyCompressionCount) ?? 0;
  Future<void> setCompressionCount(int value) async =>
      await _prefs?.setInt(_keyCompressionCount, value);

  String get deviceId => _prefs?.getString(_keyDeviceId) ?? '';
  Future<void> setDeviceId(String value) async =>
      await _prefs?.setString(_keyDeviceId, value);

  bool get ratingShown => _prefs?.getBool(_keyRatingShown) ?? false;
  Future<void> setRatingShown(bool value) async =>
      await _prefs?.setBool(_keyRatingShown, value);

  List<String> get recentCompressions =>
      _prefs?.getStringList(_keyRecentCompressions) ?? [];
  Future<void> setRecentCompressions(List<String> value) async =>
      await _prefs?.setStringList(_keyRecentCompressions, value);

  String get themeMode => _prefs?.getString(_keyThemeMode) ?? 'dark';
  Future<void> setThemeMode(String value) async =>
      await _prefs?.setString(_keyThemeMode, value);

  Future<void> addRecentCompression(Map<String, String> entry) async {
    final list = recentCompressions;
    list.insert(0, '${entry['type']}|${entry['path']}|${entry['size']}');
    if (list.length > 20) list.removeRange(20, list.length);
    await setRecentCompressions(list);
  }

  Future<void> clearCache() async {
    final keys = _prefs?.getKeys() ?? {};
    for (final key in keys) {
      if (key != _keyDeviceId) {
        await _prefs?.remove(key);
      }
    }
  }
}
