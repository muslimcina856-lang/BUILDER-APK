import 'preferences_service.dart';

class CompressionTrackerService {
  final PreferencesService _prefs;

  CompressionTrackerService(this._prefs);

  int get compressionCount => _prefs.compressionCount;

  /// Always returns true — premium users have no limits.
  bool canCompress() => true;

  /// Returns "Unlimited" for premium users.
  String getRemainingCompressions() => 'Unlimited';

  /// Returns true — always premium.
  bool isPremium() => true;

  /// Increments compression count tracker.
  Future<void> incrementCompression() async {
    final count = _prefs.compressionCount + 1;
    await _prefs.setCompressionCount(count);
  }
}
