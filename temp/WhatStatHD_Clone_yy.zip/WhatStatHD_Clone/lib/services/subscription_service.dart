/// Subscription service — always returns premium active.
/// No Google Play Billing or any purchase dependency.
class SubscriptionService {
  bool _initialized = false;

  Future<void> init() async {
    _initialized = true;
  }

  /// Always returns true — user is subscribed.
  bool isSubscribed() => true;

  /// Always returns true — subscription is active.
  bool isActive() => true;

  /// Returns a date far in the future.
  DateTime getExpiryDate() => DateTime(2099, 12, 31);

  /// Returns 'Lifetime Premium' plan name.
  String getPlanName() => 'Lifetime Premium';

  /// Returns 'lifetime' plan ID.
  String getPlanId() => 'premium_lifetime';

  /// No-op — no subscription to cancel.
  Future<void> cancelSubscription() async {}

  /// No-op — nothing to refresh.
  Future<void> refreshStatus() async {}

  bool get isInitialized => _initialized;
}
