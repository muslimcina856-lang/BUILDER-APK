class SubscriptionStatus {
  final bool isPremium;
  final String plan;
  final bool isLifetime;

  const SubscriptionStatus({
    this.isPremium = true,
    this.plan = 'lifetime',
    this.isLifetime = true,
  });

  factory SubscriptionStatus.free() => const SubscriptionStatus();
  factory SubscriptionStatus.premium() => const SubscriptionStatus(
        isPremium: true,
        plan: 'lifetime',
        isLifetime: true,
      );

  static const premium = SubscriptionStatus(
    isPremium: true,
    plan: 'lifetime',
    isLifetime: true,
  );
}
