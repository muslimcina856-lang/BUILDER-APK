class EnvConfig {
  static const appName = 'WhatStatHD';
  static const version = '2026.07.01';
  static const versionCode = 1;
  static const maxCompressionWidth = 1920;
  static const maxCompressionHeight = 1080;
  static const defaultBitrateKbps = 16000;
  static const supportEmail = 'support@whatstathd.com';
}
