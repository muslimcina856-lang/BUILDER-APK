import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'config/env_config.dart';
import 'services/preferences_service.dart';
import 'services/compression_tracker_service.dart';
import 'services/file_service.dart';
import 'services/ad_service.dart';
import 'services/monetization_service.dart';
import 'services/backend_service.dart';
import 'services/subscription_service.dart';
import 'services/update_check_service.dart';
import 'services/rating_service.dart';
import 'screens/splash_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/home_screen.dart';
import 'screens/video_editor_screen.dart';
import 'screens/image_editor_screen.dart';
import 'screens/collage_editor_screen.dart';
import 'screens/result_screen.dart';
import 'screens/subscription_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/faq_screen.dart';
import 'screens/contact_screen.dart';
import 'screens/legal_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  final prefsService = PreferencesService();
  await prefsService.init();

  final fileService = FileService();
  await fileService.init();

  runApp(
    MultiProvider(
      providers: [
        Provider<AdService>.value(value: AdService()..init()),
        Provider<MonetizationService>.value(value: MonetizationService()..init()),
        Provider<BackendService>.value(value: BackendService()..init()),
        Provider<SubscriptionService>.value(value: SubscriptionService()..init()),
        Provider<UpdateCheckService>.value(value: UpdateCheckService()),
        ChangeNotifierProvider<PreferencesService>.value(value: prefsService),
        Provider<FileService>.value(value: fileService),
        Provider<CompressionTrackerService>(
          create: (_) => CompressionTrackerService(prefsService),
        ),
        Provider<RatingService>(
          create: (_) => RatingService(prefsService),
        ),
      ],
      child: const WhatStatHDApp(),
    ),
  );
}

class WhatStatHDApp extends StatelessWidget {
  const WhatStatHDApp({super.key});

  @override
  Widget build(BuildContext context) {
    final prefs = context.watch<PreferencesService>();
    final isDark = prefs.themeMode == 'dark';

    return MaterialApp(
      title: EnvConfig.appName,
      debugShowCheckedModeBanner: false,
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF075E54),
        scaffoldBackgroundColor: const Color(0xFF121B22),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF075E54),
          secondary: Color(0xFF128C7E),
          surface: Color(0xFF1F2C34),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1F2C34),
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF1F2C34),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF1F2C34),
          selectedItemColor: Color(0xFF128C7E),
          unselectedItemColor: Colors.white38,
        ),
        dividerTheme: const DividerThemeData(
          color: Colors.white12,
          thickness: 0.5,
        ),
        snackBarTheme: const SnackBarThemeData(
          backgroundColor: Color(0xFF1F2C34),
          contentTextStyle: TextStyle(color: Colors.white),
          behavior: SnackBarBehavior.floating,
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: const Color(0xFF1F2C34),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF2A3942),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF128C7E)),
          ),
          labelStyle: const TextStyle(color: Colors.white54),
          hintStyle: const TextStyle(color: Colors.white38),
        ),
      ),
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF075E54),
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF075E54),
          secondary: Color(0xFF128C7E),
        ),
      ),
      initialRoute: '/splash',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/splash':
            return MaterialPageRoute(
              builder: (_) => SplashScreen(
                prefsService: context.read<PreferencesService>(),
              ),
            );
          case '/onboarding':
            return MaterialPageRoute(
              builder: (_) => OnboardingScreen(
                prefsService: context.read<PreferencesService>(),
              ),
            );
          case '/home':
            return MaterialPageRoute(
              builder: (_) => const HomeScreen(),
            );
          case '/video-editor':
            return MaterialPageRoute(
              builder: (_) => const VideoEditorScreen(),
            );
          case '/image-editor':
            return MaterialPageRoute(
              builder: (_) => const ImageEditorScreen(),
            );
          case '/collage-editor':
            return MaterialPageRoute(
              builder: (_) => const CollageEditorScreen(),
            );
          case '/result':
            return MaterialPageRoute(
              builder: (_) => const ResultScreen(),
              settings: settings,
            );
          case '/subscription':
            return MaterialPageRoute(
              builder: (_) => const SubscriptionScreen(),
            );
          case '/settings':
            return MaterialPageRoute(
              builder: (_) => const SettingsScreen(),
            );
          case '/faq':
            return MaterialPageRoute(
              builder: (_) => const FaqScreen(),
            );
          case '/contact':
            return MaterialPageRoute(
              builder: (_) => const ContactScreen(),
            );
          case '/legal':
            return MaterialPageRoute(
              builder: (_) => const LegalScreen(),
            );
          default:
            return MaterialPageRoute(
              builder: (_) => const HomeScreen(),
            );
        }
      },
    );
  }
}
