import 'package:flutter/material.dart';
import '../widgets/feature_row_widget.dart';
import '../widgets/premium_badge_widget.dart';

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});

  final List<_Feature> _features = const [
    _Feature(Icons.videocam, 'Unlimited Video Compression',
        'Compress unlimited videos at maximum quality'),
    _Feature(Icons.photo_library, 'Batch Image Compression',
        'Compress up to 10 images at once'),
    _Feature(Icons.dashboard_customize, 'Collage Creator',
        'Create video collages with multiple layouts'),
    _Feature(Icons.music_note, 'Audio Extraction',
        'Extract and mix audio from videos'),
    _Feature(Icons.water_drop, 'No Watermark',
        'Remove watermarks from your content'),
    _Feature(Icons.high_quality, 'High Quality (1080p)',
        'Export at full 1080p resolution'),
    _Feature(Icons.support, 'Priority Support',
        'Get priority assistance when you need it'),
    _Feature(Icons.block, 'No Ads',
        'Enjoy an ad-free experience'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('WhatStatHD Premium'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Premium card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF075E54), Color(0xFF128C7E)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF128C7E).withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Icon(Icons.star, color: Color(0xFFFFD700), size: 64),
                  const SizedBox(height: 16),
                  const PremiumBadgeWidget(
                    showActive: true,
                    fontSize: 18,
                    iconSize: 22,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Premium - Lifetime',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'All features unlocked forever',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle,
                            color: Colors.white, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'ACTIVE',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Features
            const Text(
              'All Features Included',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),

            ...List.generate(_features.length, (index) {
              final feature = _features[index];
              return Column(
                children: [
                  FeatureRowWidget(
                    icon: feature.icon,
                    title: feature.title,
                    subtitle: feature.subtitle,
                    isPremium: true,
                  ),
                  if (index < _features.length - 1)
                    const Divider(color: Colors.white12, height: 1),
                ],
              );
            }),

            const SizedBox(height: 32),

            // Status info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1F2C34),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.info, color: Color(0xFF128C7E), size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Subscription Status',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  _StatusRow('Plan', 'Lifetime Premium'),
                  SizedBox(height: 8),
                  _StatusRow('Status', 'Active'),
                  SizedBox(height: 8),
                  _StatusRow('Expires', 'Never'),
                  SizedBox(height: 8),
                  _StatusRow('Devices', 'Unlimited'),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _Feature {
  final IconData icon;
  final String title;
  final String subtitle;

  const _Feature(this.icon, this.title, this.subtitle);
}

class _StatusRow extends StatelessWidget {
  final String label;
  final String value;

  const _StatusRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 14)),
        Text(
          value,
          style: const TextStyle(
            color: Color(0xFF128C7E),
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}
