import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../services/collage_service.dart';
import '../services/file_service.dart';
import '../services/compression_tracker_service.dart';

class CollageEditorScreen extends StatefulWidget {
  const CollageEditorScreen({super.key});

  @override
  State<CollageEditorScreen> createState() => _CollageEditorScreenState();
}

class _CollageEditorScreenState extends State<CollageEditorScreen> {
  final CollageService _collageService = CollageService();
  final ImagePicker _picker = ImagePicker();

  List<String> _selectedClips = [];
  CollageLayout _selectedLayout = CollageLayout.grid2x2;
  String _selectedQuality = '1080p';
  bool _isProcessing = false;
  double _progress = 0;

  final List<_LayoutOption> _layouts = [
    _LayoutOption(CollageLayout.grid2x2, Icons.grid_view, '2x2 Grid', 2, 4),
    _LayoutOption(CollageLayout.grid1x2, Icons.view_column, '1x2 Vertical', 2, 2),
    _LayoutOption(CollageLayout.grid2x1, Icons.view_stream, '2x1 Horizontal', 2, 2),
    _LayoutOption(CollageLayout.pictureInPicture, Icons.picture_in_picture, 'PiP', 2, 2),
    _LayoutOption(CollageLayout.vertical1x3, Icons.view_column, '1x3 Vertical', 3, 3),
    _LayoutOption(CollageLayout.horizontal3x1, Icons.view_stream, '3x1 Horizontal', 3, 3),
  ];

  Future<void> _pickClips() async {
    try {
      final xfiles = await _picker.pickMultiImage();
      if (xfiles.isEmpty) return;

      setState(() {
        _selectedClips = xfiles.map((x) => x.path).toList();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error selecting clips: $e')),
        );
      }
    }
  }

  Future<void> _createCollage() async {
    if (_selectedClips.isEmpty) return;

    setState(() {
      _isProcessing = true;
      _progress = 0;
    });

    try {
      final fileService = context.read<FileService>();
      final outputPath = fileService.generateOutputPath('mp4');

      final result = await _collageService.createCollage(
        _selectedClips,
        outputPath,
        layout: _selectedLayout,
        targetHeight: _selectedQuality == '1080p' ? 1080 : 720,
        bitrateKbps: _selectedQuality == '1080p' ? 16000 : 8000,
        onProgress: (p) {
          if (mounted) setState(() => _progress = p);
        },
      );

      await context.read<CompressionTrackerService>().incrementCompression();

      if (!mounted) return;

      Navigator.pushNamed(context, '/result', arguments: {
        'path': result.path,
        'type': 'video',
        'originalSize': 0,
        'compressedSize': result.size,
        'compressionRatio': 0,
        'duration': result.duration,
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Collage creation failed: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('Create Collage'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
      ),
      body: _isProcessing ? _buildProgressView() : _buildEditorView(),
    );
  }

  Widget _buildEditorView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Clip selection
          _buildClipSelector(),
          const SizedBox(height: 24),

          // Layout selection
          const Text(
            'Layout',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1,
            ),
            itemCount: _layouts.length,
            itemBuilder: (context, index) {
              final layout = _layouts[index];
              final isSelected = _selectedLayout == layout.layout;
              final canUse = _selectedClips.length >= layout.minClips &&
                  _selectedClips.length <= layout.maxClips;

              return GestureDetector(
                onTap: canUse
                    ? () => setState(() => _selectedLayout = layout.layout)
                    : null,
                child: Container(
                  decoration: BoxDecoration(
                    color: isSelected
                        ? const Color(0xFF075E54)
                        : const Color(0xFF1F2C34),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected
                          ? const Color(0xFF128C7E)
                          : Colors.white12,
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        layout.icon,
                        color: isSelected
                            ? Colors.white
                            : canUse
                                ? Colors.white54
                                : Colors.white24,
                        size: 28,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        layout.label,
                        style: TextStyle(
                          color: isSelected
                              ? Colors.white
                              : canUse
                                  ? Colors.white54
                                  : Colors.white24,
                          fontSize: 11,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),

          // Quality selector
          const Text(
            'Quality',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _QualityChip(
                  label: '1080p',
                  isSelected: _selectedQuality == '1080p',
                  onTap: () => setState(() => _selectedQuality = '1080p'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _QualityChip(
                  label: '720p',
                  isSelected: _selectedQuality == '720p',
                  onTap: () => setState(() => _selectedQuality = '720p'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),

          // Create button
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: _selectedClips.length >= 2 ? _createCollage : null,
              icon: const Icon(Icons.dashboard_customize),
              label: Text(
                _selectedClips.length < 2
                    ? 'Select at least 2 clips'
                    : 'Create Collage',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF075E54),
                foregroundColor: Colors.white,
                disabledBackgroundColor: Colors.white12,
                disabledForegroundColor: Colors.white24,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(26),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClipSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Video Clips',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const Spacer(),
            Text(
              '${_selectedClips.length}/4',
              style: const TextStyle(color: Colors.white54),
            ),
            const SizedBox(width: 8),
            if (_selectedClips.length < 4)
              TextButton(
                onPressed: _pickClips,
                child: const Text('Add', style: TextStyle(color: Color(0xFF128C7E))),
              ),
          ],
        ),
        const SizedBox(height: 8),
        if (_selectedClips.isEmpty)
          GestureDetector(
            onTap: _pickClips,
            child: Container(
              width: double.infinity,
              height: 120,
              decoration: BoxDecoration(
                color: const Color(0xFF1F2C34),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF128C7E).withOpacity(0.3)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.video_library, size: 40, color: const Color(0xFF128C7E).withOpacity(0.5)),
                  const SizedBox(height: 8),
                  const Text('Tap to select videos', style: TextStyle(color: Colors.white54)),
                ],
              ),
            ),
          )
        else
          SizedBox(
            height: 100,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _selectedClips.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                return Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(_selectedClips[index]),
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 100,
                          height: 100,
                          color: const Color(0xFF2A3942),
                          child: const Icon(Icons.videocam, color: Colors.white38),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 4,
                      right: 4,
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedClips.removeAt(index)),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, color: Colors.white, size: 14),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 4,
                      left: 4,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Clip ${index + 1}',
                          style: const TextStyle(color: Colors.white, fontSize: 10),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
      ],
    );
  }

  Widget _buildProgressView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 80,
              height: 80,
              child: CircularProgressIndicator(
                strokeWidth: 6,
                color: Color(0xFF128C7E),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Creating collage...',
              style: TextStyle(fontSize: 18, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

class _LayoutOption {
  final CollageLayout layout;
  final IconData icon;
  final String label;
  final int minClips;
  final int maxClips;

  _LayoutOption(this.layout, this.icon, this.label, this.minClips, this.maxClips);
}

class _QualityChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _QualityChip({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF075E54) : const Color(0xFF1F2C34),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? const Color(0xFF128C7E) : Colors.white12,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white70,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}

