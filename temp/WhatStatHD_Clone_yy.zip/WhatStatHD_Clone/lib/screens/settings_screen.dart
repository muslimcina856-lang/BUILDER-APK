import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/env_config.dart';
import '../services/preferences_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final prefs = context.watch<PreferencesService>();

    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Theme
          _SectionHeader(title: 'Appearance'),
          const SizedBox(height: 8),
          _SettingsCard(
            children: [
              _buildSettingRow(
                icon: Icons.dark_mode,
                title: 'Dark Mode',
                subtitle: 'WhatsApp dark theme',
                trailing: Switch(
                  value: prefs.themeMode == 'dark',
                  onChanged: (v) {
                    prefs.setThemeMode(v ? 'dark' : 'light');
                    setState(() {});
                  },
                  activeColor: const Color(0xFF128C7E),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Defaults
          _SectionHeader(title: 'Defaults'),
          const SizedBox(height: 8),
          _SettingsCard(
            children: [
              _buildSettingRow(
                icon: Icons.high_quality,
                title: 'Default Quality',
                subtitle: prefs.defaultQuality,
                onTap: () => _showQualityPicker(context, prefs),
              ),
              const Divider(color: Colors.white12, height: 1),
              _buildSettingRow(
                icon: Icons.speed,
                title: 'Default Bitrate',
                subtitle: '${prefs.defaultBitrateKbps ~/ 1000} Mbps',
                onTap: () => _showBitratePicker(context, prefs),
              ),
              const Divider(color: Colors.white12, height: 1),
              _buildSettingRow(
                icon: Icons.water_drop,
                title: 'Watermark By Default',
                subtitle: prefs.watermarkEnabled ? 'Enabled' : 'Disabled',
                trailing: Switch(
                  value: prefs.watermarkEnabled,
                  onChanged: (v) {
                    prefs.setWatermarkEnabled(v);
                    setState(() {});
                  },
                  activeColor: const Color(0xFF128C7E),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // About
          _SectionHeader(title: 'About'),
          const SizedBox(height: 8),
          _SettingsCard(
            children: [
              _buildSettingRow(
                icon: Icons.info,
                title: 'Version',
                subtitle: EnvConfig.version,
              ),
              const Divider(color: Colors.white12, height: 1),
              _buildSettingRow(
                icon: Icons.star,
                title: 'Plan',
                subtitle: 'Premium Lifetime',
                iconColor: const Color(0xFFFFD700),
              ),
              const Divider(color: Colors.white12, height: 1),
              _buildSettingRow(
                icon: Icons.code,
                title: 'Developer',
                subtitle: 'WhatStatHD Team',
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Cache
          _SettingsCard(
            children: [
              _buildSettingRow(
                icon: Icons.cleaning_services,
                title: 'Clear Cache',
                subtitle: 'Clear temporary files',
                iconColor: Colors.orangeAccent,
                onTap: () => _clearCache(context, prefs),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Footer
          const Center(
            child: Text(
              '${EnvConfig.appName} v${EnvConfig.version}',
              style: TextStyle(color: Colors.white24, fontSize: 13),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSettingRow({
    required IconData icon,
    required String title,
    required String subtitle,
    Color? iconColor,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
        child: Row(
          children: [
            Icon(
              icon,
              color: iconColor ?? const Color(0xFF128C7E),
              size: 22,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white54, fontSize: 13),
                  ),
                ],
              ),
            ),
            if (trailing != null) trailing,
            if (onTap != null && trailing == null)
              const Icon(
                Icons.chevron_right,
                color: Colors.white38,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _showQualityPicker(
      BuildContext context, PreferencesService prefs) async {
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => _SimpleDialog(
        title: 'Default Quality',
        items: ['1080p', '720p', '480p', '360p'],
        selected: prefs.defaultQuality,
      ),
    );
    if (result != null) {
      await prefs.setDefaultQuality(result);
      setState(() {});
    }
  }

  Future<void> _showBitratePicker(
      BuildContext context, PreferencesService prefs) async {
    final options = [4000, 8000, 12000, 16000, 20000, 30000, 50000];
    final labels = options.map((b) => '${b ~/ 1000} Mbps').toList();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => _SimpleDialog(
        title: 'Default Bitrate',
        items: labels,
        selected: '${prefs.defaultBitrateKbps ~/ 1000} Mbps',
      ),
    );
    if (result != null) {
      final value = int.parse(result.replaceAll(' Mbps', '')) * 1000;
      await prefs.setDefaultBitrateKbps(value);
      setState(() {});
    }
  }

  Future<void> _clearCache(
      BuildContext context, PreferencesService prefs) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F2C34),
        title: const Text('Clear Cache?',
            style: TextStyle(color: Colors.white)),
        content: const Text(
          'This will clear all cached data. Your preferences will be reset.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Clear', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await prefs.clearCache();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Cache cleared'),
            behavior: SnackBarBehavior.floating,
          ),
        );
        setState(() {});
      }
    }
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;

  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: Colors.white54,
        letterSpacing: 0.5,
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;

  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(children: children),
    );
  }
}

class _SimpleDialog extends StatelessWidget {
  final String title;
  final List<String> items;
  final String selected;

  const _SimpleDialog({
    required this.title,
    required this.items,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1F2C34),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ...items.map((item) {
            final isSelected = item == selected;
            return ListTile(
              title: Text(
                item,
                style: TextStyle(
                  color: isSelected ? const Color(0xFF128C7E) : Colors.white70,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              trailing: isSelected
                  ? const Icon(Icons.check, color: Color(0xFF128C7E))
                  : null,
              onTap: () => Navigator.of(context).pop(item),
            );
          }),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
