import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preferences_service.dart';
import '../widgets/premium_badge_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final prefs = context.watch<PreferencesService>();
    final recentCompressions = prefs.recentCompressions;

    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text(
          'WhatStatHD',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
        actions: [
          const Padding(
            padding: EdgeInsets.only(right: 8),
            child: PremiumBadgeWidget(),
          ),
        ],
      ),
      drawer: _buildDrawer(context),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Quick Actions
            const Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.videocam,
                    label: 'Compress
Video',
                    color: const Color(0xFF128C7E),
                    onTap: () => Navigator.pushNamed(context, '/video-editor'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.photo_library,
                    label: 'Compress
Image',
                    color: const Color(0xFF25D366),
                    onTap: () => Navigator.pushNamed(context, '/image-editor'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.dashboard_customize,
                    label: 'Make
Collage',
                    color: const Color(0xFF075E54),
                    onTap: () =>
                        Navigator.pushNamed(context, '/collage-editor'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            // Stats row
            Row(
              children: [
                _StatCard(
                  icon: Icons.compress,
                  label: 'Compressions',
                  value: '${prefs.compressionCount}',
                  color: const Color(0xFF128C7E),
                ),
                const SizedBox(width: 12),
                _StatCard(
                  icon: Icons.star,
                  label: 'Plan',
                  value: 'Premium',
                  color: const Color(0xFFFFD700),
                ),
                const SizedBox(width: 12),
                _StatCard(
                  icon: Icons.infinity,
                  label: 'Remaining',
                  value: 'Unlimited',
                  color: const Color(0xFF25D366),
                ),
              ],
            ),
            const SizedBox(height: 32),
            // Recent compressions
            const Text(
              'Recent',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 12),
            if (recentCompressions.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2C34),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Column(
                  children: [
                    Icon(Icons.inbox, size: 48, color: Colors.white24),
                    SizedBox(height: 12),
                    Text(
                      'No compressions yet',
                      style: TextStyle(color: Colors.white38, fontSize: 16),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Compress your first video or image',
                      style: TextStyle(color: Colors.white24, fontSize: 13),
                    ),
                  ],
                ),
              )
            else
              ...recentCompressions.take(5).map((entry) {
                final parts = entry.split('|');
                final type = parts.length > 0 ? parts[0] : 'Unknown';
                final path = parts.length > 1 ? parts[1] : '';
                final size = parts.length > 2 ? parts[2] : '';
                return _RecentItem(type: type, path: path, size: size);
              }),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, '/video-editor'),
        backgroundColor: const Color(0xFF128C7E),
        icon: const Icon(Icons.compress),
        label: const Text('Compress'),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF1F2C34),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF075E54), Color(0xFF121B22)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF128C7E),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.compress, color: Colors.white, size: 32),
                ),
                const SizedBox(height: 12),
                const Text(
                  'WhatStatHD',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const PremiumBadgeWidget(fontSize: 10, iconSize: 12),
              ],
            ),
          ),
          _drawerItem(Icons.home, 'Home', () => Navigator.pop(context)),
          _drawerItem(Icons.settings, 'Settings', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/settings');
          }),
          _drawerItem(Icons.subscriptions, 'Subscription', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/subscription');
          }),
          _drawerItem(Icons.support, 'Support', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/faq');
          }),
          _drawerItem(Icons.help, 'FAQ', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/faq');
          }),
          _drawerItem(Icons.mail, 'Contact', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/contact');
          }),
          const Divider(color: Colors.white12),
          _drawerItem(Icons.description, 'Legal', () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/legal');
          }),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.white70),
      title: Text(title, style: const TextStyle(color: Colors.white)),
      onTap: onTap,
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;

  const _QuickActionCard({
    required this.icon,
    required this.label,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2C34),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2C34),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

class _RecentItem extends StatelessWidget {
  final String type;
  final String path;
  final String size;

  const _RecentItem({
    required this.type,
    required this.path,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    final isVideo = type.toLowerCase() == 'video';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: (isVideo
                      ? const Color(0xFF128C7E)
                      : const Color(0xFF25D366))
                  .withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              isVideo ? Icons.videocam : Icons.image,
              color: isVideo
                  ? const Color(0xFF128C7E)
                  : const Color(0xFF25D366),
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  type == 'video' ? 'Video compressed' : 'Image compressed',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
                if (size.isNotEmpty)
                  Text(
                    size,
                    style: const TextStyle(color: Colors.white38, fontSize: 12),
                  ),
              ],
            ),
          ),
          const Icon(Icons.check_circle, color: Color(0xFF128C7E), size: 20),
        ],
      ),
    );
  }
}
