import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:path/path.dart' as p;
import '../services/image_service.dart';
import '../services/file_service.dart';
import '../services/preferences_service.dart';
import '../services/compression_tracker_service.dart';

class ImageEditorScreen extends StatefulWidget {
  const ImageEditorScreen({super.key});

  @override
  State<ImageEditorScreen> createState() => _ImageEditorScreenState();
}

class _ImageEditorScreenState extends State<ImageEditorScreen> {
  final ImageService _imageService = ImageService();
  final ImagePicker _picker = ImagePicker();

  List<String> _selectedImages = [];
  int _quality = 80;
  String _resizeOption = 'Original';
  bool _isCompressing = false;
  double _progress = 0;
  int _completedCount = 0;

  final List<String> _resizeOptions = [
    'Original',
    '1920x1080',
    '1280x720',
    '800x600',
  ];

  Future<void> _pickImages() async {
    try {
      final xfiles = await _picker.pickMultiImage();
      if (xfiles.isEmpty) return;

      setState(() {
        _selectedImages = xfiles.map((x) => x.path).toList();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking images: $e')),
        );
      }
    }
  }

  Future<void> _compress() async {
    if (_selectedImages.isEmpty) return;

    setState(() {
      _isCompressing = true;
      _progress = 0;
      _completedCount = 0;
    });

    try {
      final fileService = context.read<FileService>();
      final outputDir = fileService.compressedImageDir.path;

      // Parse resize dimensions
      int maxWidth = 1920;
      int maxHeight = 1080;
      if (_resizeOption != 'Original') {
        final parts = _resizeOption.split('x');
        maxWidth = int.parse(parts[0]);
        maxHeight = int.parse(parts[1]);
      }

      final results = await _imageService.compressBatch(
        _selectedImages,
        outputDir,
        quality: _quality,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        onProgress: (p) {
          if (mounted) {
            setState(() {
              _progress = p;
              _completedCount = (p * _selectedImages.length).round();
            });
          }
        },
      );

      // Track compression
      await context.read<CompressionTrackerService>().incrementCompression();

      // Get the last result for navigation
      if (results.isNotEmpty) {
        final lastResult = results.last;
        await context.read<PreferencesService>().addRecentCompression({
          'type': 'image',
          'path': lastResult.path,
          'size': fileService.formatFileSize(lastResult.compressedSize),
        });

        if (!mounted) return;

        Navigator.pushNamed(context, '/result', arguments: {
          'path': lastResult.path,
          'type': 'image',
          'originalSize': lastResult.originalSize,
          'compressedSize': lastResult.compressedSize,
          'compressionRatio': lastResult.compressionRatio,
          'batchSize': results.length,
          'allResults': results
              .map((r) => {
                    'path': r.path,
                    'originalSize': r.originalSize,
                    'compressedSize': r.compressedSize,
                  })
              .toList(),
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Compression failed: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCompressing = false;
        });
      }
    }
  }

  void _cancel() {
    _imageService.cancel();
    setState(() {
      _isCompressing = false;
    });
  }

  void _removeImage(int index) {
    setState(() {
      _selectedImages.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('Compress Images'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
      ),
      body: _isCompressing ? _buildProgressView() : _buildEditorView(),
    );
  }

  Widget _buildEditorView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image selection
          if (_selectedImages.isEmpty)
            GestureDetector(
              onTap: _pickImages,
              child: Container(
                width: double.infinity,
                height: 200,
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2C34),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFF25D366).withOpacity(0.3),
                    width: 2,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.photo_library,
                        size: 64, color: const Color(0xFF25D366).withOpacity(0.5)),
                    const SizedBox(height: 16),
                    const Text(
                      'Select up to 10 images',
                      style: TextStyle(color: Colors.white54, fontSize: 18),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'from gallery',
                      style: TextStyle(color: Colors.white38, fontSize: 14),
                    ),
                  ],
                ),
              ),
            )
          else ...[
            // Selected images count
            Row(
              children: [
                const Text(
                  'Selected Images',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_selectedImages.length}/10',
                  style: const TextStyle(color: Colors.white54, fontSize: 14),
                ),
                const SizedBox(width: 8),
                TextButton(
                  onPressed: _pickImages,
                  child: const Text(
                    'Add more',
                    style: TextStyle(color: Color(0xFF25D366)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Image grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 1,
              ),
              itemCount: _selectedImages.length,
              itemBuilder: (context, index) {
                return Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(_selectedImages[index]),
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        errorBuilder: (_, __, ___) => Container(
                          color: const Color(0xFF2A3942),
                          child: const Icon(Icons.broken_image, color: Colors.white38),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 4,
                      right: 4,
                      child: GestureDetector(
                        onTap: () => _removeImage(index),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ],

          if (_selectedImages.isNotEmpty) ...[
            const SizedBox(height: 24),

            // Quality slider
            const Text(
              'Quality',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                const Text('Low', style: TextStyle(color: Colors.white38, fontSize: 12)),
                Expanded(
                  child: Slider(
                    value: _quality.toDouble(),
                    min: 1,
                    max: 100,
                    divisions: 99,
                    activeColor: const Color(0xFF25D366),
                    inactiveColor: Colors.white12,
                    onChanged: (v) => setState(() => _quality = v.toInt()),
                  ),
                ),
                const Text('High', style: TextStyle(color: Colors.white38, fontSize: 12)),
              ],
            ),
            Text(
              'Quality: $_quality%',
              style: const TextStyle(color: Color(0xFF25D366), fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            // Resize options
            const Text(
              'Resize',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _resizeOptions.map((option) {
                final isSelected = _resizeOption == option;
                return ChoiceChip(
                  label: Text(
                    option,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.white70,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  selected: isSelected,
                  selectedColor: const Color(0xFF075E54),
                  backgroundColor: const Color(0xFF2A3942),
                  onSelected: (selected) {
                    if (selected) setState(() => _resizeOption = option);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 32),

            // Compress button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _compress,
                icon: const Icon(Icons.compress),
                label: Text(
                  'Compress All (${_selectedImages.length} images)',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }

  Widget _buildProgressView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 120,
              height: 120,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: _progress,
                    strokeWidth: 8,
                    backgroundColor: Colors.white12,
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF25D366)),
                  ),
                  Text(
                    '${(_progress * 100).toInt()}%',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Compressing $_completedCount/${_selectedImages.length} images...',
              style: const TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: _progress,
              backgroundColor: Colors.white12,
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF25D366)),
            ),
            const SizedBox(height: 20),
            TextButton.icon(
              onPressed: _cancel,
              icon: const Icon(Icons.cancel_outlined, color: Colors.redAccent),
              label: const Text(
                'Cancel',
                style: TextStyle(color: Colors.redAccent),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
