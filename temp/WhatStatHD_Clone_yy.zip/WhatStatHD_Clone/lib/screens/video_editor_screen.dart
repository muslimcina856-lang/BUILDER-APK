import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:path/path.dart' as p;
import '../config/env_config.dart';
import '../services/video_service.dart';
import '../services/file_service.dart';
import '../services/preferences_service.dart';
import '../services/compression_tracker_service.dart';
import '../widgets/quality_selector_widget.dart';
import '../widgets/watermark_toggle_widget.dart';
import '../widgets/compression_progress_widget.dart';

class VideoEditorScreen extends StatefulWidget {
  const VideoEditorScreen({super.key});

  @override
  State<VideoEditorScreen> createState() => _VideoEditorScreenState();
}

class _VideoEditorScreenState extends State<VideoEditorScreen> {
  final VideoService _videoService = VideoService();
  final ImagePicker _picker = ImagePicker();

  String? _inputPath;
  String? _outputPath;
  VideoInfo? _videoInfo;

  String _selectedQuality = '1080p';
  int _bitrateKbps = 16000;
  bool _enableWatermark = false;
  String _audioMode = 'original';
  double? _trimStart;
  double? _trimEnd;

  bool _isCompressing = false;
  double _progress = 0;
  String _statusText = '';

  final Map<String, int> _qualityHeights = {
    '1080p': 1080,
    '720p': 720,
    '480p': 480,
    '360p': 360,
  };

  final Map<String, int> _qualityBitrates = {
    '1080p': 16000,
    '720p': 8000,
    '480p': 4000,
    '360p': 2000,
  };

  Future<void> _pickVideo() async {
    try {
      final xfile = await _picker.pickVideo(source: ImageSource.gallery);
      if (xfile == null) return;

      setState(() {
        _inputPath = xfile.path;
        _outputPath = null;
      });

      final info = await _videoService.getVideoInfo(_inputPath!);
      setState(() {
        _videoInfo = info;
        _trimStart = 0;
        _trimEnd = info.duration;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking video: $e')),
        );
      }
    }
  }

  Future<void> _compress() async {
    if (_inputPath == null) return;

    setState(() {
      _isCompressing = true;
      _progress = 0;
      _statusText = 'Getting video info...';
    });

    try {
      final fileService = context.read<FileService>();
      final outputPath = fileService.generateOutputPath('mp4');

      final height = _qualityHeights[_selectedQuality] ?? 1080;
      final bitrate = _bitrateKbps;

      final result = await _videoService.compressFast(
        inputPath: _inputPath!,
        outputPath: outputPath,
        targetHeight: height,
        bitrateKbps: bitrate,
        enableWatermark: _enableWatermark,
        trimStart: _trimStart,
        trimEnd: _trimEnd,
        audioMode: _audioMode,
        enableUnsharp: true,
        onProgress: (p) {
          if (mounted) {
            setState(() {
              _progress = p;
              _statusText = 'Compressing... ${(p * 100).toInt()}%';
            });
          }
        },
      );

      // Track compression
      await context.read<CompressionTrackerService>().incrementCompression();
      await context.read<PreferencesService>().addRecentCompression({
        'type': 'video',
        'path': result.path,
        'size': fileService.formatFileSize(result.compressedSize),
      });

      if (!mounted) return;

      // Navigate to result
      Navigator.pushNamed(context, '/result', arguments: {
        'path': result.path,
        'type': 'video',
        'originalSize': result.originalSize,
        'compressedSize': result.compressedSize,
        'compressionRatio': result.compressionRatio,
        'duration': result.duration,
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Compression failed: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCompressing = false;
          _statusText = '';
        });
      }
    }
  }

  void _cancelCompression() {
    _videoService.cancelCompression();
    setState(() {
      _isCompressing = false;
      _statusText = 'Cancelled';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('Compress Video'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
      ),
      body: _isCompressing ? _buildProgressView() : _buildEditorView(),
    );
  }

  Widget _buildEditorView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Video selection
          if (_inputPath == null)
            GestureDetector(
              onTap: _pickVideo,
              child: Container(
                width: double.infinity,
                height: 200,
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2C34),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFF128C7E).withOpacity(0.3),
                    width: 2,
                    strokeAlign: BorderSide.strokeAlignInside,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.video_library,
                        size: 64, color: const Color(0xFF128C7E).withOpacity(0.5)),
                    const SizedBox(height: 16),
                    const Text(
                      'Tap to select video',
                      style: TextStyle(color: Colors.white54, fontSize: 18),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'from gallery',
                      style: TextStyle(color: Colors.white38, fontSize: 14),
                    ),
                  ],
                ),
              ),
            )
          else
            _buildVideoInfoCard(),

          if (_inputPath != null) ...[
            const SizedBox(height: 24),

            // Quality selector
            QualitySelectorWidget(
              selectedQuality: _selectedQuality,
              onQualityChanged: (q) {
                setState(() {
                  _selectedQuality = q;
                  _bitrateKbps = _qualityBitrates[q] ?? 16000;
                });
              },
            ),
            const SizedBox(height: 20),

            // Bitrate slider
            const Text(
              'Bitrate',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
            ),
            const SizedBox(height: 4),
            Text(
              '${_bitrateKbps ~/ 1000} Mbps',
              style: const TextStyle(color: Color(0xFF128C7E), fontWeight: FontWeight.bold),
            ),
            Slider(
              value: _bitrateKbps.toDouble(),
              min: 1000,
              max: 50000,
              divisions: 49,
              activeColor: const Color(0xFF128C7E),
              inactiveColor: Colors.white12,
              onChanged: (v) => setState(() => _bitrateKbps = v.toInt()),
            ),
            const SizedBox(height: 12),

            // Trim controls
            if (_videoInfo != null) ...[
              const Text(
                'Trim',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
              ),
              const SizedBox(height: 4),
              Text(
                '${(_trimStart ?? 0).toStringAsFixed(1)}s - ${(_trimEnd ?? 0).toStringAsFixed(1)}s',
                style: const TextStyle(color: Colors.white54, fontSize: 13),
              ),
              RangeSlider(
                values: RangeValues(_trimStart ?? 0, _trimEnd ?? _videoInfo!.duration),
                min: 0,
                max: _videoInfo!.duration,
                activeColor: const Color(0xFF128C7E),
                inactiveColor: Colors.white12,
                onChanged: (v) => setState(() {
                  _trimStart = v.start;
                  _trimEnd = v.end;
                }),
              ),
              const SizedBox(height: 12),
            ],

            // Watermark toggle
            WatermarkToggleWidget(
              initialValue: _enableWatermark,
              onChanged: (v) => setState(() => _enableWatermark = v),
            ),
            const SizedBox(height: 12),

            // Audio options
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF2A3942),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonFormField<String>(
                value: _audioMode,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  labelText: 'Audio',
                  labelStyle: TextStyle(color: Colors.white54),
                ),
                dropdownColor: const Color(0xFF2A3942),
                icon: const Icon(Icons.expand_more, color: Colors.white70),
                style: const TextStyle(color: Colors.white),
                items: const [
                  DropdownMenuItem(value: 'original', child: Text('Original Audio')),
                  DropdownMenuItem(value: 'mute', child: Text('Mute')),
                  DropdownMenuItem(value: 'replace', child: Text('Replace Audio')),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _audioMode = v);
                },
              ),
            ),
            const SizedBox(height: 24),

            // Compress button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _compress,
                icon: const Icon(Icons.compress),
                label: const Text(
                  'Compress & Send to WhatsApp',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF128C7E),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(26),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }

  Widget _buildVideoInfoCard() {
    if (_videoInfo == null) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: const Color(0xFF128C7E).withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.videocam, color: Color(0xFF128C7E), size: 32),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p.basename(_inputPath!),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  '${_videoInfo!.width}x${_videoInfo!.height} | ${_videoInfo!.duration.toStringAsFixed(1)}s | ${_videoInfo!.codec}',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => setState(() {
              _inputPath = null;
              _videoInfo = null;
            }),
            icon: const Icon(Icons.close, color: Colors.white38),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: CompressionProgressWidget(
          progress: _progress,
          statusText: _statusText,
          showCancel: true,
          onCancel: _cancelCompression,
        ),
      ),
    );
  }
}
