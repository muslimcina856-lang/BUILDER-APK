import 'package:flutter/material.dart';
import '../widgets/premium_badge_widget.dart';

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  final List<_FaqItem> _faqs = const [
    _FaqItem(
      'How do I compress a video?',
      'Open the app and tap "Compress Video" on the home screen. Select your video from the gallery, '
      'choose your desired quality (1080p, 720p, 480p, or 360p), and tap "Compress & Send to WhatsApp". '
      'The compressed video will be ready in seconds.',
    ),
    _FaqItem(
      'What file formats are supported?',
      'WhatStatHD supports MP4, MOV, AVI, and MKV for videos. For images, we support JPG, JPEG, PNG, '
      'and WEBP formats. The app will automatically detect and process your files.',
    ),
    _FaqItem(
      'Where are my compressed files saved?',
      'All compressed files are saved in the WhatStatHD folder in your device's internal storage. '
      'You can also save them directly to your gallery from the result screen.',
    ),
    _FaqItem(
      'Is WhatStatHD really free?',
      'Yes! WhatStatHD Premium is completely unlocked at no cost. You have access to all premium features '
      'including unlimited compressions, batch processing, collage creation, and more — with no limits and no ads.',
    ),
    _FaqItem(
      'How do I share to WhatsApp Status?',
      'After compression, tap the WhatsApp button on the result screen. The app will open WhatsApp Status '
      'directly with your compressed media ready to post. Make sure WhatsApp is installed on your device.',
    ),
    _FaqItem(
      'What is the maximum video duration?',
      'There is no maximum duration limit for Premium users. You can compress videos of any length. '
      'However, WhatsApp Status has a 30-second limit for video statuses.',
    ),
    _FaqItem(
      'Does compression reduce quality?',
      'WhatStatHD uses advanced H.264 encoding to maintain the best possible quality while reducing file size. '
      'You can choose from multiple quality presets. The 1080p preset maintains excellent quality while '
      'significantly reducing file size.',
    ),
    _FaqItem(
      'Can I compress multiple images at once?',
      'Yes! Premium users can compress up to 10 images simultaneously using the batch compression feature. '
      'Simply select multiple images and the app will process them all at once.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: const Text('Frequently Asked Questions'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
        actions: [
          const Padding(
            padding: EdgeInsets.only(right: 8),
            child: PremiumBadgeWidget(),
          ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _faqs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final faq = _faqs[index];
          return _FaqCard(question: faq.question, answer: faq.answer);
        },
      ),
    );
  }
}

class _FaqItem {
  final String question;
  final String answer;

  const _FaqItem(this.question, this.answer);
}

class _FaqCard extends StatefulWidget {
  final String question;
  final String answer;

  const _FaqCard({required this.question, required this.answer});

  @override
  State<_FaqCard> createState() => _FaqCardState();
}

class _FaqCardState extends State<_FaqCard> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _isExpanded
            ? const Color(0xFF128C7E).withOpacity(0.5)
            : Colors.white12),
      ),
      child: InkWell(
        onTap: () => setState(() => _isExpanded = !_isExpanded),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.question,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Icon(
                    _isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: const Color(0xFF128C7E),
                  ),
                ],
              ),
              if (_isExpanded) ...[
                const SizedBox(height: 12),
                Text(
                  widget.answer,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.5,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
