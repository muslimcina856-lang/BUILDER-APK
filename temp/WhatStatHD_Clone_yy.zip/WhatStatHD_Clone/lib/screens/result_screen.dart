import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:path/path.dart' as p;
import '../services/file_service.dart';
import '../services/social_share_service.dart';
import '../widgets/social_share_button.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments
        as Map<String, dynamic>?;

    if (args == null) {
      return Scaffold(
        backgroundColor: const Color(0xFF121B22),
        appBar: AppBar(
          title: const Text('Result'),
          backgroundColor: const Color(0xFF1F2C34),
        ),
        body: const Center(child: Text('No result data')),
      );
    }

    final path = args['path'] as String;
    final type = args['type'] as String;
    final originalSize = args['originalSize'] as int;
    final compressedSize = args['compressedSize'] as int;
    final compressionRatio = (args['compressionRatio'] as double?) ?? 0;
    final batchSize = args['batchSize'] as int?;
    final isVideo = type == 'video';
    final fileService = context.read<FileService>();

    return Scaffold(
      backgroundColor: const Color(0xFF121B22),
      appBar: AppBar(
        title: Text(isVideo ? 'Video Result' : 'Image Result'),
        backgroundColor: const Color(0xFF1F2C34),
        elevation: 0,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context, '/home', (route) => false),
            icon: const Icon(Icons.home),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Success animation placeholder
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: const Color(0xFF128C7E).withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle,
                color: Color(0xFF128C7E),
                size: 48,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              batchSize != null
                  ? '$batchSize files compressed successfully!'
                  : 'Compression Complete!',
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 32),

            // File info
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF1F2C34),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  // Icon
                  Icon(
                    isVideo ? Icons.videocam : Icons.image,
                    size: 48,
                    color: isVideo
                        ? const Color(0xFF128C7E)
                        : const Color(0xFF25D366),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    p.basename(path),
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 20),

                  // Size comparison
                  Row(
                    children: [
                      Expanded(
                        child: _SizeCard(
                          label: 'Original',
                          size: fileService.formatFileSize(originalSize),
                          color: Colors.white54,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Icon(
                          Icons.arrow_forward,
                          color: const Color(0xFF128C7E),
                          size: 28,
                        ),
                      ),
                      Expanded(
                        child: _SizeCard(
                          label: 'Compressed',
                          size: fileService.formatFileSize(compressedSize),
                          color: const Color(0xFF128C7E),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Compression ratio
                  if (compressionRatio > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF128C7E).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'Saved ${compressionRatio.toStringAsFixed(1)}%',
                        style: const TextStyle(
                          color: Color(0xFF128C7E),
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Share buttons
            const Text(
              'Share to',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  SocialShareButton.whatsApp(
                    onPressed: () => _share(context, path, 'whatsapp'),
                  ),
                  const SizedBox(width: 12),
                  SocialShareButton.instagram(
                    onPressed: () => _share(context, path, 'instagram'),
                  ),
                  const SizedBox(width: 12),
                  SocialShareButton.facebook(
                    onPressed: () => _share(context, path, 'facebook'),
                  ),
                  const SizedBox(width: 12),
                  SocialShareButton.snapchat(
                    onPressed: () => _share(context, path, 'snapchat'),
                  ),
                  const SizedBox(width: 12),
                  SocialShareButton.save(
                    onPressed: () => _saveToGallery(context, path, fileService),
                  ),
                  const SizedBox(width: 12),
                  SocialShareButton.share(
                    onPressed: () => _share(context, path, 'other'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white70,
                      side: const BorderSide(color: Colors.white24),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(26),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text('Compress Another'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushNamedAndRemoveUntil(
                        context, '/home', (route) => false),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF128C7E),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(26),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text('Go Home'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  void _share(BuildContext context, String path, String platform) async {
    final shareService = SocialShareService();
    bool success = false;

    switch (platform) {
      case 'whatsapp':
        success = await shareService.shareToWhatsAppStatus(path);
        break;
      case 'instagram':
        success = await shareService.shareToInstagramStory(path);
        break;
      case 'facebook':
        success = await shareService.shareToFacebookStory(path);
        break;
      case 'snapchat':
        success = await shareService.shareToSnapchat(path);
        break;
      case 'other':
        success = await shareService.shareToOtherApps(path);
        break;
    }

    if (!success && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not share. Try another method.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _saveToGallery(
      BuildContext context, String path, FileService fileService) async {
    final success = await fileService.saveToGallery(path);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success
              ? 'Saved to gallery!'
              : 'Failed to save to gallery'),
          behavior: SnackBarBehavior.floating,
          backgroundColor:
              success ? const Color(0xFF128C7E) : Colors.redAccent,
        ),
      );
    }
  }
}

class _SizeCard extends StatelessWidget {
  final String label;
  final String size;
  final Color color;

  const _SizeCard({
    required this.label,
    required this.size,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(color: color.withOpacity(0.7), fontSize: 12),
          ),
          const SizedBox(height: 4),
          Text(
            size,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
