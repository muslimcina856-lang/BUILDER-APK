import 'package:flutter/material.dart';

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFF121B22),
        appBar: AppBar(
          title: const Text('Legal'),
          backgroundColor: const Color(0xFF1F2C34),
          elevation: 0,
          bottom: const TabBar(
            indicatorColor: Color(0xFF128C7E),
            labelColor: Color(0xFF128C7E),
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(text: 'Privacy Policy'),
              Tab(text: 'Terms of Service'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _PrivacyPolicyView(),
            _TermsOfServiceView(),
          ],
        ),
      ),
    );
  }
}

class _PrivacyPolicyView extends StatelessWidget {
  const _PrivacyPolicyView();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Privacy Policy'),
          _sectionText(
            'Last updated: July 2026

'
            'Thank you for choosing WhatStatHD. Your privacy is important to us.

'
            'Information We Collect

'
            'WhatStatHD does not collect, store, or transmit any personal information. '
            'All media processing is performed locally on your device.

'
            '• No account registration required
'
            '• No personal data collected
'
            '• No usage tracking or analytics
'
            '• No third-party data sharing

'
            'Media Access

'
            'WhatStatHD requires access to your device's gallery/storage to:'
            '
• Read media files for compression'
            '
• Save compressed files to your device'
            '
• Share media to other applications'
            '

All media files remain on your device and are never uploaded to any server.

'
            'Permissions

'
            'The app requests the following permissions:
'
            '• Storage: To read and save media files
'
            '• Media Library: To access photos and videos

'
            'These permissions are used solely for the app's core functionality.

'
            'Data Security

'
            'Since all processing is done locally on your device, there is no risk of '
            'data interception or unauthorized access during transmission.

'
            'Changes to This Policy

'
            'We may update this privacy policy from time to time. Changes will be '
            'posted within the app.

'
            'Contact Us

'
            'If you have questions about this privacy policy, please contact us at: '
            'support@whatstathd.com',
          ),
        ],
      ),
    );
  }
}

class _TermsOfServiceView extends StatelessWidget {
  const _TermsOfServiceView();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('Terms of Service'),
          _sectionText(
            'Last updated: July 2026

'
            'By using WhatStatHD, you agree to the following terms and conditions.

'
            'Acceptance of Terms

'
            'By downloading, installing, or using WhatStatHD, you agree to be bound by '
            'these Terms of Service. If you do not agree, please do not use the app.

'
            'License

'
            'WhatStatHD grants you a limited, non-exclusive, non-transferable license to '
            'use the application for personal, non-commercial purposes.

'
            'Prohibited Uses

'
            'You agree not to:
'
            '• Use the app for any illegal purpose
'
            '• Modify, reverse engineer, or decompile the app
'
            '• Distribute copyrighted content without permission
'
            '• Use the app to violate any applicable laws

'
            'Intellectual Property

'
            'WhatStatHD and its content, features, and functionality are owned by '
            'WhatStatHD and are protected by applicable copyright and intellectual property laws.

'
            'Disclaimer of Warranties

'
            'WhatStatHD is provided "as is" without warranties of any kind, either express or implied. '
            'We do not guarantee that the app will be uninterrupted or error-free.

'
            'Limitation of Liability

'
            'WhatStatHD shall not be liable for any indirect, incidental, special, consequential, '
            'or punitive damages arising from your use of the app.

'
            'Changes to Terms

'
            'We reserve the right to modify these terms at any time. Continued use of the app '
            'after changes constitutes acceptance of the new terms.

'
            'Contact

'
            'For questions about these terms, contact: support@whatstathd.com',
          ),
        ],
      ),
    );
  }
}

Widget _sectionTitle(String title) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(
      title,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),
  );
}

Widget _sectionText(String text) {
  return Text(
    text,
    style: const TextStyle(
      color: Colors.white70,
      fontSize: 14,
      height: 1.6,
    ),
  );
}
