package com.chatapp.webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
