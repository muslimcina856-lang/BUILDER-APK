// ==========================================
// FILE: simpan.js
// PENYIMPANAN & PENGIRIMAN CHAT REAL-TIME VIA FIREBASE
// Update: render foto, video, file di bubble chat
// ==========================================

function getPairKey(userA, userB) {
    if (userB === 'pesan tersimpan' || userA === userB) {
        return userA + '_self';
    }
    return [userA, userB].sort().join('_');
}

let activeChatListener = null;
let activeChatPairKey = null;

// KIRIM PESAN TEKS KE SERVER
function simpanPesanLokal(targetOrang, isSelf, text, time) {
    let myUser = (localStorage.getItem('active_session') || "Guest").toLowerCase();
    let target = targetOrang.replace('@', '').toLowerCase();
    let pairKey = getPairKey(myUser, target);
    let timestamp = Date.now();

    db.ref('chats/' + pairKey).push({
        sender: myUser,
        type: 'text',
        text: text,
        time: time,
        timestamp: timestamp
    });

    db.ref('chats_index/' + myUser + '/' + target).set({ lastMsg: text, lastTime: timestamp });
    if (target !== 'pesan tersimpan' && target !== myUser) {
        db.ref('chats_index/' + target + '/' + myUser).set({ lastMsg: text, lastTime: timestamp });
    }
}

// MEMUAT & MENDENGARKAN PESAN REAL-TIME
function muatPesanLokal(targetOrang) {
    let myUser = (localStorage.getItem('active_session') || "Guest").toLowerCase();
    let target = targetOrang.replace('@', '').toLowerCase();
    let pairKey = getPairKey(myUser, target);
    const messagesContainer = document.getElementById('cr-messages');

    if (activeChatListener && activeChatPairKey) {
        db.ref('chats/' + activeChatPairKey).off('value', activeChatListener);
    }

    activeChatPairKey = pairKey;
    activeChatListener = function(snap) {
        const data = snap.val() || {};
        messagesContainer.innerHTML = "";

        Object.values(data)
            .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0))
            .forEach(msg => {
                let html = '';
                // Pakai renderBubbleMedia dari seting.js jika tersedia
                if (typeof renderBubbleMedia === 'function') {
                    html = renderBubbleMedia(msg, myUser);
                } else {
                    let alignClass = (msg.sender === myUser) ? "msg-self" : "msg-other";
                    let checkIcon = (msg.sender === myUser) ? "<i class='bx bx-check-double' style='color:#3ba4f9'></i>" : "";
                    html = `<div class="msg-bubble ${alignClass}">${msg.text || ''}<span class="msg-time">${msg.time} ${checkIcon}</span></div>`;
                }
                messagesContainer.innerHTML += html;
            });

        if (window.twemoji) { twemoji.parse(messagesContainer); }
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    };

    db.ref('chats/' + pairKey).on('value', activeChatListener);
}

// LEPAS LISTENER
function lepasListenerChat() {
    if (activeChatListener && activeChatPairKey) {
        db.ref('chats/' + activeChatPairKey).off('value', activeChatListener);
        activeChatListener = null;
        activeChatPairKey = null;
    }
}

// MEMUAT DAFTAR OBROLAN REAL-TIME
function muatDaftarObrolan() {
    let myUser = (localStorage.getItem('active_session') || "Guest").toLowerCase();

    db.ref('chats_index/' + myUser).on('value', snap => {
        const data = snap.val() || {};
        const targets = Object.keys(data);

        targets.forEach(target => {
            const entry = data[target];
            const existingDiv = document.querySelector('.chat-item[data-chatname="' + target + '"]');

            if (existingDiv) {
                const pEl = existingDiv.querySelector('.chat-message p');
                const tEl = existingDiv.querySelector('.chat-header .time');
                if (pEl && entry.lastMsg) pEl.textContent = entry.lastMsg;
                if (tEl && entry.lastTime) {
                    tEl.textContent = new Date(entry.lastTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }
            } else if (target === 'pesan tersimpan') {
                if (typeof buatItemChat === 'function') buatItemChat("Pesan Tersimpan", true, {});
            } else {
                db.ref('users/' + target).once('value').then(uSnap => {
                    if (typeof buatItemChat === 'function') buatItemChat(target, false, uSnap.val() || {});
                });
            }
        });

        const totalChatDiv = document.querySelectorAll('#regular-chats .chat-item, #pinned-chats .chat-item').length;
        if (targets.length === 0 && totalChatDiv === 0) {
            document.getElementById('chat-empty-state').style.display = 'block';
        }
    });
}
