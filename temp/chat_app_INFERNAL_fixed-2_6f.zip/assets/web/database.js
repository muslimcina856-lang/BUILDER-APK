// ==========================================
// FILE: database.js
// OTAK DATABASE REAL-TIME FIREBASE
// ==========================================

const firebaseConfig = {
  apiKey: "AIzaSyDuF70h00Vf6Vbqk4YFrqrWyTWOovmn7ms",
  authDomain: "edxzvip.firebaseapp.com",
  databaseURL: "https://edxzvip-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "edxzvip",
  storageBucket: "edxzvip.firebasestorage.app",
  messagingSenderId: "963004829027",
  appId: "1:963004829027:web:dd1d4e791a9868d616d756",
  measurementId: "G-R7EY4XXWJP"
};

// Inisialisasi Firebase (Kita gunakan versi Compat agar tidak merusak tombol UI Tuan)
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

// Menyalakan Mesin Database
const db = firebase.database();

console.log("Mesin Firebase berhasil disiapkan!");
