// ==========================================
// FILE: seting.js
// LOGIKA UTAMA DASHBOARD — DIPERBAHARUI
// Tambahan: popup woun di profil, kirim foto/video/file di chat,
//           notifikasi push saat ada pesan masuk
// ==========================================

const navItems = document.querySelectorAll('.nav-item');
const tabContents = document.querySelectorAll('.tab-content');
const headerDropdown = document.getElementById('header-dropdown');

let currentSelectedChat = null; 
let pinnedCount = 0;
let arsipCount = 0;
let isPesanTersimpanActive = false; 

const verifiedSVG = `<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg" class="global-chat-verified-badge" onclick="event.stopPropagation(); openModal('modal-verified')"><circle cx="12" cy="12" r="11" fill="#3ba4f9"/><path d="M7.2 12.6l3.1 3.1L17 9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const safeVerifiedSVG = `<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg" class="global-chat-verified-badge" onclick="event.stopPropagation(); openModal('modal-verified-safe')"><circle cx="12" cy="12" r="11" fill="#22c55e"/><path d="M7.2 12.6l3.1 3.1L17 9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const scamSVG = `<svg viewBox="0 0 100 110" class="global-chat-scam-badge" onclick="event.stopPropagation(); openModal('modal-scam')" xmlns="http://www.w3.org/2000/svg"><polygon points="50,10 95,75 5,75" fill="#fde047" stroke="#ef4444" stroke-width="8" stroke-linejoin="round"/><line x1="50" y1="30" x2="50" y2="50" stroke="#ef4444" stroke-width="8" stroke-linecap="round"/><circle cx="50" cy="63" r="5" fill="#ef4444"/><rect x="15" y="75" width="70" height="25" rx="6" fill="#ef4444"/><text x="50" y="93" font-family="'Inter', sans-serif" font-weight="900" font-size="18" fill="#fde047" text-anchor="middle">SCAM</text></svg>`;

let myUsername = localStorage.getItem('active_session');
let myWounVal = 0;

// ================================================
// NOTIFIKASI PUSH — MINTA IZIN SAAT PERTAMA KALI
// ================================================
function mintaIzinNotifikasi() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                tampilkanNotif('💬 Notifikasi Aktif', 'Anda akan mendapat notifikasi saat ada pesan masuk!');
            }
        });
    }
}

function tampilkanNotif(judul, isi, iconUrl) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    // Jangan notif kalau tab sedang aktif & fokus
    if (document.visibilityState === 'visible' && document.hasFocus()) return;
    const notif = new Notification(judul, {
        body: isi,
        icon: iconUrl || 'https://cdn-icons-png.flaticon.com/512/134/134914.png',
        badge: iconUrl || 'https://cdn-icons-png.flaticon.com/512/134/134914.png',
        tag: 'chat-msg',
        renotify: true
    });
    notif.onclick = () => { window.focus(); notif.close(); };
}

// Dengarkan pesan masuk dari semua obrolan untuk notifikasi
let notifListeners = {};
function daftarNotifikasiChat() {
    if (!myUsername) return;
    db.ref('chats_index/' + myUsername).on('value', snap => {
        const data = snap.val() || {};
        Object.keys(data).forEach(target => {
            if (notifListeners[target]) return; // sudah didaftarkan
            const pairKey = [myUsername, target].sort().join('_');
            // Khusus self
            const realKey = (target === 'pesan tersimpan' || target === myUsername) ? myUsername + '_self' : pairKey;
            notifListeners[target] = true;
            db.ref('chats/' + realKey).limitToLast(1).on('child_added', snap => {
                const msg = snap.val();
                if (!msg || msg.sender === myUsername) return; // abaikan pesan kita sendiri
                // Ambil display name pengirim
                db.ref('users/' + msg.sender).once('value').then(uSnap => {
                    const uData = uSnap.val() || {};
                    const nama = uData.display_name || msg.sender;
                    const isiPesan = msg.type === 'image' ? '📷 Foto' : msg.type === 'video' ? '🎥 Video' : msg.type === 'file' ? '📎 File: ' + (msg.fileName || '') : msg.text || '';
                    tampilkanNotif('Pesan dari @' + msg.sender, isiPesan, uData.avatar || null);
                });
            });
        });
    });
}

// ================================================
// WINDOW ONLOAD
// ================================================
window.onload = function() {
    if (!myUsername) { window.location.href = 'login.html'; return; }
    
    // Minta izin notifikasi
    mintaIzinNotifikasi();
    
    document.getElementById('set-username').textContent = "@" + myUsername;
    document.getElementById('set-date').textContent = new Date().toLocaleDateString('id-ID');
    document.getElementById('set-id').textContent = "1" + Math.floor(10000000 + Math.random() * 90000000);
    document.getElementById('my-username-display').textContent = "@" + myUsername;

    // REAL TIME DARI FIREBASE UNTUK PROFIL SENDIRI
    db.ref('users/' + myUsername).on('value', (snap) => {
        let data = snap.val() || {};
        let dispName = data.display_name || (myUsername.charAt(0).toUpperCase() + myUsername.slice(1));
        
        if(myUsername === 'edxzvip') {
            dispName = "Owner Resmi";
            document.getElementById('verified-badge').classList.remove('hidden');
            document.getElementById('owner-panel').classList.remove('hidden');
            document.getElementById('menu-verifikasi-aman').classList.add('hidden');

            db.ref('verif_requests').on('value', (vsnap) => {
                let count = vsnap.exists() ? Object.keys(vsnap.val()).length : 0;
                let badgeEl = document.getElementById('verif-pending-count');
                if (badgeEl) badgeEl.textContent = count;
            });
        }

        if (data.verified === true) {
            document.getElementById('verified-safe-badge').classList.remove('hidden');
        } else {
            document.getElementById('verified-safe-badge').classList.add('hidden');
        }

        document.getElementById('display-name-text').textContent = dispName;
        document.getElementById('my-bio-display').textContent = data.bio && data.bio.trim() !== "" ? data.bio : "Tap untuk tambah bio...";
        
        // Update woun saya
        myWounVal = data.woun || 0;
        const myWounEl = document.getElementById('my-woun-display');
        if (myWounEl) myWounEl.textContent = myWounVal;

        if(data.avatar) {
            document.getElementById('my-avatar').src = data.avatar;
            document.getElementById('my-avatar').classList.remove('hidden');
            document.getElementById('avatar-placeholder').classList.add('hidden');
            document.getElementById('nav-avatar-box').innerHTML = `<img src="${data.avatar}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
        }

        if(data.scam === true) { document.getElementById('scam-badge').classList.remove('hidden'); } 
        else { document.getElementById('scam-badge').classList.add('hidden'); }
    });

    if (typeof muatDaftarObrolan === 'function') { muatDaftarObrolan(); }

    // Mulai dengarkan notifikasi
    daftarNotifikasiChat();
};

document.addEventListener('click', (e) => {
    if (!e.target.matches('#main-menu-btn')) headerDropdown.classList.add('hidden');
    if (!e.target.closest('.bx-dots-vertical-rounded')) {
        let upDrop = document.getElementById('up-dropdown');
        if(upDrop) upDrop.classList.add('hidden');
    }
    // Tutup woun popup jika klik di luar
    const wounPopup = document.getElementById('woun-info-popup');
    if (wounPopup && !wounPopup.classList.contains('hidden')) {
        if (!e.target.closest('#woun-info-popup') && !e.target.closest('.woun-clickable')) {
            wounPopup.classList.add('hidden');
        }
    }
});

navItems.forEach(item => {
    item.addEventListener('click', function(e) {
        e.preventDefault();
        navItems.forEach(nav => nav.classList.remove('active'));
        navItems.forEach(nav => {
            const icon = nav.querySelector('i');
            if (icon) icon.className = icon.className.replace('bxs-', 'bx-');
        });
        this.classList.add('active');
        const activeIcon = this.querySelector('i');
        if (activeIcon) activeIcon.className = activeIcon.className.replace('bx-', 'bxs-');

        const targetName = this.getAttribute('data-target');
        tabContents.forEach(content => content.classList.add('hidden'));
        tabContents.forEach(content => content.classList.remove('active'));
        const targetView = document.getElementById('view-' + targetName.toLowerCase());
        if (targetView) {
            targetView.classList.remove('hidden');
            targetView.classList.add('active');
        }
    });
});

function toggleHeaderMenu() { headerDropdown.classList.toggle('hidden'); }
function openModal(modalId) { document.getElementById(modalId).classList.add('show'); }
function closeModals() { document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('show')); }

function bukaPesanTersimpan() { headerDropdown.classList.add('hidden'); bukaChatRoom("Pesan Tersimpan", true); }

function bukaChatRoom(nama, isSaved = false) {
    let cleanName = nama.replace('@', '').toLowerCase();
    
    db.ref('users/' + cleanName).once('value').then(snap => {
        let data = snap.val() || {};
        let titleHeaderName = nama;
        
        if(cleanName === 'edxzvip') { titleHeaderName = `Owner Resmi ${verifiedSVG}`; }
        if(data.verified === true) { titleHeaderName += ` ${safeVerifiedSVG}`; }
        if(data.scam === true) { titleHeaderName += ` ${scamSVG}`; }

        document.getElementById('cr-title').innerHTML = titleHeaderName;
        
        db.ref(`blocks/${myUsername}_${cleanName}`).once('value').then(bSnap => {
            if(bSnap.val() === true) {
                document.getElementById('cr-status').textContent = "Anda memblokir pengguna ini";
                document.getElementById('cr-status').style.color = "#ef4444";
            } else {
                document.getElementById('cr-status').textContent = isSaved ? "Catatan pribadi" : "Terhubung";
                document.getElementById('cr-status').style.color = "#00a884";
            }
            
            window.activeChatTarget = cleanName;
            document.getElementById('chat-room').classList.remove('hidden');
            if (typeof muatPesanLokal === 'function') { muatPesanLokal(window.activeChatTarget); }
        });
    });
}

function tutupChatRoom() {
    document.getElementById('chat-room').classList.add('hidden');
    if (typeof lepasListenerChat === 'function') { lepasListenerChat(); }
    const title = document.getElementById('cr-title').textContent;
    if (title.includes("Pesan Tersimpan") && !isPesanTersimpanActive) {
        isPesanTersimpanActive = true;
        buatItemChat("Pesan Tersimpan", true); 
    }
}

function handleEnter(e) { if(e.key === 'Enter' && !e.shiftKey) kirimPesan(); }

function kirimPesan() {
    const input = document.getElementById('cr-input');
    const text = input.value.trim();
    if(text === "") return;

    let target = window.activeChatTarget.toLowerCase();
    const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    db.ref(`blocks/${myUsername}_${target}`).once('value').then(snap => {
        let isBlocked = snap.val() === true;
        input.value = ""; 
        if (typeof simpanPesanLokal === 'function') { 
            simpanPesanLokal(window.activeChatTarget, true, text, time, isBlocked); 
        }
    });
}

// ================================================
// KIRIM FOTO / VIDEO / FILE DI CHAT
// ================================================
function triggerLampiranChat() {
    // Buka pilihan: foto, video, file
    const existing = document.getElementById('lampiran-picker');
    if (existing) { existing.classList.toggle('hidden'); return; }
    
    const picker = document.createElement('div');
    picker.id = 'lampiran-picker';
    picker.style.cssText = 'position:absolute; bottom:70px; left:15px; background:#2a3942; border-radius:14px; padding:10px; z-index:3500; display:flex; flex-direction:column; gap:6px; box-shadow:0 4px 20px rgba(0,0,0,0.5);';
    picker.innerHTML = `
        <label style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;color:#e4e6eb;font-size:14px;border-radius:8px;" onmouseover="this.style.background='#202c33'" onmouseout="this.style.background=''">
            <i class='bx bx-image' style="font-size:22px;color:#3ba4f9;"></i> Kirim Foto
            <input type="file" accept="image/*" hidden onchange="kirimFileChat(this, 'image')">
        </label>
        <label style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;color:#e4e6eb;font-size:14px;border-radius:8px;" onmouseover="this.style.background='#202c33'" onmouseout="this.style.background=''">
            <i class='bx bx-video' style="font-size:22px;color:#22c55e;"></i> Kirim Video
            <input type="file" accept="video/*" hidden onchange="kirimFileChat(this, 'video')">
        </label>
        <label style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;color:#e4e6eb;font-size:14px;border-radius:8px;" onmouseover="this.style.background='#202c33'" onmouseout="this.style.background=''">
            <i class='bx bx-file' style="font-size:22px;color:#fbbf24;"></i> Kirim File
            <input type="file" hidden onchange="kirimFileChat(this, 'file')">
        </label>
    `;
    document.querySelector('.chat-room-overlay').appendChild(picker);
}

// Tutup picker lampiran jika klik di luar
document.addEventListener('click', function(e) {
    const picker = document.getElementById('lampiran-picker');
    if (picker && !picker.classList.contains('hidden') && !e.target.closest('#lampiran-picker') && !e.target.closest('.cr-attach-btn')) {
        picker.classList.add('hidden');
    }
});

function kirimFileChat(input, tipe) {
    const file = input.files[0];
    if (!file) return;
    const picker = document.getElementById('lampiran-picker');
    if (picker) picker.classList.add('hidden');

    // Batas ukuran: foto/video maks 5MB, file maks 2MB
    const maxSize = tipe === 'file' ? 2 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxSize) {
        alert(`Ukuran file terlalu besar! Maksimal ${tipe === 'file' ? '2MB' : '5MB'}.`);
        return;
    }

    const target = window.activeChatTarget.toLowerCase();
    const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

    // Tampilkan loading bubble
    const messagesContainer = document.getElementById('cr-messages');
    const loadingBubble = document.createElement('div');
    loadingBubble.className = 'msg-bubble msg-self';
    loadingBubble.innerHTML = `<span style="color:#8696a0;font-size:13px;">⏳ Mengunggah ${tipe}...</span>`;
    messagesContainer.appendChild(loadingBubble);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    const reader = new FileReader();
    reader.onload = function(e) {
        const base64Data = e.target.result;
        loadingBubble.remove();

        db.ref(`blocks/${myUsername}_${target}`).once('value').then(snap => {
            const isBlocked = snap.val() === true;
            const pairKey = typeof getPairKey === 'function' ? getPairKey(myUsername, target) : [myUsername, target].sort().join('_');
            const timestamp = Date.now();

            const msgData = {
                sender: myUsername,
                type: tipe,
                time: time,
                timestamp: timestamp,
                isBlocked: isBlocked || false
            };

            if (tipe === 'image') {
                msgData.imageData = base64Data;
                msgData.text = '📷 Foto';
            } else if (tipe === 'video') {
                msgData.videoData = base64Data;
                msgData.text = '🎥 Video';
            } else {
                msgData.fileData = base64Data;
                msgData.fileName = file.name;
                msgData.fileSize = (file.size / 1024).toFixed(1) + ' KB';
                msgData.text = '📎 ' + file.name;
            }

            db.ref('chats/' + pairKey).push(msgData);
            db.ref('chats_index/' + myUsername + '/' + target).set({ lastMsg: msgData.text, lastTime: timestamp });
            if (target !== 'pesan tersimpan' && target !== myUsername) {
                db.ref('chats_index/' + target + '/' + myUsername).set({ lastMsg: msgData.text, lastTime: timestamp });
            }
        });
    };

    if (tipe === 'image' || tipe === 'file') {
        reader.readAsDataURL(file);
    } else {
        // Video dibaca sebagai data URL juga (ukuran dibatasi)
        reader.readAsDataURL(file);
    }
}

// ================================================
// RENDER PESAN — patch ke simpan.js agar render foto/video/file
// (Fungsi ini dipanggil dari simpan.js via muatPesanLokal)
// ================================================
function renderBubbleMedia(msg, myUser) {
    let alignClass = (msg.sender === myUser) ? "msg-self" : "msg-other";
    let checkIcon = (msg.sender === myUser) ? "<i class='bx bx-check-double' style='color:#3ba4f9'></i>" : "";

    if (msg.type === 'image' && msg.imageData) {
        return `<div class="msg-bubble ${alignClass}" style="padding:6px;">
            <img src="${msg.imageData}" style="max-width:220px; border-radius:10px; display:block; cursor:pointer;" onclick="bukaZoomFoto('${msg.imageData}')">
            <span class="msg-time">${msg.time} ${checkIcon}</span>
        </div>`;
    } else if (msg.type === 'video' && msg.videoData) {
        return `<div class="msg-bubble ${alignClass}" style="padding:6px;">
            <video src="${msg.videoData}" controls style="max-width:220px; border-radius:10px; display:block;"></video>
            <span class="msg-time">${msg.time} ${checkIcon}</span>
        </div>`;
    } else if (msg.type === 'file' && msg.fileData) {
        return `<div class="msg-bubble ${alignClass}">
            <a href="${msg.fileData}" download="${msg.fileName || 'file'}" style="color:#3ba4f9; text-decoration:none; display:flex; align-items:center; gap:8px;">
                <i class='bx bx-file' style="font-size:24px;"></i>
                <span>${msg.fileName || 'File'}<br><small style="color:#8696a0;">${msg.fileSize || ''}</small></span>
            </a>
            <span class="msg-time">${msg.time} ${checkIcon}</span>
        </div>`;
    } else {
        return `<div class="msg-bubble ${alignClass}">
            ${msg.text}
            <span class="msg-time">${msg.time} ${checkIcon}</span>
        </div>`;
    }
}

// Zoom foto pesan
function bukaZoomFoto(src) {
    let overlay = document.getElementById('foto-zoom-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'foto-zoom-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.92);z-index:9999;display:flex;align-items:center;justify-content:center;';
        overlay.innerHTML = `<img id="foto-zoom-img" style="max-width:96vw;max-height:90vh;border-radius:10px;object-fit:contain;">
            <i class='bx bx-x' onclick="document.getElementById('foto-zoom-overlay').remove()" style="position:absolute;top:16px;right:16px;font-size:32px;color:#fff;cursor:pointer;"></i>`;
        overlay.onclick = function(e) { if(e.target === overlay) overlay.remove(); };
        document.body.appendChild(overlay);
    }
    document.getElementById('foto-zoom-img').src = src;
}

// ================================================
// POPUP WOUN DI PROFIL SENDIRI
// ================================================
function bukaPopupWounSendiri() {
    let popup = document.getElementById('woun-info-popup');
    if (!popup) {
        popup = document.createElement('div');
        popup.id = 'woun-info-popup';
        popup.style.cssText = `
            position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
            background:#202c33; border-radius:20px; padding:28px 24px; z-index:7000;
            box-shadow:0 10px 40px rgba(0,0,0,0.7); min-width:260px; text-align:center;
            border:1px solid rgba(59,164,249,0.2);
        `;
        document.body.appendChild(popup);
    }
    popup.classList.remove('hidden');
    popup.innerHTML = `
        <div style="font-size:36px; margin-bottom:8px;">💰</div>
        <div style="font-size:15px; color:#8696a0; margin-bottom:6px; text-transform:uppercase; letter-spacing:1px;">Saldo Woun Anda</div>
        <div style="font-size:48px; font-weight:800; color:#3ba4f9; line-height:1;" id="popup-woun-val">...</div>
        <div style="font-size:14px; color:#8696a0; margin-top:4px; margin-bottom:20px;">WOUN</div>
        <button onclick="window.location.href='woun.html'" style="width:100%;padding:13px;background:#3ba4f9;border:none;border-radius:12px;color:#fff;font-size:15px;font-weight:600;cursor:pointer;margin-bottom:8px;">Buka Dompet Woun</button>
        <button onclick="document.getElementById('woun-info-popup').classList.add('hidden')" style="width:100%;padding:12px;background:#2a3942;border:none;border-radius:12px;color:#8696a0;font-size:14px;cursor:pointer;">Tutup</button>
    `;
    // Ambil nilai real-time
    db.ref('users/' + myUsername + '/woun').once('value').then(snap => {
        const val = snap.val() || 0;
        myWounVal = val;
        const el = document.getElementById('popup-woun-val');
        if (el) el.textContent = val;
    });
}

// ================================================
// POPUP WOUN DI PROFIL ORANG LAIN
// ================================================
function bukaPopupWounUser(username) {
    let popup = document.getElementById('woun-info-popup');
    if (!popup) {
        popup = document.createElement('div');
        popup.id = 'woun-info-popup';
        popup.style.cssText = `
            position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
            background:#202c33; border-radius:20px; padding:28px 24px; z-index:7000;
            box-shadow:0 10px 40px rgba(0,0,0,0.7); min-width:260px; text-align:center;
            border:1px solid rgba(59,164,249,0.2);
        `;
        document.body.appendChild(popup);
    }
    popup.classList.remove('hidden');
    popup.innerHTML = `
        <div style="font-size:36px; margin-bottom:8px;">💰</div>
        <div style="font-size:14px; color:#8696a0; margin-bottom:4px;">Woun Milik</div>
        <div style="font-size:16px; color:#3ba4f9; font-weight:600; margin-bottom:10px;">@${username}</div>
        <div style="font-size:13px; color:#8696a0; text-transform:uppercase; letter-spacing:1px; margin-bottom:6px;">Jumlah</div>
        <div style="font-size:48px; font-weight:800; color:#3ba4f9; line-height:1;" id="popup-woun-val-user">...</div>
        <div style="font-size:14px; color:#8696a0; margin-top:4px; margin-bottom:20px;">WOUN</div>
        <button onclick="document.getElementById('woun-info-popup').classList.add('hidden')" style="width:100%;padding:13px;background:#2a3942;border:none;border-radius:12px;color:#e4e6eb;font-size:15px;font-weight:600;cursor:pointer;">Tutup</button>
    `;
    db.ref('users/' + username + '/woun').once('value').then(snap => {
        const val = snap.val() || 0;
        const el = document.getElementById('popup-woun-val-user');
        if (el) el.textContent = val;
    });
}

// ================================================
// TAMBAH ORANG
// ================================================
function tambahOrang() {
    const user = document.getElementById('new-chat-username').value.trim().toLowerCase();
    let cleanUser = user.replace('@', '');
    if (!cleanUser) return;
    
    db.ref('users/' + cleanUser).once('value').then(snap => {
        if(!snap.exists() && cleanUser !== 'pesan tersimpan') {
            alert("User tidak ditemukan di server!");
        } else {
            buatItemChat(user, false, snap.val());
            closeModals();
            document.getElementById('new-chat-username').value = "";
        }
    });
}

function buatItemChat(nama, forcePin = false, dataServer = {}) {
    document.getElementById('chat-empty-state').style.display = 'none';
    const div = document.createElement('div');
    div.className = 'chat-item';
    
    let cleanName = nama.replace('@', '').toLowerCase();
    div.dataset.chatname = cleanName;
    let icon = "";
    if (nama === "Pesan Tersimpan") {
        icon = "<div class='chat-blank-avatar-div' style='background:#3ba4f9; color:white;'><i class='bx bx-bookmark'></i></div>";
    } else {
        if(dataServer && dataServer.avatar) {
            icon = `<img src="${dataServer.avatar}" style="width:55px;height:55px;border-radius:50%;object-fit:cover;">`;
        } else {
            icon = "<div class='chat-blank-avatar-div'><i class='bx bx-user'></i></div>";
        }
    }
        
    const msg = nama === "Pesan Tersimpan" ? "Catatan tersimpan..." : "Mulai obrolan baru...";
    let cetakNamaDanBadge = nama;

    if(cleanName === 'edxzvip') cetakNamaDanBadge = `Owner Resmi ${verifiedSVG}`;
    if(dataServer && dataServer.verified === true) cetakNamaDanBadge += ` ${safeVerifiedSVG}`;
    if(dataServer && dataServer.scam === true) cetakNamaDanBadge += ` ${scamSVG}`;

    div.innerHTML = `
        <div class="avatar" onclick="event.stopPropagation(); bukaProfilUser('${nama}')">${icon}</div>
        <div class="chat-details" onclick="bukaChatRoom('${nama}', ${nama === 'Pesan Tersimpan'})">
            <div class="chat-header"><h4>${cetakNamaDanBadge}</h4><span class="time">Baru</span></div>
            <div class="chat-message"><p>${msg}</p><i class='bx bxs-pin pinned-icon hidden'></i></div>
        </div>
    `;

    let pressTimer;
    let isLongPress = false;
    const mulaiTahan = () => { isLongPress = false; pressTimer = setTimeout(() => { isLongPress = true; bukaMenuAksi(div, nama); }, 600); };
    const lepasTahan = () => clearTimeout(pressTimer);

    div.addEventListener('mousedown', mulaiTahan);
    div.addEventListener('touchstart', mulaiTahan);
    div.addEventListener('mouseup', lepasTahan);
    div.addEventListener('mouseleave', lepasTahan);
    div.addEventListener('touchend', lepasTahan);

    div.addEventListener('click', () => {
        if (!isLongPress) {
            if (div.parentElement.id === 'archived-chats') {
                document.getElementById('regular-chats').prepend(div);
                arsipCount--; document.getElementById('arsip-count').textContent = arsipCount;
                if (arsipCount <= 0) {
                    document.getElementById('arsip-btn-container').classList.add('hidden');
                    document.getElementById('archived-chats').classList.add('hidden');
                }
            }
            bukaChatRoom(nama, nama === "Pesan Tersimpan");
        }
    });

    if (forcePin) { div.querySelector('.pinned-icon').classList.remove('hidden'); document.getElementById('pinned-chats').prepend(div); } 
    else { document.getElementById('regular-chats').prepend(div); }
}

// ================================================
// PROFIL USER LAIN — dengan woun row yang bisa dipencet
// ================================================
function bukaProfilUser(nama) {
    let cleanName = nama.replace('@', '').toLowerCase();
    window.currentViewedProfile = cleanName;
    document.getElementById('up-username').textContent = "@" + cleanName;
    
    db.ref('users/' + cleanName).once('value').then(snap => {
        let data = snap.val() || {};
        let dispName = data.display_name || (cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
        
        document.getElementById('up-badge-area').innerHTML = "";
        if(cleanName === 'edxzvip') { dispName = "Owner Resmi"; document.getElementById('up-badge-area').innerHTML += verifiedSVG; }
        if (data.verified === true) { document.getElementById('up-badge-area').innerHTML += safeVerifiedSVG; }
        if (data.scam === true) { document.getElementById('up-badge-area').innerHTML += scamSVG; }
        document.getElementById('up-name').textContent = dispName;
        document.getElementById('up-bio').textContent = data.bio && data.bio.trim() !== "" ? data.bio : "Akun ini tidak memiliki bio.";

        if(data.avatar) {
            document.getElementById('up-avatar-box').innerHTML = `<img src="${data.avatar}" style="width:100%; height:100%; object-fit:cover;">`;
        } else {
            document.getElementById('up-avatar-box').innerHTML = `<i class='bx bx-user' style="font-size: 55px; color: #8696a0;"></i>`;
        }

        // Catatan: tampilan woun di profil user lain (#up-woun-area / #up-woun-value)
        // sekarang ditangani oleh override window.bukaProfilUser di dashboard.html,
        // supaya tidak ada dua kode yang menulis ke elemen yang sama secara bersamaan.
    });

    db.ref(`blocks/${myUsername}_${cleanName}`).once('value').then(snap => {
        let isBlocked = snap.val() === true;
        let blokirBtn = document.getElementById('btn-up-blokir');
        if (blokirBtn) {
            if (isBlocked) {
                blokirBtn.innerHTML = "Buka Blokir User"; blokirBtn.style.color = "#6ee7b7"; 
            } else {
                blokirBtn.innerHTML = "Blokir User"; blokirBtn.style.color = "#e4e6eb"; 
            }
        }
    });

    document.getElementById('user-profile-view').classList.remove('hidden');
}

function tutupProfilUser() { document.getElementById('user-profile-view').classList.add('hidden'); }
function toggleUPMenu() { document.getElementById('up-dropdown').classList.toggle('hidden'); }
function upAksi(jenis) {
    document.getElementById('up-dropdown').classList.add('hidden');
    let target = window.currentViewedProfile.toLowerCase();

    if(jenis === 'laporkan') {
        alert("Terima kasih, laporan terhadap akun ini telah dikirim ke sistem pusat.");
    } else if (jenis === 'blokir') {
        let refBlock = db.ref(`blocks/${myUsername}_${target}`);
        refBlock.once('value').then(snap => {
            let isBlocked = snap.val() === true;
            if(isBlocked) {
                refBlock.remove(); alert("Blokir dibuka. Anda sekarang dapat mengirim pesan.");
            } else {
                refBlock.set(true); alert("Pengguna diblokir. Pesan tidak akan dikirimkan.");
            }
            bukaProfilUser(target); 
        });
    } else if (jenis === 'arsipkan') {
        alert("Fitur arsip dari dalam profil akan diarahkan ke beranda. Silakan tahan pesan dari luar untuk mengarsipkan.");
        tutupProfilUser();
    }
}
function upMulaiChat() { tutupProfilUser(); bukaChatRoom(window.currentViewedProfile); }

// ================================================
// MENU AKSES OWNER & EDIT (REAL-TIME)
// ================================================
function tagScam() {
    const target = prompt("Masukkan Username untuk ditandai sebagai SCAM (tanpa @):");
    if (target) {
        const userClean = target.replace('@', '').trim().toLowerCase();
        db.ref('users/' + userClean).update({ scam: true }).then(() => {
            alert(`Berhasil! @${userClean} telah resmi ditandai sebagai SCAMER.`);
        });
    }
}
function unScam() {
    const target = prompt("Masukkan Username yang ingin dilepaskan dari SCAM (tanpa @):");
    if (target) {
        const userClean = target.replace('@', '').trim().toLowerCase();
        db.ref('users/' + userClean).update({ scam: false }).then(() => {
            alert(`Berhasil! Status SCAMER untuk @${userClean} telah dicabut.`);
        });
    }
}

function editDisplayName() {
    let current = document.getElementById('display-name-text').textContent;
    let newName = prompt("Masukkan Display Name Baru:", current);
    if(newName && newName.trim() !== "") {
        db.ref('users/' + myUsername).update({ display_name: newName.trim() }).then(() => {
            alert("Display Name berhasil diubah di Server!");
        });
    }
}

function editBio() {
    let current = document.getElementById('my-bio-display').textContent;
    if (current === "Tap untuk tambah bio...") current = "";
    let newBio = prompt("Tulis bio kamu (maks 100 karakter):", current);
    if (newBio === null) return;
    newBio = newBio.trim();
    if (newBio.length > 100) {
        alert("Bio terlalu panjang! Maksimal 100 karakter.");
        return;
    }
    db.ref('users/' + myUsername).update({ bio: newBio }).then(() => {
        alert("Bio berhasil disimpan!");
    });
}

function editUsername() {
    let newName = prompt("Masukkan Username Baru (Tanpa @)\n\nPERHATIAN: Mengubah username akan me-refresh paksa sesi aplikasi Anda.", myUsername);
    if (newName && newName.trim() !== "") {
        let cleanNew = newName.replace('@', '').trim().toLowerCase();
        if(cleanNew === myUsername) return; 
        if(cleanNew.length < 4) { alert("Username terlalu pendek! Minimal 4 huruf."); return; }
        if(cleanNew === 'edxzvip') { alert("Dilarang menggunakan username Owner!"); return; }
        
        db.ref('users/' + cleanNew).once('value').then(snap => {
            if (snap.exists()) {
                document.getElementById('username-error').classList.remove('hidden');
                return;
            }
            db.ref('users/' + myUsername).once('value').then(oldSnap => {
                db.ref('users/' + cleanNew).set(oldSnap.val()).then(() => {
                    db.ref('users/' + myUsername).remove();
                    localStorage.setItem('active_session', cleanNew);
                    alert("Username berhasil diganti menjadi @" + cleanNew);
                    window.location.reload();
                });
            });
        });
    }
}

function prosesGantiPassword() {
    const lama = document.getElementById('pass-lama').value;
    const baru = document.getElementById('pass-baru').value;
    const ulang = document.getElementById('pass-baru-konfirmasi').value;
    if(!lama || !baru || !ulang) { alert("Semua kolom harus diisi!"); return; }
    
    db.ref('users/' + myUsername).once('value').then(snap => {
        if(lama !== snap.val().password) { alert("Password Lama Anda Salah!"); return; }
        if(baru !== ulang) { alert("Password Baru dan Konfirmasi Tidak Cocok!"); return; }

        db.ref('users/' + myUsername).update({ password: baru });

        closeModals();
        document.getElementById('notif-user-pass').textContent = "@" + myUsername;
        document.getElementById('notif-pass-baru').textContent = baru;
        document.getElementById('pass-lama').value = ""; document.getElementById('pass-baru').value = ""; document.getElementById('pass-baru-konfirmasi').value = "";
        openModal('modal-sukses-password');
    });
}

function pindahAkun() { localStorage.removeItem('active_session'); window.location.href = 'login.html'; }
function keluarAkun() { if(confirm("Yakin ingin keluar dari akun?")) { localStorage.removeItem('active_session'); window.location.href = 'login.html'; } }

document.getElementById('change-avatar-input').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const MAX_SIZE = 250;
            let width = img.width;
            let height = img.height;
            if (width > height) { if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; } } 
            else { if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; } }
            canvas.width = width; canvas.height = height; ctx.drawImage(img, 0, 0, width, height);
            const base64 = canvas.toDataURL('image/jpeg', 0.8);
            db.ref('users/' + myUsername).update({ avatar: base64 }).then(() => {
                alert("Foto profil berhasil diperbarui ke Satelit!");
            });
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
});

document.getElementById('upload-post-input').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if(!file) return;
    const grid = document.getElementById('post-grid');
    const newItem = document.createElement('div');
    newItem.className = 'grid-item';
    const fileURL = URL.createObjectURL(file);
    if(file.type.startsWith('video/')) { newItem.innerHTML = `<video src="${fileURL}" autoplay loop muted></video>`; } 
    else { newItem.innerHTML = `<img src="${fileURL}">`; }
    grid.prepend(newItem); 
});

// ================================================
// FUNGSI MENU AKSI CHAT
// ================================================
function bukaMenuAksi(chatElement, nama) {
    currentSelectedChat = chatElement;
    document.getElementById('action-chat-title').textContent = nama;
    const isPinned = chatElement.parentElement.id === 'pinned-chats';
    const isArchived = chatElement.parentElement.id === 'archived-chats';
    const btnSematkan = document.getElementById('btn-action-sematkan');
    const btnArsip = document.getElementById('btn-action-arsipkan');
    
    btnSematkan.innerHTML = isPinned ? "<i class='bx bx-pin' style='color:#8696a0'></i> Lepaskan Sematan" : "<i class='bx bxs-pin'></i> Sematkan";
    if (isArchived) { btnArsip.innerHTML = "<i class='bx bx-archive-out'></i> Lepas Arsipkan"; } 
    else { btnArsip.innerHTML = "<i class='bx bx-archive-in'></i> Arsipkan"; }

    openModal('modal-chat-action');
}

function actionSematkan() {
    const isPinned = currentSelectedChat.parentElement.id === 'pinned-chats';
    if (isPinned) {
        currentSelectedChat.querySelector('.pinned-icon').classList.add('hidden');
        document.getElementById('regular-chats').prepend(currentSelectedChat);
        pinnedCount--;
    } else {
        if (pinnedCount >= 3) { alert("Maksimal hanya bisa menyematkan 3 obrolan!"); closeModals(); return; }
        currentSelectedChat.querySelector('.pinned-icon').classList.remove('hidden');
        document.getElementById('pinned-chats').prepend(currentSelectedChat);
        pinnedCount++;
    }
    document.getElementById('pin-count').textContent = pinnedCount;
    closeModals();
}

function actionArsipkan() {
    const isArchived = currentSelectedChat.parentElement.id === 'archived-chats';
    if (isArchived) {
        document.getElementById('regular-chats').prepend(currentSelectedChat);
        arsipCount--;
    } else {
        document.getElementById('archived-chats').prepend(currentSelectedChat);
        document.getElementById('arsip-btn-container').classList.remove('hidden');
        arsipCount++;
    }
    document.getElementById('arsip-count').textContent = arsipCount;
    if (arsipCount <= 0) {
        document.getElementById('arsip-btn-container').classList.add('hidden');
        document.getElementById('archived-chats').classList.add('hidden');
    }
    closeModals();
}

function actionHapus() {
    if (confirm("Yakin ingin menghapus obrolan ini? Riwayat chat akan hilang permanen untuk Anda.")) {
        const nama = document.getElementById('action-chat-title').textContent;
        const target = nama.replace('@', '').toLowerCase();
        if (typeof getPairKey === 'function') {
            const pairKey = getPairKey(myUsername, target);
            db.ref('chats/' + pairKey).remove();
        }
        db.ref('chats_index/' + myUsername + '/' + target).remove();
        const wasInRegular = currentSelectedChat.parentElement.id === 'regular-chats';
        currentSelectedChat.remove();
        if (wasInRegular && document.getElementById('regular-chats').children.length === 0) {
            document.getElementById('chat-empty-state').style.display = 'block';
        }
    }
    closeModals();
}

function toggleArsip() { document.getElementById('archived-chats').classList.toggle('hidden'); }

function sematkanDariMenu() {
    headerDropdown.classList.add('hidden');
    alert("Tahan (long press) salah satu obrolan di daftar untuk menyematkannya. Maksimal 3 obrolan.");
}

function bukaProfilDariChat() {
    if (window.activeChatTarget) {
        tutupChatRoom();
        bukaProfilUser(window.activeChatTarget);
    }
}

// ================================================
// VERIFIKASI AKUN AMAN (USER)
// ================================================
function bukaVerifikasiAman() {
    const content = document.getElementById('verifikasi-aman-content');
    content.innerHTML = `<p style="text-align:center; padding:30px 0; color:#8696a0;">Memuat status...</p>`;
    openModal('modal-verifikasi-aman');

    db.ref('users/' + myUsername).once('value').then(snap => {
        const data = snap.val() || {};
        const now = Date.now();
        const tigaHariMs = 3 * 24 * 60 * 60 * 1000;

        if (data.verified === true) {
            content.innerHTML = `
                <h3 style="text-align:center; color:#22c55e;">Akun Sudah Terverifikasi</h3>
                <p class="verification-text-para" style="text-align:center;">Akun Anda sudah terverifikasi sebagai akun aman ✅</p>
                <button class="btn-primary" onclick="closeModals()" style="width:100%; border-radius:20px; background:#22c55e;">OK</button>`;
            return;
        }

        if (data.verif_status === 'pending') {
            content.innerHTML = `
                <h3 style="text-align:center;">Sedang Ditinjau</h3>
                <p class="verification-text-para" style="text-align:center;">Permintaan verifikasi akun Anda sedang ditinjau oleh Owner. Mohon tunggu konfirmasi.</p>
                <button class="btn-primary" onclick="closeModals()" style="width:100%; border-radius:20px;">OK</button>`;
            return;
        }

        if (data.verif_status === 'rejected') {
            const sisaMs = (data.verif_reject_time || 0) + tigaHariMs - now;
            if (sisaMs > 0) {
                const sisaHari = Math.ceil(sisaMs / (24 * 60 * 60 * 1000));
                content.innerHTML = `
                    <h3 style="text-align:center; color:#ef4444;">Verifikasi Gagal</h3>
                    <p class="verification-text-para" style="text-align:center;">Akun gagal terverifikasi karena umur dan identitas tidak memenuhi jaminan kami. Mohon ulangi lagi selama 3 hari. (Sisa ${sisaHari} hari)</p>
                    <button class="btn-primary" onclick="closeModals()" style="width:100%; border-radius:20px;">OK</button>`;
                return;
            }
        }

        content.innerHTML = `
            <h3 style="text-align:center;">Verifikasi Akun Aman</h3>
            <p class="verification-text-para" style="text-align:center;">Verifikasi akun aman untuk mendapatkan Lencana icon hijau terverifikasi ✅ untuk menandai bahwa akun Anda aman dan akun akan lebih diprioritaskan ke amanannya.</p>
            <div class="modal-actions" style="justify-content:center; gap:15px;">
                <button class="btn-cancel" onclick="closeModals()">Tidak</button>
                <button class="btn-primary" onclick="mulaiSelfieVerifikasi()" style="background:#22c55e;">Verifikasi</button>
            </div>`;
    });
}

// ================================================
// CAPTURE SELFIE 3 LANGKAH
// ================================================
let selfieStream = null;
let selfiePhotos = [];
let selfieStep = 0;
const selfieLangkah = ["Hadapkan wajah lurus ke kamera", "Hadapkan wajah ke arah KIRI", "Hadapkan wajah ke arah KANAN"];

function mulaiSelfieVerifikasi() {
    closeModals();
    selfiePhotos = [];
    selfieStep = 0;
    document.getElementById('selfie-overlay').classList.remove('hidden');
    document.getElementById('selfie-instruksi').textContent = selfieLangkah[0];
    document.getElementById('selfie-action-btn').textContent = 'Ambil Foto';
    document.getElementById('selfie-action-btn').setAttribute('onclick', 'ambilFotoSelfie()');
    document.getElementById('selfie-thumbs').innerHTML = '';

    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } }).then(stream => {
        selfieStream = stream;
        document.getElementById('selfie-video').srcObject = stream;
    }).catch(() => {
        alert("Gagal mengakses kamera depan. Pastikan izin kamera diaktifkan di browser.");
        batalSelfie();
    });
}

function ambilFotoSelfie() {
    const video = document.getElementById('selfie-video');
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 480;
    canvas.height = video.videoHeight || 640;
    const ctx = canvas.getContext('2d');
    ctx.translate(canvas.width, 0); ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const foto = canvas.toDataURL('image/jpeg', 0.7);
    selfiePhotos.push(foto);

    const thumb = document.createElement('img');
    thumb.src = foto;
    document.getElementById('selfie-thumbs').appendChild(thumb);

    selfieStep++;
    if (selfieStep < 3) {
        document.getElementById('selfie-instruksi').textContent = selfieLangkah[selfieStep];
    } else {
        document.getElementById('selfie-instruksi').textContent = "Semua foto terambil. Siap dikirim?";
        document.getElementById('selfie-action-btn').textContent = 'Kirim';
        document.getElementById('selfie-action-btn').setAttribute('onclick', 'kirimVerifikasiSelfie()');
    }
}

function batalSelfie() {
    if (selfieStream) { selfieStream.getTracks().forEach(t => t.stop()); selfieStream = null; }
    document.getElementById('selfie-overlay').classList.add('hidden');
}

function kirimVerifikasiSelfie() {
    db.ref('users/' + myUsername).update({
        verif_status: 'pending',
        verif_photos: selfiePhotos
    }).then(() => {
        db.ref('verif_requests/' + myUsername).set({ time: Date.now(), photos: selfiePhotos });
        batalSelfie();
        alert("Permintaan verifikasi terkirim! Mohon tunggu peninjauan dari Owner.");
    });
}

// ================================================
// VERIFIKASI 2 LANGKAH
// ================================================
function bukaVerifikasi2Step() {
    document.getElementById('confirm-pass-input').value = '';
    openModal('modal-confirm-password');
}

function prosesKonfirmasiPassword() {
    const inputPass = document.getElementById('confirm-pass-input').value;
    if (!inputPass) { alert("Masukkan password Anda."); return; }

    db.ref('users/' + myUsername).once('value').then(snap => {
        const data = snap.val() || {};
        if (data.password === inputPass) {
            window.location.href = 'verifikasi2.html';
        } else {
            alert("Password salah! Silakan coba lagi.");
        }
    });
}

// ================================================
// SEARCH BAR
// ================================================
function toggleSearchBar() {
    document.getElementById('search-bar-box').classList.remove('hidden');
    document.getElementById('search-toggle-btn').classList.add('hidden');
    document.getElementById('search-input').focus();
}

function tutupSearchBar() {
    document.getElementById('search-bar-box').classList.add('hidden');
    document.getElementById('search-toggle-btn').classList.remove('hidden');
    document.getElementById('search-input').value = "";
    document.getElementById('search-result-box').classList.add('hidden');
    document.getElementById('search-result-box').innerHTML = "";
}

function cariUsername(keyword) {
    const box = document.getElementById('search-result-box');
    let clean = keyword.trim().replace('@', '').toLowerCase();

    if (clean === "") { box.classList.add('hidden'); box.innerHTML = ""; return; }

    db.ref('users').once('value').then(snap => {
        const data = snap.val() || {};
        const cocok = Object.keys(data).filter(u => u.includes(clean));

        if (cocok.length === 0) {
            box.innerHTML = `<div style="padding:15px; text-align:center; color:#8696a0;">Username tidak ditemukan.</div>`;
        } else {
            box.innerHTML = "";
            cocok.forEach(u => {
                const item = document.createElement('div');
                item.style = "display:flex; align-items:center; gap:10px; padding:12px 15px; cursor:pointer; border-bottom:1px solid #2a3942;";
                let icon = data[u].avatar ? `<img src="${data[u].avatar}" style="width:38px; height:38px; border-radius:50%; object-fit:cover;">` : `<div style="width:38px; height:38px; border-radius:50%; background:#2a3942; display:flex; align-items:center; justify-content:center;"><i class='bx bx-user'></i></div>`;
                item.innerHTML = `${icon}<span>@${u}</span>`;
                item.onclick = function() {
                    tutupSearchBar();
                    bukaProfilUser(u);
                };
                box.appendChild(item);
            });
        }
        box.classList.remove('hidden');
    });
}
