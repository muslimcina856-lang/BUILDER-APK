# Chat App — Flutter WebView Wrapper

Project ini membungkus website kamu (login.html, dashboard.html, dll) menjadi
aplikasi Android (APK) menggunakan Flutter + WebView.

⚠️ PENTING: Saya tidak bisa compile APK langsung di sini karena environment
ini tidak punya Flutter SDK dan tidak ada akses internet. Project ini sudah
lengkap dan tinggal kamu build sendiri di laptop/PC kamu yang sudah terinstall
Flutter SDK. Caranya gampang, ikuti langkah di bawah.

---

## 📁 Struktur Project

```
flutter_app/
├── lib/
│   └── main.dart              ← kode utama (WebView wrapper)
├── assets/
│   ├── web/                   ← semua file HTML/CSS/JS kamu
│   │   ├── login.html         ← halaman pertama yang dibuka
│   │   ├── dashboard.html
│   │   ├── verif.html
│   │   ├── verifikasi2.html
│   │   ├── woun.html
│   │   ├── style.css
│   │   ├── seting.js
│   │   ├── emoji.js
│   │   ├── simpan.js
│   │   └── database.js
│   ├── icon/
│   │   └── icon.png           ← GANTI dengan logo app kamu (1024x1024 px)
│   └── splash/
│       └── splash.png         ← GANTI dengan gambar loading kamu
├── android/                   ← konfigurasi native Android
└── pubspec.yaml                ← daftar dependency Flutter
```

## 🔄 Urutan Halaman (sudah otomatis)

1. App dibuka → tampil **login.html** (Login / Register / Setup Profil / Verifikasi 2 Langkah)
2. Setelah login sukses → redirect otomatis ke **dashboard.html**
3. Dari dashboard, owner bisa buka **verif.html** (kelola verifikasi), **woun.html** (dompet), dll — sesuai logika asli di file JS kamu, tidak diubah sama sekali.

Semua navigasi `window.location.href = '...'` di kode asli kamu tetap jalan
normal karena semua file disalin ke satu folder yang sama di HP user.

---

## 🛠️ Cara Build APK (di laptop/PC kamu)

### 1. Install Flutter SDK
Download dari https://docs.flutter.dev/get-started/install lalu jalankan:
```bash
flutter doctor
```
Pastikan semua centang hijau (terutama Android toolchain).

### 2. Ganti Icon & Splash Screen (opsional, custom gambar app)
- Ganti `assets/icon/icon.png` dengan logo app kamu (ukuran 1024x1024 px, format PNG)
- Ganti `assets/splash/splash.png` dengan gambar loading kamu (disarankan persegi, background transparan/sesuai warna `#0b0f14`)

### 3. Install dependency
Masuk ke folder project lewat terminal:
```bash
cd flutter_app
flutter pub get
```

### 4. Generate Icon & Splash Screen
```bash
flutter pub run flutter_launcher_icons
flutter pub run flutter_native_splash:create
```

### 5. Build APK
```bash
flutter build apk --release
```

APK hasil build akan ada di:
```
build/app/outputs/flutter-apk/app-release.apk
```

Tinggal kirim/install file `app-release.apk` itu ke HP Android.

---

## ⚙️ Custom Lain-lain

- **Nama App**: edit `android:label="Chat App"` di file
  `android/app/src/main/AndroidManifest.xml`
- **Package/Application ID**: edit `applicationId "com.chatapp.webview"` di
  file `android/app/build.gradle` (ganti jadi `com.namakamu.aplikasimu`)
- **Warna splash screen**: edit `color: "#0b0f14"` di `pubspec.yaml`
  bagian `flutter_native_splash`

---

## ❗ Catatan Penting

- App ini butuh **koneksi internet** karena terhubung ke Firebase
  (lewat `database.js`). Izin internet sudah otomatis ditambahkan di
  AndroidManifest.
- Semua fitur (login, register, chat, verifikasi, woun/dompet, dll) **tidak
  diubah sama sekali** — Flutter di sini hanya bertugas sebagai "pembungkus"
  (WebView) agar website kamu bisa dipasang sebagai APK biasa.
- Tombol back HP akan otomatis kembali ke halaman sebelumnya di dalam app
  (misal dari dashboard balik ke login), bukan langsung keluar aplikasi.
