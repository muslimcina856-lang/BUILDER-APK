import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'INFERNAL',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF0b0f14),
      ),
      home: const WebViewScreen(),
    );
  }
}

enum _LoadState { loading, ready, error }

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  WebViewController? _controller;
  _LoadState _state = _LoadState.loading;
  String _errorMessage = '';
  Timer? _timeoutTimer;
  DateTime? _lastBackPress;
  String? _webDirPath;

  // Halaman pertama yang dibuka saat app dijalankan,
  // dan halaman "hub" utama yang jadi pusat navigasi.
  static const String startPage = 'login.html';
  static const String hubPage = 'dashboard.html';

  @override
  void initState() {
    super.initState();
    _setupWebView();
  }

  @override
  void dispose() {
    _timeoutTimer?.cancel();
    super.dispose();
  }

  /// Menyalin semua file di assets/web/ ke storage lokal device,
  /// lalu memuat login.html. Dibungkus try/catch + timeout supaya
  /// kalau ada apapun yang gagal, user lihat layar error + tombol
  /// "Coba Lagi" — bukan loading muter selamanya tanpa kejelasan.
  Future<void> _setupWebView() async {
    _timeoutTimer?.cancel();
    setState(() {
      _state = _LoadState.loading;
      _errorMessage = '';
    });

    try {
      final docDir = await getApplicationDocumentsDirectory();
      final webDir = Directory('${docDir.path}/web');
      if (!await webDir.exists()) {
        await webDir.create(recursive: true);
      }
      _webDirPath = webDir.path;

      final manifestJson = await rootBundle.loadString('AssetManifest.json');
      final Map<String, dynamic> manifestMap = json.decode(manifestJson);

      final webAssets =
          manifestMap.keys.where((k) => k.startsWith('assets/web/')).toList();

      if (webAssets.isEmpty) {
        throw Exception(
          'File web (assets/web) tidak ditemukan di dalam aplikasi.',
        );
      }

      for (final assetPath in webAssets) {
        final fileName = assetPath.replaceFirst('assets/web/', '');
        final byteData = await rootBundle.load(assetPath);
        final file = File('${webDir.path}/$fileName');
        await file.writeAsBytes(
          byteData.buffer.asUint8List(
            byteData.offsetInBytes,
            byteData.lengthInBytes,
          ),
        );
      }

      final entryFile = File('${webDir.path}/$startPage');
      if (!await entryFile.exists()) {
        throw Exception('Halaman awal ($startPage) gagal disalin.');
      }

      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF0b0f14))
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageFinished: (_) {
              _timeoutTimer?.cancel();
              if (mounted) setState(() => _state = _LoadState.ready);
            },
            onWebResourceError: (error) {
              // Cuma anggap fatal kalau yang gagal itu halaman utamanya,
              // bukan resource kecil (gambar/font luar) yang gagal dimuat.
              if (error.isForMainFrame ?? true) {
                _timeoutTimer?.cancel();
                if (mounted) {
                  setState(() {
                    _state = _LoadState.error;
                    _errorMessage =
                        'Gagal memuat halaman: ${error.description}';
                  });
                }
              }
            },
          ),
        )
        ..loadFile(entryFile.path);

      // Jaring pengaman: kalau onPageFinished tidak pernah terpanggil
      // (root cause loading-muter-selamanya yang dialami sebelumnya),
      // paksa keluar dari status loading setelah 20 detik.
      _timeoutTimer = Timer(const Duration(seconds: 20), () {
        if (mounted && _state == _LoadState.loading) {
          setState(() {
            _state = _LoadState.error;
            _errorMessage = 'Halaman terlalu lama merespons.';
          });
        }
      });

      if (mounted) {
        setState(() {
          _controller = controller;
        });
      }
    } catch (e) {
      _timeoutTimer?.cancel();
      if (mounted) {
        setState(() {
          _state = _LoadState.error;
          _errorMessage = e.toString();
        });
      }
    }
  }

  /// Logika tombol back yang baru:
  /// - Dari halaman manapun selain dashboard -> langsung balik ke
  ///   dashboard.html (hub utama), bukan pakai goBack() bawaan WebView.
  ///   goBack() bawaan tidak cocok di sini karena tiap halaman pakai
  ///   full page navigation (window.location.href), jadi history-nya
  ///   gampang berantakan dan bikin alur back jadi tidak terduga.
  /// - Di dashboard/login -> tekan back 2x dalam 2 detik untuk keluar.
  Future<bool> _handleBack() async {
    if (_controller == null || _webDirPath == null) return true;

    final currentUrl = await _controller!.currentUrl() ?? '';

    if (!currentUrl.endsWith(hubPage) && !currentUrl.endsWith(startPage)) {
      _controller!.loadFile('$_webDirPath/$hubPage');
      return false;
    }

    final now = DateTime.now();
    if (_lastBackPress == null ||
        now.difference(_lastBackPress!) > const Duration(seconds: 2)) {
      _lastBackPress = now;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tekan sekali lagi untuk keluar'),
            duration: Duration(seconds: 2),
            backgroundColor: Color(0xFF202c33),
          ),
        );
      }
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _handleBack,
      child: Scaffold(
        backgroundColor: const Color(0xFF0b0f14),
        body: SafeArea(
          child: Stack(
            children: [
              if (_controller != null)
                WebViewWidget(controller: _controller!),
              if (_state == _LoadState.loading)
                const Center(
                  child: CircularProgressIndicator(color: Color(0xFF00a884)),
                ),
              if (_state == _LoadState.error) _buildErrorView(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorView() {
    return Container(
      color: const Color(0xFF0b0f14),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.wifi_off_rounded, color: Colors.white54, size: 48),
          const SizedBox(height: 16),
          const Text(
            'Gagal memuat aplikasi',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _errorMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white54, fontSize: 13),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _setupWebView,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00a884),
            ),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              child: Text('Coba Lagi', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}
