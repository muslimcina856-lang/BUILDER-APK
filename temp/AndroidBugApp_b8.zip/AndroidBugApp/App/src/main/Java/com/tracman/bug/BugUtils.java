package com.tracman.bug;
public class BugUtils {
    public static void doNothing() {}
}