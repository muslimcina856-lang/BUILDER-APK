Rakku Play Android WebView Project - Java 8 Compatible

Ini versi khusus untuk builder Telegram yang masih memakai Java 8.

Penyebab error sebelumnya:
AGP 8.5.2 butuh Java 11+, sedangkan builder kamu pakai Java 8.
Versi ini sudah diturunkan ke Android Gradle Plugin 4.2.2 agar cocok dengan Java 8.

Cara pakai:
1. Upload ZIP ini ke bot/build app Telegram yang menerima Android Studio/Gradle project.
2. Build APK.
3. Install APK.

URL web yang dibuka app:
https://rakkumusic.vercel.app

Kalau URL Vercel kamu beda, edit:
app/src/main/res/values/strings.xml

Ganti:
<string name="app_url">https://rakkumusic.vercel.app</string>

Catatan:
- Ini APK wrapper WebView bersih, tanpa iklan/watermark.
- Semua fitur web tetap dari URL Vercel kamu.
- Download audio mengikuti fitur dari web.
- Jika ingin background audio sekuat Spotify saat app ditutup total, itu butuh native foreground service.
