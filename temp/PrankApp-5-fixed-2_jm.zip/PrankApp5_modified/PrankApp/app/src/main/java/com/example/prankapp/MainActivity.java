package com.example.prankapp;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GestureDetectorCompat;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {

    private RelativeLayout root;
    private TextView mainText, subText, icon, swipeInstruction, swipeArrow;
    private Handler handler = new Handler(Looper.getMainLooper());

    private boolean[] flickerState = {true};
    private final int FLICKER_DURATION_MS = 3000;
    private final int FLICKER_INTERVAL_MS = 150;

    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean hasFlash = false;
    private Runnable flickerRunnableRef;

    // Swipe + tahan
    private boolean isSwiping = false;
    private boolean swipeUnlockTriggered = false;
    private Runnable swipeHoldRunnable;
    private final long HOLD_DURATION_MS = 1500;
    private float swipeStartY = 0f;

    // Volume ramp
    private Runnable volumeRampRunnable;
    private int currentVolume = 0;
    private final int VOLUME_RAMP_STEP_MS = 700;

    private GestureDetectorCompat gestureDetector;

    private static final int REQUEST_CAMERA = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Layar penuh terang
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = 1.0f;
        getWindow().setAttributes(lp);

        root = findViewById(R.id.root_layout);
        mainText = findViewById(R.id.main_text);
        subText = findViewById(R.id.sub_text);
        icon = findViewById(R.id.warning_icon);
        swipeInstruction = findViewById(R.id.swipe_instruction);
        swipeArrow = findViewById(R.id.swipe_arrow);

        gestureDetector = new GestureDetectorCompat(this, this);

        // Vibrate
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(800);
                }
            }
        } catch (Exception ignored) {}

        // Minta permission camera dulu, baru setup flash
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            setupFlashlight();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA);
        }

        // Start background service
        try {
            Intent serviceIntent = new Intent(this, AlarmService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception ignored) {}

        startVolumeRamp();
        playAlarmSound();
        startFlicker();

        // Flash blink hanya kalau ada flash
        if (hasFlash) startFlashBlink();

        handler.postDelayed(this::revealSwipeScreen, FLICKER_DURATION_MS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupFlashlight();
                if (hasFlash) startFlashBlink();
            }
            // Kalau ditolak, app tetap jalan tanpa flash — tidak crash
        }
    }

    // ===================== VOLUME RAMP-UP =====================
    private void startVolumeRamp() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            currentVolume = 0;
            am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);

            volumeRampRunnable = new Runnable() {
                @Override
                public void run() {
                    if (currentVolume < max) {
                        currentVolume++;
                        am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);
                        handler.postDelayed(this, VOLUME_RAMP_STEP_MS);
                    }
                }
            };
            handler.postDelayed(volumeRampRunnable, VOLUME_RAMP_STEP_MS);
        } catch (Exception ignored) {}
    }

    private void stopVolumeRamp() {
        if (volumeRampRunnable != null) {
            handler.removeCallbacks(volumeRampRunnable);
            volumeRampRunnable = null;
        }
    }

    // ===================== ALARM SOUND =====================
    private void playAlarmSound() {
        try {
            Uri alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
            if (alarmUri == null)
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION);
            if (alarmUri == null)
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE);
            if (alarmUri == null) return;

            mediaPlayer = new MediaPlayer();

            // Guna AudioAttributes (cara baru, tak deprecated)
            if (Build.VERSION.SDK_INT >= 21) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                mediaPlayer.setAudioAttributes(attrs);
            } else {
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
            }

            mediaPlayer.setDataSource(this, alarmUri);
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception ignored) {}
    }

    private void stopAlarmSound() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception ignored) {}
    }

    // ===================== FLASHLIGHT =====================
    private void setupFlashlight() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager == null) return;
            for (String id : cameraManager.getCameraIdList()) {
                Boolean flashAvailable = cameraManager.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flashAvailable != null && flashAvailable) {
                    cameraId = id;
                    hasFlash = true;
                    break;
                }
            }
        } catch (Exception ignored) {}
    }

    private void setFlash(boolean on) {
        if (!hasFlash || cameraManager == null || cameraId == null) return;
        try {
            cameraManager.setTorchMode(cameraId, on);
        } catch (Exception ignored) {}
    }

    private void startFlashBlink() {
        Runnable flashRunnable = new Runnable() {
            boolean on = false;
            @Override
            public void run() {
                on = !on;
                setFlash(on);
                if (flickerRunnableRef != null) {
                    handler.postDelayed(this, FLICKER_INTERVAL_MS);
                } else {
                    setFlash(false);
                }
            }
        };
        handler.post(flashRunnable);
    }

    // ===================== FLICKER LAYAR =====================
    private void startFlicker() {
        Runnable flickerRunnable = new Runnable() {
            @Override
            public void run() {
                root.setBackgroundColor(flickerState[0]
                        ? Color.parseColor("#B71C1C")
                        : Color.parseColor("#FF1744"));
                flickerState[0] = !flickerState[0];
                handler.postDelayed(this, FLICKER_INTERVAL_MS);
            }
        };
        handler.post(flickerRunnable);
        flickerRunnableRef = flickerRunnable;
    }

    // ===================== LAYAR KUNCI =====================
    private void revealSwipeScreen() {
        if (flickerRunnableRef != null) {
            handler.removeCallbacks(flickerRunnableRef);
            flickerRunnableRef = null;
        }
        setFlash(false);
        stopAlarmSound();
        stopVolumeRamp();

        root.setBackgroundColor(Color.parseColor("#1A1A1A"));
        icon.setText("🔒");
        mainText.setText("Terkunci");
        subText.setText("APK ini sedang disemak untuk membuka, geser ke atas dan tahan");
        swipeInstruction.setText("↑ Geser ke Atas & Tahan ↑");
        swipeInstruction.setVisibility(View.VISIBLE);
        swipeArrow.setVisibility(View.VISIBLE);
    }

    // ===================== TOUCH =====================
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                swipeStartY = event.getY();
                isSwiping = false;
                break;
            case MotionEvent.ACTION_MOVE:
                float dy = swipeStartY - event.getY();
                if (dy > 100 && !isSwiping && !swipeUnlockTriggered) {
                    isSwiping = true;
                    swipeHoldRunnable = () -> {
                        if (isSwiping && !swipeUnlockTriggered) {
                            swipeUnlockTriggered = true;
                            unlockScreen();
                        }
                    };
                    handler.postDelayed(swipeHoldRunnable, HOLD_DURATION_MS);
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (swipeHoldRunnable != null && !swipeUnlockTriggered) {
                    handler.removeCallbacks(swipeHoldRunnable);
                    swipeHoldRunnable = null;
                }
                isSwiping = false;
                break;
        }
        return true;
    }

    @Override public boolean onDown(MotionEvent e) { return true; }
    @Override public void onShowPress(MotionEvent e) {}
    @Override public boolean onSingleTapUp(MotionEvent e) { return false; }
    @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dX, float dY) { return false; }
    @Override public void onLongPress(MotionEvent e) {}
    @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float velX, float velY) { return true; }

    // ===================== UNLOCK =====================
    private void unlockScreen() {
        root.setBackgroundColor(Color.parseColor("#2E7D32"));
        icon.setText("😂");
        mainText.setText("JK! Cuma Prank!");
        subText.setText("Santai, HP kamu aman kok 😄");
        swipeInstruction.setVisibility(View.GONE);
        swipeArrow.setVisibility(View.GONE);
        handler.postDelayed(this::finish, 2000);
    }

    @Override
    public void onBackPressed() {
        if (swipeUnlockTriggered) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setFlash(false);
        stopAlarmSound();
        stopVolumeRamp();
        handler.removeCallbacksAndMessages(null);
    }
}
