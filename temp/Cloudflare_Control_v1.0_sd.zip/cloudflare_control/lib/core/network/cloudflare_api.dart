import 'package:dio/dio.dart';
import '../../models/cloudflare_account.dart';

class CloudflareApi {
  final Dio _dio;
  final CloudflareAccount account;

  CloudflareApi(this.account)
      : _dio = Dio(BaseOptions(
          baseUrl: 'https://api.cloudflare.com/client/v4',
          headers: {
            'Authorization': 'Bearer ${account.token}',
            'Content-Type': 'application/json',
          },
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 30),
        ));

  // ==================== ACCOUNT ====================
  Future<Map<String, dynamic>> getUser() async {
    final res = await _dio.get('/user');
    return res.data['result'] ?? {};
  }

  Future<List<dynamic>> getAccounts() async {
    final res = await _dio.get('/accounts');
    return res.data['result'] ?? [];
  }

  // ==================== ZONES ====================
  Future<List<dynamic>> getZones() async {
    final res = await _dio.get('/zones', queryParameters: {'per_page': 50});
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> getZone(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> createZone(String name, {bool jumpStart = true}) async {
    final res = await _dio.post('/zones', data: {
      'name': name,
      'account': {'id': account.id},
      'jump_start': jumpStart,
      'type': 'full',
    });
    return res.data['result'] ?? {};
  }

  Future<void> deleteZone(String zoneId) async {
    await _dio.delete('/zones/$zoneId');
  }

  // ==================== DNS RECORDS ====================
  Future<List<dynamic>> getDnsRecords(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/dns_records', queryParameters: {'per_page': 100});
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createDnsRecord(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.post('/zones/$zoneId/dns_records', data: data);
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateDnsRecord(String zoneId, String recordId, Map<String, dynamic> data) async {
    final res = await _dio.put('/zones/$zoneId/dns_records/$recordId', data: data);
    return res.data['result'] ?? {};
  }

  Future<void> deleteDnsRecord(String zoneId, String recordId) async {
    await _dio.delete('/zones/$zoneId/dns_records/$recordId');
  }

  // ==================== ZONE SETTINGS ====================
  Future<Map<String, dynamic>> getZoneSetting(String zoneId, String settingId) async {
    final res = await _dio.get('/zones/$zoneId/settings/$settingId');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateZoneSetting(String zoneId, String settingId, dynamic value) async {
    final res = await _dio.patch('/zones/$zoneId/settings/$settingId', data: {'value': value});
    return res.data['result'] ?? {};
  }

  // ==================== PURGE CACHE ====================
  Future<void> purgeEverything(String zoneId) async {
    await _dio.post('/zones/$zoneId/purge_cache', data: {'purge_everything': true});
  }

  Future<void> purgeUrls(String zoneId, List<String> urls) async {
    await _dio.post('/zones/$zoneId/purge_cache', data: {'files': urls});
  }

  // ==================== EMAIL ROUTING ====================
  Future<Map<String, dynamic>> getEmailRoutingSettings(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing');
    return res.data['result'] ?? {};
  }

  Future<List<dynamic>> getEmailRoutingRules(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing/rules');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createEmailRoutingRule(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.post('/zones/$zoneId/email/routing/rules', data: data);
    return res.data['result'] ?? {};
  }

  Future<void> deleteEmailRoutingRule(String zoneId, String ruleId) async {
    await _dio.delete('/zones/$zoneId/email/routing/rules/$ruleId');
  }

  Future<List<dynamic>> getEmailDestinationAddresses() async {
    final res = await _dio.get('/accounts/${account.id}/email/routing/addresses');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createEmailDestinationAddress(String email) async {
    final res = await _dio.post('/accounts/${account.id}/email/routing/addresses', data: {
      'email': email,
    });
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> getCatchAll(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/email/routing/rules/catch_all');
    return res.data['result'] ?? {};
  }

  Future<Map<String, dynamic>> updateCatchAll(String zoneId, Map<String, dynamic> data) async {
    final res = await _dio.put('/zones/$zoneId/email/routing/rules/catch_all', data: data);
    return res.data['result'] ?? {};
  }

  // ==================== WORKERS ====================
  Future<List<dynamic>> getWorkers() async {
    final res = await _dio.get('/accounts/${account.id}/workers/scripts');
    return res.data['result'] ?? [];
  }

  // ==================== PAGES ====================
  Future<List<dynamic>> getPagesProjects() async {
    final res = await _dio.get('/accounts/${account.id}/pages/projects');
    return res.data['result'] ?? [];
  }

  // ==================== R2 ====================
  Future<List<dynamic>> getR2Buckets() async {
    final res = await _dio.get('/accounts/${account.id}/r2/buckets');
    return res.data['result']?['buckets'] ?? [];
  }

  Future<Map<String, dynamic>> createR2Bucket(String name) async {
    final res = await _dio.post('/accounts/${account.id}/r2/buckets', data: {'name': name});
    return res.data['result'] ?? {};
  }

  Future<void> deleteR2Bucket(String name) async {
    await _dio.delete('/accounts/${account.id}/r2/buckets/$name');
  }

  // ==================== KV ====================
  Future<List<dynamic>> getKvNamespaces() async {
    final res = await _dio.get('/accounts/${account.id}/storage/kv/namespaces');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createKvNamespace(String title) async {
    final res = await _dio.post('/accounts/${account.id}/storage/kv/namespaces', data: {'title': title});
    return res.data['result'] ?? {};
  }

  // ==================== FIREWALL IP ACCESS RULES ====================
  Future<List<dynamic>> getIpAccessRules(String zoneId) async {
    final res = await _dio.get('/zones/$zoneId/firewall/access_rules/rules');
    return res.data['result'] ?? [];
  }

  Future<Map<String, dynamic>> createIpAccessRule(String zoneId, String mode, String value, {String? notes}) async {
    final res = await _dio.post('/zones/$zoneId/firewall/access_rules/rules', data: {
      'mode': mode,
      'configuration': {'target': 'ip', 'value': value},
      if (notes != null) 'notes': notes,
    });
    return res.data['result'] ?? {};
  }

  Future<void> deleteIpAccessRule(String zoneId, String ruleId) async {
    await _dio.delete('/zones/$zoneId/firewall/access_rules/rules/$ruleId');
  }
}
