class CloudflareAccount {
  final String id;          // Account ID
  final String email;       // Email of the account
  final String token;       // Global API Key (encrypted in storage)
  final String? name;
  final DateTime addedAt;
  final bool notificationsEnabled;

  const CloudflareAccount({
    required this.id,
    required this.email,
    required this.token,
    this.name,
    required this.addedAt,
    this.notificationsEnabled = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'token': token,
        'name': name,
        'addedAt': addedAt.toIso8601String(),
        'notificationsEnabled': notificationsEnabled,
      };

  factory CloudflareAccount.fromJson(Map<String, dynamic> json) {
    return CloudflareAccount(
      id: json['id'] as String,
      email: json['email'] as String,
      token: json['token'] as String,
      name: json['name'] as String?,
      addedAt: DateTime.parse(json['addedAt'] as String),
      notificationsEnabled: json['notificationsEnabled'] as bool? ?? false,
    );
  }

  CloudflareAccount copyWith({
    bool? notificationsEnabled,
    String? name,
  }) {
    return CloudflareAccount(
      id: id,
      email: email,
      token: token,
      name: name ?? this.name,
      addedAt: addedAt,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    );
  }
}
