import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';

import '../models/cloudflare_account.dart';

class AppController extends ChangeNotifier {
  final _secureStorage = const FlutterSecureStorage();
  static const _accountsKey = 'cf_accounts';
  static const _localeKey = 'app_locale';
  static const _activeAccountKey = 'active_account_id';

  bool isInitialized = false;
  Locale? locale;
  List<CloudflareAccount> accounts = [];
  String? activeAccountId;
  bool loading = false;
  String? error;

  CloudflareAccount? get activeAccount {
    if (activeAccountId == null) return accounts.isNotEmpty ? accounts.first : null;
    try {
      return accounts.firstWhere((a) => a.id == activeAccountId);
    } catch (_) {
      return accounts.isNotEmpty ? accounts.first : null;
    }
  }

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final lang = prefs.getString(_localeKey);
    if (lang != null) {
      locale = Locale(lang);
    }

    final raw = await _secureStorage.read(key: _accountsKey);
    if (raw != null && raw.isNotEmpty) {
      final list = jsonDecode(raw) as List;
      accounts = list.map((e) => CloudflareAccount.fromJson(e)).toList();
    }

    activeAccountId = prefs.getString(_activeAccountKey);
    isInitialized = true;
    notifyListeners();
  }

  Future<void> setLocale(Locale newLocale) async {
    locale = newLocale;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localeKey, newLocale.languageCode);
    notifyListeners();
  }

  Future<void> addAccount(String globalApiKey) async {
    loading = true;
    error = null;
    notifyListeners();

    try {
      // Verify the Global API Key by calling Cloudflare API
      final dio = Dio(BaseOptions(
        baseUrl: 'https://api.cloudflare.com/client/v4',
        headers: {
          'Authorization': 'Bearer $globalApiKey',
          'Content-Type': 'application/json',
        },
      ));

      // Get user / account info
      final userRes = await dio.get('/user');
      if (userRes.data['success'] != true) {
        throw Exception('Token tidak sah atau bukan Global API Key');
      }

      final user = userRes.data['result'];
      final email = user['email'] as String? ?? 'unknown@cloudflare.com';
      final accountId = user['id'] as String? ?? '';

      // Check duplicate
      if (accounts.any((a) => a.id == accountId || a.email == email)) {
        throw Exception('Akaun ini sudah ditambah');
      }

      // Get accounts list to confirm
      final accountsRes = await dio.get('/accounts');
      String finalAccountId = accountId;
      if (accountsRes.data['success'] == true) {
        final accList = accountsRes.data['result'] as List;
        if (accList.isNotEmpty) {
          finalAccountId = accList.first['id'] as String;
        }
      }

      final newAccount = CloudflareAccount(
        id: finalAccountId,
        email: email,
        token: globalApiKey,
        name: user['first_name'] != null
            ? '${user['first_name']} ${user['last_name'] ?? ''}'.trim()
            : null,
        addedAt: DateTime.now(),
        notificationsEnabled: false,
      );

      accounts.add(newAccount);
      activeAccountId = newAccount.id;

      await _saveAccounts();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_activeAccountKey, newAccount.id);

      loading = false;
      notifyListeners();
    } catch (e) {
      loading = false;
      error = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      rethrow;
    }
  }

  Future<void> removeAccount(String accountId) async {
    accounts.removeWhere((a) => a.id == accountId);
    if (activeAccountId == accountId) {
      activeAccountId = accounts.isNotEmpty ? accounts.first.id : null;
    }
    await _saveAccounts();
    final prefs = await SharedPreferences.getInstance();
    if (activeAccountId != null) {
      await prefs.setString(_activeAccountKey, activeAccountId!);
    } else {
      await prefs.remove(_activeAccountKey);
    }
    notifyListeners();
  }

  Future<void> setActiveAccount(String accountId) async {
    activeAccountId = accountId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_activeAccountKey, accountId);
    notifyListeners();
  }

  Future<void> toggleNotifications(String accountId, bool value) async {
    final index = accounts.indexWhere((a) => a.id == accountId);
    if (index == -1) return;
    accounts[index] = accounts[index].copyWith(notificationsEnabled: value);
    await _saveAccounts();
    notifyListeners();
  }

  Future<void> clearAllAccounts() async {
    accounts.clear();
    activeAccountId = null;
    await _secureStorage.delete(key: _accountsKey);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_activeAccountKey);
    notifyListeners();
  }

  Future<void> _saveAccounts() async {
    final data = accounts.map((a) => a.toJson()).toList();
    await _secureStorage.write(key: _accountsKey, value: jsonEncode(data));
  }

  // Helper to get Dio for active account
  Dio? getApiClient() {
    final account = activeAccount;
    if (account == null) return null;
    return Dio(BaseOptions(
      baseUrl: 'https://api.cloudflare.com/client/v4',
      headers: {
        'Authorization': 'Bearer ${account.token}',
        'Content-Type': 'application/json',
      },
    ));
  }
}
