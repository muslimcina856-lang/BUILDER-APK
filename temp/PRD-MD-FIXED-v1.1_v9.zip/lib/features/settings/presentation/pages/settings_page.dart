import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../dashboard/presentation/pages/dashboard_page.dart';
import '../bloc/settings_bloc.dart';

class SettingsPage extends StatefulWidget {
  /// True apabila skrin ini dibuka semasa first-run (splash → tiada API key
  /// wujud lagi). Dalam kes ini, selepas kunci API berjaya disimpan dan sah,
  /// Settings akan meneruskan secara automatik ke Dashboard supaya pengguna
  /// tidak terperangkap di skrin Settings.
  ///
  /// False (lalai) apabila dibuka dari ikon gear di Dashboard untuk
  /// mengemaskini tetapan sedia ada — dalam kes ini pengguna kekal di
  /// Settings selepas simpan, seperti biasa.
  final bool isInitialSetup;

  const SettingsPage({super.key, this.isInitialSetup = false});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _apiKeyController = TextEditingController();
  bool _obscureApiKey = true;
  bool _isNavigatingToDashboard = false;

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  void _showBackupDialog(BuildContext context, String backupJson) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Salin Data Sandaran',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Sila salin kod JSON di bawah dan simpan di lokasi selamat. '
                'Anda boleh menggunakannya untuk mengimport semula data pada masa hadapan.',
              ),
              const SizedBox(height: 16),
              Container(
                constraints: const BoxConstraints(maxHeight: 150),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.scaffold,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                child: SingleChildScrollView(
                  child: SelectableText(
                    backupJson,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: backupJson));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Kod sandaran disalin ke clipboard!')),
                );
                Navigator.pop(context);
              },
              child: const Text('Salin Kod'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }

  void _showImportDialog(BuildContext context) {
    final TextEditingController importController = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Import Data Sandaran',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Tampalkan kod JSON sandaran yang telah anda salin sebelum ini. '
                '⚠️ Tindakan ini akan memadam semua data semasa anda!',
              ),
              const SizedBox(height: 16),
              TextField(
                controller: importController,
                maxLines: 5,
                decoration: InputDecoration(
                  hintText: 'Tampal JSON di sini...',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                final String text = importController.text.trim();
                if (text.isNotEmpty) {
                  try {
                    // Quick validation of JSON
                    jsonDecode(text);
                    context.read<SettingsBloc>().add(ImportData(text));
                    Navigator.pop(context);
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Format JSON tidak sah!')),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent),
              child: const Text('Import Sekarang'),
            ),
          ],
        );
      },
    );
  }

  void _confirmDeleteAll(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: AppColors.error),
              SizedBox(width: 8),
              Text('Danger Zone: Padam Semua?'),
            ],
          ),
          content: const Text(
            'Adakah anda benar-benar pasti mahu memadamkan semua rekod sembang, '
            'kunci API, dan tetapan dari peranti secara kekal? Tindakan ini tidak boleh diundurkan.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<SettingsBloc>().add(ClearAllData());
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Ya, Padam Semua'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SettingsBloc, SettingsState>(
      listener: (context, state) {
        if (state is ApiTestResult) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: state.success ? AppColors.success : AppColors.error,
              duration: const Duration(seconds: 4),
            ),
          );
        } else if (state is DataCleared) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Semua data peranti telah dipadamkan secara kekal.'),
              backgroundColor: AppColors.error,
            ),
          );
          _apiKeyController.clear();
        } else if (state is DataBackupResult) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: state.success ? AppColors.success : AppColors.error,
            ),
          );
          if (state.success && state.backupJson != null) {
            _showBackupDialog(context, state.backupJson!);
          }
        } else if (state is SettingsLoaded &&
            widget.isInitialSetup &&
            _isNavigatingToDashboard &&
            state.isApiKeyValid) {
          // Kunci API baru sahaja berjaya disimpan semasa first-run setup.
          // Teruskan secara automatik ke Dashboard supaya pengguna tidak
          // terperangkap di skrin Settings.
          _isNavigatingToDashboard = false;
          Navigator.of(context).pushReplacement(
            MaterialPageRoute<void>(
              builder: (context) => const DashboardPage(),
            ),
          );
        }
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          title: Text(
            AppStrings.titleSettings,
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppColors.scaffold.withOpacity( 0.9),
                  AppColors.scaffold.withOpacity( 0.0),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: BlocBuilder<SettingsBloc, SettingsState>(
            builder: (context, state) {
              String apiKey = '';
              String defaultModel = 'deepseek-v4-flash';
              bool isWebSearchDefault = false;
              bool isDarkMode = true;

              if (state is SettingsLoaded) {
                apiKey = state.apiKey;
                defaultModel = state.defaultModel;
                isWebSearchDefault = state.isWebSearchEnabled;
                isDarkMode = state.isDarkMode;

                if (_apiKeyController.text.isEmpty && apiKey.isNotEmpty) {
                  _apiKeyController.text = apiKey;
                }
              }

              return SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // BYOK Settings Manager Card
                      _buildSectionHeader('DeepSeek API Key (BYOK)', Icons.vpn_key_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          children: [
                            TextField(
                              controller: _apiKeyController,
                              obscureText: _obscureApiKey,
                              style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                              decoration: InputDecoration(
                                labelText: 'Kunci API DeepSeek',
                                hintText: 'Masukkan sk_...',
                                prefixIcon: const Icon(Icons.security, color: AppColors.accent),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    _obscureApiKey ? Icons.visibility_off : Icons.visibility,
                                    color: AppColors.textMuted,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _obscureApiKey = !_obscureApiKey;
                                    });
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    icon: state is SettingsSaving
                                        ? const SizedBox(
                                            width: 16,
                                            height: 16,
                                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                          )
                                        : const Icon(Icons.network_ping, color: AppColors.accent),
                                    label: const Text('Uji Sambungan'),
                                    onPressed: state is SettingsSaving
                                        ? null
                                        : () {
                                            context.read<SettingsBloc>().add(
                                                  TestApiConnection(_apiKeyController.text),
                                                );
                                          },
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: ElevatedButton.icon(
                                    icon: const Icon(Icons.save_rounded),
                                    label: const Text('Simpan'),
                                    onPressed: () {
                                      final String trimmedKey =
                                          _apiKeyController.text.trim();
                                      // Hanya tandakan untuk auto-navigate jika
                                      // ini setup pertama kali DAN kunci tidak kosong.
                                      _isNavigatingToDashboard =
                                          widget.isInitialSetup &&
                                              trimmedKey.isNotEmpty;
                                      context.read<SettingsBloc>().add(
                                            SaveApiKey(_apiKeyController.text),
                                          );
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Kunci API disimpan!')),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Locked Model Switcher Config
                      _buildSectionHeader('Konfigurasi Model Lalai', Icons.psychology_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Pilih model DeepSeek lalai untuk setiap perbualan baru. '
                              'Model ini akan dikunci apabila sembang dimulakan.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                _buildModelOption(
                                  title: 'DeepSeek Flash',
                                  subtitle: 'Pantas & Jimat',
                                  model: 'deepseek-v4-flash',
                                  selected: defaultModel == 'deepseek-v4-flash',
                                  onTap: () {
                                    context.read<SettingsBloc>().add(
                                          const UpdateDefaultModel('deepseek-v4-flash'),
                                        );
                                  },
                                ),
                                const SizedBox(width: 12),
                                _buildModelOption(
                                  title: 'DeepSeek Pro',
                                  subtitle: 'Penaakulan Khas',
                                  model: 'deepseek-v4-pro',
                                  selected: defaultModel == 'deepseek-v4-pro',
                                  onTap: () {
                                    context.read<SettingsBloc>().add(
                                          const UpdateDefaultModel('deepseek-v4-pro'),
                                        );
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Toggles Section
                      _buildSectionHeader('Pilihan Antaramuka', Icons.tune_rounded),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          children: [
                            SwitchListTile(
                              title: const Text('Carian Web Secara Lalai'),
                              subtitle: const Text('Aktifkan carian DuckDuckGo & Yahoo secara automatik'),
                              value: isWebSearchDefault,
                              activeColor: AppColors.accent,
                              contentPadding: EdgeInsets.zero,
                              onChanged: (val) {
                                context.read<SettingsBloc>().add(ToggleWebSearchDefault(val));
                              },
                            ),
                            const Divider(color: AppColors.cardBorder, height: 24),
                            SwitchListTile(
                              title: const Text('Mod Gelap Premium'),
                              subtitle: const Text('Tema visual gelap bertenaga tinggi'),
                              value: isDarkMode,
                              activeColor: AppColors.accent,
                              contentPadding: EdgeInsets.zero,
                              onChanged: (val) {
                                // Default true for this premium app
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Data Management & Backup
                      _buildSectionHeader('Pengurusan Data & Backup', Icons.backup_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const Icon(Icons.download_rounded),
                                label: const Text('Eksport Data'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.card,
                                  foregroundColor: Colors.white,
                                  side: const BorderSide(color: AppColors.cardBorder),
                                ),
                                onPressed: () {
                                  context.read<SettingsBloc>().add(ExportData());
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const Icon(Icons.upload_rounded),
                                label: const Text('Import Data'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.card,
                                  foregroundColor: Colors.white,
                                  side: const BorderSide(color: AppColors.cardBorder),
                                ),
                                onPressed: () => _showImportDialog(context),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Danger Zone Card
                      _buildSectionHeader('Danger Zone', Icons.report_problem_outlined, color: AppColors.error),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        borderColor: AppColors.error.withOpacity( 0.3),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Padamkan semua rekod sembang, kunci API, dan tetapan kustom dari peranti secara kekal.',
                                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                              ),
                            ),
                            const SizedBox(width: 16),
                            ElevatedButton(
                              onPressed: () => _confirmDeleteAll(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.error,
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              ),
                              child: const Text('Padam Semua'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, {Color color = AppColors.textPrimary}) {
    return Row(
      children: [
        Icon(icon, color: color == AppColors.textPrimary ? AppColors.accent : color, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.inter(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: color,
            letterSpacing: 0.5,
          ),
        ),
      ],
    ).animate().fadeIn(duration: 300.ms).slideX(begin: -0.1, end: 0);
  }

  Widget _buildGlassCard({required Widget child, Color borderColor = AppColors.cardBorder}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity( 0.2),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    ).animate().fadeIn(duration: 400.ms).scaleY(begin: 0.9, end: 1.0);
  }

  Widget _buildModelOption({
    required String title,
    required String subtitle,
    required String model,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.accent.withOpacity( 0.15) : AppColors.scaffold,
            borderRadius: BorderRadius.circular(AppTheme.radiusSm),
            border: Border.all(
              color: selected ? AppColors.accent : AppColors.cardBorder,
              width: selected ? 1.5 : 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontWeight: FontWeight.bold,
                      color: selected ? Colors.white : AppColors.textPrimary,
                      fontSize: 14,
                    ),
                  ),
                  if (selected)
                    const Icon(Icons.check_circle, color: AppColors.accent, size: 16),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  color: selected ? Colors.white.withOpacity( 0.7) : AppColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
