package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "game_sessions",
    foreignKeys = [ForeignKey(
        entity = PlayerProfile::class,
        parentColumns = ["id"],
        childColumns = ["player_id"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["player_id"])]
)
data class GameSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")
    val playerId: Long,
    val playerColor: String,
    val result: String,
    val botLevelStart: Int,
    val botLevelEnd: Int,
    val totalMoves: Int = 0,
    val openingUsed: String? = null,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long? = null
)
