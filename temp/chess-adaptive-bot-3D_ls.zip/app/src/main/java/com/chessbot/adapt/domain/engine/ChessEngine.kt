package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

interface ChessEngine {
    fun initializeBoard(): Board
    fun getValidMoves(board: Board, square: Square): List<com.chessbot.adapt.domain.model.Move>
    fun makeMove(board: Board, move: com.chessbot.adapt.domain.model.Move): Board
    fun isCheck(board: Board, color: Color): Boolean
    fun isCheckmate(board: Board, color: Color): Boolean
    fun isStalemate(board: Board, color: Color): Boolean
    fun isDraw(board: Board): Boolean
    fun toFEN(board: Board): String
    fun fromFEN(fen: String): Board
}
