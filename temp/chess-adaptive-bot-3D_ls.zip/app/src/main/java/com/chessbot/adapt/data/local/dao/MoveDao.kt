package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.MoveEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MoveDao {
    @Insert
    suspend fun insert(move: MoveEntity): Long

    @Insert
    suspend fun insertAll(moves: List<MoveEntity>)

    @Query("SELECT * FROM moves WHERE game_id = :gameId ORDER BY move_number ASC")
    fun getMovesForGame(gameId: Long): Flow<List<MoveEntity>>

    @Query("SELECT * FROM moves WHERE game_id = :gameId ORDER BY move_number ASC")
    suspend fun getMovesForGameSync(gameId: Long): List<MoveEntity>

    @Delete
    suspend fun delete(move: MoveEntity)
}
