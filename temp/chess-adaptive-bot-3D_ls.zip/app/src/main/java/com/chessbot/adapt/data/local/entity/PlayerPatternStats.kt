package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "player_pattern_stats",
    foreignKeys = [
        ForeignKey(entity = PlayerProfile::class, parentColumns = ["id"], childColumns = ["player_id"]),
        ForeignKey(entity = PatternDefinition::class, parentColumns = ["id"], childColumns = ["pattern_id"])
    ],
    indices = [Index(value = ["player_id", "pattern_id"], unique = true)]
)
data class PlayerPatternStats(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")
    val playerId: Long,
    @ColumnInfo(name = "pattern_id")
    val patternId: Long,
    val timesEncountered: Int = 0,
    val timesSuccessful: Int = 0,
    val timesFailed: Int = 0,
    val successRate: Float = 0.5f,
    val lastSeenAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
