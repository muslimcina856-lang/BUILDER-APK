package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(tableName = "opening_book")
data class OpeningBook(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    @ColumnInfo(name = "eco_code")
    val ecoCode: String,
    @ColumnInfo(name = "move_sequence")
    val moveSequence: String,
    val category: String = "OPENING",
    @ColumnInfo(name = "popularity_score")
    val popularityScore: Int = 50
)
