package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "moves",
    foreignKeys = [ForeignKey(
        entity = GameSession::class,
        parentColumns = ["id"],
        childColumns = ["game_id"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class MoveEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "game_id")
    val gameId: Long,
    val moveNumber: Int,
    val color: String,
    val fromSquare: String,
    val toSquare: String,
    val pieceType: String,
    val promotionPiece: String? = null,
    val capturedPiece: String? = null,
    val isCheck: Boolean = false,
    val isCheckmate: Boolean = false,
    val isCastling: Boolean = false,
    val isEnPassant: Boolean = false,
    val thinkTimeMs: Int = 0,
    val fenAfter: String
)
