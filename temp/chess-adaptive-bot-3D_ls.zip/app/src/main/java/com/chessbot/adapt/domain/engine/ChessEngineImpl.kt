package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

/**
 * Full chess engine implementation with board setup, move execution, and FEN support
 */
class ChessEngineImpl(
    private val validator: MoveValidator = MoveValidator(),
    private val stateDetector: GameStateDetector = GameStateDetector(validator)
) : ChessEngine {

    override fun initializeBoard(): Board {
        val squares = Array(8) { Array<Piece?>(8) { null } }

        // Black pieces (rank 7)
        squares[7][0] = Piece(PieceType.ROOK, Color.BLACK)
        squares[7][1] = Piece(PieceType.KNIGHT, Color.BLACK)
        squares[7][2] = Piece(PieceType.BISHOP, Color.BLACK)
        squares[7][3] = Piece(PieceType.QUEEN, Color.BLACK)
        squares[7][4] = Piece(PieceType.KING, Color.BLACK)
        squares[7][5] = Piece(PieceType.BISHOP, Color.BLACK)
        squares[7][6] = Piece(PieceType.KNIGHT, Color.BLACK)
        squares[7][7] = Piece(PieceType.ROOK, Color.BLACK)
        // Black pawns (rank 6)
        for (f in 0..7) squares[6][f] = Piece(PieceType.PAWN, Color.BLACK)

        // White pieces (rank 0)
        squares[0][0] = Piece(PieceType.ROOK, Color.WHITE)
        squares[0][1] = Piece(PieceType.KNIGHT, Color.WHITE)
        squares[0][2] = Piece(PieceType.BISHOP, Color.WHITE)
        squares[0][3] = Piece(PieceType.QUEEN, Color.WHITE)
        squares[0][4] = Piece(PieceType.KING, Color.WHITE)
        squares[0][5] = Piece(PieceType.BISHOP, Color.WHITE)
        squares[0][6] = Piece(PieceType.KNIGHT, Color.WHITE)
        squares[0][7] = Piece(PieceType.ROOK, Color.WHITE)
        // White pawns (rank 1)
        for (f in 0..7) squares[1][f] = Piece(PieceType.PAWN, Color.WHITE)

        return Board(squares)
    }

    override fun getValidMoves(board: Board, square: Square): List<Move> {
        val piece = board.squares[square.rank][square.file] ?: return emptyList()
        val rawMoves = validator.generatePieceMoves(board, square)
        // Filter out moves that leave own king in check
        return rawMoves.filter { move ->
            val newBoard = stateDetector.applyMove(board, move)
            !stateDetector.isInCheck(newBoard, piece.color)
        }
    }

    override fun makeMove(board: Board, move: Move): Board {
        return stateDetector.applyMove(board, move)
    }

    override fun isCheck(board: Board, color: Color): Boolean {
        return stateDetector.isInCheck(board, color)
    }

    override fun isCheckmate(board: Board, color: Color): Boolean {
        return stateDetector.isCheckmate(board, color)
    }

    override fun isStalemate(board: Board, color: Color): Boolean {
        return stateDetector.isStalemate(board, color)
    }

    override fun isDraw(board: Board): Boolean {
        return stateDetector.isDraw(board)
    }

    override fun toFEN(board: Board): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var emptyCount = 0
            for (f in 0..7) {
                val piece = board.squares[r][f]
                if (piece == null) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    val symbol = when (piece.type) {
                        PieceType.KING -> 'k'
                        PieceType.QUEEN -> 'q'
                        PieceType.ROOK -> 'r'
                        PieceType.BISHOP -> 'b'
                        PieceType.KNIGHT -> 'n'
                        PieceType.PAWN -> 'p'
                    }
                    sb.append(if (piece.color == Color.WHITE) symbol.uppercase() else symbol)
                }
            }
            if (emptyCount > 0) sb.append(emptyCount)
            if (r > 0) sb.append('/')
        }
        sb.append(" w KQkq - 0 1") // simplified FEN
        return sb.toString()
    }

    override fun fromFEN(fen: String): Board {
        val squares = Array(8) { Array<Piece?>(8) { null } }
        val parts = fen.split(" ")
        val rows = parts[0].split("/")
        for ((ri, row) in rows.withIndex()) {
            val r = 7 - ri
            var f = 0
            for (ch in row) {
                if (ch.isDigit()) {
                    f += ch.digitToInt()
                } else {
                    val color = if (ch.isUpperCase()) Color.WHITE else Color.BLACK
                    val type = when (ch.lowercaseChar()) {
                        'k' -> PieceType.KING
                        'q' -> PieceType.QUEEN
                        'r' -> PieceType.ROOK
                        'b' -> PieceType.BISHOP
                        'n' -> PieceType.KNIGHT
                        'p' -> PieceType.PAWN
                        else -> throw IllegalArgumentException("Unknown piece: $ch")
                    }
                    squares[r][f] = Piece(type, color)
                    f++
                }
            }
        }
        return Board(squares)
    }
}
