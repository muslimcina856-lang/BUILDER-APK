package com.chessbot.adapt.presentation.chessboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chessbot.adapt.data.local.dao.BotConfigDao
import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.GameSession
import com.chessbot.adapt.data.local.entity.MoveEntity
import com.chessbot.adapt.data.local.entity.PlayerProfile
import com.chessbot.adapt.domain.bot.PatternAnalyzer
import com.chessbot.adapt.domain.engine.ChessEngineImpl
import com.chessbot.adapt.domain.model.*
import com.chessbot.adapt.domain.repository.GameRepository
import com.chessbot.adapt.domain.repository.PlayerRepository
import com.chessbot.adapt.domain.usecase.AnalyzePatternsUseCase
import com.chessbot.adapt.domain.usecase.GetBotMoveUseCase
import com.chessbot.adapt.domain.usecase.UpdateBotLevelUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChessBoardUiState(
    val board: Board? = null,
    val validMoves: List<Move> = emptyList(),
    val selectedSquare: Square? = null,
    val isBotThinking: Boolean = false,
    val gameResult: String? = null,
    val currentLevel: Int = 1,
    val moveHistory: List<Move> = emptyList(),
    val lastMove: Move? = null,
    val playerColor: Color = Color.WHITE,
    val botColor: Color = Color.BLACK,
    val currentTurn: Color = Color.WHITE,
    val isCheck: Boolean = false,
    val isCheckmate: Boolean = false
)

@HiltViewModel
class ChessBoardViewModel @Inject constructor(
    private val getBotMoveUseCase: GetBotMoveUseCase,
    private val updateBotLevelUseCase: UpdateBotLevelUseCase,
    private val analyzePatternsUseCase: AnalyzePatternsUseCase,
    private val gameRepository: GameRepository,
    private val playerRepository: PlayerRepository,
    private val botConfigDao: BotConfigDao,
    private val botLearningDataDao: BotLearningDataDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChessBoardUiState())
    val uiState: StateFlow<ChessBoardUiState> = _uiState

    private val engine = ChessEngineImpl()
    private val patternAnalyzer = PatternAnalyzer()

    private var currentGameId: Long = 0L
    private var currentPlayerId: Long = 0L
    private var botConfig = BotConfig()
    private var learningData: List<BotLearningData> = emptyList()

    init {
        viewModelScope.launch {
            initPlayer()
        }
    }

    private suspend fun initPlayer() {
        // Load atau cipta player
        val player = playerRepository.getFirstPlayer() ?: run {
            val now = System.currentTimeMillis()
            val id = playerRepository.savePlayer(
                PlayerProfile(username = "Player", createdAt = now, updatedAt = now)
            )
            playerRepository.getPlayer(id)!!
        }
        currentPlayerId = player.id

        // Load atau cipta BotConfig
        val savedConfig = botConfigDao.getConfig(currentPlayerId)
        botConfig = savedConfig ?: run {
            val newConfig = BotConfig(playerId = currentPlayerId)
            botConfigDao.upsert(newConfig)
            newConfig
        }

        // Load learning data
        learningData = botLearningDataDao.getLearningDataForPlayer(currentPlayerId)

        // Update level di UI
        _uiState.value = _uiState.value.copy(currentLevel = botConfig.currentLevel)
    }

    fun startNewGame(playerColor: Color = Color.WHITE) {
        val board    = engine.initializeBoard()
        val botColor = if (playerColor == Color.WHITE) Color.BLACK else Color.WHITE

        _uiState.value = ChessBoardUiState(
            board        = board,
            playerColor  = playerColor,
            botColor     = botColor,
            currentTurn  = Color.WHITE,
            currentLevel = botConfig.currentLevel
        )

        viewModelScope.launch {
            currentGameId = gameRepository.saveGame(
                GameSession(
                    playerId      = currentPlayerId,
                    playerColor   = playerColor.name,
                    result        = "IN_PROGRESS",
                    botLevelStart = botConfig.currentLevel,
                    botLevelEnd   = botConfig.currentLevel,
                    startedAt     = System.currentTimeMillis()
                )
            )
        }

        if (playerColor == Color.BLACK) makeBotMove()
    }

    fun onSquareTapped(square: Square) {
        val state = _uiState.value
        if (state.isBotThinking || state.gameResult != null) return
        if (state.currentTurn != state.playerColor) return

        if (state.selectedSquare == null) {
            val piece = state.board?.squares?.get(square.rank)?.get(square.file)
            if (piece != null && piece.color == state.playerColor) {
                val validMoves = engine.getValidMoves(state.board!!, square)
                _uiState.value = state.copy(selectedSquare = square, validMoves = validMoves)
            }
        } else {
            val move = state.validMoves.find {
                it.toSquare == square && it.fromSquare == state.selectedSquare
            }
            if (move != null) {
                executePlayerMove(move)
            } else {
                val piece = state.board?.squares?.get(square.rank)?.get(square.file)
                if (piece != null && piece.color == state.playerColor) {
                    val validMoves = engine.getValidMoves(state.board!!, square)
                    _uiState.value = state.copy(selectedSquare = square, validMoves = validMoves)
                } else {
                    _uiState.value = state.copy(selectedSquare = null, validMoves = emptyList())
                }
            }
        }
    }

    private fun executePlayerMove(move: Move) {
        val state         = _uiState.value
        val newBoard      = engine.makeMove(state.board!!, move)
        val newHistory    = state.moveHistory + move
        val opponentColor = if (state.playerColor == Color.WHITE) Color.BLACK else Color.WHITE

        val isCheck     = engine.isCheck(newBoard, opponentColor)
        val isCheckmate = engine.isCheckmate(newBoard, opponentColor)
        val isStalemate = engine.isStalemate(newBoard, opponentColor)

        viewModelScope.launch {
            gameRepository.saveMove(buildMoveEntity(state.playerColor, move, newHistory.size, isCheck, isCheckmate, newBoard))
        }

        _uiState.value = state.copy(
            board          = newBoard,
            selectedSquare = null,
            validMoves     = emptyList(),
            moveHistory    = newHistory,
            lastMove       = move,
            currentTurn    = opponentColor,
            isCheck        = isCheck,
            isCheckmate    = isCheckmate
        )

        if (isCheckmate) { onGameEnd("WIN"); return }
        if (isStalemate) { onGameEnd("DRAW"); return }
        makeBotMove()
    }

    private fun makeBotMove() {
        val state = _uiState.value
        _uiState.value = state.copy(isBotThinking = true)

        viewModelScope.launch {
            try {
                val botMove     = getBotMoveUseCase(state.board!!, state.botColor, botConfig, learningData)
                val newBoard    = engine.makeMove(state.board!!, botMove)
                val newHistory  = state.moveHistory + botMove
                val isCheck     = engine.isCheck(newBoard, state.playerColor)
                val isCheckmate = engine.isCheckmate(newBoard, state.playerColor)
                val isStalemate = engine.isStalemate(newBoard, state.playerColor)

                gameRepository.saveMove(buildMoveEntity(state.botColor, botMove, newHistory.size, isCheck, isCheckmate, newBoard))

                _uiState.value = _uiState.value.copy(
                    board         = newBoard,
                    isBotThinking = false,
                    moveHistory   = newHistory,
                    lastMove      = botMove,
                    currentTurn   = state.playerColor,
                    isCheck       = isCheck,
                    isCheckmate   = isCheckmate
                )

                if (isCheckmate) onGameEnd("LOSS")
                else if (isStalemate) onGameEnd("DRAW")

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isBotThinking = false)
            }
        }
    }

    private fun onGameEnd(result: String) {
        val state = _uiState.value
        _uiState.value = state.copy(gameResult = result)

        viewModelScope.launch {
            // Analisis pattern dan update learning
            analyzePatternsUseCase(currentPlayerId, state.moveHistory, result)

            // Refresh learning data untuk game seterusnya
            learningData = botLearningDataDao.getLearningDataForPlayer(currentPlayerId)

            // Update GameSession di DB
            if (currentGameId > 0) {
                gameRepository.getGame(currentGameId)?.let { session ->
                    gameRepository.updateGame(
                        session.copy(
                            result      = result,
                            botLevelEnd = botConfig.currentLevel,
                            totalMoves  = state.moveHistory.size,
                            openingUsed = patternAnalyzer.identifyOpening(state.moveHistory),
                            endedAt     = System.currentTimeMillis()
                        )
                    )
                }
            }

            // Update level
            botConfig = updateBotLevelUseCase(botConfig.copy(playerId = currentPlayerId), result == "WIN")
            _uiState.value = _uiState.value.copy(currentLevel = botConfig.currentLevel)
        }
    }

    private fun buildMoveEntity(
        color: Color,
        move: Move,
        moveNumber: Int,
        isCheck: Boolean,
        isCheckmate: Boolean,
        board: Board
    ) = MoveEntity(
        gameId         = currentGameId,
        moveNumber     = moveNumber,
        color          = color.name,
        fromSquare     = "${('a' + move.fromSquare.file)}${move.fromSquare.rank + 1}",
        toSquare       = "${('a' + move.toSquare.file)}${move.toSquare.rank + 1}",
        pieceType      = move.piece.type.name,
        promotionPiece = move.promotionPiece?.name,
        isCheck        = isCheck,
        isCheckmate    = isCheckmate,
        fenAfter       = engine.toFEN(board)
    )

    fun resetGame() {
        _uiState.value = ChessBoardUiState(currentLevel = botConfig.currentLevel)
        startNewGame(Color.WHITE)
    }
}
