package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.PatternDefinition

@Dao
interface PatternDefinitionDao {
    @Query("SELECT * FROM pattern_definitions")
    suspend fun getAllPatterns(): List<PatternDefinition>

    @Query("SELECT * FROM pattern_definitions WHERE category = :category")
    suspend fun getPatternsByCategory(category: String): List<PatternDefinition>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(patterns: List<PatternDefinition>)
}
