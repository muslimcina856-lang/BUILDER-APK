package com.chessbot.adapt.domain.repository

import com.chessbot.adapt.data.local.entity.PlayerProfile

interface PlayerRepository {
    suspend fun getPlayer(id: Long): PlayerProfile?
    suspend fun getFirstPlayer(): PlayerProfile?
    suspend fun savePlayer(player: PlayerProfile): Long
    suspend fun updatePlayer(player: PlayerProfile)
}
