package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.PlayerPatternStats

@Dao
interface PlayerPatternStatsDao {
    @Query("SELECT * FROM player_pattern_stats WHERE player_id = :playerId")
    suspend fun getStatsForPlayer(playerId: Long): List<PlayerPatternStats>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stats: PlayerPatternStats)

    @Query("""
        SELECT * FROM player_pattern_stats
        WHERE player_id = :playerId AND pattern_id = :patternId
    """)
    suspend fun getStats(playerId: Long, patternId: Long): PlayerPatternStats?
}
