package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(tableName = "pattern_definitions")
data class PatternDefinition(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "pattern_key")
    val patternKey: String,
    val category: String,
    val name: String,
    val description: String? = null,
    @ColumnInfo(name = "detection_rules")
    val detectionRules: String,
    @ColumnInfo(name = "base_weight")
    val baseWeight: Float = 1.0f
)
