package com.chessbot.adapt.test

import kotlin.random.Random

// Simplified Evaluation and Learning Simulation
class BotSimulator {
    var level = 1
    var aggression = 0.5f
    var defense = 0.5f

    // Simulate playing a game
    fun playAndLearn(playerWin: Boolean) {
        // Logic: if player wins, bot learns to be more aggressive/defensive
        if (playerWin) {
            aggression = (aggression + 0.05f).coerceAtMost(1.0f)
            defense = (defense - 0.02f).coerceAtLeast(0.0f)
            level++
        } else {
            // If bot wins, it feels confident, becomes more balanced
            aggression = (aggression - 0.02f).coerceAtLeast(0.0f)
            defense = (defense + 0.05f).coerceAtMost(1.0f)
        }
    }

    fun getStatus(): String {
        return "Level: $level | Aggression: %.2f | Defense: %.2f".format(aggression, defense)
    }
}

fun main() {
    val bot = BotSimulator()
    println("--- Bot Learning Simulation: Level 1 to 100 ---")

    repeat(100) {
        val playerWins = Random.nextBoolean()
        bot.playAndLearn(playerWins)
        if (it % 10 == 0) {
            println("Progress: ${bot.getStatus()}")
        }
    }
    println("--- Final State: ${bot.getStatus()} ---")
}
