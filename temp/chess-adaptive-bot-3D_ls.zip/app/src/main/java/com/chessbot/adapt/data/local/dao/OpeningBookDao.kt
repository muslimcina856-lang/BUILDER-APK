package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.OpeningBook

@Dao
interface OpeningBookDao {
    @Query("SELECT * FROM opening_book ORDER BY popularity_score DESC")
    suspend fun getAllOpenings(): List<OpeningBook>

    @Query("SELECT * FROM opening_book WHERE move_sequence LIKE :movesPrefix LIMIT 1")
    suspend fun findOpeningByMoves(movesPrefix: String): OpeningBook?
}
