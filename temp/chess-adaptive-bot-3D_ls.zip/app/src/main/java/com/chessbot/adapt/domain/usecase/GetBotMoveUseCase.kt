package com.chessbot.adapt.domain.usecase

import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.bot.MinimaxEngine
import com.chessbot.adapt.domain.model.*

class GetBotMoveUseCase(
    private val minimaxEngine: MinimaxEngine
) {
    suspend operator fun invoke(
        board: Board,
        botColor: Color,
        config: BotConfig,
        learningData: List<BotLearningData>
    ): Move {
        return minimaxEngine.getBestMove(board, botColor, config, learningData)
    }
}
