package com.chessbot.adapt.domain.model

data class Move(
    val fromSquare: Square,
    val toSquare: Square,
    val piece: Piece,
    val promotionPiece: PieceType? = null
)
