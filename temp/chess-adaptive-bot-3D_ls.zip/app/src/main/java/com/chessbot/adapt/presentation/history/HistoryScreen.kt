package com.chessbot.adapt.presentation.history

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.chessbot.adapt.data.local.entity.GameSession
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    games: List<GameSession>,
    onGameClick: (Long) -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    LazyColumn {
        items(games) { game ->
            Card(
                onClick = { onGameClick(game.id) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                ListItem(
                    headlineContent = { Text("Result: ${game.result}") },
                    supportingContent = {
                        Text("Level ${game.botLevelStart} → ${game.botLevelEnd}  •  ${game.totalMoves} moves")
                    },
                    trailingContent = {
                        Text(
                            text = dateFormat.format(Date(game.startedAt)),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                )
            }
        }
    }
}
