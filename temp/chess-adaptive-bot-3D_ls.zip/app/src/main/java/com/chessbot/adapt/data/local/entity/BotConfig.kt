package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "bot_config",
    foreignKeys = [ForeignKey(
        entity = PlayerProfile::class,
        parentColumns = ["id"],
        childColumns = ["player_id"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["player_id"])]
)
data class BotConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")
    val playerId: Long = 0L,           // Fix #6 — default value
    val currentLevel: Int = 1,
    val searchDepth: Int = 2,
    val evalAggression: Float = 0.5f,
    val evalDefense: Float = 0.5f,
    val evalPositional: Float = 0.5f,
    val evalTactical: Float = 0.5f,
    val patternRecognitionWeight: Float = 0.3f,
    val learningEnabled: Boolean = true,
    val lastUpdatedAt: Long = System.currentTimeMillis()
)
