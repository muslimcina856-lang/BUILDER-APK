package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.domain.model.*

/**
 * Logik teras: Menganalisis sejarah pergerakan pemain dan menyesuaikan
 * parameter evaluasi (weights) bot secara dinamik.
 */
class AdaptiveLearner {

    // Mengemaskini berat evaluasi berdasarkan corak kelemahan yang dikesan
    fun adjustWeights(
        currentWeights: EvalWeights,
        weaknesses: List<String>
    ): EvalWeights {
        var newAggression = currentWeights.aggression
        var newDefense = currentWeights.defense

        weaknesses.forEach { weakness ->
            when (weakness) {
                "AGGRESSIVE_OPENING" -> newDefense += 0.1f // Bot jadi lebih defensif jika pemain agresif
                "TACTICAL_BLUNDER" -> newAggression += 0.2f // Bot jadi lebih agresif jika pemain sering tersilap
                "ENDGAME_WEAKNESS" -> newAggression += 0.1f
            }
        }

        return currentWeights.copy(
            aggression = newAggression.coerceIn(0.0f, 1.0f),
            defense = newDefense.coerceIn(0.0f, 1.0f)
        )
    }

    // Mengesan corak berdasarkan pergerakan terkini
    fun detectPattern(moves: List<Move>): String {
        // Contoh logik ringkas: jika pemain sering menggerakkan bidak tengah
        // dalam 3 pergerakan pertama, itu adalah "CENTER_CONTROL_PATTERN"
        return if (moves.take(3).any { it.fromSquare.rank == 1 }) {
            "CENTER_CONTROL"
        } else {
            "UNKNOWN"
        }
    }
}
