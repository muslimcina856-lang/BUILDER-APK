package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

/**
 * Detects check, checkmate, stalemate, and draw conditions
 */
class GameStateDetector(
    private val validator: MoveValidator
) {

    fun isInCheck(board: Board, color: Color): Boolean {
        val kingSquare = findKing(board, color) ?: return false
        val opponentColor = if (color == Color.WHITE) Color.BLACK else Color.WHITE
        return validator.isSquareAttacked(board, kingSquare, opponentColor)
    }

    fun isCheckmate(board: Board, color: Color): Boolean {
        if (!isInCheck(board, color)) return false
        return !hasAnyLegalMove(board, color)
    }

    fun isStalemate(board: Board, color: Color): Boolean {
        if (isInCheck(board, color)) return false
        return !hasAnyLegalMove(board, color)
    }

    fun isDraw(board: Board): Boolean {
        return isInsufficientMaterial(board)
    }

    private fun hasAnyLegalMove(board: Board, color: Color): Boolean {
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f] ?: continue
                if (piece.color != color) continue
                val moves = validator.generatePieceMoves(board, Square(f, r))
                for (move in moves) {
                    val newBoard = applyMove(board, move)
                    if (!isInCheck(newBoard, color)) return true
                }
            }
        }
        return false
    }

    fun findKing(board: Board, color: Color): Square? {
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f]
                if (piece?.type == PieceType.KING && piece.color == color) {
                    return Square(f, r)
                }
            }
        }
        return null
    }

    fun applyMove(board: Board, move: Move): Board {
        val newSquares = Array(8) { r -> Array<Piece?>(8) { f -> board.squares[r][f] } }
        newSquares[move.toSquare.rank][move.toSquare.file] = if (move.promotionPiece != null) {
            Piece(move.promotionPiece!!, move.piece.color)
        } else {
            move.piece
        }
        newSquares[move.fromSquare.rank][move.fromSquare.file] = null
        return Board(newSquares)
    }

    private fun isInsufficientMaterial(board: Board): Boolean {
        var whitePieces = 0
        var blackPieces = 0
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f]
                if (piece != null) {
                    if (piece.color == Color.WHITE) whitePieces++ else blackPieces++
                }
            }
        }
        // King vs King is draw
        return whitePieces == 1 && blackPieces == 1
    }
}
