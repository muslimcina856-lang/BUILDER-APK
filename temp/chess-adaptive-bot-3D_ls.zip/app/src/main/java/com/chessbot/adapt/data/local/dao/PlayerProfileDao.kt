package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.PlayerProfile

@Dao
interface PlayerProfileDao {
    @Query("SELECT * FROM player_profile WHERE id = :id")
    suspend fun getPlayer(id: Long): PlayerProfile?

    @Query("SELECT * FROM player_profile LIMIT 1")
    suspend fun getFirstPlayer(): PlayerProfile?

    @Insert
    suspend fun insert(player: PlayerProfile): Long

    @Update
    suspend fun update(player: PlayerProfile)

    @Query("UPDATE player_profile SET wins = wins + 1, total_games = total_games + 1 WHERE id = :id")
    suspend fun incrementWins(id: Long)

    @Query("UPDATE player_profile SET losses = losses + 1, total_games = total_games + 1 WHERE id = :id")
    suspend fun incrementLosses(id: Long)
}
