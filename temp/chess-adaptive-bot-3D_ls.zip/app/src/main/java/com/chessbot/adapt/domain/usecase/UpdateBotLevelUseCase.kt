package com.chessbot.adapt.domain.usecase

import com.chessbot.adapt.data.local.dao.BotConfigDao
import com.chessbot.adapt.data.local.entity.BotConfig

/**
 * Level hanya naik, tak boleh turun.
 * searchDepth meningkat di threshold tertentu.
 */
class UpdateBotLevelUseCase(
    private val botConfigDao: BotConfigDao
) {
    suspend operator fun invoke(config: BotConfig, playerWon: Boolean): BotConfig {
        val newLevel = if (playerWon) {
            (config.currentLevel + 1).coerceAtMost(999)
        } else {
            config.currentLevel
        }

        val newDepth = when {
            newLevel > 700 -> 5
            newLevel > 300 -> 4
            newLevel > 100 -> 3
            else           -> 2
        }

        val updated = config.copy(
            currentLevel = newLevel,
            searchDepth = newDepth,
            lastUpdatedAt = System.currentTimeMillis()
        )

        botConfigDao.upsert(updated)
        return updated
    }
}
