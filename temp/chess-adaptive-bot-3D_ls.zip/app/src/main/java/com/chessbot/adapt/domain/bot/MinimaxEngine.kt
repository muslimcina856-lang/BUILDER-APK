package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.engine.GameStateDetector
import com.chessbot.adapt.domain.engine.MoveValidator
import com.chessbot.adapt.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MinimaxEngine(
    private val patternAnalyzer: PatternAnalyzer = PatternAnalyzer(),
    private val adaptiveLearner: AdaptiveLearner = AdaptiveLearner()
) : BotEngine {

    private val validator = MoveValidator()
    private val stateDetector = GameStateDetector(validator)

    override suspend fun getBestMove(
        board: Board,
        color: Color,
        config: BotConfig,
        learningData: List<BotLearningData>
    ): Move = withContext(Dispatchers.Default) {
        val depth = config.searchDepth

        // Fix #28-29 — gunakan learningData untuk adjust weights
        val baseWeights = patternAnalyzer.getCounterStrategy(
            patternAnalyzer.identifyOpening(emptyList())
        )
        val weights = if (learningData.isNotEmpty()) {
            val avgAgg = learningData.map { it.aggressionModifier }.average().toFloat()
            val avgDef = learningData.map { it.defenseModifier }.average().toFloat()
            adaptiveLearner.adjustWeights(baseWeights, listOf()).let { adjusted ->
                adjusted.copy(
                    aggression = (baseWeights.aggression + avgAgg).coerceIn(0f, 1f),
                    defense    = (baseWeights.defense + avgDef).coerceIn(0f, 1f)
                )
            }
        } else baseWeights

        val (bestMove, _) = alphaBeta(board, depth, Int.MIN_VALUE + 1, Int.MAX_VALUE - 1, true, color, weights)

        bestMove ?: getAllLegalMoves(board, color).firstOrNull()
            ?: throw IllegalStateException("Tiada langkah sah untuk $color")
    }

    private fun alphaBeta(
        board: Board,
        depth: Int,
        alpha: Int,
        beta: Int,
        maximizing: Boolean,
        botColor: Color,
        weights: EvalWeights
    ): Pair<Move?, Int> {
        if (depth == 0) {
            return null to evaluatePosition(board, botColor, weights)
        }

        val currentColor = if (maximizing) botColor else oppositeColor(botColor)
        val legalMoves = getAllLegalMoves(board, currentColor)

        if (legalMoves.isEmpty()) {
            return if (stateDetector.isInCheck(board, currentColor)) {
                null to if (maximizing) -(100000 - depth) else (100000 - depth)
            } else {
                null to 0 // stalemate
            }
        }

        // Move ordering: MVV-LVA (Most Valuable Victim - Least Valuable Attacker)
        val orderedMoves = legalMoves.sortedByDescending { move ->
            val target = board.squares[move.toSquare.rank][move.toSquare.file]
            if (target != null) pieceValue(target.type) - pieceValue(move.piece.type) / 10 else 0
        }

        var bestMove: Move? = null
        var bestValue = if (maximizing) Int.MIN_VALUE + 1 else Int.MAX_VALUE - 1
        var currentAlpha = alpha
        var currentBeta = beta

        for (move in orderedMoves) {
            val newBoard = stateDetector.applyMove(board, move)
            val (_, value) = alphaBeta(newBoard, depth - 1, currentAlpha, currentBeta, !maximizing, botColor, weights)

            if (maximizing) {
                if (value > bestValue) { bestValue = value; bestMove = move }
                currentAlpha = max(currentAlpha, bestValue)
            } else {
                if (value < bestValue) { bestValue = value; bestMove = move }
                currentBeta = min(currentBeta, bestValue)
            }

            if (currentBeta <= currentAlpha) break
        }

        return bestMove to bestValue
    }

    override fun evaluatePosition(board: Board, color: Color, weights: EvalWeights): Int {
        var score = 0

        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f] ?: continue
                val value = pieceValue(piece.type)

                if (piece.color == color) {
                    score += value
                    score += getPositionalBonus(piece, r, f)
                } else {
                    score -= value
                    score -= getPositionalBonus(piece, r, f)
                }
            }
        }

        score = (score * weights.material).toInt()
        score += (getMobilityScore(board, color) * weights.mobility).toInt()
        score += (getKingSafetyScore(board, color) * weights.kingSafety).toInt()

        // Aggression: galak serang lawan, kurang nilai langkah lawan
        val opponentMobility = getMobilityScore(board, oppositeColor(color))
        score -= (opponentMobility * weights.aggression * 0.3f).toInt()

        return score
    }

    private fun getMobilityScore(board: Board, color: Color): Int {
        var mobility = 0
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f] ?: continue
                if (piece.color != color) continue
                mobility += validator.generatePieceMoves(board, Square(f, r)).size
            }
        }
        return mobility
    }

    private fun getKingSafetyScore(board: Board, color: Color): Int {
        val kingSquare = stateDetector.findKing(board, color) ?: return 0
        var safety = 0
        val pawnDir = if (color == Color.WHITE) 1 else -1
        for (df in -1..1) {
            val f = kingSquare.file + df
            val r = kingSquare.rank + pawnDir
            if (f in 0..7 && r in 0..7) {
                val piece = board.squares[r][f]
                if (piece?.type == PieceType.PAWN && piece.color == color) safety += 10
            }
        }
        return safety
    }

    private fun getPositionalBonus(piece: Piece, rank: Int, file: Int): Int {
        val centerDist = abs(3.5 - rank) + abs(3.5 - file)
        return when (piece.type) {
            PieceType.KNIGHT, PieceType.BISHOP -> max(0, ((7 - centerDist) * 5).toInt())
            PieceType.PAWN   -> max(0, ((7 - centerDist) * 2).toInt())
            PieceType.KING   -> if (piece.color == Color.WHITE) -(rank * 3) else -((7 - rank) * 3)
            else             -> max(0, ((7 - centerDist) * 3).toInt())
        }
    }

    private fun getAllLegalMoves(board: Board, color: Color): List<Move> {
        val moves = mutableListOf<Move>()
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f] ?: continue
                if (piece.color != color) continue
                val pieceMoves = validator.generatePieceMoves(board, Square(f, r))
                for (move in pieceMoves) {
                    val newBoard = stateDetector.applyMove(board, move)
                    if (!stateDetector.isInCheck(newBoard, color)) {
                        moves.add(move)
                    }
                }
            }
        }
        return moves
    }

    override fun setDifficulty(level: Int) {}

    override fun updateWeights(learningData: BotLearningData) {}

    private fun pieceValue(type: PieceType): Int = when (type) {
        PieceType.PAWN   -> 100
        PieceType.KNIGHT -> 320
        PieceType.BISHOP -> 330
        PieceType.ROOK   -> 500
        PieceType.QUEEN  -> 900
        PieceType.KING   -> 20000
    }

    private fun oppositeColor(color: Color): Color =
        if (color == Color.WHITE) Color.BLACK else Color.WHITE
}
