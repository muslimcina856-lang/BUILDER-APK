package com.chessbot.adapt.presentation.stats

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.chessbot.adapt.data.local.entity.PlayerProfile

@Composable
fun StatsScreen(
    player: PlayerProfile?
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Text("Statistics", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        if (player != null) {
            Text("Total Games: ${player.totalGames}")
            Text("Wins: ${player.wins}")
            Text("Losses: ${player.losses}")
            Text("Draws: ${player.draws}")
            Text("Win Rate: ${if (player.totalGames > 0) (player.wins * 100 / player.totalGames) else 0}%")

            Spacer(modifier = Modifier.height(8.dp))

            Text("Current Streak: ${player.currentStreak} ${player.streakType.lowercase()}")
        }
    }
}
