package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "bot_learning_data",
    foreignKeys = [
        ForeignKey(entity = PlayerProfile::class, parentColumns = ["id"], childColumns = ["player_id"]),
        ForeignKey(entity = PatternDefinition::class, parentColumns = ["id"], childColumns = ["pattern_id"])
    ],
    indices = [Index(value = ["player_id", "pattern_id"], unique = true)]
)
data class BotLearningData(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")
    val playerId: Long,
    @ColumnInfo(name = "pattern_id")
    val patternId: Long,
    val counterStrategy: String,
    val effectivenessScore: Float = 0.5f,
    val timesApplied: Int = 0,
    val successfulApplies: Int = 0,
    val aggressionModifier: Float = 0.0f,
    val defenseModifier: Float = 0.0f,
    val positionWeightModifier: Float = 0.0f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
