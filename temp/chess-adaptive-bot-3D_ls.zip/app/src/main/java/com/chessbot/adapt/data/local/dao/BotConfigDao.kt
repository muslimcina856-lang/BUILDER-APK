package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.BotConfig

@Dao
interface BotConfigDao {
    @Query("SELECT * FROM bot_config WHERE player_id = :playerId")
    suspend fun getConfig(playerId: Long): BotConfig?

    @Query("SELECT * FROM bot_config LIMIT 1")
    suspend fun getFirstConfig(): BotConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(config: BotConfig)
}
