package com.chessbot.adapt

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ChessBotApplication : Application()
