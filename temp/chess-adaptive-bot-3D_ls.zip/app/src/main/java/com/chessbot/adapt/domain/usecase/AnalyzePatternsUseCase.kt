package com.chessbot.adapt.domain.usecase

import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.dao.PlayerPatternStatsDao
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.PlayerPatternStats
import com.chessbot.adapt.domain.bot.PatternAnalyzer
import com.chessbot.adapt.domain.model.Move

/**
 * Analisis permainan yang selesai — update atau INSERT rekod baru.
 * Dipanggil selepas setiap permainan tamat.
 */
class AnalyzePatternsUseCase(
    private val patternAnalyzer: PatternAnalyzer,
    private val playerPatternStatsDao: PlayerPatternStatsDao,
    private val botLearningDataDao: BotLearningDataDao
) {
    suspend operator fun invoke(
        playerId: Long,
        moves: List<Move>,
        result: String
    ) {
        val opening = patternAnalyzer.identifyOpening(moves)
        val patternKey: Long = when (opening) {
            "KING_PAWN_GAME"  -> 1L
            "QUEEN_PAWN_GAME" -> 2L
            else              -> 3L
        }

        val playerWon = result == "WIN"
        val botWon    = result == "LOSS"
        val now       = System.currentTimeMillis()

        // === Player Pattern Stats ===
        val existingStats = playerPatternStatsDao.getStats(playerId, patternKey)
        if (existingStats != null) {
            playerPatternStatsDao.upsert(existingStats.copy(
                timesEncountered = existingStats.timesEncountered + 1,
                timesSuccessful  = if (playerWon) existingStats.timesSuccessful + 1 else existingStats.timesSuccessful,
                timesFailed      = if (!playerWon) existingStats.timesFailed + 1 else existingStats.timesFailed,
                successRate      = (existingStats.timesSuccessful + if (playerWon) 1 else 0).toFloat() /
                                   (existingStats.timesEncountered + 1).toFloat(),
                lastSeenAt       = now,
                updatedAt        = now
            ))
        } else {
            // Fix #26 — INSERT rekod baru kalau belum wujud
            playerPatternStatsDao.upsert(PlayerPatternStats(
                playerId         = playerId,
                patternId        = patternKey,
                timesEncountered = 1,
                timesSuccessful  = if (playerWon) 1 else 0,
                timesFailed      = if (!playerWon) 1 else 0,
                successRate      = if (playerWon) 1.0f else 0.0f,
                lastSeenAt       = now,
                updatedAt        = now
            ))
        }

        // === Bot Learning Data ===
        val existingLearning = botLearningDataDao.getLearningData(playerId, patternKey)
        if (existingLearning != null) {
            botLearningDataDao.upsert(existingLearning.copy(
                timesApplied      = existingLearning.timesApplied + 1,
                successfulApplies = if (botWon) existingLearning.successfulApplies + 1 else existingLearning.successfulApplies,
                effectivenessScore = (existingLearning.successfulApplies + if (botWon) 1 else 0).toFloat() /
                                     (existingLearning.timesApplied + 1).toFloat(),
                updatedAt         = now
            ))
        } else {
            // INSERT rekod baru
            botLearningDataDao.upsert(BotLearningData(
                playerId          = playerId,
                patternId         = patternKey,
                counterStrategy   = opening,
                timesApplied      = 1,
                successfulApplies = if (botWon) 1 else 0,
                effectivenessScore = if (botWon) 1.0f else 0.0f,
                createdAt         = now,
                updatedAt         = now
            ))
        }
    }
}
