package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.domain.model.*

/**
 * Menganalisis langkah pembukaan dan mengesan corak kegemaran pemain.
 * Board coordinates: rank 0-7 (0=rank1), file 0-7 (0=a, 4=e, 3=d)
 */
class PatternAnalyzer {

    fun identifyOpening(moves: List<Move>): String {
        if (moves.isEmpty()) return "UNKNOWN_OPENING"

        val openingMoves = moves.take(6)

        // Detect King's Pawn opening: pawn putih dari e2(rank1,file4) ke e4(rank3,file4)
        // atau pawn hitam balas e5/e6
        val hasKingPawn = openingMoves.any { move ->
            move.piece.type == PieceType.PAWN &&
            move.fromSquare.file == 4 &&  // lajur e
            move.fromSquare.rank == 1      // rank asal pawn putih
        } || openingMoves.any { move ->
            move.piece.type == PieceType.PAWN &&
            move.fromSquare.file == 4 &&
            move.fromSquare.rank == 6      // rank asal pawn hitam
        }

        // Detect Queen's Pawn: d2(rank1,file3) ke d4
        val hasQueenPawn = openingMoves.any { move ->
            move.piece.type == PieceType.PAWN &&
            move.fromSquare.file == 3 &&  // lajur d
            (move.fromSquare.rank == 1 || move.fromSquare.rank == 6)
        }

        return when {
            hasKingPawn  -> "KING_PAWN_GAME"
            hasQueenPawn -> "QUEEN_PAWN_GAME"
            else         -> "UNKNOWN_OPENING"
        }
    }

    fun getCounterStrategy(opening: String): EvalWeights {
        return when (opening) {
            "KING_PAWN_GAME"  -> EvalWeights(material = 1.0f, aggression = 0.8f, defense = 0.4f)
            "QUEEN_PAWN_GAME" -> EvalWeights(material = 1.1f, aggression = 0.5f, defense = 0.7f)
            else              -> EvalWeights(aggression = 0.5f, defense = 0.5f)
        }
    }
}
