package com.chessbot.adapt.domain.usecase

import com.chessbot.adapt.data.local.dao.GameSessionDao
import com.chessbot.adapt.data.local.entity.GameSession
import kotlinx.coroutines.flow.Flow

class GetGameStatsUseCase(
    private val gameSessionDao: GameSessionDao
) {
    operator fun invoke(playerId: Long): Flow<List<GameSession>> {
        return gameSessionDao.getGamesByPlayer(playerId)
    }
}
