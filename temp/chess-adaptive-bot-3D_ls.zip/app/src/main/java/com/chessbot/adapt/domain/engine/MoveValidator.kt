package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

/**
 * Validator for chess moves - ensures all moves follow chess rules
 */
class MoveValidator {

    fun validateMove(board: Board, move: Move, color: Color): Boolean {
        val piece = board.squares[move.fromSquare.rank][move.fromSquare.file] ?: return false
        if (piece.color != color) return false

        val target = board.squares[move.toSquare.rank][move.toSquare.file]
        if (target?.color == color) return false // can't capture own piece

        val validMoves = generatePieceMoves(board, move.fromSquare)
        return validMoves.any { it.toSquare == move.toSquare && it.promotionPiece == move.promotionPiece }
    }

    fun generatePieceMoves(board: Board, square: Square): List<Move> {
        val piece = board.squares[square.rank][square.file] ?: return emptyList()
        return when (piece.type) {
            PieceType.PAWN -> generatePawnMoves(board, square, piece)
            PieceType.KNIGHT -> generateKnightMoves(board, square, piece)
            PieceType.BISHOP -> generateBishopMoves(board, square, piece)
            PieceType.ROOK -> generateRookMoves(board, square, piece)
            PieceType.QUEEN -> generateQueenMoves(board, square, piece)
            PieceType.KING -> generateKingMoves(board, square, piece)
        }
    }

    private fun generatePawnMoves(board: Board, square: Square, piece: Piece): List<Move> {
        val moves = mutableListOf<Move>()
        val direction = if (piece.color == Color.WHITE) 1 else -1
        val startRank = if (piece.color == Color.WHITE) 1 else 6
        val promotionRank = if (piece.color == Color.WHITE) 7 else 0

        val oneStep = square.copy(rank = square.rank + direction)
        if (oneStep.rank in 0..7 && board.squares[oneStep.rank][oneStep.file] == null) {
            if (oneStep.rank == promotionRank) {
                for (promo in listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)) {
                    moves.add(Move(square, oneStep, piece, promotionPiece = promo))
                }
            } else {
                moves.add(Move(square, oneStep, piece))
            }

            // Two steps from start
            if (square.rank == startRank) {
                val twoStep = square.copy(rank = square.rank + 2 * direction)
                if (board.squares[twoStep.rank][twoStep.file] == null) {
                    moves.add(Move(square, twoStep, piece))
                }
            }
        }

        // Captures
        for (dx in listOf(-1, 1)) {
            val capture = Square(square.file + dx, square.rank + direction)
            if (capture.file in 0..7 && capture.rank in 0..7) {
                val target = board.squares[capture.rank][capture.file]
                if (target != null && target.color != piece.color) {
                    if (capture.rank == promotionRank) {
                        for (promo in listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)) {
                            moves.add(Move(square, capture, piece, promotionPiece = promo))
                        }
                    } else {
                        moves.add(Move(square, capture, piece))
                    }
                }
            }
        }

        return moves
    }

    private fun generateKnightMoves(board: Board, square: Square, piece: Piece): List<Move> {
        val moves = mutableListOf<Move>()
        val offsets = listOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        for ((dr, df) in offsets) {
            val target = Square(square.file + df, square.rank + dr)
            if (target.file in 0..7 && target.rank in 0..7) {
                val targetPiece = board.squares[target.rank][target.file]
                if (targetPiece == null || targetPiece.color != piece.color) {
                    moves.add(Move(square, target, piece))
                }
            }
        }
        return moves
    }

    private fun generateSlidingMoves(board: Board, square: Square, piece: Piece, directions: List<Pair<Int, Int>>): List<Move> {
        val moves = mutableListOf<Move>()
        for ((dr, df) in directions) {
            var r = square.rank + dr
            var f = square.file + df
            while (r in 0..7 && f in 0..7) {
                val target = board.squares[r][f]
                if (target == null) {
                    moves.add(Move(square, Square(f, r), piece))
                } else {
                    if (target.color != piece.color) {
                        moves.add(Move(square, Square(f, r), piece))
                    }
                    break
                }
                r += dr
                f += df
            }
        }
        return moves
    }

    private fun generateBishopMoves(board: Board, square: Square, piece: Piece): List<Move> {
        return generateSlidingMoves(board, square, piece, listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1))
    }

    private fun generateRookMoves(board: Board, square: Square, piece: Piece): List<Move> {
        return generateSlidingMoves(board, square, piece, listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1))
    }

    private fun generateQueenMoves(board: Board, square: Square, piece: Piece): List<Move> {
        return generateSlidingMoves(board, square, piece, listOf(
            1 to 0, -1 to 0, 0 to 1, 0 to -1,
            1 to 1, 1 to -1, -1 to 1, -1 to -1
        ))
    }

    private fun generateKingMoves(board: Board, square: Square, piece: Piece): List<Move> {
        val moves = mutableListOf<Move>()
        for (dr in -1..1) {
            for (df in -1..1) {
                if (dr == 0 && df == 0) continue
                val target = Square(square.file + df, square.rank + dr)
                if (target.file in 0..7 && target.rank in 0..7) {
                    val targetPiece = board.squares[target.rank][target.file]
                    if (targetPiece == null || targetPiece.color != piece.color) {
                        moves.add(Move(square, target, piece))
                    }
                }
            }
        }
        return moves
    }

    fun isSquareAttacked(board: Board, square: Square, byColor: Color): Boolean {
        // Check all opponent pieces if they can attack this square
        for (r in 0..7) {
            for (f in 0..7) {
                val piece = board.squares[r][f] ?: continue
                if (piece.color != byColor) continue
                val moves = generatePieceMoves(board, Square(f, r))
                if (moves.any { it.toSquare == square }) return true
            }
        }
        return false
    }
}
