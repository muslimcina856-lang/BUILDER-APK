package com.chessbot.adapt.presentation.chessboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.chessbot.adapt.domain.model.*
import kotlin.math.PI

/**
 * 3D chess board rendered entirely with Compose Canvas.
 *
 * Features:
 *  • Perspective-projected board + pieces (painters-algorithm depth sort)
 *  • Drag gesture = orbit camera around board (360° horizontal, ~25–75° elevation)
 *  • Spring-animated piece lift when selected
 *  • Arc-path move animation for every move (player + bot)
 *  • Gradient-shaded cylinders for pieces (ivory / ebony look)
 *  • Diagonal wood-grain gradient on tiles
 *  • Glow ring + highlight on selected piece
 *  • Gold highlight on last move squares
 *  • Cyan dots on valid destination squares
 *  • Red overlay on king when in check
 */
@Composable
fun ChessBoard3DView(
    board: Board?,
    selectedSquare: Square?,
    validMoves: List<Move>,
    lastMove: Move?,
    isCheck: Boolean,
    checkColor: com.chessbot.adapt.domain.model.Color?,
    playerColor: com.chessbot.adapt.domain.model.Color,
    boardSize: Dp = 360.dp,
    onSquareTap: (Square) -> Unit
) {
    // Initial camera angle based on player side
    val initTheta = remember(playerColor) {
        if (playerColor == com.chessbot.adapt.domain.model.Color.WHITE)
            PI.toFloat() * 1.2f   // looking from white's side
        else
            PI.toFloat() * 0.2f   // looking from black's side
    }

    // Camera orbit state
    var camTheta by remember(playerColor) { mutableFloatStateOf(initTheta) }
    var camPhi   by remember { mutableFloatStateOf(PI.toFloat() / 3.2f) } // ~56° elevation

    // Selected-piece lift: springs up when a square is selected
    val selLift by animateFloatAsState(
        targetValue    = if (selectedSquare != null) 0.48f else 0f,
        animationSpec  = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow),
        label          = "selLift"
    )

    // Move animation: piece arcs from source to destination
    var animMove     by remember { mutableStateOf<Move?>(null) }
    var animProgress by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(lastMove) {
        lastMove ?: return@LaunchedEffect
        animMove     = lastMove
        animProgress = 0f
        animate(
            initialValue = 0f, targetValue = 1f,
            animationSpec = tween(400, easing = FastOutSlowInEasing)
        ) { v, _ -> animProgress = v }
        animMove     = null
        animProgress = 1f
    }

    val density = LocalDensity.current
    val sizePx  = with(density) { boardSize.toPx() }

    Canvas(
        modifier = Modifier
            .size(boardSize)
            // Orbit: drag to rotate camera
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, _, _ ->
                    camTheta -= pan.x * 0.009f
                    camPhi    = (camPhi - pan.y * 0.006f).coerceIn(0.22f, 1.15f)
                }
            }
            // Tap: unproject to board square
            .pointerInput(board, selectedSquare, camTheta, camPhi) {
                detectTapGestures { offset ->
                    val sq = tapToSquare(
                        offset.x, offset.y,
                        sizePx, sizePx,
                        camTheta, camPhi
                    )
                    if (sq != null) onSquareTap(sq)
                }
            }
    ) {
        draw3DChessBoard(
            board          = board,
            selected       = selectedSquare,
            validMoves     = validMoves,
            lastMove       = lastMove,
            isCheck        = isCheck,
            checkSideColor = checkColor,
            cameraTheta    = camTheta,
            cameraPhi      = camPhi,
            selectedLift   = selLift,
            animMove       = animMove,
            animProgress   = animProgress
        )
    }
}
