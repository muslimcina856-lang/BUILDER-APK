package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.GameSession
import kotlinx.coroutines.flow.Flow

@Dao
interface GameSessionDao {
    @Insert
    suspend fun insert(session: GameSession): Long

    @Update
    suspend fun update(session: GameSession)

    @Query("SELECT * FROM game_sessions WHERE player_id = :playerId ORDER BY started_at DESC")
    fun getGamesByPlayer(playerId: Long): Flow<List<GameSession>>

    @Query("SELECT * FROM game_sessions WHERE id = :gameId")
    suspend fun getGame(gameId: Long): GameSession?

    @Query("SELECT * FROM game_sessions WHERE player_id = :playerId ORDER BY started_at DESC LIMIT 1")
    suspend fun getLastGame(playerId: Long): GameSession?
}
