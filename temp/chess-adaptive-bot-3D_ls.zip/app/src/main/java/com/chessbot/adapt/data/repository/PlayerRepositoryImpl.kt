package com.chessbot.adapt.data.repository

import com.chessbot.adapt.data.local.dao.PlayerProfileDao
import com.chessbot.adapt.data.local.entity.PlayerProfile
import com.chessbot.adapt.domain.repository.PlayerRepository

class PlayerRepositoryImpl(
    private val playerProfileDao: PlayerProfileDao
) : PlayerRepository {

    override suspend fun getPlayer(id: Long): PlayerProfile? {
        return playerProfileDao.getPlayer(id)
    }

    override suspend fun getFirstPlayer(): PlayerProfile? {
        return playerProfileDao.getFirstPlayer()
    }

    override suspend fun savePlayer(player: PlayerProfile): Long {
        return playerProfileDao.insert(player)
    }

    override suspend fun updatePlayer(player: PlayerProfile) {
        playerProfileDao.update(player)
    }
}
