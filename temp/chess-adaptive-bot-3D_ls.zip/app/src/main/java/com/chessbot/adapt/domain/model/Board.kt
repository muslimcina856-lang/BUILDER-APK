package com.chessbot.adapt.domain.model

enum class PieceType { KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN }
enum class Color { WHITE, BLACK }

data class Square(val file: Int, val rank: Int)

data class Piece(val type: PieceType, val color: Color)

data class Board(val squares: Array<Array<Piece?>>) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as Board
        return squares.contentDeepEquals(other.squares)
    }

    override fun hashCode(): Int {
        return squares.contentDeepHashCode()
    }
}
