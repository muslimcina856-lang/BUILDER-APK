package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(tableName = "player_profile")
data class PlayerProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val totalGames: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val draws: Int = 0,
    val currentStreak: Int = 0,
    val streakType: String = "NONE",
    val totalPlayTimeMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
