package com.chessbot.adapt.data.local.dao

import androidx.room.*
import com.chessbot.adapt.data.local.entity.BotLearningData

@Dao
interface BotLearningDataDao {
    @Query("SELECT * FROM bot_learning_data WHERE player_id = :playerId")
    suspend fun getLearningDataForPlayer(playerId: Long): List<BotLearningData>

    @Query("""
        SELECT * FROM bot_learning_data
        WHERE player_id = :playerId AND pattern_id = :patternId
    """)
    suspend fun getLearningData(playerId: Long, patternId: Long): BotLearningData?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(data: BotLearningData)
}
