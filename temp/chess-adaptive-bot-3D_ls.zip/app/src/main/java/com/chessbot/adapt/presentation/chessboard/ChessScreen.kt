package com.chessbot.adapt.presentation.chessboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.hilt.navigation.compose.hiltViewModel
import com.chessbot.adapt.domain.model.Color

@Composable
fun ChessScreen(viewModel: ChessBoardViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        if (state.board == null) viewModel.startNewGame(Color.WHITE)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Board takes most of screen but leaves room for UI
        val boardSize = min(maxWidth, maxHeight * 0.72f)

        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ── Header ────────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text  = "Bot  Lv ${state.currentLevel}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (state.isCheck && state.gameResult == null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = MaterialTheme.shapes.extraSmall
                    ) {
                        Text(
                            "CHECK",
                            modifier   = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            color      = MaterialTheme.colorScheme.onErrorContainer,
                            style      = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            // ── 3D Board ──────────────────────────────────────────────
            ChessBoard3DView(
                board         = state.board,
                selectedSquare= state.selectedSquare,
                validMoves    = state.validMoves,
                lastMove      = state.lastMove,
                isCheck       = state.isCheck,
                checkColor    = if (state.isCheck) {
                    if (state.currentTurn == state.playerColor) state.playerColor
                    else state.botColor
                } else null,
                playerColor   = state.playerColor,
                boardSize     = boardSize,
                onSquareTap   = { sq -> viewModel.onSquareTapped(sq) }
            )

            Spacer(Modifier.height(10.dp))

            // ── Status ────────────────────────────────────────────────
            when {
                state.gameResult != null -> GameResultCard(
                    result     = state.gameResult!!,
                    level      = state.currentLevel,
                    onPlayAgain= { viewModel.resetGame() }
                )
                state.isBotThinking -> Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Bot sedang fikir…", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> Text(
                    text  = if (state.currentTurn == state.playerColor) "Giliran kamu" else "Giliran bot",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (state.currentTurn == state.playerColor)
                        MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(4.dp))
            if (state.moveHistory.isNotEmpty()) {
                Text(
                    "Langkah ke-${state.moveHistory.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(
                "Drag untuk putar board",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun GameResultCard(result: String, level: Int, onPlayAgain: () -> Unit) {
    val (emoji, title, sub) = when (result) {
        "WIN"  -> Triple("🏆", "Kamu Menang!", "Bot naik ke Level $level")
        "LOSS" -> Triple("♟", "Bot Menang", "Jangan give up — cuba lagi!")
        "DRAW" -> Triple("🤝", "Seri", "Permainan menarik!")
        else   -> Triple("🎯", result, "")
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(emoji, style = MaterialTheme.typography.displaySmall)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onPlayAgain, modifier = Modifier.fillMaxWidth()) {
                Text("Main Lagi")
            }
        }
    }
}
