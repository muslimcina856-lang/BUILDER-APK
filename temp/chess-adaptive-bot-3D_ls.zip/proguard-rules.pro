# Keep Room entities
-keep class com.chessbot.adapt.data.local.entity.** { *; }
-keep class com.chessbot.adapt.domain.model.** { *; }
