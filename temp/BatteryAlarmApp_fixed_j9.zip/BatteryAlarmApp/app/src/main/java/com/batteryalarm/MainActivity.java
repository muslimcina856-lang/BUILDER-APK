package com.batteryalarm;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_THRESHOLD = "threshold";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_RINGTONE_URI = "ringtone_uri";

    private TextView tvBatteryLevel;
    private TextView tvThresholdValue;
    private SeekBar seekBarThreshold;
    private SwitchMaterial switchService;
    private Button btnPickRingtone;
    private TextView tvRingtoneName;
    private TextView tvServiceStatus;

    private int currentBatteryLevel = 0;
    private Uri ringtoneUri;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            currentBatteryLevel = (level * 100) / scale;
            updateBatteryDisplay();
        }
    };

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied - alarm may not work", Toast.LENGTH_LONG).show();
            }
        });

    private final ActivityResultLauncher<Intent> ringtonePickerLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri pickedUri = result.getData().getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if (pickedUri != null) {
                    ringtoneUri = pickedUri;
                    saveRingtoneUri(pickedUri);
                    updateRingtoneDisplay();
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        loadPreferences();
        requestPermissions();
        setupListeners();
        updateServiceStatus();
        updateRingtoneDisplay();
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        updateServiceStatus();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(batteryReceiver);
        } catch (IllegalArgumentException ignored) {}
    }

    private void initViews() {
        tvBatteryLevel = findViewById(R.id.tv_battery_level);
        tvThresholdValue = findViewById(R.id.tv_threshold_value);
        seekBarThreshold = findViewById(R.id.seekbar_threshold);
        switchService = findViewById(R.id.switch_service);
        btnPickRingtone = findViewById(R.id.btn_pick_ringtone);
        tvRingtoneName = findViewById(R.id.tv_ringtone_name);
        tvServiceStatus = findViewById(R.id.tv_service_status);
    }

    private void loadPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int threshold = prefs.getInt(KEY_THRESHOLD, 80);
        seekBarThreshold.setProgress(threshold);
        tvThresholdValue.setText(threshold + "%");
        boolean serviceRunning = prefs.getBoolean(KEY_SERVICE_RUNNING, false);
        switchService.setChecked(serviceRunning);

        String uriStr = prefs.getString(KEY_RINGTONE_URI, null);
        if (uriStr != null) {
            ringtoneUri = Uri.parse(uriStr);
        } else {
            ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        }
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            boolean alreadyIgnoring = powerManager != null
                && powerManager.isIgnoringBatteryOptimizations(getPackageName());
            if (!alreadyIgnoring) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }

    private void setupListeners() {
        seekBarThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 10) progress = 10;
                tvThresholdValue.setText(progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveThreshold(seekBar.getProgress());
            }
        });

        switchService.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startMonitoring();
            } else {
                stopMonitoring();
            }
        });

        btnPickRingtone.setOnClickListener(v -> pickRingtone());
    }

    private void startMonitoring() {
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            Toast.makeText(this, "Notifications disabled - enable in settings", Toast.LENGTH_LONG).show();
            switchService.setChecked(false);
            return;
        }

        int threshold = seekBarThreshold.getProgress();
        Intent serviceIntent = new Intent(this, BatteryAlarmService.class);
        serviceIntent.putExtra("threshold", threshold);
        if (ringtoneUri != null) {
            serviceIntent.putExtra("ringtone_uri", ringtoneUri.toString());
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        saveServiceRunning(true);
        updateServiceStatus();
        Toast.makeText(this, "Battery alarm started at " + threshold + "%", Toast.LENGTH_SHORT).show();
    }

    private void stopMonitoring() {
        stopService(new Intent(this, BatteryAlarmService.class));
        saveServiceRunning(false);
        updateServiceStatus();
        Toast.makeText(this, "Battery alarm stopped", Toast.LENGTH_SHORT).show();
    }

    private void pickRingtone() {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        if (ringtoneUri != null) {
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri);
        }
        ringtonePickerLauncher.launch(intent);
    }

    private void updateBatteryDisplay() {
        tvBatteryLevel.setText(currentBatteryLevel + "%");
        int color;
        if (currentBatteryLevel < 20) {
            color = ContextCompat.getColor(this, android.R.color.holo_red_dark);
        } else if (currentBatteryLevel <= seekBarThreshold.getProgress()) {
            color = ContextCompat.getColor(this, android.R.color.holo_orange_dark);
        } else {
            color = ContextCompat.getColor(this, android.R.color.holo_green_dark);
        }
        tvBatteryLevel.setTextColor(color);
    }

    private void updateServiceStatus() {
        boolean running = BatteryAlarmService.isRunning();
        if (running) {
            tvServiceStatus.setText("Status: Monitoring active");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            tvServiceStatus.setText("Status: Stopped");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
        }
        switchService.setChecked(running);
    }

    private void updateRingtoneDisplay() {
        if (ringtoneUri != null) {
            String name = RingtoneManager.getRingtone(this, ringtoneUri).getTitle(this);
            tvRingtoneName.setText(name);
        } else {
            tvRingtoneName.setText("Default alarm");
        }
    }

    private void saveThreshold(int threshold) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putInt(KEY_THRESHOLD, threshold)
            .apply();
    }

    private void saveServiceRunning(boolean running) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SERVICE_RUNNING, running)
            .apply();
    }

    private void saveRingtoneUri(Uri uri) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(KEY_RINGTONE_URI, uri.toString())
            .apply();
    }
}
