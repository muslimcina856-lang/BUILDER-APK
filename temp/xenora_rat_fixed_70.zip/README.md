# 🔥 XENORA X RAT v1.0

<div align="center">
  <img src="assets/images/logo.png" alt="Xenora X" width="200"/>
  <br/>
  <h3>🚀 Advanced Remote Administration Tool</h3>
  <p><i>by MAKKAUYTIM</i></p>
</div>

---

## 📌 **Overview**

**Xenora X** adalah aplikasi RAT (Remote Administration Tool) canggih yang dibangun dengan Flutter untuk Android. Aplikasi ini memungkinkan kontrol jarak jauh perangkat target dengan berbagai fitur monitoring dan kontrol.

> ⚠️ **DISCLAIMER:** apk ini jangan di salah gunakan,dan resiko penggunaan di tanggung. Penggunaan untuk aktivitas ilegal adalah tanggung jawab pengguna sepenuhnya admin atau developer tidak bertanggung jawab.

---

## ✨ **Fitur Utama**

### 🎯 **Dashboard**
- **2 Mode Dashboard** → Classic & High (Cyber Gold Theme)
- **Real-time Stats** → Online, Devices, Messages
- **Jadwal Sholat** → API Aladhan (High version)
- **Activity Log** → Riwayat aktivitas real-time

### 📱 **Device Management**
- **Multi Device** → Kelola banyak perangkat sekaligus
- **Status Monitoring** → Online/Offline, Battery, Network
- **Device Info** → Model, Android Version, SDK, Storage

### 🎮 **Remote Control**
- **Flashlight** → Nyalakan/matikan senter
- **Lock/Unlock** → Kunci dan buka kunci perangkat
- **Hide Icon** → Sembunyikan ikon aplikasi
- **Vibrate** → Getar perangkat dengan durasi custom
- **Mute Volume** → Matikan suara perangkat
- **Text to Speech** → Suruh HP ngomong
- **Toast Message** → Kirim pesan popup

### 📸 **Camera & Screen**
- **Take Photo** → Ambil foto depan/belakang
- **Live Camera** → Stream kamera real-time
- **Live Screen** → Stream layar real-time
- **Screenshot** → Ambil screenshot perangkat

### 📊 **Data Grabber**
- **Contacts** → Dump semua kontak
- **Gmail Accounts** → Lihat akun Gmail terdaftar
- **WhatsApp Number** → Ambil nomor WA terdaftar
- **GPS Location** → Lacak lokasi perangkat
- **Gallery** → Lihat foto di galeri
- **Phone Info** → Info lengkap perangkat

### ⚔️ **Attack Features**
- **Jumpscare** → Fullscreen jumpscare
- **Spam Notif** → Spam dialog 7x
- **Stuck Layar** → Block semua sentuhan
- **Block App** → Blokir aplikasi tertentu
- **Hard Lock V2/V3** → Kunci perangkat dengan PIN

### 🎵 **Media Control**
- **Play Audio** → Putar audio dari URL
- **Stop Audio** → Hentikan audio
- **Set Wallpaper** → Ubah wallpaper perangkat
- **Open URL** → Buka situs di perangkat

### 🛠️ **System Control**
- **Reboot** → Restart perangkat
- **Shutdown** → Matikan perangkat
- **Volume Control** → Atur volume
- **Silent Mode** → Mode senyap

---

## 📱 **Screenshots**

| Dashboard Classic | Dashboard High | Control Panel |
|:---:|:---:|:---:|
| <img src="screenshots/classic.jpg" width="200"/> | <img src="screenshots/high.jpg" width="200"/> | <img src="screenshots/control.jpg" width="200"/> |

| Home Page | Settings | Admin Panel |
|:---:|:---:|:---:|
| <img src="screenshots/home.jpg" width="200"/> | <img src="screenshots/settings.jpg" width="200"/> | <img src="screenshots/admin.jpg" width="200"/> |

---

## 🏗️ **Tech Stack**

### Frontend
- **Flutter** → UI Framework
- **Dart** → Programming Language
- **GetX / Provider** → State Management
- **WebSocket** → Real-time communication

### Backend
- **Node.js** → Server Runtime
- **Express** → Web Framework
- **WebSocket** → Real-time events
- **JWT** → Authentication

### Android Native
- **Kotlin** → Native Code
- **Device Admin** → Anti-uninstall
- **MediaProjection** → Screen Capture
- **Foreground Service** → Background tasks

---

## 📁 **Project Structure**
