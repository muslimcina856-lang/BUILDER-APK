// lib/pages/splash_page.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'login_page.dart';
import 'landing_page.dart';
import 'dashboard_high.dart';
import 'dashboard_classic.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  late VideoPlayerController _controller;
  bool _isVideoReady = false;
  double _progress = 0.0;
  String _statusText = 'Loading...';

  @override
  void initState() {
    super.initState();
    _initVideo();
    _startLoading();
  }

  void _initVideo() {
    _controller = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        setState(() => _isVideoReady = true);
        _controller.setLooping(true);
        _controller.setVolume(0.0);
        _controller.play();
      }).catchError((e) {
        print('Splash video error: $e');
        setState(() => _isVideoReady = true);
      });
  }

  Future<void> _startLoading() async {
    // Simulasi loading progress
    for (int i = 0; i <= 100; i += 5) {
      await Future.delayed(Duration(milliseconds: 50 + (i * 2)));
      if (mounted) {
        setState(() {
          _progress = i / 100;
          if (i < 30) {
            _statusText = 'Initializing...';
          } else if (i < 60) {
            _statusText = 'Loading Assets...';
          } else if (i < 85) {
            _statusText = 'Connecting to Server...';
          } else {
            _statusText = 'Ready!';
          }
        });
      }
    }

    // Check auth setelah loading selesai
    await Future.delayed(const Duration(milliseconds: 300));
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    final hasSelectedDashboard = prefs.getBool('has_selected_dashboard') ?? false;

    if (token != null && token.isNotEmpty) {
      if (hasSelectedDashboard) {
        final dashboardType = prefs.getString('dashboard_type') ?? 'high';
        if (dashboardType == 'classic') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const DashboardClassicPage()),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const DashboardHighPage()),
          );
        }
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LandingPage()),
        );
      }
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginPage()),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ========== VIDEO BACKGROUND ==========
          if (_isVideoReady)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            )
          else
            Container(
              color: Colors.black,
              child: const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)),
                ),
              ),
            ),

          // ========== OVERLAY ==========
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.5),
                  Colors.black.withOpacity(0.8),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // ========== CONTENT ==========
          SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(flex: 2),

                // ===== LOGO =====
                Image.asset(
                  'assets/images/logo.png',
                  height: 120,
                )
                    .animate()
                    .scale(
                      begin: const Offset(0.5, 0.5),
                      end: const Offset(1, 1),
                      duration: const Duration(milliseconds: 800),
                      curve: Curves.easeOutBack,
                    )
                    .fadeIn(
                      duration: const Duration(milliseconds: 600),
                    ),

                const SizedBox(height: 24),

                // ===== TITLE =====
                Column(
                  children: [
                    Text(
                      'XENORA X',
                      style: TextStyle(
                        color: const Color(0xFFD4AF37),
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Xenora',
                        letterSpacing: 8,
                        shadows: [
                          Shadow(
                            color: const Color(0xFFD4AF37).withOpacity(0.4),
                            blurRadius: 40,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                    )
                        .animate()
                        .fadeIn(
                          duration: const Duration(milliseconds: 600),
                          delay: const Duration(milliseconds: 200),
                        )
                        .slideY(
                          begin: 0.3,
                          end: 0,
                          duration: const Duration(milliseconds: 600),
                          delay: const Duration(milliseconds: 200),
                        ),

                    const SizedBox(height: 8),

                    Text(
                      'by MAKKAUYTIM',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 12,
                        fontFamily: 'Share Tech Mono',
                        letterSpacing: 3,
                      ),
                    )
                        .animate()
                        .fadeIn(
                          duration: const Duration(milliseconds: 600),
                          delay: const Duration(milliseconds: 400),
                        )
                        .slideY(
                          begin: 0.3,
                          end: 0,
                          duration: const Duration(milliseconds: 600),
                          delay: const Duration(milliseconds: 400),
                        ),
                  ],
                ),

                const Spacer(flex: 1),

                // ===== LOADING PROGRESS =====
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Column(
                    children: [
                      // Progress Bar
                      Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(2),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(2),
                          child: LinearProgressIndicator(
                            value: _progress,
                            backgroundColor: Colors.transparent,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                              Color(0xFFD4AF37),
                            ),
                          ),
                        ),
                      )
                          .animate()
                          .fadeIn(
                            duration: const Duration(milliseconds: 400),
                            delay: const Duration(milliseconds: 600),
                          ),

                      const SizedBox(height: 12),

                      // Status Text
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _statusText,
                            style: TextStyle(
                              color: Colors.grey.shade400,
                              fontSize: 10,
                              fontFamily: 'Share Tech Mono',
                              letterSpacing: 1,
                            ),
                          )
                              .animate()
                              .fadeIn(
                                duration: const Duration(milliseconds: 400),
                                delay: const Duration(milliseconds: 600),
                              ),
                          Text(
                            '${(_progress * 100).toInt()}%',
                            style: TextStyle(
                              color: const Color(0xFFD4AF37),
                              fontSize: 10,
                              fontFamily: 'Share Tech Mono',
                              fontWeight: FontWeight.bold,
                            ),
                          )
                              .animate()
                              .fadeIn(
                                duration: const Duration(milliseconds: 400),
                                delay: const Duration(milliseconds: 600),
                              ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 40),

                // ===== VERSION =====
                Text(
                  'Version 1.0.0',
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontSize: 9,
                    fontFamily: 'Share Tech Mono',
                    letterSpacing: 2,
                  ),
                )
                    .animate()
                    .fadeIn(
                      duration: const Duration(milliseconds: 400),
                      delay: const Duration(milliseconds: 800),
                    ),

                const Spacer(flex: 1),
              ],
            ),
          ),
        ],
      ),
    );
  }
}