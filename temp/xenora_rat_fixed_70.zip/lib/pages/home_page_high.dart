// lib/pages/home_page_high.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../widgets/glass_card.dart';
import '../widgets/role_badge.dart';
import '../utils/role_helper.dart';

class HomePageHigh extends StatefulWidget {
  const HomePageHigh({super.key});

  @override
  State<HomePageHigh> createState() => _HomePageHighState();
}

class _HomePageHighState extends State<HomePageHigh> {
  late VideoPlayerController _bannerController;
  bool _bannerReady = false;
  String _username = 'User';
  String _role = 'MEMBER';
  int _deviceCount = 0;
  int _onlineCount = 0;
  int _daysLeft = 30;
  int _totalMessages = 0;
  int _unreadMessages = 0;

  // ===== JADWAL SHOLAT =====
  Map<String, String> _prayerTimes = {};
  bool _isLoadingPrayer = true;
  String _prayerLocation = 'Jakarta';
  String _nextPrayer = '-';
  String _nextPrayerTime = '-';
  String _countdown = '--:--:--';
  Timer? _countdownTimer;

  final List<Map<String, dynamic>> _quickActions = [
    {'icon': Icons.devices_rounded, 'label': 'Device', 'color': Color(0xFF4D8FFF)},
    {'icon': Icons.control_point_rounded, 'label': 'Kontrol', 'color': Color(0xFFA78BFA)},
    {'icon': Icons.chat_rounded, 'label': 'Chat', 'color': Color(0xFF34D399)},
    {'icon': Icons.settings_rounded, 'label': 'Settings', 'color': Color(0xFFFB923C)},
  ];

  final List<Map<String, dynamic>> _activityLog = [
    {'icon': Icons.check_circle_rounded, 'text': 'Device 1 connected', 'time': '2m ago', 'color': Color(0xFF34D399)},
    {'icon': Icons.warning_rounded, 'text': 'Device 2 offline', 'time': '15m ago', 'color': Color(0xFFFB923C)},
    {'icon': Icons.message_rounded, 'text': 'Pesan baru dari Admin', 'time': '1h ago', 'color': Color(0xFF4D8FFF)},
    {'icon': Icons.update_rounded, 'text': 'System update available', 'time': '3h ago', 'color': Color(0xFFA78BFA)},
  ];

  // ============================================================
  //  JADWAL SHOLAT
  // ============================================================
  final List<Map<String, String>> _prayerNames = [
    {'key': 'Imsak', 'label': 'Imsak', 'icon': '🌙'},
    {'key': 'Fajr', 'label': 'Subuh', 'icon': '🌅'},
    {'key': 'Sunrise', 'label': 'Terbit', 'icon': '☀️'},
    {'key': 'Dhuhr', 'label': 'Dzuhur', 'icon': '🌞'},
    {'key': 'Asr', 'label': 'Ashar', 'icon': '🌇'},
    {'key': 'Maghrib', 'label': 'Maghrib', 'icon': '🌆'},
    {'key': 'Isha', 'label': 'Isya', 'icon': '🌙'},
  ];

  @override
  void initState() {
    super.initState();
    _initBanner();
    _loadUserData();
    _fetchPrayerTimes();
  }

  void _initBanner() {
    _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() => _bannerReady = true);
        _bannerController.setLooping(true);
        _bannerController.setVolume(0.0);
        _bannerController.play();
      }).catchError((e) => print('Banner Video error: $e'));
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('username') ?? 'User';
      _role = prefs.getString('role')?.toUpperCase() ?? 'MEMBER';
      _daysLeft = prefs.getInt('days_left') ?? 30;
      _deviceCount = prefs.getInt('device_count') ?? 0;
      _onlineCount = prefs.getInt('online_count') ?? 0;
      _totalMessages = prefs.getInt('total_messages') ?? 0;
      _unreadMessages = prefs.getInt('unread_messages') ?? 0;
    });
  }

  // ============================================================
  //  FETCH JADWAL SHOLAT
  // ============================================================
  Future<void> _fetchPrayerTimes() async {
    setState(() => _isLoadingPrayer = true);

    try {
      // Pakai API Aladhan
      final lat = -6.200000; // Jakarta
      final lng = 106.816666;
      final now = DateTime.now();
      final url = Uri.parse(
        'http://api.aladhan.com/v1/timings/${now.day}-${now.month}-${now.year}?latitude=$lat&longitude=$lng&method=20'
      );

      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200) {
          final timings = data['data']['timings'];
          final meta = data['data']['meta'];
          
          setState(() {
            _prayerLocation = meta['timezone'] ?? 'Jakarta';
            _prayerTimes = {
              'Imsak': timings['Imsak'] ?? '-',
              'Fajr': timings['Fajr'] ?? '-',
              'Sunrise': timings['Sunrise'] ?? '-',
              'Dhuhr': timings['Dhuhr'] ?? '-',
              'Asr': timings['Asr'] ?? '-',
              'Maghrib': timings['Maghrib'] ?? '-',
              'Isha': timings['Isha'] ?? '-',
            };
            _isLoadingPrayer = false;
          });
          _calculateNextPrayer();
          _startCountdown();
        }
      }
    } catch (e) {
      print('Error fetching prayer times: $e');
      setState(() => _isLoadingPrayer = false);
    }
  }

  void _calculateNextPrayer() {
    final now = DateTime.now();
    final order = ['Imsak', 'Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    String foundName = '-';
    String foundTime = '-';
    DateTime? nextPrayerTime;

    for (String key in order) {
      final timeStr = _prayerTimes[key];
      if (timeStr == null || timeStr == '-') continue;
      final parts = timeStr.split(':');
      if (parts.length < 2) continue;
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour == null || minute == null) continue;

      final prayerTime = DateTime(now.year, now.month, now.day, hour, minute);
      if (prayerTime.isAfter(now)) {
        foundName = key;
        foundTime = timeStr;
        nextPrayerTime = prayerTime;
        break;
      }
    }

    // Jika tidak ada (semua sudah lewat), ambil besok
    if (nextPrayerTime == null) {
      final imsakStr = _prayerTimes['Imsak'];
      if (imsakStr != null && imsakStr != '-') {
        final parts = imsakStr.split(':');
        if (parts.length >= 2) {
          final hour = int.tryParse(parts[0]) ?? 0;
          final minute = int.tryParse(parts[1]) ?? 0;
          nextPrayerTime = DateTime(now.year, now.month, now.day + 1, hour, minute);
          foundName = 'Imsak';
          foundTime = imsakStr;
        }
      }
    }

    setState(() {
      _nextPrayer = _getPrayerLabel(foundName);
      _nextPrayerTime = foundTime;
    });

    if (nextPrayerTime != null) {
      _startCountdown(nextPrayerTime);
    }
  }

  String _getPrayerLabel(String key) {
    final map = {
      'Imsak': 'Imsak',
      'Fajr': 'Subuh',
      'Sunrise': 'Terbit',
      'Dhuhr': 'Dzuhur',
      'Asr': 'Ashar',
      'Maghrib': 'Maghrib',
      'Isha': 'Isya',
    };
    return map[key] ?? key;
  }

  void _startCountdown([DateTime? targetTime]) {
    _countdownTimer?.cancel();

    if (targetTime == null) {
      setState(() => _countdown = '--:--:--');
      return;
    }

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      final now = DateTime.now();
      final diff = targetTime.difference(now);

      if (diff.isNegative) {
        timer.cancel();
        _calculateNextPrayer();
        return;
      }

      final hours = diff.inHours.toString().padLeft(2, '0');
      final minutes = (diff.inMinutes % 60).toString().padLeft(2, '0');
      final seconds = (diff.inSeconds % 60).toString().padLeft(2, '0');

      if (mounted) {
        setState(() {
          _countdown = '$hours:$minutes:$seconds';
        });
      }
    });
  }

  @override
  void dispose() {
    _bannerController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  // ============================================================
  //  BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final roleData = RoleHelper.getRole(_role);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
      child: Column(
        children: [
          // ===== BANNER VIDEO =====
          _buildBanner(),
          const SizedBox(height: 16),

          // ===== JADWAL SHOLAT CARD =====
          _buildPrayerCard(),
          const SizedBox(height: 16),

          // ===== USER PROFILE =====
          _buildUserProfile(roleData),
          const SizedBox(height: 16),

          // ===== STATS ROW =====
          _buildStatsRow(),
          const SizedBox(height: 16),

          // ===== QUICK ACTIONS =====
          _buildQuickActions(),
          const SizedBox(height: 16),

          // ===== ACTIVITY LOG =====
          _buildActivityLog(),
          const SizedBox(height: 16),

          // ===== DEVICE STATUS =====
          _buildDeviceStatus(),
        ],
      ),
    );
  }

  // ============================================================
  //  BANNER
  // ============================================================
  Widget _buildBanner() {
    return Container(
      height: 120,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFFD4AF37).withOpacity(0.08),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_bannerReady)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bannerController.value.size.width,
                  height: _bannerController.value.size.height,
                  child: VideoPlayer(_bannerController),
                ),
              )
            else
              Container(color: Colors.grey.shade900),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.black.withOpacity(0.7),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Image.asset('assets/images/logo.png', height: 40),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'XENORA X',
                        style: TextStyle(
                          color: const Color(0xFFD4AF37),
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Xenora',
                          letterSpacing: 2,
                        ),
                      ),
                      Text(
                        'v1.0.0 • HIGH',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 8,
                          fontFamily: 'Share Tech Mono',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF34D399).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFF34D399).withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF34D399),
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'ONLINE',
                          style: TextStyle(
                            color: const Color(0xFF34D399),
                            fontSize: 8,
                            fontFamily: 'Share Tech Mono',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  JADWAL SHOLAT CARD — PREMIUM
  // ============================================================
  Widget _buildPrayerCard() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFD4AF37).withOpacity(0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: const Color(0xFFD4AF37).withOpacity(0.12),
                  ),
                ),
                child: const Icon(
                  Icons.mosque_rounded,
                  color: Color(0xFFD4AF37),
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'JADWAL SHOLAT',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Xenora',
                        letterSpacing: 2,
                      ),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_rounded,
                          color: const Color(0xFFD4AF37).withOpacity(0.5),
                          size: 10,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _prayerLocation,
                          style: TextStyle(
                            color: Colors.grey.shade500,
                            fontSize: 8,
                            fontFamily: 'Share Tech Mono',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (!_isLoadingPrayer)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF34D399).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: const Color(0xFF34D399).withOpacity(0.15),
                    ),
                  ),
                  child: Text(
                    '🔄 UPDATE',
                    style: TextStyle(
                      color: const Color(0xFF34D399),
                      fontSize: 7,
                      fontFamily: 'Share Tech Mono',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),

          // Next Prayer
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFFD4AF37).withOpacity(0.06),
                  Colors.transparent,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFFD4AF37).withOpacity(0.08),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MENUJU',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 7,
                        fontFamily: 'Share Tech Mono',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _nextPrayer,
                      style: TextStyle(
                        color: const Color(0xFFD4AF37),
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Xenora',
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      _nextPrayerTime,
                      style: TextStyle(
                        color: Colors.grey.shade400,
                        fontSize: 10,
                        fontFamily: 'Share Tech Mono',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _countdown,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Share Tech Mono',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Prayer Times Grid
          if (_isLoadingPrayer)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)),
                  strokeWidth: 2,
                ),
              ),
            )
          else
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _prayerNames.map((prayer) {
                final key = prayer['key']!;
                final time = _prayerTimes[key] ?? '-';
                final isNext = key == _getPrayerKey(_nextPrayer);
                return Container(
                  width: (MediaQuery.of(context).size.width - 48) / 4,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: isNext
                        ? const Color(0xFFD4AF37).withOpacity(0.08)
                        : Colors.white.withOpacity(0.02),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isNext
                          ? const Color(0xFFD4AF37).withOpacity(0.2)
                          : Colors.white.withOpacity(0.04),
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        prayer['icon']!,
                        style: const TextStyle(fontSize: 14),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        prayer['label']!,
                        style: TextStyle(
                          color: isNext ? const Color(0xFFD4AF37) : Colors.grey.shade500,
                          fontSize: 7,
                          fontFamily: 'Share Tech Mono',
                          fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                      Text(
                        time.replaceAll(':00', ''),
                        style: TextStyle(
                          color: isNext ? Colors.white : Colors.grey.shade400,
                          fontSize: 9,
                          fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  String _getPrayerKey(String label) {
    final map = {
      'Imsak': 'Imsak',
      'Subuh': 'Fajr',
      'Terbit': 'Sunrise',
      'Dzuhur': 'Dhuhr',
      'Ashar': 'Asr',
      'Maghrib': 'Maghrib',
      'Isya': 'Isha',
    };
    return map[label] ?? label;
  }

  // ============================================================
  //  USER PROFILE
  // ============================================================
  Widget _buildUserProfile(RoleData roleData) {
    return GlassCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: roleData.gradient,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: roleData.color.withOpacity(0.3),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: roleData.color.withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(
                  roleData.icon,
                  color: roleData.color,
                  size: 28,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome Back!',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 10,
                        fontFamily: 'Share Tech Mono',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      _username.toUpperCase(),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Xenora',
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        RoleBadge(
                          role: _role,
                          size: 14,
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: _daysLeft <= 3
                                ? Colors.red.withOpacity(0.1)
                                : Colors.grey.shade800,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: _daysLeft <= 3
                                  ? Colors.red.withOpacity(0.2)
                                  : Colors.grey.shade700,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.timer_rounded,
                                color: _daysLeft <= 3 ? Colors.red : Colors.grey.shade500,
                                size: 10,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '$_daysLeft hari',
                                style: TextStyle(
                                  color: _daysLeft <= 3 ? Colors.red : Colors.grey.shade400,
                                  fontSize: 8,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Divider(
            color: Colors.white.withOpacity(0.04),
            height: 1,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildProfileStat(
                '📱',
                '$_deviceCount',
                'Devices',
                const Color(0xFF4D8FFF),
              ),
              _buildProfileStat(
                '🟢',
                '$_onlineCount',
                'Online',
                const Color(0xFF34D399),
              ),
              _buildProfileStat(
                '💬',
                '$_totalMessages',
                'Pesan',
                const Color(0xFFA78BFA),
              ),
              _buildProfileStat(
                '🔔',
                '$_unreadMessages',
                'Belum Dibaca',
                const Color(0xFFF472B6),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProfileStat(String icon, String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.04),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: color.withOpacity(0.06),
          ),
        ),
        child: Column(
          children: [
            Text(
              icon,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'Xenora',
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 7,
                fontFamily: 'Share Tech Mono',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  STATS ROW
  // ============================================================
  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: GlassCard(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Column(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFF34D399).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: const Color(0xFF34D399).withOpacity(0.2),
                    ),
                  ),
                  child: const Icon(
                    Icons.check_circle_rounded,
                    color: Color(0xFF34D399),
                    size: 20,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'ONLINE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Xenora',
                  ),
                ),
                Text(
                  '${_onlineCount} device aktif',
                  style: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 9,
                    fontFamily: 'Share Tech Mono',
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GlassCard(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Column(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF472B6).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: const Color(0xFFF472B6).withOpacity(0.2),
                    ),
                  ),
                  child: const Icon(
                    Icons.notifications_active_rounded,
                    color: Color(0xFFF472B6),
                    size: 20,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'PESAN',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Xenora',
                  ),
                ),
                Text(
                  '$_unreadMessages belum dibaca',
                  style: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 9,
                    fontFamily: 'Share Tech Mono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  //  QUICK ACTIONS
  // ============================================================
  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'QUICK ACTIONS',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            fontFamily: 'Share Tech Mono',
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: _quickActions.map((action) {
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  // Navigate
                },
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: action['color'].withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: action['color'].withOpacity(0.2),
                          ),
                        ),
                        child: Icon(
                          action['icon'],
                          color: action['color'],
                          size: 20,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        action['label'],
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // ============================================================
  //  ACTIVITY LOG
  // ============================================================
  Widget _buildActivityLog() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'ACTIVITY LOG',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Share Tech Mono',
                  letterSpacing: 2,
                ),
              ),
              Text(
                'View All →',
                style: TextStyle(
                  color: const Color(0xFFD4AF37),
                  fontSize: 9,
                  fontFamily: 'Share Tech Mono',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ..._activityLog.map((log) {
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Colors.white.withOpacity(0.03),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: log['color'].withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Icon(
                      log['icon'],
                      color: log['color'],
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      log['text'],
                      style: TextStyle(
                        color: Colors.grey.shade300,
                        fontSize: 10,
                        fontFamily: 'Share Tech Mono',
                      ),
                    ),
                  ),
                  Text(
                    log['time'],
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 8,
                      fontFamily: 'Share Tech Mono',
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  // ============================================================
  //  DEVICE STATUS
  // ============================================================
  Widget _buildDeviceStatus() {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'DEVICE STATUS',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              fontFamily: 'Share Tech Mono',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.02),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.white.withOpacity(0.04),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      const Text(
                        'TOTAL',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 8,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                      Text(
                        '$_deviceCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Xenora',
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 1,
                  height: 30,
                  color: Colors.white.withOpacity(0.05),
                ),
                Expanded(
                  child: Column(
                    children: [
                      const Text(
                        'ONLINE',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 8,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                      Text(
                        '$_onlineCount',
                        style: const TextStyle(
                          color: Color(0xFF34D399),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Xenora',
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 1,
                  height: 30,
                  color: Colors.white.withOpacity(0.05),
                ),
                Expanded(
                  child: Column(
                    children: [
                      const Text(
                        'OFFLINE',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 8,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                      Text(
                        '${_deviceCount - _onlineCount}',
                        style: const TextStyle(
                          color: Color(0xFFEF4444),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Xenora',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}