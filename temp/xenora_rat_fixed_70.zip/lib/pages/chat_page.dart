// lib/pages/chat_page.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../widgets/glass_card.dart';
import '../utils/helpers.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isTyping = false;
  final ScrollController _scrollController = ScrollController();

  final List<Map<String, dynamic>> _quickReplies = [
    {'text': 'Halo', 'icon': '👋'},
    {'text': 'Ok', 'icon': '👍'},
    {'text': 'Terima kasih', 'icon': '🙏'},
    {'text': 'Siap', 'icon': '💪'},
    {'text': 'Nanti', 'icon': '⏰'},
    {'text': 'Help', 'icon': '🆘'},
  ];

  @override
  void initState() {
    super.initState();
    _initVideo();
    _addWelcomeMessage();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  void _addWelcomeMessage() {
    _messages.add({
      'sender': 'Xenora Bot',
      'message': 'Selamat datang di Xenora X Chat!',
      'time': DateTime.now().toLocal().toString().substring(11, 16),
      'isMe': false,
    });
  }

  @override
  void dispose() {
    _bgController.dispose();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;

    final now = DateTime.now().toLocal().toString().substring(11, 16);

    setState(() {
      _messages.add({
        'sender': 'You',
        'message': text.trim(),
        'time': now,
        'isMe': true,
      });
      _messageController.clear();
      _isTyping = true;
    });

    _scrollToBottom();

    // Simulasi balasan
    Future.delayed(const Duration(seconds: 1 + (text.length / 10)), () {
      final replies = [
        'Pesan diterima! ✅',
        'Baik, akan segera diproses!',
        'Terima kasih! 🙏',
        'Siap! 💪',
        'Ok, tunggu sebentar...',
      ];
      final reply = replies[DateTime.now().second % replies.length];

      setState(() {
        _messages.add({
          'sender': 'Xenora Bot',
          'message': reply,
          'time': DateTime.now().toLocal().toString().substring(11, 16),
          'isMe': false,
        });
        _isTyping = false;
      });

      _scrollToBottom();
    });
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'CHAT',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF34D399).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: const Color(0xFF34D399).withOpacity(0.15),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF34D399),
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'ONLINE',
                  style: TextStyle(
                    color: Color(0xFF34D399),
                    fontSize: 8,
                    fontFamily: 'Share Tech Mono',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),
          Container(color: Colors.black.withOpacity(0.7)),

          SafeArea(
            child: Column(
              children: [
                // Chat Header Info
                GlassCard(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF34D399).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.chat_rounded,
                          color: Color(0xFF34D399),
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${_messages.length} pesan',
                        style: TextStyle(
                          color: Colors.grey.shade400,
                          fontSize: 11,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                      const Spacer(),
                      if (_isTyping)
                        Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFFD4AF37),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Text(
                              'Typing...',
                              style: TextStyle(
                                color: Color(0xFFD4AF37),
                                fontSize: 8,
                                fontFamily: 'Share Tech Mono',
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),

                // Messages
                Expanded(
                  child: ListView.builder(
                    controller: _scrollController,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final msg = _messages[index];
                      return _buildMessageBubble(msg);
                    },
                  ),
                ),

                // Quick Replies
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _quickReplies.map((reply) {
                        return GestureDetector(
                          onTap: () => _sendMessage(reply['text']),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            margin: const EdgeInsets.only(right: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFFD4AF37).withOpacity(0.06),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFFD4AF37).withOpacity(0.08),
                              ),
                            ),
                            child: Row(
                              children: [
                                Text(
                                  reply['icon'],
                                  style: const TextStyle(fontSize: 14),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  reply['text'],
                                  style: TextStyle(
                                    color: Colors.grey.shade400,
                                    fontSize: 10,
                                    fontFamily: 'Share Tech Mono',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),

                // Input
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    border: Border(
                      top: BorderSide(
                        color: Colors.white.withOpacity(0.04),
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.03),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.06),
                            ),
                          ),
                          child: TextField(
                            controller: _messageController,
                            style: const TextStyle(color: Colors.white),
                            onSubmitted: (text) => _sendMessage(text),
                            decoration: InputDecoration(
                              hintText: 'Ketik pesan...',
                              hintStyle: TextStyle(
                                color: Colors.grey.shade600,
                                fontSize: 12,
                              ),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFD4AF37), Color(0xFFB8942A)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFD4AF37).withOpacity(0.3),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: IconButton(
                          onPressed: () => _sendMessage(_messageController.text),
                          icon: const Icon(
                            Icons.send_rounded,
                            color: Colors.black,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> msg) {
    final isMe = msg['isMe'] == true;

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: isMe
              ? LinearGradient(
                  colors: [
                    const Color(0xFFD4AF37).withOpacity(0.15),
                    const Color(0xFFB8942A).withOpacity(0.08),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    Colors.white.withOpacity(0.04),
                    Colors.white.withOpacity(0.01),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(12),
            topRight: const Radius.circular(12),
            bottomLeft: isMe ? const Radius.circular(12) : const Radius.circular(4),
            bottomRight: isMe ? const Radius.circular(4) : const Radius.circular(12),
          ),
          border: Border.all(
            color: isMe
                ? const Color(0xFFD4AF37).withOpacity(0.12)
                : Colors.white.withOpacity(0.04),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Text(
                msg['sender'],
                style: TextStyle(
                  color: const Color(0xFFD4AF37),
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Share Tech Mono',
                ),
              ),
            const SizedBox(height: 2),
            Text(
              msg['message'],
              style: TextStyle(
                color: isMe ? Colors.white : Colors.grey.shade300,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                msg['time'],
                style: TextStyle(
                  color: isMe ? Colors.white54 : Colors.grey.shade500,
                  fontSize: 8,
                  fontFamily: 'Share Tech Mono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}