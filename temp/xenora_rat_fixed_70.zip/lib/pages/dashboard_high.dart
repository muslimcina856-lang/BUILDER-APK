// lib/pages/dashboard_high.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'home_page.dart';
import 'control_page.dart';
import 'pesan_page.dart';
import 'chat_page.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/glass_card.dart';

class DashboardHighPage extends StatefulWidget {
  const DashboardHighPage({super.key});

  @override
  State<DashboardHighPage> createState() => _DashboardHighPageState();
}

class _DashboardHighPageState extends State<DashboardHighPage> {
  late VideoPlayerController _bgController;
  late VideoPlayerController _bannerController;
  bool _bgReady = false;
  bool _bannerReady = false;
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const ControlPage(deviceId: 'device_id', deviceName: 'Device Name'),
    const PesanPage(),
    const ChatPage(),
  ];

  @override
  void initState() {
    super.initState();
    _initVideos();
  }

  void _initVideos() {
    // Background
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));

    // Banner
    _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() => _bannerReady = true);
        _bannerController.setLooping(true);
        _bannerController.setVolume(0.0);
        _bannerController.play();
      }).catchError((e) => print('Banner Video error: $e'));
  }

  @override
  void dispose() {
    _bgController.dispose();
    _bannerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Background Video
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),

          // Dark Overlay
          Container(color: Colors.black.withOpacity(0.6)),

          // Content
          SafeArea(
            child: Column(
              children: [
                // App Bar (Glassmorphism)
                _buildAppBar(),
                // Pages
                Expanded(
                  child: _pages[_currentIndex],
                ),
              ],
            ),
          ),

          // Bottom Navigation (Glassmorphism)
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: BottomNav(
              currentIndex: _currentIndex,
              onTap: (index) {
                setState(() => _currentIndex = index);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.04),
            Colors.white.withOpacity(0.01),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFFD4AF37).withOpacity(0.12),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 30,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: const Color(0xFFD4AF37).withOpacity(0.05),
            blurRadius: 40,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu_rounded, color: Color(0xFFD4AF37)),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
          const Spacer(),
          Image.asset('assets/images/logo.png', height: 36),
          const SizedBox(width: 10),
          Text(
            'XENORA X',
            style: TextStyle(
              color: const Color(0xFFD4AF37),
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: 'Xenora',
              letterSpacing: 3,
              shadows: [
                Shadow(
                  color: const Color(0xFFD4AF37).withOpacity(0.3),
                  blurRadius: 20,
                ),
              ],
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFD4AF37).withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFFD4AF37).withOpacity(0.12),
              ),
            ),
            child: Icon(
              Icons.settings_rounded,
              color: const Color(0xFFD4AF37),
              size: 22,
            ),
          ),
        ],
      ),
    );
  }
}