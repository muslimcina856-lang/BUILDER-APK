// lib/pages/landing_page.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_classic.dart';
import 'dashboard_high.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  int _selectedIndex = -1;

  final List<Map<String, dynamic>> _dashboardOptions = [
    {
      'type': 'classic',
      'title': 'CLASSIC',
      'caption': 'Minimalis · Elegan · Professional',
      'icon': Icons.dashboard_rounded,
      'gradient': [Color(0xFF1a1a2e), Color(0xFF16213e)],
      'description': 'Tampilan bersih dan minimalis dengan fokus pada fungsionalitas.',
    },
    {
      'type': 'high',
      'title': 'HIGH',
      'caption': 'Cyber Gold · Glassmorphism · Premium',
      'icon': Icons.diamond_rounded,
      'gradient': [Color(0xFF1a0a0a), Color(0xFF2d1212)],
      'description': 'Tampilan mewah dengan efek glassmorphism dan aksen emas.',
    },
  ];

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background Video
          if (_bgReady)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgController.value.size.width,
                height: _bgController.value.size.height,
                child: VideoPlayer(_bgController),
              ),
            )
          else
            Container(color: Colors.black),

          // Dark Overlay
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.7),
                  Colors.black.withOpacity(0.85),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // Content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header
                  const SizedBox(height: 20),
                  Image.asset('assets/images/logo.png', height: 80),
                  const SizedBox(height: 12),
                  Text(
                    'XENORA X',
                    style: TextStyle(
                      color: const Color(0xFFD4AF37),
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Xenora',
                      letterSpacing: 6,
                      shadows: [
                        Shadow(
                          color: const Color(0xFFD4AF37).withOpacity(0.3),
                          blurRadius: 30,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'by MAKKAUYTIM',
                    style: TextStyle(
                      color: Colors.grey.shade500,
                      fontSize: 12,
                      fontFamily: 'Share Tech Mono',
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFD4AF37).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFD4AF37).withOpacity(0.2),
                      ),
                    ),
                    child: const Text(
                      'PILIH DASHBOARD',
                      style: TextStyle(
                        color: Color(0xFFD4AF37),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Share Tech Mono',
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.03),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.06),
                      ),
                    ),
                    child: const Text(
                      'Pilih gaya dashboard yang kamu suka',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                        fontFamily: 'Share Tech Mono',
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Dashboard Cards
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _dashboardOptions.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 16),
                    itemBuilder: (context, index) {
                      final option = _dashboardOptions[index];
                      final isSelected = _selectedIndex == index;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedIndex = index),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: option['gradient'],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFFD4AF37)
                                  : Colors.white.withOpacity(0.05),
                              width: isSelected ? 2 : 1,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFFD4AF37).withOpacity(0.3),
                                      blurRadius: 25,
                                      spreadRadius: 5,
                                    ),
                                  ]
                                : [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.4),
                                      blurRadius: 20,
                                      spreadRadius: 2,
                                    ),
                                  ],
                          ),
                          child: Stack(
                            children: [
                              // Glass effect
                              Positioned.fill(
                                child: Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.white.withOpacity(0.04),
                                        Colors.white.withOpacity(0.01),
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                              ),
                              // Corner glow
                              if (isSelected)
                                Positioned(
                                  top: -20,
                                  right: -20,
                                  child: Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFD4AF37).withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                  ),
                                ),
                              Padding(
                                padding: const EdgeInsets.all(20),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(14),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFD4AF37).withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(14),
                                        border: Border.all(
                                          color: const Color(0xFFD4AF37).withOpacity(0.2),
                                        ),
                                      ),
                                      child: Icon(
                                        option['icon'],
                                        color: isSelected
                                            ? const Color(0xFFD4AF37)
                                            : Colors.white54,
                                        size: 30,
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            option['title'],
                                            style: TextStyle(
                                              color: isSelected
                                                  ? const Color(0xFFD4AF37)
                                                  : Colors.white,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              fontFamily: 'Xenora',
                                              letterSpacing: 2,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            option['caption'],
                                            style: TextStyle(
                                              color: isSelected
                                                  ? Colors.white70
                                                  : Colors.grey.shade500,
                                              fontSize: 10,
                                              fontFamily: 'Share Tech Mono',
                                              letterSpacing: 0.5,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            option['description'],
                                            style: TextStyle(
                                              color: Colors.grey.shade600,
                                              fontSize: 9,
                                              fontFamily: 'Share Tech Mono',
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (isSelected)
                                      Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFD4AF37),
                                          shape: BoxShape.circle,
                                          boxShadow: [
                                            BoxShadow(
                                              color: const Color(0xFFD4AF37).withOpacity(0.4),
                                              blurRadius: 12,
                                            ),
                                          ],
                                        ),
                                        child: const Icon(
                                          Icons.check_rounded,
                                          color: Colors.black,
                                          size: 18,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 30),

                  // Continue Button
                  Container(
                    width: double.infinity,
                    height: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: _selectedIndex != -1
                          ? const LinearGradient(
                              colors: [Color(0xFFD4AF37), Color(0xFFB8942A)],
                            )
                          : null,
                      color: _selectedIndex == -1 ? Colors.grey.shade800 : null,
                      boxShadow: _selectedIndex != -1
                          ? [
                              BoxShadow(
                                color: const Color(0xFFD4AF37).withOpacity(0.3),
                                blurRadius: 30,
                                spreadRadius: 5,
                              ),
                            ]
                          : null,
                    ),
                    child: ElevatedButton(
                      onPressed: _selectedIndex == -1 ? null : _saveAndNavigate,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        foregroundColor: _selectedIndex == -1 ? Colors.grey.shade600 : Colors.black,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'LANJUTKAN',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Xenora',
                              letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Icon(
                            Icons.arrow_forward_rounded,
                            size: 20,
                            color: _selectedIndex == -1 ? Colors.grey.shade600 : Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveAndNavigate() async {
    final option = _dashboardOptions[_selectedIndex];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dashboard_type', option['type']);
    await prefs.setBool('has_selected_dashboard', true);

    if (option['type'] == 'classic') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DashboardClassicPage()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DashboardHighPage()),
      );
    }
  }
}