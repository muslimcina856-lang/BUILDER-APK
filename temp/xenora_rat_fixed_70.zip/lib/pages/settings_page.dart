// lib/pages/settings_page.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import '../widgets/glass_card.dart';
import '../widgets/role_badge.dart';
import '../utils/role_helper.dart';
import '../utils/constants.dart';
import '../utils/helpers.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  String _username = '';
  String _role = '';
  String _uid = '';
  bool _notifications = true;
  bool _darkMode = true;
  bool _autoConnect = false;
  bool _biometric = false;
  bool _soundEffects = true;
  bool _vibration = true;

  final List<Map<String, dynamic>> _settingsMenus = [
    {
      'icon': Icons.person_rounded,
      'title': 'Profile',
      'subtitle': 'Ubah informasi profil',
      'color': 0xFF4D8FFF,
      'route': '/profile'
    },
    {
      'icon': Icons.security_rounded,
      'title': 'Keamanan',
      'subtitle': 'Password, biometric, 2FA',
      'color': 0xFFA78BFA,
      'route': '/security'
    },
    {
      'icon': Icons.notifications_rounded,
      'title': 'Notifikasi',
      'subtitle': 'Atur notifikasi',
      'color': 0xFFF472B6,
      'route': '/notifications'
    },
    {
      'icon': Icons.language_rounded,
      'title': 'Bahasa',
      'subtitle': 'Pilih bahasa aplikasi',
      'color': 0xFF34D399,
      'route': '/language'
    },
    {
      'icon': Icons.color_lens_rounded,
      'title': 'Tema',
      'subtitle': 'Ubah tema aplikasi',
      'color': 0xFFFB923C,
      'route': '/theme'
    },
    {
      'icon': Icons.info_rounded,
      'title': 'Tentang',
      'subtitle': 'Versi & informasi',
      'color': 0xFFD4AF37,
      'route': '/about'
    },
    {
      'icon': Icons.devices_rounded,
      'title': 'Device Manager',
      'subtitle': 'Kelola perangkat terhubung',
      'color': 0xFF22D3EE,
      'route': '/devices'
    },
    {
      'icon': Icons.backup_rounded,
      'title': 'Backup & Restore',
      'subtitle': 'Backup data dan restore',
      'color': 0xFFA78BFA,
      'route': '/backup'
    },
  ];

  @override
  void initState() {
    super.initState();
    _initVideo();
    _loadUserData();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('username') ?? 'User';
      _role = prefs.getString('role')?.toUpperCase() ?? 'MEMBER';
      _uid = prefs.getString('uid') ?? 'XENORA-UID-XXXXXXXXXX';
      _notifications = prefs.getBool('notifications') ?? true;
      _darkMode = prefs.getBool('dark_mode') ?? true;
      _autoConnect = prefs.getBool('auto_connect') ?? false;
      _biometric = prefs.getBool('biometric') ?? false;
      _soundEffects = prefs.getBool('sound_effects') ?? true;
      _vibration = prefs.getBool('vibration') ?? true;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications', _notifications);
    await prefs.setBool('dark_mode', _darkMode);
    await prefs.setBool('auto_connect', _autoConnect);
    await prefs.setBool('biometric', _biometric);
    await prefs.setBool('sound_effects', _soundEffects);
    await prefs.setBool('vibration', _vibration);
    Helpers.showToast(context, '✅ Pengaturan disimpan', color: Colors.green);
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final roleData = RoleHelper.getRole(_role);

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'SETTINGS',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
            letterSpacing: 3,
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),
          Container(color: Colors.black.withOpacity(0.7)),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
              child: Column(
                children: [
                  // User Info Card
                  GlassCard(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: roleData.gradient,
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                border: Border.all(
                                  color: roleData.color.withOpacity(0.3),
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: roleData.color.withOpacity(0.2),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: Icon(
                                roleData.icon,
                                color: roleData.color,
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _username.toUpperCase(),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Xenora',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      RoleBadge(
                                        role: _role,
                                        size: 12,
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: Colors.grey.shade800,
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          Helpers.truncate(_uid, 16),
                                          style: TextStyle(
                                            color: Colors.grey.shade500,
                                            fontSize: 7,
                                            fontFamily: 'Share Tech Mono',
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.edit_rounded, color: Color(0xFFD4AF37)),
                              onPressed: () {
                                // Navigate to edit profile
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Settings Menu
                  ..._settingsMenus.map((menu) {
                    return GlassCard(
                      padding: const EdgeInsets.all(14),
                      margin: const EdgeInsets.only(bottom: 8),
                      onTap: () {
                        // Navigate
                        Helpers.showToast(
                          context,
                          '${menu['title']} coming soon',
                          color: Colors.orange,
                        );
                      },
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Color(menu['color']).withOpacity(0.08),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              menu['icon'],
                              color: Color(menu['color']),
                              size: 18,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  menu['title'],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  menu['subtitle'],
                                  style: TextStyle(
                                    color: Colors.grey.shade500,
                                    fontSize: 9,
                                    fontFamily: 'Share Tech Mono',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: Colors.grey,
                          ),
                        ],
                      ),
                    );
                  }).toList(),

                  const SizedBox(height: 16),

                  // Toggle Settings
                  GlassCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildToggleItem(
                          icon: Icons.notifications_rounded,
                          title: 'Notifikasi',
                          subtitle: 'Terima notifikasi push',
                          value: _notifications,
                          onChanged: (val) {
                            setState(() => _notifications = val);
                            _saveSettings();
                          },
                        ),
                        _buildDivider(),
                        _buildToggleItem(
                          icon: Icons.dark_mode_rounded,
                          title: 'Mode Gelap',
                          subtitle: 'Tampilan dark mode',
                          value: _darkMode,
                          onChanged: (val) {
                            setState(() => _darkMode = val);
                            _saveSettings();
                          },
                        ),
                        _buildDivider(),
                        _buildToggleItem(
                          icon: Icons.wifi_rounded,
                          title: 'Auto Connect',
                          subtitle: 'Otomatis konek ke device',
                          value: _autoConnect,
                          onChanged: (val) {
                            setState(() => _autoConnect = val);
                            _saveSettings();
                          },
                        ),
                        _buildDivider(),
                        _buildToggleItem(
                          icon: Icons.fingerprint_rounded,
                          title: 'Biometric',
                          subtitle: 'Login dengan sidik jari',
                          value: _biometric,
                          onChanged: (val) {
                            setState(() => _biometric = val);
                            _saveSettings();
                          },
                        ),
                        _buildDivider(),
                        _buildToggleItem(
                          icon: Icons.volume_up_rounded,
                          title: 'Sound Effects',
                          subtitle: 'Suara efek interaksi',
                          value: _soundEffects,
                          onChanged: (val) {
                            setState(() => _soundEffects = val);
                            _saveSettings();
                          },
                        ),
                        _buildDivider(),
                        _buildToggleItem(
                          icon: Icons.vibration_rounded,
                          title: 'Vibration',
                          subtitle: 'Getaran saat interaksi',
                          value: _vibration,
                          onChanged: (val) {
                            setState(() => _vibration = val);
                            _saveSettings();
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Change Password
                  GlassCard(
                    padding: const EdgeInsets.all(14),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ChangePasswordPage()),
                      );
                    },
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(
                            Icons.lock_rounded,
                            color: Colors.red,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Ubah Password',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Ganti password akun Anda',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 9,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.grey,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Logout
                  GlassCard(
                    padding: const EdgeInsets.all(14),
                    onTap: () {
                      Helpers.showConfirmDialog(
                        context,
                        title: 'Konfirmasi Logout',
                        message: 'Yakin ingin keluar dari akun Anda?',
                        onConfirm: () async {
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.clear();
                          Navigator.pushReplacementNamed(context, '/login');
                        },
                      );
                    },
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(
                            Icons.logout_rounded,
                            color: Colors.red,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Logout',
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Keluar dari akun Anda',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 9,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.grey,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Version
                  Center(
                    child: Column(
                      children: [
                        Image.asset('assets/images/logo.png', height: 30),
                        const SizedBox(height: 4),
                        Text(
                          'XENORA X v1.0.0',
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 9,
                            fontFamily: 'Share Tech Mono',
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'by MAKKAUYTIM',
                          style: TextStyle(
                            color: Colors.grey.shade700,
                            fontSize: 8,
                            fontFamily: 'Share Tech Mono',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFFD4AF37).withOpacity(0.08),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: const Color(0xFFD4AF37),
            size: 18,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 9,
                  fontFamily: 'Share Tech Mono',
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: const Color(0xFFD4AF37),
          activeTrackColor: const Color(0xFFD4AF37).withOpacity(0.3),
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return Divider(
      color: Colors.white.withOpacity(0.04),
      height: 1,
    );
  }
}