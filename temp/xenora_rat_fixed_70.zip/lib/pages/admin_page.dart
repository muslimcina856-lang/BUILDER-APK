// lib/pages/admin_page.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../widgets/glass_card.dart';
import '../utils/constants.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;

  final List<Map<String, dynamic>> _users = [
    {'name': 'User1', 'role': 'MEMBER', 'status': 'Active', 'email': 'user1@mail.com'},
    {'name': 'User2', 'role': 'VIP', 'status': 'Active', 'email': 'user2@mail.com'},
    {'name': 'User3', 'role': 'RESELLER', 'status': 'Inactive', 'email': 'user3@mail.com'},
    {'name': 'User4', 'role': 'MODERATOR', 'status': 'Active', 'email': 'user4@mail.com'},
  ];

  final List<Map<String, dynamic>> _logs = [
    {'action': 'User Login', 'user': 'User1', 'time': '10:30', 'ip': '192.168.1.1'},
    {'action': 'Device Connected', 'user': 'User2', 'time': '10:25', 'ip': '192.168.1.2'},
    {'action': 'User Logout', 'user': 'User3', 'time': '09:15', 'ip': '192.168.1.3'},
    {'action': 'Settings Changed', 'user': 'User4', 'time': '08:00', 'ip': '192.168.1.4'},
  ];

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'ADMIN PANEL',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Color(0xFFD4AF37)),
            onPressed: () {},
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),
          Container(color: Colors.black.withOpacity(0.7)),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
              child: Column(
                children: [
                  // Stats
                  Row(
                    children: [
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Column(
                            children: [
                              const Text(
                                '4',
                                style: TextStyle(
                                  color: Color(0xFFD4AF37),
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Total Users',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 9,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Column(
                            children: [
                              const Text(
                                '3',
                                style: TextStyle(
                                  color: Color(0xFF34D399),
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Active',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 9,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Column(
                            children: [
                              const Text(
                                '1',
                                style: TextStyle(
                                  color: Color(0xFFEF4444),
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Inactive',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 9,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // User List
                  GlassCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'USERS',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Share Tech Mono',
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ..._users.map((user) {
                          return Container(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Colors.white.withOpacity(0.03),
                                ),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFD4AF37).withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Center(
                                    child: Text(
                                      user['name'][0].toUpperCase(),
                                      style: const TextStyle(
                                        color: Color(0xFFD4AF37),
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        user['name'],
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        user['email'],
                                        style: TextStyle(
                                          color: Colors.grey.shade500,
                                          fontSize: 8,
                                          fontFamily: 'Share Tech Mono',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: user['role'] == 'OWNER'
                                        ? const Color(0xFFD4AF37).withOpacity(0.1)
                                        : user['role'] == 'ADMIN'
                                            ? Colors.pink.withOpacity(0.1)
                                            : user['role'] == 'VIP'
                                                ? Colors.amber.withOpacity(0.1)
                                                : Colors.grey.shade800,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    user['role'],
                                    style: TextStyle(
                                      color: user['role'] == 'OWNER'
                                          ? const Color(0xFFD4AF37)
                                          : user['role'] == 'ADMIN'
                                              ? Colors.pink
                                              : user['role'] == 'VIP'
                                                  ? Colors.amber
                                                  : Colors.grey.shade500,
                                      fontSize: 7,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Share Tech Mono',
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: user['status'] == 'Active'
                                        ? const Color(0xFF34D399).withOpacity(0.1)
                                        : Colors.red.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    user['status'],
                                    style: TextStyle(
                                      color: user['status'] == 'Active'
                                          ? const Color(0xFF34D399)
                                          : Colors.red,
                                      fontSize: 7,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Share Tech Mono',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Activity Logs
                  GlassCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'ACTIVITY LOGS',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Share Tech Mono',
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 10),
                        ..._logs.map((log) {
                          return Container(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Colors.white.withOpacity(0.03),
                                ),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFD4AF37).withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Icon(
                                    Icons.history_rounded,
                                    color: Color(0xFFD4AF37),
                                    size: 12,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        log['action'],
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        '${log['user']} • ${log['ip']}',
                                        style: TextStyle(
                                          color: Colors.grey.shade500,
                                          fontSize: 7,
                                          fontFamily: 'Share Tech Mono',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  log['time'],
                                  style: TextStyle(
                                    color: Colors.grey.shade500,
                                    fontSize: 7,
                                    fontFamily: 'Share Tech Mono',
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}