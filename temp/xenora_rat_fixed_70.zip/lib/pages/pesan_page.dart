// lib/pages/pesan_page.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../widgets/glass_card.dart';
import '../utils/helpers.dart';

class PesanPage extends StatefulWidget {
  const PesanPage({super.key});

  @override
  State<PesanPage> createState() => _PesanPageState();
}

class _PesanPageState extends State<PesanPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  String _filter = 'Semua';

  final List<Map<String, dynamic>> _allMessages = [
    {
      'sender': 'System',
      'message': 'Welcome to Xenora X',
      'time': '10:30',
      'unread': false,
      'type': 'system',
      'icon': Icons.check_circle_rounded,
      'color': 0xFFD4AF37,
    },
    {
      'sender': 'Device 1',
      'message': 'Connected successfully',
      'time': '10:25',
      'unread': true,
      'type': 'device',
      'icon': Icons.devices_rounded,
      'color': 0xFF34D399,
    },
    {
      'sender': 'Device 2',
      'message': 'Offline detected',
      'time': '09:15',
      'unread': true,
      'type': 'device',
      'icon': Icons.warning_rounded,
      'color': 0xFFFF4D6D,
    },
    {
      'sender': 'Admin',
      'message': 'Update available v1.1.0',
      'time': '08:00',
      'unread': false,
      'type': 'system',
      'icon': Icons.update_rounded,
      'color': 0xFF4D8FFF,
    },
    {
      'sender': 'Security',
      'message': 'New login detected from IP 192.168.1.1',
      'time': '07:30',
      'unread': true,
      'type': 'security',
      'icon': Icons.security_rounded,
      'color': 0xFFA78BFA,
    },
    {
      'sender': 'Device 3',
      'message': 'Battery low (15%)',
      'time': '06:45',
      'unread': false,
      'type': 'device',
      'icon': Icons.battery_alert_rounded,
      'color': 0xFFFB923C,
    },
    {
      'sender': 'System',
      'message': 'Backup completed successfully',
      'time': '06:00',
      'unread': false,
      'type': 'system',
      'icon': Icons.backup_rounded,
      'color': 0xFF34D399,
    },
  ];

  final List<String> _filters = ['Semua', 'System', 'Device', 'Security'];

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _filteredMessages {
    if (_filter == 'Semua') return _allMessages;
    return _allMessages.where((m) => m['type'] == _filter.toLowerCase()).toList();
  }

  @override
  Widget build(BuildContext context) {
    final messages = _filteredMessages;
    final unread = _allMessages.where((m) => m['unread'] == true).length;

    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'PESAN & NOTIFIKASI',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Xenora',
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: unread > 0 ? Colors.red.withOpacity(0.1) : Colors.grey.shade800,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: unread > 0 ? Colors.red.withOpacity(0.2) : Colors.grey.shade700,
              ),
            ),
            child: Text(
              '$unread baru',
              style: TextStyle(
                color: unread > 0 ? Colors.red : Colors.grey.shade500,
                fontSize: 9,
                fontFamily: 'Share Tech Mono',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),
          Container(color: Colors.black.withOpacity(0.7)),

          SafeArea(
            child: Column(
              children: [
                // Stats
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            children: [
                              const Text(
                                '${_allMessages.length}',
                                style: TextStyle(
                                  color: Color(0xFFD4AF37),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Total Pesan',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 8,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            children: [
                              Text(
                                '$unread',
                                style: TextStyle(
                                  color: unread > 0 ? Colors.red : Colors.grey.shade500,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Belum Dibaca',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 8,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: GlassCard(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            children: [
                              const Text(
                                '7',
                                style: TextStyle(
                                  color: Color(0xFF34D399),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Xenora',
                                ),
                              ),
                              Text(
                                'Aktif',
                                style: TextStyle(
                                  color: Colors.grey.shade500,
                                  fontSize: 8,
                                  fontFamily: 'Share Tech Mono',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Filters
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: _filters.map((filter) {
                        final isActive = _filter == filter;
                        return GestureDetector(
                          onTap: () => setState(() => _filter = filter),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? const Color(0xFFD4AF37).withOpacity(0.12)
                                  : Colors.grey.shade800,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isActive
                                    ? const Color(0xFFD4AF37).withOpacity(0.2)
                                    : Colors.grey.shade700,
                              ),
                            ),
                            child: Text(
                              filter,
                              style: TextStyle(
                                color: isActive ? const Color(0xFFD4AF37) : Colors.grey.shade400,
                                fontSize: 10,
                                fontFamily: 'Share Tech Mono',
                                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),

                // Message List
                Expanded(
                  child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final msg = messages[index];
                      return _buildMessageCard(msg);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageCard(Map<String, dynamic> msg) {
    final color = Color(msg['color']);
    final isUnread = msg['unread'] == true;

    return GlassCard(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 8),
      borderColor: isUnread ? color.withOpacity(0.15) : null,
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: color.withOpacity(0.15),
              ),
            ),
            child: Icon(
              msg['icon'],
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      msg['sender'],
                      style: TextStyle(
                        color: isUnread ? Colors.white : Colors.grey.shade400,
                        fontSize: 13,
                        fontWeight: isUnread ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (isUnread)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'NEW',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 7,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    const Spacer(),
                    Text(
                      msg['time'],
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 9,
                        fontFamily: 'Share Tech Mono',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  msg['message'],
                  style: TextStyle(
                    color: isUnread ? Colors.white70 : Colors.grey.shade500,
                    fontSize: 11,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    msg['type'].toUpperCase(),
                    style: TextStyle(
                      color: color,
                      fontSize: 7,
                      fontFamily: 'Share Tech Mono',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}