// lib/pages/dashboard_classic.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'home_page.dart';
import 'control_page.dart';
import 'pesan_page.dart';
import 'chat_page.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/glass_card.dart';

class DashboardClassicPage extends StatefulWidget {
  const DashboardClassicPage({super.key});

  @override
  State<DashboardClassicPage> createState() => _DashboardClassicPageState();
}

class _DashboardClassicPageState extends State<DashboardClassicPage> {
  late VideoPlayerController _bgController;
  bool _bgReady = false;
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const ControlPage(deviceId: 'device_id', deviceName: 'Device Name'),
    const PesanPage(),
    const ChatPage(),
  ];

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _bgController = VideoPlayerController.asset('assets/videos/zz.mp4')
      ..initialize().then((_) {
        setState(() => _bgReady = true);
        _bgController.setLooping(true);
        _bgController.setVolume(0.0);
        _bgController.play();
      }).catchError((e) => print('BG Video error: $e'));
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Background Video
          if (_bgReady)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgController.value.size.width,
                  height: _bgController.value.size.height,
                  child: VideoPlayer(_bgController),
                ),
              ),
            )
          else
            Container(color: Colors.black),

          // Dark Overlay
          Container(color: Colors.black.withOpacity(0.7)),

          // Content
          SafeArea(
            child: Column(
              children: [
                // App Bar
                _buildAppBar(),
                // Pages
                Expanded(
                  child: _pages[_currentIndex],
                ),
              ],
            ),
          ),

          // Bottom Navigation
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: BottomNav(
              currentIndex: _currentIndex,
              onTap: (index) {
                setState(() => _currentIndex = index);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu_rounded, color: Color(0xFFD4AF37)),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
          const Spacer(),
          Image.asset('assets/images/logo.png', height: 32),
          const SizedBox(width: 8),
          const Text(
            'XENORA X',
            style: TextStyle(
              color: Color(0xFFD4AF37),
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Xenora',
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.settings_rounded, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}