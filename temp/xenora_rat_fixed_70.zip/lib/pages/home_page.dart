// lib/pages/home_page.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_card.dart';
import '../widgets/role_badge.dart';
import '../utils/role_helper.dart';
import '../utils/constants.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late VideoPlayerController _bannerController;
  bool _bannerReady = false;
  String _username = 'User';
  String _role = 'MEMBER';
  int _deviceCount = 0;
  int _onlineCount = 0;
  int _daysLeft = 30;
  int _totalMessages = 0;
  int _unreadMessages = 0;

  // ===== TYPER WRITER STATE =====
  String _displayText = '';
  int _currentIndex = 0;
  bool _isDeleting = false;
  final List<String> _typingMessages = [
    'Welcome to Xenora X',
    'by MAKKAUYTIM',
    'Control your devices',
    'Stay connected',
  ];

  final List<Map<String, dynamic>> _quickActions = [
    {'icon': Icons.devices_rounded, 'label': 'Device', 'color': Color(0xFF4D8FFF), 'route': '/devices'},
    {'icon': Icons.control_point_rounded, 'label': 'Kontrol', 'color': Color(0xFFA78BFA), 'route': '/control'},
    {'icon': Icons.chat_rounded, 'label': 'Chat', 'color': Color(0xFF34D399), 'route': '/chat'},
    {'icon': Icons.settings_rounded, 'label': 'Settings', 'color': Color(0xFFFB923C), 'route': '/settings'},
  ];

  final List<Map<String, dynamic>> _activityLog = [
    {'icon': Icons.check_circle_rounded, 'text': 'Device 1 connected', 'time': '2m ago', 'color': Color(0xFF34D399)},
    {'icon': Icons.warning_rounded, 'text': 'Device 2 offline', 'time': '15m ago', 'color': Color(0xFFFB923C)},
    {'icon': Icons.message_rounded, 'text': 'Pesan baru dari Admin', 'time': '1h ago', 'color': Color(0xFF4D8FFF)},
    {'icon': Icons.update_rounded, 'text': 'System update available', 'time': '3h ago', 'color': Color(0xFFA78BFA)},
  ];

  @override
  void initState() {
    super.initState();
    _initBanner();
    _loadUserData();
    _startTyperWriter();
  }

  void _initBanner() {
    _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() => _bannerReady = true);
        _bannerController.setLooping(true);
        _bannerController.setVolume(0.0);
        _bannerController.play();
      }).catchError((e) => print('Banner Video error: $e'));
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString('username') ?? 'User';
      _role = prefs.getString('role')?.toUpperCase() ?? 'MEMBER';
      _daysLeft = prefs.getInt('days_left') ?? 30;
      _deviceCount = prefs.getInt('device_count') ?? 0;
      _onlineCount = prefs.getInt('online_count') ?? 0;
      _totalMessages = prefs.getInt('total_messages') ?? 0;
      _unreadMessages = prefs.getInt('unread_messages') ?? 0;
    });
  }

  // ============================================================
  //  TYPER WRITER
  // ============================================================
  void _startTyperWriter() {
    Future.delayed(const Duration(milliseconds: 500), _typeNext);
  }

  void _typeNext() {
    if (_currentIndex >= _typingMessages.length) {
      _currentIndex = 0;
    }

    final fullText = _typingMessages[_currentIndex];
    setState(() {
      _displayText = fullText;
    });

    _currentIndex++;
    Future.delayed(const Duration(seconds: 3), _typeNext);
  }

  @override
  void dispose() {
    _bannerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final roleData = RoleHelper.getRole(_role);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 80),
      child: Column(
        children: [
          // ===== BANNER =====
          _buildBanner(),
          const SizedBox(height: 16),

          // ===== TYPER WRITER =====
          _buildTyperWriter(),
          const SizedBox(height: 16),

          // ===== USER CARD =====
          _buildUserCard(roleData),
          const SizedBox(height: 16),

          // ===== STATS ROW =====
          _buildStatsRow(),
          const SizedBox(height: 16),

          // ===== QUICK ACTIONS =====
          _buildQuickActions(),
          const SizedBox(height: 16),

          // ===== ACTIVITY LOG =====
          _buildActivityLog(),
          const SizedBox(height: 16),

          // ===== DEVICE STATUS =====
          _buildDeviceStatus(),
        ],
      ),
    );
  }

  // ============================================================
  //  BANNER
  // ============================================================
  Widget _buildBanner() {
    return Container(
      height: 100,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video
            if (_bannerReady)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bannerController.value.size.width,
                  height: _bannerController.value.size.height,
                  child: VideoPlayer(_bannerController),
                ),
              )
            else
              Container(
                color: Colors.grey.shade900,
                child: Center(
                  child: CircularProgressIndicator(
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFD4AF37)),
                    strokeWidth: 2,
                  ),
                ),
              ),

            // Overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.2),
                    Colors.black.withOpacity(0.6),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),

            // Content
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Image.asset('assets/images/logo.png', height: 32),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'XENORA X',
                        style: TextStyle(
                          color: const Color(0xFFD4AF37),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Xenora',
                          letterSpacing: 2,
                        ),
                      ),
                      Text(
                        'v1.0.0 • CLASSIC',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 8,
                          fontFamily: 'Share Tech Mono',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF34D399).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: const Color(0xFF34D399).withOpacity(0.15),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 5,
                          height: 5,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF34D399),
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'ONLINE',
                          style: TextStyle(
                            color: const Color(0xFF34D399),
                            fontSize: 7,
                            fontFamily: 'Share Tech Mono',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  TYPER WRITER
  // ============================================================
  Widget _buildTyperWriter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.04),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 20,
            decoration: BoxDecoration(
              color: const Color(0xFFD4AF37),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: _displayText,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontFamily: 'Share Tech Mono',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  TextSpan(
                    text: '|',
                    style: TextStyle(
                      color: const Color(0xFFD4AF37),
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.grey.shade800,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              'TYPING...',
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 6,
                fontFamily: 'Share Tech Mono',
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  USER CARD
  // ============================================================
  Widget _buildUserCard(RoleData roleData) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.04),
        ),
      ),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: roleData.gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: roleData.color.withOpacity(0.2),
                width: 1.5,
              ),
            ),
            child: Icon(
              roleData.icon,
              color: roleData.color,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _username.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Xenora',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    RoleBadge(
                      role: _role,
                      size: 12,
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade800,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '$_daysLeft hari',
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 7,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Stats mini
          Column(
            children: [
              Text(
                '$_deviceCount',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Xenora',
                ),
              ),
              Text(
                'DEVICES',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 7,
                  fontFamily: 'Share Tech Mono',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  STATS ROW
  // ============================================================
  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatItem(
            icon: Icons.wifi_rounded,
            value: '$_onlineCount',
            label: 'ONLINE',
            color: const Color(0xFF34D399),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildStatItem(
            icon: Icons.notifications_rounded,
            value: '$_unreadMessages',
            label: 'PESAN',
            color: const Color(0xFFF472B6),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildStatItem(
            icon: Icons.timer_rounded,
            value: '$_daysLeft',
            label: 'SISA HARI',
            color: _daysLeft <= 3 ? Colors.red : const Color(0xFFD4AF37),
          ),
        ),
      ],
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withOpacity(0.08),
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 18,
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Xenora',
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade500,
              fontSize: 7,
              fontFamily: 'Share Tech Mono',
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  QUICK ACTIONS
  // ============================================================
  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'QUICK ACTIONS',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 9,
            fontWeight: FontWeight.bold,
            fontFamily: 'Share Tech Mono',
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: _quickActions.map((action) {
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  // Navigate
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.02),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: action['color'].withOpacity(0.08),
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        action['icon'],
                        color: action['color'],
                        size: 22,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        action['label'],
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Share Tech Mono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // ============================================================
  //  ACTIVITY LOG
  // ============================================================
  Widget _buildActivityLog() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.04),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'ACTIVITY LOG',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Share Tech Mono',
                  letterSpacing: 2,
                ),
              ),
              Text(
                'View All →',
                style: TextStyle(
                  color: const Color(0xFFD4AF37),
                  fontSize: 8,
                  fontFamily: 'Share Tech Mono',
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ..._activityLog.map((log) {
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Colors.white.withOpacity(0.03),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: log['color'].withOpacity(0.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Icon(
                      log['icon'],
                      color: log['color'],
                      size: 12,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      log['text'],
                      style: TextStyle(
                        color: Colors.grey.shade400,
                        fontSize: 9,
                        fontFamily: 'Share Tech Mono',
                      ),
                    ),
                  ),
                  Text(
                    log['time'],
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 7,
                      fontFamily: 'Share Tech Mono',
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  // ============================================================
  //  DEVICE STATUS
  // ============================================================
  Widget _buildDeviceStatus() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.04),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'DEVICE STATUS',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 9,
              fontWeight: FontWeight.bold,
              fontFamily: 'Share Tech Mono',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _buildDeviceStatusItem('TOTAL', '$_deviceCount', Colors.white),
              _buildDeviceStatusItem('ONLINE', '$_onlineCount', const Color(0xFF34D399)),
              _buildDeviceStatusItem('OFFLINE', '${_deviceCount - _onlineCount}', const Color(0xFFEF4444)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceStatusItem(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.04),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: color.withOpacity(0.06),
          ),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'Xenora',
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 7,
                fontFamily: 'Share Tech Mono',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}