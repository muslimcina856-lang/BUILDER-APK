// lib/services/settings_service.dart
import 'package:shared_preferences/shared_preferences.dart';
import '../models/settings_model.dart';
import 'api_service.dart';

class SettingsService {
  static final SettingsService _instance = SettingsService._internal();
  factory SettingsService() => _instance;
  SettingsService._internal();

  final ApiService _api = ApiService();
  SettingsModel? _cachedSettings;

  // ============================================================
  //  GET SETTINGS
  // ============================================================
  Future<SettingsModel> getSettings() async {
    if (_cachedSettings != null) {
      return _cachedSettings!;
    }

    try {
      final result = await _api.getSettings();
      if (result['success'] == true) {
        _cachedSettings = SettingsModel.fromJson(result['settings'] ?? {});
        return _cachedSettings!;
      }
    } catch (e) {}

    // Fallback to local
    final prefs = await SharedPreferences.getInstance();
    return SettingsModel(
      notifications: prefs.getBool('notifications') ?? true,
      darkMode: prefs.getBool('dark_mode') ?? true,
      autoConnect: prefs.getBool('auto_connect') ?? false,
      biometric: prefs.getBool('biometric') ?? false,
      soundEffects: prefs.getBool('sound_effects') ?? true,
      vibration: prefs.getBool('vibration') ?? true,
      language: prefs.getString('language'),
      theme: prefs.getString('theme'),
      autoLockTimer: prefs.getInt('auto_lock_timer'),
      keepAlive: prefs.getBool('keep_alive') ?? true,
      debugMode: prefs.getBool('debug_mode') ?? false,
    );
  }

  // ============================================================
  //  UPDATE SETTINGS
  // ============================================================
  Future<Map<String, dynamic>> updateSettings(SettingsModel settings) async {
    final result = await _api.updateSettings(settings.toJson());

    if (result['success'] == true) {
      _cachedSettings = settings;

      // Save to local
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('notifications', settings.notifications);
      await prefs.setBool('dark_mode', settings.darkMode);
      await prefs.setBool('auto_connect', settings.autoConnect);
      await prefs.setBool('biometric', settings.biometric);
      await prefs.setBool('sound_effects', settings.soundEffects);
      await prefs.setBool('vibration', settings.vibration);
      if (settings.language != null) {
        await prefs.setString('language', settings.language!);
      }
      if (settings.theme != null) {
        await prefs.setString('theme', settings.theme!);
      }
      if (settings.autoLockTimer != null) {
        await prefs.setInt('auto_lock_timer', settings.autoLockTimer!);
      }
      await prefs.setBool('keep_alive', settings.keepAlive);
      await prefs.setBool('debug_mode', settings.debugMode);
    }

    return result;
  }

  // ============================================================
  //  TOGGLE SETTINGS
  // ============================================================
  Future<SettingsModel> toggleNotifications() async {
    final settings = await getSettings();
    final updated = settings.copyWith(notifications: !settings.notifications);
    await updateSettings(updated);
    return updated;
  }

  Future<SettingsModel> toggleDarkMode() async {
    final settings = await getSettings();
    final updated = settings.copyWith(darkMode: !settings.darkMode);
    await updateSettings(updated);
    return updated;
  }

  Future<SettingsModel> toggleAutoConnect() async {
    final settings = await getSettings();
    final updated = settings.copyWith(autoConnect: !settings.autoConnect);
    await updateSettings(updated);
    return updated;
  }

  Future<SettingsModel> toggleBiometric() async {
    final settings = await getSettings();
    final updated = settings.copyWith(biometric: !settings.biometric);
    await updateSettings(updated);
    return updated;
  }

  // ============================================================
  //  CLEAR CACHE
  // ============================================================
  void clearCache() {
    _cachedSettings = null;
  }
}