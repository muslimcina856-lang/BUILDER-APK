// lib/services/notification_service.dart
import '../models/notification_model.dart';
import 'api_service.dart';
import 'websocket_service.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final ApiService _api = ApiService();
  final WebSocketService _ws = WebSocketService();

  // ============================================================
  //  GET NOTIFICATIONS
  // ============================================================
  Future<List<NotificationModel>> getNotifications() async {
    try {
      final result = await _api.getNotifications();
      if (result['success'] == true) {
        final list = result['notifications'] ?? [];
        return list.map((n) => NotificationModel.fromJson(n)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ============================================================
  //  MARK ALL AS READ
  // ============================================================
  Future<Map<String, dynamic>> markAllAsRead() async {
    return _api.markAllAsRead();
  }

  // ============================================================
  //  DELETE NOTIFICATION
  // ============================================================
  Future<Map<String, dynamic>> deleteNotification(String id) async {
    return _api.deleteNotification(id);
  }

  // ============================================================
  //  LISTEN TO WEBSOCKET NOTIFICATIONS
  // ============================================================
  void listenToNotifications(Function(NotificationModel) onNotification) {
    _ws.onMessage.listen((data) {
      if (data['type'] == 'notification') {
        final notification = NotificationModel.fromJson(data);
        onNotification(notification);
      }
    });
  }

  // ============================================================
  //  SEND LOCAL NOTIFICATION
  // ============================================================
  void sendLocalNotification({
    required String title,
    required String body,
    NotificationType type = NotificationType.info,
    String? route,
  }) {
    final notification = NotificationModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      body: body,
      type: type,
      createdAt: DateTime.now(),
    );
    // Handle local notification
  }
}