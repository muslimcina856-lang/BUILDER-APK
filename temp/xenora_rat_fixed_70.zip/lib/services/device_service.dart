// lib/services/device_service.dart
import '../models/device_model.dart';
import 'api_service.dart';

class DeviceService {
  static final DeviceService _instance = DeviceService._internal();
  factory DeviceService() => _instance;
  DeviceService._internal();

  final ApiService _api = ApiService();

  // ============================================================
  //  GET DEVICES
  // ============================================================
  Future<List<DeviceModel>> getDevices() async {
    try {
      final result = await _api.getDevices();
      if (result['success'] == true) {
        final list = result['devices'] ?? [];
        return list.map((d) => DeviceModel.fromJson(d)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ============================================================
  //  GET DEVICE
  // ============================================================
  Future<DeviceModel?> getDevice(String deviceId) async {
    try {
      final result = await _api.getDevice(deviceId);
      if (result['success'] == true) {
        return DeviceModel.fromJson(result['device'] ?? {});
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  //  REGISTER DEVICE
  // ============================================================
  Future<Map<String, dynamic>> registerDevice({
    required String name,
    required String uid,
    String? model,
    String? brand,
  }) async {
    return _api.registerDevice({
      'name': name,
      'uid': uid,
      'model': model ?? '',
      'brand': brand ?? '',
    });
  }

  // ============================================================
  //  DELETE DEVICE
  // ============================================================
  Future<Map<String, dynamic>> deleteDevice(String deviceId) async {
    return _api.deleteDevice(deviceId);
  }

  // ============================================================
  //  SEND COMMAND
  // ============================================================
  Future<Map<String, dynamic>> sendCommand(
    String deviceId,
    String command, {
    String? extra,
  }) async {
    return _api.sendCommand(deviceId, command, extra: extra);
  }

  // ============================================================
  //  GET ONLINE COUNT
  // ============================================================
  Future<int> getOnlineCount() async {
    final devices = await getDevices();
    return devices.where((d) => d.isOnline).length;
  }

  // ============================================================
  //  GET DEVICE STATS
  // ============================================================
  Future<Map<String, int>> getDeviceStats() async {
    final devices = await getDevices();
    return {
      'total': devices.length,
      'online': devices.where((d) => d.isOnline).length,
      'offline': devices.where((d) => !d.isOnline).length,
    };
  }
}