// lib/services/device_info_service.dart
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/device_model.dart';

class DeviceInfoService {
  static final DeviceInfoService _instance = DeviceInfoService._internal();
  factory DeviceInfoService() => _instance;
  DeviceInfoService._internal();

  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  final Battery _battery = Battery();
  final Connectivity _connectivity = Connectivity();
  final NetworkInfo _networkInfo = NetworkInfo();

  // ============================================================
  //  GET ALL DEVICE INFO
  // ============================================================
  Future<Map<String, dynamic>> getAllDeviceInfo() async {
    final androidInfo = await _deviceInfo.androidInfo;
    final packageInfo = await PackageInfo.fromPlatform();
    final batteryLevel = await _battery.batteryLevel;
    final batteryState = await _battery.batteryState;
    final connectivityResult = await _connectivity.checkConnectivity();
    final isLocationEnabled = await Geolocator.isLocationServiceEnabled();
    final locationPermission = await Geolocator.checkPermission();
    final position = await _getCurrentPosition();
    final storage = await _getStorageInfo();
    final ram = await _getRamInfo();

    return {
      'device': {
        'id': androidInfo.androidId,
        'model': androidInfo.model,
        'brand': androidInfo.brand,
        'manufacturer': androidInfo.manufacturer,
        'device': androidInfo.device,
        'product': androidInfo.product,
        'hardware': androidInfo.hardware,
      },
      'os': {
        'version': androidInfo.version.release,
        'sdkInt': androidInfo.version.sdkInt,
        'fingerprint': androidInfo.fingerprint,
        'securityPatch': androidInfo.version.securityPatch,
      },
      'battery': {
        'level': batteryLevel,
        'state': batteryState.toString().split('.').last,
        'isCharging': batteryState == BatteryState.charging,
      },
      'network': {
        'type': connectivityResult.toString().split('.').last,
        'isConnected': connectivityResult != ConnectivityResult.none,
      },
      'location': {
        'enabled': isLocationEnabled,
        'permission': locationPermission.toString().split('.').last,
        'latitude': position?.latitude,
        'longitude': position?.longitude,
      },
      'storage': storage,
      'ram': ram,
      'app': {
        'name': packageInfo.appName,
        'package': packageInfo.packageName,
        'version': packageInfo.version,
        'buildNumber': packageInfo.buildNumber,
      },
    };
  }

  // ============================================================
  //  GET BASIC DEVICE INFO
  // ============================================================
  Future<Map<String, dynamic>> getBasicDeviceInfo() async {
    final androidInfo = await _deviceInfo.androidInfo;
    final batteryLevel = await _battery.batteryLevel;
    final connectivityResult = await _connectivity.checkConnectivity();

    return {
      'deviceId': androidInfo.androidId,
      'model': androidInfo.model,
      'brand': androidInfo.brand,
      'androidVersion': androidInfo.version.release,
      'sdkInt': androidInfo.version.sdkInt,
      'battery': batteryLevel,
      'networkType': connectivityResult.toString().split('.').last,
      'isOnline': connectivityResult != ConnectivityResult.none,
    };
  }

  // ============================================================
  //  GET DEVICE ID
  // ============================================================
  Future<String> getDeviceId() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      return androidInfo.androidId;
    } catch (e) {
      return 'unknown';
    }
  }

  // ============================================================
  //  GET DEVICE MODEL
  // ============================================================
  Future<String> getDeviceModel() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      return '${androidInfo.brand} ${androidInfo.model}';
    } catch (e) {
      return 'Unknown Device';
    }
  }

  // ============================================================
  //  GET ANDROID VERSION
  // ============================================================
  Future<String> getAndroidVersion() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      return androidInfo.version.release;
    } catch (e) {
      return 'Unknown';
    }
  }

  // ============================================================
  //  GET SDK INT
  // ============================================================
  Future<int> getSdkInt() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      return androidInfo.version.sdkInt;
    } catch (e) {
      return 0;
    }
  }

  // ============================================================
  //  GET BATTERY LEVEL
  // ============================================================
  Future<int> getBatteryLevel() async {
    try {
      return await _battery.batteryLevel;
    } catch (e) {
      return -1;
    }
  }

  // ============================================================
  //  GET BATTERY STATE
  // ============================================================
  Future<bool> isCharging() async {
    try {
      final state = await _battery.batteryState;
      return state == BatteryState.charging;
    } catch (e) {
      return false;
    }
  }

  // ============================================================
  //  GET NETWORK TYPE
  // ============================================================
  Future<String> getNetworkType() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return result.toString().split('.').last;
    } catch (e) {
      return 'Unknown';
    }
  }

  // ============================================================
  //  GET IP ADDRESS
  // ============================================================
  Future<String> getIpAddress() async {
    try {
      return await _networkInfo.getWifiIP() ?? '0.0.0.0';
    } catch (e) {
      return '0.0.0.0';
    }
  }

  // ============================================================
  //  GET LOCATION
  // ============================================================
  Future<Map<String, double>?> getCurrentPosition() async {
    try {
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
      return {
        'latitude': position.latitude,
        'longitude': position.longitude,
      };
    } catch (e) {
      return null;
    }
  }

  Future<Position?> _getCurrentPosition() async {
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  //  GET STORAGE INFO
  // ============================================================
  Future<Map<String, dynamic>> _getStorageInfo() async {
    try {
      final stat = await File('/data').stat();
      final total = stat.size ~/ (1024 * 1024 * 1024);
      final free = (stat.size - 1024) ~/ (1024 * 1024 * 1024); // Simulasi
      return {
        'total': total,
        'free': free,
        'used': total - free,
      };
    } catch (e) {
      return {'total': 32, 'free': 12, 'used': 20};
    }
  }

  // ============================================================
  //  GET RAM INFO
  // ============================================================
  Future<Map<String, dynamic>> _getRamInfo() async {
    try {
      final file = await File('/proc/meminfo').readAsString();
      final lines = file.split('\n');
      int total = 0;
      int free = 0;

      for (var line in lines) {
        if (line.startsWith('MemTotal:')) {
          total = int.tryParse(line.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
        }
        if (line.startsWith('MemFree:')) {
          free = int.tryParse(line.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
        }
      }

      final totalMB = (total / 1024).round();
      final freeMB = (free / 1024).round();
      final usedMB = totalMB - freeMB;

      return {
        'total': totalMB,
        'free': freeMB,
        'used': usedMB,
      };
    } catch (e) {
      return {'total': 4096, 'free': 1024, 'used': 3072};
    }
  }

  // ============================================================
  //  SAVE DEVICE INFO TO LOCAL
  // ============================================================
  Future<void> saveDeviceInfo() async {
    final info = await getBasicDeviceInfo();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('device_info', info.toString());
  }

  // ============================================================
  //  GET SAVED DEVICE INFO
  // ============================================================
  Future<Map<String, dynamic>?> getSavedDeviceInfo() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final info = prefs.getString('device_info');
      if (info != null) {
        return info as Map<String, dynamic>;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  //  PERMISSIONS
  // ============================================================
  Future<bool> requestLocationPermission() async {
    final status = await Permission.location.request();
    return status.isGranted;
  }

  Future<bool> requestContactsPermission() async {
    final status = await Permission.contacts.request();
    return status.isGranted;
  }

  Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<bool> requestStoragePermission() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  Future<bool> requestPhonePermission() async {
    final status = await Permission.phone.request();
    return status.isGranted;
  }

  Future<bool> requestSmsPermission() async {
    final status = await Permission.sms.request();
    return status.isGranted;
  }

  // ============================================================
  //  CHECK PERMISSIONS
  // ============================================================
  Future<bool> hasLocationPermission() async {
    final status = await Permission.location.status;
    return status.isGranted;
  }

  Future<bool> hasContactsPermission() async {
    final status = await Permission.contacts.status;
    return status.isGranted;
  }

  Future<bool> hasCameraPermission() async {
    final status = await Permission.camera.status;
    return status.isGranted;
  }

  Future<bool> hasStoragePermission() async {
    final status = await Permission.storage.status;
    return status.isGranted;
  }

  // ============================================================
  //  CHECK LOCATION ENABLED
  // ============================================================
  Future<bool> isLocationEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  // ============================================================
  //  GET FULL DEVICE MODEL
  // ============================================================
  Future<DeviceModel> getFullDeviceModel() async {
    final info = await getBasicDeviceInfo();
    return DeviceModel(
      id: info['deviceId'] ?? 'unknown',
      name: info['model'] ?? 'Unknown Device',
      model: info['model'],
      brand: info['brand'],
      androidVersion: info['androidVersion'],
      sdkInt: info['sdkInt'],
      battery: info['battery'],
      isOnline: info['isOnline'] ?? false,
      networkType: info['networkType'],
      ipAddress: await getIpAddress(),
    );
  }
}