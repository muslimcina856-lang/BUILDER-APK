// lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // ============================================================
  //  BASE REQUEST
  // ============================================================
  Future<Map<String, dynamic>> _request(
    String endpoint, {
    String method = 'GET',
    Map<String, dynamic>? body,
    Map<String, String>? headers,
    bool useAuth = true,
  }) async {
    final url = Uri.parse('${AppConstants.apiBaseUrl}$endpoint');
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';

    final defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (useAuth && token.isNotEmpty) {
      defaultHeaders['Authorization'] = 'Bearer $token';
    }

    if (headers != null) {
      defaultHeaders.addAll(headers);
    }

    try {
      late http.Response response;

      switch (method.toUpperCase()) {
        case 'GET':
          response = await http.get(url, headers: defaultHeaders);
          break;
        case 'POST':
          response = await http.post(
            url,
            headers: defaultHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
          break;
        case 'PUT':
          response = await http.put(
            url,
            headers: defaultHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
          break;
        case 'DELETE':
          response = await http.delete(url, headers: defaultHeaders);
          break;
        default:
          return {'success': false, 'message': 'Method not supported'};
      }

      final data = jsonDecode(response.body);
      return data;
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // ============================================================
  //  AUTH
  // ============================================================
  Future<Map<String, dynamic>> login(String username, String password) async {
    return _request(
      '/auth/login',
      method: 'POST',
      body: {'username': username, 'password': password},
      useAuth: false,
    );
  }

  Future<Map<String, dynamic>> register(Map<String, dynamic> data) async {
    return _request(
      '/auth/register',
      method: 'POST',
      body: data,
      useAuth: false,
    );
  }

  Future<Map<String, dynamic>> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('username');
    await prefs.remove('role');
    return {'success': true};
  }

  Future<Map<String, dynamic>> getProfile() async {
    return _request('/user/profile');
  }

  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) async {
    return _request(
      '/user/profile',
      method: 'PUT',
      body: data,
    );
  }

  Future<Map<String, dynamic>> changePassword(
    String oldPassword,
    String newPassword,
  ) async {
    return _request(
      '/user/change-password',
      method: 'POST',
      body: {
        'oldPassword': oldPassword,
        'newPassword': newPassword,
      },
    );
  }

  // ============================================================
  //  USER
  // ============================================================
  Future<Map<String, dynamic>> getUsers() async {
    return _request('/admin/users');
  }

  Future<Map<String, dynamic>> getUser(String userId) async {
    return _request('/admin/users/$userId');
  }

  Future<Map<String, dynamic>> updateUser(String userId, Map<String, dynamic> data) async {
    return _request(
      '/admin/users/$userId',
      method: 'PUT',
      body: data,
    );
  }

  Future<Map<String, dynamic>> deleteUser(String userId) async {
    return _request(
      '/admin/users/$userId',
      method: 'DELETE',
    );
  }

  // ============================================================
  //  DEVICE
  // ============================================================
  Future<Map<String, dynamic>> getDevices() async {
    return _request('/devices');
  }

  Future<Map<String, dynamic>> getDevice(String deviceId) async {
    return _request('/devices/$deviceId');
  }

  Future<Map<String, dynamic>> registerDevice(Map<String, dynamic> data) async {
    return _request(
      '/devices/register',
      method: 'POST',
      body: data,
    );
  }

  Future<Map<String, dynamic>> deleteDevice(String deviceId) async {
    return _request(
      '/devices/$deviceId',
      method: 'DELETE',
    );
  }

  // ============================================================
  //  COMMAND
  // ============================================================
  Future<Map<String, dynamic>> sendCommand(
    String deviceId,
    String command, {
    String? extra,
  }) async {
    return _request(
      '/command/send',
      method: 'POST',
      body: {
        'deviceId': deviceId,
        'command': command,
        'extra': extra ?? '',
      },
    );
  }

  Future<Map<String, dynamic>> getCommandHistory(String deviceId) async {
    return _request('/command/history/$deviceId');
  }

  Future<Map<String, dynamic>> getCommandResult(String commandId) async {
    return _request('/command/result/$commandId');
  }

  // ============================================================
  //  MESSAGE
  // ============================================================
  Future<Map<String, dynamic>> getMessages() async {
    return _request('/messages');
  }

  Future<Map<String, dynamic>> sendMessage(Map<String, dynamic> data) async {
    return _request(
      '/messages/send',
      method: 'POST',
      body: data,
    );
  }

  Future<Map<String, dynamic>> markAsRead(String messageId) async {
    return _request(
      '/messages/$messageId/read',
      method: 'PUT',
    );
  }

  Future<Map<String, dynamic>> deleteMessage(String messageId) async {
    return _request(
      '/messages/$messageId',
      method: 'DELETE',
    );
  }

  // ============================================================
  //  NOTIFICATION
  // ============================================================
  Future<Map<String, dynamic>> getNotifications() async {
    return _request('/notifications');
  }

  Future<Map<String, dynamic>> markAllAsRead() async {
    return _request(
      '/notifications/read-all',
      method: 'PUT',
    );
  }

  Future<Map<String, dynamic>> deleteNotification(String id) async {
    return _request(
      '/notifications/$id',
      method: 'DELETE',
    );
  }

  // ============================================================
  //  SETTINGS
  // ============================================================
  Future<Map<String, dynamic>> getSettings() async {
    return _request('/settings');
  }

  Future<Map<String, dynamic>> updateSettings(Map<String, dynamic> data) async {
    return _request(
      '/settings',
      method: 'PUT',
      body: data,
    );
  }
}