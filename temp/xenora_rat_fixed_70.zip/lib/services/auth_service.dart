// lib/services/auth_service.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final ApiService _api = ApiService();

  // ============================================================
  //  LOGIN
  // ============================================================
  Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      final result = await _api.login(username, password);

      if (result['success'] == true) {
        final token = result['token'] ?? '';
        final userData = result['user'] ?? {};

        // Save to shared preferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', token);
        await prefs.setString('username', userData['username'] ?? '');
        await prefs.setString('role', userData['role']?.toUpperCase() ?? 'USER');
        await prefs.setString('uid', userData['uid'] ?? '');
        await prefs.setInt('days_left', userData['daysLeft'] ?? 30);

        return {
          'success': true,
          'token': token,
          'user': UserModel.fromJson(userData),
        };
      }

      return result;
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // ============================================================
  //  REGISTER
  // ============================================================
  Future<Map<String, dynamic>> register({
    required String username,
    required String email,
    required String password,
    String? phoneNumber,
  }) async {
    try {
      final result = await _api.register({
        'username': username,
        'email': email,
        'password': password,
        'phoneNumber': phoneNumber ?? '',
      });

      if (result['success'] == true) {
        // Auto login after register
        return await login(username, password);
      }

      return result;
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // ============================================================
  //  LOGOUT
  // ============================================================
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  // ============================================================
  //  CHECK AUTH
  // ============================================================
  Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    return token != null && token.isNotEmpty;
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('username');
  }

  Future<String?> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('role');
  }

  Future<String?> getUid() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('uid');
  }

  Future<int?> getDaysLeft() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('days_left');
  }

  // ============================================================
  //  GET USER DATA
  // ============================================================
  Future<UserModel?> getUserData() async {
    try {
      final result = await _api.getProfile();
      if (result['success'] == true) {
        return UserModel.fromJson(result['user'] ?? {});
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  //  UPDATE PROFILE
  // ============================================================
  Future<Map<String, dynamic>> updateProfile({
    String? displayName,
    String? phoneNumber,
    String? profileImage,
  }) async {
    final data = {
      if (displayName != null) 'displayName': displayName,
      if (phoneNumber != null) 'phoneNumber': phoneNumber,
      if (profileImage != null) 'profileImage': profileImage,
    };

    return _api.updateProfile(data);
  }

  // ============================================================
  //  CHANGE PASSWORD
  // ============================================================
  Future<Map<String, dynamic>> changePassword(
    String oldPassword,
    String newPassword,
  ) async {
    return _api.changePassword(oldPassword, newPassword);
  }
}