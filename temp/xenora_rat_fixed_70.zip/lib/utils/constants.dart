// lib/utils/constants.dart
class AppConstants {
  static const String appName = 'XENORA X';
  static const String appVersion = '1.0.0';
  static const String author = 'MAKKAUYTIM';

  // API
  static const String apiBaseUrl = 'https://your-c2-server.com/api';
  static const String wsBaseUrl = 'wss://your-c2-server.com:2595';

  // Colors
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFE8C84A);
  static const Color goldDark = Color(0xFFB8942A);

  // SharedPreferences Keys
  static const String keyToken = 'token';
  static const String keyUsername = 'username';
  static const String keyRole = 'role';
  static const String keyDashboardType = 'dashboard_type';
  static const String keyHasSelectedDashboard = 'has_selected_dashboard';
  static const String keyRememberMe = 'remember_me';
  static const String keySavedUsername = 'saved_username';
}