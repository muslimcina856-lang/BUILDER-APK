// lib/utils/theme.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ============================================================
  //  COLORS
  // ============================================================
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFE8C84A);
  static const Color goldDark = Color(0xFFB8942A);
  static const Color goldGlow = Color(0x33D4AF37);
  
  static const Color bgDark = Color(0xFF0D0D0D);
  static const Color bgCard = Color(0x1AFFFFFF);
  static const Color bgGlass = Color(0x08FFFFFF);
  
  static const Color textWhite = Color(0xFFF0ECE4);
  static const Color textWhite70 = Color(0xB3F0ECE4);
  static const Color textWhite54 = Color(0x8AF0ECE4);
  static const Color textWhite30 = Color(0x4DF0ECE4);
  
  static const Color green = Color(0xFF34D399);
  static const Color red = Color(0xFFFF4D6D);
  static const Color orange = Color(0xFFFB923C);
  static const Color purple = Color(0xFFA78BFA);
  static const Color pink = Color(0xFFF472B6);
  static const Color cyan = Color(0xFF22D3EE);
  static const Color blue = Color(0xFF60A5FA);
  
  static const Color border = Color(0x1AFFFFFF);
  static const Color borderGold = Color(0x33D4AF37);

  // ============================================================
  //  DARK THEME
  // ============================================================
  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    primaryColor: gold,
    primaryColorLight: goldLight,
    primaryColorDark: goldDark,
    colorScheme: const ColorScheme.dark(
      primary: gold,
      secondary: gold,
      surface: bgDark,
      background: bgDark,
      error: red,
      onPrimary: Colors.black,
      onSecondary: Colors.black,
      onSurface: textWhite,
      onBackground: textWhite,
    ),
    
    // ============================================================
    //  TEXT THEME
    // ============================================================
    textTheme: TextTheme(
      displayLarge: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 32,
        fontWeight: FontWeight.bold,
        letterSpacing: 1,
      ),
      displayMedium: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 28,
        fontWeight: FontWeight.bold,
        letterSpacing: 0.5,
      ),
      displaySmall: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 24,
        fontWeight: FontWeight.w600,
      ),
      headlineMedium: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 20,
        fontWeight: FontWeight.w600,
      ),
      headlineSmall: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
      titleLarge: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
      titleMedium: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
      titleSmall: GoogleFonts.outfit(
        color: textWhite70,
        fontSize: 12,
        fontWeight: FontWeight.w500,
      ),
      bodyLarge: GoogleFonts.outfit(
        color: textWhite70,
        fontSize: 14,
        height: 1.6,
      ),
      bodyMedium: GoogleFonts.outfit(
        color: textWhite70,
        fontSize: 12,
        height: 1.5,
      ),
      bodySmall: GoogleFonts.outfit(
        color: textWhite54,
        fontSize: 10,
        height: 1.4,
      ),
      labelLarge: GoogleFonts.outfit(
        color: textWhite,
        fontSize: 12,
        fontWeight: FontWeight.w600,
      ),
      labelMedium: GoogleFonts.outfit(
        color: textWhite70,
        fontSize: 10,
        fontWeight: FontWeight.w500,
      ),
      labelSmall: GoogleFonts.outfit(
        color: textWhite54,
        fontSize: 8,
        fontWeight: FontWeight.w400,
      ),
    ),

    // ============================================================
    //  APP BAR THEME
    // ============================================================
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      iconTheme: IconThemeData(color: gold),
      titleTextStyle: TextStyle(
        color: textWhite,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        fontFamily: 'Xenora',
        letterSpacing: 2,
      ),
    ),

    // ============================================================
    //  BUTTON THEME
    // ============================================================
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: gold,
        foregroundColor: Colors.black,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          fontFamily: 'Xenora',
          letterSpacing: 1.5,
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: gold,
        textStyle: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          fontFamily: 'Xenora',
        ),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: gold,
        side: const BorderSide(color: gold),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          fontFamily: 'Xenora',
          letterSpacing: 1.5,
        ),
      ),
    ),

    // ============================================================
    //  INPUT DECORATION THEME
    // ============================================================
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white.withOpacity(0.03),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(
          color: gold,
          width: 1.5,
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(
          color: red,
          width: 1.5,
        ),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(
          color: red,
          width: 1.5,
        ),
      ),
      labelStyle: const TextStyle(
        color: textWhite70,
        fontSize: 12,
        fontFamily: 'Share Tech Mono',
      ),
      hintStyle: const TextStyle(
        color: textWhite30,
        fontSize: 12,
        fontFamily: 'Share Tech Mono',
      ),
      prefixIconColor: gold,
      suffixIconColor: textWhite54,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),

    // ============================================================
    //  CARD THEME
    // ============================================================
    cardTheme: CardTheme(
      color: bgCard,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      borderOnForeground: true,
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
    ),

    // ============================================================
    //  DIALOG THEME
    // ============================================================
    dialogTheme: DialogTheme(
      backgroundColor: bgDark,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: gold.withOpacity(0.15),
        ),
      ),
      titleTextStyle: const TextStyle(
        color: textWhite,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        fontFamily: 'Xenora',
        letterSpacing: 1.5,
      ),
      contentTextStyle: const TextStyle(
        color: textWhite70,
        fontSize: 12,
        fontFamily: 'Share Tech Mono',
      ),
    ),

    // ============================================================
    //  SNACKBAR THEME
    // ============================================================
    snackBarTheme: SnackBarThemeData(
      backgroundColor: bgDark,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: gold.withOpacity(0.15),
        ),
      ),
      behavior: SnackBarBehavior.floating,
      contentTextStyle: const TextStyle(
        color: textWhite,
        fontSize: 12,
        fontFamily: 'Share Tech Mono',
      ),
    ),

    // ============================================================
    //  DIVIDER THEME
    // ============================================================
    dividerTheme: DividerThemeData(
      color: Colors.white.withOpacity(0.04),
      thickness: 1,
      space: 0,
    ),

    // ============================================================
    //  NAVIGATION BAR THEME
    // ============================================================
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: bgDark.withOpacity(0.8),
      elevation: 0,
      indicatorColor: gold.withOpacity(0.12),
      labelTextStyle: MaterialStateProperty.all(
        const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          fontFamily: 'Share Tech Mono',
          letterSpacing: 0.5,
        ),
      ),
      iconTheme: MaterialStateProperty.all(
        const IconThemeData(
          color: textWhite54,
          size: 22,
        ),
      ),
    ),

    // ============================================================
    //  TAB THEME
    // ============================================================
    tabBarTheme: const TabBarTheme(
      labelColor: gold,
      unselectedLabelColor: textWhite54,
      labelStyle: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.bold,
        fontFamily: 'Xenora',
        letterSpacing: 1.5,
      ),
      unselectedLabelStyle: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.normal,
        fontFamily: 'Share Tech Mono',
      ),
      indicator: UnderlineTabIndicator(
        borderSide: BorderSide(color: gold, width: 2),
        insets: EdgeInsets.symmetric(horizontal: 16),
      ),
    ),

    // ============================================================
    //  CHIP THEME
    // ============================================================
    chipTheme: ChipThemeData(
      backgroundColor: Colors.white.withOpacity(0.04),
      selectedColor: gold.withOpacity(0.12),
      labelStyle: const TextStyle(
        color: textWhite70,
        fontSize: 10,
        fontFamily: 'Share Tech Mono',
      ),
      secondaryLabelStyle: const TextStyle(
        color: gold,
        fontSize: 10,
        fontFamily: 'Share Tech Mono',
      ),
      borderSide: BorderSide(
        color: Colors.white.withOpacity(0.06),
      ),
      selectedShadowColor: gold.withOpacity(0.2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),

    // ============================================================
    //  TOOLTIP THEME
    // ============================================================
    tooltipTheme: TooltipThemeData(
      backgroundColor: bgDark,
      textStyle: const TextStyle(
        color: textWhite,
        fontSize: 10,
        fontFamily: 'Share Tech Mono',
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: gold.withOpacity(0.15),
        ),
      ),
    ),
  );

  // ============================================================
  //  LIGHT THEME (Bonus)
  // ============================================================
  static ThemeData lightTheme = darkTheme.copyWith(
    brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF5F5F5),
    colorScheme: const ColorScheme.light(
      primary: goldDark,
      secondary: goldDark,
      surface: Colors.white,
      background: Color(0xFFF5F5F5),
      error: red,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: Color(0xFF1A1A1A),
      onBackground: Color(0xFF1A1A1A),
    ),
    textTheme: darkTheme.textTheme.apply(
      bodyColor: const Color(0xFF1A1A1A),
      displayColor: const Color(0xFF1A1A1A),
    ),
  );

  // ============================================================
  //  CUSTOM STYLES
  // ============================================================
  static BoxDecoration glassDecoration({
    double radius = 16,
    double blur = 16,
    double opacity = 0.04,
    Color? borderColor,
  }) {
    return BoxDecoration(
      gradient: LinearGradient(
        colors: [
          Colors.white.withOpacity(0.04),
          Colors.white.withOpacity(0.01),
        ],
      ),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(
        color: borderColor ?? Colors.white.withOpacity(0.06),
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.3),
          blurRadius: 20,
          spreadRadius: 2,
        ),
      ],
    );
  }

  static BoxDecoration goldGradient({
    double radius = 12,
  }) {
    return BoxDecoration(
      gradient: const LinearGradient(
        colors: [gold, goldDark],
      ),
      borderRadius: BorderRadius.circular(radius),
      boxShadow: [
        BoxShadow(
          color: gold.withOpacity(0.3),
          blurRadius: 20,
        ),
      ],
    );
  }

  static BoxDecoration darkGlass({
    double radius = 16,
    Color? borderColor,
  }) {
    return BoxDecoration(
      color: Colors.black.withOpacity(0.6),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(
        color: borderColor ?? Colors.white.withOpacity(0.04),
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.3),
          blurRadius: 20,
          spreadRadius: 2,
        ),
      ],
    );
  }

  // ============================================================
  //  TEXT STYLES
  // ============================================================
  static TextStyle get goldTitle => const TextStyle(
    color: gold,
    fontSize: 20,
    fontWeight: FontWeight.bold,
    fontFamily: 'Xenora',
    letterSpacing: 2,
  );

  static TextStyle get goldSubtitle => const TextStyle(
    color: goldLight,
    fontSize: 14,
    fontWeight: FontWeight.w600,
    fontFamily: 'Share Tech Mono',
    letterSpacing: 1,
  );

  static TextStyle get whiteTitle => const TextStyle(
    color: textWhite,
    fontSize: 18,
    fontWeight: FontWeight.bold,
    fontFamily: 'Xenora',
    letterSpacing: 1.5,
  );

  static TextStyle get monoText => const TextStyle(
    color: textWhite70,
    fontSize: 12,
    fontFamily: 'Share Tech Mono',
    letterSpacing: 0.5,
  );

  static TextStyle get monoSmall => const TextStyle(
    color: textWhite54,
    fontSize: 10,
    fontFamily: 'Share Tech Mono',
    letterSpacing: 0.3,
  );

  // ============================================================
  //  SHADOWS
  // ============================================================
  static List<BoxShadow> get glowShadow => [
    BoxShadow(
      color: gold.withOpacity(0.15),
      blurRadius: 30,
      spreadRadius: 5,
    ),
  ];

  static List<BoxShadow> get glassShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.3),
      blurRadius: 20,
      spreadRadius: 2,
    ),
  ];

  // ============================================================
  //  GRADIENTS
  // ============================================================
  static const LinearGradient goldGradient = LinearGradient(
    colors: [gold, goldDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGradient = LinearGradient(
    colors: [Color(0xFF0D0D0D), Color(0xFF1A1A1A)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const RadialGradient glowGradient = RadialGradient(
    colors: [goldGlow, Colors.transparent],
    center: Alignment.center,
    radius: 0.6,
  );

  // ============================================================
  //  ANIMATIONS
  // ============================================================
  static const Duration fastAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 400);
  static const Duration slowAnimation = Duration(milliseconds: 600);

  static const Curve curve = Curves.easeOutCubic;
  static const Curve bounceCurve = Curves.easeOutBack;
}