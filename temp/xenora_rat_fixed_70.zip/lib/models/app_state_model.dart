// lib/models/app_state_model.dart
import 'user_model.dart';
import 'device_model.dart';
import 'settings_model.dart';

class AppStateModel {
  final UserModel? user;
  final List<DeviceModel> devices;
  final DeviceModel? selectedDevice;
  final SettingsModel settings;
  final bool isLoading;
  final String? error;
  final bool isConnected;

  AppStateModel({
    this.user,
    this.devices = const [],
    this.selectedDevice,
    required this.settings,
    this.isLoading = false,
    this.error,
    this.isConnected = false,
  });

  factory AppStateModel.initial() {
    return AppStateModel(
      settings: SettingsModel(),
    );
  }

  AppStateModel copyWith({
    UserModel? user,
    List<DeviceModel>? devices,
    DeviceModel? selectedDevice,
    SettingsModel? settings,
    bool? isLoading,
    String? error,
    bool? isConnected,
  }) {
    return AppStateModel(
      user: user ?? this.user,
      devices: devices ?? this.devices,
      selectedDevice: selectedDevice ?? this.selectedDevice,
      settings: settings ?? this.settings,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isConnected: isConnected ?? this.isConnected,
    );
  }

  int get deviceCount => devices.length;
  int get onlineCount => devices.where((d) => d.isOnline).length;
  int get offlineCount => deviceCount - onlineCount;
  bool get hasDevices => devices.isNotEmpty;
  bool get hasSelectedDevice => selectedDevice != null;
}