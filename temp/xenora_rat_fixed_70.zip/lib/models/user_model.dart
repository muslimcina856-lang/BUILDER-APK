// lib/models/user_model.dart
class UserModel {
  final String id;
  final String username;
  final String email;
  final String role;
  final String? displayName;
  final String? phoneNumber;
  final String? profileImage;
  final DateTime? createdAt;
  final DateTime? lastLogin;
  final bool isActive;
  final bool isVerified;
  final int? daysLeft;
  final String? uid;

  UserModel({
    required this.id,
    required this.username,
    required this.email,
    required this.role,
    this.displayName,
    this.phoneNumber,
    this.profileImage,
    this.createdAt,
    this.lastLogin,
    this.isActive = true,
    this.isVerified = false,
    this.daysLeft,
    this.uid,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      role: json['role'] ?? 'USER',
      displayName: json['displayName'],
      phoneNumber: json['phoneNumber'],
      profileImage: json['profileImage'],
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
      lastLogin: json['lastLogin'] != null ? DateTime.parse(json['lastLogin']) : null,
      isActive: json['isActive'] ?? true,
      isVerified: json['isVerified'] ?? false,
      daysLeft: json['daysLeft'],
      uid: json['uid'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'email': email,
      'role': role,
      'displayName': displayName,
      'phoneNumber': phoneNumber,
      'profileImage': profileImage,
      'createdAt': createdAt?.toIso8601String(),
      'lastLogin': lastLogin?.toIso8601String(),
      'isActive': isActive,
      'isVerified': isVerified,
      'daysLeft': daysLeft,
      'uid': uid,
    };
  }

  UserModel copyWith({
    String? id,
    String? username,
    String? email,
    String? role,
    String? displayName,
    String? phoneNumber,
    String? profileImage,
    DateTime? createdAt,
    DateTime? lastLogin,
    bool? isActive,
    bool? isVerified,
    int? daysLeft,
    String? uid,
  }) {
    return UserModel(
      id: id ?? this.id,
      username: username ?? this.username,
      email: email ?? this.email,
      role: role ?? this.role,
      displayName: displayName ?? this.displayName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      profileImage: profileImage ?? this.profileImage,
      createdAt: createdAt ?? this.createdAt,
      lastLogin: lastLogin ?? this.lastLogin,
      isActive: isActive ?? this.isActive,
      isVerified: isVerified ?? this.isVerified,
      daysLeft: daysLeft ?? this.daysLeft,
      uid: uid ?? this.uid,
    );
  }

  String get initials {
    final name = displayName ?? username;
    if (name.isEmpty) return '?';
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.substring(0, 1).toUpperCase();
  }
}