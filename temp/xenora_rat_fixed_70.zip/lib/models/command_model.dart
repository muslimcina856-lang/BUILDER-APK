// lib/models/command_model.dart
class CommandModel {
  final String id;
  final String deviceId;
  final String command;
  final String? extra;
  final CommandStatus status;
  final DateTime sentAt;
  final DateTime? executedAt;
  final Map<String, dynamic>? result;
  final String? error;

  CommandModel({
    required this.id,
    required this.deviceId,
    required this.command,
    this.extra,
    this.status = CommandStatus.pending,
    required this.sentAt,
    this.executedAt,
    this.result,
    this.error,
  });

  factory CommandModel.fromJson(Map<String, dynamic> json) {
    return CommandModel(
      id: json['id'] ?? '',
      deviceId: json['deviceId'] ?? '',
      command: json['command'] ?? '',
      extra: json['extra'],
      status: CommandStatus.values.firstWhere(
        (e) => e.toString() == 'CommandStatus.${json['status']}',
        orElse: () => CommandStatus.pending,
      ),
      sentAt: json['sentAt'] != null ? DateTime.parse(json['sentAt']) : DateTime.now(),
      executedAt: json['executedAt'] != null ? DateTime.parse(json['executedAt']) : null,
      result: json['result'],
      error: json['error'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'deviceId': deviceId,
      'command': command,
      'extra': extra,
      'status': status.toString().split('.').last,
      'sentAt': sentAt.toIso8601String(),
      'executedAt': executedAt?.toIso8601String(),
      'result': result,
      'error': error,
    };
  }

  bool get isCompleted => status == CommandStatus.success || status == CommandStatus.failed;
  bool get isSuccess => status == CommandStatus.success;
  bool get isPending => status == CommandStatus.pending;
  bool get isRunning => status == CommandStatus.running;
}

enum CommandStatus {
  pending,
  running,
  success,
  failed,
}