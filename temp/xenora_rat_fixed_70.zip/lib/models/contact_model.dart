// lib/models/contact_model.dart
class ContactModel {
  final String id;
  final String name;
  final String? number;
  final String? email;
  final String? photoUrl;
  final List<String>? phoneNumbers;
  final List<String>? emails;
  final String? company;
  final String? jobTitle;
  final DateTime? createdAt;
  final bool isFavorite;

  ContactModel({
    required this.id,
    required this.name,
    this.number,
    this.email,
    this.photoUrl,
    this.phoneNumbers,
    this.emails,
    this.company,
    this.jobTitle,
    this.createdAt,
    this.isFavorite = false,
  });

  factory ContactModel.fromJson(Map<String, dynamic> json) {
    return ContactModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      number: json['number'],
      email: json['email'],
      photoUrl: json['photoUrl'],
      phoneNumbers: json['phoneNumbers'] != null ? List<String>.from(json['phoneNumbers']) : null,
      emails: json['emails'] != null ? List<String>.from(json['emails']) : null,
      company: json['company'],
      jobTitle: json['jobTitle'],
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
      isFavorite: json['isFavorite'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'number': number,
      'email': email,
      'photoUrl': photoUrl,
      'phoneNumbers': phoneNumbers,
      'emails': emails,
      'company': company,
      'jobTitle': jobTitle,
      'createdAt': createdAt?.toIso8601String(),
      'isFavorite': isFavorite,
    };
  }

  String get initials {
    if (name.isEmpty) return '?';
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.substring(0, 1).toUpperCase();
  }
}