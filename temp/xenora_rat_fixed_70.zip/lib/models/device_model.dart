// lib/models/device_model.dart
class DeviceModel {
  final String id;
  final String name;
  final String? model;
  final String? brand;
  final String? androidVersion;
  final int? sdkInt;
  final String? ipAddress;
  final String? networkType;
  final String? carrier;
  final int? battery;
  final bool isCharging;
  final bool isOnline;
  final DateTime? connectedAt;
  final DateTime? lastSeen;
  final String? uid;
  final Map<String, dynamic>? status;
  final Map<String, dynamic>? info;

  DeviceModel({
    required this.id,
    required this.name,
    this.model,
    this.brand,
    this.androidVersion,
    this.sdkInt,
    this.ipAddress,
    this.networkType,
    this.carrier,
    this.battery,
    this.isCharging = false,
    this.isOnline = false,
    this.connectedAt,
    this.lastSeen,
    this.uid,
    this.status,
    this.info,
  });

  factory DeviceModel.fromJson(Map<String, dynamic> json) {
    return DeviceModel(
      id: json['id'] ?? '',
      name: json['name'] ?? 'Unknown Device',
      model: json['model'],
      brand: json['brand'],
      androidVersion: json['androidVersion'],
      sdkInt: json['sdkInt'],
      ipAddress: json['ipAddress'],
      networkType: json['networkType'],
      carrier: json['carrier'],
      battery: json['battery'],
      isCharging: json['isCharging'] ?? false,
      isOnline: json['isOnline'] ?? false,
      connectedAt: json['connectedAt'] != null ? DateTime.parse(json['connectedAt']) : null,
      lastSeen: json['lastSeen'] != null ? DateTime.parse(json['lastSeen']) : null,
      uid: json['uid'],
      status: json['status'],
      info: json['info'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'model': model,
      'brand': brand,
      'androidVersion': androidVersion,
      'sdkInt': sdkInt,
      'ipAddress': ipAddress,
      'networkType': networkType,
      'carrier': carrier,
      'battery': battery,
      'isCharging': isCharging,
      'isOnline': isOnline,
      'connectedAt': connectedAt?.toIso8601String(),
      'lastSeen': lastSeen?.toIso8601String(),
      'uid': uid,
      'status': status,
      'info': info,
    };
  }

  String get batteryStatus {
    if (battery == null) return 'Unknown';
    if (battery! > 60) return 'Good';
    if (battery! > 20) return 'Low';
    return 'Critical';
  }

  Color get batteryColor {
    if (battery == null) return Colors.grey;
    if (battery! > 60) return const Color(0xFF34D399);
    if (battery! > 20) return const Color(0xFFFB923C);
    return const Color(0xFFFF4D6D);
  }

  String get uptime {
    if (connectedAt == null) return '-';
    final duration = DateTime.now().difference(connectedAt!);
    final days = duration.inDays;
    final hours = duration.inHours % 24;
    final minutes = duration.inMinutes % 60;
    if (days > 0) return '${days}d ${hours}h';
    if (hours > 0) return '${hours}h ${minutes}m';
    return '${minutes}m';
  }
}