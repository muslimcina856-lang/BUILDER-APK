// lib/models/settings_model.dart
class SettingsModel {
  final bool notifications;
  final bool darkMode;
  final bool autoConnect;
  final bool biometric;
  final bool soundEffects;
  final bool vibration;
  final String? language;
  final String? theme;
  final int? autoLockTimer;
  final bool keepAlive;
  final bool debugMode;

  SettingsModel({
    this.notifications = true,
    this.darkMode = true,
    this.autoConnect = false,
    this.biometric = false,
    this.soundEffects = true,
    this.vibration = true,
    this.language,
    this.theme,
    this.autoLockTimer,
    this.keepAlive = true,
    this.debugMode = false,
  });

  factory SettingsModel.fromJson(Map<String, dynamic> json) {
    return SettingsModel(
      notifications: json['notifications'] ?? true,
      darkMode: json['darkMode'] ?? true,
      autoConnect: json['autoConnect'] ?? false,
      biometric: json['biometric'] ?? false,
      soundEffects: json['soundEffects'] ?? true,
      vibration: json['vibration'] ?? true,
      language: json['language'],
      theme: json['theme'],
      autoLockTimer: json['autoLockTimer'],
      keepAlive: json['keepAlive'] ?? true,
      debugMode: json['debugMode'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'notifications': notifications,
      'darkMode': darkMode,
      'autoConnect': autoConnect,
      'biometric': biometric,
      'soundEffects': soundEffects,
      'vibration': vibration,
      'language': language,
      'theme': theme,
      'autoLockTimer': autoLockTimer,
      'keepAlive': keepAlive,
      'debugMode': debugMode,
    };
  }

  SettingsModel copyWith({
    bool? notifications,
    bool? darkMode,
    bool? autoConnect,
    bool? biometric,
    bool? soundEffects,
    bool? vibration,
    String? language,
    String? theme,
    int? autoLockTimer,
    bool? keepAlive,
    bool? debugMode,
  }) {
    return SettingsModel(
      notifications: notifications ?? this.notifications,
      darkMode: darkMode ?? this.darkMode,
      autoConnect: autoConnect ?? this.autoConnect,
      biometric: biometric ?? this.biometric,
      soundEffects: soundEffects ?? this.soundEffects,
      vibration: vibration ?? this.vibration,
      language: language ?? this.language,
      theme: theme ?? this.theme,
      autoLockTimer: autoLockTimer ?? this.autoLockTimer,
      keepAlive: keepAlive ?? this.keepAlive,
      debugMode: debugMode ?? this.debugMode,
    );
  }
}