// lib/models/notification_model.dart
class NotificationModel {
  final String id;
  final String title;
  final String body;
  final String? icon;
  final String? imageUrl;
  final NotificationType type;
  final NotificationPriority priority;
  final DateTime createdAt;
  final bool isRead;
  final Map<String, dynamic>? action;
  final String? route;

  NotificationModel({
    required this.id,
    required this.title,
    required this.body,
    this.icon,
    this.imageUrl,
    this.type = NotificationType.info,
    this.priority = NotificationPriority.normal,
    required this.createdAt,
    this.isRead = false,
    this.action,
    this.route,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      body: json['body'] ?? '',
      icon: json['icon'],
      imageUrl: json['imageUrl'],
      type: NotificationType.values.firstWhere(
        (e) => e.toString() == 'NotificationType.${json['type']}',
        orElse: () => NotificationType.info,
      ),
      priority: NotificationPriority.values.firstWhere(
        (e) => e.toString() == 'NotificationPriority.${json['priority']}',
        orElse: () => NotificationPriority.normal,
      ),
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : DateTime.now(),
      isRead: json['isRead'] ?? false,
      action: json['action'],
      route: json['route'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'icon': icon,
      'imageUrl': imageUrl,
      'type': type.toString().split('.').last,
      'priority': priority.toString().split('.').last,
      'createdAt': createdAt.toIso8601String(),
      'isRead': isRead,
      'action': action,
      'route': route,
    };
  }

  String get timeAgo {
    final diff = DateTime.now().difference(createdAt);
    if (diff.inDays > 7) {
      return '${diff.inDays} hari lalu';
    } else if (diff.inDays > 0) {
      return '${diff.inDays} hari lalu';
    } else if (diff.inHours > 0) {
      return '${diff.inHours} jam lalu';
    } else if (diff.inMinutes > 0) {
      return '${diff.inMinutes} menit lalu';
    } else {
      return 'Baru saja';
    }
  }
}

enum NotificationType {
  info,
  success,
  warning,
  error,
  system,
}

enum NotificationPriority {
  low,
  normal,
  high,
  critical,
}