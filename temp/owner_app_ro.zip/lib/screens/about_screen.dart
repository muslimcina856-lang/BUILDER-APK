import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:earl_builder_owner/config.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xxxl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.hero),
                child: Image.asset(
                  'ic_launcher-playstore.png',
                  width: 64,
                  height: 64,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Center(child: Text(OwnerConfig.appName, style: AppText.title)),
            const SizedBox(height: AppSpacing.xs),
            Center(
              child: Text('Owner management panel', style: AppText.subtitle),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            const Text('ABOUT THIS PANEL', style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.md),
            Text(
              'The Earl Builder owner panel lets you manage users, grant '
              'credits, generate redeem codes, and control the maintenance '
              'state of the build server.',
              style: AppText.body.copyWith(
                color: AppColors.textSecondary,
                height: 1.6,
              ),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            const Text('CONTACT', style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.md),
            _LinkTile(
              icon: Icons.person_rounded,
              label: 'Owner',
              subtitle: 'Get in touch with the developer',
              onTap: () => _openLink(OwnerConfig.ownerLink),
            ),
            const SizedBox(height: AppSpacing.sm),
            _LinkTile(
              icon: Icons.campaign_rounded,
              label: 'Channel',
              subtitle: 'Latest updates and announcements',
              onTap: () => _openLink(OwnerConfig.channelLink),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            Center(
              child: GestureDetector(
                onTap: () => _openLink('https://app.earlstore.online/privacy'),
                child: Text(
                  '© 2026 Earlxz. All rights reserved.',
                  style: AppText.caption.copyWith(color: AppColors.textDisabled),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LinkTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _LinkTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Row(
            children: [
              Icon(icon, size: AppIcons.lg, color: AppColors.textPrimary),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: AppText.heading.copyWith(fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: AppText.subtitle),
                  ],
                ),
              ),
              const Icon(
                Icons.open_in_new_rounded,
                size: AppIcons.sm,
                color: AppColors.textMuted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
