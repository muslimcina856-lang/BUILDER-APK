import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/services/owner_auth_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class OwnerLoginScreen extends StatefulWidget {
  final ValueChanged<String> onAuthenticated;

  const OwnerLoginScreen({super.key, required this.onAuthenticated});

  @override
  State<OwnerLoginScreen> createState() => _OwnerLoginScreenState();
}

class _OwnerLoginScreenState extends State<OwnerLoginScreen> {
  final _controller = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final key = _controller.text.trim();
    if (key.length < 16) {
      setState(() => _error = 'Kunci owner mesti sekurang-kurangnya 16 aksara.');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final valid = await OwnerApiService.verifyApiKey(key);
      if (!valid) {
        if (mounted) setState(() => _error = 'Kunci owner tidak sah atau server belum dikonfigurasi.');
        return;
      }
      await OwnerAuthService.saveApiKey(key);
      OwnerApiService.setApiKey(key);
      if (mounted) widget.onAuthenticated(key);
    } on DioException {
      if (mounted) setState(() => _error = 'Tidak dapat menyambung ke server.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(AppSpacing.xxl),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Container(
                padding: const EdgeInsets.all(AppSpacing.xxl),
                decoration: BoxDecoration(
                  color: AppColors.bgElevated,
                  borderRadius: BorderRadius.circular(AppRadius.hero),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(AppRadius.input),
                        child: Image.asset(
                          'ic_launcher-playstore.png',
                          width: 52,
                          height: 52,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    const Text('Owner Access', style: AppText.title, textAlign: TextAlign.center),
                    const SizedBox(height: AppSpacing.xxl),
                    TextField(
                      controller: _controller,
                      obscureText: _obscure,
                      autocorrect: false,
                      enableSuggestions: false,
                      onSubmitted: (_) {
                        if (!_loading) _login();
                      },
                      decoration: InputDecoration(
                        labelText: 'Owner API Key',
                        errorText: _error,
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _obscure = !_obscure),
                          icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    FilledButton.icon(
                      onPressed: _loading ? null : _login,
                      icon: _loading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.lock_open_rounded),
                      label: const Text('MASUK'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
