package com.google.android.gms.persistent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
