import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';


class QRGenerator extends StatefulWidget {

  const QRGenerator({super.key});


  @override
  State<QRGenerator> createState() =>
      _QRGeneratorState();

}



class _QRGeneratorState
    extends State<QRGenerator> {


  final TextEditingController controller =
      TextEditingController();



  String data =
      "Raven DarkNote";



  @override
  void dispose() {

    controller.dispose();

    super.dispose();

  }



  void buatQR() {


    final text =
        controller.text.trim();



    if (text.isEmpty) {

      return;

    }



    setState(() {

      data = text;

    });


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("QR Generator"),

      ),



      body: Padding(

        padding:
            const EdgeInsets.all(20),



        child: Column(

          children: [


            TextField(

              controller:
                  controller,


              decoration:
                 