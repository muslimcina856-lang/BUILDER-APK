static Future<TabunganModel?> load() async {
  try {

    final prefs =
        await SharedPreferences.getInstance();


    final data =
        prefs.getString(_key);


    if (data == null || data.isEmpty) {
      return null;
    }


    final json =
        jsonDecode(data);


    if (json is! Map<String, dynamic>) {
      return null;
    }


    return TabunganModel.fromJson(json);


  } catch (e) {

    return null;

  }
}