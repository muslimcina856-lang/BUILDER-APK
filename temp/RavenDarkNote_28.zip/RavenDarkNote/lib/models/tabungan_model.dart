class TabunganModel {

  String nama;

  double target;

  double saldo;



  TabunganModel({

    required this.nama,

    required this.target,

    required this.saldo,

  });



  double get progress {

    if (target <= 0) {

      return 0;

    }


    double hasil = saldo / target;


    if (hasil > 1) {

      return 1;

    }


    if (hasil < 0) {

      return 0;

    }


    return hasil;

  }



  Map<String, dynamic> toJson() {

    return {

      "nama": nama,

      "target": target,

      "saldo": saldo,

    };

  }



  factory TabunganModel.fromJson(
      Map<String, dynamic> json
  ) {

    return TabunganModel(

      nama: json["nama"] ?? "",


      target:
          (json["target"] ?? 0).toDouble(),


      saldo:
          (json["saldo"] ?? 0).toDouble(),

    );

  }

}