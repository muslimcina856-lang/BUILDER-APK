import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/tabungan_model.dart';



class TabunganService{


static Future<void> save(
TabunganModel data
) async{


final prefs =
await SharedPreferences.getInstance();



await prefs.setString(

"tabungan",

jsonEncode(
data.toJson()
),

);


}



static Future<TabunganModel?> load()
async{


final prefs =
await SharedPreferences.getInstance();



String? data =
prefs.getString("tabungan");



if(data == null){

return null;

}



return TabunganModel.fromJson(

jsonDecode(data)

);


}



static Future<void> delete()
async{


final prefs =
await SharedPreferences.getInstance();


await prefs.remove("tabungan");


}


}