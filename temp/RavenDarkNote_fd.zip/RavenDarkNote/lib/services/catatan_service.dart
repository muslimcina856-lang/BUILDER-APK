import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/catatan_model.dart';



class CatatanService {


static Future<void> save(
List<CatatanModel> data
) async {


final prefs =
await SharedPreferences.getInstance();


String jsonData =
jsonEncode(

data.map(
(e)=>e.toJson()
).toList()

);


await prefs.setString(
"catatan",
jsonData
);


}



static Future<List<CatatanModel>> load()
async {


final prefs =
await SharedPreferences.getInstance();


String? data =
prefs.getString("catatan");



if(data == null){

return [];

}



List hasil =
jsonDecode(data);



return hasil.map(

(e)=>CatatanModel.fromJson(e)

).toList();



}


}