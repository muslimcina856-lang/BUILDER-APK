import 'package:shared_preferences/shared_preferences.dart';


class ThemeService{


static Future<void> saveTheme(
String theme
) async{


final prefs =
await SharedPreferences.getInstance();


await prefs.setString(
"theme",
theme
);


}



static Future<String> getTheme()
async{


final prefs =
await SharedPreferences.getInstance();


return prefs.getString("theme")
?? "system";


}


}