import 'package:flutter/material.dart';

import '../models/catatan_model.dart';
import '../services/catatan_service.dart';



class Catatan extends StatefulWidget {

const Catatan({super.key});


@override
State<Catatan> createState()
=> _CatatanState();

}



class _CatatanState extends State<Catatan>{


List<CatatanModel> list = [];



@override
void initState(){

super.initState();

load();

}



void load() async {

list =
await CatatanService.load();

setState((){});

}



void tambahCatatan(){


TextEditingController judul =
TextEditingController();


TextEditingController isi =
TextEditingController();



showDialog(

context:context,

builder:(context){


return AlertDialog(

title:
const Text("Catatan Baru"),


content:
Column(

mainAxisSize:
MainAxisSize.min,


children:[


TextField(

controller:judul,

decoration:
const InputDecoration(

labelText:"Judul"

),

),



TextField(

controller:isi,

maxLines:5,

decoration:
const InputDecoration(

labelText:"Isi Catatan"

),

),


],

),



actions:[


TextButton(

child:
const Text("Simpan"),


onPressed:() async {


list.add(

CatatanModel(

judul:judul.text,

isi:isi.text,

tanggal:
DateTime.now()
.toString(),

)

);



await CatatanService.save(list);



setState((){});


Navigator.pop(context);


},

)


],

);


}

);


}



void hapus(int index) async {


list.removeAt(index);


await CatatanService.save(list);


setState((){});


}



@override
Widget build(BuildContext context){


return Scaffold(


appBar:
AppBar(

title:
const Text("Catatan"),

),



floatingActionButton:

FloatingActionButton(

onPressed:tambahCatatan,

child:
const Icon(Icons.add),

),



body:

list.isEmpty

?

const Center(

child:
Text(
"Belum ada catatan"
),

)


:

ListView.builder(

itemCount:list.length,


itemBuilder:(context,index){


final data =
list[index];


return Card(

margin:
const EdgeInsets.all(10),


child:ListTile(


title:
Text(data.judul),


subtitle:
Text(data.isi),


trailing:

IconButton(

icon:
const Icon(Icons.delete),


onPressed:(){

hapus(index);

},

),


),


);


},


),



);


}

}