import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../widgets/video_banner.dart';
import '../widgets/menu_card.dart';



class Dashboard extends StatelessWidget{


const Dashboard({super.key});



final String whatsapp =
"https://whatsapp.com/channel/0029Vb7ISSJDeON39wZx6s2M";



void openWA() async{

final url=Uri.parse(whatsapp);

await launchUrl(url);

}



@override
Widget build(BuildContext context){


return Scaffold(


body:SafeArea(


child:SingleChildScrollView(


padding:
const EdgeInsets.all(16),


child:Column(


crossAxisAlignment:
CrossAxisAlignment.start,


children:[



const Text(

"Raven DarkNote",

style:TextStyle(

fontSize:28,

fontWeight:FontWeight.bold,

),

),



const SizedBox(height:15),



const VideoBanner(),



const SizedBox(height:20),



const Text(

"Menu Cepat",

style:TextStyle(

fontSize:20,

fontWeight:FontWeight.bold,

),

),



const SizedBox(height:15),



GridView.count(

crossAxisCount:2,

shrinkWrap:true,

physics:
const NeverScrollableScrollPhysics(),


crossAxisSpacing:15,

mainAxisSpacing:15,


children:[


const MenuCard(

icon:Icons.savings,

title:"Tabungan",

),


const MenuCard(

icon:Icons.build,

title:"Tools",

),


const MenuCard(

icon:Icons.note,

title:"Catatan",

),


const MenuCard(

icon:Icons.settings,

title:"Pengaturan",

),


],


),



const SizedBox(height:25),



GestureDetector(

onTap:openWA,


child:Container(

padding:
const EdgeInsets.all(15),


decoration:BoxDecoration(

borderRadius:
BorderRadius.circular(20),

color:Colors.green,

),


child:const Row(

children:[


Icon(

Icons.message,

),


SizedBox(width:10),


Text(

"Join Saluran WhatsApp RavenZy",

),

],


),

),


),



],


),


),


),


);


}


}