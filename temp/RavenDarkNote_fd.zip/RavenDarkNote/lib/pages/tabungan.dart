import 'package:flutter/material.dart';

import '../models/tabungan_model.dart';
import '../services/tabungan_service.dart';



class Tabungan extends StatefulWidget{

const Tabungan({super.key});


@override
State<Tabungan> createState()
=>_TabunganState();


}



class _TabunganState extends State<Tabungan>{


TabunganModel?
data;



@override
void initState(){

super.initState();

loadData();

}



void loadData() async{

data =
await TabunganService.load();


setState((){});


}



void buatTarget() async{


TextEditingController nama =
TextEditingController();


TextEditingController target =
TextEditingController();



showDialog(

context:context,


builder:(context){


return AlertDialog(

title:
const Text("Target Baru"),


content:
Column(

mainAxisSize:
MainAxisSize.min,


children:[


TextField(

controller:nama,

decoration:
const InputDecoration(
labelText:"Nama"
),

),


TextField(

controller:target,

keyboardType:
TextInputType.number,

decoration:
const InputDecoration(
labelText:"Target"
),

),


],

),



actions:[


TextButton(

onPressed:(){

final baru =
TabunganModel(

nama:nama.text,

target:
double.parse(target.text),

saldo:0,

);


TabunganService.save(baru);


setState((){

data=baru;

});


Navigator.pop(context);


},

child:
const Text("Simpan"),

)

],

);

}

);


}



void tambahSaldo() async{


if(data==null)return;


data!.saldo += 10000;


await TabunganService.save(data!);


setState((){});


}



@override
Widget build(BuildContext context){


return Scaffold(


appBar:AppBar(

title:
const Text("Tabungan"),

),



floatingActionButton:

FloatingActionButton(

onPressed:buatTarget,

child:
const Icon(Icons.add),

),



body:


data==null?


const Center(

child:
Text(
"Belum ada target"
),

)


:


Padding(

padding:
const EdgeInsets.all(20),


child:Column(

crossAxisAlignment:
CrossAxisAlignment.start,


children:[


Text(

data!.nama,

style:
const TextStyle(

fontSize:25,

fontWeight:
FontWeight.bold,

),

),



Text(

"Rp ${data!.saldo}",

),



const SizedBox(height:20),



LinearProgressIndicator(

value:
data!.progress,

),



const SizedBox(height:20),



ElevatedButton(

onPressed:tambahSaldo,

child:
const Text(
"Tambah Rp10.000"
),

),



],

),


),



);


}

}