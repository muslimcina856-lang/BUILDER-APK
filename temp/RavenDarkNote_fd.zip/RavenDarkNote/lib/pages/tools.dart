import 'package:flutter/material.dart';

import '../widgets/tool_card.dart';

import '../tools/calculator.dart';
import '../tools/password_generator.dart';
import '../tools/text_counter.dart';
import '../tools/case_converter.dart';
import '../tools/json_formatter.dart';



class Tools extends StatelessWidget {

  const Tools({super.key});


  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text(
          "Raven Tools",
        ),

      ),


      body: Padding(

        padding: const EdgeInsets.all(15),


        child: GridView(

          gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(

            crossAxisCount: 2,

            crossAxisSpacing: 15,

            mainAxisSpacing: 15,

          ),



          children: [



            ToolCard(

              title: "Kalkulator",

              icon: Icons.calculate,

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (context) =>
                    const Calculator(),

                  ),

                );

              },

            ),




            ToolCard(

              title: "Password Generator",

              icon: Icons.password,

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (context) =>
                    const PasswordGenerator(),

                  ),

                );

              },

            ),




            ToolCard(

              title: "Text Counter",

              icon: Icons.text_fields,

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (context) =>
                    const TextCounter(),

                  ),

                );

              },

            ),





            ToolCard(

              title: "Case Converter",

              icon: Icons.text_format,

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (context) =>
                    const CaseConverter(),

                  ),

                );

              },

            ),





            ToolCard(

              title: "JSON Formatter",

              icon: Icons.code,

              onTap: () {

                Navigator.push(

                  context,

                  MaterialPageRoute(

                    builder: (context) =>
                    const JsonFormatter(),

                  ),

                );

              },

            ),



          ],

        ),

      ),

    );

  }

}