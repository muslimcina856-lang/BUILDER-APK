import 'package:flutter/material.dart';

import '../services/theme_service.dart';

import '../widgets/theme_button.dart';



class Pengaturan extends StatefulWidget{

const Pengaturan({super.key});


@override
State<Pengaturan> createState()
=>_PengaturanState();


}



class _PengaturanState
extends State<Pengaturan>{



String tema="system";



@override
void initState(){

super.initState();

load();

}



void load() async{


tema =
await ThemeService.getTheme();


setState((){});


}



void pilihTema(String value) async{


await ThemeService.saveTheme(value);


setState((){

tema=value;

});


}



void caraPakai(){


showDialog(

context:context,

builder:(context){

return AlertDialog(

title:
const Text("Cara Menggunakan"),


content:
const SingleChildScrollView(

child:
Text(

"""
Raven DarkNote

1. Dashboard
Menampilkan menu utama.

2. Tabungan
Buat target dan simpan uang secara offline.

3. Tools
Gunakan berbagai alat yang tersedia.

4. Catatan
Simpan catatan pribadi.

5. Pengaturan
Atur tema dan informasi aplikasi.

Semua data tersimpan di perangkat.

"""

),

),


);

}

);


}



@override
Widget build(BuildContext context){


return Scaffold(

appBar:

AppBar(

title:
const Text("Pengaturan"),

),


body:

ListView(

padding:
const EdgeInsets.all(15),


children:[



const Text(

"Tema Aplikasi",

style:
TextStyle(

fontSize:22,

fontWeight:
FontWeight.bold,

),

),



ThemeButton(

title:"Sistem",

onTap:(){

pilihTema("system");

},

),



ThemeButton(

title:"Gelap",

onTap:(){

pilihTema("dark");

},

),



ThemeButton(

title:"Putih",

onTap:(){

pilihTema("light");

},

),



ThemeButton(

title:"Pink",

onTap:(){

pilihTema("pink");

},

),



ThemeButton(

title:"Biru",

onTap:(){

pilihTema("blue");

},

),



ThemeButton(

title:"Merah",

onTap:(){

pilihTema("red");

},

),



const SizedBox(height:20),



ListTile(

leading:
const Icon(Icons.favorite),

title:
const Text(
"Donate Developer"
),


onTap:(){

showDialog(

context:context,

builder:(context){

return AlertDialog(

title:
const Text(
"Donate Raven DarkNote"
),


content:

Image.asset(
"assets/donate.jpg"
),


);

}

);


},

),



ListTile(

leading:
const Icon(Icons.help),

title:
const Text(
"Cara Pakai"
),


onTap:caraPakai,

),



const ListTile(

leading:
Icon(Icons.info),

title:
Text(
"Versi APK"
),


subtitle:
Text(
"1.0.0"
),


),



const ListTile(

leading:
Icon(Icons.apps),

title:
Text(
"Tentang Raven DarkNote"
),


subtitle:
Text(

"Aplikasi catatan, tabungan dan tools pribadi."

),

),


],

),

);


}

}