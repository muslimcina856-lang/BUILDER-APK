import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


class IPChecker extends StatefulWidget{

const IPChecker({super.key});


@override
State<IPChecker> createState()
=>_IPCheckerState();


}



class _IPCheckerState
extends State<IPChecker>{


String ip="Belum dicek";


void cek() async{


final response =
await http.get(

Uri.parse(
"https://api.ipify.org"
)

);


setState((){

ip=response.body;

});


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:
AppBar(

title:
const Text("Public IP"),

),


body:
Center(

child:
Column(

mainAxisAlignment:
MainAxisAlignment.center,


children:[


Text(
"IP Kamu:\n$ip",
textAlign:
TextAlign.center,
),


ElevatedButton(

onPressed:cek,

child:
const Text("Cek IP"),

)

],

),

),

);

}

}