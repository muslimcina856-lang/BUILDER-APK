import 'package:flutter/material.dart';


class CaseConverter extends StatefulWidget{

const CaseConverter({super.key});


@override
State<CaseConverter> createState()
=>_CaseConverterState();

}



class _CaseConverterState
extends State<CaseConverter>{


final controller =
TextEditingController();


String hasil="";


void upper(){

setState((){

hasil=
controller.text.toUpperCase();

});

}


void lower(){

setState((){

hasil=
controller.text.toLowerCase();

});

}



void title(){

setState((){


hasil =
controller.text
.split(" ")
.map(
(e)=> e.isEmpty
?
e
:
e[0].toUpperCase()
+
e.substring(1)

)

.join(" ");


});

}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(

title:
const Text("Case Converter"),

),


body:Padding(

padding:
const EdgeInsets.all(20),


child:Column(

children:[


TextField(

controller:controller,

decoration:
const InputDecoration(

labelText:"Masukkan teks"

),

),


Wrap(

spacing:10,

children:[

ElevatedButton(

onPressed:upper,

child:
const Text("UPPER"),

),


ElevatedButton(

onPressed:lower,

child:
const Text("lower"),

),


ElevatedButton(

onPressed:title,

child:
const Text("Title"),

),


],

),


const SizedBox(height:20),


Text(

hasil,

style:
const TextStyle(fontSize:20),

)


],

),

),

);

}

}