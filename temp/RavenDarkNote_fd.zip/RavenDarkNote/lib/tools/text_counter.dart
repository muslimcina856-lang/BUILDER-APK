import 'package:flutter/material.dart';


class TextCounter extends StatefulWidget{

const TextCounter({super.key});


@override
State<TextCounter> createState()
=>_TextCounterState();


}



class _TextCounterState 
extends State<TextCounter>{


final controller =
TextEditingController();


int karakter=0;

int kata=0;

int baris=0;



void hitung(){


String text =
controller.text;


setState((){


karakter =
text.length;


kata =
text.trim().isEmpty
?
0
:
text.trim()
.split(RegExp(r'\s+'))
.length;


baris =
text.split("\n").length;


});


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(

title:
const Text("Text Counter"),

),


body:Padding(

padding:
const EdgeInsets.all(20),


child:Column(

children:[


TextField(

controller:controller,

maxLines:8,

onChanged:(v){

hitung();

},

decoration:
const InputDecoration(

border:
OutlineInputBorder(),

hintText:
"Tulis teks..."

),

),



const SizedBox(height:20),



Text(
"Karakter : $karakter"
),


Text(
"Kata : $kata"
),


Text(
"Baris : $baris"
),



],

),

),

);

}

}