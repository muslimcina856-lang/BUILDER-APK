import 'dart:convert';

import 'package:flutter/material.dart';


class JsonFormatter extends StatefulWidget{

const JsonFormatter({super.key});


@override
State<JsonFormatter> createState()
=>_JsonFormatterState();

}



class _JsonFormatterState
extends State<JsonFormatter>{


final controller =
TextEditingController();


String hasil="";


void format(){


try{


var data =
jsonDecode(controller.text);


setState((){

hasil =
const JsonEncoder.withIndent("  ")
.convert(data);

});


}

catch(e){

setState((){

hasil="JSON tidak valid";

});

}


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(

title:
const Text("JSON Formatter"),

),


body:Padding(

padding:
const EdgeInsets.all(20),


child:Column(

children:[


TextField(

controller:controller,

maxLines:8,

decoration:
const InputDecoration(

hintText:
"Masukkan JSON"

),

),


ElevatedButton(

onPressed:format,

child:
const Text("Format"),

),


Expanded(

child:
SingleChildScrollView(

child:
Text(hasil),

),

)


],

),

),

);

}

}