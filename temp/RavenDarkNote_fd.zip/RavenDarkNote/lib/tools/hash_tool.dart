import 'dart:convert';

import 'package:crypto/crypto.dart';

import 'package:flutter/material.dart';


class HashTool extends StatefulWidget{

const HashTool({super.key});


@override
State<HashTool> createState()
=>_HashToolState();

}



class _HashToolState
extends State<HashTool>{


final controller =
TextEditingController();


String hasil="";


void generate(){


String text =
controller.text;


var md5Hash =
md5.convert(

utf8.encode(text)

);


var sha =
sha256.convert(

utf8.encode(text)

);



setState((){


hasil=
"""
MD5:
$md5Hash


SHA256:
$sha
""";


});


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:
AppBar(

title:
const Text("Hash Generator"),

),


body:
Padding(

padding:
const EdgeInsets.all(20),


child:
Column(

children:[


TextField(

controller:controller,

decoration:
const InputDecoration(

labelText:"Text"

),

),


ElevatedButton(

onPressed:generate,

child:
const Text("Generate"),

),


Text(hasil)

],

),

),

);

}

}