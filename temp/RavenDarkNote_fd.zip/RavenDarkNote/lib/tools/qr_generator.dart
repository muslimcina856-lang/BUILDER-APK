import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';


class QRGenerator extends StatefulWidget {

const QRGenerator({super.key});


@override
State<QRGenerator> createState()
=> _QRGeneratorState();

}



class _QRGeneratorState
extends State<QRGenerator>{


final controller =
TextEditingController();


String data="Raven DarkNote";



@override
Widget build(BuildContext context){


return Scaffold(

appBar:AppBar(

title:
const Text("QR Generator"),

),


body:Padding(

padding:
const EdgeInsets.all(20),


child:Column(

children:[


TextField(

controller:controller,

decoration:
const InputDecoration(

labelText:
"Teks atau Link"

),

),



const SizedBox(height:20),



QrImageView(

data:data,

size:220,

),



const SizedBox(height:20),



ElevatedButton(

onPressed:(){


setState((){


if(controller.text.isNotEmpty){

data =
controller.text;

}


});


},

child:
const Text("Buat QR"),

)



],

),

),

);


}

}