import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';


class DeviceInfoPage extends StatefulWidget {

const DeviceInfoPage({super.key});


@override
State<DeviceInfoPage> createState()
=> _DeviceInfoPageState();

}



class _DeviceInfoPageState
extends State<DeviceInfoPage>{


String info="Loading...";


@override
void initState(){

super.initState();

load();

}



void load() async{


final device =
DeviceInfoPlugin();


final android =
await device.androidInfo;


setState((){

info =
"""
Brand : ${android.brand}

Model : ${android.model}

Android : ${android.version.release}

SDK : ${android.version.sdkInt}

""";


});


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(
title:const Text("Device Info"),
),

body:
Center(

child:
Text(

info,

style:
const TextStyle(fontSize:18),

),

),

);

}

}