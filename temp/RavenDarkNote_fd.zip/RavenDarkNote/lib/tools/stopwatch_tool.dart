import 'dart:async';
import 'package:flutter/material.dart';


class StopwatchTool extends StatefulWidget{

const StopwatchTool({super.key});


@override
State<StopwatchTool> createState()
=>_StopwatchToolState();


}



class _StopwatchToolState
extends State<StopwatchTool>{


int detik=0;

Timer? timer;


void start(){

timer =
Timer.periodic(

const Duration(seconds:1),

(e){

setState((){

detik++;

});

}

);

}


void stop(){

timer?.cancel();

}



void reset(){

stop();

setState((){

detik=0;

});

}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(

title:
const Text("Stopwatch"),

),


body:
Center(

child:
Column(

mainAxisAlignment:
MainAxisAlignment.center,

children:[


Text(

"$detik detik",

style:
const TextStyle(fontSize:35),

),


Wrap(

spacing:10,

children:[

ElevatedButton(

onPressed:start,

child:
const Text("Start"),

),


ElevatedButton(

onPressed:stop,

child:
const Text("Stop"),

),


ElevatedButton(

onPressed:reset,

child:
const Text("Reset"),

),

],

)

],

),

),

);

}

}