import 'package:flutter/material.dart';


class Calculator extends StatefulWidget{

const Calculator({super.key});


@override
State<Calculator> createState()
=>_CalculatorState();

}



class _CalculatorState extends State<Calculator>{


final a =
TextEditingController();

final b =
TextEditingController();


String hasil="0";



void hitung(String op){


double x =
double.tryParse(a.text) ?? 0;


double y =
double.tryParse(b.text) ?? 0;


double r=0;


if(op=="+"){

r=x+y;

}

else if(op=="-"){

r=x-y;

}

else if(op=="*"){

r=x*y;

}

else if(op=="/" && y!=0){

r=x/y;

}


setState((){

hasil=r.toString();

});


}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:AppBar(
title:
const Text("Kalkulator"),
),


body:Padding(

padding:
const EdgeInsets.all(20),


child:Column(

children:[


TextField(

controller:a,

keyboardType:
TextInputType.number,

decoration:
const InputDecoration(
labelText:"Angka 1"
),

),


TextField(

controller:b,

keyboardType:
TextInputType.number,

decoration:
const InputDecoration(
labelText:"Angka 2"
),

),


const SizedBox(height:20),


Wrap(

spacing:10,

children:[

ElevatedButton(
onPressed:()=>hitung("+"),
child:const Text("+"),
),

ElevatedButton(
onPressed:()=>hitung("-"),
child:const Text("-"),
),

ElevatedButton(
onPressed:()=>hitung("*"),
child:const Text("*"),
),

ElevatedButton(
onPressed:()=>hitung("/"),
child:const Text("/"),
),

],

),


Text(
"Hasil: $hasil",
style:
const TextStyle(fontSize:25),
)


],

),

),

);

}

}