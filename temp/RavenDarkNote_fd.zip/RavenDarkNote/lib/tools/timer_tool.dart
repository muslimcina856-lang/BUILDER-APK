import 'dart:async';
import 'package:flutter/material.dart';


class TimerTool extends StatefulWidget{

const TimerTool({super.key});


@override
State<TimerTool> createState()
=>_TimerToolState();


}



class _TimerToolState
extends State<TimerTool>{


int waktu=60;

Timer? timer;


void mulai(){

timer =
Timer.periodic(

const Duration(seconds:1),

(t){


if(waktu>0){

setState((){

waktu--;

});

}

else{

timer?.cancel();

}


});

}



@override
Widget build(BuildContext context){

return Scaffold(

appBar:
AppBar(

title:
const Text("Timer"),

),


body:
Center(

child:
Column(

mainAxisAlignment:
MainAxisAlignment.center,


children:[


Text(

"$waktu",

style:
const TextStyle(fontSize:50),

),


ElevatedButton(

onPressed:mulai,

child:
const Text("Mulai"),

)

],

),

),

);

}

}