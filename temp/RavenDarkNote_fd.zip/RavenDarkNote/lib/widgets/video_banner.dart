import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';


class VideoBanner extends StatefulWidget {

const VideoBanner({super.key});


@override
State<VideoBanner> createState()=>_VideoBannerState();

}


class _VideoBannerState extends State<VideoBanner>{


late VideoPlayerController controller;


@override
void initState(){

super.initState();


controller = VideoPlayerController.asset(
"assets/banner.mp4"
)


..initialize().then((value){

setState((){});

controller.setLooping(true);

controller.setVolume(1);

controller.play();


});


}



@override
void dispose(){

controller.dispose();

super.dispose();

}



@override
Widget build(BuildContext context){


if(!controller.value.isInitialized){

return const SizedBox(

height:200,

child:Center(

child:CircularProgressIndicator(),

),

);

}



return ClipRRect(

borderRadius:BorderRadius.circular(20),


child:AspectRatio(

aspectRatio:
controller.value.aspectRatio,


child:VideoPlayer(controller),

),

);

}


}