import 'package:flutter/material.dart';


class MenuCard extends StatelessWidget{


final IconData icon;
final String title;


const MenuCard({

super.key,

required this.icon,

required this.title,

});



@override
Widget build(BuildContext context){


return Container(

padding:
const EdgeInsets.all(15),


decoration:BoxDecoration(

borderRadius:
BorderRadius.circular(20),

color:
Colors.white10,

),


child:Column(

mainAxisAlignment:
MainAxisAlignment.center,


children:[


Icon(

icon,

size:35,

color:Colors.blue,

),


const SizedBox(height:10),


Text(title),


],


),

);


}


}