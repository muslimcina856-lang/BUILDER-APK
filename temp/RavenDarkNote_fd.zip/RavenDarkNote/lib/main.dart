import 'package:flutter/material.dart';

import 'widgets/bottom_nav.dart';
import 'services/theme_service.dart';



void main() async {

WidgetsFlutterBinding.ensureInitialized();


String theme =
await ThemeService.getTheme();


runApp(

RavenDarkNote(

theme: theme,

),

);

}




class RavenDarkNote extends StatefulWidget {


final String theme;


const RavenDarkNote({

super.key,

required this.theme,

});



@override
State<RavenDarkNote> createState()
=> _RavenDarkNoteState();


}



class _RavenDarkNoteState
extends State<RavenDarkNote>{



late String currentTheme;



@override
void initState(){

super.initState();

currentTheme =
widget.theme;

}




ThemeMode getThemeMode(){


switch(currentTheme){


case "dark":

return ThemeMode.dark;


case "light":

return ThemeMode.light;


default:

return ThemeMode.system;


}


}



@override
Widget build(BuildContext context){


return MaterialApp(


debugShowCheckedModeBanner:false,


title:
"Raven DarkNote",



themeMode:
getThemeMode(),



theme:

ThemeData(

useMaterial3:true,

brightness:
Brightness.light,

colorSchemeSeed:
Colors.blue,

),



darkTheme:

ThemeData(

useMaterial3:true,

brightness:
Brightness.dark,

colorSchemeSeed:
Colors.blue,

),



home:

const BottomNav(),



);

}


}