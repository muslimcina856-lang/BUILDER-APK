class AppInfo{

static const name =
"Raven DarkNote";


static const version =
"1.0.0";


}