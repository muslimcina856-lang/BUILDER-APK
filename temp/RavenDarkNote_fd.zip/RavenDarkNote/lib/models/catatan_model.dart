class CatatanModel {

  String judul;
  String isi;
  String tanggal;


  CatatanModel({

    required this.judul,
    required this.isi,
    required this.tanggal,

  });



  Map<String,dynamic> toJson(){

    return {

      "judul": judul,
      "isi": isi,
      "tanggal": tanggal,

    };

  }



  factory CatatanModel.fromJson(
      Map<String,dynamic> json
  ){

    return CatatanModel(

      judul: json["judul"],
      isi: json["isi"],
      tanggal: json["tanggal"],

    );

  }

}