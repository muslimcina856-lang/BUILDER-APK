class TabunganModel {

String nama;

double target;

double saldo;


TabunganModel({

required this.nama,

required this.target,

required this.saldo,

});


double get progress {

if(target == 0){

return 0;

}

return saldo / target;

}



Map<String,dynamic> toJson(){

return {

"nama":nama,

"target":target,

"saldo":saldo,

};

}



factory TabunganModel.fromJson(
Map<String,dynamic> json
){

return TabunganModel(

nama:json["nama"],

target:json["target"],

saldo:json["saldo"],

);

}


}