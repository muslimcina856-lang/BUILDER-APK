package com.subakir.cyber_optimizer

import android.content.ContentResolver
import android.provider.Settings
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.subakir.cyber_optimizer/resolution"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "changeResolution") {
                val width = call.argument<Int>("width")
                val height = call.argument<Int>("height")
                val dpi = call.argument<Int>("dpi")

                try {
                    val cr: ContentResolver = contentResolver
                    // Mengubah display size forced dan density tingkat sistem aman
                    Settings.Global.putString(cr, "display_size_forced", "${width}x${height}")
                    Settings.Secure.putString(cr, "display_density_forced", "$dpi")
                    
                    result.success("Sistem Berhasil Dioptimasi ke ${width}x${height} (${dpi} DPI)")
                } catch (e: Exception) {
                    result.error("PERM_DENIED", "Izin Secure Settings Ditolak: ${e.message}", null)
                }
            } else {
                result.notImplemented()
            }
        }
    }
}
