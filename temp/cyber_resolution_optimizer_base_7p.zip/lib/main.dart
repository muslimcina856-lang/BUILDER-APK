import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const CyberOptimizerApp());
}

class CyberOptimizerApp extends StatelessWidget {
  const CyberOptimizerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cyber Resolution Optimizer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF05050A),
        primaryColor: const Color(0xFF00FFCC),
        hintColor: const Color(0xFFFF0055),
      ),
      home: const CyberLoginScreen(),
    );
  }
}

class CyberLoginScreen extends StatefulWidget {
  const CyberLoginScreen({super.key});

  @override
  State<CyberLoginScreen> createState() => _CyberLoginScreenState();
}

class _CyberLoginScreenState extends State<CyberLoginScreen> {
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  String _errorMessage = '';

  void _handleLogin() {
    final username = _userController.text.trim();
    final password = _passController.text.trim();

    if (username == "RT 17" && password == "SUBAKIR") {
      setState(() => _errorMessage = '');
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(const Builder: (context) => const CyberDashboardScreen()),
      );
    } else {
      setState(() => _errorMessage = "ACCESS DENIED: INVALID CREDENTIALS");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF0D0E15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFFF0055), width: 1.5),
              boxShadow: const [
                BoxShadow(color: Color(0xFFFF0055), blurRadius: 10, spreadRadius: 1),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.gpp_good_sharp, size: 80, color: Color(0xFF00FFCC)),
                const SizedBox(height: 10),
                const Text(
                  "CYBER RESOLUTION",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2),
                ),
                const Text("SYSTEM OPTIMIZER", style: TextStyle(color: Color(0xFF00FFCC), fontSize: 12)),
                const SizedBox(height: 30),
                TextField(
                  controller: _userController,
                  decoration: const InputDecoration(
                    labelText: "USERNAME",
                    labelStyle: TextStyle(color: Color(0xFF00FFCC)),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF333333))),
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF00FFCC))),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: _passController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: "PASSWORD",
                    labelStyle: TextStyle(color: Color(0xFFFF0055)),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF333333))),
                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFFF0055))),
                  ),
                ),
                const SizedBox(height: 15),
                if (_errorMessage.isNotEmpty)
                  Text(_errorMessage, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 12)),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00FFCC),
                    foregroundColor: Colors.black,
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: _handleLogin,
                  child: const Text("INITIALIZE ACCESS", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CyberDashboardScreen extends StatefulWidget {
  const CyberDashboardScreen({super.key});

  @override
  State<CyberDashboardScreen> createState() => _CyberDashboardScreenState();
}

class _CyberDashboardScreenState extends State<CyberDashboardScreen> {
  static const platform = MethodChannel('com.subakir.cyber_optimizer/resolution');
  
  final TextEditingController _widthController = TextEditingController(text: "1080");
  final TextEditingController _heightController = TextEditingController(text: "2400");
  final TextEditingController _dpiController = TextEditingController(text: "440");

  Future<void> _applyResolution() async {
    final int width = int.parse(_widthController.text);
    final int height = int.parse(_heightController.text);
    final int dpi = int.parse(_dpiController.text);

    try {
      final String result = await platform.invokeMethod('changeResolution', {
        'width': width,
        'height': height,
        'dpi': dpi,
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
    } on PlatformException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal mengubah sistem: ${e.message}. Pastikan izin ADB aktif.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CORE OPTIMIZER"),
        backgroundColor: const Color(0xFF0D0E15),
        actions: [
          IconButton(
            icon: const Icon(Icons.power_settings_new, color: Color(0xFFFF0055)),
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(const Builder: (context) => const CyberLoginScreen())),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("RESOLUTION OVERRIDE", style: TextStyle(color: Color(0xFF00FFCC), fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _widthController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Width"),
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: TextField(
                    controller: _heightController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Height"),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _dpiController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Density (DPI)"),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF0055),
                minimumSize: const Size.fromHeight(55),
              ),
              onPressed: _applyResolution,
              child: const Text("APPLY SECURE SETTINGS", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
            )
          ],
        ),
      ),
    );
  }
}
