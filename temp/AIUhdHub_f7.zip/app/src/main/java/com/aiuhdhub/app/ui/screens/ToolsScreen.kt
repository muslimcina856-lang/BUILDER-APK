@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.aiuhdhub.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aiuhdhub.app.data.AiTool
import com.aiuhdhub.app.data.ToolCategory
import com.aiuhdhub.app.data.ToolsRepository
import com.aiuhdhub.app.ui.components.ToolCard
import com.aiuhdhub.app.ui.theme.*

enum class FilterOption(val label: String, val category: ToolCategory?) {
    ALL("Semua", null),
    IMAGE("Image", ToolCategory.IMAGE_UPSCALER),
    VIDEO("Video", ToolCategory.VIDEO_UPSCALER),
    ALL_IN_ONE("All-in-One", ToolCategory.ALL_IN_ONE)
}

@Composable
fun ToolsScreen(
    onDownloadClick: (String) -> Unit,
    onGithubClick: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf(FilterOption.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val allTools = ToolsRepository.getAllTools()
    val filteredTools = remember(selectedFilter, searchQuery) {
        allTools.filter { tool ->
            val matchesFilter = selectedFilter.category == null ||
                    tool.category == selectedFilter.category ||
                    (selectedFilter == FilterOption.VIDEO && tool.supportsVideo)
            val matchesSearch = searchQuery.isBlank() ||
                    tool.name.contains(searchQuery, ignoreCase = true) ||
                    tool.developer.contains(searchQuery, ignoreCase = true) ||
                    tool.description.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 50.dp, start = 24.dp, end = 24.dp, bottom = 16.dp)
        ) {
            Text(
                text = "AI Tools",
                style = MaterialTheme.typography.headlineLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Muat turun tool AI UHD open-source terbaik",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            placeholder = {
                Text(
                    "Cari tool...",
                    color = TextMuted
                )
            },
            leadingIcon = {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = TextMuted
                )
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            Icons.Filled.Clear,
                            contentDescription = "Clear",
                            tint = TextMuted
                        )
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark,
                focusedBorderColor = AccentBlue.copy(alpha = 0.5f),
                unfocusedBorderColor = DividerColor,
                cursorColor = AccentBlue,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterOption.entries.forEach { filter ->
                FilterChipItem(
                    label = filter.label,
                    selected = selectedFilter == filter,
                    onClick = { selectedFilter = filter },
                    color = when (filter) {
                        FilterOption.ALL -> AccentCyan
                        FilterOption.IMAGE -> AccentBlue
                        FilterOption.VIDEO -> AccentPurple
                        FilterOption.ALL_IN_ONE -> AccentGreen
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Results Count
        Text(
            text = "${filteredTools.size} tool ditemui",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
        )

        // Tools List
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 4.dp,
                bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(
                items = filteredTools,
                key = { it.id }
            ) { tool ->
                ToolCard(
                    tool = tool,
                    onDownloadClick = onDownloadClick,
                    onGithubClick = onGithubClick,
                    modifier = Modifier.animateItemPlacement()
                )
            }

            if (filteredTools.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SearchOff,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Tiada tool ditemui",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextSecondary
                        )
                        Text(
                            text = "Cuba tukar filter atau kata kunci carian",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    color: Color
) {
    val bgColor = if (selected) color.copy(alpha = 0.2f) else Color.Transparent
    val borderColor = if (selected) color.copy(alpha = 0.5f) else DividerColor
    val textColor = if (selected) color else TextMuted

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = textColor,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
