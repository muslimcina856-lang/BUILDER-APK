import 'package:flutter_test/flutter_test.dart';
import 'package:warung_kita/game/game_state.dart';

void main() {
  test('permainan baharu mempunyai modal awal', () {
    final state = GameState.fresh();
    expect(state.money, 350);
    expect(state.day, 1);
    expect(state.inventory['rice'], 16);
  });
}
