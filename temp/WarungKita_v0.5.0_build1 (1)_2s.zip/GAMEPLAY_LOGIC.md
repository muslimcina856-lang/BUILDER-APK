# Logik Operasi Warung

## Kitaran pelanggan

`Masuk → Duduk → Tunggu pelayan → Pesan → Tunggu makanan → Makan → Tunggu bayaran → Keluar`

Pelanggan mempunyai tahap kesabaran berbeza. Masa menunggu menurunkan kepuasan. Pelanggan yang menunggu terlalu lama sebelum pesanan atau makanan boleh meninggalkan warung.

## Tugas pelayan lelaki

`Sambut → Catat pesanan → Pergi ke stor → Ambil bahan → Serah kepada tukang masak → Ambil hidangan siap → Hantar ke meja → Ambil bayaran → Bersihkan meja → Bawa pinggan ke sinki`

Keutamaan kerja pelayan:

1. Hantar makanan yang sudah siap.
2. Ambil bayaran pelanggan yang selesai makan.
3. Bersihkan meja jika semua tempat duduk sedang terhalang.
4. Ambil pesanan baharu.
5. Bersihkan baki meja kotor.

## Tugas tukang masak wanita

`Terima bahan → Potong → Masak → Susun hidangan → Sedia untuk pesanan seterusnya`

Apabila tiada pesanan menunggu, tukang masak membasuh pinggan yang dihantar ke sinki.

## Stok dan pembaziran

Bahan ditempah apabila pesanan dicatat dan ditolak daripada inventori apabila pelayan mengambilnya dari stor. Pesanan yang dibatalkan sebelum bahan diambil melepaskan tempahan. Pesanan yang dibatalkan selepas bahan diambil menambah kiraan pembaziran.

## Kepuasan dan bayaran

- Servis cepat meningkatkan kepuasan dan peluang tip.
- Servis terlalu lambat mengurangkan tip dan boleh menurunkan reputasi.
- Laporan harian menyimpan jualan, tip, reputasi, kepuasan, pelanggan terlepas dan pembaziran.

## Kesan naik taraf

- **Taraf Kedai:** rupa kedai, menu terbuka dan jumlah permintaan.
- **Dapur:** masa memasak lebih singkat.
- **Meja & Kerusi:** lebih banyak pelanggan boleh duduk serentak.
- **Stor Bahan:** kapasiti lebih besar dan harga bahan lebih murah.
- **Servis Pelayan:** pergerakan, pengambilan pesanan dan bayaran lebih cepat.
- **Kebersihan:** meja dibersihkan lebih cepat dan peluang tip bertambah.
- **Populariti:** lebih ramai pelanggan dan peluang tip lebih tinggi.
- **Keuntungan:** hasil setiap hidangan meningkat.
