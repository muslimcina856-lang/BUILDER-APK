# Aset Warung Kita v0.5.0

- `assets/images/customers/`: 100 pelanggan individu.
- `assets/images/staff/`: aksi tukang masak, pelayan dan prop kerja.
- `assets/images/environment/`: kedai, dapur, stor, kaunter, sinki, meja, kerusi, lantai dan hiasan.
- `assets/images/food_new/`: makanan, minuman, bahan dan peralatan hidangan.
- `assets/images/*.png`: aset menu bersih yang digunakan oleh kad menu dan pesanan.
- `assets/app_icon.png`: ikon aplikasi.

Aplikasi membungkus fail individu sahaja. Serpihan objek jiran telah dibuang daripada aset yang digunakan semasa permainan.
