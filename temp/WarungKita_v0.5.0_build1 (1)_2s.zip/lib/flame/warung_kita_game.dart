import 'dart:collection';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../game/game_data.dart';

class WarungKitaGame extends FlameGame {
  WarungKitaGame({required this.controller});

  final GameController controller;
  final Random _random = Random();

  static final List<String> customerAssets = List<String>.generate(
    100,
    (index) => 'customers/customer_${(index + 1).toString().padLeft(3, '0')}.png',
  );

  static const List<String> staffAssets = <String>[
    'staff/cook_idle.png',
    'staff/cook_receive.png',
    'staff/cook_chop.png',
    'staff/cook_stir.png',
    'staff/cook_fry.png',
    'staff/cook_plate.png',
    'staff/cook_clean.png',
    'staff/cook_wash.png',
    'staff/waiter_order.png',
    'staff/waiter_greet.png',
    'staff/waiter_ingredients.png',
    'staff/waiter_food.png',
    'staff/waiter_serve.png',
    'staff/waiter_payment.png',
    'staff/waiter_clean.png',
    'staff/waiter_dirty.png',
    'staff/cook_ticket.png',
    'staff/plates.png',
  ];

  static const List<String> environmentAssets = <String>[
    'environment/warung_tier_1.png',
    'environment/warung_tier_2.png',
    'environment/warung_tier_3.png',
    'environment/warung_tier_4.png',
    'environment/warung_tier_5.png',
    'environment/warung_tier_6.png',
    'environment/stove_tier_1.png',
    'environment/stove_tier_2.png',
    'environment/stove_tier_3.png',
    'environment/storage_tier_1.png',
    'environment/storage_tier_2.png',
    'environment/storage_tier_3.png',
    'environment/counter_tier_1.png',
    'environment/counter_tier_2.png',
    'environment/counter_tier_3.png',
    'environment/sink_tier_1.png',
    'environment/sink_tier_2.png',
    'environment/sink_tier_3.png',
    'environment/table_long.png',
    'environment/table_square.png',
    'environment/table_umbrella.png',
    'environment/lights_long.png',
    'environment/floor_stone.png',
    'environment/floor_tile.png',
    'environment/floor_wood_1.png',
  ];

  final Map<String, ui.Image> loadedImages = <String, ui.Image>{};
  final Queue<String> _customerDeck = Queue<String>();
  final Queue<CustomerComponent> _waitingForOrder = Queue<CustomerComponent>();
  final Queue<OrderTicket> _cookQueue = Queue<OrderTicket>();
  final Queue<OrderTicket> _readyOrders = Queue<OrderTicket>();
  final Queue<CustomerComponent> _paymentQueue = Queue<CustomerComponent>();
  final Queue<SeatSlot> _cleanupQueue = Queue<SeatSlot>();
  final List<SeatSlot> _seats = <SeatSlot>[];

  WarungSceneComponent? _scene;
  CookComponent? _cook;
  WaiterComponent? _waiter;
  bool _sessionRunning = false;
  bool _disposed = false;
  int _spawned = 0;
  double _spawnDelay = 0;

  @override
  Color backgroundColor() => const Color(0xFFEDD49F);

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    camera.viewfinder
      ..anchor = Anchor.topLeft
      ..position = Vector2.zero();

    final foodFiles = menuItems.values
        .map((item) => item.flameImageName)
        .toSet()
        .toList(growable: false);
    final files = <String>[
      ...environmentAssets,
      ...staffAssets,
      ...customerAssets,
      ...foodFiles,
    ];
    final loaded = await images.loadAll(files);
    for (var index = 0; index < files.length; index++) {
      loadedImages[files[index]] = loaded[index];
    }

    _scene = WarungSceneComponent(
      game: this,
      gameSize: size.clone(),
    );
    await world.add(_scene!);

    _createSeats();
    await _createStaff();

    controller.addListener(_handleControllerChanged);
    _handleControllerChanged();
  }

  Future<void> _createStaff() async {
    final cookImage = loadedImages['staff/cook_idle.png'];
    final waiterImage = loadedImages['staff/waiter_order.png'];
    if (cookImage == null || waiterImage == null) return;

    final cook = CookComponent(
      game: this,
      sprite: Sprite(cookImage),
    );
    final waiter = WaiterComponent(
      game: this,
      sprite: Sprite(waiterImage),
    );
    _cook = cook;
    _waiter = waiter;
    await world.add(cook);
    await world.add(waiter);
  }

  @override
  void onGameResize(Vector2 newSize) {
    super.onGameResize(newSize);
    _scene?.resizeTo(newSize);
    if (!_sessionRunning && _activeCustomerCount == 0) {
      _createSeats();
      _cook?.snapHome();
      _waiter?.snapHome();
    }
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_disposed) return;

    _dispatchWork();

    if (_sessionRunning &&
        controller.serviceActive &&
        controller.acceptingCustomers &&
        _spawned < controller.customersTotal) {
      if (_spawnDelay > 0) {
        _spawnDelay -= dt;
      } else {
        final seat = _findFreeSeat();
        if (seat == null) {
          _spawnDelay = 0.18;
        } else {
          _spawnCustomer(seat);
        }
      }
    }

    _maybeFinishService();
  }

  int get _activeCustomerCount =>
      _seats.where((seat) => seat.customer != null).length;

  void _handleControllerChanged() {
    if (_disposed) return;
    _scene?.markNeedsRefresh();

    if (controller.serviceActive && !_sessionRunning) {
      _sessionRunning = true;
      _spawned = 0;
      _spawnDelay = 0.25;
      _clearQueues();
    } else if (!controller.serviceActive && _sessionRunning) {
      _sessionRunning = false;
    } else if (!controller.serviceActive && _activeCustomerCount == 0) {
      _createSeats();
    }
  }

  void _clearQueues() {
    _waitingForOrder.clear();
    _cookQueue.clear();
    _readyOrders.clear();
    _paymentQueue.clear();
  }

  void _createSeats() {
    _seats.clear();
    final count = controller.seatCount;
    final rows = <double>[0.61, 0.76, 0.90];
    for (var index = 0; index < count; index++) {
      final column = index % 2;
      final row = index ~/ 2;
      final x = column == 0 ? 0.24 : 0.76;
      final rowIndex = row < rows.length ? row : rows.length - 1;
      final y = rows[rowIndex];
      _seats.add(
        SeatSlot(
          index: index,
          customerPoint: Vector2(size.x * x, size.y * (y + 0.055)),
          mealPoint: Vector2(size.x * x, size.y * y),
          orderPoint: Vector2(
            size.x * (column == 0 ? x + 0.13 : x - 0.13),
            size.y * (y + 0.02),
          ),
          servicePoint: Vector2(
            size.x * (column == 0 ? x + 0.14 : x - 0.14),
            size.y * y,
          ),
        ),
      );
    }
  }

  SeatSlot? _findFreeSeat() {
    for (final seat in _seats) {
      if (seat.isAvailable) return seat;
    }
    return null;
  }

  String _nextCustomerAsset() {
    if (_customerDeck.isEmpty) {
      final shuffled = List<String>.from(customerAssets)..shuffle(_random);
      _customerDeck.addAll(shuffled);
    }
    return _customerDeck.removeFirst();
  }

  void _spawnCustomer(SeatSlot seat) {
    final imageName = _nextCustomerAsset();
    final image = loadedImages[imageName];
    if (image == null) return;

    seat.reserved = true;
    _spawned++;
    _spawnDelay = max(
      0.24,
      0.72 - controller.popularityLevel * 0.05 + _random.nextDouble() * 0.20,
    );

    final customer = CustomerComponent(
      game: this,
      sprite: Sprite(image),
      seat: seat,
      profile: CustomerProfile.fromAsset(imageName),
    );
    seat.customer = customer;
    world.add(customer);
  }

  void customerSeated(CustomerComponent customer) {
    customer.showWaitingForOrder();
    _waitingForOrder.add(customer);
    controller.setServiceStatus(
      'Pelanggan duduk. Pelayan menuju ke meja untuk mengambil pesanan.',
    );
    _dispatchWork();
  }

  void waiterTookOrder(CustomerComponent customer) {
    if (!customer.canTakeOrder) return;
    final result = controller.takeCustomerOrder();
    if (!result.served || result.item == null) {
      customer.rejectOrder();
      return;
    }
    final image = loadedImages[result.item!.flameImageName];
    if (image == null) {
      controller.cancelOrder(result, countAsMissed: true);
      customer.rejectOrder();
      return;
    }
    final ticket = OrderTicket(
      order: result,
      customer: customer,
      foodImage: image,
    );
    customer.acceptOrder(ticket);
    _waiter?.continueOrderRun(ticket);
  }

  bool waiterCollectedIngredients(OrderTicket ticket) {
    if (!ticket.customer.canReceiveService) return false;
    return controller.commitOrderIngredients(ticket.order);
  }

  void waiterHandedIngredientsToCook(OrderTicket ticket) {
    if (!ticket.customer.canReceiveService || ticket.order.cancelled) return;
    ticket.stage = OrderStage.waitingForCook;
    _cookQueue.add(ticket);
    _startCookIfPossible();
  }

  void _startCookIfPossible() {
    final cook = _cook;
    if (cook == null || !cook.isIdle || _cookQueue.isEmpty) return;
    OrderTicket? ticket;
    while (_cookQueue.isNotEmpty && ticket == null) {
      final candidate = _cookQueue.removeFirst();
      if (candidate.customer.canReceiveService && !candidate.order.cancelled) {
        ticket = candidate;
      }
    }
    if (ticket != null) cook.assignTicket(ticket);
  }

  void cookStarted(OrderTicket ticket) {
    controller.markOrderCooking(ticket.order);
  }

  void cookFinished(OrderTicket ticket) {
    if (ticket.order.cancelled || !ticket.customer.canReceiveService) return;
    ticket.stage = OrderStage.ready;
    _readyOrders.add(ticket);
    controller.markOrderReady(ticket.order);
    _dispatchWork();
    _startCookIfPossible();
  }

  void waiterDeliveredOrder(OrderTicket ticket) {
    if (!ticket.customer.canReceiveService || ticket.order.cancelled) return;
    final meal = TableMealComponent(
      image: ticket.foodImage,
      position: ticket.customer.seat.mealPoint.clone(),
      mealSize: size.x * 0.135,
    );
    ticket.customer.seat.meal = meal;
    world.add(meal);
    ticket.stage = OrderStage.eating;
    ticket.customer.receiveMeal(meal);
    controller.markOrderDelivered(ticket.order);
  }

  void customerFinishedMeal(CustomerComponent customer) {
    final ticket = customer.ticket;
    final meal = customer.seat.meal;
    if (ticket == null || meal == null) return;
    meal.markDirty();
    customer.seat.dirty = true;
    ticket.stage = OrderStage.waitingPayment;
    customer.waitForPayment();
    controller.markWaitingForPayment(ticket.order);
    _paymentQueue.add(customer);
    _dispatchWork();
  }

  void waiterCollectedPayment(CustomerComponent customer) {
    final ticket = customer.ticket;
    if (ticket == null) return;
    ticket.stage = OrderStage.paid;
    controller.completeCustomerOrder(
      ticket.order,
      serviceQuality: customer.serviceQuality,
    );
    customer.paymentCollected();
  }

  void customerAbandonedBeforeOrder(CustomerComponent customer) {
    controller.customerLeftBeforeOrder(
      reason: '${customer.profile.label} hilang sabar sebelum pesanan diambil.',
    );
    customer.leaveDisappointed();
  }

  void customerAbandonedOrder(CustomerComponent customer) {
    final ticket = customer.ticket;
    if (ticket != null) controller.customerAbandonedOrder(ticket.order);
    customer.leaveDisappointed();
  }

  void customerExited(CustomerComponent customer) {
    final seat = customer.seat;
    seat.customer = null;
    if (seat.dirty && seat.meal != null) {
      if (!_cleanupQueue.contains(seat)) _cleanupQueue.add(seat);
    } else {
      seat.reserved = false;
      _maybeFinishService();
    }
    _dispatchWork();
  }

  void waiterDeliveredDirtyDishes(SeatSlot seat) {
    seat.meal?.removeFromParent();
    seat.meal = null;
    seat.dirty = false;
    seat.reserved = false;
    _cook?.washDishesBriefly();
    _spawnDelay = min(_spawnDelay, 0.10);
    _maybeFinishService();
  }

  void _dispatchWork() {
    _startCookIfPossible();
    final waiter = _waiter;
    if (waiter == null || !waiter.isIdle) return;

    while (_readyOrders.isNotEmpty) {
      final ticket = _readyOrders.removeFirst();
      if (ticket.customer.canReceiveService && !ticket.order.cancelled) {
        waiter.assignDelivery(ticket);
        return;
      }
    }

    while (_paymentQueue.isNotEmpty) {
      final customer = _paymentQueue.removeFirst();
      if (customer.isWaitingForPayment) {
        waiter.assignPayment(customer);
        return;
      }
    }

    final cleanupBlocksArrival = controller.acceptingCustomers &&
        _spawned < controller.customersTotal &&
        _findFreeSeat() == null;
    if (cleanupBlocksArrival && _assignNextCleanup(waiter)) return;

    while (_waitingForOrder.isNotEmpty) {
      final customer = _waitingForOrder.removeFirst();
      if (customer.canTakeOrder) {
        waiter.assignTakeOrder(customer);
        return;
      }
    }

    _assignNextCleanup(waiter);
  }

  bool _assignNextCleanup(WaiterComponent waiter) {
    while (_cleanupQueue.isNotEmpty) {
      final seat = _cleanupQueue.removeFirst();
      if (seat.dirty && seat.meal != null && seat.customer == null) {
        waiter.assignCleanup(seat);
        return true;
      }
    }
    return false;
  }

  void _maybeFinishService() {
    if (!controller.serviceActive) return;
    final arrivalsComplete = !controller.acceptingCustomers ||
        _spawned >= controller.customersTotal;
    final seatsClear = _seats.every(
      (seat) =>
          seat.customer == null &&
          !seat.reserved &&
          !seat.dirty &&
          seat.meal == null,
    );
    final staffIdle = (_waiter?.isIdle ?? true) && (_cook?.isIdle ?? true);
    final sceneDrained = arrivalsComplete &&
        _activeCustomerCount == 0 &&
        seatsClear &&
        staffIdle;
    controller.tryFinishService(sceneDrained: sceneDrained);
  }

  Vector2 get entryPoint => Vector2(size.x * 0.50, size.y * 1.08);
  Vector2 get exitPoint => Vector2(size.x * 1.10, size.y * 0.94);
  Vector2 get cookHomePoint => Vector2(size.x * 0.24, size.y * 0.345);
  Vector2 get waiterHomePoint => Vector2(size.x * 0.76, size.y * 0.405);
  Vector2 get storagePoint => Vector2(size.x * 0.84, size.y * 0.325);
  Vector2 get cookHandoffPoint => Vector2(size.x * 0.40, size.y * 0.365);
  Vector2 get readyCounterPoint => Vector2(size.x * 0.53, size.y * 0.405);
  Vector2 get sinkPoint => Vector2(size.x * 0.13, size.y * 0.335);

  double get customerSpeed => size.y * 0.38;

  double get waiterSpeed =>
      size.y * (0.30 + controller.serviceLevel * 0.035);

  double get orderTakingDuration =>
      max(0.28, 0.86 - controller.serviceLevel * 0.10);

  double get ingredientGatherDuration =>
      max(0.24, 0.72 - controller.serviceLevel * 0.08);

  double get handoffDuration => 0.25;

  double get cookStageDuration =>
      max(0.35, 0.95 - controller.kitchenLevel * 0.11);

  double get eatingDuration => 2.1 + _random.nextDouble() * 0.9;

  double get orderPatience =>
      5.8 + controller.serviceLevel * 0.55 + controller.cleaningLevel * 0.10;

  double get foodPatience =>
      8.5 + controller.kitchenLevel * 0.75 + controller.serviceLevel * 0.20;

  double get paymentPatience => 5.0 + controller.serviceLevel * 0.35;

  double get paymentDuration =>
      max(0.25, 0.70 - controller.serviceLevel * 0.07);

  double get cleaningDuration =>
      max(0.28, 1.00 - controller.cleaningLevel * 0.13);

  ui.Image? image(String name) => loadedImages[name];

  void shutdown() {
    if (_disposed) return;
    _disposed = true;
    controller.removeListener(_handleControllerChanged);
  }

  @override
  void onRemove() {
    shutdown();
    super.onRemove();
  }
}

enum OrderStage {
  ordered,
  ingredientsCollected,
  waitingForCook,
  cooking,
  ready,
  eating,
  waitingPayment,
  paid,
}

class OrderTicket {
  OrderTicket({
    required this.order,
    required this.customer,
    required this.foodImage,
  });

  final CustomerServiceResult order;
  final CustomerComponent customer;
  final ui.Image foodImage;
  OrderStage stage = OrderStage.ordered;
}

class SeatSlot {
  SeatSlot({
    required this.index,
    required this.customerPoint,
    required this.mealPoint,
    required this.orderPoint,
    required this.servicePoint,
  });

  final int index;
  final Vector2 customerPoint;
  final Vector2 mealPoint;
  final Vector2 orderPoint;
  final Vector2 servicePoint;

  bool reserved = false;
  bool dirty = false;
  CustomerComponent? customer;
  TableMealComponent? meal;

  bool get isAvailable => !reserved && !dirty && customer == null && meal == null;
}

class WarungSceneComponent extends PositionComponent {
  WarungSceneComponent({
    required this.game,
    required Vector2 gameSize,
  }) : _gameSize = gameSize {
    priority = -100;
    size = gameSize;
  }

  final WarungKitaGame game;
  Vector2 _gameSize;

  void resizeTo(Vector2 newSize) {
    _gameSize = newSize.clone();
    size = newSize;
  }

  void markNeedsRefresh() {}

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final width = _gameSize.x;
    final height = _gameSize.y;
    if (width <= 0 || height <= 0) return;

    final wallPaint = Paint()..color = const Color(0xFFF6DFAE);
    final floorPaintA = Paint()..color = const Color(0xFFE8BD72);
    final floorPaintB = Paint()..color = const Color(0xFFDCAA5C);
    final borderPaint = Paint()
      ..color = const Color(0x448A4A25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(0.8, width * 0.0025);

    canvas.drawRect(Rect.fromLTWH(0, 0, width, height * 0.48), wallPaint);
    const columns = 8;
    const rows = 8;
    final tileWidth = width / columns;
    final floorTop = height * 0.39;
    final tileHeight = (height - floorTop) / rows;
    for (var row = 0; row < rows; row++) {
      for (var column = 0; column < columns; column++) {
        final rect = Rect.fromLTWH(
          column * tileWidth,
          floorTop + row * tileHeight,
          tileWidth,
          tileHeight,
        );
        canvas.drawRect(
          rect,
          (row + column).isEven ? floorPaintA : floorPaintB,
        );
        canvas.drawRect(rect, borderPaint);
      }
    }

    final warungLevel = _boundedTier(game.controller.warungLevel, 6);
    _drawAsset(
      canvas,
      'environment/warung_tier_$warungLevel.png',
      Rect.fromLTWH(width * 0.19, height * 0.005, width * 0.62, height * 0.26),
    );

    final kitchenTier = _boundedTier(game.controller.kitchenLevel, 3);
    final storageTier = _boundedTier(game.controller.storageLevel, 3);
    final serviceTier = _boundedTier(game.controller.serviceLevel, 3);
    final cleaningTier = _boundedTier(game.controller.cleaningLevel, 3);

    _drawAsset(
      canvas,
      'environment/stove_tier_$kitchenTier.png',
      Rect.fromLTWH(width * 0.04, height * 0.245, width * 0.24, height * 0.105),
    );
    _drawAsset(
      canvas,
      'environment/sink_tier_$cleaningTier.png',
      Rect.fromLTWH(width * 0.015, height * 0.335, width * 0.20, height * 0.08),
    );
    _drawAsset(
      canvas,
      'environment/storage_tier_$storageTier.png',
      Rect.fromLTWH(width * 0.73, height * 0.245, width * 0.25, height * 0.12),
    );
    _drawAsset(
      canvas,
      'environment/counter_tier_$serviceTier.png',
      Rect.fromLTWH(width * 0.32, height * 0.29, width * 0.38, height * 0.115),
    );

    if (game.controller.popularityLevel >= 3) {
      _drawAsset(
        canvas,
        'environment/lights_long.png',
        Rect.fromLTWH(width * 0.18, height * 0.20, width * 0.64, height * 0.055),
      );
    }

    final tableAsset = game.controller.tableLevel >= 4
        ? 'environment/table_umbrella.png'
        : game.controller.tableLevel >= 2
            ? 'environment/table_square.png'
            : 'environment/table_long.png';
    for (final seat in game._seats) {
      _drawAsset(
        canvas,
        tableAsset,
        Rect.fromCenter(
          center: Offset(seat.mealPoint.x, seat.mealPoint.y),
          width: width * 0.22,
          height: width * 0.105,
        ),
      );
    }

    final pathPaint = Paint()
      ..color = const Color(0x44FFF7DD)
      ..strokeWidth = width * 0.095
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(width * 0.50, height * 0.45),
      Offset(width * 0.50, height * 1.01),
      pathPaint,
    );
  }

  int _boundedTier(int value, int maximum) {
    if (value < 1) return 1;
    if (value > maximum) return maximum;
    return value;
  }

  void _drawAsset(Canvas canvas, String name, Rect bounds) {
    final image = game.image(name);
    if (image == null) return;
    final imageRatio = image.width / image.height;
    final boundsRatio = bounds.width / bounds.height;
    late Rect destination;
    if (imageRatio > boundsRatio) {
      final targetHeight = bounds.width / imageRatio;
      destination = Rect.fromLTWH(
        bounds.left,
        bounds.top + (bounds.height - targetHeight) / 2,
        bounds.width,
        targetHeight,
      );
    } else {
      final targetWidth = bounds.height * imageRatio;
      destination = Rect.fromLTWH(
        bounds.left + (bounds.width - targetWidth) / 2,
        bounds.top,
        targetWidth,
        bounds.height,
      );
    }
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      destination,
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class CustomerProfile {
  const CustomerProfile({
    required this.label,
    required this.patienceMultiplier,
  });

  final String label;
  final double patienceMultiplier;

  factory CustomerProfile.fromAsset(String asset) {
    final match = RegExp(r'customer_(\d+)').firstMatch(asset);
    final index = int.tryParse(match?.group(1) ?? '') ?? 1;
    switch (index % 6) {
      case 0:
        return const CustomerProfile(
          label: 'Pelanggan tergesa-gesa',
          patienceMultiplier: 0.72,
        );
      case 1:
        return const CustomerProfile(
          label: 'Pelanggan biasa',
          patienceMultiplier: 1.00,
        );
      case 2:
        return const CustomerProfile(
          label: 'Pelanggan santai',
          patienceMultiplier: 1.25,
        );
      case 3:
        return const CustomerProfile(
          label: 'Pelanggan teliti',
          patienceMultiplier: 0.90,
        );
      case 4:
        return const CustomerProfile(
          label: 'Pelanggan keluarga',
          patienceMultiplier: 1.15,
        );
      default:
        return const CustomerProfile(
          label: 'Pelanggan sibuk',
          patienceMultiplier: 0.82,
        );
    }
  }
}

enum CustomerPhase {
  entering,
  waitingOrder,
  waitingFood,
  eating,
  waitingPayment,
  rejected,
  leaving,
}

class CustomerComponent extends SpriteComponent {
  CustomerComponent({
    required this.game,
    required Sprite sprite,
    required this.seat,
    required this.profile,
  }) : super(sprite: sprite, anchor: Anchor.center, priority: 20);

  final WarungKitaGame game;
  final SeatSlot seat;
  final CustomerProfile profile;

  CustomerPhase _phase = CustomerPhase.entering;
  late Vector2 _target;
  late Vector2 _standingSize;
  double _phaseTimer = 0;
  double _eatingDuration = 0;
  double _patienceRemaining = 0;
  double _patienceMaximum = 1;
  double _serviceQuality = 1.0;
  PositionComponent? _bubble;
  OrderTicket? ticket;
  TableMealComponent? meal;

  bool get canTakeOrder => _phase == CustomerPhase.waitingOrder;
  bool get canReceiveService =>
      _phase == CustomerPhase.waitingFood && ticket != null;
  bool get isWaitingForPayment => _phase == CustomerPhase.waitingPayment;
  double get serviceQuality => _serviceQuality.clamp(0.0, 1.0).toDouble();

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final characterWidth = game.size.x * 0.115;
    _standingSize = Vector2(characterWidth, characterWidth * 1.45);
    size = _standingSize.clone();
    position = game.entryPoint;
    _target = seat.customerPoint.clone();
  }

  @override
  void update(double dt) {
    super.update(dt);
    switch (_phase) {
      case CustomerPhase.entering:
      case CustomerPhase.leaving:
        _moveTowardsTarget(dt);
        break;
      case CustomerPhase.eating:
        _phaseTimer -= dt;
        if (_eatingDuration > 0) {
          final progress = 1 - max(0.0, _phaseTimer) / _eatingDuration;
          meal?.setEatingProgress(progress);
        }
        if (_phaseTimer <= 0) _finishEating();
        break;
      case CustomerPhase.rejected:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _beginLeaving();
        break;
      case CustomerPhase.waitingOrder:
      case CustomerPhase.waitingFood:
      case CustomerPhase.waitingPayment:
        _updatePatience(dt);
        break;
    }
  }

  void _moveTowardsTarget(double dt) {
    final delta = _target - position;
    final distance = delta.length;
    if (distance <= max(2.0, game.size.x * 0.006)) {
      position = _target;
      _arrived();
      return;
    }
    final step = game.customerSpeed * dt;
    if (step >= distance) {
      position = _target;
      _arrived();
      return;
    }
    position += delta.normalized() * step;
  }

  void _arrived() {
    if (_phase == CustomerPhase.entering) {
      size = Vector2(_standingSize.x, _standingSize.y * 0.82);
      position = seat.customerPoint.clone();
      _phase = CustomerPhase.waitingOrder;
      _startPatience(game.orderPatience);
      game.customerSeated(this);
    } else if (_phase == CustomerPhase.leaving) {
      game.customerExited(this);
      removeFromParent();
    }
  }

  void showWaitingForOrder() {
    _setMoodBubble(Icons.receipt_long_rounded, const Color(0xFFFFC94A));
  }

  void acceptOrder(OrderTicket value) {
    ticket = value;
    _phase = CustomerPhase.waitingFood;
    _startPatience(game.foodPatience);
    _bubble?.removeFromParent();
    final bubble = FoodBubbleComponent(
      image: value.foodImage,
      position: Vector2(size.x * 0.74, -size.y * 0.03),
      bubbleSize: game.size.x * 0.082,
    );
    _bubble = bubble;
    add(bubble);
  }

  void rejectOrder() {
    _phase = CustomerPhase.rejected;
    _phaseTimer = 0.55;
    _setMoodBubble(Icons.sentiment_dissatisfied, const Color(0xFFE54B3F));
  }

  void receiveMeal(TableMealComponent deliveredMeal) {
    if (!canReceiveService) return;
    _bubble?.removeFromParent();
    _bubble = null;
    meal = deliveredMeal;
    _phase = CustomerPhase.eating;
    _eatingDuration = game.eatingDuration;
    _phaseTimer = _eatingDuration;
  }

  void _finishEating() {
    if (_phase != CustomerPhase.eating) return;
    game.customerFinishedMeal(this);
  }

  void waitForPayment() {
    _phase = CustomerPhase.waitingPayment;
    _startPatience(game.paymentPatience);
    _setMoodBubble(Icons.payments_rounded, const Color(0xFFFFD34D));
  }

  void _startPatience(double baseSeconds) {
    _patienceMaximum = max(1.0, baseSeconds * profile.patienceMultiplier);
    _patienceRemaining = _patienceMaximum;
  }

  void _updatePatience(double dt) {
    _patienceRemaining -= dt;
    final fraction = (_patienceRemaining / _patienceMaximum)
        .clamp(0.0, 1.0)
        .toDouble();
    final phaseQuality = 0.20 + fraction * 0.80;
    _serviceQuality = min(_serviceQuality, phaseQuality);

    if (_patienceRemaining > 0 || _phase == CustomerPhase.waitingPayment) {
      return;
    }
    if (_phase == CustomerPhase.waitingOrder) {
      game.customerAbandonedBeforeOrder(this);
    } else if (_phase == CustomerPhase.waitingFood) {
      game.customerAbandonedOrder(this);
    }
  }

  void leaveDisappointed() {
    if (_phase == CustomerPhase.leaving || _phase == CustomerPhase.rejected) {
      return;
    }
    _phase = CustomerPhase.rejected;
    _phaseTimer = 0.38;
    _setMoodBubble(Icons.sentiment_very_dissatisfied, const Color(0xFFE54B3F));
  }

  void paymentCollected() {
    _setMoodBubble(Icons.sentiment_very_satisfied, const Color(0xFF66BE4A));
    _beginLeaving();
  }

  void _beginLeaving() {
    size = _standingSize.clone();
    _phase = CustomerPhase.leaving;
    _target = game.exitPoint;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (_phase != CustomerPhase.waitingOrder &&
        _phase != CustomerPhase.waitingFood &&
        _phase != CustomerPhase.waitingPayment) {
      return;
    }
    final fraction = (_patienceRemaining / _patienceMaximum)
        .clamp(0.0, 1.0)
        .toDouble();
    final barRect = Rect.fromLTWH(size.x * 0.12, size.y * 0.94, size.x * 0.76, 5);
    canvas.drawRRect(
      RRect.fromRectAndRadius(barRect, const Radius.circular(4)),
      Paint()..color = const Color(0x88000000),
    );
    final fillColor = fraction > 0.55
        ? const Color(0xFF54B948)
        : fraction > 0.25
            ? const Color(0xFFFFB52B)
            : const Color(0xFFE54B3F);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(barRect.left, barRect.top, barRect.width * fraction, barRect.height),
        const Radius.circular(4),
      ),
      Paint()..color = fillColor,
    );
  }

  void _setMoodBubble(IconData icon, Color color) {
    _bubble?.removeFromParent();
    final bubble = IconBubbleComponent(
      icon: icon,
      color: color,
      position: Vector2(size.x * 0.72, -size.y * 0.03),
      bubbleSize: game.size.x * 0.072,
    );
    _bubble = bubble;
    add(bubble);
  }
}

enum CookPhase {
  idle,
  receiving,
  chopping,
  cooking,
  plating,
  washing,
}

class CookComponent extends SpriteComponent {
  CookComponent({required this.game, required Sprite sprite})
      : super(sprite: sprite, anchor: Anchor.center, priority: 30);

  final WarungKitaGame game;
  CookPhase _phase = CookPhase.idle;
  double _phaseTimer = 0;
  OrderTicket? _ticket;
  int _pendingDishWashes = 0;

  bool get isIdle => _phase == CookPhase.idle;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final width = game.size.x * 0.145;
    size = Vector2(width, width * 1.45);
    snapHome();
  }

  void snapHome() {
    position = game.cookHomePoint;
  }

  void assignTicket(OrderTicket ticket) {
    if (!isIdle) return;
    _ticket = ticket;
    ticket.stage = OrderStage.cooking;
    _setPhase(CookPhase.receiving, 'staff/cook_receive.png', 0.28);
    game.cookStarted(ticket);
  }

  void washDishesBriefly() {
    _pendingDishWashes++;
    _startWashIfPossible();
  }

  void _startWashIfPossible() {
    if (!isIdle || _pendingDishWashes <= 0 || game._cookQueue.isNotEmpty) {
      return;
    }
    _pendingDishWashes--;
    _setPhase(CookPhase.washing, 'staff/cook_wash.png', 0.55);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_phase == CookPhase.idle) return;
    _phaseTimer -= dt;
    if (_phaseTimer > 0) return;

    switch (_phase) {
      case CookPhase.receiving:
        _setPhase(CookPhase.chopping, 'staff/cook_chop.png', game.cookStageDuration);
        break;
      case CookPhase.chopping:
        final useFry = _ticket?.order.item?.id.contains('goreng') ?? false;
        _setPhase(
          CookPhase.cooking,
          useFry ? 'staff/cook_fry.png' : 'staff/cook_stir.png',
          game.cookStageDuration,
        );
        break;
      case CookPhase.cooking:
        _setPhase(
          CookPhase.plating,
          'staff/cook_plate.png',
          game.cookStageDuration * 0.75,
        );
        break;
      case CookPhase.plating:
        final ticket = _ticket;
        _ticket = null;
        _setIdle();
        if (ticket != null) game.cookFinished(ticket);
        _startWashIfPossible();
        break;
      case CookPhase.washing:
        _setIdle();
        game._startCookIfPossible();
        _startWashIfPossible();
        break;
      case CookPhase.idle:
        break;
    }
  }

  void _setPhase(CookPhase phase, String imageName, double duration) {
    _phase = phase;
    _phaseTimer = duration;
    final image = game.image(imageName);
    if (image != null) sprite = Sprite(image);
  }

  void _setIdle() {
    _phase = CookPhase.idle;
    _phaseTimer = 0;
    final image = game.image('staff/cook_idle.png');
    if (image != null) sprite = Sprite(image);
  }
}

enum WaiterPhase {
  idle,
  walkingToCustomer,
  takingOrder,
  walkingToStorage,
  gatheringIngredients,
  carryingIngredientsToCook,
  handingIngredients,
  walkingToReadyCounter,
  pickingUpFood,
  carryingFoodToTable,
  serving,
  walkingToPayment,
  collectingPayment,
  walkingToCleanup,
  cleaningTable,
  carryingDirtyToSink,
  returning,
}

class WaiterComponent extends SpriteComponent {
  WaiterComponent({required this.game, required Sprite sprite})
      : super(sprite: sprite, anchor: Anchor.center, priority: 31);

  final WarungKitaGame game;
  WaiterPhase _phase = WaiterPhase.idle;
  late Vector2 _target;
  double _phaseTimer = 0;
  CustomerComponent? _customer;
  OrderTicket? _ticket;
  SeatSlot? _cleanupSeat;

  bool get isIdle => _phase == WaiterPhase.idle;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final width = game.size.x * 0.13;
    size = Vector2(width, width * 1.50);
    snapHome();
  }

  void snapHome() {
    position = game.waiterHomePoint;
    _target = position.clone();
  }

  void assignTakeOrder(CustomerComponent customer) {
    if (!isIdle || !customer.canTakeOrder) return;
    _customer = customer;
    _phase = WaiterPhase.walkingToCustomer;
    _target = customer.seat.orderPoint.clone();
    _setSprite('staff/waiter_greet.png');
  }

  void continueOrderRun(OrderTicket ticket) {
    _ticket = ticket;
    _phase = WaiterPhase.walkingToStorage;
    _target = game.storagePoint;
    _setSprite('staff/waiter_order.png');
  }

  void assignDelivery(OrderTicket ticket) {
    if (!isIdle) return;
    _ticket = ticket;
    _phase = WaiterPhase.walkingToReadyCounter;
    _target = game.readyCounterPoint;
    _setSprite('staff/waiter_order.png');
  }

  void assignPayment(CustomerComponent customer) {
    if (!isIdle) return;
    _customer = customer;
    _phase = WaiterPhase.walkingToPayment;
    _target = customer.seat.servicePoint.clone();
    _setSprite('staff/waiter_payment.png');
  }

  void assignCleanup(SeatSlot seat) {
    if (!isIdle || !seat.dirty || seat.meal == null) return;
    _cleanupSeat = seat;
    _phase = WaiterPhase.walkingToCleanup;
    _target = seat.servicePoint.clone();
    _setSprite('staff/waiter_clean.png');
  }

  @override
  void update(double dt) {
    super.update(dt);
    switch (_phase) {
      case WaiterPhase.idle:
        break;
      case WaiterPhase.walkingToCustomer:
      case WaiterPhase.walkingToStorage:
      case WaiterPhase.carryingIngredientsToCook:
      case WaiterPhase.walkingToReadyCounter:
      case WaiterPhase.carryingFoodToTable:
      case WaiterPhase.walkingToPayment:
      case WaiterPhase.walkingToCleanup:
      case WaiterPhase.carryingDirtyToSink:
      case WaiterPhase.returning:
        _moveTowardsTarget(dt);
        break;
      case WaiterPhase.takingOrder:
      case WaiterPhase.gatheringIngredients:
      case WaiterPhase.handingIngredients:
      case WaiterPhase.pickingUpFood:
      case WaiterPhase.serving:
      case WaiterPhase.collectingPayment:
      case WaiterPhase.cleaningTable:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _finishTimedPhase();
        break;
    }
  }

  void _moveTowardsTarget(double dt) {
    final delta = _target - position;
    final distance = delta.length;
    if (distance <= max(2.0, game.size.x * 0.006)) {
      position = _target;
      _arrived();
      return;
    }
    final step = game.waiterSpeed * dt;
    if (step >= distance) {
      position = _target;
      _arrived();
      return;
    }
    position += delta.normalized() * step;
  }

  void _arrived() {
    switch (_phase) {
      case WaiterPhase.walkingToCustomer:
        _phase = WaiterPhase.takingOrder;
        _phaseTimer = game.orderTakingDuration;
        _setSprite('staff/waiter_order.png');
        break;
      case WaiterPhase.walkingToStorage:
        _phase = WaiterPhase.gatheringIngredients;
        _phaseTimer = game.ingredientGatherDuration;
        _setSprite('staff/waiter_ingredients.png');
        break;
      case WaiterPhase.carryingIngredientsToCook:
        _phase = WaiterPhase.handingIngredients;
        _phaseTimer = game.handoffDuration;
        _setSprite('staff/waiter_ingredients.png');
        break;
      case WaiterPhase.walkingToReadyCounter:
        _phase = WaiterPhase.pickingUpFood;
        _phaseTimer = 0.24;
        _setSprite('staff/waiter_food.png');
        break;
      case WaiterPhase.carryingFoodToTable:
        _phase = WaiterPhase.serving;
        _phaseTimer = 0.25;
        _setSprite('staff/waiter_serve.png');
        break;
      case WaiterPhase.walkingToPayment:
        _phase = WaiterPhase.collectingPayment;
        _phaseTimer = game.paymentDuration;
        _setSprite('staff/waiter_payment.png');
        break;
      case WaiterPhase.walkingToCleanup:
        _phase = WaiterPhase.cleaningTable;
        _phaseTimer = game.cleaningDuration;
        _setSprite('staff/waiter_clean.png');
        break;
      case WaiterPhase.carryingDirtyToSink:
        final seat = _cleanupSeat;
        if (seat != null) game.waiterDeliveredDirtyDishes(seat);
        _cleanupSeat = null;
        _returnHome();
        break;
      case WaiterPhase.returning:
        _setIdle();
        game._dispatchWork();
        break;
      case WaiterPhase.idle:
      case WaiterPhase.takingOrder:
      case WaiterPhase.gatheringIngredients:
      case WaiterPhase.handingIngredients:
      case WaiterPhase.pickingUpFood:
      case WaiterPhase.serving:
      case WaiterPhase.collectingPayment:
      case WaiterPhase.cleaningTable:
        break;
    }
  }

  void _finishTimedPhase() {
    switch (_phase) {
      case WaiterPhase.takingOrder:
        final customer = _customer;
        if (customer != null) game.waiterTookOrder(customer);
        if (_phase == WaiterPhase.takingOrder) {
          _customer = null;
          _returnHome();
        }
        break;
      case WaiterPhase.gatheringIngredients:
        final ticket = _ticket;
        if (ticket == null || !game.waiterCollectedIngredients(ticket)) {
          ticket?.customer.rejectOrder();
          _ticket = null;
          _returnHome();
          return;
        }
        ticket.stage = OrderStage.ingredientsCollected;
        _phase = WaiterPhase.carryingIngredientsToCook;
        _target = game.cookHandoffPoint;
        _setSprite('staff/waiter_ingredients.png');
        break;
      case WaiterPhase.handingIngredients:
        final ticket = _ticket;
        if (ticket != null) game.waiterHandedIngredientsToCook(ticket);
        _ticket = null;
        _customer = null;
        _returnHome();
        break;
      case WaiterPhase.pickingUpFood:
        final ticket = _ticket;
        if (ticket == null || !ticket.customer.canReceiveService) {
          _ticket = null;
          _returnHome();
          return;
        }
        _phase = WaiterPhase.carryingFoodToTable;
        _target = ticket.customer.seat.servicePoint.clone();
        _setSprite('staff/waiter_food.png');
        break;
      case WaiterPhase.serving:
        final ticket = _ticket;
        if (ticket != null) game.waiterDeliveredOrder(ticket);
        _ticket = null;
        _returnHome();
        break;
      case WaiterPhase.collectingPayment:
        final customer = _customer;
        if (customer != null) game.waiterCollectedPayment(customer);
        _customer = null;
        _returnHome();
        break;
      case WaiterPhase.cleaningTable:
        _phase = WaiterPhase.carryingDirtyToSink;
        _target = game.sinkPoint;
        _setSprite('staff/waiter_dirty.png');
        break;
      case WaiterPhase.idle:
      case WaiterPhase.walkingToCustomer:
      case WaiterPhase.walkingToStorage:
      case WaiterPhase.carryingIngredientsToCook:
      case WaiterPhase.walkingToReadyCounter:
      case WaiterPhase.carryingFoodToTable:
      case WaiterPhase.walkingToPayment:
      case WaiterPhase.walkingToCleanup:
      case WaiterPhase.carryingDirtyToSink:
      case WaiterPhase.returning:
        break;
    }
  }

  void _returnHome() {
    _phase = WaiterPhase.returning;
    _target = game.waiterHomePoint;
    _setSprite('staff/waiter_order.png');
  }

  void _setIdle() {
    _phase = WaiterPhase.idle;
    _phaseTimer = 0;
    _ticket = null;
    _customer = null;
    _cleanupSeat = null;
    _setSprite('staff/waiter_order.png');
  }

  void _setSprite(String name) {
    final image = game.image(name);
    if (image != null) sprite = Sprite(image);
  }
}

class TableMealComponent extends PositionComponent {
  TableMealComponent({
    required this.image,
    required Vector2 position,
    required double mealSize,
  }) : super(
          position: position,
          size: Vector2(mealSize, mealSize * 0.72),
          anchor: Anchor.center,
          priority: 18,
        );

  final ui.Image image;
  bool _dirty = false;
  double _eatingProgress = 0;

  void setEatingProgress(double progress) {
    _eatingProgress = progress.clamp(0.0, 1.0).toDouble();
  }

  void markDirty() {
    _dirty = true;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final shadow = Paint()..color = const Color(0x44000000);
    final plate = Paint()..color = const Color(0xFFF7F0DF);
    final rim = Paint()
      ..color = const Color(0xFFB9A47F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(1.0, size.x * 0.035);
    final plateRect = Rect.fromLTWH(0, size.y * 0.15, size.x, size.y * 0.70);
    canvas.drawOval(plateRect.shift(Offset(size.x * 0.03, size.y * 0.05)), shadow);
    canvas.drawOval(plateRect, plate);
    canvas.drawOval(plateRect, rim);

    if (!_dirty) {
      final foodScale = 0.88 - _eatingProgress * 0.50;
      final foodWidth = size.x * foodScale;
      final foodHeight = size.y * (0.90 - _eatingProgress * 0.42);
      canvas.drawImageRect(
        image,
        Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
        Rect.fromLTWH(
          (size.x - foodWidth) / 2,
          size.y * 0.02 + _eatingProgress * size.y * 0.18,
          foodWidth,
          foodHeight,
        ),
        Paint()..filterQuality = FilterQuality.medium,
      );
      return;
    }

    final leftoverPaint = Paint()
      ..filterQuality = FilterQuality.medium
      ..color = const Color(0x77FFFFFF);
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(size.x * 0.33, size.y * 0.25, size.x * 0.34, size.y * 0.34),
      leftoverPaint,
    );
    final crumb = Paint()..color = const Color(0xFF8A4A25);
    canvas.drawCircle(Offset(size.x * 0.25, size.y * 0.54), size.x * 0.035, crumb);
    canvas.drawCircle(Offset(size.x * 0.69, size.y * 0.46), size.x * 0.025, crumb);
    canvas.drawCircle(Offset(size.x * 0.55, size.y * 0.64), size.x * 0.020, crumb);
  }
}

class FoodBubbleComponent extends PositionComponent {
  FoodBubbleComponent({
    required this.image,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final ui.Image image;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final shadowPaint = Paint()..color = const Color(0x44000000);
    final bubblePaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(size.x * 0.54, size.y * 0.57), size.x * 0.49, shadowPaint);
    canvas.drawCircle(Offset(size.x * 0.50, size.y * 0.50), size.x * 0.47, bubblePaint);
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(size.x * 0.12, size.y * 0.18, size.x * 0.76, size.y * 0.62),
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class IconBubbleComponent extends PositionComponent {
  IconBubbleComponent({
    required this.icon,
    required this.color,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final IconData icon;
  final Color color;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final shadowPaint = Paint()..color = const Color(0x44000000);
    final bubblePaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(size.x * 0.54, size.y * 0.57), size.x * 0.49, shadowPaint);
    canvas.drawCircle(Offset(size.x * 0.50, size.y * 0.50), size.x * 0.47, bubblePaint);
    final textPainter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(icon.codePoint),
        style: TextStyle(
          fontSize: size.x * 0.52,
          fontFamily: icon.fontFamily,
          package: icon.fontPackage,
          color: color,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(
      canvas,
      Offset((size.x - textPainter.width) / 2, (size.y - textPainter.height) / 2),
    );
  }
}
