import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import 'game_data.dart';
import 'game_repository.dart';
import 'game_state.dart';

class CustomerServiceResult {
  CustomerServiceResult({
    required this.served,
    required this.message,
    this.item,
    this.sequence = 0,
  });

  final bool served;
  final String message;
  final MenuDefinition? item;
  final int sequence;

  bool ingredientsCommitted = false;
  bool completed = false;
  bool cancelled = false;
  bool wasted = false;
  double serviceQuality = 1.0;
  int earned = 0;
  int tip = 0;
  int reputation = 0;
}

class GameController extends ChangeNotifier {
  GameController({required this.state, required GameRepository repository})
      : _repository = repository;

  final GameState state;
  final GameRepository _repository;
  final Random _random = Random();
  final Map<String, int> _reservedInventory = <String, int>{};

  bool serviceActive = false;
  bool acceptingCustomers = false;
  int customersTotal = 0;
  int customersRemaining = 0;
  int ordersInProgress = 0;
  int _orderSequence = 0;
  bool _finishingService = false;
  String serviceStatus = 'Warung bersedia dibuka.';
  String? lastSoldItemId;

  double get serviceProgress {
    if (customersTotal <= 0) return 0;
    return (customersTotal - customersRemaining) / customersTotal;
  }

  int get warungLevel => state.upgradeLevels['warung'] ?? 1;
  int get kitchenLevel => state.upgradeLevels['kitchen'] ?? 1;
  int get tableLevel => state.upgradeLevels['tables'] ?? 1;
  int get storageLevel => state.upgradeLevels['storage'] ?? 1;
  int get serviceLevel => state.upgradeLevels['service'] ?? 1;
  int get cleaningLevel => state.upgradeLevels['cleaning'] ?? 1;
  int get popularityLevel => state.upgradeLevels['popularity'] ?? 1;
  int get profitLevel => state.upgradeLevels['profit'] ?? 1;

  int get servedToday =>
      serviceActive ? _workingReport.served : (state.lastReport?.served ?? 0);

  int get missedToday =>
      serviceActive ? _workingReport.missed : (state.lastReport?.missed ?? 0);

  int get wastedToday =>
      serviceActive ? _workingReport.wasted : (state.lastReport?.wasted ?? 0);

  int get satisfactionToday {
    if (!serviceActive) return state.lastReport?.satisfaction ?? 100;
    if (_workingReport.qualitySamples <= 0) return 100;
    return ((_workingReport.satisfactionTotal / _workingReport.qualitySamples) * 100)
        .round()
        .clamp(0, 100)
        .toInt();
  }

  int get seatCount => min(6, 2 + (tableLevel - 1));

  int get storageCapacity => 120 + (storageLevel - 1) * 45;

  int get inventoryUsed =>
      state.inventory.values.fold<int>(0, (sum, amount) => sum + amount);

  int get inventoryFree => max(0, storageCapacity - inventoryUsed);

  double get profitMultiplier => 1 + (profitLevel - 1) * 0.06;

  Future<void> save() => _repository.save(state);

  void setServiceStatus(String value) {
    serviceStatus = value;
    notifyListeners();
  }

  List<MenuDefinition> availableMenuItems({bool requireStock = true}) {
    final result = <MenuDefinition>[];
    for (final item in menuItems.values) {
      if (warungLevel < item.unlockLevel) continue;
      if (!(state.menuEnabled[item.id] ?? true)) continue;
      if (requireStock && !hasRecipe(item.recipe, includeReservations: true)) {
        continue;
      }
      result.add(item);
    }
    return result;
  }

  bool hasRecipe(
    Map<String, int> recipe, {
    bool includeReservations = false,
  }) {
    for (final entry in recipe.entries) {
      final reserved = includeReservations ? (_reservedInventory[entry.key] ?? 0) : 0;
      if ((state.inventory[entry.key] ?? 0) - reserved < entry.value) {
        return false;
      }
    }
    return true;
  }

  int customerCapacity() {
    return min(
      50,
      5 +
          (state.day ~/ 2) +
          warungLevel * 2 +
          tableLevel * 2 +
          popularityLevel * 3 +
          state.reputation ~/ 40,
    );
  }

  int estimatedServings() {
    final inventoryCopy = Map<String, int>.from(state.inventory);
    final enabled = availableMenuItems(requireStock: false);
    if (enabled.isEmpty) return 0;

    var estimate = 0;
    for (var cycle = 0; cycle < 150; cycle++) {
      MenuDefinition? selected;
      for (final item in enabled) {
        final canMake = item.recipe.entries.every(
          (entry) => (inventoryCopy[entry.key] ?? 0) >= entry.value,
        );
        if (canMake) {
          selected = item;
          break;
        }
      }
      if (selected == null) break;
      for (final entry in selected.recipe.entries) {
        inventoryCopy[entry.key] =
            (inventoryCopy[entry.key] ?? 0) - entry.value;
      }
      estimate++;
    }
    return estimate;
  }

  String? startService() {
    if (serviceActive) return null;
    if (availableMenuItems().isEmpty) {
      return 'Tiada hidangan dapat disediakan. Beli stok atau aktifkan menu.';
    }

    _reservedInventory.clear();
    _workingReport.reset();
    serviceActive = true;
    acceptingCustomers = true;
    customersTotal = customerCapacity();
    customersRemaining = customersTotal;
    ordersInProgress = 0;
    _orderSequence = 0;
    _finishingService = false;
    serviceStatus = 'Pelanggan mula datang. Pelayan bersedia mengambil pesanan.';
    lastSoldItemId = null;
    notifyListeners();
    return null;
  }

  CustomerServiceResult takeCustomerOrder() {
    if (!serviceActive || !acceptingCustomers || customersRemaining <= 0) {
      return CustomerServiceResult(
        served: false,
        message: 'Warung tidak menerima pesanan baharu.',
      );
    }

    final possible = availableMenuItems();
    if (possible.isEmpty) {
      _closeOrdersBecauseStockEnded();
      return CustomerServiceResult(
        served: false,
        message: serviceStatus,
      );
    }

    final item = possible[_random.nextInt(possible.length)];
    _reserveRecipe(item.recipe);
    ordersInProgress++;
    _orderSequence++;
    serviceStatus =
        '${item.name} dicatat. Pelayan akan mengambil bahan dari stor.';
    notifyListeners();

    return CustomerServiceResult(
      served: true,
      message: serviceStatus,
      item: item,
      sequence: _orderSequence,
    );
  }

  bool commitOrderIngredients(CustomerServiceResult order) {
    final item = order.item;
    if (!order.served || item == null || order.cancelled) return false;
    if (order.ingredientsCommitted) return true;

    for (final entry in item.recipe.entries) {
      if ((state.inventory[entry.key] ?? 0) < entry.value) {
        cancelOrder(order, countAsMissed: true);
        return false;
      }
    }

    for (final entry in item.recipe.entries) {
      state.inventory[entry.key] =
          max(0, (state.inventory[entry.key] ?? 0) - entry.value);
      _reservedInventory[entry.key] =
          max(0, (_reservedInventory[entry.key] ?? 0) - entry.value);
    }
    order.ingredientsCommitted = true;
    serviceStatus =
        'Bahan ${item.name} dibawa kepada tukang masak.';
    notifyListeners();
    return true;
  }

  void markOrderCooking(CustomerServiceResult order) {
    final item = order.item;
    if (!serviceActive || item == null || order.cancelled) return;
    serviceStatus = '${item.name} sedang dimasak.';
    notifyListeners();
  }

  void markOrderReady(CustomerServiceResult order) {
    final item = order.item;
    if (!serviceActive || item == null || order.cancelled) return;
    serviceStatus = '${item.name} siap. Pelayan akan menghantarnya.';
    notifyListeners();
  }

  void markOrderDelivered(CustomerServiceResult order) {
    final item = order.item;
    if (!serviceActive || item == null || order.cancelled) return;
    serviceStatus = '${item.name} telah dihantar. Pelanggan sedang makan.';
    notifyListeners();
  }

  void markWaitingForPayment(CustomerServiceResult order) {
    final item = order.item;
    if (!serviceActive || item == null || order.cancelled) return;
    serviceStatus = '${item.name} selesai dimakan. Pelayan mengambil bayaran.';
    notifyListeners();
  }

  void completeCustomerOrder(
    CustomerServiceResult order, {
    required double serviceQuality,
  }) {
    final item = order.item;
    if (!order.served || item == null || order.completed || order.cancelled) {
      return;
    }

    final quality = serviceQuality.clamp(0.0, 1.0).toDouble();
    order
      ..completed = true
      ..serviceQuality = quality;
    ordersInProgress = max(0, ordersInProgress - 1);
    customersRemaining = max(0, customersRemaining - 1);

    final saleValue = max(1, (item.price * profitMultiplier).round());
    final baseTipChance = min(
      0.60,
      0.05 + popularityLevel * 0.035 + cleaningLevel * 0.020,
    );
    final tipChance = baseTipChance * (0.30 + quality * 0.70);
    final tip = _random.nextDouble() < tipChance
        ? 1 + _random.nextInt(2 + popularityLevel)
        : 0;
    final repGain = quality >= 0.82
        ? 1 + (popularityLevel >= 4 ? 1 : 0)
        : quality >= 0.50
            ? 1
            : quality >= 0.30
                ? 0
                : -1;
    order
      ..earned = saleValue + tip
      ..tip = tip
      ..reputation = repGain;

    state.money += order.earned;
    state.reputation = max(0, state.reputation + repGain);
    _workingReport.served++;
    _workingReport.revenue += saleValue;
    _workingReport.tips += tip;
    _workingReport.reputation += repGain;
    _workingReport.satisfactionTotal += quality;
    _workingReport.qualitySamples++;
    lastSoldItemId = item.id;
    final satisfaction = (quality * 100).round();
    serviceStatus =
        '${item.name} dibayar • +RM ${order.earned} • puas $satisfaction%${tip > 0 ? ' • tip RM $tip' : ''}';
    notifyListeners();
  }

  void customerLeftBeforeOrder({required String reason}) {
    if (!serviceActive || customersRemaining <= 0) return;
    customersRemaining = max(0, customersRemaining - 1);
    _workingReport.missed++;
    state.reputation = max(0, state.reputation - 1);
    serviceStatus = reason;
    notifyListeners();
  }

  void customerAbandonedOrder(CustomerServiceResult order) {
    cancelOrder(order, countAsMissed: true);
    serviceStatus = order.ingredientsCommitted
        ? 'Pelanggan hilang sabar. Bahan yang sudah diambil menjadi pembaziran.'
        : 'Pelanggan hilang sabar sebelum bahan diambil.';
    state.reputation = max(0, state.reputation - 1);
    notifyListeners();
  }

  void tryFinishService({required bool sceneDrained}) {
    _checkForServiceEnd(sceneDrained: sceneDrained);
  }

  void cancelOrder(
    CustomerServiceResult order, {
    bool countAsMissed = false,
  }) {
    if (order.cancelled || order.completed) return;
    order.cancelled = true;
    final item = order.item;
    if (item != null && !order.ingredientsCommitted) {
      _releaseReservation(item.recipe);
    }
    if (order.served) {
      ordersInProgress = max(0, ordersInProgress - 1);
    }
    if (countAsMissed) {
      customersRemaining = max(0, customersRemaining - 1);
      _workingReport.missed++;
      if (order.ingredientsCommitted && !order.wasted) {
        order.wasted = true;
        _workingReport.wasted++;
      }
    }
    notifyListeners();
  }

  Future<String> buyStock(String id, int amount) async {
    final ingredient = ingredients[id];
    if (ingredient == null) return 'Bahan tidak dikenali.';
    if (amount <= 0) return 'Jumlah belian tidak sah.';
    if (inventoryFree < amount) {
      return 'Stor tidak cukup. Ruang kosong $inventoryFree unit. Naik taraf Stor Bahan.';
    }
    final cost = stockPrice(id, amount);
    if (state.money < cost) {
      return 'Wang tidak mencukupi untuk membeli ${ingredient.name}.';
    }
    state.money -= cost;
    state.inventory[id] = (state.inventory[id] ?? 0) + amount;
    await save();
    notifyListeners();
    return '${ingredient.name} +$amount dibeli dengan harga RM $cost.';
  }

  Future<String> buyBasicBundle() async {
    final bundleSize = basicBundle.values.fold<int>(0, (sum, value) => sum + value);
    if (inventoryFree < bundleSize) {
      return 'Pakej memerlukan $bundleSize ruang stor. Ruang kosong hanya $inventoryFree.';
    }
    var cost = 0;
    for (final entry in basicBundle.entries) {
      cost += stockPrice(entry.key, entry.value);
    }
    cost = (cost * 0.88).round();
    if (state.money < cost) {
      return 'Pakej asas berharga RM $cost. Wang semasa tidak mencukupi.';
    }
    state.money -= cost;
    for (final entry in basicBundle.entries) {
      state.inventory[entry.key] =
          (state.inventory[entry.key] ?? 0) + entry.value;
    }
    await save();
    notifyListeners();
    return 'Pakej stok asas dibeli dengan harga RM $cost.';
  }

  Future<String> toggleMenu(String id) async {
    final item = menuItems[id];
    if (item == null) return 'Menu tidak dikenali.';
    if (warungLevel < item.unlockLevel) {
      return 'Menu ini memerlukan Taraf Kedai Lv.${item.unlockLevel}.';
    }
    state.menuEnabled[id] = !(state.menuEnabled[id] ?? true);
    await save();
    notifyListeners();
    return state.menuEnabled[id]!
        ? '${item.name} diaktifkan.'
        : '${item.name} ditutup sementara.';
  }

  Future<String> buyUpgrade(String id) async {
    final definition = upgrades[id];
    if (definition == null) return 'Naik taraf tidak dikenali.';
    if (serviceActive) return 'Tutup operasi dahulu sebelum menaik taraf.';
    final current = state.upgradeLevels[id] ?? 1;
    if (current >= definition.maxLevel) {
      return '${definition.name} sudah maksimum.';
    }
    final cost = upgradeCost(id);
    if (state.money < cost) {
      return 'Wang tidak mencukupi. Naik taraf ini memerlukan RM $cost.';
    }
    state.money -= cost;
    state.upgradeLevels[id] = current + 1;
    await save();
    notifyListeners();
    return '${definition.name} dinaikkan ke Lv.${current + 1}. ${upgradeBenefitText(id, current + 1)}';
  }

  int stockPrice(String id, int amount) {
    final base = ingredients[id]?.buyPrice ?? 1;
    final discount = 1 - min(0.24, (storageLevel - 1) * 0.06);
    return max(1, (base * amount * discount).ceil());
  }

  int upgradeCost(String id) {
    final definition = upgrades[id]!;
    final level = state.upgradeLevels[id] ?? 1;
    return (definition.baseCost * pow(1.58, level - 1)).round();
  }

  String recipeText(Map<String, int> recipe) {
    return recipe.entries
        .map(
          (entry) =>
              '${ingredients[entry.key]?.name ?? entry.key} x${entry.value}',
        )
        .join(', ');
  }

  String upgradeBenefitText(String id, int level) {
    switch (id) {
      case 'warung':
        final unlocked = menuItems.values.where((item) => item.unlockLevel <= level).length;
        return 'Rupa kedai Tier $level • $unlocked menu terbuka • +${level * 2} permintaan.';
      case 'kitchen':
        return 'Masa memasak ${max(45, 100 - (level - 1) * 13)}% daripada asal.';
      case 'tables':
        return '${min(6, 2 + level - 1)} tempat duduk aktif • pelanggan serentak bertambah.';
      case 'storage':
        return 'Kapasiti ${120 + (level - 1) * 45} unit • diskaun stok ${(level - 1) * 6}%.';
      case 'service':
        return 'Kelajuan pelayan +${(level - 1) * 12}% • ambil pesanan lebih cepat.';
      case 'cleaning':
        return 'Masa membersih -${(level - 1) * 14}% • peluang tip meningkat.';
      case 'popularity':
        return '+${level * 3} pelanggan harian • peluang tip lebih tinggi.';
      case 'profit':
        return 'Nilai jualan +${(level - 1) * 6}% bagi setiap hidangan.';
      default:
        return '';
    }
  }

  String upgradeImagePath(String id, int level) {
    int bounded(int maximum) {
      if (level < 1) return 1;
      if (level > maximum) return maximum;
      return level;
    }

    switch (id) {
      case 'warung':
        return 'assets/images/environment/warung_tier_${bounded(6)}.png';
      case 'kitchen':
        return 'assets/images/environment/stove_tier_${bounded(3)}.png';
      case 'tables':
        if (level >= 4) return 'assets/images/environment/table_umbrella.png';
        if (level >= 2) return 'assets/images/environment/table_square.png';
        return 'assets/images/environment/table_long.png';
      case 'storage':
        return 'assets/images/environment/storage_tier_${bounded(3)}.png';
      case 'service':
        return 'assets/images/environment/counter_tier_${bounded(3)}.png';
      case 'cleaning':
        return 'assets/images/environment/sink_tier_${bounded(3)}.png';
      case 'popularity':
        return level >= 3
            ? 'assets/images/environment/lights_long.png'
            : 'assets/images/environment/sign_warung.png';
      case 'profit':
        return 'assets/images/environment/sign_selera.png';
      default:
        return 'assets/images/environment/sign_warung.png';
    }
  }

  final _workingReport = _MutableReport();

  void _closeOrdersBecauseStockEnded() {
    if (!serviceActive || !acceptingCustomers) return;
    acceptingCustomers = false;
    final customersWithoutOrders = max(0, customersRemaining - ordersInProgress);
    if (customersWithoutOrders > 0) {
      customersRemaining -= customersWithoutOrders;
      _workingReport.missed += customersWithoutOrders;
    }
    serviceStatus = ordersInProgress > 0
        ? 'Stok yang belum ditempah habis. Pesanan sedia ada akan diselesaikan.'
        : 'Stok habis. Operasi hari ini ditutup.';
    notifyListeners();
  }

  void _checkForServiceEnd({required bool sceneDrained}) {
    if (!serviceActive || !sceneDrained || _finishingService) return;
    if (customersRemaining <= 0 && ordersInProgress <= 0) {
      _finishingService = true;
      unawaited(_finishService());
    }
  }

  Future<void> _finishService() async {
    if (!serviceActive) {
      _finishingService = false;
      return;
    }
    serviceActive = false;
    acceptingCustomers = false;
    ordersInProgress = 0;
    _reservedInventory.clear();

    var note = 'Hari operasi selesai dengan baik.';
    final served = _workingReport.served;
    final missed = _workingReport.missed;
    final satisfaction = _workingReport.qualitySamples <= 0
        ? 0
        : ((_workingReport.satisfactionTotal / _workingReport.qualitySamples) * 100)
            .round()
            .clamp(0, 100)
            .toInt();
    final excellentCoverage = served >= (customersTotal * 0.8).floor();
    final lowWaste = _workingReport.wasted <= max(1, served ~/ 10);
    if (excellentCoverage && satisfaction >= 75 && lowWaste) {
      final bonus = 20 + warungLevel * 10 + popularityLevel * 4;
      state.money += bonus;
      _workingReport.revenue += bonus;
      note = 'Bonus servis cemerlang: RM $bonus';
    } else if (_workingReport.wasted > max(2, served ~/ 4)) {
      note = 'Pembaziran tinggi. Tingkatkan dapur atau kurangkan menu aktif.';
    } else if (satisfaction < 55 && served > 0) {
      note = 'Pelanggan menunggu lama. Tingkatkan dapur, servis atau kebersihan.';
    } else if (missed > served) {
      note = 'Tambah stok atau tingkatkan kelajuan sebelum membuka esok.';
    }
    state.lastReport = GameReport(
      day: state.day,
      served: served,
      missed: missed,
      revenue: _workingReport.revenue,
      tips: _workingReport.tips,
      reputation: _workingReport.reputation,
      wasted: _workingReport.wasted,
      satisfaction: satisfaction,
      note: note,
    );
    state.stats
      ..served += served
      ..missed += missed
      ..revenue += _workingReport.revenue
      ..daysPlayed += 1;
    state.day++;
    customersRemaining = 0;
    serviceStatus = note;
    _workingReport.reset();
    await save();
    _finishingService = false;
    notifyListeners();
  }

  void _reserveRecipe(Map<String, int> recipe) {
    for (final entry in recipe.entries) {
      _reservedInventory[entry.key] =
          (_reservedInventory[entry.key] ?? 0) + entry.value;
    }
  }

  void _releaseReservation(Map<String, int> recipe) {
    for (final entry in recipe.entries) {
      _reservedInventory[entry.key] =
          max(0, (_reservedInventory[entry.key] ?? 0) - entry.value);
    }
  }
}

class _MutableReport {
  int served = 0;
  int missed = 0;
  int revenue = 0;
  int tips = 0;
  int reputation = 0;
  int wasted = 0;
  double satisfactionTotal = 0;
  int qualitySamples = 0;

  void reset() {
    served = 0;
    missed = 0;
    revenue = 0;
    tips = 0;
    reputation = 0;
    wasted = 0;
    satisfactionTotal = 0;
    qualitySamples = 0;
  }
}
