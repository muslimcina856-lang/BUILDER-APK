# Audit Aset Warung Kita v0.5.0

## Aset yang digunakan aplikasi

- Pelanggan: **100** fail individu.
- Aksi pekerja dan prop: **23** fail.
- Persekitaran, perabot dan peralatan: **64** fail.
- Makanan, minuman dan bahan: **45** fail.
- Imej menu utama: **9** fail makanan/minuman dan 1 imej menu utama.

## Pembaikan aset runtime

Aset berikut diperiksa dan dibersihkan semula kerana masih membawa bahagian kecil daripada objek bersebelahan pada helaian sumber:

- Kerusi kedua.
- Stesen memasak besar.
- Tiga peti simpanan.
- Pagar kayu.
- Lima kepingan lantai.
- Platform kayu.
- Meja berkaki logam.
- Aksi pelayan menghidang makanan.

Setiap fail di atas kini mempunyai satu komponen visual utama dengan ruang lutsinar di sekeliling. Semua imej menu turut disamakan dengan aset makanan bersih dalam `assets/images/food_new/`.

## Pemeriksaan

- Semua 100 pelanggan wujud dan mempunyai sempadan lutsinar.
- Aset pekerja tidak digunakan sebagai pelanggan.
- Tiada aset runtime lutsinar menyentuh tepi fail, kecuali imej menu utama yang memang menggunakan keseluruhan kanvas.
- Rujukan aset dalam kod disemak terhadap fail sebenar.
- Helaian sumber tidak dimasukkan sebagai aset runtime.
