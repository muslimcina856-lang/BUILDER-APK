# Nota Kemas Kini v0.5.0

- Version name `0.5.0` dan build number `1`.
- 100 aset pelanggan digunakan melalui giliran rawak tanpa pengulangan awal.
- Tukang masak wanita menerima bahan, memotong, memasak, menyediakan hidangan dan membasuh pinggan ketika tiada pesanan menunggu.
- Pelayan lelaki mengambil pesanan, mengambil bahan dari stor, menyerahkan bahan, menghantar hidangan, mengambil bayaran, membersihkan meja dan membawa pinggan ke sinki.
- Pelanggan kini mempunyai profil kesabaran yang berlainan.
- Masa menunggu mempengaruhi kepuasan, tip dan reputasi.
- Pelanggan boleh meninggalkan warung sebelum pesanan atau ketika menunggu makanan.
- Pesanan terbatal selepas bahan diambil direkodkan sebagai pembaziran.
- Hari operasi hanya tamat selepas ruang permainan benar-benar kosong dan bersih.
- Skrin laporan memaparkan kepuasan purata dan jumlah hidangan terbazir.
- Pembelian naik taraf kini meminta pengesahan dengan harga serta perbandingan manfaat semasa dan tahap seterusnya.
- Serpihan aset jiran telah dibuang daripada kerusi, dapur, peti, pagar, lantai, platform, meja logam dan aksi menghidang pelayan.
- Semua imej menu utama menggunakan salinan aset makanan yang telah dibersihkan.
- Konfigurasi Android mengekalkan Gradle 8.14.4, AGP 8.11.1, Kotlin 2.2.20 dan Java 17.
