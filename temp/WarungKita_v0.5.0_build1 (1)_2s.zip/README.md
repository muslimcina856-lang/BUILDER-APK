# Warung Kita

Aplikasi permainan pengurusan warung offline untuk Android.

## Aliran permainan

1. Beli dan urus stok bahan.
2. Aktifkan menu yang hendak dijual.
3. Buka warung dan terima pelanggan.
4. Pelayan lelaki menyambut pelanggan serta mencatat pesanan.
5. Pelayan pergi ke stor, mengambil bahan dan menyerahkannya kepada tukang masak wanita.
6. Tukang masak memotong, memasak dan menyediakan hidangan.
7. Pelayan mengambil hidangan siap lalu menghantarnya ke meja.
8. Pelanggan makan, membayar dan meninggalkan pinggan kotor.
9. Pelayan membersihkan meja serta membawa pinggan ke sinki.
10. Gunakan keuntungan untuk menaik taraf kedai dan peralatan.

## Logik operasi

- Setiap pelanggan mempunyai tahap kesabaran yang berbeza.
- Masa menunggu pesanan, makanan dan bayaran mempengaruhi kepuasan, tip serta reputasi.
- Pelanggan boleh meninggalkan warung jika menunggu terlalu lama.
- Bahan yang sudah diambil untuk pesanan terbatal dikira sebagai pembaziran.
- Meja tidak boleh digunakan semula sebelum pelanggan keluar dan meja selesai dibersihkan.
- Hari hanya tamat selepas semua pelanggan keluar, pesanan selesai, meja bersih dan kedua-dua pekerja kembali lapang.

## Kandungan utama

- 100 variasi pelanggan, digunakan secara rawak tanpa pengulangan sehingga satu pusingan selesai.
- 9 menu dan 13 jenis bahan.
- Aksi berasingan untuk tukang masak wanita dan pelayan lelaki.
- 6 taraf rupa kedai.
- Naik taraf dapur, meja, stor, servis, kebersihan, populariti dan keuntungan.
- Harga serta manfaat tahap seterusnya dipaparkan sebelum pembelian disahkan.
- Simpanan automatik dan kemajuan offline terhad.

## Binaan Android

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Versi aplikasi: `0.5.0+1`
