# Tetapan Bot Binaan

Pilih jenis projek: **Flutter**

Fail pengesan projek berada terus pada akar ZIP:

- `pubspec.yaml`
- `lib/main.dart`
- `android/settings.gradle.kts`

Arahan binaan:

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Versi: `0.5.0+1`
