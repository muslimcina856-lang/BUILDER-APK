import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';

void main() => runApp(BugApp());

class BugApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Color(0xFF7B2FBE),
        colorScheme: ColorScheme.dark(
          primary: Color(0xFF7B2FBE),
          secondary: Colors.white,
          surface: Colors.black.withOpacity(0.6),
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: Colors.white, fontFamily: 'monospace'),
          bodyMedium: TextStyle(color: Colors.white70, fontFamily: 'monospace'),
        ),
      ),
      home: BugHome(),
    );
  }
}

class BugHome extends StatefulWidget {
  @override
  _BugHomeState createState() => _BugHomeState();
}

class _BugHomeState extends State<BugHome> with SingleTickerProviderStateMixin {
  List<Map<String, String>> apps = [];
  String selectedPkg = '';
  String deviceInfo = '';
  bool isRooted = false;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: Duration(seconds: 2))..repeat();
    _checkPermissions();
    _loadDeviceInfo();
    _loadApps();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  _checkPermissions() async {
    await Permission.packageUsage.request();
    await Permission.phone.request();
  }

  _loadDeviceInfo() async {
    try {
      if (Platform.isAndroid) {
        AndroidDeviceInfo info = await DeviceInfoPlugin().androidInfo;
        setState(() {
          deviceInfo = '${info.model} | ${info.version.release}';
          isRooted = info.isPhysicalDevice == false; // dummy, bisa diganti cek su
        });
        // cek root real
        Process.run('sh', ['-c', 'which su']).then((result) {
          setState(() => isRooted = result.stdout.toString().trim().isNotEmpty);
        });
      }
    } catch (e) {
      setState(() => deviceInfo = 'error');
    }
  }

  _loadApps() async {
    try {
      final List<Map<String, String>> list = [];
      if (Platform.isAndroid) {
        final result = await Process.run('sh', ['-c', 'pm list packages']);
        if (result.exitCode == 0) {
          final lines = (result.stdout as String).split('\n');
          for (var line in lines) {
            if (line.startsWith('package:')) {
              final pkg = line.substring(8).trim();
              final labelResult = await Process.run('sh', ['-c', 'dumpsys package $pkg | grep "applicationLabel=" | head -1']);
              String label = pkg;
              if (labelResult.exitCode == 0) {
                final l = (labelResult.stdout as String).trim();
                if (l.isNotEmpty) {
                  final parts = l.split('=');
                  if (parts.length > 1) label = parts[1].trim();
                }
              }
              list.add({'name': label, 'package': pkg});
            }
          }
        }
      }
      setState(() => apps = list);
    } catch (e) {
      setState(() => apps = [{'name': 'Error: $e', 'package': ''}]);
    }
  }

  _exec(String cmd, {bool showToast = true}) async {
    try {
      final result = await Process.run('sh', ['-c', 'su -c "$cmd"']);
      if (showToast) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('✔ ${result.stdout}', style: TextStyle(color: Colors.green)),
          backgroundColor: Colors.black87,
        ));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('✘ $e', style: TextStyle(color: Colors.red)),
        backgroundColor: Colors.black87,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0D0D0D), Color(0xFF1A0A2E), Color(0xFF2D1B4E)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: Color(0xFF7B2FBE), width: 1)),
                  boxShadow: [BoxShadow(color: Color(0xFF7B2FBE).withOpacity(0.3), blurRadius: 20)],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.security, color: Color(0xFF7B2FBE), size: 32),
                        SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('BUGANDROID', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2)),
                            Text('v3.0 • ${isRooted ? "ROOTED" : "UNROOTED"}', style: TextStyle(fontSize: 10, color: isRooted ? Colors.green : Colors.red)),
                          ],
                        ),
                      ],
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Color(0xFF7B2FBE)),
                        color: Colors.black26,
                      ),
                      child: Text(deviceInfo, style: TextStyle(fontSize: 10, color: Colors.white70)),
                    ),
                  ],
                ),
              ),
              // Stats
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(
                  children: [
                    _statChip('TOTAL', apps.length.toString()),
                    SizedBox(width: 16),
                    _statChip('SELECTED', selectedPkg.isEmpty ? 'none' : selectedPkg.split('.').last),
                    Spacer(),
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (ctx, child) => Icon(Icons.wifi_tethering, color: Color(0xFF7B2FBE).withOpacity(0.5 + 0.5 * _pulseController.value)),
                    ),
                  ],
                ),
              ),
              // List apps
              Expanded(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: Colors.black.withOpacity(0.3),
                    border: Border.all(color: Color(0xFF7B2FBE).withOpacity(0.2)),
                  ),
                  child: ListView.builder(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    itemCount: apps.length,
                    itemBuilder: (ctx, i) {
                      final app = apps[i];
                      final isSelected = selectedPkg == app['package'];
                      return AnimatedContainer(
                        duration: Duration(milliseconds: 200),
                        margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: isSelected ? Color(0xFF7B2FBE).withOpacity(0.3) : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          border: isSelected ? Border.all(color: Color(0xFF7B2FBE), width: 1.5) : null,
                        ),
                        child: ListTile(
                          leading: Icon(Icons.android, color: isSelected ? Colors.white : Color(0xFF7B2FBE)),
                          title: Text(app['name']!, style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                          subtitle: Text(app['package']!, style: TextStyle(fontSize: 10, color: Colors.white54)),
                          tileColor: Colors.transparent,
                          onTap: () => setState(() => selectedPkg = app['package']!),
                        ),
                      );
                    },
                  ),
                ),
              ),
              // Action buttons
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: Color(0xFF7B2FBE), width: 1)),
                  color: Colors.black.withOpacity(0.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _actionButton(Icons.close, 'Force', () => _exec('am force-stop $selectedPkg')),
                    _actionButton(Icons.delete_sweep, 'Clear', () => _exec('pm clear $selectedPkg')),
                    _actionButton(Icons.flash_on, 'Crash', () {
                      if (selectedPkg == 'com.target.app') {
                        _exec('am broadcast -a com.target.CRASH --ez crash true');
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('✘ target only com.target.app', style: TextStyle(color: Colors.orange)),
                          backgroundColor: Colors.black87,
                        ));
                      }
                    }),
                    _actionButton(Icons.power_settings_new, 'Reboot', () => _exec('reboot')),
                  ],
                ),
              ),
              SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statChip(String label, String value) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.black26,
        border: Border.all(color: Color(0xFF7B2FBE).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Text(label, style: TextStyle(fontSize: 8, color: Colors.white60)),
          SizedBox(width: 4),
          Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _actionButton(IconData icon, String label, VoidCallback onPressed) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF7B2FBE), Color(0xFF4A0E78)]),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Color(0xFF7B2FBE).withOpacity(0.4), blurRadius: 12)],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 18),
            SizedBox(width: 6),
            Text(label, style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}