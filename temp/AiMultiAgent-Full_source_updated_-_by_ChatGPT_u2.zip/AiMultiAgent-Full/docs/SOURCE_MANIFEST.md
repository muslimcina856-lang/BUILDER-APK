# Manifest Sumber Ai MultiAgent Full 1.0.0+1

## Edisi dalam arkib ini

| Edisi | Package | Launcher | Compile/Target | Entry point |
|---|---|---|---|---|
| Full | `com.aiauto.claw.full` | Ai MultiAgent Full | 36 / 28 | `lib/main.dart` |

Minimum SDK 24, Java 17 dan Flutter/Kotlin Android. Edisi Standard diselenggara dalam arkib sumber berasingan dan tidak diperlukan untuk membina projek Full ini.

## Komponen utama

- Provider BYOK dan Custom Provider.
- Orchestrator model utama, sub-agent dinamik dan tool calling.
- SQLite lokal, secure API-key vault dan approval berasaskan risiko.
- Browser Chromium tersembunyi dengan konteks runtime yang diberi kepada AI.
- Linux Workspace Full dalam direktori sokongan internal private aplikasi.
- Alpine Linux 3.24.1 aarch64 + PRoot 0.15 dibina sebagai Flutter asset sebelum APK/AAB.
- Auto-install runtime, health check, pemasangan transaksi crash-safe, rollback, terminal start/poll/stop, rolling output buffer dan dashboard proses.
- PC Windows local berasaskan Ubuntu ARM64 + Wine WoW64 + Box64 dengan muat turun boleh resume, cache sah, sambung pemasangan dan desktop headless.
- UI chat tanpa kad pembantu, dengan status Berfikir berada sebelum kandungan jawapan.
- Ikon premium Full tanpa teks.
- Skrip debug/release dan workflow CI ARM64.

## Fail penting

- `mobile/lib/main.dart`
- `mobile/lib/src/config/app_config.dart`
- `mobile/lib/src/services/linux_workspace_service.dart`
- `mobile/lib/src/services/terminal_service.dart`
- `mobile/lib/src/services/tool_engine.dart`
- `mobile/lib/src/services/agent_runtime.dart`
- `mobile/lib/src/services/windows_runtime_service.dart`
- `mobile/lib/src/services/windows_process_service.dart`
- `mobile/lib/src/ui/screens/chat_screen.dart`
- `mobile/lib/src/ui/screens/linux_workspace_screen.dart`
- `mobile/android/app/build.gradle.kts`
- `mobile/android/app/src/main/AndroidManifest.xml`
- `scripts/linux/prepare_bundled_runtime.py`
- `scripts/linux/create_runtime_pack.py`
- `scripts/test_linux_runtime_builder.py`
- `scripts/build_debug.sh`
- `scripts/build_full.sh`
- `docs/LINUX_COMPLETION_AUDIT_2026-08-04.md`
- `docs/previews/01-chat-answer.png`
- `docs/previews/02-chat-thinking.png`
- `docs/previews/03-windows-installing.png`
- `docs/previews/04-windows-recovery.png`
- `.github/workflows/android-release-check.yml`
- `assets/branding/icon_full_master.png`

## Asset yang dijana ketika build

Fail berikut sengaja tidak disimpan dalam source ZIP dan dijana oleh skrip build daripada sumber yang dipinkan:

- `mobile/assets/linux/full/runtime-pack.zip`
- `mobile/assets/linux/full/runtime-manifest.json`
- `mobile/assets/linux/full/runtime-pack.sha256`
- `mobile/assets/linux/full/runtime-build-info.json`

Build debug atau release akan gagal jika runtime tidak sah atau tidak terkandung dalam artifact Android. Source ZIP kekal reproducible dan tidak menyamar sebagai runtime siap-jana; binary sebenar hanya diterima selepas semakan sumber, struktur, checksum/ELF dan kontrak ZIP lulus.
