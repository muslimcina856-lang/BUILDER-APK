import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../config/app_config.dart';
import '../../services/linux_workspace_service.dart';
import '../../services/terminal_service.dart';
import '../../services/windows_process_service.dart';
import '../../services/windows_runtime_service.dart';
import '../../theme/app_theme.dart';

class LinuxWorkspaceScreen extends StatefulWidget {
  const LinuxWorkspaceScreen({super.key});

  @override
  State<LinuxWorkspaceScreen> createState() => _LinuxWorkspaceScreenState();
}

class _LinuxWorkspaceScreenState extends State<LinuxWorkspaceScreen> {
  final LinuxWorkspaceService _service = LinuxWorkspaceService();
  final TerminalService _terminal = TerminalService();
  final WindowsRuntimeService _windowsService = WindowsRuntimeService();
  final WindowsProcessService _windowsProcess = WindowsProcessService();
  final TextEditingController _commandController = TextEditingController();
  final ScrollController _consoleScroll = ScrollController();

  late Future<LinuxWorkspaceStatus> _status;
  late Future<WindowsRuntimeStatus> _windowsStatus;
  Timer? _pollTimer;
  String? _activeJobId;
  String _console = '';
  bool _attemptedBundledRuntime = false;
  bool _attemptedWindowsRuntime = false;
  String? _runtimeError;
  String? _windowsRuntimeError;

  @override
  void initState() {
    super.initState();
    _status = _loadStatus();
    _windowsStatus = _loadWindowsStatus();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _commandController.dispose();
    _consoleScroll.dispose();
    super.dispose();
  }

  Future<LinuxWorkspaceStatus> _loadStatus() async {
    if (!_attemptedBundledRuntime) {
      _attemptedBundledRuntime = true;
      try {
        await _service.ensureBundledRuntimeReady();
        _runtimeError = null;
      } catch (error) {
        _runtimeError = error.toString();
      }
    }
    return _service.status();
  }

  Future<WindowsRuntimeStatus> _loadWindowsStatus() async {
    if (!_attemptedWindowsRuntime) {
      _attemptedWindowsRuntime = true;
      try {
        await _windowsService.ensureReady();
        _windowsRuntimeError = null;
      } catch (error) {
        _windowsRuntimeError = error.toString();
      }
    }
    return _windowsService.status();
  }

  void _refresh() {
    if (!mounted) return;
    setState(() {
      _status = _loadStatus();
      _windowsStatus = _loadWindowsStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!AppConfig.isFullEdition) {
      return const Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'Workspace penuh hanya tersedia dalam Ai MultiAgent Full.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Workspace'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Segarkan',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: FutureBuilder<LinuxWorkspaceStatus>(
        future: _status,
        builder: (context, snapshot) {
          final status = snapshot.data;
          if (status == null) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 120),
            children: <Widget>[
              _HeroCard(status: status),
              const SizedBox(height: 14),
              ValueListenableBuilder<WindowsInstallProgress?>(
                valueListenable: _windowsService.installProgress,
                builder: (context, progress, _) =>
                    FutureBuilder<WindowsRuntimeStatus>(
                  future: _windowsStatus,
                  builder: (context, windowsSnapshot) => _WindowsPcCard(
                    status: windowsSnapshot.data,
                    installing: windowsSnapshot.connectionState ==
                            ConnectionState.waiting ||
                        progress != null,
                    progress: progress,
                    error: _windowsRuntimeError,
                    onRetry: _retryWindowsRuntime,
                    onReset: _confirmWindowsReset,
                  ),
                ),
              ),
              if (_runtimeError != null) ...<Widget>[
                const SizedBox(height: 10),
                _InfoCard(
                  icon: Icons.error_outline_rounded,
                  title: 'Runtime bawaan belum dapat disahkan',
                  body: _runtimeError!,
                ),
              ],
              const SizedBox(height: 14),
              _ActionGrid(
                ready: status.ready,
                onInstall: _installBundledRuntime,
                onImport: _installRuntimePack,
                onReset: _confirmReset,
                onQuickCommand: (command) {
                  _commandController.text = command;
                  _runCommand(status);
                },
              ),
              const SizedBox(height: 14),
              _TerminalCard(
                ready: status.ready,
                controller: _commandController,
                output: _console,
                running: _activeJobId != null,
                scrollController: _consoleScroll,
                onRun: () => _runCommand(status),
                onStop: _stopActiveJob,
              ),
              const SizedBox(height: 14),
              _JobsCard(jobs: _terminal.jobs.toList().reversed.take(8).toList()),
              const SizedBox(height: 14),
              const _InfoCard(
                icon: Icons.window_rounded,
                title: 'PC Windows untuk AI',
                body:
                    'AI boleh menjalankan cmd.exe dan fail .exe daripada /workspace, lampiran chat atau aplikasi yang sudah dipasang dalam drive C: Wine. Aplikasi GUI dirender dalam desktop headless 1280×720; AI boleh ambil screenshot, fokus tetingkap, klik, menaip dan menghantar kekunci. Ini lapisan keserasian Wine + Box64, bukan VM Windows penuh.',
              ),
              const SizedBox(height: 10),
              const _InfoCard(
                icon: Icons.lock_rounded,
                title: 'Storan internal aplikasi sahaja',
                body:
                    'Rootfs Alpine, pakej apk, projek, cache browser dan screenshot berada dalam direktori private com.aiauto.claw.full. Tiada akses pukal ke /sdcard, Downloads atau Pictures.',
              ),
              const SizedBox(height: 10),
              const _InfoCard(
                icon: Icons.admin_panel_settings_rounded,
                title: 'Root Linux, bukan root Android',
                body:
                    'UID root diemulasikan oleh PRoot dalam rootfs sendiri. Android, data aplikasi lain dan storan luaran kekal di luar kawalan Workspace.',
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _retryWindowsRuntime() async {
    if (!mounted) return;
    setState(() {
      _attemptedWindowsRuntime = false;
      _windowsRuntimeError = null;
      _windowsStatus = _loadWindowsStatus();
    });
  }

  Future<void> _confirmWindowsReset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reset PC Windows?'),
        content: const Text(
          'Runtime Ubuntu, Wine, Box64 dan prefix Windows akan dipadam. Projek /workspace dan Shell Alpine tidak dipadam. PC Windows akan dimuat turun semula apabila dipasang.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await _windowsProcess.stopAll();
    await _windowsService.reset();
    if (!mounted) return;
    setState(() {
      _attemptedWindowsRuntime = false;
      _windowsRuntimeError = null;
      _windowsStatus = _loadWindowsStatus();
    });
  }

  Future<void> _runCommand(LinuxWorkspaceStatus status) async {
    if (!status.ready || _activeJobId != null) return;
    final command = _commandController.text.trim();
    if (command.isEmpty) return;
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() => _console = r'$ ' + command + '\n');
    final result = await _terminal.start(command: command);
    if (!mounted) return;
    if (!result.success) {
      setState(() => _console += '${result.output}\n');
      return;
    }
    final id = result.data['job_id']?.toString();
    if (id == null || id.isEmpty) {
      setState(() => _console += '${result.output}\n');
      return;
    }
    setState(() => _activeJobId = id);
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(
      const Duration(milliseconds: 650),
      (_) => _pollActiveJob(),
    );
    await _pollActiveJob();
  }

  Future<void> _pollActiveJob() async {
    final id = _activeJobId;
    if (id == null) return;
    final result = await _terminal.poll(id);
    if (!mounted) return;
    final data = result.data;
    final stdout = data['stdout']?.toString() ?? '';
    final stderr = data['stderr']?.toString() ?? '';
    final running = data['running'] == true;
    final exitCode = data['exit_code'];
    setState(() {
      _console = [
        r'$ ' + (_commandController.text.trim()),
        if (stdout.isNotEmpty) stdout.trimRight(),
        if (stderr.isNotEmpty) stderr.trimRight(),
        if (!running) '[exit ${exitCode ?? '?'}]',
      ].join('\n');
      if (!running) _activeJobId = null;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_consoleScroll.hasClients) {
        _consoleScroll.animateTo(
          _consoleScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
        );
      }
    });
    if (!running) {
      _pollTimer?.cancel();
      _pollTimer = null;
      _refresh();
    }
  }

  Future<void> _stopActiveJob() async {
    final id = _activeJobId;
    if (id == null) return;
    await _terminal.stop(id);
    await _pollActiveJob();
  }

  Future<void> _installBundledRuntime() async {
    try {
      await _stopTerminalJobsForRuntimeChange();
      await _service.ensureBundledRuntimeReady();
      if (!mounted) return;
      setState(() => _runtimeError = null);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Alpine Linux ARM64 bawaan sudah dipasang dan disahkan.'),
        ),
      );
      _refresh();
    } catch (error) {
      if (!mounted) return;
      setState(() => _runtimeError = error.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Runtime bawaan gagal dipasang: $error')),
      );
    }
  }

  Future<void> _installRuntimePack() async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const <String>['zip'],
      allowMultiple: false,
      withData: false,
    );
    final path = picked?.files.single.path;
    if (path == null || !mounted) return;
    try {
      await _stopTerminalJobsForRuntimeChange();
      await _service.installRuntimePack(path);
      if (!mounted) return;
      setState(() => _runtimeError = null);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Runtime Linux berjaya dipasang.')),
      );
      _refresh();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pemasangan gagal: $error')),
      );
    }
  }

  Future<void> _stopTerminalJobsForRuntimeChange() async {
    _pollTimer?.cancel();
    _pollTimer = null;
    await _terminal.stopAll();
    if (!mounted) return;
    setState(() => _activeJobId = null);
  }

  Future<void> _confirmReset() async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Padam Linux Workspace?'),
        content: const Text(
          'Semua rootfs, pakej, projek dan cache dalam Workspace akan dipadam. Storan lain pada telefon tidak disentuh.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    try {
      await _stopTerminalJobsForRuntimeChange();
      await _service.reset();
      if (!mounted) return;
      setState(() {
        _console = '';
        _activeJobId = null;
        _runtimeError = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Linux Workspace dipadam dan runtime bawaan dipasang semula.'),
        ),
      );
      _refresh();
    } catch (error) {
      if (!mounted) return;
      setState(() => _runtimeError = error.toString());
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Reset Linux Workspace gagal: $error')),
      );
    }
  }
}

class _WindowsPcCard extends StatelessWidget {
  const _WindowsPcCard({
    required this.status,
    required this.installing,
    required this.error,
    required this.onRetry,
    required this.onReset,
    this.progress,
  });

  final WindowsRuntimeStatus? status;
  final bool installing;
  final WindowsInstallProgress? progress;
  final String? error;
  final VoidCallback onRetry;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    final ready = status?.ready == true;
    final subtitle = ready
        ? 'Windows-compatible siap · AI boleh guna CMD dan .exe'
        : installing
            ? (progress?.stage ??
                'Memuat turun & menyediakan runtime Windows kali pertama…')
            : error != null
                ? 'Pemasangan belum lengkap · boleh disambung tanpa mula semula'
                : 'Runtime Windows akan dimuat turun pada penggunaan pertama';
    final detail = progress?.detail ?? '';
    final bytes = progress?.bytesLabel ?? '';
    final value = progress?.progress;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(
          color: ready ? const Color(0x665CC8FF) : AppTheme.outlineSoft,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: const Color(0x1F5CC8FF),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0x445CC8FF)),
                ),
                child: const Icon(
                  Icons.window_rounded,
                  color: Color(0xFF8ED8FF),
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'PC Windows',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
              if (installing && value != null)
                Text(
                  progress!.percentLabel,
                  style: const TextStyle(
                    color: Color(0xFF8ED8FF),
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                )
              else if (installing)
                const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.4,
                    color: Color(0xFF8ED8FF),
                  ),
                )
              else
                _StatusDot(ready: ready),
            ],
          ),
          if (installing) ...<Widget>[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: value,
                minHeight: 8,
                backgroundColor: const Color(0xFF1A2436),
                color: const Color(0xFF5CC8FF),
              ),
            ),
            if (detail.isNotEmpty || bytes.isNotEmpty) ...<Widget>[
              const SizedBox(height: 8),
              if (bytes.isNotEmpty)
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    bytes,
                    style: const TextStyle(
                      color: Color(0xFF8ED8FF),
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              if (detail.isNotEmpty) ...<Widget>[
                const SizedBox(height: 4),
                Text(
                  detail,
                  maxLines: 8,
                  overflow: TextOverflow.fade,
                  softWrap: true,
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 11.5,
                    height: 1.35,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ],
          ],
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              const _Chip(label: 'Ubuntu 24.04.4 ARM64'),
              const _Chip(label: 'Wine WoW64'),
              const _Chip(label: 'Box64'),
              const _Chip(label: '1280×720'),
              if (status != null)
                _Chip(label: _HeroCard._formatBytes(status!.usedBytes)),
            ],
          ),
          if (error != null && !installing) ...<Widget>[
            const SizedBox(height: 12),
            Text(
              error!,
              maxLines: 10,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppTheme.error, fontSize: 12),
            ),
            const SizedBox(height: 7),
            const Text(
              'Tekan Sambung pemasangan untuk menggunakan semula muat turun dan rootfs yang sudah siap. Guna Reset hanya jika ralat yang sama masih berulang.',
              style: TextStyle(
                color: AppTheme.textMuted,
                fontSize: 11.5,
                height: 1.35,
              ),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: installing ? null : onRetry,
                  icon: Icon(
                    ready
                        ? Icons.verified_rounded
                        : installing
                            ? Icons.hourglass_top_rounded
                            : Icons.download_rounded,
                  ),
                  label: Text(
                    ready
                        ? 'Sahkan'
                        : installing
                            ? 'Sedang memasang…'
                            : error != null
                                ? 'Sambung pemasangan'
                                : 'Pasang PC Windows',
                  ),
                ),
              ),
              const SizedBox(width: 10),
              IconButton.filledTonal(
                tooltip: 'Reset PC Windows',
                onPressed: installing ? null : onReset,
                icon: const Icon(Icons.restart_alt_rounded),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'PC ini khusus untuk menjalankan aplikasi Windows yang serasi. Ia bukan kernel atau VM Windows penuh. Kali pertama boleh ambil 5–15 minit bergantung pada rangkaian.',
            style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.status});

  final LinuxWorkspaceStatus status;

  @override
  Widget build(BuildContext context) {
    final readyText = status.ready
        ? '${status.distribution} ${status.distributionVersion} ${status.architecture} bersedia · PRoot disahkan'
        : 'Runtime Alpine ARM64 akan dipasang automatik';
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFF30105C), Color(0xFF111A2C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x665E2DE1)),
        boxShadow: const <BoxShadow>[
          BoxShadow(color: Color(0x442E0B65), blurRadius: 30, offset: Offset(0, 12)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .18),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0x665E2DE1)),
                ),
                child: const Icon(
                  Icons.terminal_rounded,
                  color: AppTheme.purpleLight,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Shell',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      readyText,
                      style: const TextStyle(color: AppTheme.textSecondary),
                    ),
                  ],
                ),
              ),
              _StatusDot(ready: status.ready),
            ],
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _Chip(label: _formatBytes(status.usedBytes)),
              _Chip(label: status.packageManager.isEmpty ? 'apk' : status.packageManager),
              _Chip(label: status.healthStatus),
              const _Chip(label: 'private storage'),
              const _Chip(label: 'background jobs'),
            ],
          ),
        ],
      ),
    );
  }

  static String _formatBytes(int bytes) {
    const units = <String>['B', 'KB', 'MB', 'GB'];
    var value = bytes.toDouble();
    var unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024;
      unit++;
    }
    return '${value.toStringAsFixed(unit == 0 ? 0 : 1)} ${units[unit]}';
  }
}

class _ActionGrid extends StatelessWidget {
  const _ActionGrid({
    required this.ready,
    required this.onInstall,
    required this.onImport,
    required this.onReset,
    required this.onQuickCommand,
  });

  final bool ready;
  final VoidCallback onInstall;
  final VoidCallback onImport;
  final VoidCallback onReset;
  final ValueChanged<String> onQuickCommand;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 9,
      runSpacing: 9,
      children: <Widget>[
        _ActionButton(
          icon: Icons.system_update_alt_rounded,
          label: ready ? 'Sahkan runtime' : 'Pasang automatik',
          onTap: onInstall,
        ),
        _ActionButton(
          icon: Icons.folder_zip_outlined,
          label: 'Import pemulihan',
          onTap: onImport,
        ),
        _ActionButton(
          icon: Icons.monitor_heart_outlined,
          label: 'Status sistem',
          onTap: ready ? () => onQuickCommand('uname -a; echo; df -h; echo; free -h 2>/dev/null || true') : null,
        ),
        _ActionButton(
          icon: Icons.inventory_2_outlined,
          label: 'Kemas kini apk',
          onTap: ready ? () => onQuickCommand('apk update') : null,
        ),
        _ActionButton(
          icon: Icons.delete_sweep_rounded,
          label: 'Reset',
          onTap: onReset,
          destructive: true,
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: (MediaQuery.sizeOf(context).width - 41) / 2,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppTheme.outlineSoft),
          ),
          child: Row(
            children: <Widget>[
              Icon(
                icon,
                size: 20,
                color: destructive ? AppTheme.error : AppTheme.purpleLight,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: onTap == null ? AppTheme.textMuted : AppTheme.textPrimary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TerminalCard extends StatelessWidget {
  const _TerminalCard({
    required this.ready,
    required this.controller,
    required this.output,
    required this.running,
    required this.scrollController,
    required this.onRun,
    required this.onStop,
  });

  final bool ready;
  final TextEditingController controller;
  final String output;
  final bool running;
  final ScrollController scrollController;
  final VoidCallback onRun;
  final VoidCallback onStop;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF090D15),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 13, 12, 12),
            child: Row(
              children: <Widget>[
                const Icon(Icons.terminal_rounded, color: AppTheme.purpleLight),
                const SizedBox(width: 9),
                const Expanded(
                  child: Text('Terminal root@local', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
                if (running)
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
          ),
          Container(
            constraints: const BoxConstraints(minHeight: 150, maxHeight: 300),
            width: double.infinity,
            color: const Color(0xFF05070C),
            child: SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(16),
              child: SelectableText(
                output.isEmpty
                    ? (ready ? 'Terminal bersedia.' : 'Runtime Linux belum dipasang.')
                    : output,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 12.5,
                  height: 1.5,
                  color: Color(0xFFD9D7E8),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: controller,
                    enabled: ready && !running,
                    minLines: 1,
                    maxLines: 3,
                    textInputAction: TextInputAction.newline,
                    decoration: const InputDecoration(
                      hintText: 'Masukkan arahan Linux…',
                      prefixText: r'$  ',
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                IconButton.filled(
                  tooltip: running ? 'Hentikan' : 'Jalankan',
                  onPressed: !ready ? null : (running ? onStop : onRun),
                  icon: Icon(running ? Icons.stop_rounded : Icons.arrow_upward_rounded),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _JobsCard extends StatelessWidget {
  const _JobsCard({required this.jobs});

  final List<TerminalJob> jobs;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Row(
              children: <Widget>[
                Icon(Icons.account_tree_outlined, color: AppTheme.purpleLight),
                SizedBox(width: 9),
                Text('Proses AI & terminal', style: TextStyle(fontWeight: FontWeight.w800)),
              ],
            ),
            const SizedBox(height: 12),
            if (jobs.isEmpty)
              const Text(
                'Belum ada proses. Agent dan terminal akan dipaparkan di sini.',
                style: TextStyle(color: AppTheme.textSecondary),
              )
            else
              ...jobs.map(
                (job) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(
                        job.running ? Icons.circle : Icons.check_circle_rounded,
                        size: 14,
                        color: job.running ? AppTheme.warning : AppTheme.success,
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              job.command,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              job.running ? 'Sedang berjalan' : 'Exit ${job.exitCode ?? '?'}',
                              style: const TextStyle(color: AppTheme.textMuted, fontSize: 11.5),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.ready});

  final bool ready;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        color: ready ? AppTheme.success : AppTheme.warning,
        shape: BoxShape.circle,
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: (ready ? AppTheme.success : AppTheme.warning).withValues(alpha: .45),
            blurRadius: 10,
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .055),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppTheme.outlineSoft),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon, color: AppTheme.purpleLight),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  Text(body, style: const TextStyle(color: AppTheme.textSecondary, height: 1.45)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
