#!/usr/bin/env python3
"""Semakan statik lapisan PC Windows apabila Flutter SDK tidak tersedia."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


def read(relative: str) -> str:
    path = ROOT / relative
    require(path.exists(), f"Fail tiada: {relative}")
    return path.read_text(encoding="utf-8") if path.exists() else ""


runtime = read("mobile/lib/src/services/windows_runtime_service.dart")
process = read("mobile/lib/src/services/windows_process_service.dart")
tools = read("mobile/lib/src/services/tool_engine.dart")
agent = read("mobile/lib/src/services/agent_runtime.dart")
workspace = read("mobile/lib/src/ui/screens/linux_workspace_screen.dart")
state = read("mobile/lib/src/state/app_state.dart")
config = read("mobile/lib/src/config/app_config.dart")
guide = read("mobile/lib/src/data/usage_guide.dart")

require("windowsCompatibilityEnabled => isFullEdition" in config,
        "Lapisan Windows mesti dihadkan kepada edisi Full")
require("expectedDistributionVersion = '24.04.4'" in runtime,
        "Versi Ubuntu Base Windows belum dipinkan")
require("expectedWineVersion = '11.11'" in runtime,
        "Versi Wine belum dipinkan")
for label, pattern in (
    ("Ubuntu Base", r"_ubuntuBaseSha256\s*=\s*'([0-9a-f]{64})'"),
    ("Wine", r"_wineSha256\s*=\s*'([0-9a-f]{64})'"),
):
    require(re.search(pattern, runtime) is not None,
            f"SHA-256 {label} tiada atau tidak sah")

require("pi-apps-coders.github.io/box64-debs/KEY.gpg" in runtime and
        "Signed-By: /usr/share/keyrings/box64-archive-keyring.gpg" in runtime and
        "box64-generic-arm" in runtime,
        "Pemasangan Box64 bertandatangan belum lengkap")
require("expectedBox64Version = '0.4.4'" in runtime and
        "2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a" in runtime and
        "-DBAD_SIGNAL=ON" in runtime and
        "box64-proot-build" in runtime,
        "Fallback Box64 Android/PRoot belum dipin atau BAD_SIGNAL belum aktif")
require("wine-11.11-staging-tkg-amd64-wow64.tar.xz" in runtime and
        "sha256sum -c -" in runtime,
        "Muat turun/semakan Wine WoW64 belum lengkap")
require("Ubuntu Base" in runtime and "sha256sum -c -" in runtime,
        "Muat turun/semakan Ubuntu Base belum lengkap")
require("_downloadFile(" in runtime and
        "BUSYBOX=/bin/busybox" in runtime and
        "apk add --no-cache ca-certificates curl tar gzip" not in runtime,
        "Bootstrap Ubuntu masih bergantung pada apk/trigger BusyBox")
require("_rootfsMatchesExpectedVersion" in runtime and
        "Sambung pemasangan" in runtime,
        "Pemasangan PC Windows belum menyambung rootfs Ubuntu yang sah")
require("/opt/ai-cache/wine-11.11-staging-tkg-amd64-wow64.tar.xz" in runtime and
        "Guna semula cache" in runtime and
        "Muat turun boleh disambung semula" in runtime,
        "Muat turun Wine belum boleh resume/guna cache dengan selamat")
require("box64-generic-arm_0.3.4_arm64.deb" not in runtime and
        "binaan PRoot rasmi akan digunakan" in runtime,
        "Fallback Box64 0.3.4 lama masih digunakan")
require("xvfb openbox scrot xdotool" in runtime and
        'command -v openbox >/dev/null || fail' in runtime,
        "Kebergantungan desktop headless belum diwajibkan/disahkan")
require("for i in 1 2 3; do" in runtime and
        "pakej binaan Box64 gagal dipasang" in runtime and
        "for i in 1 2 3 4; do" in runtime,
        "Retry apt/git untuk fallback Box64 belum lengkap")
require("'PROOT_NO_SECCOMP': '1'" not in runtime,
        "Windows masih memaksa PROOT_NO_SECCOMP pada semua peranti")
require("/workspace" in runtime and "/attachments" in runtime and
        "drive C: Wine" in runtime and "home', '.wine', 'drive_c" in runtime,
        "Sempadan laluan EXE belum dikunci kepada workspace/lampiran/drive C")
require("Xvfb" in runtime and "openbox --sm-disable" in runtime and
        "desktopWidth = 1280" in runtime and "desktopHeight = 720" in runtime,
        "Desktop Windows headless belum lengkap")

for tool_id in (
    "windows_runtime_status", "windows_install", "windows_run_cmd",
    "windows_run_exe", "windows_poll", "windows_stop", "windows_screenshot",
    "windows_list_windows", "windows_ui_action",
):
    require(f"id: '{tool_id}'" in tools and f"'{tool_id}' =>" in tools,
            f"Tool Windows tidak lengkap: {tool_id}")

require("xdotool mousemove" in process and "xdotool type" in process and
        "xdotool key" in process and "xdotool windowactivate" in process and
        "xdotool search --onlyvisible" in process,
        "Kawalan GUI Windows klik/taip/key/fokus/senarai belum lengkap")
require("scrot -q 100" in process,
        "Screenshot desktop Windows belum lengkap")
require("_maxConcurrentJobs = 1" in process and "stopAll()" in process,
        "Had proses/stop Windows belum lengkap")

require("await _windowsService.ensureReady();" in workspace and
        "Memuat turun & menyediakan runtime Windows kali pertama" in workspace and
        "title: 'PC Windows untuk AI'" in workspace,
        "Auto-install atau UI PC Windows pada Workspace belum lengkap")
require("Sambung pemasangan" in workspace and
        "Guna Reset hanya jika ralat yang sama masih berulang" in workspace,
        "UI pemulihan pemasangan PC Windows belum jelas")
require("windows_screenshot" in agent and "windows_ui_action" in agent and
        "Wine WoW64 + Box64" in agent,
        "Agent belum diajar penggunaan PC Windows local")
require("windowsProcessService.stopAll()" in state and
        "WindowsRuntimeService().reset()" in state,
        "Lifecycle/reset Windows belum disambungkan kepada AppState")
require("fokus tetingkap, klik, menaip" in workspace and
        "klik koordinat, menaip teks" in guide,
        "Panduan kawalan GUI Windows belum dikemas kini")

if ERRORS:
    print("SEMAKAN WINDOWS GAGAL")
    for item in ERRORS:
        print(f"- {item}")
    sys.exit(1)

print("SEMAKAN WINDOWS LULUS")
print("- Ubuntu Base/Wine dipinkan dan disahkan SHA-256")
print("- Box64 menggunakan repository bertandatangan + fallback PRoot dipin")
print("- CMD/EXE/job/screenshot/kawalan GUI AI disambungkan")
print("- Auto-install kali pertama, lifecycle dan reset disahkan secara statik")
