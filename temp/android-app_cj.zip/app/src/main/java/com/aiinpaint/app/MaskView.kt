package com.aiinpaint.app

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class MaskView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 60f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }

    private val path = Path()
    private var maskBitmap: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var imageBitmap: Bitmap? = null

    fun setImage(bitmap: Bitmap) {
        imageBitmap = bitmap
        maskBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        maskCanvas = Canvas(maskBitmap!!)
        maskCanvas?.drawColor(Color.BLACK)
        invalidate()
    }

    fun getMaskBitmap(): Bitmap? = maskBitmap

    fun clearMask() {
        maskCanvas?.drawColor(Color.BLACK)
        path.reset()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        imageBitmap?.let {
            val matrix = Matrix()
            val scale = minOf(width.toFloat() / it.width, height.toFloat() / it.height)
            matrix.setScale(scale, scale)
            val dx = (width - it.width * scale) / 2f
            val dy = (height - it.height * scale) / 2f
            matrix.postTranslate(dx, dy)
            canvas.drawBitmap(it, matrix, null)
        }
        maskBitmap?.let {
            val matrix = Matrix()
            val scale = minOf(width.toFloat() / it.width, height.toFloat() / it.height)
            matrix.setScale(scale, scale)
            val dx = (width - it.width * scale) / 2f
            val dy = (height - it.height * scale) / 2f
            matrix.postTranslate(dx, dy)
            val alphaPaint = Paint().apply { alpha = 120 }
            canvas.drawBitmap(it, matrix, alphaPaint)
        }
    }

    private fun viewToImage(x: Float, y: Float): PointF? {
        val bmp = imageBitmap ?: return null
        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val dx = (width - bmp.width * scale) / 2f
        val dy = (height - bmp.height * scale) / 2f
        val ix = (x - dx) / scale
        val iy = (y - dy) / scale
        return PointF(ix, iy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val point = viewToImage(event.x, event.y) ?: return false
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                path.moveTo(point.x, point.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(point.x, point.y)
                maskCanvas?.drawPath(path, paint)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                path.reset()
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
