package com.aiinpaint.app

/**
 * ===== CONFIG YANG PERLU DIISI =====
 * Hanya dua nilai ni sahaja yang wajib.
 */
object AppConfig {
    const val GITHUB_TOKEN = "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"
    const val GITHUB_REPO = "earltiktokofficial04-jpg/AI-REMOVAL"   // contoh: ali/ai-inpaint
}
