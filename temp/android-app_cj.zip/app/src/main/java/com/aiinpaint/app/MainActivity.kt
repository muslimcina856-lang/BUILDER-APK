package com.aiinpaint.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aiinpaint.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var currentBitmap: Bitmap? = null
    private var isProcessing = false

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { loadImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSelect.setOnClickListener {
            if (!isProcessing) pickImage.launch("image/*")
        }

        binding.btnClearMask.setOnClickListener {
            binding.maskView.clearMask()
        }

        binding.btnProcess.setOnClickListener {
            if (!isProcessing) startProcess()
        }
    }

    private fun loadImage(uri: Uri) {
        try {
            val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.isMutableRequired = true
                }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }

            // Resize if too large to avoid OOM later
            val maxSide = 1024
            val scaled = if (bitmap.width > maxSide || bitmap.height > maxSide) {
                val scale = maxSide.toFloat() / maxOf(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
            } else bitmap

            currentBitmap = scaled
            binding.maskView.setImage(scaled)
            binding.tvStatus.text = "Gambar dimuatkan. Lukis mask (putih = buang)"
            binding.btnProcess.isEnabled = true
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal muat gambar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startProcess() {
        val bmp = currentBitmap
        val mask = binding.maskView.getMaskBitmap()

        if (bmp == null || mask == null) {
            Toast.makeText(this, "Sila pilih gambar dan lukis mask dulu", Toast.LENGTH_SHORT).show()
            return
        }

        if (AppConfig.GITHUB_TOKEN.contains("xxxx") || AppConfig.GITHUB_REPO.contains("username")) {
            Toast.makeText(this, "Sila isi GITHUB_TOKEN dan GITHUB_REPO dalam AppConfig.kt", Toast.LENGTH_LONG).show()
            return
        }

        isProcessing = true
        binding.btnProcess.isEnabled = false
        binding.btnSelect.isEnabled = false
        binding.progress.visibility = View.VISIBLE
        binding.tvStatus.text = "Memulakan proses..."

        lifecycleScope.launch {
            try {
                val resultFile = withContext(Dispatchers.IO) {
                    processFull(bmp, mask)
                }

                if (resultFile != null && resultFile.exists()) {
                    val resultBmp = BitmapFactory.decodeFile(resultFile.absolutePath)
                    binding.maskView.setImage(resultBmp)
                    binding.tvStatus.text = "Selesai! Hasil dipaparkan."
                    Toast.makeText(this@MainActivity, "Proses berjaya", Toast.LENGTH_SHORT).show()
                } else {
                    binding.tvStatus.text = "Gagal mendapatkan hasil"
                    Toast.makeText(this@MainActivity, "Gagal", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                binding.tvStatus.text = "Error: ${e.message}"
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isProcessing = false
                binding.btnProcess.isEnabled = true
                binding.btnSelect.isEnabled = true
                binding.progress.visibility = View.GONE
            }
        }
    }

    private fun processFull(image: Bitmap, mask: Bitmap): File? {
        val cacheDir = File(cacheDir, "inpaint_temp").apply { mkdirs() }
        val imageFile = File(cacheDir, "image.png")
        val maskFile = File(cacheDir, "mask.png")

        // Save bitmaps
        if (!GitHubHelper.saveBitmapToFile(image, imageFile)) throw Exception("Gagal simpan gambar")
        if (!GitHubHelper.saveBitmapToFile(mask, maskFile)) throw Exception("Gagal simpan mask")

        runOnUiThread { binding.tvStatus.text = "Uploading gambar..." }
        val imageUrl = GitHubHelper.uploadImage(imageFile) ?: throw Exception("Gagal upload gambar")

        runOnUiThread { binding.tvStatus.text = "Uploading mask..." }
        val maskUrl = GitHubHelper.uploadImage(maskFile) ?: throw Exception("Gagal upload mask")

        runOnUiThread { binding.tvStatus.text = "Trigger GitHub Action..." }
        if (!GitHubHelper.triggerWorkflow(imageUrl, maskUrl)) {
            throw Exception("Gagal trigger GitHub Action. Check token & repo.")
        }

        // Tunggu sekejap supaya run muncul
        Thread.sleep(8000)

        val runId = GitHubHelper.getLatestRunId() ?: throw Exception("Tak jumpa workflow run")

        val success = GitHubHelper.waitForCompletion(runId) { status ->
            runOnUiThread { binding.tvStatus.text = status }
        }

        if (!success) throw Exception("Workflow gagal atau timeout")

        runOnUiThread { binding.tvStatus.text = "Downloading hasil..." }
        val zipFile = GitHubHelper.downloadArtifact(runId, cacheDir) ?: throw Exception("Gagal download artifact")

        // Extract zip
        val extractDir = File(cacheDir, "extracted").apply { mkdirs() }
        ZipFile(zipFile).use { zip ->
            zip.entries().asSequence().forEach { entry ->
                if (!entry.isDirectory) {
                    val outFile = File(extractDir, entry.name.substringAfterLast('/'))
                    zip.getInputStream(entry).use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }

        // Cari fail gambar hasil
        return extractDir.listFiles()?.firstOrNull {
            it.extension.lowercase() in listOf("png", "jpg", "jpeg", "webp")
        }
    }
}
