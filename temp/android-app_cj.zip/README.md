# AI Remove - Android App (Siap Guna)

Framework: **Kotlin (Native Android)**  
versionCode: **1**  
versionName: **1.0**  
minSdk: 24 | targetSdk: 34

## Apa yang sudah ada

- Pilih gambar dari gallery
- Lukis mask (brush putih = kawasan dibuang)
- Clear mask
- Upload automatik ke litterbox (fallback 0x0.st)
- Trigger GitHub Action
- Poll status sehingga selesai
- Download hasil + paparkan

## Cara Setup

1. Buka fail:
   `app/src/main/java/com/aiinpaint/app/AppConfig.kt`

2. Isi:
```kotlin
const val GITHUB_TOKEN = "ghp_xxxx..."
const val GITHUB_REPO  = "username/nama-repo"
```

3. Sync Gradle + Build APK

## Nota

- Prompt & Negative Prompt sudah hardcode di sebelah GitHub Actions.
- Process ambil masa 10–30+ minit (CPU only).
- Pastikan repo GitHub Actions sudah di-push dan Actions dibenarkan.
