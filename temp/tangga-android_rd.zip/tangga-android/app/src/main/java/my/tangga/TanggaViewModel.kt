package my.tangga

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import my.tangga.data.SimpananProgres
import my.tangga.enjin.EnjinJs
import my.tangga.enjin.SemakanWebView
import java.time.LocalDate

enum class Skrin { BAHASA, PETA, LEVEL, LESEN }

data class Keadaan(
    val memuat: Boolean = true,
    val skrin: Skrin = Skrin.BAHASA,
    val bahasa: Bahasa? = null,
    val menyediakanEnjin: Boolean = false,
    /** Runtime berat sedang dimuat di latar. Melayari tetap berfungsi. */
    val memanaskan: Boolean = false,
    val enjinPanas: Boolean = false,
    val kemajuan: Kemajuan? = null,
    /** Keupayaan penyedia WebView peranti. Null sehingga disemak. */
    val semakanWebView: SemakanWebView.Keputusan? = null,
    /** Teks lesen sumber terbuka, dimuat sesuai permintaan. */
    val lesen: List<Pair<String, String>> = emptyList(),
    val bab: List<Bab> = emptyList(),
    val jumlahLevel: Int = 0,
    val semua: SemuaProgres = SemuaProgres(),
    val level: Level? = null,
    val kod: String = "",
    val jawapanTeks: String = "",
    val keputusan: Keputusan? = null,
    val hasilRamal: HasilRamal? = null,
    val pilihanDipilih: Int? = null,
    val berjalan: Boolean = false,
    val petunjukDibuka: Int = 0,
    val jawapanDibuka: Boolean = false,
    val cuba: Int = 0,
    val memuatLevel: Boolean = false,
    val ralatEnjin: String? = null,
    /** Dinaikkan hanya bila kod diganti dari luar, supaya editor tak melawan taipan. */
    val kodVersi: Int = 0,
    /** Ditetapkan sebaik progres ditulis ke cakera, supaya UI boleh mengesahkannya. */
    val baruDisimpan: Int? = null,
) {
    val progres: Progres get() = bahasa?.let { semua.untuk(it) } ?: Progres()

    val babSemasa: Bab? get() = level?.let { l -> bab.firstOrNull { l.n in it.dari..it.hingga } }

    /** Level semasa mesti diselesaikan sebelum yang seterusnya terbuka. */
    val bolehKeSeterusnya: Boolean
        get() = level?.let { progres.sudahSiap(it.n) } == true
}

class TanggaViewModel(private val app: Application) : AndroidViewModel(app) {

    private var enjin: EnjinJs? = null
    private var kerjaKemajuan: Job? = null
    private var kerjaPemasa: Job? = null
    private val simpanan = SimpananProgres(app)
    private val json = Json { ignoreUnknownKeys = true }

    private val _keadaan = MutableStateFlow(Keadaan())
    val keadaan: StateFlow<Keadaan> = _keadaan.asStateFlow()

    init {
        // Disemak sekali semasa mula. Murah — hanya bacaan pengurus pakej.
        _keadaan.value = _keadaan.value.copy(semakanWebView = SemakanWebView.semak(app))

        viewModelScope.launch {
            simpanan.aliran.collect { s ->
                _keadaan.value = _keadaan.value.copy(semua = s, memuat = false)
            }
        }
    }

    // ---------------- Pemilihan bahasa ----------------

    fun pilihBahasa(b: Bahasa) {
        if (_keadaan.value.menyediakanEnjin) return
        _keadaan.value = _keadaan.value.copy(
            bahasa = b,
            menyediakanEnjin = true,
            ralatEnjin = null,
            bab = emptyList(),
            jumlahLevel = 0,
            level = null,
            enjinPanas = false,
            memanaskan = false,
        )
        enjin?.lepaskan()
        val e = EnjinJs(app, b)
        enjin = e

        viewModelScope.launch {
            // Hanya aset ringan diperlukan untuk melayari bab dan level.
            val senaraiBab = e.bab()?.let {
                runCatching { json.decodeFromString<List<Bab>>(it) }.getOrNull()
            }
            val jumlah = e.jumlahLevel()

            if (senaraiBab.isNullOrEmpty() || jumlah == 0) {
                _keadaan.value = _keadaan.value.copy(
                    menyediakanEnjin = false,
                    bahasa = null,
                    ralatEnjin = "Enjin ${b.label} tidak dapat dimuatkan.",
                )
                return@launch
            }

            _keadaan.value = _keadaan.value.copy(
                menyediakanEnjin = false,
                skrin = Skrin.PETA,
                bab = senaraiBab,
                jumlahLevel = jumlah,
            )
            simpan(_keadaan.value.semua.tetapkan(b, _keadaan.value.progres))

            // Runtime berat dimuat selepas ini, tanpa menyekat apa-apa.
            panaskanLatar()
        }
    }

    /**
     * Memuatkan runtime berat di latar. Pengguna boleh melayari bab, membaca
     * soalan dan menaip kod sepanjang masa ini.
     */
    private fun panaskanLatar() {
        val e = enjin ?: return
        if (_keadaan.value.memanaskan || e.panas) return
        _keadaan.value = _keadaan.value.copy(memanaskan = true, kemajuan = null)

        // Cerminkan peringkat enjin ke dalam keadaan UI.
        kerjaKemajuan?.cancel()
        kerjaKemajuan = viewModelScope.launch {
            e.kemajuan.collect { km ->
                if (_keadaan.value.memanaskan) {
                    _keadaan.value = _keadaan.value.copy(kemajuan = km)
                }
            }
        }

        // Peringkat berat tidak boleh diukur, jadi kira saat berlalu supaya
        // pengguna nampak ia masih hidup dan bukannya tergantung.
        kerjaPemasa?.cancel()
        kerjaPemasa = viewModelScope.launch {
            var saat = 0
            while (isActive && _keadaan.value.memanaskan) {
                delay(1_000)
                saat++
                val km = _keadaan.value.kemajuan ?: continue
                if (km.pecahan == null) {
                    _keadaan.value = _keadaan.value.copy(kemajuan = km.copy(saat = saat))
                }
            }
        }

        viewModelScope.launch {
            val ok = e.panaskan()
            kerjaKemajuan?.cancel()
            kerjaPemasa?.cancel()
            _keadaan.value = _keadaan.value.copy(
                memanaskan = false,
                enjinPanas = ok,
                kemajuan = null,
                ralatEnjin = if (ok) _keadaan.value.ralatEnjin else
                    "Runtime ${_keadaan.value.bahasa?.label} gagal dimuat. " +
                        "Pastikan skrip pemasangan aset sudah dijalankan " +
                        "(./ambil-pyodide.sh atau ./ambil-sqljs.sh).",
            )
        }
    }

    fun tukarBahasa() {
        enjin?.lepaskan()
        enjin = null
        _keadaan.value = _keadaan.value.copy(
            skrin = Skrin.BAHASA,
            bahasa = null,
            bab = emptyList(),
            jumlahLevel = 0,
            level = null,
            ralatEnjin = null,
            enjinPanas = false,
            memanaskan = false,
        )
    }

    // ---------------- Navigasi level ----------------

    fun bukaLevel(n: Int) {
        val semasa = _keadaan.value
        val e = enjin ?: return
        // Abaikan ketukan berganda dan ketukan semasa ujian sedang berjalan.
        if (semasa.memuatLevel || semasa.berjalan) return

        val had = semasa.jumlahLevel.takeIf { it > 0 } ?: 1
        val nombor = n.coerceIn(1, had)

        // Bab boleh dimasuki bila-bila. Di dalam bab, tiada lompat.
        val bab = semasa.bab.firstOrNull { nombor in it.dari..it.hingga }
        if (bab != null && !semasa.progres.bolehBuka(nombor, bab)) {
            _keadaan.value = semasa.copy(
                ralatEnjin = "Selesaikan level ${nombor - 1} dahulu sebelum ke level $nombor.",
            )
            return
        }

        _keadaan.value = semasa.copy(memuatLevel = true, ralatEnjin = null)

        viewModelScope.launch {
            var level: Level? = null
            for (percubaan in 1..2) {
                val mentah = e.level(nombor)
                if (mentah != null) {
                    level = runCatching { json.decodeFromString<Level>(mentah) }.getOrNull()
                }
                if (level != null) break
            }

            val l = level
            if (l == null) {
                // Dahulu ini `return@launch` senyap — ketukan kelihatan tak berfungsi.
                _keadaan.value = _keadaan.value.copy(
                    memuatLevel = false,
                    ralatEnjin = "Enjin tidak bertindak balas. Tekan sekali lagi.",
                )
                return@launch
            }

            _keadaan.value = _keadaan.value.copy(
                skrin = Skrin.LEVEL,
                level = l,
                kod = l.starter.orEmpty(),
                kodVersi = _keadaan.value.kodVersi + 1,
                jawapanTeks = "",
                keputusan = null,
                hasilRamal = null,
                pilihanDipilih = null,
                petunjukDibuka = 0,
                jawapanDibuka = false,
                cuba = 0,
                memuatLevel = false,
                ralatEnjin = null,
                baruDisimpan = null,
            )
            simpanKedudukan(nombor)
        }
    }

    /** Meneruskan ke level seterusnya. Terkunci sehingga level semasa selesai. */
    fun seterusnya() {
        val k = _keadaan.value
        val l = k.level ?: return
        if (!k.bolehKeSeterusnya) {
            _keadaan.value = k.copy(ralatEnjin = "Jawab level ini dengan betul dahulu.")
            return
        }
        bukaLevel(l.n + 1)
    }

    fun sebelum() {
        val l = _keadaan.value.level ?: return
        bukaLevel(l.n - 1)
    }

    /** Membuka bab pada level pertama yang belum selesai — bukan sentiasa dari awal. */
    fun bukaBab(b: Bab) = bukaLevel(_keadaan.value.progres.sambungDalam(b))

    /**
     * Memuat setiap fail dalam assets/lesen. Lesen mesti kelihatan kepada
     * pengguna kerana Apache-2.0 dan MIT mewajibkannya, bukan sekadar disimpan
     * dalam APK.
     */
    fun bukaLesen() {
        viewModelScope.launch {
            val teks = withContext(Dispatchers.IO) {
                runCatching {
                    val am = app.assets
                    (am.list("lesen") ?: emptyArray()).sorted().map { nama ->
                        val isi = am.open("lesen/$nama").bufferedReader().use { it.readText() }
                        nama.removeSuffix(".txt") to isi
                    }
                }.getOrDefault(emptyList())
            }
            _keadaan.value = _keadaan.value.copy(skrin = Skrin.LESEN, lesen = teks)
        }
    }

    fun tutupLesen() {
        _keadaan.value = _keadaan.value.copy(skrin = Skrin.BAHASA)
    }

    fun kePeta() {
        _keadaan.value = _keadaan.value.copy(skrin = Skrin.PETA, ralatEnjin = null)
    }

    // ---------------- Interaksi level ----------------

    fun tetapkanKod(baharu: String) {
        _keadaan.value = _keadaan.value.copy(kod = baharu)
    }

    fun tetapkanJawapanTeks(baharu: String) {
        _keadaan.value = _keadaan.value.copy(jawapanTeks = baharu)
    }

    fun bukaPetunjuk() {
        _keadaan.value = _keadaan.value.copy(petunjukDibuka = _keadaan.value.petunjukDibuka + 1)
    }

    fun bukaJawapan() {
        _keadaan.value = _keadaan.value.copy(jawapanDibuka = true)
    }

    fun setSemula() {
        val l = _keadaan.value.level ?: return
        _keadaan.value = _keadaan.value.copy(
            kod = l.starter.orEmpty(),
            kodVersi = _keadaan.value.kodVersi + 1,
        )
    }

    fun jalankan() {
        val k = _keadaan.value
        val level = k.level ?: return
        val e = enjin ?: return
        if (k.berjalan) return
        _keadaan.value = k.copy(berjalan = true, keputusan = null, cuba = k.cuba + 1)
        viewModelScope.launch {
            val mentah = e.jalan(level.n, _keadaan.value.kod)
            val hasil = runCatching { json.decodeFromString<Keputusan>(mentah) }
                .getOrElse { Keputusan(fatal = "Tidak dapat membaca keputusan ujian.") }
            _keadaan.value = _keadaan.value.copy(
                berjalan = false,
                keputusan = hasil,
                enjinPanas = e.panas,
            )
            if (hasil.semuaLulus) tandaSiap(level.n, _keadaan.value.cuba)
            // Masa tamat memusnahkan WebView, jadi runtime perlu dimuat semula.
            if (!e.panas) panaskanLatar()
        }
    }

    fun semakRamal() {
        val k = _keadaan.value
        val level = k.level ?: return
        val e = enjin ?: return
        _keadaan.value = k.copy(cuba = k.cuba + 1)
        viewModelScope.launch {
            val mentah = e.semakRamal(level.n, _keadaan.value.jawapanTeks)
            val hasil = mentah?.let { runCatching { json.decodeFromString<HasilRamal>(it) }.getOrNull() }
            if (hasil == null) {
                _keadaan.value = _keadaan.value.copy(ralatEnjin = "Enjin tidak bertindak balas. Cuba lagi.")
                return@launch
            }
            _keadaan.value = _keadaan.value.copy(hasilRamal = hasil, ralatEnjin = null)
            if (hasil.lulus) tandaSiap(level.n, _keadaan.value.cuba)
        }
    }

    fun pilih(indeks: Int) {
        val k = _keadaan.value
        val level = k.level ?: return
        if (k.pilihanDipilih != null) return
        _keadaan.value = k.copy(pilihanDipilih = indeks, cuba = k.cuba + 1)
        if (indeks == level.betul) tandaSiap(level.n, _keadaan.value.cuba)
    }

    // ---------------- Progres ----------------

    /**
     * Dipanggil sebaik jawapan betul disahkan. Progres ditulis ke cakera pada
     * saat itu juga — bukan bila pengguna menekan Seterusnya.
     */
    private fun tandaSiap(n: Int, percubaan: Int) {
        val k = _keadaan.value
        val b = k.bahasa ?: return
        val p = k.progres
        val hariIni = LocalDate.now().toString()
        val semalam = LocalDate.now().minusDays(1).toString()
        val rentetan = when {
            p.hariAkhir == hariIni -> p.rentetan
            p.hariAkhir == semalam -> p.rentetan + 1
            else -> 1
        }
        val baharu = !p.sudahSiap(n)
        val dikemas = p.copy(
            siap = p.siap + (n.toString() to percubaan),
            xp = p.xp + if (baharu) (if (percubaan <= 1) 15 else 10) else 0,
            hariAkhir = hariIni,
            rentetan = rentetan,
            sekarang = n,
        )
        _keadaan.value = _keadaan.value.copy(baruDisimpan = n)
        simpan(k.semua.tetapkan(b, dikemas))
    }

    private fun simpanKedudukan(n: Int) {
        val k = _keadaan.value
        val b = k.bahasa ?: return
        simpan(k.semua.tetapkan(b, k.progres.copy(sekarang = n)))
    }

    private fun simpan(s: SemuaProgres) {
        _keadaan.value = _keadaan.value.copy(semua = s)
        viewModelScope.launch { simpanan.simpan(s) }
    }

    override fun onCleared() {
        kerjaKemajuan?.cancel()
        kerjaPemasa?.cancel()
        enjin?.lepaskan()
        super.onCleared()
    }
}
