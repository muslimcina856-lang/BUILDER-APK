package my.tangga.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Bahasa
import my.tangga.Keadaan

@Composable
fun BahasaSkrin(k: Keadaan, padaPilih: (Bahasa) -> Unit, padaLesen: () -> Unit = {}) {
    var masuk by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { masuk = true }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(76.dp))

        Berperingkat(masuk, 0) {
            Text(
                "TANGGA",
                color = Warna.Oker,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                letterSpacing = 10.sp,
            )
        }
        Spacer(Modifier.height(12.dp))
        Berperingkat(masuk, 1) {
            Text(
                "Pilih bahasa yang kau nak belajar. Progres setiap laluan disimpan " +
                    "berasingan, jadi kau boleh bertukar bila-bila tanpa kehilangan apa-apa.",
                color = Warna.Senyap,
                fontSize = 14.5.sp,
                lineHeight = 23.sp,
            )
        }
        k.semakanWebView?.amaran?.let { amaran ->
            Berperingkat(masuk, 2) {
                Column {
                    Nota(amaran, merah = k.semakanWebView.bahasaBermasalah.size > 1)
                    Spacer(Modifier.height(20.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Bahasa.entries.forEachIndexed { i, b ->
            val progres = k.semua.untuk(b)
            Berperingkat(masuk, 3 + i) {
                KadBahasa(
                    bahasa = b,
                    siap = progres.siap.size,
                    xp = progres.xp,
                    sibuk = k.menyediakanEnjin && k.bahasa == b,
                    hidup = !k.menyediakanEnjin,
                    // Amaran, bukan sekatan. Ambang itu anggaran, jadi pengguna
                    // masih boleh mencuba jika tekaan kita salah pada peranti mereka.
                    disokong = k.semakanWebView?.sokong(b) ?: true,
                ) { padaPilih(b) }
            }
            Spacer(Modifier.height(12.dp))
        }

        AnimatedVisibility(
            visible = k.ralatEnjin != null,
            enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
            exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
        ) {
            Column {
                Spacer(Modifier.height(6.dp))
                Nota(k.ralatEnjin.orEmpty(), merah = true)
            }
        }

        Spacer(Modifier.height(28.dp))

        Berperingkat(masuk, 9) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clickable(onClickLabel = "Lihat lesen sumber terbuka") { padaLesen() },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Eyebrow("Lesen sumber terbuka \u2192", warna = Warna.SenyapGelap)
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

/** Kemasukan berperingkat: setiap item meluncur masuk sedikit selepas item sebelumnya. */
@Composable
private fun Berperingkat(masuk: Boolean, indeks: Int, kandungan: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = masuk,
        enter = fadeIn(Gerak.peringkat(indeks)) +
            slideInVertically(Gerak.peringkat(indeks)) { it / 4 },
        exit = fadeOut(Gerak.biasa()),
    ) { kandungan() }
}

@Composable
private fun KadBahasa(
    bahasa: Bahasa,
    siap: Int,
    xp: Int,
    sibuk: Boolean,
    hidup: Boolean,
    disokong: Boolean = true,
    padaKlik: () -> Unit,
) {
    val interaksi = remember { MutableInteractionSource() }
    val ditekan by interaksi.collectIsPressedAsState()
    val skala by animateFloatAsState(
        targetValue = if (ditekan && hidup) 0.975f else 1f,
        animationSpec = Gerak.pantas(),
        label = "kad",
    )

    Kaca(
        modifier = Modifier
            .graphicsLayer(scaleX = skala, scaleY = skala)
            .fillMaxWidth()
            .clickable(enabled = hidup, onClickLabel = "Buka laluan ${bahasa.label}") { padaKlik() },
        aksen = when {
            sibuk -> Warna.Oker
            !disokong -> Warna.Bata
            else -> null
        },
    ) {
        Row(
            Modifier.height(IntrinsicSize.Min),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .width(80.dp)
                    .fillMaxHeight()
                    .background(if (sibuk) Warna.OkerRedup else Warna.KacaIsi),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    bahasa.kod.uppercase(),
                    color = Warna.Oker,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                )
            }
            Column(Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 18.dp)) {
                Text(
                    bahasa.label,
                    color = Warna.Dakwat,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    when {
                        sibuk -> "Menyediakan enjin\u2026"
                        !disokong -> "\u26a0 WebView mungkin terlalu lama"
                        else -> bahasa.nota
                    },
                    color = when {
                        sibuk -> Warna.Oker
                        !disokong -> Warna.Bata
                        else -> Warna.Senyap
                    },
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
                AnimatedVisibility(
                    visible = siap > 0 && !sibuk,
                    enter = fadeIn(Gerak.biasa()),
                    exit = fadeOut(Gerak.biasa()),
                ) {
                    Column {
                        Spacer(Modifier.height(6.dp))
                        Box(
                            Modifier
                                .clip(Bentuk.Cip)
                                .background(Warna.HijauRedup, Bentuk.Cip)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                "$siap level \u00b7 $xp XP",
                                color = Warna.Hijau,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                            )
                        }
                    }
                }
            }
            Text(
                "\u2192",
                color = if (hidup) Warna.Oker else Warna.SenyapGelap,
                fontSize = 20.sp,
                modifier = Modifier.padding(end = 20.dp),
            )
        }
    }
}
