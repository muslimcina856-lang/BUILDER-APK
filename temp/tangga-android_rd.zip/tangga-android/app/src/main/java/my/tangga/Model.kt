package my.tangga

import kotlinx.serialization.Serializable

/** Laluan pembelajaran. Setiap satu ada enjin, bank tugasan dan progres sendiri. */
enum class Bahasa(
    val kod: String,
    val label: String,
    val nota: String,
    /** Aset yang diperlukan untuk melayari bab dan level. Mesti ringan. */
    val aset: List<String>,
    /** Aset berat yang hanya diperlukan untuk menjalankan kod. Dimuat di latar. */
    val asetPanas: List<String>,
    val global: String,
) {
    JAVASCRIPT(
        kod = "js",
        label = "JavaScript",
        nota = "26 bab \u00b7 3,500 level",
        aset = listOf("enjin.js"),
        asetPanas = emptyList(),
        global = "TanggaEnjin",
    ),
    PYTHON(
        kod = "py",
        label = "Python",
        nota = "12 bab \u00b7 1,800 level",
        // python.js kecil (63 KB) dan mengandungi semua bab dan level.
        // pyodide.js hanya diperlukan untuk menjalankan kod, jadi ia menunggu.
        aset = listOf("python.js"),
        asetPanas = listOf("pyodide/pyodide.js"),
        global = "TanggaPython",
    ),
    SQL(
        kod = "sql",
        label = "SQL",
        nota = "11 bab \u00b7 1,300 level",
        // sql.js kecil dan mula dalam bawah sesaat.
        aset = listOf("sql.js"),
        asetPanas = listOf("sqljs/sql-wasm.js"),
        global = "TanggaSql",
    ),
    TYPESCRIPT(
        kod = "ts",
        label = "TypeScript",
        nota = "11 bab \u00b7 1,400 level",
        // Pengkompil itu sendiri berat; fail lib diambil sesuai permintaan.
        aset = listOf("ts.js"),
        // Enjin memuat pengkompil sendiri melalui tag skrip.
        asetPanas = emptyList(),
        global = "TanggaTs",
    ),
    LUA(
        kod = "lua",
        label = "Lua",
        nota = "9 bab \u00b7 1,100 level",
        aset = listOf("lua.js"),
        asetPanas = emptyList(),
        global = "TanggaLua",
    ),
    HTML(
        kod = "html",
        label = "HTML & CSS",
        nota = "9 bab \u00b7 1,000 level",
        // Tiada runtime tambahan langsung: kod pengguna dihuraikan oleh DOM
        // WebView sendiri dalam iframe berkotak pasir.
        aset = listOf("html.js"),
        asetPanas = emptyList(),
        global = "TanggaHtml",
    );

    companion object {
        fun dari(kod: String?): Bahasa = entries.firstOrNull { it.kod == kod } ?: JAVASCRIPT
    }
}

@Serializable
data class Bab(
    val n: Int,
    val nama: String,
    val dari: Int,
    val hingga: Int,
) {
    val bilanganLevel: Int get() = hingga - dari + 1
}

@Serializable
data class Kes(
    val hujah: String,
    val jangka: String,
)

/** Satu level, sebagaimana dihantar oleh enjin JS. */
@Serializable
data class Level(
    val n: Int,
    val bab: Int,
    val namaBab: String,
    val jenis: String,
    val tajuk: String,
    val brief: String,
    val petunjuk: List<String> = emptyList(),

    // jenis = ramal
    val kod: String? = null,

    // jenis = pilih
    val soalan: String? = null,
    val pilihan: List<String> = emptyList(),
    val betul: Int = -1,
    val huraian: String? = null,

    // jenis = tulis / baiki / kukuh
    val fn: String? = null,
    val starter: String? = null,
    val jawapan: String = "",
    val kes: List<Kes> = emptyList(),
    /** Hanya untuk laluan SQL: DDL jadual yang kueri dijalankan terhadapnya. */
    val skema: String? = null,
) {
    val adaEditor: Boolean get() = jenis == "tulis" || jenis == "baiki" || jenis == "kukuh"

    val labelJenis: String
        get() = when (jenis) {
            "tulis" -> "Tulis"
            "baiki" -> "Baiki"
            "kukuh" -> "Kukuhkan"
            "ramal" -> "Ramal"
            "pilih" -> "Pilih"
            else -> jenis
        }
}

@Serializable
data class KeputusanKes(
    val lulus: Boolean,
    val papar: String,
)

@Serializable
data class Keputusan(
    val fatal: String? = null,
    val results: List<KeputusanKes>? = null,
) {
    val semuaLulus: Boolean get() = results?.isNotEmpty() == true && results.all { it.lulus }
    val bilanganLulus: Int get() = results?.count { it.lulus } ?: 0
}

@Serializable
data class HasilRamal(
    val lulus: Boolean,
    val jangka: String,
)

/** Progres pengguna. Disimpan sebagai satu blob JSON dalam DataStore. */
@Serializable
data class Progres(
    val siap: Map<String, Int> = emptyMap(),
    val xp: Int = 0,
    val sekarang: Int = 1,
    val hariAkhir: String? = null,
    val rentetan: Int = 0,
) {
    fun sudahSiap(n: Int) = siap.containsKey(n.toString())

    fun siapDalam(b: Bab) = (b.dari..b.hingga).count { sudahSiap(it) }

    /**
     * Bab boleh dimasuki bila-bila masa. Di dalam bab, kau mesti menyelesaikan
     * setiap level sebelum yang seterusnya terbuka.
     */
    fun bolehBuka(n: Int, bab: Bab) = n <= bab.dari || sudahSiap(n - 1)

    /** Level pertama yang belum selesai dalam bab — titik sambung semula. */
    fun sambungDalam(bab: Bab) =
        (bab.dari..bab.hingga).firstOrNull { !sudahSiap(it) } ?: bab.hingga
}

/** Progres disimpan berasingan untuk setiap bahasa. */
@Serializable
data class SemuaProgres(
    val js: Progres = Progres(),
    val py: Progres = Progres(),
    val sql: Progres = Progres(),
    val ts: Progres = Progres(),
    val lua: Progres = Progres(),
    val html: Progres = Progres(),
    val bahasaAkhir: String? = null,
) {
    fun untuk(b: Bahasa) = when (b) {
        Bahasa.JAVASCRIPT -> js
        Bahasa.PYTHON -> py
        Bahasa.SQL -> sql
        Bahasa.TYPESCRIPT -> ts
        Bahasa.LUA -> lua
        Bahasa.HTML -> html
    }

    fun tetapkan(b: Bahasa, p: Progres) = when (b) {
        Bahasa.JAVASCRIPT -> copy(js = p, bahasaAkhir = b.kod)
        Bahasa.PYTHON -> copy(py = p, bahasaAkhir = b.kod)
        Bahasa.SQL -> copy(sql = p, bahasaAkhir = b.kod)
        Bahasa.TYPESCRIPT -> copy(ts = p, bahasaAkhir = b.kod)
        Bahasa.LUA -> copy(lua = p, bahasaAkhir = b.kod)
        Bahasa.HTML -> copy(html = p, bahasaAkhir = b.kod)
    }
}

/** Satu peringkat dalam permulaan runtime, untuk dipaparkan kepada pengguna. */
data class Kemajuan(
    val peringkat: String,
    /** null bermakna tak boleh diukur — papar bar tak tentu. */
    val pecahan: Float? = null,
    val saat: Int = 0,
)
