# Ai MultiAgent

Ai MultiAgent ialah klien AI Android **local/BYOK** yang menyambung terus dari telefon kepada provider pilihan pengguna. Ia tidak memerlukan login dan tidak mempunyai backend milik aplikasi.

| Perkara | Nilai |
|---|---|
| Nama aplikasi | Ai MultiAgent |
| Package ID | `com.aiauto.claw` |
| Versi sumber | `2.0.0+4` |
| UI | Flutter |
| Android native | Kotlin |
| Data biasa | SQLite local |
| API key | Flutter Secure Storage / Android Keystore |
| Backend aplikasi | Tiada |

## Fungsi utama

- Provider Manager dengan preset luas, termasuk Xiaomi MiMo, serta Custom Provider.
- Base URL, endpoint chat/model, API key, model manual, custom headers dan protokol boleh diubah.
- Simpan provider akan menjalankan ujian Base URL, autentikasi, model dan respons chat secara automatik.
- Senarai model diambil daripada endpoint provider apabila tersedia; model manual sentiasa boleh digunakan.
- Chat terus ke provider menggunakan OpenAI Chat, OpenAI Responses, Anthropic Messages, Gemini atau Custom REST.
- General, Research, Browser, Coding, Document, File, Productivity dan Orchestrator Agent.
- Orchestrator boleh mendelegasikan sub-agent tanpa had tetap daripada aplikasi.
- DuckDuckGo Search dengan parser HTML + Lite fallback dan hasil JSON penuh.
- Browser WebView kelihatan dengan cookies local, klik, isi input, hantar borang, bacaan DOM dan muat turun.
- Terminal latar belakang dalam workspace aplikasi; AI boleh membaca `stdout`, `stderr`, status dan exit code.
- Fail local, memori local, skills ZIP/URL, skrip skill dalam sandbox dan MCP local.
- Automasi WorkManager dengan pilihan notifikasi semasa tugas panjang.
- Tool biasa berjalan terus. Hanya tindakan yang boleh memadam, menimpa atau merosakkan data meminta kelulusan.
- Kelulusan: sekali, semua risiko untuk sesi ini, atau sentiasa untuk tool + skop.
- Tetapan boleh memberi kelulusan kekal secara local dan menariknya semula.
- Tiada Accessibility Service dan tiada prompt penapisan topik tambahan daripada aplikasi.

## Struktur projek

```text
AiMultiAgent/
├── mobile/                     # Flutter + Android Kotlin
│   ├── lib/src/data/           # Katalog provider
│   ├── lib/src/services/       # Provider, tools, agent, browser, terminal, MCP
│   ├── lib/src/state/          # State dan lifecycle sesi
│   ├── lib/src/ui/             # Semua skrin
│   └── test/                   # Ujian parser DuckDuckGo
├── assets/branding/            # Ikon sumber
├── store/                      # Aset dan teks Google Play
├── docs/                       # Fungsi, keselamatan, privasi dan status
└── scripts/                    # Semakan sumber dan build release
```

## Jalankan

Flutter stable, Android SDK dan Java 17 diperlukan.

```bash
cd mobile
flutter pub get
flutter run
```

Tiada URL backend atau secret build diperlukan. Provider dan API key dimasukkan sendiri melalui aplikasi.

## Aliran provider

1. Buka **Provider** dan pilih preset atau Custom.
2. Semak Base URL, protokol dan endpoint.
3. Masukkan API key jika diperlukan.
4. Pilih model daripada senarai atau masukkan Model ID manual.
5. Tekan **Simpan**. Aplikasi menguji sambungan secara automatik.
6. Status, latency dan mesej ujian dipaparkan serta disimpan local.

## Semakan sumber

```bash
./scripts/check_project.sh
```

Skrip sentiasa menjalankan fixture DuckDuckGo dan pemeriksaan struktur/import. Jika Flutter tersedia, ia turut menjalankan format check, `flutter analyze` dan `flutter test`.

## Build release

```bash
./scripts/build_release.sh
```

Rujuk `docs/KEYSTORE.md` dan `docs/RELEASE_CHECKLIST.md` dahulu. APK/AAB tidak disertakan dalam pakej sumber ini seperti diminta.

## Perhatian keselamatan

- Base URL menerima kandungan chat dan API key mengikut kaedah auth yang dipilih. Gunakan hanya endpoint yang dipercayai.
- HTTP cleartext dibenarkan untuk Ollama/LM Studio pada localhost atau LAN; provider awam patut menggunakan HTTPS.
- Skill URL dipasang secara automatik tetapi diekstrak ke folder aplikasi, melalui pemeriksaan path traversal/saiz dan skripnya dijalankan dalam salinan workspace sandbox.
- Android dan provider masih boleh mengenakan had teknikal walaupun aplikasi tidak menetapkan had token/sub-agent sendiri.
