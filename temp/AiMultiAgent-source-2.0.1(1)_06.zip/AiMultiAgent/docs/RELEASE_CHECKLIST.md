# Checklist Google Play — Ai MultiAgent 2.0

## Build dan signing

- [ ] Pasang Flutter stable, Android SDK dan Java 17.
- [ ] Jalankan `./scripts/check_project.sh` hingga semua analyze/test lulus.
- [ ] Cipta upload keystore mengikut `docs/KEYSTORE.md`.
- [ ] Pastikan `mobile/android/key.properties` tidak dimasukkan ke Git.
- [ ] Jalankan `./scripts/build_release.sh`.
- [ ] Uji APK release dan AAB melalui Internal Testing.

## Ujian kritikal peranti

- [ ] Tambah, uji, simpan dan padam provider.
- [ ] Uji provider tanpa auth, bearer, API-key header, x-api-key dan query key.
- [ ] Uji model endpoint dan model manual.
- [ ] Uji Xiaomi MiMo menggunakan Base URL/model semasa akaun pengguna.
- [ ] Uji OpenAI-compatible, Anthropic dan Gemini tool calling.
- [ ] Uji DuckDuckGo HTML dan fallback Lite melalui rangkaian sebenar.
- [ ] Uji Browser WebView: cookies, klik, isi dan submit borang.
- [ ] Uji fail baharu tanpa dialog dan overwrite dengan dialog.
- [ ] Uji delete, sekali, sesi ini dan sentiasa benarkan.
- [ ] Uji sesi tamat selepas 30 minit dan selepas proses ditutup.
- [ ] Uji terminal start/poll/stop pada Android.
- [ ] Uji skill ZIP/URL dan script sandbox.
- [ ] Uji MCP localhost/.local.
- [ ] Uji automasi dengan background dimatikan/dihidupkan.
- [ ] Uji notifikasi ongoing dan keputusan automasi.
- [ ] Uji secure storage selepas restart/peranti lock.
- [ ] Uji padam semua data local.

## Google Play

- [ ] Host Polisi Privasi pada URL HTTPS awam.
- [ ] Ganti maklumat hubungan placeholder dalam polisi/listing.
- [ ] Lengkapkan Data Safety: data local, provider pihak ketiga, WebView/cookies dan mikrofon.
- [ ] Jelaskan bahawa API key/kandungan dihantar terus ke Base URL pilihan pengguna.
- [ ] Nyatakan trafik HTTP hanya untuk local/LAN provider.
- [ ] Pastikan tiada Accessibility Service.
- [ ] Semak deklarasi background work dan notification permission.
- [ ] Sediakan screenshot sebenar daripada build release.
- [ ] Semak content rating dan kategori aplikasi.
- [ ] Gunakan Play App Signing dan simpan backup upload key.

## Security review

- [ ] Uji tiada API key/token dalam log.
- [ ] Uji path traversal fail dan ZIP ditolak.
- [ ] Uji archive terlalu besar/zip bomb ditolak.
- [ ] Uji Base URL tidak dipercayai dengan akaun ujian sahaja.
- [ ] Uji terminal hanya bermula dalam workspace.
- [ ] Semak senarai pattern arahan destruktif.
- [ ] Semak persistent permission sebelum release.
