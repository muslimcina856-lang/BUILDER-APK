# Model Keselamatan Ai MultiAgent

## Sempadan kepercayaan

- Telefon dan storan aplikasi dianggap milik pengguna.
- Base URL provider, laman web, skill URL dan MCP ialah pihak luar yang pengguna pilih.
- Model AI tidak dianggap autoriti untuk memberi permission kepada dirinya sendiri.
- Tiada backend Ai MultiAgent yang memegang secret pengguna.

## Secret

- API key disimpan dalam Flutter Secure Storage/Android Keystore.
- API key tidak dimasukkan ke objek provider SQLite.
- Log tool menyimpan metadata/ringkasan sahaja dan menapis corak secret biasa.
- `allowBackup=false` ditetapkan dalam manifest.

## Approval berasaskan risiko

Tool biasa berjalan terus. Pemeriksaan runtime meminta kelulusan apabila tindakan boleh memadam, menimpa atau merosakkan data. Persistent permission boleh ditetapkan oleh pengguna dan disimpan local.

“Sesi ini” memberikan semua tindakan berisiko untuk sesi semasa. Sesi tamat selepas 30 minit tanpa aktiviti atau proses aplikasi baharu apabila background tidak dibenarkan.

## Fail dan terminal

- Semua path tool fail dihadkan ke workspace aplikasi.
- Root workspace tidak boleh dipadam.
- Path traversal ditolak.
- Terminal bermula di workspace dengan environment minimum.
- Arahan destruktif biasa dikesan secara heuristik dan meminta approval.
- Sandbox ini bukan container/VM. Kernel Android dan permission aplikasi ialah sempadan akhir.

## Skills

- ZIP mempunyai had saiz dan had pengembangan.
- Absolute path dan `../` tidak diekstrak.
- Skrip skill dijalankan daripada salinan dalam workspace.
- Pemasangan automatik tidak bermaksud skill dipercayai; sumber skill perlu dipilih dengan berhati-hati.

## Web

- DuckDuckGo search dan laman web menerima query/permintaan secara langsung.
- WebView menyimpan cookies local supaya login laman boleh kekal.
- Hantar borang berjalan tanpa approval mengikut spesifikasi produk.
- HTTP cleartext dibenarkan untuk server local/LAN; ia tidak selamat untuk provider awam.

## MCP

Versi ini mengehadkan MCP kepada localhost, loopback dan `.local`. Tool MCP yang kelihatan destruktif meminta approval, tetapi pengesanan adalah heuristik; pengguna patut hanya menambah server yang dipercayai.

## Prompt

Aplikasi tidak menambah prompt sekatan topik. Ia hanya menambah arahan operasi agent/tools. Polisi provider/model dan sekatan API mereka masih digunakan.

## Perkara yang perlu diuji sebelum release

- Redaction log dengan pelbagai format token.
- Permission persistent dan global.
- Terminal command detection.
- ZIP bomb/path traversal.
- WebView cookies dan submit.
- WorkManager/Doze.
- Provider error bodies dan custom REST templates.
