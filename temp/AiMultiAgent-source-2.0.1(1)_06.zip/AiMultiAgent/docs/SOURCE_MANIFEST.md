# Manifest Sumber Ai MultiAgent 2.0.0+4

## Identiti

| Perkara | Nilai |
|---|---|
| Nama aplikasi | Ai MultiAgent |
| Package ID | `com.aiauto.claw` |
| Versi | `2.0.0+4` |
| Platform sasaran | Android / Google Play |
| Rangka kerja | Flutter + Kotlin Android |
| Mod operasi | Local/BYOK tanpa login dan tanpa backend aplikasi |

## Kandungan kod

| Komponen | Kandungan |
|---|---|
| Provider | 52 preset provider, Custom Provider, Base URL/model/header/auth boleh diubah |
| Protokol AI | OpenAI Chat, OpenAI Responses, Anthropic Messages, Gemini, Custom REST |
| Agent | General, Research, Browser, Coding, Document, File, Productivity, Orchestrator |
| Tools | 28 definisi tool untuk web, browser, fail, memori, terminal, skills, MCP dan utiliti |
| Search | DuckDuckGo HTML dengan Lite fallback dan output JSON penuh |
| Browser | WebView kelihatan, DOM read/click/fill/submit, cookies local dan muat turun |
| Skills | Built-in/custom, ZIP/URL, validasi arkib dan skrip dalam salinan workspace sandbox |
| MCP | Server local/localhost, initialize, tools/list dan tools/call |
| Automasi | WorkManager background dengan pilihan notifikasi ongoing |
| Data | SQLite, secure storage dan workspace private aplikasi |
| Kelulusan | Hanya tindakan destruktif; sekali, sesi atau persistent local |
| Android | Tiada Accessibility Service |

## Fail penting

- `mobile/lib/src/data/provider_catalog.dart` — preset provider.
- `mobile/lib/src/services/provider_service.dart` — adapter dan ujian provider.
- `mobile/lib/src/services/agent_runtime.dart` — agent loop dan delegasi.
- `mobile/lib/src/services/tool_engine.dart` — registry dan pelaksanaan tools.
- `mobile/lib/src/services/permission_manager.dart` — polisi risiko dan kelulusan.
- `mobile/lib/src/services/duckduckgo_search_service.dart` — enjin search.
- `mobile/lib/src/services/browser_session_service.dart` — bridge Browser WebView.
- `mobile/lib/src/services/terminal_service.dart` — job terminal background.
- `mobile/lib/src/services/skill_service.dart` — pemasangan dan sandbox skill.
- `mobile/lib/src/services/mcp_service.dart` — MCP local.
- `mobile/lib/src/services/automation_service.dart` — automasi background.
- `docs/FUNCTIONS.md` — spesifikasi fungsi yang dilaksanakan.
- `docs/PROJECT_STATUS.md` — status ujian dan batasan pengesahan.

## Pemeriksaan sumber

Jalankan:

```bash
./scripts/check_project.sh
```

Dalam persekitaran yang mempunyai Flutter, skrip turut menjalankan `flutter pub get`, semakan format, `flutter analyze` dan `flutter test`. Build release dijalankan berasingan melalui `./scripts/build_release.sh` selepas upload keystore disediakan.
