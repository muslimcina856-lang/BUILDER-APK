# Spesifikasi Fungsi Ai MultiAgent 2.0

Dokumen ini menerangkan fungsi yang telah diterjemahkan kepada kod sumber.

## Keputusan skop

| No. | Perkara | Pelaksanaan |
|---:|---|---|
| 1 | Tamat sesi | Selepas 30 minit tanpa aktiviti; proses aplikasi baharu turut memulakan sesi baharu jika background tidak dibenarkan |
| 2 | “Sesi ini” | Membenarkan semua tindakan berisiko hingga sesi tamat |
| 3 | Kelulusan default merentas sesi | Tiada; persistent hanya apabila pengguna memilih **Sentiasa** atau menetapkannya dalam Tetapan |
| 4 | DuckDuckGo | HTML endpoint + Lite fallback, parser fixture dan hasil JSON penuh |
| 5 | Hantar borang | Berjalan terus tanpa dialog approval |
| 6 | Login laman | Cookies WebView disimpan local oleh profil aplikasi |
| 7 | Browser | WebView kelihatan; boleh ditutup dan dibuka semula |
| 8 | Sub-agent | Tiada had bilangan/kedalaman buatan aplikasi; boleh dihentikan pengguna |
| 9 | Token | Tiada had token buatan aplikasi; parameter provider masih boleh ditetapkan |
| 10 | Automasi | WorkManager background; notifikasi ongoing boleh dipilih untuk tugas panjang |
| 11 | Skrip skill | Dijalankan dalam salinan sandbox workspace aplikasi |
| 12 | MCP | MCP local/localhost sahaja |
| 13 | Terminal | Job shell latar belakang; AI boleh poll output, error dan exit code |
| 14 | Accessibility | Tidak digunakan |
| 15 | Edaran | Struktur Google Play |
| 16 | Skill URL | Muat turun dan pasang automatik selepas validasi arkib |
| 17 | Provider oleh model | Tidak; provider datang daripada pilihan pengguna atau profil agent |
| 18 | Log | Metadata + ringkasan local dengan API key/token/password ditapis |

## Provider dan model

| Fungsi | Tingkah laku |
|---|---|
| Login aplikasi | Tiada |
| Backend aplikasi | Tiada |
| API key | Secure storage, berasingan daripada SQLite |
| Base URL | Boleh diubah bagi setiap konfigurasi |
| Model | Endpoint model + senarai preset + input manual |
| Banyak konfigurasi | Provider sama boleh disimpan beberapa kali |
| Ujian automatik | Simpan provider menguji auth, model dan respons kecil |
| Provider offline | Keputusan gagal disimpan; konfigurasi boleh dikekalkan |
| Custom | OpenAI Chat, OpenAI Responses, Anthropic, Gemini dan Custom REST JSON |

Katalog merangkumi provider utama, China/Asia, inference, aggregator, cloud dan local. Katalog bukan had mutlak kerana Custom Provider dan Base URL bebas sentiasa tersedia.

## Tool dan kelulusan

### Berjalan terus

| Tool/tindakan | Default |
|---|---|
| DuckDuckGo Search | Terus |
| Buka/baca/klik/isi browser | Terus |
| Hantar borang | Terus |
| Muat turun | Terus |
| HTTP biasa yang tidak dikesan destruktif | Terus |
| Senarai/baca fail | Terus |
| Cipta fail baharu | Terus |
| Salin/pindah ke destinasi baharu | Terus |
| Cari/tambah memori | Terus |
| Terminal bukan destruktif | Terus |
| Pasang skill URL | Terus selepas validasi arkib |
| Skrip skill sandbox | Terus kecuali arahan dikesan destruktif |
| MCP read/list atau panggilan tidak destruktif | Terus |

### Meminta kelulusan

- Padam fail/folder.
- Padam memori.
- Menimpa fail atau destinasi yang sudah wujud.
- Arahan terminal yang dikesan memadam, memformat, uninstall atau merosakkan data.
- HTTP `DELETE` atau kandungan yang dikesan destruktif.
- Tool MCP yang nama/argumennya dikesan destruktif.

Pilihan dialog:

| Pilihan | Kesan |
|---|---|
| Tolak | Tidak dijalankan |
| Sekali | Panggilan semasa sahaja |
| Sesi ini | Semua tindakan berisiko dibenarkan hingga sesi tamat |
| Sentiasa | Tool + skop/domain/path disimpan local sebagai selalu dibenarkan |

Tetapan menyediakan switch per tool dan switch global. Semua rule boleh ditarik balik.

## Search dan browser

### DuckDuckGo Search

Input: query, maksimum hasil, region, Safe Search dan time range. Output mengandungi:

```json
{
  "query": "...",
  "engine": "DuckDuckGo",
  "endpoint": "...",
  "count": 2,
  "elapsed_ms": 123,
  "results": [
    {
      "rank": 1,
      "title": "...",
      "url": "https://...",
      "display_url": "example.com",
      "snippet": "...",
      "source": "html"
    }
  ]
}
```

Parser utama menggunakan HTML Search. Jika tiada hasil boleh dibaca, aplikasi mencuba DuckDuckGo Lite.

### Browser visual

- WebView dipaparkan kepada pengguna.
- Browser boleh dibuka oleh agent dan ditutup/dibuka semula.
- Cookies dan sesi laman kekal dalam profil local WebView.
- AI boleh membaca tajuk, URL, teks, 100 pautan dan 30 borang.
- AI boleh klik berdasarkan selector/teks, mengisi input dan menghantar borang.
- Tiada Accessibility API.

## Multi-agent

| Agent | Fokus |
|---|---|
| General | Semua tugas/tools aktif |
| Research | DuckDuckGo, sumber web dan laporan |
| Browser | WebView, borang, download dan HTTP |
| Coding | Workspace, terminal, web dan skrip skill |
| Document | Kandungan, fail, web dan memori |
| File | Operasi workspace |
| Productivity | Memori, masa dan MCP local |
| Orchestrator | Delegasi kepada agent lain |

Provider sub-agent hanya diambil daripada profil agent yang pengguna tetapkan. Model tidak boleh menukar provider sendiri.

## Terminal dan sandbox

- Shell hanya bermula dalam folder `workspace` aplikasi.
- Working directory di luar workspace ditolak.
- Setiap job mempunyai ID, command, working directory, masa mula/tamat, status, exit code, stdout dan stderr.
- `terminal_poll` membolehkan model memantau job latar belakang.
- Output dihadkan saiznya supaya konteks model tidak dibanjiri.
- Ini sandbox peringkat path/aplikasi, bukan VM atau container OS penuh.

## Skills

- Built-in skills dan custom skills.
- Import ZIP manual atau URL automatik.
- Validasi saiz, ZIP traversal dan had pengembangan.
- `skill.json`, arahan, trigger dan senarai tools.
- Skrip disalin ke `.skill_runs/<skillId>` dalam workspace sebelum dijalankan.
- Skill tidak boleh memberi dirinya rule persistent; polisi tool masih digunakan.

## MCP local

- URL hanya `localhost`, `127.0.0.1`, `::1` atau domain `.local`.
- Streamable HTTP/JSON-RPC dan parsing event `data:` asas.
- Ujian initialize, `tools/list` dan `tools/call`.
- Panggilan yang dikesan destruktif meminta kelulusan.

## Automasi

- WorkManager periodic minimum 15 minit.
- Provider dan agent dipilih pengguna.
- Provider tidak dipilih secara automatik oleh model.
- Tool berisiko perlu disenaraikan secara jelas pada automasi background.
- Tugas panjang boleh memaparkan notifikasi ongoing.
- Hasil dan masa larian terakhir disimpan local.
- Android boleh menunda jadual berdasarkan battery, Doze dan polisi sistem.

## Prompt sistem

Prompt aplikasi hanya menerangkan identiti agent, tools, skills, delegasi, provider yang ditetapkan dan cara menghasilkan jawapan akhir. Tiada prompt penapisan topik tambahan. Polisi dan sekatan asal provider/model masih kekal.
