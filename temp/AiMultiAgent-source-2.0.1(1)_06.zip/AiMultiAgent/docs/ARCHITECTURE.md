# Seni Bina Ai MultiAgent

```text
Flutter UI
├── Chat / Agent / Provider / Automasi / Tetapan
├── Local SQLite
├── Secure API Key Vault
├── Visible WebView Browser
└── AppState + Session Lifecycle
        │
        ├── ProviderService
        │   ├── OpenAI Chat
        │   ├── OpenAI Responses
        │   ├── Anthropic
        │   ├── Gemini
        │   └── Custom REST
        │
        └── AgentRuntime
            ├── ToolEngine
            │   ├── DuckDuckGo
            │   ├── Browser
            │   ├── Files / Memory
            │   ├── Terminal
            │   ├── Skills
            │   └── MCP local
            ├── PermissionManager
            └── Orchestrator delegation
```

Tiada lapisan backend aplikasi. Setiap provider call dibuat terus melalui `ProviderService`. API key dibaca daripada vault hanya ketika permintaan dibuat.

Background automation membuka database/vault dalam isolate WorkManager, memuat provider/agent/skill dan menjalankan runtime yang sama dalam mod background. Tool visual tidak sesuai untuk worker; `browser_open` menggunakan pembacaan HTTP dalam mod background.
