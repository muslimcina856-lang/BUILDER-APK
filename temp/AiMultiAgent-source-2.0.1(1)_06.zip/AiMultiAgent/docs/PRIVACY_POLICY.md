# Polisi Privasi Ai MultiAgent

Tarikh berkuat kuasa: 2 Ogos 2026

Ai MultiAgent ialah aplikasi local/BYOK tanpa akaun dan tanpa backend milik Ai MultiAgent. Data aplikasi disimpan pada peranti, kecuali data yang pengguna atau agent hantar terus kepada provider AI, laman web, URL muat turun atau server MCP yang pengguna konfigurasi.

## Data local

Aplikasi boleh menyimpan pada peranti:

- Konfigurasi provider, Base URL, model dan parameter.
- API key dalam secure storage Android.
- Mesej chat, agent, skills, memori, automasi dan MCP.
- Workspace fail dan fail yang dimuat turun.
- Cookies/sesi laman dalam WebView.
- Metadata dan ringkasan log tool yang telah melalui redaction asas.
- Audio sementara apabila pengguna menggunakan input suara.

`android:allowBackup` dimatikan supaya data aplikasi tidak dimasukkan ke backup Android biasa.

## Data dihantar keluar

Bergantung pada tindakan pengguna, aplikasi boleh menghantar:

- Prompt, konteks, hasil tool dan lampiran kepada Base URL provider yang dipilih.
- API key melalui kaedah autentikasi konfigurasi provider.
- Query kepada DuckDuckGo.
- Permintaan, borang dan cookies kepada laman yang dibuka dalam browser.
- Permintaan kepada server MCP local yang dikonfigurasi.
- URL untuk memuat turun dan memasang skill.

Provider dan laman pihak ketiga mempunyai polisi privasi mereka sendiri. Pengguna perlu memastikan Base URL dan skill source dipercayai.

## Kawalan pengguna

Pengguna boleh:

- Melihat, mengubah dan memadam provider.
- Memadam API key provider.
- Melihat dan memadam memori.
- Mengubah atau menarik balik permission persistent.
- Menutup background execution.
- Memadam skills, automasi, MCP dan fail workspace.
- Menggunakan fungsi **Padam semua data local**.

## Keselamatan

API key disimpan melalui secure storage yang menggunakan mekanisme Android Keystore. Aplikasi menapis corak API key, authorization, token, secret dan password daripada ringkasan log, tetapi pengguna tidak patut meminta model menulis secret ke fail/chat biasa.

## Mikrofon

Permission mikrofon hanya digunakan untuk input suara apabila pengguna mengaktifkannya. Audio tidak dihantar ke backend Ai MultiAgent kerana backend tersebut tidak wujud; pemprosesan bergantung pada implementasi input suara/peranti dan provider yang digunakan.

## Hubungi

Sebelum penerbitan, gantikan bahagian ini dengan nama penerbit, alamat e-mel sokongan dan URL polisi privasi rasmi.
