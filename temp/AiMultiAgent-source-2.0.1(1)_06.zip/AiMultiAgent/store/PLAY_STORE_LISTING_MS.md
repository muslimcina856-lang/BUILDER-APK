# Google Play Listing — Bahasa Melayu

**Nama:** Ai MultiAgent

**Penerangan pendek:** Klien AI local/BYOK dengan pelbagai provider, agent, browser, skills dan automasi.

**Penerangan penuh:**

Ai MultiAgent menghubungkan telefon anda terus kepada provider AI pilihan anda. Tiada login aplikasi dan tiada backend Ai MultiAgent. Tambah API key sendiri, pilih model dan gunakan agent khusus untuk penyelidikan, browser, coding, dokumen, fail serta produktiviti.

Ciri utama:

- Provider dan model sendiri, termasuk Xiaomi MiMo serta Custom Provider.
- Base URL, API key dan ujian sambungan.
- Chat multi-agent dan Orchestrator.
- DuckDuckGo Search dan browser WebView kelihatan.
- Fail, memori dan terminal dalam workspace aplikasi.
- Skills, skrip sandbox dan MCP local.
- Automasi background melalui WorkManager.
- Data serta permission disimpan local.
- Approval hanya untuk tindakan yang boleh memadam atau menimpa data.

API key disimpan menggunakan secure storage Android. Kandungan dihantar terus kepada provider atau laman yang anda pilih. Ai MultiAgent tidak menggunakan Accessibility Service.

**Nota penerbit:** Tambah alamat sokongan dan URL Polisi Privasi sebelum dihantar ke Google Play.
