# Flutter engine and plugins are automatically configured by Flutter Gradle.
-keep class io.flutter.** { *; }
-dontwarn io.flutter.embedding.**
