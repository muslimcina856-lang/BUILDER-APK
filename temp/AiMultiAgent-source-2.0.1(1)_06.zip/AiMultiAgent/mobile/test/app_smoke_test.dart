import 'package:ai_multiagent/src/data/provider_catalog.dart';
import 'package:ai_multiagent/src/services/local_database.dart';
import 'package:ai_multiagent/src/services/tool_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('katalog mempunyai Xiaomi MiMo, local dan provider custom', () {
    expect(ProviderCatalog.presets.any((item) => item.id == 'mimo'), isTrue);
    expect(ProviderCatalog.presets.any((item) => item.id == 'custom_rest'), isTrue);
    expect(ProviderCatalog.presets.any((item) => item.id == 'ollama'), isTrue);
  });

  test('hanya tindakan berisiko meminta kelulusan', () async {
    final engine = ToolEngine(LocalDatabase());
    expect(await engine.requiresPermission('web_search', const <String, dynamic>{'query': 'test'}), isFalse);
    expect(await engine.requiresPermission('browser_submit_form', const <String, dynamic>{'selector': 'form'}), isFalse);
    expect(await engine.requiresPermission('memory_delete', const <String, dynamic>{'id': '1'}), isTrue);
    expect(await engine.requiresPermission('http_request', const <String, dynamic>{'method': 'GET', 'url': 'https://example.com'}), isFalse);
    expect(await engine.requiresPermission('http_request', const <String, dynamic>{'method': 'DELETE', 'url': 'https://example.com'}), isTrue);
    engine.dispose();
  });
}
