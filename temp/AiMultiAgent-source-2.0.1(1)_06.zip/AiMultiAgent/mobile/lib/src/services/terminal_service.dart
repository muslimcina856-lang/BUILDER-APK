import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';

class TerminalJob {
  TerminalJob({
    required this.id,
    required this.command,
    required this.workingDirectory,
    required this.startedAt,
    required this.process,
  });

  final String id;
  final String command;
  final String workingDirectory;
  final DateTime startedAt;
  final Process process;
  final StringBuffer stdout = StringBuffer();
  final StringBuffer stderr = StringBuffer();
  int? exitCode;
  DateTime? finishedAt;

  bool get running => exitCode == null;

  Map<String, dynamic> snapshot() => <String, dynamic>{
        'job_id': id,
        'command': command,
        'working_directory': workingDirectory,
        'running': running,
        'exit_code': exitCode,
        'started_at': startedAt.toIso8601String(),
        'finished_at': finishedAt?.toIso8601String(),
        'stdout': _clip(stdout.toString()),
        'stderr': _clip(stderr.toString()),
      };

  static String _clip(String value) => value.length <= AppConfig.maxToolOutputChars
      ? value
      : value.substring(value.length - AppConfig.maxToolOutputChars);
}

class TerminalService {
  static const _uuid = Uuid();
  final Map<String, TerminalJob> _jobs = <String, TerminalJob>{};

  Iterable<TerminalJob> get jobs => _jobs.values;

  bool isDestructiveCommand(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    const destructivePatterns = <String>[
      ' rm ',
      'rm -',
      'rmdir ',
      'unlink ',
      'truncate ',
      'shred ',
      'dd if=',
      'mkfs',
      'format ',
      'reboot',
      'shutdown',
      'poweroff',
      'pm uninstall',
      'cmd package uninstall',
      'settings delete',
      'sqlite3 ',
      'drop table',
      'delete from',
      '> /',
      'chmod 000',
      'kill -9',
      'pkill ',
      'killall ',
    ];
    final padded = ' $normalized ';
    return destructivePatterns.any(padded.contains);
  }

  Future<ToolResult> start({
    required String command,
    String workingDirectory = '.',
    Map<String, String> environment = const <String, String>{},
  }) async {
    final text = command.trim();
    if (text.isEmpty) return const ToolResult(success: false, output: 'Arahan terminal kosong.');
    final root = await _workspace();
    final cwd = _safeDirectory(root, workingDirectory);
    await cwd.create(recursive: true);
    final shell = Platform.isAndroid ? '/system/bin/sh' : '/bin/sh';
    final process = await Process.start(
      shell,
      <String>['-c', text],
      workingDirectory: cwd.path,
      environment: <String, String>{
        'HOME': root.path,
        'TMPDIR': p.join(root.path, '.tmp'),
        'PATH': Platform.environment['PATH'] ?? '/system/bin:/system/xbin',
        'LANG': 'C.UTF-8',
        ...environment,
      },
      includeParentEnvironment: false,
      runInShell: false,
    );
    final job = TerminalJob(
      id: _uuid.v4(),
      command: text,
      workingDirectory: p.relative(cwd.path, from: root.path),
      startedAt: DateTime.now(),
      process: process,
    );
    _jobs[job.id] = job;
    process.stdout.transform(utf8.decoder).listen(job.stdout.write);
    process.stderr.transform(utf8.decoder).listen(job.stderr.write);
    unawaited(process.exitCode.then((code) {
      job.exitCode = code;
      job.finishedAt = DateTime.now();
    }));
    return ToolResult(
      success: true,
      output: jsonEncode(job.snapshot()),
      data: job.snapshot(),
    );
  }

  Future<ToolResult> poll(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) return const ToolResult(success: false, output: 'Job terminal tidak ditemui.');
    final snapshot = job.snapshot();
    return ToolResult(
      success: job.exitCode == null || job.exitCode == 0,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> stop(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) return const ToolResult(success: false, output: 'Job terminal tidak ditemui.');
    if (!job.running) return poll(jobId);
    final stopped = job.process.kill(ProcessSignal.sigterm);
    if (!stopped) job.process.kill(ProcessSignal.sigkill);
    return ToolResult(success: true, output: 'Permintaan berhenti dihantar kepada job $jobId.');
  }

  Future<Directory> _workspace() async {
    final directory = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'workspace'));
    await directory.create(recursive: true);
    await Directory(p.join(directory.path, '.tmp')).create(recursive: true);
    return directory;
  }

  Directory _safeDirectory(Directory root, String relative) {
    final normalized = p.normalize(p.join(root.path, relative));
    if (normalized != root.path && !p.isWithin(root.path, normalized)) {
      throw const FileSystemException('Working directory di luar workspace tidak dibenarkan.');
    }
    return Directory(normalized);
  }

  void dispose() {
    for (final job in _jobs.values.where((item) => item.running)) {
      job.process.kill(ProcessSignal.sigterm);
    }
  }
}
