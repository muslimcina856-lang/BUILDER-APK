import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'local_database.dart';

class SkillService {
  SkillService(this.database, {http.Client? client}) : _client = client ?? http.Client();
  final LocalDatabase database;
  final http.Client _client;
  static const _uuid = Uuid();

  Future<List<SkillDefinition>> loadSkills() async {
    final values = await database.listObjects('skill');
    if (values.isEmpty) {
      final builtIns = _builtInSkills();
      for (final skill in builtIns) {
        await database.saveObject('skill', skill.id, skill.toJson());
      }
      return builtIns;
    }
    return values.map(SkillDefinition.fromJson).toList();
  }

  Future<SkillDefinition> importZip(String zipPath) async => importBytes(
        await File(zipPath).readAsBytes(),
        sourceLabel: zipPath,
      );

  Future<SkillDefinition> importUrl(String rawUrl) async {
    final uri = Uri.tryParse(rawUrl.trim());
    if (uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      throw const FormatException('URL skill tidak sah.');
    }
    final response = await _client.get(uri).timeout(AppConfig.defaultTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('Muat turun skill gagal: HTTP ${response.statusCode}.');
    }
    if (response.bodyBytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    return importBytes(response.bodyBytes, sourceLabel: uri.toString());
  }

  Future<SkillDefinition> importBytes(List<int> bytes, {required String sourceLabel}) async {
    if (bytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    final skillsRoot = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'skills'));
    await skillsRoot.create(recursive: true);
    final root = Directory(p.join(skillsRoot.path, _uuid.v4()));
    await root.create(recursive: true);

    var extractedBytes = 0;
    for (final entry in archive) {
      final normalizedName = p.normalize(entry.name.replaceAll('\\', '/'));
      if (normalizedName.startsWith('../') || p.isAbsolute(normalizedName)) continue;
      final target = p.normalize(p.join(root.path, normalizedName));
      if (!p.isWithin(root.path, target)) continue;
      if (entry.isFile) {
        final content = entry.content as List<int>;
        extractedBytes += content.length;
        if (extractedBytes > AppConfig.maxSkillArchiveBytes * 4) {
          await root.delete(recursive: true);
          throw const FileSystemException('Arkib skill mengembang melebihi had keselamatan.');
        }
        final output = File(target);
        await output.parent.create(recursive: true);
        await output.writeAsBytes(content, flush: true);
      } else {
        await Directory(target).create(recursive: true);
      }
    }

    final manifest = await _findManifest(root);
    if (manifest == null) {
      await root.delete(recursive: true);
      throw const FormatException('skill.json tidak ditemui dalam fail ZIP.');
    }
    final data = Map<String, dynamic>.from(jsonDecode(await manifest.readAsString()) as Map);
    final instructionFile = File(p.join(manifest.parent.path, data['instructionsFile']?.toString() ?? 'instructions.md'));
    final instructions = data['instructions']?.toString() ?? (await instructionFile.exists() ? await instructionFile.readAsString() : '');
    final skill = SkillDefinition(
      id: data['id']?.toString().trim().isNotEmpty == true ? data['id'].toString() : _uuid.v4(),
      name: data['name']?.toString() ?? 'Imported Skill',
      description: data['description']?.toString() ?? 'Dipasang daripada $sourceLabel',
      instructions: instructions,
      triggers: (data['triggers'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      toolIds: (data['tools'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      enabled: data['enabled'] as bool? ?? true,
      sourcePath: manifest.parent.path,
    );
    await database.saveObject('skill', skill.id, skill.toJson());
    return skill;
  }

  Future<String> prepareScriptSandbox(String skillId) async {
    final json = await database.getObject('skill', skillId);
    if (json == null) throw StateError('Skill $skillId tidak ditemui.');
    final skill = SkillDefinition.fromJson(json);
    if (skill.sourcePath.isEmpty) throw StateError('Skill ini tidak mempunyai folder skrip.');
    final source = Directory(skill.sourcePath);
    if (!await source.exists()) throw StateError('Folder skill tidak ditemui.');
    final appRoot = await getApplicationDocumentsDirectory();
    final allowedRoot = p.join(appRoot.path, 'skills');
    final normalizedSource = p.normalize(source.path);
    if (!p.isWithin(allowedRoot, normalizedSource)) throw const FileSystemException('Folder skill di luar sandbox aplikasi.');

    final workspace = Directory(p.join(appRoot.path, 'workspace', '.skill_runs', skillId));
    if (await workspace.exists()) await workspace.delete(recursive: true);
    await _copyDirectory(source, workspace);
    return p.relative(workspace.path, from: p.join(appRoot.path, 'workspace'));
  }

  Future<void> _copyDirectory(Directory source, Directory destination) async {
    await destination.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final target = p.join(destination.path, p.basename(entity.path));
      if (entity is Directory) {
        await _copyDirectory(entity, Directory(target));
      } else if (entity is File) {
        await entity.copy(target);
      }
    }
  }

  Future<File?> _findManifest(Directory root) async {
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File && p.basename(entity.path) == 'skill.json') return entity;
    }
    return null;
  }

  Future<void> save(SkillDefinition skill) => database.saveObject('skill', skill.id, skill.toJson());

  Future<void> delete(SkillDefinition skill) async {
    await database.deleteObject('skill', skill.id);
    if (skill.sourcePath.isNotEmpty) {
      final directory = Directory(skill.sourcePath);
      if (await directory.exists()) await directory.delete(recursive: true);
    }
  }

  List<SkillDefinition> _builtInSkills() => const <SkillDefinition>[
        SkillDefinition(
          id: 'web_research',
          name: 'Web Research',
          description: 'Mencari beberapa sumber, membuka halaman dan menghasilkan ringkasan bersumber.',
          instructions: 'Gunakan web_search dahulu. Buka hasil penting dalam browser visual, baca kandungan sebenar dan bandingkan sumber sebelum membuat kesimpulan.',
          triggers: <String>['cari', 'research', 'berita', 'terbaru', 'semak web'],
          toolIds: <String>['web_search', 'browser_open', 'browser_read', 'browser_click'],
        ),
        SkillDefinition(
          id: 'document_writer',
          name: 'Document Writer',
          description: 'Menyediakan teks dan menyimpan hasil ke fail tempatan.',
          instructions: 'Susun kandungan dengan tajuk yang jelas. Gunakan file_write selepas kandungan siap.',
          triggers: <String>['buat dokumen', 'simpan fail', 'laporan', 'tulis'],
          toolIds: <String>['file_write', 'file_read', 'file_list'],
        ),
        SkillDefinition(
          id: 'local_memory',
          name: 'Local Memory',
          description: 'Mencari dan menyimpan fakta pengguna dalam pangkalan data tempatan.',
          instructions: 'Gunakan memory_search sebelum menganggap sesuatu fakta peribadi. Simpan apabila pengguna meminta atau fakta jelas berguna.',
          triggers: <String>['ingat', 'memori', 'simpan fakta'],
          toolIds: <String>['memory_search', 'memory_add', 'memory_delete'],
        ),
        SkillDefinition(
          id: 'sandbox_automation',
          name: 'Sandbox Automation',
          description: 'Menjalankan skrip skill dan arahan terminal di workspace aplikasi.',
          instructions: 'Gunakan skill_run_script untuk skrip dalam pakej skill atau terminal_start untuk arahan workspace. Pantau hasil dengan terminal_poll.',
          triggers: <String>['jalankan skrip', 'terminal', 'automasi kod'],
          toolIds: <String>['skill_run_script', 'terminal_start', 'terminal_poll', 'terminal_stop'],
        ),
      ];

  void dispose() => _client.close();
}
