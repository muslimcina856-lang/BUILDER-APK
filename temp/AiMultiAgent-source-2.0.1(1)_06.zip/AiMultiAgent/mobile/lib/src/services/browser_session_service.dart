import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

class BrowserAction {
  BrowserAction({required this.type, required this.arguments}) : id = const Uuid().v4();
  final String id;
  final String type;
  final Map<String, dynamic> arguments;
}

typedef BrowserActionExecutor = Future<Map<String, dynamic>> Function(BrowserAction action);

class BrowserSessionService extends ChangeNotifier {
  String currentUrl = 'https://duckduckgo.com';
  String? requestedUrl;
  int requestSerial = 0;
  bool isVisible = false;
  BrowserActionExecutor? _executor;
  Completer<void>? _executorReady;

  void requestVisibleOpen(String url) {
    currentUrl = url;
    requestedUrl = url;
    requestSerial++;
    notifyListeners();
  }

  void updateUrl(String url) {
    currentUrl = url;
    notifyListeners();
  }

  void markVisible(bool value) {
    isVisible = value;
    notifyListeners();
  }

  void attachExecutor(BrowserActionExecutor executor) {
    _executor = executor;
    _executorReady?.complete();
    _executorReady = null;
    markVisible(true);
  }

  void detachExecutor(BrowserActionExecutor executor) {
    _executor = null;
    markVisible(false);
  }

  Future<Map<String, dynamic>> execute(
    BrowserAction action, {
    Duration timeout = const Duration(seconds: 60),
  }) async {
    if (_executor == null) {
      final url = action.arguments['url']?.toString();
      requestVisibleOpen(url?.isNotEmpty == true ? url! : currentUrl);
      _executorReady ??= Completer<void>();
      await _executorReady!.future.timeout(timeout);
    }
    final executor = _executor;
    if (executor == null) throw StateError('Browser visual belum tersedia.');
    return executor(action).timeout(timeout);
  }

  void consumeRequest() {
    requestedUrl = null;
  }
}
