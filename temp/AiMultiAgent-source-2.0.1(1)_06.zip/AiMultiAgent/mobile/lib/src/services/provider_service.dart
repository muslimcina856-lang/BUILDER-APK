import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';

class ProviderException implements Exception {
  ProviderException(this.message, {this.statusCode, this.body});
  final String message;
  final int? statusCode;
  final String? body;
  @override
  String toString() => message;
}

class ProviderService {
  ProviderService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  static const _uuid = Uuid();

  Future<ProviderTestResult> test(ProviderConfig config, String apiKey) async {
    final watch = Stopwatch()..start();
    try {
      var models = <String>[];
      try {
        models = await listModels(config, apiKey);
      } catch (_) {
        models = config.availableModels;
      }
      final chosenModel = config.model.isNotEmpty ? config.model : (models.isNotEmpty ? models.first : '');
      if (chosenModel.isEmpty) {
        throw ProviderException('Model belum dipilih dan provider tidak memulangkan senarai model.');
      }
      final turn = await complete(
        config: config,
        apiKey: apiKey,
        modelOverride: chosenModel,
        messages: <ChatMessage>[
          ChatMessage(id: _uuid.v4(), sessionId: 'test', role: MessageRole.user, content: 'Jawab tepat dengan perkataan OK.', createdAt: DateTime.now()),
        ],
        tools: const <ToolDefinition>[],
      );
      watch.stop();
      final ok = turn.text.trim().isNotEmpty;
      return ProviderTestResult(
        success: ok,
        message: ok ? 'Sambungan berjaya. Respons: ${turn.text.trim()}' : 'Provider tidak memulangkan teks.',
        latencyMs: watch.elapsedMilliseconds,
        models: models,
      );
    } catch (error) {
      watch.stop();
      return ProviderTestResult(success: false, message: error.toString(), latencyMs: watch.elapsedMilliseconds);
    }
  }

  Future<List<String>> listModels(ProviderConfig config, String apiKey) async {
    if (config.modelsPath.trim().isEmpty) return config.availableModels;
    final uri = _uri(config, config.modelsPath, apiKey: apiKey);
    final response = await _client
        .get(uri, headers: _headers(config, apiKey))
        .timeout(Duration(seconds: config.timeoutSeconds));
    _ensureSuccess(response);
    final body = jsonDecode(response.body);
    final values = <String>[];
    if (body is Map && body['data'] is List) {
      for (final item in body['data'] as List) {
        if (item is Map && item['id'] != null) values.add(item['id'].toString());
      }
    } else if (body is Map && body['models'] is List) {
      for (final item in body['models'] as List) {
        if (item is Map) {
          final name = item['name'] ?? item['id'] ?? item['model'];
          if (name != null) values.add(name.toString().replaceFirst('models/', ''));
        } else {
          values.add(item.toString());
        }
      }
    }
    values.sort();
    return values.toSet().toList();
  }

  Future<ModelTurn> complete({
    required ProviderConfig config,
    required String apiKey,
    required List<ChatMessage> messages,
    required List<ToolDefinition> tools,
    String? modelOverride,
  }) async {
    final model = modelOverride?.trim().isNotEmpty == true ? modelOverride!.trim() : config.model.trim();
    if (model.isEmpty) throw ProviderException('Model belum dipilih.');
    return switch (config.protocol) {
      ProviderProtocol.openAiChat => _openAiChat(config, apiKey, messages, tools, model),
      ProviderProtocol.openAiResponses => _openAiResponses(config, apiKey, messages, tools, model),
      ProviderProtocol.anthropic => _anthropic(config, apiKey, messages, tools, model),
      ProviderProtocol.gemini => _gemini(config, apiKey, messages, tools, model),
      ProviderProtocol.customRest => _customRest(config, apiKey, messages, tools, model),
    };
  }

  Future<ModelTurn> _openAiChat(ProviderConfig config, String apiKey, List<ChatMessage> messages, List<ToolDefinition> tools, String model) async {
    final payload = <String, dynamic>{
      'model': model,
      'messages': messages.map(_openAiMessage).toList(),
      'temperature': config.temperature,
      'max_tokens': config.maxTokens,
      'stream': false,
      if (tools.isNotEmpty && config.supportsTools) 'tools': tools.map((item) => item.toOpenAiJson()).toList(),
      if (tools.isNotEmpty && config.supportsTools) 'tool_choice': 'auto',
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final json = _decodeMap(response.body);
    final choices = json['choices'] as List?;
    if (choices == null || choices.isEmpty) throw ProviderException('Respons provider tiada choices.', body: response.body);
    final message = Map<String, dynamic>.from((choices.first as Map)['message'] as Map? ?? const <String, dynamic>{});
    final text = _contentToText(message['content']);
    final calls = <ToolCall>[];
    for (final raw in message['tool_calls'] as List? ?? const <dynamic>[]) {
      final item = Map<String, dynamic>.from(raw as Map);
      final function = Map<String, dynamic>.from(item['function'] as Map? ?? const <String, dynamic>{});
      calls.add(ToolCall(
        id: item['id']?.toString() ?? _uuid.v4(),
        name: function['name']?.toString() ?? '',
        arguments: _decodeArguments(function['arguments']),
      ));
    }
    return ModelTurn(text: text, toolCalls: calls, raw: json);
  }

  Future<ModelTurn> _openAiResponses(ProviderConfig config, String apiKey, List<ChatMessage> messages, List<ToolDefinition> tools, String model) async {
    final input = <Map<String, dynamic>>[];
    for (final message in messages) {
      if (message.role == MessageRole.tool) {
        input.add(<String, dynamic>{
          'type': 'function_call_output',
          'call_id': message.toolCallId,
          'output': message.content,
        });
      } else if (message.metadata['toolCalls'] is List) {
        for (final raw in message.metadata['toolCalls'] as List) {
          final call = Map<String, dynamic>.from(raw as Map);
          input.add(<String, dynamic>{
            'type': 'function_call',
            'call_id': call['id'],
            'name': call['name'],
            'arguments': jsonEncode(call['arguments'] ?? const <String, dynamic>{}),
          });
        }
      } else {
        input.add(<String, dynamic>{'role': message.role.name, 'content': message.content});
      }
    }
    final payload = <String, dynamic>{
      'model': model,
      'input': input,
      'temperature': config.temperature,
      'max_output_tokens': config.maxTokens,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map((item) => <String, dynamic>{
                  'type': 'function',
                  'name': item.id,
                  'description': item.description,
                  'parameters': item.parameters,
                })
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final json = _decodeMap(response.body);
    final output = json['output'] as List? ?? const <dynamic>[];
    final textParts = <String>[];
    final calls = <ToolCall>[];
    for (final raw in output) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (item['type'] == 'function_call') {
        calls.add(ToolCall(
          id: item['call_id']?.toString() ?? item['id']?.toString() ?? _uuid.v4(),
          name: item['name']?.toString() ?? '',
          arguments: _decodeArguments(item['arguments']),
        ));
      }
      final content = item['content'];
      if (content is List) {
        for (final block in content) {
          if (block is Map && (block['type'] == 'output_text' || block['type'] == 'text')) {
            textParts.add(block['text']?.toString() ?? '');
          }
        }
      }
    }
    final fallback = json['output_text']?.toString() ?? '';
    return ModelTurn(text: textParts.join('\n').trim().isEmpty ? fallback : textParts.join('\n'), toolCalls: calls, raw: json);
  }

  Future<ModelTurn> _anthropic(ProviderConfig config, String apiKey, List<ChatMessage> messages, List<ToolDefinition> tools, String model) async {
    final system = messages.where((item) => item.role == MessageRole.system).map((item) => item.content).join('\n\n');
    final anthropicMessages = <Map<String, dynamic>>[];
    for (final message in messages.where((item) => item.role != MessageRole.system)) {
      if (message.role == MessageRole.tool) {
        anthropicMessages.add(<String, dynamic>{
          'role': 'user',
          'content': <Map<String, dynamic>>[
            <String, dynamic>{'type': 'tool_result', 'tool_use_id': message.toolCallId, 'content': message.content},
          ],
        });
      } else if (message.metadata['toolCalls'] is List) {
        anthropicMessages.add(<String, dynamic>{
          'role': 'assistant',
          'content': (message.metadata['toolCalls'] as List)
              .map((raw) {
                final call = Map<String, dynamic>.from(raw as Map);
                return <String, dynamic>{'type': 'tool_use', 'id': call['id'], 'name': call['name'], 'input': call['arguments']};
              })
              .toList(),
        });
      } else {
        anthropicMessages.add(<String, dynamic>{'role': message.role == MessageRole.assistant ? 'assistant' : 'user', 'content': message.content});
      }
    }
    final payload = <String, dynamic>{
      'model': model,
      'max_tokens': config.maxTokens,
      'temperature': config.temperature,
      if (system.isNotEmpty) 'system': system,
      'messages': anthropicMessages,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map((item) => <String, dynamic>{'name': item.id, 'description': item.description, 'input_schema': item.parameters})
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final json = _decodeMap(response.body);
    final textParts = <String>[];
    final calls = <ToolCall>[];
    for (final raw in json['content'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (item['type'] == 'text') textParts.add(item['text']?.toString() ?? '');
      if (item['type'] == 'tool_use') {
        calls.add(ToolCall(
          id: item['id']?.toString() ?? _uuid.v4(),
          name: item['name']?.toString() ?? '',
          arguments: Map<String, dynamic>.from(item['input'] as Map? ?? const <String, dynamic>{}),
        ));
      }
    }
    return ModelTurn(text: textParts.join('\n'), toolCalls: calls, raw: json);
  }

  Future<ModelTurn> _gemini(ProviderConfig config, String apiKey, List<ChatMessage> messages, List<ToolDefinition> tools, String model) async {
    final system = messages.where((item) => item.role == MessageRole.system).map((item) => item.content).join('\n\n');
    final contents = <Map<String, dynamic>>[];
    for (final message in messages.where((item) => item.role != MessageRole.system)) {
      if (message.role == MessageRole.tool) {
        contents.add(<String, dynamic>{
          'role': 'user',
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{
              'functionResponse': <String, dynamic>{
                'name': message.name ?? 'tool',
                'response': _decodeArguments(message.content),
              }
            }
          ],
        });
      } else if (message.metadata['toolCalls'] is List) {
        contents.add(<String, dynamic>{
          'role': 'model',
          'parts': (message.metadata['toolCalls'] as List)
              .map((raw) {
                final call = Map<String, dynamic>.from(raw as Map);
                return <String, dynamic>{'functionCall': <String, dynamic>{'name': call['name'], 'args': call['arguments']}};
              })
              .toList(),
        });
      } else {
        contents.add(<String, dynamic>{
          'role': message.role == MessageRole.assistant ? 'model' : 'user',
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{'text': message.content}
          ],
        });
      }
    }
    final payload = <String, dynamic>{
      if (system.isNotEmpty)
        'systemInstruction': <String, dynamic>{
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{'text': system}
          ]
        },
      'contents': contents,
      'generationConfig': <String, dynamic>{'temperature': config.temperature, 'maxOutputTokens': config.maxTokens},
      if (tools.isNotEmpty && config.supportsTools)
        'tools': <Map<String, dynamic>>[
          <String, dynamic>{
            'functionDeclarations': tools
                .map((item) => <String, dynamic>{'name': item.id, 'description': item.description, 'parameters': item.parameters})
                .toList(),
          }
        ],
    };
    final path = config.chatPath.replaceAll('{model}', model);
    final response = await _post(config, apiKey, path, payload);
    final json = _decodeMap(response.body);
    final candidates = json['candidates'] as List?;
    if (candidates == null || candidates.isEmpty) throw ProviderException('Gemini tidak memulangkan candidate.', body: response.body);
    final content = Map<String, dynamic>.from((candidates.first as Map)['content'] as Map? ?? const <String, dynamic>{});
    final textParts = <String>[];
    final calls = <ToolCall>[];
    for (final raw in content['parts'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final part = Map<String, dynamic>.from(raw);
      if (part['text'] != null) textParts.add(part['text'].toString());
      if (part['functionCall'] is Map) {
        final call = Map<String, dynamic>.from(part['functionCall'] as Map);
        calls.add(ToolCall(
          id: _uuid.v4(),
          name: call['name']?.toString() ?? '',
          arguments: Map<String, dynamic>.from(call['args'] as Map? ?? const <String, dynamic>{}),
        ));
      }
    }
    return ModelTurn(text: textParts.join('\n'), toolCalls: calls, raw: json);
  }

  Future<ModelTurn> _customRest(ProviderConfig config, String apiKey, List<ChatMessage> messages, List<ToolDefinition> tools, String model) async {
    final template = config.customRequestTemplate.trim();
    final fallback = <String, dynamic>{
      'model': model,
      'messages': messages.map(_openAiMessage).toList(),
      'temperature': config.temperature,
      'max_tokens': config.maxTokens,
      if (tools.isNotEmpty) 'tools': tools.map((item) => item.toOpenAiJson()).toList(),
    };
    Map<String, dynamic> payload = fallback;
    if (template.isNotEmpty) {
      final replaced = template
          .replaceAll('{{model}}', jsonEncode(model))
          .replaceAll('{{messages}}', jsonEncode(messages.map(_openAiMessage).toList()))
          .replaceAll('{{tools}}', jsonEncode(tools.map((item) => item.toOpenAiJson()).toList()))
          .replaceAll('{{temperature}}', config.temperature.toString())
          .replaceAll('{{max_tokens}}', config.maxTokens.toString());
      payload = Map<String, dynamic>.from(jsonDecode(replaced) as Map);
    }
    final response = await _post(config, apiKey, config.chatPath.replaceAll('{model}', model), payload);
    final json = _decodeMap(response.body);
    final value = _readJsonPath(json, config.customResponsePath);
    return ModelTurn(text: value?.toString() ?? response.body, raw: json);
  }

  Map<String, dynamic> _openAiMessage(ChatMessage message) {
    if (message.role == MessageRole.tool) {
      return <String, dynamic>{
        'role': 'tool',
        'tool_call_id': message.toolCallId,
        'content': message.content,
      };
    }
    final map = <String, dynamic>{
      'role': message.role.name,
      'content': message.content,
    };
    if (message.name != null) map['name'] = message.name;
    if (message.metadata['toolCalls'] is List) {
      map['tool_calls'] = (message.metadata['toolCalls'] as List)
          .map((raw) {
            final call = Map<String, dynamic>.from(raw as Map);
            return <String, dynamic>{
              'id': call['id'],
              'type': 'function',
              'function': <String, dynamic>{'name': call['name'], 'arguments': jsonEncode(call['arguments'])},
            };
          })
          .toList();
    }
    return map;
  }

  Future<http.Response> _post(ProviderConfig config, String apiKey, String path, Map<String, dynamic> payload) async {
    final uri = _uri(config, path, apiKey: apiKey);
    final response = await _client
        .post(uri, headers: _headers(config, apiKey), body: jsonEncode(payload))
        .timeout(Duration(seconds: config.timeoutSeconds));
    _ensureSuccess(response);
    return response;
  }

  Uri _uri(ProviderConfig config, String path, {required String apiKey}) {
    final base = config.baseUrl.endsWith('/') ? config.baseUrl.substring(0, config.baseUrl.length - 1) : config.baseUrl;
    final normalizedPath = path.isEmpty || path.startsWith('/') ? path : '/$path';
    var uri = Uri.parse('$base$normalizedPath');
    if (config.authStyle == AuthStyle.queryParameter && apiKey.isNotEmpty) {
      uri = uri.replace(queryParameters: <String, String>{...uri.queryParameters, config.apiKeyHeader: apiKey});
    }
    return uri;
  }

  Map<String, String> _headers(ProviderConfig config, String apiKey) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      AppConfig.sessionHeader: AppConfig.appName,
      ...config.extraHeaders,
    };
    if (apiKey.isNotEmpty && config.authStyle != AuthStyle.none && config.authStyle != AuthStyle.queryParameter) {
      headers[config.apiKeyHeader] = '${config.apiKeyPrefix}$apiKey';
    }
    return headers;
  }

  void _ensureSuccess(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) return;
    String message = 'HTTP ${response.statusCode}';
    try {
      final body = jsonDecode(response.body);
      if (body is Map) {
        final error = body['error'];
        if (error is Map) message = error['message']?.toString() ?? message;
        if (error is String) message = error;
        message = body['message']?.toString() ?? message;
      }
    } catch (_) {}
    throw ProviderException(message, statusCode: response.statusCode, body: response.body);
  }

  Map<String, dynamic> _decodeMap(String body) {
    final decoded = jsonDecode(body);
    if (decoded is! Map) throw ProviderException('Respons bukan objek JSON.', body: body);
    return Map<String, dynamic>.from(decoded);
  }

  Map<String, dynamic> _decodeArguments(Object? raw) {
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is String) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      } catch (_) {
        return <String, dynamic>{'value': raw};
      }
    }
    return const <String, dynamic>{};
  }

  String _contentToText(Object? content) {
    if (content == null) return '';
    if (content is String) return content;
    if (content is List) {
      return content
          .map((part) {
            if (part is Map) return part['text']?.toString() ?? part['content']?.toString() ?? '';
            return part.toString();
          })
          .where((item) => item.isNotEmpty)
          .join('\n');
    }
    return content.toString();
  }

  Object? _readJsonPath(Object? root, String path) {
    Object? current = root;
    for (final part in path.split('.').where((item) => item.isNotEmpty)) {
      if (current is Map) {
        current = current[part];
      } else if (current is List) {
        final index = int.tryParse(part);
        if (index == null || index < 0 || index >= current.length) return null;
        current = current[index];
      } else {
        return null;
      }
    }
    return current;
  }

  void dispose() => _client.close();
}
