import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../models/app_models.dart';
import 'local_database.dart';
import 'permission_manager.dart';
import 'provider_service.dart';
import 'tool_engine.dart';

class RunControl {
  bool _cancelled = false;
  bool get cancelled => _cancelled;
  void cancel() => _cancelled = true;
}

class AgentRuntime {
  AgentRuntime({
    required this.providerService,
    required this.toolEngine,
    required this.permissionManager,
    required this.database,
  });

  final ProviderService providerService;
  final ToolEngine toolEngine;
  final PermissionManager permissionManager;
  final LocalDatabase database;
  static const _uuid = Uuid();

  Future<ChatMessage> run({
    required String sessionId,
    required ProviderConfig provider,
    required String apiKey,
    required AgentProfile agent,
    required List<SkillDefinition> skills,
    required List<ChatMessage> history,
    required String userInput,
    List<AgentProfile> agents = const <AgentProfile>[],
    List<ProviderConfig> providers = const <ProviderConfig>[],
    Future<String> Function(String providerId)? apiKeyResolver,
    RunControl? control,
    int depth = 0,
    void Function(RunStatus status, String detail)? onProgress,
  }) async {
    final runControl = control ?? RunControl();
    final selectedTools = _selectTools(agent, skills);
    if (agent.id == 'orchestrator') {
      selectedTools.add(_delegateAgentDefinition(agents.where((item) => item.enabled && item.id != agent.id).toList()));
    }
    final activeSkills = _selectSkills(agent, skills, userInput);
    final messages = <ChatMessage>[
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.system,
        content: _systemPrompt(agent, activeSkills, selectedTools),
        createdAt: DateTime.now(),
      ),
      ...history.where((message) => message.role != MessageRole.system),
      ChatMessage(id: _uuid.v4(), sessionId: sessionId, role: MessageRole.user, content: userInput, createdAt: DateTime.now()),
    ];

    var step = 0;
    while (!runControl.cancelled) {
      onProgress?.call(
        step == 0 ? RunStatus.planning : RunStatus.runningTool,
        step == 0 ? '${agent.name} sedang merancang tindakan…' : '${agent.name} sedang memproses hasil tool…',
      );
      final turn = await providerService.complete(
        config: provider,
        apiKey: apiKey,
        messages: messages,
        tools: selectedTools,
        modelOverride: agent.modelOverride,
      );
      if (runControl.cancelled) break;
      if (turn.toolCalls.isEmpty) {
        final finalText = turn.text.trim().isEmpty ? 'Model tidak memulangkan jawapan teks.' : turn.text.trim();
        onProgress?.call(RunStatus.completed, '${agent.name} selesai');
        return ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: finalText,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'agentId': agent.id,
            'providerId': provider.id,
            'model': agent.modelOverride ?? provider.model,
            'steps': step + 1,
            'delegationDepth': depth,
          },
        );
      }

      messages.add(ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.assistant,
        content: turn.text,
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          'toolCalls': turn.toolCalls
              .map((call) => <String, dynamic>{'id': call.id, 'name': call.name, 'arguments': call.arguments})
              .toList(),
        },
      ));

      for (final call in turn.toolCalls) {
        if (runControl.cancelled) break;
        final definition = call.name == 'delegate_agent'
            ? selectedTools.where((item) => item.id == 'delegate_agent').firstOrNull
            : toolEngine.definition(call.name);
        if (definition == null || !selectedTools.any((item) => item.id == call.name)) {
          messages.add(_toolMessage(sessionId, call, ToolResult(success: false, output: 'Tool ${call.name} tidak tersedia untuk agent ini.')));
          continue;
        }

        if (call.name == 'delegate_agent') {
          onProgress?.call(RunStatus.runningTool, '${agent.name} menyerahkan subtugas kepada sub-agent…');
          final result = await _delegate(
            sessionId: sessionId,
            call: call,
            currentProvider: provider,
            currentApiKey: apiKey,
            agents: agents,
            providers: providers,
            skills: skills,
            apiKeyResolver: apiKeyResolver,
            control: runControl,
            depth: depth,
            onProgress: onProgress,
          );
          messages.add(_toolMessage(sessionId, call, result));
          await _logTool(
            sessionId: sessionId,
            toolId: call.name,
            scope: call.arguments['agent_id']?.toString() ?? 'sub-agent',
            result: result,
          );
          continue;
        }

        final scope = toolEngine.permissionScope(call.name, call.arguments);
        if (await toolEngine.requiresPermission(call.name, call.arguments)) {
          onProgress?.call(RunStatus.waitingPermission, 'Menunggu kelulusan untuk ${definition.name}…');
          final decision = await permissionManager.request(
            tool: definition,
            scope: scope,
            description: toolEngine.permissionDescription(call.name, call.arguments),
          );
          if (decision == PermissionDecision.deny) {
            final denied = const ToolResult(success: false, output: 'Pengguna menolak kebenaran untuk tindakan ini.');
            messages.add(_toolMessage(sessionId, call, denied));
            await _logTool(sessionId: sessionId, toolId: call.name, scope: scope, result: denied);
            continue;
          }
        }
        onProgress?.call(RunStatus.runningTool, 'Menjalankan ${definition.name}…');
        final result = await toolEngine.execute(call.name, call.arguments);
        messages.add(_toolMessage(sessionId, call, result));
        await _logTool(sessionId: sessionId, toolId: call.name, scope: scope, result: result);
      }
      step++;
    }

    onProgress?.call(RunStatus.cancelled, '${agent.name} dihentikan oleh pengguna.');
    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.assistant,
      content: 'Tugasan dihentikan. Hasil tool yang telah selesai kekal dalam log local.',
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{'cancelled': true, 'steps': step},
    );
  }

  Future<ToolResult> _delegate({
    required String sessionId,
    required ToolCall call,
    required ProviderConfig currentProvider,
    required String currentApiKey,
    required List<AgentProfile> agents,
    required List<ProviderConfig> providers,
    required List<SkillDefinition> skills,
    required Future<String> Function(String providerId)? apiKeyResolver,
    required RunControl control,
    required int depth,
    void Function(RunStatus status, String detail)? onProgress,
  }) async {
    final agentId = call.arguments['agent_id']?.toString() ?? '';
    final task = call.arguments['task']?.toString().trim() ?? '';
    if (task.isEmpty) return const ToolResult(success: false, output: 'Subtugas kosong.');
    final target = agents.where((item) => item.id == agentId && item.enabled).firstOrNull;
    if (target == null) return ToolResult(success: false, output: 'Agent $agentId tidak ditemui atau tidak aktif.');

    // Model tidak memilih provider secara bebas. Provider sub-agent datang hanya
    // daripada konfigurasi yang pengguna tetapkan pada profil agent tersebut.
    ProviderConfig targetProvider = currentProvider;
    if (target.providerId?.isNotEmpty == true) {
      targetProvider = providers.where((item) => item.id == target.providerId).firstOrNull ?? currentProvider;
    }
    var targetKey = currentApiKey;
    if (targetProvider.id != currentProvider.id && apiKeyResolver != null) {
      targetKey = await apiKeyResolver(targetProvider.id);
    }
    if (targetProvider.authStyle != AuthStyle.none && targetKey.isEmpty) {
      return ToolResult(success: false, output: 'API key untuk provider ${targetProvider.name} belum disimpan.');
    }

    onProgress?.call(RunStatus.runningTool, '${target.name} sedang menjalankan subtugas…');
    final response = await run(
      sessionId: '$sessionId/${target.id}/${_uuid.v4()}',
      provider: targetProvider,
      apiKey: targetKey,
      agent: target,
      agents: agents,
      providers: providers,
      apiKeyResolver: apiKeyResolver,
      skills: skills,
      history: const <ChatMessage>[],
      userInput: task,
      control: control,
      depth: depth + 1,
      onProgress: onProgress,
    );
    return ToolResult(
      success: !control.cancelled,
      output: response.content,
      data: <String, dynamic>{
        'agent_id': target.id,
        'agent_name': target.name,
        'provider_id': targetProvider.id,
        'model': target.modelOverride ?? targetProvider.model,
        'depth': depth + 1,
      },
    );
  }

  Future<void> _logTool({
    required String sessionId,
    required String toolId,
    required String scope,
    required ToolResult result,
  }) async {
    await database.logTool(
      sessionId: sessionId,
      toolId: toolId,
      scope: scope,
      success: result.success,
      summary: _redactedSummary(result.output),
    );
  }

  String _redactedSummary(String value) {
    var text = value
        .replaceAll(RegExp(r'(api[_-]?key|authorization|token|secret|password)["\s:=]+[^,\s"}]+', caseSensitive: false), r'$1=[REDACTED]')
        .replaceAll(RegExp(r'bearer\s+[A-Za-z0-9._~+/-]+=*', caseSensitive: false), 'Bearer [REDACTED]');
    if (text.length > 1200) text = '${text.substring(0, 1200)}…';
    return text;
  }

  ToolDefinition _delegateAgentDefinition(List<AgentProfile> agents) => ToolDefinition(
        id: 'delegate_agent',
        name: 'Delegasi Sub-Agent',
        category: 'Multi-Agent',
        risk: ToolRisk.readOnly,
        description: 'Serahkan subtugas kepada agent khusus. Aplikasi tidak mengenakan had bilangan atau kedalaman sub-agent.',
        parameters: <String, dynamic>{
          'type': 'object',
          'properties': <String, dynamic>{
            'agent_id': <String, dynamic>{
              'type': 'string',
              if (agents.isNotEmpty) 'enum': agents.map((item) => item.id).toList(),
              'description': agents.map((item) => '${item.id}: ${item.description}').join(' | '),
            },
            'task': <String, dynamic>{'type': 'string', 'description': 'Subtugas lengkap yang boleh dilaksanakan secara bebas.'},
          },
          'required': <String>['agent_id', 'task'],
        },
      );

  ChatMessage _toolMessage(String sessionId, ToolCall call, ToolResult result) => ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.tool,
        name: call.name,
        toolCallId: call.id,
        content: result.toModelText(),
        createdAt: DateTime.now(),
      );

  List<ToolDefinition> _selectTools(AgentProfile agent, List<SkillDefinition> skills) {
    final ids = <String>{...agent.toolIds};
    for (final skill in skills.where((item) => item.enabled && agent.skillIds.contains(item.id))) {
      ids.addAll(skill.toolIds);
    }
    if (ids.isEmpty) return <ToolDefinition>[...toolEngine.definitions];
    return toolEngine.definitions.where((item) => ids.contains(item.id)).toList();
  }

  List<SkillDefinition> _selectSkills(AgentProfile agent, List<SkillDefinition> skills, String input) {
    final lower = input.toLowerCase();
    return skills.where((skill) {
      if (!skill.enabled) return false;
      if (agent.skillIds.contains(skill.id)) return true;
      return skill.triggers.any((trigger) => lower.contains(trigger.toLowerCase()));
    }).toList();
  }

  String _systemPrompt(AgentProfile agent, List<SkillDefinition> skills, List<ToolDefinition> tools) {
    final skillText = skills.isEmpty
        ? 'Tiada skill tambahan aktif.'
        : skills.map((skill) => 'SKILL ${skill.name}:\n${skill.instructions}').join('\n\n');
    final toolNames = tools.map((item) => item.id).join(', ');
    return '''
Anda ialah ${agent.name} dalam aplikasi Ai MultiAgent.

Peranan agent:
${agent.systemPrompt}

Arahan operasi teknikal:
- Jawab dalam bahasa pengguna kecuali pengguna meminta bahasa lain.
- Gunakan tool apabila diperlukan dan gunakan hasil sebenar yang dipulangkan.
- Untuk carian web gunakan web_search, kemudian buka sumber penting dalam browser visual.
- Gunakan terminal_start untuk proses latar belakang dan terminal_poll untuk membaca hasilnya.
- Jika delegate_agent tersedia, pecahkan tugas kompleks dan gabungkan hasil sub-agent.
- Provider hanya ditentukan oleh tetapan pengguna pada agent; jangan cuba menukar provider.
- Kebenaran tindakan berisiko dikendalikan oleh aplikasi.
- Berikan jawapan akhir selepas tugasan selesai atau apabila pengguna menghentikannya.

Tools tersedia: $toolNames

$skillText
'''.trim();
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}
