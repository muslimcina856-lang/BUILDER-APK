abstract final class AppConfig {
  static const String appName = 'Ai MultiAgent';
  static const String packageName = 'com.aiauto.claw';
  static const String version = '2.0.1';

  /// Tiada had token atau sub-agent buatan aplikasi. Provider, Android dan
  /// sumber peranti masih boleh mengenakan had teknikal mereka sendiri.
  static const int maxAgentSteps = 0;
  static const int maxAgentDepth = 0;
  static const int maxSearchResults = 20;
  static const Duration defaultTimeout = Duration(seconds: 60);
  static const Duration sessionInactivityTimeout = Duration(minutes: 30);
  static const Duration terminalDefaultTimeout = Duration(seconds: 120);
  static const int maxToolOutputChars = 48000;
  static const int maxDownloadBytes = 100 * 1024 * 1024;
  static const int maxSkillArchiveBytes = 50 * 1024 * 1024;
  static const String sessionHeader = 'X-Ai-MultiAgent';
}
