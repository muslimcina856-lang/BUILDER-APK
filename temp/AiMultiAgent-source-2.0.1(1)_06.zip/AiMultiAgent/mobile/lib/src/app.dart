import 'package:flutter/material.dart';

import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'ui/home_shell.dart';

class AiMultiAgentBootstrap extends StatefulWidget {
  const AiMultiAgentBootstrap({super.key});

  @override
  State<AiMultiAgentBootstrap> createState() => _AiMultiAgentBootstrapState();
}

class _AiMultiAgentBootstrapState extends State<AiMultiAgentBootstrap> {
  late final AppState state;

  @override
  void initState() {
    super.initState();
    state = AppState();
    state.initialize();
  }

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      notifier: state,
      child: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: (_) => state.recordActivity(),
        onPointerSignal: (_) => state.recordActivity(),
        child: MaterialApp(
          title: 'Ai MultiAgent',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.dark(),
          home: AnimatedBuilder(
            animation: state,
            builder: (context, _) {
              if (!state.initialized) {
                return const Scaffold(body: Center(child: CircularProgressIndicator()));
              }
              return const HomeShell();
            },
          ),
        ),
      ),
    );
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({required AppState notifier, required super.child, super.key}) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope tidak ditemui.');
    return scope!.notifier!;
  }
}
