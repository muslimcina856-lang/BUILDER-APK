import 'package:flutter/material.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../theme/app_theme.dart';
import 'browser_screen.dart';
import 'memory_screen.dart';
import 'mcp_servers_screen.dart';
import 'settings_screen.dart';
import 'skills_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Lain-lain')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
          children: <Widget>[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: <Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset('assets/images/app_icon.png', width: 62, height: 62),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(AppConfig.appName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                          SizedBox(height: 3),
                          Text('Local • BYOK • Multi-provider • Multi-agent'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            _MoreTile(
              icon: Icons.extension_rounded,
              title: 'Skills',
              subtitle: '${state.skills.length} skill tersedia',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SkillsScreen())),
            ),
            _MoreTile(
              icon: Icons.psychology_alt_rounded,
              title: 'Memori Local',
              subtitle: 'Lihat, tambah dan padam fakta yang disimpan',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const MemoryScreen())),
            ),
            _MoreTile(
              icon: Icons.hub_rounded,
              title: 'MCP Local',
              subtitle: '${state.mcpServers.length} server local dikonfigurasi',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const McpServersScreen())),
            ),
            _MoreTile(
              icon: Icons.public_rounded,
              title: 'Browser Visual',
              subtitle: 'WebView local dengan JavaScript dan cookies peranti',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const BrowserScreen())),
            ),
            _MoreTile(
              icon: Icons.security_rounded,
              title: 'Tetapan & Kebenaran',
              subtitle: '${state.permissionRules.length} peraturan kelulusan kekal',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                'Ai MultiAgent tidak memerlukan akaun atau backend milik aplikasi. Data, chat, konfigurasi, skills dan API key kekal pada peranti kecuali kandungan yang dihantar terus kepada provider atau laman web yang dipilih.',
                style: TextStyle(color: Colors.white54, fontSize: 12.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppTheme.purple.withValues(alpha: .14),
          child: Icon(icon, color: AppTheme.purpleLight),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}
