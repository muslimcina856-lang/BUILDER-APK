import 'package:flutter/material.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';
import 'tool_logs_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const Set<String> _riskCapableTools = <String>{
    'file_write',
    'file_copy',
    'file_move',
    'file_delete',
    'memory_delete',
    'terminal_start',
    'http_request',
    'mcp_call',
  };

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final approvalTools = state.toolEngine.definitions.where((tool) => _riskCapableTools.contains(tool.id)).toList();
    final scopedRules = state.permissionRules.where((rule) => rule.scope != '*' && rule.toolId != '*').toList();
    final globalAllowed = state.permissionManager.policyFor('*', '*') == PermissionPolicy.alwaysAllow;

    return Scaffold(
      appBar: AppBar(title: const Text('Tetapan & Kebenaran')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 40),
        children: <Widget>[
          const _SectionTitle('Kelulusan tindakan berisiko'),
          Card(
            child: SwitchListTile.adaptive(
              value: globalAllowed,
              onChanged: (value) => state.setGlobalRiskPermission(value ? PermissionPolicy.alwaysAllow : PermissionPolicy.ask),
              secondary: Icon(Icons.verified_user_outlined, color: globalAllowed ? AppTheme.success : Colors.amber),
              title: const Text('Sentiasa benarkan semua tindakan berisiko', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('Disimpan local merentas sesi. Gunakan hanya apabila anda benar-benar mempercayai agent, skills dan MCP.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(state.sessionAllowsAllRisky ? Icons.check_circle_rounded : Icons.timer_outlined, color: state.sessionAllowsAllRisky ? AppTheme.success : AppTheme.purpleLight),
              title: const Text('Kebenaran sesi semasa'),
              subtitle: Text(state.sessionAllowsAllRisky ? 'Semua tindakan berisiko dibenarkan hingga sesi tamat.' : 'Tiada kelulusan menyeluruh untuk sesi ini.'),
              trailing: state.sessionAllowsAllRisky
                  ? TextButton(onPressed: state.permissionManager.clearSessionPermissions, child: const Text('Tarik balik'))
                  : null,
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 4, 4, 10),
            child: Text(
              'Carian, bacaan web, klik, isi dan hantar borang, muat turun, fail baharu, memori baharu, skills dan tool biasa berjalan tanpa dialog. Kelulusan hanya dinilai apabila operasi boleh memadam atau menimpa data.',
              style: TextStyle(color: Colors.white60),
            ),
          ),
          ...approvalTools.map((tool) {
            final allowed = state.permissionManager.policyFor(tool.id, '*') == PermissionPolicy.alwaysAllow;
            return Card(
              child: SwitchListTile.adaptive(
                value: allowed,
                onChanged: (value) => state.setToolPermission(tool.id, value ? PermissionPolicy.alwaysAllow : PermissionPolicy.ask),
                secondary: Icon(tool.risk == ToolRisk.sensitive ? Icons.delete_forever_outlined : Icons.warning_amber_rounded, color: allowed ? AppTheme.success : Colors.amber),
                title: Text(tool.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(tool.description),
              ),
            );
          }),
          if (scopedRules.isNotEmpty) ...<Widget>[
            const SizedBox(height: 18),
            const _SectionTitle('Kelulusan mengikut sasaran'),
            ...scopedRules.map((rule) {
              final tool = state.toolEngine.definition(rule.toolId);
              return Card(
                child: ListTile(
                  leading: Icon(rule.policy == PermissionPolicy.alwaysAllow ? Icons.check_circle_outline_rounded : Icons.block_rounded),
                  title: Text(tool?.name ?? rule.toolId),
                  subtitle: Text('${rule.scope} • ${_policyLabel(rule.policy)}'),
                  trailing: IconButton(
                    tooltip: 'Tarik balik',
                    onPressed: () => state.revokePermission(rule.id),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ),
              );
            }),
          ],
          const SizedBox(height: 18),
          const _SectionTitle('Sesi dan latar belakang'),
          Card(
            child: SwitchListTile.adaptive(
              value: state.backgroundExecutionAllowed,
              onChanged: state.setBackgroundExecutionAllowed,
              secondary: const Icon(Icons.sync_rounded, color: AppTheme.purpleLight),
              title: const Text('Benarkan tugas latar belakang'),
              subtitle: const Text('Automasi WorkManager boleh berjalan selepas UI ditutup. Tugasan panjang menggunakan notifikasi/foreground execution mengikut keperluan Android.'),
            ),
          ),
          const Card(
            child: ListTile(
              leading: Icon(Icons.timer_outlined, color: AppTheme.purpleLight),
              title: Text('Sesi tamat selepas 30 minit'),
              subtitle: Text('Kebenaran “sesi ini” dikosongkan selepas 30 minit tanpa aktiviti. Pada proses aplikasi baharu, sesi turut ditamatkan jika latar belakang tidak dibenarkan.'),
            ),
          ),
          const Card(
            child: ListTile(
              leading: Icon(Icons.accessibility_new_rounded, color: AppTheme.success),
              title: Text('Tiada Accessibility Service'),
              subtitle: Text('Versi Google Play menggunakan API rasmi, WebView, WorkManager dan sandbox aplikasi sahaja.'),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Audit local'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.receipt_long_outlined, color: AppTheme.purpleLight),
              title: const Text('Log tool'),
              subtitle: const Text('Metadata dan ringkasan disimpan local; token, kata laluan dan API key ditapis daripada ringkasan.'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ToolLogsScreen())),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Privasi dan data local'),
          const Card(
            child: ListTile(
              leading: Icon(Icons.key_rounded, color: AppTheme.purpleLight),
              title: Text('API key dalam secure storage'),
              subtitle: Text('API key tidak disimpan bersama chat atau konfigurasi SQLite.'),
            ),
          ),
          const Card(
            child: ListTile(
              leading: Icon(Icons.cloud_off_rounded, color: AppTheme.purpleLight),
              title: Text('Tiada backend Ai MultiAgent'),
              subtitle: Text('Permintaan dihantar terus kepada Base URL provider yang dipilih.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.delete_sweep_outlined, color: AppTheme.danger),
              title: const Text('Padam semua data local'),
              subtitle: const Text('Provider, API key, chat, memori, skills, automasi, MCP dan kebenaran akan dipadam.'),
              onTap: () => _deleteAll(context),
            ),
          ),
          const SizedBox(height: 18),
          const _SectionTitle('Tentang aplikasi'),
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline_rounded),
              title: Text(AppConfig.appName),
              subtitle: Text('${AppConfig.packageName}\nVersi ${AppConfig.version}\nLocal BYOK multi-provider agent client'),
              isThreeLine: true,
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(6, 12, 6, 0),
            child: Text(
              'Prompt sistem hanya menerangkan peranan agent, skills, provider yang pengguna tetapkan dan format penggunaan tools. Tiada prompt sekatan topik tambahan daripada aplikasi.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  static String _policyLabel(PermissionPolicy policy) => switch (policy) {
        PermissionPolicy.ask => 'Tanya jika berisiko',
        PermissionPolicy.alwaysAllow => 'Sentiasa benarkan',
        PermissionPolicy.alwaysDeny => 'Sentiasa tolak',
      };

  Future<void> _deleteAll(BuildContext context) async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            icon: const Icon(Icons.warning_amber_rounded, color: Colors.amber),
            title: const Text('Padam semua data?'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('Tindakan ini tidak boleh dipulihkan. Taip PADAM untuk meneruskan.'),
                const SizedBox(height: 12),
                TextField(controller: controller, decoration: const InputDecoration(labelText: 'Pengesahan')),
              ],
            ),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim().toUpperCase() == 'PADAM'), child: const Text('Padam semua')),
            ],
          ),
        ) ??
        false;
    controller.dispose();
    if (!confirmed || !context.mounted) return;
    await AppScope.of(context).deleteAllLocalData();
    if (context.mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Semua data local telah dipadam.')));
    }
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
        child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppTheme.purpleLight)),
      );
}
