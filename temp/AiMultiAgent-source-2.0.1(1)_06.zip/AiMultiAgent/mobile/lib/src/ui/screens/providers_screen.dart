import 'dart:convert';

import 'package:flutter/material.dart';

import '../../app.dart';
import '../../data/provider_catalog.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class ProvidersScreen extends StatelessWidget {
  const ProvidersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Provider AI'),
          actions: <Widget>[
            IconButton(
              tooltip: 'Tambah provider',
              onPressed: () => _addProvider(context),
              icon: const Icon(Icons.add_rounded),
            ),
          ],
        ),
        body: state.providers.isEmpty
            ? _EmptyProviders(onAdd: () => _addProvider(context))
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 96),
                itemCount: state.providers.length,
                itemBuilder: (context, index) {
                  final provider = state.providers[index];
                  final selected = provider.id == state.selectedProviderId;
                  return Card(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => ProviderEditorScreen(provider: provider)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: <Widget>[
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                color: AppTheme.purple.withValues(alpha: .14),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Icon(Icons.hub_rounded, color: AppTheme.purpleLight),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(child: Text(provider.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                                      if (selected) const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 19),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(provider.model.isEmpty ? 'Model belum dipilih' : provider.model, maxLines: 1, overflow: TextOverflow.ellipsis),
                                  const SizedBox(height: 5),
                                  Row(
                                    children: <Widget>[
                                      _TestStatus(status: provider.testStatus),
                                      if (provider.lastLatencyMs != null) ...<Widget>[
                                        const SizedBox(width: 8),
                                        Text('${provider.lastLatencyMs} ms', style: Theme.of(context).textTheme.bodySmall),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            PopupMenuButton<String>(
                              onSelected: (value) async {
                                if (value == 'select') await state.selectProvider(provider.id);
                                if (value == 'edit' && context.mounted) {
                                  await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ProviderEditorScreen(provider: provider)));
                                }
                                if (value == 'delete' && context.mounted) {
                                  final ok = await _confirmDelete(context, provider.name);
                                  if (ok) await state.deleteProvider(provider);
                                }
                              },
                              itemBuilder: (_) => const <PopupMenuEntry<String>>[
                                PopupMenuItem(value: 'select', child: Text('Jadikan aktif')),
                                PopupMenuItem(value: 'edit', child: Text('Edit')),
                                PopupMenuDivider(),
                                PopupMenuItem(value: 'delete', child: Text('Padam')),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _addProvider(context),
          icon: const Icon(Icons.add_rounded),
          label: const Text('Provider'),
        ),
      ),
    );
  }

  Future<void> _addProvider(BuildContext context) async {
    final preset = await showModalBottomSheet<ProviderPreset>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const _PresetPicker(),
    );
    if (preset == null || !context.mounted) return;
    final provider = AppScope.of(context).createProviderFromPreset(preset);
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => ProviderEditorScreen(provider: provider, isNew: true)),
    );
  }

  Future<bool> _confirmDelete(BuildContext context, String name) async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam provider?'),
            content: Text('Konfigurasi $name dan API key yang disimpan akan dipadam daripada peranti.'),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Padam')),
            ],
          ),
        ) ??
        false;
  }
}

class _EmptyProviders extends StatelessWidget {
  const _EmptyProviders({required this.onAdd});
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.key_rounded, size: 58, color: AppTheme.purpleLight),
            const SizedBox(height: 16),
            const Text('Sambungkan provider AI', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text(
              'Tiada login dan tiada backend Ai MultiAgent. API key disimpan secara terenkripsi pada peranti dan permintaan dihantar terus ke provider pilihan anda.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add_rounded), label: const Text('Tambah provider')),
          ],
        ),
      ),
    );
  }
}

class _TestStatus extends StatelessWidget {
  const _TestStatus({required this.status});
  final ProviderTestStatus status;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      ProviderTestStatus.success => ('Berjaya', AppTheme.success),
      ProviderTestStatus.failed => ('Gagal', AppTheme.danger),
      ProviderTestStatus.testing => ('Menguji', Colors.amber),
      ProviderTestStatus.untested => ('Belum diuji', Colors.white54),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(99)),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }
}

class _PresetPicker extends StatefulWidget {
  const _PresetPicker();

  @override
  State<_PresetPicker> createState() => _PresetPickerState();
}

class _PresetPickerState extends State<_PresetPicker> {
  final _search = TextEditingController();
  String query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final values = ProviderCatalog.presets.where((item) {
      final haystack = '${item.name} ${item.category}'.toLowerCase();
      return haystack.contains(query.toLowerCase());
    }).toList();
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: .86,
      maxChildSize: .96,
      minChildSize: .55,
      builder: (context, controller) => Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Column(
              children: <Widget>[
                Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(99))),
                const SizedBox(height: 14),
                const Row(
                  children: <Widget>[
                    Expanded(child: Text('Pilih provider', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _search,
                  onChanged: (value) => setState(() => query = value),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Cari OpenAI, MiMo, Ollama, Custom…'),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: controller,
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 24),
              itemCount: values.length,
              itemBuilder: (context, index) {
                final item = values[index];
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.hub_outlined)),
                  title: Text(item.name),
                  subtitle: Text('${item.category} • ${item.protocol.name}'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.pop(context, item),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ProviderEditorScreen extends StatefulWidget {
  const ProviderEditorScreen({required this.provider, this.isNew = false, super.key});
  final ProviderConfig provider;
  final bool isNew;

  @override
  State<ProviderEditorScreen> createState() => _ProviderEditorScreenState();
}

class _ProviderEditorScreenState extends State<ProviderEditorScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _baseUrl;
  late final TextEditingController _chatPath;
  late final TextEditingController _modelsPath;
  late final TextEditingController _apiKey;
  late final TextEditingController _model;
  late final TextEditingController _apiKeyHeader;
  late final TextEditingController _apiKeyPrefix;
  late final TextEditingController _headers;
  late final TextEditingController _customRequest;
  late final TextEditingController _customResponse;
  late ProviderProtocol _protocol;
  late AuthStyle _authStyle;
  late bool _supportsTools;
  late bool _supportsVision;
  late bool _supportsStreaming;
  late double _temperature;
  late int _maxTokens;
  late int _timeout;
  late List<String> _models;
  bool _busy = false;
  bool _hideKey = true;
  String _result = '';

  @override
  void initState() {
    super.initState();
    final p = widget.provider;
    _name = TextEditingController(text: p.name);
    _baseUrl = TextEditingController(text: p.baseUrl);
    _chatPath = TextEditingController(text: p.chatPath);
    _modelsPath = TextEditingController(text: p.modelsPath);
    _apiKey = TextEditingController();
    _model = TextEditingController(text: p.model);
    _apiKeyHeader = TextEditingController(text: p.apiKeyHeader);
    _apiKeyPrefix = TextEditingController(text: p.apiKeyPrefix);
    _headers = TextEditingController(text: const JsonEncoder.withIndent('  ').convert(p.extraHeaders));
    _customRequest = TextEditingController(text: p.customRequestTemplate);
    _customResponse = TextEditingController(text: p.customResponsePath);
    _protocol = p.protocol;
    _authStyle = p.authStyle;
    _supportsTools = p.supportsTools;
    _supportsVision = p.supportsVision;
    _supportsStreaming = p.supportsStreaming;
    _temperature = p.temperature;
    _maxTokens = p.maxTokens;
    _timeout = p.timeoutSeconds;
    _models = List<String>.from(p.availableModels);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final key = await AppScope.of(context).providerKey(p.id);
      if (mounted) setState(() => _apiKey.text = key);
    });
  }

  @override
  void dispose() {
    for (final controller in <TextEditingController>[_name, _baseUrl, _chatPath, _modelsPath, _apiKey, _model, _apiKeyHeader, _apiKeyPrefix, _headers, _customRequest, _customResponse]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew ? 'Tambah Provider' : 'Edit Provider'),
        actions: <Widget>[
          TextButton(onPressed: _busy ? null : _save, child: const Text('Simpan')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            _sectionTitle('Sambungan'),
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nama konfigurasi'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(
              controller: _baseUrl,
              decoration: const InputDecoration(labelText: 'Base URL', hintText: 'https://api.example.com/v1'),
              keyboardType: TextInputType.url,
              validator: (value) {
                final uri = Uri.tryParse(value?.trim() ?? '');
                return uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty ? 'Masukkan Base URL HTTP/HTTPS yang sah.' : null;
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<ProviderProtocol>(
              value: _protocol,
              decoration: const InputDecoration(labelText: 'Protokol API'),
              items: ProviderProtocol.values.map((item) => DropdownMenuItem(value: item, child: Text(_protocolLabel(item)))).toList(),
              onChanged: (value) => setState(() => _protocol = value ?? _protocol),
            ),
            const SizedBox(height: 10),
            TextFormField(controller: _chatPath, decoration: const InputDecoration(labelText: 'Chat endpoint', hintText: '/chat/completions'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(controller: _modelsPath, decoration: const InputDecoration(labelText: 'Models endpoint', hintText: '/models atau kosong')),
            const SizedBox(height: 14),
            _sectionTitle('API key dan autentikasi'),
            TextFormField(
              controller: _apiKey,
              obscureText: _hideKey,
              autocorrect: false,
              enableSuggestions: false,
              decoration: InputDecoration(
                labelText: _authStyle == AuthStyle.none ? 'API key (tidak diperlukan)' : 'API key',
                suffixIcon: IconButton(onPressed: () => setState(() => _hideKey = !_hideKey), icon: Icon(_hideKey ? Icons.visibility_outlined : Icons.visibility_off_outlined)),
              ),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<AuthStyle>(
              value: _authStyle,
              decoration: const InputDecoration(labelText: 'Kaedah autentikasi'),
              items: AuthStyle.values.map((item) => DropdownMenuItem(value: item, child: Text(_authLabel(item)))).toList(),
              onChanged: (value) => setState(() => _authStyle = value ?? _authStyle),
            ),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(child: TextFormField(controller: _apiKeyHeader, decoration: const InputDecoration(labelText: 'Nama header/query'))),
                const SizedBox(width: 8),
                Expanded(child: TextFormField(controller: _apiKeyPrefix, decoration: const InputDecoration(labelText: 'Prefix', hintText: 'Bearer '))),
              ],
            ),
            const SizedBox(height: 14),
            _sectionTitle('Model'),
            TextFormField(controller: _model, decoration: const InputDecoration(labelText: 'Model ID', hintText: 'Masukkan model secara manual'), validator: _required),
            if (_models.isNotEmpty) ...<Widget>[
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _models.contains(_model.text) ? _model.text : null,
                decoration: const InputDecoration(labelText: 'Model tersedia daripada provider'),
                items: _models.map((item) => DropdownMenuItem(value: item, child: Text(item, overflow: TextOverflow.ellipsis))).toList(),
                onChanged: (value) {
                  if (value != null) setState(() => _model.text = value);
                },
              ),
            ],
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : _refreshModels,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Muat model'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _test,
                    icon: const Icon(Icons.wifi_tethering_rounded),
                    label: const Text('Uji sambungan'),
                  ),
                ),
              ],
            ),
            if (_result.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppTheme.surfaceHigh, borderRadius: BorderRadius.circular(12)),
                child: Text(_result),
              ),
            ],
            const SizedBox(height: 16),
            _sectionTitle('Keupayaan dan parameter'),
            SwitchListTile.adaptive(value: _supportsTools, onChanged: (value) => setState(() => _supportsTools = value), title: const Text('Tool calling')),
            SwitchListTile.adaptive(value: _supportsVision, onChanged: (value) => setState(() => _supportsVision = value), title: const Text('Vision/imej')),
            SwitchListTile.adaptive(value: _supportsStreaming, onChanged: (value) => setState(() => _supportsStreaming = value), title: const Text('Streaming')),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Temperature: ${_temperature.toStringAsFixed(2)}'),
              subtitle: Slider(value: _temperature.clamp(0.0, 2.0).toDouble(), min: 0, max: 2, divisions: 40, onChanged: (value) => setState(() => _temperature = value)),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextFormField(
                    initialValue: _maxTokens.toString(),
                    decoration: const InputDecoration(labelText: 'Max tokens'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => _maxTokens = int.tryParse(value) ?? _maxTokens,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    initialValue: _timeout.toString(),
                    decoration: const InputDecoration(labelText: 'Timeout (saat)'),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => _timeout = int.tryParse(value) ?? _timeout,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('Tetapan lanjutan'),
              children: <Widget>[
                TextFormField(
                  controller: _headers,
                  minLines: 4,
                  maxLines: 10,
                  decoration: const InputDecoration(labelText: 'Custom headers (JSON)', alignLabelWithHint: true),
                  validator: _validateHeaders,
                ),
                const SizedBox(height: 10),
                if (_protocol == ProviderProtocol.customRest) ...<Widget>[
                  TextFormField(
                    controller: _customRequest,
                    minLines: 5,
                    maxLines: 14,
                    decoration: const InputDecoration(
                      labelText: 'Request template JSON',
                      hintText: '{"model": {{model}}, "messages": {{messages}}}',
                      alignLabelWithHint: true,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(controller: _customResponse, decoration: const InputDecoration(labelText: 'JSON path respons', hintText: 'choices.0.message.content')),
                ],
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Semua konfigurasi disimpan local. API key disimpan melalui Android Keystore/secure storage dan tidak dimasukkan ke database chat.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(top: 4, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppTheme.purpleLight)),
      );

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  String? _validateHeaders(String? value) {
    try {
      final decoded = jsonDecode(value?.trim().isEmpty == true ? '{}' : value!);
      if (decoded is! Map) return 'Headers mesti objek JSON.';
      return null;
    } catch (_) {
      return 'JSON headers tidak sah.';
    }
  }

  ProviderConfig? _draft() {
    if (!(_formKey.currentState?.validate() ?? false)) return null;
    final decoded = jsonDecode(_headers.text.trim().isEmpty ? '{}' : _headers.text) as Map;
    return widget.provider.copyWith(
      name: _name.text.trim(),
      protocol: _protocol,
      baseUrl: _baseUrl.text.trim(),
      chatPath: _chatPath.text.trim(),
      modelsPath: _modelsPath.text.trim(),
      authStyle: _authStyle,
      apiKeyHeader: _apiKeyHeader.text.trim(),
      apiKeyPrefix: _apiKeyPrefix.text,
      model: _model.text.trim(),
      extraHeaders: decoded.map((key, value) => MapEntry(key.toString(), value.toString())),
      availableModels: _models,
      temperature: _temperature,
      maxTokens: _maxTokens,
      timeoutSeconds: _timeout,
      supportsStreaming: _supportsStreaming,
      supportsTools: _supportsTools,
      supportsVision: _supportsVision,
      customRequestTemplate: _customRequest.text.trim(),
      customResponsePath: _customResponse.text.trim(),
    );
  }

  Future<void> _save() async {
    final provider = _draft();
    if (provider == null) return;
    setState(() {
      _busy = true;
      _result = 'Menyimpan dan menguji sambungan…';
    });
    final state = AppScope.of(context);
    final result = await state.testProvider(provider, _apiKey.text.trim());
    if (!mounted) return;
    _models = <String>{..._models, ...result.models}.toList()..sort();
    _result = '${result.success ? 'Berjaya' : 'Gagal'} • ${result.latencyMs} ms\n${result.message}';
    if (!result.success) {
      setState(() => _busy = false);
      final keep = await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              icon: const Icon(Icons.warning_amber_rounded, color: Colors.amber),
              title: const Text('Ujian sambungan gagal'),
              content: Text('${result.message}\n\nKonfigurasi dan keputusan ujian sudah disimpan local. Simpan provider ini untuk dibaiki atau digunakan apabila server kembali online?'),
              actions: <Widget>[
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Kekal di sini')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan juga')),
              ],
            ),
          ) ??
          false;
      if (!mounted || !keep) return;
    }
    if (mounted) Navigator.pop(context);
  }

  Future<void> _refreshModels() async {
    final provider = _draft();
    if (provider == null) return;
    setState(() {
      _busy = true;
      _result = 'Memuat senarai model…';
    });
    try {
      final values = await AppScope.of(context).refreshModels(provider, _apiKey.text.trim());
      if (!mounted) return;
      setState(() {
        _models = values;
        _result = values.isEmpty ? 'Provider tidak memulangkan model. Gunakan Model ID manual.' : '${values.length} model ditemui.';
      });
    } catch (error) {
      if (mounted) setState(() => _result = 'Gagal memuat model: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _test() async {
    final provider = _draft();
    if (provider == null) return;
    setState(() {
      _busy = true;
      _result = 'Menguji Base URL, API key dan model…';
    });
    final result = await AppScope.of(context).testProvider(provider, _apiKey.text.trim());
    if (!mounted) return;
    setState(() {
      _busy = false;
      _models = <String>{..._models, ...result.models}.toList()..sort();
      _result = '${result.success ? 'Berjaya' : 'Gagal'} • ${result.latencyMs} ms\n${result.message}';
    });
  }

  String _protocolLabel(ProviderProtocol value) => switch (value) {
        ProviderProtocol.openAiChat => 'OpenAI Chat Completions',
        ProviderProtocol.openAiResponses => 'OpenAI Responses',
        ProviderProtocol.anthropic => 'Anthropic Messages',
        ProviderProtocol.gemini => 'Google Gemini',
        ProviderProtocol.customRest => 'Custom REST JSON',
      };

  String _authLabel(AuthStyle value) => switch (value) {
        AuthStyle.bearer => 'Bearer token',
        AuthStyle.apiKeyHeader => 'API key header',
        AuthStyle.xApiKey => 'x-api-key',
        AuthStyle.queryParameter => 'Query parameter',
        AuthStyle.none => 'Tiada autentikasi',
      };
}
