import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class McpServersScreen extends StatelessWidget {
  const McpServersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('MCP Local'),
        actions: <Widget>[
          IconButton(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const McpServerEditorScreen())),
            icon: const Icon(Icons.add_rounded),
          ),
        ],
      ),
      body: state.mcpServers.isEmpty
          ? const Center(child: Text('Belum ada server MCP local.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
              itemCount: state.mcpServers.length,
              itemBuilder: (context, index) {
                final server = state.mcpServers[index];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppTheme.purple.withValues(alpha: .14),
                      child: Icon(server.enabled ? Icons.hub_rounded : Icons.hub_outlined, color: AppTheme.purpleLight),
                    ),
                    title: Text(server.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${server.baseUrl}\n${server.lastTestMessage.isEmpty ? 'Belum diuji' : server.lastTestMessage}'),
                    isThreeLine: true,
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => McpServerEditorScreen(server: server))),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const McpServerEditorScreen())),
        icon: const Icon(Icons.add_rounded),
        label: const Text('MCP'),
      ),
    );
  }
}

class McpServerEditorScreen extends StatefulWidget {
  const McpServerEditorScreen({super.key, this.server});
  final McpServerConfig? server;

  @override
  State<McpServerEditorScreen> createState() => _McpServerEditorScreenState();
}

class _McpServerEditorScreenState extends State<McpServerEditorScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _url;
  late final TextEditingController _headers;
  late McpTransport _transport;
  late bool _enabled;
  bool _testing = false;
  String _testMessage = '';

  @override
  void initState() {
    super.initState();
    final server = widget.server;
    _name = TextEditingController(text: server?.name ?? 'MCP Local');
    _url = TextEditingController(text: server?.baseUrl ?? 'http://127.0.0.1:3000/mcp');
    _headers = TextEditingController(text: const JsonEncoder.withIndent('  ').convert(server?.headers ?? const <String, String>{}));
    _transport = server?.transport ?? McpTransport.streamableHttp;
    _enabled = server?.enabled ?? true;
    _testMessage = server?.lastTestMessage ?? '';
  }

  @override
  void dispose() {
    _name.dispose();
    _url.dispose();
    _headers.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.server == null ? 'Tambah MCP Local' : 'Edit MCP Local'),
        actions: <Widget>[
          if (widget.server != null)
            IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded), tooltip: 'Padam'),
          IconButton(onPressed: _save, icon: const Icon(Icons.save_outlined), tooltip: 'Simpan'),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
          children: <Widget>[
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nama'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(
              controller: _url,
              decoration: const InputDecoration(labelText: 'Base URL MCP', helperText: 'Hanya localhost, 127.0.0.1, ::1 atau .local.'),
              keyboardType: TextInputType.url,
              validator: _required,
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<McpTransport>(
              value: _transport,
              decoration: const InputDecoration(labelText: 'Transport'),
              items: const <DropdownMenuItem<McpTransport>>[
                DropdownMenuItem(value: McpTransport.streamableHttp, child: Text('Streamable HTTP')),
                DropdownMenuItem(value: McpTransport.legacySse, child: Text('Legacy SSE melalui HTTP')),
              ],
              onChanged: (value) => setState(() => _transport = value ?? _transport),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _headers,
              minLines: 4,
              maxLines: 10,
              decoration: const InputDecoration(labelText: 'Headers JSON', hintText: '{"Authorization":"Bearer ..."}'),
              validator: (value) {
                try {
                  final decoded = jsonDecode(value?.trim().isEmpty == true ? '{}' : value!);
                  return decoded is Map ? null : 'Headers mesti objek JSON.';
                } catch (_) {
                  return 'JSON tidak sah.';
                }
              },
            ),
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, value: _enabled, onChanged: (value) => setState(() => _enabled = value), title: const Text('Aktif')),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: _testing ? null : _test,
              icon: _testing ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.cable_rounded),
              label: const Text('Uji MCP'),
            ),
            if (_testMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: SelectableText(_testMessage),
              ),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  McpServerConfig _value() {
    final decoded = Map<String, dynamic>.from(jsonDecode(_headers.text.trim().isEmpty ? '{}' : _headers.text) as Map);
    return McpServerConfig(
      id: widget.server?.id ?? const Uuid().v4(),
      name: _name.text.trim(),
      baseUrl: _url.text.trim(),
      transport: _transport,
      enabled: _enabled,
      headers: decoded.map((key, value) => MapEntry(key, value.toString())),
      lastTestMessage: _testMessage,
      lastTestAt: widget.server?.lastTestAt,
    );
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    await AppScope.of(context).saveMcpServer(_value());
    if (mounted) Navigator.pop(context);
  }

  Future<void> _test() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _testing = true;
      _testMessage = 'Menguji…';
    });
    try {
      final result = await AppScope.of(context).testMcpServer(_value());
      if (mounted) setState(() => _testMessage = const JsonEncoder.withIndent('  ').convert(result));
    } catch (error) {
      if (mounted) setState(() => _testMessage = 'Gagal: $error');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _delete() async {
    final server = widget.server;
    if (server == null) return;
    await AppScope.of(context).deleteMcpServer(server);
    if (mounted) Navigator.pop(context);
  }
}
