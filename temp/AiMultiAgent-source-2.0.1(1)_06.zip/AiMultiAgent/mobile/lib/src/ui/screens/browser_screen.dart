import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../app.dart';
import '../../services/browser_session_service.dart';

class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key, this.initialUrl});
  final String? initialUrl;

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> {
  late final WebViewController _controller;
  late final TextEditingController _url;
  BrowserSessionService? _session;
  bool _attached = false;
  bool _loading = true;
  double _progress = 0;
  Completer<void>? _pageLoaded;

  @override
  void initState() {
    super.initState();
    _url = TextEditingController(text: widget.initialUrl ?? 'https://duckduckgo.com');
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (value) {
            if (!mounted) return;
            setState(() {
              _loading = true;
              _url.text = value;
            });
            _session?.updateUrl(value);
          },
          onProgress: (value) {
            if (mounted) setState(() => _progress = value / 100);
          },
          onPageFinished: (value) {
            if (!mounted) return;
            setState(() {
              _loading = false;
              _progress = 1;
              _url.text = value;
            });
            _session?.updateUrl(value);
            final completer = _pageLoaded;
            if (completer != null && !completer.isCompleted) completer.complete();
          },
          onWebResourceError: (error) {
            final completer = _pageLoaded;
            if (completer != null && !completer.isCompleted && error.isForMainFrame == true) {
              completer.completeError(StateError(error.description));
            }
          },
        ),
      );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_attached) return;
    _attached = true;
    _session = AppScope.of(context).browserSession;
    _session!.attachExecutor(_executeAction);
    final initial = widget.initialUrl ?? _session!.requestedUrl ?? _session!.currentUrl;
    _session!.consumeRequest();
    _load(initial);
  }

  @override
  void dispose() {
    _session?.detachExecutor(_executeAction);
    _url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 8,
        title: TextField(
          controller: _url,
          keyboardType: TextInputType.url,
          textInputAction: TextInputAction.go,
          decoration: const InputDecoration(hintText: 'URL atau carian', isDense: true),
          onSubmitted: _go,
        ),
        actions: <Widget>[
          IconButton(onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh_rounded), tooltip: 'Muat semula'),
        ],
        bottom: _loading
            ? PreferredSize(
                preferredSize: const Size.fromHeight(2),
                child: LinearProgressIndicator(value: _progress == 0 ? null : _progress),
              )
            : null,
      ),
      body: WebViewWidget(controller: _controller),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            IconButton(
              onPressed: () async {
                if (await _controller.canGoBack()) await _controller.goBack();
              },
              icon: const Icon(Icons.arrow_back_rounded),
            ),
            IconButton(
              onPressed: () async {
                if (await _controller.canGoForward()) await _controller.goForward();
              },
              icon: const Icon(Icons.arrow_forward_rounded),
            ),
            IconButton(onPressed: () => _load('https://duckduckgo.com'), icon: const Icon(Icons.home_outlined)),
            IconButton(
              tooltip: 'Baca halaman untuk AI',
              onPressed: () async {
                final result = await _executeAction(BrowserAction(type: 'read', arguments: const <String, dynamic>{}));
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Halaman tersedia untuk AI: ${result['title'] ?? result['url'] ?? ''}')),
                  );
                }
              },
              icon: const Icon(Icons.visibility_outlined),
            ),
          ],
        ),
      ),
    );
  }

  Future<Map<String, dynamic>> _executeAction(BrowserAction action) async {
    switch (action.type) {
      case 'open':
        final url = action.arguments['url']?.toString() ?? '';
        await _load(url);
        return _readPage();
      case 'read':
        return _readPage();
      case 'click':
        final selector = action.arguments['selector']?.toString() ?? '';
        final text = action.arguments['text']?.toString() ?? '';
        final result = await _runJson('''
(() => {
  const selector = ${jsonEncode(selector)};
  const wanted = ${jsonEncode(text)}.trim().toLowerCase();
  let element = selector ? document.querySelector(selector) : null;
  if (!element && wanted) {
    element = [...document.querySelectorAll('a,button,[role="button"],input[type="submit"]')]
      .find((item) => ((item.innerText || item.value || '').trim().toLowerCase()).includes(wanted));
  }
  if (!element) return JSON.stringify({success:false,error:'Elemen tidak ditemui'});
  element.scrollIntoView({block:'center'});
  element.click();
  return JSON.stringify({success:true,tag:element.tagName,text:(element.innerText || element.value || '').trim()});
})()
''');
        await Future<void>.delayed(const Duration(milliseconds: 700));
        return result;
      case 'fill':
        final selector = action.arguments['selector']?.toString() ?? '';
        final value = action.arguments['value']?.toString() ?? '';
        return _runJson('''
(() => {
  const element = document.querySelector(${jsonEncode(selector)});
  if (!element) return JSON.stringify({success:false,error:'Input tidak ditemui'});
  element.focus();
  element.value = ${jsonEncode(value)};
  element.dispatchEvent(new Event('input',{bubbles:true}));
  element.dispatchEvent(new Event('change',{bubbles:true}));
  return JSON.stringify({success:true,name:element.name || '',type:element.type || ''});
})()
''');
      case 'submit':
        final selector = action.arguments['selector']?.toString() ?? 'form';
        final result = await _runJson('''
(() => {
  const target = document.querySelector(${jsonEncode(selector)});
  if (!target) return JSON.stringify({success:false,error:'Borang/elemen tidak ditemui'});
  const form = target.tagName === 'FORM' ? target : target.closest('form');
  if (form) {
    if (form.requestSubmit) form.requestSubmit(); else form.submit();
  } else {
    target.click();
  }
  return JSON.stringify({success:true});
})()
''');
        await Future<void>.delayed(const Duration(milliseconds: 700));
        return result;
      case 'back':
        if (await _controller.canGoBack()) await _controller.goBack();
        return <String, dynamic>{'success': true, 'url': _session?.currentUrl};
      case 'forward':
        if (await _controller.canGoForward()) await _controller.goForward();
        return <String, dynamic>{'success': true, 'url': _session?.currentUrl};
      case 'reload':
        await _controller.reload();
        return <String, dynamic>{'success': true};
      default:
        throw UnsupportedError('Aksi browser tidak dikenali: ${action.type}');
    }
  }

  Future<Map<String, dynamic>> _readPage() async {
    return _runJson(r'''
(() => {
  const clean = (value) => (value || '').replace(/\s+/g,' ').trim();
  const links = [...document.querySelectorAll('a[href]')].slice(0,100).map((a,index) => ({
    index,
    text: clean(a.innerText || a.textContent),
    url: a.href
  }));
  const forms = [...document.forms].slice(0,30).map((form,index) => ({
    index,
    action: form.action,
    method: (form.method || 'get').toUpperCase(),
    fields: [...form.elements].slice(0,60).map((field) => ({
      name: field.name || '',
      id: field.id || '',
      type: field.type || field.tagName,
      value: field.type === 'password' ? '' : (field.value || '')
    }))
  }));
  return JSON.stringify({
    success:true,
    title:document.title,
    url:location.href,
    text:clean(document.body ? document.body.innerText : '').slice(0,48000),
    links,
    forms
  });
})()
''');
  }

  Future<Map<String, dynamic>> _runJson(String script) async {
    final raw = await _controller.runJavaScriptReturningResult(script);
    var text = raw.toString();
    if (text.startsWith('"') && text.endsWith('"')) {
      try {
        text = jsonDecode(text).toString();
      } catch (_) {}
    }
    final decoded = jsonDecode(text);
    return Map<String, dynamic>.from(decoded as Map);
  }

  Future<void> _load(String raw) async {
    final value = raw.trim();
    if (value.isEmpty) return;
    final uri = value.contains('://')
        ? Uri.tryParse(value)
        : value.contains('.') && !value.contains(' ')
            ? Uri.tryParse('https://$value')
            : Uri.https('duckduckgo.com', '/', <String, String>{'q': value});
    if (uri == null) throw const FormatException('URL tidak sah.');
    _pageLoaded = Completer<void>();
    await _controller.loadRequest(uri);
    await _pageLoaded!.future.timeout(const Duration(seconds: 60));
  }

  void _go(String raw) {
    _load(raw).catchError((Object error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
    });
  }
}
