import 'package:flutter/material.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class ToolLogsScreen extends StatefulWidget {
  const ToolLogsScreen({super.key});

  @override
  State<ToolLogsScreen> createState() => _ToolLogsScreenState();
}

class _ToolLogsScreenState extends State<ToolLogsScreen> {
  late Future<List<ToolLogRecord>> _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _future = AppScope.of(context).toolLogs();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log Tool'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Padam log',
            onPressed: () async {
              await AppScope.of(context).database.clearToolLogs();
              if (mounted) setState(() => _future = AppScope.of(context).toolLogs());
            },
            icon: const Icon(Icons.delete_sweep_outlined),
          ),
        ],
      ),
      body: FutureBuilder<List<ToolLogRecord>>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final logs = snapshot.data!;
          if (logs.isEmpty) return const Center(child: Text('Belum ada log tool.'));
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
            itemCount: logs.length,
            itemBuilder: (context, index) {
              final log = logs[index];
              return Card(
                child: ExpansionTile(
                  leading: Icon(log.success ? Icons.check_circle_outline_rounded : Icons.error_outline_rounded, color: log.success ? AppTheme.success : AppTheme.danger),
                  title: Text(log.toolId, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${log.scope} • ${_time(log.createdAt)}'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SelectableText(log.summary.isEmpty ? '(tiada ringkasan)' : log.summary),
                    const SizedBox(height: 8),
                    Text('Sesi: ${log.sessionId}', style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _time(DateTime value) =>
      '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year} '
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
}
