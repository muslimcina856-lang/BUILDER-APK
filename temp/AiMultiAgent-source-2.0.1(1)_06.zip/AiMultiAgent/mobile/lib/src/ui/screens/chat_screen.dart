import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _composer = TextEditingController();
  final _scroll = ScrollController();
  final _speech = SpeechToText();
  bool _listening = false;
  int _lastMessageCount = 0;

  @override
  void dispose() {
    _composer.dispose();
    _scroll.dispose();
    _speech.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.messages.length != _lastMessageCount) {
      _lastMessageCount = state.messages.length;
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }

    return SafeArea(
      child: Column(
        children: <Widget>[
          _header(context, state),
          if (state.runStatus != RunStatus.idle && state.runDetail.isNotEmpty)
            _RunBanner(status: state.runStatus, detail: state.runDetail),
          Expanded(
            child: state.messages.isEmpty
                ? const Center(child: Text('Mulakan perbualan.'))
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                    itemCount: state.messages.length,
                    itemBuilder: (context, index) => _MessageBubble(message: state.messages[index]),
                  ),
          ),
          _composerBar(context, state),
        ],
      ),
    );
  }

  Widget _header(BuildContext context, dynamic state) {
    final selectedProvider = state.selectedProvider as ProviderConfig?;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 12, 8),
      child: Row(
        children: <Widget>[
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset('assets/images/app_icon.png', width: 42, height: 42),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('Ai MultiAgent', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text(
                  selectedProvider == null
                      ? 'Provider belum dipilih'
                      : '${selectedProvider.name} • ${selectedProvider.model.isEmpty ? 'model belum dipilih' : selectedProvider.model}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Sesi baharu',
            onPressed: state.newSession,
            icon: const Icon(Icons.add_comment_outlined),
          ),
        ],
      ),
    );
  }

  Widget _composerBar(BuildContext context, dynamic state) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: state.providers.any((ProviderConfig item) => item.id == state.selectedProviderId) ? state.selectedProviderId : null,
                    decoration: const InputDecoration(labelText: 'Provider', isDense: true),
                    items: state.providers
                        .map<DropdownMenuItem<String>>((ProviderConfig item) => DropdownMenuItem<String>(
                              value: item.id,
                              child: Text('${item.name} · ${item.model}', overflow: TextOverflow.ellipsis),
                            ))
                        .toList(),
                    onChanged: (value) {
                      if (value != null) state.selectProvider(value);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: state.agents.any((AgentProfile item) => item.id == state.selectedAgentId) ? state.selectedAgentId : null,
                    decoration: const InputDecoration(labelText: 'Agent', isDense: true),
                    items: state.agents
                        .where((AgentProfile item) => item.enabled)
                        .map<DropdownMenuItem<String>>((AgentProfile item) => DropdownMenuItem<String>(
                              value: item.id,
                              child: Text(item.name, overflow: TextOverflow.ellipsis),
                            ))
                        .toList(),
                    onChanged: (value) {
                      if (value != null) state.selectAgent(value);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _composer,
                    minLines: 1,
                    maxLines: 6,
                    textInputAction: TextInputAction.newline,
                    decoration: const InputDecoration(
                      hintText: 'Tulis arahan…',
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                    ),
                    onSubmitted: (_) {
                      if (!state.isSending) _send(state);
                    },
                  ),
                ),
                const SizedBox(width: 6),
                IconButton.filledTonal(
                  tooltip: _listening ? 'Hentikan suara' : 'Input suara',
                  onPressed: _toggleSpeech,
                  icon: Icon(_listening ? Icons.stop_circle_outlined : Icons.mic_none_rounded),
                ),
                const SizedBox(width: 4),
                IconButton.filled(
                  tooltip: state.isSending ? 'Hentikan tugasan' : 'Hantar',
                  onPressed: state.isSending
                      ? state.stopCurrentRun
                      : (!state.hasProvider ? null : () => _send(state)),
                  icon: state.isSending
                      ? const Icon(Icons.stop_rounded)
                      : const Icon(Icons.arrow_upward_rounded),
                ),
              ],
            ),
            if (!state.hasProvider)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: InkWell(
                  onTap: () => state.selectTab(1),
                  child: const Text('Tambah provider dan API key dahulu', style: TextStyle(color: AppTheme.purpleLight)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _send(dynamic state) async {
    final text = _composer.text.trim();
    if (text.isEmpty) return;
    _composer.clear();
    await state.sendMessage(text);
    _scrollToBottom();
  }

  Future<void> _toggleSpeech() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    final available = await _speech.initialize(
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          if (mounted) setState(() => _listening = false);
        }
      },
    );
    if (!available) return;
    setState(() => _listening = true);
    await _speech.listen(
      localeId: 'ms_MY',
      partialResults: true,
      onResult: (result) {
        _composer.text = result.recognizedWords;
        _composer.selection = TextSelection.collapsed(offset: _composer.text.length);
      },
    );
  }

  void _scrollToBottom() {
    if (!_scroll.hasClients) return;
    _scroll.animateTo(
      _scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }
}

class _RunBanner extends StatelessWidget {
  const _RunBanner({required this.status, required this.detail});
  final RunStatus status;
  final String detail;

  @override
  Widget build(BuildContext context) {
    final waiting = status == RunStatus.waitingPermission;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: waiting ? Colors.amber.withValues(alpha: .12) : AppTheme.purple.withValues(alpha: .12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: waiting ? Colors.amber.withValues(alpha: .35) : AppTheme.purple.withValues(alpha: .35)),
      ),
      child: Row(
        children: <Widget>[
          if (status == RunStatus.planning || status == RunStatus.runningTool)
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
          else
            Icon(waiting ? Icons.approval_outlined : Icons.info_outline_rounded, size: 18),
          const SizedBox(width: 9),
          Expanded(child: Text(detail, style: const TextStyle(fontSize: 12.5))),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message});
  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    if (message.role == MessageRole.tool) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: <Widget>[
            const Icon(Icons.build_circle_outlined, size: 14, color: Colors.white38),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                '${message.name ?? 'tool'} selesai',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white38),
              ),
            ),
          ],
        ),
      );
    }
    final user = message.role == MessageRole.user;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * .84),
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: user ? AppTheme.purple : AppTheme.surface,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(user ? 16 : 4),
            bottomRight: Radius.circular(user ? 4 : 16),
          ),
          border: user ? null : Border.all(color: const Color(0xFF203044)),
        ),
        child: SelectableText(message.content),
      ),
    );
  }
}
