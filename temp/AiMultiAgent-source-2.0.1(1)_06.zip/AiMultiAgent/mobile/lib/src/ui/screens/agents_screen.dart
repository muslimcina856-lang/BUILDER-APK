import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class AgentsScreen extends StatelessWidget {
  const AgentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Multi-Agent'),
          actions: <Widget>[
            IconButton(
              tooltip: 'Agent baharu',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AgentEditorScreen())),
              icon: const Icon(Icons.add_rounded),
            ),
          ],
        ),
        body: ListView.builder(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 96),
          itemCount: state.agents.length,
          itemBuilder: (context, index) {
            final agent = state.agents[index];
            final selected = state.selectedAgentId == agent.id;
            final provider = state.providers.where((item) => item.id == agent.providerId).firstOrNull;
            return Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => state.selectAgent(agent.id),
                onLongPress: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AgentEditorScreen(agent: agent))),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: <Widget>[
                      CircleAvatar(
                        radius: 24,
                        backgroundColor: AppTheme.purple.withValues(alpha: .16),
                        child: Icon(agent.icon, color: AppTheme.purpleLight),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(child: Text(agent.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                                if (selected) const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 19),
                              ],
                            ),
                            const SizedBox(height: 3),
                            Text(agent.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 6),
                            Text(
                              '${provider?.name ?? 'Provider aktif'} • ${agent.modelOverride?.isNotEmpty == true ? agent.modelOverride : 'model provider'} • ${agent.toolIds.isEmpty ? 'semua tools' : '${agent.toolIds.length} tools'}',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Edit agent',
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AgentEditorScreen(agent: agent))),
                        icon: const Icon(Icons.tune_rounded),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AgentEditorScreen())),
          icon: const Icon(Icons.add_rounded),
          label: const Text('Agent'),
        ),
      ),
    );
  }
}

class AgentEditorScreen extends StatefulWidget {
  const AgentEditorScreen({this.agent, super.key});
  final AgentProfile? agent;

  @override
  State<AgentEditorScreen> createState() => _AgentEditorScreenState();
}

class _AgentEditorScreenState extends State<AgentEditorScreen> {
  static const _uuid = Uuid();
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _prompt;
  late final TextEditingController _model;
  String? _providerId;
  late bool _enabled;
  late bool _allTools;
  late Set<String> _toolIds;
  late Set<String> _skillIds;

  @override
  void initState() {
    super.initState();
    final agent = widget.agent;
    _name = TextEditingController(text: agent?.name ?? 'Custom Agent');
    _description = TextEditingController(text: agent?.description ?? 'Agent tersuai untuk tugasan tertentu.');
    _prompt = TextEditingController(text: agent?.systemPrompt ?? 'Selesaikan tugasan pengguna menggunakan tools dan skills yang tersedia.');
    _model = TextEditingController(text: agent?.modelOverride ?? '');
    _providerId = agent?.providerId;
    _enabled = agent?.enabled ?? true;
    _allTools = agent == null || agent.toolIds.isEmpty;
    _toolIds = agent?.toolIds.toSet() ?? <String>{};
    _skillIds = agent?.skillIds.toSet() ?? <String>{};
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _prompt.dispose();
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.agent == null ? 'Agent Baharu' : 'Edit Agent'),
        actions: <Widget>[
          if (widget.agent != null && !widget.agent!.isBuiltIn)
            IconButton(
              tooltip: 'Padam agent',
              onPressed: _delete,
              icon: const Icon(Icons.delete_outline_rounded),
            ),
          TextButton(onPressed: _save, child: const Text('Simpan')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nama agent'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(controller: _description, decoration: const InputDecoration(labelText: 'Penerangan'), maxLines: 2, validator: _required),
            const SizedBox(height: 10),
            TextFormField(
              controller: _prompt,
              decoration: const InputDecoration(labelText: 'Arahan agent', alignLabelWithHint: true),
              minLines: 5,
              maxLines: 14,
              validator: _required,
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: state.providers.any((item) => item.id == _providerId) ? _providerId : '',
              decoration: const InputDecoration(labelText: 'Provider khusus'),
              items: <DropdownMenuItem<String>>[
                const DropdownMenuItem<String>(value: '', child: Text('Gunakan provider aktif')),
                ...state.providers.map((item) => DropdownMenuItem<String>(value: item.id, child: Text(item.name))),
              ],
              onChanged: (value) => setState(() => _providerId = value?.isEmpty == true ? null : value),
            ),
            const SizedBox(height: 10),
            TextFormField(controller: _model, decoration: const InputDecoration(labelText: 'Model khusus (pilihan)', hintText: 'Kosong = model provider')),
            const SizedBox(height: 8),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _enabled,
              onChanged: (value) => setState(() => _enabled = value),
              title: const Text('Agent aktif'),
            ),
            const Divider(height: 28),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _allTools,
              onChanged: (value) => setState(() => _allTools = value),
              title: const Text('Benarkan semua tools'),
              subtitle: const Text('Kelulusan berisiko masih ditentukan oleh polisi aplikasi.'),
            ),
            if (!_allTools) ...<Widget>[
              const SizedBox(height: 6),
              const Text('Tools', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.purpleLight)),
              ...state.toolEngine.definitions.map((tool) => CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: _toolIds.contains(tool.id),
                    onChanged: (value) => setState(() => value == true ? _toolIds.add(tool.id) : _toolIds.remove(tool.id)),
                    title: Text(tool.name),
                    subtitle: Text('${tool.category} • ${_riskLabel(tool.risk)}'),
                  )),
            ],
            const Divider(height: 28),
            const Text('Skills', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.purpleLight)),
            if (state.skills.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Tiada skill dipasang.'))
            else
              ...state.skills.map((skill) => CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: _skillIds.contains(skill.id),
                    onChanged: (value) => setState(() => value == true ? _skillIds.add(skill.id) : _skillIds.remove(skill.id)),
                    title: Text(skill.name),
                    subtitle: Text(skill.description),
                  )),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  String _riskLabel(ToolRisk risk) => switch (risk) {
        ToolRisk.readOnly => 'baca',
        ToolRisk.localWrite => 'tulis local',
        ToolRisk.externalWrite => 'tindakan luar',
        ToolRisk.sensitive => 'berisiko',
      };

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final old = widget.agent;
    final agent = AgentProfile(
      id: old?.id ?? _uuid.v4(),
      name: _name.text.trim(),
      description: _description.text.trim(),
      systemPrompt: _prompt.text.trim(),
      iconCode: old?.iconCode ?? Icons.auto_awesome_rounded.codePoint,
      providerId: _providerId,
      modelOverride: _model.text.trim().isEmpty ? null : _model.text.trim(),
      toolIds: _allTools ? const <String>[] : _toolIds.toList(),
      skillIds: _skillIds.toList(),
      enabled: _enabled,
      isBuiltIn: old?.isBuiltIn ?? false,
    );
    await AppScope.of(context).saveAgent(agent);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final agent = widget.agent;
    if (agent == null || agent.isBuiltIn) return;
    final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam agent?'),
            content: Text('${agent.name} akan dipadam daripada peranti.'),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Padam')),
            ],
          ),
        ) ??
        false;
    if (!ok || !mounted) return;
    await AppScope.of(context).deleteAgent(agent);
    if (mounted) Navigator.pop(context);
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}
