import 'package:flutter/material.dart';

import '../app.dart';
import '../models/app_models.dart';
import 'screens/agents_screen.dart';
import 'screens/automations_screen.dart';
import 'screens/browser_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/more_screen.dart';
import 'screens/providers_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  String? _showingPermissionId;
  int _lastBrowserRequest = 0;

  static const _pages = <Widget>[
    ChatScreen(),
    ProvidersScreen(),
    AgentsScreen(),
    AutomationsScreen(),
    MoreScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    _schedulePermissionDialog(state.pendingPermission);
    _scheduleBrowser(state.browserSession.requestSerial, state.browserSession.requestedUrl);
    return Scaffold(
      body: IndexedStack(index: state.selectedTab, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: state.selectedTab,
        onDestinationSelected: state.selectTab,
        destinations: const <NavigationDestination>[
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.hub_outlined), selectedIcon: Icon(Icons.hub_rounded), label: 'Provider'),
          NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy_rounded), label: 'Agent'),
          NavigationDestination(icon: Icon(Icons.schedule_outlined), selectedIcon: Icon(Icons.schedule_rounded), label: 'Automasi'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view_rounded), label: 'Lain-lain'),
        ],
      ),
    );
  }

  void _scheduleBrowser(int serial, String? url) {
    if (serial == 0 || serial == _lastBrowserRequest || url == null) return;
    _lastBrowserRequest = serial;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final state = AppScope.of(context);
      if (state.browserSession.isVisible) return;
      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => BrowserScreen(initialUrl: url)));
    });
  }

  void _schedulePermissionDialog(PermissionRequest? request) {
    if (request == null || request.id == _showingPermissionId) return;
    _showingPermissionId = request.id;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final decision = await showDialog<PermissionDecision>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.warning_amber_rounded, size: 36),
          title: Text(request.tool.name),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(request.description),
              const SizedBox(height: 12),
              Text('Skop: ${request.scope}', style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              const Text('Dialog ini hanya muncul untuk tindakan yang dikesan boleh memadam, menimpa atau merosakkan data.'),
              const SizedBox(height: 8),
              const Text('“Sesi ini” membenarkan semua tindakan berisiko sehingga sesi tamat. “Sentiasa” menyimpan kelulusan untuk tool dan skop ini dalam Tetapan.'),
            ],
          ),
          actionsOverflowDirection: VerticalDirection.up,
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.pop(dialogContext, PermissionDecision.deny), child: const Text('Tolak')),
            OutlinedButton(onPressed: () => Navigator.pop(dialogContext, PermissionDecision.allowOnce), child: const Text('Sekali')),
            OutlinedButton(onPressed: () => Navigator.pop(dialogContext, PermissionDecision.allowSession), child: const Text('Sesi ini')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, PermissionDecision.allowAlways), child: const Text('Sentiasa')),
          ],
        ),
      );
      if (!mounted) return;
      AppScope.of(context).resolvePermission(decision ?? PermissionDecision.deny);
      _showingPermissionId = null;
    });
  }
}
