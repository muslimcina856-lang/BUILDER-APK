import 'dart:async';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../data/provider_catalog.dart';
import '../models/app_models.dart';
import '../services/agent_runtime.dart';
import '../services/automation_service.dart';
import '../services/browser_session_service.dart';
import '../services/local_database.dart';
import '../services/mcp_service.dart';
import '../services/permission_manager.dart';
import '../services/provider_service.dart';
import '../services/secure_vault.dart';
import '../services/skill_service.dart';
import '../services/terminal_service.dart';
import '../services/tool_engine.dart';

class AppState extends ChangeNotifier with WidgetsBindingObserver {
  AppState() {
    WidgetsBinding.instance.addObserver(this);
    browserSession.addListener(_notifyFromBrowser);
  }

  void _notifyFromBrowser() => notifyListeners();

  static const _uuid = Uuid();
  final LocalDatabase database = LocalDatabase();
  final SecureVault vault = SecureVault();
  final ProviderService providerService = ProviderService();
  final BrowserSessionService browserSession = BrowserSessionService();
  final TerminalService terminalService = TerminalService();
  final McpService mcpService = McpService();
  late final SkillService skillService = SkillService(database);
  late final ToolEngine toolEngine = ToolEngine(
        database,
        browserSession: browserSession,
        terminalService: terminalService,
        skillService: skillService,
        mcpService: mcpService,
      );
  late final PermissionManager permissionManager = PermissionManager(database)..onChanged = notifyListeners;
  late final AutomationService automationService = AutomationService(database);
  late final AgentRuntime runtime = AgentRuntime(
        providerService: providerService,
        toolEngine: toolEngine,
        permissionManager: permissionManager,
        database: database,
      );

  bool initialized = false;
  bool isSending = false;
  bool backgroundExecutionAllowed = false;
  RunStatus runStatus = RunStatus.idle;
  String runDetail = '';
  int selectedTab = 0;
  String sessionId = _uuid.v4();
  String selectedProviderId = '';
  String selectedAgentId = 'general';
  DateTime lastActivityAt = DateTime.now();
  List<ProviderConfig> providers = <ProviderConfig>[];
  List<AgentProfile> agents = <AgentProfile>[];
  List<SkillDefinition> skills = <SkillDefinition>[];
  List<AutomationDefinition> automations = <AutomationDefinition>[];
  List<McpServerConfig> mcpServers = <McpServerConfig>[];
  List<ChatMessage> messages = <ChatMessage>[];

  Timer? _inactivityTimer;
  RunControl? _runControl;
  DateTime _lastPersistedActivity = DateTime.fromMillisecondsSinceEpoch(0);

  PermissionRequest? get pendingPermission => permissionManager.pending;
  ProviderConfig? get selectedProvider => _providerById(selectedProviderId);
  AgentProfile get selectedAgent => agents.firstWhere((item) => item.id == selectedAgentId, orElse: () => _builtInAgents().first);
  bool get hasProvider => providers.isNotEmpty;
  bool get sessionAllowsAllRisky => permissionManager.allowAllRiskyForSession;

  Future<void> initialize() async {
    _inactivityTimer?.cancel();
    await permissionManager.initialize();
    agents = await _loadAgents();
    skills = await skillService.loadSkills();
    providers = (await database.listObjects('provider')).map(ProviderConfig.fromJson).toList();
    automations = await automationService.load();
    mcpServers = (await database.listObjects('mcp_server')).map(McpServerConfig.fromJson).toList();
    selectedProviderId = await database.getSetting('selectedProviderId') ?? (providers.isEmpty ? '' : providers.first.id);
    selectedAgentId = await database.getSetting('selectedAgentId') ?? 'general';
    backgroundExecutionAllowed = (await database.getSetting('backgroundExecutionAllowed')) == 'true';

    final storedSession = await database.getSetting('activeSessionId');
    final previousLifecycle = await database.getSetting('lastLifecycleState');
    final storedActivity = DateTime.tryParse(await database.getSetting('lastActivityAt') ?? '');
    final inactiveTooLong = storedActivity == null || DateTime.now().difference(storedActivity) >= AppConfig.sessionInactivityTimeout;
    final freshProcessAfterBackground = previousLifecycle == 'background' && !backgroundExecutionAllowed;

    if (storedSession == null || inactiveTooLong || freshProcessAfterBackground) {
      sessionId = _uuid.v4();
      await database.setSetting('activeSessionId', sessionId);
    } else {
      sessionId = storedSession;
    }
    lastActivityAt = DateTime.now();
    await database.setSetting('lastLifecycleState', 'foreground');
    await _persistActivity(force: true);

    messages = await database.listMessages(sessionId);
    if (messages.isEmpty) {
      messages = <ChatMessage>[
        ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: providers.isEmpty
              ? 'Selamat datang. Tambah provider AI, masukkan API key, pilih model dan uji sambungan untuk mula.'
              : 'Sedia. Tool biasa berjalan terus; hanya tindakan berisiko tinggi akan meminta kelulusan.',
          createdAt: DateTime.now(),
        ),
      ];
      await database.saveMessage(messages.first);
    }

    _inactivityTimer = Timer.periodic(const Duration(minutes: 1), (_) => _checkInactivity());
    initialized = true;
    notifyListeners();
  }

  void recordActivity() {
    lastActivityAt = DateTime.now();
    unawaited(_persistActivity());
  }

  Future<void> _persistActivity({bool force = false}) async {
    if (!force && DateTime.now().difference(_lastPersistedActivity) < const Duration(seconds: 15)) return;
    _lastPersistedActivity = DateTime.now();
    await database.setSetting('lastActivityAt', lastActivityAt.toIso8601String());
  }

  Future<void> _checkInactivity() async {
    if (!initialized || isSending) return;
    if (DateTime.now().difference(lastActivityAt) >= AppConfig.sessionInactivityTimeout) {
      await newSession(reason: 'Sesi tamat selepas 30 minit tanpa aktiviti.');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!initialized) return;
    if (state == AppLifecycleState.resumed) {
      final elapsed = DateTime.now().difference(lastActivityAt);
      if (elapsed >= AppConfig.sessionInactivityTimeout) {
        unawaited(newSession(reason: 'Sesi tamat selepas 30 minit di latar belakang.'));
      }
      unawaited(database.setSetting('lastLifecycleState', 'foreground'));
      recordActivity();
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached || state == AppLifecycleState.hidden) {
      unawaited(database.setSetting('lastLifecycleState', 'background'));
      unawaited(_persistActivity(force: true));
    }
  }

  void selectTab(int value) {
    recordActivity();
    selectedTab = value;
    notifyListeners();
  }

  Future<void> selectProvider(String id) async {
    recordActivity();
    selectedProviderId = id;
    await database.setSetting('selectedProviderId', id);
    notifyListeners();
  }

  Future<void> selectAgent(String id) async {
    recordActivity();
    selectedAgentId = id;
    await database.setSetting('selectedAgentId', id);
    notifyListeners();
  }

  Future<void> setBackgroundExecutionAllowed(bool value) async {
    backgroundExecutionAllowed = value;
    await database.setSetting('backgroundExecutionAllowed', value.toString());
    notifyListeners();
  }

  ProviderConfig createProviderFromPreset(ProviderPreset preset) => ProviderConfig(
        id: _uuid.v4(),
        name: preset.name,
        presetId: preset.id,
        protocol: preset.protocol,
        baseUrl: preset.baseUrl,
        chatPath: preset.chatPath,
        modelsPath: preset.modelsPath,
        authStyle: preset.authStyle,
        apiKeyHeader: preset.apiKeyHeader,
        apiKeyPrefix: preset.apiKeyPrefix,
        model: preset.defaultModels.isEmpty ? '' : preset.defaultModels.first,
        availableModels: preset.defaultModels,
        extraHeaders: preset.defaultHeaders,
        supportsStreaming: true,
        supportsTools: true,
        supportsVision: preset.id == 'gemini' || preset.id == 'openai' || preset.id == 'mimo',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

  Future<void> saveProvider(ProviderConfig provider, {String? apiKey}) async {
    final index = providers.indexWhere((item) => item.id == provider.id);
    if (index < 0) {
      providers.insert(0, provider);
    } else {
      providers[index] = provider;
    }
    await database.saveObject('provider', provider.id, provider.toJson());
    if (apiKey != null) await vault.writeProviderKey(provider.id, apiKey);
    if (selectedProviderId.isEmpty) await selectProvider(provider.id);
    notifyListeners();
  }

  Future<String> providerKey(String providerId) => vault.readProviderKey(providerId);

  Future<void> deleteProvider(ProviderConfig provider) async {
    providers.removeWhere((item) => item.id == provider.id);
    await database.deleteObject('provider', provider.id);
    await vault.deleteProviderKey(provider.id);
    if (selectedProviderId == provider.id) {
      selectedProviderId = providers.isEmpty ? '' : providers.first.id;
      await database.setSetting('selectedProviderId', selectedProviderId);
    }
    notifyListeners();
  }

  Future<List<String>> refreshModels(ProviderConfig provider, String key) async {
    final models = await providerService.listModels(provider, key);
    final merged = <String>{...provider.availableModels, ...models}.toList()..sort();
    await saveProvider(provider.copyWith(availableModels: merged, updatedAt: DateTime.now()));
    return merged;
  }

  Future<ProviderTestResult> testProvider(ProviderConfig provider, String key) async {
    final testing = provider.copyWith(testStatus: ProviderTestStatus.testing, lastTestMessage: 'Menguji…');
    await saveProvider(testing);
    final result = await providerService.test(testing, key);
    final updated = testing.copyWith(
      testStatus: result.success ? ProviderTestStatus.success : ProviderTestStatus.failed,
      lastTestMessage: result.message,
      lastLatencyMs: result.latencyMs,
      availableModels: result.models.isEmpty ? testing.availableModels : <String>{...testing.availableModels, ...result.models}.toList()..sort(),
    );
    await saveProvider(updated, apiKey: key);
    return result;
  }

  Future<void> sendMessage(String value) async {
    recordActivity();
    final text = value.trim();
    if (text.isEmpty || isSending) return;
    final provider = _effectiveProvider();
    if (provider == null) {
      runStatus = RunStatus.failed;
      runDetail = 'Tambah dan pilih provider terlebih dahulu.';
      notifyListeners();
      return;
    }
    final apiKey = await vault.readProviderKey(provider.id);
    if (provider.authStyle != AuthStyle.none && apiKey.isEmpty) {
      runStatus = RunStatus.failed;
      runDetail = 'API key provider belum disimpan.';
      notifyListeners();
      return;
    }
    final userMessage = ChatMessage(id: _uuid.v4(), sessionId: sessionId, role: MessageRole.user, content: text, createdAt: DateTime.now());
    final history = List<ChatMessage>.from(messages);
    messages.add(userMessage);
    await database.saveMessage(userMessage);
    isSending = true;
    _runControl = RunControl();
    runStatus = RunStatus.planning;
    runDetail = 'Model sedang memproses…';
    notifyListeners();
    try {
      final assistant = await runtime.run(
        sessionId: sessionId,
        provider: provider,
        apiKey: apiKey,
        agent: selectedAgent,
        agents: agents,
        providers: providers,
        apiKeyResolver: vault.readProviderKey,
        skills: skills,
        history: history,
        userInput: text,
        control: _runControl,
        onProgress: (status, detail) {
          runStatus = status;
          runDetail = detail;
          notifyListeners();
        },
      );
      messages.add(assistant);
      await database.saveMessage(assistant);
    } catch (error) {
      runStatus = RunStatus.failed;
      runDetail = error.toString();
      final failure = ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.assistant,
        content: 'Ralat provider/agent:\n$error',
        createdAt: DateTime.now(),
      );
      messages.add(failure);
      await database.saveMessage(failure);
    } finally {
      isSending = false;
      _runControl = null;
      if (runStatus != RunStatus.failed && runStatus != RunStatus.cancelled) runStatus = RunStatus.completed;
      notifyListeners();
    }
  }

  void stopCurrentRun() {
    _runControl?.cancel();
    permissionManager.cancelPending();
    runStatus = RunStatus.cancelled;
    runDetail = 'Menghentikan tugasan…';
    notifyListeners();
  }

  void resolvePermission(PermissionDecision decision) => permissionManager.resolve(decision);
  void grantSessionRiskPermission() => permissionManager.grantSessionAllRisky();
  List<PermissionRule> get permissionRules => permissionManager.rules;

  Future<void> setToolPermission(String toolId, PermissionPolicy policy, {String scope = '*'}) =>
      permissionManager.setPolicy(toolId, scope: scope, policy: policy);

  Future<void> setGlobalRiskPermission(PermissionPolicy policy) =>
      permissionManager.setPolicy('*', scope: '*', policy: policy);

  Future<void> revokePermission(String ruleId) => permissionManager.revoke(ruleId);

  Future<void> newSession({String reason = 'Sesi baharu dimulakan.'}) async {
    _runControl?.cancel();
    permissionManager.clearSessionPermissions();
    sessionId = _uuid.v4();
    await database.setSetting('activeSessionId', sessionId);
    lastActivityAt = DateTime.now();
    await _persistActivity(force: true);
    messages = <ChatMessage>[
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.assistant,
        content: '$reason Kebenaran “sesi ini” telah dikosongkan; peraturan kekal dalam Tetapan masih digunakan.',
        createdAt: DateTime.now(),
      ),
    ];
    await database.saveMessage(messages.first);
    runStatus = RunStatus.idle;
    runDetail = '';
    notifyListeners();
  }

  Future<void> saveAgent(AgentProfile agent) async {
    final index = agents.indexWhere((item) => item.id == agent.id);
    if (index < 0) {
      agents.add(agent);
    } else {
      agents[index] = agent;
    }
    await database.saveObject('agent', agent.id, agent.toJson());
    notifyListeners();
  }

  Future<void> deleteAgent(AgentProfile agent) async {
    if (agent.isBuiltIn) return;
    agents.removeWhere((item) => item.id == agent.id);
    await database.deleteObject('agent', agent.id);
    if (selectedAgentId == agent.id) await selectAgent('general');
    notifyListeners();
  }

  Future<void> saveSkill(SkillDefinition skill) async {
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    await skillService.save(skill);
    notifyListeners();
  }

  Future<void> importSkill(String path) async {
    final skill = await skillService.importZip(path);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> installSkillFromUrl(String url) async {
    final skill = await skillService.importUrl(url);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> deleteSkill(SkillDefinition skill) async {
    skills.removeWhere((item) => item.id == skill.id);
    await skillService.delete(skill);
    notifyListeners();
  }

  Future<void> saveAutomation(AutomationDefinition automation) async {
    final index = automations.indexWhere((item) => item.id == automation.id);
    if (index < 0) {
      automations.add(automation);
    } else {
      automations[index] = automation;
    }
    await automationService.save(automation);
    notifyListeners();
  }

  Future<void> deleteAutomation(AutomationDefinition automation) async {
    automations.removeWhere((item) => item.id == automation.id);
    await automationService.delete(automation);
    notifyListeners();
  }

  Future<void> saveMcpServer(McpServerConfig server) async {
    final index = mcpServers.indexWhere((item) => item.id == server.id);
    if (index < 0) {
      mcpServers.add(server);
    } else {
      mcpServers[index] = server;
    }
    await database.saveObject('mcp_server', server.id, server.toJson());
    notifyListeners();
  }

  Future<Map<String, dynamic>> testMcpServer(McpServerConfig server) async {
    try {
      final result = await mcpService.test(server);
      await saveMcpServer(server.copyWith(lastTestMessage: 'Berjaya', lastTestAt: DateTime.now()));
      return result;
    } catch (error) {
      await saveMcpServer(server.copyWith(lastTestMessage: error.toString(), lastTestAt: DateTime.now()));
      rethrow;
    }
  }

  Future<void> deleteMcpServer(McpServerConfig server) async {
    mcpServers.removeWhere((item) => item.id == server.id);
    await database.deleteObject('mcp_server', server.id);
    notifyListeners();
  }

  Future<List<MemoryRecord>> memories() async =>
      (await database.listObjects('memory')).map(MemoryRecord.fromJson).toList();

  Future<void> saveMemory(MemoryRecord memory) async {
    await database.saveObject('memory', memory.id, memory.toJson());
    notifyListeners();
  }

  Future<void> deleteMemory(MemoryRecord memory) async {
    await database.deleteObject('memory', memory.id);
    notifyListeners();
  }

  Future<List<ToolLogRecord>> toolLogs({int limit = 200}) => database.listToolLogs(limit: limit);

  Future<void> deleteAllLocalData() async {
    _inactivityTimer?.cancel();
    _runControl?.cancel();
    permissionManager.cancelPending();
    await automationService.cancelAll();
    await vault.deleteAll();
    await database.deleteAllLocalData();
    providers.clear();
    automations.clear();
    skills.clear();
    mcpServers.clear();
    messages.clear();
    initialized = false;
    notifyListeners();
    await initialize();
  }

  ProviderConfig? _effectiveProvider() {
    final agent = selectedAgent;
    if (agent.providerId?.isNotEmpty == true) return _providerById(agent.providerId!);
    return selectedProvider;
  }

  ProviderConfig? _providerById(String id) {
    for (final provider in providers) {
      if (provider.id == id) return provider;
    }
    return null;
  }

  Future<List<AgentProfile>> _loadAgents() async {
    final saved = (await database.listObjects('agent')).map(AgentProfile.fromJson).toList();
    final values = <AgentProfile>[...saved];
    for (final builtIn in _builtInAgents()) {
      final index = values.indexWhere((item) => item.id == builtIn.id);
      if (index < 0) {
        values.add(builtIn);
      } else if (values[index].isBuiltIn) {
        values[index] = builtIn.copyWith(
          providerId: values[index].providerId,
          modelOverride: values[index].modelOverride,
          enabled: values[index].enabled,
        );
      }
      await database.saveObject('agent', builtIn.id, values.firstWhere((item) => item.id == builtIn.id).toJson());
    }
    return values;
  }

  List<AgentProfile> _builtInAgents() => const <AgentProfile>[
        AgentProfile(
          id: 'general',
          name: 'General Agent',
          description: 'Pembantu umum dengan semua tools dan skills yang aktif.',
          systemPrompt: 'Selesaikan tugasan pengguna dengan tepat dan gunakan tools yang diperlukan.',
          iconCode: 0xe0ca,
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'research',
          name: 'Research Agent',
          description: 'DuckDuckGo, browser visual dan laporan berdasarkan sumber.',
          systemPrompt: 'Cari, buka dan baca sumber sebenar sebelum membuat kesimpulan.',
          iconCode: 0xe8b6,
          toolIds: <String>['web_search', 'browser_open', 'browser_read', 'browser_follow_link', 'browser_click', 'browser_download', 'file_write'],
          skillIds: <String>['web_research'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'browser',
          name: 'Browser Agent',
          description: 'Browser visual, input, klik, borang, muat turun dan HTTP.',
          systemPrompt: 'Gunakan browser visual yang kelihatan untuk navigasi dan interaksi web.',
          iconCode: 0xe894,
          toolIds: <String>['web_search', 'browser_open', 'browser_read', 'browser_follow_link', 'browser_click', 'browser_fill', 'browser_submit_form', 'browser_download', 'open_url', 'http_request'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'coding',
          name: 'Coding Agent',
          description: 'Kod, terminal latar belakang dan workspace aplikasi.',
          systemPrompt: 'Baca fail berkaitan, jalankan arahan dalam sandbox, pantau output dan ubah hanya fail yang diperlukan.',
          iconCode: 0xe86f,
          toolIds: <String>['file_list', 'file_read', 'file_write', 'file_copy', 'file_move', 'file_delete', 'terminal_start', 'terminal_poll', 'terminal_stop', 'web_search', 'browser_open', 'calculator', 'skill_run_script'],
          skillIds: <String>['document_writer', 'sandbox_automation'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'document',
          name: 'Document Agent',
          description: 'Laporan, dokumen local, web dan memori.',
          systemPrompt: 'Hasilkan kandungan tersusun dan simpan ke workspace apabila diminta.',
          iconCode: 0xe873,
          toolIds: <String>['file_list', 'file_read', 'file_write', 'file_copy', 'memory_search', 'web_search', 'browser_open'],
          skillIds: <String>['document_writer'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'files',
          name: 'File Agent',
          description: 'Mengurus fail dalam workspace aplikasi.',
          systemPrompt: 'Urus fail dengan path tepat dan semak hasil selepas perubahan.',
          iconCode: 0xe2c7,
          toolIds: <String>['file_list', 'file_read', 'file_write', 'file_copy', 'file_move', 'file_delete', 'browser_download'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'productivity',
          name: 'Productivity Agent',
          description: 'Memori, automasi, MCP local dan aliran kerja.',
          systemPrompt: 'Bantu mengurus maklumat dan aliran kerja berulang menggunakan tools local.',
          iconCode: 0xe8b5,
          toolIds: <String>['memory_search', 'memory_add', 'memory_delete', 'file_write', 'current_time', 'mcp_list_tools', 'mcp_call'],
          skillIds: <String>['local_memory'],
          isBuiltIn: true,
        ),
        AgentProfile(
          id: 'orchestrator',
          name: 'Orchestrator',
          description: 'Pecah tugas kompleks dan delegasi sub-agent tanpa had tetap.',
          systemPrompt: 'Pecahkan tugas kompleks, gunakan tools dan delegasikan subtugas sehingga hasil lengkap.',
          iconCode: 0xf1b3,
          isBuiltIn: true,
        ),
      ];

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    browserSession.removeListener(_notifyFromBrowser);
    _inactivityTimer?.cancel();
    _runControl?.cancel();
    providerService.dispose();
    toolEngine.dispose();
    unawaited(database.close());
    super.dispose();
  }
}
