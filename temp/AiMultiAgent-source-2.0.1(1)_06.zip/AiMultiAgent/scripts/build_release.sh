#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

if [[ ! -f "mobile/android/key.properties" ]]; then
  echo "Ralat: mobile/android/key.properties belum disediakan. Rujuk docs/KEYSTORE.md" >&2
  exit 1
fi
if ! command -v flutter >/dev/null 2>&1; then
  echo "Ralat: Flutter SDK tidak ditemui." >&2
  exit 1
fi

pushd mobile >/dev/null
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
popd >/dev/null

echo "Build release selesai."
echo "APK: mobile/build/app/outputs/flutter-apk/app-release.apk"
echo "AAB: mobile/build/app/outputs/bundle/release/app-release.aab"
