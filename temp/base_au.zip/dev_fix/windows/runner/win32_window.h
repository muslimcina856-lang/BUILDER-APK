#ifndef WIN32_WINDOW_H
#define WIN32_WINDOW_H
#include <windows.h>
class Win32Window {
 public:
  bool Create(const char* title, int width, int height);
  HWND GetHandle() const;
  void Show();
  virtual ~Win32Window();
 private:
  HWND window_handle_;
};
#endif