#include "flutter_window.h"
#include <flutter_windows.h>
FlutterWindow::FlutterWindow(int width, int height, const char* title) {
  Win32Window::Create(title, width, height);
  controller_ = FlutterDesktopViewControllerCreate(1280, 720, GetHandle());
}
FlutterWindow::~FlutterWindow() {
  if (controller_) FlutterDesktopViewControllerDestroy(controller_);
}