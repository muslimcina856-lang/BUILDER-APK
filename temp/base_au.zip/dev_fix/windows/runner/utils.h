#ifndef UTILS_H
#define UTILS_H
#include <string>
std::string Utf8FromWide(const wchar_t* wide);
#endif