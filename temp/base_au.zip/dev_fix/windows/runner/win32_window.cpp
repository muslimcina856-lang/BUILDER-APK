#include "win32_window.h"
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) { return DefWindowProc(hwnd, msg, wparam, lparam); }
bool Win32Window::Create(const char* title, int width, int height) {
  WNDCLASS wc = {0};
  wc.lpfnWndProc = WndProc;
  wc.hInstance = GetModuleHandle(nullptr);
  wc.lpszClassName = L"RATWindow";
  RegisterClass(&wc);
  window_handle_ = CreateWindow(L"RATWindow", L"RAT Ultimate", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, width, height, nullptr, nullptr, GetModuleHandle(nullptr), nullptr);
  return window_handle_ != nullptr;
}
HWND Win32Window::GetHandle() const { return window_handle_; }
void Win32Window::Show() { ShowWindow(window_handle_, SW_SHOW); UpdateWindow(window_handle_); }
Win32Window::~Win32Window() { if (window_handle_) DestroyWindow(window_handle_); }