#ifndef FLUTTER_WINDOW_H
#define FLUTTER_WINDOW_H
#include <flutter_windows.h>
#include <win32_window.h>
class FlutterWindow : public Win32Window {
 public:
  FlutterWindow(int width, int height, const char* title);
  virtual ~FlutterWindow();
 private:
  FlutterDesktopViewControllerRef controller_;
};
#endif