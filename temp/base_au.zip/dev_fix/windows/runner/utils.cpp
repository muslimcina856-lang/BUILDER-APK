#include "utils.h"
std::string Utf8FromWide(const wchar_t* wide) {
  int size = WideCharToMultiByte(CP_UTF8, 0, wide, -1, nullptr, 0, nullptr, nullptr);
  std::string utf8(size, 0);
  WideCharToMultiByte(CP_UTF8, 0, wide, -1, &utf8[0], size, nullptr, nullptr);
  return utf8;
}