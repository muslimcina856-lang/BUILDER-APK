#include "generated_plugin_registrant.h"
#include <flutter/plugin_registry.h>
void RegisterPlugins(flutter::PluginRegistry* registry) {}