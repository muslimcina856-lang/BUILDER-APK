#ifndef GENERATED_PLUGIN_REGISTRANT_H
#define GENERATED_PLUGIN_REGISTRANT_H
#include <flutter/plugin_registry.h>
void RegisterPlugins(flutter::PluginRegistry* registry);
#endif