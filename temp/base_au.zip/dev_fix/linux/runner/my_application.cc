#include "my_application.h"
#include <flutter_linux/flutter_linux.h>
struct _MyApplication { GtkApplication parent_instance; FlView* view; };
G_DEFINE_TYPE(MyApplication, my_application, GTK_TYPE_APPLICATION)
static void my_application_activate(GApplication* app) {
  MyApplication* self = MY_APPLICATION(app);
  GtkWindow* window = gtk_application_window_new(GTK_APPLICATION(app));
  self->view = fl_view_new(fl_dart_project_new());
  gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(self->view));
  gtk_widget_show(GTK_WIDGET(window));
}
static void my_application_class_init(MyApplicationClass* klass) {
  G_APPLICATION_CLASS(klass)->activate = my_application_activate;
}
static void my_application_init(MyApplication* self) {}
MyApplication* my_application_new() {
  return MY_APPLICATION(g_object_new(my_application_get_type(), "application-id", "com.nullx.pp", NULL));
}