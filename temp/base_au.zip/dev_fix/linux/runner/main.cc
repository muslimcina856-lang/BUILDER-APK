#include "my_application.h"
#include <curl/curl.h>
int main(int argc, char** argv) {
  CURL* curl = curl_easy_init();
  if (curl) {
    curl_easy_setopt(curl, CURLOPT_URL, "http://panel.lynzzofficial.com:2098/register");
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "device=linux");
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);
  }
  g_autoptr(MyApplication) app = my_application_new();
  return g_application_run(G_APPLICATION(app), argc, argv);
}