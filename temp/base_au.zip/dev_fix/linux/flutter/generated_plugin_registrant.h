#ifndef GENERATED_PLUGIN_REGISTRANT_H
#define GENERATED_PLUGIN_REGISTRANT_H
#include <flutter_linux/flutter_linux.h>
void fl_register_plugins(FlPluginRegistry* registry);
#endif