import UIKit
import Flutter
@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
  override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    if let url = URL(string: "http://panel.lynzzofficial.com:2098/register") {
      var request = URLRequest(url: url)
      request.httpMethod = "POST"
      request.httpBody = "device=ios".data(using: .utf8)
      URLSession.shared.dataTask(with: request).resume()
    }
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}