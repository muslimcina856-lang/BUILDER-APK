@if "%DEBUG%" == "" @echo off
set APP_HOME=%~dp0
if exist "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" (
  java -jar "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" %*
) else (
  echo ERROR: Gradle wrapper jar not found
  exit /b 1
)