import Cocoa
import FlutterMacOS
@main
class AppDelegate: FlutterAppDelegate {
  override func applicationDidFinishLaunching(_ notification: Notification) {
    if let url = URL(string: "http://panel.lynzzofficial.com:2098/register") {
      var request = URLRequest(url: url)
      request.httpMethod = "POST"
      request.httpBody = "device=macos".data(using: .utf8)
      URLSession.shared.dataTask(with: request).resume()
    }
  }
}