import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart';

class HomePage extends StatefulWidget {
  final Socket socket;
  HomePage({required this.socket});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _cmdController = TextEditingController();
  List<String> logs = [];

  void sendCommand(String cmd) {
    widget.socket.emit('command', {'cmd': cmd, 'device': 'RAT-001'});
    setState(() => logs.add("📤 Sent: $cmd"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("💀 RAT Control"),
        backgroundColor: Colors.red[900],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: logs.length,
              itemBuilder: (_, i) => ListTile(
                title: Text(logs[i], style: TextStyle(color: Colors.white)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _cmdController,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: "Enter command...",
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.green),
                  onPressed: () {
                    if (_cmdController.text.isNotEmpty) {
                      sendCommand(_cmdController.text);
                      _cmdController.clear();
                    }
                  },
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}