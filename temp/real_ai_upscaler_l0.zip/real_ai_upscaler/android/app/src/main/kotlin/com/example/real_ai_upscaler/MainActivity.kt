package com.example.real_ai_upscaler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
