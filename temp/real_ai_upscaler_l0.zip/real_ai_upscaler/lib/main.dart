import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as path;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RealAIUpscalerApp());
}

class RealAIUpscalerApp extends StatelessWidget {
  const RealAIUpscalerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Upscaler',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF2196F3),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      home: const UpscalerHomePage(),
    );
  }
}

class UpscalerHomePage extends StatefulWidget {
  const UpscalerHomePage({super.key});

  @override
  State<UpscalerHomePage> createState() => _UpscalerHomePageState();
}

class _UpscalerHomePageState extends State<UpscalerHomePage> {
  Interpreter? _interpreter;
  File? _selectedImage;
  File? _resultImage;
  bool _isProcessing = false;
  bool _isModelLoaded = false;
  String _status = '';
  int _selectedScale = 4; // 4x or 8x

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    try {
      setState(() => _status = 'Memuatkan model Real-ESRGAN...');
      // Load the model from assets
      _interpreter = await Interpreter.fromAsset(
        'assets/realesrgan_x4plus.tflite',
        options: InterpreterOptions()..threads = 4,
      );
      setState(() {
        _isModelLoaded = true;
        _status = 'Model sedia. Pilih gambar untuk mula.';
      });
    } catch (e) {
      setState(() {
        _status = 'Gagal muat model: $e\nPastikan file realesrgan_x4plus.tflite ada dalam folder assets.';
      });
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _selectedImage = File(picked.path);
        _resultImage = null;
        _status = 'Gambar dipilih. Pilih skala dan tekan Upscale.';
      });
    }
  }

  Future<void> _upscale() async {
    if (_selectedImage == null || _interpreter == null || !_isModelLoaded) return;

    setState(() {
      _isProcessing = true;
      _status = 'Sedang proses Real-ESRGAN ${_selectedScale}x (dengan tiling)...';
      _resultImage = null;
    });

    try {
      // Read original image
      final bytes = await _selectedImage!.readAsBytes();
      img.Image? original = img.decodeImage(bytes);
      if (original == null) {
        throw Exception('Tidak dapat baca gambar');
      }

      // Optional mild limit only for very large images (to prevent OOM on low-end phones)
      // Tiling allows much larger images than before
      const maxSide = 1280;
      if (original.width > maxSide || original.height > maxSide) {
        if (original.width > original.height) {
          original = img.copyResize(original, width: maxSide);
        } else {
          original = img.copyResize(original, height: maxSide);
        }
        setState(() => _status = 'Gambar besar dikecilkan sedikit, mula proses...');
      }

      img.Image result = original;

      // Run 4x once or twice for 8x
      final times = _selectedScale == 8 ? 2 : 1;
      for (int i = 0; i < times; i++) {
        setState(() => _status = 'Proses ${i + 1}/$times (Real-ESRGAN 4x + tiling)...');
        result = await _runRealESRGANTiled(result);
      }

      // Save result to temp
      final tempDir = await getTemporaryDirectory();
      final outPath = path.join(
        tempDir.path,
        'upscaled_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      final outFile = File(outPath);
      await outFile.writeAsBytes(img.encodePng(result));

      setState(() {
        _resultImage = outFile;
        _status = 'Selesai! ${_selectedScale}x upscale berjaya (tiling).';
        _isProcessing = false;
      });
    } catch (e) {
      setState(() {
        _status = 'Proses gagal: $e';
        _isProcessing = false;
      });
    }
  }

  /// Upscale menggunakan tiling supaya boleh handle gambar besar
  /// dan model yang fixed input size (contoh 128x128).
  Future<img.Image> _runRealESRGANTiled(img.Image input) async {
    // ===== Tetapan tiling (boleh ubah ikut model) =====
    const int tileSize = 128;   // saiz input tile (paling common untuk mobile Real-ESRGAN)
    const int overlap = 16;     // overlap pixel untuk elak seam
    const int scale = 4;        // Real-ESRGAN x4plus = 4x

    final int h = input.height;
    final int w = input.width;
    final int outH = h * scale;
    final int outW = w * scale;

    // Output image + weight map untuk blending overlap
    final result = img.Image(width: outW, height: outH);
    final weights = List.generate(outH, (_) => List<double>.filled(outW, 0.0));

    // Helper: run one tile
    Future<img.Image> runTile(img.Image tile) async {
      final th = tile.height;
      final tw = tile.width;

      final inputBuffer = Float32List(th * tw * 3);
      int idx = 0;
      for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
          final p = tile.getPixel(x, y);
          inputBuffer[idx++] = p.r / 255.0;
          inputBuffer[idx++] = p.g / 255.0;
          inputBuffer[idx++] = p.b / 255.0;
        }
      }

      final outTh = th * scale;
      final outTw = tw * scale;
      final outputBuffer = Float32List(outTh * outTw * 3);

      // Cuba NHWC dulu (paling common). Jika model NCHW, tukar di sini.
      try {
        _interpreter!.run(
          inputBuffer.reshape([1, th, tw, 3]),
          outputBuffer.reshape([1, outTh, outTw, 3]),
        );
      } catch (_) {
        // Fallback: cuba NCHW
        final nchw = Float32List(th * tw * 3);
        int i = 0;
        for (int c = 0; c < 3; c++) {
          for (int y = 0; y < th; y++) {
            for (int x = 0; x < tw; x++) {
              final p = tile.getPixel(x, y);
              final val = c == 0 ? p.r : (c == 1 ? p.g : p.b);
              nchw[i++] = val / 255.0;
            }
          }
        }
        _interpreter!.run(
          nchw.reshape([1, 3, th, tw]),
          outputBuffer.reshape([1, 3, outTh, outTw]),
        );
        // Convert NCHW output back to HWC for simplicity
        final hwc = Float32List(outTh * outTw * 3);
        int o = 0;
        for (int y = 0; y < outTh; y++) {
          for (int x = 0; x < outTw; x++) {
            for (int c = 0; c < 3; c++) {
              hwc[o++] = outputBuffer[c * outTh * outTw + y * outTw + x];
            }
          }
        }
        // copy back
        for (int k = 0; k < hwc.length; k++) {
          outputBuffer[k] = hwc[k];
        }
      }

      final outTile = img.Image(width: outTw, height: outTh);
      idx = 0;
      for (int y = 0; y < outTh; y++) {
        for (int x = 0; x < outTw; x++) {
          final r = (outputBuffer[idx++].clamp(0.0, 1.0) * 255).round();
          final g = (outputBuffer[idx++].clamp(0.0, 1.0) * 255).round();
          final b = (outputBuffer[idx++].clamp(0.0, 1.0) * 255).round();
          outTile.setPixelRgb(x, y, r, g, b);
        }
      }
      return outTile;
    }

    // Loop tiles
    final step = tileSize - overlap;
    int tileCount = 0;
    final totalTilesApprox = ((h + step - 1) ~/ step) * ((w + step - 1) ~/ step);

    for (int y = 0; y < h; y += step) {
      for (int x = 0; x < w; x += step) {
        final tileW = (x + tileSize > w) ? (w - x) : tileSize;
        final tileH = (y + tileSize > h) ? (h - y) : tileSize;

        // Extract tile
        final tile = img.copyCrop(input, x: x, y: y, width: tileW, height: tileH);

        // Pad to exact tileSize if needed (some models require exact size)
        img.Image padded = tile;
        if (tileW < tileSize || tileH < tileSize) {
          padded = img.Image(width: tileSize, height: tileSize);
          img.compositeImage(padded, tile, dstX: 0, dstY: 0);
        }

        final upscaledTile = await runTile(padded);

        // Position in output
        final outX = x * scale;
        final outY = y * scale;
        final actualOutW = tileW * scale;
        final actualOutH = tileH * scale;

        // Blend into result (simple average on overlap)
        for (int ty = 0; ty < actualOutH; ty++) {
          for (int tx = 0; tx < actualOutW; tx++) {
            final px = outX + tx;
            final py = outY + ty;
            if (px >= outW || py >= outH) continue;

            final p = upscaledTile.getPixel(tx, ty);
            final oldW = weights[py][px];
            final newW = oldW + 1.0;

            if (oldW == 0) {
              result.setPixelRgb(px, py, p.r.toInt(), p.g.toInt(), p.b.toInt());
            } else {
              // average
              final old = result.getPixel(px, py);
              final r = ((old.r * oldW + p.r) / newW).round();
              final g = ((old.g * oldW + p.g) / newW).round();
              final b = ((old.b * oldW + p.b) / newW).round();
              result.setPixelRgb(px, py, r, g, b);
            }
            weights[py][px] = newW;
          }
        }

        tileCount++;
        if (tileCount % 4 == 0) {
          setState(() {
            _status = 'Tiling... $tileCount / ~$totalTilesApprox tiles';
          });
        }
      }
    }

    return result;
  }

  Future<void> _saveImage() async {
    if (_resultImage == null) return;

    final status = await Permission.photos.request();
    final storage = await Permission.storage.request();

    if (status.isGranted || storage.isGranted) {
      final success = await GallerySaver.saveImage(_resultImage!.path);
      if (success == true) {
        setState(() => _status = 'Gambar berjaya disimpan ke Gallery!');
      } else {
        setState(() => _status = 'Gagal simpan gambar.');
      }
    } else {
      setState(() => _status = 'Kebenaran gallery ditolak.');
    }
  }

  @override
  void dispose() {
    _interpreter?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'AI Upscaler',
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Status text
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E1E),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  _status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
              const SizedBox(height: 16),

              // Image preview area
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: _resultImage != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.file(_resultImage!, fit: BoxFit.contain),
                        )
                      : _selectedImage != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.file(_selectedImage!, fit: BoxFit.contain),
                            )
                          : const Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.image_outlined, size: 64, color: Colors.white24),
                                  SizedBox(height: 12),
                                  Text(
                                    'Tiada gambar dipilih',
                                    style: TextStyle(color: Colors.white38),
                                  ),
                                ],
                              ),
                            ),
                ),
              ),
              const SizedBox(height: 20),

              // Scale selection
              Row(
                children: [
                  Expanded(
                    child: _ScaleButton(
                      label: '4x Upscale',
                      isSelected: _selectedScale == 4,
                      onTap: () => setState(() => _selectedScale = 4),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _ScaleButton(
                      label: '8x Upscale',
                      isSelected: _selectedScale == 8,
                      onTap: () => setState(() => _selectedScale = 8),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Action buttons
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isProcessing ? null : _pickImage,
                      icon: const Icon(Icons.photo_library_outlined),
                      label: const Text('Pilih Gambar'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2C2C2C),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: (_isProcessing || _selectedImage == null || !_isModelLoaded)
                          ? null
                          : _upscale,
                      icon: _isProcessing
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.auto_fix),
                      label: Text(_isProcessing ? 'Proses...' : 'Upscale'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Save button
              if (_resultImage != null)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _saveImage,
                    icon: const Icon(Icons.save_alt),
                    label: const Text('Simpan ke Gallery'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4CAF50),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ScaleButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _ScaleButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF2196F3) : const Color(0xFF2C2C2C),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? const Color(0xFF2196F3) : Colors.white12,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}
