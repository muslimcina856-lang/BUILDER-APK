# AI Upscaler (Real-ESRGAN x4plus)

App Android upscale gambar menggunakan **Real-ESRGAN x4plus** — model yang lebih kuat dari ESRGAN biasa.

Dibina menyerupai app asal "AI Upscaler" (design C).

## Ciri-ciri
- Pilih gambar dari Gallery
- Upscale **4x** (native Real-ESRGAN)
- Upscale **8x** (jalankan 4x dua kali)
- **Tiling** (boleh handle gambar besar + model fixed input size seperti 128×128)
- Preview hasil
- Simpan ke Gallery
- 100% offline

## Cara Setup & Build

### 1. Pasang Flutter
Pastikan Flutter sudah dipasang di komputer anda (https://flutter.dev)

### 2. Dapatkan Model Real-ESRGAN x4plus (.tflite)

Model `realesrgan_x4plus.tflite` **tidak disertakan** kerana saiz besar (~67MB).

Cara dapatkan:

**Pilihan A (disyorkan untuk mobile):**
- Cari "Real-ESRGAN x4plus TFLite" di Hugging Face (Qualcomm atau litert-community)
- Atau convert sendiri dari official Real-ESRGAN PyTorch menggunakan TensorFlow / ONNX → TFLite

**Pilihan B (lebih ringan & recommended untuk phone):**
Guna `realesr-general-x4v3` (~3-5MB) yang lebih sesuai untuk mobile. Tukar nama file dalam `pubspec.yaml` dan kod jika guna model ini.

Letakkan file model ke dalam folder:
```
assets/realesrgan_x4plus.tflite
```

### 3. Setup Project
```bash
cd real_ai_upscaler
flutter create . --project-name real_ai_upscaler --org com.example
flutter pub get
```

### 4. Build APK
```bash
flutter build apk --release
```

APK akan berada di:
`build/app/outputs/flutter-apk/app-release.apk`

## Nota Penting
- **Tiling sudah ditambah**. Default tile size = 128px + overlap 16px (paling sesuai untuk kebanyakan Real-ESRGAN mobile).
- Gambar sangat besar (>1280px) masih dikecilkan sedikit untuk elak OOM di phone low-end.
- Kod cuba NHWC dulu, jika gagal akan cuba NCHW secara automatik.
- Kalau model kau guna saiz tile berbeza (contoh 256), ubah nilai `tileSize` di dalam fungsi `_runRealESRGANTiled`.

## Struktur
```
lib/main.dart          → UI + logic utama
assets/                → letak .tflite di sini
android/               → konfigurasi Android
```

---
Dibina untuk menggantikan ESRGAN lama dengan Real-ESRGAN yang lebih baik.
