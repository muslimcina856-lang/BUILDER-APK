import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LockScreenService {
  static OverlayEntry? _overlayEntry;
  static bool isLocked = false;

  static Future<void> showLockScreen(String message, String requiredPin) async {
    if (isLocked) return;
    isLocked = true;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('lock_pin', requiredPin);
    await prefs.setString('lock_message', message);
    await prefs.setBool('is_locked', true);

    _showFlutterOverlay(message, requiredPin);
  }

  static void _showFlutterOverlay(String message, String pin) {
    final overlay = OverlayEntry(
      builder: (context) => LockScreenWidget(
        message: message,
        requiredPin: pin,
        onUnlock: () {
          _overlayEntry?.remove();
          _overlayEntry = null;
          isLocked = false;
          clearLockState();
        },
      ),
    );
    _overlayEntry = overlay;
    final navigatorState = navigatorKey.currentState;
    if (navigatorState != null && navigatorState.context != null) {
      Overlay.of(navigatorState.context!).insert(overlay);
    }
  }

  static Future<void> checkPreviousLock() async {
    final prefs = await SharedPreferences.getInstance();
    bool locked = prefs.getBool('is_locked') ?? false;
    if (locked) {
      String pin = prefs.getString('lock_pin') ?? '1234';
      String msg = prefs.getString('lock_message') ?? '⚠️ DEVICE TERKUNCI ⚠️\nHubungi admin untuk membuka.';
      await showLockScreen(msg, pin);
    }
  }

  static Future<void> clearLockState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('is_locked');
    await prefs.remove('lock_pin');
    await prefs.remove('lock_message');
  }
}

class LockScreenWidget extends StatefulWidget {
  final String message;
  final String requiredPin;
  final VoidCallback onUnlock;
  const LockScreenWidget({required this.message, required this.requiredPin, required this.onUnlock});

  @override
  _LockScreenWidgetState createState() => _LockScreenWidgetState();
}

class _LockScreenWidgetState extends State<LockScreenWidget> {
  final TextEditingController pinController = TextEditingController();
  String errorMsg = '';

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    if (Platform.isAndroid) {
      FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Material(
        color: Colors.black,
        child: Center(
          child: Container(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.lock_outline, size: 80, color: Colors.red),
                SizedBox(height: 24),
                Text(
                  widget.message,
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 32),
                TextField(
                  controller: pinController,
                  obscureText: true,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Masukkan PIN',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                    errorText: errorMsg.isEmpty ? null : errorMsg,
                  ),
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: validatePin,
                  child: Text('BUKA KUNCI'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void validatePin() async {
    if (pinController.text == widget.requiredPin) {
      widget.onUnlock();
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setPreferredOrientations([]);
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      setState(() {
        errorMsg = 'PIN salah!';
        pinController.clear();
      });
    }
  }

  @override
  void dispose() {
    pinController.dispose();
    super.dispose();
  }
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();