import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAwD4j9ne0kwKFLt5-Kwm5QXatok9GjIHA',
    appId: '1:777954391414:android:36bc8bf334a18727703657',
    messagingSenderId: 'YOUR_SENDER_ID',
    projectId: 'yanzdev-5e9ba',
    databaseURL: 'https://yanzdev-5e9ba-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'yanzdev-5e9ba.firebasestorage.app',
  );
}