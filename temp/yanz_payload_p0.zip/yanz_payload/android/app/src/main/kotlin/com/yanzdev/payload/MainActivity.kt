package com.yanzdev.payload

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()