/* CHIKZX — Full features + fixed auth for APK WebView */
(function () {
  'use strict';

  function $(s, el) { return (el || document).querySelector(s); }
  function $$(s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); }

  var mem = {};
  var store = {
    get: function (k, d) {
      try {
        var v = localStorage.getItem('chikzx_' + k);
        if (v != null) return JSON.parse(v);
      } catch (e) {}
      return mem.hasOwnProperty(k) ? mem[k] : d;
    },
    set: function (k, v) {
      mem[k] = v;
      try { localStorage.setItem('chikzx_' + k, JSON.stringify(v)); } catch (e) {}
    },
    del: function (k) {
      delete mem[k];
      try { localStorage.removeItem('chikzx_' + k); } catch (e) {}
    }
  };

  function toast(msg) {
    var t = $('#toast');
    if (!t) { try { alert(msg); } catch (e) {} return; }
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 2400);
  }

  function fmt(n) {
    var cur = store.get('currency', 'IDR');
    var sym = { IDR: 'Rp ', USD: '$', EUR: '€', SGD: 'S$' }[cur] || (cur + ' ');
    var x = Number(n) || 0;
    if (cur === 'IDR') return sym + Math.round(x).toLocaleString('id-ID');
    return sym + x.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }

  function showScreen(id) {
    $$('.screen').forEach(function (s) { s.classList.remove('active'); });
    var el = $('#' + id);
    if (el) el.classList.add('active');
  }

  function applyTheme() {
    document.body.setAttribute('data-theme', store.get('theme', 'dark'));
  }

  function initStars() {
    try {
      var c = $('#stars');
      if (!c) return;
      var ctx = c.getContext('2d');
      var w, h, pts = [];
      function resize() {
        w = c.width = window.innerWidth;
        h = c.height = window.innerHeight;
        pts = [];
        for (var i = 0; i < 100; i++) pts.push({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.3 + 0.2, a: Math.random(), s: Math.random() * 0.3 + 0.05 });
      }
      function draw() {
        ctx.clearRect(0, 0, w, h);
        for (var i = 0; i < pts.length; i++) {
          var p = pts[i];
          p.a += p.s * 0.02;
          ctx.globalAlpha = 0.3 + Math.abs(Math.sin(p.a)) * 0.7;
          ctx.fillStyle = '#c7d2fe';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fill();
        }
        requestAnimationFrame(draw);
      }
      resize();
      window.addEventListener('resize', resize);
      draw();
    } catch (e) {}
  }

  function bindAuth() {
    var users = store.get('users', {});
    if (!users.demo) { users.demo = { pass: 'demo', nama: 'Demo User' }; store.set('users', users); }

    $$('.sleek-tabs .tab').forEach(function (btn) {
      btn.onclick = function () {
        $$('.sleek-tabs .tab').forEach(function (b) { b.classList.remove('on'); });
        btn.classList.add('on');
        var reg = btn.getAttribute('data-tab') === 'up';
        if ($('#form-login')) $('#form-login').classList.toggle('hidden', reg);
        if ($('#form-reg')) $('#form-reg').classList.toggle('hidden', !reg);
      };
    });

    function doRegister() {
      var users = store.get('users', {});
      var u = (($('#reg-user') && $('#reg-user').value) || '').trim().toLowerCase();
      var p = ($('#reg-pass') && $('#reg-pass').value) || '';
      var n = (($('#reg-nama') && $('#reg-nama').value) || '').trim();
      if (!u || !p || !n) return toast('Isi semua field');
      if (p.length < 4) return toast('Password min 4 karakter');
      if (users[u]) return toast('Username sudah dipakai');
      users[u] = { pass: p, nama: n };
      store.set('users', users);
      toast('Daftar berhasil! Silakan masuk');
      var tab = $$('.sleek-tabs .tab')[0];
      if (tab) tab.click();
      if ($('#login-user')) $('#login-user').value = u;
    }

    function doLogin() {
      var users = store.get('users', {});
      var u = (($('#login-user') && $('#login-user').value) || '').trim().toLowerCase();
      var p = ($('#login-pass') && $('#login-pass').value) || '';
      if (!u || !p) return toast('Isi username & password');
      if (!users[u] || users[u].pass !== p) return toast('Username / password salah');
      store.set('pending_user', { username: u, nama: users[u].nama });
      $$('#otp-inputs input').forEach(function (i) { i.value = ''; });
      showScreen('screen-otp');
    }

    var formReg = $('#form-reg'), formLogin = $('#form-login');
    if (formReg) {
      formReg.onsubmit = function (e) { e.preventDefault(); doRegister(); return false; };
      var btnR = formReg.querySelector('button');
      if (btnR) btnR.onclick = function (e) { e.preventDefault(); doRegister(); };
    }
    if (formLogin) {
      formLogin.onsubmit = function (e) { e.preventDefault(); doLogin(); return false; };
      var btnL = formLogin.querySelector('button');
      if (btnL) btnL.onclick = function (e) { e.preventDefault(); doLogin(); };
    }

    var otpInputs = $$('#otp-inputs input');
    otpInputs.forEach(function (inp, i) {
      inp.addEventListener('input', function () {
        inp.value = String(inp.value).replace(/\D/g, '').slice(0, 1);
        if (inp.value && i < otpInputs.length - 1) otpInputs[i + 1].focus();
      });
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Backspace' && !inp.value && i > 0) otpInputs[i - 1].focus();
      });
    });
    if ($('#btn-otp')) $('#btn-otp').onclick = function () {
      var code = otpInputs.map(function (i) { return i.value; }).join('');
      if (code.length < 6) return toast('Isi 6 digit OTP');
      if (code !== '123456') return toast('OTP salah — demo: 123456');
      var pend = store.get('pending_user');
      if (!pend) return showScreen('screen-login');
      store.set('session', pend);
      store.del('pending_user');
      enterApp();
    };
    if ($('#btn-resend')) $('#btn-resend').onclick = function () { toast('OTP demo: 123456'); };

    var otpCard = $('.otp-card');
    if (otpCard && !$('#btn-skip-otp')) {
      var sk = document.createElement('button');
      sk.id = 'btn-skip-otp';
      sk.className = 'btn-text';
      sk.textContent = 'Lewati OTP (demo)';
      sk.onclick = function () {
        var pend = store.get('pending_user');
        if (!pend) return;
        store.set('session', pend);
        store.del('pending_user');
        enterApp();
      };
      otpCard.appendChild(sk);
    }
  }

  function enterApp() {
    var s = store.get('session');
    if (!s) return showScreen('screen-login');
    if ($('#sb-user')) $('#sb-user').textContent = s.nama || s.username;
    applyTheme();
    showScreen('screen-app');
    checkBillNotif();
    navTo('home');
  }

  function closeSb() {
    if ($('#sidebar')) $('#sidebar').classList.remove('open');
    if ($('#sidebar-overlay')) $('#sidebar-overlay').classList.remove('open');
  }

  function bindShell() {
    if ($('#menu-btn')) $('#menu-btn').onclick = function () {
      $('#sidebar').classList.add('open');
      $('#sidebar-overlay').classList.add('open');
    };
    if ($('#sidebar-overlay')) $('#sidebar-overlay').onclick = closeSb;
    if ($('#btn-logout')) $('#btn-logout').onclick = function () {
      store.del('session');
      showScreen('screen-login');
    };
    $$('.nav-item').forEach(function (a) {
      a.onclick = function (e) {
        e.preventDefault();
        $$('.nav-item').forEach(function (x) { x.classList.remove('active'); });
        a.classList.add('active');
        closeSb();
        navTo(a.getAttribute('data-page'));
      };
    });
  }

  var titles = {
    home: 'Dashboard', tx: 'Transaksi', market: 'Pasar Live', portfolio: 'Portfolio',
    budget: 'Anggaran', goal: 'Target', calc: 'Kalkulator', bills: 'Tagihan',
    scan: 'Scan Struk', candle: 'Chart Candle', settings: 'Pengaturan',
    loan: 'Pinjaman', export: 'Export'
  };

  function navTo(page) {
    if ($('#page-title')) $('#page-title').textContent = titles[page] || page;
    var map = {
      home: pageHome, tx: pageTx, market: pageMarket, portfolio: pagePort,
      budget: pageBudget, goal: pageGoal, calc: pageCalc, bills: pageBills,
      scan: pageScan, candle: pageCandle, settings: pageSettings,
      loan: pageLoan, export: pageExport
    };
    (map[page] || pageHome)();
  }

  function txs() { return store.get('txs', []); }
  function setTxs(v) { store.set('txs', v); }
  function portfolio() { return store.get('portfolio', []); }
  function setPort(v) { store.set('portfolio', v); }
  function bills() { return store.get('bills', []); }
  function setBills(v) { store.set('bills', v); }
  function loans() { return store.get('loans', []); }
  function setLoans(v) { store.set('loans', v); }

  function summary() {
    var list = txs(), month = new Date().toISOString().slice(0, 7);
    var pem = 0, peng = 0, allP = 0, allG = 0;
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      if (t.jenis === 'pemasukan') { allP += t.jumlah; if (t.tanggal.indexOf(month) === 0) pem += t.jumlah; }
      else { allG += t.jumlah; if (t.tanggal.indexOf(month) === 0) peng += t.jumlah; }
    }
    return { pem: pem, peng: peng, sisa: pem - peng, saldo: allP - allG };
  }

  var BASE = { BBCA: 9250, BBRI: 4980, TLKM: 3120, ASII: 4850, GOTO: 58, BTC: 1580000000, ETH: 52000000, GOLD: 1450000, USDIDR: 15850 };
  var NAMES = { BBCA: 'Bank BCA', BBRI: 'Bank BRI', TLKM: 'Telkom', ASII: 'Astra', GOTO: 'GoTo', BTC: 'Bitcoin', ETH: 'Ethereum', GOLD: 'Emas', USDIDR: 'USD/IDR' };
  var market = {}, candleHist = {};
  Object.keys(BASE).forEach(function (k) {
    market[k] = { harga: BASE[k], prev: BASE[k] };
    candleHist[k] = [];
    var p = BASE[k];
    for (var i = 0; i < 30; i++) {
      var o = p;
      p = p * (1 + (Math.random() * 0.04 - 0.02));
      candleHist[k].push({ o: o, h: Math.max(o, p) * 1.01, l: Math.min(o, p) * 0.99, c: p });
    }
  });

  var marketMode = 'live'; // live = API real, sim = offline
  var lastFetch = 0;

  function tickMarketSim() {
    Object.keys(market).forEach(function (k) {
      var ch = market[k].harga * (Math.random() * 0.016 - 0.008);
      market[k].prev = market[k].harga;
      market[k].harga = Math.max(BASE[k] * 0.5, market[k].harga + ch);
      market[k].harga = market[k].harga > 1000 ? Math.round(market[k].harga) : Math.round(market[k].harga * 100) / 100;
      var o = market[k].prev, c = market[k].harga;
      candleHist[k].push({ o: o, h: Math.max(o, c) * 1.002, l: Math.min(o, c) * 0.998, c: c });
      if (candleHist[k].length > 40) candleHist[k].shift();
    });
  }

  function tickMarket() {
    // try real prices every 30s; between that soft-sim for motion
    var now = Date.now();
    if (now - lastFetch > 30000) {
      lastFetch = now;
      fetchRealPrices();
    } else {
      tickMarketSim();
    }
  }

  function fetchRealPrices() {
    // CoinGecko free API — real crypto prices (USD), convert rough IDR
    var url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=idr,usd&include_24hr_change=true';
    fetch(url).then(function (r) { return r.json(); }).then(function (d) {
      marketMode = 'live';
      var map = { BTC: d.bitcoin, ETH: d.ethereum, SOL: d.solana };
      Object.keys(map).forEach(function (sym) {
        if (!map[sym] || !market[sym]) return;
        var harga = map[sym].idr || (map[sym].usd * 15850);
        market[sym].prev = market[sym].harga;
        market[sym].harga = Math.round(harga);
        market[sym].real = true;
        market[sym].change24 = map[sym].usd_24h_change || 0;
        var o = market[sym].prev, c = market[sym].harga;
        candleHist[sym].push({ o: o, h: Math.max(o, c) * 1.001, l: Math.min(o, c) * 0.999, c: c });
        if (candleHist[sym].length > 40) candleHist[sym].shift();
      });
      // keep stocks as marked simulation
      ['BBCA','BBRI','TLKM','ASII','GOTO','GOLD','USDIDR'].forEach(function (k) {
        if (market[k]) market[k].real = false;
      });
    }).catch(function () {
      marketMode = 'sim';
      tickMarketSim();
    });
  }

  function checkBillNotif() {
    var today = new Date().toISOString().slice(0, 10);
    var list = bills().filter(function (b) { return !b.paid && b.due <= today; });
    if (list.length) toast('⚠ ' + list.length + ' tagihan jatuh tempo!');
  }

  function pageHome() {
    var s = summary();
    var overdue = bills().filter(function (b) { return !b.paid && b.due <= new Date().toISOString().slice(0, 10); }).length;
    $('#content').innerHTML = '<div class="stat-row">' +
      '<div class="stat"><div class="l">Pemasukan</div><div class="v up">' + fmt(s.pem) + '</div></div>' +
      '<div class="stat"><div class="l">Pengeluaran</div><div class="v down">' + fmt(s.peng) + '</div></div>' +
      '<div class="stat"><div class="l">Saldo</div><div class="v">' + fmt(s.saldo) + '</div></div>' +
      '<div class="stat"><div class="l">Tagihan due</div><div class="v ' + (overdue ? 'down' : '') + '">' + overdue + '</div></div></div>' +
      '<div class="panel"><div class="panel-h">Transaksi terbaru</div><div class="panel-b" style="padding:0">' + renderTxTable(txs().slice(0, 8)) + '</div></div>';
  }

  function renderTxTable(list) {
    if (!list.length) return '<p class="empty">Belum ada transaksi</p>';
    var h = '<table class="data"><thead><tr><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Jumlah</th></tr></thead><tbody>';
    list.forEach(function (t) {
      var cls = t.jenis === 'pemasukan' ? 'up' : 'down';
      h += '<tr><td>' + t.tanggal + '</td><td class="' + cls + '">' + t.jenis + '</td><td>' + t.kategori + '</td><td class="' + cls + '">' + fmt(t.jumlah) + '</td></tr>';
    });
    return h + '</tbody></table>';
  }

  function pageTx() {
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Tambah transaksi</div><div class="panel-b">' +
      '<select class="inp" id="tx-jenis"><option value="pengeluaran">Pengeluaran</option><option value="pemasukan">Pemasukan</option></select>' +
      '<select class="inp" id="tx-kat"><option>Makanan</option><option>Transportasi</option><option>Tagihan</option><option>Belanja</option><option>Gaji</option><option>Freelance</option><option>Lainnya</option></select>' +
      '<input class="inp" id="tx-jml" type="number" placeholder="Jumlah"><input class="inp" id="tx-ket" placeholder="Keterangan">' +
      '<button class="btn-sm" id="tx-save">Simpan</button></div></div>' +
      '<div class="panel"><div class="panel-h">Riwayat</div><div class="panel-b" style="padding:0" id="tx-list"></div></div>';
    $('#tx-list').innerHTML = renderTxTable(txs());
    $('#tx-save').onclick = function () {
      var jumlah = Number($('#tx-jml').value);
      if (jumlah <= 0) return toast('Jumlah tidak valid');
      var list = txs();
      list.unshift({ id: Date.now(), tanggal: new Date().toISOString().slice(0, 10), jenis: $('#tx-jenis').value, kategori: $('#tx-kat').value, jumlah: jumlah, ket: $('#tx-ket').value.trim() });
      setTxs(list); toast('Tersimpan'); pageTx();
    };
  }

  var marketTimer;
  function pageMarket() {
    clearInterval(marketTimer);
    tickMarket(); renderMarket();
    marketTimer = setInterval(function () { tickMarket(); renderMarket(); }, 2000);
  }
  function renderMarket() {
    if ($('#page-title').textContent !== 'Pasar Live') { clearInterval(marketTimer); return; }
    var rows = Object.keys(market).map(function (sym) {
      var m = market[sym], pct = m.prev ? ((m.harga - m.prev) / m.prev * 100) : 0, cls = pct >= 0 ? 'up' : 'down';
      return '<tr><td><b style="color:#60a5fa">' + sym + '</b><br><small style="color:#9ca3af">' + NAMES[sym] + '</small></td><td>' + fmt(m.harga) + '</td><td class="' + cls + '">' + (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%</td><td><button class="btn-sm" data-buy="' + sym + '">Beli</button></td></tr>';
    }).join('');
    var badge = marketMode === 'live' ? '🟢 DATA REAL (kripto CoinGecko)' : '🟡 SIMULASI (offline)';
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Pasar — ' + badge + '</div><div class="panel-b" style="padding:0"><table class="data"><thead><tr><th>Simbol</th><th>Harga</th><th>%</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div></div>';
    $$('[data-buy]').forEach(function (b) {
      b.onclick = function () {
        var sym = b.getAttribute('data-buy'), jml = Number(prompt('Jumlah unit ' + sym + ':', '1'));
        if (!jml || jml <= 0) return;
        var list = portfolio();
        list.push({ id: Date.now(), simbol: sym, nama: NAMES[sym], jumlah: jml, harga_beli: market[sym].harga });
        setPort(list); toast('Beli ' + sym + ' OK');
      };
    });
  }

  function pagePort() {
    var list = portfolio(), nilai = 0, modal = 0;
    var rows = list.map(function (p) {
      var now = market[p.simbol] ? market[p.simbol].harga : p.harga_beli, n = now * p.jumlah, m = p.harga_beli * p.jumlah, pl = n - m;
      nilai += n; modal += m;
      return '<tr><td><b>' + p.simbol + '</b></td><td>' + p.jumlah + '</td><td>' + fmt(p.harga_beli) + '</td><td>' + fmt(now) + '</td><td class="' + (pl >= 0 ? 'up' : 'down') + '">' + fmt(pl) + '</td><td><button class="btn-sm danger" data-sell="' + p.id + '">Jual</button></td></tr>';
    }).join('');
    $('#content').innerHTML = '<div class="stat-row"><div class="stat"><div class="l">Nilai</div><div class="v">' + fmt(nilai) + '</div></div><div class="stat"><div class="l">Modal</div><div class="v">' + fmt(modal) + '</div></div><div class="stat"><div class="l">P/L</div><div class="v ' + (nilai - modal >= 0 ? 'up' : 'down') + '">' + fmt(nilai - modal) + '</div></div></div>' +
      '<div class="panel"><div class="panel-h">Kepemilikan</div><div class="panel-b" style="padding:0">' + (list.length ? '<table class="data"><thead><tr><th>Simbol</th><th>Jml</th><th>Beli</th><th>Now</th><th>P/L</th><th></th></tr></thead><tbody>' + rows + '</tbody></table>' : '<p class="empty">Belum ada posisi</p>') + '</div></div>';
    $$('[data-sell]').forEach(function (b) {
      b.onclick = function () {
        setPort(portfolio().filter(function (x) { return x.id !== Number(b.getAttribute('data-sell')); }));
        toast('Terjual'); pagePort();
      };
    });
  }

  function pageBudget() {
    var budgets = store.get('budgets', {}), month = new Date().toISOString().slice(0, 7), spent = {};
    txs().forEach(function (t) { if (t.jenis === 'pengeluaran' && t.tanggal.indexOf(month) === 0) spent[t.kategori] = (spent[t.kategori] || 0) + t.jumlah; });
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Atur anggaran</div><div class="panel-b"><select class="inp" id="b-kat"><option>Makanan</option><option>Transportasi</option><option>Tagihan</option><option>Belanja</option><option>Lainnya</option></select><input class="inp" id="b-limit" type="number" placeholder="Batas"><button class="btn-sm" id="b-save">Simpan</button></div></div><div class="panel"><div class="panel-h">Status</div><div class="panel-b" id="b-list"></div></div>';
    var keys = Object.keys(budgets);
    $('#b-list').innerHTML = keys.length ? keys.map(function (k) {
      var use = spent[k] || 0, lim = budgets[k], pct = Math.min(100, use / lim * 100);
      return '<div style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;font-size:13px"><b>' + k + '</b><span>' + fmt(use) + ' / ' + fmt(lim) + '</span></div><div style="height:8px;background:#1f2937;border-radius:4px"><div style="height:100%;width:' + pct + '%;background:' + (pct > 90 ? '#ef4444' : '#22c55e') + '"></div></div></div>';
    }).join('') : '<p class="empty">Belum ada anggaran</p>';
    $('#b-save').onclick = function () {
      var k = $('#b-kat').value, lim = Number($('#b-limit').value);
      if (lim <= 0) return toast('Tidak valid');
      budgets[k] = lim; store.set('budgets', budgets); toast('OK'); pageBudget();
    };
  }

  function pageGoal() {
    var goals = store.get('goals', []);
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Buat target</div><div class="panel-b"><input class="inp" id="g-nama" placeholder="Nama"><input class="inp" id="g-target" type="number" placeholder="Target"><button class="btn-sm" id="g-save">Buat</button></div></div><div class="panel"><div class="panel-h">Daftar</div><div class="panel-b" id="g-list"></div></div>';
    $('#g-list').innerHTML = goals.length ? goals.map(function (g, i) {
      var pct = Math.min(100, g.terkumpul / g.target * 100);
      return '<div style="border:1px solid #1f2937;border-radius:10px;padding:12px;margin-bottom:10px"><b>' + g.nama + '</b><div style="font-size:12px;color:#9ca3af">' + fmt(g.terkumpul) + ' / ' + fmt(g.target) + '</div><div style="height:8px;background:#1f2937;border-radius:4px;margin:6px 0"><div style="height:100%;width:' + pct + '%;background:#3b82f6"></div></div><div style="display:flex;gap:8px"><input class="inp" id="setor-' + i + '" type="number" placeholder="Setor" style="margin:0"><button class="btn-sm" data-setor="' + i + '">Setor</button><button class="btn-sm ghost" data-gdel="' + i + '">Hapus</button></div></div>';
    }).join('') : '<p class="empty">Belum ada target</p>';
    $('#g-save').onclick = function () {
      var nama = $('#g-nama').value.trim(), target = Number($('#g-target').value);
      if (!nama || target <= 0) return toast('Tidak valid');
      goals.push({ nama: nama, target: target, terkumpul: 0 }); store.set('goals', goals); pageGoal();
    };
    $$('[data-setor]').forEach(function (b) {
      b.onclick = function () {
        var i = Number(b.getAttribute('data-setor')), j = Number($('#setor-' + i).value);
        if (j <= 0) return;
        goals[i].terkumpul += j; store.set('goals', goals); toast(goals[i].terkumpul >= goals[i].target ? 'Target tercapai!' : 'Setoran OK'); pageGoal();
      };
    });
    $$('[data-gdel]').forEach(function (b) {
      b.onclick = function () { goals.splice(Number(b.getAttribute('data-gdel')), 1); store.set('goals', goals); pageGoal(); };
    });
  }

  function pageCalc() {
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Kalkulator bunga</div><div class="panel-b"><input class="inp" id="c-pokok" type="number" placeholder="Modal"><input class="inp" id="c-bunga" type="number" placeholder="Bunga % / tahun"><input class="inp" id="c-tahun" type="number" value="1"><select class="inp" id="c-tipe"><option value="tunggal">Tunggal</option><option value="majemuk">Majemuk</option></select><button class="btn-sm" id="c-go">Hitung</button><div id="c-out" style="margin-top:12px"></div></div></div>';
    $('#c-go').onclick = function () {
      var pokok = Number($('#c-pokok').value), bunga = Number($('#c-bunga').value), tahun = Number($('#c-tahun').value) || 1;
      var total = $('#c-tipe').value === 'majemuk' ? pokok * Math.pow(1 + bunga / 100, tahun) : pokok + pokok * bunga / 100 * tahun;
      if (pokok <= 0) return toast('Modal tidak valid');
      $('#c-out').innerHTML = '<div class="stat-row"><div class="stat"><div class="l">Bunga</div><div class="v up">' + fmt(total - pokok) + '</div></div><div class="stat"><div class="l">Total</div><div class="v">' + fmt(total) + '</div></div></div>';
    };
  }

  function pageBills() {
    var list = bills(), today = new Date().toISOString().slice(0, 10);
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Tambah tagihan</div><div class="panel-b"><input class="inp" id="bill-nama" placeholder="Nama tagihan"><input class="inp" id="bill-jml" type="number" placeholder="Jumlah"><input class="inp" id="bill-due" type="date"><button class="btn-sm" id="bill-save">Simpan</button></div></div><div class="panel"><div class="panel-h">Daftar</div><div class="panel-b" id="bill-list"></div></div>';
    if ($('#bill-due')) $('#bill-due').value = today;
    $('#bill-list').innerHTML = list.length ? list.map(function (b, i) {
      var overdue = !b.paid && b.due <= today;
      return '<div style="border:1px solid #1f2937;border-radius:10px;padding:12px;margin-bottom:8px"><div style="display:flex;justify-content:space-between"><b>' + b.nama + '</b><span class="' + (b.paid ? 'up' : overdue ? 'down' : '') + '">' + (b.paid ? 'Lunas' : overdue ? 'OVERDUE' : 'Pending') + '</span></div><div style="font-size:12px;color:#9ca3af">' + fmt(b.jumlah) + ' · Due ' + b.due + '</div>' + (!b.paid ? '<button class="btn-sm" style="margin-top:8px" data-paid="' + i + '">Tandai lunas</button> ' : '') + '<button class="btn-sm ghost" style="margin-top:8px" data-bdel="' + i + '">Hapus</button></div>';
    }).join('') : '<p class="empty">Belum ada tagihan</p>';
    $('#bill-save').onclick = function () {
      var nama = $('#bill-nama').value.trim(), jumlah = Number($('#bill-jml').value), due = $('#bill-due').value;
      if (!nama || jumlah <= 0 || !due) return toast('Lengkapi data');
      list.push({ nama: nama, jumlah: jumlah, due: due, paid: false }); setBills(list); toast('OK'); pageBills();
    };
    $$('[data-paid]').forEach(function (b) {
      b.onclick = function () {
        var i = Number(b.getAttribute('data-paid'));
        list[i].paid = true; setBills(list);
        var tx = txs(); tx.unshift({ id: Date.now(), tanggal: today, jenis: 'pengeluaran', kategori: 'Tagihan', jumlah: list[i].jumlah, ket: list[i].nama }); setTxs(tx);
        toast('Lunas & dicatat'); pageBills();
      };
    });
    $$('[data-bdel]').forEach(function (b) {
      b.onclick = function () { list.splice(Number(b.getAttribute('data-bdel')), 1); setBills(list); pageBills(); };
    });
  }

  function pageScan() {
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Scan / Upload struk</div><div class="panel-b"><p class="muted" style="margin-bottom:12px">Foto struk atau pilih galeri, lalu isi nominal.</p><input type="file" id="scan-file" accept="image/*" capture="environment" class="inp" style="padding:8px"><div id="scan-preview" style="margin:12px 0;text-align:center"></div><input class="inp" id="scan-jml" type="number" placeholder="Jumlah di struk"><input class="inp" id="scan-ket" placeholder="Keterangan"><select class="inp" id="scan-kat"><option>Makanan</option><option>Belanja</option><option>Transportasi</option><option>Lainnya</option></select><button class="btn-sm" id="scan-save">Simpan pengeluaran</button></div></div>';
    $('#scan-file').onchange = function () {
      var f = this.files && this.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () { $('#scan-preview').innerHTML = '<img src="' + r.result + '" style="max-width:100%;max-height:200px;border-radius:10px">'; };
      r.readAsDataURL(f);
    };
    $('#scan-save').onclick = function () {
      var jumlah = Number($('#scan-jml').value); if (jumlah <= 0) return toast('Isi jumlah');
      var list = txs();
      list.unshift({ id: Date.now(), tanggal: new Date().toISOString().slice(0, 10), jenis: 'pengeluaran', kategori: $('#scan-kat').value, jumlah: jumlah, ket: '[Struk] ' + ($('#scan-ket').value || '') });
      setTxs(list); toast('Struk dicatat'); navTo('tx');
    };
  }

  function pageCandle() {
    var sym = 'BBCA';
    function draw() {
      var hist = candleHist[sym] || [], w = Math.min(360, window.innerWidth - 48), h = 200, max = 0, min = Infinity;
      hist.forEach(function (c) { if (c.h > max) max = c.h; if (c.l < min) min = c.l; });
      var range = max - min || 1, bw = w / hist.length - 2, svg = '<svg width="' + w + '" height="' + h + '" style="display:block;margin:0 auto">';
      hist.forEach(function (c, i) {
        var x = i * (w / hist.length) + 1;
        var yO = h - ((c.o - min) / range) * (h - 20) - 10, yC = h - ((c.c - min) / range) * (h - 20) - 10;
        var yH = h - ((c.h - min) / range) * (h - 20) - 10, yL = h - ((c.l - min) / range) * (h - 20) - 10;
        var col = c.c >= c.o ? '#22c55e' : '#ef4444';
        svg += '<line x1="' + (x + bw / 2) + '" y1="' + yH + '" x2="' + (x + bw / 2) + '" y2="' + yL + '" stroke="' + col + '" stroke-width="1"/>';
        svg += '<rect x="' + x + '" y="' + Math.min(yO, yC) + '" width="' + Math.max(bw, 2) + '" height="' + Math.max(Math.abs(yC - yO), 1) + '" fill="' + col + '"/>';
      });
      svg += '</svg>';
      $('#candle-box').innerHTML = '<div style="text-align:center;margin-bottom:8px"><b style="color:#60a5fa">' + sym + '</b> · ' + fmt(market[sym] ? market[sym].harga : 0) + '</div>' + svg;
    }
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Chart Candle</div><div class="panel-b"><select class="inp" id="candle-sym">' + Object.keys(BASE).map(function (k) { return '<option value="' + k + '">' + k + '</option>'; }).join('') + '</select><div id="candle-box"></div></div></div>';
    $('#candle-sym').onchange = function () { sym = this.value; draw(); };
    draw();
    clearInterval(window._candleTimer);
    window._candleTimer = setInterval(function () {
      if ($('#page-title').textContent !== 'Chart Candle') { clearInterval(window._candleTimer); return; }
      tickMarket(); draw();
    }, 2000);
  }

  function pageLoan() {
    var list = loans();
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Catat pinjaman</div><div class="panel-b"><input class="inp" id="ln-nama" placeholder="Nama"><input class="inp" id="ln-total" type="number" placeholder="Total"><input class="inp" id="ln-sisa" type="number" placeholder="Sisa"><input class="inp" id="ln-cicil" type="number" placeholder="Cicilan/bulan"><button class="btn-sm" id="ln-save">Simpan</button></div></div>' +
      '<div class="panel"><div class="panel-h">Kalkulator cicilan</div><div class="panel-b"><input class="inp" id="lc-pokok" type="number" placeholder="Pokok"><input class="inp" id="lc-bunga" type="number" placeholder="Bunga %/thn"><input class="inp" id="lc-bln" type="number" value="12" placeholder="Tenor bulan"><button class="btn-sm" id="lc-go">Hitung</button><div id="lc-out" style="margin-top:10px"></div></div></div>' +
      '<div class="panel"><div class="panel-h">Daftar</div><div class="panel-b" id="ln-list"></div></div>';
    $('#ln-list').innerHTML = list.length ? list.map(function (l, i) {
      return '<div style="border:1px solid #1f2937;border-radius:10px;padding:12px;margin-bottom:8px"><b>' + l.nama + '</b><div style="font-size:12px;color:#9ca3af">Sisa ' + fmt(l.sisa) + ' / ' + fmt(l.total) + ' · Cicilan ' + fmt(l.cicil) + '/bln</div><button class="btn-sm ghost" style="margin-top:6px" data-ldel="' + i + '">Hapus</button></div>';
    }).join('') : '<p class="empty">Belum ada pinjaman</p>';
    $('#ln-save').onclick = function () {
      var nama = $('#ln-nama').value.trim(), total = Number($('#ln-total').value), sisa = Number($('#ln-sisa').value), cicil = Number($('#ln-cicil').value);
      if (!nama || total <= 0) return toast('Lengkapi data');
      list.push({ nama: nama, total: total, sisa: sisa || total, cicil: cicil || 0 }); setLoans(list); toast('OK'); pageLoan();
    };
    $('#lc-go').onclick = function () {
      var P = Number($('#lc-pokok').value), r = Number($('#lc-bunga').value) / 100 / 12, n = Number($('#lc-bln').value) || 12;
      if (P <= 0) return toast('Pokok tidak valid');
      var c = r === 0 ? P / n : P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      $('#lc-out').innerHTML = '<div class="stat"><div class="l">Cicilan / bulan</div><div class="v">' + fmt(c) + '</div></div><div class="stat" style="margin-top:8px"><div class="l">Total bayar</div><div class="v">' + fmt(c * n) + '</div></div>';
    };
    $$('[data-ldel]').forEach(function (b) {
      b.onclick = function () { list.splice(Number(b.getAttribute('data-ldel')), 1); setLoans(list); pageLoan(); };
    });
  }

  function pageExport() {
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Export & Sync</div><div class="panel-b"><button class="btn-sm" id="ex-tx">Export Transaksi CSV</button> <button class="btn-sm ghost" id="ex-port">Export Portfolio</button> <button class="btn-sm ghost" id="ex-bills">Export Tagihan</button><p class="empty" style="padding:12px 0">Sync butuh URL server di Pengaturan</p><button class="btn-sm" id="ex-sync">Cek Server / Sync</button></div></div>';
    function dl(name, rows) {
      var csv = rows.map(function (r) { return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(','); }).join('\n');
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = name; a.click(); toast('Export: ' + name);
    }
    $('#ex-tx').onclick = function () {
      var rows = [['Tanggal', 'Jenis', 'Kategori', 'Jumlah', 'Ket']];
      txs().forEach(function (t) { rows.push([t.tanggal, t.jenis, t.kategori, t.jumlah, t.ket || '']); });
      dl('chikzx_transaksi.csv', rows);
    };
    $('#ex-port').onclick = function () {
      var rows = [['Simbol', 'Nama', 'Jumlah', 'Harga Beli']];
      portfolio().forEach(function (p) { rows.push([p.simbol, p.nama, p.jumlah, p.harga_beli]); });
      dl('chikzx_portfolio.csv', rows);
    };
    $('#ex-bills').onclick = function () {
      var rows = [['Nama', 'Jumlah', 'Due', 'Lunas']];
      bills().forEach(function (b) { rows.push([b.nama, b.jumlah, b.due, b.paid ? 'Ya' : 'Tidak']); });
      dl('chikzx_tagihan.csv', rows);
    };
    $('#ex-sync').onclick = function () {
      var url = store.get('api_url', '');
      if (!url) return toast('Isi URL server di Pengaturan');
      fetch(url.replace(/\/$/, '') + '/api/health').then(function (r) {
        if (!r.ok) throw new Error('x');
        toast('Server online');
      }).catch(function () { toast('Server tidak terjangkau — data tetap di HP'); });
    };
  }

  function pageSettings() {
    $('#content').innerHTML = '<div class="panel"><div class="panel-h">Pengaturan</div><div class="panel-b"><label class="muted">Mata uang</label><select class="inp" id="set-cur"><option value="IDR">IDR</option><option value="USD">USD</option><option value="EUR">EUR</option><option value="SGD">SGD</option></select><label class="muted">Tema</label><select class="inp" id="set-theme"><option value="dark">Dark</option><option value="light">Light</option></select><label class="muted">URL Server API</label><input class="inp" id="set-api" placeholder="https://server.com"><button class="btn-sm" id="set-save">Simpan</button></div></div>';
    $('#set-cur').value = store.get('currency', 'IDR');
    $('#set-theme').value = store.get('theme', 'dark');
    $('#set-api').value = store.get('api_url', '');
    $('#set-save').onclick = function () {
      store.set('currency', $('#set-cur').value);
      store.set('theme', $('#set-theme').value);
      store.set('api_url', $('#set-api').value.trim());
      applyTheme(); toast('Disimpan');
    };
  }

  function boot() {
    applyTheme();
    initStars();
    bindAuth();
    bindShell();
    if (store.get('session')) enterApp();
    else showScreen('screen-login');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
