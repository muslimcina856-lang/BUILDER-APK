# CHIKZX APK

App keuangan + trading dengan UI:
- Sleek login menu
- OTP verification (demo: 123456)
- Responsive sidebar
- Black hole animated background
- Dashboard, transaksi, pasar live, portfolio, anggaran, target, kalkulator

## Build APK
Kirim zip ini ke BOT BUILD APK → pilih **Capacitor** atau **Ionic**.

Akun demo: username `demo` / password `demo`  
OTP demo: `123456`
