package my.tangga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Bab
import my.tangga.Keadaan

@Composable
fun PetaSkrin(k: Keadaan, padaBuka: (Int) -> Unit) {
    var lompat by remember { mutableStateOf("") }
    val siapSemua = k.progres.siap.size

    Column(Modifier.fillMaxSize().background(Warna.Dasar)) {

        // Bar tajuk
        Row(
            Modifier
                .fillMaxWidth()
                .background(Warna.Panel)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "TANGGA",
                color = Warna.Oker,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 4.sp,
            )
            Spacer(Modifier.weight(1f))
            Text(
                "$siapSemua/${k.jumlahLevel}  ·  ${k.progres.xp} XP  ·  ${k.progres.rentetan} hari",
                color = Warna.Senyap,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis))

        if (k.memuat) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Eyebrow("Memuatkan enjin\u2026")
            }
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .border(1.dp, Warna.Garis, RectangleShape)
                        .background(Warna.Panel)
                ) {
                    Row(Modifier.height(IntrinsicSize.Min)) {
                        Box(
                            Modifier
                                .widthIn(min = 96.dp)
                                .fillMaxHeight()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                "${k.progres.sekarang}",
                                color = Warna.Oker,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 26.sp,
                            )
                        }
                        Box(Modifier.width(1.dp).fillMaxHeight().background(Warna.Garis))
                        Column(
                            Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Eyebrow("Sambung di sini")
                            Spacer(Modifier.height(3.dp))
                            Text(
                                k.bab.firstOrNull { k.progres.sekarang in it.dari..it.hingga }?.nama ?: "",
                                color = Warna.Dakwat,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis))
                    Column(Modifier.padding(13.dp)) {
                        Butang(
                            "Mula belajar",
                            Modifier.fillMaxWidth(),
                            utama = true,
                        ) { padaBuka(k.progres.sekarang) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            BasicTextField(
                                value = lompat,
                                onValueChange = { baharu -> lompat = baharu.filter { it.isDigit() }.take(5) },
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, Warna.Garis, RectangleShape)
                                    .background(Warna.Editor)
                                    .padding(11.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = LocalTextStyle.current.copy(
                                    color = Warna.Dakwat,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                ),
                                cursorBrush = SolidColor(Warna.Oker),
                                decorationBox = { medan ->
                                    if (lompat.isEmpty()) {
                                        Text(
                                            "Lompat ke level 1\u2013${k.jumlahLevel}",
                                            color = Warna.Senyap,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 14.sp,
                                        )
                                    }
                                    medan()
                                },
                            )
                            Butang("Pergi") {
                                val n = lompat.toIntOrNull() ?: 1
                                lompat = ""
                                padaBuka(n)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Eyebrow("${k.bab.size} bab \u00b7 ${k.jumlahLevel} level")
            }

            items(k.bab) { b ->
                BarisBab(b, k.progres.siapDalam(b)) { padaBuka(b.dari) }
            }

            item {
                Spacer(Modifier.height(10.dp))
                Nota(
                    "Kod kau dijalankan sungguh-sungguh terhadap kes ujian, termasuk kes sempadan " +
                        "dan input rosak. Tiada level lulus dengan jawapan yang hampir betul. " +
                        "Semua progres kekal pada peranti ini."
                )
            }
        }
    }
}

@Composable
private fun BarisBab(b: Bab, siap: Int, padaKlik: () -> Unit) {
    val peratus = if (b.bilanganLevel == 0) 0 else siap * 100 / b.bilanganLevel
    Row(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Warna.Garis, RectangleShape)
            .background(Warna.Panel)
            .clickable { padaKlik() }
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "B%02d".format(b.n),
            color = Warna.Senyap,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier.width(34.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(
                b.nama,
                color = Warna.Dakwat,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${b.dari}",
                    color = Warna.Senyap,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.5.sp,
                )
                Spacer(Modifier.width(7.dp))
                Box(
                    Modifier
                        .weight(1f)
                        .height(3.dp)
                        .background(Warna.Garis2)
                ) {
                    if (peratus > 0) {
                        Box(
                            Modifier
                                .fillMaxWidth(peratus / 100f)
                                .fillMaxHeight()
                                .background(Warna.Oker)
                        )
                    }
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    "${b.hingga}",
                    color = Warna.Senyap,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.5.sp,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "$peratus%",
                    color = if (peratus > 0) Warna.Oker else Warna.Senyap,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.5.sp,
                    modifier = Modifier.width(36.dp),
                )
            }
        }
    }
}
