export interface User {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  avatarUrl?: string;
  bio?: string;
  isAdmin: boolean;
  isOnline: boolean;
  totalPurchases: number;
  createdAt: number;
}
