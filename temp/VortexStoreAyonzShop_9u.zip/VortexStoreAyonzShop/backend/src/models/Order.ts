export type OrderStatus = "PENDING_PAYMENT" | "PAYMENT_REVIEW" | "PAID" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED";
export type PaymentMethod = "DANA" | "QRIS";

export interface OrderItem {
  productId: string;
  quantity: number;
  priceAtPurchase: number;
}

export interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  totalAmount: number;
  paymentMethod: PaymentMethod;
  status: OrderStatus;
  paymentProofUrl?: string;
  createdAt: number;
}
