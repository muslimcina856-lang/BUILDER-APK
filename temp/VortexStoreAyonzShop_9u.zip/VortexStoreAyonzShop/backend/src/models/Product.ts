export type ProductCategory =
  | "PANEL_BOT"
  | "APLIKASI_DIGITAL"
  | "JASA_WEBSITE"
  | "JASA_APLIKASI"
  | "JASA_CUSTOM_FEATURE"
  | "JASA_UIUX"
  | "MAINTENANCE"
  | "RESELLER"
  | "REKBER"
  | "PRODUK_LAIN";

export interface Product {
  id: string;
  name: string;
  description: string;
  category: ProductCategory;
  priceMin: number;
  priceMax?: number;
  imageUrl?: string;
  isAvailable: boolean;
  features: string[];
  rating: number;
  soldCount: number;
}
