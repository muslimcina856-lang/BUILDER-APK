export type ChatType = "GLOBAL" | "PRIVATE";

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatarUrl?: string;
  receiverId?: string;
  chatType: ChatType;
  content: string;
  timestamp: number;
  isSeen: boolean;
}
