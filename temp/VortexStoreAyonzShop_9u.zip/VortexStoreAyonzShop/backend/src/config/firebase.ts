import admin from "firebase-admin";
import { env } from "./env";

/**
 * Firebase Admin SDK initialization placeholder.
 * Create a real Firebase project, generate a service account key,
 * and populate FIREBASE_* env vars before enabling this in production.
 * Firestore is used here as the primary data store; swap for
 * PostgreSQL/MongoDB if you prefer a self-hosted database instead.
 */
let initialized = false;

export function initFirebase() {
  if (initialized || !env.firebase.projectId) return;
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: env.firebase.projectId,
      clientEmail: env.firebase.clientEmail,
      privateKey: env.firebase.privateKey
    })
  });
  initialized = true;
}

export function getFirestore() {
  if (!initialized) initFirebase();
  return admin.firestore();
}
