import { Request, Response, NextFunction } from "express";
import { logger } from "../utils/logger";

export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  logger.error("Unhandled error", { error: String(err), path: req.path });
  res.status(500).json({ message: "Terjadi kesalahan pada server" });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({ message: `Route ${req.path} tidak ditemukan` });
}
