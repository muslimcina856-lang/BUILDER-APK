import { Request, Response, NextFunction } from "express";
import { verifyAccessToken } from "../utils/jwt";

export interface AuthedRequest extends Request {
  userId?: string;
  isAdmin?: boolean;
}

export function authMiddleware(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Token tidak ditemukan" });
  }
  try {
    const payload = verifyAccessToken(header.replace("Bearer ", ""));
    req.userId = payload.userId;
    req.isAdmin = payload.isAdmin;
    next();
  } catch {
    return res.status(401).json({ message: "Token tidak valid atau kedaluwarsa" });
  }
}

export function adminOnly(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.isAdmin) return res.status(403).json({ message: "Akses ditolak — khusus admin" });
  next();
}
