import { Router } from "express";
import { register, login, refresh, me } from "../controllers/authController";
import { authMiddleware } from "../middleware/authMiddleware";
import { authRateLimiter } from "../middleware/rateLimiter";

const router = Router();
router.post("/register", authRateLimiter, register);
router.post("/login", authRateLimiter, login);
router.post("/refresh", refresh);
router.get("/me", authMiddleware, me);

export default router;
