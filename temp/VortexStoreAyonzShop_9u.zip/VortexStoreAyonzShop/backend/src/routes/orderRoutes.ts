import { Router } from "express";
import { createOrder, uploadPaymentProof, getMyOrders, getOrderDetail } from "../controllers/orderController";
import { authMiddleware } from "../middleware/authMiddleware";

const router = Router();
router.use(authMiddleware);
router.post("/", createOrder);
router.post("/upload-proof", uploadPaymentProof);
router.get("/", getMyOrders);
router.get("/:id", getOrderDetail);

export default router;
