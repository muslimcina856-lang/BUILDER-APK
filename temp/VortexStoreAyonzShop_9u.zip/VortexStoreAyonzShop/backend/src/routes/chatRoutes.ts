import { Router } from "express";
import { getGlobalChatHistory, getPrivateChatHistory } from "../controllers/chatController";
import { authMiddleware } from "../middleware/authMiddleware";

const router = Router();
router.use(authMiddleware);
router.get("/global", getGlobalChatHistory);
router.get("/private/:userId", getPrivateChatHistory);

export default router;
