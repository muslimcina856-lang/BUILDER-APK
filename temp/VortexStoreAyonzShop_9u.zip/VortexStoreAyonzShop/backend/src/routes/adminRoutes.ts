import { Router } from "express";
import { createProduct, updateProduct, deleteProduct } from "../controllers/productController";
import { verifyPayment } from "../controllers/orderController";
import { authMiddleware, adminOnly } from "../middleware/authMiddleware";

const router = Router();
router.use(authMiddleware, adminOnly);
router.post("/products", createProduct);
router.put("/products/:id", updateProduct);
router.delete("/products/:id", deleteProduct);
router.put("/orders/:id/verify", verifyPayment);

export default router;
