import { Response } from "express";
import { v4 as uuid } from "uuid";
import { db } from "../database/inMemoryStore";
import { Order, OrderItem } from "../models/Order";
import { AuthedRequest } from "../middleware/authMiddleware";

export function createOrder(req: AuthedRequest, res: Response) {
  const { items, paymentMethod } = req.body as { items: { productId: string; quantity: number }[]; paymentMethod: "DANA" | "QRIS" };
  if (!items?.length) return res.status(400).json({ message: "Keranjang kosong" });

  const orderItems: OrderItem[] = items.map((i) => {
    const product = db.products.get(i.productId);
    return { productId: i.productId, quantity: i.quantity, priceAtPurchase: product?.priceMin ?? 0 };
  });
  const totalAmount = orderItems.reduce((sum, i) => sum + i.priceAtPurchase * i.quantity, 0);

  const id = uuid();
  const order: Order = {
    id, userId: req.userId!, items: orderItems, totalAmount, paymentMethod,
    status: "PENDING_PAYMENT", createdAt: Date.now()
  };
  db.orders.set(id, order);
  res.status(201).json(order);
}

export function uploadPaymentProof(req: AuthedRequest, res: Response) {
  const { orderId, proofUrl } = req.body;
  const order = db.orders.get(orderId);
  if (!order) return res.status(404).json({ message: "Pesanan tidak ditemukan" });
  order.paymentProofUrl = proofUrl;
  order.status = "PAYMENT_REVIEW";
  res.json(order);
}

export function getMyOrders(req: AuthedRequest, res: Response) {
  const orders = [...db.orders.values()].filter((o) => o.userId === req.userId);
  res.json(orders);
}

export function getOrderDetail(req: AuthedRequest, res: Response) {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ message: "Pesanan tidak ditemukan" });
  res.json(order);
}

export function verifyPayment(req: AuthedRequest, res: Response) {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ message: "Pesanan tidak ditemukan" });
  order.status = "PAID";
  res.json(order);
}
