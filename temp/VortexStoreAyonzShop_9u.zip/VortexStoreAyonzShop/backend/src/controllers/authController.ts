import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { v4 as uuid } from "uuid";
import { db } from "../database/inMemoryStore";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../utils/jwt";
import { AuthedRequest } from "../middleware/authMiddleware";

function toPublicUser(user: ReturnType<typeof db.users.get>) {
  if (!user) return null;
  const { passwordHash, ...publicUser } = user;
  return publicUser;
}

export async function register(req: Request, res: Response) {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ message: "Username, email, dan password wajib diisi" });
  }
  const exists = [...db.users.values()].some((u) => u.email === email);
  if (exists) return res.status(409).json({ message: "Email sudah terdaftar" });

  const passwordHash = await bcrypt.hash(password, 10);
  const id = uuid();
  db.users.set(id, {
    id, username, email, passwordHash, isAdmin: false, isOnline: true,
    totalPurchases: 0, createdAt: Date.now()
  });

  const accessToken = signAccessToken({ userId: id, isAdmin: false });
  const refreshToken = signRefreshToken({ userId: id, isAdmin: false });
  res.status(201).json({ accessToken, refreshToken, user: toPublicUser(db.users.get(id)) });
}

export async function login(req: Request, res: Response) {
  const { email, password } = req.body;
  const user = [...db.users.values()].find((u) => u.email === email);
  if (!user) return res.status(401).json({ message: "Email atau password salah" });

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ message: "Email atau password salah" });

  const accessToken = signAccessToken({ userId: user.id, isAdmin: user.isAdmin });
  const refreshToken = signRefreshToken({ userId: user.id, isAdmin: user.isAdmin });
  res.json({ accessToken, refreshToken, user: toPublicUser(user) });
}

export async function refresh(req: Request, res: Response) {
  const { refreshToken } = req.body;
  try {
    const payload = verifyRefreshToken(refreshToken);
    const user = db.users.get(payload.userId);
    if (!user) return res.status(401).json({ message: "User tidak ditemukan" });
    const accessToken = signAccessToken({ userId: user.id, isAdmin: user.isAdmin });
    const newRefreshToken = signRefreshToken({ userId: user.id, isAdmin: user.isAdmin });
    res.json({ accessToken, refreshToken: newRefreshToken, user: toPublicUser(user) });
  } catch {
    res.status(401).json({ message: "Refresh token tidak valid" });
  }
}

export async function me(req: AuthedRequest, res: Response) {
  const user = db.users.get(req.userId!);
  if (!user) return res.status(404).json({ message: "User tidak ditemukan" });
  res.json(toPublicUser(user));
}
