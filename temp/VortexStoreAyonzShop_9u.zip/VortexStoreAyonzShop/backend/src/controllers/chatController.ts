import { Response } from "express";
import { db } from "../database/inMemoryStore";
import { AuthedRequest } from "../middleware/authMiddleware";

export function getGlobalChatHistory(req: AuthedRequest, res: Response) {
  const limit = parseInt((req.query.limit as string) || "50", 10);
  res.json(db.globalMessages.slice(-limit));
}

export function getPrivateChatHistory(req: AuthedRequest, res: Response) {
  const otherUserId = req.params.userId;
  const userId = req.userId!;
  const history = db.privateMessages.filter(
    (m) =>
      (m.senderId === userId && m.receiverId === otherUserId) ||
      (m.senderId === otherUserId && m.receiverId === userId)
  );
  res.json(history);
}
