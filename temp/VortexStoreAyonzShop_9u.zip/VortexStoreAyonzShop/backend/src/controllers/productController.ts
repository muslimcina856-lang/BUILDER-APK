import { Request, Response } from "express";
import { v4 as uuid } from "uuid";
import { db } from "../database/inMemoryStore";
import { Product, ProductCategory } from "../models/Product";

export function getProducts(req: Request, res: Response) {
  const category = req.query.category as ProductCategory | undefined;
  let products = [...db.products.values()];
  if (category) products = products.filter((p) => p.category === category);
  res.json(products);
}

export function getProductDetail(req: Request, res: Response) {
  const product = db.products.get(req.params.id);
  if (!product) return res.status(404).json({ message: "Produk tidak ditemukan" });
  res.json(product);
}

export function createProduct(req: Request, res: Response) {
  const body = req.body as Partial<Product>;
  if (!body.name || !body.category || body.priceMin === undefined) {
    return res.status(400).json({ message: "name, category, priceMin wajib diisi" });
  }
  const id = uuid();
  const product: Product = {
    id, name: body.name, description: body.description || "",
    category: body.category, priceMin: body.priceMin, priceMax: body.priceMax,
    imageUrl: body.imageUrl, isAvailable: body.isAvailable ?? true,
    features: body.features || [], rating: 0, soldCount: 0
  };
  db.products.set(id, product);
  res.status(201).json(product);
}

export function updateProduct(req: Request, res: Response) {
  const existing = db.products.get(req.params.id);
  if (!existing) return res.status(404).json({ message: "Produk tidak ditemukan" });
  const updated = { ...existing, ...req.body, id: existing.id };
  db.products.set(existing.id, updated);
  res.json(updated);
}

export function deleteProduct(req: Request, res: Response) {
  if (!db.products.delete(req.params.id)) {
    return res.status(404).json({ message: "Produk tidak ditemukan" });
  }
  res.status(204).send();
}
