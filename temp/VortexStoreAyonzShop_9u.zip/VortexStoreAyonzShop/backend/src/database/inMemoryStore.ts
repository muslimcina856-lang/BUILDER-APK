import { User } from "../models/User";
import { Product } from "../models/Product";
import { Order } from "../models/Order";
import { ChatMessage } from "../models/Message";

/**
 * Process-memory data store used so this starter backend runs
 * out-of-the-box without any external database configured.
 * Replace each Map with real Firestore/Postgres/Mongo calls once
 * a database is provisioned — the controllers are written so that
 * swapping the storage layer only touches this file.
 */
export const db = {
  users: new Map<string, User>(),
  products: new Map<string, Product>(),
  orders: new Map<string, Order>(),
  globalMessages: [] as ChatMessage[],
  privateMessages: [] as ChatMessage[]
};

export function seedSampleProducts() {
  if (db.products.size > 0) return;
  const samples: Product[] = [
    {
      id: "prod_panel_bot_1", name: "Panel Bot WhatsApp - Starter",
      description: "Hosting panel bot WhatsApp dengan uptime 24/7 dan auto-restart.",
      category: "PANEL_BOT", priceMin: 25000, priceMax: 75000,
      imageUrl: "", isAvailable: true, features: ["Uptime 24/7", "Auto restart", "Support 1x1"],
      rating: 4.8, soldCount: 120
    },
    {
      id: "prod_jasa_web_1", name: "Jasa Pembuatan Website Landing Page",
      description: "Website landing page profesional, responsive, siap pakai untuk bisnis.",
      category: "JASA_WEBSITE", priceMin: 150000, priceMax: 500000,
      imageUrl: "", isAvailable: true, features: ["Responsive", "SEO friendly", "Revisi 2x"],
      rating: 4.9, soldCount: 80
    },
    {
      id: "prod_rekber_1", name: "Jasa MC / Rekber Transaksi",
      description: "Pihak ketiga tepercaya untuk transaksi jual-beli aman antar pengguna.",
      category: "REKBER", priceMin: 5000, priceMax: 20000,
      imageUrl: "", isAvailable: true, features: ["Fee transparan", "Proses cepat"],
      rating: 5.0, soldCount: 230
    }
  ];
  samples.forEach((p) => db.products.set(p.id, p));
}
