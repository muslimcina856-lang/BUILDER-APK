import http from "http";
import { Server } from "socket.io";
import { createApp } from "./app";
import { env } from "./config/env";
import { registerSocketHandlers } from "./websocket/socketHandler";
import { logger } from "./utils/logger";

const app = createApp();
const httpServer = http.createServer(app);

const io = new Server(httpServer, {
  cors: { origin: env.corsOrigin }
});
registerSocketHandlers(io);

httpServer.listen(env.port, () => {
  logger.info(`Vortex Store backend running on port ${env.port}`);
});
