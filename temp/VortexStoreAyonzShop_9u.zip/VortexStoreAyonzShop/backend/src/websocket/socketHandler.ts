import { Server, Socket } from "socket.io";
import { v4 as uuid } from "uuid";
import { verifyAccessToken } from "../utils/jwt";
import { db } from "../database/inMemoryStore";
import { ChatMessage } from "../models/Message";
import { logger } from "../utils/logger";

interface AuthedSocket extends Socket {
  userId?: string;
}

const onlineUsers = new Map<string, string>(); // userId -> socketId

export function registerSocketHandlers(io: Server) {
  io.use((socket: AuthedSocket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(); // allow guests to connect read-only
    try {
      const payload = verifyAccessToken(token);
      socket.userId = payload.userId;
      next();
    } catch {
      next(); // invalid token -> still connect as anonymous/guest
    }
  });

  io.on("connection", (socket: AuthedSocket) => {
    if (socket.userId) {
      onlineUsers.set(socket.userId, socket.id);
      const user = db.users.get(socket.userId);
      if (user) user.isOnline = true;
    }
    logger.info("Socket connected", { socketId: socket.id, userId: socket.userId });

    socket.on("chat:global:send", (payload: { content: string }) => {
      if (!socket.userId || !payload?.content?.trim()) return;
      const user = db.users.get(socket.userId);
      const message: ChatMessage = {
        id: uuid(), senderId: socket.userId, senderName: user?.username ?? "User",
        chatType: "GLOBAL", content: payload.content.trim(), timestamp: Date.now(), isSeen: false
      };
      db.globalMessages.push(message);
      io.emit("chat:message", message);
    });

    socket.on("chat:private:send", (payload: { receiverId: string; content: string }) => {
      if (!socket.userId || !payload?.content?.trim() || !payload?.receiverId) return;
      const user = db.users.get(socket.userId);
      const message: ChatMessage = {
        id: uuid(), senderId: socket.userId, senderName: user?.username ?? "User",
        receiverId: payload.receiverId, chatType: "PRIVATE",
        content: payload.content.trim(), timestamp: Date.now(), isSeen: false
      };
      db.privateMessages.push(message);
      socket.emit("chat:message", message);
      const receiverSocketId = onlineUsers.get(payload.receiverId);
      if (receiverSocketId) io.to(receiverSocketId).emit("chat:message", message);
    });

    socket.on("chat:typing", (payload: { receiverId?: string }) => {
      if (!socket.userId) return;
      if (payload?.receiverId) {
        const receiverSocketId = onlineUsers.get(payload.receiverId);
        if (receiverSocketId) io.to(receiverSocketId).emit("chat:typing", { userId: socket.userId });
      } else {
        socket.broadcast.emit("chat:typing", { userId: socket.userId });
      }
    });

    socket.on("disconnect", () => {
      if (socket.userId) {
        onlineUsers.delete(socket.userId);
        const user = db.users.get(socket.userId);
        if (user) user.isOnline = false;
      }
      logger.info("Socket disconnected", { socketId: socket.id });
    });
  });
}
