package com.vortexstore.ayonzshop.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.models.ProductCategory
import com.vortexstore.ayonzshop.ui.components.BottomNavItem
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.components.VortexBottomNavBar
import com.vortexstore.ayonzshop.ui.theme.VortexAccent

@Composable
fun HomeScreen(
    onCategoryClick: (String) -> Unit,
    onProductClick: (String) -> Unit,
    onCartClick: () -> Unit,
    onChatClick: () -> Unit,
    onProfileClick: () -> Unit,
    onToolsClick: () -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            VortexBottomNavBar(
                items = listOf(
                    BottomNavItem("Home", Icons.Default.Home) {},
                    BottomNavItem("Tools", Icons.Default.Build, onToolsClick),
                    BottomNavItem("Keranjang", Icons.Default.ShoppingCart, onCartClick),
                    BottomNavItem("Chat", Icons.Default.Chat, onChatClick),
                    BottomNavItem("Profil", Icons.Default.Person, onProfileClick)
                ),
                selectedIndex = 0
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                HomeHeader()
            }
            items(ProductCategory.entries.toList()) { category ->
                CategoryTile(category = category, onClick = { onCategoryClick(category.name) })
            }
        }
    }
}

@Composable
private fun HomeHeader() {
    Column(Modifier.padding(bottom = 8.dp)) {
        Text("Vortex Store", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Ayonz Shop — marketplace digital masa depan",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        Text("Kategori", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CategoryTile(category: ProductCategory, onClick: () -> Unit) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Icon(categoryIcon(category), contentDescription = null, tint = VortexAccent)
            Spacer(Modifier.height(6.dp))
            Text(category.displayName, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
        }
    }
}

private fun categoryIcon(category: ProductCategory) = when (category) {
    ProductCategory.PANEL_BOT -> Icons.Default.Dns
    ProductCategory.APLIKASI_DIGITAL -> Icons.Default.Apps
    ProductCategory.JASA_WEBSITE -> Icons.Default.Language
    ProductCategory.JASA_APLIKASI -> Icons.Default.PhoneAndroid
    ProductCategory.JASA_CUSTOM_FEATURE -> Icons.Default.Extension
    ProductCategory.JASA_UIUX -> Icons.Default.Brush
    ProductCategory.MAINTENANCE -> Icons.Default.Build
    ProductCategory.RESELLER -> Icons.Default.Storefront
    ProductCategory.REKBER -> Icons.Default.Security
    ProductCategory.PRODUK_LAIN -> Icons.Default.Category
}
