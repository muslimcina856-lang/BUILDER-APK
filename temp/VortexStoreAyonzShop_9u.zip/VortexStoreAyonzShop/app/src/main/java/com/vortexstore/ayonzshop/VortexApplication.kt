package com.vortexstore.ayonzshop

import android.app.Application
import com.vortexstore.ayonzshop.data.datastore.PreferencesManager
import com.vortexstore.ayonzshop.database.AppDatabase
import com.vortexstore.ayonzshop.network.RetrofitClient
import com.vortexstore.ayonzshop.network.WebSocketManager

/**
 * Application-level singleton container.
 * Manual lightweight DI (no Hilt) to keep the starter project easy to read.
 * Swap this out for Hilt/Koin once the project grows.
 */
class VortexApplication : Application() {

    lateinit var preferencesManager: PreferencesManager
        private set

    lateinit var database: AppDatabase
        private set

    lateinit var webSocketManager: WebSocketManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        preferencesManager = PreferencesManager(this)
        database = AppDatabase.getInstance(this)
        RetrofitClient.init(preferencesManager)
        webSocketManager = WebSocketManager(preferencesManager)
    }

    companion object {
        lateinit var instance: VortexApplication
            private set
    }
}
