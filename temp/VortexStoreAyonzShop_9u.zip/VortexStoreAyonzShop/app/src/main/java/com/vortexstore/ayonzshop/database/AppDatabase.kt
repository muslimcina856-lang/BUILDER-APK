package com.vortexstore.ayonzshop.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.vortexstore.ayonzshop.database.dao.CartDao
import com.vortexstore.ayonzshop.database.dao.ChatDao
import com.vortexstore.ayonzshop.database.dao.ProductDao
import com.vortexstore.ayonzshop.database.entities.CartEntity
import com.vortexstore.ayonzshop.database.entities.ChatMessageEntity
import com.vortexstore.ayonzshop.database.entities.ProductEntity

@Database(
    entities = [ProductEntity::class, CartEntity::class, ChatMessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vortex_store.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
