package com.vortexstore.ayonzshop.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.models.CartItem
import com.vortexstore.ayonzshop.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CartViewModel : ViewModel() {

    private val repository = CartRepository(
        VortexApplication.instance.database.cartDao(),
        VortexApplication.instance.database.productDao()
    )

    val cartItems: StateFlow<List<CartItem>> = repository.observeCart()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAmount: StateFlow<Long> = kotlinx.coroutines.flow.MutableStateFlow(0L).also { state ->
        viewModelScope.launch {
            cartItems.collect { items -> state.value = items.sumOf { it.subtotal } }
        }
    }

    fun addToCart(productId: String, quantity: Int = 1) {
        viewModelScope.launch { repository.addToCart(productId, quantity) }
    }

    fun clearCart() {
        viewModelScope.launch { repository.clearCart() }
    }
}
