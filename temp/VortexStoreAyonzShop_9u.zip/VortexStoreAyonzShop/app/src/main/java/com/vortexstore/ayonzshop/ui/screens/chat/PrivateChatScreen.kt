package com.vortexstore.ayonzshop.ui.screens.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.ui.theme.VortexAccent
import com.vortexstore.ayonzshop.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateChatScreen(otherUserId: String, onBack: () -> Unit, viewModel: ChatViewModel = viewModel()) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val currentUserId by VortexApplication.instance.preferencesManager.userIdFlow.collectAsState(initial = null)
    val app = VortexApplication.instance
    val messages by app.database.chatDao()
        .observePrivateChat(currentUserId ?: "", otherUserId)
        .collectAsState(initial = emptyList())

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Chat dengan $otherUserId") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Tulis pesan...") },
                    modifier = Modifier.weight(1f), singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = { viewModel.sendPrivateMessage(otherUserId, input); input = "" },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = VortexAccent)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Kirim", tint = MaterialTheme.colorScheme.background)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { entity ->
                ChatBubble(
                    message = com.vortexstore.ayonzshop.models.ChatMessage(
                        id = entity.id, senderId = entity.senderId, senderName = entity.senderName,
                        receiverId = entity.receiverId, chatType = com.vortexstore.ayonzshop.models.ChatType.PRIVATE,
                        content = entity.content, timestamp = entity.timestamp
                    ),
                    isMine = entity.senderId == currentUserId
                )
            }
        }
    }
}
