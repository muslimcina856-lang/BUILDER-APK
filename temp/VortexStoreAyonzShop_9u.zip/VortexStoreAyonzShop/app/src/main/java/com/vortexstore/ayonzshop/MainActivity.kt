package com.vortexstore.ayonzshop

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import com.vortexstore.ayonzshop.ui.navigation.VortexNavGraph
import com.vortexstore.ayonzshop.ui.theme.VortexStoreTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VortexStoreTheme(darkTheme = true) {
                VortexNavGraph()
            }
        }
    }
}
