package com.vortexstore.ayonzshop.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.theme.VortexAccent
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(onBack: () -> Unit, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    val userId by VortexApplication.instance.preferencesManager.userIdFlow.collectAsState(initial = null)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Profil") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AsyncImage(
                model = null,
                contentDescription = "Foto profil",
                modifier = Modifier.size(96.dp).clip(CircleShape)
            )
            Spacer(Modifier.height(12.dp))
            Text(userId ?: "Guest", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Status: Online", color = VortexAccent, style = MaterialTheme.typography.labelSmall)

            Spacer(Modifier.height(24.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    ProfileRow("Riwayat Pembelian", "Lihat semua transaksi")
                    Spacer(Modifier.height(10.dp))
                    ProfileRow("Statistik Akun", "Total pembelian, poin, level")
                }
            }

            Spacer(Modifier.height(20.dp))
            OutlinedButton(
                onClick = {
                    scope.launch {
                        VortexApplication.instance.preferencesManager.clearSession()
                        onLogout()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Keluar")
            }
        }
    }
}

@Composable
private fun ProfileRow(title: String, subtitle: String) {
    Column {
        Text(title, fontWeight = FontWeight.Medium)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
