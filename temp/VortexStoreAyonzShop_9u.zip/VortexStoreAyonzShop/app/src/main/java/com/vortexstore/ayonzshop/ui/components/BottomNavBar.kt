package com.vortexstore.ayonzshop.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.ui.theme.VortexAccent

data class BottomNavItem(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val onClick: () -> Unit)

@Composable
fun VortexBottomNavBar(items: List<BottomNavItem>, selectedIndex: Int) {
    GlassCard(modifier = Modifier.fillMaxWidth().padding(12.dp), cornerRadius = 24) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEachIndexed { index, item ->
                val selected = index == selectedIndex
                val interactionSource = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = item.onClick
                    )
                ) {
                    Icon(
                        item.icon,
                        contentDescription = item.label,
                        tint = if (selected) VortexAccent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(item.label, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
