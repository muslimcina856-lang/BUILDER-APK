package com.vortexstore.ayonzshop.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartEntity(
    @PrimaryKey(autoGenerate = true) val cartId: Long = 0,
    val productId: String,
    val quantity: Int,
    val notes: String? = null
)
