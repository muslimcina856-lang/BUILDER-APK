package com.vortexstore.ayonzshop.service

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Handles incoming push notifications (order status updates, new chat
 * messages, admin verification results). Wire up a NotificationCompat
 * builder here once a notification channel strategy is decided.
 */
class VortexFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // TODO: send token to backend via POST /api/auth/fcm-token
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: "Vortex Store"
        val body = message.notification?.body ?: ""
        // TODO: build and show a NotificationCompat notification with title/body
    }
}
