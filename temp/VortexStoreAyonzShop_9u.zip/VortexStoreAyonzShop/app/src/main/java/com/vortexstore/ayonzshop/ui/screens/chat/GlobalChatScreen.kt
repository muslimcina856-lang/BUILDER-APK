package com.vortexstore.ayonzshop.ui.screens.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.models.ChatMessage
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.theme.VortexAccent
import com.vortexstore.ayonzshop.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalChatScreen(
    onBack: () -> Unit,
    onOpenPrivateChat: (String) -> Unit,
    viewModel: ChatViewModel = viewModel()
) {
    val messages by viewModel.globalMessages.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val currentUserId by VortexApplication.instance.preferencesManager.userIdFlow.collectAsState(initial = null)

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Chat Global") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Tulis pesan...") },
                    modifier = Modifier.weight(1f), singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        viewModel.sendGlobalMessage(input)
                        input = ""
                    },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = VortexAccent)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Kirim", tint = MaterialTheme.colorScheme.background)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { message ->
                ChatBubble(
                    message = message,
                    isMine = message.senderId == currentUserId,
                    onAvatarClick = { onOpenPrivateChat(message.senderId) }
                )
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, isMine: Boolean, onAvatarClick: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        GlassCard(modifier = Modifier.widthIn(max = 260.dp)) {
            Column(Modifier.padding(10.dp)) {
                if (!isMine) {
                    Text(
                        message.senderName,
                        style = MaterialTheme.typography.labelSmall,
                        color = VortexAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(message.content, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
