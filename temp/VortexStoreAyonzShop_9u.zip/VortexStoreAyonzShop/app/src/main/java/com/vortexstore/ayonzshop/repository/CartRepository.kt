package com.vortexstore.ayonzshop.repository

import com.vortexstore.ayonzshop.database.dao.CartDao
import com.vortexstore.ayonzshop.database.dao.ProductDao
import com.vortexstore.ayonzshop.database.entities.CartEntity
import com.vortexstore.ayonzshop.models.CartItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class CartRepository(
    private val cartDao: CartDao,
    private val productDao: ProductDao
) {
    fun observeCart(): Flow<List<CartItem>> {
        return cartDao.observeCart().combine(productDao.observeAll()) { cartEntities, products ->
            val productMap = products.associateBy { it.id }
            cartEntities.mapNotNull { entity ->
                val product = productMap[entity.productId] ?: return@mapNotNull null
                CartItem(
                    product = com.vortexstore.ayonzshop.models.Product(
                        id = product.id, name = product.name, description = product.description,
                        category = runCatching { com.vortexstore.ayonzshop.models.ProductCategory.valueOf(product.category) }
                            .getOrDefault(com.vortexstore.ayonzshop.models.ProductCategory.PRODUK_LAIN),
                        priceMin = product.priceMin, priceMax = product.priceMax, imageUrl = product.imageUrl
                    ),
                    quantity = entity.quantity,
                    notes = entity.notes
                )
            }
        }
    }

    suspend fun addToCart(productId: String, quantity: Int = 1, notes: String? = null) {
        cartDao.addItem(CartEntity(productId = productId, quantity = quantity, notes = notes))
    }

    suspend fun clearCart() = cartDao.clearCart()
}
