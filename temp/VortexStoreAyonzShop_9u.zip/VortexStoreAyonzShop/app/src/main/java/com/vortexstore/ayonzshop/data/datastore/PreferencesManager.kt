package com.vortexstore.ayonzshop.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.dataStore by preferencesDataStore(name = "vortex_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val ACCESS_TOKEN = stringPreferencesKey("access_token")
        val REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        val USER_ID = stringPreferencesKey("user_id")
        val IS_GUEST = booleanPreferencesKey("is_guest")
    }

    val accessTokenFlow: Flow<String?> = context.dataStore.data.map { it[Keys.ACCESS_TOKEN] }
    val userIdFlow: Flow<String?> = context.dataStore.data.map { it[Keys.USER_ID] }
    val isGuestFlow: Flow<Boolean> = context.dataStore.data.map { it[Keys.IS_GUEST] ?: false }

    // Synchronous helper for the Retrofit auth interceptor
    fun getAccessTokenBlocking(): String? = runBlocking { accessTokenFlow.first() }

    suspend fun saveSession(accessToken: String, refreshToken: String, userId: String, isGuest: Boolean = false) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACCESS_TOKEN] = accessToken
            prefs[Keys.REFRESH_TOKEN] = refreshToken
            prefs[Keys.USER_ID] = userId
            prefs[Keys.IS_GUEST] = isGuest
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { it.clear() }
    }
}
