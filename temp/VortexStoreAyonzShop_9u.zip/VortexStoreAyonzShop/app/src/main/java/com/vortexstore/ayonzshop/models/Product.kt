package com.vortexstore.ayonzshop.models

enum class ProductCategory(val displayName: String) {
    PANEL_BOT("Panel Bot Hosting"),
    APLIKASI_DIGITAL("Aplikasi Digital"),
    JASA_WEBSITE("Jasa Pembuatan Website"),
    JASA_APLIKASI("Jasa Pembuatan Aplikasi"),
    JASA_CUSTOM_FEATURE("Jasa Custom Feature"),
    JASA_UIUX("Jasa Desain UI/UX"),
    MAINTENANCE("Maintenance System"),
    RESELLER("Reseller / Partner"),
    REKBER("Jasa MC / Rekber"),
    PRODUK_LAIN("Produk Online Lainnya")
}

data class Product(
    val id: String,
    val name: String,
    val description: String,
    val category: ProductCategory,
    val priceMin: Long,
    val priceMax: Long? = null,
    val imageUrl: String? = null,
    val isAvailable: Boolean = true,
    val features: List<String> = emptyList(),
    val rating: Float = 0f,
    val soldCount: Int = 0
)
