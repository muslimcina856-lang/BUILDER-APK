package com.vortexstore.ayonzshop.network

import com.vortexstore.ayonzshop.BuildConfig
import com.vortexstore.ayonzshop.data.datastore.PreferencesManager
import com.vortexstore.ayonzshop.models.ChatMessage
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import org.json.JSONObject

/**
 * Wraps a Socket.IO client connection to the Express/Socket.IO backend
 * for real-time global chat, private chat, typing indicators and
 * online-status events.
 */
class WebSocketManager(private val preferencesManager: PreferencesManager) {

    private var socket: Socket? = null

    fun connect() {
        val token = preferencesManager.getAccessTokenBlocking()
        val options = IO.Options().apply {
            auth = mapOf("token" to (token ?: ""))
            reconnection = true
            reconnectionAttempts = Int.MAX_VALUE
        }
        socket = IO.socket(BuildConfig.SOCKET_URL, options)
        socket?.connect()
    }

    fun disconnect() {
        socket?.disconnect()
        socket?.off()
    }

    fun sendGlobalMessage(content: String) {
        val payload = JSONObject().put("content", content)
        socket?.emit("chat:global:send", payload)
    }

    fun sendPrivateMessage(receiverId: String, content: String) {
        val payload = JSONObject().put("receiverId", receiverId).put("content", content)
        socket?.emit("chat:private:send", payload)
    }

    fun sendTyping(receiverId: String?) {
        val payload = JSONObject().apply { receiverId?.let { put("receiverId", it) } }
        socket?.emit("chat:typing", payload)
    }

    /** Cold flow of incoming chat messages (both global and private). */
    fun observeIncomingMessages(): Flow<ChatMessage> = callbackFlow {
        val listener = io.socket.emitter.Emitter.Listener { args ->
            val json = args.getOrNull(0) as? JSONObject ?: return@Listener
            trySend(json.toChatMessage())
        }
        socket?.on("chat:message", listener)
        awaitClose { socket?.off("chat:message", listener) }
    }

    private fun JSONObject.toChatMessage(): ChatMessage {
        return ChatMessage(
            id = optString("id"),
            senderId = optString("senderId"),
            senderName = optString("senderName"),
            senderAvatarUrl = optString("senderAvatarUrl", null),
            receiverId = if (has("receiverId")) optString("receiverId") else null,
            chatType = if (has("receiverId")) com.vortexstore.ayonzshop.models.ChatType.PRIVATE else com.vortexstore.ayonzshop.models.ChatType.GLOBAL,
            content = optString("content"),
            timestamp = optLong("timestamp", System.currentTimeMillis())
        )
    }
}
