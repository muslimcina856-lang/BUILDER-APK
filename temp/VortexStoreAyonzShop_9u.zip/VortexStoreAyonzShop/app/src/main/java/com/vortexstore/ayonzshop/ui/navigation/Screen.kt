package com.vortexstore.ayonzshop.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object ProductList : Screen("products/{category}") {
        fun createRoute(category: String) = "products/$category"
    }
    object ProductDetail : Screen("product/{productId}") {
        fun createRoute(productId: String) = "product/$productId"
    }
    object Cart : Screen("cart")
    object Checkout : Screen("checkout")
    object Profile : Screen("profile")
    object GlobalChat : Screen("chat/global")
    object PrivateChat : Screen("chat/private/{userId}") {
        fun createRoute(userId: String) = "chat/private/$userId"
    }
    object Tools : Screen("tools")
    object AdminDashboard : Screen("admin")
}
