package com.vortexstore.ayonzshop.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.models.User
import com.vortexstore.ayonzshop.network.RetrofitClient
import com.vortexstore.ayonzshop.repository.AuthRepository
import com.vortexstore.ayonzshop.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class Success(val user: User) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel : ViewModel() {

    private val repository = AuthRepository(
        RetrofitClient.apiService,
        VortexApplication.instance.preferencesManager
    )

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState

    fun login(email: String, password: String) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            when (val result = repository.login(email, password)) {
                is AuthResult.Success -> _uiState.value = AuthUiState.Success(result.user)
                is AuthResult.Error -> _uiState.value = AuthUiState.Error(result.message)
            }
        }
    }

    fun register(username: String, email: String, password: String) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            when (val result = repository.register(username, email, password)) {
                is AuthResult.Success -> _uiState.value = AuthUiState.Success(result.user)
                is AuthResult.Error -> _uiState.value = AuthUiState.Error(result.message)
            }
        }
    }

    fun continueAsGuest() {
        viewModelScope.launch {
            repository.continueAsGuest()
            _uiState.value = AuthUiState.Success(
                User(id = "guest", username = "Guest", email = "")
            )
        }
    }
}
