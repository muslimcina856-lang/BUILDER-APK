package com.vortexstore.ayonzshop.utils

import java.text.NumberFormat
import java.util.Locale

object CurrencyFormatter {
    private val idFormat = NumberFormat.getNumberInstance(Locale("in", "ID"))

    fun format(amount: Long): String = "Rp${idFormat.format(amount)}"

    fun formatRange(min: Long, max: Long?): String {
        return if (max != null && max > min) "${format(min)} - ${format(max)}" else format(min)
    }
}
