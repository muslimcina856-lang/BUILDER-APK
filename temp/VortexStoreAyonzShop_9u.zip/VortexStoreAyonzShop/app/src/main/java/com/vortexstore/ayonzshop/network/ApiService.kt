package com.vortexstore.ayonzshop.network

import com.vortexstore.ayonzshop.models.*
import retrofit2.Response
import retrofit2.http.*

data class AuthRequest(val email: String, val password: String, val username: String? = null)
data class AuthResponse(val accessToken: String, val refreshToken: String, val user: User)
data class RefreshRequest(val refreshToken: String)
data class CreateOrderRequest(val items: List<CartItem>, val paymentMethod: String)
data class UploadProofRequest(val orderId: String, val proofUrl: String)

interface ApiService {

    // --- Auth ---
    @POST("api/auth/register")
    suspend fun register(@Body request: AuthRequest): Response<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: AuthRequest): Response<AuthResponse>

    @POST("api/auth/google")
    suspend fun loginWithGoogle(@Body idToken: Map<String, String>): Response<AuthResponse>

    @POST("api/auth/refresh")
    suspend fun refreshToken(@Body request: RefreshRequest): Response<AuthResponse>

    @GET("api/auth/me")
    suspend fun getProfile(): Response<User>

    // --- Products ---
    @GET("api/products")
    suspend fun getProducts(@Query("category") category: String? = null): Response<List<Product>>

    @GET("api/products/{id}")
    suspend fun getProductDetail(@Path("id") id: String): Response<Product>

    // --- Orders ---
    @POST("api/orders")
    suspend fun createOrder(@Body request: CreateOrderRequest): Response<Order>

    @POST("api/orders/upload-proof")
    suspend fun uploadPaymentProof(@Body request: UploadProofRequest): Response<Order>

    @GET("api/orders")
    suspend fun getMyOrders(): Response<List<Order>>

    @GET("api/orders/{id}")
    suspend fun getOrderDetail(@Path("id") id: String): Response<Order>

    // --- Chat history (live messages come over WebSocket) ---
    @GET("api/chat/global")
    suspend fun getGlobalChatHistory(@Query("limit") limit: Int = 50): Response<List<ChatMessage>>

    @GET("api/chat/private/{userId}")
    suspend fun getPrivateChatHistory(@Path("userId") userId: String): Response<List<ChatMessage>>

    // --- Admin ---
    @POST("api/admin/products")
    suspend fun createProduct(@Body product: Product): Response<Product>

    @PUT("api/admin/products/{id}")
    suspend fun updateProduct(@Path("id") id: String, @Body product: Product): Response<Product>

    @DELETE("api/admin/products/{id}")
    suspend fun deleteProduct(@Path("id") id: String): Response<Unit>

    @PUT("api/admin/orders/{id}/verify")
    suspend fun verifyPayment(@Path("id") id: String): Response<Order>
}
