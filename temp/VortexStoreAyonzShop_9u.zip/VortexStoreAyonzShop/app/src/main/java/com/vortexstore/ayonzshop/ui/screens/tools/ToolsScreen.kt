package com.vortexstore.ayonzshop.ui.screens.tools

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.theme.VortexAccent

private data class ToolEntry(val title: String, val description: String, val icon: ImageVector)

private val tools = listOf(
    ToolEntry("Panel Bot Hosting", "Kelola hosting bot WhatsApp & Telegram", Icons.Default.Dns),
    ToolEntry("Jasa Pembuatan Website", "Pesan website custom sesuai kebutuhan", Icons.Default.Language),
    ToolEntry("Jasa Pembuatan Aplikasi", "Pesan aplikasi Android/iOS custom", Icons.Default.PhoneAndroid),
    ToolEntry("Custom Feature", "Tambah fitur khusus ke produk yang sudah ada", Icons.Default.Extension),
    ToolEntry("Jasa UI/UX", "Desain antarmuka profesional", Icons.Default.Brush),
    ToolEntry("Maintenance", "Paket perawatan sistem berkala", Icons.Default.Build),
    ToolEntry("Reseller / Partner", "Gabung program reseller Ayonz", Icons.Default.Storefront),
    ToolEntry("MC / Rekber", "Jasa pihak ketiga transaksi aman", Icons.Default.Security)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(onBack: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Tools & Layanan") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tools) { tool ->
                val interactionSource = remember { MutableInteractionSource() }
                GlassCard(
                    modifier = Modifier.fillMaxWidth().clickable(
                        interactionSource = interactionSource, indication = null, onClick = {}
                    )
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(tool.icon, contentDescription = null, tint = VortexAccent, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(tool.title, fontWeight = FontWeight.SemiBold)
                            Text(tool.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
