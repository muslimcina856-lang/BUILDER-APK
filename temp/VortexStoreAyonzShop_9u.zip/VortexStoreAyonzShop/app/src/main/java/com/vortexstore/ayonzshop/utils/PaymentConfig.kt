package com.vortexstore.ayonzshop.utils

/**
 * Static payment destination info for Vortex Store / Ayonz Shop.
 * The actual QRIS code is bundled as R.drawable.qris_payment.
 * Replace with a real payment-gateway integration (Midtrans/Xendit)
 * before shipping to production — manual proof upload is a stop-gap.
 */
object PaymentConfig {
    const val DANA_NUMBER = "0821-81129767"
    const val MERCHANT_NAME = "Yonz Market"
    const val QRIS_NMID = "ID1026470184932"
}
