package com.vortexstore.ayonzshop.models

data class User(
    val id: String,
    val username: String,
    val email: String,
    val avatarUrl: String? = null,
    val bio: String? = null,
    val isOnline: Boolean = false,
    val isAdmin: Boolean = false,
    val totalPurchases: Int = 0,
    val joinedAt: Long = System.currentTimeMillis()
)
