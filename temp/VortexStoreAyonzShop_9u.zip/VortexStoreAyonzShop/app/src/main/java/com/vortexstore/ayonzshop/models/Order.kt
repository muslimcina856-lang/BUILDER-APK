package com.vortexstore.ayonzshop.models

enum class OrderStatus {
    PENDING_PAYMENT,
    PAYMENT_REVIEW,
    PAID,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

enum class PaymentMethod {
    DANA,
    QRIS
}

data class Order(
    val id: String,
    val userId: String,
    val items: List<CartItem>,
    val totalAmount: Long,
    val paymentMethod: PaymentMethod,
    val status: OrderStatus = OrderStatus.PENDING_PAYMENT,
    val paymentProofUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
