package com.vortexstore.ayonzshop.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.vortexstore.ayonzshop.ui.screens.admin.AdminDashboardScreen
import com.vortexstore.ayonzshop.ui.screens.auth.LoginScreen
import com.vortexstore.ayonzshop.ui.screens.auth.RegisterScreen
import com.vortexstore.ayonzshop.ui.screens.cart.CartScreen
import com.vortexstore.ayonzshop.ui.screens.checkout.CheckoutScreen
import com.vortexstore.ayonzshop.ui.screens.chat.GlobalChatScreen
import com.vortexstore.ayonzshop.ui.screens.chat.PrivateChatScreen
import com.vortexstore.ayonzshop.ui.screens.home.HomeScreen
import com.vortexstore.ayonzshop.ui.screens.marketplace.ProductDetailScreen
import com.vortexstore.ayonzshop.ui.screens.marketplace.ProductListScreen
import com.vortexstore.ayonzshop.ui.screens.profile.ProfileScreen
import com.vortexstore.ayonzshop.ui.screens.splash.SplashScreen
import com.vortexstore.ayonzshop.ui.screens.tools.ToolsScreen

@Composable
fun VortexNavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {

        composable(Screen.Splash.route) {
            SplashScreen(onFinished = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Splash.route) { inclusive = true }
                }
            })
        }

        composable(Screen.Login.route) {
            LoginScreen(
                onLoginSuccess = { navController.navigate(Screen.Home.route) { popUpTo(0) } },
                onNavigateRegister = { navController.navigate(Screen.Register.route) },
                onGuestContinue = { navController.navigate(Screen.Home.route) { popUpTo(0) } }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                onRegisterSuccess = { navController.navigate(Screen.Home.route) { popUpTo(0) } },
                onNavigateLogin = { navController.popBackStack() }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onCategoryClick = { category -> navController.navigate(Screen.ProductList.createRoute(category)) },
                onProductClick = { id -> navController.navigate(Screen.ProductDetail.createRoute(id)) },
                onCartClick = { navController.navigate(Screen.Cart.route) },
                onChatClick = { navController.navigate(Screen.GlobalChat.route) },
                onProfileClick = { navController.navigate(Screen.Profile.route) },
                onToolsClick = { navController.navigate(Screen.Tools.route) }
            )
        }

        composable(
            Screen.ProductList.route,
            arguments = listOf(navArgument("category") { type = NavType.StringType })
        ) { backStackEntry ->
            val category = backStackEntry.arguments?.getString("category").orEmpty()
            ProductListScreen(
                categoryName = category,
                onProductClick = { id -> navController.navigate(Screen.ProductDetail.createRoute(id)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            Screen.ProductDetail.route,
            arguments = listOf(navArgument("productId") { type = NavType.StringType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getString("productId").orEmpty()
            ProductDetailScreen(
                productId = productId,
                onBack = { navController.popBackStack() },
                onAddedToCart = { navController.navigate(Screen.Cart.route) }
            )
        }

        composable(Screen.Cart.route) {
            CartScreen(
                onBack = { navController.popBackStack() },
                onCheckout = { navController.navigate(Screen.Checkout.route) }
            )
        }

        composable(Screen.Checkout.route) {
            CheckoutScreen(onBack = { navController.popBackStack() }, onOrderPlaced = {
                navController.navigate(Screen.Home.route) { popUpTo(Screen.Home.route) { inclusive = true } }
            })
        }

        composable(Screen.Profile.route) {
            ProfileScreen(onBack = { navController.popBackStack() }, onLogout = {
                navController.navigate(Screen.Login.route) { popUpTo(0) }
            })
        }

        composable(Screen.GlobalChat.route) {
            GlobalChatScreen(
                onBack = { navController.popBackStack() },
                onOpenPrivateChat = { userId -> navController.navigate(Screen.PrivateChat.createRoute(userId)) }
            )
        }

        composable(
            Screen.PrivateChat.route,
            arguments = listOf(navArgument("userId") { type = NavType.StringType })
        ) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId").orEmpty()
            PrivateChatScreen(otherUserId = userId, onBack = { navController.popBackStack() })
        }

        composable(Screen.Tools.route) {
            ToolsScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.AdminDashboard.route) {
            AdminDashboardScreen(onBack = { navController.popBackStack() })
        }
    }
}
