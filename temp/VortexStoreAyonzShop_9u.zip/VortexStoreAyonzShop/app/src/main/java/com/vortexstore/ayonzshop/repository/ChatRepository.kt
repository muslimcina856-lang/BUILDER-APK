package com.vortexstore.ayonzshop.repository

import com.vortexstore.ayonzshop.database.dao.ChatDao
import com.vortexstore.ayonzshop.database.entities.ChatMessageEntity
import com.vortexstore.ayonzshop.models.ChatMessage
import com.vortexstore.ayonzshop.models.ChatType
import com.vortexstore.ayonzshop.network.WebSocketManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChatRepository(
    private val chatDao: ChatDao,
    private val webSocketManager: WebSocketManager
) {
    fun observeGlobalChat(): Flow<List<ChatMessage>> =
        chatDao.observeGlobalChat().map { list -> list.map { it.toDomain() } }

    fun observePrivateChat(userId: String, otherUserId: String): Flow<List<ChatMessage>> =
        chatDao.observePrivateChat(userId, otherUserId).map { list -> list.map { it.toDomain() } }

    fun observeIncoming(): Flow<ChatMessage> = webSocketManager.observeIncomingMessages()

    suspend fun cacheIncoming(message: ChatMessage) = chatDao.insertMessage(message.toEntity())

    fun sendGlobal(content: String) = webSocketManager.sendGlobalMessage(content)
    fun sendPrivate(receiverId: String, content: String) = webSocketManager.sendPrivateMessage(receiverId, content)
}

private fun ChatMessageEntity.toDomain() = ChatMessage(
    id = id, senderId = senderId, senderName = senderName, receiverId = receiverId,
    chatType = if (chatType == "GLOBAL") ChatType.GLOBAL else ChatType.PRIVATE,
    content = content, timestamp = timestamp, isSeen = isSeen
)

private fun ChatMessage.toEntity() = ChatMessageEntity(
    id = id, senderId = senderId, senderName = senderName, receiverId = receiverId,
    chatType = chatType.name, contentType = contentType.name, content = content,
    timestamp = timestamp, isSeen = isSeen
)
