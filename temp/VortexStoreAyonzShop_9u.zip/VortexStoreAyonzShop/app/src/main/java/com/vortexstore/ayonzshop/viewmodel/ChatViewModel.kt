package com.vortexstore.ayonzshop.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.models.ChatMessage
import com.vortexstore.ayonzshop.repository.ChatRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {

    private val app = VortexApplication.instance
    private val repository = ChatRepository(app.database.chatDao(), app.webSocketManager)

    val globalMessages: StateFlow<List<ChatMessage>> = repository.observeGlobalChat()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        app.webSocketManager.connect()
        viewModelScope.launch {
            repository.observeIncoming().collect { message -> repository.cacheIncoming(message) }
        }
    }

    fun sendGlobalMessage(content: String) {
        if (content.isBlank()) return
        repository.sendGlobal(content)
    }

    fun sendPrivateMessage(receiverId: String, content: String) {
        if (content.isBlank()) return
        repository.sendPrivate(receiverId, content)
    }

    override fun onCleared() {
        super.onCleared()
        app.webSocketManager.disconnect()
    }
}
