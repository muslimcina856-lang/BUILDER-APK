package com.vortexstore.ayonzshop.database.dao

import androidx.room.*
import com.vortexstore.ayonzshop.database.entities.CartEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun observeCart(): Flow<List<CartEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addItem(item: CartEntity)

    @Update
    suspend fun updateItem(item: CartEntity)

    @Delete
    suspend fun removeItem(item: CartEntity)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}
