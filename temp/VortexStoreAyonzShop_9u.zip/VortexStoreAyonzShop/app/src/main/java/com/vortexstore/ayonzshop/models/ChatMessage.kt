package com.vortexstore.ayonzshop.models

enum class ChatType { GLOBAL, PRIVATE }
enum class MessageContentType { TEXT, IMAGE, VIDEO, FILE, VOICE, STICKER }

data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarUrl: String? = null,
    val receiverId: String? = null, // null for global chat
    val chatType: ChatType,
    val contentType: MessageContentType = MessageContentType.TEXT,
    val content: String,
    val replyToId: String? = null,
    val reactions: Map<String, String> = emptyMap(), // userId -> emoji
    val isSeen: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
