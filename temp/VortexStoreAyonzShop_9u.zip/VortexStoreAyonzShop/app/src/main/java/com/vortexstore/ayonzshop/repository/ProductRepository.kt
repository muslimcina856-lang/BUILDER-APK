package com.vortexstore.ayonzshop.repository

import com.vortexstore.ayonzshop.database.dao.ProductDao
import com.vortexstore.ayonzshop.database.entities.ProductEntity
import com.vortexstore.ayonzshop.models.Product
import com.vortexstore.ayonzshop.models.ProductCategory
import com.vortexstore.ayonzshop.network.ApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Single source of truth pattern: network refresh writes into Room,
 * UI always observes Room via Flow so the catalog also works offline.
 */
class ProductRepository(
    private val api: ApiService,
    private val productDao: ProductDao
) {
    fun observeProducts(category: ProductCategory? = null): Flow<List<Product>> {
        val flow = if (category != null) productDao.observeByCategory(category.name) else productDao.observeAll()
        return flow.map { list -> list.map { it.toDomain() } }
    }

    suspend fun refreshProducts(category: ProductCategory? = null) {
        val response = api.getProducts(category?.name)
        if (response.isSuccessful) {
            val products = response.body().orEmpty()
            productDao.upsertAll(products.map { it.toEntity() })
        }
    }

    suspend fun getProductDetail(id: String): Product? {
        val response = api.getProductDetail(id)
        return if (response.isSuccessful) response.body() else productDao.getById(id)?.toDomain()
    }
}

private fun ProductEntity.toDomain() = Product(
    id = id,
    name = name,
    description = description,
    category = runCatching { ProductCategory.valueOf(category) }.getOrDefault(ProductCategory.PRODUK_LAIN),
    priceMin = priceMin,
    priceMax = priceMax,
    imageUrl = imageUrl,
    isAvailable = isAvailable,
    rating = rating,
    soldCount = soldCount
)

private fun Product.toEntity() = ProductEntity(
    id = id,
    name = name,
    description = description,
    category = category.name,
    priceMin = priceMin,
    priceMax = priceMax,
    imageUrl = imageUrl,
    isAvailable = isAvailable,
    rating = rating,
    soldCount = soldCount
)
