package com.vortexstore.ayonzshop.repository

import com.vortexstore.ayonzshop.data.datastore.PreferencesManager
import com.vortexstore.ayonzshop.models.User
import com.vortexstore.ayonzshop.network.ApiService
import com.vortexstore.ayonzshop.network.AuthRequest

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(
    private val api: ApiService,
    private val preferencesManager: PreferencesManager
) {
    suspend fun register(username: String, email: String, password: String): AuthResult {
        return try {
            val response = api.register(AuthRequest(email, password, username))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                preferencesManager.saveSession(body.accessToken, body.refreshToken, body.user.id)
                AuthResult.Success(body.user)
            } else {
                AuthResult.Error(response.errorBody()?.string() ?: "Registrasi gagal")
            }
        } catch (e: Exception) {
            AuthResult.Error(e.message ?: "Terjadi kesalahan jaringan")
        }
    }

    suspend fun login(email: String, password: String): AuthResult {
        return try {
            val response = api.login(AuthRequest(email, password))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                preferencesManager.saveSession(body.accessToken, body.refreshToken, body.user.id)
                AuthResult.Success(body.user)
            } else {
                AuthResult.Error(response.errorBody()?.string() ?: "Login gagal")
            }
        } catch (e: Exception) {
            AuthResult.Error(e.message ?: "Terjadi kesalahan jaringan")
        }
    }

    suspend fun continueAsGuest() {
        preferencesManager.saveSession(accessToken = "", refreshToken = "", userId = "guest", isGuest = true)
    }

    suspend fun logout() {
        preferencesManager.clearSession()
    }
}
