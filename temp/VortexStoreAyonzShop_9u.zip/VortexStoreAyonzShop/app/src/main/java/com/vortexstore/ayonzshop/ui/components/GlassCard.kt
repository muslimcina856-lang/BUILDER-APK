package com.vortexstore.ayonzshop.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.ui.theme.GlassBorder
import com.vortexstore.ayonzshop.ui.theme.GlassWhite05
import com.vortexstore.ayonzshop.ui.theme.GlassWhite10

/**
 * Frosted "glassmorphism" container used across product cards, dialogs
 * and chat bubbles for the premium futuristic look.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Int = 20,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(
                Brush.linearGradient(listOf(GlassWhite10, GlassWhite05))
            )
            .border(1.dp, GlassBorder, RoundedCornerShape(cornerRadius.dp))
    ) {
        content()
    }
}
