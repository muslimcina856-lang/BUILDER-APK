package com.vortexstore.ayonzshop.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.theme.VortexAccent

private data class AdminAction(val title: String, val icon: ImageVector)

private val actions = listOf(
    AdminAction("Kelola Produk", Icons.Default.Inventory2),
    AdminAction("Verifikasi Pembayaran", Icons.Default.VerifiedUser),
    AdminAction("Pesanan Masuk", Icons.Default.Receipt),
    AdminAction("Kelola Pengguna", Icons.Default.People),
    AdminAction("Statistik Penjualan", Icons.Default.BarChart),
    AdminAction("Moderasi Chat", Icons.Default.Forum)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(onBack: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(actions) { action ->
                GlassCard(modifier = Modifier.fillMaxWidth().height(100.dp)) {
                    Column(
                        Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Icon(action.icon, contentDescription = null, tint = VortexAccent)
                        Spacer(Modifier.height(6.dp))
                        Text(action.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
