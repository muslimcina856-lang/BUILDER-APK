package com.vortexstore.ayonzshop.ui.theme

import androidx.compose.ui.graphics.Color

// Vortex futuristic dark palette
val VortexBackground = Color(0xFF0A0E1A)
val VortexSurface = Color(0xFF121829)
val VortexSurfaceAlt = Color(0xFF1A2238)
val VortexPrimary = Color(0xFF7B5CFF)
val VortexPrimaryVariant = Color(0xFF5A3FE0)
val VortexAccent = Color(0xFF00E5C7)
val VortexTextPrimary = Color(0xFFF2F4FF)
val VortexTextSecondary = Color(0xFF9AA3C7)
val VortexError = Color(0xFFFF5C7A)
val VortexSuccess = Color(0xFF27D17E)

// Glassmorphism overlay colors
val GlassWhite10 = Color(0x1AFFFFFF)
val GlassWhite05 = Color(0x0DFFFFFF)
val GlassBorder = Color(0x33FFFFFF)
