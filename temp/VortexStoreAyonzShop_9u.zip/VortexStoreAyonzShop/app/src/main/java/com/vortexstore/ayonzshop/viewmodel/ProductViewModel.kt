package com.vortexstore.ayonzshop.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vortexstore.ayonzshop.VortexApplication
import com.vortexstore.ayonzshop.models.Product
import com.vortexstore.ayonzshop.models.ProductCategory
import com.vortexstore.ayonzshop.network.RetrofitClient
import com.vortexstore.ayonzshop.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

class ProductViewModel : ViewModel() {

    private val repository = ProductRepository(
        RetrofitClient.apiService,
        VortexApplication.instance.database.productDao()
    )

    private val _selectedCategory = MutableStateFlow<ProductCategory?>(null)
    val selectedCategory: StateFlow<ProductCategory?> = _selectedCategory

    val products: StateFlow<List<Product>> = _selectedCategory
        .let { categoryFlow ->
            kotlinx.coroutines.flow.flatMapLatest(categoryFlow) { repository.observeProducts(it) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isLoading = MutableStateFlow(false)

    init {
        refresh()
    }

    fun selectCategory(category: ProductCategory?) {
        _selectedCategory.value = category
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            isLoading.value = true
            runCatching { repository.refreshProducts(_selectedCategory.value) }
            isLoading.value = false
        }
    }
}
