package com.vortexstore.ayonzshop.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val category: String,
    val priceMin: Long,
    val priceMax: Long?,
    val imageUrl: String?,
    val isAvailable: Boolean,
    val rating: Float,
    val soldCount: Int,
    val lastSyncedAt: Long = System.currentTimeMillis()
)
