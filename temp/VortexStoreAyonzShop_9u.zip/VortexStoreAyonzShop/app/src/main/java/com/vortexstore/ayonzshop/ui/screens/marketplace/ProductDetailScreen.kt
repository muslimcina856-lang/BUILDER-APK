package com.vortexstore.ayonzshop.ui.screens.marketplace

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vortexstore.ayonzshop.models.Product
import com.vortexstore.ayonzshop.ui.theme.VortexAccent
import com.vortexstore.ayonzshop.utils.CurrencyFormatter
import com.vortexstore.ayonzshop.viewmodel.CartViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vortexstore.ayonzshop.network.RetrofitClient
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    productId: String,
    onBack: () -> Unit,
    onAddedToCart: () -> Unit,
    cartViewModel: CartViewModel = viewModel()
) {
    var product by remember { mutableStateOf<Product?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(productId) {
        scope.launch {
            val response = RetrofitClient.apiService.getProductDetail(productId)
            if (response.isSuccessful) product = response.body()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(product?.name ?: "Detail Produk") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            product?.let { p ->
                Surface(color = MaterialTheme.colorScheme.background) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Button(
                            onClick = { cartViewModel.addToCart(p.id); onAddedToCart() },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = VortexAccent)
                        ) {
                            Text("Tambah ke Keranjang — ${CurrencyFormatter.formatRange(p.priceMin, p.priceMax)}")
                        }
                    }
                }
            }
        }
    ) { padding ->
        product?.let { p ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
                AsyncImage(
                    model = p.imageUrl, contentDescription = p.name, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
                Column(Modifier.padding(20.dp)) {
                    Text(p.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(p.category.displayName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))
                    Text("Deskripsi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(p.description, style = MaterialTheme.typography.bodyMedium)
                    if (p.features.isNotEmpty()) {
                        Spacer(Modifier.height(16.dp))
                        Text("Fitur", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        p.features.forEach { feature ->
                            Text("• $feature", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        } ?: Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}
