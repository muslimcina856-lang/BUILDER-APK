package com.vortexstore.ayonzshop.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val senderName: String,
    val receiverId: String?,
    val chatType: String,
    val contentType: String,
    val content: String,
    val timestamp: Long,
    val isSeen: Boolean = false
)
