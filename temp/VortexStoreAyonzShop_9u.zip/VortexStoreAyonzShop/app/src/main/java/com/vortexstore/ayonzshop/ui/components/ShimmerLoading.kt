package com.vortexstore.ayonzshop.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.vortexstore.ayonzshop.ui.theme.GlassWhite05
import com.vortexstore.ayonzshop.ui.theme.GlassWhite10

/** Shimmering placeholder shown while product/chat data is loading. */
@Composable
fun ShimmerBox(modifier: Modifier = Modifier, cornerRadius: Int = 14) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerTranslate"
    )
    val brush = Brush.linearGradient(
        colors = listOf(GlassWhite05, GlassWhite10, GlassWhite05),
        start = Offset(translateAnim - 400f, 0f),
        end = Offset(translateAnim, 0f)
    )
    Column(
        modifier
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(brush)
    ) {}
}

@Composable
fun ProductCardShimmer(modifier: Modifier = Modifier) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            ShimmerBox(Modifier.fillMaxWidth().height(110.dp))
        }
    }
}
