package com.vortexstore.ayonzshop.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val VortexDarkColorScheme = darkColorScheme(
    primary = VortexPrimary,
    onPrimary = VortexTextPrimary,
    primaryContainer = VortexPrimaryVariant,
    secondary = VortexAccent,
    onSecondary = VortexBackground,
    background = VortexBackground,
    onBackground = VortexTextPrimary,
    surface = VortexSurface,
    onSurface = VortexTextPrimary,
    surfaceVariant = VortexSurfaceAlt,
    onSurfaceVariant = VortexTextSecondary,
    error = VortexError
)

@Composable
fun VortexStoreTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        val window = (view.context as? android.app.Activity)?.window
        window?.let {
            WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = VortexDarkColorScheme,
        typography = VortexTypography,
        content = content
    )
}
