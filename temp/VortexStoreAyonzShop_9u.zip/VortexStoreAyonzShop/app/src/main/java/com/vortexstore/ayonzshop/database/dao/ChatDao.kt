package com.vortexstore.ayonzshop.database.dao

import androidx.room.*
import com.vortexstore.ayonzshop.database.entities.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE chatType = 'GLOBAL' ORDER BY timestamp ASC")
    fun observeGlobalChat(): Flow<List<ChatMessageEntity>>

    @Query("""
        SELECT * FROM chat_messages
        WHERE chatType = 'PRIVATE' AND
        ((senderId = :userId AND receiverId = :otherUserId) OR (senderId = :otherUserId AND receiverId = :userId))
        ORDER BY timestamp ASC
    """)
    fun observePrivateChat(userId: String, otherUserId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)
}
