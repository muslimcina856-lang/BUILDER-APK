package com.vortexstore.ayonzshop.models

data class CartItem(
    val product: Product,
    val quantity: Int = 1,
    val notes: String? = null
) {
    val subtotal: Long get() = product.priceMin * quantity
}
