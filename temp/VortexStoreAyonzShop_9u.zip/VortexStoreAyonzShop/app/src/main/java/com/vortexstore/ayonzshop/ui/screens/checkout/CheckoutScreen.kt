package com.vortexstore.ayonzshop.ui.screens.checkout

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vortexstore.ayonzshop.R
import com.vortexstore.ayonzshop.models.PaymentMethod
import com.vortexstore.ayonzshop.network.CreateOrderRequest
import com.vortexstore.ayonzshop.network.RetrofitClient
import com.vortexstore.ayonzshop.ui.components.GlassCard
import com.vortexstore.ayonzshop.ui.theme.VortexAccent
import com.vortexstore.ayonzshop.utils.CurrencyFormatter
import com.vortexstore.ayonzshop.utils.PaymentConfig
import com.vortexstore.ayonzshop.viewmodel.CartViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(onBack: () -> Unit, onOrderPlaced: () -> Unit, cartViewModel: CartViewModel = viewModel()) {
    val items by cartViewModel.cartItems.collectAsState()
    val total by cartViewModel.totalAmount.collectAsState()
    var selectedMethod by remember { mutableStateOf(PaymentMethod.QRIS) }
    var isSubmitting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Checkout") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)
        ) {
            Text("Metode Pembayaran", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))

            PaymentOption(
                label = "QRIS — ${PaymentConfig.MERCHANT_NAME}",
                selected = selectedMethod == PaymentMethod.QRIS,
                onClick = { selectedMethod = PaymentMethod.QRIS }
            )
            Spacer(Modifier.height(10.dp))
            PaymentOption(
                label = "DANA — ${PaymentConfig.DANA_NUMBER}",
                selected = selectedMethod == PaymentMethod.DANA,
                onClick = { selectedMethod = PaymentMethod.DANA }
            )

            Spacer(Modifier.height(20.dp))
            if (selectedMethod == PaymentMethod.QRIS) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = R.drawable.qris_payment),
                            contentDescription = "QRIS ${PaymentConfig.MERCHANT_NAME}",
                            modifier = Modifier.fillMaxWidth().height(280.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Scan menggunakan aplikasi e-wallet / m-banking apa pun", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Transfer ke DANA", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text(PaymentConfig.DANA_NUMBER, color = VortexAccent, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Tagihan", style = MaterialTheme.typography.titleMedium)
                        Text(CurrencyFormatter.format(total), color = VortexAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Setelah transfer, unggah bukti pembayaran pada halaman Pesanan Saya. Admin akan memverifikasi sebelum pesanan diproses.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    isSubmitting = true
                    scope.launch {
                        runCatching {
                            RetrofitClient.apiService.createOrder(
                                CreateOrderRequest(items = items, paymentMethod = selectedMethod.name)
                            )
                        }
                        isSubmitting = false
                        cartViewModel.clearCart()
                        onOrderPlaced()
                    }
                },
                enabled = !isSubmitting && items.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VortexAccent)
            ) {
                if (isSubmitting) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                else Text("Buat Pesanan")
            }
        }
    }
}

@Composable
private fun PaymentOption(label: String, selected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.Medium)
            RadioButton(selected = selected, onClick = onClick, colors = RadioButtonDefaults.colors(selectedColor = VortexAccent))
        }
    }
}
