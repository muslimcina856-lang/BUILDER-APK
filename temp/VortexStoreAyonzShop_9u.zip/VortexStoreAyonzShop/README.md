# Vortex Store: Ayonz Shop

Starter project (bukan production jadi 100%) untuk aplikasi marketplace digital
"Vortex Store: Ayonz Shop" — terdiri dari aplikasi Android (Kotlin + Jetpack
Compose) dan backend (Node.js + Express + TypeScript + Socket.IO).

## Catatan Penting

- Kategori **nomor virtual untuk verifikasi SMS/OTP** sengaja **tidak**
  dibuatkan di project ini karena fitur tersebut umum disalahgunakan untuk
  pembuatan akun palsu massal dan penipuan. Semua kategori lain dari
  spesifikasi awal (panel bot hosting, jasa website/aplikasi, custom feature,
  jasa UI/UX, maintenance, reseller, MC/rekber) sudah dibuatkan.
- Backend memakai **in-memory store** (`src/database/inMemoryStore.ts`) agar
  bisa langsung dijalankan tanpa setup database. Ganti dengan Firestore/
  PostgreSQL/MongoDB sebelum dipakai produksi — lihat `src/config/firebase.ts`
  untuk titik integrasi Firebase Admin SDK.
- Pembayaran QRIS memakai gambar QRIS asli yang diunggah
  (`app/src/main/res/drawable/qris_payment.jpg`) dan nomor DANA dari
  `PaymentConfig.kt` (Android) / `.env` (`DANA_NUMBER`, backend). Proses
  verifikasi masih manual (upload bukti transfer → admin verifikasi) — belum
  terhubung ke payment gateway otomatis.
- Project ini adalah **kerangka kerja (scaffold) yang solid**, bukan aplikasi
  yang sudah teruji/compile penuh. Diperlukan langkah lanjutan: buka di
  Android Studio, sync Gradle, perbaiki error kecil yang mungkin muncul,
  isi konfigurasi Firebase asli, lalu build APK.

## Struktur Project

```
VortexStoreAyonzShop/
├── app/                  # Aplikasi Android (Kotlin, Jetpack Compose, MVVM)
│   └── src/main/java/com/vortexstore/ayonzshop/
│       ├── ui/           # Screens, components, navigation, theme
│       ├── viewmodel/    # ViewModel per fitur
│       ├── repository/   # Single source of truth (Room + network)
│       ├── network/      # Retrofit API + Socket.IO client
│       ├── database/     # Room (entities, DAO, AppDatabase)
│       ├── data/datastore/ # Session/token storage
│       ├── models/       # Domain models
│       └── utils/        # Formatter, payment config
└── backend/              # API + WebSocket server
    └── src/
        ├── controllers/  # Auth, product, order, chat logic
        ├── routes/       # Express route definitions
        ├── middleware/   # JWT auth, rate limiter, error handler
        ├── websocket/    # Socket.IO real-time chat handler
        ├── models/       # TypeScript interfaces
        └── database/     # In-memory store (swap for real DB)
```

## Menjalankan Backend

```bash
cd backend
cp .env.example .env
npm install
npm run dev        # development (ts-node-dev)
# atau
npm run build && npm start
```

Server berjalan di `http://localhost:4000`. Endpoint kesehatan: `GET /health`.

## Membuka Aplikasi Android

1. Buka folder root project ini di Android Studio (Hedgehog/Iguana ke atas).
2. Salin `local.properties.example` → `local.properties`, isi `sdk.dir` sesuai
   lokasi Android SDK kamu.
3. Untuk emulator, `BASE_URL`/`SOCKET_URL` debug sudah diarahkan ke
   `http://10.0.2.2:4000/` (alias localhost dari host machine).
4. Sync Gradle, lalu Run pada perangkat/emulator.
5. (Opsional) Tambahkan file `google-services.json` dari project Firebase
   asli ke folder `app/` agar Firebase Auth/Firestore/Messaging aktif.

## Build APK Release

```bash
./gradlew assembleRelease
```

APK hasil build ada di `app/build/outputs/apk/release/`.

## Langkah Lanjutan yang Disarankan

- Hubungkan backend ke database sungguhan (Firestore/PostgreSQL).
- Integrasikan payment gateway otomatis (Midtrans/Xendit) agar verifikasi
  pembayaran tidak manual.
- Tambah upload gambar (Firebase Storage/S3) untuk bukti pembayaran & foto
  profil.
- Tambah Hilt/Koin untuk dependency injection yang lebih rapi.
- Tambah unit test & instrumented test.
