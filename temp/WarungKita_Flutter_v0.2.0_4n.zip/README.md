# Warung Kita — Flutter

Game simulasi warung offline untuk Android. Projek ini ialah **projek Flutter/Dart tulen**, bukan Godot.

## Teknologi

- Flutter / Dart
- Android embedding v2
- `shared_preferences` untuk simpanan tempatan
- Tiada pelayan dan tiada keperluan internet semasa bermain

## Ciri prototaip

- Menu utama dan sambung permainan
- Operasi pelanggan automatik
- 6 menu makanan dan minuman
- Sistem stok, pembelian dan resipi
- Wang, tip dan reputasi
- 4 kategori naik taraf
- Laporan harian dan statistik keseluruhan
- Auto-simpan dan kemajuan offline maksimum 4 jam
- Ikon aplikasi serta helaian aset sumber

## Build APK

```bash
flutter pub get
flutter build apk --release
```

APK akan terhasil di:

```text
build/app/outputs/flutter-apk/app-release.apk
```

ID pakej Android: `com.earlxz.warungkita`

## Nota tandatangan

Konfigurasi release prototaip menggunakan debug signing supaya bot boleh menghasilkan APK ujian. Untuk Play Store, gantikan dengan release keystore sendiri.
