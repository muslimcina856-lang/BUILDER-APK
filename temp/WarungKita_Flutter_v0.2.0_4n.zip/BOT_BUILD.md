# Tetapan bot binaan

Jenis projek: **Flutter**

Fail pengesanan utama berada terus pada akar projek:

- `pubspec.yaml`
- `lib/main.dart`
- `android/settings.gradle.kts`
- `android/app/build.gradle.kts`

Arahan binaan yang disyorkan:

```bash
flutter clean
flutter pub get
flutter build apk --release
```

APK akan berada di:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Pilih **Flutter** pada bot binaan. Projek ini tidak menggunakan Godot dan tidak memerlukan Flame.
