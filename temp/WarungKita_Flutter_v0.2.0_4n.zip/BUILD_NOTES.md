# Catatan binaan

Projek ini ialah projek Flutter/Dart tulen untuk Android dengan ID pakej `com.earlxz.warungkita`.

Semakan yang dibuat dalam persekitaran penyediaan:

- `pubspec.yaml` berjaya diparsing sebagai YAML.
- Semua fail Android XML berjaya diparsing.
- Struktur kurungan dan rentetan asas semua fail Dart telah disemak.
- Semua aset yang dirujuk dalam kod dan `pubspec.yaml` wujud.
- Ikon Android disediakan untuk mdpi hingga xxxhdpi.
- Pelancar Gradle wrapper disertakan dan diuji menggunakan agihan Gradle ujian tempatan.

Ujian `flutter analyze` dan eksport APK sebenar tidak dapat dijalankan di persekitaran penyediaan kerana Flutter SDK tidak dipasang. Bot binaan yang mempunyai Flutter SDK perlu menjalankan arahan dalam `BOT_BUILD.md`.
