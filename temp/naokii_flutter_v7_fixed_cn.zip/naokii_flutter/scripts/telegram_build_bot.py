#!/usr/bin/env python3
"""
Bot Telegram sederhana untuk trigger build APK Naokii Comic.

Perintah:
  /start   — info
  /build   — trigger GitHub Actions workflow_dispatch (Build APK)
  /status  — cek run terakhir

Setup:
  1. Buat bot via @BotFather → dapatkan TELEGRAM_BOT_TOKEN
  2. GitHub PAT (repo scope) → GITHUB_TOKEN
  3. Set env:
       TELEGRAM_BOT_TOKEN=...
       GITHUB_TOKEN=...
       GITHUB_REPO=username/naokii_flutter   # owner/repo
       ALLOWED_CHAT_IDS=123456789,987654321 # optional whitelist
  4. Di GitHub repo → Settings → Secrets:
       TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID (untuk upload APK otomatis)
  5. Jalankan: python scripts/telegram_build_bot.py

Butuh: pip install requests
"""

from __future__ import annotations

import os
import time
import requests

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
GH_TOKEN = os.environ.get("GITHUB_TOKEN", "")
REPO = os.environ.get("GITHUB_REPO", "")  # e.g. reyy/naokii_flutter
ALLOWED = {
    x.strip()
    for x in os.environ.get("ALLOWED_CHAT_IDS", "").split(",")
    if x.strip()
}
WORKFLOW_FILE = "build-apk.yml"
API = f"https://api.telegram.org/bot{TOKEN}"


def tg(method: str, **payload):
    r = requests.post(f"{API}/{method}", json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def send(chat_id: int, text: str):
    return tg("sendMessage", chat_id=chat_id, text=text, parse_mode="HTML")


def trigger_build(note: str = "") -> str:
    if not GH_TOKEN or not REPO:
        return "GITHUB_TOKEN / GITHUB_REPO belum di-set."
    url = f"https://api.github.com/repos/{REPO}/actions/workflows/{WORKFLOW_FILE}/dispatches"
    headers = {
        "Authorization": f"Bearer {GH_TOKEN}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    body = {
        "ref": "main",
        "inputs": {"note": note or "Triggered from Telegram bot"},
    }
    r = requests.post(url, headers=headers, json=body, timeout=30)
    if r.status_code in (204, 200):
        return (
            "✅ Build di-trigger.\n"
            f"Pantau: https://github.com/{REPO}/actions\n"
            "APK akan dikirim ke chat ini jika secret TELEGRAM_* terisi di GitHub."
        )
    return f"❌ Gagal trigger ({r.status_code}): {r.text[:400]}"


def last_run_status() -> str:
    if not GH_TOKEN or not REPO:
        return "GITHUB_TOKEN / GITHUB_REPO belum di-set."
    url = f"https://api.github.com/repos/{REPO}/actions/workflows/{WORKFLOW_FILE}/runs?per_page=1"
    headers = {
        "Authorization": f"Bearer {GH_TOKEN}",
        "Accept": "application/vnd.github+json",
    }
    r = requests.get(url, headers=headers, timeout=30)
    if r.status_code != 200:
        return f"Error: {r.status_code} {r.text[:200]}"
    runs = r.json().get("workflow_runs") or []
    if not runs:
        return "Belum ada workflow run."
    run = runs[0]
    return (
        f"Run #{run.get('run_number')}\n"
        f"Status: <b>{run.get('status')}</b> / {run.get('conclusion')}\n"
        f"URL: {run.get('html_url')}"
    )


def allowed(chat_id: int) -> bool:
    if not ALLOWED:
        return True
    return str(chat_id) in ALLOWED


def main():
    if not TOKEN:
        raise SystemExit("Set TELEGRAM_BOT_TOKEN")
    print("Naokii build bot running…")
    offset = 0
    while True:
        try:
            data = tg("getUpdates", offset=offset, timeout=30)
            for upd in data.get("result", []):
                offset = upd["update_id"] + 1
                msg = upd.get("message") or {}
                text = (msg.get("text") or "").strip()
                chat = msg.get("chat") or {}
                chat_id = chat.get("id")
                if not chat_id or not text:
                    continue
                if not allowed(chat_id):
                    send(chat_id, "Unauthorized.")
                    continue
                if text.startswith("/start"):
                    send(
                        chat_id,
                        "<b>Naokii Comic Build Bot</b>\n\n"
                        "/build — trigger APK release build\n"
                        "/status — status run terakhir",
                    )
                elif text.startswith("/build"):
                    note = text[6:].strip()
                    send(chat_id, "⏳ Triggering build…")
                    send(chat_id, trigger_build(note))
                elif text.startswith("/status"):
                    send(chat_id, last_run_status())
        except Exception as e:
            print("loop error:", e)
            time.sleep(3)


if __name__ == "__main__":
    main()
