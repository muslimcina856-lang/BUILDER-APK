# Fix Google Sign-In "login batal" / ApiException 10 (DEVELOPER_ERROR)

## Root cause yang ketemu

`android/app/google-services.json` kamu **nggak punya satupun `oauth_client`
entry** — artinya belum ada SHA-1 yang pernah didaftarin ke Firebase buat
app Android ini. Karena itu, Google Sign-In (Credential Manager di
google_sign_in 7.x) nggak nemu kredensial yang cocok dan langsung
"cancel" tanpa error jelas — makanya kelihatannya "login batal gitu aja".

Masalah keduanya: `android/app/build.gradle` kemarin masih pakai
`signingConfigs.debug` bawaan Android Gradle Plugin, yang keystore-nya
(`~/.android/debug.keystore`) **di-generate ulang secara acak tiap run
GitHub Actions** (VM baru tiap kali). Jadi walaupun SHA-1 didaftarin
hari ini, besok build ulang → SHA-1 beda lagi → Google Sign-In rusak lagi.

## Yang udah gue benerin di project ini

1. Generate **`android/app/naokii-debug.keystore`** — keystore permanen,
   di-commit ke repo, dipakai konsisten di SETIAP build (lokal maupun CI).
2. `android/app/build.gradle` sekarang eksplisit pakai keystore itu
   (`signingConfigs.naokiiDebug`), bukan `signingConfigs.debug` bawaan.
3. `.gitignore` di-allowlist khusus buat file keystore ini biar ke-commit.

**⚠️ Catatan:** ini keystore testing/sideloading (password plaintext di
build.gradle, memang disengaja karena bukan buat Play Store). Kalau nanti
mau publish ke Play Store, wajib bikin keystore rilis terpisah yang
password-nya disimpan sebagai GitHub Secret, bukan di-commit.

## Yang PERLU kamu lakuin sekarang (sekali aja)

SHA-1 dari keystore yang baru gue generate:
```
SHA1:   3A:29:07:AB:40:67:EE:50:28:9B:CC:A9:09:B3:6E:01:4F:B0:90:87
SHA256: 53:81:24:CF:59:4F:00:AA:E7:DA:9E:07:4A:56:06:44:69:96:12:A7:28:53:40:A6:7D:60:5B:2B:EE:AA:70:7D
```

1. **Firebase Console** → project `ryychatroom` → Project settings →
   Your apps → app Android (`com.naokii.comic`) → **Add fingerprint**
   → paste SHA1 di atas → Save. (Tambahin SHA256 juga kalau kolomnya ada.)
2. Firebase bakal regenerate `google-services.json` — **download ulang**
   file itu, timpa `android/app/google-services.json` yang lama.
3. Firebase → Authentication → Sign-in method → pastiin **Google** provider
   statusnya Enabled.
4. Commit & push semuanya (termasuk `naokii-debug.keystore` dan
   `google-services.json` yang baru) ke repo, `/build` lagi lewat bot Telegram.
5. **Uninstall APK lama di HP dulu sebelum install yang baru** — APK lama
   di-sign pakai keystore acak yang beda, Android nolak install "update"
   dengan signature berbeda kalau nggak di-uninstall dulu.

Setelah ini, SHA-1 app kamu udah permanen — nggak perlu diulang lagi tiap
build, kecuali kamu ganti isi `naokii-debug.keystore`.
