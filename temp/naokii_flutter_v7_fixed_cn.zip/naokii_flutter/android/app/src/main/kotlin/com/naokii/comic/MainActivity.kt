package com.naokii.comic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
