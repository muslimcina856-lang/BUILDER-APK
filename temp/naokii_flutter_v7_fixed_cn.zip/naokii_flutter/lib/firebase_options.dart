// GENERATED PLACEHOLDER — ganti dengan output `flutterfire configure`
// Project Firebase yang sama: ryychatroom

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return android;
    }
  }

  // Mirror nilai NEXT_PUBLIC_* dari web (client-safe)
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDZKqQAxo77pDNhcAMcOZoGdu25gVMTVaY',
    appId: '1:402217827316:web:0f97dd7773361b7e0e17a1',
    messagingSenderId: '402217827316',
    projectId: 'ryychatroom',
    authDomain: 'ryychatroom.firebaseapp.com',
    databaseURL:
        'https://ryychatroom-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'ryychatroom.firebasestorage.app',
    measurementId: 'G-WC8XTPZKE2',
  );

  // TODO: tambahkan Android app di Firebase Console → Project settings →
  // Add app → Android (package: com.naokii.comic) lalu isi nilai di bawah
  // atau jalankan: flutterfire configure
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDZKqQAxo77pDNhcAMcOZoGdu25gVMTVaY',
    appId: '1:402217827316:web:0f97dd7773361b7e0e17a1',
    messagingSenderId: '402217827316',
    projectId: 'ryychatroom',
    storageBucket: 'ryychatroom.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDZKqQAxo77pDNhcAMcOZoGdu25gVMTVaY',
    appId: '1:402217827316:web:0f97dd7773361b7e0e17a1',
    messagingSenderId: '402217827316',
    projectId: 'ryychatroom',
    storageBucket: 'ryychatroom.firebasestorage.app',
    iosBundleId: 'com.naokii.comic',
  );
}
