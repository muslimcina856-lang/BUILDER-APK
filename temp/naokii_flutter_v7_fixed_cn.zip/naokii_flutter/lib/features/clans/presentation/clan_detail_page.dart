import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

class ClanDetailPage extends ConsumerWidget {
  const ClanDetailPage({super.key, required this.clanId});
  final String clanId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: SocialRepository().listenClan(clanId),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data!.data();
          if (data == null) {
            return Scaffold(
              appBar: AppBar(),
              body: const Center(
                child: Text('Clan tidak ditemukan.', style: TextStyle(color: AppColors.textMuted)),
              ),
            );
          }
          final name = data['name'] as String? ?? 'Clan';
          final tag = data['tag'] as String? ?? '';
          final memberCount = data['memberCount'] as num? ?? 0;
          final ownerUid = data['ownerUid'] as String?;

          return CustomScrollView(
            slivers: [
              SliverAppBar(
                pinned: true,
                title: Text(name),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.bgCard,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: AppColors.accentSoft,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Icon(Icons.shield_rounded, color: AppColors.primary, size: 26),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                              Text('[$tag] · $memberCount member',
                                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                            ],
                          ),
                        ),
                        if (user != null)
                          user.uid == ownerUid
                              ? const SizedBox.shrink()
                              : TextButton(
                                  onPressed: () => SocialRepository().leaveClan(clanId, user.uid),
                                  child: const Text('Keluar', style: TextStyle(color: AppColors.danger)),
                                ),
                      ],
                    ),
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverToBoxAdapter(
                  child: const Text('Member', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 10)),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: SocialRepository().listenClanMembers(clanId),
                builder: (context, memSnap) {
                  final docs = memSnap.data?.docs ?? [];
                  if (!memSnap.hasData) {
                    return const SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Center(child: CircularProgressIndicator()),
                      ),
                    );
                  }
                  return SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
                    sliver: SliverList.builder(
                      itemCount: docs.length,
                      itemBuilder: (context, i) {
                        final m = docs[i];
                        final role = m.data()['role'] as String? ?? 'member';
                        return FutureBuilder(
                          future: UserRepository().getProfile(m.id),
                          builder: (context, uSnap) {
                            final p = uSnap.data;
                            return ListTile(
                              onTap: () => context.push('/u/${m.id}'),
                              contentPadding: const EdgeInsets.symmetric(vertical: 4),
                              leading: AvatarBorder(
                                photoUrl: p?.photoUrl,
                                size: 40,
                                baseBorderId: p?.borderId,
                                verified: p?.verified ?? false,
                              ),
                              title: Text(p?.name ?? '...', style: const TextStyle(fontWeight: FontWeight.w700)),
                              trailing: role == 'owner'
                                  ? const Icon(Icons.workspace_premium_rounded, size: 18, color: AppColors.warning)
                                  : null,
                            );
                          },
                        );
                      },
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
