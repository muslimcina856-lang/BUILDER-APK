
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';

class ClansPage extends ConsumerWidget {
  const ClansPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clan'),
        actions: [
          if (user != null)
            IconButton(
              icon: const Icon(Icons.add_rounded),
              onPressed: () async {
                final name = TextEditingController();
                final tag = TextEditingController();
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: AppColors.bgSurface,
                    title: const Text('Buat Clan'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(controller: name, decoration: const InputDecoration(hintText: 'Nama clan')),
                        const SizedBox(height: 8),
                        TextField(controller: tag, decoration: const InputDecoration(hintText: 'Tag (max 6)'), maxLength: 6),
                      ],
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Buat')),
                    ],
                  ),
                );
                if (ok == true && name.text.trim().isNotEmpty) {
                  await SocialRepository().createClan(uid: user.uid, name: name.text, tag: tag.text.isEmpty ? 'CLAN' : tag.text);
                }
              },
            ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: SocialRepository().listenClans(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('Belum ada clan.', style: TextStyle(color: AppColors.textMuted)));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final d = docs[i].data();
              return ListTile(
                onTap: () => context.push('/clan/${docs[i].id}'),
                tileColor: AppColors.bgCard,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: AppColors.border)),
                title: Text(d['name'] as String? ?? 'Clan', style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('[${d['tag'] ?? ''}] · ${d['memberCount'] ?? 0} member'),
                trailing: user == null
                    ? null
                    : TextButton(
                        onPressed: () async {
                          try {
                            await SocialRepository().joinClan(docs[i].id, user.uid);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bergabung!')));
                            }
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                            }
                          }
                        },
                        child: const Text('Join'),
                      ),
              );
            },
          );
        },
      ),
    );
  }
}
