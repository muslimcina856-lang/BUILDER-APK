
import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/comic.dart';
import '../../../data/repositories/comic_repository.dart';
import '../../../data/repositories/library_repository.dart';
import '../../../data/services/auth_service.dart';

final _chapterProvider =
    FutureProvider.family<Chapter?, ({String comicId, String chapterId})>(
  (ref, args) => ComicRepository().getChapter(args.comicId, args.chapterId),
);

final _chaptersListProvider =
    FutureProvider.family<List<Chapter>, String>(
  (ref, comicId) => ComicRepository().listChapters(comicId),
);

enum ReaderMode { longStrip, singlePage }

class ReaderPage extends ConsumerStatefulWidget {
  const ReaderPage({
    super.key,
    required this.comicId,
    required this.chapterId,
  });

  final String comicId;
  final String chapterId;

  @override
  ConsumerState<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends ConsumerState<ReaderPage> {
  ReaderMode _mode = ReaderMode.longStrip;
  bool _chromeVisible = true;
  bool _autoScroll = false;
  double _autoSpeed = 1.5;
  Timer? _autoTimer;
  final _scrollCtrl = ScrollController();
  final _pageCtrl = PageController();
  int _pageIndex = 0;
  bool _progressSaved = false;

  @override
  void dispose() {
    _autoTimer?.cancel();
    _scrollCtrl.dispose();
    _pageCtrl.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _toggleChrome() {
    HapticFeedback.selectionClick();
    setState(() => _chromeVisible = !_chromeVisible);
    if (_chromeVisible) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _setAutoScroll(bool on) {
    _autoTimer?.cancel();
    setState(() => _autoScroll = on);
    if (on && _mode == ReaderMode.longStrip) {
      _autoTimer = Timer.periodic(const Duration(milliseconds: 32), (_) {
        if (!_scrollCtrl.hasClients) return;
        final next = _scrollCtrl.offset + _autoSpeed;
        final max = _scrollCtrl.position.maxScrollExtent;
        if (next >= max) {
          _autoTimer?.cancel();
          setState(() => _autoScroll = false);
          return;
        }
        _scrollCtrl.jumpTo(next);
      });
    }
  }

  void _goChapter(String chapterId) {
    HapticFeedback.mediumImpact();
    _setAutoScroll(false);
    context.pushReplacement('/read/${widget.comicId}/$chapterId');
  }

  void _showChapterList(List<Chapter> chapters) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgSurface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) {
        return SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.65,
          child: Column(
            children: [
              const SizedBox(height: 10),
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Daftar Chapter',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: chapters.length,
                  itemBuilder: (_, i) {
                    final ch = chapters[i];
                    final active = ch.id == widget.chapterId;
                    return ListTile(
                      selected: active,
                      selectedTileColor: AppColors.accentSoft,
                      title: Text(
                        ch.displayTitle,
                        style: TextStyle(
                          fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                          color: active ? AppColors.primary : null,
                        ),
                      ),
                      trailing: active
                          ? const Icon(Icons.menu_book_rounded, color: AppColors.primary, size: 18)
                          : null,
                      onTap: () {
                        Navigator.pop(ctx);
                        if (!active) _goChapter(ch.id);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(_chapterProvider((
      comicId: widget.comicId,
      chapterId: widget.chapterId,
    )));
    final chaptersAsync = ref.watch(_chaptersListProvider(widget.comicId));

    return Scaffold(
      backgroundColor: Colors.black,
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error: (e, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Error: $e', style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center),
          ),
        ),
        data: (chapter) {
          if (chapter == null || chapter.pages.isEmpty) {
            return const Center(child: Text('Chapter kosong / tidak tersedia', style: TextStyle(color: Colors.white70)));
          }

          if (!_progressSaved) {
            _progressSaved = true;
            final user = ref.read(authServiceProvider).currentUser;
            if (user != null) {
              LibraryRepository().setLastRead(
                user.uid,
                comicId: widget.comicId,
                chapterId: widget.chapterId,
                chapterNumber: chapter.number,
              );
              LibraryRepository().markChapterRead(user.uid, widget.comicId, widget.chapterId);
            }
          }

          final chapters = chaptersAsync.valueOrNull ?? [];
          Chapter? prev;
          Chapter? next;
          if (chapters.isNotEmpty) {
            final idx = chapters.indexWhere((c) => c.id == widget.chapterId);
            if (idx > 0) prev = chapters[idx - 1];
            if (idx >= 0 && idx < chapters.length - 1) next = chapters[idx + 1];
          }

          return Stack(
            children: [
              GestureDetector(
                onTap: _toggleChrome,
                child: _mode == ReaderMode.longStrip
                    ? ListView.builder(
                        controller: _scrollCtrl,
                        physics: const BouncingScrollPhysics(),
                        itemCount: chapter.pages.length,
                        itemBuilder: (_, i) => CachedNetworkImage(
                          imageUrl: chapter.pages[i],
                          fit: BoxFit.fitWidth,
                          width: double.infinity,
                          placeholder: (_, __) => const SizedBox(
                            height: 200,
                            child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary)),
                          ),
                          errorWidget: (_, __, ___) => const SizedBox(
                            height: 120,
                            child: Center(child: Icon(Icons.broken_image_outlined, color: Colors.white38)),
                          ),
                        ),
                      )
                    : PageView.builder(
                        controller: _pageCtrl,
                        itemCount: chapter.pages.length,
                        onPageChanged: (i) => setState(() => _pageIndex = i),
                        itemBuilder: (_, i) => InteractiveViewer(
                          child: CachedNetworkImage(
                            imageUrl: chapter.pages[i],
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
              ),
              AnimatedOpacity(
                opacity: _chromeVisible ? 1 : 0,
                duration: const Duration(milliseconds: 180),
                child: IgnorePointer(
                  ignoring: !_chromeVisible,
                  child: SafeArea(
                    child: Column(
                      children: [
                        // Top bar
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                          color: Colors.black.withValues(alpha: 0.72),
                          child: Row(
                            children: [
                              IconButton(
                                onPressed: () => context.pop(),
                                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                              ),
                              Expanded(
                                child: Text(
                                  chapter.displayTitle,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                ),
                              ),
                              IconButton(
                                tooltip: _mode == ReaderMode.longStrip ? 'Mode halaman' : 'Mode strip',
                                onPressed: () {
                                  _setAutoScroll(false);
                                  setState(() {
                                    _mode = _mode == ReaderMode.longStrip
                                        ? ReaderMode.singlePage
                                        : ReaderMode.longStrip;
                                  });
                                },
                                icon: Icon(
                                  _mode == ReaderMode.longStrip
                                      ? Icons.view_day_rounded
                                      : Icons.view_agenda_rounded,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        // Bottom controls — next/prev/list/auto like web Reader
                        Container(
                          padding: const EdgeInsets.fromLTRB(8, 10, 8, 12),
                          color: Colors.black.withValues(alpha: 0.78),
                          child: Column(
                            children: [
                              Text(
                                _mode == ReaderMode.singlePage
                                    ? '${_pageIndex + 1} / ${chapter.pages.length}'
                                    : '${chapter.pages.length} halaman',
                                style: const TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Expanded(
                                    child: _CtrlBtn(
                                      icon: Icons.skip_previous_rounded,
                                      label: 'Prev',
                                      onTap: prev == null ? null : () => _goChapter(prev!.id),
                                    ),
                                  ),
                                  Expanded(
                                    child: _CtrlBtn(
                                      icon: _autoScroll ? Icons.pause_rounded : Icons.keyboard_double_arrow_down_rounded,
                                      label: _autoScroll ? 'Jeda' : 'Auto',
                                      active: _autoScroll,
                                      onTap: _mode != ReaderMode.longStrip
                                          ? null
                                          : () => _setAutoScroll(!_autoScroll),
                                    ),
                                  ),
                                  Expanded(
                                    child: _CtrlBtn(
                                      icon: Icons.list_rounded,
                                      label: 'List',
                                      onTap: chapters.isEmpty ? null : () => _showChapterList(chapters),
                                    ),
                                  ),
                                  Expanded(
                                    child: _CtrlBtn(
                                      icon: Icons.skip_next_rounded,
                                      label: 'Next',
                                      onTap: next == null ? null : () => _goChapter(next!.id),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CtrlBtn extends StatelessWidget {
  const _CtrlBtn({required this.icon, required this.label, this.onTap, this.active = false});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          children: [
            Icon(icon, color: !enabled
                ? Colors.white24
                : active
                    ? AppColors.primary
                    : Colors.white),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: !enabled
                      ? Colors.white24
                      : active
                          ? AppColors.primary
                          : Colors.white70,
                )),
          ],
        ),
      ),
    );
  }
}
