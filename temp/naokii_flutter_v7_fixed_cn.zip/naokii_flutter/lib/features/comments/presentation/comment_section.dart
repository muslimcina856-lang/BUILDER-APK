import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';
import 'reaction_bar.dart';

class CommentSection extends ConsumerStatefulWidget {
  const CommentSection({super.key, required this.comicId, this.chapterId});
  final String comicId;
  final String? chapterId;

  @override
  ConsumerState<CommentSection> createState() => _CommentSectionState();
}

class _CommentSectionState extends ConsumerState<CommentSection> {
  final _ctrl = TextEditingController();
  bool _sending = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      context.push('/login');
      return;
    }
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      final profile = await UserRepository().getProfile(user.uid);
      await SocialRepository().postComment(
        comicId: widget.comicId,
        chapterId: widget.chapterId,
        uid: user.uid,
        name: profile?.name.isNotEmpty == true ? profile!.name : (user.displayName ?? 'Pembaca'),
        avatar: profile?.photoUrl ?? user.photoURL,
        borderId: profile?.borderId,
        verified: profile?.verified ?? false,
        text: text,
      );
      _ctrl.clear();
      FocusScope.of(context).unfocus();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _upvote(String commentId) async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      context.push('/login');
      return;
    }
    HapticFeedback.selectionClick();
    await SocialRepository().toggleCommentVote(
      comicId: widget.comicId,
      chapterId: widget.chapterId,
      commentId: commentId,
      uid: user.uid,
    );
  }

  @override
  Widget build(BuildContext context) {
    final comicId = widget.comicId;
    if (comicId.startsWith('md_')) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'Komentar untuk judul upload platform. Feed MangaDex belum punya thread lokal.',
          style: TextStyle(color: AppColors.textMuted, fontSize: 13),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Text('Komentar', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        ),
        if (widget.chapterId != null) ReactionBar(comicId: comicId, chapterId: widget.chapterId!),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  maxLength: 1000,
                  decoration: const InputDecoration(hintText: 'Tulis komentar…', counterText: ''),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _sending ? null : _send,
                style: IconButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                icon: _sending
                    ? const SizedBox(
                        width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send_rounded, size: 18),
              ),
            ],
          ),
        ),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: SocialRepository().listenComments(comicId, chapterId: widget.chapterId),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const SizedBox(height: 40, child: Center(child: CircularProgressIndicator(color: AppColors.primary)));
            }
            final docs = snap.data!.docs;
            if (docs.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Belum ada komentar. Jadi yang pertama!', style: TextStyle(color: AppColors.textMuted)),
              );
            }
            return ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              itemCount: docs.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final doc = docs[i];
                final d = doc.data();
                final uid = d['uid'] as String? ?? '';
                final upvotes = (d['upvotes'] as num?)?.toInt() ?? 0;
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AvatarBorder(
                        photoUrl: (d['avatar'] as String?)?.isNotEmpty == true ? d['avatar'] as String : null,
                        size: 34,
                        baseBorderId: d['equippedBorder'] as String?,
                        verified: d['verified'] == true,
                        onTap: uid.isEmpty ? null : () => context.push('/u/$uid'),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d['name'] as String? ?? 'User',
                                style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 13)),
                            const SizedBox(height: 4),
                            Text(d['text'] as String? ?? '', style: const TextStyle(fontSize: 13.5, height: 1.4)),
                            const SizedBox(height: 6),
                            InkWell(
                              borderRadius: BorderRadius.circular(999),
                              onTap: () => _upvote(doc.id),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 2),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.keyboard_arrow_up_rounded,
                                        size: 16, color: AppColors.textMuted),
                                    const SizedBox(width: 2),
                                    Text('$upvotes',
                                        style: const TextStyle(fontSize: 12, color: AppColors.textMuted, fontWeight: FontWeight.w700)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }
}
