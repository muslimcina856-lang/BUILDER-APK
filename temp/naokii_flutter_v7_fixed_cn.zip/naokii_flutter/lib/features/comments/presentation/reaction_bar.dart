
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';

class ReactionBar extends ConsumerStatefulWidget {
  const ReactionBar({super.key, required this.comicId, required this.chapterId});
  final String comicId;
  final String chapterId;

  @override
  ConsumerState<ReactionBar> createState() => _ReactionBarState();
}

class _ReactionBarState extends ConsumerState<ReactionBar> {
  Map<String, int> _counts = {for (final k in SocialRepository.reactionKeys) k: 0};
  String? _mine;
  bool _loading = true;

  static const _icons = {
    'like': Icons.thumb_up_rounded,
    'funny': Icons.sentiment_very_satisfied_rounded,
    'nice': Icons.auto_awesome_rounded,
    'sad': Icons.sentiment_very_dissatisfied_rounded,
    'angry': Icons.mood_bad_rounded,
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.comicId.startsWith('md_')) {
      setState(() => _loading = false);
      return;
    }
    final repo = SocialRepository();
    final counts = await repo.getReactionCounts(widget.comicId, widget.chapterId);
    final user = ref.read(authServiceProvider).currentUser;
    String? mine;
    if (user != null) {
      mine = await repo.getUserReaction(widget.comicId, widget.chapterId, user.uid);
    }
    if (mounted) {
      setState(() {
        _counts = counts;
        _mine = mine;
        _loading = false;
      });
    }
  }

  Future<void> _tap(String type) async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      context.push('/login');
      return;
    }
    if (widget.comicId.startsWith('md_')) return;
    await SocialRepository().setReaction(widget.comicId, widget.chapterId, user.uid, type);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.comicId.startsWith('md_') || _loading) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: SocialRepository.reactionKeys.map((k) {
          final active = _mine == k;
          return GestureDetector(
            onTap: () => _tap(k),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: active ? AppColors.accentSoft : AppColors.bgCard,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: active ? AppColors.primary : AppColors.border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _icons[k] ?? Icons.circle,
                    size: 14,
                    color: active ? AppColors.primary : AppColors.textSecondary,
                  ),
                  const SizedBox(width: 4),
                  Text('${_counts[k] ?? 0}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: active ? AppColors.primary : AppColors.textSecondary,
                      )),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
