import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/skeleton.dart';

const _typeIcon = {
  'like': Icons.thumb_up_rounded,
  'comment': Icons.mode_comment_rounded,
  'affinity': Icons.diversity_3_rounded,
  'clan': Icons.groups_rounded,
  'system': Icons.campaign_rounded,
  'reward': Icons.card_giftcard_rounded,
  'level': Icons.military_tech_rounded,
};

class NotificationsPage extends ConsumerWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifikasi'),
        actions: [
          if (user != null)
            IconButton(
              tooltip: 'Tandai semua dibaca',
              onPressed: () {
                HapticFeedback.selectionClick();
                SocialRepository().markAllNotificationsRead(user.uid);
              },
              icon: const Icon(Icons.done_all_rounded),
            ),
        ],
      ),
      body: user == null
          ? const _EmptyState(
              icon: Icons.notifications_off_rounded,
              text: 'Login dulu untuk lihat notifikasi kamu.',
            )
          : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: SocialRepository().listenNotifications(user.uid),
              builder: (context, snap) {
                if (!snap.hasData) {
                  return const ListRowSkeleton();
                }
                final docs = snap.data!.docs;
                if (docs.isEmpty) {
                  return const _EmptyState(
                    icon: Icons.notifications_none_rounded,
                    text: 'Belum ada notifikasi.',
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 4),
                  itemBuilder: (context, i) {
                    final d = docs[i];
                    final data = d.data();
                    final read = data['read'] == true;
                    final type = data['type'] as String? ?? 'system';
                    final title = data['title'] as String? ?? 'Notifikasi';
                    final body = data['body'] as String? ?? '';
                    final ts = data['createdAt'];
                    String timeStr = '';
                    if (ts is Timestamp) {
                      final dt = ts.toDate();
                      timeStr =
                          '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')} · '
                          '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
                    }
                    return InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () {
                        HapticFeedback.selectionClick();
                        if (!read) {
                          SocialRepository().markNotificationRead(user.uid, d.id);
                        }
                        final link = data['link'] as String?;
                        if (link != null && link.isNotEmpty) context.push(link);
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: read ? AppColors.bgCard : AppColors.accentSoft,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: AppColors.bgElevated,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(_typeIcon[type] ?? Icons.notifications_rounded,
                                  size: 18, color: AppColors.primary),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(title,
                                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                                  if (body.isNotEmpty) ...[
                                    const SizedBox(height: 2),
                                    Text(body,
                                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
                                  ],
                                  if (timeStr.isNotEmpty) ...[
                                    const SizedBox(height: 4),
                                    Text(timeStr,
                                        style: const TextStyle(color: AppColors.textDim, fontSize: 10.5)),
                                  ],
                                ],
                              ),
                            ),
                            if (!read)
                              Container(
                                margin: const EdgeInsets.only(left: 6, top: 4),
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(
                                  color: AppColors.primary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }
}
