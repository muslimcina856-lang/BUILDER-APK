
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('Profil', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                ),
                if (user != null)
                  IconButton(
                    tooltip: 'Notifikasi',
                    onPressed: () => context.push('/notifications'),
                    icon: const Icon(Icons.notifications_rounded, color: AppColors.textMain),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (user == null)
              _Guest(onLogin: () => context.push('/login'))
            else
              FutureBuilder(
                future: UserRepository().getProfile(user.uid),
                builder: (context, snap) {
                  final p = snap.data;
                  return _UserCard(
                    name: p?.name ?? user.displayName ?? 'User',
                    email: user.email,
                    photoUrl: p?.photoUrl ?? user.photoURL,
                    exp: p?.exp ?? 0,
                    level: p?.level ?? 1,
                    coins: p?.coins ?? 0,
                    verified: p?.verified ?? false,
                    borderId: p?.borderId,
                    frameImageUrl: p?.frameImageUrl,
                    role: p?.role ?? 'user',
                    onSignOut: () => ref.read(authServiceProvider).signOut(),
                    onTapAvatar: () => context.push('/u/${user.uid}'),
                  );
                },
              ),
            const SizedBox(height: 20),
            _Tile(Icons.storefront_rounded, 'Shop Border', () => context.push('/shop')),
            _Tile(Icons.bookmark_rounded, 'Library', () => context.go('/library')),
            _Tile(Icons.groups_rounded, 'Clan', () => context.push('/clans')),
            _Tile(Icons.favorite_rounded, 'Top Waifu', () => context.push('/waifu')),
            _Tile(Icons.diversity_3_rounded, 'Affinity', () => context.push('/affinity')),
            _Tile(Icons.card_giftcard_rounded, 'Redeem Code', () => context.push('/redeem')),
            _Tile(Icons.menu_book_rounded, 'Novel', () => context.go('/novel')),
            _Tile(Icons.chat_bubble_rounded, 'Global Chat', () => context.go('/chat')),
            if (user != null)
              FutureBuilder(
                future: UserRepository().getProfile(user.uid),
                builder: (context, snap) {
                  final isAdmin = snap.data?.isAdmin ?? false;
                  if (!isAdmin) return const SizedBox.shrink();
                  return _Tile(Icons.admin_panel_settings_rounded, 'Admin Panel',
                      () => context.push('/admin'));
                },
              ),
            const Divider(height: 32),
            const Text('Naokii Comic APK', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
            const Text('v1.1.0 · Flutter · fitur sosial + MangaDex',
                style: TextStyle(color: AppColors.textDim, fontSize: 11.5)),
          ],
        ),
      ),
    );
  }
}

class _Guest extends StatelessWidget {
  const _Guest({required this.onLogin});
  final VoidCallback onLogin;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          const Icon(Icons.person_rounded, size: 48, color: AppColors.textMuted),
          const SizedBox(height: 10),
          const Text('Belum login', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: onLogin, child: const Text('Masuk dengan Google'))),
        ],
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  const _UserCard({
    required this.name,
    this.email,
    this.photoUrl,
    required this.exp,
    required this.level,
    required this.onSignOut,
    this.coins = 0,
    this.verified = false,
    this.borderId,
    this.frameImageUrl,
    this.role = 'user',
    this.onTapAvatar,
  });
  final String name;
  final String? email;
  final String? photoUrl;
  final int exp;
  final int level;
  final VoidCallback onSignOut;
  final int coins;
  final bool verified;
  final String? borderId;
  final String? frameImageUrl;
  final String role;
  final VoidCallback? onTapAvatar;

  static const _roleLabel = {
    'owner': 'Owner',
    'admin': 'Admin',
    'premium': 'Premium',
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              AvatarBorder(
                photoUrl: photoUrl,
                size: 64,
                baseBorderId: borderId,
                frameImageUrl: frameImageUrl,
                verified: verified,
                onTap: onTapAvatar,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(name,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        ),
                        if (_roleLabel[role] != null) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.accentSoft,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(_roleLabel[role]!,
                                style: const TextStyle(
                                    fontSize: 9.5, fontWeight: FontWeight.w800, color: AppColors.primary)),
                          ),
                        ],
                      ],
                    ),
                    if (email != null) Text(email!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text('Lv.$level · $exp EXP',
                            style: const TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.w700)),
                        const SizedBox(width: 10),
                        const Icon(Icons.monetization_on_rounded, size: 13, color: AppColors.warning),
                        const SizedBox(width: 2),
                        Text('$coins',
                            style: const TextStyle(color: AppColors.warning, fontSize: 12, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Keluar',
                onPressed: onSignOut,
                icon: const Icon(Icons.logout_rounded, color: AppColors.danger, size: 20),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile(this.icon, this.title, this.onTap);
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(color: AppColors.accentSoft, borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: AppColors.primary, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
      onTap: onTap,
    );
  }
}
