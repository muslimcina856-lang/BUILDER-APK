import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/user_profile.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

const _roleLabel = {'owner': 'Owner', 'admin': 'Admin', 'premium': 'Premium'};

const _affinityOptions = [
  (key: 'pasangan', label: 'Pasangan', icon: Icons.favorite_rounded, color: AppColors.pink),
  (key: 'sahabat', label: 'Sahabat', icon: Icons.diversity_1_rounded, color: AppColors.cyan),
  (key: 'teman', label: 'Teman', icon: Icons.groups_rounded, color: AppColors.violet),
];

class PublicProfilePage extends ConsumerStatefulWidget {
  const PublicProfilePage({super.key, required this.uid});
  final String uid;

  @override
  ConsumerState<PublicProfilePage> createState() => _PublicProfilePageState();
}

class _PublicProfilePageState extends ConsumerState<PublicProfilePage> {
  UserProfile? _profile;
  bool _loading = true;
  bool _sendingRequest = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await UserRepository().getProfile(widget.uid);
    if (mounted) setState(() { _profile = p; _loading = false; });
  }

  Future<void> _sendAffinity(String type) async {
    final me = ref.read(authServiceProvider).currentUser;
    if (me == null) {
      context.push('/login');
      return;
    }
    if (me.uid == widget.uid) return;
    setState(() => _sendingRequest = true);
    try {
      await SocialRepository().requestAffinity(me.uid, widget.uid, type);
      HapticFeedback.mediumImpact();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Permintaan terkirim.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _sendingRequest = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = ref.watch(authStateProvider).valueOrNull;
    final isSelf = me?.uid == widget.uid;

    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _profile == null
              ? const Center(
                  child: Text('Pengguna tidak ditemukan.', style: TextStyle(color: AppColors.textMuted)),
                )
              : RefreshIndicator(
                  color: AppColors.primary,
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                    children: [
                      Center(
                        child: AvatarBorder(
                          photoUrl: _profile!.photoUrl,
                          size: 96,
                          baseBorderId: _profile!.borderId,
                          frameImageUrl: _profile!.frameImageUrl,
                          verified: _profile!.verified,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(_profile!.name,
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
                            if (_roleLabel[_profile!.role] != null) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                                decoration: BoxDecoration(
                                  color: AppColors.accentSoft,
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Text(_roleLabel[_profile!.role]!,
                                    style: const TextStyle(
                                        fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.primary)),
                              ),
                            ],
                          ],
                        ),
                      ),
                      if (_profile!.customTitle?.isNotEmpty == true)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(_profile!.customTitle!,
                                style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      const SizedBox(height: 10),
                      Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.military_tech_rounded, size: 14, color: AppColors.primary),
                            const SizedBox(width: 4),
                            Text('Lv.${_profile!.level} · ${_profile!.exp} EXP',
                                style: const TextStyle(color: AppColors.primary, fontSize: 12.5, fontWeight: FontWeight.w700)),
                            if (_profile!.clanTag?.isNotEmpty == true) ...[
                              const SizedBox(width: 10),
                              const Icon(Icons.shield_rounded, size: 14, color: AppColors.textMuted),
                              const SizedBox(width: 3),
                              Text('[${_profile!.clanTag}]',
                                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                            ],
                          ],
                        ),
                      ),
                      if (_profile!.bio?.isNotEmpty == true) ...[
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: AppColors.bgCard,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Text(_profile!.bio!,
                              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.4)),
                        ),
                      ],
                      if (!isSelf) ...[
                        const SizedBox(height: 20),
                        const Text('Kirim Permintaan Affinity',
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                        const SizedBox(height: 10),
                        Row(
                          children: _affinityOptions.map((o) {
                            return Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: OutlinedButton(
                                  onPressed: _sendingRequest ? null : () => _sendAffinity(o.key),
                                  style: OutlinedButton.styleFrom(
                                    side: BorderSide(color: o.color.withValues(alpha: 0.4)),
                                    padding: const EdgeInsets.symmetric(vertical: 10),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(o.icon, size: 18, color: o.color),
                                      const SizedBox(height: 4),
                                      Text(o.label, style: TextStyle(fontSize: 10.5, color: o.color)),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ],
                  ),
                ),
    );
  }
}
