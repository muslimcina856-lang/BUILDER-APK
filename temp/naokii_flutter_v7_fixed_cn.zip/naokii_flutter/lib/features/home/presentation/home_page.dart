
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/comic.dart';
import '../../../data/repositories/comic_repository.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/section_header.dart';
import '../../../shared/widgets/skeleton.dart';

final _homeComicsProvider = FutureProvider<List<Comic>>((ref) {
  return ComicRepository().listComics(max: 24);
});

final _latestComicsProvider = FutureProvider<List<Comic>>((ref) {
  return ComicRepository().listLatest(max: 18);
});

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;
    final comicsAsync = ref.watch(_homeComicsProvider);
    final latestAsync = ref.watch(_latestComicsProvider);

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async {
            ref.invalidate(_homeComicsProvider);
            ref.invalidate(_latestComicsProvider);
          },
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              const SliverToBoxAdapter(child: _Greeting()),
              SliverToBoxAdapter(
                child: GestureDetector(
                  onTap: () => context.go('/discover'),
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.search_rounded, color: AppColors.textMuted, size: 20),
                        SizedBox(width: 10),
                        Text('Cari manhwa, manga…',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 14)),
                      ],
                    ),
                  ),
                ),
              ),
              const 
SliverToBoxAdapter(child: _AnnounceStrip()),
              const SliverToBoxAdapter(child: _QuickRow()),
              // Carousel popular dengan cover
              comicsAsync.when(
                data: (list) {
                  final withCover = list.where((c) => (c.cover ?? '').isNotEmpty).take(10).toList();
                  if (withCover.isEmpty) return const 
SliverToBoxAdapter(child: SizedBox.shrink());
                  return SliverToBoxAdapter(child: _CoverCarousel(comics: withCover));
                },
                loading: () => const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: ShimmerBox(width: double.infinity, height: 168, radius: 18),
                  ),
                ),
                error: (_, __) => const SliverToBoxAdapter(child: SizedBox.shrink()),
              ),
              const SliverToBoxAdapter(
                child: SectionHeader(title: 'Populer', icon: Icons.local_fire_department_rounded),
              ),
              comicsAsync.when(
                data: (list) => _ComicGrid(comics: list),
                loading: () => const ComicGridSkeletonSliver(),
                error: (e, _) => SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Gagal memuat: $e',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.textMuted)),
                  ),
                ),
              ),
              const SliverToBoxAdapter(
                child: SectionHeader(title: 'Update terbaru', icon: Icons.new_releases_rounded),
              ),
              latestAsync.when(
                data: (list) => _ComicGrid(comics: list),
                loading: () => const ComicGridSkeletonSliver(itemCount: 6),
                error: (_, __) => const SliverToBoxAdapter(child: SizedBox.shrink()),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 28)),
            ],
          ),
        ),
      ),
    );
  }
}

class _Greeting extends ConsumerWidget {
  const _Greeting();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;
    final hour = DateTime.now().hour;
    final hello = hour < 11
        ? 'Selamat pagi'
        : hour < 15
            ? 'Selamat siang'
            : hour < 18
                ? 'Selamat sore'
                : 'Selamat malam';
    final name = user?.displayName?.split(' ').first;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(hello, style: const TextStyle(color: AppColors.textMuted, fontSize: 13, fontWeight: FontWeight.w600)),
          ShaderMask(
            shaderCallback: (rect) => AppGradients.vibrant.createShader(rect),
            child: Text(
              name != null && name.isNotEmpty ? name : 'Naokii Comic',
              style: const TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.4,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickRow extends StatelessWidget {
  const _QuickRow();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
      child: Row(
        children: [
          Expanded(
            child: _QuickCard(
              icon: Icons.forum_rounded,
              title: 'Global Chat',
              subtitle: 'Ngobrol bareng',
              onTap: () => context.go('/chat'),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _QuickCard(
              icon: Icons.menu_book_rounded,
              title: 'Novel',
              subtitle: 'Baca cerita',
              onTap: () => context.go('/novel'),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  const _QuickCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    // Warna sama (primary) untuk Chat & Novel
    return Material(
      color: AppColors.bgCard,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.accentSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: AppColors.primary, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                    Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CoverCarousel extends StatefulWidget {
  const _CoverCarousel({required this.comics});
  final List<Comic> comics;
  @override
  State<_CoverCarousel> createState() => _CoverCarouselState();
}

class _CoverCarouselState extends State<_CoverCarousel> {
  final _ctrl = PageController(viewportFraction: 0.88);
  int _page = 0;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 168,
          child: PageView.builder(
            controller: _ctrl,
            itemCount: widget.comics.length,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (_, i) {
              final c = widget.comics[i];
              return GestureDetector(
                onTap: () => context.push('/comic/${c.slug}'),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.border),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      CachedNetworkImage(
                        imageUrl: c.cover!,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => Container(color: AppColors.bgElevated),
                      ),
                      Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, Colors.black87],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 14,
                        right: 14,
                        bottom: 12,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: Colors.black54,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(c.type, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.white)),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              c.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.comics.length.clamp(0, 10), (i) {
            final on = i == _page;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: on ? 16 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: on ? AppColors.primary : AppColors.border,
                borderRadius: BorderRadius.circular(4),
              ),
            );
          }),
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}

class _ComicGrid extends StatelessWidget {
  const _ComicGrid({required this.comics});
  final List<Comic> comics;

  @override
  Widget build(BuildContext context) {
    if (comics.isEmpty) {
      return const SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('Belum ada judul.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textMuted)),
        ),
      );
    }
    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          mainAxisSpacing: 10,
          crossAxisSpacing: 8,
          childAspectRatio: 0.5,
        ),
        delegate: SliverChildBuilderDelegate(
          (_, i) {
            final c = comics[i];
            return GestureDetector(
              onTap: () => context.push('/comic/${c.slug}'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: c.cover != null && c.cover!.isNotEmpty
                          ? CachedNetworkImage(
                              imageUrl: c.cover!,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              errorWidget: (_, __, ___) => Container(
                                color: AppColors.bgElevated,
                                child: const Icon(Icons.menu_book_rounded, color: AppColors.textMuted),
                              ),
                            )
                          : Container(
                              color: AppColors.bgElevated,
                              child: const Icon(Icons.menu_book_rounded, color: AppColors.textMuted),
                            ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(c.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, height: 1.2)),
                ],
              ),
            );
          },
          childCount: comics.length,
        ),
      ),
    );
  }
}

class _AnnounceStrip extends StatelessWidget {
  const _AnnounceStrip();
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: SocialRepository().listenAnnouncements(max: 1),
      builder: (context, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty) return const SizedBox.shrink();
        final d = snap.data!.docs.first.data();
        final title = d['title'] as String? ?? 'Pengumuman';
        final body = d['body'] as String? ?? '';
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.bgCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.campaign_rounded, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5))),
                ]),
                if (body.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(body, maxLines: 3, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary)),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
