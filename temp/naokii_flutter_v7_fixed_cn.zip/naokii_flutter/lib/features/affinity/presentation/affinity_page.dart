import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

const _slots = [
  (key: 'pasangan', label: 'Pasangan', icon: Icons.favorite_rounded, color: AppColors.pink),
  (key: 'sahabat', label: 'Sahabat', icon: Icons.diversity_1_rounded, color: AppColors.cyan),
  (key: 'teman', label: 'Teman', icon: Icons.groups_rounded, color: AppColors.violet),
];

class AffinityPage extends ConsumerWidget {
  const AffinityPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(title: const Text('Affinity')),
      body: user == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.diversity_3_rounded, size: 48, color: AppColors.textMuted),
                    const SizedBox(height: 12),
                    const Text('Login dulu untuk pakai fitur affinity.',
                        style: TextStyle(color: AppColors.textMuted), textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    ElevatedButton(onPressed: () => context.push('/login'), child: const Text('Masuk')),
                  ],
                ),
              ),
            )
          : StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
              builder: (context, profSnap) {
                final data = profSnap.data?.data() ?? {};
                final activeAffinity = (data['activeAffinity'] as Map?) ?? {};

                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    const Text(
                      'Hubungkan ikatanmu dengan pengguna lain. Terima permintaan dari orang lain, '
                      'atau kirim permintaan lewat halaman profil publik mereka.',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                    ),
                    const SizedBox(height: 18),
                    ..._slots.map((slot) {
                      final active = activeAffinity[slot.key] as Map?;
                      return _SlotCard(
                        label: slot.label,
                        icon: slot.icon,
                        color: slot.color,
                        partnerUid: active?['partnerUid'] as String?,
                        onEnd: active == null
                            ? null
                            : () => SocialRepository()
                                .endAffinity(user.uid, active['partnerUid'] as String, slot.key),
                      );
                    }),
                    const SizedBox(height: 24),
                    const Text('Permintaan Masuk',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: SocialRepository().listenIncomingAffinityRequests(user.uid),
                      builder: (context, snap) {
                        final docs = snap.data?.docs ?? [];
                        if (!snap.hasData) {
                          return const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        if (docs.isEmpty) {
                          return const Text('Tidak ada permintaan masuk.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13));
                        }
                        return Column(
                          children: docs.map((d) {
                            final r = d.data();
                            final fromUid = r['fromUid'] as String;
                            final type = r['type'] as String;
                            final slot = _slots.firstWhere((s) => s.key == type,
                                orElse: () => _slots.last);
                            return FutureBuilder(
                              future: UserRepository().getProfile(fromUid),
                              builder: (context, userSnap) {
                                final p = userSnap.data;
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppColors.bgCard,
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: AppColors.border),
                                  ),
                                  child: Row(
                                    children: [
                                      AvatarBorder(photoUrl: p?.photoUrl, size: 40, baseBorderId: p?.borderId),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(p?.name ?? 'Pengguna',
                                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                                            Row(
                                              children: [
                                                Icon(slot.icon, size: 12, color: slot.color),
                                                const SizedBox(width: 4),
                                                Text('Ingin jadi ${slot.label.toLowerCase()}',
                                                    style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.check_circle_rounded, color: AppColors.success),
                                        onPressed: () {
                                          HapticFeedback.mediumImpact();
                                          SocialRepository().respondAffinityRequest(
                                            d.id, true, fromUid: fromUid, toUid: user.uid, type: type,
                                          );
                                        },
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.cancel_rounded, color: AppColors.danger),
                                        onPressed: () {
                                          HapticFeedback.selectionClick();
                                          SocialRepository().respondAffinityRequest(
                                              d.id, false, fromUid: fromUid, toUid: user.uid, type: type);
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          }).toList(),
                        );
                      },
                    ),
                  ],
                );
              },
            ),
    );
  }
}

class _SlotCard extends StatelessWidget {
  const _SlotCard({
    required this.label,
    required this.icon,
    required this.color,
    required this.partnerUid,
    required this.onEnd,
  });
  final String label;
  final IconData icon;
  final Color color;
  final String? partnerUid;
  final VoidCallback? onEnd;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.15), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                if (partnerUid != null)
                  FutureBuilder(
                    future: UserRepository().getProfile(partnerUid!),
                    builder: (context, snap) => Text(
                      snap.data?.name ?? '...',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  )
                else
                  const Text('Belum terhubung', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
          if (onEnd != null)
            TextButton(
              onPressed: onEnd,
              child: const Text('Putuskan', style: TextStyle(color: AppColors.danger, fontSize: 12)),
            ),
        ],
      ),
    );
  }
}
