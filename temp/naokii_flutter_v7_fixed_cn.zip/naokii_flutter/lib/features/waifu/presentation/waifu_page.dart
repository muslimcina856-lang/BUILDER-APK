
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';

class WaifuPage extends ConsumerWidget {
  const WaifuPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).valueOrNull;
    return Scaffold(
      appBar: AppBar(title: const Text('Top Waifu')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: SocialRepository().listenWaifus(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('Belum ada kandidat waifu.', style: TextStyle(color: AppColors.textMuted)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data();
              final img = d['image'] as String?;
              return Card(
                child: ListTile(
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 48, height: 48,
                      child: img != null
                          ? CachedNetworkImage(imageUrl: img, fit: BoxFit.cover)
                          : Container(color: AppColors.bgElevated, child: const Icon(Icons.favorite)),
                    ),
                  ),
                  title: Text(d['name'] as String? ?? '?', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Row(
                    children: [
                      Flexible(
                        child: Text('${d['series'] ?? ''}',
                            overflow: TextOverflow.ellipsis),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.favorite_rounded, size: 12, color: AppColors.pink),
                      const SizedBox(width: 2),
                      Text('${d['voteCount'] ?? 0}'),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.how_to_vote_rounded, color: AppColors.primary),
                    onPressed: () async {
                      if (user == null) {
                        context.push('/login');
                        return;
                      }
                      await SocialRepository().toggleWaifuVote(docs[i].id, user.uid);
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
