import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/user_profile.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/storage_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

/// Admin panel — role/title/EXP/ban management. Access is gated by both the
/// UI (owner/admin role check) and Firestore security rules server-side.
class AdminPage extends ConsumerStatefulWidget {
  const AdminPage({super.key});
  @override
  ConsumerState<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends ConsumerState<AdminPage> with SingleTickerProviderStateMixin {
  final _searchCtrl = TextEditingController();
  List<UserProfile> _results = [];
  bool _searching = false;
  UserProfile? _me;
  late final _tabCtrl = TabController(length: 2, vsync: this);

  @override
  void initState() {
    super.initState();
    _loadMe();
  }

  Future<void> _loadMe() async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) return;
    final p = await UserRepository().getProfile(user.uid);
    if (mounted) setState(() => _me = p);
  }

  Future<void> _search(String q) async {
    setState(() => _searching = true);
    final docs = await SocialRepository().searchUsersByName(q);
    setState(() {
      _results = docs.map((d) => UserProfile.fromMap(d.id, d.data())).toList();
      _searching = false;
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_me != null && !_me!.isAdmin) {
      return Scaffold(
        appBar: AppBar(title: const Text('Admin Panel')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.block_rounded, size: 48, color: AppColors.danger),
                SizedBox(height: 12),
                Text('Akses ditolak — halaman ini khusus Owner/Admin.',
                    textAlign: TextAlign.center, style: TextStyle(color: AppColors.textMuted)),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          tabs: const [
            Tab(icon: Icon(Icons.people_alt_rounded), text: 'Pengguna'),
            Tab(icon: Icon(Icons.storefront_rounded), text: 'Border Shop'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    filled: false,
                    border: InputBorder.none,
                    hintText: 'Cari nama pengguna...',
                    prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textMuted),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.arrow_forward_rounded, color: AppColors.primary),
                      onPressed: () => _search(_searchCtrl.text),
                    ),
                  ),
                  onSubmitted: _search,
                ),
              ),
              const SizedBox(height: 16),
              if (_searching) const Center(child: CircularProgressIndicator()),
              ..._results.map((u) => _UserAdminTile(user: u, canManageRole: _me?.isOwner ?? false)),
            ],
          ),
          _BorderShopManager(canManage: _me?.isAdmin ?? false),
        ],
      ),
    );
  }
}

class _UserAdminTile extends StatefulWidget {
  const _UserAdminTile({required this.user, required this.canManageRole});
  final UserProfile user;
  final bool canManageRole;

  @override
  State<_UserAdminTile> createState() => _UserAdminTileState();
}

class _UserAdminTileState extends State<_UserAdminTile> {
  bool _busy = false;
  late String _role = widget.user.role;

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
      HapticFeedback.mediumImpact();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Berhasil diperbarui.')));
      }
    } catch (e) {
      HapticFeedback.heavyImpact();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _promptText(String title, Future<void> Function(String) onSubmit) async {
    final ctrl = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        title: Text(title),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Simpan')),
        ],
      ),
    );
    if (value != null && value.trim().isNotEmpty) {
      await _run(() => onSubmit(value.trim()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.user;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AvatarBorder(photoUrl: u.photoUrl, size: 40, verified: u.verified),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(u.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                    Text('Lv.${u.level} · ${u.exp} EXP · $_role',
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                  ],
                ),
              ),
              if (_busy)
                const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (widget.canManageRole)
                _ActionChip(
                  icon: Icons.admin_panel_settings_rounded,
                  label: 'Ubah Role',
                  onTap: _busy
                      ? null
                      : () => showModalBottomSheet(
                            context: context,
                            backgroundColor: AppColors.bgCard,
                            builder: (ctx) => SafeArea(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: ['owner', 'admin', 'premium', 'user']
                                    .map((r) => ListTile(
                                          leading: Icon(
                                            r == _role ? Icons.radio_button_checked : Icons.radio_button_off,
                                            color: AppColors.primary,
                                          ),
                                          title: Text(r),
                                          onTap: () {
                                            Navigator.pop(ctx);
                                            _run(() => SocialRepository().adminSetRole(u.uid, r));
                                            setState(() => _role = r);
                                          },
                                        ))
                                    .toList(),
                              ),
                            ),
                          ),
              ),
              _ActionChip(
                icon: Icons.military_tech_rounded,
                label: 'Set Title',
                onTap: _busy
                    ? null
                    : () => _promptText('Custom Title', (v) => SocialRepository().adminSetTitle(u.uid, v)),
              ),
              _ActionChip(
                icon: Icons.bolt_rounded,
                label: 'Set EXP',
                onTap: _busy
                    ? null
                    : () => _promptText(
                          'Set EXP (angka)',
                          (v) => SocialRepository().adminSetLevelExp(u.uid, int.tryParse(v) ?? u.exp),
                        ),
              ),
              _ActionChip(
                icon: Icons.block_rounded,
                label: 'Ban / Unban',
                color: AppColors.danger,
                onTap: _busy
                    ? null
                    : () => _run(() => SocialRepository().adminBanUser(u.uid, true)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.icon, required this.label, required this.onTap, this.color});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primary;
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: c.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: c.withValues(alpha: 0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 13, color: c),
            const SizedBox(width: 5),
            Text(label, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: c)),
          ],
        ),
      ),
    );
  }
}

/// Upload & manage purchasable border frames. Images are expected to
/// already be transparent PNG rings (same as web's uploaded frame assets) —
/// there's no reliable on-device background-removal in Flutter without a
/// heavy ML model bundled into the app, so the practical flow is: prepare
/// the PNG with transparency beforehand (Photoshop/remove.bg/etc.), then
/// upload it here. A crop-to-square step is included since that's the part
/// that's genuinely useful to do on-device.
class _BorderShopManager extends StatefulWidget {
  const _BorderShopManager({required this.canManage});
  final bool canManage;

  @override
  State<_BorderShopManager> createState() => _BorderShopManagerState();
}

class _BorderShopManagerState extends State<_BorderShopManager> {
  File? _picked;
  final _nameCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  String _rarity = 'Rare';
  bool _uploading = false;

  static const _rarities = ['Rare', 'Epic', 'Mythical', 'S', 'SS', 'SSS', 'LastBoss'];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (file != null) {
      HapticFeedback.selectionClick();
      setState(() => _picked = File(file.path));
    }
  }

  Future<void> _upload() async {
    if (_picked == null || _nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Pilih gambar dan isi nama dulu.')));
      return;
    }
    setState(() => _uploading = true);
    try {
      final id = SocialRepository().newBorderItemId();
      final url = await StorageRepository().uploadBorderImage(_picked!, id);
      await SocialRepository().createBorderItem(
        id: id,
        name: _nameCtrl.text.trim(),
        rarity: _rarity,
        price: int.tryParse(_priceCtrl.text.trim()) ?? 0,
        imageUrl: url,
      );
      HapticFeedback.mediumImpact();
      if (mounted) {
        setState(() {
          _picked = null;
          _nameCtrl.clear();
          _priceCtrl.clear();
        });
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Border berhasil diunggah.')));
      }
    } catch (e) {
      HapticFeedback.heavyImpact();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (widget.canManage) ...[
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Unggah Border Baru',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                const SizedBox(height: 4),
                const Text(
                  'Gunakan PNG transparan (ring/frame) — sama seperti asset di web. '
                  'Belum ada penghapus background otomatis di app, siapkan gambarnya dulu.',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 11.5),
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    height: 110,
                    width: 110,
                    decoration: BoxDecoration(
                      color: AppColors.bgElevated,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border, style: BorderStyle.solid),
                    ),
                    child: _picked == null
                        ? const Icon(Icons.add_photo_alternate_rounded,
                            color: AppColors.textMuted, size: 30)
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.file(_picked!, fit: BoxFit.contain),
                          ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameCtrl,
                  decoration: const InputDecoration(hintText: 'Nama border'),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _rarity,
                        items: _rarities
                            .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                            .toList(),
                        onChanged: (v) => setState(() => _rarity = v ?? _rarity),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _priceCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(hintText: 'Harga (coin)'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _uploading ? null : _upload,
                    icon: _uploading
                        ? const SizedBox(
                            width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.cloud_upload_rounded, size: 18),
                    label: Text(_uploading ? 'Mengunggah...' : 'Unggah'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
        const Text('Border Terpasang', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
        const SizedBox(height: 10),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: SocialRepository().listenBorderItems(),
          builder: (context, snap) {
            final docs = snap.data?.docs ?? [];
            if (!snap.hasData) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            if (docs.isEmpty) {
              return const Text('Belum ada border.', style: TextStyle(color: AppColors.textMuted, fontSize: 13));
            }
            return Column(
              children: docs.map((d) {
                final data = d.data();
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      AvatarBorder(photoUrl: null, size: 40, frameImageUrl: data['imageUrl'] as String?),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(data['name'] as String? ?? '?',
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                            Text('${data['rarity']} · ${data['price']} coin',
                                style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                          ],
                        ),
                      ),
                      if (widget.canManage)
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger, size: 20),
                          onPressed: () => SocialRepository().deleteBorderItem(d.id),
                        ),
                    ],
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}
