
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';

String? _hiResGoogleAvatar(String? url) {
  if (url == null || url.isEmpty) return null;
  // Google photos often come as s96 — bump resolution
  return url
      .replaceAll('=s96-c', '=s256-c')
      .replaceAll('s96-c', 's256-c')
      .replaceAll('/s96/', '/s256/');
}

class GlobalChatPage extends ConsumerStatefulWidget {
  const GlobalChatPage({super.key});

  @override
  ConsumerState<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends ConsumerState<GlobalChatPage> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  bool _sending = false;

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      if (mounted) context.push('/login');
      return;
    }
    final text = _ctrl.text.trim();
    if (text.isEmpty || text.length > 300) return;
    setState(() => _sending = true);
    try {
      // Ambil profil Firestore biar nama & foto konsisten dengan web
      final profile = await UserRepository().getProfile(user.uid);
      final name = (profile?.name.isNotEmpty == true)
          ? profile!.name
          : (user.displayName?.trim().isNotEmpty == true
              ? user.displayName!.trim()
              : 'Pembaca');
      final avatar = _hiResGoogleAvatar(
            profile?.photoUrl ?? user.photoURL,
          ) ??
          '';

      await FirebaseFirestore.instance.collection('globalChat').add({
        // Field sama persis dengan web (GlobalChatWidget / sendGlobalChatMessage)
        'uid': user.uid,
        'name': name,
        'avatar': avatar,
        'text': text,
        'equippedBorder': profile?.borderId ?? '',
        'clanTag': profile?.clanTag ?? '',
        'verified': profile?.verified ?? false,
        'verifiedRole': null,
        'mediaUrl': '',
        'mediaType': '',
        'createdAt': FieldValue.serverTimestamp(),
      });
      _ctrl.clear();
      if (_scroll.hasClients) {
        await Future<void>.delayed(const Duration(milliseconds: 80));
        _scroll.animateTo(
          _scroll.position.maxScrollExtent + 80,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal kirim: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  const Icon(Icons.forum_rounded, color: AppColors.primary, size: 22),
                  const SizedBox(width: 8),
                  const Text(
                    'Global Chat',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.success.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle, size: 8, color: AppColors.success),
                        SizedBox(width: 6),
                        Text('Live', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.success)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: FirebaseFirestore.instance
                    .collection('globalChat')
                    .orderBy('createdAt', descending: true)
                    .limit(80)
                    .snapshots(),
                builder: (context, snap) {
                  if (snap.hasError) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(
                          'Chat error: ${snap.error}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: AppColors.textMuted),
                        ),
                      ),
                    );
                  }
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator(color: AppColors.primary));
                  }
                  final docs = snap.data!.docs.reversed.toList();
                  if (docs.isEmpty) {
                    return const Center(
                      child: Text('Belum ada pesan.\nJadilah yang pertama!',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textMuted)),
                    );
                  }
                  return ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                    itemCount: docs.length,
                    itemBuilder: (_, i) {
                      final d = docs[i].data();
                      // Web: name/avatar — Flutter lama: displayName/photoURL
                      final name = (d['name'] as String?)?.trim().isNotEmpty == true
                          ? d['name'] as String
                          : (d['displayName'] as String?)?.trim().isNotEmpty == true
                              ? d['displayName'] as String
                              : 'Pembaca';
                      final avatar = (d['avatar'] as String?)?.isNotEmpty == true
                          ? d['avatar'] as String
                          : (d['photoURL'] as String? ?? '');
                      final text = d['text'] as String? ?? '';
                      final isMe = user != null && d['uid'] == user.uid;
                      final tag = d['clanTag'] as String? ?? '';
                      final borderId = d['equippedBorder'] as String? ?? '';
                      final verified = d['verified'] == true;
                      final senderUid = d['uid'] as String? ?? '';
                      return _Bubble(
                        name: name,
                        avatar: avatar,
                        text: text,
                        isMe: isMe,
                        clanTag: tag,
                        borderId: borderId,
                        verified: verified,
                        onTapAvatar: senderUid.isEmpty ? null : () => context.push('/u/$senderUid'),
                      );
                    },
                  );
                },
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
              decoration: BoxDecoration(
                color: AppColors.bgSurface,
                border: Border(top: BorderSide(color: AppColors.borderStrong.withValues(alpha: 0.45))),
              ),
              child: user == null
                  ? SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => context.push('/login'),
                        icon: const Icon(Icons.login_rounded),
                        label: const Text('Login untuk chat'),
                      ),
                    )
                  : Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _ctrl,
                            maxLength: 300,
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) => _send(),
                            decoration: const InputDecoration(
                              hintText: 'Ketik pesan…',
                              counterText: '',
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          onPressed: _sending ? null : _send,
                          style: IconButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                          ),
                          icon: _sending
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                              : const Icon(Icons.send_rounded),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({
    required this.name,
    required this.avatar,
    required this.text,
    required this.isMe,
    this.clanTag = '',
    this.borderId = '',
    this.verified = false,
    this.onTapAvatar,
  });

  final String name;
  final String avatar;
  final String text;
  final bool isMe;
  final String clanTag;
  final String borderId;
  final bool verified;
  final VoidCallback? onTapAvatar;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isMe) ...[
            AvatarBorder(
              photoUrl: avatar.isEmpty ? null : avatar,
              size: 32,
              baseBorderId: borderId,
              verified: verified,
              onTap: onTapAvatar,
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (clanTag.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(
                          color: AppColors.accentSoft,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(clanTag, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.primary)),
                      ),
                    Text(
                      name,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: isMe ? AppColors.primary : AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  decoration: BoxDecoration(
                    color: isMe ? AppColors.primary.withValues(alpha: 0.2) : AppColors.bgCard,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(14),
                      topRight: const Radius.circular(14),
                      bottomLeft: Radius.circular(isMe ? 14 : 4),
                      bottomRight: Radius.circular(isMe ? 4 : 14),
                    ),
                    border: Border.all(color: isMe ? AppColors.primary.withValues(alpha: 0.35) : AppColors.border),
                  ),
                  child: Text(text, style: const TextStyle(fontSize: 14, height: 1.35)),
                ),
              ],
            ),
          ),
          if (isMe) ...[
            const SizedBox(width: 8),
            AvatarBorder(
              photoUrl: avatar.isEmpty ? null : avatar,
              size: 32,
              baseBorderId: borderId,
              verified: verified,
            ),
          ],
        ],
      ),
    );
  }
}
