import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/comic.dart';
import '../../../data/repositories/comic_repository.dart';
import '../../../data/repositories/library_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../comments/presentation/comment_section.dart';

final _comicBySlugProvider =
    FutureProvider.family<Comic?, String>((ref, slug) {
  return ComicRepository().getBySlug(slug);
});

final _chaptersProvider =
    FutureProvider.family<List<Chapter>, String>((ref, comicId) {
  return ComicRepository().listChapters(comicId);
});

class ComicDetailPage extends ConsumerWidget {
  const ComicDetailPage({super.key, required this.slug});
  final String slug;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final comicAsync = ref.watch(_comicBySlugProvider(slug));

    return Scaffold(
      body: comicAsync.when(
        loading: () => const Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (comic) {
          if (comic == null) {
            return const Center(child: Text('Komik tidak ditemukan'));
          }
          return _DetailBody(comic: comic);
        },
      ),
    );
  }
}

class _DetailBody extends ConsumerWidget {
  const _DetailBody({required this.comic});
  final Comic comic;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chaptersAsync = ref.watch(_chaptersProvider(comic.id));

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverAppBar(
          expandedHeight: 280,
          pinned: true,
          backgroundColor: AppColors.bgPrimary,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => context.pop(),
            style: IconButton.styleFrom(backgroundColor: Colors.black45),
          ),
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(
              fit: StackFit.expand,
              children: [
                if (comic.cover != null)
                  CachedNetworkImage(
                    imageUrl: comic.cover!,
                    fit: BoxFit.cover,
                    color: Colors.black.withValues(alpha: 0.45),
                    colorBlendMode: BlendMode.darken,
                  )
                else
                  Container(color: AppColors.bgElevated),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: comic.cover != null
                          ? CachedNetworkImage(
                              imageUrl: comic.cover!,
                              width: 130,
                              height: 185,
                              fit: BoxFit.cover,
                            )
                          : Container(
                              width: 130,
                              height: 185,
                              color: AppColors.bgCard,
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Column(
              children: [
                Text(
                  comic.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                ),
                if (comic.author != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    comic.author!,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 13,
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  alignment: WrapAlignment.center,
                  children: [
                    _Badge(
                      comic.isOngoing ? 'Ongoing' : 'Tamat',
                      color: comic.isOngoing
                          ? AppColors.success
                          : AppColors.textMuted,
                    ),
                    _Badge(comic.type, color: AppColors.primary),
                    if (comic.rating > 0)
                      _Badge(comic.rating.toStringAsFixed(1),
                          color: AppColors.warning,
                          icon: Icons.star_rounded),
                  ],
                ),
                const SizedBox(height: 16),
                chaptersAsync.when(
                  data: (chs) {
                    if (chs.isEmpty) return const SizedBox.shrink();
                    final first = chs.first;
                    return Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => context.push(
                              '/read/${comic.id}/${first.id}',
                            ),
                            child: Text('Baca Chapter ${first.number}'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              final user = ref.read(authServiceProvider).currentUser;
                              if (user == null) {
                                context.push('/login');
                                return;
                              }
                              await LibraryRepository().addBookmark(
                                user.uid,
                                comicId: comic.id,
                                title: comic.title,
                                cover: comic.cover,
                                slug: comic.slug,
                                type: comic.type,
                              );
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Ditambahkan ke Library')),
                                );
                              }
                            },
                            icon: const Icon(Icons.bookmark_add_outlined),
                            label: const Text('Bookmark'),
                          ),
                        ),
                      ],
                    );
                  },
                  loading: () => const SizedBox.shrink(),
                  error: (_, __) => const SizedBox.shrink(),
                ),
                if (comic.genres.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    alignment: WrapAlignment.center,
                    children: comic.genres
                        .map(
                          (g) => Chip(
                            label: Text(g),
                            visualDensity: VisualDensity.compact,
                          ),
                        )
                        .toList(),
                  ),
                ],
                if (comic.synopsis?.isNotEmpty == true) ...[
                  const SizedBox(height: 20),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Sinopsis',
                      style:
                          TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    comic.synopsis!,
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13.5,
                      height: 1.55,
                    ),
                  ),
                ],
                const SizedBox(height: 24),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Daftar Chapter',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
        chaptersAsync.when(
          loading: () => const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              ),
            ),
          ),
          error: (e, _) => SliverToBoxAdapter(child: Text('$e')),
          data: (chapters) {
            if (chapters.isEmpty) {
              return const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'Chapter belum tersedia',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textMuted),
                  ),
                ),
              );
            }
            return SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) {
                  final ch = chapters[chapters.length - 1 - i]; // newest first
                  return ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                    title: Text(
                      ch.displayTitle,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    subtitle: ch.uploadedBy != null
                        ? Text(
                            'by ${ch.uploadedBy}',
                            style: const TextStyle(fontSize: 12),
                          )
                        : null,
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () =>
                        context.push('/read/${comic.id}/${ch.id}'),
                  );
                },
                childCount: chapters.length,
              ),
            );
          },
        ),
        SliverToBoxAdapter(child: CommentSection(comicId: comic.id)),
        const SliverToBoxAdapter(child: SizedBox(height: 32)),
      ],
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge(this.label, {required this.color, this.icon});
  final String label;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
