import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/comic.dart';
import '../../../data/repositories/comic_repository.dart';
import '../../../shared/widgets/comic_card.dart';
import '../../../shared/widgets/skeleton.dart';

final _discoverProvider = FutureProvider.family<List<Comic>, String?>((ref, type) {
  final repo = ComicRepository();
  if (type == null || type == 'Semua') return repo.listComics(max: 40);
  return repo.listByType(type, max: 40);
});

class DiscoverPage extends ConsumerStatefulWidget {
  const DiscoverPage({super.key});

  @override
  ConsumerState<DiscoverPage> createState() => _DiscoverPageState();
}

class _DiscoverPageState extends ConsumerState<DiscoverPage> {
  String _type = 'Semua';
  final _searchCtrl = TextEditingController();
  List<Comic>? _searchResults;
  bool _searching = false;
  Timer? _debounce;

  static const _types = ['Semua', 'Manhwa', 'Manga', 'Manhua', 'Comic'];

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onQueryChanged(String v) {
    _debounce?.cancel();
    if (v.trim().length < 2) {
      setState(() => _searchResults = null);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () => _runSearch(v));
  }

  Future<void> _runSearch(String q) async {
    if (q.trim().length < 2) {
      setState(() => _searchResults = null);
      return;
    }
    setState(() => _searching = true);
    final r = await ComicRepository().search(q);
    if (mounted) {
      setState(() {
        _searchResults = r;
        _searching = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(_discoverProvider(_type == 'Semua' ? null : _type));
    final list = _searchResults ?? async.valueOrNull ?? [];

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                controller: _searchCtrl,
                onChanged: _onQueryChanged,
                decoration: InputDecoration(
                  hintText: 'Cari judul…',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() => _searchResults = null);
                          },
                        )
                      : null,
                ),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: _types.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final t = _types[i];
                  final active = t == _type;
                  return FilterChip(
                    label: Text(t),
                    selected: active,
                    onSelected: (_) {
                      HapticFeedback.selectionClick();
                      setState(() {
                        _type = t;
                        _searchResults = null;
                        _searchCtrl.clear();
                      });
                    },
                    selectedColor: AppColors.primary,
                    checkmarkColor: Colors.white,
                    labelStyle: TextStyle(
                      color: active ? Colors.white : AppColors.textSecondary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.5,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _searching
                  ? const ComicGridSkeleton(itemCount: 9, crossAxisCount: 3, aspectRatio: 0.5)
                  : async.isLoading && _searchResults == null
                      ? const ComicGridSkeleton(itemCount: 9, crossAxisCount: 3, aspectRatio: 0.5)
                      : list.isEmpty
                          ? const Center(
                              child: Text(
                                'Tidak ada hasil',
                                style: TextStyle(color: AppColors.textMuted),
                              ),
                            )
                          : GridView.builder(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                              physics: const BouncingScrollPhysics(),
                              itemCount: list.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 10,
                                childAspectRatio: 0.5,
                              ),
                              itemBuilder: (_, i) =>
                                  ComicGridCard(comic: list[i]),
                            ),
            ),
          ],
        ),
      ),
    );
  }
}
