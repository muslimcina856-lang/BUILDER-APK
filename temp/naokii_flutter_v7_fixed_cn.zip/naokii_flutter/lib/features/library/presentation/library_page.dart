import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/library_repository.dart';
import '../../../data/services/auth_service.dart';

class LibraryPage extends ConsumerStatefulWidget {
  const LibraryPage({super.key});

  @override
  ConsumerState<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends ConsumerState<LibraryPage> {
  int _tab = 0; // 0 bookmark 1 history

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).valueOrNull;

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text('Library',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _chip('Bookmark', 0),
                  const SizedBox(width: 8),
                  _chip('Lanjut baca', 1),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: user == null
                  ? _loginGate(context)
                  : _tab == 0
                      ? _Bookmarks(uid: user.uid)
                      : _History(uid: user.uid),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, int i) {
    final active = _tab == i;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? AppColors.primary : AppColors.bgCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? AppColors.primary : AppColors.border),
          ),
          alignment: Alignment.center,
          child: Text(label,
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: active ? Colors.white : AppColors.textSecondary)),
        ),
      ),
    );
  }

  Widget _loginGate(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.bookmark_border_rounded, size: 48, color: AppColors.primary),
          const SizedBox(height: 12),
          const Text('Login untuk simpan koleksi', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () => context.push('/login'), child: const Text('Masuk')),
        ],
      ),
    );
  }
}

class _Bookmarks extends StatelessWidget {
  const _Bookmarks({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: LibraryRepository().listenBookmarks(uid),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator(color: AppColors.primary));
        }
        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          return const Center(
            child: Text('Belum ada bookmark.\nTambah dari halaman detail.',
                textAlign: TextAlign.center, style: TextStyle(color: AppColors.textMuted)),
          );
        }
        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4, mainAxisSpacing: 10, crossAxisSpacing: 8, childAspectRatio: 0.5,
          ),
          itemCount: docs.length,
          itemBuilder: (_, i) {
            final d = docs[i].data();
            final slug = d['slug'] as String? ?? d['comicId'] as String? ?? '';
            final title = d['title'] as String? ?? '';
            final cover = d['cover'] as String?;
            return GestureDetector(
              onTap: () => context.push('/comic/$slug'),
              onLongPress: () async {
                await LibraryRepository().removeBookmark(uid, docs[i].id);
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: cover != null && cover.isNotEmpty
                          ? CachedNetworkImage(imageUrl: cover, fit: BoxFit.cover, width: double.infinity)
                          : Container(color: AppColors.bgElevated, child: const Icon(Icons.menu_book)),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _History extends StatelessWidget {
  const _History({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: LibraryRepository().listenLastReads(uid),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator(color: AppColors.primary));
        }
        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          return const Center(
            child: Text('Belum ada riwayat baca.', style: TextStyle(color: AppColors.textMuted)),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) {
            final d = docs[i].data();
            final slug = d['comicSlug'] as String? ?? d['comicId'] as String? ?? '';
            final title = d['comicTitle'] as String? ?? 'Komik';
            final cover = d['cover'] as String?;
            final ch = d['chapterNumber'];
            final chapterId = d['chapterId'] as String? ?? '';
            final comicId = d['comicId'] as String? ?? '';
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: const BorderSide(color: AppColors.border),
              ),
              tileColor: AppColors.bgCard,
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 44, height: 58,
                  child: cover != null && cover.isNotEmpty
                      ? CachedNetworkImage(imageUrl: cover, fit: BoxFit.cover)
                      : Container(color: AppColors.bgElevated),
                ),
              ),
              title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              subtitle: Text('Ch. $ch', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
              trailing: const Icon(Icons.play_arrow_rounded, color: AppColors.primary),
              onTap: () {
                if (comicId.isNotEmpty && chapterId.isNotEmpty) {
                  context.push('/read/$comicId/$chapterId');
                } else {
                  context.push('/comic/$slug');
                }
              },
            );
          },
        );
      },
    );
  }
}
