import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';

class NovelReaderPage extends StatefulWidget {
  const NovelReaderPage({
    super.key,
    required this.novelId,
    required this.chapterId,
  });

  final String novelId;
  final String chapterId;

  @override
  State<NovelReaderPage> createState() => _NovelReaderPageState();
}

class _NovelReaderPageState extends State<NovelReaderPage> {
  double _fontSize = 16;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.pop(),
        ),
        title: const Text('Baca Novel'),
        actions: [
          IconButton(
            icon: const Icon(Icons.text_decrease_rounded),
            onPressed: () =>
                setState(() => _fontSize = (_fontSize - 1).clamp(12, 28)),
          ),
          IconButton(
            icon: const Icon(Icons.text_increase_rounded),
            onPressed: () =>
                setState(() => _fontSize = (_fontSize + 1).clamp(12, 28)),
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance
            .collection('novels')
            .doc(widget.novelId)
            .collection('chapters')
            .doc(widget.chapterId)
            .get(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            );
          }
          if (!snap.hasData || !snap.data!.exists) {
            return const Center(child: Text('Chapter tidak ditemukan'));
          }
          final data = snap.data!.data()!;
          final title = data['title'] as String? ?? 'Chapter';
          final body = data['content'] as String? ?? data['text'] as String? ?? '';
          final paragraphs = body
              .split(RegExp(r'\n\s*\n'))
              .map((p) => p.trim())
              .where((p) => p.isNotEmpty)
              .toList();

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 48),
            physics: const BouncingScrollPhysics(),
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  height: 1.3,
                ),
              ),
              const SizedBox(height: 20),
              ...paragraphs.map(
                (p) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Text(
                    p,
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: _fontSize,
                      height: 1.65,
                      color: AppColors.textMain,
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
