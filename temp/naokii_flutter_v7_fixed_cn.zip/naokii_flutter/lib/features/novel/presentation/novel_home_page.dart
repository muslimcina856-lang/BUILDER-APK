
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';

class NovelHomePage extends StatelessWidget {
  const NovelHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Novel'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.go('/'),
        ),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('novels')
            .limit(40)
            .snapshots(),
        builder: (context, snap) {
          if (snap.hasError) {
            final msg = snap.error.toString();
            final denied = msg.contains('permission-denied') ||
                msg.contains('PERMISSION_DENIED');
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      denied ? Icons.lock_outline_rounded : Icons.error_outline,
                      size: 40,
                      color: AppColors.textMuted,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      denied
                          ? 'Novel belum bisa dibaca dari app.\n'
                              'Deploy firestore.rules yang memuat match /novels '
                              '(allow read: if true) lewat Firebase CLI / Console.'
                          : 'Gagal memuat novel.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                    if (!denied) ...[
                      const SizedBox(height: 8),
                      Text(msg,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 11, color: AppColors.textMuted)),
                    ],
                  ],
                ),
              ),
            );
          }
          if (!snap.hasData) {
            return const Center(
                child: CircularProgressIndicator(color: AppColors.primary));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                'Belum ada novel.\nUpload lewat admin panel web.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              final title = d['title'] as String? ?? 'Untitled';
              final cover = d['cover'] as String?;
              final author = d['author'] as String? ?? '';
              return ListTile(
                tileColor: AppColors.bgCard,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: const BorderSide(color: AppColors.border),
                ),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox(
                    width: 44,
                    height: 58,
                    child: cover != null && cover.isNotEmpty
                        ? CachedNetworkImage(imageUrl: cover, fit: BoxFit.cover)
                        : Container(
                            color: AppColors.bgElevated,
                            child: const Icon(Icons.menu_book_rounded),
                          ),
                  ),
                ),
                title: Text(title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: author.isEmpty
                    ? null
                    : Text(author,
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textMuted)),
                onTap: () => context.push('/novel/$id/ch/first'),
              );
            },
          );
        },
      ),
    );
  }
}
