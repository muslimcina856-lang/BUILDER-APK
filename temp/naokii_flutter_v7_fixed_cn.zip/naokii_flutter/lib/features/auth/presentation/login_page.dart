import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/auth_service.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  bool _loading = false;

  String _friendlyError(Object e) {
    final s = e.toString();
    if (s.contains('ApiException: 10') || s.contains('sign_in_failed')) {
      return 'Google Sign-In gagal (kode 10).\n'
          'Tambahkan SHA-1 keystore APK ke Firebase Console → '
          'Project settings → Android app (com.naokii.comic), '
          'lalu unduh ulang google-services.json dan rebuild.';
    }
    if (s.contains('network') || s.contains('NETWORK')) {
      return 'Jaringan bermasalah. Coba lagi.';
    }
    if (s.contains('canceled') || s.contains('cancelled')) {
      return 'Login dibatalkan.\n'
          'Kalau ini kejadian terus tiap login (bukan kamu yang nutup '
          'pilihan akun), kemungkinan besar SHA-1 app ini belum '
          'terdaftar di Firebase — cek SETUP_GOOGLE_SIGNIN.md.';
    }
    return 'Login gagal: $e';
  }

  Future<void> _google() async {
    setState(() => _loading = true);
    try {
      final cred = await ref.read(authServiceProvider).signInWithGoogle();
      if (cred != null && mounted) {
        context.go('/');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_friendlyError(e)),
            duration: const Duration(seconds: 8),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  onPressed: () => context.pop(),
                  icon: const Icon(Icons.close_rounded),
                ),
              ),
              const Spacer(),
              const Icon(Icons.menu_book_rounded, size: 56, color: AppColors.primary),
              const SizedBox(height: 12),
              const Text(
                'Naokii Comic',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Masuk untuk bookmark, chat, dan progress baca.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted, fontSize: 14),
              ),
              const SizedBox(height: 36),
              ElevatedButton.icon(
                onPressed: _loading ? null : _google,
                icon: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.login_rounded, size: 22),
                label: Text(_loading ? 'Memproses…' : 'Lanjut dengan Google'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
              const Spacer(flex: 2),
              TextButton(
                onPressed: () => context.go('/'),
                child: const Text(
                  'Lewati dulu',
                  style: TextStyle(color: AppColors.textMuted),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
