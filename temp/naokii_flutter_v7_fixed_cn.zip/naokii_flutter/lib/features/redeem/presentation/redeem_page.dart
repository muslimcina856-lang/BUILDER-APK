
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/services/auth_service.dart';

class RedeemPage extends ConsumerStatefulWidget {
  const RedeemPage({super.key});
  @override
  ConsumerState<RedeemPage> createState() => _RedeemPageState();
}

class _RedeemPageState extends ConsumerState<RedeemPage> {
  final _ctrl = TextEditingController();
  bool _loading = false;

  Future<void> _go() async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      context.push('/login');
      return;
    }
    setState(() => _loading = true);
    try {
      final exp = await SocialRepository().redeemCode(user.uid, _ctrl.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(exp > 0 ? 'Berhasil! +$exp EXP' : 'Kode berhasil dipakai.')),
        );
        _ctrl.clear();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Redeem Code')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Icon(Icons.card_giftcard_rounded, size: 48, color: AppColors.warning),
            const SizedBox(height: 12),
            const Text('Masukkan kode hadiah', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            TextField(
              controller: _ctrl,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(hintText: 'KODE'),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : _go,
                child: Text(_loading ? '…' : 'Tukar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
