import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/models/user_profile.dart';
import '../../../data/repositories/social_repository.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/services/auth_service.dart';
import '../../../shared/widgets/avatar_border.dart';
import '../../../shared/widgets/skeleton.dart';

const _baseBorders = [
  (id: 'border-glow-blue', name: 'Azure Pulse', rarity: 'Common', desc: 'Cincin biru berdenyut pelan — signature Naokii.'),
  (id: 'border-frost', name: 'Frost', rarity: 'Common', desc: 'Kilau dingin es, tenang dan bersih.'),
  (id: 'border-minimal', name: 'Minimal Ring', rarity: 'Common', desc: 'Cincin tipis polos, clean look.'),
  (id: 'border-gold-shimmer', name: 'Gold Shimmer', rarity: 'Rare', desc: 'Gradasi emas bergerak lembut.'),
  (id: 'border-fire', name: 'Blaze', rarity: 'Rare', desc: 'Gradasi api oranye-merah menyala.'),
  (id: 'border-rainbow', name: 'Prism', rarity: 'Epic', desc: 'Cincin warna-warni berputar penuh.'),
];

const _rarityColor = {
  'Common': AppColors.textMuted,
  'Rare': Color(0xFF0A84FF),
  'Epic': Color(0xFF8B5CF6),
  'Mythical': Color(0xFF5E5CE6),
  'S': Color(0xFF30D158),
  'SS': Color(0xFFFF9F0A),
  'SSS': Color(0xFFFF453A),
  'LastBoss': Color(0xFFFF2D78),
};

class ShopPage extends ConsumerStatefulWidget {
  const ShopPage({super.key});
  @override
  ConsumerState<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends ConsumerState<ShopPage> {
  UserProfile? _profile;
  Set<String> _purchased = {};
  String _busy = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      setState(() => _loading = false);
      return;
    }
    final profile = await UserRepository().getProfile(user.uid);
    final purchased = await SocialRepository().listPurchasedBorders(user.uid);
    if (mounted) {
      setState(() {
        _profile = profile;
        _purchased = purchased;
        _loading = false;
      });
    }
  }

  Future<void> _equip(String borderId) async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) return;
    HapticFeedback.selectionClick();
    setState(() => _busy = borderId);
    final next = _profile?.borderId == borderId ? null : borderId;
    await SocialRepository().equipBorder(user.uid, next ?? '');
    setState(() {
      _profile = _profile?.copyWith(borderId: next ?? '');
      _busy = '';
    });
  }

  Future<void> _purchase(String itemId, int price) async {
    final user = ref.read(authServiceProvider).currentUser;
    if (user == null) {
      context.push('/login');
      return;
    }
    setState(() => _busy = itemId);
    try {
      await SocialRepository().purchaseBorderItem(user.uid, itemId);
      HapticFeedback.mediumImpact();
      setState(() {
        _purchased = {..._purchased, itemId};
        _profile = _profile?.copyWith(coins: (_profile?.coins ?? 0) - price);
      });
    } catch (e) {
      HapticFeedback.heavyImpact();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = '');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).valueOrNull;
    final coins = _profile?.coins ?? 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Shop Border')),
      body: _loading
          ? const _ShopSkeleton()
          : RefreshIndicator(
              color: AppColors.primary,
              onRefresh: _load,
              child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              children: [
                const Text(
                  'Hiasi avatar profilmu dengan efek border. Koleksi dasar gratis — '
                  'border spesial bisa dibeli pakai coin (didapat otomatis tiap kamu dapat EXP).',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 14),
                if (user != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.bgCard,
                      border: Border.all(color: AppColors.border),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.monetization_on_rounded, size: 16, color: AppColors.warning),
                        const SizedBox(width: 6),
                        Text('$coins', style: const TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(width: 4),
                        const Text('coin', style: TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
                      ],
                    ),
                  )
                else
                  const Text('Login dulu untuk bisa pasang border di profilmu.',
                      style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                const SizedBox(height: 22),
                const _SectionLabel('Koleksi Dasar (Gratis)'),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _baseBorders.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 12,
                    childAspectRatio: 0.78,
                  ),
                  itemBuilder: (_, i) {
                    final b = _baseBorders[i];
                    final equipped = _profile?.borderId == b.id;
                    return _BorderTile(
                      name: b.name,
                      rarity: b.rarity,
                      equipped: equipped,
                      busy: _busy == b.id,
                      preview: AvatarBorder(photoUrl: _profile?.photoUrl, size: 56, baseBorderId: b.id),
                      actionLabel: equipped ? 'Terpasang' : 'Pasang',
                      onTap: user == null ? () => context.push('/login') : () => _equip(b.id),
                    );
                  },
                ),
                const SizedBox(height: 26),
                const _SectionLabel('Border Spesial'),
                const SizedBox(height: 10),
                StreamBuilder(
                  stream: SocialRepository().listenBorderItems(),
                  builder: (context, snap) {
                    final docs = snap.data?.docs ?? [];
                    if (!snap.hasData) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    if (docs.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Text('Belum ada border spesial.',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                      );
                    }
                    return GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: docs.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 12,
                        childAspectRatio: 0.78,
                      ),
                      itemBuilder: (_, i) {
                        final d = docs[i];
                        final data = d.data();
                        final id = d.id;
                        final name = data['name'] as String? ?? '?';
                        final rarity = data['rarity'] as String? ?? 'Rare';
                        final price = (data['price'] as num?)?.toInt() ?? 0;
                        final imageUrl = data['imageUrl'] as String?;
                        final owned = _purchased.contains(id);
                        final equipped = _profile?.borderId == id;
                        return _BorderTile(
                          name: name,
                          rarity: rarity,
                          equipped: equipped,
                          busy: _busy == id,
                          preview: AvatarBorder(photoUrl: _profile?.photoUrl, size: 56, frameImageUrl: imageUrl),
                          actionLabel: equipped ? 'Terpasang' : (owned ? 'Pasang' : '$price coin'),
                          actionIcon: owned || equipped ? null : Icons.monetization_on_rounded,
                          onTap: user == null
                              ? () => context.push('/login')
                              : owned
                                  ? () => _equip(id)
                                  : () => _purchase(id, price),
                        );
                      },
                    );
                  },
                ),
              ],
              ),
            ),
    );
  }
}

class _ShopSkeleton extends StatelessWidget {
  const _ShopSkeleton();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
      children: const [
        ShimmerBox(width: 140, height: 14, radius: 4),
        SizedBox(height: 16),
        ComicGridSkeleton(itemCount: 6),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) =>
      Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800));
}

class _BorderTile extends StatelessWidget {
  const _BorderTile({
    required this.name,
    required this.rarity,
    required this.equipped,
    required this.busy,
    required this.preview,
    required this.actionLabel,
    required this.onTap,
    this.actionIcon,
  });

  final String name;
  final String rarity;
  final bool equipped;
  final bool busy;
  final Widget preview;
  final String actionLabel;
  final IconData? actionIcon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = _rarityColor[rarity] ?? AppColors.textMuted;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: equipped ? AppColors.primary : AppColors.border),
      ),
      child: Column(
        children: [
          preview,
          const SizedBox(height: 8),
          Text(name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
          Text(rarity, style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: color)),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            height: 30,
            child: OutlinedButton(
              onPressed: busy ? null : onTap,
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.zero,
                side: BorderSide(color: equipped ? AppColors.primary : AppColors.border),
                foregroundColor: equipped ? AppColors.primary : AppColors.textSecondary,
              ),
              child: busy
                  ? const SizedBox(
                      width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2))
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (actionIcon != null) ...[
                          Icon(actionIcon, size: 11, color: AppColors.warning),
                          const SizedBox(width: 3),
                        ],
                        Text(actionLabel, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800)),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
