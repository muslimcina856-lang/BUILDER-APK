import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_theme.dart';
import '../../data/models/comic.dart';

class ComicCard extends StatelessWidget {
  const ComicCard({
    super.key,
    required this.comic,
    this.width = 116,
  });

  final Comic comic;
  final double width;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/comic/${comic.slug}'),
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 3 / 4,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.md),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    _Cover(url: comic.cover),
                    // bottom scrim so title reads if cover ever overlaps
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      height: 34,
                      child: DecoratedBox(
                        decoration: BoxDecoration(gradient: AppGradients.coverScrim(opacity: 0.55)),
                      ),
                    ),
                    if (comic.isOngoing)
                      Positioned(
                        top: 6,
                        left: 6,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2.5),
                          decoration: BoxDecoration(
                            gradient: AppGradients.vibrant,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            'ON',
                            style: TextStyle(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ),
                      ),
                    if (comic.rating > 0)
                      Positioned(
                        top: 6,
                        right: 6,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5.5, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.65),
                            borderRadius: BorderRadius.circular(7),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.star_rounded, size: 11, color: AppColors.warning),
                              const SizedBox(width: 2),
                              Text(
                                comic.rating.toStringAsFixed(1),
                                style: const TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.warning,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              comic.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                height: 1.2,
                letterSpacing: -0.1,
              ),
            ),
            if (comic.chapterCount > 0) ...[
              const SizedBox(height: 1),
              Text(
                'Ch. ${comic.latestChapter > 0 ? comic.latestChapter : comic.chapterCount}',
                style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted, fontWeight: FontWeight.w600),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class ComicGridCard extends StatelessWidget {
  const ComicGridCard({super.key, required this.comic});

  final Comic comic;

  @override
  Widget build(BuildContext context) {
    return ComicCard(comic: comic, width: double.infinity);
  }
}

class _Cover extends StatelessWidget {
  const _Cover({this.url});
  final String? url;

  @override
  Widget build(BuildContext context) {
    if (url == null || url!.isEmpty) {
      return Container(
        color: AppColors.bgElevated,
        child: const Center(
          child: Icon(Icons.menu_book_rounded, color: AppColors.textDim, size: 32),
        ),
      );
    }
    return CachedNetworkImage(
      imageUrl: url!,
      fit: BoxFit.cover,
      placeholder: (_, __) => Container(color: AppColors.bgElevated),
      errorWidget: (_, __, ___) => Container(
        color: AppColors.bgElevated,
        child: const Icon(Icons.broken_image_outlined, color: AppColors.textDim),
      ),
    );
  }
}
