import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../core/theme/app_theme.dart';

/// A single shimmering placeholder block — replaces spinners on feed-style
/// content so the app feels like it's already loading the layout, not just
/// "thinking" (native iOS/Android pattern rather than a web spinner).
class ShimmerBox extends StatelessWidget {
  const ShimmerBox({super.key, this.width, this.height, this.radius = 10});
  final double? width;
  final double? height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.bgElevated,
      highlightColor: AppColors.bgCard,
      period: const Duration(milliseconds: 1200),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
    );
  }
}

/// Skeleton for a 3-column comic grid, mirrors [ComicCard] proportions.
class ComicGridSkeleton extends StatelessWidget {
  const ComicGridSkeleton({
    super.key,
    this.itemCount = 12,
    this.crossAxisCount = 4,
    this.aspectRatio = 0.5,
  });
  final int itemCount;
  final int crossAxisCount;
  final double aspectRatio;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: itemCount,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 10,
        crossAxisSpacing: 8,
        childAspectRatio: aspectRatio,
      ),
      itemBuilder: (_, __) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: ShimmerBox(width: double.infinity, radius: 12)),
          const SizedBox(height: 6),
          const ShimmerBox(width: double.infinity, height: 11, radius: 4),
          const SizedBox(height: 4),
          const ShimmerBox(width: 60, height: 11, radius: 4),
        ],
      ),
    );
  }
}

/// Sliver-friendly wrapper so it can drop straight into a CustomScrollView.
class ComicGridSkeletonSliver extends StatelessWidget {
  const ComicGridSkeletonSliver({super.key, this.itemCount = 9});
  final int itemCount;

  @override
  Widget build(BuildContext context) => SliverToBoxAdapter(
        child: ComicGridSkeleton(itemCount: itemCount),
      );
}

/// Skeleton for list-style rows (notifications, chat, search results).
class ListRowSkeleton extends StatelessWidget {
  const ListRowSkeleton({super.key, this.itemCount = 6});
  final int itemCount;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: itemCount,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, __) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            const ShimmerBox(width: 38, height: 38, radius: 12),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  ShimmerBox(width: 140, height: 12, radius: 4),
                  SizedBox(height: 6),
                  ShimmerBox(width: 90, height: 10, radius: 4),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
