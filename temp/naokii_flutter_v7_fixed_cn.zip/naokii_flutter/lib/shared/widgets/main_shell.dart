import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_theme.dart';

/// Bottom navigation shell — UI khusus APK (bukan copy web).
class MainShell extends StatelessWidget {
  const MainShell({super.key, required this.child});

  final Widget child;

  static const _tabs = [
    _Tab(path: '/', label: 'Home', icon: Icons.home_rounded),
    _Tab(path: '/discover', label: 'Jelajah', icon: Icons.explore_rounded),
    _Tab(path: '/library', label: 'Library', icon: Icons.bookmark_rounded),
    _Tab(path: '/chat', label: 'Chat', icon: Icons.chat_bubble_rounded),
    _Tab(path: '/profile', label: 'Profil', icon: Icons.person_rounded),
  ];

  int _indexFor(String location) {
    if (location.startsWith('/discover') || location.startsWith('/comic')) {
      return 1;
    }
    if (location.startsWith('/library') || location.startsWith('/novel')) {
      return 2;
    }
    if (location.startsWith('/chat')) return 3;
    if (location.startsWith('/profile') || location.startsWith('/u/')) {
      return 4;
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.toString();
    final index = _indexFor(location);

    return Scaffold(
      body: child,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xF2000000),
          border: Border(top: BorderSide(color: AppColors.borderStrong.withValues(alpha: 0.5))),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x8C000000),
              blurRadius: 24,
              offset: Offset(0, -8),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
            child: Row(
              children: List.generate(_tabs.length, (i) {
                final tab = _tabs[i];
                final active = i == index;
                return Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () {
                      if (!active) {
                        HapticFeedback.selectionClick();
                        context.go(tab.path);
                      }
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          width: 46,
                          height: 30,
                          decoration: BoxDecoration(
                            gradient: active ? AppGradients.vibrant : null,
                            borderRadius: BorderRadius.circular(999),
                            boxShadow: active
                                ? [
                                    BoxShadow(
                                      color: AppColors.accentStart.withValues(alpha: 0.45),
                                      blurRadius: 14,
                                      offset: const Offset(0, 3),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Icon(
                            tab.icon,
                            size: 21,
                            color: active ? Colors.white : AppColors.textMuted,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          tab.label,
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                            color: active ? AppColors.textMain : AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _Tab {
  const _Tab({required this.path, required this.label, required this.icon});
  final String path;
  final String label;
  final IconData icon;
}
