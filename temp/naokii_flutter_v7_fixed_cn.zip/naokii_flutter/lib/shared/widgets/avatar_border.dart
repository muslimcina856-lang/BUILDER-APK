import 'dart:math' as math;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

/// Base (free) border styles — drawn entirely with code (gradients/paint),
/// mirroring the CSS-only rings on web. No image assets, no emoji.
enum BaseBorderStyle { none, azurePulse, frost, minimal, goldShimmer, blaze, prism }

BaseBorderStyle baseBorderFromId(String? id) {
  switch (id) {
    case 'border-glow-blue':
      return BaseBorderStyle.azurePulse;
    case 'border-frost':
      return BaseBorderStyle.frost;
    case 'border-minimal':
      return BaseBorderStyle.minimal;
    case 'border-gold-shimmer':
      return BaseBorderStyle.goldShimmer;
    case 'border-fire':
      return BaseBorderStyle.blaze;
    case 'border-rainbow':
      return BaseBorderStyle.prism;
    default:
      return BaseBorderStyle.none;
  }
}

/// Renders a user avatar with their equipped border (either a code-drawn
/// base style, or a purchased frame image overlay) plus an optional
/// verified badge — all vector/icon based, never emoji glyphs.
class AvatarBorder extends StatefulWidget {
  const AvatarBorder({
    super.key,
    required this.photoUrl,
    this.size = 56,
    this.baseBorderId,
    this.frameImageUrl,
    this.verified = false,
    this.onTap,
  });

  final String? photoUrl;
  final double size;

  /// e.g. "border-glow-blue" for free CSS-equivalent styles.
  final String? baseBorderId;

  /// Purchased/uploaded frame PNG (rendered on top of the avatar), takes
  /// priority over [baseBorderId] when present.
  final String? frameImageUrl;

  final bool verified;
  final VoidCallback? onTap;

  @override
  State<AvatarBorder> createState() => _AvatarBorderState();
}

class _AvatarBorderState extends State<AvatarBorder>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 4),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final style = baseBorderFromId(widget.baseBorderId);
    final ringPad = widget.size * 0.12;

    Widget avatar = ClipOval(
      child: widget.photoUrl != null && widget.photoUrl!.isNotEmpty
          ? CachedNetworkImage(
              imageUrl: widget.photoUrl!,
              fit: BoxFit.cover,
              placeholder: (_, __) => Container(color: AppColors.bgElevated),
              errorWidget: (_, __, ___) => _fallbackAvatar(),
            )
          : _fallbackAvatar(),
    );

    Widget content = SizedBox(
      width: widget.size,
      height: widget.size,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          if (widget.frameImageUrl == null && style != BaseBorderStyle.none)
            AnimatedBuilder(
              animation: _controller,
              builder: (_, __) => CustomPaint(
                size: Size(widget.size, widget.size),
                painter: _BorderRingPainter(
                  style: style,
                  progress: _controller.value,
                ),
              ),
            ),
          Padding(
            padding: EdgeInsets.all(
              widget.frameImageUrl == null && style != BaseBorderStyle.none
                  ? ringPad * 0.6
                  : 0,
            ),
            child: SizedBox(
              width: widget.size - (style != BaseBorderStyle.none ? ringPad * 1.2 : 0),
              height: widget.size - (style != BaseBorderStyle.none ? ringPad * 1.2 : 0),
              child: avatar,
            ),
          ),
          if (widget.frameImageUrl != null)
            Positioned.fill(
              child: CachedNetworkImage(
                imageUrl: widget.frameImageUrl!,
                fit: BoxFit.contain,
                errorWidget: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          if (widget.verified)
            Positioned(
              right: -2,
              bottom: -2,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  color: AppColors.bgPrimary,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.verified_rounded,
                  size: widget.size * 0.26,
                  color: AppColors.primary,
                ),
              ),
            ),
        ],
      ),
    );

    if (widget.onTap != null) {
      content = GestureDetector(onTap: widget.onTap, child: content);
    }
    return content;
  }

  Widget _fallbackAvatar() => Container(
        color: AppColors.bgElevated,
        alignment: Alignment.center,
        child: Icon(Icons.person_rounded,
            size: widget.size * 0.5, color: AppColors.textMuted),
      );
}

class _BorderRingPainter extends CustomPainter {
  _BorderRingPainter({required this.style, required this.progress});
  final BaseBorderStyle style;
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2 - 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.07
      ..strokeCap = StrokeCap.round;

    switch (style) {
      case BaseBorderStyle.azurePulse:
        final pulse = 0.55 + 0.45 * (0.5 + 0.5 * math.sin(progress * 2 * math.pi));
        paint.color = AppColors.primary.withValues(alpha: pulse);
        paint.strokeWidth = size.width * (0.06 + 0.015 * pulse);
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.frost:
        paint.shader = const SweepGradient(
          colors: [Color(0xFFBAE6FD), Color(0xFF38BDF8), Color(0xFFBAE6FD)],
        ).createShader(rect);
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.minimal:
        paint.color = AppColors.textMuted.withValues(alpha: 0.8);
        paint.strokeWidth = size.width * 0.035;
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.goldShimmer:
        final angle = progress * 2 * math.pi;
        paint.shader = SweepGradient(
          transform: GradientRotation(angle),
          colors: const [
            Color(0xFFFDE68A),
            Color(0xFFF59E0B),
            Color(0xFFFDE68A),
            Color(0xFFB45309),
            Color(0xFFFDE68A),
          ],
        ).createShader(rect);
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.blaze:
        paint.shader = SweepGradient(
          startAngle: 0,
          endAngle: 2 * math.pi,
          transform: GradientRotation(progress * 2 * math.pi * 0.5),
          colors: const [
            Color(0xFFFDBA74),
            Color(0xFFEF4444),
            Color(0xFFF59E0B),
            Color(0xFFFDBA74),
          ],
        ).createShader(rect);
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.prism:
        paint.shader = SweepGradient(
          transform: GradientRotation(progress * 2 * math.pi),
          colors: const [
            Color(0xFFEF4444),
            Color(0xFFF59E0B),
            Color(0xFFEAB308),
            Color(0xFF22C55E),
            Color(0xFF3B82F6),
            Color(0xFF8B5CF6),
            Color(0xFFEF4444),
          ],
        ).createShader(rect);
        canvas.drawCircle(center, radius, paint);
        break;
      case BaseBorderStyle.none:
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _BorderRingPainter old) =>
      old.progress != progress || old.style != style;
}
