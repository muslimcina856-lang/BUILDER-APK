/// Web client ID dari Firebase Console.
///
/// Cara ambil (sekali saja):
/// 1. Firebase Console → Authentication → Sign-in method → Google
/// 2. Salin **Web client ID** (berakhiran .apps.googleusercontent.com)
/// 3. Tempel di bawah mengganti nilai default.
///
/// Atau: Google Cloud Console → APIs & Services → Credentials →
/// OAuth 2.0 Client IDs → tipe "Web client".
class GoogleConfig {
  /// WAJIB diisi untuk Google Sign-In di Android (google_sign_in 7.x)
  static const String serverClientId =
      '402217827316-jdcid934r297mqqa2kosi0ubdm8gd5rm.apps.googleusercontent.com';
}
