class AppConstants {
  static const appName = 'Naokii Comic';
  static const packageName = 'com.naokii.comic';

  /// Firebase project (shared with web)
  static const firebaseProjectId = 'ryychatroom';

  /// Cloudinary (public cloud name only — uploads via signed server if needed)
  static const cloudinaryCloudName = 'eetrxo5k';

  /// Pagination
  static const comicsPageSize = 24;
  static const chaptersPageSize = 50;

  /// Reader
  static const readerDefaultWidth = 1.0; // full bleed
  static const readerPreloadPages = 3;

  /// Chat
  static const chatMaxLength = 300;
  static const commentMaxLength = 1000;
}
