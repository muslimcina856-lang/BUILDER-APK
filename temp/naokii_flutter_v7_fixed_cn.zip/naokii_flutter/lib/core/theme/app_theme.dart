import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// True-black neutral base + a single vibrant gradient accent (magenta →
/// violet) — the "anime/webtoon" pop comes from that one accent glowing
/// against pure black/white, not from a rainbow of competing colors.
class AppColors {
  static const bgPrimary = Color(0xFF000000);
  static const bgSurface = Color(0xFF0C0C10);
  static const bgCard = Color(0xFF131318);
  static const bgElevated = Color(0xFF1B1B22);
  static const border = Color(0x14FFFFFF);
  static const borderStrong = Color(0xFF2A2A33);

  static const textMain = Color(0xFFFFFFFF);
  static const textSecondary = Color(0xFFC7C7D1);
  static const textMuted = Color(0xFF8B8B96);
  static const textDim = Color(0xFF57575F);

  // The one accent — used as a solid for UI chrome, and as a gradient
  // (accentStart → accentEnd) for hero moments (badges, active states,
  // rings, CTA glows).
  static const accentStart = Color(0xFFFF2D87); // hot magenta
  static const accentEnd = Color(0xFF8B5CF6); // electric violet
  static const primary = accentStart;
  static const primaryHover = Color(0xFFE0246F);
  static const accentSoft = Color(0x26FF2D87);
  static const primaryGlow = Color(0x40FF2D87);

  static const success = Color(0xFF2ECC71);
  static const warning = Color(0xFFFFC93C);
  static const danger = Color(0xFFFF3B5C);
  static const cyan = Color(0xFF2FD8DE);
  static const violet = accentEnd;
  static const pink = accentStart;
}

/// Gradient tokens for the vibrant "hero" moments — keep the neutral base
/// for structure, save the gradient for the handful of places that should
/// pop (rating badges, active nav, CTA buttons, avatar ring accents).
class AppGradients {
  static const vibrant = LinearGradient(
    colors: [AppColors.accentStart, AppColors.accentEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const vibrantSoft = LinearGradient(
    colors: [Color(0x40FF2D87), Color(0x408B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient coverScrim({double opacity = 0.9}) => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.transparent, Colors.black.withValues(alpha: opacity)],
        stops: const [0.5, 1.0],
      );
}

/// Shared spacing/radius scale so new screens stay consistent with the
/// system instead of picking arbitrary numbers per widget.
class AppRadius {
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 22.0;
  static const pill = 999.0;
}

class AppSpace {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 12.0;
  static const lg = 16.0;
  static const xl = 24.0;
  static const xxl = 32.0;
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bgPrimary,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.violet,
        surface: AppColors.bgSurface,
        error: AppColors.danger,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: AppColors.textMain,
        onError: Colors.white,
      ),
    );

    return base.copyWith(
      textTheme: GoogleFonts.interTextTheme(base.textTheme).apply(
        bodyColor: AppColors.textMain,
        displayColor: AppColors.textMain,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bgPrimary,
        elevation: 0,
        centerTitle: false,
        foregroundColor: AppColors.textMain,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: AppColors.textMain,
          letterSpacing: -0.3,
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
          side: const BorderSide(color: AppColors.border),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xE60A0D14),
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textMuted,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
        unselectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.bgCard,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: const BorderSide(color: AppColors.borderStrong, width: 0.8),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: const BorderSide(color: AppColors.borderStrong, width: 0.8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.4),
        ),
        hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 14),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.textSecondary,
          side: const BorderSide(color: AppColors.borderStrong),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.bgCard,
        selectedColor: AppColors.primary,
        labelStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
        side: const BorderSide(color: AppColors.border),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.pill)),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      ),
      dividerTheme: const DividerThemeData(color: AppColors.borderStrong, thickness: 0.6, space: 32),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.bgElevated,
        contentTextStyle: const TextStyle(color: AppColors.textMain),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
