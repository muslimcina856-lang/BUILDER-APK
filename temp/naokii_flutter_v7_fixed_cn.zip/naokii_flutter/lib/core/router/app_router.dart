import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/login_page.dart';
import '../../features/catalog/presentation/comic_detail_page.dart';
import '../../features/catalog/presentation/discover_page.dart';
import '../../features/chat/presentation/global_chat_page.dart';
import '../../features/home/presentation/home_page.dart';
import '../../features/library/presentation/library_page.dart';
import '../../features/novel/presentation/novel_home_page.dart';
import '../../features/novel/presentation/novel_reader_page.dart';
import '../../features/profile/presentation/profile_page.dart';
import '../../features/profile/presentation/public_profile_page.dart';
import '../../features/reader/presentation/reader_page.dart';
import '../../features/clans/presentation/clans_page.dart';
import '../../features/clans/presentation/clan_detail_page.dart';
import '../../features/waifu/presentation/waifu_page.dart';
import '../../features/redeem/presentation/redeem_page.dart';
import '../../features/shop/presentation/shop_page.dart';
import '../../features/notifications/presentation/notifications_page.dart';
import '../../features/affinity/presentation/affinity_page.dart';
import '../../features/admin/presentation/admin_page.dart';
import '../../shared/widgets/main_shell.dart';

final _rootKey = GlobalKey<NavigatorState>();
final _shellKey = GlobalKey<NavigatorState>();

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _rootKey,
    initialLocation: '/',
    routes: [
      // Auth (full screen, no bottom nav)
      GoRoute(
        path: '/login',
        builder: (_, __) => const LoginPage(),
      ),

      // Reader (full bleed, no chrome)
      GoRoute(
        path: '/read/:comicId/:chapterId',
        builder: (_, state) => ReaderPage(
          comicId: state.pathParameters['comicId']!,
          chapterId: state.pathParameters['chapterId']!,
        ),
      ),
      GoRoute(
        path: '/novel/read/:novelId/:chapterId',
        builder: (_, state) => NovelReaderPage(
          novelId: state.pathParameters['novelId']!,
          chapterId: state.pathParameters['chapterId']!,
        ),
      ),

      // Main shell with bottom nav
      ShellRoute(
        navigatorKey: _shellKey,
        builder: (_, __, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: '/',
            pageBuilder: (_, __) => const NoTransitionPage(child: HomePage()),
          ),
          GoRoute(
            path: '/discover',
            pageBuilder: (_, __) =>
                const NoTransitionPage(child: DiscoverPage()),
          ),
          GoRoute(
            path: '/library',
            pageBuilder: (_, __) =>
                const NoTransitionPage(child: LibraryPage()),
          ),
          GoRoute(
            path: '/chat',
            pageBuilder: (_, __) =>
                const NoTransitionPage(child: GlobalChatPage()),
          ),
          GoRoute(
            path: '/profile',
            pageBuilder: (_, __) =>
                const NoTransitionPage(child: ProfilePage()),
          ),
          GoRoute(
            path: '/novel',
            pageBuilder: (_, __) =>
                const NoTransitionPage(child: NovelHomePage()),
          ),
          GoRoute(
            path: '/comic/:slug',
            builder: (_, state) =>
                ComicDetailPage(slug: state.pathParameters['slug']!),
          ),

          GoRoute(
            path: '/clans',
            builder: (_, __) => const ClansPage(),
          ),
          GoRoute(
            path: '/clan/:id',
            builder: (_, state) => ClanDetailPage(clanId: state.pathParameters['id']!),
          ),
          GoRoute(
            path: '/waifu',
            builder: (_, __) => const WaifuPage(),
          ),
          GoRoute(
            path: '/redeem',
            builder: (_, __) => const RedeemPage(),
          ),
          GoRoute(
            path: '/shop',
            builder: (_, __) => const ShopPage(),
          ),
          GoRoute(
            path: '/notifications',
            builder: (_, __) => const NotificationsPage(),
          ),
          GoRoute(
            path: '/affinity',
            builder: (_, __) => const AffinityPage(),
          ),
          GoRoute(
            path: '/admin',
            builder: (_, __) => const AdminPage(),
          ),
          GoRoute(
            path: '/u/:uid',
            builder: (_, state) =>
                PublicProfilePage(uid: state.pathParameters['uid']!),
          ),
        ],
      ),
    ],
  );
});
