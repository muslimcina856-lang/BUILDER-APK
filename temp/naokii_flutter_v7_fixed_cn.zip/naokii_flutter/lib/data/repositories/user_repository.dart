import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_profile.dart';

class UserRepository {
  UserRepository({FirebaseFirestore? db}) : _db = db ?? FirebaseFirestore.instance;
  final FirebaseFirestore _db;

  Future<UserProfile?> getProfile(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    return UserProfile.fromMap(doc.id, doc.data()!);
  }

  Future<void> ensureProfile(String uid, {String? name, String? photoUrl}) async {
    final ref = _db.collection('users').doc(uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'displayName': name ?? 'Pembaca',
        'photoURL': photoUrl ?? '',
        'exp': 0,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    await _db.collection('users').doc(uid).set({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<List<UserProfile>> topByExp({int max = 20}) async {
    final snap = await _db.collection('users').orderBy('exp', descending: true).limit(max).get();
    return snap.docs.map((d) => UserProfile.fromMap(d.id, d.data())).toList();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> notifications(String uid, {int max = 30}) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .orderBy('createdAt', descending: true)
        .limit(max)
        .snapshots();
  }

  Future<void> markNotifRead(String uid, String id) async {
    await _db.collection('users').doc(uid).collection('notifications').doc(id).update({'read': true});
  }
}
