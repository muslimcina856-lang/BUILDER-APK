import 'package:cloud_firestore/cloud_firestore.dart';

/// Komentar, reaction chapter, pengumuman, waifu, redeem, clan, affinity.
class SocialRepository {
  SocialRepository({FirebaseFirestore? db}) : _db = db ?? FirebaseFirestore.instance;
  final FirebaseFirestore _db;

  // ---- Comments ----
  CollectionReference<Map<String, dynamic>> _comments(String comicId, String? chapterId) {
    if (chapterId != null && chapterId.isNotEmpty) {
      return _db.collection('comics').doc(comicId).collection('chapters').doc(chapterId).collection('comments');
    }
    return _db.collection('comics').doc(comicId).collection('comments');
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenComments(String comicId, {String? chapterId}) {
    return _comments(comicId, chapterId).orderBy('createdAt', descending: true).limit(80).snapshots();
  }

  Future<void> postComment({
    required String comicId,
    String? chapterId,
    required String uid,
    required String name,
    String? avatar,
    String? borderId,
    bool verified = false,
    required String text,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return;
    await _comments(comicId, chapterId).add({
      'uid': uid,
      'name': name,
      'avatar': avatar ?? '',
      'equippedBorder': borderId ?? '',
      'verified': verified,
      'text': clean,
      'upvotes': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> toggleCommentVote({
    required String comicId,
    String? chapterId,
    required String commentId,
    required String uid,
  }) async {
    final voteRef = _comments(comicId, chapterId).doc(commentId).collection('votes').doc(uid);
    final commentRef = _comments(comicId, chapterId).doc(commentId);
    await _db.runTransaction((tx) async {
      final v = await tx.get(voteRef);
      if (v.exists) {
        tx.delete(voteRef);
        tx.update(commentRef, {'upvotes': FieldValue.increment(-1)});
      } else {
        tx.set(voteRef, {'createdAt': FieldValue.serverTimestamp()});
        tx.update(commentRef, {'upvotes': FieldValue.increment(1)});
      }
    });
  }

  // ---- Chapter reactions (sticker-style keys) ----
  static const reactionKeys = ['like', 'funny', 'nice', 'sad', 'angry'];

  Future<Map<String, int>> getReactionCounts(String comicId, String chapterId) async {
    final meta = await _db
        .collection('comics')
        .doc(comicId)
        .collection('chapters')
        .doc(chapterId)
        .collection('meta')
        .doc('reactions')
        .get();
    final data = meta.data() ?? {};
    return {
      for (final k in reactionKeys) k: (data[k] as num?)?.toInt() ?? 0,
    };
  }

  Future<String?> getUserReaction(String comicId, String chapterId, String uid) async {
    final d = await _db
        .collection('comics')
        .doc(comicId)
        .collection('chapters')
        .doc(chapterId)
        .collection('userReactions')
        .doc(uid)
        .get();
    return d.data()?['type'] as String?;
  }

  Future<void> setReaction(String comicId, String chapterId, String uid, String type) async {
    final userRef = _db
        .collection('comics')
        .doc(comicId)
        .collection('chapters')
        .doc(chapterId)
        .collection('userReactions')
        .doc(uid);
    final metaRef = _db
        .collection('comics')
        .doc(comicId)
        .collection('chapters')
        .doc(chapterId)
        .collection('meta')
        .doc('reactions');

    await _db.runTransaction((tx) async {
      final prev = await tx.get(userRef);
      final prevType = prev.data()?['type'] as String?;
      if (prevType == type) {
        tx.delete(userRef);
        tx.set(metaRef, {type: FieldValue.increment(-1)}, SetOptions(merge: true));
        return;
      }
      if (prevType != null) {
        tx.set(metaRef, {prevType: FieldValue.increment(-1)}, SetOptions(merge: true));
      }
      tx.set(userRef, {'type': type, 'updatedAt': FieldValue.serverTimestamp()});
      tx.set(metaRef, {type: FieldValue.increment(1)}, SetOptions(merge: true));
    });
  }

  // ---- Announcements ----
  Stream<QuerySnapshot<Map<String, dynamic>>> listenAnnouncements({int max = 5}) {
    return _db.collection('announcements').orderBy('createdAt', descending: true).limit(max).snapshots();
  }

  // ---- Waifu poll ----
  Stream<QuerySnapshot<Map<String, dynamic>>> listenWaifus() {
    return _db.collection('waifus').orderBy('voteCount', descending: true).snapshots();
  }

  Future<void> toggleWaifuVote(String waifuId, String uid) async {
    final voteRef = _db.collection('waifus').doc(waifuId).collection('votes').doc(uid);
    final waifuRef = _db.collection('waifus').doc(waifuId);
    await _db.runTransaction((tx) async {
      final v = await tx.get(voteRef);
      if (v.exists) {
        tx.delete(voteRef);
        tx.update(waifuRef, {'voteCount': FieldValue.increment(-1)});
      } else {
        tx.set(voteRef, {'createdAt': FieldValue.serverTimestamp()});
        tx.update(waifuRef, {'voteCount': FieldValue.increment(1)});
      }
    });
  }

  // ---- Redeem ----
  Future<int> redeemCode(String uid, String raw) async {
    final code = raw.trim().toUpperCase();
    final codeRef = _db.collection('redeemCodes').doc(code);
    final redeemedRef = codeRef.collection('redeemedBy').doc(uid);
    return _db.runTransaction((tx) async {
      final snap = await tx.get(codeRef);
      if (!snap.exists) throw Exception('Kode tidak ditemukan.');
      final data = snap.data()!;
      if (data['active'] != true) throw Exception('Kode tidak aktif.');
      if ((data['usedCount'] as num? ?? 0) >= (data['maxUses'] as num? ?? 1)) {
        throw Exception('Kode sudah habis.');
      }
      final already = await tx.get(redeemedRef);
      if (already.exists) throw Exception('Kamu sudah pakai kode ini.');
      tx.set(redeemedRef, {'redeemedAt': FieldValue.serverTimestamp()});
      tx.update(codeRef, {'usedCount': FieldValue.increment(1)});
      return (data['rewardExp'] as num?)?.toInt() ?? 0;
    });
  }

  // ---- Clans ----
  Stream<QuerySnapshot<Map<String, dynamic>>> listenClans({int max = 40}) {
    return _db.collection('clans').orderBy('memberCount', descending: true).limit(max).snapshots();
  }

  Future<void> createClan({
    required String uid,
    required String name,
    required String tag,
  }) async {
    final ref = await _db.collection('clans').add({
      'name': name.trim(),
      'tag': tag.trim().toUpperCase().substring(0, tag.trim().length.clamp(0, 6)),
      'ownerUid': uid,
      'memberCount': 1,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await ref.collection('members').doc(uid).set({
      'role': 'owner',
      'joinedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> joinClan(String clanId, String uid) async {
    final clanRef = _db.collection('clans').doc(clanId);
    await clanRef.collection('members').doc(uid).set({
      'role': 'member',
      'joinedAt': FieldValue.serverTimestamp(),
    });
    await clanRef.update({'memberCount': FieldValue.increment(1)});
  }

  Future<void> leaveClan(String clanId, String uid) async {
    final clanRef = _db.collection('clans').doc(clanId);
    await clanRef.collection('members').doc(uid).delete();
    await clanRef.update({'memberCount': FieldValue.increment(-1)});
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> listenClan(String clanId) {
    return _db.collection('clans').doc(clanId).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenClanMembers(String clanId) {
    return _db.collection('clans').doc(clanId).collection('members').orderBy('joinedAt').snapshots();
  }

  // ---- Affinity ----
  static const affinityTypes = ['pasangan', 'sahabat', 'teman'];

  Future<void> requestAffinity(String fromUid, String toUid, String type) async {
    await _db.collection('affinityRequests').add({
      'fromUid': fromUid,
      'toUid': toUid,
      'type': type,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenIncomingAffinityRequests(String uid) {
    return _db
        .collection('affinityRequests')
        .where('toUid', isEqualTo: uid)
        .where('status', isEqualTo: 'pending')
        .snapshots();
  }

  Future<void> respondAffinityRequest(String requestId, bool accept, {
    required String fromUid,
    required String toUid,
    required String type,
  }) async {
    final reqRef = _db.collection('affinityRequests').doc(requestId);
    if (!accept) {
      await reqRef.update({'status': 'declined'});
      return;
    }
    final batch = _db.batch();
    batch.update(reqRef, {'status': 'accepted'});
    batch.update(_db.collection('users').doc(fromUid), {
      'activeAffinity.$type': {'partnerUid': toUid, 'since': FieldValue.serverTimestamp()},
    });
    batch.update(_db.collection('users').doc(toUid), {
      'activeAffinity.$type': {'partnerUid': fromUid, 'since': FieldValue.serverTimestamp()},
    });
    await batch.commit();
  }

  Future<void> endAffinity(String uid, String partnerUid, String type) async {
    final batch = _db.batch();
    batch.update(_db.collection('users').doc(uid), {'activeAffinity.$type': FieldValue.delete()});
    batch.update(_db.collection('users').doc(partnerUid), {'activeAffinity.$type': FieldValue.delete()});
    await batch.commit();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenAffinitiesFor(String uid) {
    return _db.collection('affinities').where('status', isEqualTo: 'accepted').snapshots();
  }

  // ---- Shop / borders ----
  String newBorderItemId() => _db.collection('borderItems').doc().id;

  Future<void> createBorderItem({
    required String id,
    required String name,
    required String rarity,
    required int price,
    required String imageUrl,
  }) async {
    await _db.collection('borderItems').doc(id).set({
      'name': name,
      'rarity': rarity,
      'price': price,
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteBorderItem(String itemId) async {
    await _db.collection('borderItems').doc(itemId).delete();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenBorderItems() {
    return _db.collection('borderItems').orderBy('price').snapshots();
  }

  Future<Set<String>> listPurchasedBorders(String uid) async {
    final snap = await _db.collection('users').doc(uid).collection('purchasedBorders').get();
    return snap.docs.map((d) => d.id).toSet();
  }

  Future<void> purchaseBorderItem(String uid, String itemId) async {
    final userRef = _db.collection('users').doc(uid);
    final itemRef = _db.collection('borderItems').doc(itemId);
    final purchaseRef = userRef.collection('purchasedBorders').doc(itemId);
    await _db.runTransaction((tx) async {
      final userSnap = await tx.get(userRef);
      final itemSnap = await tx.get(itemRef);
      if (!itemSnap.exists) throw Exception('Border tidak ditemukan.');
      final already = await tx.get(purchaseRef);
      if (already.exists) throw Exception('Border sudah kamu miliki.');
      final price = (itemSnap.data()?['price'] as num?)?.toInt() ?? 0;
      final coins = (userSnap.data()?['coins'] as num?)?.toInt() ?? 0;
      if (coins < price) throw Exception('Coin kamu tidak cukup.');
      tx.set(purchaseRef, {'purchasedAt': FieldValue.serverTimestamp()});
      tx.update(userRef, {'coins': FieldValue.increment(-price)});
    });
  }

  Future<void> equipBorder(String uid, String borderId) async {
    await _db.collection('users').doc(uid).update({'equippedBorder': borderId});
  }

  // ---- Notifications ----
  Stream<QuerySnapshot<Map<String, dynamic>>> listenNotifications(String uid, {int max = 50}) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .orderBy('createdAt', descending: true)
        .limit(max)
        .snapshots();
  }

  Future<void> markNotificationRead(String uid, String notifId) async {
    await _db
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .doc(notifId)
        .update({'read': true});
  }

  Future<void> markAllNotificationsRead(String uid) async {
    final snap = await _db
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .where('read', isEqualTo: false)
        .get();
    final batch = _db.batch();
    for (final d in snap.docs) {
      batch.update(d.reference, {'read': true});
    }
    await batch.commit();
  }

  // ---- Admin actions (owner/admin only — enforced by Firestore rules) ----
  Future<void> adminSetRole(String targetUid, String role) async {
    await _db.collection('users').doc(targetUid).update({'role': role});
  }

  Future<void> adminSetTitle(String targetUid, String title) async {
    await _db.collection('users').doc(targetUid).update({'customTitle': title});
  }

  Future<void> adminSetLevelExp(String targetUid, int exp) async {
    await _db.collection('users').doc(targetUid).update({'exp': exp});
  }

  Future<void> adminGrantTitle(String targetUid, String title) async {
    await _db.collection('users').doc(targetUid).update({'customTitle': title});
  }

  Future<void> adminBanUser(String targetUid, bool banned) async {
    await _db.collection('users').doc(targetUid).update({'banned': banned});
  }

  Future<List<QueryDocumentSnapshot<Map<String, dynamic>>>> searchUsersByName(String query) async {
    if (query.trim().isEmpty) return [];
    final snap = await _db
        .collection('users')
        .orderBy('displayName')
        .startAt([query])
        .endAt(['$query\uf8ff'])
        .limit(20)
        .get();
    return snap.docs;
  }
}
