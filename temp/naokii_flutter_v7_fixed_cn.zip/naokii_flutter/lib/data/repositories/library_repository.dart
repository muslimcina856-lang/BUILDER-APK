import 'package:cloud_firestore/cloud_firestore.dart';

class LibraryRepository {
  LibraryRepository({FirebaseFirestore? db}) : _db = db ?? FirebaseFirestore.instance;
  final FirebaseFirestore _db;

  Future<void> addBookmark(String uid, {
    required String comicId,
    required String title,
    String? cover,
    String? slug,
    String? type,
  }) async {
    await _db.collection('users').doc(uid).collection('bookmarks').doc(comicId).set({
      'comicId': comicId,
      'title': title,
      'cover': cover ?? '',
      'slug': slug ?? comicId,
      'type': type ?? 'Manhwa',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> removeBookmark(String uid, String comicId) async {
    await _db.collection('users').doc(uid).collection('bookmarks').doc(comicId).delete();
  }

  Future<bool> isBookmarked(String uid, String comicId) async {
    final d = await _db.collection('users').doc(uid).collection('bookmarks').doc(comicId).get();
    return d.exists;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenBookmarks(String uid) {
    return _db.collection('users').doc(uid).collection('bookmarks').snapshots();
  }

  Future<void> setLastRead(String uid, {
    required String comicId,
    String? comicSlug,
    String? comicTitle,
    String? cover,
    required String chapterId,
    num? chapterNumber,
  }) async {
    await _db.collection('users').doc(uid).collection('readingProgress').doc(comicId).set({
      'comicId': comicId,
      'comicSlug': comicSlug ?? comicId,
      'comicTitle': comicTitle ?? '',
      'cover': cover ?? '',
      'chapterId': chapterId,
      'chapterNumber': chapterNumber ?? 0,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> listenLastReads(String uid, {int max = 12}) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('readingProgress')
        .orderBy('updatedAt', descending: true)
        .limit(max)
        .snapshots();
  }

  Future<void> markChapterRead(String uid, String comicId, String chapterId) async {
    final id = '${comicId}_$chapterId';
    await _db.collection('users').doc(uid).collection('readChapters').doc(id).set({
      'comicId': comicId,
      'chapterId': chapterId,
      'readAt': FieldValue.serverTimestamp(),
    });
  }
}
