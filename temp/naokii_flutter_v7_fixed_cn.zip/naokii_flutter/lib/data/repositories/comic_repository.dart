import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/comic.dart';
import '../services/mangadex_api.dart';

class ComicRepository {
  ComicRepository({FirebaseFirestore? db, MangaDexApi? md})
      : _db = db ?? FirebaseFirestore.instance,
        _md = md ?? MangaDexApi();

  final FirebaseFirestore _db;
  final MangaDexApi _md;

  CollectionReference<Map<String, dynamic>> get _comics =>
      _db.collection('comics');

  bool _isMd(String idOrSlug) =>
      idOrSlug.startsWith('md_') ||
      RegExp(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
              caseSensitive: false)
          .hasMatch(idOrSlug);

  /// Gabungan: MangaDex popular + judul admin di Firestore.
  Future<List<Comic>> listComics({int max = 24}) async {
    List<Comic> md = [];
    try {
      md = await _md.popular(limit: max);
    } catch (_) {}
    List<Comic> local = [];
    try {
      final snap = await _comics
          .orderBy('updatedAt', descending: true)
          .limit(max)
          .get();
      local = snap.docs.map((d) => Comic.fromMap(d.id, d.data())).toList();
    } catch (_) {}
    // local dulu biar judul upload sendiri muncul, lalu MD
    final seen = <String>{};
    final out = <Comic>[];
    for (final c in [...local, ...md]) {
      if (seen.add(c.id)) out.add(c);
    }
    return out.take(max).toList();
  }

  Future<List<Comic>> listLatest({int max = 24}) async {
    try {
      return await _md.latest(limit: max);
    } catch (_) {
      return listComics(max: max);
    }
  }

  Future<List<Comic>> listByType(String type, {int max = 24}) async {
    final lang = switch (type) {
      'Manhwa' => 'ko',
      'Manhua' => 'zh',
      'Manga' => 'ja',
      _ => 'ko',
    };
    try {
      return await _md.popular(limit: max, lang: lang);
    } catch (_) {
      return [];
    }
  }

  Future<Comic?> getBySlug(String slug) async {
    if (_isMd(slug)) {
      return _md.detail(slug);
    }
    final snap = await _comics.where('slug', isEqualTo: slug).limit(1).get();
    if (snap.docs.isEmpty) {
      final doc = await _comics.doc(slug).get();
      if (!doc.exists || doc.data() == null) {
        // fallback coba sebagai MD id
        if (_isMd(slug)) return _md.detail(slug);
        return null;
      }
      return Comic.fromMap(doc.id, doc.data()!);
    }
    final d = snap.docs.first;
    return Comic.fromMap(d.id, d.data());
  }

  Future<Comic?> getById(String id) async {
    if (_isMd(id)) return _md.detail(id);
    final doc = await _comics.doc(id).get();
    if (!doc.exists || doc.data() == null) return null;
    return Comic.fromMap(doc.id, doc.data()!);
  }

  Future<List<Chapter>> listChapters(String comicId) async {
    if (_isMd(comicId)) return _md.chapters(comicId);
    final snap = await _comics
        .doc(comicId)
        .collection('chapters')
        .orderBy('number')
        .get();
    return snap.docs.map((d) => Chapter.fromMap(d.id, d.data())).toList();
  }

  Future<Chapter?> getChapter(String comicId, String chapterId) async {
    if (_isMd(comicId) || _isMd(chapterId)) {
      final pages = await _md.pages(chapterId);
      return Chapter(
        id: chapterId,
        number: 0,
        title: 'Chapter',
        pages: pages,
      );
    }
    final doc =
        await _comics.doc(comicId).collection('chapters').doc(chapterId).get();
    if (!doc.exists || doc.data() == null) return null;
    return Chapter.fromMap(doc.id, doc.data()!);
  }

  Future<List<Comic>> search(String query, {int max = 20}) async {
    final q = query.trim();
    if (q.length < 2) return [];
    List<Comic> md = [];
    try {
      md = await _md.search(q, limit: max);
    } catch (_) {}
    List<Comic> local = [];
    try {
      final all = await _comics.orderBy('updatedAt', descending: true).limit(80).get();
      local = all.docs
          .map((d) => Comic.fromMap(d.id, d.data()))
          .where((c) =>
              c.title.toLowerCase().contains(q.toLowerCase()) ||
              (c.author?.toLowerCase().contains(q.toLowerCase()) ?? false))
          .toList();
    } catch (_) {}
    final seen = <String>{};
    final out = <Comic>[];
    for (final c in [...local, ...md]) {
      if (seen.add(c.id)) out.add(c);
    }
    return out.take(max).toList();
  }
}
