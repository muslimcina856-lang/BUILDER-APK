import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';

class StorageRepository {
  final _storage = FirebaseStorage.instance;

  /// Uploads a border frame PNG (expected to already have transparency —
  /// see note in AdminPage) and returns its public download URL.
  Future<String> uploadBorderImage(File file, String itemId) async {
    final ref = _storage.ref('borders/$itemId.png');
    final task = await ref.putFile(
      file,
      SettableMetadata(contentType: 'image/png'),
    );
    return task.ref.getDownloadURL();
  }

  Future<String> uploadBannerImage(File file, String bannerId) async {
    final ref = _storage.ref('banners/$bannerId.jpg');
    final task = await ref.putFile(
      file,
      SettableMetadata(contentType: 'image/jpeg'),
    );
    return task.ref.getDownloadURL();
  }
}
