import 'package:equatable/equatable.dart';

class UserProfile extends Equatable {
  const UserProfile({
    required this.uid,
    this.displayName,
    this.photoUrl,
    this.bio,
    this.exp = 0,
    this.customTitle,
    this.publicId,
    this.verified = false,
    this.borderId,
    this.clanId,
    this.clanTag,
    this.coins = 0,
    this.role = 'user',
    this.frameImageUrl,
  });

  final String uid;
  final String? displayName;
  final String? photoUrl;
  final String? bio;
  final int exp;
  final String? customTitle;
  final String? publicId;
  final bool verified;
  final String? borderId;
  final String? clanId;
  final String? clanTag;
  final int coins;

  /// One of: owner, admin, premium, user.
  final String role;

  /// Purchased/uploaded frame overlay image, if any.
  final String? frameImageUrl;

  bool get isOwner => role == 'owner';
  bool get isAdmin => role == 'owner' || role == 'admin';
  bool get isPremium => isAdmin || role == 'premium';

  int get level => (exp / 100).floor() + 1;

  String get name =>
      displayName?.isNotEmpty == true ? displayName! : 'User';

  factory UserProfile.fromMap(String uid, Map<String, dynamic> m) {
    return UserProfile(
      uid: uid,
      displayName: m['displayName'] as String? ?? m['name'] as String?,
      photoUrl: m['photoURL'] as String? ?? m['photoUrl'] as String? ?? m['avatarUrl'] as String? ?? m['avatar'] as String?,
      bio: m['bio'] as String?,
      exp: (m['exp'] as num?)?.toInt() ?? 0,
      customTitle: m['customTitle'] as String?,
      publicId: m['publicId'] as String?,
      verified: m['verified'] == true,
      borderId: m['borderId'] as String? ?? m['equippedBorder'] as String?,
      clanId: m['clanId'] as String?,
      clanTag: m['clanTag'] as String?,
      coins: (m['coins'] as num?)?.toInt() ?? 0,
      role: m['role'] as String? ?? 'user',
      frameImageUrl: m['frameImageUrl'] as String?,
    );
  }

  UserProfile copyWith({
    String? borderId,
    int? coins,
    String? frameImageUrl,
  }) {
    return UserProfile(
      uid: uid,
      displayName: displayName,
      photoUrl: photoUrl,
      bio: bio,
      exp: exp,
      customTitle: customTitle,
      publicId: publicId,
      verified: verified,
      borderId: borderId ?? this.borderId,
      clanId: clanId,
      clanTag: clanTag,
      coins: coins ?? this.coins,
      role: role,
      frameImageUrl: frameImageUrl ?? this.frameImageUrl,
    );
  }

  @override
  List<Object?> get props => [uid, displayName, exp, borderId, coins, role];
}
