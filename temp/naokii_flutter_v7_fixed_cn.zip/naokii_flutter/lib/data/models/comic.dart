import 'package:equatable/equatable.dart';

class Comic extends Equatable {
  const Comic({
    required this.id,
    required this.title,
    required this.slug,
    this.cover,
    this.synopsis,
    this.genres = const [],
    this.status = 'ongoing',
    this.type = 'Manhwa',
    this.author,
    this.rating = 0,
    this.views = 0,
    this.latestChapter = 0,
    this.chapterCount = 0,
    this.createdAt,
    this.updatedAt,
  });

  final String id;
  final String title;
  final String slug;
  final String? cover;
  final String? synopsis;
  final List<String> genres;
  final String status;
  final String type;
  final String? author;
  final double rating;
  final int views;
  final int latestChapter;
  final int chapterCount;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  bool get isOngoing => status == 'ongoing';

  factory Comic.fromMap(String id, Map<String, dynamic> m) {
    return Comic(
      id: id,
      title: m['title'] as String? ?? '',
      slug: m['slug'] as String? ?? id,
      cover: m['cover'] as String?,
      synopsis: m['synopsis'] as String?,
      genres: (m['genres'] as List?)?.cast<String>() ?? const [],
      status: m['status'] as String? ?? 'ongoing',
      type: m['type'] as String? ?? 'Manhwa',
      author: m['author'] as String?,
      rating: (m['rating'] as num?)?.toDouble() ?? 0,
      views: (m['views'] as num?)?.toInt() ?? 0,
      latestChapter: (m['latestChapter'] as num?)?.toInt() ?? 0,
      chapterCount: (m['chapterCount'] as num?)?.toInt() ?? 0,
      createdAt: _ts(m['createdAt']),
      updatedAt: _ts(m['updatedAt']),
    );
  }

  static DateTime? _ts(dynamic v) {
    if (v == null) return null;
    if (v is DateTime) return v;
    try {
      // Firestore Timestamp
      return (v as dynamic).toDate() as DateTime;
    } catch (_) {
      return null;
    }
  }

  @override
  List<Object?> get props => [id, title, slug, chapterCount, updatedAt];
}

class Chapter extends Equatable {
  const Chapter({
    required this.id,
    required this.number,
    this.title,
    this.pages = const [],
    this.views = 0,
    this.uploadedBy,
    this.createdAt,
  });

  final String id;
  final num number;
  final String? title;
  final List<String> pages;
  final int views;
  final String? uploadedBy;
  final DateTime? createdAt;

  String get displayTitle =>
      title?.isNotEmpty == true ? title! : 'Chapter $number';

  factory Chapter.fromMap(String id, Map<String, dynamic> m) {
    return Chapter(
      id: id,
      number: m['number'] as num? ?? 0,
      title: m['title'] as String?,
      pages: (m['pages'] as List?)?.cast<String>() ?? const [],
      views: (m['views'] as num?)?.toInt() ?? 0,
      uploadedBy: m['uploadedBy'] as String?,
      createdAt: Comic._ts(m['createdAt']),
    );
  }

  @override
  List<Object?> get props => [id, number];
}
