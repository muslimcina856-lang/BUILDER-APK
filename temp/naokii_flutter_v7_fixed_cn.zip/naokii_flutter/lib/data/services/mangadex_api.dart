import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/comic.dart';

/// Client langsung ke api.mangadex.org (sama logika proxy web /api/mangadex).
class MangaDexApi {
  MangaDexApi({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const _base = 'https://api.mangadex.org';
  static const _uploads = 'https://uploads.mangadex.org';
  static const _ua = 'Mozilla/5.0 (compatible; NaokiiComic/1.0)';

  Future<Map<String, dynamic>> _get(String path) async {
    final res = await _client.get(
      Uri.parse('$_base$path'),
      headers: {'User-Agent': _ua, 'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw Exception('MangaDex HTTP ${res.statusCode}');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  String _titleOf(Map<String, dynamic>? attrs) {
    final t = attrs?['title'] as Map<String, dynamic>? ?? {};
    return (t['en'] ??
            t['ja-ro'] ??
            t['id'] ??
            t['ja'] ??
            (t.values.isNotEmpty ? t.values.first : null) ??
            'Untitled')
        .toString();
  }

  Map<String, String> _coverMap(List included) {
    final map = <String, String>{};
    for (final item in included) {
      if (item is Map && item['type'] == 'cover_art') {
        final id = item['id'] as String?;
        final fn = (item['attributes'] as Map?)?['fileName'] as String?;
        if (id != null && fn != null) map[id] = fn;
      }
    }
    return map;
  }

  String? _resolveCover(Map m, Map<String, String> coverMap) {
    final rels = m['relationships'] as List? ?? [];
    for (final r in rels) {
      if (r is Map && r['type'] == 'cover_art') {
        final cid = r['id'] as String?;
        final fn = coverMap[cid ?? ''];
        if (fn != null && cid != null) {
          // manga id + filename
          final mid = m['id'] as String;
          return '$_uploads/covers/$mid/$fn.512.jpg';
        }
      }
    }
    return null;
  }

  Comic _mapCard(Map m, Map<String, String> coverMap) {
    final attrs = m['attributes'] as Map<String, dynamic>? ?? {};
    final tags = attrs['tags'] as List? ?? [];
    final genres = tags
        .whereType<Map>()
        .where((t) => (t['attributes'] as Map?)?['group'] == 'genre')
        .map((t) => ((t['attributes'] as Map?)?['name'] as Map?)?['en'])
        .whereType<String>()
        .toList();

    final originalLang = attrs['originalLanguage'] as String? ?? '';
    String type = 'Manga';
    if (originalLang == 'ko') {
      type = 'Manhwa';
    } else if (originalLang == 'zh' || originalLang == 'zh-hk') {
      type = 'Manhua';
    } else if (originalLang == 'en') {
      type = 'Comic';
    }

    final id = m['id'] as String;
    final cover = _resolveCover(m, coverMap);

    return Comic(
      id: 'md_$id',
      title: _titleOf(attrs),
      slug: id, // MangaDex UUID dipakai sebagai slug route
      cover: cover,
      synopsis: null,
      genres: genres,
      status: attrs['status'] == 'ongoing' ? 'ongoing' : 'completed',
      type: type,
      author: null,
      rating: 0,
      views: 0,
      latestChapter: 0,
      chapterCount: 0,
    );
  }

  List<Comic> _mapList(Map<String, dynamic> data) {
    final coverMap = _coverMap(data['included'] as List? ?? []);
    final list = data['data'] as List? ?? [];
    return list.whereType<Map>().map((m) => _mapCard(m, coverMap)).toList();
  }

  Uri _mangaQuery({
    required int limit,
    String? title,
    String orderKey = 'followedCount',
    String lang = 'ko',
  }) {
    final q = <String, String>{
      'limit': '$limit',
      'order[$orderKey]': 'desc',
      'hasAvailableChapters': 'true',
    };
    final params = <String>[];
    q.forEach((k, v) => params.add('${Uri.encodeQueryComponent(k)}=${Uri.encodeQueryComponent(v)}'));
    params.add('includes[]=cover_art');
    params.add('contentRating[]=safe');
    params.add('contentRating[]=suggestive');
    params.add('originalLanguage[]=$lang');
    if (title != null && title.isNotEmpty) {
      params.add('title=${Uri.encodeQueryComponent(title)}');
    }
    return Uri.parse('$_base/manga?${params.join('&')}');
  }

  Future<List<Comic>> popular({int limit = 24, String lang = 'ko'}) async {
    final uri = _mangaQuery(limit: limit, lang: lang);
    final res = await _client.get(uri, headers: {'User-Agent': _ua, 'Accept': 'application/json'})
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw Exception('MangaDex HTTP ${res.statusCode}');
    return _mapList(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<List<Comic>> latest({int limit = 24, String lang = 'ko'}) async {
    final uri = _mangaQuery(limit: limit, orderKey: 'latestUploadedChapter', lang: lang);
    final res = await _client.get(uri, headers: {'User-Agent': _ua, 'Accept': 'application/json'})
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw Exception('MangaDex HTTP ${res.statusCode}');
    return _mapList(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<List<Comic>> search(String query, {int limit = 24, String lang = 'ko'}) async {
    if (query.trim().length < 2) return [];
    final uri = _mangaQuery(limit: limit, title: query.trim(), lang: lang);
    final res = await _client.get(uri, headers: {'User-Agent': _ua, 'Accept': 'application/json'})
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw Exception('MangaDex HTTP ${res.statusCode}');
    return _mapList(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<Comic?> detail(String id) async {
    final pure = id.startsWith('md_') ? id.substring(3) : id;
    final data = await _get('/manga/$pure?includes[]=cover_art&includes[]=author&includes[]=artist');
    final m = data['data'] as Map?;
    if (m == null) return null;
    final coverMap = _coverMap(data['included'] as List? ?? []);
    final comic = _mapCard(m, coverMap);
    final attrs = m['attributes'] as Map<String, dynamic>? ?? {};
    final desc = attrs['description'] as Map<String, dynamic>? ?? {};
    final synopsis = (desc['en'] ?? desc['id'] ?? (desc.values.isNotEmpty ? desc.values.first : ''))
        .toString();

    String? author;
    for (final r in (data['included'] as List? ?? [])) {
      if (r is Map && (r['type'] == 'author' || r['type'] == 'artist')) {
        author = (r['attributes'] as Map?)?['name'] as String?;
        if (author != null) break;
      }
    }

    return Comic(
      id: comic.id,
      title: comic.title,
      slug: pure,
      cover: comic.cover,
      synopsis: synopsis,
      genres: comic.genres,
      status: comic.status,
      type: comic.type,
      author: author,
      rating: comic.rating,
      views: comic.views,
      latestChapter: comic.latestChapter,
      chapterCount: comic.chapterCount,
    );
  }

  Future<List<Chapter>> chapters(String mangaId) async {
    final pure = mangaId.startsWith('md_') ? mangaId.substring(3) : mangaId;

    Future<List<Chapter>> feed(String lang) async {
      final params = <String>[
        'translatedLanguage[]=$lang',
        'order[chapter]=asc',
        'limit=100',
        'contentRating[]=safe',
        'contentRating[]=suggestive',
      ];
      final data = await _get('/manga/$pure/feed?${params.join('&')}');
      final list = data['data'] as List? ?? [];
      return list.whereType<Map>().map((c) {
        final attrs = c['attributes'] as Map<String, dynamic>? ?? {};
        final numStr = attrs['chapter']?.toString() ?? '?';
        final chapterNum = num.tryParse(numStr) ?? 0;
        return Chapter(
          id: c['id'] as String,
          number: chapterNum,
          title: (attrs['title'] as String?)?.isNotEmpty == true
              ? attrs['title'] as String
              : 'Chapter $numStr',
          pages: const [],
        );
      }).toList();
    }

    var list = await feed('id');
    if (list.isEmpty) list = await feed('en');
    return list;
  }

  Future<List<String>> pages(String chapterId) async {
    final data = await _get('/at-home/server/$chapterId');
    final baseUrl = data['baseUrl'] as String?;
    final chapter = data['chapter'] as Map<String, dynamic>?;
    final hash = chapter?['hash'] as String?;
    final files = chapter?['data'] as List?;
    if (baseUrl == null || hash == null || files == null || files.isEmpty) {
      throw Exception('Chapter tidak tersedia di MangaDex at-home.');
    }
    return files.map((f) => '$baseUrl/data/$hash/$f').toList();
  }
}
