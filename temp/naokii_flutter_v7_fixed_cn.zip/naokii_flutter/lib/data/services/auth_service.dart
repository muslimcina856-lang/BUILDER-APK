
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../core/config/google_config.dart';
import '../repositories/user_repository.dart';

final authServiceProvider = Provider<AuthService>((_) => AuthService());

final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authServiceProvider).authStateChanges();
});

/// google_sign_in 7.x — butuh serverClientId (Web client ID) di Android.
class AuthService {
  AuthService({FirebaseAuth? auth}) : _auth = auth ?? FirebaseAuth.instance;

  final FirebaseAuth _auth;
  bool _googleReady = false;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  Future<void> _ensureGoogle() async {
    if (_googleReady) return;
    final serverId = GoogleConfig.serverClientId;
    if (serverId.contains('REPLACE_WITH')) {
      throw Exception(
        'Isi Web client ID di lib/core/config/google_config.dart\n'
        'Firebase Console → Authentication → Google → Web client ID',
      );
    }
    await GoogleSignIn.instance.initialize(serverClientId: serverId);
    _googleReady = true;
  }

  Future<UserCredential?> signInWithGoogle() async {
    await _ensureGoogle();
    final GoogleSignInAccount account =
        await GoogleSignIn.instance.authenticate();
    final idToken = account.authentication.idToken;
    if (idToken == null) {
      throw Exception(
        'Google idToken kosong. Pastikan SHA-1 Android app '
        'sudah ditambahkan di Firebase + google-services.json.',
      );
    }
    final credential = GoogleAuthProvider.credential(idToken: idToken);
    final cred = await _auth.signInWithCredential(credential);
    final u = cred.user;
    if (u != null) {
      await UserRepository().ensureProfile(
        u.uid,
        name: u.displayName,
        photoUrl: u.photoURL,
      );
    }
    return cred;
  }

  Future<void> signOut() async {
    await _auth.signOut();
    try {
      await GoogleSignIn.instance.signOut();
    } catch (_) {}
  }
}
