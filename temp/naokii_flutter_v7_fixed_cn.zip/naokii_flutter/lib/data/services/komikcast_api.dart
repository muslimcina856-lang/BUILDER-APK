
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/comic.dart';

/// Client ke komikcast-api (judul Indo) — mirror logika /api/catalog web.
class KomikcastApi {
  KomikcastApi({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  static const _base = 'https://komikcast-api.vercel.app';
  static const _ua =
      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36';

  Future<dynamic> _json(String path) async {
    final res = await _client
        .get(
          Uri.parse('$_base$path'),
          headers: {'User-Agent': _ua, 'Accept': 'application/json'},
        )
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw Exception('KC HTTP ${res.statusCode}');
    return jsonDecode(res.body);
  }

  String _mapType(dynamic raw) {
    final t = (raw ?? '').toString().toLowerCase();
    if (t.contains('manhwa')) return 'Manhwa';
    if (t.contains('manhua')) return 'Manhua';
    if (t.contains('novel')) return 'Novel';
    if (t.contains('manga')) return 'Manga';
    return 'Manhwa';
  }

  String _slugOf(Map m) {
    var endpoint = (m['endpoint'] ?? m['slug'] ?? m['href'] ?? m['link'] ?? '')
        .toString()
        .replaceAll(RegExp(r'^/+|/+$'), '');
    endpoint = endpoint.replaceFirst(RegExp(r'^(komik|manga)/'), '');
    if (endpoint.isEmpty) {
      endpoint = (m['title'] ?? 'untitled')
          .toString()
          .toLowerCase()
          .replaceAll(RegExp(r'\s+'), '-');
    }
    return endpoint;
  }

  Comic _norm(Map m) {
    final slug = _slugOf(m);
    final thumb =
        (m['thumb'] ?? m['thumbnail'] ?? m['image'] ?? m['cover'])?.toString();
    final title = (m['title'] ?? m['manga_title'] ?? 'Untitled').toString();
    final ch = (m['chapter'] ?? m['latest_chapter'] ?? m['last_chapter'] ?? m['ch'])
        ?.toString();
    final score = m['score'] != null ? (num.tryParse('${m['score']}') ?? 0) : 0;
    return Comic(
      id: 'kc_$slug',
      title: title,
      slug: slug,
      cover: thumb,
      synopsis: null,
      genres: const [],
      status: RegExp(r'tamat|complete', caseSensitive: false)
              .hasMatch((m['status'] ?? '').toString())
          ? 'completed'
          : 'ongoing',
      type: _mapType(m['type']),
      author: (m['author'] ?? m['pengarang'])?.toString(),
      rating: score.toDouble(),
      views: 0,
      latestChapter: num.tryParse(ch?.replaceAll(RegExp(r'[^\d.]'), '') ?? '') ?? 0,
      chapterCount: 0,
    );
  }

  List _arr(dynamic data) {
    if (data is List) return data;
    if (data is Map) {
      final a = data['manga_list'] ??
          data['popular'] ??
          data['data'] ??
          data['comics'] ??
          data['home']?['popular'];
      if (a is List) return a;
    }
    return const [];
  }

  Future<List<Comic>> popular() async {
    for (final path in ['/popular', '/recommended', '/api/popular', '/api/home']) {
      try {
        final data = await _json(path);
        final arr = _arr(data);
        if (arr.isNotEmpty) {
          return arr.whereType<Map>().map((m) => _norm(Map<String, dynamic>.from(m))).toList();
        }
      } catch (_) {}
    }
    return [];
  }

  Future<List<Comic>> latest({int page = 1}) async {
    for (final path in [
      '/terbaru?page=$page',
      '/latest?page=$page',
      '/api/terbaru?page=$page',
      '/manga/page/$page',
    ]) {
      try {
        final data = await _json(path);
        final arr = _arr(data);
        if (arr.isNotEmpty) {
          return arr.whereType<Map>().map((m) => _norm(Map<String, dynamic>.from(m))).toList();
        }
      } catch (_) {}
    }
    return [];
  }

  Future<List<Comic>> search(String q) async {
    if (q.trim().length < 2) return [];
    final enc = Uri.encodeQueryComponent(q.trim());
    for (final path in ['/search?keyword=$enc', '/api/search?keyword=$enc']) {
      try {
        final data = await _json(path);
        final arr = _arr(data);
        if (arr.isNotEmpty) {
          return arr.whereType<Map>().map((m) => _norm(Map<String, dynamic>.from(m))).toList();
        }
      } catch (_) {}
    }
    return [];
  }

  Future<Comic?> detail(String endpoint) async {
    final pure = endpoint.startsWith('kc_') ? endpoint.substring(3) : endpoint;
    for (final path in ['/detail/$pure', '/api/komik/$pure', '/manga/detail/$pure']) {
      try {
        final data = await _json(path);
        final d = (data is Map)
            ? (data['manga'] ?? data['data'] ?? data)
            : null;
        if (d is! Map) continue;
        final map = Map<String, dynamic>.from(d);
        if ((map['title'] ?? map['manga_title']) == null) continue;
        final c = _norm({...map, 'endpoint': pure, 'slug': pure});
        final synopsis = (map['synopsis'] ?? map['description'] ?? map['sinopsis'] ?? '')
            .toString();
        final genres = <String>[];
        final g = map['genre'] ?? map['genres'];
        if (g is List) {
          for (final x in g) {
            if (x is String) genres.add(x);
            if (x is Map) genres.add((x['genre_name'] ?? x['name'] ?? '').toString());
          }
        } else if (g is String) {
          genres.addAll(g.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty));
        }
        return Comic(
          id: c.id,
          title: c.title,
          slug: pure,
          cover: c.cover,
          synopsis: synopsis,
          genres: genres,
          status: c.status,
          type: c.type,
          author: c.author,
          rating: c.rating,
          views: c.views,
          latestChapter: c.latestChapter,
          chapterCount: c.chapterCount,
        );
      } catch (_) {}
    }
    return null;
  }

  Future<List<Chapter>> chapters(String endpoint) async {
    final pure = endpoint.startsWith('kc_') ? endpoint.substring(3) : endpoint;
    // detail embeds chapters
    for (final path in ['/detail/$pure', '/api/komik/$pure', '/manga/detail/$pure']) {
      try {
        final data = await _json(path);
        final d = (data is Map) ? (data['manga'] ?? data['data'] ?? data) : null;
        if (d is! Map) continue;
        final list = d['chapter'] ?? d['chapter_list'] ?? d['chapters'];
        if (list is! List || list.isEmpty) continue;
        final out = <Chapter>[];
        for (final c in list) {
          if (c is! Map) continue;
          final cm = Map<String, dynamic>.from(c);
          final numStr = (cm['chapter'] ?? cm['chapter_number'] ?? cm['num'] ?? cm['name'] ?? '?')
              .toString();
          final n = num.tryParse(numStr.replaceAll(RegExp(r'[^\d.]'), '')) ?? 0;
          var ep = (cm['chapter_endpoint'] ?? cm['endpoint'] ?? cm['slug'] ?? '')
              .toString()
              .replaceAll(RegExp(r'^/+|/+$'), '');
          if (ep.isEmpty) ep = '${pure}-chapter-$numStr'.replaceAll(' ', '-');
          final title = (cm['chapter_title'] ?? cm['title'] ?? cm['name'] ?? 'Chapter $numStr')
              .toString();
          out.add(Chapter(id: ep, number: n, title: title, pages: const []));
        }
        // sort ascending by number
        out.sort((a, b) => a.number.compareTo(b.number));
        return out;
      } catch (_) {}
    }
    return [];
  }

  Future<List<String>> pages(String chapterEndpoint) async {
    final pure = chapterEndpoint.startsWith('kc_')
        ? chapterEndpoint.substring(3)
        : chapterEndpoint;
    for (final path in ['/read/$pure', '/api/chapter/$pure', '/chapter/$pure']) {
      try {
        final data = await _json(path);
        if (data is! Map) continue;
        final imgs = data['chapter_image'] ??
            data['images'] ??
            data['chapter']?['images'] ??
            data['data']?['images'];
        if (imgs is! List || imgs.isEmpty) continue;
        return imgs
            .map((i) {
              if (i is String) return i;
              if (i is Map) {
                return (i['chapter_image_link'] ?? i['image'] ?? i['src'] ?? '')
                    .toString();
              }
              return '';
            })
            .where((s) => s.startsWith('http'))
            .toList();
      } catch (_) {}
    }
    return [];
  }
}
