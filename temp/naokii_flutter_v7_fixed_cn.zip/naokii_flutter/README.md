# Naokii Comic — Flutter APK

Versi **native Flutter** dari platform Naokii Comic (Next.js).  
Backend tetap **Firebase project yang sama** (`ryychatroom`) — comics, chapters, novels, globalChat, auth.

## Fitur yang sudah di-scaffold

| Area | Status |
|------|--------|
| Home (greeting, search, quick chat/novel, populer, grid update) | ✅ |
| Jelajah + filter tipe + search | ✅ |
| Detail komik + daftar chapter | ✅ |
| Reader (long strip + single page + immersive) | ✅ |
| Library (placeholder + gate login) | ✅ skeleton |
| Global Chat (Firestore live) | ✅ |
| Novel home + novel reader teks | ✅ |
| Login Google | ✅ |
| Profil | ✅ |
| Bottom nav mobile-first | ✅ |
| CI build APK + bot Telegram | ✅ template |

## Setup lokal

```bash
# 1. Install Flutter 3.24+ https://docs.flutter.dev/get-started/install
cd naokii_flutter

# 2. Tambah Android app di Firebase Console
#    Package name: com.naokii.comic
#    Download google-services.json → android/app/google-services.json

# 3. (Disarankan) regenerate options
dart pub global activate flutterfire_cli
flutterfire configure --project=ryychatroom

# 4. Dependencies & run
flutter pub get
flutter run
```

### Google Sign-In Android
- SHA-1 debug: `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android`
- Tambahkan SHA-1 di Firebase → Project settings → Android app
- OAuth client akan ter-generate otomatis

## Build APK manual

```bash
flutter build apk --release --split-per-abi
# Output: build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
#         build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
```

## Build lewat bot Telegram

1. Push repo ke GitHub.
2. Settings → Secrets and variables → Actions:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID` (chat id kamu / group)
3. Di mesin/server bot:

```bash
export TELEGRAM_BOT_TOKEN=...
export GITHUB_TOKEN=ghp_...          # PAT dengan scope `repo` + `workflow`
export GITHUB_REPO=owner/naokii_flutter
export ALLOWED_CHAT_IDS=123456789    # opsional
pip install requests
python scripts/telegram_build_bot.py
```

4. Di Telegram: `/build` → GitHub Actions jalan → APK arm64 dikirim ke chat.

Workflow: `.github/workflows/build-apk.yml`

## Struktur

```
lib/
  main.dart
  firebase_options.dart          # ganti via flutterfire configure
  core/theme, router, constants
  data/models, repositories, services
  features/
    home, catalog, reader, library,
    auth, profile, chat, novel
  shared/widgets
android/                         # applicationId com.naokii.comic
scripts/telegram_build_bot.py
.github/workflows/build-apk.yml
```

## Catatan keamanan

- **Jangan** commit Firebase Admin private key / Cloudinary API secret ke repo Flutter.
- Client hanya pakai Firebase client config (sama seperti `NEXT_PUBLIC_*` di web).
- Upload gambar chapter tetap lewat admin panel **web** (signed Cloudinary). APK bersifat reader + komunitas.

## Roadmap lanjutan (bisa diminta bertahap)

1. Bookmark & reading progress (Firestore `users/{uid}/…`)
2. Komentar + reaction di chapter
3. Clan / affinity UI
4. Offline cache halaman chapter
5. Signing keystore production + Play Store listing
6. Port fitur admin (opsional — biasanya tetap di web)

## UI/UX APK (bukan web dipaksa ke HP)

- Bottom navigation 5 tab (Home / Jelajah / Library / Chat / Profil)
- Reader immersive (tap hide chrome, long-strip default)
- Kartu komik aspect 3:4, grid 2 kolom
- Dark theme solid (`#0B0F19`), radius 14–18, chip filter
- Safe area + bounce scroll native
