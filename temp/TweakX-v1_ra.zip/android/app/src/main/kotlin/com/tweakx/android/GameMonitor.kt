package com.tweakx.android

import android.os.Handler
import android.os.Looper
import java.util.regex.Pattern

/**
 * Polls the foreground package through Shizuku. A short grace period prevents
 * the launch transition from looking like a game exit; two consecutive misses
 * prevent transient system dialogs from resetting the session.
 */
class GameMonitor(private val gameBridge: GameBridge) {
    companion object {
        private const val POLL_INTERVAL_MS = 1500L
        private const val STARTUP_GRACE_MS = 8000L
        private const val REQUIRED_AWAY_CHECKS = 2
        private val FOCUSED_PACKAGE_PATTERN = Pattern.compile(
            "(?:mResumedActivity|topResumedActivity).*?\\{[^}]*\\s([a-zA-Z0-9_.]+)/"
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private var monitoredPackage: String? = null
    private var onGameClosed: (() -> Unit)? = null
    private var running = false
    private var startedAtMs = 0L
    private var awayChecks = 0

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            checkForegroundApp()
            if (running) handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    fun start(packageName: String, onClosed: () -> Unit) {
        stop()
        monitoredPackage = packageName
        onGameClosed = onClosed
        running = true
        startedAtMs = System.currentTimeMillis()
        awayChecks = 0
        handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)
    }

    fun stop() {
        running = false
        monitoredPackage = null
        onGameClosed = null
        startedAtMs = 0L
        awayChecks = 0
        handler.removeCallbacks(pollRunnable)
    }

    private fun checkForegroundApp() {
        val target = monitoredPackage ?: return
        if (System.currentTimeMillis() - startedAtMs < STARTUP_GRACE_MS) return

        val result = ShizukuCommandExecutor.execute(CommandAllowlist.getForegroundApp())
        if (!result.success) {
            val callback = onGameClosed
            stop()
            callback?.invoke()
            return
        }

        val matcher = FOCUSED_PACKAGE_PATTERN.matcher(result.stdout)
        val foregroundPackage = if (matcher.find()) matcher.group(1) else null
        if (foregroundPackage == null || foregroundPackage == target) {
            awayChecks = 0
            return
        }

        awayChecks += 1
        if (awayChecks >= REQUIRED_AWAY_CHECKS) {
            val callback = onGameClosed
            stop()
            callback?.invoke()
        }
    }
}
