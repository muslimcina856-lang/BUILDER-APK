package com.tweakx.android

/**
 * Bridges game-profile tweak operations (resolution, DPI, refresh rate,
 * thermal read, touch info, launch) to CommandAllowlist + ShizukuCommandExecutor.
 *
 * Distinct from TweakBridge (global tweaks): these operations are meant to
 * be applied right before launching a specific game, and reset afterward
 * by GameMonitor once the game closes.
 */
class GameBridge {

    fun getPeakRefreshRate(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getPeakRefreshRate()).toMap()

    fun setPeakRefreshRate(hz: Int): Map<String, Any> {
        return try {
            ShizukuCommandExecutor.execute(CommandAllowlist.setPeakRefreshRate(hz)).toMap()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            failureMap(e.message)
        }
    }

    fun resetPeakRefreshRate(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.resetPeakRefreshRate()).toMap()

    /**
     * Thermal status is READ-ONLY. There is no universal, cross-OEM Android
     * API to force a thermal/power profile from a regular app — even via
     * Shizuku. Different manufacturers (Samsung Game Booster, MIUI, etc.)
     * implement this differently and inconsistently. TweakX honestly
     * reports current thermal status rather than pretending to control it.
     */
    fun getThermalStatus(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getThermalStatus()).toMap()

    /**
     * Touch sampling info is READ-ONLY for the same reason as thermal:
     * no universal setter exists across devices via Shizuku-level access.
     */
    fun getTouchInfo(): Map<String, Any> =
        ShizukuCommandExecutor.execute(CommandAllowlist.getTouchSampleRateInfo()).toMap()

    fun launchApp(packageName: String): Map<String, Any> {
        return try {
            ShizukuCommandExecutor.execute(CommandAllowlist.launchApp(packageName)).toMap()
        } catch (e: CommandAllowlist.InvalidTweakInputException) {
            failureMap(e.message)
        }
    }

    private fun failureMap(message: String?): Map<String, Any> = mapOf(
        "success" to false,
        "exitCode" to -1,
        "stdout" to "",
        "stderr" to (message ?: "invalid input")
    )
}
