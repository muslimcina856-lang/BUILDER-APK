package com.tweakx.android

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.EnumMap
import kotlin.math.roundToInt

/**
 * Owns one game session at a time. Every mutable global setting is captured
 * before it is changed, then restored to that exact value when the monitored
 * game leaves the foreground. This avoids hard-coded "reset" values that
 * could overwrite the user's normal device configuration.
 */
class GameSessionManager(
    private val context: Context,
    private val gameBridge: GameBridge,
    private val gameMonitor: GameMonitor,
) {
    private val snapshot = EnumMap<CommandAllowlist.SnapshotSetting, String?>(
        CommandAllowlist.SnapshotSetting::class.java
    )
    private var activePackage: String? = null
    private var densityWasCaptured = false
    private var previousDensityOverride: Int? = null
    private var compilationChanged = false
    private var restoreInProgress = false

    @Synchronized
    fun launchGame(profile: Map<*, *>): Map<String, Any> {
        restoreCurrentSession()

        val packageName = profile["packageName"] as? String
            ?: return failure("Missing packageName")
        val label = profile["label"] as? String ?: packageName
        val refreshRate = (profile["refreshRateHz"] as? Number)?.toInt()
        val brightness = (profile["brightness"] as? Number)?.toInt()
        val smallestWidth = (profile["smallestWidthDp"] as? Number)?.toInt()
        val animationScale = (profile["animationScale"] as? Number)?.toDouble()
        val compileBooster = profile["compileBoosterEnabled"] as? Boolean ?: false
        val graphicsMode = profile["graphicsApiMode"] as? String ?: "default"
        val fpsMeter = profile["fpsMeterEnabled"] as? Boolean ?: false
        val dozeMode = profile["dozeMode"] as? String ?: "stock"
        val crosshairEnabled = profile["crosshairEnabled"] as? Boolean ?: false
        val crosshairStyle = profile["crosshairStyle"] as? String ?: "cross"
        val crosshairColor = profile["crosshairColorHex"] as? String ?: "#00E676"
        val crosshairSize = (profile["crosshairSize"] as? Number)?.toInt() ?: 48

        val settingsToCapture = linkedSetOf<CommandAllowlist.SnapshotSetting>()
        if (brightness != null) settingsToCapture += CommandAllowlist.SnapshotSetting.BRIGHTNESS
        if (refreshRate != null) settingsToCapture += CommandAllowlist.SnapshotSetting.PEAK_REFRESH_RATE
        if (animationScale != null) {
            settingsToCapture += CommandAllowlist.SnapshotSetting.WINDOW_ANIMATION
            settingsToCapture += CommandAllowlist.SnapshotSetting.TRANSITION_ANIMATION
            settingsToCapture += CommandAllowlist.SnapshotSetting.ANIMATOR_DURATION
        }
        if (dozeMode != "stock") settingsToCapture += CommandAllowlist.SnapshotSetting.DOZE_CONSTANTS
        if (graphicsMode != "default") {
            settingsToCapture += CommandAllowlist.SnapshotSetting.ANGLE_PACKAGES
            settingsToCapture += CommandAllowlist.SnapshotSetting.ANGLE_VALUES
        }

        val captureError = capture(settingsToCapture)
        if (captureError != null) {
            restoreCurrentSession()
            return failure("Unable to capture current settings: $captureError")
        }
        if (smallestWidth != null) {
            val densityError = captureDensity()
            if (densityError != null) {
                restoreCurrentSession()
                return failure("Unable to capture current Smallest Width: $densityError")
            }
        }

        val warnings = mutableListOf<String>()
        if (refreshRate != null) {
            run(CommandAllowlist.setPeakRefreshRate(refreshRate), warnings, "Refresh rate")
        }
        if (brightness != null) {
            run(CommandAllowlist.setBrightness(brightness), warnings, "Brightness")
        }
        if (smallestWidth != null) {
            val density = calculateDensityForSmallestWidth(smallestWidth)
            if (density == null) {
                warnings += "Smallest Width: unable to determine real display size"
            } else {
                run(CommandAllowlist.setSmallestWidthDpi(density), warnings, "Smallest Width")
            }
        }
        if (animationScale != null) {
            val animationSettings = listOf(
                CommandAllowlist.AnimationSetting.WINDOW,
                CommandAllowlist.AnimationSetting.TRANSITION,
                CommandAllowlist.AnimationSetting.ANIMATOR,
            )
            animationSettings.forEach {
                run(CommandAllowlist.setAnimationScale(it, animationScale), warnings, "Animation")
            }
        }
        if (dozeMode != "stock") {
            val mode = when (dozeMode) {
                "aggressive" -> CommandAllowlist.DozeMode.AGGRESSIVE
                "extreme" -> CommandAllowlist.DozeMode.EXTREME
                else -> null
            }
            if (mode == null) {
                warnings += "Doze: unsupported mode"
            } else {
                run(CommandAllowlist.setDozeConstants(mode), warnings, "Doze")
            }
        }
        if (graphicsMode != "default") {
            val driver = if (graphicsMode == "angle") "angle" else "native"
            run(CommandAllowlist.setAnglePackages(packageName), warnings, "Graphics package")
            run(CommandAllowlist.setAngleValues(driver), warnings, "Graphics driver")
        }
        if (compileBooster) {
            compilationChanged = true
            run(CommandAllowlist.compileAllAot(), warnings, "Compile Booster")
        }

        val launchResult = gameBridge.launchApp(packageName)
        if (!(launchResult["success"] as? Boolean ?: false)) {
            restoreCurrentSession()
            val error = launchResult["stderr"]?.toString()?.ifBlank { "Unable to launch game" }
                ?: "Unable to launch game"
            return failure("Launch: $error")
        }

        activePackage = packageName
        gameMonitor.start(packageName) { onGameClosed() }
        if (crosshairEnabled || fpsMeter) {
            showOverlay(
                packageName,
                crosshairEnabled,
                crosshairStyle,
                crosshairColor,
                crosshairSize,
                fpsMeter,
            )
        }

        val suffix = if (warnings.isEmpty()) "" else " Warnings: ${warnings.joinToString("; ")}"
        return mapOf(
            "success" to true,
            "exitCode" to 0,
            "stdout" to "$label launched.$suffix",
            "stderr" to "",
        )
    }

    @Synchronized
    fun onGameClosed() {
        if (activePackage == null && snapshot.isEmpty() && !densityWasCaptured && !compilationChanged) return
        gameMonitor.stop()
        hideOverlay()
        restoreCurrentSession()
    }

    @Synchronized
    fun stop() {
        gameMonitor.stop()
        hideOverlay()
        restoreCurrentSession()
    }

    private fun captureDensity(): String? {
        val result = ShizukuCommandExecutor.execute(CommandAllowlist.getDensity())
        if (!result.success) return result.stderr.ifBlank { "density read failed" }
        densityWasCaptured = true
        previousDensityOverride = Regex("Override density:\\s*(\\d+)", RegexOption.IGNORE_CASE)
            .find(result.stdout)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
        return null
    }

    private fun calculateDensityForSmallestWidth(smallestWidthDp: Int): Int? {
        if (smallestWidthDp !in 240..720) return null
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            ?: return null
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val smallestPx = minOf(metrics.widthPixels, metrics.heightPixels)
        if (smallestPx <= 0) return null
        return (smallestPx * 160.0 / smallestWidthDp).roundToInt().coerceIn(120, 640)
    }

    private fun capture(settings: Set<CommandAllowlist.SnapshotSetting>): String? {
        snapshot.clear()
        settings.forEach { setting ->
            val result = ShizukuCommandExecutor.execute(CommandAllowlist.getSnapshotSetting(setting))
            if (!result.success) return result.stderr.ifBlank { "${setting.key} read failed" }
            snapshot[setting] = normalizeSetting(result.stdout)
        }
        return null
    }

    private fun normalizeSetting(raw: String): String? {
        val value = raw.trim().lineSequence().lastOrNull()?.trim() ?: return null
        if (value.isBlank() || value.equals("null", ignoreCase = true)) return null
        if (value.startsWith("Unknown", ignoreCase = true)) return null
        if (value.startsWith("No such property", ignoreCase = true)) return null
        return value
    }

    private fun run(command: List<String>, warnings: MutableList<String>, label: String) {
        val result = ShizukuCommandExecutor.execute(command)
        if (!result.success) warnings += "$label: ${result.stderr.ifBlank { "command failed" }}"
    }

    private fun restoreCurrentSession() {
        if (restoreInProgress) return
        restoreInProgress = true
        try {
            snapshot.entries.reversed().forEach { (setting, value) ->
                ShizukuCommandExecutor.execute(CommandAllowlist.restoreSnapshotSetting(setting, value))
            }
            if (densityWasCaptured) {
                val restoreDensity = previousDensityOverride?.let {
                    CommandAllowlist.setSmallestWidthDpi(it)
                } ?: CommandAllowlist.resetSmallestWidth()
                ShizukuCommandExecutor.execute(restoreDensity)
            }
            if (compilationChanged) {
                ShizukuCommandExecutor.execute(CommandAllowlist.resetAllCompilation())
            }
        } finally {
            snapshot.clear()
            activePackage = null
            densityWasCaptured = false
            previousDensityOverride = null
            compilationChanged = false
            restoreInProgress = false
        }
    }

    private fun showOverlay(
        packageName: String,
        crosshairEnabled: Boolean,
        style: String,
        color: String,
        size: Int,
        fpsMeter: Boolean,
    ) {
        if (!android.provider.Settings.canDrawOverlays(context)) return
        val intent = Intent(context, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW_SESSION
            putExtra(OverlayService.EXTRA_PACKAGE, packageName)
            putExtra(OverlayService.EXTRA_SHOW_CROSSHAIR, crosshairEnabled)
            putExtra(OverlayService.EXTRA_COLOR, CrosshairView.parseColorSafe(color))
            putExtra(OverlayService.EXTRA_SIZE, size.coerceIn(24, 120))
            putExtra(OverlayService.EXTRA_STYLE, style)
            putExtra(OverlayService.EXTRA_SHOW_FPS, fpsMeter)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    private fun hideOverlay() {
        context.stopService(Intent(context, OverlayService::class.java))
    }

    private fun failure(message: String): Map<String, Any> = mapOf(
        "success" to false,
        "exitCode" to -1,
        "stdout" to "",
        "stderr" to message,
    )
}
