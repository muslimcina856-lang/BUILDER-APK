package com.tweakx.android

/**
 * Typed, fixed allowlist for every privileged command used by TweakX.
 * Flutter never supplies a free-form shell command or a raw shell string.
 */
object CommandAllowlist {
    class InvalidTweakInputException(message: String) : IllegalArgumentException(message)

    fun getBrightness(): List<String> = listOf("settings", "get", "system", "screen_brightness")
    fun setBrightness(value: Int): List<String> {
        if (value !in 0..255) throw InvalidTweakInputException("Brightness must be between 0 and 255")
        return listOf("settings", "put", "system", "screen_brightness", value.toString())
    }

    private val ALLOWED_TIMEOUTS_MS = setOf(15_000, 30_000, 60_000, 300_000, 600_000)
    fun getScreenTimeout(): List<String> = listOf("settings", "get", "system", "screen_off_timeout")
    fun setScreenTimeout(valueMs: Int): List<String> {
        if (valueMs !in ALLOWED_TIMEOUTS_MS) {
            throw InvalidTweakInputException("Screen timeout must be one of $ALLOWED_TIMEOUTS_MS milliseconds")
        }
        return listOf("settings", "put", "system", "screen_off_timeout", valueMs.toString())
    }

    private val ALLOWED_ANIMATION_SCALES = setOf(0.0, 0.5, 1.0, 1.5, 2.0)
    enum class AnimationSetting(val key: String) {
        WINDOW("window_animation_scale"),
        TRANSITION("transition_animation_scale"),
        ANIMATOR("animator_duration_scale")
    }
    fun getAnimationScale(setting: AnimationSetting): List<String> =
        listOf("settings", "get", "global", setting.key)
    fun setAnimationScale(setting: AnimationSetting, value: Double): List<String> {
        if (value !in ALLOWED_ANIMATION_SCALES) {
            throw InvalidTweakInputException("Animation scale must be one of $ALLOWED_ANIMATION_SCALES")
        }
        return listOf("settings", "put", "global", setting.key, value.toString())
    }

    fun getRefreshRate(): List<String> = listOf("dumpsys", "display")
    fun getDensity(): List<String> = listOf("wm", "density")
    fun setSmallestWidthDpi(dpi: Int): List<String> {
        if (dpi !in 120..640) {
            throw InvalidTweakInputException("Calculated density must be between 120 and 640")
        }
        return listOf("wm", "density", dpi.toString())
    }
    fun resetSmallestWidth(): List<String> = listOf("wm", "density", "reset")

    private val ALLOWED_REFRESH_RATES = setOf(60, 90, 120, 144)
    fun getPeakRefreshRate(): List<String> = listOf("settings", "get", "system", "peak_refresh_rate")
    fun setPeakRefreshRate(hz: Int): List<String> {
        if (hz !in ALLOWED_REFRESH_RATES) {
            throw InvalidTweakInputException("Refresh rate must be one of $ALLOWED_REFRESH_RATES")
        }
        return listOf("settings", "put", "system", "peak_refresh_rate", hz.toString())
    }
    fun resetPeakRefreshRate(): List<String> = listOf("settings", "delete", "system", "peak_refresh_rate")

    enum class SnapshotSetting(val namespace: String, val key: String) {
        BRIGHTNESS("system", "screen_brightness"),
        PEAK_REFRESH_RATE("system", "peak_refresh_rate"),
        WINDOW_ANIMATION("global", "window_animation_scale"),
        TRANSITION_ANIMATION("global", "transition_animation_scale"),
        ANIMATOR_DURATION("global", "animator_duration_scale"),
        DOZE_CONSTANTS("global", "device_idle_constants"),
        ANGLE_PACKAGES("global", "angle_gl_driver_selection_pkgs"),
        ANGLE_VALUES("global", "angle_gl_driver_selection_values")
    }

    fun getSnapshotSetting(setting: SnapshotSetting): List<String> =
        listOf("settings", "get", setting.namespace, setting.key)

    fun restoreSnapshotSetting(setting: SnapshotSetting, value: String?): List<String> =
        if (value == null) {
            listOf("settings", "delete", setting.namespace, setting.key)
        } else {
            listOf("settings", "put", setting.namespace, setting.key, value)
        }

    enum class DozeMode { STOCK, AGGRESSIVE, EXTREME }
    fun getDozeConstants(): List<String> =
        listOf("settings", "get", "global", "device_idle_constants")
    fun setDozeConstants(mode: DozeMode): List<String> {
        val constants = when (mode) {
            DozeMode.STOCK -> return resetDozeConstants()
            DozeMode.AGGRESSIVE ->
                "inactive_to=10000,sensing_to=10000,locating_to=10000," +
                    "motion_inactive_to=10000,idle_after_inactive_to=10000," +
                    "idle_pending_to=60000,max_idle_pending_to=120000," +
                    "idle_to=21600000,max_idle_to=43200000"
            DozeMode.EXTREME ->
                "inactive_to=1000,sensing_to=1000,locating_to=1000," +
                    "motion_inactive_to=1000,idle_after_inactive_to=1000," +
                    "idle_pending_to=10000,max_idle_pending_to=20000," +
                    "idle_to=43200000,max_idle_to=86400000"
        }
        return listOf("settings", "put", "global", "device_idle_constants", constants)
    }
    fun resetDozeConstants(): List<String> = listOf("settings", "delete", "global", "device_idle_constants")

    fun getAnglePackages(): List<String> =
        listOf("settings", "get", "global", "angle_gl_driver_selection_pkgs")
    fun getAngleValues(): List<String> =
        listOf("settings", "get", "global", "angle_gl_driver_selection_values")
    fun setAnglePackages(packageName: String): List<String> {
        validatePackage(packageName)
        return listOf("settings", "put", "global", "angle_gl_driver_selection_pkgs", packageName)
    }
    fun setAngleValues(value: String): List<String> {
        if (value !in setOf("angle", "native")) {
            throw InvalidTweakInputException("Unsupported graphics driver value")
        }
        return listOf("settings", "put", "global", "angle_gl_driver_selection_values", value)
    }
    fun resetAnglePackages(): List<String> =
        listOf("settings", "delete", "global", "angle_gl_driver_selection_pkgs")
    fun resetAngleValues(): List<String> =
        listOf("settings", "delete", "global", "angle_gl_driver_selection_values")

    fun compileAllAot(): List<String> =
        listOf("cmd", "package", "compile", "-m", "speed", "-f", "--all")
    fun resetAllCompilation(): List<String> =
        listOf("cmd", "package", "compile", "--reset", "--all")

    fun getGfxInfo(packageName: String): List<String> {
        validatePackage(packageName)
        return listOf("dumpsys", "gfxinfo", packageName, "framestats")
    }

    fun getGfxInfoSummary(packageName: String): List<String> {
        validatePackage(packageName)
        return listOf("dumpsys", "gfxinfo", packageName)
    }

    fun getTouchSampleRateInfo(): List<String> = listOf("dumpsys", "input")
    fun getThermalStatus(): List<String> = listOf("dumpsys", "thermalservice")
    fun getForegroundApp(): List<String> = listOf("dumpsys", "activity", "activities")

    fun launchApp(packageName: String): List<String> {
        validatePackage(packageName)
        return listOf("monkey", "-p", packageName, "-c", "android.intent.category.LAUNCHER", "1")
    }

    private fun validatePackage(packageName: String) {
        if (!packageName.matches(Regex("^[a-zA-Z0-9_.]+$"))) {
            throw InvalidTweakInputException("Invalid package name")
        }
    }
}
