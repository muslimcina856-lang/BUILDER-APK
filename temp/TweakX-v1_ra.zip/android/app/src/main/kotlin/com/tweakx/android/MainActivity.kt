package com.tweakx.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import rikka.shizuku.Shizuku
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Thin Flutter channel router. GameSessionManager owns the transaction that
 * snapshots, applies, monitors, and restores per-game settings.
 */
class MainActivity : FlutterActivity() {
    private val shizukuChannelName = "com.tweakx.android/shizuku"
    private val tweakChannelName = "com.tweakx.android/tweak"
    private val deviceChannelName = "com.tweakx.android/device"
    private val shizukuEventChannelName = "com.tweakx.android/shizuku_events"
    private val appsChannelName = "com.tweakx.android/apps"
    private val gameChannelName = "com.tweakx.android/game"
    private val gameEventChannelName = "com.tweakx.android/game_events"
    private val overlayChannelName = "com.tweakx.android/overlay"

    private lateinit var tweakBridge: TweakBridge
    private lateinit var gameBridge: GameBridge
    private lateinit var appListManager: AppListManager
    private lateinit var gameMonitor: GameMonitor
    private lateinit var sessionManager: GameSessionManager
    private var eventSink: EventChannel.EventSink? = null
    private var gameEventSink: EventChannel.EventSink? = null
    private val sessionExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
            }
        }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        tweakBridge = TweakBridge(getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
        gameBridge = GameBridge()
        appListManager = AppListManager(applicationContext)
        gameMonitor = GameMonitor(gameBridge)
        sessionManager = GameSessionManager(applicationContext, gameBridge, gameMonitor)

        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuChannelName)
            .setMethodCallHandler { call, result -> handleShizukuCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, tweakChannelName)
            .setMethodCallHandler { call, result -> handleTweakCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result -> handleDeviceCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, appsChannelName)
            .setMethodCallHandler { call, result -> handleAppsCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, gameChannelName)
            .setMethodCallHandler { call, result -> handleGameCall(call, result) }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, overlayChannelName)
            .setMethodCallHandler { call, result -> handleOverlayCall(call, result) }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuEventChannelName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    eventSink = sink
                    sink?.success(ShizukuManager.getStatusMap())
                }
                override fun onCancel(arguments: Any?) { eventSink = null }
            })

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, gameEventChannelName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    gameEventSink = sink
                }
                override fun onCancel(arguments: Any?) { gameEventSink = null }
            })
    }

    private fun handleAppsCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getLaunchableApps" -> result.success(appListManager.getLaunchableApps().map {
                    mapOf(
                        "packageName" to it.packageName,
                        "label" to it.label,
                        "iconBase64" to (it.iconBase64 ?: ""),
                    )
                })
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("APPS_ERROR", e.message ?: "Unknown apps error", null)
        }
    }

    private fun handleGameCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "launchProfile" -> {
                    val profile = call.arguments as? Map<*, *>
                        ?: return result.error("INVALID_ARGS", "Missing game profile", null)
                    sessionExecutor.execute {
                        val sessionResult = sessionManager.launchGame(profile)
                        runOnUiThread { result.success(sessionResult) }
                    }
                }
                "getPeakRefreshRate" -> result.success(gameBridge.getPeakRefreshRate())
                "setPeakRefreshRate" -> {
                    val hz = call.argument<Int>("hz")
                        ?: return result.error("INVALID_ARGS", "Missing 'hz'", null)
                    result.success(gameBridge.setPeakRefreshRate(hz))
                }
                "resetPeakRefreshRate" -> result.success(gameBridge.resetPeakRefreshRate())
                "getThermalStatus" -> result.success(gameBridge.getThermalStatus())
                "getTouchInfo" -> result.success(gameBridge.getTouchInfo())
                "getBrightness" -> result.success(tweakBridge.getBrightness())
                "setBrightness" -> {
                    val value = call.argument<Int>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setBrightness(value))
                }
                "getAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    result.success(tweakBridge.getAnimationScale(setting))
                }
                "setAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    val value = call.argument<Double>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setAnimationScale(setting, value))
                }
                "stopSession" -> {
                    sessionManager.stop()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("GAME_ERROR", e.message ?: "Unknown game error", null)
        }
    }

    private fun handleShizukuCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "isAvailable" -> result.success(ShizukuManager.isAvailable())
                "isPermissionGranted" -> result.success(ShizukuManager.isPermissionGranted())
                "requestPermission" -> {
                    ShizukuManager.requestPermission()
                    result.success(null)
                }
                "getStatus" -> result.success(ShizukuManager.getStatusMap())
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("SHIZUKU_ERROR", e.message ?: "Unknown Shizuku error", null)
        }
    }

    private fun handleTweakCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getBrightness" -> result.success(tweakBridge.getBrightness())
                "setBrightness" -> {
                    val value = call.argument<Int>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setBrightness(value))
                }
                "getScreenTimeout" -> result.success(tweakBridge.getScreenTimeout())
                "setScreenTimeout" -> {
                    val value = call.argument<Int>("valueMs")
                        ?: return result.error("INVALID_ARGS", "Missing 'valueMs'", null)
                    result.success(tweakBridge.setScreenTimeout(value))
                }
                "getAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    result.success(tweakBridge.getAnimationScale(setting))
                }
                "setAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    val value = call.argument<Double>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setAnimationScale(setting, value))
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("TWEAK_ERROR", e.message ?: "Unknown tweak error", null)
        }
    }

    private fun handleDeviceCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getInfo" -> result.success(tweakBridge.getDeviceInfo())
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("DEVICE_ERROR", e.message ?: "Unknown device error", null)
        }
    }

    private fun handleOverlayCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "canDrawOverlays" -> result.success(Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> {
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"),
                    ))
                    result.success(null)
                }
                "showCrosshair" -> result.error(
                    "SESSION_ONLY",
                    "Overlay is activated only through Save & Launch while the game is open",
                    null,
                )
                "hideCrosshair" -> {
                    stopService(Intent(this, OverlayService::class.java))
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("OVERLAY_ERROR", e.message ?: "Unknown overlay error", null)
        }
    }

    override fun onResume() {
        super.onResume()
        eventSink?.success(ShizukuManager.getStatusMap())
    }

    override fun onDestroy() {
        sessionManager.stop()
        sessionExecutor.shutdownNow()
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }
}
