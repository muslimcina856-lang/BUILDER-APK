package com.tweakx.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Owns all session overlays. FPS is sampled from the selected app's gfxinfo
 * counters, rather than measuring TweakX's own overlay, so the number is useful
 * for game performance analysis.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.tweakx.android.action.SHOW_OVERLAY"
        const val ACTION_SHOW_SESSION = "com.tweakx.android.action.SHOW_SESSION_OVERLAY"
        const val ACTION_HIDE = "com.tweakx.android.action.HIDE_OVERLAY"
        const val EXTRA_COLOR = "color"
        const val EXTRA_SIZE = "size"
        const val EXTRA_STYLE = "style"
        const val EXTRA_PACKAGE = "package"
        const val EXTRA_SHOW_CROSSHAIR = "show_crosshair"
        const val EXTRA_SHOW_FPS = "show_fps"
        const val NOTIFICATION_CHANNEL_ID = "tweakx_overlay"
        const val NOTIFICATION_ID = 4201
    }

    private var windowManager: WindowManager? = null
    private var crosshairView: View? = null
    private var controlView: View? = null
    private var fpsView: TextView? = null
    private var crosshairVisible = true
    private var fpsExecutor: ScheduledExecutorService? = null
    private var lastFrameCount: Long? = null
    private var lastSampleTimeMs: Long? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_SESSION -> {
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundWithNotification()
                showOverlay(
                    color = intent.getIntExtra(EXTRA_COLOR, Color.GREEN),
                    sizeDp = intent.getIntExtra(EXTRA_SIZE, 48),
                    style = intent.getStringExtra(EXTRA_STYLE) ?: "cross",
                    showCrosshair = intent.getBooleanExtra(EXTRA_SHOW_CROSSHAIR, false),
                    packageName = intent.getStringExtra(EXTRA_PACKAGE),
                    showFps = intent.getBooleanExtra(EXTRA_SHOW_FPS, false),
                )
            }
            ACTION_SHOW -> {
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundWithNotification()
                showOverlay(
                    color = intent.getIntExtra(EXTRA_COLOR, Color.GREEN),
                    sizeDp = intent.getIntExtra(EXTRA_SIZE, 48),
                    style = intent.getStringExtra(EXTRA_STYLE) ?: "cross",
                    showCrosshair = true,
                    packageName = null,
                    showFps = false,
                )
            }
            ACTION_HIDE -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "TweakX game session",
                NotificationManager.IMPORTANCE_MIN,
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("TweakX game session active")
            .setContentText("Performance profile and FPS analysis are active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun showOverlay(
        color: Int,
        sizeDp: Int,
        style: String,
        showCrosshair: Boolean,
        packageName: String?,
        showFps: Boolean,
    ) {
        removeOverlay()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        crosshairVisible = true
        val density = resources.displayMetrics.density
        val sizePx = (sizeDp.coerceIn(24, 120) * density).toInt()

        if (showCrosshair) {
            val crosshair = CrosshairView(this, color, style)
            val crosshairParams = WindowManager.LayoutParams(
                sizePx,
                sizePx,
                overlayWindowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply { gravity = Gravity.CENTER }
            windowManager?.addView(crosshair, crosshairParams)
            crosshairView = crosshair
            addControlButton(density)
        }

        if (showFps && !packageName.isNullOrBlank()) {
            val fps = TextView(this).apply {
                text = "FPS  —"
                setTextColor(Color.WHITE)
                textSize = 13f
                setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
                background = GradientDrawable().apply {
                    setColor(0xCC111111.toInt())
                    cornerRadius = 10 * density
                }
            }
            val fpsParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayWindowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = (52 * density).toInt()
            }
            windowManager?.addView(fps, fpsParams)
            fpsView = fps
            startFpsSampling(packageName)
        }
    }

    private fun addControlButton(density: Float) {
        val controlSizePx = (36 * density).toInt()
        val control = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setBackgroundColor(Color.parseColor("#CC121212"))
            setPadding(controlSizePx / 5, controlSizePx / 5, controlSizePx / 5, controlSizePx / 5)
            alpha = 0.85f
        }
        val controlParams = WindowManager.LayoutParams(
            controlSizePx,
            controlSizePx,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }

        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDrag = false
        control.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = controlParams.x
                    initialY = controlParams.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) isDrag = true
                    controlParams.x = initialX + dx
                    controlParams.y = initialY + dy
                    windowManager?.updateViewLayout(control, controlParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDrag) {
                        crosshairVisible = !crosshairVisible
                        crosshairView?.visibility = if (crosshairVisible) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }
        windowManager?.addView(control, controlParams)
        controlView = control
    }

    private fun startFpsSampling(packageName: String) {
        lastFrameCount = null
        lastSampleTimeMs = null
        fpsExecutor?.shutdownNow()
        fpsExecutor = Executors.newSingleThreadScheduledExecutor().also { executor ->
            executor.scheduleWithFixedDelay({
                val result = ShizukuCommandExecutor.execute(CommandAllowlist.getGfxInfo(packageName))
                var current = parseRenderedFrames(result.stdout)
                if (current == null) {
                    val fallback = ShizukuCommandExecutor.execute(
                        CommandAllowlist.getGfxInfoSummary(packageName)
                    )
                    current = parseRenderedFrames(fallback.stdout)
                }
                val previous = lastFrameCount
                val now = SystemClock.elapsedRealtime()
                val previousTime = lastSampleTimeMs
                val elapsedMs = if (previousTime == null) 0L else now - previousTime
                val fps = if (current != null && previous != null && current >= previous && elapsedMs > 0) {
                    (((current - previous) * 1000.0) / elapsedMs)
                        .roundToInt()
                        .coerceIn(0, 240)
                } else {
                    null
                }
                lastFrameCount = current
                lastSampleTimeMs = now
                runOnMainThread {
                    fpsView?.text = if (fps == null) "FPS  —" else "FPS  $fps"
                }
            }, 500, 500, TimeUnit.MILLISECONDS)
        }
    }

    private fun parseRenderedFrames(raw: String): Long? {
        val summaryPatterns = listOf(
            Regex("Total frames rendered:\\s*(\\d+)", RegexOption.IGNORE_CASE),
            Regex("Frames rendered:\\s*(\\d+)", RegexOption.IGNORE_CASE),
        )
        for (pattern in summaryPatterns) {
            val match = pattern.find(raw) ?: continue
            return match.groupValues[1].toLongOrNull()
        }

        // `dumpsys gfxinfo <package> framestats` exposes PROFILEDATA rows.
        // Counting numeric frame rows gives a monotonic counter even when the
        // usual summary section is absent on Vulkan or OEM graphics stacks.
        val lines = raw.lineSequence().toList()
        val profileIndex = lines.indexOfFirst { it.trim().equals("PROFILEDATA", ignoreCase = true) }
        if (profileIndex < 0) return null
        var frames = 0L
        for (line in lines.drop(profileIndex + 1)) {
            val value = line.trim()
            if (value.isEmpty() || value.startsWith("Flags", ignoreCase = true)) continue
            val fields = value.split(',')
            if (fields.size >= 10 && fields.first().trim().toLongOrNull() != null) {
                frames++
            }
        }
        return frames.takeIf { it > 0 }
    }

    private fun runOnMainThread(block: () -> Unit) {
        android.os.Handler(mainLooper).post(block)
    }

    private fun removeOverlay() {
        fpsExecutor?.shutdownNow()
        fpsExecutor = null
        lastFrameCount = null
        lastSampleTimeMs = null
        try {
            crosshairView?.let { windowManager?.removeView(it) }
            controlView?.let { windowManager?.removeView(it) }
            fpsView?.let { windowManager?.removeView(it) }
        } catch (_: Throwable) {
            // Views may already be detached when the game process disappears.
        } finally {
            crosshairView = null
            controlView = null
            fpsView = null
        }
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}
