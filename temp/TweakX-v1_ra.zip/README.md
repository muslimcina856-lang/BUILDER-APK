# TweakX

**TweakX** adalah aplikasi Android untuk membuat profil performa **per game** melalui [Shizuku](https://shizuku.rikka.app/) tanpa root. Profil tidak aktif secara global: nilai perangkat dicatat saat pengguna memilih **Save & Launch**, diterapkan hanya selama game berada di foreground, lalu dipulihkan otomatis setelah game keluar.

## Fitur

| Kategori | Kemampuan |
|---|---|
| Lifecycle aman | Snapshot nilai awal, penerapan profil, pemantauan foreground, dan restore otomatis dalam satu game session native. |
| Display | Refresh rate dan brightness sementara untuk game yang dipilih. |
| Compile Booster | Full AOT compilation seluruh aplikasi terinstal melalui Shizuku sebelum game dijalankan. |
| Graphics API Override | Pilihan ANGLE/Vulkan translation atau native driver pada perangkat Android yang mendukung setting tersebut. |
| Shizuku FPS Meter | Overlay FPS real-time yang membaca counter frame `gfxinfo` game setiap detik. |
| DOZE / IDLE | Stock, Aggressive, dan Extreme idle timings yang dipulihkan setelah sesi. |
| Aim | Crosshair overlay dengan style, warna, dan ukuran yang hanya aktif saat game berjalan. |
| Device telemetry | Informasi thermal dan touch input read-only. |

> **Resolusi template** dan **DPI template** telah dihapus. Data profil lama yang masih memuat field tersebut tetap dapat dibuka dengan aman; field lama akan diabaikan.

## Prasyarat

Aplikasi memerlukan Android API 24 atau lebih baru, Shizuku yang sedang berjalan, dan izin API Shizuku untuk menerapkan command privileged. FPS Meter dan Crosshair juga memerlukan izin Android **Display over other apps**.

## Cara Pakai

1. Jalankan Shizuku, kemudian buka TweakX dan berikan izin API.
2. Tambahkan game dari daftar aplikasi yang terinstal.
3. Atur Display, Performance, serta Aim sesuai kebutuhan game.
4. Tekan **Save & Launch** dari halaman profil.
5. Mainkan game seperti biasa. TweakX melakukan cleanup setelah game tidak lagi berada di foreground secara stabil.

## Catatan Kompatibilitas

Aplikasi dapat meminta refresh rate tinggi serta konfigurasi ANGLE/native ketika perangkat mendukung command Android terkait. Namun, tidak ada API universal yang dapat menjamin FPS tertentu atau memaksa Vulkan pada semua game, chipset, dan OEM. Performa nyata tetap dipengaruhi game, driver, suhu, serta batas hardware perangkat.

Compile Booster dapat memerlukan waktu cukup lama, terutama pada penggunaan awal dan perangkat dengan banyak aplikasi. Ini berjalan melalui worker native agar UI TweakX tidak membeku.

## Validasi

Versi ini telah melewati formatter Dart, **37 unit test Flutter**, static analysis tanpa error kompilasi, dan build APK debug dengan compileSdk 36. Rincian perubahan, bug fix, serta cara pengujian tersedia di [PERUBAHAN.md](PERUBAHAN.md).

## Revisi UI dan Display Terbaru

Warna aksen UI menggunakan **#00E676**, yaitu warna hijau dominan yang dipakai pada ikon aplikasi. Halaman pembukaan kini menampilkan intro/loading animation sebelum HomeScreen.

Display menambahkan **Smallest Width** dengan preset dan input custom 240–720 dp. Nilai ini session-bound: Android menghitung density sementara untuk mencapai target logical width dan memulihkan override density sebelumnya ketika game ditutup.

FPS Meter memakai `gfxinfo framestats` dengan fallback ke ringkasan `gfxinfo`, sampling 500 ms, dan perhitungan FPS berdasarkan waktu sampel. Angka tetap bergantung pada dukungan counter grafis Android/OEM dan izin Shizuku serta overlay.
