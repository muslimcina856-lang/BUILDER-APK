# TweakX — Pembaruan Performa dan Sesi Game

Dokumen ini merangkum perubahan pada proyek TweakX. Pembaruan difokuskan pada **profil performa per game** yang hanya aktif setelah pengguna menekan **Save & Launch**, lalu dipulihkan otomatis ketika game tidak lagi menjadi aplikasi foreground.

## Ringkasan Implementasi

| Area | Perubahan |
|---|---|
| Lifecycle game | Menambahkan `GameSessionManager` native untuk mengambil snapshot nilai awal, menerapkan profil, memantau game, dan memulihkan nilai awal secara otomatis. |
| UI | Tema Material 3 diperbarui menjadi tampilan dark performance console dengan surface, input, transisi, dan kartu yang lebih konsisten. |
| Kelancaran UI | Penerapan profil dan Compile Booster dipindahkan ke executor native satu-thread agar perintah Shizuku berat tidak memblokir thread UI Flutter. |
| Stabilitas monitor | Monitor foreground memakai grace period 8 detik serta dua pengecekan keluar berturut-turut untuk mencegah reset saat transisi launch atau dialog sistem singkat. |
| Pengaturan lama | Template **Resolusi** dan **DPI** dihapus dari model, layar, service, command allowlist, dan test. Data profil lama tetap dapat dimuat; field lama akan diabaikan secara aman. |

## Fitur Baru

| Fitur | Implementasi | Perilaku saat game ditutup |
|---|---|---|
| Compile Booster | Menjalankan `cmd package compile -m speed -f --all` melalui Shizuku sebelum game diluncurkan. | Menjalankan reset kompilasi untuk mengembalikan state kompilasi sistem. Proses pertama dapat memerlukan waktu cukup lama. |
| Graphics API Override | Menggunakan selection settings Android untuk **ANGLE / Vulkan translation** atau driver native pada package game yang dipilih. | Nilai setting ANGLE sebelum sesi disimpan dan dipulihkan persis seperti semula. |
| Shizuku FPS Meter | Overlay mengambil sampel counter frame dari `dumpsys gfxinfo <package>` setiap satu detik dan menampilkan FPS real-time. | Overlay dan worker sampling dihentikan. Memerlukan izin **Display over other apps**. |
| DOZE / IDLE | Menyediakan **Stock**, **Aggressive** (sekitar 10 detik), dan **Extreme** (hampir langsung) melalui `device_idle_constants`. | Nilai konstanta Doze asli perangkat dipulihkan. |
| Refresh Rate / Brightness / Animation | Tetap tersedia sebagai profil sementara per game. | Nilai sebelum game berjalan dipulihkan, bukan dipaksa ke angka default generik. |
| Crosshair | Tidak lagi dapat dinyalakan sebagai preview di luar game. | Hanya aktif selama sesi game; service overlay dihentikan otomatis. |

> **Catatan kompatibilitas:** Sistem Android dan OEM tidak menyediakan API universal untuk menjamin game berjalan pada FPS tertentu atau memaksa Vulkan pada setiap perangkat. TweakX dapat meminta refresh rate tinggi dan memilih path ANGLE/native pada perangkat yang mendukungnya, tetapi FPS riil tetap bergantung pada game, chipset, suhu, driver, serta batas perangkat.

## Bug yang Diperbaiki

| Bug awal | Perbaikan |
|---|---|
| Event `gameClosed` telah dipancarkan oleh native, tetapi tidak ada subscriber Flutter yang melakukan reset. | Reset kini dimiliki oleh session manager native sehingga tidak bergantung pada layar Flutter tetap hidup. |
| Reset lama berpotensi memakai nilai “default” generik dan mengubah konfigurasi personal pengguna. | Snapshot disimpan untuk brightness, refresh rate, tiga animation scale, Doze, serta settings ANGLE; setiap nilai dipulihkan setelah sesi. |
| Perintah privileged berat dapat berjalan di jalur handler UI. | Launch profil diproses pada native executor, sementara hasil dikirim kembali ke UI pada main thread. |
| Deteksi foreground tunggal dapat salah membaca transisi launch atau dialog sistem sebagai game tertutup. | Ditambahkan grace period dan konfirmasi dua kali sebelum cleanup. |
| Overlay dapat menyisakan service atau menjalankan preview di luar sesi. | Lifecycle overlay terikat pada sesi game dan dihentikan dengan `stopService` pada cleanup. |

## Cara Menggunakan

1. Instal APK debug yang disertakan lalu buka TweakX.
2. Jalankan Shizuku dan berikan izin API kepada TweakX.
3. Tambahkan game, kemudian atur **Display**, **Performance**, dan **Aim**.
4. Jika menggunakan FPS Meter atau Crosshair, berikan izin **Display over other apps** pada Android Settings.
5. Tekan **Save & Launch** dari salah satu halaman profil. Konfigurasi mulai aktif hanya setelah proses launch berhasil.
6. Saat game ditutup atau berpindah ke aplikasi lain secara stabil, TweakX menghentikan overlay dan mengembalikan konfigurasi yang dicatat sebelum sesi.

## Validasi

| Pemeriksaan | Hasil |
|---|---|
| Formatter Dart | Berhasil dijalankan. |
| Unit test Flutter | **37 test lulus**. |
| Static analysis | Tidak ada error kompilasi; masih ada lint info/deprecation non-fatal dari template dan API Flutter terbaru. |
| Build Android | **Berhasil** membentuk `app-debug.apk` menggunakan compileSdk 36. |

> APK debug ditandatangani dengan konfigurasi debug dan ditujukan untuk pengujian. Gunakan keystore rilis tersendiri sebelum distribusi produksi.

## Revisi Berdasarkan Umpan Balik

| Permintaan | Implementasi |
|---|---|
| Aksen terlalu terang | Aksen utama dikembalikan ke warna ikon dominan **#00E676** dan dipakai konsisten pada theme, chip, slider, progress, serta overlay. |
| FPS hanya `FPS —` | FPS Meter kini meminta `dumpsys gfxinfo <package> framestats`, menghitung frame profile-data dengan interval 500 ms, menghitung FPS berdasarkan elapsed time, dan memakai fallback summary gfxinfo bila OEM tidak mendukung framestats. |
| Smallest Width manual/custom | Profil menyimpan `smallestWidthDp`, layar Display menyediakan preset dan input custom 240–720 dp, native menghitung density sementara berdasarkan ukuran fisik layar, lalu memulihkan override density sebelumnya setelah game selesai. |
| Intro/loading | Entry point kini membuka IntroScreen dengan animasi fade, scale, glow, linear progress, dan transisi fade menuju HomeScreen. |
| Build | Sesuai permintaan revisi, source final ini tidak dibuild ulang; pemeriksaan ringan dapat dijalankan secara manual oleh pengguna. |
