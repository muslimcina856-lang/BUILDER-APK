import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/models/game_profile.dart';

void main() {
  group('GameProfile.hasAnyCustomSetting', () {
    test('is false for a freshly added game with no settings', () {
      const profile =
          GameProfile(packageName: 'com.example.game', label: 'Game');
      expect(profile.hasAnyCustomSetting, isFalse);
    });

    test('is true when a performance field is set', () {
      const profile = GameProfile(
        packageName: 'com.example.game',
        label: 'Game',
        compileBoosterEnabled: true,
      );
      expect(profile.hasAnyCustomSetting, isTrue);
    });

    test('is true when crosshair is enabled even with no other settings', () {
      const profile = GameProfile(
        packageName: 'com.example.game',
        label: 'Game',
        crosshairEnabled: true,
      );
      expect(profile.hasAnyCustomSetting, isTrue);
    });
  });

  group('GameProfile.copyWith', () {
    const base = GameProfile(packageName: 'com.example.game', label: 'Game');

    test('sets new fields while preserving others', () {
      final profile = base.copyWith(
        refreshRateHz: 120,
        graphicsApiMode: 'angle',
        smallestWidthDp: 420,
        fpsMeterEnabled: true,
      );

      expect(profile.refreshRateHz, 120);
      expect(profile.graphicsApiMode, 'angle');
      expect(profile.smallestWidthDp, 420);
      expect(profile.fpsMeterEnabled, isTrue);
    });

    test('clears temporary values without affecting other fields', () {
      final profile = base.copyWith(
        refreshRateHz: 120,
        brightness: 200,
        animationScale: 0.5,
      );
      final cleared = profile.copyWith(
        clearRefreshRate: true,
        clearBrightness: true,
        clearAnimationScale: true,
      );

      expect(cleared.refreshRateHz, isNull);
      expect(cleared.brightness, isNull);
      expect(cleared.animationScale, isNull);
    });
  });

  group('GameProfile JSON round-trip', () {
    test('serializes and deserializes all active fields correctly', () {
      const original = GameProfile(
        packageName: 'com.tencent.ig',
        label: 'PUBG Mobile',
        iconBase64: 'AAAA',
        refreshRateHz: 90,
        brightness: 200,
        smallestWidthDp: 420,
        animationScale: 0.5,
        compileBoosterEnabled: true,
        graphicsApiMode: 'native-vulkan',
        fpsMeterEnabled: true,
        dozeMode: 'aggressive',
        crosshairEnabled: true,
        crosshairStyle: 'dot',
        crosshairColorHex: '#FF5252',
        crosshairSize: 64,
      );

      final restored = GameProfile.fromJson(original.toJson());

      expect(restored.packageName, original.packageName);
      expect(restored.label, original.label);
      expect(restored.iconBase64, original.iconBase64);
      expect(restored.refreshRateHz, original.refreshRateHz);
      expect(restored.brightness, original.brightness);
      expect(restored.smallestWidthDp, original.smallestWidthDp);
      expect(restored.animationScale, original.animationScale);
      expect(restored.compileBoosterEnabled, original.compileBoosterEnabled);
      expect(restored.graphicsApiMode, original.graphicsApiMode);
      expect(restored.fpsMeterEnabled, original.fpsMeterEnabled);
      expect(restored.dozeMode, original.dozeMode);
      expect(restored.crosshairEnabled, original.crosshairEnabled);
      expect(restored.crosshairStyle, original.crosshairStyle);
      expect(restored.crosshairColorHex, original.crosshairColorHex);
      expect(restored.crosshairSize, original.crosshairSize);
    });

    test('ignores legacy resolution and DPI fields during migration', () {
      final restored = GameProfile.fromJson({
        'packageName': 'com.example.game',
        'label': 'Legacy Game',
        'resolutionWidth': 1920,
        'resolutionHeight': 1080,
        'dpi': 400,
      });

      expect(restored.refreshRateHz, isNull);
      expect(restored.smallestWidthDp, isNull);
      expect(restored.compileBoosterEnabled, isFalse);
      expect(restored.graphicsApiMode, 'default');
      expect(restored.fpsMeterEnabled, isFalse);
      expect(restored.dozeMode, 'stock');
      expect(restored.crosshairEnabled, isFalse);
      expect(restored.hasAnyCustomSetting, isFalse);
    });
  });
}
