import 'dart:async';
import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/command_result.dart';
import '../models/game_profile.dart';

/// Flutter facade for the native game-session transaction. Native code owns
/// snapshot, apply, foreground monitoring, and exact restore.
class GameService {
  GameService._internal() {
    _gameClosedController = StreamController<String>.broadcast();
    _eventChannel.receiveBroadcastStream().listen((event) {
      final map = Map<dynamic, dynamic>.from(event as Map);
      if (map['event'] == 'gameClosed') {
        _gameClosedController.add(map['packageName'] as String? ?? '');
      }
    }, onError: (_) {});
  }

  static final GameService instance = GameService._internal();
  static const MethodChannel _channel = MethodChannel(Channels.game);
  static const EventChannel _eventChannel = EventChannel(Channels.gameEvents);

  late final StreamController<String> _gameClosedController;
  Stream<String> get onGameClosed => _gameClosedController.stream;

  Future<CommandResult> launchProfile(GameProfile profile) => _invoke(
        'launchProfile',
        profile.toJson(),
      );

  Future<void> stopSession() async {
    try {
      await _channel.invokeMethod('stopSession');
    } on PlatformException {
      // Native onDestroy also restores, so this is best-effort.
    }
  }

  Future<CommandResult> getPeakRefreshRate() => _invoke('getPeakRefreshRate');
  Future<CommandResult> setPeakRefreshRate(int hz) =>
      _invoke('setPeakRefreshRate', {'hz': hz});
  Future<CommandResult> resetPeakRefreshRate() =>
      _invoke('resetPeakRefreshRate');
  Future<CommandResult> getThermalStatus() => _invoke('getThermalStatus');
  Future<CommandResult> getTouchInfo() => _invoke('getTouchInfo');
  Future<CommandResult> getBrightness() => _invoke('getBrightness');
  Future<CommandResult> setBrightness(int value) =>
      _invoke('setBrightness', {'value': value});
  Future<CommandResult> getAnimationScale(String setting) =>
      _invoke('getAnimationScale', {'setting': setting});
  Future<CommandResult> setAnimationScale(String setting, double value) =>
      _invoke('setAnimationScale', {'setting': setting, 'value': value});

  Future<CommandResult> _invoke(
    String method, [
    Map<String, dynamic>? args,
  ]) async {
    try {
      final result = await _channel.invokeMethod(method, args);
      return CommandResult.fromMap(Map<dynamic, dynamic>.from(result as Map));
    } on PlatformException catch (e) {
      return CommandResult.failure(e.message ?? 'Platform error: $method');
    } on MissingPluginException {
      return CommandResult.failure('Native handler not available for $method');
    }
  }
}
