import 'dart:async';
import 'package:flutter/services.dart';
import '../core/constants/channels.dart';
import '../models/shizuku_status.dart';

/// Real bridge to the native Shizuku layer. No field or method here returns
/// a fabricated value — every call crosses the MethodChannel/EventChannel
/// into Kotlin, which in turn calls the real Shizuku binder API.
class ShizukuService {
  ShizukuService._internal() {
    _statusStream = _eventChannel.receiveBroadcastStream().map((event) {
      final map = Map<dynamic, dynamic>.from(event as Map);
      return ShizukuStatus.fromMap(map);
    }).handleError((error) {
      // Surface stream errors as an "unavailable" status rather than
      // crashing the listening widget tree.
    });
  }

  static final ShizukuService instance = ShizukuService._internal();

  static const MethodChannel _methodChannel = MethodChannel(Channels.shizuku);
  static const EventChannel _eventChannel =
      EventChannel(Channels.shizukuEvents);

  late final Stream<ShizukuStatus> _statusStream;

  /// Broadcast stream of real-time Shizuku status, updated on: app open,
  /// resume from background, permission change, and Shizuku service
  /// restart/disconnect — all driven by native listeners, not polling.
  Stream<ShizukuStatus> get statusStream => _statusStream;

  Future<bool> isAvailable() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('isAvailable');
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> isPermissionGranted() async {
    try {
      final result =
          await _methodChannel.invokeMethod<bool>('isPermissionGranted');
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<ShizukuStatus> getStatus() async {
    try {
      final result = await _methodChannel.invokeMethod('getStatus');
      return ShizukuStatus.fromMap(Map<dynamic, dynamic>.from(result as Map));
    } on PlatformException {
      return ShizukuStatus.initial();
    }
  }

  /// Triggers the real Shizuku permission dialog. Result arrives
  /// asynchronously through [statusStream], not as a return value here,
  /// because that's how Shizuku's own permission callback works.
  Future<String?> requestPermission() async {
    try {
      await _methodChannel.invokeMethod('requestPermission');
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Failed to request Shizuku permission';
    }
  }
}
