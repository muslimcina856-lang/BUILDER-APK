class TweakOptions {
  TweakOptions._();

  static const List<double> animationScales = [0.0, 0.5, 1.0];
  static const int brightnessMin = 0;
  static const int brightnessMax = 255;
  static const List<int> refreshRates = [60, 90, 120, 144];
  static const int smallestWidthMin = 240;
  static const int smallestWidthMax = 720;
  static const List<int> smallestWidthPresets = [
    320,
    360,
    400,
    420,
    480,
    540,
    600
  ];

  static const List<String> compileModes = [
    'default',
    'speed',
    'speed-profile',
  ];

  static const List<String> graphicsApiModes = [
    'default',
    'angle',
    'native-gles',
    'native-vulkan',
  ];

  static const List<String> dozeModes = [
    'stock',
    'aggressive',
    'extreme',
  ];

  static String compileLabel(String mode) => switch (mode) {
        'speed' => 'Full AOT',
        'speed-profile' => 'Profile + AOT',
        _ => 'System default',
      };

  static String graphicsLabel(String mode) => switch (mode) {
        'angle' => 'ANGLE / Vulkan',
        'native-gles' => 'Native GLES',
        'native-vulkan' => 'Native Vulkan',
        _ => 'System default',
      };

  static String dozeLabel(String mode) => switch (mode) {
        'aggressive' => 'Aggressive · ~10 sec',
        'extreme' => 'Extreme · almost now',
        _ => 'Stock timings',
      };
}
