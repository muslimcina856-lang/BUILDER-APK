import 'package:flutter/material.dart';
import '../../core/constants/tweak_options.dart';
import '../../core/theme/app_theme.dart';
import '../../models/game_profile.dart';
import '../../services/game_service.dart';
import '../../services/game_storage_service.dart';
import '../../widgets/tweak_card.dart';
import 'save_launch_bar.dart';

class PerformanceSettingsScreen extends StatefulWidget {
  final GameProfile profile;
  const PerformanceSettingsScreen({super.key, required this.profile});

  @override
  State<PerformanceSettingsScreen> createState() =>
      _PerformanceSettingsScreenState();
}

class _PerformanceSettingsScreenState extends State<PerformanceSettingsScreen> {
  final _service = GameService.instance;
  final _storage = GameStorageService.instance;
  late GameProfile _profile;
  bool _saving = false;
  String? _thermalInfo;
  String? _touchInfo;
  bool _loadingInfo = true;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    _loadReadOnlyInfo();
  }

  Future<void> _loadReadOnlyInfo() async {
    final thermal = await _service.getThermalStatus();
    final touch = await _service.getTouchInfo();
    if (!mounted) return;
    setState(() {
      _thermalInfo = thermal.success
          ? _summarizeThermal(thermal.stdout)
          : thermal.humanError;
      _touchInfo =
          touch.success ? 'Touch input service is active' : touch.humanError;
      _loadingInfo = false;
    });
  }

  String _summarizeThermal(String raw) {
    final match = RegExp(r'mStatus\s*=\s*(\d+)').firstMatch(raw);
    const labels = {
      '0': 'None',
      '1': 'Light',
      '2': 'Moderate',
      '3': 'Severe',
      '4': 'Critical',
      '5': 'Emergency',
      '6': 'Shutdown',
    };
    return match == null
        ? (raw.isEmpty
            ? 'No thermal data available'
            : 'Status read from device')
        : 'Current thermal level: ${labels[match.group(1)] ?? 'Unknown'}';
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (mounted) _showSnack('Performance profile saved');
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);
    final result = await _service.launchProfile(_profile);
    if (!mounted) return;
    setState(() => _saving = false);
    _showSnack(result.success
        ? '${_profile.label} launched · profile active'
        : result.humanError);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Performance')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          _SessionHint(),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.animation_outlined,
            title: 'Animation Scale',
            description:
                'Shorter system animations reduce perceived input delay',
            currentValueLabel: _profile.animationScale != null
                ? '${_profile.animationScale}x'
                : 'System default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _choice(
                    'Default',
                    _profile.animationScale == null,
                    () => setState(() => _profile =
                        _profile.copyWith(clearAnimationScale: true))),
                ...TweakOptions.animationScales.map((scale) => _choice(
                      '${scale}x',
                      _profile.animationScale == scale,
                      () => setState(() =>
                          _profile = _profile.copyWith(animationScale: scale)),
                    )),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.memory_rounded,
            title: 'Compile Booster',
            description:
                'Force full AOT compilation of every installed app for faster startup. The compilation reset runs when the game session ends.',
            currentValueLabel:
                _profile.compileBoosterEnabled ? 'Full AOT' : 'Off',
            control: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Enable full AOT for this session',
                  style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
              subtitle: const Text('May take several minutes on first launch',
                  style:
                      TextStyle(color: AppTheme.textSecondary, fontSize: 11.5)),
              value: _profile.compileBoosterEnabled,
              activeColor: AppTheme.accent,
              onChanged: (value) => setState(() =>
                  _profile = _profile.copyWith(compileBoosterEnabled: value)),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.account_tree_rounded,
            title: 'Graphics API Override',
            description:
                'Select ANGLE/Vulkan translation or the native driver for compatible apps. Android/OEM support varies.',
            currentValueLabel:
                TweakOptions.graphicsLabel(_profile.graphicsApiMode),
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.graphicsApiModes
                  .map((mode) => _choice(
                        TweakOptions.graphicsLabel(mode),
                        _profile.graphicsApiMode == mode,
                        () => setState(() => _profile =
                            _profile.copyWith(graphicsApiMode: mode)),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.monitor_heart_outlined,
            title: 'Shizuku FPS Meter',
            description:
                'Displays a real-time FPS overlay from the selected game\'s gfxinfo frame counters for lag analysis. Requires Display over other apps permission.',
            currentValueLabel: _profile.fpsMeterEnabled ? 'Overlay on' : 'Off',
            control: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Show FPS overlay while playing',
                  style: TextStyle(color: AppTheme.textPrimary, fontSize: 13)),
              value: _profile.fpsMeterEnabled,
              activeColor: AppTheme.accent,
              onChanged: (value) => setState(
                  () => _profile = _profile.copyWith(fpsMeterEnabled: value)),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.bedtime_outlined,
            title: 'DOZE / IDLE',
            description:
                'Temporary Stock, Aggressive, or Extreme idle timings. The original device constants are restored after the game closes.',
            currentValueLabel: TweakOptions.dozeLabel(_profile.dozeMode),
            control: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: TweakOptions.dozeModes
                  .map((mode) => RadioListTile<String>(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        title: Text(TweakOptions.dozeLabel(mode),
                            style: const TextStyle(
                                color: AppTheme.textPrimary, fontSize: 13)),
                        subtitle: mode == 'stock'
                            ? const Text('System default timings',
                                style: TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontSize: 11.5))
                            : Text(
                                mode == 'aggressive'
                                    ? 'Enter Doze in about 10 seconds'
                                    : 'Enter Doze almost immediately and remain idle longer',
                                style: const TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontSize: 11.5)),
                        value: mode,
                        groupValue: _profile.dozeMode,
                        activeColor: AppTheme.accent,
                        onChanged: (value) => setState(() => _profile =
                            _profile.copyWith(dozeMode: value ?? 'stock')),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.thermostat_outlined,
            title: 'Thermal Status',
            subtitle:
                'Read-only device telemetry; no universal cross-OEM thermal setter exists.',
            value: _loadingInfo ? null : _thermalInfo,
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.touch_app_outlined,
            title: 'Touch Input',
            subtitle:
                'Read-only device telemetry; no universal touch-sampling setter exists.',
            value: _loadingInfo ? null : _touchInfo,
          ),
        ],
      ),
      bottomNavigationBar: SaveLaunchBar(
        saving: _saving,
        onSave: _save,
        onSaveAndLaunch: _saveAndLaunch,
      ),
    );
  }

  Widget _choice(String label, bool selected, VoidCallback onSelected) =>
      ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onSelected(),
        selectedColor: AppTheme.accent,
        backgroundColor: AppTheme.surfaceVariant,
        labelStyle: TextStyle(
          color: selected ? Colors.black : AppTheme.textSecondary,
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
        side: BorderSide.none,
      );
}

class _SessionHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.accent.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.accent.withValues(alpha: 0.18)),
        ),
        child: const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.shield_outlined, color: AppTheme.accent, size: 18),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Profiles are transactional: apply on launch, monitor the foreground game, and restore the prior device state automatically.',
                style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12.5,
                    height: 1.35),
              ),
            ),
          ],
        ),
      );
}

class _ReadOnlyInfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? value;

  const _ReadOnlyInfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
  });

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: AppTheme.textSecondary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: const TextStyle(
                            fontSize: 11.5,
                            color: AppTheme.textSecondary,
                            height: 1.35)),
                    const SizedBox(height: 8),
                    value == null
                        ? const SizedBox(
                            height: 14,
                            width: 14,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: AppTheme.accent))
                        : Text(value!,
                            style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.accent)),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
