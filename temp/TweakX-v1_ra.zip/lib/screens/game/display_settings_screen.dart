import 'package:flutter/material.dart';
import '../../core/constants/tweak_options.dart';
import '../../core/theme/app_theme.dart';
import '../../models/game_profile.dart';
import '../../services/game_service.dart';
import '../../services/game_storage_service.dart';
import '../../widgets/tweak_card.dart';
import 'save_launch_bar.dart';

class DisplaySettingsScreen extends StatefulWidget {
  final GameProfile profile;
  const DisplaySettingsScreen({super.key, required this.profile});

  @override
  State<DisplaySettingsScreen> createState() => _DisplaySettingsScreenState();
}

class _DisplaySettingsScreenState extends State<DisplaySettingsScreen> {
  final _service = GameService.instance;
  final _storage = GameStorageService.instance;
  late GameProfile _profile;
  bool _saving = false;
  final _smallestWidthController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    if (_profile.smallestWidthDp != null) {
      _smallestWidthController.text = _profile.smallestWidthDp.toString();
    }
  }

  @override
  void dispose() {
    _smallestWidthController.dispose();
    super.dispose();
  }

  void _applySmallestWidth() {
    final value = int.tryParse(_smallestWidthController.text.trim());
    if (value == null ||
        value < TweakOptions.smallestWidthMin ||
        value > TweakOptions.smallestWidthMax) {
      _showSnack(
        'Smallest Width must be between ${TweakOptions.smallestWidthMin} and ${TweakOptions.smallestWidthMax} dp',
      );
      return;
    }
    setState(() => _profile = _profile.copyWith(smallestWidthDp: value));
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (mounted) _showSnack('Display profile saved');
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);
    final result = await _service.launchProfile(_profile);
    if (!mounted) return;
    setState(() => _saving = false);
    _showSnack(result.success
        ? '${_profile.label} launched · profile active'
        : result.humanError);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Display')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          _SessionHint(),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.speed_outlined,
            title: 'Refresh Rate / FPS',
            description:
                'Requests the highest supported display mode for this game session',
            currentValueLabel: _profile.refreshRateHz != null
                ? '${_profile.refreshRateHz} Hz'
                : 'System default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _chip(
                  label: 'Default',
                  selected: _profile.refreshRateHz == null,
                  onSelected: () => setState(() =>
                      _profile = _profile.copyWith(clearRefreshRate: true)),
                ),
                ...TweakOptions.refreshRates.map((hz) => _chip(
                      label: '${hz}Hz',
                      selected: _profile.refreshRateHz == hz,
                      onSelected: () => setState(() =>
                          _profile = _profile.copyWith(refreshRateHz: hz)),
                    )),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.aspect_ratio_outlined,
            title: 'Smallest Width',
            description:
                'Custom logical width for the game session. The app converts dp to a temporary display density and restores the prior state afterward.',
            currentValueLabel: _profile.smallestWidthDp != null
                ? '${_profile.smallestWidthDp} dp'
                : 'System default',
            control: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _chip(
                      label: 'Default',
                      selected: _profile.smallestWidthDp == null,
                      onSelected: () => setState(() {
                        _profile = _profile.copyWith(clearSmallestWidth: true);
                        _smallestWidthController.clear();
                      }),
                    ),
                    ...TweakOptions.smallestWidthPresets.map((value) => _chip(
                          label: '${value}dp',
                          selected: _profile.smallestWidthDp == value,
                          onSelected: () => setState(() {
                            _profile =
                                _profile.copyWith(smallestWidthDp: value);
                            _smallestWidthController.text = value.toString();
                          }),
                        )),
                  ],
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _smallestWidthController,
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _applySmallestWidth(),
                  decoration: InputDecoration(
                    labelText: 'Custom Smallest Width',
                    hintText:
                        '${TweakOptions.smallestWidthMin}–${TweakOptions.smallestWidthMax} dp',
                    suffixText: 'dp',
                    suffixIcon: IconButton(
                      tooltip: 'Apply custom value',
                      onPressed: _applySmallestWidth,
                      icon: const Icon(Icons.check_circle_outline_rounded),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.brightness_6_outlined,
            title: 'Brightness',
            description: 'Temporary screen brightness while the game is active',
            currentValueLabel: _profile.brightness != null
                ? '${_profile.brightness}/255'
                : 'System default',
            control: Column(
              children: [
                Slider(
                  value: (_profile.brightness ?? 128)
                      .clamp(TweakOptions.brightnessMin,
                          TweakOptions.brightnessMax)
                      .toDouble(),
                  min: TweakOptions.brightnessMin.toDouble(),
                  max: TweakOptions.brightnessMax.toDouble(),
                  onChanged: (value) => setState(() =>
                      _profile = _profile.copyWith(brightness: value.round())),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => setState(() =>
                        _profile = _profile.copyWith(clearBrightness: true)),
                    child: const Text('Use system default'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: SaveLaunchBar(
        saving: _saving,
        onSave: _save,
        onSaveAndLaunch: _saveAndLaunch,
      ),
    );
  }

  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onSelected,
  }) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onSelected(),
      selectedColor: AppTheme.accent,
      backgroundColor: AppTheme.surfaceVariant,
      labelStyle: TextStyle(
        color: selected ? Colors.black : AppTheme.textSecondary,
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
      side: BorderSide.none,
    );
  }
}

class _SessionHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.accent.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.accent.withValues(alpha: 0.18)),
        ),
        child: const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.lock_clock_rounded, color: AppTheme.accent, size: 18),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'All display changes are temporary. Save & Launch captures your current device values and restores them automatically when the game closes.',
                style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12.5,
                    height: 1.35),
              ),
            ),
          ],
        ),
      );
}
