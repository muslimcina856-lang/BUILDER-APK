import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/game_profile.dart';
import '../services/game_storage_service.dart';
import 'game/display_settings_screen.dart';
import 'game/performance_settings_screen.dart';
import 'game/aim_settings_screen.dart';

/// Top-level per-game screen. Shows a category menu (Display, Performance,
/// Aim) rather than a single long scrolling page — each category opens its
/// own dedicated screen with its own settings and its own Save & Launch
/// action, per the requested flow.
class GameDetailScreen extends StatefulWidget {
  final GameProfile profile;

  const GameDetailScreen({super.key, required this.profile});

  @override
  State<GameDetailScreen> createState() => _GameDetailScreenState();
}

class _GameDetailScreenState extends State<GameDetailScreen> {
  final _storage = GameStorageService.instance;
  late GameProfile _profile;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
  }

  Future<void> _refreshFromStorage() async {
    final games = await _storage.loadGames();
    final updated = games.where((g) => g.packageName == _profile.packageName);
    if (updated.isNotEmpty && mounted) {
      setState(() => _profile = updated.first);
    }
  }

  Future<void> _openCategory(Widget screen) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    await _refreshFromStorage();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_profile.label, overflow: TextOverflow.ellipsis),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          _GameHeader(profile: _profile),
          const SizedBox(height: 24),
          _CategoryCard(
            icon: Icons.aspect_ratio_outlined,
            title: 'Display',
            description: 'Smallest Width, refresh rate, temporary brightness',
            summary: _displaySummary(_profile),
            onTap: () => _openCategory(
              DisplaySettingsScreen(profile: _profile),
            ),
          ),
          const SizedBox(height: 12),
          _CategoryCard(
            icon: Icons.speed_outlined,
            title: 'Performance',
            description: 'AOT, graphics, Doze, FPS meter, animation',
            summary: _performanceSummary(_profile),
            onTap: () => _openCategory(
              PerformanceSettingsScreen(profile: _profile),
            ),
          ),
          const SizedBox(height: 12),
          _CategoryCard(
            icon: Icons.gps_fixed_rounded,
            title: 'Aim',
            description: 'Crosshair overlay & floating control',
            summary: _profile.crosshairEnabled
                ? 'Crosshair enabled (${_profile.crosshairStyle})'
                : 'Crosshair off',
            onTap: () => _openCategory(
              AimSettingsScreen(profile: _profile),
            ),
          ),
        ],
      ),
    );
  }

  String _displaySummary(GameProfile p) {
    final parts = <String>[];
    if (p.refreshRateHz != null) parts.add('${p.refreshRateHz}Hz');
    if (p.brightness != null) parts.add('brightness ${p.brightness}');
    if (p.smallestWidthDp != null) parts.add('SW ${p.smallestWidthDp}dp');
    return parts.isEmpty ? 'Using system defaults' : parts.join(' • ');
  }

  String _performanceSummary(GameProfile p) {
    final parts = <String>[];
    if (p.compileBoosterEnabled) parts.add('Full AOT');
    if (p.graphicsApiMode != 'default') parts.add(p.graphicsApiMode);
    if (p.fpsMeterEnabled) parts.add('FPS meter');
    if (p.dozeMode != 'stock') parts.add('${p.dozeMode} Doze');
    if (p.animationScale != null) parts.add('Animation ${p.animationScale}x');
    return parts.isEmpty ? 'Using system defaults' : parts.join(' • ');
  }
}

class _GameHeader extends StatelessWidget {
  final GameProfile profile;
  const _GameHeader({required this.profile});

  @override
  Widget build(BuildContext context) {
    Widget icon;
    if (profile.iconBase64 != null) {
      try {
        final bytes = base64Decode(profile.iconBase64!);
        icon = ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.memory(bytes, width: 56, height: 56, fit: BoxFit.cover),
        );
      } catch (_) {
        icon = _fallback();
      }
    } else {
      icon = _fallback();
    }

    return Row(
      children: [
        icon,
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                profile.label,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                profile.packageName,
                style: const TextStyle(
                  fontSize: 11.5,
                  color: AppTheme.textSecondary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _fallback() => Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.videogame_asset_outlined,
            color: AppTheme.textSecondary, size: 26),
      );
}

class _CategoryCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final String summary;
  final VoidCallback onTap;

  const _CategoryCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.summary,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: AppTheme.accent, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      summary,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.accent,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right_rounded,
                  color: AppTheme.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
