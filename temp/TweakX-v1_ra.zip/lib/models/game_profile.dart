/// A saved per-game configuration. Values are applied only for the active
/// game session and are restored to the exact pre-game device values on exit.
class GameProfile {
  final String packageName;
  final String label;
  final String? iconBase64;

  final int? refreshRateHz;
  final int? brightness;
  final int? smallestWidthDp;
  final double? animationScale;
  final bool compileBoosterEnabled;
  final String graphicsApiMode; // default, angle, native-gles, native-vulkan
  final bool fpsMeterEnabled;
  final String dozeMode; // stock, aggressive, extreme

  // Aim / crosshair settings
  final bool crosshairEnabled;
  final String crosshairStyle; // cross, dot, circle-cross
  final String crosshairColorHex;
  final int crosshairSize;

  const GameProfile({
    required this.packageName,
    required this.label,
    this.iconBase64,
    this.refreshRateHz,
    this.brightness,
    this.smallestWidthDp,
    this.animationScale,
    this.compileBoosterEnabled = false,
    this.graphicsApiMode = 'default',
    this.fpsMeterEnabled = false,
    this.dozeMode = 'stock',
    this.crosshairEnabled = false,
    this.crosshairStyle = 'cross',
    this.crosshairColorHex = '#00E676',
    this.crosshairSize = 48,
  });

  GameProfile copyWith({
    int? refreshRateHz,
    int? brightness,
    int? smallestWidthDp,
    double? animationScale,
    bool? compileBoosterEnabled,
    String? graphicsApiMode,
    bool? fpsMeterEnabled,
    String? dozeMode,
    bool? crosshairEnabled,
    String? crosshairStyle,
    String? crosshairColorHex,
    int? crosshairSize,
    bool clearRefreshRate = false,
    bool clearBrightness = false,
    bool clearSmallestWidth = false,
    bool clearAnimationScale = false,
  }) {
    return GameProfile(
      packageName: packageName,
      label: label,
      iconBase64: iconBase64,
      refreshRateHz:
          clearRefreshRate ? null : (refreshRateHz ?? this.refreshRateHz),
      brightness: clearBrightness ? null : (brightness ?? this.brightness),
      smallestWidthDp:
          clearSmallestWidth ? null : (smallestWidthDp ?? this.smallestWidthDp),
      animationScale:
          clearAnimationScale ? null : (animationScale ?? this.animationScale),
      compileBoosterEnabled:
          compileBoosterEnabled ?? this.compileBoosterEnabled,
      graphicsApiMode: graphicsApiMode ?? this.graphicsApiMode,
      fpsMeterEnabled: fpsMeterEnabled ?? this.fpsMeterEnabled,
      dozeMode: dozeMode ?? this.dozeMode,
      crosshairEnabled: crosshairEnabled ?? this.crosshairEnabled,
      crosshairStyle: crosshairStyle ?? this.crosshairStyle,
      crosshairColorHex: crosshairColorHex ?? this.crosshairColorHex,
      crosshairSize: crosshairSize ?? this.crosshairSize,
    );
  }

  Map<String, dynamic> toJson() => {
        'packageName': packageName,
        'label': label,
        'iconBase64': iconBase64,
        'refreshRateHz': refreshRateHz,
        'brightness': brightness,
        'smallestWidthDp': smallestWidthDp,
        'animationScale': animationScale,
        'compileBoosterEnabled': compileBoosterEnabled,
        'graphicsApiMode': graphicsApiMode,
        'fpsMeterEnabled': fpsMeterEnabled,
        'dozeMode': dozeMode,
        'crosshairEnabled': crosshairEnabled,
        'crosshairStyle': crosshairStyle,
        'crosshairColorHex': crosshairColorHex,
        'crosshairSize': crosshairSize,
      };

  factory GameProfile.fromJson(Map<String, dynamic> json) => GameProfile(
        packageName: json['packageName'] as String,
        label: json['label'] as String,
        iconBase64: json['iconBase64'] as String?,
        refreshRateHz: (json['refreshRateHz'] as num?)?.toInt(),
        brightness: (json['brightness'] as num?)?.toInt(),
        smallestWidthDp: (json['smallestWidthDp'] as num?)?.toInt(),
        animationScale: (json['animationScale'] as num?)?.toDouble(),
        compileBoosterEnabled: json['compileBoosterEnabled'] as bool? ?? false,
        graphicsApiMode: json['graphicsApiMode'] as String? ?? 'default',
        fpsMeterEnabled: json['fpsMeterEnabled'] as bool? ?? false,
        dozeMode: json['dozeMode'] as String? ?? 'stock',
        crosshairEnabled: json['crosshairEnabled'] as bool? ?? false,
        crosshairStyle: json['crosshairStyle'] as String? ?? 'cross',
        crosshairColorHex: json['crosshairColorHex'] as String? ?? '#00E676',
        crosshairSize: (json['crosshairSize'] as num?)?.toInt() ?? 48,
      );

  bool get hasAnyCustomSetting =>
      refreshRateHz != null ||
      brightness != null ||
      smallestWidthDp != null ||
      animationScale != null ||
      compileBoosterEnabled ||
      graphicsApiMode != 'default' ||
      fpsMeterEnabled ||
      dozeMode != 'stock' ||
      crosshairEnabled;
}
