import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  static const String keyDeviceId = 'device_id';
  static const String keyServerUrl = 'server_url';
  static const String keyLockPin = 'lock_pin';
  static const String keyLockText = 'lock_text';
  static const String keyLockHtml = 'lock_html';
  static const String keyIsLocked = 'is_locked';
  static const String keyAntiUninstall = 'anti_uninstall';

  static Future<String?> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyDeviceId);
  }

  static Future<void> setDeviceId(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyDeviceId, id);
  }

  static Future<String?> getServerUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyServerUrl);
  }

  static Future<void> setServerUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyServerUrl, url);
  }

  static Future<String?> getLockPin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyLockPin);
  }

  static Future<void> setLockPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyLockPin, pin);
  }

  static Future<String?> getLockText() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyLockText);
  }

  static Future<void> setLockText(String text) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyLockText, text);
  }

  static Future<String?> getLockHtml() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyLockHtml);
  }

  static Future<void> setLockHtml(String html) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyLockHtml, html);
  }

  static Future<bool> getIsLocked() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyIsLocked) ?? false;
  }

  static Future<void> setIsLocked(bool locked) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyIsLocked, locked);
  }

  static Future<bool> getAntiUninstall() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyAntiUninstall) ?? false;
  }

  static Future<void> setAntiUninstall(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyAntiUninstall, enabled);
  }
}