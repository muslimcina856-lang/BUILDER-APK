import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock/wakelock.dart';
import '../utils/preferences.dart';
import '../screens/lock_screen.dart';

class LockService {
  static final LockService _instance = LockService._internal();
  factory LockService() => _instance;
  LockService._internal();

  bool _isLocked = false;

  Future<void> lockDevice(String pin, String text, String html) async {
    // Simpan pin dan teks ke preferences
    await Preferences.setLockPin(pin);
    await Preferences.setLockText(text);
    await Preferences.setLockHtml(html);
    await Preferences.setIsLocked(true);
    _isLocked = true;

    // Aktifkan wakelock agar layar tetap menyala
    Wakelock.enable();

    // Tampilkan lockscreen
    // Navigasi ke LockScreen dengan fullscreen dan hindari dismiss
    // Kita akan gunakan overlay global atau navigator dengan barrier dismiss false
    // Karena ini dari service, kita perlu context dari main.
    // Kita akan set global navigator key.

    // Kirim event ke main untuk menampilkan lockscreen
    // Kita gunakan global key
    final navKey = LockService._navKey;
    if (navKey != null && navKey.currentContext != null) {
      Navigator.push(
        navKey.currentContext!,
        MaterialPageRoute(
          builder: (context) => LockScreen(pin: pin, text: text, html: html),
          settings: RouteSettings(name: '/lock'),
        ),
      );
    }
  }

  Future<void> unlockDevice() async {
    _isLocked = false;
    await Preferences.setIsLocked(false);
    Wakelock.disable();

    // Pop lockscreen
    final navKey = LockService._navKey;
    if (navKey != null && navKey.currentContext != null) {
      Navigator.popUntil(navKey.currentContext!, (route) => route.settings.name != '/lock');
    }
  }

  Future<bool> isLocked() async {
    return await Preferences.getIsLocked();
  }

  // Global navigator key
  static GlobalKey<NavigatorState>? _navKey;
  static void setNavigatorKey(GlobalKey<NavigatorState> key) {
    _navKey = key;
  }
}