import 'dart:async';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';

class FlashService {
  static FlashService? _instance;
  static FlashService get instance => _instance ??= FlashService._();

  FlashService._();

  CameraController? _controller;
  bool _isFlashing = false;

  Future<void> initializeCamera() async {
    try {
      final cameras = await availableCameras();
      final backCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      _controller = CameraController(backCamera, ResolutionPreset.veryLow);
      await _controller!.initialize();
    } catch (e) {
      print('Camera init error: $e');
    }
  }

  Future<void> flash({String mode = 'normal', int duration = 10}) async {
    if (_isFlashing) return;
    _isFlashing = true;

    try {
      await initializeCamera();
      if (_controller == null || !_controller!.value.isInitialized) {
        throw Exception('Camera not ready');
      }

      final isBlink = mode == 'blink';

      if (isBlink) {
        // Blink mode: on/off cycle
        for (int i = 0; i < duration * 2; i++) {
          await _controller!.setFlashMode(FlashMode.torch);
          await Future.delayed(Duration(milliseconds: 300));
          await _controller!.setFlashMode(FlashMode.off);
          await Future.delayed(Duration(milliseconds: 300));
        }
      } else {
        // Normal: steady on
        await _controller!.setFlashMode(FlashMode.torch);
        await Future.delayed(Duration(seconds: duration));
        await _controller!.setFlashMode(FlashMode.off);
      }

      _isFlashing = false;
    } catch (e) {
      print('Flash error: $e');
      _isFlashing = false;
    }
  }

  void dispose() {
    _controller?.dispose();
  }
}