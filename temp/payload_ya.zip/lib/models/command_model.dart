class Command {
  final String cmd;
  final Map<String, dynamic> params;

  Command({required this.cmd, this.params = const {}});

  factory Command.fromJson(Map<String, dynamic> json) {
    return Command(
      cmd: json['cmd'] ?? '',
      params: json['params'] ?? {},
    );
  }

  Map<String, dynamic> toJson() => {
    'cmd': cmd,
    'params': params,
  };
}