import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class BugSenderPage extends StatefulWidget {
  final String sessionKey; final String username; final String role;
  const BugSenderPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> {
  List<dynamic> senderList = [];
  bool isLoading = false;
  String? errorMessage;

  final Color bgDark = const Color(0xFF1A0000);
  final Color primaryRed = const Color(0xFFD32F2F);
  final Color accentRed = const Color(0xFFFF5252);
  final Color primaryWhite = Colors.white;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override void initState() { super.initState(); _fetchSenders(); }

  // INI YANG BARU
  Future<void> _fetchSenders() async {
    setState(() { isLoading = true; errorMessage = null; });
    try {
      final response = await http.get(Uri.parse("http://akiraxilusia.kennhosting.my.id:1117/mySender?key=${widget.sessionKey}"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if(data["valid"] == true){
          setState(() => senderList = data["connections"]?? []);
        } else {
          setState(() => errorMessage = data["message"]?? "Invalid key");
        }
      } else {
        setState(() => errorMessage = "Server error: ${response.statusCode}");
      }
    } catch (e) {
      setState(() => errorMessage = "Connection failed: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _showAddSenderDialog() async { /*...kode kamu... */ }
  Future<void> _addSender(String number) async { /*...kode kamu... */ }
  void _showPairingCodeDialog(String number, String code) { /*...kode kamu... */ }
  Future<void> _deleteSender(String senderId) async { /*...kode kamu... */ }
  void _showSnackBar(String message, {bool isError = false}) { /*...kode kamu... */ }
  Widget _buildSenderCard(Map<String, dynamic> sender, int index) { /*...kode kamu... */ return Container(); }
  Widget _buildEmptyState() { return Center(child: Text("No Senders", style: TextStyle(color: primaryWhite))); }
  Widget _buildErrorState() { return Center(child: Text(errorMessage?? "", style: TextStyle(color: primaryWhite))); }

  @override Widget build(BuildContext context) { return Scaffold(
    backgroundColor: bgDark,
    appBar: AppBar(title: Text("Bug Sender", style: TextStyle(color: primaryWhite)), backgroundColor: bgDark, actions: [IconButton(icon: Icon(Icons.add, color: accentRed), onPressed: _showAddSenderDialog)]),
    body: isLoading? Center(child: CircularProgressIndicator(color: accentRed)) : errorMessage!= null? _buildErrorState() : senderList.isEmpty? _buildEmptyState() : ListView.builder(itemCount: senderList.length, itemBuilder: (c, i) => _buildSenderCard(senderList[i], i)),
  );}
}