
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'info_page.dart';

class DashboardPage extends StatefulWidget {
  final String username; final String password; final String role; final String expiredDate; final String sessionKey;
  final List<Map<String, dynamic>> listBug; final List<Map<String, dynamic>> listDoos; final List<dynamic> news;
  const DashboardPage({super.key, required this.username, required this.password, required this.role, required this.expiredDate, required this.listBug, required this.listDoos, required this.sessionKey, required this.news});

  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late WebSocketChannel channel; late String sessionKey; late String username; late String role;
  late List<dynamic> newsList; int onlineUsers = 0; int activeConnections = 0; int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder(); String androidId = "unknown";

  final Color bgDark = const Color(0xFF1A1A1A);
  final Color primarySilver = const Color(0xFF757575);
  final Color accentSilver = const Color(0xFFBDBDBD); // FIX: DITAMBAH BD
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override void initState() { super.initState();
    sessionKey = widget.sessionKey; username = widget.username; role = widget.role; newsList = widget.news;
    _selectedPage = _buildNewsPage(); _initAndroidIdAndConnect();
  }

  @override void dispose() { channel.sink.close(status.goingAway); super.dispose(); }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo; androidId = deviceInfo.id; _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.VorlexzStars.my.id'));
    channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) { final data = jsonDecode(event);
      if (data['type'] == 'stats') setState(() { onlineUsers = data['onlineUsers']?? 0; activeConnections = data['activeConnections']?? 0; });
    });
  }

  Future<void> _openUrl(String url) async { await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication); }

  void _onBottomNavTapped(int index) { setState(() { _bottomNavIndex = index;
    if (index == 0) _selectedPage = _buildNewsPage();
    else if (index == 1) _selectedPage = HomePage(username: widget.username, password: widget.password, listBug: widget.listBug, role: widget.role, expiredDate: widget.expiredDate, sessionKey: sessionKey);
    else if (index == 2) _selectedPage = InfoPage(sessionKey: sessionKey);
    else if (index == 3) _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: widget.listDoos);
  });}

  void _onSidebarTabSelected(int index) { setState(() {
    if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
    else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
    else if (index == 3) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
  }); Navigator.pop(context); }

  Widget _buildNewsPage() { return SingleChildScrollView(child: Column(children: [
    Padding(padding: const EdgeInsets.all(16), child: Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: cardGlass, borderRadius: BorderRadius.circular(24), border: Border.all(color: borderGlass)), child: Row(children: [
      Expanded(child: _buildCompactInfoItem(icon: Icons.people, label: "Online", value: "$onlineUsers")),
      const SizedBox(width: 12), Expanded(child: _buildCompactInfoItem(icon: Icons.link, label: "Connections", value: "$activeConnections")),
    ]))),
    Container(height: 190, margin: const EdgeInsets.symmetric(horizontal: 16), child: PageView.builder(
      controller: PageController(viewportFraction: 0.9), itemCount: newsList.length, itemBuilder: (context, index) {
      final item = newsList[index]; return Container(margin: const EdgeInsets.symmetric(horizontal: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: cardGlass), child: ClipRRect(borderRadius: BorderRadius.circular(20), child: Stack(fit: StackFit.expand, children: [
        if (item['image']!= null) CachedNetworkImage(imageUrl: item['image'], fit: BoxFit.cover, placeholder: (context, url) => Center(child: CircularProgressIndicator(color: accentSilver))),
        Positioned(bottom: 16, left: 16, child: Text(item['title']?? 'No Title', style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)))
      ])));
    })),
    const SizedBox(height: 16),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ElevatedButton.icon(onPressed: () => _openUrl("https://t.me/Tr4dictXTeam"), icon: Icon(Icons.send, color: primaryWhite), label: Text("Join Channel", style: TextStyle(color: primaryWhite)), style: ElevatedButton.styleFrom(backgroundColor: primarySilver, minimumSize: Size(double.infinity, 50)))),
    const SizedBox(height: 16),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: ElevatedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))), icon: Icon(Icons.bug_report, color: primaryWhite), label: Text("MANAGE BUG SENDER", style: TextStyle(color: primaryWhite)), style: ElevatedButton.styleFrom(backgroundColor: accentSilver, minimumSize: Size(double.infinity, 50)))),
  ]));}

  Widget _buildCompactInfoItem({required IconData icon, required String label, required String value}) {
    return Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black.withOpacity(0.2), borderRadius: BorderRadius.circular(14)), child: Row(children: [Icon(icon, color: accentSilver), const SizedBox(width: 12), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: TextStyle(color: accentGrey)), Text(value, style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold))])]));
  }

  Widget _buildCustomDrawer() { return Drawer(backgroundColor: bgDark, child: ListView(children: [
    DrawerHeader(child: Text("Menu", style: TextStyle(color: primaryWhite, fontSize: 24))),
    ListTile(title: Text("Seller", style: TextStyle(color: primaryWhite)), onTap: () => _onSidebarTabSelected(1)),
    ListTile(title: Text("Admin", style: TextStyle(color: primaryWhite)), onTap: () => _onSidebarTabSelected(2)),
    ListTile(title: Text("Owner", style: TextStyle(color: primaryWhite)), onTap: () => _onSidebarTabSelected(3)),
  ]));}

  @override Widget build(BuildContext context) { return Scaffold(
    backgroundColor: bgDark, appBar: AppBar(backgroundColor: bgDark, title: Text("Dashboard", style: TextStyle(color: primaryWhite))), drawer: _buildCustomDrawer(),
    body: _selectedPage,
    bottomNavigationBar: BottomNavigationBar(
      currentIndex: _bottomNavIndex,
      onTap: _onBottomNavTapped,
      backgroundColor: bgDark,
      selectedItemColor: accentSilver,
      unselectedItemColor: Colors.white54,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "News"),
        BottomNavigationBarItem(icon: Icon(Icons.bug_report), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.info), label: "Info"),
        BottomNavigationBarItem(icon: Icon(Icons.build), label: "Tools"),
      ]
    ),
  );}
} 