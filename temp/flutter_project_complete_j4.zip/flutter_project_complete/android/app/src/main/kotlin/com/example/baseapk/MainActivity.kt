package com.example.slot_gcr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()