import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:slot_gcr/services/api_service.dart';

class HistoryTopupPage extends StatefulWidget {
  const HistoryTopupPage({super.key});

  @override
  State<HistoryTopupPage> createState() => _HistoryTopupPageState();
}

class _HistoryTopupPageState extends State<HistoryTopupPage> {
  List<dynamic> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final result = await ApiService.getHistoryTopup();
    setState(() {
      if (result is List) {
        _history = result;
      } else if (result.containsKey('error')) {
        _history = [];
      }
      _isLoading = false;
    });
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      return DateFormat('dd/MM/yyyy HH:mm').format(date);
    } catch (e) {
      return dateStr;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('History Top Up'),
        backgroundColor: Colors.grey,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _history.isEmpty
              ? const Center(child: Text('Belum ada history top up', style: TextStyle(color: Colors.grey)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _history.length,
                  itemBuilder: (context, index) {
                    final item = _history[index];
                    return Card(
                      color: Colors.grey,
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Colors.green,
                          child: Icon(Icons.arrow_downward, color: Colors.white),
                        ),
                        title: Text('+ Rp ${(item['amount'] ?? 0).toString()}'),
                        subtitle: Text(_formatDate(item['created_at'] ?? '')),
                        trailing: const Chip(
                          label: Text('SUKSES', style: TextStyle(color: Colors.white)),
                          backgroundColor: Colors.green,
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}