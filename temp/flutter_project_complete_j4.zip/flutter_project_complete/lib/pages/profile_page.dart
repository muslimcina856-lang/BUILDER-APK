import 'package:flutter/material.dart';
import 'package:slot_gcr/models/user_model.dart';
import 'package:slot_gcr/services/api_service.dart';

class ProfilePage extends StatefulWidget {
  final UserModel user;
  const ProfilePage({super.key, required this.user});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late UserModel _user;

  @override
  void initState() {
    super.initState();
    _user = widget.user;
  }

  void _refresh() async {
    final result = await ApiService.getProfile();
    if (result.containsKey('user_id')) {
      setState(() {
        _user = UserModel.fromJson(result);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Profil Saya'),
        backgroundColor: Colors.grey,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 24),
            CircleAvatar(
              radius: 60,
              backgroundColor: Colors.red,
              child: Text(
                _user.username[0].toUpperCase(),
                style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              _user.username,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('ID: ', style: TextStyle(color: Colors.white70)),
                  Text(_user.userId, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('ID tercopy')),
                      );
                    },
                    child: const Icon(Icons.copy, size: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            _buildInfoCard('Total Spin', _user.totalSpin.toString(), Icons.slots),
            const SizedBox(height: 12),
            _buildInfoCard('Total Win', 'Rp ${_user.totalWin.toString()}', Icons.emoji_events),
            const SizedBox(height: 12),
            _buildInfoCard('Balance', 'Rp ${_user.balance.toString()}', Icons.account_balance_wallet),
            const SizedBox(height: 12),
            if (_user.isAdmin)
              _buildInfoCard('Status', 'ADMIN', Icons.admin_panel_settings, color: Colors.red),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, IconData icon, {Color color = Colors.white}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
              Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
        ],
      ),
    );
  }
}