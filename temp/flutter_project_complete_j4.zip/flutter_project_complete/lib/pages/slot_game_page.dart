import 'dart:math';
import 'package:flutter/material.dart';
import 'package:slot_gcr/services/api_service.dart';
import 'package:slot_gcr/models/user_model.dart';
import 'package:slot_gcr/utils/constants.dart';

class SlotGamePage extends StatefulWidget {
  final UserModel user;
  const SlotGamePage({super.key, required this.user});

  @override
  State<SlotGamePage> createState() => _SlotGamePageState();
}

class _SlotGamePageState extends State<SlotGamePage> {
  List<String> reels = ['🍒', '🍒', '🍒'];
  bool isSpinning = false;
  int selectedBet = 1500;
  int currentBalance = 0;
  double currentRTP = 70;

  @override
  void initState() {
    super.initState();
    currentBalance = widget.user.balance;
  }

  Future<void> _spin() async {
    if (isSpinning) return;
    if (currentBalance < selectedBet) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saldo tidak cukup!')),
      );
      return;
    }

    setState(() {
      isSpinning = true;
      currentBalance -= selectedBet;
    });

    await Future.delayed(const Duration(milliseconds: 300));

    // Animasi reel berubah-ubah
    for (int i = 0; i < 10; i++) {
      setState(() {
        reels = [
          Constants.symbols[Random().nextInt(Constants.symbols.length)],
          Constants.symbols[Random().nextInt(Constants.symbols.length)],
          Constants.symbols[Random().nextInt(Constants.symbols.length)],
        ];
      });
      await Future.delayed(const Duration(milliseconds: 50));
    }

    // Hasil akhir dari backend
    final result = await ApiService.spin(selectedBet);
    
    if (result.containsKey('win')) {
      final winAmount = result['win'] as int;
      final newBalance = result['new_balance'] as int;
      final backendReels = result['reels'] as List?;
      
      setState(() {
        if (backendReels != null && backendReels.length == 3) {
          reels = backendReels.cast<String>();
        }
        currentBalance = newBalance;
        isSpinning = false;
        currentRTP = (result['rtp'] ?? 70).toDouble();
      });

      if (winAmount > 0) {
        _showWinDialog(winAmount);
      }
    } else {
      setState(() => isSpinning = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['error'] ?? 'Spin gagal')),
      );
    }
  }

  void _showWinDialog(int amount) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.green,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('🎉 YOU WIN! 🎉', style: TextStyle(color: Colors.white)),
        content: Text(
          'Rp $amount',
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
          textAlign: TextAlign.center,
        ),
        actions: [
          Center(
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
              child: const Text('OK', style: TextStyle(color: Colors.green)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('SLOT GAME', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.grey,
      ),
      body: Column(
        children: [
          // Balance & RTP
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('BALANCE', style: TextStyle(color: Colors.white70)),
                    Text('Rp $currentBalance', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('RTP', style: TextStyle(color: Colors.white70)),
                    Text('${currentRTP.toStringAsFixed(0)}%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.yellow)),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 40),
          
          // Slot Reels
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: reels.map((symbol) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Text(symbol, style: const TextStyle(fontSize: 48)),
                );
              }).toList(),
            ),
          ),
          
          const SizedBox(height: 40),
          
          // Spin Button
          ElevatedButton(
            onPressed: isSpinning ? null : _spin,
            style: ElevatedButton.styleFrom(
              backgroundColor: isSpinning ? Colors.grey : Colors.red,
              padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
            ),
            child: Text(
              isSpinning ? 'SPINNING...' : 'SPIN',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Bet Selector
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                const Text('BET AMOUNT', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: Constants.betOptions.map((bet) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: FilterChip(
                          label: Text('Rp $bet'),
                          selected: selectedBet == bet,
                          onSelected: (_) => setState(() => selectedBet = bet),
                          backgroundColor: Colors.grey,
                          selectedColor: Colors.red,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}