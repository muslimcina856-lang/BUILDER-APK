import 'package:flutter/material.dart';
import 'package:slot_gcr/services/api_service.dart';

class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});

  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  final _userIdController = TextEditingController();
  final _amountController = TextEditingController();
  final _oldPinController = TextEditingController();
  final _newPinController = TextEditingController();
  final _botTokenController = TextEditingController();
  final _botChatIdController = TextEditingController();
  
  double _rtp = 70;
  List<dynamic> _users = [];
  bool _isLoading = true;
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await _loadRTP();
    await _loadUsers();
    setState(() => _isLoading = false);
  }

  Future<void> _loadRTP() async {
    // RTP diambil dari backend via endpoint khusus
    // Sementara pakai default
  }

  Future<void> _loadUsers() async {
    final result = await ApiService.adminGetUsers();
    setState(() => _users = result);
  }

  Future<void> _topUp() async {
    if (_userIdController.text.isEmpty || _amountController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi User ID dan jumlah')),
      );
      return;
    }
    
    final result = await ApiService.adminTopup(
      _userIdController.text,
      int.parse(_amountController.text),
    );
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result['message'] ?? 'Top up berhasil')),
    );
    _userIdController.clear();
    _amountController.clear();
    _loadUsers();
  }

  Future<void> _updateRTP() async {
    await ApiService.adminSetRTP(_rtp);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('RTP updated')),
    );
  }

  Future<void> _banUser(String userId) async {
    await ApiService.adminBanUser(userId);
    _loadUsers();
  }

  Future<void> _unbanUser(String userId) async {
    await ApiService.adminUnbanUser(userId);
    _loadUsers();
  }

  Future<void> _changePin() async {
    if (_oldPinController.text.isEmpty || _newPinController.text.isEmpty) return;
    final result = await ApiService.adminChangePin(_oldPinController.text, _newPinController.text);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result['message'] ?? 'PIN changed')),
    );
    _oldPinController.clear();
    _newPinController.clear();
  }

  Future<void> _saveBotSetting() async {
    await ApiService.adminSetBotSetting(_botTokenController.text, _botChatIdController.text);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Bot settings saved')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('ADMIN PANEL', style: TextStyle(color: Colors.red)),
        backgroundColor: Colors.grey,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                TabBar(
                  onTap: (index) => setState(() => _selectedTab = index),
                  tabs: const [
                    Tab(text: 'TOP UP', icon: Icon(Icons.upload)),
                    Tab(text: 'RTP', icon: Icon(Icons.percent)),
                    Tab(text: 'USERS', icon: Icon(Icons.people)),
                    Tab(text: 'SETTINGS', icon: Icon(Icons.settings)),
                  ],
                ),
                Expanded(
                  child: IndexedStack(
                    index: _selectedTab,
                    children: [
                      _buildTopUpTab(),
                      _buildRTPTab(),
                      _buildUsersTab(),
                      _buildSettingsTab(),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildTopUpTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            color: Colors.grey,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('TOP UP USER', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _userIdController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'User ID (6 digit angka)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _amountController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Jumlah Coin',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _topUp,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    child: const Text('TOP UP', style: TextStyle(fontSize: 16)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRTPTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Card(
        color: Colors.grey,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const Text('RTP CONTROL', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Text('${_rtp.toStringAsFixed(0)}%', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: Colors.yellow)),
              Slider(
                value: _rtp,
                min: 1,
                max: 98,
                divisions: 97,
                onChanged: (v) => setState(() => _rtp = v),
                onChangeEnd: (_) => _updateRTP(),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text('1% (SUSAH)', style: TextStyle(color: Colors.red)),
                  Text('50% (NORMAL)', style: TextStyle(color: Colors.orange)),
                  Text('98% (GAMPANG)', style: TextStyle(color: Colors.green)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUsersTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _users.length,
      itemBuilder: (context, index) {
        final user = _users[index];
        final isBanned = user['is_banned'] == true;
        return Card(
          color: Colors.grey,
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isBanned ? Colors.red : Colors.green,
              child: Text(user['username'][0].toUpperCase()),
            ),
            title: Text('${user['username']} (${user['user_id']})'),
            subtitle: Text('Saldo: Rp ${user['balance']}'),
            trailing: isBanned
                ? ElevatedButton(
                    onPressed: () => _unbanUser(user['user_id']),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    child: const Text('UNBAN'),
                  )
                : ElevatedButton(
                    onPressed: () => _banUser(user['user_id']),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('BAN'),
                  ),
          ),
        );
      },
    );
  }

  Widget _buildSettingsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            color: Colors.grey,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('TELEGRAM BOT', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _botTokenController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'Bot Token'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _botChatIdController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'Chat ID'),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _saveBotSetting,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                    child: const Text('SAVE BOT SETTING'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            color: Colors.grey,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('UBAH PIN ADMIN', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _oldPinController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'PIN Lama'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _newPinController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'PIN Baru (4-6 digit)'),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _changePin,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                    child: const Text('GANTI PIN'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}