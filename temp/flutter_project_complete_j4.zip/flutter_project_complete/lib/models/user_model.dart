class UserModel {
  final String userId;
  final String username;
  final int balance;
  final int totalSpin;
  final int totalWin;
  final bool isAdmin;
  final bool isBanned;

  UserModel({
    required this.userId,
    required this.username,
    required this.balance,
    required this.totalSpin,
    required this.totalWin,
    required this.isAdmin,
    required this.isBanned,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      userId: json['user_id']?.toString() ?? '',
      username: json['username'] ?? '',
      balance: json['balance'] ?? 0,
      totalSpin: json['total_spin'] ?? 0,
      totalWin: json['total_win'] ?? 0,
      isAdmin: json['is_admin'] ?? false,
      isBanned: json['is_banned'] ?? false,
    );
  }
}