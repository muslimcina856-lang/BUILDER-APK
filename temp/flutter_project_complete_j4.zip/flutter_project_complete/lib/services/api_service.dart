import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // GANTI DENGAN DOMAIN PTERODACTYL LU!
  static const String baseUrl = 'http://zahrazx.perzxlystore.my.id:2004';
  
  static Future<Map<String, String>> _getHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }
  
  static Future<Map<String, dynamic>> post(String endpoint, Map<String, dynamic> data, {bool needAuth = true}) async {
    try {
      final headers = needAuth ? await _getHeaders() : {'Content-Type': 'application/json'};
      final response = await http.post(
        Uri.parse('$baseUrl$endpoint'),
        headers: headers,
        body: jsonEncode(data),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'error': 'Connection failed'};
    }
  }
  
  static Future<Map<String, dynamic>> get(String endpoint) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$endpoint'),
        headers: await _getHeaders(),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'error': 'Connection failed'};
    }
  }
  
  static Future<Map<String, dynamic>> put(String endpoint, Map<String, dynamic> data) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl$endpoint'),
        headers: await _getHeaders(),
        body: jsonEncode(data),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'error': 'Connection failed'};
    }
  }
  
  static Future<void> setToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
  }
  
  static Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }
  
  // AUTH
  static Future<Map<String, dynamic>> register(String username, String password) async {
    return await post('/register', {'username': username, 'password': password}, needAuth: false);
  }
  
  static Future<Map<String, dynamic>> login(String username, String password) async {
    return await post('/login', {'username': username, 'password': password}, needAuth: false);
  }
  
  // USER
  static Future<Map<String, dynamic>> getProfile() async {
    return await get('/profile');
  }
  
  static Future<Map<String, dynamic>> spin(int bet) async {
    return await post('/spin', {'bet': bet});
  }
  
  static Future<Map<String, dynamic>> getHistoryTopup() async {
    return await get('/history/topup');
  }
  
  static Future<List<dynamic>> getLeaderboard() async {
    final result = await get('/leaderboard');
    if (result is List) return result;
    return [];
  }
  
  // ADMIN
  static Future<Map<String, dynamic>> adminTopup(String userId, int amount) async {
    return await post('/admin/topup', {'userId': userId, 'amount': amount});
  }
  
  static Future<Map<String, dynamic>> adminSetRTP(double rtp) async {
    return await put('/admin/rtp', {'rtp': rtp});
  }
  
  static Future<List<dynamic>> adminGetUsers() async {
    final result = await get('/admin/users');
    if (result is List) return result;
    return [];
  }
  
  static Future<Map<String, dynamic>> adminBanUser(String userId) async {
    return await put('/admin/ban/$userId', {});
  }
  
  static Future<Map<String, dynamic>> adminUnbanUser(String userId) async {
    return await put('/admin/unban/$userId', {});
  }
  
  static Future<Map<String, dynamic>> adminChangePin(String oldPin, String newPin) async {
    return await put('/admin/pin', {'oldPin': oldPin, 'newPin': newPin});
  }
  
  static Future<Map<String, dynamic>> adminSetBotSetting(String botToken, String botChatId) async {
    return await post('/admin/bot/setting', {'botToken': botToken, 'botChatId': botChatId});
  }
}