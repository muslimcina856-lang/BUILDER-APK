class Constants {
  static const List<String> symbols = ['🍒', '🍋', '🍊', '🍉', '⭐', '💎', '👑'];
  static const List<int> betOptions = [500, 1000, 1500, 2000, 2500, 5000, 10000];
  
  // Admin PIN default
  static const String defaultAdminPin = '1717';
}