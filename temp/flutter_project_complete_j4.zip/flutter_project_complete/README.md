# Flutter Base APK Complete

Project sudah include:
- Android
- iOS
- Assets
- Widgets
- Screens
- Gradle
- Kotlin MainActivity

Command:
flutter pub get
flutter run
flutter build apk
