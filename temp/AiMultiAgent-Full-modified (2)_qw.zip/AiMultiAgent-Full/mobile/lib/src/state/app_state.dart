import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import '../services/agent_runtime.dart';
import '../services/attachment_service.dart';
import '../services/automation_service.dart';
import '../services/browser_session_service.dart';
import '../services/linux_workspace_service.dart';
import '../services/local_database.dart';
import '../services/mcp_service.dart';
import '../services/permission_manager.dart';
import '../services/platform_bridge_service.dart';
import '../services/provider_service.dart';
import '../services/provider_model_policy.dart';
import '../services/secure_vault.dart';
import '../services/skill_service.dart';
import '../services/terminal_service.dart';
import '../services/tool_engine.dart';

class AppState extends ChangeNotifier with WidgetsBindingObserver {
  AppState() {
    WidgetsBinding.instance.addObserver(this);
    browserSession.addListener(_notifyFromBrowser);
  }

  static const _uuid = Uuid();

  final LocalDatabase database = LocalDatabase();
  final SecureVault vault = SecureVault();
  final ProviderService providerService = ProviderService();
  final BrowserSessionService browserSession = BrowserSessionService();
  final TerminalService terminalService = TerminalService();
  final McpService mcpService = McpService();
  final AttachmentService attachmentService = AttachmentService();
  final PlatformBridgeService platformBridge = PlatformBridgeService();

  late final SkillService skillService = SkillService(database);
  late final ToolEngine toolEngine = ToolEngine(
        database,
        browserSession: browserSession,
        terminalService: terminalService,
        skillService: skillService,
        mcpService: mcpService,
        platformBridge: platformBridge,
        providerService: providerService,
      );
  late final PermissionManager permissionManager =
      PermissionManager(database)..onChanged = notifyListeners;
  late final AutomationService automationService = AutomationService(database);
  late final AgentRuntime runtime = AgentRuntime(
        providerService: providerService,
        toolEngine: toolEngine,
        permissionManager: permissionManager,
        database: database,
      );

  bool initialized = false;
  bool isSending = false;
  /// Lalai MATI — user mesti tick + notifikasi + bateri.
  bool backgroundExecutionAllowed = false;
  /// true bila app tidak di foreground (paused/hidden/detached).
  bool appInBackground = false;
  RunStatus runStatus = RunStatus.idle;
  String runDetail = '';

  static const int _notifIdWorking = 71001;
  static const int _notifIdDone = 71002;
  static const int _notifIdNeedUser = 71003;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  int selectedTab = 0;
  String sessionId = _uuid.v4();
  String selectedProviderId = '';
  String selectedAgentId = 'orchestrator';
  DateTime lastActivityAt = DateTime.now();
  DateTime? runStartedAt;

  /// Skop konsol per mesej/turn. Turn baru = timestamp baru → konsol turn lama hilang.
  DateTime? terminalScopeStartedAt;

  List<ProviderConfig> providers = <ProviderConfig>[];
  List<AgentProfile> agents = <AgentProfile>[];
  List<SkillDefinition> skills = <SkillDefinition>[];
  List<AutomationDefinition> automations = <AutomationDefinition>[];
  List<McpServerConfig> mcpServers = <McpServerConfig>[];
  String userNickname = '';
  String customInstructions = '';
  List<ChatMessage> messages = <ChatMessage>[];
  List<RunEvent> currentRunEvents = <RunEvent>[];
  final List<ChatAttachment> pendingAttachments = <ChatAttachment>[];
  /// Mesej susulan yang dihantar semasa AI masih bekerja.
  final List<String> followUpQueue = <String>[];
  String sessionNotice = '';

  Timer? _inactivityTimer;
  Timer? _backgroundLimitTimer;
  RunControl? _runControl;
  DateTime _lastPersistedActivity = DateTime.fromMillisecondsSinceEpoch(0);

  PermissionRequest? get pendingPermission => permissionManager.pending;
  ProviderConfig? get selectedProvider => _providerById(selectedProviderId);
  AgentProfile get selectedAgent => agents.firstWhere(
        (item) => item.id == selectedAgentId,
        orElse: () => rootAgent,
      );
  AgentProfile get rootAgent => agents.firstWhere(
        (item) => item.id == 'orchestrator',
        orElse: () => _builtInAgents().first,
      );
  bool get hasProvider => providers.isNotEmpty;
  bool get sessionAllowsAllRisky =>
      permissionManager.allowAllRiskyForSession;
  List<RunEvent> get activeRunEvents =>
      List<RunEvent>.unmodifiable(currentRunEvents);

  void _notifyFromBrowser() => notifyListeners();

  Future<void> initialize() async {
    _inactivityTimer?.cancel();
    await permissionManager.initialize();
    agents = await _loadAgents();
    skills = await skillService.loadSkills();
    final storedProviders = (await database.listObjects('provider'))
        .map(ProviderConfig.fromJson)
        .toList();
    providers = <ProviderConfig>[];
    for (final stored in storedProviders) {
      final migrated = ProviderModelPolicy.migrateStoredProvider(stored);
      providers.add(migrated);
      if (migrated.toJson().toString() != stored.toJson().toString()) {
        await database.saveObject('provider', migrated.id, migrated.toJson());
      }
    }
    automations = await automationService.load();
    mcpServers = (await database.listObjects('mcp_server'))
        .map(McpServerConfig.fromJson)
        .toList();

    selectedProviderId = await database.getSetting('selectedProviderId') ??
        (providers.isEmpty ? '' : providers.first.id);
    if (_providerById(selectedProviderId) == null && providers.isNotEmpty) {
      selectedProviderId = providers.first.id;
      await database.setSetting('selectedProviderId', selectedProviderId);
    }
    selectedAgentId =
        await database.getSetting('selectedAgentId') ?? 'orchestrator';
    if (!agents.any((item) => item.id == selectedAgentId)) {
      selectedAgentId = 'orchestrator';
      await database.setSetting('selectedAgentId', selectedAgentId);
    }
    final storedBackgroundExecution =
        await database.getSetting('backgroundExecutionAllowed');
    // Default baru: false. Install lama tanpa key juga dianggap mati.
    backgroundExecutionAllowed = storedBackgroundExecution == 'true';
    if (storedBackgroundExecution == null) {
      await database.setSetting('backgroundExecutionAllowed', 'false');
    }

    // Sesi kekal merentas tutup/buka app. Sesi baru HANYA bila user tekan "Chat baru".
    final storedSession = await database.getSetting('activeSessionId');
    if (storedSession == null || storedSession.isEmpty) {
      sessionId = _uuid.v4();
      await database.setSetting('activeSessionId', sessionId);
    } else {
      sessionId = storedSession;
    }

    lastActivityAt = DateTime.now();
    await database.setSetting('lastLifecycleState', 'foreground');
    await _persistActivity(force: true);
    await _applyChatHistoryRetention();
    messages = await database.listMessages(sessionId);

    selectedTab = int.tryParse(
          await database.getSetting('selectedTab') ?? '0',
        ) ??
        0;
    selectedTab = selectedTab.clamp(0, 4).toInt();
    userNickname = await database.getSetting('userNickname') ?? '';
    customInstructions = await database.getSetting('customInstructions') ?? '';

    initialized = true;
    notifyListeners();
    if (AppConfig.isFullEdition) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
      });
    }
  }



  void recordActivity() {
    lastActivityAt = DateTime.now();
    unawaited(_persistActivity());
  }

  Future<void> _persistActivity({bool force = false}) async {
    if (!force &&
        DateTime.now().difference(_lastPersistedActivity) <
            const Duration(seconds: 15)) {
      return;
    }
    _lastPersistedActivity = DateTime.now();
    await database.setSetting(
      'lastActivityAt',
      lastActivityAt.toIso8601String(),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!initialized) return;
    if (state == AppLifecycleState.resumed) {
      appInBackground = false;
      // Dalam app: tiada notif kerja + henti FGS (wajib notif hanya bila latar).
      unawaited(_cancelAgentNotifications());
      // Automasi aktif: jangan matikan FGS bila masuk app.
      unawaited(_syncBackgroundKeepAlive());
      unawaited(database.setSetting('lastLifecycleState', 'foreground'));
      recordActivity();
      return;
    }
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      appInBackground = true;
      unawaited(database.setSetting('lastLifecycleState', 'background'));
      unawaited(_persistActivity(force: true));
      if (isSending || hasActiveAutomation) {
        unawaited(_syncBackgroundKeepAlive());
        if (isSending &&
            backgroundExecutionAllowed &&
            !hasActiveAutomation) {
          _backgroundLimitTimer?.cancel();
          _backgroundLimitTimer = Timer(
            AppConfig.backgroundExecutionLimit,
            _stopRunAfterBackgroundLimit,
          );
        }
      }
    }
  }

  DateTime? _lastLiveNotifAt;
  String _lastLiveNotifText = '';

  Future<void> _updateLiveWorkingNotification(String raw) async {
    if (!appInBackground || !isSending) return;
    var text = raw
        .replaceAll(RegExp(r'[#*_`]+'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (text.isEmpty) text = runDetail.isEmpty ? 'Tugasan AI aktif.' : runDetail;
    if (text.length > 280) text = '${text.substring(0, 280)}…';
    final now = DateTime.now();
    if (_lastLiveNotifText == text &&
        _lastLiveNotifAt != null &&
        now.difference(_lastLiveNotifAt!) < const Duration(milliseconds: 350)) {
      return;
    }
    _lastLiveNotifText = text;
    _lastLiveNotifAt = now;
    await platformBridge.updateExecutionKeepAlive(
      title: 'Ai MultiAgent sedang bekerja',
      text: text,
    );
  }

  /// Notifikasi agent: HANYA bila app di latar belakang.
  Future<void> _showAgentNotification({
    required int id,
    required String title,
    required String body,
    bool ongoing = false,
    String channelId = 'agent_events',
    String channelName = 'Status agent',
  }) async {
    if (!appInBackground) return;
    // Perlu kebenaran notifikasi sistem; jika mati, diam sahaja.
    try {
      final android = _notifications.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final enabled = await android?.areNotificationsEnabled() ?? true;
      if (!enabled) return;

      final details = AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription: 'Notifikasi hanya bila anda keluar dari aplikasi',
        importance: ongoing ? Importance.low : Importance.high,
        priority: ongoing ? Priority.low : Priority.high,
        ongoing: ongoing,
        autoCancel: !ongoing,
        onlyAlertOnce: ongoing,
      );
      await _notifications.show(
        id,
        title,
        body.length > 200 ? '${body.substring(0, 200)}…' : body,
        NotificationDetails(android: details),
      );
    } catch (_) {}
  }

  Future<void> _cancelAgentNotifications() async {
    try {
      await _notifications.cancel(_notifIdWorking);
      // Done / need-user dibiarkan sehingga user buka atau dismiss.
    } catch (_) {}
  }

  Future<void> _notifyAgentFinished({
    required bool success,
    required String summary,
  }) async {
    await _notifications.cancel(_notifIdWorking);
    if (!appInBackground) return;
    await _showAgentNotification(
      id: _notifIdDone,
      title: success ? 'Jawapan AI siap' : 'Tugasan AI gagal',
      body: summary.isEmpty
          ? (success ? 'Buka app untuk baca jawapan.' : 'Semak ralat dalam chat.')
          : summary,
      ongoing: false,
      channelId: 'agent_done',
      channelName: 'Agent selesai',
    );
  }

  Future<void> _notifyNeedsUser(String reason) async {
    if (!appInBackground) return;
    await _showAgentNotification(
      id: _notifIdNeedUser,
      title: 'AI perlukan interaksi anda',
      body: reason,
      ongoing: false,
      channelId: 'agent_need_user',
      channelName: 'Perlu interaksi',
    );
  }

  void selectTab(int value) {
    recordActivity();
    selectedTab = value.clamp(0, 4).toInt();
    unawaited(database.setSetting('selectedTab', selectedTab.toString()));
    notifyListeners();
  }

  Future<void> selectProvider(String id) async {
    recordActivity();
    selectedProviderId = id;
    await database.setSetting('selectedProviderId', id);
    notifyListeners();
  }

  Future<void> selectAgent(String id) async {
    recordActivity();
    selectedAgentId = id;
    await database.setSetting('selectedAgentId', id);
    notifyListeners();
  }

  Future<void> setBackgroundExecutionAllowed(bool value) async {
    backgroundExecutionAllowed = value;
    await database.setSetting('backgroundExecutionAllowed', value.toString());
    await _syncBackgroundKeepAlive();
    notifyListeners();
  }

  void _stopRunAfterBackgroundLimit() {
    if (!isSending) return;
    _runControl?.cancel();
    unawaited(_haltSideEffects());
    runStatus = RunStatus.cancelled;
    runDetail = 'Had 30 minit latar belakang dicapai';
    _upsertRunEvent(
      RunEvent(
        id: 'background-limit',
        title: 'Had latar belakang dicapai',
        detail: 'Tugasan dihentikan selepas 30 minit aktif di latar belakang.',
        state: RunEventState.info,
        createdAt: DateTime.now(),
      ),
    );
  }

  ProviderConfig createProviderFromPreset(ProviderPreset preset) {
    return ProviderConfig(
      id: _uuid.v4(),
      name: preset.name,
      presetId: preset.id,
      protocol: preset.protocol,
      baseUrl: preset.baseUrl,
      chatPath: preset.chatPath,
      modelsPath: preset.modelsPath,
      authStyle: preset.authStyle,
      apiKeyHeader: preset.apiKeyHeader,
      apiKeyPrefix: preset.apiKeyPrefix,
      model: preset.defaultModels.isEmpty ? '' : preset.defaultModels.first,
      availableModels: preset.defaultModels,
      extraHeaders: preset.defaultHeaders,
      supportsStreaming: true,
      supportsTools: true,
      supportsVision: preset.id == 'gemini' ||
          preset.id == 'openai' ||
          preset.id == 'openai_chat' ||
          preset.id == 'mimo',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  Future<void> saveProvider(
    ProviderConfig provider, {
    String? apiKey,
  }) async {
    final normalizedProvider =
        ProviderModelPolicy.migrateStoredProvider(provider);
    final index =
        providers.indexWhere((item) => item.id == normalizedProvider.id);
    if (index < 0) {
      providers.insert(0, normalizedProvider);
    } else {
      providers[index] = normalizedProvider;
    }
    await database.saveObject(
      'provider',
      normalizedProvider.id,
      normalizedProvider.toJson(),
    );
    if (apiKey != null) {
      await vault.writeProviderKey(normalizedProvider.id, apiKey);
    }
    if (selectedProviderId.isEmpty) {
      await selectProvider(normalizedProvider.id);
    }
    notifyListeners();
  }

  Future<void> updateProviderModel(
    ProviderConfig provider,
    String model,
  ) async {
    final normalized = model.trim();
    if (normalized.isEmpty) return;
    final available = <String>{...provider.availableModels, normalized}.toList()
      ..sort();
    await saveProvider(
      provider.copyWith(
        model: normalized,
        availableModels: available,
        updatedAt: DateTime.now(),
      ),
    );
  }

  Future<void> updateSelectedModel(String model) async {
    final provider = selectedProvider;
    if (provider == null) return;
    await updateProviderModel(provider, model);
  }

  Future<String> providerKey(String providerId) =>
      vault.readProviderKey(providerId);

  Future<void> deleteProvider(ProviderConfig provider) async {
    providers.removeWhere((item) => item.id == provider.id);
    await database.deleteObject('provider', provider.id);
    await vault.deleteProviderKey(provider.id);
    if (selectedProviderId == provider.id) {
      selectedProviderId = providers.isEmpty ? '' : providers.first.id;
      await database.setSetting('selectedProviderId', selectedProviderId);
    }
    notifyListeners();
  }

  Future<List<String>> refreshModels(
    ProviderConfig provider,
    String key,
  ) =>
      providerService.listChatModels(provider, key);

  List<String> chatModelsFor(ProviderConfig provider) {
    final models = providerService.cachedChatModels(provider);
    if (models.isNotEmpty) return models;
    if (provider.model.trim().isEmpty) return const <String>[];
    return ProviderModelPolicy.isChatModel(provider, provider.model)
        ? <String>[provider.model]
        : const <String>[];
  }

  Future<ProviderTestResult> testProvider(
    ProviderConfig provider,
    String key,
  ) {
    final testing = provider.copyWith(
      testStatus: ProviderTestStatus.testing,
      lastTestMessage: 'Menguji sambungan…',
    );
    return providerService.test(testing, key);
  }

  Future<void> pickAttachments() async {
    recordActivity();
    final imported = await attachmentService.pickAndImport(sessionId);
    if (imported.isEmpty) return;
    pendingAttachments.addAll(imported);
    notifyListeners();
  }

  Future<void> addPastedText(String text) async {
    recordActivity();
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    final item = await attachmentService.importPastedText(
      sessionId: sessionId,
      text: trimmed,
    );
    pendingAttachments.add(item);
    notifyListeners();
  }

  Future<void> removePendingAttachment(ChatAttachment attachment) async {
    pendingAttachments.removeWhere((item) => item.id == attachment.id);
    await attachmentService.delete(attachment);
    notifyListeners();
  }

  Future<void> sendMessage(
    String value, {
    List<ChatAttachment> attachments = const <ChatAttachment>[],
  }) async {
    recordActivity();
    final text = value.trim();
    final outgoingAttachments = attachments.isNotEmpty
        ? List<ChatAttachment>.from(attachments)
        : List<ChatAttachment>.from(pendingAttachments);
    if (text.isEmpty && outgoingAttachments.isEmpty) return;
    if (outgoingAttachments.isNotEmpty) {
      unawaited(attachmentService.mirrorIntoWorkspace(outgoingAttachments));
    }

    // Semasa AI masih bekerja, mesej baharu masuk barisan susulan.
    if (isSending) {
      if (text.isNotEmpty) {
        followUpQueue.add(text);
        notifyListeners();
      }
      return;
    }

    final configuredProvider = selectedProvider;
    if (configuredProvider == null) {
      runStatus = RunStatus.failed;
      runDetail = 'Tambah dan pilih provider terlebih dahulu.';
      notifyListeners();
      return;
    }
    var activeProvider = configuredProvider;
    if (activeProvider.model.trim().isEmpty) {
      runStatus = RunStatus.failed;
      runDetail = 'Pilih model untuk provider ${activeProvider.name}.';
      notifyListeners();
      return;
    }

    final apiKey = await vault.readProviderKey(activeProvider.id);
    if (activeProvider.authStyle != AuthStyle.none && apiKey.isEmpty) {
      runStatus = RunStatus.failed;
      runDetail = 'API key provider belum disimpan.';
      notifyListeners();
      return;
    }

    final history = List<ChatMessage>.from(messages);
    final userMessage = ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.user,
      content: text,
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{
        if (outgoingAttachments.isNotEmpty)
          'attachments': outgoingAttachments.map((item) => item.toJson()).toList(),
      },
    );
    messages.add(userMessage);
    await database.saveMessage(userMessage);
    pendingAttachments.clear();
    sessionNotice = '';

    isSending = true;
    _runControl = RunControl();
    runStatus = RunStatus.planning;
    runDetail = outgoingAttachments.isEmpty
        ? 'Menunggu jawapan model…'
        : 'Menghantar ${outgoingAttachments.length} lampiran + menunggu model…';
    runStartedAt = DateTime.now();
    terminalScopeStartedAt = runStartedAt;
    currentRunEvents = <RunEvent>[
      RunEvent(
        id: 'plan-0',
        title: 'Orchestrator',
        detail: runDetail,
        state: RunEventState.running,
        createdAt: DateTime.now(),
        agentRole: rootAgent.name,
      ),
    ];
    notifyListeners();

    try {
      // FGS + notif hanya bila app sudah di latar. Dalam app: jangan tunjuk notif.
      if (backgroundExecutionAllowed && appInBackground) {
        await platformBridge.startExecutionKeepAlive();
      }
      Future<ChatMessage> execute() => runtime.run(
            sessionId: sessionId,
            provider: activeProvider,
            apiKey: apiKey,
            agent: rootAgent,
            agents: agents,
            providers: providers,
            apiKeyResolver: vault.readProviderKey,
            skills: skills,
            history: history,
            userInput: text,
            userAttachments: outgoingAttachments,
            control: _runControl,
            onProgress: (status, detail) {
              runStatus = status;
              runDetail = detail;
              notifyListeners();
              // Hanya bila keluar app: notif “perlu interaksi” / status kerja.
              if (appInBackground) {
                if (status == RunStatus.waitingPermission) {
                  unawaited(
                    _notifyNeedsUser(
                      detail.isNotEmpty
                          ? detail
                          : 'Agent menunggu tindakan anda.',
                    ),
                  );
                }
                unawaited(_updateLiveWorkingNotification(detail));
              }
            },
            onEvent: _upsertRunEvent,
          );

      ChatMessage assistant;
      try {
        assistant = await execute();
      } catch (firstError) {
        if (!providerService.isModelUnavailableError(firstError)) rethrow;
        final fallback = await providerService.resolveFallbackModel(
          activeProvider,
          apiKey,
          exclude: activeProvider.model,
        );
        if (fallback == null || fallback == activeProvider.model) rethrow;

        final previousModel = activeProvider.model;
        activeProvider = activeProvider.copyWith(
          model: fallback,
          availableModels: <String>{
            ...providerService.cachedChatModels(activeProvider),
            fallback,
          }.toList(),
          testStatus: ProviderTestStatus.untested,
          lastTestMessage:
              'Model $previousModel tidak tersedia. Bertukar automatik kepada $fallback.',
          updatedAt: DateTime.now(),
        );
        await saveProvider(activeProvider);
        _upsertRunEvent(
          RunEvent(
            id: 'model-fallback',
            title: 'Menukar model',
            detail: '$previousModel tidak tersedia · menggunakan $fallback',
            state: RunEventState.info,
            createdAt: DateTime.now(),
          ),
        );
        assistant = await execute();
      }

      // Hanya simpan langkah tool sebenar — elak kad "Berfikir" selepas chat biasa.
      final meaningfulEvents = currentRunEvents
          .where((e) {
            final t = e.title.toLowerCase();
            if (t.contains('memahami permintaan')) return false;
            if (t.contains('menyusun hasil')) return false;
            if (t == 'berfikir' || t.startsWith('sedang berfikir')) {
              return false;
            }
            return true;
          })
          .toList();
      final metadata = <String, dynamic>{
        ...assistant.metadata,
        'providerId': activeProvider.id,
        'model': activeProvider.model,
        if (meaningfulEvents.isNotEmpty)
          'runEvents': meaningfulEvents.map((item) => item.toJson()).toList(),
        if (runStartedAt != null)
          'durationMs':
              DateTime.now().difference(runStartedAt!).inMilliseconds,
      };

      // Stream teks pantas ke UI (bukan dump penuh serentak).
      final fullText = assistant.content;
      final streamed = assistant.copyWith(content: '', metadata: metadata);
      messages.add(streamed);
      notifyListeners();
      const chunk = 12;
      for (var i = 0; i < fullText.length; i += chunk) {
        if (_runControl?.cancelled == true) break;
        final end = (i + chunk > fullText.length) ? fullText.length : i + chunk;
        final partial = fullText.substring(0, end);
        final idx = messages.indexWhere((m) => m.id == streamed.id);
        if (idx >= 0) {
          messages[idx] = messages[idx].copyWith(content: partial);
          notifyListeners();
        }
        await Future<void>.delayed(const Duration(milliseconds: 10));
      }
      final completed = assistant.copyWith(
        content: fullText,
        metadata: metadata,
      );
      final finalIdx = messages.indexWhere((m) => m.id == streamed.id);
      if (finalIdx >= 0) {
        messages[finalIdx] = completed;
      } else {
        messages.add(completed);
      }
      await database.saveMessage(completed);
      if (runStatus != RunStatus.cancelled) {
        runStatus = RunStatus.completed;
        runDetail = 'Selesai';
        final preview = fullText.trim().isEmpty
            ? 'Buka app untuk lihat jawapan.'
            : fullText.trim();
        unawaited(_notifyAgentFinished(success: true, summary: preview));
      }
    } catch (error) {
      runStatus = RunStatus.failed;
      runDetail = _friendlyError(error);
      final event = RunEvent(
        id: 'runtime-error',
        title: 'Tugasan gagal',
        detail: _friendlyError(error),
        state: RunEventState.failed,
        createdAt: DateTime.now(),
      );
      _upsertRunEvent(event);
      final failure = ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.assistant,
        content: _friendlyError(error),
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          'providerId': activeProvider.id,
          'model': activeProvider.model,
          'runEvents': currentRunEvents.map((item) => item.toJson()).toList(),
          'failed': true,
        },
      );
      messages.add(failure);
      await database.saveMessage(failure);
      unawaited(
        _notifyAgentFinished(
          success: false,
          summary: _friendlyError(error),
        ),
      );
    } finally {
      _backgroundLimitTimer?.cancel();
      _backgroundLimitTimer = null;
      isSending = false;
      unawaited(_syncBackgroundKeepAlive());
      _runControl = null;
      runStartedAt = null;
      // Segarkan skill jika AI baru cipta/pasang (tanpa tutup app).
      try {
        skills = await skillService.loadSkills();
      } catch (_) {}
      try {
        mcpServers = (await database.listObjects('mcp_server'))
            .map(McpServerConfig.fromJson)
            .toList();
      } catch (_) {}
      notifyListeners();
      // Proses mesej susulan yang dihantar semasa larian tadi.
      if (followUpQueue.isNotEmpty) {
        final next = followUpQueue.removeAt(0);
        notifyListeners();
        unawaited(sendMessage(next));
      }
    }
  }

  void _upsertRunEvent(RunEvent event) {
    final index = currentRunEvents.indexWhere((item) => item.id == event.id);
    if (index < 0) {
      currentRunEvents.add(event);
    } else {
      currentRunEvents[index] = event;
    }
    runDetail = event.title;
    notifyListeners();
    if (appInBackground && isSending) {
      final live = event.detail.trim().isNotEmpty ? event.detail : event.title;
      unawaited(_updateLiveWorkingNotification(live));
    }
  }

  String _friendlyError(Object error) {
    var value = error.toString().trim();
    value = value.replaceFirst(RegExp(r'^FormatException:\s*'), '');
    value = value.replaceFirst(RegExp(r'^Exception:\s*'), '');
    value = value.replaceFirst(RegExp(r'^StateError:\s*'), '');
    value = value.trim();
    if (providerService.isModelUnavailableError(error)) {
      return 'Model yang dipilih tidak tersedia untuk API key/provider ini. '
          'Tekan nama model di bahagian atas dan pilih model daripada senarai '
          'yang disahkan secara langsung oleh provider.';
    }
    final lower = value.toLowerCase();
    if (lower.contains('connection abort') ||
        lower.contains('software caused connection abort') ||
        lower.contains('broken pipe')) {
      return 'Sambungan terputus semasa hantar ke API (biasa bila gambar besar / lambat). '
          'Cuba semula — app kini mampat gambar & timeout lebih panjang. '
          'Elak hantar terlalu banyak gambar HD sekali gus.';
    }
    if (lower.contains('failed host lookup') ||
        lower.contains('socketexception') ||
        lower.contains('no address associated with hostname') ||
        lower.contains('network is unreachable') ||
        lower.contains('connection refused') ||
        lower.contains('connection reset') ||
        lower.contains('timed out') ||
        lower.contains('timeout')) {
      final hostMatch = RegExp(
        r"host lookup:\s*'([^']+)'",
        caseSensitive: false,
      ).firstMatch(value);
      final host = hostMatch?.group(1);
      return host == null
          ? 'Rangkaian gagal: tidak dapat sambung ke API provider. '
              'Semak internet, VPN, atau Base URL provider.'
          : 'Rangkaian gagal: tidak jumpa host "$host". '
              'Semak internet/DNS, atau Base URL provider (Xiaomi MiMo dsb.).';
    }
    value = value.replaceAllMapped(
      RegExp(
        r'''/(?:data/(?:user/\d+/|data/)|storage|sdcard|mnt)[^\s"')\]]*''',
        caseSensitive: false,
      ),
      (_) => '[path-host-disembunyikan]',
    );
    if (value.contains('Permission denied') ||
        value.contains('PathAccess') ||
        value.contains('errno = 13')) {
      return 'Akses folder sistem tidak dibenarkan. Gunakan workspace (/workspace) sahaja.';
    }
    if (value.length <= 500) return value;
    return '${value.substring(0, 500)}…';
  }

  Future<void> reloadCurrentSessionMessages() async {
    messages = await database.listMessages(sessionId);
    notifyListeners();
  }

  void stopCurrentRun() {
    _runControl?.cancel();
    unawaited(_haltSideEffects());
    permissionManager.cancelPending();
    followUpQueue.clear();
    runStatus = RunStatus.cancelled;
    runDetail = 'Dihentikan';
    _upsertRunEvent(
      RunEvent(
        id: 'cancel-request',
        title: 'Dihentikan',
        detail: 'Semua proses aktif dihentikan (terminal, browser, background).',
        state: RunEventState.info,
        createdAt: DateTime.now(),
      ),
    );
    // Tandakan terus supaya UI responsif; finally sendMessage akan clear isSending.
    notifyListeners();
  }

  /// Hentikan semua side-effect lepas agent stop — elak skrip terus jalan.
  Future<void> _haltSideEffects() async {
    await terminalService.stopAll();
    await browserSession.cancelPending();
    await platformBridge.stopExecutionKeepAlive();
  }







  void resolvePermission(PermissionDecision decision) {
    permissionManager.resolve(decision);
  }

  void grantSessionRiskPermission() {
    permissionManager.grantSessionAllRisky();
  }

  List<PermissionRule> get permissionRules => permissionManager.rules;

  Future<void> setToolPermission(
    String toolId,
    PermissionPolicy policy, {
    String scope = '*',
  }) {
    return permissionManager.setPolicy(
      toolId,
      scope: scope,
      policy: policy,
    );
  }

  Future<void> setGlobalRiskPermission(PermissionPolicy policy) {
    return permissionManager.setPolicy('*', scope: '*', policy: policy);
  }

  Future<void> revokePermission(String ruleId) =>
      permissionManager.revoke(ruleId);

  /// Edit mesej pengguna: padam ia + semua mesej selepasnya. Pulangkan teks untuk composer.
  Future<String> editFromUserMessage(ChatMessage message) async {
    recordActivity();
    followUpQueue.clear();
    await database.deleteMessagesFrom(sessionId, message.createdAt);
    messages.removeWhere(
      (item) => !item.createdAt.isBefore(message.createdAt),
    );
    notifyListeners();
    return message.content;
  }

  /// Hantar semula mesej yang diedit. AI hanya berhenti di sini, bukan masa buka panel edit.
  Future<void> commitEditedUserMessage({
    required ChatMessage original,
    required String text,
    List<ChatAttachment> attachments = const <ChatAttachment>[],
  }) async {
    recordActivity();
    if (isSending) {
      stopCurrentRun();
    }
    followUpQueue.clear();
    await database.deleteMessagesFrom(sessionId, original.createdAt);
    messages.removeWhere(
      (item) => !item.createdAt.isBefore(original.createdAt),
    );
    notifyListeners();
    await sendMessage(text, attachments: attachments);
  }

  Future<void> newSession({
    String reason = 'Sesi baharu dimulakan.',
  }) async {
    _runControl?.cancel();
    followUpQueue.clear();
    await _haltSideEffects();
    try {
      await browserSession.clearCookies();
    } catch (_) {}
    permissionManager.clearSessionPermissions();
    sessionId = _uuid.v4();
    await database.setSetting('activeSessionId', sessionId);
    lastActivityAt = DateTime.now();
    await _persistActivity(force: true);
    messages = <ChatMessage>[];
    currentRunEvents = <RunEvent>[];
    pendingAttachments.clear();
    isSending = false;
    runStatus = RunStatus.idle;
    runDetail = '';
    sessionNotice = reason;
    notifyListeners();
  }

  /// Buka sesi chat lama dari sejarah (mesej auto-tersimpan).
  Future<void> openSession(String id) async {
    if (id == sessionId) return;
    _runControl?.cancel();
    followUpQueue.clear();
    await _haltSideEffects();
    permissionManager.clearSessionPermissions();
    sessionId = id;
    await database.setSetting('activeSessionId', sessionId);
    lastActivityAt = DateTime.now();
    await _persistActivity(force: true);
    messages = await database.listMessages(sessionId);
    currentRunEvents = <RunEvent>[];
    pendingAttachments.clear();
    isSending = false;
    runStatus = RunStatus.idle;
    runDetail = '';
    sessionNotice = '';
    selectedTab = 0;
    await database.setSetting('selectedTab', '0');
    notifyListeners();
  }

  Future<List<Map<String, dynamic>>> listChatSessions() {
    return database.listChatSessions();
  }

  Future<void> renameChatSession(String id, String title) async {
    final value = title.trim();
    if (value.isEmpty) return;
    await database.setSessionTitle(id, value);
    notifyListeners();
  }

  Future<void> deleteChatSession(String id) async {
    await database.clearMessages(id);
    if (id == sessionId) {
      await newSession(reason: 'Chat dipadam. Sesi baharu dimulakan.');
    } else {
      notifyListeners();
    }
  }

  /// 0 = tiada auto-padam; selain itu bilangan hari.
  Future<int> getChatHistoryRetentionDays() async {
    final raw = await database.getSetting('chatHistoryRetentionDays');
    return int.tryParse(raw ?? '30') ?? 30;
  }

  Future<void> setChatHistoryRetentionDays(int days) async {
    final safe = days < 0 ? 0 : days;
    await database.setSetting('chatHistoryRetentionDays', '$safe');
    await _applyChatHistoryRetention();
    notifyListeners();
  }

  Future<void> _applyChatHistoryRetention() async {
    final days = await getChatHistoryRetentionDays();
    if (days <= 0) return;
    await database.deleteSessionsOlderThan(Duration(days: days));
  }

  Future<void> saveAgent(AgentProfile agent) async {
    final index = agents.indexWhere((item) => item.id == agent.id);
    if (index < 0) {
      agents.add(agent);
    } else {
      agents[index] = agent;
    }
    await database.saveObject('agent', agent.id, agent.toJson());
    notifyListeners();
  }

  Future<void> deleteAgent(AgentProfile agent) async {
    if (agent.isBuiltIn) return;
    agents.removeWhere((item) => item.id == agent.id);
    await database.deleteObject('agent', agent.id);
    if (selectedAgentId == agent.id) {
      await selectAgent('orchestrator');
    }
    notifyListeners();
  }

  Future<void> reloadSkills() async {
    skills = await skillService.loadSkills();
    notifyListeners();
  }

  Future<void> saveSkill(SkillDefinition skill) async {
    if (skill.isBuiltIn) {
      // Builtin: hanya toggle enabled dibenarkan.
      final index = skills.indexWhere((item) => item.id == skill.id);
      if (index >= 0) {
        skills[index] = skills[index].copyWith(enabled: skill.enabled);
        await skillService.save(skills[index]);
        notifyListeners();
      }
      return;
    }
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    await skillService.save(skill);
    notifyListeners();
  }

  Future<void> importSkill(String path) async {
    final skill = await skillService.importZip(path);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> installSkillFromUrl(String url) async {
    final skill = await skillService.importUrl(url);
    final index = skills.indexWhere((item) => item.id == skill.id);
    if (index < 0) {
      skills.add(skill);
    } else {
      skills[index] = skill;
    }
    notifyListeners();
  }

  Future<void> deleteSkill(SkillDefinition skill) async {
    if (skill.isBuiltIn) return;
    skills.removeWhere((item) => item.id == skill.id);
    await skillService.delete(skill);
    notifyListeners();
  }

  Future<void> saveAutomation(AutomationDefinition automation) async {
    final index = automations.indexWhere((item) => item.id == automation.id);
    if (index < 0) {
      automations.add(automation);
    } else {
      automations[index] = automation;
    }
    await automationService.save(automation);
    await _syncBackgroundKeepAlive();
    notifyListeners();
  }

  Future<void> deleteAutomation(AutomationDefinition automation) async {
    automations.removeWhere((item) => item.id == automation.id);
    await automationService.delete(automation);
    await _syncBackgroundKeepAlive();
    notifyListeners();
  }

  bool get hasActiveAutomation =>
      automations.any((item) => item.enabled);

  /// Automasi aktif → FGS tanpa had 30 minit.
  /// Chat latar → FGS 30 minit.
  /// Tiada kedua-dua → henti FGS.
  Future<void> _syncBackgroundKeepAlive() async {
    if (!backgroundExecutionAllowed) {
      _backgroundLimitTimer?.cancel();
      _backgroundLimitTimer = null;
      await platformBridge.stopExecutionKeepAlive();
      return;
    }
    if (hasActiveAutomation) {
      _backgroundLimitTimer?.cancel();
      _backgroundLimitTimer = null;
      await platformBridge.startExecutionKeepAlive(maxDuration: Duration.zero);
      return;
    }
    if (isSending && appInBackground) {
      await platformBridge.startExecutionKeepAlive(
        maxDuration: AppConfig.backgroundExecutionLimit,
      );
      return;
    }
    _backgroundLimitTimer?.cancel();
    _backgroundLimitTimer = null;
    await platformBridge.stopExecutionKeepAlive();
  }

  Future<void> savePersonalization({
    required String nickname,
    required String instructions,
  }) async {
    userNickname = nickname.trim();
    customInstructions = instructions.trim();
    await database.setSetting('userNickname', userNickname);
    await database.setSetting('customInstructions', customInstructions);
    notifyListeners();
  }

  Future<void> saveMcpServer(McpServerConfig server) async {
    final index = mcpServers.indexWhere((item) => item.id == server.id);
    if (index < 0) {
      mcpServers.add(server);
    } else {
      mcpServers[index] = server;
    }
    await database.saveObject('mcp_server', server.id, server.toJson());
    notifyListeners();
  }

  Future<Map<String, dynamic>> testMcpServer(McpServerConfig server) async {
    try {
      final result = await mcpService.test(server);
      await saveMcpServer(
        server.copyWith(
          lastTestMessage: 'Berjaya',
          lastTestAt: DateTime.now(),
        ),
      );
      return result;
    } catch (error) {
      await saveMcpServer(
        server.copyWith(
          lastTestMessage: error.toString(),
          lastTestAt: DateTime.now(),
        ),
      );
      rethrow;
    }
  }

  Future<void> deleteMcpServer(McpServerConfig server) async {
    mcpServers.removeWhere((item) => item.id == server.id);
    await database.deleteObject('mcp_server', server.id);
    notifyListeners();
  }

  Future<List<MemoryRecord>> memories() async {
    return (await database.listObjects('memory'))
        .map(MemoryRecord.fromJson)
        .toList();
  }

  Future<void> saveMemory(MemoryRecord memory) async {
    await database.saveObject('memory', memory.id, memory.toJson());
    notifyListeners();
  }

  Future<void> deleteMemory(MemoryRecord memory) async {
    await database.deleteObject('memory', memory.id);
    notifyListeners();
  }

  Future<List<ToolLogRecord>> toolLogs({int limit = 200}) {
    return database.listToolLogs(limit: limit);
  }

  Future<void> deleteAllLocalData() async {
    _inactivityTimer?.cancel();
    _backgroundLimitTimer?.cancel();
    _runControl?.cancel();
    permissionManager.cancelPending();
    await _haltSideEffects();
    await automationService.cancelAll();
    await vault.deleteAll();
    await database.deleteAllLocalData();
    await LinuxWorkspaceService().reset();
    providers.clear();
    automations.clear();
    skills.clear();
    mcpServers.clear();
    messages.clear();
    currentRunEvents.clear();
    pendingAttachments.clear();
    sessionNotice = '';
    initialized = false;
    notifyListeners();
    await initialize();
  }

  ProviderConfig? _providerById(String id) {
    for (final provider in providers) {
      if (provider.id == id) return provider;
    }
    return null;
  }

  Future<List<AgentProfile>> _loadAgents() async {
    // Profil agent lama dibersihkan daripada UI/data. Model yang dipilih ialah
    // orchestrator tunggal dan mencipta sub-agent dinamik apabila diperlukan.
    for (final saved in await database.listObjects('agent')) {
      final id = saved['id']?.toString() ?? '';
      if (id.isNotEmpty && id != 'orchestrator') {
        await database.deleteObject('agent', id);
      }
    }
    final root = _builtInAgents().first;
    await database.saveObject('agent', root.id, root.toJson());
    return <AgentProfile>[root];
  }

  List<AgentProfile> _builtInAgents() => const <AgentProfile>[
        AgentProfile(
          id: 'orchestrator',
          name: 'Ai MultiAgent',
          description:
              'Model utama yang memilih tools, skills dan sub-agent secara automatik.',
          systemPrompt:
              'Selesaikan tugasan pengguna secara menyeluruh. Cipta sub-agent dinamik di latar belakang apabila pembahagian kerja meningkatkan hasil, kemudian gabungkan semua hasil.',
          iconCode: 0xf1b3,
          isBuiltIn: true,
        ),
      ];

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    browserSession.removeListener(_notifyFromBrowser);
    _inactivityTimer?.cancel();
    _backgroundLimitTimer?.cancel();
    _runControl?.cancel();
    unawaited(platformBridge.stopExecutionKeepAlive());
    providerService.dispose();
    toolEngine.dispose();
    unawaited(database.close());
    super.dispose();
  }
}
