class CompressionProgress {
  final int progress; // 0-100
  final int frameNumber;
  final int totalFrames;
  final double speed; // encoding speed (e.g., 2.5x)
  final Duration elapsedTime;

  CompressionProgress({
    required this.progress,
    required this.frameNumber,
    required this.totalFrames,
    required this.speed,
    required this.elapsedTime,
  });

  String get progressPercentage => '$progress%';
  
  String get frameInfo => '$frameNumber / $totalFrames';
  
  String get speedInfo => '${speed.toStringAsFixed(1)}x';
  
  Duration get estimatedTimeRemaining {
    if (speed == 0) return Duration.zero;
    final remainingFrames = totalFrames - frameNumber;
    final secondsPerFrame = 1.0 / speed;
    final estimatedSeconds = (remainingFrames * secondsPerFrame).toInt();
    return Duration(seconds: estimatedSeconds);
  }
}
