enum QualityMode { ultraCompress, balanced, highQuality }

class CompressionSettings {
  final QualityMode qualityMode;
  final String targetResolution;
  final int targetBitrate; // kbps
  final int targetFps;

  CompressionSettings({
    required this.qualityMode,
    required this.targetResolution,
    required this.targetBitrate,
    required this.targetFps,
  });

  static CompressionSettings getPreset(QualityMode mode) {
    switch (mode) {
      case QualityMode.ultraCompress:
        return CompressionSettings(
          qualityMode: mode,
          targetResolution: '1280x720',
          targetBitrate: 1500,
          targetFps: 30,
        );
      case QualityMode.balanced:
        return CompressionSettings(
          qualityMode: mode,
          targetResolution: '1920x1080',
          targetBitrate: 2500,
          targetFps: 30,
        );
      case QualityMode.highQuality:
        return CompressionSettings(
          qualityMode: mode,
          targetResolution: '1920x1080',
          targetBitrate: 4000,
          targetFps: 60,
        );
    }
  }

  String get modeName {
    switch (qualityMode) {
      case QualityMode.ultraCompress:
        return 'Ultra Compress';
      case QualityMode.balanced:
        return 'Balanced';
      case QualityMode.highQuality:
        return 'High Quality';
    }
  }

  String get modeDescription {
    switch (qualityMode) {
      case QualityMode.ultraCompress:
        return 'Maximum compression, acceptable quality';
      case QualityMode.balanced:
        return 'Best balance quality vs size (Recommended)';
      case QualityMode.highQuality:
        return 'Minimal compression, highest quality';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'quality_mode': qualityMode.index,
      'target_resolution': targetResolution,
      'target_bitrate': targetBitrate,
      'target_fps': targetFps,
    };
  }
}
