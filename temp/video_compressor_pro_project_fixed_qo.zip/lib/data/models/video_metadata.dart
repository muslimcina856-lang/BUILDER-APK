class VideoMetadata {
  final String filename;
  final String filePath;
  final int fileSize; // in bytes
  final int duration; // in milliseconds
  final String resolution; // e.g., "1920x1080"
  final int bitrate; // in kbps
  final double frameRate; // fps

  VideoMetadata({
    required this.filename,
    required this.filePath,
    required this.fileSize,
    required this.duration,
    required this.resolution,
    required this.bitrate,
    required this.frameRate,
  });

  String get durationFormatted {
    final minutes = duration ~/ 60000;
    final seconds = (duration % 60000) ~/ 1000;
    return '${minutes}m ${seconds}s';
  }

  String get fileSizeFormatted {
    if (fileSize < 1024 * 1024) {
      return '${(fileSize / 1024).toStringAsFixed(2)} KB';
    } else if (fileSize < 1024 * 1024 * 1024) {
      return '${(fileSize / (1024 * 1024)).toStringAsFixed(2)} MB';
    } else {
      return '${(fileSize / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'filename': filename,
      'filePath': filePath,
      'fileSize': fileSize,
      'duration': duration,
      'resolution': resolution,
      'bitrate': bitrate,
      'frameRate': frameRate,
    };
  }
}
