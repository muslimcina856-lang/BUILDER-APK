import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;

class DatabaseProvider {
  static final DatabaseProvider _instance = DatabaseProvider._internal();
  late Database _database;

  factory DatabaseProvider() {
    return _instance;
  }

  DatabaseProvider._internal();

  Future<Database> get database async {
    return _database;
  }

  Future<void> initializeDatabase() async {
    final databasePath = await getDatabasesPath();
    final dbPath = path.join(databasePath, 'video_compressor.db');

    _database = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await _createTables(db);
      },
    );
  }

  Future<void> _createTables(Database db) async {
    // Compression History Table
    await db.execute('''
      CREATE TABLE IF NOT EXISTS compression_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_filename TEXT NOT NULL,
        original_size INTEGER NOT NULL,
        original_duration INTEGER,
        original_resolution TEXT,
        original_bitrate INTEGER,
        quality_mode INTEGER NOT NULL,
        target_resolution TEXT,
        target_bitrate INTEGER,
        target_fps INTEGER,
        output_filename TEXT NOT NULL UNIQUE,
        output_size INTEGER,
        output_path TEXT NOT NULL,
        compression_ratio REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        duration_ms INTEGER,
        status TEXT,
        error_message TEXT
      )
    ''');

    // Compression Presets Table
    await db.execute('''
      CREATE TABLE IF NOT EXISTS compression_presets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        preset_name TEXT UNIQUE NOT NULL,
        resolution TEXT,
        bitrate INTEGER,
        fps INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    ''');

    // Insert default presets
    await _insertDefaultPresets(db);
  }

  Future<void> _insertDefaultPresets(Database db) async {
    final presets = [
      {
        'preset_name': 'Ultra Compress',
        'resolution': '1280x720',
        'bitrate': 1500,
        'fps': 30,
      },
      {
        'preset_name': 'Balanced (Recommended)',
        'resolution': '1920x1080',
        'bitrate': 2500,
        'fps': 30,
      },
      {
        'preset_name': 'High Quality',
        'resolution': '1920x1080',
        'bitrate': 4000,
        'fps': 60,
      },
    ];

    for (var preset in presets) {
      await db.insert(
        'compression_presets',
        preset,
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  Future<int> insertCompressionRecord(Map<String, dynamic> record) async {
    return await _database.insert(
      'compression_history',
      record,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getCompressionHistory() async {
    return await _database.query(
      'compression_history',
      orderBy: 'created_at DESC',
    );
  }

  Future<int> deleteCompressionRecord(int id) async {
    return await _database.delete(
      'compression_history',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<Map<String, dynamic>?> getCompressionRecordById(int id) async {
    final result = await _database.query(
      'compression_history',
      where: 'id = ?',
      whereArgs: [id],
    );
    return result.isNotEmpty ? result.first : null;
  }

  Future<List<Map<String, dynamic>>> getCompressionPresets() async {
    return await _database.query('compression_presets');
  }

  Future<void> clearOldRecords({int daysOld = 30}) async {
    await _database.delete(
      'compression_history',
      where: 'datetime(created_at) < datetime("now", "-$daysOld days")',
    );
  }
}
