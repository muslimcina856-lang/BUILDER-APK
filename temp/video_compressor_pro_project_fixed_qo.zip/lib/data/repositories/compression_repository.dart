import 'dart:async';
import 'dart:io';
import 'package:ffmpeg_kit_flutter/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter/return_code.dart';
import 'package:path_provider/path_provider.dart';
import '../models/compression_progress.dart';
import '../models/compression_settings.dart';
import '../models/video_metadata.dart';

class CompressionRepository {
  StreamController<CompressionProgress>? _progressController;
  bool _isCompressing = false;

  Stream<CompressionProgress> compressVideo({
    required String inputPath,
    required VideoMetadata metadata,
    required CompressionSettings settings,
  }) async* {
    if (_isCompressing) {
      throw Exception('Compression already in progress');
    }

    _isCompressing = true;
    _progressController = StreamController<CompressionProgress>();

    try {
      final outputPath = await _getOutputPath(metadata.filename);
      final ffmpegCommand = _buildFFmpegCommand(
        inputPath,
        outputPath,
        settings,
      );

      yield* _executeFFmpegCommand(ffmpegCommand, metadata);
    } catch (e) {
      _progressController?.close();
      _isCompressing = false;
      rethrow;
    }
  }

  Stream<CompressionProgress> _executeFFmpegCommand(
    String command,
    VideoMetadata metadata,
  ) async* {
    try {
      final session = await FFmpegKit.executeAsync(
        command,
        (statistics) {
          if (statistics != null) {
            final progress = _parseProgress(statistics, metadata);
            _progressController?.add(progress);
          }
        },
      );

      final returnCode = await session.getReturnCode();

      if (ReturnCode.isSuccess(returnCode)) {
        // Final progress
        yield CompressionProgress(
          progress: 100,
          frameNumber: metadata.duration ~/ 33, // Approximate
          totalFrames: metadata.duration ~/ 33,
          speed: 1.0,
          elapsedTime: Duration.zero,
        );
      } else {
        throw Exception('FFmpeg compression failed');
      }

      _progressController?.close();
      _isCompressing = false;
    } catch (e) {
      _progressController?.close();
      _isCompressing = false;
      rethrow;
    }
  }

  CompressionProgress _parseProgress(dynamic statistics, VideoMetadata metadata) {
    // Parse FFmpeg statistics (frame, speed, time, etc.)
    // This is a placeholder implementation
    int frame = 0;
    double speed = 1.0;
    Duration elapsedTime = Duration.zero;

    // Calculate progress percentage
    final totalFrames = metadata.duration ~/ 33;
    final progress = ((frame / totalFrames) * 100).toInt().clamp(0, 100);

    return CompressionProgress(
      progress: progress,
      frameNumber: frame,
      totalFrames: totalFrames,
      speed: speed,
      elapsedTime: elapsedTime,
    );
  }

  String _buildFFmpegCommand(
    String inputPath,
    String outputPath,
    CompressionSettings settings,
  ) {
    final resolution = settings.targetResolution.split('x');
    final width = resolution[0];
    final height = resolution[1];

    return '-i "$inputPath" '
        '-c:v libx265 '
        '-preset fast '
        '-crf 28 '
        '-b:v ${settings.targetBitrate}k '
        '-c:a aac '
        '-b:a 128k '
        '-s ${width}x${height} '
        '-r ${settings.targetFps} '
        '-y "$outputPath"';
  }

  Future<String> _getOutputPath(String originalFilename) async {
    final documentsDir = await getApplicationDocumentsDirectory();
    final outputDir = Directory('${documentsDir.path}/compressed_videos');

    if (!await outputDir.exists()) {
      await outputDir.create(recursive: true);
    }

    final filename = originalFilename.split('.').first;
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return '${outputDir.path}/${filename}_compressed_$timestamp.mp4';
  }

  Future<void> cancelCompression() async {
    try {
      await FFmpegKit.cancel();
      _progressController?.close();
      _isCompressing = false;
    } catch (e) {
      rethrow;
    }
  }

  bool get isCompressing => _isCompressing;
}
