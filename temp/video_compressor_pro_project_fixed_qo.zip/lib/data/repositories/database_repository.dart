import '../database/database_provider.dart';
import '../models/compression_settings.dart';

class CompressionRecord {
  final int? id;
  final String originalFilename;
  final int originalSize;
  final int? originalDuration;
  final String? originalResolution;
  final int? originalBitrate;
  final int qualityMode;
  final String? targetResolution;
  final int? targetBitrate;
  final int? targetFps;
  final String outputFilename;
  final int? outputSize;
  final String outputPath;
  final double? compressionRatio;
  final DateTime createdAt;
  final int? durationMs;
  final String? status;
  final String? errorMessage;

  CompressionRecord({
    this.id,
    required this.originalFilename,
    required this.originalSize,
    this.originalDuration,
    this.originalResolution,
    this.originalBitrate,
    required this.qualityMode,
    this.targetResolution,
    this.targetBitrate,
    this.targetFps,
    required this.outputFilename,
    this.outputSize,
    required this.outputPath,
    this.compressionRatio,
    required this.createdAt,
    this.durationMs,
    this.status = 'success',
    this.errorMessage,
  });

  double get savedPercentage {
    if (outputSize == null) return 0;
    return ((1 - (outputSize! / originalSize)) * 100);
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'original_filename': originalFilename,
      'original_size': originalSize,
      'original_duration': originalDuration,
      'original_resolution': originalResolution,
      'original_bitrate': originalBitrate,
      'quality_mode': qualityMode,
      'target_resolution': targetResolution,
      'target_bitrate': targetBitrate,
      'target_fps': targetFps,
      'output_filename': outputFilename,
      'output_size': outputSize,
      'output_path': outputPath,
      'compression_ratio': compressionRatio,
      'created_at': createdAt.toIso8601String(),
      'duration_ms': durationMs,
      'status': status,
      'error_message': errorMessage,
    };
  }

  factory CompressionRecord.fromMap(Map<String, dynamic> map) {
    return CompressionRecord(
      id: map['id'] as int?,
      originalFilename: map['original_filename'] as String,
      originalSize: map['original_size'] as int,
      originalDuration: map['original_duration'] as int?,
      originalResolution: map['original_resolution'] as String?,
      originalBitrate: map['original_bitrate'] as int?,
      qualityMode: map['quality_mode'] as int,
      targetResolution: map['target_resolution'] as String?,
      targetBitrate: map['target_bitrate'] as int?,
      targetFps: map['target_fps'] as int?,
      outputFilename: map['output_filename'] as String,
      outputSize: map['output_size'] as int?,
      outputPath: map['output_path'] as String,
      compressionRatio: map['compression_ratio'] as double?,
      createdAt: DateTime.parse(map['created_at'] as String),
      durationMs: map['duration_ms'] as int?,
      status: map['status'] as String?,
      errorMessage: map['error_message'] as String?,
    );
  }
}

class DatabaseRepository {
  final DatabaseProvider databaseProvider;

  DatabaseRepository(this.databaseProvider);

  Future<int> saveCompressionRecord(CompressionRecord record) async {
    return await databaseProvider.insertCompressionRecord(record.toMap());
  }

  Future<List<CompressionRecord>> getCompressionHistory() async {
    final maps = await databaseProvider.getCompressionHistory();
    return maps.map((map) => CompressionRecord.fromMap(map)).toList();
  }

  Future<bool> deleteCompressionRecord(int id) async {
    final result = await databaseProvider.deleteCompressionRecord(id);
    return result > 0;
  }

  Future<CompressionRecord?> getCompressionRecordById(int id) async {
    final map = await databaseProvider.getCompressionRecordById(id);
    return map != null ? CompressionRecord.fromMap(map) : null;
  }

  Future<CompressionStats> getCompressionStats() async {
    final records = await getCompressionHistory();
    
    int totalCompressions = records.length;
    int totalBytesOriginal = 0;
    int totalBytesCompressed = 0;
    int totalTimeSaved = 0;

    for (var record in records) {
      totalBytesOriginal += record.originalSize;
      if (record.outputSize != null) {
        totalBytesCompressed += record.outputSize!;
        totalTimeSaved += (record.originalSize - record.outputSize!);
      }
    }

    return CompressionStats(
      totalCompressions: totalCompressions,
      totalBytesOriginal: totalBytesOriginal,
      totalBytesCompressed: totalBytesCompressed,
      totalSpaceSaved: totalTimeSaved,
      averageCompressionRatio: totalCompressions > 0
          ? (totalBytesCompressed / totalBytesOriginal)
          : 0,
    );
  }

  Future<void> clearOldRecords({int daysOld = 30}) async {
    await databaseProvider.clearOldRecords(daysOld: daysOld);
  }
}

class CompressionStats {
  final int totalCompressions;
  final int totalBytesOriginal;
  final int totalBytesCompressed;
  final int totalSpaceSaved;
  final double averageCompressionRatio;

  CompressionStats({
    required this.totalCompressions,
    required this.totalBytesOriginal,
    required this.totalBytesCompressed,
    required this.totalSpaceSaved,
    required this.averageCompressionRatio,
  });

  String get totalBytesOriginalFormatted {
    return _formatBytes(totalBytesOriginal);
  }

  String get totalBytesCompressedFormatted {
    return _formatBytes(totalBytesCompressed);
  }

  String get totalSpaceSavedFormatted {
    return _formatBytes(totalSpaceSaved);
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  double get averageCompressionPercentage {
    return (1 - averageCompressionRatio) * 100;
  }
}
