import 'package:flutter/material.dart';
import '../../data/repositories/database_repository.dart';

class RecentCompressionsWidget extends StatelessWidget {
  final List<CompressionRecord> records;

  const RecentCompressionsWidget({
    Key? key,
    required this.records,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final recentRecords = records.take(5).toList();

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: recentRecords.length,
      itemBuilder: (context, index) {
        final record = recentRecords[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.indigo.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.video_library,
                color: Colors.indigo.shade700,
              ),
            ),
            title: Text(
              record.originalFilename,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: Text(
              '${record.originalSize ~/ (1024 * 1024)} MB → '
              '${(record.outputSize ?? 0) ~/ (1024 * 1024)} MB '
              '(${record.savedPercentage.toStringAsFixed(1)}% ↓)',
              style: const TextStyle(fontSize: 12),
            ),
            trailing: Text(
              _getTimeAgo(record.createdAt),
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ),
        );
      },
    );
  }

  String _getTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}
