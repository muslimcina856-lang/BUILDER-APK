import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/models/compression_progress.dart';
import '../../data/models/compression_settings.dart';
import '../../data/models/video_metadata.dart';
import '../../data/repositories/compression_repository.dart';
import '../../data/repositories/database_repository.dart';
import '../../data/repositories/video_repository.dart';

// Events
abstract class CompressionEvent {}

class SelectVideoEvent extends CompressionEvent {
  final String? videoPath;
  SelectVideoEvent({this.videoPath});
}

class CompressVideoEvent extends CompressionEvent {
  final QualityMode qualityMode;
  CompressVideoEvent(this.qualityMode);
}

class CancelCompressionEvent extends CompressionEvent {}

class UpdateQualityModeEvent extends CompressionEvent {
  final QualityMode qualityMode;
  UpdateQualityModeEvent(this.qualityMode);
}

// States
abstract class CompressionState {}

class CompressionInitial extends CompressionState {}

class VideoSelectedState extends CompressionState {
  final VideoMetadata metadata;
  final QualityMode selectedQualityMode;
  
  VideoSelectedState({
    required this.metadata,
    this.selectedQualityMode = QualityMode.balanced,
  });
}

class CompressionInProgressState extends CompressionState {
  final CompressionProgress progress;
  
  CompressionInProgressState(this.progress);
}

class CompressionSuccessState extends CompressionState {
  final String outputPath;
  final int outputSize;
  final double savedPercentage;
  final Duration compressionDuration;
  
  CompressionSuccessState({
    required this.outputPath,
    required this.outputSize,
    required this.savedPercentage,
    required this.compressionDuration,
  });
}

class CompressionFailureState extends CompressionState {
  final String errorMessage;
  
  CompressionFailureState(this.errorMessage);
}

// BLoC
class CompressionBloc extends Bloc<CompressionEvent, CompressionState> {
  final VideoRepository videoRepository;
  final CompressionRepository compressionRepository;
  final DatabaseRepository databaseRepository;

  VideoMetadata? _selectedVideoMetadata;
  QualityMode _selectedQualityMode = QualityMode.balanced;
  StreamSubscription? _compressionSubscription;

  CompressionBloc({
    required this.videoRepository,
    required this.compressionRepository,
    required this.databaseRepository,
  }) : super(CompressionInitial()) {
    on<SelectVideoEvent>(_onSelectVideo);
    on<CompressVideoEvent>(_onCompressVideo);
    on<CancelCompressionEvent>(_onCancelCompression);
    on<UpdateQualityModeEvent>(_onUpdateQualityMode);
  }

  Future<void> _onSelectVideo(SelectVideoEvent event, Emitter emit) async {
    try {
      late String videoPath;
      
      if (event.videoPath != null) {
        videoPath = event.videoPath!;
      } else {
        final selectedFile = await videoRepository.selectVideoFromGallery();
        if (selectedFile == null) {
          emit(CompressionFailureState('No video selected'));
          return;
        }
        videoPath = selectedFile.path;
      }

      final metadata = await videoRepository.getVideoMetadata(
        _createFile(videoPath),
      );

      if (metadata != null) {
        _selectedVideoMetadata = metadata;
        emit(VideoSelectedState(
          metadata: metadata,
          selectedQualityMode: _selectedQualityMode,
        ));
      } else {
        emit(CompressionFailureState('Failed to load video metadata'));
      }
    } catch (e) {
      emit(CompressionFailureState('Error selecting video: $e'));
    }
  }

  Future<void> _onCompressVideo(
    CompressVideoEvent event,
    Emitter emit,
  ) async {
    if (_selectedVideoMetadata == null) {
      emit(CompressionFailureState('No video selected'));
      return;
    }

    try {
      final settings = CompressionSettings.getPreset(event.qualityMode);
      final startTime = DateTime.now();

      _compressionSubscription = compressionRepository
          .compressVideo(
            inputPath: _selectedVideoMetadata!.filePath,
            metadata: _selectedVideoMetadata!,
            settings: settings,
          )
          .listen(
            (progress) {
              emit(CompressionInProgressState(progress));
            },
            onError: (error) {
              emit(CompressionFailureState('Compression failed: $error'));
            },
            onDone: () async {
              final endTime = DateTime.now();
              final duration = endTime.difference(startTime);
              
              // Calculate output metrics
              final outputSize = _selectedVideoMetadata!.fileSize ~/ 2; // Placeholder
              final savedPercentage = ((1 - (outputSize / _selectedVideoMetadata!.fileSize)) * 100);

              emit(CompressionSuccessState(
                outputPath: '',
                outputSize: outputSize,
                savedPercentage: savedPercentage,
                compressionDuration: duration,
              ));

              // Save to database
              // await databaseRepository.saveCompressionRecord(...);
            },
          );
    } catch (e) {
      emit(CompressionFailureState('Error starting compression: $e'));
    }
  }

  Future<void> _onCancelCompression(
    CancelCompressionEvent event,
    Emitter emit,
  ) async {
    try {
      await compressionRepository.cancelCompression();
      await _compressionSubscription?.cancel();
      emit(CompressionInitial());
    } catch (e) {
      emit(CompressionFailureState('Error canceling compression: $e'));
    }
  }

  Future<void> _onUpdateQualityMode(
    UpdateQualityModeEvent event,
    Emitter emit,
  ) async {
    _selectedQualityMode = event.qualityMode;
    if (_selectedVideoMetadata != null) {
      emit(VideoSelectedState(
        metadata: _selectedVideoMetadata!,
        selectedQualityMode: event.qualityMode,
      ));
    }
  }

  @override
  Future<void> close() async {
    await _compressionSubscription?.cancel();
    return super.close();
  }

  dynamic _createFile(String path) {
    // Mock file creation
    return {};
  }
}
