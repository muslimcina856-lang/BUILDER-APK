import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/repositories/database_repository.dart';

// Events
abstract class HistoryEvent {}

class LoadHistoryEvent extends HistoryEvent {}

class DeleteHistoryItemEvent extends HistoryEvent {
  final int id;
  DeleteHistoryItemEvent(this.id);
}

class ClearHistoryEvent extends HistoryEvent {}

class RefreshHistoryEvent extends HistoryEvent {}

// States
abstract class HistoryState {}

class HistoryInitial extends HistoryState {}

class HistoryLoadingState extends HistoryState {}

class HistoryLoadedState extends HistoryState {
  final List<CompressionRecord> records;
  final CompressionStats stats;
  
  HistoryLoadedState({
    required this.records,
    required this.stats,
  });
}

class HistoryEmptyState extends HistoryState {}

class HistoryErrorState extends HistoryState {
  final String errorMessage;
  HistoryErrorState(this.errorMessage);
}

// BLoC
class HistoryBloc extends Bloc<HistoryEvent, HistoryState> {
  final DatabaseRepository databaseRepository;

  HistoryBloc({required this.databaseRepository}) : super(HistoryInitial()) {
    on<LoadHistoryEvent>(_onLoadHistory);
    on<DeleteHistoryItemEvent>(_onDeleteHistoryItem);
    on<ClearHistoryEvent>(_onClearHistory);
    on<RefreshHistoryEvent>(_onRefreshHistory);
  }

  Future<void> _onLoadHistory(LoadHistoryEvent event, Emitter emit) async {
    emit(HistoryLoadingState());
    try {
      final records = await databaseRepository.getCompressionHistory();
      final stats = await databaseRepository.getCompressionStats();

      if (records.isEmpty) {
        emit(HistoryEmptyState());
      } else {
        emit(HistoryLoadedState(records: records, stats: stats));
      }
    } catch (e) {
      emit(HistoryErrorState('Failed to load history: $e'));
    }
  }

  Future<void> _onDeleteHistoryItem(
    DeleteHistoryItemEvent event,
    Emitter emit,
  ) async {
    try {
      final success = await databaseRepository.deleteCompressionRecord(event.id);
      if (success) {
        add(RefreshHistoryEvent());
      }
    } catch (e) {
      emit(HistoryErrorState('Failed to delete history item: $e'));
    }
  }

  Future<void> _onClearHistory(ClearHistoryEvent event, Emitter emit) async {
    try {
      final records = await databaseRepository.getCompressionHistory();
      for (var record in records) {
        if (record.id != null) {
          await databaseRepository.deleteCompressionRecord(record.id!);
        }
      }
      emit(HistoryEmptyState());
    } catch (e) {
      emit(HistoryErrorState('Failed to clear history: $e'));
    }
  }

  Future<void> _onRefreshHistory(RefreshHistoryEvent event, Emitter emit) async {
    emit(HistoryLoadingState());
    try {
      final records = await databaseRepository.getCompressionHistory();
      final stats = await databaseRepository.getCompressionStats();

      if (records.isEmpty) {
        emit(HistoryEmptyState());
      } else {
        emit(HistoryLoadedState(records: records, stats: stats));
      }
    } catch (e) {
      emit(HistoryErrorState('Failed to refresh history: $e'));
    }
  }
}
