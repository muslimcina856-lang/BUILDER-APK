import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'config/theme.dart';
import 'data/database/database_provider.dart';
import 'data/repositories/video_repository.dart';
import 'data/repositories/compression_repository.dart';
import 'data/repositories/database_repository.dart';
import 'presentation/bloc/compression_bloc.dart';
import 'presentation/bloc/history_bloc.dart';
import 'presentation/pages/home_page.dart';
import 'utils/logger.dart';

final getIt = GetIt.instance;

Future<void> setupServiceLocator() async {
  // Logger
  getIt.registerSingleton<AppLogger>(AppLogger());

  // Database
  final dbProvider = DatabaseProvider();
  await dbProvider.initializeDatabase();
  getIt.registerSingleton<DatabaseProvider>(dbProvider);

  // Repositories
  getIt.registerSingleton<VideoRepository>(VideoRepository());
  getIt.registerSingleton<DatabaseRepository>(
    DatabaseRepository(dbProvider),
  );
  getIt.registerSingleton<CompressionRepository>(CompressionRepository());

  // BLoCs
  getIt.registerSingleton<CompressionBloc>(
    CompressionBloc(
      videoRepository: getIt<VideoRepository>(),
      compressionRepository: getIt<CompressionRepository>(),
      databaseRepository: getIt<DatabaseRepository>(),
    ),
  );

  getIt.registerSingleton<HistoryBloc>(
    HistoryBloc(databaseRepository: getIt<DatabaseRepository>()),
  );
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await setupServiceLocator();
  runApp(const VideoCompressorApp());
}

class VideoCompressorApp extends StatelessWidget {
  const VideoCompressorApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Compressor Pro',
      theme: appTheme,
      darkTheme: appDarkTheme,
      themeMode: ThemeMode.system,
      home: MultiBlocProvider(
        providers: [
          BlocProvider<CompressionBloc>(
            create: (context) => getIt<CompressionBloc>(),
          ),
          BlocProvider<HistoryBloc>(
            create: (context) => getIt<HistoryBloc>()..add(LoadHistoryEvent()),
          ),
        ],
        child: const HomePage(),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
