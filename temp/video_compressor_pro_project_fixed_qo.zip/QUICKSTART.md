# ⚡ Quick Start Guide

## 5-Minute Setup

### 1. **Navigate to Project**
```bash
cd video_compressor_pro
```

### 2. **Install Flutter Dependencies**
```bash
flutter pub get
```

### 3. **Run on Device/Emulator**

**Android:**
```bash
flutter run
```

**iOS:**
```bash
flutter run -d "iPhone"
```

### 4. **Build Release APK**
```bash
flutter build apk --release
```

APK will be in: `build/app/outputs/flutter-apk/app-release.apk`

---

## 📊 Project Structure Quick Overview

```
lib/
├── main.dart              # App entry point
├── config/theme.dart      # UI theme
├── data/
│   ├── database/          # SQLite setup
│   ├── models/            # Data models
│   └── repositories/      # Business logic
├── presentation/
│   ├── bloc/              # State management
│   ├── pages/             # UI screens
│   └── widgets/           # Reusable components
└── utils/                 # Helpers & utilities
```

---

## 🎯 Key Features to Understand

### 1. **Quality Modes**
- Ultra Compress: 720p @ 1500 kbps
- Balanced: 1080p @ 2500 kbps (recommended)
- High Quality: 1080p @ 4000 kbps

### 2. **Compression Flow**
1. User selects video
2. App extracts metadata
3. FFmpeg compresses based on selected mode
4. Result saved to local storage
5. Record stored in SQLite database

### 3. **State Management (BLoC)**
- `CompressionBloc` - Handles compression logic
- `HistoryBloc` - Manages compression history

---

## 🔧 Customization

### Change App Name
Edit `pubspec.yaml`:
```yaml
name: my_video_compressor
```

### Customize Theme Colors
Edit `lib/config/theme.dart`:
```dart
const Color primaryColor = Color(0xFF6366F1); // Change this
```

### Adjust Compression Settings
Edit `lib/data/models/compression_settings.dart`:
```dart
targetBitrate: 2500,  // Adjust kbps
targetResolution: '1920x1080',  // Change resolution
```

---

## 🚀 Build for Production

### Android
```bash
# Generate signing key (one time)
keytool -genkey -v -keystore ~/.android/my_key.jks \
  -keyalg RSA -keysize 2048 -validity 10000

# Build AAB for Play Store
flutter build appbundle --release

# Build APK
flutter build apk --split-per-abi --release
```

### iOS
```bash
# Build iOS app
flutter build ios --release

# Create IPA for App Store
# (Use Xcode: Product > Archive)
```

---

## ✅ Test Checklist

- [ ] Select video from gallery
- [ ] Display video metadata
- [ ] Try all 3 quality modes
- [ ] Start compression
- [ ] View progress updates
- [ ] Complete compression
- [ ] Check compression history
- [ ] Delete history item
- [ ] Test dark theme

---

## 🐛 Common Issues

### Issue: FFmpeg not found
**Solution:**
```bash
flutter clean
flutter pub get
```

### Issue: Storage permission denied
**Solution:** Update permissions in `android/app/src/main/AndroidManifest.xml`

### Issue: Build fails
**Solution:**
```bash
flutter clean
flutter pub cache repair
flutter pub get
flutter build apk
```

---

## 📱 Testing on Real Device

### Android
```bash
# Enable USB debugging on device
# Connect device via USB
flutter devices  # Verify device shows
flutter run      # Run on device
```

### iOS
```bash
# Connect device via USB
flutter devices  # Verify device shows
flutter run      # Run on device
```

---

## 📈 Next Steps

1. ✅ Run the app and test features
2. ✅ Customize theme/colors for your brand
3. ✅ Adjust compression quality settings
4. ✅ Test on real devices
5. ✅ Build APK/IPA for distribution
6. ✅ Submit to Google Play Store & App Store

---

## 📚 Learning Resources

- **Flutter Docs:** https://flutter.dev/docs
- **FFmpeg Kit:** https://github.com/tanersener/ffmpeg-kit
- **BLoC Pattern:** https://bloclibrary.dev/
- **Material Design 3:** https://material.io/

---

## 💡 Pro Tips

1. **Use Balanced mode** for most videos (best quality/size ratio)
2. **Test compression** on various video formats (MP4, MOV, AVI)
3. **Monitor battery usage** during long compressions
4. **Clean up old records** periodically from history
5. **Keep FFmpeg updated** for best codec support

---

**Ready to go!** 🚀 Start with `flutter run` and enjoy your video compressor app!
