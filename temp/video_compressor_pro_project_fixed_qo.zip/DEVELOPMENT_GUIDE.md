# 🚀 Development Guide - Video Compressor Pro

## Project Overview

**Video Compressor Pro** is a production-ready Flutter application for compressing videos while maintaining HD quality. This guide covers everything from setup to deployment.

---

## 📦 What's Included

### ✅ Complete Source Code
- **14 Dart files** implementing core functionality
- **3 BLoC files** for state management
- **5 Data layer files** for repositories & models
- **3 Presentation layer files** for UI
- **Utility files** for logging and helpers

### ✅ Configuration Files
- `pubspec.yaml` - All dependencies configured
- `analysis_options.yaml` - Code quality rules
- `AndroidManifest.xml` - Android permissions
- `.gitignore` - Git configuration

### ✅ Documentation
- `README.md` - Complete project documentation
- `QUICKSTART.md` - 5-minute setup guide
- `DEVELOPMENT_GUIDE.md` - This file
- Inline code comments for complex logic

---

## 🎯 Architecture Overview

### **Clean Architecture Layers**

```
┌─────────────────────────────────────────────────┐
│         Presentation Layer (UI)                 │
│   - Pages, Widgets, BLoC (State Management)    │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────┴────────────────────────────┐
│         Domain Layer (Business Logic)           │
│   - Use Cases, Entities, Repository Interfaces │
└────────────────────┬────────────────────────────┘
                     │
┌────────────────────┴────────────────────────────┐
│         Data Layer (Data Sources)               │
│   - Repositories, Models, Database, APIs       │
└─────────────────────────────────────────────────┘
```

### **BLoC Pattern**

```
User Input (UI) 
    ↓
BLoC Event 
    ↓
Event Handler 
    ↓
Repository (Business Logic) 
    ↓
State Update 
    ↓
UI Rebuild
```

---

## 📱 Core Components

### 1. **CompressionBloc** (State Management)
Handles:
- Video selection
- Compression process
- Quality mode changes
- Error handling

```dart
// Example usage
context.read<CompressionBloc>().add(SelectVideoEvent());
context.read<CompressionBloc>().add(CompressVideoEvent(QualityMode.balanced));
```

### 2. **HistoryBloc** (History Management)
Handles:
- Loading compression history
- Deleting records
- Calculating statistics
- Refreshing data

### 3. **Repositories** (Business Logic)
- **VideoRepository** - File selection & metadata extraction
- **CompressionRepository** - FFmpeg compression logic
- **DatabaseRepository** - SQLite operations

### 4. **Models** (Data Structures)
- **VideoMetadata** - Original video information
- **CompressionSettings** - Quality mode parameters
- **CompressionProgress** - Real-time progress tracking
- **CompressionRecord** - Database record structure

---

## 🔧 Key Features Implementation

### 1. **Video Selection**
Located: `lib/data/repositories/video_repository.dart`

```dart
Future<File?> selectVideoFromGallery() async {
  final result = await FilePicker.platform.pickFiles(
    type: FileType.video,
    allowMultiple: false,
  );
  return result != null ? File(result.files.first.path!) : null;
}
```

### 2. **Video Compression**
Located: `lib/data/repositories/compression_repository.dart`

FFmpeg command structure:
```bash
ffmpeg -i input.mp4 \
  -c:v libx265 \              # H.265 codec (modern, efficient)
  -preset fast \              # Balanced speed/quality
  -crf 28 \                   # Quality level (lower = better)
  -b:v 2500k \                # Video bitrate
  -c:a aac \                  # Audio codec
  -b:a 128k \                 # Audio bitrate
  -s 1280x720 \               # Resolution scaling
  -r 30 \                     # Frame rate
  output.mp4
```

### 3. **Local Database**
Located: `lib/data/database/database_provider.dart`

Tables:
- `compression_history` - Compression records
- `compression_presets` - Quality mode presets

### 4. **UI Screens**
- **HomePage** - Main screen with stats & history
- **CompressionPage** - Video selection & quality mode (expandable)
- **HistoryPage** - Compression history (expandable)

---

## 📊 Data Flow Example

### Video Compression Flow

```
1. User taps "SELECT VIDEO" button
   ↓
2. CompressionBloc receives SelectVideoEvent
   ↓
3. VideoRepository.selectVideoFromGallery() called
   ↓
4. File selected, metadata extracted
   ↓
5. CompressionBloc emits VideoSelectedState
   ↓
6. UI displays video metadata & quality options
   ↓
7. User selects quality mode & taps "COMPRESS"
   ↓
8. CompressionBloc receives CompressVideoEvent
   ↓
9. CompressionRepository.compressVideo() called
   ↓
10. FFmpeg starts compression with streaming progress
   ↓
11. CompressionBloc emits CompressionInProgressState (every frame)
   ↓
12. UI updates progress bar in real-time
   ↓
13. FFmpeg finishes, CompressionBloc emits CompressionSuccessState
   ↓
14. DatabaseRepository saves record to SQLite
   ↓
15. UI shows success screen with compression metrics
   ↓
16. HistoryBloc loads updated history
   ↓
17. HomePage shows new item in recent compressions
```

---

## 🛠️ Development Workflow

### Step 1: Setup Environment
```bash
# Clone/navigate to project
cd video_compressor_pro

# Get dependencies
flutter pub get

# Check environment
flutter doctor
```

### Step 2: Run for Development
```bash
# Run with hot reload
flutter run

# Run with logging
flutter run -v

# Run on specific device
flutter run -d "emulator-name"
```

### Step 3: Make Changes
1. Edit Dart files in `lib/`
2. Hot reload (press 'r') to see changes instantly
3. Test features manually

### Step 4: Build for Testing
```bash
# Debug APK for testing
flutter build apk --debug

# Profile build (performance testing)
flutter build apk --profile

# Release build
flutter build apk --release
```

---

## 🎨 Customization Guide

### Change Theme Colors

Edit `lib/config/theme.dart`:

```dart
const Color primaryColor = Color(0xFF6366F1);      // Main brand color
const Color secondaryColor = Color(0xFF8B5CF6);    // Secondary color
const Color accentColor = Color(0xFF06B6D4);       // Accent color
const Color backgroundColor = Color(0xFFF8FAFC);   // Background

// Dark mode colors
const Color darkPrimaryColor = Color(0xFFA78BFA);
const Color darkBackgroundColor = Color(0xFF0F172A);
```

### Adjust Compression Presets

Edit `lib/data/models/compression_settings.dart`:

```dart
static CompressionSettings getPreset(QualityMode mode) {
  switch (mode) {
    case QualityMode.ultraCompress:
      return CompressionSettings(
        qualityMode: mode,
        targetResolution: '1280x720',    // Change resolution
        targetBitrate: 1500,              // Change bitrate (kbps)
        targetFps: 30,                    // Change frame rate
      );
    // ... other modes
  }
}
```

### Modify FFmpeg Parameters

Edit `lib/data/repositories/compression_repository.dart`:

```dart
String _buildFFmpegCommand(
  String inputPath,
  String outputPath,
  CompressionSettings settings,
) {
  return '-i "$inputPath" '
    '-c:v libx265 '              // Codec (libx264 for older devices)
    '-preset fast '              // Speed (fast/medium/slow)
    '-crf 28 '                   // Quality (0-51, lower = better)
    '-b:v ${settings.targetBitrate}k '
    // ... add more parameters
  ;
}
```

---

## 🧪 Testing Strategy

### Unit Tests (Repository Layer)
```bash
flutter test test/repositories/
```

Test areas:
- Video metadata extraction
- FFmpeg command building
- Database operations
- BLoC event handling

### Widget Tests (UI Layer)
```bash
flutter test test/presentation/
```

Test areas:
- Widget rendering
- User interactions
- Navigation
- State updates

### Integration Tests (Full Flow)
```bash
flutter test integration_test/
```

Test areas:
- Complete compression flow
- Database persistence
- Error handling

---

## 📊 Performance Optimization

### 1. **Image & Media Handling**
```dart
// Use lazy loading for thumbnails
final thumbnail = await VideoThumbnail.thumbnailFile(
  video: videoPath,
  maxHeight: 200,      // Limit resolution
  quality: 75,         // Reduce quality
);
```

### 2. **Database Queries**
```dart
// Use indexed columns for faster queries
// In database_provider.dart:
// CREATE INDEX idx_created_at ON compression_history(created_at);
```

### 3. **Memory Management**
```dart
// Clean up old records periodically
await databaseRepository.clearOldRecords(daysOld: 30);
```

### 4. **FFmpeg Optimization**
```bash
# Use faster preset
-preset fast    # Instead of "medium" or "slow"

# Reduce quality if size critical
-crf 32         # Instead of 28 (lower quality, smaller size)
```

---

## 🚀 Deployment Checklist

### Pre-Release
- [ ] Increment version in `pubspec.yaml`
- [ ] Update `CHANGELOG.md`
- [ ] Run `flutter test` - all tests pass
- [ ] Run `flutter analyze` - no warnings
- [ ] Test on real device (Android & iOS)
- [ ] Verify all UI screens work
- [ ] Test compression with various video formats

### Android Release
- [ ] Create signed keystore: `keytool -genkey ...`
- [ ] Build AAB: `flutter build appbundle --release`
- [ ] Build APK: `flutter build apk --split-per-abi --release`
- [ ] Test APK on device
- [ ] Upload AAB to Google Play Console
- [ ] Fill app details, permissions, screenshots
- [ ] Submit for review

### iOS Release
- [ ] Update app version in Xcode
- [ ] Create signing certificate & provisioning profile
- [ ] Build: `flutter build ios --release`
- [ ] Create archive in Xcode
- [ ] Upload to App Store Connect
- [ ] Fill app details, screenshots, privacy policy
- [ ] Submit for review

---

## 🐛 Debugging Tips

### Enable Verbose Logging
```bash
flutter run -v
```

### Debug FFmpeg Issues
Add logging in `compression_repository.dart`:
```dart
final session = await FFmpegKit.executeAsync(command);
final logs = await session.getLogs();
logs.forEach((log) => print(log.message));
```

### Inspect Database
```bash
# Use Android Studio device file explorer
# Or use adb:
adb pull /data/data/com.fadhil.videoprocompressor/databases/video_compressor.db
```

### Track BLoC State Changes
```dart
// Add this in main.dart
Bloc.observer = SimpleBlocObserver();
```

---

## 📚 Code Organization Best Practices

### File Naming
```
✅ GOOD:
- video_metadata.dart
- compression_bloc.dart
- home_page.dart

❌ BAD:
- VideoMetadata.dart
- CompressionBloc.dart
- HomePage.dart
```

### Class Organization
```dart
class MyClass {
  // 1. Static members
  static const String _constant = 'value';
  
  // 2. Instance variables
  final String _private;
  String public = '';
  
  // 3. Constructor
  MyClass(this._private);
  
  // 4. Public methods
  void publicMethod() {}
  
  // 5. Private methods
  void _privateMethod() {}
  
  // 6. Getters
  String get property => _private;
}
```

### Comments
```dart
// GOOD: Explain WHY, not WHAT
// We use H.265 codec because it provides 40% better compression
// than H.264 with minimal quality loss on modern devices.
final codec = 'libx265';

// BAD: Obvious comments are noise
// Set the codec to libx265
final codec = 'libx265';
```

---

## 🔐 Security Best Practices

1. **File Permissions**
   - Request minimal required permissions
   - Handle permission denials gracefully

2. **Data Storage**
   - Store sensitive data in app-specific directories
   - Clear temp files after use
   - Don't expose file paths in logs

3. **API Security** (if adding backend)
   - Use HTTPS only
   - Implement certificate pinning
   - Validate all inputs

4. **Code Security**
   - Don't hardcode secrets
   - Use environment variables for config
   - Sanitize user inputs

---

## 📈 Analytics Integration (Optional)

If you want to track app usage:

```dart
// In main.dart
import 'package:firebase_analytics/firebase_analytics.dart';

final analytics = FirebaseAnalytics.instance;

// Track events
await analytics.logEvent(
  name: 'video_compressed',
  parameters: {
    'quality_mode': 'balanced',
    'file_size': 185000000,
    'output_size': 45000000,
  },
);
```

---

## 🎓 Learning Path

**If you want to understand the codebase:**

1. **Start with** `lib/main.dart` - App entry point
2. **Learn** `lib/config/theme.dart` - Design system
3. **Understand** `lib/presentation/pages/home_page.dart` - UI
4. **Study** `lib/presentation/bloc/compression_bloc.dart` - State management
5. **Explore** `lib/data/repositories/` - Business logic
6. **Deep dive** `lib/data/database/` - Data persistence

---

## 🤝 Contributing Code

### Code Review Checklist
- [ ] Follows naming conventions
- [ ] No commented-out code
- [ ] Proper error handling
- [ ] Includes helpful comments
- [ ] No unused imports
- [ ] Tests included (if applicable)

### Commit Message Format
```
feat: Add video compression progress tracking
fix: Handle permission denial on Android 11+
docs: Update README with FFmpeg parameters
refactor: Simplify BLoC event handling
test: Add compression repository tests
```

---

## 📞 Troubleshooting

### Build Errors
```bash
# Clean everything
flutter clean
rm -rf pubspec.lock
rm -rf ios/Pods

# Reinstall
flutter pub get
flutter pub cache repair
```

### FFmpeg Issues
```bash
# Clear FFmpeg cache
rm -rf ~/.ffmpeg-kit-flutter/

# Rebuild with clean
flutter clean
flutter build apk --release
```

### Database Issues
```dart
// Reset database (development only!)
await databaseProvider.resetDatabase();
```

---

## 🎉 Next Steps

1. ✅ Review the complete source code
2. ✅ Run `flutter pub get`
3. ✅ Run the app: `flutter run`
4. ✅ Test all features manually
5. ✅ Customize theme/colors
6. ✅ Adjust compression settings
7. ✅ Build release APK/AAB
8. ✅ Deploy to stores

---

**Happy coding! 🚀**

For questions or issues, refer to:
- README.md - Project overview
- QUICKSTART.md - Quick setup
- Inline code comments - Implementation details
- Flutter Docs - Framework documentation
