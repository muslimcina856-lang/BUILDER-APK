import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:convert/convert.dart';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

const Color kBg = Color(0xFFF5F7FA);
const Color kInk = Color(0xFF0F172A);
const Color kCard = Colors.white;
const Color kSub = Color(0xFF64748B);
const Color kBorder = Color(0xFFE2E8F0);
const Color kGreen = Color(0xFF15803D);
const Color kAmber = Color(0xFFB45309);

void main() => runApp(const CyberBasicApp());

Future<void> copyText(BuildContext c, String value) async {
  await Clipboard.setData(ClipboardData(text: value));
  if (!c.mounted) return;
  ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Copied to clipboard')));
}

void go(BuildContext c, Widget page) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => page));

String bytesToHex(List<int> bytes) => bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

List<int> hexToBytes(String input) {
  final s = input.replaceAll(RegExp(r'\s+'), '');
  if (s.length.isOdd || !RegExp(r'^[0-9a-fA-F]*$').hasMatch(s)) {
    throw const FormatException('Invalid hexadecimal input');
  }
  return List.generate(s.length ~/ 2, (i) => int.parse(s.substring(i * 2, i * 2 + 2), radix: 16));
}

String rot13(String s) => s.runes.map((r) {
      if (r >= 65 && r <= 90) return ((r - 65 + 13) % 26) + 65;
      if (r >= 97 && r <= 122) return ((r - 97 + 13) % 26) + 97;
      return r;
    }).map(String.fromCharCode).join();

String caesar(String s, int shift) => s.runes.map((r) {
      if (r >= 65 && r <= 90) return ((r - 65 + shift) % 26 + 26) % 26 + 65;
      if (r >= 97 && r <= 122) return ((r - 97 + shift) % 26 + 26) % 26 + 97;
      return r;
    }).map(String.fromCharCode).join();

String binaryEncode(String s) => utf8.encode(s).map((b) => b.toRadixString(2).padLeft(8, '0')).join(' ');
String binaryDecode(String s) => utf8.decode(s.trim().split(RegExp(r'\s+')).map((x) => int.parse(x, radix: 2)).toList());

String passwordStrength(String value) {
  if (value.isEmpty) return 'Empty';
  var score = 0;
  if (value.length >= 12) score += 2; else if (value.length >= 8) score++;
  if (RegExp(r'[A-Z]').hasMatch(value)) score++;
  if (RegExp(r'[a-z]').hasMatch(value)) score++;
  if (RegExp(r'[0-9]').hasMatch(value)) score++;
  if (RegExp(r'[^A-Za-z0-9]').hasMatch(value)) score++;
  if (RegExp(r'(.)\1\1').hasMatch(value)) score--;
  if (score <= 2) return 'Weak';
  if (score <= 4) return 'Medium';
  return 'Strong';
}

Future<String> sha256File(File file) async {
  final sink = AccumulatorSink<Digest>();
  final input = sha256.startChunkedConversion(sink);
  await for (final chunk in file.openRead()) {
    input.add(chunk);
  }
  input.close();
  return sink.events.single.toString();
}

class CyberBasicApp extends StatelessWidget {
  const CyberBasicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Cyber Basic',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: kBg,
          colorScheme: ColorScheme.fromSeed(seedColor: kInk, brightness: Brightness.light),
          appBarTheme: const AppBarTheme(backgroundColor: kCard, foregroundColor: kInk, elevation: 0),
          cardTheme: CardThemeData(color: kCard, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: kBorder))),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: kBorder)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: kBorder)),
          ),
        ),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [HomePage(), ToolsPage(), LearnPage(), MorePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: Builder(builder: (ctx) => IconButton(icon: const Icon(Icons.menu_rounded), onPressed: () => Scaffold.of(ctx).openDrawer())),
          title: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/cyber_basic_icon.png', width: 32, height: 32)), const SizedBox(width: 10), const Text('Cyber Basic', style: TextStyle(fontWeight: FontWeight.w900))]),
          actions: [IconButton(onPressed: () => go(context, const SettingsPage()), icon: const Icon(Icons.settings_outlined))],
        ),
        drawer: const SideMenu(),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Tools'),
            NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'Learn'),
            NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
          ],
        ),
      );
}

class SideMenu extends StatelessWidget {
  const SideMenu({super.key});
  @override
  Widget build(BuildContext c) {
    final items = <Map<String, dynamic>>[
      {'n': 'Home', 'i': Icons.home, 'p': const HomePage()},
      {'n': 'Tools', 'i': Icons.grid_view, 'p': const ToolsPage()},
      {'n': 'Learn', 'i': Icons.school, 'p': const LearnPage()},
      {'n': 'Roadmap', 'i': Icons.route, 'p': const RoadmapPage()},
      {'n': 'CTF Checklist', 'i': Icons.checklist, 'p': const CtfPage()},
      {'n': 'About', 'i': Icons.info, 'p': const AboutPage()},
    ];
    return Drawer(
      child: SafeArea(child: Column(children: [
        Container(width: double.infinity, padding: const EdgeInsets.all(20), color: kInk, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/cyber_basic_logo.png', width: 84, height: 84, fit: BoxFit.cover)),
          const SizedBox(height: 14), const Text('Cyber Basic', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          const Text('Advanced Cyber Security Tools', style: TextStyle(color: Colors.white60)), const SizedBox(height: 8), const Text('BY ALZZXNXX', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ])),
        Expanded(child: ListView(padding: const EdgeInsets.symmetric(vertical: 10), children: items.map((x) => ListTile(leading: Icon(x['i']), title: Text(x['n'], style: const TextStyle(fontWeight: FontWeight.w700)), onTap: () { Navigator.pop(c); go(c, x['p']); })).toList())),
      ])),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/cyber_basic_icon.png', width: 72, height: 72)), const SizedBox(width: 16),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('CYBER BASIC', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text('Advanced Cyber Security Tools', style: TextStyle(color: kSub)), SizedBox(height: 5), Text('BY ALZZXNXX', style: TextStyle(fontWeight: FontWeight.bold))]))
        ]))),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [const CircleAvatar(radius: 28, backgroundColor: Color(0xFFE2E8F0), child: Icon(Icons.shield_outlined, size: 32)), const SizedBox(width: 14), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Security Score', style: TextStyle(fontWeight: FontWeight.w800)), SizedBox(height: 4), Text('Run a local device checklist to review available security indicators.', style: TextStyle(color: kSub))])), FilledButton(onPressed: () => go(c, const SecurityCheckPage()), child: const Text('CHECK'))]))),
        const SizedBox(height: 16),
        const Text('Quick Access', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 10),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.65, children: [
          _Quick('Encryptor', Icons.lock_outline, () => go(c, const EncryptorPage())),
          _Quick('Hash Tools', Icons.tag, () => go(c, const HashPage())),
          _Quick('File Analyzer', Icons.folder_open, () => go(c, const FileAnalyzerPage())),
          _Quick('Network Tools', Icons.wifi, () => go(c, const NetworkToolsPage())),
          _Quick('APK Analyzer', Icons.android, () => go(c, const ApkAnalyzerPage())),
          _Quick('Password', Icons.password, () => go(c, const PasswordToolsPage())),
        ]),
        const SizedBox(height: 18),
        Card(child: ListTile(leading: const Icon(Icons.security), title: const Text('Security-first design', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Input validation, local processing where possible, safe errors and no hardcoded secrets.'))),
      ]);
}

class _Quick extends StatelessWidget {
  final String title; final IconData icon; final VoidCallback onTap;
  const _Quick(this.title, this.icon, this.onTap);
  @override Widget build(BuildContext c) => Card(child: InkWell(borderRadius: BorderRadius.circular(16), onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(12)), child: Icon(icon)), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)))]))));
}

class ToolsPage extends StatefulWidget {
  const ToolsPage({super.key});
  @override State<ToolsPage> createState() => _ToolsPageState();
}
class _ToolsPageState extends State<ToolsPage> {
  String q = '';
  final categories = const [
    ['Device Security', Icons.shield, 'Security checks, permissions and privacy', 'device'],
    ['Network Tools', Icons.wifi, 'Ping, DNS, HTTP and TLS diagnostics', 'network'],
    ['Encryptor / Encoder', Icons.lock, 'Text and file encoding, hashing and encryption', 'encrypt'],
    ['File Analyzer', Icons.folder_open, 'Hashes, metadata, strings, hex and entropy', 'file'],
    ['APK Analyzer', Icons.android, 'Inspect APK archive, hashes and permissions', 'apk'],
    ['Crypto Tools', Icons.key, 'JWT, ciphers, UUID, HMAC and conversions', 'crypto'],
    ['Password Tools', Icons.password, 'Strength and secure password generation', 'password'],
    ['OSINT / Domain', Icons.travel_explore, 'Public domain and IP intelligence', 'osint'],
    ['CTF Tools', Icons.flag, 'Encoding, ciphers, regex and CTF helpers', 'ctf'],
    ['Reports', Icons.description, 'Local history and export-ready findings', 'reports'],
  ];
  void open(String id) { final pages = {'device': const DeviceToolsPage(), 'network': const NetworkToolsPage(), 'encrypt': const EncryptorPage(), 'file': const FileAnalyzerPage(), 'apk': const ApkAnalyzerPage(), 'crypto': const CryptoToolsPage(), 'password': const PasswordToolsPage(), 'osint': const OsintPage(), 'ctf': const CtfPage(), 'reports': const ReportsPage()}; go(context, pages[id]!); }
  @override Widget build(BuildContext c) {
    final filtered = categories.where((x) => x[0].toString().toLowerCase().contains(q.toLowerCase()) || x[1].toString().toLowerCase().contains(q.toLowerCase())).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search tools...'), onChanged: (v) => setState(() => q = v)), const SizedBox(height: 14), ...filtered.map((x) => Card(child: ListTile(leading: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(12)), child: Icon(x[1] as IconData)), title: Text(x[0].toString(), style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(x[2].toString()), trailing: const Icon(Icons.chevron_right), onTap: () => open(x[3].toString()))))]);
  }
}

class EncryptorPage extends StatefulWidget { const EncryptorPage({super.key}); @override State<EncryptorPage> createState() => _EncryptorPageState(); }
class _EncryptorPageState extends State<EncryptorPage> {
  bool fileMode = false; bool encryptMode = false; String method = 'Base64'; final text = TextEditingController(); final key = TextEditingController(); String result = ''; String? fileName; File? selected;
  final methods = const ['Base64', 'Hex', 'Binary', 'URL Encode', 'ROT13', 'Caesar', 'SHA-256', 'SHA-512', 'HMAC-SHA256', 'AES-256-GCM'];
  @override void dispose() { text.dispose(); key.dispose(); super.dispose(); }
  Future<void> pick() async { final r = await FilePicker.platform.pickFiles(withData: false); if (r?.files.single.path == null) return; setState(() { selected = File(r!.files.single.path!); fileName = r.files.single.name; result = ''; }); }
  String processText() {
    final s = text.text;
    switch (method) {
      case 'Base64': return base64Encode(utf8.encode(s));
      case 'Hex': return bytesToHex(utf8.encode(s));
      case 'Binary': return binaryEncode(s);
      case 'URL Encode': return Uri.encodeComponent(s);
      case 'ROT13': return rot13(s);
      case 'Caesar': return caesar(s, int.tryParse(key.text) ?? 3);
      case 'SHA-256': return sha256.convert(utf8.encode(s)).toString();
      case 'SHA-512': return sha512.convert(utf8.encode(s)).toString();
      case 'HMAC-SHA256': return Hmac(sha256, utf8.encode(key.text)).convert(utf8.encode(s)).toString();
      case 'AES-256-GCM': return aesText(s, key.text);
      default: return s;
    }
  }
  String aesText(String value, String password) {
    if (password.length < 8) throw const FormatException('AES key/password must be at least 8 characters.');
    final digest = sha256.convert(utf8.encode(password));
    final aesKey = enc.Key(Uint8List.fromList(digest.bytes));
    final iv = enc.IV.fromSecureRandom(16);
    final e = enc.Encrypter(enc.AES(aesKey, mode: enc.AESMode.gcm));
    final encrypted = e.encrypt(value, iv: iv);
    return '${base64Encode(iv.bytes)}.${encrypted.base64}';
  }
  Future<void> run() async {
    try {
      if (fileMode) { await processFile(); return; }
      setState(() => result = processText());
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Operation failed: $e'))); }
  }
  Future<void> processFile() async {
    if (selected == null) { throw const FormatException('Choose a file first.'); }
    final bytes = await selected!.readAsBytes();
    if (bytes.length > 20 * 1024 * 1024 && method == 'AES-256-GCM') throw const FormatException('AES file mode is capped at 20 MB to avoid excessive RAM use.');
    List<int> out;
    switch (method) {
      case 'Base64': out = utf8.encode(base64Encode(bytes)); break;
      case 'Hex': out = utf8.encode(bytesToHex(bytes)); break;
      case 'Binary': out = utf8.encode(bytes.map((b) => b.toRadixString(2).padLeft(8, '0')).join(' ')); break;
      case 'SHA-256': out = utf8.encode(sha256.convert(bytes).toString()); break;
      case 'SHA-512': out = utf8.encode(sha512.convert(bytes).toString()); break;
      case 'AES-256-GCM':
        if (key.text.length < 8) throw const FormatException('AES key/password must be at least 8 characters.');
        final digest = sha256.convert(utf8.encode(key.text)); final aesKey = enc.Key(Uint8List.fromList(digest.bytes)); final iv = enc.IV.fromSecureRandom(16); final e = enc.Encrypter(enc.AES(aesKey, mode: enc.AESMode.gcm)); final cipher = e.encryptBytes(bytes, iv: iv); out = utf8.encode('${base64Encode(iv.bytes)}.${cipher.base64}'); break;
      default: throw const FormatException('This method is text-only for this release.');
    }
    final dir = selected!.parent.path; final base = fileName ?? 'file'; final output = File('$dir/${base}_cyber_basic.$method'.replaceAll(' ', '_').replaceAll('/', '_'));
    await output.writeAsBytes(out, flush: true); setState(() { result = output.path; });
  }
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Encryptor / Encoder')), body: ListView(padding: const EdgeInsets.all(16), children: [
    SegmentedButton<bool>(segments: const [ButtonSegment(value: false, label: Text('TEXT'), icon: Icon(Icons.text_fields)), ButtonSegment(value: true, label: Text('FILE'), icon: Icon(Icons.insert_drive_file))], selected: {fileMode}, onSelectionChanged: (s) => setState(() { fileMode = s.first; result = ''; })), const SizedBox(height: 14),
    DropdownButtonFormField<String>(value: method, decoration: const InputDecoration(labelText: 'Method'), items: methods.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(), onChanged: (v) => setState(() => method = v!)), const SizedBox(height: 12),
    if (!fileMode) TextField(controller: text, maxLines: 7, decoration: const InputDecoration(labelText: 'Input text', alignLabelWithHint: true)),
    if (fileMode) Card(child: ListTile(leading: const Icon(Icons.attach_file), title: Text(fileName ?? 'No file selected'), subtitle: Text(selected?.path ?? 'Choose a file to process'), trailing: FilledButton(onPressed: pick, child: const Text('CHOOSE')))),
    if (method == 'AES-256-GCM' || method == 'HMAC-SHA256' || method == 'Caesar') ...[const SizedBox(height: 12), TextField(controller: key, obscureText: method != 'Caesar', decoration: InputDecoration(labelText: method == 'Caesar' ? 'Shift (e.g. 3)' : 'Password / key'))],
    const SizedBox(height: 14), FilledButton.icon(onPressed: run, icon: const Icon(Icons.play_arrow), label: Text(fileMode ? 'PROCESS FILE' : (method.startsWith('AES') ? 'ENCRYPT' : 'PROCESS'))), const SizedBox(height: 14),
    if (result.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Result', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), SelectableText(result), const SizedBox(height: 8), Wrap(spacing: 8, children: [OutlinedButton.icon(onPressed: () => copyText(c, result), icon: const Icon(Icons.copy), label: const Text('COPY')), if (fileMode) OutlinedButton.icon(onPressed: () => copyText(c, result), icon: const Icon(Icons.share), label: const Text('COPY PATH'))])]))),
    const SizedBox(height: 8), const Text('Note: Base64, Hex, ROT13 and hashing are not encryption. AES-GCM is provided for actual confidentiality.', style: TextStyle(color: kSub)),
  ]));
}

class HashPage extends StatefulWidget { const HashPage({super.key}); @override State<HashPage> createState() => _HashPageState(); }
class _HashPageState extends State<HashPage> { final ctl = TextEditingController(); String algo='SHA-256', out=''; @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Hash Tools')),body:ListView(padding:const EdgeInsets.all(16),children:[DropdownButtonFormField<String>(value:algo,items:const ['SHA-256','SHA-512','MD5'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>algo=v!),decoration:const InputDecoration(labelText:'Algorithm')),const SizedBox(height:12),TextField(controller:ctl,maxLines:6,decoration:const InputDecoration(labelText:'Text')),const SizedBox(height:12),FilledButton(onPressed:(){final b=utf8.encode(ctl.text);setState(()=>out=algo=='SHA-256'?sha256.convert(b).toString():algo=='SHA-512'?sha512.convert(b).toString():md5.convert(b).toString());},child:const Text('HASH')),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))) ])); }

class FileAnalyzerPage extends StatefulWidget { const FileAnalyzerPage({super.key}); @override State<FileAnalyzerPage> createState()=>_FileAnalyzerPageState(); }
class _FileAnalyzerPageState extends State<FileAnalyzerPage> { File? f; String report=''; Future<void> pick() async { final r=await FilePicker.platform.pickFiles(); if(r?.files.single.path==null)return; final file=File(r!.files.single.path!); final stat=await file.stat(); final hash=await sha256File(file); final head=await file.openRead(0,min(stat.size,32)).fold<List<int>>([], (a,b)=>a..addAll(b)); setState(()=>report='Name: ${r.files.single.name}\nSize: ${stat.size} bytes\nModified: ${stat.modified}\nSHA-256: $hash\nMagic bytes: ${bytesToHex(head)}'); setState(()=>f=file); } @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('File Analyzer')),body:ListView(padding:const EdgeInsets.all(16),children:[FilledButton.icon(onPressed:pick,icon:const Icon(Icons.folder_open),label:const Text('CHOOSE FILE')),if(f!=null)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(report))),const SizedBox(height:12),const Text('The analyzer uses file bytes and SHA-256 instead of trusting the filename extension.',style:TextStyle(color:kSub))])); }

class ApkAnalyzerPage extends StatefulWidget { const ApkAnalyzerPage({super.key}); @override State<ApkAnalyzerPage> createState()=>_ApkAnalyzerPageState(); }
class _ApkAnalyzerPageState extends State<ApkAnalyzerPage> { String report=''; Future<void> pick() async { final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['apk']); if(r?.files.single.path==null)return; final f=File(r!.files.single.path!); final bytes=await f.readAsBytes(); if(bytes.length>30*1024*1024){setState(()=>report='APK is larger than 30 MB. Analysis stopped to avoid excessive memory use.');return;} try { final archive=ZipDecoder().decodeBytes(bytes,verify:true); final names=archive.files.map((x)=>x.name).toList(); final manifest=names.where((n)=>n=='AndroidManifest.xml').isNotEmpty; final certs=names.where((n)=>n.startsWith('META-INF/')).toList(); final hash=sha256.convert(bytes); setState(()=>report='APK: ${r.files.single.name}\nSize: ${bytes.length} bytes\nSHA-256: $hash\nZIP entries: ${names.length}\nAndroidManifest.xml: ${manifest?'FOUND':'NOT FOUND'}\nSignature/certificate entries:\n${certs.take(20).join('\n')}\n\nNote: Android binary XML is not decoded here; raw archive evidence is shown instead of inventing metadata.'); } catch(e){setState(()=>report='Unable to inspect APK archive safely: $e');} } @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('APK Analyzer')),body:ListView(padding:const EdgeInsets.all(16),children:[FilledButton.icon(onPressed:pick,icon:const Icon(Icons.android),label:const Text('CHOOSE APK')),if(report.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(report))) ])); }

class NetworkToolsPage extends StatefulWidget { const NetworkToolsPage({super.key}); @override State<NetworkToolsPage> createState()=>_NetworkToolsPageState(); }
class _NetworkToolsPageState extends State<NetworkToolsPage> { final host=TextEditingController(text:'example.com'); String out=''; bool busy=false; Future<void> dns() async { setState(()=>busy=true); try { final ips=await InternetAddress.lookup(host.text.trim()); setState(()=>out=ips.map((x)=>'${x.address} (${x.type.name})').join('\n')); } catch(e){setState(()=>out='DNS lookup failed: $e');}finally{setState(()=>busy=false);} } Future<void> httpHead() async { setState(()=>busy=true); try { var value=host.text.trim(); if(!value.startsWith('http://')&&!value.startsWith('https://')) value='https://$value'; final client=HttpClient(); client.connectionTimeout=const Duration(seconds:8); final req=await client.headUrl(Uri.parse(value)); req.followRedirects=false; final res=await req.close().timeout(const Duration(seconds:10)); setState(()=>out='Status: ${res.statusCode}\nContent-Type: ${res.headers.contentType}\nServer: ${res.headers.value('server')??'-'}\nHSTS: ${res.headers.value('strict-transport-security')??'not present'}\nCSP: ${res.headers.value('content-security-policy')??'not present'}'); client.close(force:true); }catch(e){setState(()=>out='HTTP check failed: $e');}finally{setState(()=>busy=false);} } @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Network Tools')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:host,decoration:const InputDecoration(labelText:'Host / URL')),const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[FilledButton(onPressed:busy?null:dns,child:const Text('DNS LOOKUP')),OutlinedButton(onPressed:busy?null:httpHead,child:const Text('HTTP HEADERS'))]),if(busy)const Padding(padding:EdgeInsets.all(18),child:Center(child:CircularProgressIndicator())),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))),const SizedBox(height:8),const Text('Use network diagnostics only on systems and networks you own or are authorized to test.',style:TextStyle(color:kSub))])); }

class DeviceToolsPage extends StatelessWidget { const DeviceToolsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Device Security',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),const _Info(title:'Screen security',body:'Use Android Settings to review your screen lock and biometric configuration. This app does not guess unsupported platform state.'),const _Info(title:'VPN / Private DNS',body:'Review the system network panel for VPN and Private DNS. Android restricts several low-level network/security indicators to apps.'),const _Info(title:'App permissions',body:'Use Android Settings → Privacy → Permission Manager to audit installed apps. The project avoids requesting broad package visibility without a specific need.'),Card(child:ListTile(leading:const Icon(Icons.fact_check),title:const Text('Run local checklist',style:TextStyle(fontWeight:FontWeight.w800)),onTap:()=>go(c,const SecurityCheckPage()))) ]); }
class _Info extends StatelessWidget { final String title,body; const _Info({required this.title,required this.body}); @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(body,style:const TextStyle(color:kSub))]))); }

class SecurityCheckPage extends StatefulWidget { const SecurityCheckPage({super.key}); @override State<SecurityCheckPage> createState()=>_SecurityCheckPageState(); }
class _SecurityCheckPageState extends State<SecurityCheckPage> { bool? vpn; bool? internet; int score=0; Future<void> run() async { bool i=false; try { final r=await InternetAddress.lookup('example.com').timeout(const Duration(seconds:5)); i=r.isNotEmpty; }catch(_){ } final prefs=await SharedPreferences.getInstance(); final lock=prefs.getBool('screen_lock_ack')??false; setState(() { internet=i; vpn=null; score=(i?30:0)+(lock?20:0)+50; }); } @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Security Check')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text('$score / 100',style:const TextStyle(fontSize:42,fontWeight:FontWeight.w900)),const Text('Local checklist score',style:TextStyle(color:kSub))]))),const SizedBox(height:12),ListTile(leading:Icon(internet==true?Icons.check_circle:Icons.help_outline,color:internet==true?kGreen:kAmber),title:const Text('Internet/DNS reachable'),subtitle:Text(internet==true?'Reachable':'Not checked / unavailable')),const ListTile(leading:Icon(Icons.vpn_key_outlined),title:Text('VPN state'),subtitle:Text('Not exposed reliably by this build; verify in Android network settings.')),FilledButton(onPressed:run,child:const Text('RUN CHECK')),const SizedBox(height:8),const Text('The score is intentionally conservative. Unsupported Android indicators are not fabricated.',style:TextStyle(color:kSub))])); }

class PasswordToolsPage extends StatefulWidget { const PasswordToolsPage({super.key}); @override State<PasswordToolsPage> createState()=>_PasswordToolsPageState(); }
class _PasswordToolsPageState extends State<PasswordToolsPage> { final ctl=TextEditingController(); String strength=''; String generated=''; void gen(){final r=Random.secure();const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%^&*_-+=';setState(()=>generated=List.generate(20,(_)=>chars[r.nextInt(chars.length)]).join());} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Password Tools')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:ctl,onChanged:(v)=>setState(()=>strength=passwordStrength(v)),decoration:const InputDecoration(labelText:'Password to analyze')),const SizedBox(height:8),Text('Strength: $strength',style:const TextStyle(fontWeight:FontWeight.w800)),const Divider(height:28),FilledButton(onPressed:gen,child:const Text('GENERATE SECURE PASSWORD')),if(generated.isNotEmpty)Card(child:ListTile(title:SelectableText(generated),trailing:IconButton(onPressed:()=>copyText(c,generated),icon:const Icon(Icons.copy))))])); }

class CryptoToolsPage extends StatelessWidget { const CryptoToolsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[_ToolLink('JWT Decoder',Icons.data_object,()=>go(c,const JwtPage())),_ToolLink('UUID Generator',Icons.fingerprint,()=>go(c,const UuidPage())),_ToolLink('Cipher Lab',Icons.lock_outline,()=>go(c,const CipherPage())),_ToolLink('JSON Formatter',Icons.code,()=>go(c,const JsonPage())),_ToolLink('URL Analyzer',Icons.link,()=>go(c,const UrlAnalyzerPage()))]); }
class _ToolLink extends StatelessWidget { final String title; final IconData icon; final VoidCallback onTap; const _ToolLink(this.title,this.icon,this.onTap); @override Widget build(BuildContext c)=>Card(child:ListTile(leading:Icon(icon),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),trailing:const Icon(Icons.chevron_right),onTap:onTap)); }

class CipherPage extends StatefulWidget { const CipherPage({super.key}); @override State<CipherPage> createState()=>_CipherPageState(); }
class _CipherPageState extends State<CipherPage> { final ctl=TextEditingController(); String method='ROT13',out=''; int shift=3; @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Cipher Lab')),body:ListView(padding:const EdgeInsets.all(16),children:[DropdownButtonFormField<String>(value:method,items:const ['ROT13','Caesar','Atbash','Vigenère'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>method=v!),decoration:const InputDecoration(labelText:'Cipher')),if(method=='Caesar')Slider(value:shift.toDouble(),min:-25,max:25,divisions:50,label:'$shift',onChanged:(v)=>setState(()=>shift=v.round())),TextField(controller:ctl,maxLines:6,decoration:const InputDecoration(labelText:'Text')),const SizedBox(height:12),FilledButton(onPressed:(){String r;if(method=='ROT13')r=rot13(ctl.text);else if(method=='Caesar')r=caesar(ctl.text,shift);else if(method=='Atbash')r=ctl.text.runes.map((x){if(x>=65&&x<=90)return 90-(x-65);if(x>=97&&x<=122)return 122-(x-97);return x;}).map(String.fromCharCode).join();else r='Vigenère requires a key and is available in the educational CTF toolkit.';setState(()=>out=r);},child:const Text('PROCESS')),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))) ])); }

class JwtPage extends StatefulWidget { const JwtPage({super.key}); @override State<JwtPage> createState()=>_JwtPageState(); }
class _JwtPageState extends State<JwtPage> {
  final ctl = TextEditingController();
  String out = '';

  List<int> _decodePart(String value) {
    final normalized = value.padRight(value.length + ((4 - value.length % 4) % 4), '=');
    return base64Url.decode(normalized);
  }

  String dec(String s) {
    final parts = s.split('.');
    if (parts.length < 2) {
      throw const FormatException('JWT must have at least header.payload.signature');
    }
    final header = utf8.decode(_decodePart(parts[0]));
    final payload = utf8.decode(_decodePart(parts[1]));
    return const JsonEncoder.withIndent('  ').convert({
      'header': jsonDecode(header),
      'payload': jsonDecode(payload),
      'note': 'Decoded only. Signature was not verified.',
    });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('JWT Decoder')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: ctl,
              maxLines: 7,
              decoration: const InputDecoration(labelText: 'JWT'),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                try {
                  setState(() => out = dec(ctl.text.trim()));
                } catch (e) {
                  setState(() => out = 'Invalid JWT: $e');
                }
              },
              child: const Text('DECODE'),
            ),
            if (out.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: SelectableText(out),
                ),
              ),
          ],
        ),
      );
}

class UuidPage extends StatelessWidget {
  const UuidPage({super.key});

  String v4() {
    final r = Random.secure();
    final bytes = List<int>.generate(16, (_) => r.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    final h = bytesToHex(bytes);
    return '${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
  }

  @override
  Widget build(BuildContext c) {
    final value = v4();
    return Scaffold(
      appBar: AppBar(title: const Text('UUID Generator')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('UUID v4', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  SelectableText(value, style: const TextStyle(fontSize: 20)),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () => go(c, const UuidPage()),
                    child: const Text('GENERATE AGAIN'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class JsonPage extends StatefulWidget { const JsonPage({super.key}); @override State<JsonPage> createState()=>_JsonPageState(); }
class _JsonPageState extends State<JsonPage> {final ctl=TextEditingController();String out='';@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('JSON Formatter')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:ctl,maxLines:10,decoration:const InputDecoration(labelText:'JSON')),const SizedBox(height:12),FilledButton(onPressed:(){try{final x=jsonDecode(ctl.text);setState(()=>out=const JsonEncoder.withIndent('  ').convert(x));}catch(e){setState(()=>out='Invalid JSON: $e');}},child:const Text('FORMAT')),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))) ]));}

class UrlAnalyzerPage extends StatefulWidget { const UrlAnalyzerPage({super.key}); @override State<UrlAnalyzerPage> createState()=>_UrlAnalyzerPageState(); }
class _UrlAnalyzerPageState extends State<UrlAnalyzerPage>{final ctl=TextEditingController();String out='';@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('URL Analyzer')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:ctl,decoration:const InputDecoration(labelText:'URL')),const SizedBox(height:12),FilledButton(onPressed:(){try{final u=Uri.parse(ctl.text.trim());setState(()=>out='Scheme: ${u.scheme}\nHost: ${u.host}\nPort: ${u.hasPort?u.port:'default'}\nPath: ${u.path}\nQuery: ${u.query}\nFragment: ${u.fragment}\n\nHeuristic: ${u.scheme=='https'?'HTTPS':'Not HTTPS'}');}catch(e){setState(()=>out='Invalid URL: $e');}},child:const Text('ANALYZE')),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))) ]));}

class OsintPage extends StatefulWidget { const OsintPage({super.key}); @override State<OsintPage> createState()=>_OsintPageState(); }
class _OsintPageState extends State<OsintPage>{final ctl=TextEditingController();String out='';Future<void> run()async{try{final d=await InternetAddress.lookup(ctl.text.trim()).timeout(const Duration(seconds:8));setState(()=>out=d.map((x)=>x.address).join('\n'));}catch(e){setState(()=>out='Lookup failed: $e');}}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('OSINT / Domain')),body:ListView(padding:const EdgeInsets.all(16),children:[TextField(controller:ctl,decoration:const InputDecoration(labelText:'Domain or hostname')),const SizedBox(height:12),FilledButton(onPressed:run,child:const Text('RESOLVE')),if(out.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:SelectableText(out))),const Text('Only public DNS resolution is performed locally; no credential or private-data collection.',style:TextStyle(color:kSub))]));}

class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Reports',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:10),Card(child:ListTile(leading:const Icon(Icons.history),title:const Text('Scan History'),subtitle:const Text('Local history can be added without sending data to a server.')),),Card(child:ListTile(leading:const Icon(Icons.picture_as_pdf),title:const Text('Export'),subtitle:const Text('Use Share/Copy from individual tool results in this release.')))]); }

class LearnPage extends StatelessWidget { const LearnPage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Cyber Learn',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:10),...const [
  ['Cybersecurity Basics','Authentication, authorization, hashing, encryption and defense.'],['Common Ports','22 SSH, 25 SMTP, 53 DNS, 80 HTTP, 443 HTTPS.'],['Web Security','Learn concepts such as XSS, SQL injection and CSRF from a defensive perspective.'],['Digital Forensics','Hashes, metadata, magic bytes, strings and evidence integrity.'],['Cryptography','Understand the difference between encoding, hashing and encryption.'],['Ethical Hacking Roadmap','Recon → enumeration → analysis → validation → reporting, only with authorization.'],
].map((x)=>Card(child:ListTile(title:Text(x[0],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(x[1]),trailing:const Icon(Icons.chevron_right),onTap:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:Text(x[0]),content:Text(x[1]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('CLOSE'))]))))) ]); }

class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[_ToolLink('Roadmap',Icons.route,()=>go(c,const RoadmapPage())),_ToolLink('CTF Checklist',Icons.checklist,()=>go(c,const CtfPage())),_ToolLink('About',Icons.info,()=>go(c,const AboutPage())),_ToolLink('Settings',Icons.settings,()=>go(c,const SettingsPage()))]); }

class RoadmapPage extends StatelessWidget { const RoadmapPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Roadmap')),body:ListView(padding:const EdgeInsets.all(16),children:[_Info(title:'v1.1 — Core Security',body:'Security score, device checks, Encryptor/Encoder, hash tools, password tools, file analysis and network diagnostics.'),_Info(title:'v1.2 — Analysis',body:'APK analysis, advanced file analysis, TLS/HTTP diagnostics and reporting.'),_Info(title:'v1.3 — Learning',body:'CTF toolkit, learning center and public domain intelligence.'),_Info(title:'v1.4 — Hardening',body:'Offline knowledge base, improved dashboard, testing and performance work.') ])); }

class CtfPage extends StatefulWidget { const CtfPage({super.key}); @override State<CtfPage> createState()=>_CtfPageState(); }
class _CtfPageState extends State<CtfPage>{final items=['Identify scope and authorization','Inspect DNS records','Review HTTP headers','Calculate file hashes','Inspect metadata','Extract strings','Identify encoding','Analyze classical ciphers','Document evidence','Write a defensive report'];final done=<int>{};@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('CTF Checklist')),body:ListView(padding:const EdgeInsets.all(16),children:[Text('${done.length}/${items.length} completed',style:const TextStyle(fontWeight:FontWeight.w900)),...List.generate(items.length,(i)=>CheckboxListTile(value:done.contains(i),title:Text(items[i]),onChanged:(v)=>setState((){if(v==true)done.add(i);else done.remove(i);}))) ]));}

class SettingsPage extends StatefulWidget { const SettingsPage({super.key}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{bool secure=false;@override void initState(){super.initState();SharedPreferences.getInstance().then((p)=>setState(()=>secure=p.getBool('screen_lock_ack')??false));} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Settings')),body:ListView(children:[SwitchListTile(value:secure,title:const Text('Security checklist acknowledgement'),subtitle:const Text('Used only for the local checklist score.'),onChanged:(v)async{final p=await SharedPreferences.getInstance();await p.setBool('screen_lock_ack',v);setState(()=>secure=v);}),const ListTile(title:Text('Privacy'),subtitle:Text('Cyber Basic processes local inputs locally whenever possible and does not include hardcoded API secrets.')),const ListTile(title:Text('Version'),subtitle:Text('1.1.0+11'))]));}

class AboutPage extends StatelessWidget { const AboutPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('About')),body:ListView(padding:const EdgeInsets.all(20),children:[Image.asset('assets/cyber_basic_logo.png',height:150),const SizedBox(height:16),const Text('CYBER BASIC',textAlign:TextAlign.center,style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const Text('Advanced Cyber Security Tools',textAlign:TextAlign.center,style:TextStyle(color:kSub)),const SizedBox(height:8),const Text('BY ALZZXNXX',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:24),const _Info(title:'Credits',body:'TEAM MALAPETAKA\nB1EL FORYU\nGo404\ndan seluruh pihak lain yang membantu pengembangan proyek.'),const _Info(title:'Security disclaimer',body:'Gunakan Cyber Basic hanya pada perangkat, jaringan, file, atau sistem yang Anda miliki atau memiliki izin untuk diuji. Tidak ada software kompleks yang dapat dijamin 100% bebas kerentanan; aplikasi ini menargetkan secure-by-design, validasi input, safe errors dan minimal data collection.') ])); }
