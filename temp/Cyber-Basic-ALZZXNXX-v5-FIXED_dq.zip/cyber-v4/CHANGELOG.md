# Cyber Basic 1.1.0

- Unified Encryptor / Encoder for text and file workflows.
- Added Base64, Hex, Binary, URL encoding, ROT13, Caesar, hashing, HMAC and AES-GCM text/file processing.
- Added file analyzer with SHA-256, metadata and magic-byte preview.
- Added APK archive analyzer with SHA-256 and archive evidence.
- Added DNS and HTTP header diagnostics.
- Added password strength analysis and secure random password generation.
- Added JWT decoder, UUID generator, JSON formatter, URL analyzer and CTF checklist.
- Added security-focused error handling and size limits for expensive operations.
- Preserved the existing Cyber Basic branding and navigation.

Note: Android platform restrictions mean some device-security indicators cannot be truthfully exposed by a normal application. The app reports limitations instead of fabricating values.
