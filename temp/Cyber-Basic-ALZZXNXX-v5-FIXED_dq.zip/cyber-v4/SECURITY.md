# Security notes

Cyber Basic is intended for defensive security, education, file analysis and authorized diagnostics.

The app avoids hardcoded API secrets and does not intentionally collect credentials. Network tools should only be used against systems the user owns or is authorized to test.

File processing uses explicit size limits for operations that require in-memory buffers. File names are treated as untrusted input and output files are created separately from the original.

AES-GCM output is represented as `base64(iv).base64(ciphertext+tag)` by the encryption package. Password-derived keys are SHA-256(password) for compatibility in this release. For high-assurance password-based encryption, a memory-hard KDF such as Argon2id with a stored salt should be used in a future release.
