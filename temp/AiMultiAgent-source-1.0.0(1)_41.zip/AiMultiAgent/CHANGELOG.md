# Changelog

## 1.0.0+1 — Versi 1

- Mengekalkan versi paparan aplikasi sebagai `1.0.0`.
- Menggunakan `versionCode`/build number `1` sebagai build pertama aplikasi.
- Membetulkan ikon Material yang tidak wujud.
- Menambah pelaksanaan lengkap Skill Creator.
- Membetulkan pemeriksaan atribut HTML yang menyebabkan kompilasi gagal.
- Menggunakan UI chat premium, orchestrator model utama dan sub-agent dinamik.
- Menyokong provider BYOK, browser latar belakang, DuckDuckGo, media, fail, skills, automasi dan terminal.
- Mengunci `compileSdk` serta `targetSdk` kepada API 36.
