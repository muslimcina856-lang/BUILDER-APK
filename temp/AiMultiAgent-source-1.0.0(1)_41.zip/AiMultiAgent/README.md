# Ai MultiAgent

Ai MultiAgent ialah klien AI Android **local/BYOK** yang berhubung terus dari telefon kepada provider pilihan pengguna. Aplikasi tidak memerlukan akaun, login atau backend milik Ai MultiAgent.

| Perkara | Nilai |
|---|---|
| Nama aplikasi | Ai MultiAgent |
| Package ID | `com.aiauto.claw` |
| Versi sumber | `1.0.0+1` |
| Platform | Android |
| UI | Flutter |
| Android native | Kotlin |
| Compile/Target SDK | API 36 |
| Minimum SDK | API 24 |
| Data biasa | SQLite dan fail private local |
| API key | Flutter Secure Storage / Android Keystore |
| Backend aplikasi | Tiada |

## Pengalaman utama

- Antara muka chat premium tanpa pemilih agent tetap.
- Provider dan model dipilih secara ringkas melalui header chat.
- Model yang dipilih menjadi orchestrator utama dan boleh menggunakan tools, skills serta sub-agent dinamik secara automatik.
- Proses operasi dipaparkan di bawah perbualan dan dilipat menjadi ringkasan selepas jawapan siap.
- Markdown dirender dengan betul, termasuk tajuk, bold, senarai, pautan dan code block.
- Lampiran dan paparan chat untuk imej, video, audio, HTML, dokumen, arkib dan fail umum.
- Browser Android System WebView/Chromium berjalan tersembunyi di belakang UI; hasil teks, DOM, pautan, borang dan HTML dikembalikan ke chat.
- DuckDuckGo Search dengan parser HTML dan Lite fallback.
- Skill Creator ialah skill lalai; model menentukan sendiri bila tool atau skill diperlukan.
- Terminal latar belakang menyediakan status, `stdout`, `stderr` dan exit code kepada model.
- Automasi menggunakan WorkManager dan boleh menunjukkan notifikasi ongoing untuk tugasan panjang.

## Provider

Provider biasa hanya meminta:

1. API key, jika provider memerlukannya.
2. Model ID atau pilihan daripada senarai model.
3. **Uji & simpan**.

Provider local seperti Ollama dan LM Studio tidak meminta API key secara lalai. Hanya **Custom Provider** memaparkan Base URL, protokol, endpoint, kaedah autentikasi, header, template JSON dan JSON path respons.

Katalog mengandungi 52 preset termasuk Xiaomi MiMo, OpenAI, Anthropic, Gemini, DeepSeek, OpenRouter, Groq, Ollama dan LM Studio. Custom Provider kekal tersedia untuk API lain.

## Kelulusan tindakan

Tool biasa berjalan terus. Dialog hanya muncul apabila tindakan dikesan boleh memadam, menimpa atau merosakkan data, contohnya:

- Memadam fail atau memori.
- Menimpa fail sedia ada.
- Arahan terminal destruktif.
- HTTP `DELETE` atau tool MCP destruktif.

Pilihan kelulusan ialah **Sekali**, **Sesi ini**, **Sentiasa** atau **Tolak**. Kelulusan kekal disimpan local dan boleh ditarik balik dalam Tetapan. Sesi tamat selepas 30 minit tidak aktif atau apabila proses aplikasi ditutup tanpa tugasan background yang dibenarkan.

## Struktur projek

```text
AiMultiAgent/
├── mobile/                     # Flutter + Android Kotlin
│   ├── lib/src/data/           # Katalog provider
│   ├── lib/src/services/       # Provider, orchestrator, tools dan storage
│   ├── lib/src/state/          # State, sesi dan progres operasi
│   ├── lib/src/ui/             # Chat, provider, automasi, skills dan tetapan
│   ├── android/                # Kotlin, WebView tersembunyi dan konfigurasi release
│   └── test/                   # Ujian parser, polisi dan smoke test
├── assets/branding/            # Ikon sumber
├── docs/                       # Seni bina, fungsi, keselamatan dan release
├── scripts/                    # Semakan statik dan build
├── store/                      # Teks serta aset Google Play
└── .github/workflows/          # CI analyze/test/build release APK
```

## Jalankan

Flutter stable yang serasi, Android SDK API 36 dan Java 17 diperlukan.

```bash
cd mobile
flutter pub get
flutter run
```

Tiada URL backend atau secret build diperlukan. API key dan model dimasukkan sendiri melalui aplikasi.

## Semakan sumber

```bash
./scripts/check_project.sh
```

Skrip memeriksa struktur projek, provider, tools, resource Android, import Dart, delimiter, fixture DuckDuckGo, skrip shell dan fail Python. Jika Flutter tersedia, ia turut menjalankan format check, `flutter analyze` dan `flutter test`.

## Build

```bash
./scripts/build_debug.sh
./scripts/build_release.sh
```

Release APK boleh dibina untuk ujian. AAB Google Play hanya dibina apabila `mobile/android/key.properties` disediakan. Rujuk `docs/KEYSTORE.md` dan `docs/RELEASE_CHECKLIST.md`.

## Batasan pengesahan pakej ini

Persekitaran penyediaan sumber ini tidak mempunyai Flutter SDK/Android SDK, jadi kompilasi Flutter sebenar tidak dijalankan di sini. Semakan statik serta fixture lulus dan workflow CI disertakan untuk menjalankan format, analyze, test dan release build dalam persekitaran lengkap.
