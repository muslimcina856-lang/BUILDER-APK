#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
MOBILE = ROOT / "mobile"
errors: list[str] = []
notes: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def text(path: str) -> str:
    target = ROOT / path
    require(target.is_file(), f"Fail wajib tiada: {path}")
    return target.read_text(encoding="utf-8") if target.is_file() else ""


required = [
    "mobile/pubspec.yaml",
    "mobile/lib/main.dart",
    "mobile/lib/src/app.dart",
    "mobile/lib/src/config/app_config.dart",
    "mobile/lib/src/data/provider_catalog.dart",
    "mobile/lib/src/services/provider_service.dart",
    "mobile/lib/src/services/agent_runtime.dart",
    "mobile/lib/src/services/tool_engine.dart",
    "mobile/lib/src/services/permission_manager.dart",
    "mobile/lib/src/services/duckduckgo_search_service.dart",
    "mobile/lib/src/services/browser_session_service.dart",
    "mobile/lib/src/services/attachment_service.dart",
    "mobile/lib/src/services/terminal_service.dart",
    "mobile/lib/src/services/mcp_service.dart",
    "mobile/lib/src/services/skill_service.dart",
    "mobile/lib/src/ui/screens/chat_screen.dart",
    "mobile/lib/src/ui/screens/providers_screen.dart",
    "mobile/test/duckduckgo_search_service_test.dart",
    "mobile/android/app/src/main/AndroidManifest.xml",
    "mobile/android/app/src/main/kotlin/com/aiauto/claw/MainActivity.kt",
    "mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt",
    "mobile/android/app/proguard-rules.pro",
]
for item in required:
    text(item)

require(not (ROOT / "backend").exists(), "Direktori backend tidak dibenarkan.")
require(not (MOBILE / "lib/src/ui/screens/agents_screen.dart").exists(), "Skrin Agent lama masih wujud.")
require(not (MOBILE / "lib/src/ui/screens/browser_screen.dart").exists(), "Skrin Browser lama masih wujud.")

pubspec_raw = text("mobile/pubspec.yaml")
try:
    pubspec = yaml.safe_load(pubspec_raw)
except Exception as exc:
    errors.append(f"pubspec.yaml tidak sah: {exc}")
    pubspec = {}
require(pubspec.get("version") == "1.0.0+1", "Versi pubspec mesti 1.0.0+1.")
require("1.0.0+1" in text("README.md"), "README belum dikemas kini kepada 1.0.0+1.")
require("1.0.0+1" in text("docs/SOURCE_MANIFEST.md"), "Manifest sumber belum dikemas kini.")
require(pubspec.get("name") == "ai_multiagent", "Nama pakej Dart tidak tepat.")

home_shell = text("mobile/lib/src/ui/home_shell.dart")
skill_service = text("mobile/lib/src/services/skill_service.dart")
tool_engine = text("mobile/lib/src/services/tool_engine.dart")
require("Icons.scope_outlined" not in home_shell, "Ikon Material tidak sah scope_outlined masih digunakan.")
require(
    "Future<SkillDefinition> createFromTool(" in skill_service,
    "SkillService.createFromTool belum dilaksanakan.",
)
require(
    ".where((name) => name.toLowerCase()" not in tool_engine,
    "Key atribut HTML masih memanggil toLowerCase terus pada Object.",
)

app_build = text("mobile/android/app/build.gradle.kts")
require('applicationId = "com.aiauto.claw"' in app_build, "applicationId tidak tepat.")
require('namespace = "com.aiauto.claw"' in app_build, "namespace tidak tepat.")
require("compileSdk = 36" in app_build, "compileSdk mesti 36.")
require("targetSdk = 36" in app_build, "targetSdk mesti 36.")
require("minSdk = 24" in app_build, "minSdk mesti 24.")
require("isMinifyEnabled = true" in app_build, "R8/minify release belum diaktifkan.")
require("isShrinkResources = true" in app_build, "Resource shrinking release belum diaktifkan.")

settings = text("mobile/android/settings.gradle.kts")
require('com.android.application") version "8.11.1"' in settings, "AGP mesti 8.11.1.")
require('org.jetbrains.kotlin.android") version "2.2.20"' in settings, "Kotlin mesti 2.2.20.")
wrapper = text("mobile/android/gradle/wrapper/gradle-wrapper.properties")
require("gradle-8.14.3-bin.zip" in wrapper, "Gradle wrapper mesti 8.14.3.")
require("GRADLE_VERSION=8.14.3" in text("mobile/android/gradlew"), "Bootstrap gradlew Unix mesti 8.14.3.")
require("GRADLE_VERSION=8.14.3" in text("mobile/android/gradlew.bat"), "Bootstrap gradlew Windows mesti 8.14.3.")

manifest_path = MOBILE / "android/app/src/main/AndroidManifest.xml"
try:
    manifest_tree = ET.parse(manifest_path)
    app = manifest_tree.getroot().find("application")
    android_ns = "{http://schemas.android.com/apk/res/android}"
    require(app is not None, "Elemen application tiada dalam manifest.")
    if app is not None:
        require(app.attrib.get(android_ns + "label") == "Ai MultiAgent", "Label Android tidak tepat.")
except Exception as exc:
    errors.append(f"AndroidManifest.xml tidak sah: {exc}")
manifest = text("mobile/android/app/src/main/AndroidManifest.xml")
require("AccessibilityService" not in manifest, "AccessibilityService tidak dibenarkan.")
require("android.permission.INTERNET" in manifest, "Permission INTERNET tiada.")
require("android.permission.RECORD_AUDIO" in manifest, "Permission mikrofon tiada.")

launch = text("mobile/android/app/src/main/res/drawable/launch_background.xml")
require('android:drawable="@color/ic_launcher_background"' in launch, "Splash background mesti menggunakan resource warna.")
require('android:drawable="#' not in launch, "Warna literal tidak boleh digunakan pada android:drawable.")

catalog = text("mobile/lib/src/data/provider_catalog.dart")
provider_ids = re.findall(r"ProviderPreset\(id:\s*'([^']+)'", catalog)
require(len(provider_ids) >= 45, f"Preset provider terlalu sedikit: {len(provider_ids)}.")
require(len(provider_ids) == len(set(provider_ids)), "ID provider berulang.")
for provider_id in ["mimo", "openai", "anthropic", "gemini", "deepseek", "ollama", "custom_rest"]:
    require(provider_id in provider_ids, f"Provider wajib tiada: {provider_id}")
require("https://api.xiaomimimo.com/v1" in catalog, "Base URL Xiaomi MiMo tiada.")
require("token-plan-cn.xiaomimimo.com" not in catalog, "Preset MiMo yang tidak disahkan masih wujud.")

home = text("mobile/lib/src/ui/home_shell.dart")
require("AgentsScreen" not in home, "Tab Agent lama masih dirujuk.")
require("BrowserScreen" not in home, "Skrin Browser lama masih dirujuk.")
chat = text("mobile/lib/src/ui/screens/chat_screen.dart")
require("flutter_markdown_plus" in chat, "Renderer Markdown sebenar belum digunakan.")
require("_CompletedProcessCard" in chat and "_LiveProcessCard" in chat, "Paparan proses live/collapsed tidak lengkap.")
require("_ImagePreview" in chat and "_VideoPreview" in chat and "_AudioPreview" in chat, "Pratonton media chat tidak lengkap.")
require("_HtmlPreview" in chat, "Pratonton HTML dalam chat tiada.")
require("General Agent" not in chat, "General Agent tidak patut muncul dalam UI chat.")

provider_screen = text("mobile/lib/src/ui/screens/providers_screen.dart")
require("_tryBuildProvider" in provider_screen, "Provider editor belum menangani JSON/konfigurasi tidak sah.")
require("API key" in provider_screen and "Model ID" in provider_screen, "Aliran API key/model tidak lengkap.")

runtime = text("mobile/lib/src/services/agent_runtime.dart")
require("delegate_agent" in runtime, "Delegasi sub-agent tiada.")
require("depth >=" not in runtime and "maxDepth" not in runtime, "Had kedalaman agent tetap tidak dibenarkan.")
require("Jangan tukar provider atau model" in runtime, "Model mesti kekal pada provider/model pilihan pengguna.")
require("Tiada kata kunci pemicu" not in runtime, "Semak ejaan arahan trigger; frasa lapuk ditemui.")

engine = text("mobile/lib/src/services/tool_engine.dart")
tool_ids = re.findall(r"id:\s*'([^']+)'", engine[engine.find("List<ToolDefinition> get definitions"):engine.find("ToolDefinition? definition")])
require(len(set(tool_ids)) >= 25, f"Tools terlalu sedikit: {len(set(tool_ids))}.")
for tool_id in [
    "web_search", "browser_open", "browser_read", "browser_click", "browser_fill",
    "browser_submit_form", "browser_download", "file_read", "file_write", "file_delete",
    "terminal_start", "terminal_poll", "skill_create", "skill_run_script", "mcp_call",
]:
    require(tool_id in tool_ids, f"Tool wajib tiada: {tool_id}")
permission_start = engine.find("Future<bool> requiresPermission")
permission_end = engine.find("String permissionScope", permission_start)
permission_block = engine[permission_start:permission_end]
require("browser_submit_form" not in permission_block, "Hantar borang tidak patut meminta approval biasa.")
require("memory_delete" in permission_block and "file_delete" in permission_block, "Pemadaman mesti dianggap berisiko.")
require("terminalService.isDestructiveCommand" in permission_block, "Arahan terminal destruktif mesti dikesan.")

browser_native = text("mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt")
for capability in ["evaluateJavascript", "document.querySelector", "requestSubmit", "document.documentElement.outerHTML"]:
    require(capability in browser_native, f"Keupayaan browser native tiada: {capability}")
require("translationX = -10000f" in browser_native, "Browser mesti tersembunyi di latar UI.")

skill_service = text("mobile/lib/src/services/skill_service.dart")
require("Skill Creator" in skill_service, "Skill Creator default tiada.")
skills_screen = text("mobile/lib/src/ui/screens/skills_screen.dart")
require("Pemilihan automatik" in skills_screen, "UI skill automatik tiada.")
require("labelText: 'Trigger" not in skills_screen and "title: const Text('Trigger" not in skills_screen, "UI trigger manual tidak dibenarkan.")

permission = text("mobile/lib/src/services/permission_manager.dart")
for decision in ["allowOnce", "allowSession", "allowAlways", "deny"]:
    require(decision in permission, f"Keputusan permission tiada: {decision}")
settings_screen = text("mobile/lib/src/ui/screens/settings_screen.dart")
require("Sentiasa benarkan" in settings_screen, "Tetapan approval kekal tiada.")

# Parse all XML/JSON/YAML source files.
for path in ROOT.rglob("*.xml"):
    try:
        ET.parse(path)
    except Exception as exc:
        errors.append(f"XML tidak sah {path.relative_to(ROOT)}: {exc}")
for path in ROOT.rglob("*.json"):
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"JSON tidak sah {path.relative_to(ROOT)}: {exc}")
for path in [ROOT / ".github/workflows/android-release-check.yml"]:
    if path.exists():
        try:
            yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"YAML tidak sah {path.relative_to(ROOT)}: {exc}")

# Resolve relative Dart imports and check balanced delimiters while ignoring comments/strings.
def check_dart(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    for match in re.finditer(r"^import\s+['\"]([^'\"]+)['\"]", source, re.M):
        target = match.group(1)
        if target.startswith("."):
            resolved = (path.parent / target).resolve()
            if not resolved.exists():
                errors.append(f"Import relatif tiada {path.relative_to(ROOT)}: {target}")

    pairs = {"(": ")", "[": "]", "{": "}"}
    closers = set(pairs.values())
    stack: list[tuple[str, int]] = []
    i = 0
    state = "code"
    quote = ""
    raw = False
    while i < len(source):
        c = source[i]
        n = source[i + 1] if i + 1 < len(source) else ""
        if state == "code":
            if c == "/" and n == "/":
                state = "line"; i += 2; continue
            if c == "/" and n == "*":
                state = "block"; i += 2; continue
            if c in "rR" and n in "'\"":
                raw = True; quote = n
                if source[i + 1:i + 4] == n * 3:
                    state = "triple"; i += 4; continue
                state = "string"; i += 2; continue
            if c in "'\"":
                raw = False; quote = c
                if source[i:i + 3] == c * 3:
                    state = "triple"; i += 3; continue
                state = "string"; i += 1; continue
            if c in pairs:
                stack.append((c, i))
            elif c in closers:
                if not stack or pairs[stack[-1][0]] != c:
                    errors.append(f"Delimiter tidak sepadan {path.relative_to(ROOT)} pada offset {i}")
                    return
                stack.pop()
            i += 1
        elif state == "line":
            if c == "\n": state = "code"
            i += 1
        elif state == "block":
            if c == "*" and n == "/": state = "code"; i += 2
            else: i += 1
        elif state == "string":
            if not raw and c == "\\": i += 2
            elif c == quote: state = "code"; i += 1
            else: i += 1
        elif state == "triple":
            if source[i:i + 3] == quote * 3: state = "code"; i += 3
            elif not raw and c == "\\": i += 2
            else: i += 1
    if stack:
        errors.append(f"Delimiter tidak ditutup {path.relative_to(ROOT)}")
    if state in {"string", "triple", "block"}:
        errors.append(f"String/komen tidak ditutup {path.relative_to(ROOT)}")

    # Heuristik tambahan untuk duplicate named arguments, yang merupakan
    # ralat compile Dart tetapi mudah terlepas melalui semakan delimiter.
    stripped = []
    i = 0
    state = "code"
    quote = ""
    raw = False
    while i < len(source):
        c = source[i]
        n = source[i + 1] if i + 1 < len(source) else ""
        if state == "code":
            if c == "/" and n == "/":
                stripped.extend("  "); state = "line"; i += 2; continue
            if c == "/" and n == "*":
                stripped.extend("  "); state = "block"; i += 2; continue
            if c in "rR" and n in "'\"":
                raw = True; quote = n; stripped.extend("  ")
                if source[i + 1:i + 4] == n * 3:
                    stripped.extend("  " ); state = "triple"; i += 4; continue
                state = "string"; i += 2; continue
            if c in "'\"":
                raw = False; quote = c
                if source[i:i + 3] == c * 3:
                    stripped.extend("   " ); state = "triple"; i += 3; continue
                stripped.append(" " ); state = "string"; i += 1; continue
            stripped.append(c); i += 1; continue
        if state == "line":
            stripped.append("\n" if c == "\n" else " ")
            if c == "\n": state = "code"
            i += 1; continue
        if state == "block":
            if c == "*" and n == "/":
                stripped.extend("  " ); state = "code"; i += 2
            else:
                stripped.append("\n" if c == "\n" else " " ); i += 1
            continue
        if state == "string":
            if not raw and c == "\\":
                stripped.extend("  " ); i += 2
            elif c == quote:
                stripped.append(" " ); state = "code"; i += 1
            else:
                stripped.append("\n" if c == "\n" else " " ); i += 1
            continue
        if state == "triple":
            if source[i:i + 3] == quote * 3:
                stripped.extend("   " ); state = "code"; i += 3
            elif not raw and c == "\\":
                stripped.extend("  " ); i += 2
            else:
                stripped.append("\n" if c == "\n" else " " ); i += 1

    clean = "".join(stripped)
    frames: list[dict[str, object]] = []
    i = 0
    while i < len(clean):
        c = clean[i]
        if c == "(":
            frames.append({"brace": 0, "bracket": 0, "names": set()})
            i += 1; continue
        if c == ")":
            if frames: frames.pop()
            i += 1; continue
        if frames:
            frame = frames[-1]
            if c == "{": frame["brace"] = int(frame["brace"]) + 1
            elif c == "}": frame["brace"] = max(0, int(frame["brace"]) - 1)
            elif c == "[": frame["bracket"] = int(frame["bracket"]) + 1
            elif c == "]": frame["bracket"] = max(0, int(frame["bracket"]) - 1)
            elif (c.isalpha() or c == "_") and int(frame["brace"]) == 0 and int(frame["bracket"]) == 0:
                start = i
                i += 1
                while i < len(clean) and (clean[i].isalnum() or clean[i] == "_"):
                    i += 1
                name = clean[start:i]
                j = i
                while j < len(clean) and clean[j].isspace(): j += 1
                k = start - 1
                while k >= 0 and clean[k].isspace(): k -= 1
                previous = clean[k] if k >= 0 else ""
                if (
                    j < len(clean)
                    and clean[j] == ":"
                    and previous in {"(", ","}
                    and name not in {"case", "default"}
                ):
                    names = frame["names"]
                    assert isinstance(names, set)
                    if name in names:
                        line = source.count("\n", 0, start) + 1
                        errors.append(f"Named argument berulang {path.relative_to(ROOT)}:{line}: {name}")
                    names.add(name)
                continue
        i += 1


dart_files = list((MOBILE / "lib").rglob("*.dart")) + list((MOBILE / "test").rglob("*.dart"))
for dart_file in dart_files:
    check_dart(dart_file)

# Files that should not contain old architecture or secrets.
for path in [*dart_files, *ROOT.glob("*.md"), *ROOT.glob("docs/*.md")]:
    source = path.read_text(encoding="utf-8")
    require("OPENAI_API_KEY=" not in source, f"Rahsia/API key literal ditemui: {path.relative_to(ROOT)}")
    require("/auth/login" not in source, f"Rujukan login/backend lama ditemui: {path.relative_to(ROOT)}")

for stale in ["Visible WebView", "WebView kelihatan", "Chat / Agent / Provider"]:
    for path in [ROOT / "README.md", *ROOT.glob("docs/*.md"), ROOT / "store/PLAY_STORE_LISTING_MS.md"]:
        if path.exists() and stale in path.read_text(encoding="utf-8"):
            errors.append(f"Dokumentasi lapuk '{stale}' ditemui: {path.relative_to(ROOT)}")

notes.append(f"{len(provider_ids)} preset provider")
notes.append(f"{len(set(tool_ids))} tools")
notes.append(f"{len(dart_files)} fail Dart diperiksa")

if errors:
    print("SEMakan sumber GAGAL:", file=sys.stderr)
    for item in errors:
        print(f"- {item}", file=sys.stderr)
    raise SystemExit(1)

print("Semakan sumber lulus: " + ", ".join(notes) + ".")
