# Aset Warung Kita v0.5.1

- `assets/images/customers/`: 100 pelanggan individu.
- `assets/images/staff/`: aksi tukang masak, pelayan, pencuci pinggan dan prop kerja.
- `assets/images/environment/`: kedai, dapur, stor, kaunter, sinki, meja, kerusi, lantai dan hiasan.
- `assets/images/food_new/`: makanan, minuman, bahan dan peralatan hidangan.
- `assets/images/*.png`: aset menu bersih yang digunakan oleh kad menu, kaunter siap dan meja pelanggan.
- `assets/app_icon.png`: ikon aplikasi.

Aplikasi membungkus fail individu sahaja. Aset pencuci pinggan baharu telah dipotong semula dengan sempadan lutsinar yang selamat.
