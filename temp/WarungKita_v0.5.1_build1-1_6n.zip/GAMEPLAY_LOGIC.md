# Logik Operasi Warung

## Kitaran pelanggan

`Masuk → Duduk → Tunggu pelayan → Pesan → Tunggu makanan → Makan → Tunggu bayaran → Keluar`

Pelanggan mempunyai tahap kesabaran berbeza. Masa menunggu dibuat cukup panjang untuk memberi ruang kepada pekerja bergerak, mengambil bahan, memasak dan menghantar hidangan. Pelanggan yang menunggu terlalu lama sebelum pesanan atau makanan boleh meninggalkan warung.

## Tugas pelayan lelaki

`Sambut → Catat pesanan → Pergi ke stor → Ambil bahan → Serah kepada tukang masak → Ambil hidangan siap → Hantar ke meja → Ambil bayaran → Lap meja → Bawa pinggan ke sinki`

Keutamaan kerja pelayan:

1. Hantar makanan yang sudah siap.
2. Ambil bayaran pelanggan yang selesai makan.
3. Bersihkan meja jika semua tempat duduk sedang terhalang.
4. Ambil pesanan baharu.
5. Bersihkan baki meja kotor.

## Tugas tukang masak wanita

`Terima bahan → Potong → Masak → Susun hidangan → Letak di kaunter siap → Sedia untuk pesanan seterusnya`

Tukang masak tidak lagi membasuh pinggan. Hidangan yang selesai dimasak dipaparkan di kaunter sehingga pelayan datang mengambilnya.

## Tugas pencuci pinggan

`Terima pinggan kotor di sinki → Basuh → Susun di rak → Ambil kumpulan seterusnya`

Pencuci pinggan mempunyai barisan kerja sendiri. Naik taraf pencuci pinggan mengurangkan masa basuh dan membolehkan lebih banyak set pinggan diproses dalam satu kitaran.

## Makanan di kaunter dan meja

- Hidangan siap muncul di kaunter sebaik sahaja proses memasak selesai.
- Hidangan hilang dari kaunter apabila pelayan mengambilnya.
- Hidangan muncul dengan saiz lebih jelas di atas meja apabila dihantar.
- Kuantiti makanan berkurang secara visual semasa pelanggan makan.
- Selepas makan, pinggan dan baki makanan kekal sehingga pelayan membersihkan meja.

## Stok dan pembaziran

Bahan ditempah apabila pesanan dicatat dan ditolak daripada inventori apabila pelayan mengambilnya dari stor. Pesanan yang dibatalkan sebelum bahan diambil melepaskan tempahan. Pesanan yang dibatalkan selepas bahan diambil menambah kiraan pembaziran.

## Kesan naik taraf

- **Taraf Kedai:** rupa kedai, menu terbuka dan jumlah permintaan.
- **Dapur:** masa memasak lebih singkat.
- **Meja & Kerusi:** lebih banyak pelanggan boleh duduk serentak.
- **Stor Bahan:** kapasiti lebih besar dan harga bahan lebih murah.
- **Servis Pelayan:** pergerakan, pengambilan pesanan dan bayaran lebih cepat.
- **Kebersihan:** meja dilap lebih cepat dan peluang tip bertambah.
- **Pencuci Pinggan:** basuh lebih cepat dan kapasiti setiap kitaran bertambah.
- **Populariti:** lebih ramai pelanggan dan peluang tip lebih tinggi.
- **Keuntungan:** hasil setiap hidangan meningkat.
