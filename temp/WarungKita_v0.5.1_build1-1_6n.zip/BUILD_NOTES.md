# Nota Kemas Kini v0.5.1

- Version name `0.5.1` dan build number `1`.
- Butang `Simpan Sekarang` dibuang; kemajuan kekal disimpan secara automatik.
- Teks butang kembali tidak lagi menyebut simpanan manual.
- Tempoh menunggu pelanggan, masa makan dan aksi pekerja dipanjangkan supaya operasi lebih semula jadi.
- Hidangan siap kini dipaparkan di kaunter dan kemudian muncul dengan jelas di atas meja.
- Tukang masak wanita hanya mengurus penyediaan makanan.
- Pelayan lelaki mengambil pesanan, mengambil bahan, menghantar makanan, menerima bayaran, mengelap meja dan membawa pinggan ke sinki.
- Pekerja pencuci pinggan baharu mempunyai barisan basuhan dan animasi buih serta rak pinggan.
- Naik taraf `Pencuci Pinggan` ditambah dengan kesan kelajuan dan saiz kumpulan basuhan.
- Hari operasi menunggu semua pinggan selesai dibasuh sebelum laporan disimpan.
- Projek tidak mengandungi kunci signing, keystore atau signing config tersuai.
- Konfigurasi Android mengekalkan Gradle 8.14.4, AGP 8.11.1, Kotlin 2.2.20 dan Java 17.
