# Warung Kita

Aplikasi permainan pengurusan warung offline untuk Android.

## Aliran permainan

1. Beli dan urus stok bahan.
2. Aktifkan menu yang hendak dijual.
3. Buka warung dan terima pelanggan.
4. Pelayan lelaki menyambut pelanggan serta mencatat pesanan.
5. Pelayan pergi ke stor, mengambil bahan dan menyerahkannya kepada tukang masak wanita.
6. Tukang masak memotong, memasak dan menyediakan hidangan.
7. Hidangan siap muncul di kaunter sebelum pelayan mengambil dan menghantarnya ke meja.
8. Pelanggan makan, membayar dan meninggalkan pinggan kotor.
9. Pelayan mengelap meja serta membawa pinggan ke sinki.
10. Pekerja pencuci membasuh dan menyusun pinggan sebelum hari operasi benar-benar tamat.
11. Gunakan keuntungan untuk menaik taraf kedai, pekerja dan peralatan.

## Logik operasi

- Setiap pelanggan mempunyai tahap kesabaran yang berbeza.
- Tempoh menunggu pesanan dan makanan dibuat lebih panjang supaya aliran kerja kelihatan semula jadi.
- Masa menunggu mempengaruhi kepuasan, tip serta reputasi.
- Pelanggan boleh meninggalkan warung jika pesanan atau makanan terlalu lambat.
- Bahan yang sudah diambil untuk pesanan terbatal dikira sebagai pembaziran.
- Makanan siap dipaparkan di kaunter dan di atas meja semasa pelanggan makan.
- Meja hanya boleh digunakan semula selepas pelanggan keluar dan pelayan selesai mengelapnya.
- Pencuci pinggan mempunyai barisan kerja sendiri dan tidak mengganggu tugas memasak.
- Hari hanya tamat selepas pelanggan keluar, pesanan selesai, meja bersih, pinggan dibasuh dan semua pekerja kembali lapang.

## Kandungan utama

- 100 variasi pelanggan, digunakan secara rawak tanpa pengulangan sehingga satu pusingan selesai.
- 9 menu dan 13 jenis bahan.
- Tiga peranan pekerja: tukang masak wanita, pelayan lelaki dan pencuci pinggan.
- 6 taraf rupa kedai.
- Naik taraf dapur, meja, stor, servis, kebersihan, pencuci pinggan, populariti dan keuntungan.
- Harga serta manfaat tahap seterusnya dipaparkan sebelum pembelian disahkan.
- Simpanan automatik selepas pembelian, naik taraf dan tamat operasi.
- Tiada kunci signing atau konfigurasi keystore disertakan.

## Binaan Android

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Versi aplikasi: `0.5.1+1`
