# Perubahan v0.5.1 Build 1

- Butang simpan manual dibuang; auto-simpan kekal aktif.
- Tempoh menunggu pesanan, makanan, bayaran dan masa makan dipanjangkan.
- Makanan siap kelihatan di kaunter sebelum diambil pelayan.
- Makanan kelihatan lebih besar di atas meja dan berkurang semasa dimakan.
- Pekerja pencuci pinggan berasingan ditambah di kawasan sinki.
- Tukang masak tidak lagi meninggalkan dapur untuk membasuh pinggan.
- Pelayan mengelap meja dan membawa pinggan kotor ke sinki.
- Naik taraf Pencuci Pinggan ditambah dengan harga, manfaat dan pengesahan pembelian.
- Hari operasi menunggu semua pinggan selesai dibasuh.
- Konfigurasi signing dan semua fail kunci dikeluarkan.
