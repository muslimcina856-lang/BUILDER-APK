from __future__ import annotations

import hashlib
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml
import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[bool, str]] = []


def check(condition: bool, message: str) -> None:
    checks.append((bool(condition), message))


def balanced_dart(path: Path) -> bool:
    text = path.read_text(encoding='utf-8')
    stack: list[str] = []
    pairs = {')': '(', ']': '[', '}': '{'}
    opening = set(pairs.values())
    i = 0
    quote: str | None = None
    triple = False
    line_comment = False
    block_comment = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i:i + 2]
        if line_comment:
            if ch == '\n':
                line_comment = False
            i += 1
            continue
        if block_comment:
            if nxt == '/*':
                block_comment += 1
                i += 2
                continue
            if nxt == '*/':
                block_comment -= 1
                i += 2
                continue
            i += 1
            continue
        if quote:
            end = quote * (3 if triple else 1)
            if text.startswith(end, i):
                quote = None
                triple = False
                i += len(end)
                continue
            if ch == '\\':
                i += 2
                continue
            i += 1
            continue
        if nxt == '//':
            line_comment = True
            i += 2
            continue
        if nxt == '/*':
            block_comment = 1
            i += 2
            continue
        if ch in ('\'', '"'):
            if text.startswith(ch * 3, i):
                quote = ch
                triple = True
                i += 3
            else:
                quote = ch
                triple = False
                i += 1
            continue
        if ch in opening:
            stack.append(ch)
        elif ch in pairs:
            if not stack or stack.pop() != pairs[ch]:
                return False
        i += 1
    return not stack and quote is None and not line_comment and block_comment == 0


pubspec = yaml.safe_load((ROOT / 'pubspec.yaml').read_text(encoding='utf-8'))
check(pubspec.get('version') == '0.5.1+1', 'Versi aplikasi ialah 0.5.1 dengan build number 1')
check(pubspec.get('dependencies', {}).get('flame') == '1.23.0', 'Kebergantungan permainan dikunci pada Flame 1.23.0')
check(pubspec.get('dependencies', {}).get('shared_preferences') == '2.3.2', 'Simpanan tempatan dikunci pada shared_preferences 2.3.2')

wrapper = (ROOT / 'android/gradle/wrapper/gradle-wrapper.properties').read_text(encoding='utf-8')
settings = (ROOT / 'android/settings.gradle.kts').read_text(encoding='utf-8')
app_gradle = (ROOT / 'android/app/build.gradle.kts').read_text(encoding='utf-8')
check('gradle-8.14.4-bin.zip' in wrapper, 'Gradle wrapper menggunakan 8.14.4')
check('com.android.application") version "8.11.1' in settings, 'Android Gradle Plugin menggunakan 8.11.1')
check('org.jetbrains.kotlin.android") version "2.2.20' in settings, 'Kotlin plugin menggunakan 2.2.20')
check('JavaVersion.VERSION_17' in app_gradle, 'Konfigurasi Android menggunakan Java 17')
check('applicationId = "com.earlxz.warungkita"' in app_gradle, 'ID aplikasi Android betul')
check('signingConfig' not in app_gradle and 'keystore' not in app_gradle.lower(), 'Projek tidak menetapkan kunci atau signing config')
check(not any(ROOT.rglob('*.jks')) and not any(ROOT.rglob('*.keystore')) and not (ROOT / 'android/key.properties').exists(), 'Tiada fail kunci signing disertakan')

for rel in (
    'android/app/src/main/res/drawable/launch_background.xml',
    'android/app/src/main/res/drawable-v21/launch_background.xml',
    'android/app/src/main/AndroidManifest.xml',
):
    try:
        ET.parse(ROOT / rel)
        check(True, f'XML sah: {rel}')
    except ET.ParseError:
        check(False, f'XML rosak: {rel}')

customers = sorted((ROOT / 'assets/images/customers').glob('customer_*.png'))
check(len(customers) == 100, 'Terdapat tepat 100 aset pelanggan')
check(customers and customers[0].name == 'customer_001.png' and customers[-1].name == 'customer_100.png', 'Nama pelanggan lengkap dari 001 hingga 100')

required_staff = {
    'cook_idle.png', 'cook_receive.png', 'cook_chop.png', 'cook_stir.png',
    'cook_fry.png', 'cook_plate.png', 'cook_wash.png', 'cook_clean.png',
    'cook_ticket.png', 'dishwasher.png', 'waiter_greet.png', 'waiter_order.png',
    'waiter_ingredients.png', 'waiter_food.png', 'waiter_serve.png',
    'waiter_payment.png', 'waiter_clean.png', 'waiter_dirty.png',
}
staff_names = {p.name for p in (ROOT / 'assets/images/staff').glob('*.png')}
check(required_staff <= staff_names, 'Semua aksi tukang masak dan pelayan tersedia')

required_environment = {
    *(f'warung_tier_{i}.png' for i in range(1, 7)),
    *(f'stove_tier_{i}.png' for i in range(1, 4)),
    *(f'storage_tier_{i}.png' for i in range(1, 4)),
    *(f'counter_tier_{i}.png' for i in range(1, 4)),
    *(f'sink_tier_{i}.png' for i in range(1, 4)),
    'table_long.png', 'table_square.png', 'table_umbrella.png', 'lights_long.png',
}
env_names = {p.name for p in (ROOT / 'assets/images/environment').glob('*.png')}
check(required_environment <= env_names, 'Semua visual kedai dan objek naik taraf tersedia')

for path in customers + sorted((ROOT / 'assets/images/staff').glob('*.png')) + sorted((ROOT / 'assets/images/environment').glob('*.png')) + sorted((ROOT / 'assets/images/food_new').glob('*.png')):
    try:
        with Image.open(path) as image:
            rgba = image.convert('RGBA')
            alpha = rgba.getchannel('A')
            bbox = alpha.getbbox()
            check(bbox is not None, f'Aset tidak kosong: {path.relative_to(ROOT)}')
            if bbox is not None:
                left, top, right, bottom = bbox
                check(
                    left > 0 and top > 0 and right < rgba.width and bottom < rgba.height,
                    f'Aset mempunyai sempadan lutsinar: {path.relative_to(ROOT)}',
                )
    except Exception:
        check(False, f'Aset gagal dibuka: {path.relative_to(ROOT)}')


# Files that previously contained visible pieces from neighbouring atlas cells.
single_component_files = [
    'environment/chair_2.png',
    'environment/cooking_station.png',
    'environment/crate_1.png',
    'environment/crate_2.png',
    'environment/crate_3.png',
    'environment/fence.png',
    'environment/floor_stone.png',
    'environment/floor_tile.png',
    'environment/floor_wood_1.png',
    'environment/floor_wood_2.png',
    'environment/floor_woven.png',
    'environment/platform.png',
    'environment/table_square_metal.png',
    'staff/waiter_serve.png',
]
for rel in single_component_files:
    path = ROOT / 'assets/images' / rel
    with Image.open(path) as image:
        alpha = np.array(image.convert('RGBA'))[:, :, 3]
    count, _, stats, _ = cv2.connectedComponentsWithStats((alpha > 10).astype('uint8'), 8)
    meaningful = sum(1 for index in range(1, count) if int(stats[index, 4]) >= 3)
    check(meaningful == 1, f'Tiada serpihan aset jiran: {rel}')

for menu_name in (
    'nasi_lemak.png', 'mee_goreng.png', 'roti_bakar.png', 'teh_tarik.png',
    'kopi.png', 'nasi_ayam.png', 'roti_canai.png', 'nasi_goreng.png',
    'fried_chicken.png',
):
    root_asset = np.array(Image.open(ROOT / 'assets/images' / menu_name).convert('RGBA'))
    clean_asset = np.array(Image.open(ROOT / 'assets/images/food_new' / menu_name).convert('RGBA'))
    check(
        root_asset.shape == clean_asset.shape and np.array_equal(root_asset, clean_asset),
        f'Imej menu menggunakan aset makanan bersih: {menu_name}',
    )

# Validate literal asset references in Dart files.
asset_pattern = re.compile(r"['\"](assets/(?:images|app_icon)[^'\"]+|(?:customers|staff|environment)/[^'\"]+\.png)['\"]")
missing_refs: set[str] = set()
for dart_file in (ROOT / 'lib').rglob('*.dart'):
    text = dart_file.read_text(encoding='utf-8')
    for ref in asset_pattern.findall(text):
        if ref.startswith('assets/'):
            target = ROOT / ref
        else:
            target = ROOT / 'assets/images' / ref
        if '$' not in ref and not target.exists():
            missing_refs.add(f'{dart_file.relative_to(ROOT)} -> {ref}')
check(not missing_refs, 'Semua rujukan aset literal dalam kod wujud')

for dart_file in (ROOT / 'lib').rglob('*.dart'):
    check(balanced_dart(dart_file), f'Kurungan dan rentetan seimbang: {dart_file.relative_to(ROOT)}')

all_code = '\n'.join(p.read_text(encoding='utf-8') for p in (ROOT / 'lib').rglob('*.dart'))
check('..daysPlayed++' not in all_code, 'Tiada lagi sintaks cascade ++ yang rosak')
check('android:drawable="#' not in '\n'.join((ROOT / p).read_text(encoding='utf-8') for p in [
    Path('android/app/src/main/res/drawable/launch_background.xml'),
    Path('android/app/src/main/res/drawable-v21/launch_background.xml'),
]), 'Splash Android tidak menggunakan drawable warna yang tidak sah')
for phrase in ('prototaip', 'godot', 'enjin permainan'):
    check(phrase not in all_code.lower(), f'Teks aplikasi tidak menyebut {phrase}')

screen_code = (ROOT / 'lib/screens/game_screen.dart').read_text(encoding='utf-8')
check('Simpan Sekarang' not in screen_code, 'Tiada butang Simpan Sekarang')

check('Kembali ke menu utama' in screen_code, 'Butang keluar tidak menyebut simpanan manual')
flame_code = (ROOT / 'lib/flame/warung_kita_game.dart').read_text(encoding='utf-8')
for token in (
    'walkingToStorage', 'handingIngredients', 'CookPhase.chopping',
    'CookPhase.cooking', 'CookPhase.plating', 'carryingFoodToTable',
    'CustomerPhase.eating', 'waitingPayment', 'cleaningTable',
    'carryingDirtyToSink', 'DishwasherComponent', 'enqueueDishLoad',
    '_customerDeck', 'CustomerProfile',
    '_updatePatience', 'customerAbandonedOrder', '_maybeFinishService',
):
    check(token in flame_code, f'Aliran kerja mengandungi keadaan {token}')

check('readyCounterPoint + Vector2' in flame_code and 'ticket.readyMeal = readyMeal' in flame_code,
      'Makanan siap dipaparkan di kaunter')
check('componentPriority: 25' in flame_code and 'mealSize: size.x * 0.180' in flame_code,
      'Makanan di meja dipaparkan lebih besar dan di atas pelanggan')
check('orderPatience =>' in flame_code and '27.0 +' in flame_code,
      'Masa menunggu pesanan tidak terlalu singkat')
check('foodPatience =>' in flame_code and '55.0 +' in flame_code,
      'Masa menunggu makanan tidak terlalu singkat')
check('eatingDuration => 10.0 +' in flame_code,
      'Tempoh pelanggan makan lebih munasabah')
check("(_dishwasher?.isIdle ?? true)" in flame_code,
      'Hari operasi menunggu pencuci pinggan selesai')

controller_code = (ROOT / 'lib/game/game_controller.dart').read_text(encoding='utf-8')
for token in ('serviceQuality', 'wastedToday', 'satisfactionToday', 'sceneDrained'):
    check(token in controller_code, f'Logik kualiti operasi tersedia: {token}')
for upgrade_id in ('warung', 'kitchen', 'tables', 'storage', 'service', 'cleaning', 'dishwashing', 'popularity', 'profit'):
    check(f"case '{upgrade_id}':" in controller_code, f'Manfaat naik taraf tersedia: {upgrade_id}')

passed = sum(1 for ok, _ in checks if ok)
failed = [(msg) for ok, msg in checks if not ok]
lines = [
    '# Laporan Validasi Warung Kita v0.5.1',
    '',
    f'- Lulus: **{passed}**',
    f'- Gagal: **{len(failed)}**',
    f'- Jumlah semakan: **{len(checks)}**',
    '',
    '## Ringkasan',
    '',
    '- 100 pelanggan unik telah dipotong sebagai fail berasingan.',
    '- Aksi tukang masak wanita, pelayan lelaki dan pekerja pencuci pinggan telah dipisahkan.',
    '- Sempadan alfa dan komponen terasing diperiksa untuk mengelakkan aset terpotong atau bercampur dengan aset jiran.',
    '- Enam taraf kedai dan naik taraf dapur, stor, kaunter, sinki, pencuci pinggan serta meja tersedia.',
    '- Aliran pesanan, bahan, memasak, makan, kesabaran, bayaran, pembaziran dan membersih terdapat dalam kod.',
    '- Build number disahkan sebagai 1.',
    '',
]
if failed:
    lines += ['## Kegagalan', ''] + [f'- {msg}' for msg in failed]
else:
    lines += ['## Keputusan', '', 'Semua semakan statik dan aset lulus.']
(ROOT / 'PROJECT_VALIDATION.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

print(f'PASS={passed} FAIL={len(failed)} TOTAL={len(checks)}')
for message in failed[:50]:
    print('FAIL:', message)
sys.exit(1 if failed else 0)
