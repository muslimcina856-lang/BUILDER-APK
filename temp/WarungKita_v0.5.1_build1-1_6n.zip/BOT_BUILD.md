# Tetapan Bot Binaan

Pilih jenis projek: **Flutter**

Fail pengesan projek berada terus pada akar ZIP:

- `pubspec.yaml`
- `lib/main.dart`
- `android/settings.gradle.kts`

Arahan binaan debug:

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Versi: `0.5.1+1`

Projek tidak menyertakan kunci signing. Binaan release boleh ditandatangani sendiri selepas proses build.
