# Audit Aset Warung Kita v0.5.1

## Aset yang digunakan aplikasi

- Pelanggan: **100** fail individu.
- Aksi pekerja dan prop: **24** fail.
- Persekitaran, perabot dan peralatan: **64** fail.
- Makanan, minuman dan bahan: **45** fail.
- Imej menu utama: **10** fail.

## Pekerja baharu

Aset `assets/images/staff/dishwasher.png` ditambah sebagai pekerja pencuci pinggan yang berasingan. Aset mempunyai ruang lutsinar di sekeliling dan tidak membawa bahagian objek jiran.

## Pemeriksaan runtime

- Semua 100 pelanggan wujud dan mempunyai sempadan lutsinar.
- Aset pekerja tidak digunakan sebagai pelanggan.
- Hidangan siap menggunakan imej menu sebenar di kaunter dan di atas meja.
- Aset pencuci pinggan dimuatkan secara terus daripada folder pekerja.
- Rujukan aset dalam kod disemak terhadap fail sebenar.
- Helaian sumber tidak dimasukkan sebagai aset runtime.
