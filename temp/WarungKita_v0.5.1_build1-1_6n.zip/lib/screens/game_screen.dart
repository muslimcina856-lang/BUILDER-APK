import 'dart:async';

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../game/game_controller.dart';
import '../game/game_data.dart';
import '../game/game_state.dart';
import '../flame/warung_kita_game.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.controller,
    required this.onExit,
  });

  final GameController controller;
  final Future<void> Function() onExit;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with WidgetsBindingObserver {
  int _tab = 0;

  GameController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      unawaited(controller.save());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Scaffold(
          appBar: _buildTopBar(),
          body: _buildTab(),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (index) {
              if (controller.serviceActive && index != 0) {
                _showNotice('Selesaikan operasi warung sebelum membuka bahagian lain.');
                return;
              }
              setState(() => _tab = index);
            },
            destinations: const [
              NavigationDestination(icon: Icon(Icons.storefront), label: 'Warung'),
              NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Stok'),
              NavigationDestination(icon: Icon(Icons.restaurant_menu), label: 'Menu'),
              NavigationDestination(icon: Icon(Icons.upgrade), label: 'Naik Taraf'),
              NavigationDestination(icon: Icon(Icons.assessment), label: 'Laporan'),
            ],
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildTopBar() {
    final state = controller.state;
    return AppBar(
      toolbarHeight: 94,
      backgroundColor: AppColors.brown,
      foregroundColor: Colors.white,
      automaticallyImplyLeading: false,
      titleSpacing: 10,
      title: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset('assets/app_icon.png', width: 62, height: 62),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                _StatChip(icon: Icons.payments, text: 'RM ${state.money}'),
                _StatChip(icon: Icons.calendar_today, text: 'Hari ${state.day}'),
                _StatChip(icon: Icons.star, text: 'Rep ${state.reputation}'),
                _StatChip(icon: Icons.store, text: 'Lv.${controller.warungLevel}'),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'Kembali ke menu utama',
          onPressed: controller.serviceActive ? null : widget.onExit,
          icon: const Icon(Icons.home_rounded),
        ),
      ],
    );
  }

  Widget _buildTab() {
    return switch (_tab) {
      0 => _WarungTab(controller: controller, showNotice: _showNotice, goToMenu: () => setState(() => _tab = 2)),
      1 => _StockTab(controller: controller, showNotice: _showNotice),
      2 => _MenuTab(controller: controller, showNotice: _showNotice),
      3 => _UpgradeTab(controller: controller, showNotice: _showNotice),
      _ => _ReportTab(controller: controller),
    };
  }

  void _showNotice(String message) {
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Warung Kita'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Baik'),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.darkBrown.withOpacity(0.55),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.gold),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _WarungTab extends StatefulWidget {
  const _WarungTab({
    required this.controller,
    required this.showNotice,
    required this.goToMenu,
  });

  final GameController controller;
  final ValueChanged<String> showNotice;
  final VoidCallback goToMenu;

  @override
  State<_WarungTab> createState() => _WarungTabState();
}

class _WarungTabState extends State<_WarungTab> {
  late final WarungKitaGame _game;

  GameController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    _game = WarungKitaGame(controller: controller);
  }

  @override
  void dispose() {
    _game.shutdown();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Operasi Warung'),
        const SizedBox(height: 8),
        const Text(
          'Pelayan lelaki mengambil pesanan dan bahan, tukang masak wanita menyediakan hidangan, kemudian pelayan menghantar makanan, mengambil bayaran dan membawa pinggan kotor kepada pekerja pencuci.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              AspectRatio(
                aspectRatio: 4 / 5,
                child: ColoredBox(
                  color: const Color(0xFFEDD49F),
                  child: GameWidget<WarungKitaGame>(
                    game: _game,
                    loadingBuilder: (context) => const Center(
                      child: CircularProgressIndicator(color: AppColors.orange),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Text(
                  controller.serviceStatus,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.darkBrown,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: LinearProgressIndicator(
                  value: controller.serviceProgress,
                  minHeight: 16,
                  borderRadius: BorderRadius.circular(20),
                  backgroundColor: const Color(0xFF7A3D1E),
                  color: AppColors.green,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 14,
                  runSpacing: 6,
                  children: [
                    Text(
                      'Dilayan: ${controller.servedToday}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'Baki: ${controller.customersRemaining}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'Terlepas: ${controller.missedToday}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'Puas: ${controller.satisfactionToday}%',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'Bazir: ${controller.wastedToday}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: FilledButton.icon(
                  onPressed: controller.serviceActive
                      ? null
                      : () {
                          final error = controller.startService();
                          if (error != null) widget.showNotice(error);
                        },
                  icon: const Icon(Icons.local_fire_department),
                  label: Text(
                    controller.serviceActive
                        ? 'Warung Sedang Beroperasi'
                        : 'Buka Warung Hari Ini',
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.green,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: controller.serviceActive
                    ? null
                    : () async => widget.showNotice(
                          await controller.buyBasicBundle(),
                        ),
                icon: const Icon(Icons.shopping_basket),
                label: const Text('Beli Stok Asas'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: controller.serviceActive ? null : widget.goToMenu,
                icon: const Icon(Icons.restaurant_menu),
                label: const Text('Semak Menu'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(54),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Ringkasan Hari Ini', style: _cardTitleStyle),
                const SizedBox(height: 10),
                _InfoLine(
                  label: 'Anggaran pelanggan',
                  value: '${controller.customerCapacity()}',
                ),
                _InfoLine(
                  label: 'Hidangan boleh disediakan',
                  value: '${controller.estimatedServings()}',
                ),
                _InfoLine(
                  label: 'Menu aktif',
                  value:
                      '${controller.availableMenuItems(requireStock: false).length} / ${menuItems.length}',
                ),
                _InfoLine(label: 'Tempat duduk aktif', value: '${controller.seatCount} meja'),
                const _InfoLine(label: 'Tukang masak', value: 'Wanita • kawasan dapur'),
                const _InfoLine(label: 'Pelayan', value: 'Lelaki • pesanan, bahan & hidangan'),
                const _InfoLine(label: 'Pencuci pinggan', value: 'Kawasan sinki • pinggan kotor & rak'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _StockTab extends StatelessWidget {
  const _StockTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Inventori Bahan'),
        const SizedBox(height: 8),
        const Text(
          'Beli bahan sebelum membuka warung. Naik taraf stor menambah ruang dan memberi diskaun.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        Image.asset(
          controller.upgradeImagePath('storage', controller.storageLevel),
          height: 150,
          fit: BoxFit.contain,
        ),
        const SizedBox(height: 8),
        Text(
          'Kapasiti stor: ${controller.inventoryUsed} / ${controller.storageCapacity} unit',
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: controller.storageCapacity <= 0
              ? 0
              : controller.inventoryUsed / controller.storageCapacity,
          minHeight: 12,
          borderRadius: BorderRadius.circular(20),
          color: AppColors.green,
          backgroundColor: AppColors.brown.withOpacity(0.18),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: controller.serviceActive
              ? null
              : () async => showNotice(await controller.buyBasicBundle()),
          icon: const Icon(Icons.shopping_cart_checkout),
          label: const Text('Beli Pakej Asas'),
          style: FilledButton.styleFrom(backgroundColor: AppColors.green),
        ),
        const SizedBox(height: 12),
        for (final ingredient in ingredients.values) ...[
          Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.gold.withOpacity(0.35),
                child: Text(ingredient.name.substring(0, 1)),
              ),
              title: Text(ingredient.name, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('Stok: ${controller.state.inventory[ingredient.id] ?? 0} unit'),
              trailing: FilledButton(
                onPressed: controller.serviceActive
                    ? null
                    : () async => showNotice(await controller.buyStock(ingredient.id, 5)),
                style: FilledButton.styleFrom(
                  minimumSize: const Size(86, 46),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                ),
                child: Text('+5\nRM ${controller.stockPrice(ingredient.id, 5)}', textAlign: TextAlign.center),
              ),
            ),
          ),
          const SizedBox(height: 9),
        ],
      ],
    );
  }
}

class _MenuTab extends StatelessWidget {
  const _MenuTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Menu Jualan'),
        const SizedBox(height: 8),
        const Text(
          'Aktifkan menu yang mahu dijual. Menu baharu dibuka apabila Taraf Kedai meningkat.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        for (final item in menuItems.values) ...[
          _MenuCard(controller: controller, item: item, showNotice: showNotice),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _MenuCard extends StatelessWidget {
  const _MenuCard({required this.controller, required this.item, required this.showNotice});

  final GameController controller;
  final MenuDefinition item;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    final unlocked = controller.warungLevel >= item.unlockLevel;
    final active = controller.state.menuEnabled[item.id] ?? true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(item.imagePath, width: 116, height: 82, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name, style: _cardTitleStyle),
                  Text('Harga jual: RM ${item.price}'),
                  const SizedBox(height: 4),
                  Text(
                    controller.recipeText(item.recipe),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            FilledButton(
              onPressed: !unlocked || controller.serviceActive
                  ? null
                  : () async => showNotice(await controller.toggleMenu(item.id)),
              style: FilledButton.styleFrom(
                backgroundColor: active ? AppColors.green : const Color(0xFF7F766C),
                minimumSize: const Size(74, 48),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: Text(unlocked ? (active ? 'Aktif' : 'Tutup') : 'Lv.${item.unlockLevel}'),
            ),
          ],
        ),
      ),
    );
  }
}

class _UpgradeTab extends StatelessWidget {
  const _UpgradeTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Naik Taraf Kedai'),
        const SizedBox(height: 8),
        const Text(
          'Tekan setiap bahagian untuk melihat harga dan manfaat tahap seterusnya. Perubahan kedai terus kelihatan pada ruang operasi.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 14),
        for (final definition in upgrades.values) ...[
          Builder(
            builder: (context) {
              final level = controller.state.upgradeLevels[definition.id] ?? 1;
              final maxed = level >= definition.maxLevel;
              final nextLevel = level < definition.maxLevel ? level + 1 : definition.maxLevel;
              return Card(
                clipBehavior: Clip.antiAlias,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 112,
                            height: 94,
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF1CF),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppColors.gold),
                            ),
                            child: Image.asset(
                              controller.upgradeImagePath(definition.id, level),
                              fit: BoxFit.contain,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${definition.name} • Lv.$level/${definition.maxLevel}',
                                  style: _cardTitleStyle,
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  definition.description,
                                  style: const TextStyle(color: AppColors.muted),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.green.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'Sekarang: ${controller.upgradeBenefitText(definition.id, level)}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      if (!maxed) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.gold.withOpacity(0.17),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            'Tahap $nextLevel: ${controller.upgradeBenefitText(definition.id, nextLevel)}',
                            style: const TextStyle(
                              color: AppColors.darkBrown,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: maxed || controller.serviceActive
                            ? null
                            : () => _confirmUpgrade(
                                  context,
                                  definition,
                                  level,
                                  nextLevel,
                                ),
                        icon: Icon(maxed ? Icons.check_circle : Icons.upgrade_rounded),
                        label: Text(
                          maxed
                              ? 'TAHAP MAKSIMUM'
                              : 'NAIK TARAF KE LV.$nextLevel • RM ${controller.upgradeCost(definition.id)}',
                          textAlign: TextAlign.center,
                        ),
                        style: FilledButton.styleFrom(
                          backgroundColor: AppColors.green,
                          minimumSize: const Size.fromHeight(52),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
  Future<void> _confirmUpgrade(
    BuildContext context,
    UpgradeDefinition definition,
    int currentLevel,
    int nextLevel,
  ) async {
    final cost = controller.upgradeCost(definition.id);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Naik Taraf ${definition.name}?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Harga: RM $cost'),
            const SizedBox(height: 8),
            Text(
              'Sekarang Lv.$currentLevel: ${controller.upgradeBenefitText(definition.id, currentLevel)}',
            ),
            const SizedBox(height: 8),
            Text(
              'Selepas Lv.$nextLevel: ${controller.upgradeBenefitText(definition.id, nextLevel)}',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Sahkan'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    showNotice(await controller.buyUpgrade(definition.id));
  }
}

class _ReportTab extends StatelessWidget {
  const _ReportTab({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final report = controller.state.lastReport;
    final stats = controller.state.stats;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Laporan Perniagaan'),
        const SizedBox(height: 12),
        if (report == null)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Belum ada laporan. Buka warung untuk memulakan hari pertama.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 17),
              ),
            ),
          )
        else
          _DailyReportCard(report: report),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Statistik Keseluruhan', style: _cardTitleStyle),
                const SizedBox(height: 8),
                _InfoLine(label: 'Hari dimainkan', value: '${stats.daysPlayed}'),
                _InfoLine(label: 'Pelanggan dilayan', value: '${stats.served}'),
                _InfoLine(label: 'Pelanggan terlepas', value: '${stats.missed}'),
                _InfoLine(label: 'Jumlah hasil', value: 'RM ${stats.revenue}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Row(
              children: [
                Icon(Icons.cloud_done_rounded, color: AppColors.green),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Kemajuan disimpan secara automatik selepas pembelian, naik taraf dan tamat operasi.',
                    style: TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _DailyReportCard extends StatelessWidget {
  const _DailyReportCard({required this.report});

  final GameReport report;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Keputusan Hari ${report.day}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.brown)),
            const SizedBox(height: 12),
            _InfoLine(label: 'Pelanggan dilayan', value: '${report.served}'),
            _InfoLine(label: 'Pelanggan terlepas', value: '${report.missed}'),
            _InfoLine(label: 'Jualan dan bonus', value: 'RM ${report.revenue}'),
            _InfoLine(label: 'Tip pelanggan', value: 'RM ${report.tips}'),
            _InfoLine(label: 'Reputasi diperoleh', value: '${report.reputation >= 0 ? '+' : ''}${report.reputation}'),
            _InfoLine(label: 'Kepuasan purata', value: '${report.satisfaction}%'),
            _InfoLine(label: 'Hidangan terbazir', value: '${report.wasted}'),
            const Divider(height: 24),
            Text(report.note, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.greenDark, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: AppColors.brown,
        fontSize: 27,
        fontWeight: FontWeight.w900,
        shadows: [Shadow(color: Color(0xFFF5C96E), offset: Offset(1, 1))],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.darkBrown))),
          Text(value, style: const TextStyle(color: AppColors.greenDark, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

const _cardTitleStyle = TextStyle(
  color: AppColors.brown,
  fontSize: 19,
  fontWeight: FontWeight.w900,
);
