package com.riven.sex;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
