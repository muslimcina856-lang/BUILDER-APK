import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'dart:io';

/// ============================================================
///  TIKTOK & DOUYIN DOWNLOADER + IN-APP WATCHER
///  - Auto deteksi URL TikTok / Douyin
///  - Putar video langsung di dalam app (tanpa buka web)
///  - Multi API fallback untuk stabilitas (selalu lancar)
///  - Riwayat video terakhir untuk akses cepat
///  - Header anti-bot untuk Douyin agar video selalu bisa diputar
/// ============================================================

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  /// Platform terdeteksi: 'tiktok' | 'douyin'
  String _currentPlatform = 'tiktok';

  /// Riwayat video yang pernah ditonton (akses cepat tanpa buka web)
  final List<Map<String, dynamic>> _recentVideos = [];

  /// --- TEMA WARNA UNGU ---
  final Color bgDark = const Color(0xFF0D0221);
  final Color cardDark = const Color(0xFF1E1E2E);
  final Color primaryPurple = const Color(0xFF7B1FA2);
  final Color accentPurple = const Color(0xFFEA80FC);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color douyinPink = const Color(0xFFFE2C55);

  final LinearGradient purpleGradient = const LinearGradient(
    colors: [Color(0xFF7B1FA2), Color(0xFFEA80FC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  /// ============================================================
  ///  DETEKSI PLATFORM - TikTok atau Douyin
  /// ============================================================
  String _detectPlatform(String url) {
    final lowerUrl = url.toLowerCase();
    if (lowerUrl.contains('douyin.com') ||
        lowerUrl.contains('iesdouyin.com') ||
        lowerUrl.contains('v.douyin') ||
        lowerUrl.contains('douyinvideo') ||
        lowerUrl.contains('dy.com')) {
      return 'douyin';
    }
    return 'tiktok';
  }

  /// ============================================================
  ///  MULTI API ENDPOINTS - Fallback jika salah satu gagal
  ///  Memastikan video SELALU bisa diambil (lancar)
  /// ============================================================
  List<Map<String, String>> _getApiEndpoints(String url, String platform) {
    if (platform == 'douyin') {
      return [
        {'url': 'https://api.siputzx.my.id/api/d/douyin?url=${Uri.encodeComponent(url)}', 'format': 'siputzx'},
        {'url': 'https://api.tiklydown.eu.org/api/douyin?url=${Uri.encodeComponent(url)}', 'format': 'tiklydown'},
        {'url': 'https://delirius-api-official.vercel.app/download/douyin?url=${Uri.encodeComponent(url)}', 'format': 'delirius'},
        {'url': 'https://api.neekoi.me/api/douyin?url=${Uri.encodeComponent(url)}', 'format': 'neekoi'},
      ];
    }
    return [
      {'url': 'https://api.siputzx.my.id/api/d/tiktok?url=${Uri.encodeComponent(url)}', 'format': 'siputzx'},
      {'url': 'https://api.tiklydown.eu.org/api/tiktok?url=${Uri.encodeComponent(url)}', 'format': 'tiklydown'},
      {'url': 'https://delirius-api-official.vercel.app/download/tiktok?url=${Uri.encodeComponent(url)}', 'format': 'delirius'},
      {'url': 'https://api.neekoi.me/api/tiktok?url=${Uri.encodeComponent(url)}', 'format': 'neekoi'},
    ];
  }

  /// ============================================================
  ///  PARSE RESPONSE - Handle berbagai format API
  /// ============================================================
  Map<String, dynamic>? _parseApiResponse(Map<String, dynamic> json) {
    final dynamic data = json['data'] ?? json['result'] ?? json;

    String? videoUrl;
    String? title;
    String? creator;
    String? thumbnail;
    String? duration;

    // Coba berbagai kemungkinan struktur response
    if (data is Map) {
      // urls array
      if (data['urls'] is List && (data['urls'] as List).isNotEmpty) {
        videoUrl = data['urls'][0]?.toString();
      }
      // video_url
      else if (data['video_url'] != null) {
        videoUrl = data['video_url'].toString();
      }
      // url langsung
      else if (data['url'] != null && data['url'].toString().contains('http')) {
        videoUrl = data['url'].toString();
      }
      // nested video object
      else if (data['video'] is Map) {
        final v = data['video'] as Map;
        if (v['url'] != null) {
          videoUrl = v['url'].toString();
        } else if (v['download_addr'] is Map) {
          videoUrl = v['download_addr']?['url']?.toString();
        } else if (v['play_addr'] is Map) {
          videoUrl = v['play_addr']?['url']?.toString();
        }
      }
      // play_addr url_list
      else if (data['play_addr'] is Map) {
        final p = data['play_addr'] as Map;
        if (p['url_list'] is List && (p['url_list'] as List).isNotEmpty) {
          videoUrl = p['url_list'][0]?.toString();
        }
      }

      // Metadata
      final meta = data['metadata'] ?? data['author'] ?? data['music'] ?? {};
      title = data['title']?.toString() ??
          data['desc']?.toString() ??
          meta['title']?.toString() ??
          meta['nickname']?.toString() ??
          'No Title';
      creator = meta['creator']?.toString() ??
          meta['author']?.toString() ??
          meta['nickname']?.toString() ??
          meta['name']?.toString() ??
          'Unknown';
      // Thumbnail - cek satu per satu (hindari ternary yang membingungkan parser)
      if (data['cover'] != null) {
        thumbnail = data['cover'].toString();
      } else if (data['thumbnail'] != null) {
        thumbnail = data['thumbnail'].toString();
      } else if (data['origin_cover'] != null) {
        thumbnail = data['origin_cover'].toString();
      } else if (data['image'] is List && (data['image'] as List).isNotEmpty) {
        thumbnail = (data['image'] as List)[0]?.toString();
      }

      // Duration - cek satu per satu
      if (data['duration'] != null) {
        duration = data['duration'].toString();
      } else if (data['length'] != null) {
        duration = data['length'].toString();
      } else if (data['video'] is Map) {
        final videoMap = data['video'] as Map;
        if (videoMap['duration'] != null) {
          duration = videoMap['duration'].toString();
        }
      }
    }

    if (videoUrl == null || videoUrl.isEmpty) return null;

    return {
      'urls': [videoUrl],
      'metadata': {
        'title': title,
        'creator': creator,
        'thumbnail': thumbnail,
        'duration': duration,
      },
    };
  }

  /// ============================================================
  ///  DOWNLOAD / FETCH VIDEO - dengan retry multi API
  /// ============================================================
  Future<void> _downloadVideo() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = "URL tidak boleh kosong. Masukkan URL TikTok atau Douyin.";
        _videoData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _videoController = null;
      _chewieController = null;
      _currentPlatform = _detectPlatform(url);
    });

    final endpoints = _getApiEndpoints(url, _currentPlatform);
    Map<String, dynamic>? parsedData;
    String? lastError;

    for (int i = 0; i < endpoints.length; i++) {
      try {
        final apiUri = Uri.parse(endpoints[i]['url']!);
        final response = await http.get(
          apiUri,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Accept': 'application/json',
          },
        ).timeout(const Duration(seconds: 25));

        if (response.statusCode == 200) {
          final json = jsonDecode(response.body);
          final status = json['status'] ?? json['success'] ?? json['code'];
          if ((status == true || status == 200 || status == 'success' || status == 'ok') ||
              (json['data'] != null || json['result'] != null)) {
            parsedData = _parseApiResponse(json);
            if (parsedData != null) break;
            lastError = "Data video tidak ditemukan pada response API.";
          } else {
            lastError = json['message']?.toString() ?? "API merespon tanpa data.";
          }
        } else {
          lastError = "Server merespon kode ${response.statusCode}.";
        }
      } catch (e) {
        lastError = "Koneksi gagal: $e";
        continue;
      }
    }

    if (parsedData != null) {
      // Salin ke lokal non-null agar type promotion bekerja di dalam closure
      final result = parsedData;
      final metadata = result['metadata'] as Map<String, dynamic>?;
      setState(() {
        _videoData = result;
        // Tambahkan ke riwayat (akses cepat tanpa buka web lagi)
        _recentVideos.insert(0, {
          'url': url,
          'platform': _currentPlatform,
          'title': metadata?['title'] ?? 'No Title',
          'creator': metadata?['creator'] ?? 'Unknown',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        });
        if (_recentVideos.length > 8) {
          _recentVideos.removeLast();
        }
      });
      _initializeVideoPlayer();
    } else {
      setState(() {
        _errorMessage = lastError ??
            "Gagal mengambil video. Coba URL lain atau cek koneksi internet.";
      });
    }

    setState(() {
      _isLoading = false;
    });
  }

  /// ============================================================
  ///  INITIALIZE VIDEO PLAYER - dengan header anti-bot Douyin
  ///  Header Referer & User-Agent wajib untuk Douyin CDN
  /// ============================================================
  void _initializeVideoPlayer() {
    final videoUrl = _videoData!['urls'][0] as String;

    final Map<String, String> httpHeaders = {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      'Accept': '*/*',
      'Accept-Encoding': 'identity',
      'Range': 'bytes=0-',
    };

    if (_currentPlatform == 'douyin') {
      httpHeaders['Referer'] = 'https://www.douyin.com/';
      httpHeaders['Origin'] = 'https://www.douyin.com';
    } else {
      httpHeaders['Referer'] = 'https://www.tiktok.com/';
    }

    _videoController = VideoPlayerController.networkUrl(
      Uri.parse(videoUrl),
      httpHeaders: httpHeaders,
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );

    _videoController!.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          showControls: true,
          aspectRatio: _videoController!.value.aspectRatio,
          materialProgressColors: ChewieProgressColors(
            playedColor: primaryPurple,
            handleColor: accentPurple,
            backgroundColor: textGrey.withOpacity(0.3),
            bufferedColor: textGrey.withOpacity(0.2),
          ),
          placeholder: Container(
            color: Colors.black,
            child: Center(
              child: CircularProgressIndicator(
                color: accentPurple,
                strokeWidth: 2.5,
              ),
            ),
          ),
          errorBuilder: (context, errorMessage) {
            return Container(
              color: Colors.black,
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.error_outline, color: Colors.redAccent, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        'Gagal memutar video.\nCoba refresh atau gunakan URL lain.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: _downloadVideo,
                        icon: Icon(Icons.refresh, size: 18),
                        label: Text('Coba Lagi'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryPurple,
                          foregroundColor: primaryWhite,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      });
    }).catchError((error) {
      if (!mounted) return;
      setState(() {
        _errorMessage = "Gagal memuat video: $error\nCoba klik tombol di bawah untuk memutar ulang.";
      });
    });
  }

  /// ============================================================
  ///  SHARE VIDEO
  /// ============================================================
  Future<void> _shareVideo() async {
    if (_videoData?['urls'] == null || _videoData!['urls'].isEmpty) return;

    try {
      final videoUrl = _videoData!['urls'][0];
      final response = await http.get(Uri.parse(videoUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/${_currentPlatform}_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles([XFile(file.path)],
          text:
              'Video ${_currentPlatform == 'douyin' ? 'Douyin' : 'TikTok'} dari: ${_videoData!['metadata']?['creator'] ?? 'Unknown'}');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error sharing: $e', style: TextStyle(color: primaryWhite)),
          backgroundColor: primaryPurple,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  /// ============================================================
  ///  TONTON ULANG DARI RIWAYAT
  /// ============================================================
  void _watchFromHistory(Map<String, dynamic> item) {
    _urlController.text = item['url'] as String;
    _downloadVideo();
  }

  /// ============================================================
  ///  QUICK PASTE - Ambil dari clipboard
  /// ============================================================
  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null && data!.text!.isNotEmpty) {
      _urlController.text = data.text!;
      _downloadVideo();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Clipboard kosong', style: TextStyle(color: primaryWhite)),
          backgroundColor: cardDark,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'TIKTOK & DOUYIN',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: primaryWhite,
                fontSize: 16,
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: douyinPink,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                'WATCH IN-APP',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: bgDark,
        centerTitle: true,
        elevation: 0,
        iconTheme: IconThemeData(color: primaryWhite),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // ===== INPUT SECTION =====
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: primaryPurple.withOpacity(0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: primaryPurple.withOpacity(0.2),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Platform badge
                    Row(
                      children: [
                        Icon(
                          _currentPlatform == 'douyin' ? Icons.music_note : Icons.tiktok,
                          color: _currentPlatform == 'douyin' ? douyinPink : accentPurple,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Platform Terdeteksi: ',
                          style: TextStyle(color: textGrey, fontSize: 12),
                        ),
                        Text(
                          _currentPlatform == 'douyin' ? 'DOUYIN' : 'TIKTOK',
                          style: TextStyle(
                            color: _currentPlatform == 'douyin' ? douyinPink : accentPurple,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _urlController,
                      onChanged: (value) {
                        setState(() {
                          _currentPlatform = _detectPlatform(value);
                        });
                      },
                      style: TextStyle(color: primaryWhite, fontSize: 16),
                      decoration: InputDecoration(
                        labelText: 'Masukkan URL TikTok / Douyin',
                        labelStyle: TextStyle(color: accentPurple),
                        hintText: 'https://www.douyin.com/video/xxx',
                        hintStyle: TextStyle(color: textGrey),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: primaryPurple.withOpacity(0.5)),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: accentPurple, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Colors.black.withOpacity(0.3),
                        prefixIcon: Icon(Icons.link, color: accentPurple),
                        suffixIcon: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Paste button
                            IconButton(
                              icon: Icon(Icons.content_paste, color: accentPurple, size: 20),
                              onPressed: _pasteFromClipboard,
                              tooltip: 'Paste dari clipboard',
                            ),
                            if (_isLoading)
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    color: accentPurple,
                                    strokeWidth: 2,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : _downloadVideo,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryPurple,
                              foregroundColor: primaryWhite,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 4,
                              shadowColor: primaryPurple.withOpacity(0.5),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _isLoading ? Icons.hourglass_top : Icons.play_circle_filled,
                                  size: 20,
                                  color: primaryWhite,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _isLoading ? 'MEMUAT...' : 'TONTON SEKARANG',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                    color: primaryWhite,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tonton TikTok & Douyin langsung di app tanpa buka browser. Video diputar otomatis di dalam app.',
                      style: TextStyle(color: textGrey, fontSize: 11),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ===== RECENT VIDEOS (Akses cepat tanpa buka web lagi) =====
              if (_recentVideos.isNotEmpty && _videoData == null)
                SizedBox(
                  height: 90,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _recentVideos.length,
                    itemBuilder: (context, index) {
                      final item = _recentVideos[index];
                      final isDouyin = item['platform'] == 'douyin';
                      return GestureDetector(
                        onTap: () => _watchFromHistory(item),
                        child: Container(
                          width: 200,
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: cardDark,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: (isDouyin ? douyinPink : accentPurple).withOpacity(0.4),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    isDouyin ? Icons.music_note : Icons.tiktok,
                                    color: isDouyin ? douyinPink : accentPurple,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    isDouyin ? 'DOUYIN' : 'TIKTOK',
                                    style: TextStyle(
                                      color: isDouyin ? douyinPink : accentPurple,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                  const Spacer(),
                                  Icon(Icons.play_circle_outline,
                                      color: primaryWhite.withOpacity(0.5), size: 16),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                item['title'] as String? ?? 'No Title',
                                style: TextStyle(
                                  color: primaryWhite,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '@${item['creator']}',
                                style: TextStyle(color: textGrey, fontSize: 11),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),

              if (_recentVideos.isNotEmpty && _videoData == null)
                const SizedBox(height: 12),

              // ===== ERROR MESSAGE =====
              if (_errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: Colors.redAccent),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: Colors.redAccent, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),

              // ===== VIDEO RESULT =====
              if (_videoData != null)
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardDark,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: primaryPurple.withOpacity(0.3)),
                            boxShadow: [
                              BoxShadow(
                                color: primaryPurple.withOpacity(0.2),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              // Header
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  gradient: _currentPlatform == 'douyin'
                                      ? LinearGradient(colors: [douyinPink, accentPurple])
                                      : purpleGradient,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      _currentPlatform == 'douyin'
                                          ? Icons.music_note
                                          : Icons.videocam,
                                      color: primaryWhite,
                                      size: 16,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      _currentPlatform == 'douyin'
                                          ? 'DOUYIN PREVIEW'
                                          : 'VIDEO PREVIEW',
                                      style: TextStyle(
                                        color: primaryWhite,
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // Video Player
                              if (_chewieController != null &&
                                  _videoController!.value.isInitialized)
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                        color: primaryPurple.withOpacity(0.5)),
                                    boxShadow: [
                                      BoxShadow(
                                        color: primaryPurple.withOpacity(0.3),
                                        blurRadius: 10,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: AspectRatio(
                                      aspectRatio:
                                          _videoController!.value.aspectRatio,
                                      child: Chewie(controller: _chewieController!),
                                    ),
                                  ),
                                )
                              else
                                Container(
                                  height: 220,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.5),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                        color: primaryPurple.withOpacity(0.3)),
                                  ),
                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CircularProgressIndicator(color: accentPurple),
                                        const SizedBox(height: 16),
                                        Text(
                                          'Memuat video ${_currentPlatform == 'douyin' ? 'Douyin' : 'TikTok'}...',
                                          style: TextStyle(
                                            color: accentPurple,
                                            fontSize: 14,
                                            fontFamily: 'Orbitron',
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          'Video akan diputar otomatis di dalam app',
                                          style: TextStyle(
                                            color: textGrey,
                                            fontSize: 11,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                              const SizedBox(height: 16),

                              // Video Info
                              if (_videoData?['metadata'] != null)
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                        color: primaryPurple.withOpacity(0.2)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        _videoData!['metadata']['title'] ?? 'No Title',
                                        style: TextStyle(
                                          color: primaryWhite,
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Icon(Icons.person,
                                              color: _currentPlatform == 'douyin'
                                                  ? douyinPink
                                                  : accentPurple,
                                              size: 16),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              'Creator: ${_videoData!['metadata']['creator'] ?? 'Unknown'}',
                                              style: TextStyle(
                                                color: textGrey,
                                                fontSize: 13,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                              const SizedBox(height: 16),

                              // Share Button
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton.icon(
                                      onPressed: _shareVideo,
                                      icon: Icon(Icons.share, size: 20, color: primaryWhite),
                                      label: Text(
                                        'SHARE',
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                          color: primaryWhite,
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: accentPurple,
                                        foregroundColor: primaryWhite,
                                        padding: const EdgeInsets.symmetric(vertical: 14),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        elevation: 4,
                                        shadowColor: accentPurple.withOpacity(0.5),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  ElevatedButton.icon(
                                    onPressed: _downloadVideo,
                                    icon: Icon(Icons.refresh, size: 20, color: primaryWhite),
                                    label: Text(
                                      'ULANG',
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        color: primaryWhite,
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: primaryPurple,
                                      foregroundColor: primaryWhite,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 14, horizontal: 14),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      elevation: 4,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )

              // ===== PLACEHOLDER =====
              else if (_videoData == null &&
                  !_isLoading &&
                  _errorMessage == null)
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Douyin Logo Style
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [douyinPink, accentPurple],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: douyinPink.withOpacity(0.4),
                                  blurRadius: 20,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.play_arrow,
                              size: 60,
                              color: primaryWhite,
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Tonton Douyin & TikTok',
                            style: TextStyle(
                              color: primaryWhite,
                              fontSize: 20,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              'Tanpa buka browser. Tanpa login. Tanpa keluar app.\nPaste URL Douyin / TikTok, video langsung diputar di sini.',
                              style: TextStyle(
                                color: textGrey,
                                fontSize: 13,
                                height: 1.5,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 24),
                          // Contoh URL
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 24),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: cardDark,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: primaryPurple.withOpacity(0.3)),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  'CONTOH URL YANG DIDUKUNG:',
                                  style: TextStyle(
                                    color: accentPurple,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                                const SizedBox(height: 10),
                                _buildUrlExample('Douyin',
                                    'https://www.douyin.com/video/7372...'),
                                const SizedBox(height: 6),
                                _buildUrlExample('Douyin Share',
                                    'https://v.douyin.com/iJxxxxxx/'),
                                const SizedBox(height: 6),
                                _buildUrlExample('TikTok',
                                    'https://vt.tiktok.com/xxx/'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUrlExample(String label, String url) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: accentPurple.withOpacity(0.2),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: accentPurple,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            url,
            style: TextStyle(color: textGrey, fontSize: 11),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
