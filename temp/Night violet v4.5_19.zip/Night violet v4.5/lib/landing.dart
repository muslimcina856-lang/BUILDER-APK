import 'package:flutter/material.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _mainController;
  late AnimationController _pulseController;
  late AnimationController _textGlowController;
  late AnimationController _buttonGlowController;
  
  // Controller untuk staggered animation
  late AnimationController _staggerController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;
  
  // Animasi staggered untuk tombol
  late Animation<Offset> _buttonSlideAnimation;
  late Animation<double> _buttonFadeAnimation;
  
  // Animasi staggered untuk teks
  late Animation<Offset> _titleSlideAnimation;
  late Animation<double> _titleFadeAnimation;
  late Animation<Offset> _subtitleSlideAnimation;
  late Animation<double> _subtitleFadeAnimation;
  late Animation<Offset> _dividerSlideAnimation;
  late Animation<double> _dividerFadeAnimation;

  // --- TEMA WARNA UNGU ---
  final Color primaryDark = const Color(0xFF0A0714);
  final Color primaryPurple = const Color(0xFF6C3CE9);
  final Color accentPurple = const Color(0xFFB18CFF);
  final Color glassBorder = Colors.white.withOpacity(0.10);
  final Color cardBg = Colors.white.withOpacity(0.06);

  static const String _bgAsset = "assets/images/bg.png";

  @override
  void initState() {
    super.initState();

    // Main Animation Controller
    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    // Staggered Animation Controller
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    // Pulse Controller untuk efek berdenyut
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Text Glow Controller untuk efek cahaya bergerak pada teks
    _textGlowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    // Button Glow Controller untuk border berputar
    _buttonGlowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    // Animasi Fade
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _mainController, curve: Curves.easeOut),
    );

    // Animasi Slide dari bawah
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _mainController, curve: Curves.easeOutCubic),
    );

    // Animasi Scale untuk logo
    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: Curves.elasticOut,
      ),
    );

    // Animasi Pulse untuk tombol
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    // --- STAGGERED ANIMATIONS ---
    // Title: muncul dari bawah (delay 0ms)
    _titleSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.6),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOutCubic),
      ),
    );
    
    _titleFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );

    // Subtitle: muncul dari bawah (delay 200ms)
    _subtitleSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.15, 0.55, curve: Curves.easeOutCubic),
      ),
    );
    
    _subtitleFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.15, 0.55, curve: Curves.easeOut),
      ),
    );

    // Divider: muncul dari bawah (delay 400ms)
    _dividerSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.4),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.30, 0.60, curve: Curves.easeOutCubic),
      ),
    );
    
    _dividerFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.30, 0.60, curve: Curves.easeOut),
      ),
    );

    // Button: muncul dari bawah (delay 600ms)
    _buttonSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.7),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.45, 0.85, curve: Curves.easeOutCubic),
      ),
    );
    
    _buttonFadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _staggerController,
        curve: const Interval(0.45, 0.85, curve: Curves.easeOut),
      ),
    );

    _mainController.forward();
    _staggerController.forward();
  }

  @override
  void dispose() {
    _mainController.dispose();
    _staggerController.dispose();
    _pulseController.dispose();
    _textGlowController.dispose();
    _buttonGlowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // --- BACKGROUND IMAGE ---
          Image.asset(
            _bgAsset,
            fit: BoxFit.cover,
          ),

          // --- OVERLAY GRADIENT ---
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [0.0, 0.35, 0.7, 1.0],
                colors: [
                  primaryDark.withOpacity(0.55),
                  Colors.transparent,
                  primaryDark.withOpacity(0.45),
                  primaryDark.withOpacity(0.92),
                ],
              ),
            ),
          ),

          // --- KONTEN ---
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 12),

                    // --- WELCOME TEXT (POJOK KIRI ATAS) ---
                    _buildWelcomeBadge(),

                    // --- SPACER ---
                    const Spacer(),

                    // --- LOGO & JUDUL UTAMA ---
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Logo dengan Scale Animation
                        SlideTransition(
                          position: _slideAnimation,
                          child: _buildAnimatedLogo(),
                        ),
                        const SizedBox(height: 20),

                        // Teks Judul dengan Slide + Fade Staggered
                        SlideTransition(
                          position: _titleSlideAnimation,
                          child: FadeTransition(
                            opacity: _titleFadeAnimation,
                            child: _buildAnimatedTitle(),
                          ),
                        ),

                        const SizedBox(height: 8),

                        // Subtitle dengan Slide + Fade Staggered
                        SlideTransition(
                          position: _subtitleSlideAnimation,
                          child: FadeTransition(
                            opacity: _subtitleFadeAnimation,
                            child: Text(
                              "Alergi Apk Ampas",
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                color: Colors.white.withOpacity(0.65),
                                fontSize: 13,
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Divider dengan Slide + Fade Staggered
                        SlideTransition(
                          position: _dividerSlideAnimation,
                          child: FadeTransition(
                            opacity: _dividerFadeAnimation,
                            child: _buildAnimatedDivider(),
                          ),
                        ),

                        const SizedBox(height: 40),
                      ],
                    ),

                    // --- TOMBOL SIGN-IN (dengan Staggered Animation) ---
                    SlideTransition(
                      position: _buttonSlideAnimation,
                      child: FadeTransition(
                        opacity: _buttonFadeAnimation,
                        child: _buildAnimatedSignInButton(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // --- VERSION TEXT ---
                    FadeTransition(
                      opacity: _fadeAnimation,
                      child: Center(
                        child: Text(
                          "V4.5 • Night violet",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WELCOME BADGE ---
  Widget _buildWelcomeBadge() {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutBack,
      builder: (context, double value, child) {
        return Transform.scale(
          scale: value,
          child: child,
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: glassBorder),
          boxShadow: [
            BoxShadow(
              color: accentPurple.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, _) {
                return Container(
                  width: 8 + 2 * _pulseController.value,
                  height: 8 + 2 * _pulseController.value,
                  decoration: BoxDecoration(
                    color: accentPurple,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accentPurple.withOpacity(0.6 + 0.3 * _pulseController.value),
                        blurRadius: 8 + 4 * _pulseController.value,
                        spreadRadius: 1 + 1 * _pulseController.value,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 10),
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [accentPurple, primaryPurple],
              ).createShader(bounds),
              child: const Text(
                "WELCOME TO Night violet v4.5 PROJECT",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 0.8,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- ANIMATED LOGO ---
  Widget _buildAnimatedLogo() {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [primaryPurple, accentPurple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: accentPurple.withOpacity(0.4),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(19),
          child: Image.asset(
            'assets/images/logo.png',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  // --- ANIMATED TITLE ---
  Widget _buildAnimatedTitle() {
    return AnimatedBuilder(
      animation: _textGlowController,
      builder: (context, _) {
        final double t = _textGlowController.value;
        return ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment(-2.0 + 4.0 * t, -0.3),
              end: Alignment(-1.0 + 4.0 * t, 0.3),
              colors: const [
                Color(0xFF6C3CE9),
                Color(0xFFB18CFF),
                Colors.white,
                Color(0xFFB18CFF),
                Color(0xFF6C3CE9),
              ],
              stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
            ).createShader(bounds);
          },
          child: Text(
            "Night violet v4.5",
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 38,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: 2,
              height: 1.1,
              shadows: [
                Shadow(
                  color: primaryPurple.withOpacity(0.3 + 0.2 * t),
                  blurRadius: 20 + 10 * t,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- ANIMATED DIVIDER ---
  Widget _buildAnimatedDivider() {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 1000),
      curve: Curves.easeOut,
      builder: (context, double value, child) {
        return Container(
          width: 90 * value,
          height: 2,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryPurple, accentPurple.withOpacity(0.1)],
            ),
          ),
        );
      },
    );
  }

  // --- ANIMATED SIGN IN BUTTON ---
  Widget _buildAnimatedSignInButton() {
    return Center(
      child: AnimatedBuilder(
        animation: _buttonGlowController,
        builder: (context, child) {
          return Container(
            width: double.infinity,
            height: 60,
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: SweepGradient(
                transform: GradientRotation(_buttonGlowController.value * 6.2832),
                colors: [
                  accentPurple.withOpacity(0.0),
                  accentPurple.withOpacity(0.0),
                  accentPurple,
                  primaryPurple,
                  accentPurple,
                  accentPurple.withOpacity(0.0),
                  accentPurple.withOpacity(0.0),
                ],
                stops: const [0.0, 0.35, 0.45, 0.5, 0.55, 0.65, 1.0],
              ),
            ),
            child: AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, _) {
                return Transform.scale(
                  scale: _pulseAnimation.value,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryPurple, accentPurple],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: primaryPurple.withOpacity(0.4 + 0.2 * _pulseController.value),
                          blurRadius: 18 + 6 * _pulseController.value,
                          offset: Offset(0, 8 + 2 * _pulseController.value),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                      ),
                      onPressed: () {
                        Navigator.pushNamed(context, "/login");
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.login, color: Colors.white, size: 22),
                          const SizedBox(width: 12),
                          const Text(
                            "Sign In",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              return Transform.translate(
                                offset: Offset(4 * _pulseController.value, 0),
                                child: child,
                              );
                            },
                            child: const Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}