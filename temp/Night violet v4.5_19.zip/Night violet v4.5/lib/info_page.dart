import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage>
    with SingleTickerProviderStateMixin {
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  // Track which rule card is expanded
  int? _expandedIndex;

  // --- TEMA PURPLE/DARK (disamakan dengan Dashboard) ---
  final Color bgDark = const Color(0xFF000000);
  final Color primaryPurple = const Color(0xFF7B2FF7);
  final Color accentPurple = const Color(0xFFB388FF);
  final Color lightPurple = const Color(0xFFD1B3FF);
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  // Animation controllers
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late AnimationController _glowController;
  late AnimationController _shimmerController;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeOut);

    _glowController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _shimmerController = AnimationController(
      duration: const Duration(seconds: 2, milliseconds: 200),
      vsync: this,
    )..repeat();

    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _controller.dispose();
    _glowController.dispose();
    _shimmerController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('http://infokanlc.pteroq.biz.id:10714/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
        _controller.forward();
      } else {
        setState(() => isLoading = false);
        _controller.forward();
      }
    } catch (e) {
      setState(() => isLoading = false);
      _controller.forward();
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('http://infokanlc.pteroq.biz.id:10714/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = Colors.greenAccent;
          } else if (duration < 500) {
            apiStatusColor = Colors.amber;
          } else {
            apiStatusColor = Colors.orangeAccent;
          }
          apiStatusText = "SYS.ONLINE :: ${duration}ms";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = Colors.redAccent;
        apiStatusText = "SYS.OFFLINE";
      });
    }
  }

  // --- Glow border, sama seperti di Dashboard ---
  Widget _buildGlowBorder({
    required Widget child,
    double borderRadius = 24,
    double borderWidth = 1.4,
  }) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.all(borderWidth),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: SweepGradient(
              transform: GradientRotation(_glowController.value * 6.2832),
              colors: [
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
                lightPurple,
                accentPurple,
                primaryPurple,
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
              ],
              stops: const [0.0, 0.35, 0.45, 0.5, 0.55, 0.65, 1.0],
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius - borderWidth),
            child: child,
          ),
        );
      },
    );
  }

  // --- Shimmer title, sama seperti di Dashboard ---
  Widget _buildShimmerTitle(String text) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        final double t = _shimmerController.value;
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment(-2.0 + 4.0 * t, -0.3),
              end: Alignment(-1.0 + 4.0 * t, 0.3),
              colors: const [
                Colors.white,
                Colors.white,
                Colors.white70,
                Colors.white,
                Colors.white,
              ],
              stops: const [0.0, 0.40, 0.5, 0.60, 1.0],
            ).createShader(bounds);
          },
          child: child,
        );
      },
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.bold,
          fontSize: 16,
          letterSpacing: 2,
        ),
      ),
    );
  }

  // Fade + slide-up entrance untuk tiap elemen (staggered)
  Widget _staggeredEntrance({required int index, required Widget child}) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 80)),
      curve: Curves.easeOutCubic,
      builder: (context, value, _) {
        return Transform.translate(
          offset: Offset(0, (1 - value) * 24),
          child: Opacity(opacity: value, child: child),
        );
      },
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: bgDark,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: const Text("INFO", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        ),
        body: Stack(
          children: [
            Positioned.fill(
              child: Container(color: bgDark),
            ),
            Positioned.fill(
              child: CustomPaint(painter: _InfoGridPainter(lineColor: borderGlass)),
            ),
            Center(
              child: CircularProgressIndicator(color: accentPurple),
            ),
          ],
        ),
      );
    }

    final List<Map<String, dynamic>> rulesList = [
      {
        "icon": Icons.swap_horiz_outlined,
        "code": "001",
        "title": "NO ACCOUNT BARTERING",
        "desc": "Akun eksklusif DarkVerse tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
        "penalty": "Akun akan DIHAPUS permanen tanpa kompensasi. Aktivitas barter tercatat di log sistem dan dapat dilaporkan.",
      },
      {
        "icon": Icons.person_off_outlined,
        "code": "002",
        "title": "STRICTLY PERSONAL USE",
        "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
        "penalty": "Deteksi multi-device akan memicu suspend otomatis. Akun dibekukan dan tidak dapat dipulihkan.",
      },
      {
        "icon": Icons.money_off_outlined,
        "code": "003",
        "title": "RESELLING PROHIBITED",
        "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
        "penalty": "Hak akses dicabut sepenuhnya. Akun penjual dan pembeli akan dihapus dari sistem.",
      },
      {
        "icon": Icons.timer_off_outlined,
        "code": "004",
        "title": "ILLEGAL DURATION SALES",
        "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
        "penalty": "Akun langsung di-terminate. Tidak ada pemulihan atau refund untuk pelanggaran jenis ini.",
      },
      {
        "icon": Icons.trending_down_outlined,
        "code": "005",
        "title": "PRICE DUMPING BAN",
        "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
        "penalty": "Sanksi berupa pembekuan akun reseller dan penghapusan hak distribusi secara permanen.",
      },
    ];

    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        centerTitle: false,
        titleSpacing: 16,
        title: Row(
          children: [
            AnimatedBuilder(
              animation: _glowController,
              builder: (context, _) {
                final double pulse =
                    0.5 - 0.5 * (2 * (_glowController.value - 0.5)).abs();
                return Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: accentPurple,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accentPurple.withOpacity(0.5 + 0.3 * pulse),
                        blurRadius: 6 + 6 * pulse,
                        spreadRadius: 1 + pulse,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 12),
            _buildShimmerTitle("EULA & SYSTEM INFO"),
          ],
        ),
      ),
      body: Container(
        color: bgDark,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(painter: _InfoGridPainter(lineColor: borderGlass)),
            ),
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _staggeredEntrance(index: 0, child: _buildCompactApiStatus()),
                      const SizedBox(height: 24),

                      // Section header
                      _staggeredEntrance(
                        index: 1,
                        child: Row(
                          children: [
                            Container(
                              width: 3,
                              height: 20,
                              decoration: BoxDecoration(
                                color: accentPurple,
                                boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.8), blurRadius: 6)],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              "USER PROTOCOLS",
                              style: TextStyle(
                                color: accentPurple,
                                fontSize: 13,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.bold,
                                letterSpacing: 3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Rules list
                      ...rulesList.asMap().entries.map((entry) {
                        final int index = entry.key;
                        final Map<String, dynamic> rule = entry.value;
                        final bool isExpanded = _expandedIndex == index;

                        return _staggeredEntrance(
                          index: index + 2,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _expandedIndex = isExpanded ? null : index;
                                });
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                curve: Curves.easeInOutCubic,
                                decoration: BoxDecoration(
                                  color: cardGlass,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isExpanded ? accentPurple.withOpacity(0.6) : borderGlass,
                                    width: isExpanded ? 1.2 : 1,
                                  ),
                                  boxShadow: isExpanded
                                      ? [BoxShadow(color: accentPurple.withOpacity(0.15), blurRadius: 14, spreadRadius: 1)]
                                      : [],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Rule header row
                                    Padding(
                                      padding: const EdgeInsets.all(14),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          // Icon box
                                          AnimatedContainer(
                                            duration: const Duration(milliseconds: 300),
                                            width: 44,
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: isExpanded
                                                  ? primaryPurple.withOpacity(0.25)
                                                  : Colors.white.withOpacity(0.06),
                                              borderRadius: BorderRadius.circular(8),
                                              border: Border.all(color: accentPurple.withOpacity(0.5)),
                                            ),
                                            child: Icon(rule['icon'] as IconData, color: accentPurple, size: 22),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  children: [
                                                    Text(
                                                      rule['code'] as String,
                                                      style: TextStyle(
                                                        color: lightPurple.withOpacity(0.7),
                                                        fontSize: 11,
                                                        fontFamily: 'Orbitron',
                                                        letterSpacing: 1,
                                                      ),
                                                    ),
                                                    const Spacer(),
                                                    AnimatedRotation(
                                                      turns: isExpanded ? 0.5 : 0,
                                                      duration: const Duration(milliseconds: 300),
                                                      curve: Curves.easeInOutCubic,
                                                      child: Icon(Icons.keyboard_arrow_down, color: accentPurple, size: 18),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  rule['title'] as String,
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 13,
                                                    letterSpacing: 1,
                                                  ),
                                                ),
                                                const SizedBox(height: 6),
                                                Text(
                                                  rule['desc'] as String,
                                                  style: TextStyle(color: accentGrey, fontSize: 12, height: 1.5, fontFamily: 'ShareTechMono'),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Expandable penalty section
                                    AnimatedCrossFade(
                                      duration: const Duration(milliseconds: 300),
                                      sizeCurve: Curves.easeInOutCubic,
                                      crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                                      firstChild: const SizedBox.shrink(),
                                      secondChild: Column(
                                        children: [
                                          Container(
                                            height: 1,
                                            margin: const EdgeInsets.symmetric(horizontal: 14),
                                            color: accentPurple.withOpacity(0.25),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Icon(Icons.warning_amber_rounded, color: Colors.redAccent.shade200, size: 16),
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        "SANKSI",
                                                        style: TextStyle(
                                                          color: Colors.redAccent.shade200,
                                                          fontFamily: 'Orbitron',
                                                          fontSize: 11,
                                                          fontWeight: FontWeight.bold,
                                                          letterSpacing: 2,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 4),
                                                      Text(
                                                        rule['penalty'] as String,
                                                        style: TextStyle(
                                                          color: Colors.red.shade200,
                                                          fontSize: 12,
                                                          height: 1.5,
                                                          fontFamily: 'ShareTechMono',
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),

                      const SizedBox(height: 8),

                      // Footer disclaimer
                      _staggeredEntrance(
                        index: rulesList.length + 2,
                        child: Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 20),
                            child: Column(
                              children: [
                                Icon(Icons.shield_outlined, color: accentPurple, size: 24),
                                const SizedBox(height: 10),
                                Text(
                                  "Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan di atas.",
                                  style: TextStyle(color: accentGrey, fontSize: 11, fontStyle: FontStyle.italic, height: 1.6),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 12),
                                Container(
                                  height: 2,
                                  width: 80,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [primaryPurple, accentPurple, lightPurple],
                                    ),
                                    borderRadius: BorderRadius.circular(2),
                                    boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.4), blurRadius: 6)],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactApiStatus() {
    return _buildGlowBorder(
      borderRadius: 12,
      borderWidth: 1,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: cardGlass,
        ),
        child: Row(
          children: [
            AnimatedBuilder(
              animation: _glowController,
              builder: (context, _) {
                // Halus berdenyut (pulse) mengikuti siklus _glowController
                final double pulse =
                    (0.5 - 0.5 * (2 * (_glowController.value - 0.5)).abs()) * 2;
                return Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: apiStatusColor,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: apiStatusColor.withOpacity(0.6),
                        blurRadius: 6 + 3 * pulse,
                        spreadRadius: 1 + 0.5 * pulse,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 12),
            Text(
              apiStatusText.toUpperCase(),
              style: const TextStyle(
                color: Color(0xFFAAAAAA),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1,
              ),
            ),
            const Spacer(),
            Icon(Icons.settings_outlined, color: accentPurple, size: 18),
          ],
        ),
      ),
    );
  }
}

class _InfoGridPainter extends CustomPainter {
  final Color lineColor;
  final double cellSize;

  _InfoGridPainter({required this.lineColor, this.cellSize = 28});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 1;

    for (double x = 0; x <= size.width; x += cellSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += cellSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _InfoGridPainter oldDelegate) =>
      oldDelegate.lineColor != lineColor || oldDelegate.cellSize != cellSize;
}
