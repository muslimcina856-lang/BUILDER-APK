import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const PrankApp());
}

class PrankApp extends StatelessWidget {
  const PrankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cat Prank',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AudioPlayer _player = AudioPlayer();
  bool _showJumpscare = false;

  Future<void> _trigger() async {
    setState(() => _showJumpscare = true);

    // Getar pendek
    HapticFeedback.heavyImpact();

    // Mainkan suara jumpscare
    await _player.play(AssetSource('scream.wav'));

    // Kembalikan ke layar normal setelah beberapa saat
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) {
        setState(() => _showJumpscare = false);
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Layar utama / normal
          Center(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                textStyle: const TextStyle(fontSize: 22),
              ),
              onPressed: _trigger,
              child: const Text('Tap untuk lihat kucing lucu 🐱'),
            ),
          ),

          // Overlay jumpscare
          if (_showJumpscare)
            Positioned.fill(
              child: Container(
                color: Colors.black,
                child: Image.asset(
                  'lib/assets/jumpscare.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
