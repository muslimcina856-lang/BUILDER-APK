# Cat Prank (Jumpscare App)

Aplikasi sederhana: tombol "Tap untuk lihat kucing lucu", saat ditekan muncul
gambar jumpscare full-screen + suara + getar singkat.

## Cara menjalankan (di laptop kamu)

### 1. Install Flutter SDK
Download dari https://flutter.dev/docs/get-started/install dan ikuti instruksinya
sesuai OS kamu (Windows/Mac/Linux). Pastikan `flutter doctor` tidak ada error besar.

### 2. Letakkan folder project ini
Extract/salin folder `jumpscare_prank` ini ke mana saja, misalnya `Documents/jumpscare_prank`.

### 3. Edit `android/local.properties`
Buka file `android/local.properties`, ganti:
```
flutter.sdk=/path/to/flutter
sdk.dir=/path/to/Android/sdk
```
dengan lokasi instalasi Flutter SDK dan Android SDK di komputermu. Contoh (Windows):
```
flutter.sdk=C:\\flutter
sdk.dir=C:\\Users\\NamaKamu\\AppData\\Local\\Android\\Sdk
```

### 4. Ganti asset (opsional tapi disarankan)
Folder `lib/assets/` sudah ada `jumpscare.jpg` dan `scream.wav` placeholder
(gambar merah bertulisan "BOO!" dan suara nada naik sederhana).
Kamu bisa ganti dengan file kamu sendiri — **nama file harus sama**
(`jumpscare.jpg` dan `scream.wav`), atau ubah nama di `pubspec.yaml`
dan `lib/main.dart` sesuai file barumu.

### 5. Install dependencies
Buka terminal di folder project, jalankan:
```
flutter pub get
```

### 6. Jalankan / build
- Untuk test di HP yang tersambung USB (developer mode + USB debugging aktif):
  ```
  flutter run
  ```
- Untuk build APK:
  ```
  flutter build apk --release
  ```
  Hasil APK ada di `build/app/outputs/flutter-apk/app-release.apk`

## Catatan
- App ini tidak meminta permission aneh-aneh, hanya permission standar Flutter.
- Kalau muncul error "SDK location not found", pastikan `sdk.dir` di
  `android/local.properties` benar.
