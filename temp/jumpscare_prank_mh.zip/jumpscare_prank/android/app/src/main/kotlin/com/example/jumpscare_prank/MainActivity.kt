package com.example.jumpscare_prank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
