import 'package:flutter/material.dart';

class MiniPlayer extends StatefulWidget {
  const MiniPlayer({Key? key}) : super(key: key);

  @override
  _MiniPlayerState createState() => _MiniPlayerState();
}

class _MiniPlayerState extends State<MiniPlayer> {
  // Mock State (Nanti diisi dengan provider/just_audio state)
  bool isPlaying = false;
  String title = "Menunggu lagu...";
  String artist = "System idle";
  double progress = 0.0; // 0.0 sampai 1.0

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Logika untuk membuka Full Player (player_screen.dart)
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: const BoxDecoration(
          color: Color(0xF2000712), // Sesuai opacity .95 di CSS
          border: Border(top: BorderSide(color: Color(0xFF001F3F))),
          boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 20, offset: Offset(0, -5))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                // Thumbnail
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: const Color(0xFF222222),
                    borderRadius: BorderRadius.circular(8),
                    // image: NetworkImage(imageUrl), jika ada lagu
                  ),
                ),
                const SizedBox(width: 12),
                
                // Info Teks
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 11)),
                    ],
                  ),
                ),
                
                // Kontrol Audio
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.skip_previous, color: Colors.white, size: 24),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () { /* Logic prev */ },
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () {
                        setState(() { isPlaying = !isPlaying; });
                      },
                      child: Container(
                        width: 30, height: 30,
                        alignment: Alignment.center,
                        child: Icon(
                          isPlaying ? Icons.pause : Icons.play_arrow,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                      icon: const Icon(Icons.skip_next, color: Colors.white, size: 24),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () { /* Logic next */ },
                    ),
                  ],
                ),
              ],
            ),
            
            // Progress Bar Tipis & Waktu
            const SizedBox(height: 6),
            Row(
              children: [
                const Text('0:00', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 9, fontWeight: FontWeight.bold)),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    height: 2,
                    decoration: BoxDecoration(color: const Color(0xFF222222), borderRadius: BorderRadius.circular(2)),
                    alignment: Alignment.centerLeft,
                    child: FractionallySizedBox(
                      widthFactor: progress, // Ini akan bergerak mengikuti audio
                      child: Container(color: const Color(0xFFFF003C)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Text('0:00', style: TextStyle(color: Colors.grey, fontSize: 9, fontWeight: FontWeight.bold)),
              ],
            )
          ],
        ),
      ),
    );
  }
}
