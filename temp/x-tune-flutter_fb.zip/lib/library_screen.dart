import 'package:flutter/material.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({Key? key}) : super(key: key);

  @override
  _LibraryScreenState createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final TextEditingController _importController = TextEditingController();
  final TextEditingController _txtController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(top: 20, left: 15, right: 15, bottom: 130),
      child: Column(
        children: [
          // Section Impor YT Music
          _buildSectionBox(
            title: 'IMPOR PLAYLIST YT MUSIC',
            child: Column(
              children: [
                TextField(
                  controller: _importController,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Paste link playlist YT Music...',
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: const Color(0xFF111111),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF333333))),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF00E5FF))),
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () { /* Fungsi Impor URL */ },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00E5FF),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    minimumSize: const Size(double.infinity, 45),
                  ),
                  child: const Text('IMPOR YT MUSIC', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 15),

          // Section Impor TXT
          _buildSectionBox(
            title: 'IMPOR TEKS TUNEMYMUSIC',
            actionButton: ElevatedButton(
              onPressed: () { /* Buka modal tips */ },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00E5FF),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                minimumSize: const Size(60, 25),
                padding: const EdgeInsets.symmetric(horizontal: 10),
              ),
              child: const Text('TIPS ?', style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
            isGradient: true,
            child: Column(
              children: [
                const Text(
                  'Buka file .txt dari TuneMyMusic, Copy semua teksnya, lalu Paste ke kotak di bawah ini.',
                  style: TextStyle(color: Colors.grey, fontSize: 11),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: _txtController,
                  maxLines: 4,
                  style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Paste teks lagu dari file TXT di sini...',
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: const Color(0xFF000A15),
                    contentPadding: const EdgeInsets.all(12),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF00E5FF))),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF00E5FF))),
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () { /* Fungsi Impor TXT */ },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00E5FF),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    minimumSize: const Size(double.infinity, 45),
                  ),
                  child: const Text('SEDOT LAGU DARI TEKS', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 15),

          // Library Playlist Anda
          _buildSectionBox(
            title: 'LIBRARY PLAYLIST ANDA',
            actionButton: ElevatedButton.icon(
              onPressed: () { /* Buka modal create playlist */ },
              icon: const Icon(Icons.add, size: 14, color: Colors.white),
              label: const Text('BARU', style: TextStyle(color: Colors.white, fontSize: 10)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF003C),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                minimumSize: const Size(60, 25),
                padding: const EdgeInsets.symmetric(horizontal: 10),
              ),
            ),
            child: Column(
              children: [
                // Contoh Card Folder Offline
                _buildPlaylistFolder('Lagu Terunduh (Offline)', 'Memuat data...', Icons.download_done, const Color(0xFFFF003C)),
              ],
            ),
          ),

          const SizedBox(height: 15),

          // Histori Putar
          _buildSectionBox(
            title: 'HISTORI PUTAR',
            actionButton: TextButton(
              onPressed: () { /* Hapus Histori */ },
              child: const Text('Hapus', style: TextStyle(color: Color(0xFFFF003C), fontSize: 11, fontWeight: FontWeight.bold)),
            ),
            child: const Center(
              child: Text('Belum ada lagu yang diputar.', style: TextStyle(color: Colors.grey, fontSize: 13)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionBox({required String title, required Widget child, Widget? actionButton, bool isGradient = false}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: isGradient ? null : const Color(0xFF000712),
        gradient: isGradient ? const LinearGradient(colors: [Color(0xFF000A15), Color(0xFF000000)], begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: isGradient ? const Color(0xFF00E5FF) : const Color(0xFF001F3F)),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF))),
              if (actionButton != null) actionButton,
            ],
          ),
          const Divider(color: Color(0xFF002244), thickness: 1, height: 20),
          child,
        ],
      ),
    );
  }

  Widget _buildPlaylistFolder(String title, String subtitle, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF000712), Colors.black]),
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFF003C), Color(0xFF8800FF)]),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.music_note, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.greenAccent, fontSize: 11)),
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: color, size: 24),
        ],
      ),
    );
  }
}
