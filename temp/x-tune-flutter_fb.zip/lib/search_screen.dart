import 'package:flutter/material.dart';
import 'dart:async';
import 'api_service.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;
  
  List<dynamic> suggestions = [];
  List<dynamic> searchResults = [];
  bool isSearching = false;
  int searchIndex = 0;

  void _onSearchChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () async {
      if (query.isNotEmpty) {
        final sugg = await ApiService.getSuggestions(query);
        setState(() {
          suggestions = sugg;
        });
      } else {
        setState(() {
          suggestions = [];
        });
      }
    });
  }

  Future<void> _executeSearch(String query) async {
    setState(() {
      suggestions = [];
      isSearching = true;
      searchResults = [];
      searchIndex = 0;
    });

    final results = await ApiService.searchLagu(query);
    
    setState(() {
      searchResults = results;
      isSearching = false;
      searchIndex = 10; // Load 10 pertama, sesuai logika JS
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(top: 35, left: 15, right: 15, bottom: 130),
      child: Column(
        children: [
          // Form Input Search
          Stack(
            children: [
              TextField(
                controller: _searchController,
                onChanged: _onSearchChanged,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'Inject keywords atau URL YouTube...',
                  hintStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF000A14),
                  contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: const BorderSide(color: Color(0xFF002244))),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25), 
                    borderSide: const BorderSide(color: Color(0xFFFF003C)),
                  ),
                ),
              ),
              if (suggestions.isNotEmpty)
                Positioned(
                  top: 50,
                  left: 20,
                  right: 20,
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xE6000A14), // rgba(0,10,20,.98)
                      borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20)),
                      border: Border.all(color: const Color(0xFF00E5FF)),
                    ),
                    constraints: const BoxConstraints(maxHeight: 220),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: suggestions.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          leading: const Icon(Icons.search, size: 14, color: Colors.white),
                          title: Text(suggestions[index], style: const TextStyle(color: Colors.white, fontSize: 13)),
                          onTap: () {
                            _searchController.text = suggestions[index];
                            _executeSearch(suggestions[index]);
                          },
                        );
                      },
                    ),
                  ),
                ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // Tombol HACK / CARI
          ElevatedButton(
            onPressed: () => _executeSearch(_searchController.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF003C),
              padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 10,
              shadowColor: const Color(0xFFFF003C),
            ),
            child: const Text('HACK / CARI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),

          const SizedBox(height: 20),

          if (isSearching)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Color(0xFFFF003C), strokeWidth: 2)),
                SizedBox(width: 8),
                Text('Menghubungkan ke server...', style: TextStyle(color: Color(0xFFFF003C), fontSize: 13, fontWeight: FontWeight.bold)),
              ],
            ),

          const SizedBox(height: 20),

          // Hasil Pencarian Box
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: const Color(0xFF000712),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: const Color(0xFF001F3F)),
              boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.only(bottom: 8),
                  margin: const EdgeInsets.only(bottom: 15),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFF002244)))),
                  child: const Text('HASIL PENCARIAN', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF))),
                ),
                
                if (searchResults.isEmpty && !isSearching)
                  const Text('Menunggu perintah pencarian...', style: TextStyle(color: Colors.grey, fontSize: 13))
                else
                  ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: searchResults.length > searchIndex ? searchIndex : searchResults.length,
                    itemBuilder: (context, index) {
                      final track = searchResults[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: const Color(0xFF001F3F)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 55, height: 55,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(image: NetworkImage(track['thumbnail'] ?? ''), fit: BoxFit.cover),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(track['title'] ?? 'Unknown', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold)),
                                  Text(track['artist'] ?? 'Unknown', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.more_vert, color: Colors.grey),
                              onPressed: () { /* Opsi Modal Lagu */ },
                            )
                          ],
                        ),
                      );
                    },
                  ),

                if (searchResults.length > searchIndex)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(top: 15),
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFF00E5FF)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        setState(() { searchIndex += 10; });
                      },
                      child: const Text('Muat Hasil Lainnya...', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 13)),
                    ),
                  )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
