import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<String> genres = [
    'Populer', 'Sedih', 'Senang', 'Mengisi energi', 'Bersantai', 'Perjalanan'
  ];
  final List<String> genreQueries = [
    'Lagu Populer Hits Terbaru', 'Lagu Sedih Galau', 'Lagu Senang Bahagia', 
    'EDM Mengisi Energi', 'Lagu Bersantai Lo-Fi', 'Lagu Perjalanan Jauh'
  ];
  
  int activeGenreIndex = 0;
  bool isOfflineMode = false;
  bool isLoading = true;
  List<dynamic> berandaData = [];

  @override
  void initState() {
    super.initState();
    _checkOfflineMode();
    _loadBeranda(genreQueries[0]);
  }

  Future<void> _checkOfflineMode() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isOfflineMode = prefs.getBool('ytpro_offline_mode') ?? false;
    });
  }

  Future<void> _loadBeranda(String query) async {
    setState(() => isLoading = true);
    if (isOfflineMode) {
      setState(() => isLoading = false);
      return;
    }

    try {
      final results = await ApiService.searchLagu(query);
      setState(() {
        berandaData = results;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isOfflineMode) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.wifi_off, size: 60, color: Color(0xFF444444)),
              const SizedBox(height: 15),
              const Text(
                'MODE OFFLINE AKTIF',
                style: TextStyle(color: Color(0xFFFF003C), fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'Penggunaan data internet dimatikan sepenuhnya. Buka tab Koleksi > Lagu Terunduh untuk mendengarkan musikmu.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.5),
              ),
              const SizedBox(height: 15),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00E5FF),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: () {
                  // Nanti dihubungkan dengan library_screen.dart (Buka offline)
                },
                child: const Text('Buka File Offline', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.only(top: 20, bottom: 130),
      children: [
        // Pill Genres (Kategori)
        SizedBox(
          height: 40,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 15),
            itemCount: genres.length,
            itemBuilder: (context, index) {
              final isActive = index == activeGenreIndex;
              return GestureDetector(
                onTap: () {
                  setState(() { activeGenreIndex = index; });
                  _loadBeranda(genreQueries[index]);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFFFF003C) : const Color(0xFF002244),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isActive ? const Color(0xFFFF003C) : const Color(0xFF002244)),
                  ),
                  child: Center(
                    child: Text(
                      genres[index],
                      style: TextStyle(
                        color: isActive ? Colors.white : const Color(0xFF00E5FF),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        
        const SizedBox(height: 20),

        if (isLoading)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(40.0),
              child: CircularProgressIndicator(color: Color(0xFFFF003C)),
            ),
          )
        else
          // Konten Hasil Rekomendasi
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  activeGenreIndex == 0 ? "Teruslah mendengarkan" : "Rekomendasi ${genres[activeGenreIndex]}",
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white),
                ),
              ),
              const SizedBox(height: 15),
              SizedBox(
                height: 210,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  itemCount: berandaData.length,
                  itemBuilder: (context, index) {
                    final track = berandaData[index];
                    return GestureDetector(
                      onTap: () {
                        // Nanti disambungkan ke fungsi Play Song di player_screen
                      },
                      child: Container(
                        width: 140,
                        margin: const EdgeInsets.only(right: 15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 140,
                              height: 140,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: const Color(0xFF111111),
                                image: track['thumbnail'] != ''
                                    ? DecorationImage(image: NetworkImage(track['thumbnail']), fit: BoxFit.cover)
                                    : null,
                              ),
                              // Tombol 3 titik di pojok kanan bawah gambar
                              alignment: Alignment.bottomRight,
                              child: IconButton(
                                icon: const Icon(Icons.more_vert, color: Colors.white, size: 18),
                                onPressed: () {
                                  // Munculkan Options Modal
                                },
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              track['title'] ?? 'Unknown',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                            Text(
                              track['artist'] ?? 'Unknown Artist',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),

        // Section Antrean Memutar (Queue)
        Container(
          margin: const EdgeInsets.all(15),
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: const Color(0xFF000712),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: const Color(0xFF001F3F)),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 15, offset: Offset(0, 4))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.only(bottom: 8),
                margin: const EdgeInsets.only(bottom: 15),
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFF002244)))),
                child: const Text('ANTREAN MEMUTAR (QUEUE)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF))),
              ),
              const Text('Antrean kosong.', style: TextStyle(color: Colors.grey, fontSize: 13)),
            ],
          ),
        ),
      ],
    );
  }
}
