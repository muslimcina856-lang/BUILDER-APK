import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart'; // Untuk navigasi ke MainNavigationScreen

class AuthScreen extends StatefulWidget {
  const AuthScreen({Key? key}) : super(key: key);

  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLoginMode = true;
  bool isLoading = false;
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Endpoint API Server Python Pterodactyl kamu
  final String apiUrl = "http://de3.bot-hosting.net:21013/api/auth";

  Future<void> submitAuth() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showToast("Username dan Password wajib diisi!", isError: true);
      return;
    }

    setState(() => isLoading = true);

    try {
      // POST ke server Python sesuai format yang diminta
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "action": isLoginMode ? "login" : "register",
          "username": username,
          "password": password,
          "version": "10.03-beta.1",
          "device_info": "Android App"
        }),
      );

      final data = jsonDecode(response.body);

      if (data['status'] == 'success') {
        // Simpan sesi ke penyimpanan HP
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('ytpro_user', username);
        await prefs.setString('ytpro_password', password);

        _showToast(data['message'] ?? "Berhasil!", isError: false);

        // Pindah ke halaman utama
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
          );
        }
      } else {
        _showToast(data['message'] ?? "Terjadi kesalahan!", isError: true);
      }
    } catch (e) {
      _showToast("Gagal terhubung ke server!", isError: true);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: isError ? const Color(0xFFFF003C) : const Color(0xFF1DB954),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.98),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: const Color(0xFF000A14),
              border: Border.all(color: const Color(0xFF00E5FF)),
              borderRadius: BorderRadius.circular(15),
              boxShadow: const [BoxShadow(color: Color(0x4D00E5FF), blurRadius: 30)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.security, color: Color(0xFF00E5FF), size: 50),
                const SizedBox(height: 15),
                Text(
                  isLoginMode ? 'LOGIN SISTEM' : 'DAFTAR AKUN',
                  style: const TextStyle(
                    color: Color(0xFF00E5FF),
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    shadows: [Shadow(color: Color(0xFF00E5FF), blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF001F3F),
                    border: Border.all(color: const Color(0xFF00E5FF), style: BorderStyle.solid), // Dashed border mimic
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "Informasi Sistem:\nAkses Login/Daftar ini berfungsi sebagai pencadangan. Data Koleksi & History tersimpan aman di server.",
                    style: TextStyle(color: Colors.grey, fontSize: 11, height: 1.5),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _usernameController,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Username',
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: const Color(0xFF000000),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: const BorderSide(color: Color(0xFF002244))),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: const BorderSide(color: Color(0xFF00E5FF))),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Password',
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: const Color(0xFF000000),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: const BorderSide(color: Color(0xFF002244))),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: const BorderSide(color: Color(0xFF00E5FF))),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: isLoading ? null : submitAuth,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00E5FF),
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                    shadowColor: const Color(0xFF00E5FF),
                    elevation: 10,
                  ),
                  child: isLoading 
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                    : Text(
                        isLoginMode ? 'MASUK SEKARANG' : 'DAFTAR SEKARANG',
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                ),
                const SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      isLoginMode ? 'Belum punya akses? ' : 'Sudah punya akses? ',
                      style: const TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                    GestureDetector(
                      onTap: () => setState(() => isLoginMode = !isLoginMode),
                      child: Text(
                        isLoginMode ? 'Daftar Disini' : 'Login Disini',
                        style: const TextStyle(color: Color(0xFFFF003C), fontSize: 12, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
