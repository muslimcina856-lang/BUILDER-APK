import 'package:flutter/material.dart';

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(top: 20, left: 15, right: 15, bottom: 130),
      child: Column(
        children: [
          // Banner Video Placeholder
          Container(
            width: double.infinity,
            height: 180,
            decoration: BoxDecoration(
              color: Colors.black,
              border: Border.all(color: const Color(0xFF00E5FF)),
              borderRadius: BorderRadius.circular(15),
              image: const DecorationImage(
                image: NetworkImage('https://images.unsplash.com/photo-1614149162883-504ce4d13909?q=80&w=500'), // Placeholder banner
                fit: BoxFit.cover,
              ),
            ),
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFF00E5FF))),
                child: const Text('Bisu', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ),
          ),

          const SizedBox(height: 15),

          // Info Panel (Device & API)
          Row(
            children: [
              Expanded(child: _buildInfoCard('DEVICE INFO', ['OS: Android 14', 'Net: Online (Stabil)', 'IP: Melacak...', 'CPU: 8 Cores', 'ROM: 64 GB / 128 GB'])),
              const SizedBox(width: 10),
              Expanded(child: _buildInfoCard('API STATUS', ['yt-dlp Core: ACTIVE', 'Sanka Anime: ACTIVE', 'TikWM API: ACTIVE', 'Server DB: CONNECTED'])),
            ],
          ),

          const SizedBox(height: 15),

          // Daftar Tools
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: const Color(0xFF000712),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: const Color(0xFF001F3F)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('DAFTAR TOOLS', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF))),
                const Divider(color: Color(0xFF002244), thickness: 1, height: 20),
                
                _buildToolCard('TikTok Downloader', 'Unduh video & foto tanpa WM', Icons.tiktok, const Color(0xFF00E5FF)),
                _buildToolCard('Instagram Downloader', 'Unduh Reels, IGTV & Foto', Icons.camera_alt, const Color(0xFFE1306C)),
                _buildToolCard('Wifi Killer', '⚠️ Gunakan Hanya Untuk Testing Pribadi', Icons.wifi_tethering_error, const Color(0xFF00FF00)),
                _buildToolCard('Image Upscaler (Beta)', 'Tingkatkan resolusi & kualitas foto', Icons.hd, const Color(0xFF00E5FF)),
                _buildToolCard('Anime Watcher', 'Jelajahi & Tonton Anime HD', Icons.play_circle_filled, const Color(0xFFFF9900)),
                _buildToolCard('IQC Generator (Beta)', 'Buat Fake Chat/Quotes iOS', Icons.chat_bubble, const Color(0xFFA200FF)),
                _buildToolCard('X-Tune Cinema', 'Streaming Film & TV Series', Icons.movie, const Color(0xFFE50914)),
              ],
            ),
          ),
          
          const SizedBox(height: 15),
          
          // Tombol Refresh Script
          OutlinedButton.icon(
            onPressed: () { /* Refresh tools script */ },
            icon: const Icon(Icons.refresh, color: Color(0xFF00E5FF), size: 16),
            label: const Text('REFRESH / UPDATE SCRIPT TOOLS', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 12, fontWeight: FontWeight.bold)),
            style: OutlinedButton.styleFrom(
              backgroundColor: const Color(0xFF000A14),
              side: const BorderSide(color: Color(0xFF00E5FF)),
              padding: const EdgeInsets.symmetric(vertical: 15),
              minimumSize: const Size(double.infinity, 45),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildInfoCard(String title, List<String> items) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: const Color(0xFF050505), border: Border.all(color: const Color(0xFF111111)), borderRadius: BorderRadius.circular(8)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.only(bottom: 5),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFF222222), style: BorderStyle.solid))),
            child: Text(title, style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
          ),
          ...items.map((e) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(e, style: const TextStyle(color: Colors.white, fontSize: 10)),
          )).toList(),
        ],
      ),
    );
  }

  Widget _buildToolCard(String title, String subtitle, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF000712), Colors.black]),
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 45, height: 45,
            decoration: BoxDecoration(
              color: Colors.black,
              border: Border.all(color: color),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: color, size: 24),
        ],
      ),
    );
  }
}
