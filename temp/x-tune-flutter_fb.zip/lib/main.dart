import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'auth_screen.dart'; // Import Halaman Login
import 'home_screen.dart'; 
import 'search_screen.dart'; 
import 'library_screen.dart'; 
import 'tools_screen.dart';   

void main() async {
  // Wajib dipanggil sebelum setImmersive atau SharedPreferences
  WidgetsFlutterBinding.ensureInitialized();
  
  // PERINTAH FULL SCREEN (Menyembunyikan status bar & tombol navigasi bawah)
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  // Cek apakah user sudah login sebelumnya
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? loggedUser = prefs.getString('ytpro_user');

  runApp(XTuneApp(isLoggedIn: loggedUser != null));
}

class XTuneApp extends StatelessWidget {
  final bool isLoggedIn;
  const XTuneApp({Key? key, required this.isLoggedIn}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'X-Tune',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000), 
        primaryColor: const Color(0xFFFF003C), 
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF003C),
          secondary: Color(0xFF00E5FF), 
          surface: Color(0xFF000712), 
        ),
        fontFamily: 'Segoe UI',
      ),
      // Jika sudah login, langsung ke menu utama, jika belum ke layar Auth
      home: isLoggedIn ? const MainNavigationScreen() : const AuthScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({Key? key}) : super(key: key);

  @override
  _MainNavigationScreenState createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const HomeScreen(),
    const SearchScreen(),
    const LibraryScreen(),
    const ToolsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Drawer (Sidebar) tetap ada dan bisa ditarik dari sisi kiri layar!
      drawer: SizedBox(
        width: MediaQuery.of(context).size.width * 0.7,
        child: Drawer(
          backgroundColor: Colors.transparent,
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF000712), Colors.black],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              border: Border(right: BorderSide(color: Color(0xFF00E5FF), width: 1)),
            ),
            child: ListView(
              padding: const EdgeInsets.only(top: 50),
              children: [
                Column(
                  children: [
                    Container(
                      width: 70, height: 70,
                      decoration: BoxDecoration(
                        color: const Color(0xFF002244),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF00E5FF), width: 2),
                        boxShadow: const [BoxShadow(color: Color(0xFF00E5FF), blurRadius: 15)],
                      ),
                      child: const Icon(Icons.settings_input_antenna, color: Color(0xFF00E5FF), size: 40),
                    ),
                    const SizedBox(height: 10),
                    const Text('X-Tune', style: TextStyle(color: Colors.white, fontSize: 16, letterSpacing: 1, shadows: [Shadow(color: Color(0xFF00E5FF), blurRadius: 5)])),
                    const Text('Version 10.03-beta.1', style: TextStyle(color: Colors.grey, fontSize: 10)),
                    
                    Container(
                      margin: const EdgeInsets.all(15),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF000A15),
                        border: Border.all(color: const Color(0xFF001F3F)),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          const Text('GUEST', style: TextStyle(color: Color(0xFFFF003C), fontSize: 14, fontWeight: FontWeight.bold)),
                          const Divider(color: Color(0xFF222222)),
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [Text('User ID:', style: TextStyle(color: Colors.grey, fontSize: 10)), Text('ID-12345', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))]),
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [Text('Login:', style: TextStyle(color: Colors.grey, fontSize: 10)), Text('Tersinkron', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))]),
                        ],
                      ),
                    ),
                  ],
                ),
                _buildSidebarBtn(Icons.color_lens, 'Setelan Tema & Audio'),
                _buildSidebarBtn(Icons.info, 'Informasi Aplikasi'),
                _buildSidebarBtn(Icons.developer_mode, 'Tentang Developer'),
                _buildSidebarBtn(Icons.terminal, 'System Terminal'),
                _buildSidebarBtn(Icons.logout, 'Logout Akun', isLogout: true, context: context),
              ],
            ),
          ),
        ),
      ),
      
      // HEADER SUDAH DIHAPUS SEPENUHNYA!
      // Karena pakai Immersive mode, tidak perlu SafeArea lagi agar 100% penuh.
      body: Stack(
        children: [_pages[_currentIndex]],
      ),

      // BOTTOM NAVIGATION DENGAN EFEK GLOW
      bottomNavigationBar: Container(
        height: 60,
        decoration: const BoxDecoration(
          color: Color(0xFF000712), 
          border: Border(top: BorderSide(color: Color(0xFF001F3F), width: 1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(0, Icons.home_filled, 'BERANDA'),
            _buildNavItem(1, Icons.search, 'SEARCH'),
            _buildNavItem(2, Icons.library_music, 'KOLEKSI'),
            _buildNavItem(3, Icons.build_circle, 'TOOLS'),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final isActive = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: MediaQuery.of(context).size.width / 4,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          transform: Matrix4.translationValues(0, isActive ? -3 : 0, 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 20, color: isActive ? const Color(0xFFFF003C) : const Color(0xFF555555), shadows: isActive ? const [Shadow(color: Color(0xFFFF003C), blurRadius: 5)] : null),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1, color: isActive ? const Color(0xFFFF003C) : const Color(0xFF555555), shadows: isActive ? const [Shadow(color: Color(0xFFFF003C), blurRadius: 8)] : null)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSidebarBtn(IconData icon, String title, {bool isLogout = false, BuildContext? context}) {
    return ListTile(
      leading: Icon(icon, color: isLogout ? const Color(0xFFFF003C) : const Color(0xFF00E5FF)),
      title: Text(title, style: TextStyle(color: isLogout ? const Color(0xFFFF003C) : Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
      shape: const Border(bottom: BorderSide(color: Color(0xFF001F3F))),
      onTap: () async {
        if (isLogout && context != null) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.clear(); // Hapus sesi
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen()));
        }
      },
    );
  }
}
