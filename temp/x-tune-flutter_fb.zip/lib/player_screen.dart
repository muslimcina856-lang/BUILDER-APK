import 'package:flutter/material.dart';

class PlayerScreen extends StatefulWidget {
  final VoidCallback onClose;

  const PlayerScreen({Key? key, required this.onClose}) : super(key: key);

  @override
  _PlayerScreenState createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> with SingleTickerProviderStateMixin {
  bool isPlayerTab = true; // true = UTAMA, false = LIRIK
  bool isPlaying = false;
  bool isShuffle = false;
  int repeatMode = 0; // 0 = Off, 1 = Repeat 1, 2 = Repeat All
  double progressValue = 0.0;
  
  // Mock Data
  String currentTitle = "Judul Lagu";
  String currentArtist = "Nama Artis";
  String currentTime = "0:00";
  String totalTime = "0:00";

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF000712), Color(0xFF000000)], // Sesuai --panel ke --bg
          ),
        ),
        padding: const EdgeInsets.only(top: 50, left: 25, right: 25, bottom: 25),
        child: Column(
          children: [
            // PANEL HEADER
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 30),
                  onPressed: widget.onClose,
                ),
                // PLAYER TABS (UTAMA & LIRIK)
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => setState(() => isPlayerTab = true),
                      child: Container(
                        padding: const EdgeInsets.only(bottom: 5),
                        decoration: BoxDecoration(
                          border: Border(bottom: BorderSide(color: isPlayerTab ? const Color(0xFFFF003C) : Colors.transparent, width: 2)),
                        ),
                        child: Text('UTAMA', style: TextStyle(color: isPlayerTab ? const Color(0xFFFF003C) : Colors.grey, fontWeight: FontWeight.bold, fontSize: 14)),
                      ),
                    ),
                    const SizedBox(width: 20),
                    GestureDetector(
                      onTap: () => setState(() => isPlayerTab = false),
                      child: Container(
                        padding: const EdgeInsets.only(bottom: 5),
                        decoration: BoxDecoration(
                          border: Border(bottom: BorderSide(color: !isPlayerTab ? const Color(0xFFFF003C) : Colors.transparent, width: 2)),
                        ),
                        child: Text('LIRIK', style: TextStyle(color: !isPlayerTab ? const Color(0xFFFF003C) : Colors.grey, fontWeight: FontWeight.bold, fontSize: 14)),
                      ),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.more_vert, color: Colors.white),
                  onPressed: () { /* Buka Bottom Sheet Opsi Lagu */ },
                ),
              ],
            ),

            const SizedBox(height: 20),

            // KONTEN BERDASARKAN TAB
            Expanded(
              child: isPlayerTab ? _buildPlayerTab() : _buildLyricsTab(),
            ),
          ],
        ),
      ),
    );
  }

  // ==========================================
  // TAB UTAMA (PEMUTAR MUSIK)
  // ==========================================
  Widget _buildPlayerTab() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // COVER ALBUM
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: 250,
          height: 250,
          margin: const EdgeInsets.only(top: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: const Color(0xFF050000),
            border: Border.all(color: const Color(0xFF330011)),
            boxShadow: isPlaying 
                ? [const BoxShadow(color: Color(0x4DFF003C), blurRadius: 40, spreadRadius: 5, offset: Offset(0, 15))]
                : [const BoxShadow(color: Colors.black87, blurRadius: 35, offset: Offset(0, 15))],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: const Icon(Icons.music_note, size: 100, color: Color(0xFF222222)), // Placeholder cover
          ),
        ),

        // MINI LYRICS PREVIEW (Gradient Masking)
        GestureDetector(
          onTap: () => setState(() => isPlayerTab = false),
          child: Container(
            height: 100,
            alignment: Alignment.center,
            child: const Text(
              "Lirik memuat...",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                shadows: [Shadow(color: Color(0xFFFF003C), blurRadius: 10)],
              ),
            ),
          ),
        ),

        // TRACK DETAILS
        Column(
          children: [
            Text(
              currentTitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 5),
            Text(
              currentArtist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFFFF003C), letterSpacing: 0.5),
            ),
          ],
        ),

        const SizedBox(height: 10),

        // PROGRESS BAR
        Row(
          children: [
            Text(currentTime, style: const TextStyle(fontSize: 11, color: Colors.grey)),
            const SizedBox(width: 10),
            Expanded(
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: const Color(0xFFFF003C),
                  inactiveTrackColor: const Color(0xFF222222),
                  thumbColor: const Color(0xFFFF003C),
                  trackHeight: 4.0,
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7.0),
                ),
                child: Slider(
                  value: progressValue,
                  max: 100,
                  onChanged: (val) {
                    setState(() => progressValue = val);
                  },
                ),
              ),
            ),
            const SizedBox(width: 10),
            Text(totalTime, style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),

        // KONTROL AUDIO UTAMA
        Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: Icon(Icons.shuffle, color: isShuffle ? const Color(0xFF1DB954) : Colors.white),
                onPressed: () => setState(() => isShuffle = !isShuffle),
              ),
              IconButton(
                icon: const Icon(Icons.skip_previous, color: Colors.white, size: 36),
                onPressed: () { /* Logic Prev */ },
              ),
              GestureDetector(
                onTap: () => setState(() => isPlaying = !isPlaying),
                child: Container(
                  width: 60, height: 60,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Color(0x33FFFFFF), blurRadius: 15, offset: Offset(0, 4))],
                  ),
                  child: Icon(isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.black, size: 36),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.skip_next, color: Colors.white, size: 36),
                onPressed: () { /* Logic Next */ },
              ),
              IconButton(
                icon: Icon(
                  repeatMode == 1 ? Icons.repeat_one : Icons.repeat,
                  color: repeatMode > 0 ? const Color(0xFF1DB954) : Colors.white,
                ),
                onPressed: () => setState(() => repeatMode = (repeatMode + 1) % 3),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==========================================
  // TAB LIRIK (KARAOKE SINKRONISASI)
  // ==========================================
  Widget _buildLyricsTab() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: const Color(0xFF222222)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header Lirik (Indikator & Translate)
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Text('LIRIK DECRYPTED', style: TextStyle(color: Color(0xFFFF003C), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0x1A00E5FF),
                        border: Border.all(color: const Color(0xFF00E5FF)),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text('SYNC', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 8, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    border: Border.all(color: const Color(0xFF00E5FF)),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text('Original ▼', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 11)),
                )
              ],
            ),
          ),
          
          // Teks Lirik Scrollable
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLyricLine("Ini adalah contoh baris lirik pertama", false),
                  _buildLyricLine("Baris ini sedang aktif dinyanyikan", true), // Baris aktif
                  _buildLyricLine("Lirik akan bergulir otomatis...", false),
                  _buildLyricLine("Sesuai dengan timestamp dari server", false),
                  const SizedBox(height: 200), // Padding bawah agar bisa scroll lega
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildLyricLine(String text, bool isActive) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: AnimatedDefaultTextStyle(
        duration: const Duration(milliseconds: 300),
        style: TextStyle(
          fontSize: isActive ? 18 : 15,
          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          color: isActive ? Colors.white : Colors.white38,
          shadows: isActive ? [const Shadow(color: Color(0xFFFF003C), blurRadius: 15)] : [],
        ),
        child: Text(text),
      ),
    );
  }
}
