import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ToolsLogic {
  static const String localPythonUrl = 'http://127.0.0.1:21013';
  static const String pterodactylUrl = 'http://de3.bot-hosting.net:21013';
  static const String watchmodeApiKey = '905ANXbz9Af3LrPnTnjvGBLKfhs5azVatXPODtyF';

  // =========================================================================
  // 1. TIKTOK DOWNLOADER (NO WATERMARK)
  // =========================================================================
  static Future<Map<String, dynamic>> processTikTok(String url) async {
    final apiUrl = Uri.parse('https://www.tikwm.com/api/');
    try {
      final response = await http.post(apiUrl, body: {'url': url});
      final data = jsonDecode(response.body);
      if (data['code'] == 0 && data['data'] != null) {
        return {'status': 'success', 'data': data['data']};
      }
      return {'status': 'error', 'message': 'Gagal memproses post TikTok.'};
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke server (Cek koneksi internet)'};
    }
  }

  // =========================================================================
  // 2. INSTAGRAM DOWNLOADER (VIA LOCAL PYTHON BACKEND)
  // =========================================================================
  static Future<Map<String, dynamic>> processInstagram(String url) async {
    final apiUrl = Uri.parse('$localPythonUrl/import_ig');
    try {
      final response = await http.post(apiUrl, body: {'url': url});
      final data = jsonDecode(response.body);
      if (data['status'] == 'success' && data['media'] != null) {
        return {'status': 'success', 'media': data['media']};
      }
      return {'status': 'error', 'message': data['message'] ?? 'Media tidak ditemukan/Akun privat.'};
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke backend Python.'};
    }
  }

  // =========================================================================
  // 3. ANIME WATCHER (SANKA VOLLEREI API)
  // =========================================================================
  static Future<Map<String, dynamic>> getAnimeHome() async {
    final url = Uri.parse('https://www.sankavollerei.web.id/anime/home');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal memuat API Sanka Vollerei.'};
    }
  }

  static Future<Map<String, dynamic>> searchAnime(String query) async {
    final url = Uri.parse('https://www.sankavollerei.web.id/anime/search?query=${Uri.encodeComponent(query)}');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'API tidak merespons.'};
    }
  }

  static Future<Map<String, dynamic>> getAnimeDetails(String animeId) async {
    final url = Uri.parse('https://www.sankavollerei.web.id/anime/anime/$animeId');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Error koneksi ke API Sanka.'};
    }
  }

  static Future<Map<String, dynamic>> getAnimeEpisodeServers(String epsId) async {
    final url = Uri.parse('https://www.sankavollerei.web.id/anime/episode/$epsId');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Error jaringan/API saat memuat server.'};
    }
  }

  // =========================================================================
  // 4. MOVIE WATCHER (WATCHMODE API)
  // =========================================================================
  static Future<Map<String, dynamic>> searchMovie(String query) async {
    final url = Uri.parse('https://api.watchmode.com/v1/search/?apiKey=$watchmodeApiKey&search_field=name&search_value=${Uri.encodeComponent(query)}');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke Watchmode API.'};
    }
  }

  static Future<List<dynamic>> getMovieSources(String movieId) async {
    final url = Uri.parse('https://api.watchmode.com/v1/title/$movieId/sources/?apiKey=$watchmodeApiKey');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return [];
    }
  }

  // =========================================================================
  // 5. INTERNET UPPING (UDP SPEED TEST)
  // =========================================================================
  static Future<bool> startUpping() async {
    final url = Uri.parse('$localPythonUrl/start_upping');
    try {
      final response = await http.post(url);
      final data = jsonDecode(response.body);
      return data['status'] == 'success';
    } catch (e) {
      return false;
    }
  }

  static Future<bool> stopUpping() async {
    final url = Uri.parse('$localPythonUrl/stop_upping');
    try {
      await http.post(url);
      return true;
    } catch (e) {
      return false;
    }
  }

  static Future<double> getUppingStatus() async {
    final url = Uri.parse('$localPythonUrl/status_upping');
    try {
      final response = await http.get(url);
      final data = jsonDecode(response.body);
      return (data['speed_mbps'] ?? 0.0).toDouble();
    } catch (e) {
      return 0.0;
    }
  }

  // =========================================================================
  // 6. ADMIN PANEL SYSTEM (REALTIME DATABASE)
  // =========================================================================
  static Future<Map<String, dynamic>> fetchAdminUsers(String username, String password) async {
    final url = Uri.parse('$pterodactylUrl/api/admin/users');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': password}),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke API Server'};
    }
  }

  static Future<Map<String, dynamic>> changeUserRole(String adminUser, String adminPass, String targetUser, String newRole) async {
    final url = Uri.parse('$pterodactylUrl/api/admin/change_role');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'admin_user': adminUser,
          'admin_pass': adminPass,
          'target_user': targetUser,
          'new_role': newRole,
        }),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Server error saat mengubah role'};
    }
  }

  // =========================================================================
  // 7. PROFILE UPDATE FIX
  // =========================================================================
  static Future<Map<String, dynamic>> updateProfile(String username, String oldPass, String newPass, String avatarBase64) async {
    final url = Uri.parse('$pterodactylUrl/api/update_profile');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'password': oldPass,
          'new_password': newPass,
          'avatar_b64': avatarBase64,
        }),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke server'};
    }
  }
  
  // =========================================================================
  // 8. NATIVE DOWNLOADER TRIGGER
  // =========================================================================
  static Future<Map<String, dynamic>> triggerNativeDownload(String downloadUrl, String title, String ext, String taskKey) async {
    final url = Uri.parse('$localPythonUrl/start_download_tiktok');
    try {
      final response = await http.post(
        url,
        body: {
          'download_url': downloadUrl,
          'title': title,
          'ext': ext,
          'task_key': taskKey,
        },
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Fallback native downloader dipicu'};
    }
  }
}
