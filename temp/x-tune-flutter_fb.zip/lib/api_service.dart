import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Sesuai dengan konfigurasi di index.html Anda
  static const String localPythonUrl = 'http://127.0.0.1:21013';
  static const String pterodactylUrl = 'http://de3.bot-hosting.net:21013';
  static const String appVersion = '10.03-beta.1';

  // ==========================================
  // FUNGSI AUTHENTIKASI & SINKRONISASI PANEL
  // ==========================================
  static Future<Map<String, dynamic>> doAuth(String action, String username, String password) async {
    final url = Uri.parse('$pterodactylUrl/api/auth');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'action': action, // 'login' atau 'register'
          'username': username,
          'password': password,
          'version': appVersion,
        }),
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke server!'};
    }
  }

  static Future<Map<String, dynamic>> forceSync(String username) async {
    final url = Uri.parse('$pterodactylUrl/api/sync?username=${Uri.encodeComponent(username)}');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Koneksi ke server gagal.'};
    }
  }

  // ==========================================
  // FUNGSI PENCARIAN & BERANDA (PYTHON LOKAL)
  // ==========================================
  static Future<List<dynamic>> searchLagu(String query) async {
    final url = Uri.parse('$localPythonUrl/search');
    try {
      final response = await http.post(
        url,
        body: {'query': query},
      );
      return jsonDecode(response.body);
    } catch (e) {
      return [];
    }
  }

  static Future<List<dynamic>> getSuggestions(String query) async {
    final url = Uri.parse('$localPythonUrl/suggest');
    try {
      final response = await http.post(
        url,
        body: {'query': query},
      );
      return jsonDecode(response.body);
    } catch (e) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> getStreamUrl(String videoId, String quality) async {
    final url = Uri.parse('$localPythonUrl/stream_url/$videoId?quality=$quality');
    try {
      final response = await http.get(url);
      return jsonDecode(response.body);
    } catch (e) {
      return {'error': e.toString()};
    }
  }

  // ==========================================
  // FUNGSI TANYA AI & TOOLS LAINNYA
  // ==========================================
  static Future<Map<String, dynamic>> tanyaAi(String query) async {
    final url = Uri.parse('$localPythonUrl/tanya_ai');
    try {
      final response = await http.post(
        url,
        body: {'query': query},
      );
      return jsonDecode(response.body);
    } catch (e) {
      return {'status': 'error', 'message': 'Gagal terhubung ke server AI lokal.'};
    }
  }
}
