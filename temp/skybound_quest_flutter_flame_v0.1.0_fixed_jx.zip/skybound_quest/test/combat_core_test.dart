import 'package:flutter_test/flutter_test.dart';
import 'package:skybound_quest/game/combat/combat_actor_state.dart';
import 'package:skybound_quest/game/combat/combat_models.dart';
import 'package:skybound_quest/game/combat/combat_resolver.dart';
import 'package:skybound_quest/game/combat/health_pool.dart';
import 'package:skybound_quest/game/combat/skill_controller.dart';
import 'package:skybound_quest/game/data/actor_catalog.dart';

void main() {
  group('HealthPool', () {
    test('shield, i-frame, clamp dan death event menggunakan laluan sama', () {
      final health = HealthPool(100)..addShield(15);
      final first = health.applyDamage(25, invulnerabilityAfterHit: 0.2);
      expect(first.absorbedByShield, 15);
      expect(first.healthDamage, 10);
      expect(health.current, 90);
      expect(health.applyDamage(30).blockedByInvulnerability, isTrue);
      health.update(0.21);
      expect(health.applyDamage(200).killed, isTrue);
      expect(health.current, 0);
      expect(health.applyDamage(10).killed, isFalse);
    });
  });

  group('Katalog actor', () {
    test('setiap hero dan mob mempunyai skill serangan sah', () {
      expect(ActorCatalog.all, hasLength(10));
      for (final actor in ActorCatalog.all) {
        expect(actor.skills, isNotEmpty, reason: actor.id);
        expect(
          actor.skills.every(
            (skill) =>
                skill.hit.baseDamage + actor.stats.attackPower * skill.hit.attackScaling > 0,
          ),
          isTrue,
          reason: actor.id,
        );
      }
      expect(ActorCatalog.validate, returnsNormally);
    });
  });

  group('CombatResolver', () {
    test('hero dan mob melalui formula damage yang sama', () {
      const resolver = CombatResolver();
      final hero = CombatActorState(ActorCatalog.nova);
      final mob = CombatActorState(ActorCatalog.mimicCube);
      final heroHit = resolver.resolve(
        attacker: hero,
        target: mob,
        hit: ActorCatalog.nova.skills.first.hit,
      );
      mob.health.update(1);
      final mobHit = resolver.resolve(
        attacker: mob,
        target: hero,
        hit: ActorCatalog.mimicCube.skills.first.hit,
      );
      expect(heroHit.landed, isTrue);
      expect(mobHit.landed, isTrue);
      expect(hero.health.current, lessThan(hero.health.maximum));
      expect(mob.health.current, lessThan(mob.health.maximum));
    });

    test('friendly fire ditolak', () {
      const resolver = CombatResolver();
      final nova = CombatActorState(ActorCatalog.nova);
      final aegis = CombatActorState(ActorCatalog.aegis);
      final result = resolver.resolve(
        attacker: nova,
        target: aegis,
        hit: ActorCatalog.nova.skills.first.hit,
      );
      expect(result.rejection, DamageRejection.sameFaction);
      expect(aegis.health.current, aegis.health.maximum);
    });

    test('true damage mengabaikan defense dan resistance', () {
      const resolver = CombatResolver();
      final nova = CombatActorState(ActorCatalog.nova);
      final boss = CombatActorState(ActorCatalog.monitorGolem);
      final result = resolver.resolve(
        attacker: nova,
        target: boss,
        hit: const HitDefinition(
          baseDamage: 30,
          attackScaling: 0,
          damageType: DamageType.trueDamage,
        ),
      );
      expect(result.application.healthDamage, 30);
    });
  });

  group('SkillController', () {
    test('windup membuka satu damage window dan cooldown menghalang spam', () {
      final skill = ActorCatalog.nova.skills.first;
      final controller = SkillController([skill]);
      expect(
        controller
            .tryActivate(skill.id, availableResource: 100, actionPrevented: false)
            .accepted,
        isTrue,
      );
      expect(
        controller
            .tryActivate(skill.id, availableResource: 100, actionPrevented: false)
            .accepted,
        isFalse,
      );
      final events = controller.update(skill.windup + 0.001);
      expect(
        events.where((event) => event.type == SkillEventType.attackWindowOpened),
        hasLength(1),
      );
    });
  });
}

