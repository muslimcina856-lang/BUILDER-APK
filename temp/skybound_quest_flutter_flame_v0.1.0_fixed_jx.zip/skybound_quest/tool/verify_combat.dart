import '../lib/game/combat/combat_actor_state.dart';
import '../lib/game/combat/combat_models.dart';
import '../lib/game/combat/combat_resolver.dart';
import '../lib/game/combat/health_pool.dart';
import '../lib/game/combat/skill_controller.dart';
import '../lib/game/data/actor_catalog.dart';

void check(bool condition, String message) {
  if (!condition) throw StateError(message);
}

void main() {
  ActorCatalog.validate();
  check(ActorCatalog.all.length == 10, 'Katalog mesti mempunyai 10 actor.');
  check(
    ActorCatalog.all.every((actor) => actor.skills.isNotEmpty),
    'Semua actor wajib mempunyai skill.',
  );

  final pool = HealthPool(100);
  pool.addShield(20);
  final shieldHit = pool.applyDamage(30, invulnerabilityAfterHit: 0.3);
  check(shieldHit.absorbedByShield == 20, 'Shield mesti menyerap dahulu.');
  check(shieldHit.healthDamage == 10, 'Baki damage mesti masuk ke HP.');
  check(pool.current == 90, 'HP selepas shield tidak tepat.');
  final blocked = pool.applyDamage(20);
  check(blocked.blockedByInvulnerability, 'I-frame mesti menyekat hit kedua.');
  pool.update(0.31);
  pool.applyDamage(500);
  check(pool.isDead && pool.current == 0, 'HP mesti clamp pada sifar.');

  final attacker = CombatActorState(ActorCatalog.nova);
  final target = CombatActorState(ActorCatalog.mimicCube);
  const resolver = CombatResolver();
  final hit = resolver.resolve(
    attacker: attacker,
    target: target,
    hit: ActorCatalog.nova.skills.first.hit,
    criticalRoll: 1,
  );
  check(hit.landed, 'Serangan hero patut mengenai mob.');
  check(target.health.current < target.health.maximum, 'Mob mesti kehilangan HP.');

  final friendly = CombatActorState(ActorCatalog.aegis);
  final friendlyResult = resolver.resolve(
    attacker: attacker,
    target: friendly,
    hit: ActorCatalog.nova.skills.first.hit,
  );
  check(
    friendlyResult.rejection == DamageRejection.sameFaction,
    'Friendly fire mesti ditolak.',
  );

  final pyra = CombatActorState(ActorCatalog.pyra);
  final burnTarget = CombatActorState(ActorCatalog.mimicCube);
  resolver.resolve(
    attacker: pyra,
    target: burnTarget,
    hit: ActorCatalog.pyra.skills.first.hit,
  );
  burnTarget.health.update(1);
  final beforeBurn = burnTarget.health.current;
  burnTarget.update(1.01);
  check(burnTarget.health.current < beforeBurn, 'Burning mesti memberi periodic damage.');

  final skill = ActorCatalog.nova.skills.first;
  final controller = SkillController([skill]);
  final activation = controller.tryActivate(
    skill.id,
    availableResource: 100,
    actionPrevented: false,
  );
  check(activation.accepted, 'Skill mesti boleh diaktifkan.');
  final castEvents = controller.update(skill.windup + 0.001);
  check(
    castEvents.any((event) => event.type == SkillEventType.attackWindowOpened),
    'Damage window mesti dibuka selepas windup.',
  );

  final expensive = ActorCatalog.pyra.skills.last;
  final poorController = SkillController([expensive]);
  final rejected = poorController.tryActivate(
    expensive.id,
    availableResource: 0,
    actionPrevented: false,
  );
  check(!rejected.accepted, 'Skill tanpa resource mesti ditolak.');

  final trueDamageTarget = CombatActorState(ActorCatalog.monitorGolem);
  final trueDamage = resolver.resolve(
    attacker: attacker,
    target: trueDamageTarget,
    hit: const HitDefinition(
      baseDamage: 25,
      attackScaling: 0,
      damageType: DamageType.trueDamage,
    ),
  );
  check(
    trueDamage.application.healthDamage == 25,
    'True damage mesti mengabaikan defense.',
  );

  print('Combat verification passed: 10 actors, shared HP, skills, statuses, cooldowns.');
}

