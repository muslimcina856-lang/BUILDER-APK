#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK tidak dijumpai. Pasang Flutter 3.41 atau lebih baharu dahulu." >&2
  exit 1
fi

flutter create --platforms=android --org com.earlxz .
flutter pub get
flutter test

echo "Android project sedia. Jalankan: flutter run"

