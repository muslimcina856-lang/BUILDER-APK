import 'package:flutter/material.dart';

import '../game/combat/health_pool.dart';
import '../game/skybound_game.dart';

class CombatHud extends StatelessWidget {
  const CombatHud({super.key, required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          Positioned(left: 18, top: 14, child: _Vitals(game: game)),
          Positioned(
            left: 20,
            bottom: 18,
            child: Row(
              children: [
                _TouchButton(
                  label: '←',
                  asset: 'assets/images/controls/direction_left.png',
                  onDown: () => game.input.setLeft(true),
                  onUp: () => game.input.setLeft(false),
                ),
                const SizedBox(width: 12),
                _TouchButton(
                  label: '→',
                  asset: 'assets/images/controls/direction_right.png',
                  onDown: () => game.input.setRight(true),
                  onUp: () => game.input.setRight(false),
                ),
              ],
            ),
          ),
          Positioned(
            right: 22,
            bottom: 18,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _TouchButton(
                  label: 'S',
                  size: 68,
                  color: const Color(0xFF8E5AE8),
                  asset: 'assets/images/controls/button_diamond.png',
                  onDown: game.input.queueSecondary,
                ),
                const SizedBox(width: 14),
                _TouchButton(
                  label: 'A',
                  size: 76,
                  color: const Color(0xFFE45151),
                  asset: 'assets/images/controls/button_circle.png',
                  onDown: game.input.queuePrimary,
                ),
                const SizedBox(width: 14),
                _TouchButton(
                  label: '↑',
                  size: 88,
                  color: const Color(0xFF4BAAE8),
                  asset: 'assets/images/controls/button_circle.png',
                  onDown: () => game.input.setJump(true),
                  onUp: () => game.input.setJump(false),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Vitals extends StatelessWidget {
  const _Vitals({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xCC121A2D),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            game.selectedAvatarId.toUpperCase(),
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          ValueListenableBuilder<HealthSnapshot>(
            valueListenable: game.heroHealth,
            builder: (context, health, _) => _Meter(
              value: health.ratio,
              color: const Color(0xFFEF5350),
              label: 'HP ${health.current.ceil()} / ${health.maximum.ceil()}',
            ),
          ),
          const SizedBox(height: 5),
          ValueListenableBuilder<double>(
            valueListenable: game.heroResource,
            builder: (context, resource, _) => _Meter(
              value: resource,
              color: const Color(0xFF42A5F5),
              label: 'TENAGA ${(resource * 100).ceil()}%',
            ),
          ),
        ],
      ),
    );
  }
}

class _Meter extends StatelessWidget {
  const _Meter({required this.value, required this.color, required this.label});

  final double value;
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: LinearProgressIndicator(
            value: value.clamp(0, 1).toDouble(),
            minHeight: 16,
            color: color,
            backgroundColor: Colors.black45,
          ),
        ),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 10)),
      ],
    );
  }
}

class _TouchButton extends StatelessWidget {
  const _TouchButton({
    required this.label,
    required this.asset,
    required this.onDown,
    this.onUp,
    this.size = 72,
    this.color = const Color(0xFF66A36F),
  });

  final String label;
  final String asset;
  final VoidCallback onDown;
  final VoidCallback? onUp;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => onDown(),
      onPointerUp: (_) => onUp?.call(),
      onPointerCancel: (_) => onUp?.call(),
      child: SizedBox.square(
        dimension: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Opacity(
              opacity: 0.72,
              child: Image.asset(asset, width: size, height: size, color: color),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: size * 0.34,
                fontWeight: FontWeight.w900,
                shadows: const [Shadow(color: Colors.black, blurRadius: 4)],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
