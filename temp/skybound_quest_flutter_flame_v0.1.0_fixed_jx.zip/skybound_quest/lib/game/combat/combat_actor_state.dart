import 'combat_models.dart';
import 'health_pool.dart';
import 'skill_controller.dart';
import 'status_controller.dart';

class ActorFrameUpdate {
  const ActorFrameUpdate({
    required this.skillEvents,
    required this.periodicDamage,
  });

  final List<SkillEvent> skillEvents;
  final List<PeriodicDamageEvent> periodicDamage;
}

class CombatActorState {
  CombatActorState(this.blueprint)
      : health = HealthPool(blueprint.stats.maxHealth),
        skills = SkillController(blueprint.skills),
        resource = blueprint.stats.maxResource,
        poise = blueprint.stats.maxPoise;

  final ActorBlueprint blueprint;
  final HealthPool health;
  final SkillController skills;
  final StatusController statuses = StatusController();
  double resource;
  double poise;

  bool get isDead => health.isDead;
  bool get canAct => !isDead && !statuses.preventsAction;
  double get effectiveMoveSpeed =>
      blueprint.stats.moveSpeed * statuses.moveSpeedMultiplier;

  SkillActivationResult tryUseSkill(String skillId) {
    final result = skills.tryActivate(
      skillId,
      availableResource: resource,
      actionPrevented: !canAct,
    );
    if (result.accepted) {
      resource = (resource - result.skill!.resourceCost)
          .clamp(0, double.infinity)
          .toDouble();
      if (result.skill!.selfInvulnerability > 0) {
        health.grantInvulnerability(result.skill!.selfInvulnerability);
      }
    }
    return result;
  }

  ActorFrameUpdate update(double dt) {
    health.update(dt);
    if (!isDead) {
      resource = (resource + blueprint.stats.resourceRegenPerSecond * dt)
          .clamp(0, blueprint.stats.maxResource)
          .toDouble();
      poise = (poise + blueprint.stats.maxPoise * 0.18 * dt)
          .clamp(0, blueprint.stats.maxPoise)
          .toDouble();
    }
    final periodic = statuses.update(dt);
    for (final event in periodic) {
      final resistance = blueprint.stats.resistanceFor(event.damageType);
      final finalDamage = event.amount * (1 - resistance);
      health.applyDamage(finalDamage, bypassInvulnerability: true);
    }
    final skillEvents = isDead ? const <SkillEvent>[] : skills.update(dt);
    return ActorFrameUpdate(skillEvents: skillEvents, periodicDamage: periodic);
  }

  bool applyPoiseDamage(double amount) {
    if (amount <= 0 || isDead) return false;
    poise = (poise - amount).clamp(0, blueprint.stats.maxPoise).toDouble();
    if (poise > 0) return false;
    poise = blueprint.stats.maxPoise;
    skills.interrupt();
    return true;
  }

  void reset() {
    health.revive();
    statuses.clear();
    skills.reset();
    resource = blueprint.stats.maxResource;
    poise = blueprint.stats.maxPoise;
  }
}
