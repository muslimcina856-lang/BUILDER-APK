typedef HealthListener = void Function(HealthSnapshot snapshot);

class HealthSnapshot {
  const HealthSnapshot({
    required this.current,
    required this.maximum,
    required this.shield,
    required this.isDead,
  });

  final double current;
  final double maximum;
  final double shield;
  final bool isDead;

  double get ratio =>
      maximum == 0 ? 0.0 : (current / maximum).clamp(0, 1).toDouble();
}

class DamageApplication {
  const DamageApplication({
    required this.requested,
    required this.absorbedByShield,
    required this.healthDamage,
    required this.blockedByInvulnerability,
    required this.killed,
  });

  final double requested;
  final double absorbedByShield;
  final double healthDamage;
  final bool blockedByInvulnerability;
  final bool killed;

  double get totalApplied => absorbedByShield + healthDamage;
}

class HealthPool {
  HealthPool(double maximum)
      : _maximum = maximum,
        _current = maximum {
    if (maximum <= 0) {
      throw ArgumentError.value(maximum, 'maximum');
    }
  }

  double _maximum;
  double _current;
  double _shield = 0;
  double _invulnerableFor = 0;
  bool _deathNotified = false;
  final List<HealthListener> _listeners = [];

  double get maximum => _maximum;
  double get current => _current;
  double get shield => _shield;
  double get ratio => (_current / _maximum).clamp(0, 1).toDouble();
  double get invulnerableFor => _invulnerableFor;
  bool get isInvulnerable => _invulnerableFor > 0;
  bool get isDead => _current <= 0;
  HealthSnapshot get snapshot => HealthSnapshot(
        current: _current,
        maximum: _maximum,
        shield: _shield,
        isDead: isDead,
      );

  void addListener(HealthListener listener) => _listeners.add(listener);
  void removeListener(HealthListener listener) => _listeners.remove(listener);

  void update(double dt) {
    if (dt < 0) throw ArgumentError.value(dt, 'dt');
    _invulnerableFor =
        (_invulnerableFor - dt).clamp(0, double.infinity).toDouble();
  }

  void grantInvulnerability(double seconds) {
    if (seconds < 0) throw ArgumentError.value(seconds, 'seconds');
    if (seconds > _invulnerableFor) _invulnerableFor = seconds;
  }

  void addShield(double amount, {double? cap}) {
    if (amount <= 0 || isDead) return;
    final maximumShield = cap ?? double.infinity;
    _shield = (_shield + amount).clamp(0, maximumShield).toDouble();
    _notify();
  }

  DamageApplication applyDamage(
    double amount, {
    bool bypassInvulnerability = false,
    double invulnerabilityAfterHit = 0,
  }) {
    final requested = amount.clamp(0, double.infinity).toDouble();
    if (requested == 0 || isDead) {
      return DamageApplication(
        requested: requested,
        absorbedByShield: 0,
        healthDamage: 0,
        blockedByInvulnerability: false,
        killed: false,
      );
    }
    if (isInvulnerable && !bypassInvulnerability) {
      return DamageApplication(
        requested: requested,
        absorbedByShield: 0,
        healthDamage: 0,
        blockedByInvulnerability: true,
        killed: false,
      );
    }

    final absorbed = requested.clamp(0, _shield).toDouble();
    _shield -= absorbed;
    final remaining = requested - absorbed;
    final before = _current;
    _current = (_current - remaining).clamp(0, _maximum).toDouble();
    final healthDamage = before - _current;
    if (healthDamage > 0 && invulnerabilityAfterHit > 0) {
      grantInvulnerability(invulnerabilityAfterHit);
    }

    final killedNow = isDead && !_deathNotified;
    if (killedNow) _deathNotified = true;
    _notify();
    return DamageApplication(
      requested: requested,
      absorbedByShield: absorbed,
      healthDamage: healthDamage,
      blockedByInvulnerability: false,
      killed: killedNow,
    );
  }

  double heal(double amount) {
    if (amount <= 0 || isDead) return 0;
    final before = _current;
    _current = (_current + amount).clamp(0, _maximum).toDouble();
    final restored = _current - before;
    if (restored > 0) _notify();
    return restored;
  }

  void revive({double healthRatio = 1}) {
    if (healthRatio <= 0 || healthRatio > 1) {
      throw ArgumentError.value(healthRatio, 'healthRatio');
    }
    _current = _maximum * healthRatio;
    _shield = 0;
    _invulnerableFor = 0;
    _deathNotified = false;
    _notify();
  }

  void setMaximum(double value, {bool preserveRatio = true}) {
    if (value <= 0) throw ArgumentError.value(value, 'value');
    final oldRatio = ratio;
    _maximum = value;
    _current = preserveRatio
        ? value * oldRatio
        : _current.clamp(0, value).toDouble();
    _notify();
  }

  void _notify() {
    final value = snapshot;
    for (final listener in List<HealthListener>.of(_listeners)) {
      listener(value);
    }
  }
}
