import 'dart:math';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';

import 'combat/combat_resolver.dart';
import 'combat/health_pool.dart';
import 'components/arena_stage.dart';
import 'components/combat_actor_component.dart';
import 'components/hero_component.dart';
import 'components/mob_component.dart';
import 'data/actor_catalog.dart';
import 'input/player_input.dart';

class SkyboundGame extends FlameGame {
  SkyboundGame({this.selectedAvatarId = 'nova'});

  final String selectedAvatarId;
  final PlayerInput input = PlayerInput();
  final CombatResolver combatResolver = const CombatResolver();
  final Random random = Random();
  final ValueNotifier<HealthSnapshot> heroHealth = ValueNotifier(
    const HealthSnapshot(current: 1, maximum: 1, shield: 0, isDead: false),
  );
  final ValueNotifier<double> heroResource = ValueNotifier(1);
  final List<CombatActorComponent> combatants = [];

  late final ArenaStage stage;
  HeroComponent? _hero;
  HeroComponent get hero => _hero!;
  HeroComponent? get heroOrNull => _hero;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    ActorCatalog.validate();
    stage = ArenaStage();
    world.add(stage);

    final avatar = ActorCatalog.byId(selectedAvatarId);
    _hero = HeroComponent(
      gameRef: this,
      blueprint: avatar,
      position: Vector2(120, 280),
    );
    register(hero);

    final spawns = [
      (ActorCatalog.mimicCube, Vector2(410, 300)),
      (ActorCatalog.emberWisp, Vector2(610, 165)),
      (ActorCatalog.scoutDrone, Vector2(835, 95)),
      (ActorCatalog.drillSpike, Vector2(1290, 300)),
      (ActorCatalog.guardBot, Vector2(1590, 205)),
      (ActorCatalog.monitorGolem, Vector2(2360, 280)),
    ];
    for (final spawn in spawns) {
      register(
        MobComponent(
          gameRef: this,
          blueprint: spawn.$1,
          position: spawn.$2,
        ),
      );
    }
    camera.follow(hero);
    camera.viewfinder.zoom = 1.6;
    publishHeroVitals();
  }

  void register(CombatActorComponent actor) {
    combatants.add(actor);
    world.add(actor);
  }

  void publishHeroVitals() {
    final value = _hero;
    if (value == null) return;
    heroHealth.value = value.state.health.snapshot;
    heroResource.value = value.state.blueprint.stats.maxResource == 0
        ? 0
        : value.state.resource / value.state.blueprint.stats.maxResource;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_hero != null) publishHeroVitals();
  }

  @override
  void onRemove() {
    input.releaseAll();
    heroHealth.dispose();
    heroResource.dispose();
    super.onRemove();
  }
}

