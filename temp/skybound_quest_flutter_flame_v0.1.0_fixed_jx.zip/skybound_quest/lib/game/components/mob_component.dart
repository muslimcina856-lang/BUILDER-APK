import 'dart:math' as math;

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import '../skybound_game.dart';
import 'combat_actor_component.dart';

class MobComponent extends CombatActorComponent {
  MobComponent({
    required SkyboundGame gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
  }) : super(gameRef: gameRef, blueprint: blueprint, position: position);

  double _decisionTimer = 0;
  int _skillIndex = 0;

  @override
  void update(double dt) {
    super.update(dt);
    if (state.isDead || gameRef.hero.state.isDead) return;

    horizontalImpulse *= math.pow(0.03, dt).toDouble();
    position.x += horizontalImpulse * dt;
    _decisionTimer -= dt;
    if (_decisionTimer > 0 || !state.canAct || state.skills.isCasting) return;
    _decisionTimer = 0.12;

    final hero = gameRef.hero;
    final deltaX = hero.position.x - position.x;
    final distance = position.distanceTo(hero.position);
    if (distance > blueprint.aggroRange) return;
    if (deltaX != 0) facing = deltaX.sign;

    final skill = blueprint.skills[_skillIndex % blueprint.skills.length];
    if (distance <= skill.range) {
      final result = state.tryUseSkill(skill.id);
      if (result.accepted) _skillIndex++;
      return;
    }

    final direction = deltaX.sign;
    final step = direction * state.effectiveMoveSpeed * dt;
    position.x += step;
  }
}
