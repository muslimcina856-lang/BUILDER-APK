import 'dart:ui';

import 'package:flame/components.dart';

class ArenaStage extends PositionComponent {
  ArenaStage()
      : platforms = const [
          Rect.fromLTWH(-200, 330, 3000, 70),
          Rect.fromLTWH(310, 255, 150, 18),
          Rect.fromLTWH(515, 195, 145, 18),
          Rect.fromLTWH(710, 125, 155, 18),
          Rect.fromLTWH(925, 55, 170, 18),
          Rect.fromLTWH(1180, 150, 180, 18),
          Rect.fromLTWH(1460, 235, 180, 18),
          Rect.fromLTWH(1730, 165, 160, 18),
          Rect.fromLTWH(1980, 95, 190, 18),
          Rect.fromLTWH(2250, 220, 180, 18),
        ],
        super(position: Vector2.zero(), size: Vector2(3000, 520));

  final List<Rect> platforms;

  double? landingTop({
    required double left,
    required double right,
    required double previousBottom,
    required double nextBottom,
  }) {
    double? nearest;
    for (final platform in platforms) {
      final overlaps = right > platform.left && left < platform.right;
      final crossesTop = previousBottom <= platform.top + 2 && nextBottom >= platform.top;
      if (overlaps && crossesTop && (nearest == null || platform.top < nearest)) {
        nearest = platform.top;
      }
    }
    return nearest;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final sky = Paint()..color = const Color(0xFF17345C);
    final farMountain = Paint()..color = const Color(0xFF234A70);
    final platformPaint = Paint()..color = const Color(0xFF2D6B4F);
    final edgePaint = Paint()..color = const Color(0xFF65B85D);
    final dangerPaint = Paint()..color = const Color(0xFF8C3A44);

    canvas.drawRect(Offset.zero & Size(size.x, size.y), sky);
    for (var i = 0; i < 12; i++) {
      final x = i * 260.0;
      final peak = 250.0 - (i % 3) * 35;
      final path = Path()
        ..moveTo(x - 120, 330)
        ..lineTo(x + 80, peak)
        ..lineTo(x + 300, 330)
        ..close();
      canvas.drawPath(path, farMountain);
    }
    for (final platform in platforms) {
      canvas.drawRect(platform, platformPaint);
      canvas.drawRect(Rect.fromLTWH(platform.left, platform.top, platform.width, 5), edgePaint);
    }
    for (var x = 1070.0; x < 1160; x += 24) {
      final spike = Path()
        ..moveTo(x, 330)
        ..lineTo(x + 12, 312)
        ..lineTo(x + 24, 330)
        ..close();
      canvas.drawPath(spike, dangerPaint);
    }
  }
}
