import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../combat/combat_actor_state.dart';
import '../combat/combat_models.dart';
import '../combat/combat_resolver.dart';
import '../combat/skill_controller.dart';
import '../skybound_game.dart';

abstract class CombatActorComponent extends PositionComponent {
  CombatActorComponent({
    required this.gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
    Vector2? size,
  })  : state = CombatActorState(blueprint),
        super(
          position: position,
          size: size ?? Vector2.all(48),
          anchor: Anchor.center,
        );

  final SkyboundGame gameRef;
  final CombatActorState state;
  double facing = 1;
  double horizontalImpulse = 0;
  SpriteAnimationComponent? _visual;

  ActorBlueprint get blueprint => state.blueprint;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final frames = <Sprite>[];
    for (final path in blueprint.spriteFrames) {
      frames.add(Sprite(await gameRef.images.load(path)));
    }
    _visual = SpriteAnimationComponent(
      animation: SpriteAnimation.spriteList(frames, stepTime: 0.18),
      size: size,
    );
    add(_visual!);
    state.health.addListener((snapshot) {
      if (identical(this, gameRef.heroOrNull)) gameRef.publishHeroVitals();
    });
  }

  @override
  void update(double dt) {
    super.update(dt);
    final frame = state.update(dt);
    for (final event in frame.skillEvents) {
      if (event.type == SkillEventType.attackWindowOpened) {
        _executeAttack(event.skill);
      }
    }
    if (state.isDead) _visual?.opacity = 0.3;
  }

  void tryUseSkill(String skillId) => state.tryUseSkill(skillId);

  void receiveKnockback(double impulse) => horizontalImpulse += impulse;

  void _executeAttack(SkillDefinition skill) {
    if (state.isDead) return;
    if (skill.pattern == AttackPattern.dash && skill.dashDistance > 0) {
      position.x += facing * skill.dashDistance;
    }

    final targets = gameRef.combatants
        .where(
          (other) =>
              !identical(other, this) &&
              !other.state.isDead &&
              other.blueprint.faction != blueprint.faction,
        )
        .toList()
      ..sort(
        (a, b) => position
            .distanceTo(a.position)
            .compareTo(position.distanceTo(b.position)),
      );

    var landed = 0;
    for (final target in targets) {
      final deltaX = target.position.x - position.x;
      final distance = position.distanceTo(target.position);
      final requiresFacing = skill.pattern != AttackPattern.area;
      if (distance > skill.range || (requiresFacing && deltaX * facing < -12)) continue;

      final result = gameRef.combatResolver.resolve(
        attacker: state,
        target: target.state,
        hit: skill.hit,
        criticalRoll: gameRef.random.nextDouble(),
      );
      if (result.landed) {
        final direction = deltaX == 0 ? facing : deltaX.sign;
        target.receiveKnockback(direction * result.knockback);
        landed++;
      }
      if (landed >= skill.maximumTargets) break;
    }
  }

  @override
  void render(Canvas canvas) {
    final shadow = Paint()..color = const Color(0x55000000);
    canvas.drawOval(
      Rect.fromLTWH(size.x * 0.15, size.y * 0.82, size.x * 0.7, size.y * 0.18),
      shadow,
    );
    if (state.health.isInvulnerable) {
      final flash = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFFFE082);
      canvas.drawRect(Offset.zero & Size(size.x, size.y), flash);
    }
    _drawHealthBar(canvas);
    super.render(canvas);
  }

  void _drawHealthBar(Canvas canvas) {
    if (blueprint.faction == ActorFaction.hero || state.isDead) return;
    final background = Paint()..color = const Color(0xCC231F2B);
    final health = Paint()..color = const Color(0xFFEF5350);
    final width = math.max(size.x, 42).toDouble();
    final left = (size.x - width) / 2;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(left, -8, width, 5), const Radius.circular(2)),
      background,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(left, -8, width * state.health.ratio, 5),
        const Radius.circular(2),
      ),
      health,
    );
  }
}

