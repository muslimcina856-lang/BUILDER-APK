import 'dart:math' as math;

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import '../skybound_game.dart';
import 'combat_actor_component.dart';

class HeroComponent extends CombatActorComponent {
  HeroComponent({
    required SkyboundGame gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
  }) : super(gameRef: gameRef, blueprint: blueprint, position: position);

  static const gravity = 980.0;
  static const jumpVelocity = -390.0;
  static const coyoteDuration = 0.12;
  static const jumpBufferDuration = 0.15;

  final Vector2 velocity = Vector2.zero();
  double _coyoteRemaining = 0;
  double _jumpBufferRemaining = 0;
  bool _grounded = false;

  @override
  void update(double dt) {
    super.update(dt);
    if (state.isDead) return;

    final input = gameRef.input;
    if (input.consumePrimary()) tryUseSkill(blueprint.skills.first.id);
    if (input.consumeSecondary() && blueprint.skills.length > 1) {
      tryUseSkill(blueprint.skills[1].id);
    }
    if (input.consumeJump()) _jumpBufferRemaining = jumpBufferDuration;

    _coyoteRemaining = _grounded
        ? coyoteDuration
        : (_coyoteRemaining - dt).clamp(0, coyoteDuration).toDouble();
    _jumpBufferRemaining =
        (_jumpBufferRemaining - dt).clamp(0, jumpBufferDuration).toDouble();

    final movementAllowed = state.canAct;
    final double axis = movementAllowed ? input.horizontalAxis : 0.0;
    if (axis != 0) facing = axis.sign;
    velocity.x = axis * state.effectiveMoveSpeed + horizontalImpulse;
    horizontalImpulse *= math.pow(0.02, dt).toDouble();

    if (_jumpBufferRemaining > 0 && _coyoteRemaining > 0 && movementAllowed) {
      velocity.y = jumpVelocity;
      _grounded = false;
      _coyoteRemaining = 0;
      _jumpBufferRemaining = 0;
    }
    if (!input.jumpHeld && velocity.y < -100) velocity.y *= 0.55;

    velocity.y += gravity * dt;
    final previousBottom = position.y + size.y / 2;
    final nextX = (position.x + velocity.x * dt).clamp(0, 2600).toDouble();
    final nextY = position.y + velocity.y * dt;
    final landing = gameRef.stage.landingTop(
      left: nextX - size.x * 0.34,
      right: nextX + size.x * 0.34,
      previousBottom: previousBottom,
      nextBottom: nextY + size.y / 2,
    );
    position.x = nextX;
    if (velocity.y >= 0 && landing != null) {
      position.y = landing - size.y / 2;
      velocity.y = 0;
      _grounded = true;
    } else {
      position.y = nextY;
      _grounded = false;
    }
  }

  @override
  void receiveKnockback(double impulse) {
    super.receiveKnockback(impulse);
    velocity.y = -125;
  }
}
