# Pelan dunia Skybound Quest

## Sasaran

- Genre: action-platformer pixel art.
- Platform utama: telefon Android landscape.
- Tempoh kempen pertama: 60–90 minit.
- Empat avatar dengan statistik dan skill berbeza.
- Dunia terasa panjang secara mendatar serta tinggi secara menegak.
- Checkpoint setiap dua hingga empat minit.

## Struktur kawasan

| Bab | Kawasan | Arah dominan | Mekanik baharu | Penutup |
|---|---|---|---|---|
| 1 | Padang Permulaan | Mendatar | Lari, lompat, serang | Mimic ambush |
| 2 | Hutan Gergasi | Menegak naik | Platform bergerak, wall-jump | Scout Drone |
| 3 | Lombong Dalam | Menegak turun | Gelap, spike, lift | Drill Spike elite |
| 4 | Kota Tenggelam | Campuran | Air, suis, laluan bercabang | Guard Bot squad |
| 5 | Menara Ribut | Menegak naik | Angin, dash gap, platform jatuh | Ember Wisp swarm |
| 6 | Kubu Langit | Panjang + tinggi | Gabungan semua mekanik | Monitor Golem |

Setiap kawasan dicadangkan antara 192–320 tiles lebar dan 96–192 tiles tinggi.
Peta produksi hendaklah dipecahkan kepada chunk `64×64 tiles`; hanya chunk
semasa dan jiran terdekat dimuatkan.

## Rentak permainan

Setiap blok tiga hingga lima minit mengikuti pola:

1. Perkenalkan ruang atau mekanik tanpa tekanan.
2. Uji mekanik bersama satu jenis mob.
3. Campurkan mob kedua atau hazard.
4. Berikan ruang rehat, checkpoint atau rahsia.
5. Akhiri dengan encounter yang menggabungkan semua unsur blok.

Jalan utama mestilah sentiasa boleh dibaca. Laluan tinggi, bawah tanah dan
ceruk belakang air terjun digunakan untuk collectible, lore dan peningkatan HP.

## Kamera

- Kamera mengikuti hero dengan dead-zone, bukan melekat tepat pada pusat.
- Look-ahead mendatar mengikut arah hero.
- Bias menegak ketika jatuh atau memanjat.
- Kamera dikunci dalam sempadan chunk aktif.
- Shake hanya untuk hit berat, maksimum 0.18 saat bagi mengelakkan mabuk gerakan.

## Kawalan Android

- Kiri/kanan di bahagian kiri skrin.
- Lompat sebagai butang terbesar di kanan bawah.
- Serangan utama bersebelahan lompat.
- Skill khas lebih kecil dan sedikit ke atas.
- Pause di penjuru kanan atas pada fasa produksi.
- Multi-touch diperlukan untuk bergerak, melompat dan menyerang serentak.
- Coyote time 120ms, jump buffer 150ms dan variable jump sudah dimasukkan.
- Tetapan produksi perlu membenarkan saiz, opacity dan posisi butang diubah.
- Semua elemen HUD berada dalam `SafeArea` untuk notch dan kamera telefon baharu.

## Prestasi

- Sasaran 60 FPS; pilihan 30 FPS untuk telefon lemah boleh ditambah.
- Gabungkan sprite produksi ke atlas selepas pemilihan aset muktamad.
- Pool projectile, hit effect dan damage number.
- Jangan update AI di luar dua chunk daripada kamera.
- Audio pendek dipra-cache dan dihadkan bilangan instance serentak.
- Simpan peta serta collision sebagai data, bukan satu imej latar gergasi.

## Milestone

1. Vertical slice: satu avatar, dua mob, satu checkpoint dan satu mini-boss.
2. Combat lock: semua formula, i-frame, status, poise dan ujian diluluskan.
3. World production: enam kawasan dan sistem chunk.
4. Content pass: semua avatar, mob, collectible, bunyi dan UI.
5. Android optimization: saiz atlas, memory, input latency dan peranti notch.
6. Release: save migration, accessibility, tutorial, AAB dan closed testing.

