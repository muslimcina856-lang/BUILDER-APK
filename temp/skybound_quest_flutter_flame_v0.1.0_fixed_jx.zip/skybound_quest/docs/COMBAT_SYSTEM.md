# Sistem combat terperinci

## Prinsip utama

Hero dan mob tidak mempunyai dua sistem nyawa yang berasingan. Semua actor
menggunakan urutan yang sama:

1. Skill memasuki `windup`.
2. Satu `attackWindowOpened` diterbitkan apabila active frame bermula.
3. Sasaran ditapis mengikut faction, jarak dan arah pandangan.
4. `CombatResolver` mengira raw damage, crit, defense dan resistance.
5. Shield menyerap damage terlebih dahulu.
6. Baki damage mengurangkan HP dan mengaktifkan i-frame.
7. Poise damage boleh menyebabkan stagger dan membatalkan skill sasaran.
8. Status effect, knockback dan life steal diproses selepas hit berjaya.
9. Actor mati apabila HP mencapai sifar; nilai HP tidak boleh menjadi negatif.

Perbezaan hero dan mob hanyalah `CombatStats`, senarai skill dan pengawal input
(sentuhan pemain atau AI).

## Formula damage

```text
rawDamage = baseDamage + attackPower × attackScaling
criticalDamage = rawDamage × criticalMultiplier
defenseMultiplier = 100 ÷ (100 + defense)
resistanceMultiplier = 1 - resistance
finalDamage = max(1, criticalDamage × defenseMultiplier × resistanceMultiplier)
```

`trueDamage` mengabaikan defense dan resistance. Resistance dihadkan antara
-50% hingga 80% bagi mengelakkan kebal mutlak atau kelemahan melampau.

Crit hanya berlaku jika skill membenarkannya. Random roll disuntik ke resolver,
jadi ujian boleh menetapkan hasil secara deterministik.

## Nyawa dan perlindungan

`HealthPool` menyediakan peraturan sama untuk semua actor:

- `maximum` dan `current` HP.
- Shield sementara yang menerima damage sebelum HP.
- Invulnerability frame selepas terkena serangan.
- Serangan tertentu boleh mengabaikan i-frame.
- Heal tidak boleh melebihi max HP.
- Damage tidak boleh menurunkan HP di bawah sifar.
- Event kematian hanya dianggap baharu sekali bagi setiap hayat.
- `revive()` mengembalikan actor dan membersihkan keadaan kematian.

## Fasa skill

| Fasa | Tujuan |
|---|---|
| Windup | Animasi persediaan; pemain masih boleh membaca serangan musuh |
| Active | Damage window dibuka tepat sekali |
| Recovery | Actor belum boleh memulakan serangan baharu |
| Cooldown | Tempoh sebelum skill yang sama boleh digunakan semula |

Skill boleh mempunyai kos tenaga, jarak, maksimum sasaran, dash distance dan
tempoh kebal diri. `SkillController` menolak skill jika actor mati, stunned,
sedang casting, tidak cukup tenaga atau cooldown belum habis.

## Skill avatar

| Avatar | Skill utama | Skill khas | Gaya |
|---|---|---|---|
| Nova | Sunsteel Slash | Sky Dash | Seimbang, dash kebal seketika |
| Aegis | Shield Breaker | Guardian Quake | HP/defense tinggi, stagger kawasan |
| Pyra | Ember Orb | Solar Burst | Serangan api dan Burning bertindan |
| Volt | Spark Jab | Thunder Step | Laju, crit tinggi dan dash menembusi |

## Skill mob

| Mob | HP | Skill | Counterplay |
|---|---:|---|---|
| Mimic Cube | 58 | Cube Chomp | Windup 0.34s; undur sebelum gigitan |
| Ember Wisp | 42 | Cinder Spit | Dekati atau lompat melepasi peluru |
| Drill Spike | 76 | Drill Charge | Elak selepas telegraph 0.62s |
| Guard Bot | 92 | Guard Bolt | Lompat ketika bolt dilepaskan |
| Scout Drone | 48 | Drone Swoop | Tukar arah selepas drone mengunci |
| Monitor Golem | 480 | Golem Slam, Screen Beam | Boss; serangan berat dengan windup panjang |

## Status effect

- Burning: maksimum tiga stack, tiga damage setiap saat selama empat saat.
- Poisoned: maksimum empat stack, dua damage setiap saat selama enam saat.
- Chilled: kelajuan bergerak menjadi 65% selama 2.5 saat.
- Stunned: tidak boleh bergerak atau menggunakan skill selama 0.7 saat.
- Armor Broken: tersedia untuk pengembangan pengurangan defense seterusnya.

Periodic damage mengabaikan i-frame serangan biasa tetapi masih mengambil kira
resistance elemen actor.

## Invariant yang diuji

- Semua actor mempunyai skill serangan yang menghasilkan damage positif.
- Friendly fire ditolak secara lalai.
- Shield diproses sebelum HP.
- I-frame menyekat hit berganda terlalu rapat.
- True damage mengabaikan defense.
- Damage window dibuka sekali bagi setiap cast.
- Skill tanpa tenaga atau dalam cooldown ditolak.
- Hero dan mob kedua-duanya boleh memberi serta menerima damage melalui resolver sama.

