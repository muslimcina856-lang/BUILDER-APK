# Skybound Quest

Prototaip action-platformer 2D untuk Android menggunakan Flutter + Flame. Projek
ini mengandungi 2,046 fail aset CC0 yang dikekalkan sebagai arkib asal, 410 aset
runtime terpilih, empat avatar, enam jenis mob dan satu sistem combat bersama.

## Apa yang sudah dibina

- Empat avatar: Nova, Aegis, Pyra dan Volt.
- Enam mob: Mimic Cube, Ember Wisp, Drill Spike, Guard Bot, Monitor Golem dan
  Scout Drone.
- Setiap actor wajib mempunyai sekurang-kurangnya satu skill serangan. Katalog
  akan menolak actor tanpa skill.
- Hero dan mob menggunakan `HealthPool`, `CombatResolver`, `StatusController`
  dan `SkillController` yang sama.
- HP, shield, defense, resistance, critical hit, life steal, i-frame, poise,
  stagger, knockback, status bertindan dan periodic damage.
- Kawalan multi-touch Android: kiri, kanan, lompat, serangan utama dan skill.
- Coyote time, jump buffer dan variable jump.
- Arena contoh yang panjang dan mempunyai laluan menegak.
- Ujian unit serta verifier combat deterministik.

## Menjana projek Android

Folder Android standard perlu dijana menggunakan Flutter SDK 3.41 atau lebih
baharu. Dari folder projek ini, jalankan:

```bash
flutter create --platforms=android --org com.earlxz .
flutter pub get
flutter test
flutter run
```

Perintah `flutter create` menambah fail platform Android yang bergantung pada
versi Flutter tempatan. Kod `lib/`, aset dan konfigurasi sedia ada kekal.

Untuk bina fail Play Store:

```bash
flutter build appbundle --release
```

## Memilih avatar

Ubah nilai `selectedAvatarId` di `lib/main.dart`:

```dart
SkyboundGame(selectedAvatarId: 'nova')
```

Nilai yang tersedia: `nova`, `aegis`, `pyra`, `volt`.

## Menambah watak baharu

1. Tambah sprite ke `assets/images/characters/`.
2. Cipta `ActorBlueprint` dalam `lib/game/data/actor_catalog.dart`.
3. Berikan `CombatStats` dan sekurang-kurangnya satu `SkillDefinition`.
4. Masukkan blueprint ke `ActorCatalog.playableAvatars` atau `ActorCatalog.mobs`.
5. Jalankan `flutter test` dan `dart run tool/verify_combat.dart`.

Constructor `ActorBlueprint` akan terus menolak watak yang tiada skill, sprite,
atau mempunyai id skill berulang.

## Folder penting

```text
lib/game/combat/       Logic HP, damage, status dan skill
lib/game/data/         Statistik serta skill setiap actor
lib/game/components/   Integrasi Flame, pergerakan dan AI
lib/ui/                Kawalan sentuh dan HUD
assets/                Aset runtime yang dipilih
third_party/raw/       Semua aset dan lesen asal
docs/                  Pelan dunia dan spesifikasi combat
test/                  Ujian logic combat
```

Rujuk `docs/COMBAT_SYSTEM.md` untuk formula terperinci dan
`docs/GAME_DESIGN.md` untuk struktur level penuh.

