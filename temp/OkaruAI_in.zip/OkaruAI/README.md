# Okaru AI 🤖

**Asisten AI pengendali HP Android** dengan perintah suara & teks.

Nama: **Okaru AI**  
Package: `com.okaru.ai`

---

## Fitur yang sudah ada (kerangka)

- ✅ Input perintah **teks**
- ✅ Input perintah **suara** (SpeechRecognizer bahasa Indonesia)
- ✅ Text-to-Speech (balasan Okaru)
- ✅ Perintah dasar:
  - Buka YouTube / WhatsApp / Chrome / Kamera / Pengaturan
  - Telepon [nomor]
  - Siapa kamu / Bantuan
- ✅ Kerangka **Accessibility Service** (untuk kontrol lebih dalam)
- ✅ UI gelap modern

---

## Cara membuka & build jadi APK

1. Download & extract ZIP ini
2. Buka **Android Studio** (versi terbaru disarankan)
3. **File → Open** → pilih folder `OkaruAI`
4. Tunggu Gradle sync selesai
5. Hubungkan HP Android (USB debugging) atau pakai emulator
6. Klik **Run** (tombol hijau) atau **Build → Build Bundle(s) / APK(s) → Build APK(s)**

APK hasil build biasanya ada di:
`app/build/outputs/apk/debug/app-debug.apk`

---

## Cara menambahkan perintah sendiri

Buka file:
`app/src/main/java/com/okaru/ai/CommandProcessor.kt`

Tambahkan di dalam `when` block, contoh:

```kotlin
command.contains("buka instagram") -> {
    openApp("com.instagram.android")
    "Membuka Instagram..."
}
```

---

## Aktifkan Accessibility Service (opsional, untuk kontrol lanjutan)

1. Buka aplikasi Okaru AI
2. Pergi ke **Pengaturan HP → Aksesibilitas → Okaru AI**
3. Aktifkan service-nya
4. Setelah itu kamu bisa pakai fungsi `OkaruAccessibilityService.instance?.performGlobalActionHome()` dll.

**Peringatan**: Accessibility Service sangat powerful. Hanya aktifkan di HP sendiri dan jangan disalahgunakan.

---

## Izin yang diminta

- Mikrofon (untuk suara)
- Internet (opsional, kalau nanti integrasi AI online)
- Telepon & SMS (jika kamu aktifkan fitur tersebut)

---

## Pengembangan selanjutnya (ide)

- Integrasi OpenAI / Gemini / Grok API supaya bisa perintah natural language
- Kontrol volume, brightness, flashlight via CameraManager / AudioManager
- Gesture otomatis via Accessibility
- Wake word ("Hey Okaru")
- Widget / floating button

---

Dibuat sebagai kerangka untuk kamu kembangkan sendiri.  
Selamat coding! 🚀

**Okaru AI** – Asisten pribadi yang menurut perintahmu.
