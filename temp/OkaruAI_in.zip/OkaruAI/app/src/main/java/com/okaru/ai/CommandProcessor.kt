package com.okaru.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

/**
 * Okaru AI - Command Processor
 * Tempat kamu menambahkan perintah sendiri.
 * Contoh perintah sudah ada, silakan kembangkan sesuai kebutuhan.
 */
class CommandProcessor(private val context: Context) {

    fun process(rawCommand: String): String {
        val command = rawCommand.lowercase().trim()

        return when {
            // === Buka Aplikasi ===
            command.contains("buka youtube") || command.contains("buka yt") -> {
                openApp("com.google.android.youtube")
                "Membuka YouTube..."
            }
            command.contains("buka whatsapp") || command.contains("buka wa") -> {
                openApp("com.whatsapp")
                "Membuka WhatsApp..."
            }
            command.contains("buka chrome") || command.contains("buka browser") -> {
                openApp("com.android.chrome")
                "Membuka Chrome..."
            }
            command.contains("buka kamera") -> {
                openApp("com.android.camera")
                "Membuka Kamera..."
            }
            command.contains("buka pengaturan") || command.contains("buka setting") -> {
                context.startActivity(Intent(Settings.ACTION_SETTINGS))
                "Membuka Pengaturan..."
            }

            // === Telepon & SMS (butuh izin) ===
            command.startsWith("telepon ") || command.startsWith("panggil ") -> {
                val number = command.removePrefix("telepon ").removePrefix("panggil ").trim()
                dialNumber(number)
                "Mencoba menelepon $number"
            }
            command.startsWith("kirim sms ") -> {
                "Fitur SMS siap dikembangkan. Contoh: kirim sms ke 08xxx isi pesan"
            }

            // === Kontrol dasar ===
            command.contains("nyalakan flashlight") || command.contains("nyalakan senter") -> {
                "Senter: fitur ini butuh Camera API. Silakan kembangkan di OkaruAccessibilityService."
            }
            command.contains("matikan flashlight") || command.contains("matikan senter") -> {
                "Senter dimatikan (kerangka)."
            }

            // === Volume & Media ===
            command.contains("naikkan volume") || command.contains("volume up") -> {
                "Volume dinaikkan (gunakan AudioManager di versi lanjutan)."
            }
            command.contains("turunkan volume") || command.contains("volume down") -> {
                "Volume diturunkan (gunakan AudioManager di versi lanjutan)."
            }

            // === Info ===
            command.contains("siapa kamu") || command.contains("nama kamu") -> {
                "Saya Okaru AI, asisten pribadi yang bisa mengendalikan HP kamu dengan perintah suara atau teks."
            }
            command.contains("apa yang bisa kamu lakukan") || command.contains("bantuan") || command.contains("help") -> {
                """
                Perintah yang tersedia saat ini:
                • Buka YouTube / WhatsApp / Chrome / Kamera / Pengaturan
                • Telepon [nomor]
                • Siapa kamu / Bantuan
                
                Kamu bisa menambahkan perintah baru di file CommandProcessor.kt
                """.trimIndent()
            }

            // === Default ===
            else -> {
                "Maaf, saya belum mengerti perintah \"$rawCommand\". Ketik 'bantuan' untuk melihat daftar perintah."
            }
        }
    }

    private fun openApp(packageName: String) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                Toast.makeText(context, "Aplikasi tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membuka aplikasi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dialNumber(number: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membuka dialer", Toast.LENGTH_SHORT).show()
        }
    }
}
