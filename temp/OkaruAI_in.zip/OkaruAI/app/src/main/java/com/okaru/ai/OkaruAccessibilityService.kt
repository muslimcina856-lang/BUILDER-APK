package com.okaru.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

/**
 * Okaru Accessibility Service
 * 
 * Ini adalah kerangka untuk kontrol HP yang lebih dalam
 * (klik otomatis, scroll, buka notifikasi, dll).
 * 
 * User HARUS mengaktifkan service ini secara manual di:
 * Pengaturan → Aksesibilitas → Okaru AI
 * 
 * Jangan disalahgunakan. Hanya untuk HP sendiri.
 */
class OkaruAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "OkaruAccessibility"
        var instance: OkaruAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Okaru Accessibility Service aktif")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Di sini kamu bisa memproses event UI
        // Contoh: deteksi jendela tertentu, klik tombol, dll.
    }

    override fun onInterrupt() {
        Log.d(TAG, "Service interrupted")
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // Contoh fungsi yang bisa dipanggil dari CommandProcessor (via instance)
    fun performGlobalActionBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun performGlobalActionHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun performGlobalActionRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }
}
