package com.aiuhdhub.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.data.AiTool
import com.aiuhdhub.app.data.SourceType
import com.aiuhdhub.app.data.ToolCategory
import com.aiuhdhub.app.ui.theme.*

@Composable
fun ToolCard(
    tool: AiTool,
    onDownloadClick: (String) -> Unit,
    onGithubClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    val categoryIcon = when (tool.category) {
        ToolCategory.IMAGE_UPSCALER -> Icons.Filled.PhotoSizeSelectLarge
        ToolCategory.VIDEO_UPSCALER -> Icons.Filled.OndemandVideo
        ToolCategory.ALL_IN_ONE -> Icons.Filled.AutoAwesome
        ToolCategory.ENHANCEMENT -> Icons.Filled.AutoFixHigh
    }

    val categoryColor = when (tool.category) {
        ToolCategory.IMAGE_UPSCALER -> AccentBlue
        ToolCategory.VIDEO_UPSCALER -> AccentPurple
        ToolCategory.ALL_IN_ONE -> AccentGreen
        ToolCategory.ENHANCEMENT -> AccentOrange
    }

    val sourceIcon = when (tool.sourceType) {
        SourceType.GITHUB_RELEASE -> Icons.Filled.Code
        SourceType.PLAY_STORE -> Icons.Filled.Shop
        SourceType.FDROID -> Icons.Filled.Security
    }

    val sourceText = when (tool.sourceType) {
        SourceType.GITHUB_RELEASE -> "GitHub"
        SourceType.PLAY_STORE -> "Play Store"
        SourceType.FDROID -> "F-Droid"
    }

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        glowColor = categoryColor,
        showGlow = false
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { expanded = !expanded }
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Icon
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    categoryColor.copy(alpha = 0.3f),
                                    categoryColor.copy(alpha = 0.1f)
                                )
                            )
                        )
                        .border(
                            1.dp,
                            categoryColor.copy(alpha = 0.3f),
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = categoryIcon,
                        contentDescription = null,
                        tint = categoryColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tool.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "oleh ${tool.developer}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }

                // Rating
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = null,
                        tint = AccentOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = String.format("%.1f", tool.rating),
                        style = MaterialTheme.typography.labelLarge,
                        color = AccentOrange
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tags Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusChip(
                    text = if (tool.isOffline) "⚡ Offline" else "☁️ Cloud",
                    color = if (tool.isOffline) AccentGreen else AccentBlue
                )
                if (tool.supportsImage) {
                    StatusChip(text = "📷 Image", color = AccentCyan)
                }
                if (tool.supportsVideo) {
                    StatusChip(text = "🎬 Video", color = AccentPurple)
                }
                StatusChip(
                    text = sourceText,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Description
            Text(
                text = tool.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                maxLines = if (expanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 20.sp
            )

            // Expandable content
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    // Engine type
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Memory,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Engine: ${tool.engineType}",
                            style = MaterialTheme.typography.labelLarge,
                            color = AccentCyan
                        )
                    }

                    // AI Models
                    if (tool.aiModels.isNotEmpty()) {
                        Text(
                            text = "Model AI:",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        FlowRow(
                            modifier = Modifier.padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            tool.aiModels.forEach { model ->
                                StatusChip(
                                    text = model,
                                    color = AccentPurple
                                )
                            }
                        }
                    }

                    // Features
                    Text(
                        text = "Ciri-ciri:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    tool.features.forEach { feature ->
                        Row(
                            modifier = Modifier.padding(bottom = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 7.dp)
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(categoryColor)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = feature,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GradientButton(
                    onClick = { onDownloadClick(tool.downloadUrl) },
                    modifier = Modifier.weight(1f),
                    gradientColors = listOf(categoryColor, categoryColor.copy(alpha = 0.7f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Download",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (tool.githubUrl.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { onGithubClick(tool.githubUrl) },
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            TextMuted.copy(alpha = 0.3f)
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextSecondary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Code,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GitHub",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            // Expand indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "Tutup" else "Buka lagi",
                    tint = TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
