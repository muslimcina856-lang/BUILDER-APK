# Metro Rush untuk Android

Game endless runner Android asli dalam mod potret, dibina menggunakan Java dan Canvas Android.

## Identiti aplikasi

- Nama: Metro Rush
- Package / Application ID: com.metro.rush
- Orientasi: potret
- compileSdk: 37
- targetSdk: 37
- minSdk: 26
- Android Gradle Plugin: 9.3.0
- Gradle: 9.5.0
- Java: 17

## Ciri

- Tiga lorong dengan kawalan sentuhan dan swipe sahaja
- Swipe kiri atau kanan untuk menukar lorong
- Swipe ke atas untuk melompat
- Swipe ke bawah untuk gelongsor
- 24 bingkai watak 3D: 8 larian, 8 lompatan dan 8 tunduk/gelongsor
- Peralihan lorong berinersia, badan condong, bayang dinamik dan kesan pendaratan
- Animasi trek, parallax kamera, jejak kelajuan dan lampu lantai bergerak
- Tren 3D lengkap dengan badan gerabak, penghadang, palang, syiling, skor dan rekod terbaik
- Kedai power-up dengan dompet syiling, inventori dan pilihan kuasa tersimpan
- Perisai Neon menyekat satu pelanggaran
- Magnet Syiling menarik syiling dari semua lorong selama 20 saat
- Turbo Skor menggandakan skor selama 25 saat
- Ikon kuasa 3D khusus dan kesan visual aktif ketika bermain
- Aset latar, pelari, tren dan ikon aplikasi yang dijana khusus
- Kesan bunyi CC0 untuk UI, pembelian, kuasa, lompat, syiling dan pelanggaran
- Ambience metro CC0 berulang perlahan ketika larian dan berhenti semasa jeda
- Skrin penuh serta gaya metro retro neon
- Tiada Internet, akaun atau kebenaran sensitif diperlukan

## Cara menggunakan power-up

1. Kutip syiling semasa berlari. Syiling terus dimasukkan ke dalam dompet kekal.
2. Buka `KEDAI` pada skrin mula atau skrin tamat.
3. Tekan `BELI` pada power-up pilihan.
4. Tekan `GUNA` untuk memilihnya bagi larian seterusnya.
5. Kembali dan tekan `MULA`. Satu unit akan digunakan secara automatik.

Satu power-up boleh aktif untuk setiap larian.

## Aset pihak ketiga

Bunyi pilihan datang daripada pek Kenney CC0. Maklumat sumber dan lesen terdapat
dalam `THIRD_PARTY_NOTICES.md`.

## Cara buka

1. Pasang Android Studio Quail 3 atau lebih baharu.
2. Dalam SDK Manager, pasang Android 17 / API 37.
3. Buka folder projek ini.
4. Tunggu Gradle Sync selesai dan tekan Run.

Untuk membina APK debug:

    ./gradlew assembleDebug

APK akan terhasil di:

    app/build/outputs/apk/debug/app-debug.apk
