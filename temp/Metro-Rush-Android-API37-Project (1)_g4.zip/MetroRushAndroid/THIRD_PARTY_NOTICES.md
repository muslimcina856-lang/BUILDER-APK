# Notis aset pihak ketiga

## Kenney Sci-fi Sounds

- Pencipta: Kenney
- Sumber: https://kenney.nl/assets/sci-fi-sounds
- Cermin muat turun: https://opengameart.org/content/sci-fi-sounds
- Lesen: Creative Commons CC0 1.0 Universal
- Digunakan secara terpilih untuk lompat, pendaratan, perisai, pengaktifan kuasa
  dan pelanggaran.

## Kenney Interface Sounds

- Pencipta: Kenney
- Sumber: https://kenney.nl/assets/interface-sounds
- Pembungkusan fail WAV: https://github.com/Calinou/kenney-interface-sounds
- Lesen: Creative Commons CC0 1.0 Universal
- Digunakan secara terpilih untuk klik UI, kembali, ralat, pembelian dan kutipan
  syiling.

CC0 tidak mewajibkan atribusi. Notis ini disertakan untuk ketelusan sumber.
