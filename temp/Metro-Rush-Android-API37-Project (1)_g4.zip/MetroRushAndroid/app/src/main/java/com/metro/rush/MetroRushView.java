package com.metro.rush;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class MetroRushView extends View {
    private static final int SPRITE_COLUMNS = 4;
    private static final int SPRITE_ROWS = 2;
    private static final int SPRITE_FRAME_COUNT = 8;
    private static final float SLIDE_DURATION = 0.58f;
    private static final float EXPECTED_JUMP_DURATION = 0.92f;
    private static final float MAGNET_DURATION = 20f;
    private static final float SCORE_BOOST_DURATION = 25f;
    private static final int SHIELD_COST = 80;
    private static final int MAGNET_COST = 110;
    private static final int SCORE_BOOST_COST = 140;

    private static final int COLOR_INK = Color.rgb(18, 9, 31);
    private static final int COLOR_NIGHT = Color.rgb(23, 11, 46);
    private static final int COLOR_PANEL = Color.rgb(36, 18, 63);
    private static final int COLOR_PURPLE = Color.rgb(90, 36, 168);
    private static final int COLOR_YELLOW = Color.rgb(255, 216, 61);
    private static final int COLOR_GREEN = Color.rgb(98, 232, 74);
    private static final int COLOR_PINK = Color.rgb(255, 59, 157);
    private static final int COLOR_CREAM = Color.rgb(255, 247, 214);
    private static final int COLOR_CYAN = Color.rgb(95, 245, 255);

    private static final String PREFS_NAME = "metro_rush";
    private static final String PREF_BEST_SCORE = "best_score";
    private static final String PREF_SOUND = "sound_enabled";
    private static final String PREF_WALLET = "wallet_coins";
    private static final String PREF_SHIELD_STOCK = "shield_stock";
    private static final String PREF_MAGNET_STOCK = "magnet_stock";
    private static final String PREF_SCORE_BOOST_STOCK = "score_boost_stock";
    private static final String PREF_ARMED_POWER_UP = "armed_power_up";

    private enum Mode {
        IDLE,
        RUNNING,
        PAUSED,
        GAME_OVER,
        SHOP
    }

    private enum Kind {
        COIN,
        BARRIER,
        GATE,
        TRAIN
    }

    private enum PowerUp {
        NONE,
        SHIELD,
        MAGNET,
        SCORE_BOOST
    }

    private static final class Entity {
        final Kind kind;
        final int lane;
        float z;
        float pull;
        boolean passed;

        Entity(Kind kind, int lane, float z) {
            this.kind = kind;
            this.lane = lane;
            this.z = z;
        }
    }

    private static final class Spark {
        final int color;
        float x;
        float y;
        float vx;
        float vy;
        float life;

        Spark(float x, float y, float vx, float vy) {
            this(x, y, vx, vy, COLOR_YELLOW);
        }

        Spark(float x, float y, float vx, float vy, int color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.color = color;
            life = 1f;
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Path path = new Path();
    private final Rect bitmapSource = new Rect();
    private final RectF bitmapTarget = new RectF();
    private final RectF runnerTarget = new RectF();
    private final RectF runnerTrailTarget = new RectF();
    private final RectF pauseButton = new RectF();
    private final RectF soundButton = new RectF();
    private final RectF shopButton = new RectF();
    private final RectF shopCloseButton = new RectF();
    private final RectF[] shopBuyButtons = {
            new RectF(), new RectF(), new RectF()
    };
    private final RectF[] shopUseButtons = {
            new RectF(), new RectF(), new RectF()
    };
    private final List<Entity> entities = new ArrayList<>();
    private final List<Spark> sparks = new ArrayList<>();
    private final Random random = new Random();
    private final SharedPreferences preferences;
    private final Bitmap backgroundBitmap;
    private final Bitmap runnerRunSheet;
    private final Bitmap runnerJumpSheet;
    private final Bitmap runnerSlideSheet;
    private final Bitmap trainBitmap;
    private final Bitmap powerUpIconSheet;
    private final SoundPool soundPool;
    private final int soundCoin;
    private final int soundCrash;
    private final int soundJump;
    private final int soundLanding;
    private final int soundPowerActivate;
    private final int soundPowerReady;
    private final int soundShieldHit;
    private final int soundShopBuy;
    private final int soundUiClick;
    private final int soundUiBack;
    private final int soundUiError;
    private final int soundAmbience;
    private final float density;

    private Mode mode = Mode.IDLE;
    private int targetLane;
    private float laneVisual;
    private float laneVelocity;
    private float jump;
    private float jumpVelocity;
    private float jumpElapsed;
    private float slideTimer;
    private float characterClock;
    private float landingPulse;
    private float spawnTimer;
    private float speed;
    private float distance;
    private float scoreBonus;
    private float flash;
    private float shake;
    private float trackOffset;
    private int coins;
    private int walletCoins;
    private int shieldStock;
    private int magnetStock;
    private int scoreBoostStock;
    private int bestScore;
    private long previousFrameTime;
    private float touchStartX;
    private float touchStartY;
    private boolean trackingTouch;
    private boolean soundEnabled;
    private Mode shopReturnMode = Mode.IDLE;
    private PowerUp armedPowerUp = PowerUp.NONE;
    private PowerUp activePowerUp = PowerUp.NONE;
    private float activePowerTimer;
    private boolean shieldReady;
    private String toastMessage = "";
    private float toastTimer;
    private int ambienceStreamId;

    public MetroRushView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        bestScore = preferences.getInt(PREF_BEST_SCORE, 0);
        soundEnabled = preferences.getBoolean(PREF_SOUND, true);
        walletCoins = preferences.getInt(PREF_WALLET, 0);
        shieldStock = preferences.getInt(PREF_SHIELD_STOCK, 0);
        magnetStock = preferences.getInt(PREF_MAGNET_STOCK, 0);
        scoreBoostStock = preferences.getInt(PREF_SCORE_BOOST_STOCK, 0);
        armedPowerUp = readPowerUp(preferences.getString(PREF_ARMED_POWER_UP, "NONE"));

        backgroundBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.metro_background);
        runnerRunSheet = BitmapFactory.decodeResource(getResources(), R.drawable.runner_run_sheet);
        runnerJumpSheet = BitmapFactory.decodeResource(getResources(), R.drawable.runner_jump_sheet);
        runnerSlideSheet = BitmapFactory.decodeResource(getResources(), R.drawable.runner_slide_sheet);
        trainBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.metro_train_full);
        powerUpIconSheet = BitmapFactory.decodeResource(
                getResources(), R.drawable.powerup_icons_sheet);

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(audioAttributes)
                .build();
        soundCoin = soundPool.load(context, R.raw.coin_pickup, 1);
        soundCrash = soundPool.load(context, R.raw.crash, 1);
        soundJump = soundPool.load(context, R.raw.jump, 1);
        soundLanding = soundPool.load(context, R.raw.landing, 1);
        soundPowerActivate = soundPool.load(context, R.raw.power_activate, 1);
        soundPowerReady = soundPool.load(context, R.raw.power_ready, 1);
        soundShieldHit = soundPool.load(context, R.raw.shield_hit, 1);
        soundShopBuy = soundPool.load(context, R.raw.shop_buy, 1);
        soundUiClick = soundPool.load(context, R.raw.ui_click, 1);
        soundUiBack = soundPool.load(context, R.raw.ui_back, 1);
        soundUiError = soundPool.load(context, R.raw.ui_error, 1);
        soundAmbience = soundPool.load(context, R.raw.metro_ambience, 1);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        setFocusable(true);
        setFocusableInTouchMode(true);
        setContentDescription(context.getString(R.string.game_description));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        resetAttractScene();
    }

    public void resumeRendering() {
        previousFrameTime = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    public void pauseGame() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
            pauseAmbience();
        }
        invalidate();
    }

    public void release() {
        persistEconomy();
        stopAmbience();
        soundPool.release();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        long now = SystemClock.uptimeMillis();
        if (previousFrameTime == 0L) {
            previousFrameTime = now;
        }
        float dt = Math.min(0.034f, Math.max(0f, (now - previousFrameTime) / 1000f));
        previousFrameTime = now;

        if (mode == Mode.RUNNING) {
            updateGame(dt);
        } else {
            updateLaneMotion(dt, 44f, 10f);
        }
        updateSparks(dt);
        toastTimer = Math.max(0f, toastTimer - dt);

        drawGeneratedBackground(canvas);
        drawTrackMotionLayer(canvas);
        drawSpeedLayer(canvas, now);
        drawEntities(canvas, now);
        drawRunner(canvas, now);
        drawSparks(canvas);
        drawHeaderAndHud(canvas);
        drawActionButtons(canvas);
        drawSwipeHint(canvas);
        if (mode == Mode.SHOP) {
            drawShopOverlay(canvas);
        } else if (mode != Mode.RUNNING) {
            drawOverlay(canvas);
        }
        drawToast(canvas);

        postInvalidateOnAnimation();
    }

    private void updateGame(float dt) {
        float distanceGain = dt * (78f + speed * 100f);
        distance += distanceGain;
        if (activePowerUp == PowerUp.SCORE_BOOST && activePowerTimer > 0f) {
            scoreBonus += distanceGain;
        }
        updateActivePowerUp(dt);
        speed = Math.min(0.76f, 0.34f + distance / 3400f);
        trackOffset = (trackOffset + dt * speed * 1.25f) % 1f;
        updateLaneMotion(dt, 58f, 11f);
        characterClock += dt * (10.5f + speed * 7f);
        landingPulse = Math.max(0f, landingPulse - dt * 4.8f);
        flash = Math.max(0f, flash - dt * 3.2f);
        shake = Math.max(0f, shake - dt * 4.2f);

        if (jump > 0f || jumpVelocity > 0f) {
            jumpElapsed += dt;
            jump += jumpVelocity * dt;
            jumpVelocity -= 5.2f * dt;
            if (jump <= 0f) {
                jump = 0f;
                jumpVelocity = 0f;
                if (jumpElapsed > 0.18f) {
                    landingPulse = 1f;
                    emitLandingSparks();
                    playSfx(soundLanding, 0.42f, 1.18f);
                }
                jumpElapsed = 0f;
            }
        }
        slideTimer = Math.max(0f, slideTimer - dt);

        spawnTimer -= dt;
        if (spawnTimer <= 0f) {
            spawnWave();
            spawnTimer = Math.max(0.72f, 1.15f - speed * 0.36f);
        }

        for (Entity entity : entities) {
            entity.z += dt * speed;
            if (entity.passed) {
                continue;
            }

            if (entity.kind == Kind.COIN
                    && activePowerUp == PowerUp.MAGNET
                    && activePowerTimer > 0f
                    && entity.z > 0.46f) {
                entity.pull = Math.min(1f, entity.pull + dt * (2.8f + speed * 2.2f));
            }
            if (entity.z < 0.79f) {
                continue;
            }

            boolean sameLane = entity.lane == targetLane
                    && Math.abs(laneVisual - entity.lane) < 0.36f;

            if (entity.kind == Kind.COIN) {
                if ((sameLane && entity.z < 1.04f) || entity.pull >= 0.9f) {
                    collectCoin(entity);
                } else if (entity.z > 1.04f) {
                    entity.passed = true;
                }
                continue;
            }

            if (entity.z > 0.98f) {
                entity.passed = true;
                continue;
            }
            if (!sameLane) {
                continue;
            }

            boolean safe = (entity.kind == Kind.BARRIER && jump > 0.36f)
                    || (entity.kind == Kind.GATE && slideTimer > 0.08f);
            if (safe) {
                entity.passed = true;
                continue;
            }

            if (activePowerUp == PowerUp.SHIELD && shieldReady) {
                entity.passed = true;
                shieldReady = false;
                activePowerUp = PowerUp.NONE;
                flash = 1f;
                shake = 0.72f;
                emitShieldBurst();
                playSfx(soundShieldHit, 0.92f, 1f);
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                showToast("PERISAI MENYELAMATKAN!", 1.6f);
                continue;
            }

            entity.passed = true;
            endRun();
            break;
        }

        Iterator<Entity> iterator = entities.iterator();
        while (iterator.hasNext()) {
            Entity entity = iterator.next();
            if (entity.passed || entity.z > 1.2f) {
                iterator.remove();
            }
        }
    }

    private void updateLaneMotion(float dt, float stiffness, float damping) {
        float delta = targetLane - laneVisual;
        laneVelocity += delta * stiffness * dt;
        laneVelocity *= (float) Math.exp(-damping * dt);
        laneVisual += laneVelocity * dt;
        laneVisual = clamp(laneVisual, -1.08f, 1.08f);
        if (Math.abs(delta) < 0.002f && Math.abs(laneVelocity) < 0.01f) {
            laneVisual = targetLane;
            laneVelocity = 0f;
        }
    }

    private void updateSparks(float dt) {
        Iterator<Spark> iterator = sparks.iterator();
        while (iterator.hasNext()) {
            Spark spark = iterator.next();
            spark.x += spark.vx * dt;
            spark.y += spark.vy * dt;
            spark.vy += 220f * dt;
            spark.life -= dt * 2.4f;
            if (spark.life <= 0f) {
                iterator.remove();
            }
        }
    }

    private void spawnWave() {
        int obstacleLane = random.nextInt(3) - 1;
        float roll = random.nextFloat();
        Kind obstacle = roll < 0.38f
                ? Kind.BARRIER
                : roll < 0.68f ? Kind.GATE : Kind.TRAIN;
        entities.add(new Entity(obstacle, obstacleLane, 0f));

        int firstSafeLane = obstacleLane == -1 ? 0 : -1;
        int secondSafeLane = obstacleLane == 1 ? 0 : 1;
        int coinLane = random.nextBoolean() ? firstSafeLane : secondSafeLane;
        for (int i = 0; i < 4; i += 1) {
            entities.add(new Entity(Kind.COIN, coinLane, -0.08f - i * 0.105f));
        }
    }

    private void startGame() {
        targetLane = 0;
        laneVisual = 0f;
        laneVelocity = 0f;
        jump = 0f;
        jumpVelocity = 0f;
        jumpElapsed = 0f;
        slideTimer = 0f;
        characterClock = 0f;
        landingPulse = 0f;
        spawnTimer = 0.72f;
        speed = 0.34f;
        distance = 0f;
        scoreBonus = 0f;
        flash = 0f;
        shake = 0f;
        trackOffset = 0f;
        coins = 0;
        entities.clear();
        sparks.clear();
        mode = Mode.RUNNING;
        previousFrameTime = SystemClock.uptimeMillis();
        activateArmedPowerUp();
        playSfx(soundUiClick, 0.72f, 1f);
        startAmbience();
        announceForAccessibility("Metro Rush bermula");
    }

    private void resetAttractScene() {
        targetLane = 0;
        laneVisual = 0f;
        laneVelocity = 0f;
        speed = 0.34f;
        entities.clear();
        entities.add(new Entity(Kind.TRAIN, -1, 0.28f));
        entities.add(new Entity(Kind.BARRIER, 1, 0.5f));
        entities.add(new Entity(Kind.COIN, 0, 0.2f));
        entities.add(new Entity(Kind.COIN, 0, 0.34f));
        entities.add(new Entity(Kind.COIN, 0, 0.48f));
    }

    private void endRun() {
        mode = Mode.GAME_OVER;
        shake = 1f;
        int score = getScore();
        if (score > bestScore) {
            bestScore = score;
            preferences.edit().putInt(PREF_BEST_SCORE, bestScore).apply();
        }
        activePowerUp = PowerUp.NONE;
        activePowerTimer = 0f;
        shieldReady = false;
        persistEconomy();
        stopAmbience();
        playSfx(soundCrash, 1f, 0.92f);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        announceForAccessibility("Larian tamat. Skor " + score);
    }

    private int getScore() {
        return (int) (distance + scoreBonus) + coins * 35;
    }

    private void toggleMainAction() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
        } else if (mode == Mode.PAUSED) {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
            playSfx(soundUiClick, 0.64f, 1.08f);
            resumeAmbience();
        }
        invalidate();
    }

    private void togglePause() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
            pauseAmbience();
        } else if (mode == Mode.PAUSED) {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
            playSfx(soundUiClick, 0.64f, 1.08f);
            resumeAmbience();
        }
        invalidate();
    }

    private boolean ensureRunning() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
            return false;
        }
        return mode == Mode.RUNNING;
    }

    private void actLeft() {
        if (ensureRunning()) {
            targetLane = Math.max(-1, targetLane - 1);
        }
    }

    private void actRight() {
        if (ensureRunning()) {
            targetLane = Math.min(1, targetLane + 1);
        }
    }

    private void actJump() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.001f) {
            jumpVelocity = 2.35f;
            jumpElapsed = 0f;
            slideTimer = 0f;
            playSfx(soundJump, 0.72f, 1.08f);
        }
    }

    private void actSlide() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.12f) {
            slideTimer = SLIDE_DURATION;
            playSfx(soundUiClick, 0.52f, 0.82f);
        }
    }

    private void playSfx(int soundId, float volume, float rate) {
        if (soundEnabled) {
            soundPool.play(soundId, volume, volume, 1, 0, rate);
        }
    }

    private void startAmbience() {
        stopAmbience();
        if (soundEnabled) {
            ambienceStreamId = soundPool.play(soundAmbience, 0.16f, 0.16f, 0, -1, 1f);
        }
    }

    private void pauseAmbience() {
        if (ambienceStreamId != 0) {
            soundPool.pause(ambienceStreamId);
        }
    }

    private void resumeAmbience() {
        if (!soundEnabled) {
            return;
        }
        if (ambienceStreamId != 0) {
            soundPool.resume(ambienceStreamId);
        } else {
            startAmbience();
        }
    }

    private void stopAmbience() {
        if (ambienceStreamId != 0) {
            soundPool.stop(ambienceStreamId);
            ambienceStreamId = 0;
        }
    }

    private void updateActivePowerUp(float dt) {
        if (activePowerUp != PowerUp.MAGNET && activePowerUp != PowerUp.SCORE_BOOST) {
            return;
        }
        activePowerTimer = Math.max(0f, activePowerTimer - dt);
        if (activePowerTimer <= 0f) {
            String name = getPowerUpName(activePowerUp);
            activePowerUp = PowerUp.NONE;
            showToast(name + " TAMAT", 1.2f);
            playSfx(soundUiBack, 0.42f, 0.92f);
        }
    }

    private void collectCoin(Entity entity) {
        entity.passed = true;
        coins += 1;
        walletCoins += 1;
        if (activePowerUp == PowerUp.SCORE_BOOST && activePowerTimer > 0f) {
            scoreBonus += 35f;
        }
        preferences.edit().putInt(PREF_WALLET, walletCoins).apply();
        flash = 0.42f;
        emitCoinSparks(entity.pull > 0f ? Math.round(laneVisual) : entity.lane);
        playSfx(soundCoin, 0.68f, 0.96f + (coins % 4) * 0.035f);
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    private void activateArmedPowerUp() {
        activePowerUp = PowerUp.NONE;
        activePowerTimer = 0f;
        shieldReady = false;
        PowerUp selected = armedPowerUp;
        if (selected == PowerUp.NONE || getPowerUpStock(selected) <= 0) {
            armedPowerUp = PowerUp.NONE;
            persistEconomy();
            return;
        }

        changePowerUpStock(selected, -1);
        activePowerUp = selected;
        if (selected == PowerUp.SHIELD) {
            shieldReady = true;
        } else if (selected == PowerUp.MAGNET) {
            activePowerTimer = MAGNET_DURATION;
        } else if (selected == PowerUp.SCORE_BOOST) {
            activePowerTimer = SCORE_BOOST_DURATION;
        }
        armedPowerUp = PowerUp.NONE;
        persistEconomy();
        playSfx(soundPowerActivate, 0.82f, 1f);
        showToast(getPowerUpName(selected) + " AKTIF!", 1.7f);
    }

    private void buyPowerUp(PowerUp powerUp) {
        int cost = getPowerUpCost(powerUp);
        if (walletCoins < cost) {
            playSfx(soundUiError, 0.72f, 1f);
            showToast("SYILING TAK CUKUP", 1.5f);
            return;
        }
        walletCoins -= cost;
        changePowerUpStock(powerUp, 1);
        persistEconomy();
        playSfx(soundShopBuy, 0.82f, 1f);
        performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
        showToast(getPowerUpName(powerUp) + " DIBELI", 1.5f);
    }

    private void armPowerUp(PowerUp powerUp) {
        if (getPowerUpStock(powerUp) <= 0) {
            playSfx(soundUiError, 0.72f, 1f);
            showToast("BELI POWER-UP DULU", 1.5f);
            return;
        }
        armedPowerUp = powerUp;
        persistEconomy();
        playSfx(soundPowerReady, 0.82f, 1f);
        performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
        showToast(getPowerUpName(powerUp) + " DIPILIH", 1.5f);
    }

    private void openShop() {
        if (mode != Mode.IDLE && mode != Mode.GAME_OVER) {
            return;
        }
        shopReturnMode = mode;
        mode = Mode.SHOP;
        playSfx(soundUiClick, 0.65f, 1f);
        announceForAccessibility("Kedai power-up dibuka");
    }

    private void closeShop() {
        if (mode != Mode.SHOP) {
            return;
        }
        mode = shopReturnMode;
        playSfx(soundUiBack, 0.62f, 1f);
        announceForAccessibility("Kedai ditutup");
    }

    private int getPowerUpCost(PowerUp powerUp) {
        switch (powerUp) {
            case SHIELD:
                return SHIELD_COST;
            case MAGNET:
                return MAGNET_COST;
            case SCORE_BOOST:
                return SCORE_BOOST_COST;
            default:
                return 0;
        }
    }

    private int getPowerUpStock(PowerUp powerUp) {
        switch (powerUp) {
            case SHIELD:
                return shieldStock;
            case MAGNET:
                return magnetStock;
            case SCORE_BOOST:
                return scoreBoostStock;
            default:
                return 0;
        }
    }

    private void changePowerUpStock(PowerUp powerUp, int amount) {
        switch (powerUp) {
            case SHIELD:
                shieldStock = Math.max(0, shieldStock + amount);
                break;
            case MAGNET:
                magnetStock = Math.max(0, magnetStock + amount);
                break;
            case SCORE_BOOST:
                scoreBoostStock = Math.max(0, scoreBoostStock + amount);
                break;
            default:
                break;
        }
    }

    private String getPowerUpName(PowerUp powerUp) {
        switch (powerUp) {
            case SHIELD:
                return "PERISAI NEON";
            case MAGNET:
                return "MAGNET SYILING";
            case SCORE_BOOST:
                return "TURBO SKOR";
            default:
                return "TIADA";
        }
    }

    private PowerUp powerUpForIndex(int index) {
        if (index == 0) {
            return PowerUp.SHIELD;
        }
        if (index == 1) {
            return PowerUp.MAGNET;
        }
        return PowerUp.SCORE_BOOST;
    }

    private void persistEconomy() {
        preferences.edit()
                .putInt(PREF_WALLET, walletCoins)
                .putInt(PREF_SHIELD_STOCK, shieldStock)
                .putInt(PREF_MAGNET_STOCK, magnetStock)
                .putInt(PREF_SCORE_BOOST_STOCK, scoreBoostStock)
                .putString(PREF_ARMED_POWER_UP, armedPowerUp.name())
                .apply();
    }

    private static PowerUp readPowerUp(String stored) {
        if (stored == null) {
            return PowerUp.NONE;
        }
        try {
            return PowerUp.valueOf(stored);
        } catch (IllegalArgumentException ignored) {
            return PowerUp.NONE;
        }
    }

    private void showToast(String message, float duration) {
        toastMessage = message;
        toastTimer = duration;
    }

    private void drawGeneratedBackground(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        float screenRatio = width / (float) height;
        float imageRatio = backgroundBitmap.getWidth() / (float) backgroundBitmap.getHeight();

        if (imageRatio > screenRatio) {
            int sourceWidth = Math.round(backgroundBitmap.getHeight() * screenRatio);
            int left = (backgroundBitmap.getWidth() - sourceWidth) / 2;
            bitmapSource.set(left, 0, left + sourceWidth, backgroundBitmap.getHeight());
        } else {
            int sourceHeight = Math.round(backgroundBitmap.getWidth() / screenRatio);
            int top = Math.max(0, (backgroundBitmap.getHeight() - sourceHeight) / 2);
            bitmapSource.set(0, top, backgroundBitmap.getWidth(),
                    Math.min(backgroundBitmap.getHeight(), top + sourceHeight));
        }

        float parallax = mode == Mode.RUNNING ? (trackOffset - 0.5f) * 7f * density : 0f;
        bitmapTarget.set(-3f * density, -3f * density + parallax,
                width + 3f * density, height + 7f * density + parallax);
        canvas.drawBitmap(backgroundBitmap, bitmapSource, bitmapTarget, paint);

        paint.setShader(new LinearGradient(
                0f,
                0f,
                0f,
                height,
                new int[]{
                        withAlpha(COLOR_INK, 80),
                        withAlpha(COLOR_INK, 8),
                        withAlpha(COLOR_INK, 42),
                        withAlpha(COLOR_INK, 110)
                },
                new float[]{0f, 0.35f, 0.72f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);
    }

    private void drawTrackMotionLayer(Canvas canvas) {
        if (mode != Mode.RUNNING) {
            return;
        }

        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int lane = -1; lane <= 1; lane += 1) {
            for (int i = 0; i < 11; i += 1) {
                float phase = (trackOffset + i / 11f) % 1f;
                float z = 0.06f + pow(phase, 0.78f) * 0.98f;
                float zTail = Math.min(1.12f, z + 0.018f + z * 0.045f);
                float x = projectX(lane, z);
                float y = projectY(z);
                float tailX = projectX(lane, zTail);
                float tailY = projectY(zTail);
                int color = lane == 0 ? COLOR_YELLOW : lane < 0 ? COLOR_GREEN : COLOR_PINK;
                paint.setColor(withAlpha(color, (int) (28f + z * 92f)));
                paint.setStrokeWidth(getWidth() * (0.0022f + z * 0.0065f));
                canvas.drawLine(x, y, tailX, tailY, paint);
            }
        }
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawSpeedLayer(Canvas canvas, long now) {
        if (mode != Mode.RUNNING) {
            return;
        }
        int width = getWidth();
        int height = getHeight();
        float centerX = width / 2f;
        paint.setStrokeWidth(Math.max(2f, width * 0.004f));
        paint.setStrokeCap(Paint.Cap.ROUND);

        for (int i = 0; i < 12; i += 1) {
            float phase = ((now * 0.0005f * speed + i * 0.083f) % 1f);
            float y = height * (0.34f + phase * 0.62f);
            float spread = width * (0.06f + phase * 0.46f);
            int color = i % 3 == 0 ? COLOR_GREEN : i % 2 == 0 ? COLOR_YELLOW : COLOR_PINK;
            paint.setColor(withAlpha(color, (int) (35f + phase * 95f)));
            canvas.drawLine(centerX - spread, y, centerX - spread - width * 0.05f * phase,
                    y + height * 0.025f, paint);
            canvas.drawLine(centerX + spread, y, centerX + spread + width * 0.05f * phase,
                    y + height * 0.025f, paint);
        }
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawEntities(Canvas canvas, long now) {
        canvas.save();
        if (shake > 0f) {
            canvas.translate((float) Math.sin(now * 0.08f) * shake * 8f, 0f);
        }

        entities.sort(Comparator.comparingDouble(entity -> entity.z));
        for (Entity entity : entities) {
            if (entity.passed || entity.z < -0.02f || entity.z > 1.18f) {
                continue;
            }
            float x = projectX(entity.lane, entity.z);
            float y = projectY(entity.z);
            float scale = projectScale(entity.z);
            if (entity.kind == Kind.COIN && entity.pull > 0f) {
                float pullEase = entity.pull * entity.pull * (3f - 2f * entity.pull);
                float targetX = projectX(laneVisual, 0.88f);
                float targetY = getHeight() * 0.82f;
                x += (targetX - x) * pullEase;
                y += (targetY - y) * pullEase;
                scale *= 1f - pullEase * 0.24f;
            }
            switch (entity.kind) {
                case COIN:
                    drawCoin(canvas, x, y, scale, now);
                    break;
                case BARRIER:
                    drawBarrier(canvas, x, y, scale);
                    break;
                case GATE:
                    drawGate(canvas, x, y, scale);
                    break;
                case TRAIN:
                    drawTrainSprite(canvas, x, y, scale);
                    break;
            }
        }
        canvas.restore();

        if (flash > 0f) {
            paint.setColor(withAlpha(COLOR_YELLOW, (int) (flash * 72f)));
            canvas.drawRect(0f, 0f, getWidth(), getHeight(), paint);
        }
    }

    private void drawTrainSprite(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.255f * scale;
        float ratio = trainBitmap.getHeight() / (float) trainBitmap.getWidth();
        float height = width * ratio;

        paint.setColor(withAlpha(Color.BLACK, 120));
        canvas.drawOval(x - width * 0.36f, y - height * 0.08f,
                x + width * 0.36f, y + height * 0.08f, paint);

        bitmapTarget.set(x - width / 2f, y - height, x + width / 2f, y);
        paint.setAlpha(255);
        canvas.drawBitmap(trainBitmap, null, bitmapTarget, paint);
    }

    private void drawRunner(Canvas canvas, long now) {
        boolean jumping = jump > 0f || jumpVelocity > 0f;
        boolean sliding = !jumping && slideTimer > 0f;
        Bitmap sheet = sliding
                ? runnerSlideSheet
                : jumping ? runnerJumpSheet : runnerRunSheet;

        float sequencePosition;
        if (sliding) {
            sequencePosition = clamp(1f - slideTimer / SLIDE_DURATION, 0f, 0.999f)
                    * SPRITE_FRAME_COUNT;
        } else if (jumping) {
            sequencePosition = clamp(jumpElapsed / EXPECTED_JUMP_DURATION, 0f, 0.999f)
                    * SPRITE_FRAME_COUNT;
        } else {
            sequencePosition = characterClock;
        }
        int frame = ((int) Math.floor(sequencePosition)) % SPRITE_FRAME_COUNT;
        int nextFrame = (frame + 1) % SPRITE_FRAME_COUNT;
        float frameBlend = sequencePosition - (float) Math.floor(sequencePosition);

        int cellWidth = sheet.getWidth() / SPRITE_COLUMNS;
        int cellHeight = sheet.getHeight() / SPRITE_ROWS;
        float frameHeightRatio = sliding ? 0.225f : jumping ? 0.242f : 0.255f;
        float frameHeight = getHeight() * frameHeightRatio;
        float frameWidth = frameHeight * cellWidth / (float) cellHeight;
        float x = projectX(laneVisual, 0.88f);
        float groundY = getHeight() * 0.965f;
        float cadenceBob = mode == Mode.RUNNING && !jumping && !sliding
                ? (float) Math.sin(now * 0.0205f) * getHeight() * 0.0022f
                : 0f;
        float spriteBottom = groundY - jump * getHeight() * 0.235f + cadenceBob;

        float shadowLift = clamp(jump / 0.54f, 0f, 1f);
        float shadowWidth = frameWidth * (0.28f - shadowLift * 0.09f);
        float shadowHeight = getHeight() * (0.010f - shadowLift * 0.004f);
        paint.setColor(withAlpha(Color.BLACK, (int) (128f - shadowLift * 68f)));
        canvas.drawOval(x - shadowWidth, groundY - shadowHeight,
                x + shadowWidth, groundY + shadowHeight, paint);

        runnerTarget.set(
                x - frameWidth / 2f,
                spriteBottom - frameHeight,
                x + frameWidth / 2f,
                spriteBottom
        );

        float bankAngle = clamp(-laneVelocity * 3.15f, -8.5f, 8.5f);
        float landingSquash = landingPulse * 0.075f;
        canvas.save();
        canvas.rotate(bankAngle, x, groundY);
        canvas.scale(1f + landingSquash, 1f - landingSquash, x, groundY);

        if (mode == Mode.RUNNING) {
            float trailOffset = clamp(-laneVelocity * 4.5f * density, -16f * density,
                    16f * density);
            runnerTrailTarget.set(runnerTarget);
            runnerTrailTarget.offset(trailOffset, 5f * density);
            drawSpriteFrame(canvas, sheet, frame, runnerTrailTarget, 34);
        }

        drawSpriteFrame(canvas, sheet, frame, runnerTarget, 255);
        if (frameBlend > 0.62f) {
            int blendAlpha = (int) ((frameBlend - 0.62f) / 0.38f * 72f);
            drawSpriteFrame(canvas, sheet, nextFrame, runnerTarget, blendAlpha);
        }
        canvas.restore();
        drawRunnerPowerEffect(canvas, x, spriteBottom, frameWidth, frameHeight, now);
        paint.setAlpha(255);
    }

    private void drawRunnerPowerEffect(
            Canvas canvas,
            float x,
            float spriteBottom,
            float frameWidth,
            float frameHeight,
            long now
    ) {
        if (activePowerUp == PowerUp.SHIELD && shieldReady) {
            float pulse = 0.96f + (float) Math.sin(now * 0.009f) * 0.045f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(3f, getWidth() * 0.009f));
            paint.setColor(withAlpha(COLOR_CYAN, 150));
            paint.setShadowLayer(20f, 0f, 0f, COLOR_PURPLE);
            RectF aura = new RectF(
                    x - frameWidth * 0.38f * pulse,
                    spriteBottom - frameHeight * 0.86f * pulse,
                    x + frameWidth * 0.38f * pulse,
                    spriteBottom + frameHeight * 0.02f
            );
            canvas.drawOval(aura, paint);
            paint.clearShadowLayer();
            paint.setStyle(Paint.Style.FILL);
        } else if (activePowerUp == PowerUp.MAGNET && activePowerTimer > 0f) {
            for (int i = 0; i < 3; i += 1) {
                double angle = now * 0.006d + i * Math.PI * 2d / 3d;
                float orbitX = x + (float) Math.cos(angle) * frameWidth * 0.36f;
                float orbitY = spriteBottom - frameHeight * 0.47f
                        + (float) Math.sin(angle) * frameHeight * 0.12f;
                paint.setColor(withAlpha(COLOR_YELLOW, 205));
                paint.setShadowLayer(14f, 0f, 0f, COLOR_YELLOW);
                canvas.drawCircle(orbitX, orbitY, getWidth() * 0.012f, paint);
                paint.clearShadowLayer();
            }
        } else if (activePowerUp == PowerUp.SCORE_BOOST && activePowerTimer > 0f) {
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(getWidth() * 0.009f);
            for (int i = 0; i < 4; i += 1) {
                float offset = (i - 1.5f) * frameWidth * 0.13f;
                paint.setColor(withAlpha(i % 2 == 0 ? COLOR_YELLOW : COLOR_PINK, 150));
                canvas.drawLine(x + offset, spriteBottom - frameHeight * 0.12f,
                        x + offset * 1.16f, spriteBottom + frameHeight * 0.08f, paint);
            }
            paint.setStrokeCap(Paint.Cap.BUTT);
        }
    }

    private void drawSpriteFrame(
            Canvas canvas,
            Bitmap sheet,
            int frame,
            RectF target,
            int alpha
    ) {
        int cellWidth = sheet.getWidth() / SPRITE_COLUMNS;
        int cellHeight = sheet.getHeight() / SPRITE_ROWS;
        int column = frame % SPRITE_COLUMNS;
        int row = frame / SPRITE_COLUMNS;
        int right = column == SPRITE_COLUMNS - 1
                ? sheet.getWidth()
                : (column + 1) * cellWidth;
        int bottom = row == SPRITE_ROWS - 1
                ? sheet.getHeight()
                : (row + 1) * cellHeight;
        bitmapSource.set(column * cellWidth, row * cellHeight, right, bottom);
        paint.setAlpha(Math.max(0, Math.min(255, alpha)));
        canvas.drawBitmap(sheet, bitmapSource, target, paint);
    }

    private void drawCoin(Canvas canvas, float x, float y, float scale, long now) {
        float pulse = 0.94f + (float) Math.sin(now * 0.008f + y) * 0.06f;
        float radius = getWidth() * 0.042f * scale * pulse;

        paint.setShadowLayer(22f * scale, 0f, 0f, COLOR_YELLOW);
        paint.setColor(Color.rgb(255, 174, 0));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, radius * 0.16f));
        paint.setColor(Color.rgb(255, 245, 166));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_YELLOW);
        drawStar(canvas, x, y - radius, radius * 0.54f, radius * 0.24f, paint);
    }

    private void drawBarrier(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.18f * scale;
        float height = width * 0.58f;
        canvas.save();
        canvas.translate(x, y - height);

        paint.setColor(withAlpha(Color.BLACK, 120));
        canvas.drawOval(-width * 0.55f, height * 0.42f, width * 0.55f, height * 0.68f, paint);

        paint.setShader(new LinearGradient(
                0f,
                -height / 2f,
                0f,
                height / 2f,
                new int[]{Color.WHITE, Color.rgb(180, 180, 195)},
                null,
                Shader.TileMode.CLAMP
        ));
        RectF body = new RectF(-width / 2f, -height / 2f, width / 2f, height / 2f);
        canvas.drawRoundRect(body, height * 0.14f, height * 0.14f, paint);
        paint.setShader(null);

        canvas.save();
        canvas.clipRect(body);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(height * 0.32f);
        paint.setColor(Color.rgb(225, 48, 80));
        for (float offset = -width; offset < width; offset += width * 0.4f) {
            canvas.drawLine(offset, height / 2f, offset + width * 0.36f, -height / 2f, paint);
        }
        canvas.restore();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, width * 0.045f));
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(body, height * 0.14f, height * 0.14f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_YELLOW);
        canvas.drawCircle(-width * 0.4f, -height * 0.38f, width * 0.065f, paint);
        canvas.drawCircle(width * 0.4f, -height * 0.38f, width * 0.065f, paint);
        canvas.restore();
    }

    private void drawGate(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.2f * scale;
        float height = width * 0.92f;
        canvas.save();
        canvas.translate(x, y);

        paint.setColor(withAlpha(Color.BLACK, 110));
        canvas.drawOval(-width * 0.52f, -height * 0.05f,
                width * 0.52f, height * 0.13f, paint);

        paint.setShader(new LinearGradient(
                -width / 2f,
                0f,
                width / 2f,
                0f,
                new int[]{COLOR_PURPLE, COLOR_PANEL, COLOR_PURPLE},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(-width / 2f, -height, -width / 2f + width * 0.13f,
                0f, 8f, 8f, paint);
        canvas.drawRoundRect(width / 2f - width * 0.13f, -height, width / 2f,
                0f, 8f, 8f, paint);
        RectF header = new RectF(-width / 2f, -height, width / 2f, -height * 0.66f);
        canvas.drawRoundRect(header, 10f, 10f, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, width * 0.04f));
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(header, 10f, 10f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(Math.max(7f, width * 0.13f));
        textPaint.setColor(COLOR_YELLOW);
        canvas.drawText("TUNDUK", 0f, -height * 0.76f, textPaint);
        canvas.restore();
    }

    private void emitCoinSparks(int lane) {
        float x = projectX(lane, 0.9f);
        float y = projectY(0.9f);
        for (int i = 0; i < 10; i += 1) {
            float angle = (float) (Math.PI * 2d * i / 10d);
            float force = 70f + random.nextFloat() * 100f;
            sparks.add(new Spark(x, y, (float) Math.cos(angle) * force,
                    (float) Math.sin(angle) * force - 70f));
        }
    }

    private void emitLandingSparks() {
        float x = projectX(laneVisual, 0.88f);
        float y = getHeight() * 0.955f;
        for (int i = 0; i < 12; i += 1) {
            float direction = i % 2 == 0 ? -1f : 1f;
            float speedX = direction * (45f + random.nextFloat() * 135f);
            float speedY = -35f - random.nextFloat() * 95f;
            sparks.add(new Spark(x, y, speedX, speedY));
        }
    }

    private void emitShieldBurst() {
        float x = projectX(laneVisual, 0.88f);
        float y = getHeight() * 0.82f;
        for (int i = 0; i < 24; i += 1) {
            float angle = (float) (Math.PI * 2d * i / 24d);
            float force = 125f + random.nextFloat() * 220f;
            sparks.add(new Spark(x, y, (float) Math.cos(angle) * force,
                    (float) Math.sin(angle) * force, COLOR_CYAN));
        }
    }

    private void drawSparks(Canvas canvas) {
        for (Spark spark : sparks) {
            paint.setColor(withAlpha(spark.color, (int) (spark.life * 255f)));
            canvas.drawCircle(spark.x, spark.y, 3f * density * spark.life, paint);
        }
    }

    private void drawHeaderAndHud(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        textPaint.setTextSize(width * 0.11f);
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(8f, 5f, 7f, COLOR_PURPLE);
        canvas.drawText("METRO RUSH", width / 2f, height * 0.085f, textPaint);
        textPaint.clearShadowLayer();

        float gap = width * 0.018f;
        float margin = width * 0.035f;
        float cardWidth = (width - margin * 2f - gap * 2f) / 3f;
        float cardHeight = height * 0.068f;
        float top = height * 0.105f;

        drawHudCard(canvas, new RectF(margin, top, margin + cardWidth, top + cardHeight),
                "SKOR", String.format(Locale.US, "%06d", getScore()), false);
        drawHudCard(canvas, new RectF(margin + cardWidth + gap, top,
                        margin + cardWidth * 2f + gap, top + cardHeight),
                "SYILING", String.valueOf(coins), true);
        drawHudCard(canvas, new RectF(margin + cardWidth * 2f + gap * 2f, top,
                        width - margin, top + cardHeight),
                "TERBAIK", String.format(Locale.US, "%06d", bestScore), false);
        drawActivePowerUpHud(canvas);
    }

    private void drawHudCard(Canvas canvas, RectF bounds, String label, String value, boolean coin) {
        paint.setColor(withAlpha(Color.rgb(8, 5, 15), 218));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(Color.rgb(145, 72, 214));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(COLOR_GREEN);
        textPaint.setTextSize(bounds.height() * 0.22f);
        canvas.drawText(label, bounds.centerX(), bounds.top + bounds.height() * 0.31f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setColor(COLOR_CREAM);
        textPaint.setTextSize(bounds.height() * 0.39f);
        String shownValue = coin ? "★ " + value : value;
        canvas.drawText(shownValue, bounds.centerX(), bounds.top + bounds.height() * 0.8f, textPaint);
    }

    private void drawActivePowerUpHud(Canvas canvas) {
        if (activePowerUp == PowerUp.NONE || mode == Mode.SHOP) {
            return;
        }
        float width = getWidth() * 0.46f;
        float height = getHeight() * 0.044f;
        RectF pill = new RectF(
                getWidth() / 2f - width / 2f,
                getHeight() * 0.181f,
                getWidth() / 2f + width / 2f,
                getHeight() * 0.181f + height
        );
        paint.setColor(withAlpha(COLOR_INK, 224));
        canvas.drawRoundRect(pill, height / 2f, height / 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(activePowerUp == PowerUp.SHIELD ? COLOR_CYAN : COLOR_YELLOW);
        canvas.drawRoundRect(pill, height / 2f, height / 2f, paint);
        paint.setStyle(Paint.Style.FILL);

        RectF icon = new RectF(
                pill.left + height * 0.08f,
                pill.top + height * 0.08f,
                pill.left + height * 0.92f,
                pill.bottom - height * 0.08f
        );
        drawPowerUpIcon(canvas, activePowerUp, icon, 255);

        String status;
        if (activePowerUp == PowerUp.SHIELD) {
            status = "PERISAI • 1 HIT";
        } else {
            status = getPowerUpName(activePowerUp) + " • "
                    + String.format(Locale.US, "%.1fs", activePowerTimer);
        }
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(height * 0.34f);
        textPaint.setColor(COLOR_CREAM);
        drawTextCentered(canvas, status, icon.right + height * 0.14f, pill.centerY(), textPaint);
    }

    private void drawPowerUpIcon(
            Canvas canvas,
            PowerUp powerUp,
            RectF target,
            int alpha
    ) {
        int index = Math.max(0, powerUp.ordinal() - 1);
        int cellWidth = powerUpIconSheet.getWidth() / 3;
        int right = index == 2 ? powerUpIconSheet.getWidth() : (index + 1) * cellWidth;
        bitmapSource.set(index * cellWidth, 0, right, powerUpIconSheet.getHeight());
        paint.setAlpha(alpha);
        canvas.drawBitmap(powerUpIconSheet, bitmapSource, target, paint);
        paint.setAlpha(255);
    }

    private void drawActionButtons(Canvas canvas) {
        float size = getWidth() * 0.105f;
        float margin = getWidth() * 0.035f;
        float top = getHeight() * 0.02f;

        pauseButton.set(margin, top, margin + size, top + size);
        soundButton.set(getWidth() - margin - size, top, getWidth() - margin, top + size);
        drawMiniButton(canvas, pauseButton, mode == Mode.PAUSED ? "▶" : "Ⅱ",
                mode == Mode.RUNNING || mode == Mode.PAUSED);
        drawMiniButton(canvas, soundButton, soundEnabled ? "SFX" : "OFF", true);
    }

    private void drawMiniButton(Canvas canvas, RectF bounds, String label, boolean enabled) {
        paint.setColor(withAlpha(COLOR_INK, enabled ? 225 : 150));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(enabled ? COLOR_PINK : withAlpha(COLOR_PINK, 80));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(bounds.width() * (label.length() > 2 ? 0.24f : 0.38f));
        textPaint.setColor(enabled ? COLOR_YELLOW : withAlpha(COLOR_YELLOW, 90));
        drawTextCentered(canvas, label, bounds.centerX(), bounds.centerY(), textPaint);
    }

    private void drawSwipeHint(Canvas canvas) {
        if (mode == Mode.RUNNING || mode == Mode.SHOP) {
            return;
        }
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(getWidth() * 0.038f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 180));
        canvas.drawText("SWIPE  ←  ↑  ↓  →", getWidth() / 2f, getHeight() * 0.965f, textPaint);
    }

    private void drawOverlay(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        paint.setColor(withAlpha(Color.BLACK, 98));
        canvas.drawRect(0f, 0f, width, height, paint);

        float cardWidth = width * 0.84f;
        float cardHeight = height * 0.28f;
        RectF card = new RectF(
                (width - cardWidth) / 2f,
                height * 0.54f,
                (width + cardWidth) / 2f,
                height * 0.54f + cardHeight
        );

        paint.setColor(withAlpha(COLOR_INK, 242));
        paint.setShadowLayer(30f, 0f, 16f, Color.BLACK);
        canvas.drawRoundRect(card, 24f, 24f, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(card, 24f, 24f, paint);
        paint.setStrokeWidth(2f);
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(card.left + 8f, card.top + 8f, card.right - 8f,
                card.bottom - 8f, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);

        String kicker;
        String title;
        String description;
        String action;
        if (mode == Mode.GAME_OVER) {
            kicker = "LARIAN TAMAT";
            title = "PECAHKAN REKOD!";
            description = "Swipe lebih awal dan fokus pada lorong selamat";
            action = "CUBA LAGI";
        } else if (mode == Mode.PAUSED) {
            kicker = "DIJEDA";
            title = "TARIK NAFAS.";
            description = "Ketuk untuk kembali ke landasan";
            action = "SAMBUNG";
        } else {
            kicker = "ENDLESS RUNNER 3 LORONG";
            title = "BERSEDIA MELURU?";
            description = "Kutip syiling • Elak tren • Teruskan larian";
            action = "MULA";
        }

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.06f);
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText(kicker, card.centerX(), card.top + cardHeight * 0.16f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(Math.min(cardHeight * 0.17f, cardWidth * 0.09f));
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(5f, 4f, 5f, COLOR_PURPLE);
        canvas.drawText(title, card.centerX(), card.top + cardHeight * 0.38f, textPaint);
        textPaint.clearShadowLayer();

        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.045f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 190));
        canvas.drawText(description, card.centerX(), card.top + cardHeight * 0.55f, textPaint);

        RectF actionButton = new RectF(
                card.centerX() - cardWidth * 0.27f,
                card.top + cardHeight * 0.66f,
                card.centerX() + cardWidth * 0.27f,
                card.top + cardHeight * 0.88f
        );
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(actionButton.left + 7f, actionButton.top + 8f,
                actionButton.right + 7f, actionButton.bottom + 8f, 13f, 13f, paint);
        paint.setColor(COLOR_YELLOW);
        canvas.drawRoundRect(actionButton, 13f, 13f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(actionButton, 13f, 13f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(actionButton.height() * 0.44f);
        textPaint.setColor(COLOR_INK);
        drawTextCentered(canvas, action, actionButton.centerX(), actionButton.centerY(), textPaint);

        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            shopButton.set(
                    card.centerX() - cardWidth * 0.31f,
                    card.bottom + height * 0.012f,
                    card.centerX() + cardWidth * 0.31f,
                    card.bottom + height * 0.064f
            );
            paint.setColor(withAlpha(COLOR_INK, 238));
            canvas.drawRoundRect(shopButton, 16f, 16f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3f);
            paint.setColor(COLOR_CYAN);
            canvas.drawRoundRect(shopButton, 16f, 16f, paint);
            paint.setStyle(Paint.Style.FILL);
            textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(shopButton.height() * 0.34f);
            textPaint.setColor(COLOR_CREAM);
            drawTextCentered(canvas, "KEDAI   ★ " + walletCoins,
                    shopButton.centerX(), shopButton.centerY(), textPaint);

            if (armedPowerUp != PowerUp.NONE) {
                textPaint.setTextSize(width * 0.026f);
                textPaint.setColor(COLOR_GREEN);
                canvas.drawText("DIPILIH: " + getPowerUpName(armedPowerUp),
                        shopButton.centerX(), shopButton.bottom + height * 0.023f, textPaint);
            }
        } else {
            shopButton.setEmpty();
        }
    }

    private void drawShopOverlay(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        paint.setColor(withAlpha(Color.BLACK, 178));
        canvas.drawRect(0f, 0f, width, height, paint);

        RectF panel = new RectF(
                width * 0.035f,
                height * 0.16f,
                width * 0.965f,
                height * 0.925f
        );
        paint.setColor(withAlpha(COLOR_INK, 248));
        paint.setShadowLayer(32f, 0f, 14f, Color.BLACK);
        canvas.drawRoundRect(panel, 28f, 28f, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(panel, 28f, 28f, paint);
        paint.setStrokeWidth(2f);
        paint.setColor(COLOR_CYAN);
        canvas.drawRoundRect(panel.left + 8f, panel.top + 8f,
                panel.right - 8f, panel.bottom - 8f, 22f, 22f, paint);
        paint.setStyle(Paint.Style.FILL);

        float closeSize = width * 0.105f;
        shopCloseButton.set(
                panel.left + width * 0.026f,
                panel.top + width * 0.026f,
                panel.left + width * 0.026f + closeSize,
                panel.top + width * 0.026f + closeSize
        );
        drawMiniButton(canvas, shopCloseButton, "‹", true);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        textPaint.setTextSize(width * 0.085f);
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(7f, 4f, 5f, COLOR_PURPLE);
        canvas.drawText("KEDAI KUASA", panel.centerX(), height * 0.218f, textPaint);
        textPaint.clearShadowLayer();

        RectF wallet = new RectF(
                panel.centerX() - width * 0.22f,
                height * 0.232f,
                panel.centerX() + width * 0.22f,
                height * 0.278f
        );
        paint.setColor(withAlpha(COLOR_PANEL, 238));
        canvas.drawRoundRect(wallet, wallet.height() / 2f, wallet.height() / 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(COLOR_YELLOW);
        canvas.drawRoundRect(wallet, wallet.height() / 2f, wallet.height() / 2f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(wallet.height() * 0.39f);
        textPaint.setColor(COLOR_CREAM);
        drawTextCentered(canvas, "DOMPET  ★ " + walletCoins,
                wallet.centerX(), wallet.centerY(), textPaint);

        float cardTop = height * 0.31f;
        float cardHeight = height * 0.155f;
        float cardGap = height * 0.018f;
        drawShopCard(canvas, 0, PowerUp.SHIELD,
                "Sekat satu pelanggaran", SHIELD_COST,
                new RectF(panel.left + width * 0.025f, cardTop,
                        panel.right - width * 0.025f, cardTop + cardHeight));
        cardTop += cardHeight + cardGap;
        drawShopCard(canvas, 1, PowerUp.MAGNET,
                "Tarik syiling semua lorong • 20s", MAGNET_COST,
                new RectF(panel.left + width * 0.025f, cardTop,
                        panel.right - width * 0.025f, cardTop + cardHeight));
        cardTop += cardHeight + cardGap;
        drawShopCard(canvas, 2, PowerUp.SCORE_BOOST,
                "Gandakan skor semasa • 25s", SCORE_BOOST_COST,
                new RectF(panel.left + width * 0.025f, cardTop,
                        panel.right - width * 0.025f, cardTop + cardHeight));

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(width * 0.036f);
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText("CARA GUNA", panel.centerX(), height * 0.842f, textPaint);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(width * 0.029f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 220));
        canvas.drawText("BELI → tekan GUNA → kembali dan MULA larian",
                panel.centerX(), height * 0.868f, textPaint);
        canvas.drawText("Satu power-up aktif untuk setiap larian",
                panel.centerX(), height * 0.893f, textPaint);
    }

    private void drawShopCard(
            Canvas canvas,
            int index,
            PowerUp powerUp,
            String description,
            int cost,
            RectF card
    ) {
        boolean selected = armedPowerUp == powerUp;
        int stock = getPowerUpStock(powerUp);
        int accent = powerUp == PowerUp.SHIELD
                ? COLOR_CYAN
                : powerUp == PowerUp.MAGNET ? COLOR_PINK : COLOR_YELLOW;

        paint.setShader(new LinearGradient(
                card.left,
                card.top,
                card.right,
                card.bottom,
                new int[]{withAlpha(COLOR_PANEL, 248), withAlpha(COLOR_NIGHT, 248)},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(card, 20f, 20f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(selected ? 4f : 2.5f);
        paint.setColor(selected ? COLOR_GREEN : withAlpha(accent, 190));
        canvas.drawRoundRect(card, 20f, 20f, paint);
        paint.setStyle(Paint.Style.FILL);

        float iconSize = card.height() * 0.66f;
        RectF icon = new RectF(
                card.left + card.width() * 0.025f,
                card.centerY() - iconSize / 2f,
                card.left + card.width() * 0.025f + iconSize,
                card.centerY() + iconSize / 2f
        );
        paint.setColor(withAlpha(COLOR_INK, 150));
        canvas.drawRoundRect(icon, 18f, 18f, paint);
        drawPowerUpIcon(canvas, powerUp, icon, 255);

        float buttonWidth = card.width() * 0.225f;
        float buttonLeft = card.right - card.width() * 0.025f - buttonWidth;
        float buttonHeight = card.height() * 0.30f;
        shopBuyButtons[index].set(
                buttonLeft,
                card.top + card.height() * 0.15f,
                card.right - card.width() * 0.025f,
                card.top + card.height() * 0.15f + buttonHeight
        );
        shopUseButtons[index].set(
                buttonLeft,
                card.bottom - card.height() * 0.15f - buttonHeight,
                card.right - card.width() * 0.025f,
                card.bottom - card.height() * 0.15f
        );

        float textLeft = icon.right + card.width() * 0.025f;
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(card.height() * 0.082f);
        textPaint.setColor(accent);
        canvas.drawText(getPowerUpName(powerUp), textLeft,
                card.top + card.height() * 0.29f, textPaint);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(card.height() * 0.055f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 205));
        canvas.drawText(description, textLeft,
                card.top + card.height() * 0.49f, textPaint);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(card.height() * 0.068f);
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText("MILIK: " + stock, textLeft,
                card.top + card.height() * 0.72f, textPaint);

        drawShopActionButton(canvas, shopBuyButtons[index], "BELI ★" + cost,
                walletCoins >= cost, COLOR_YELLOW);
        drawShopActionButton(canvas, shopUseButtons[index], selected ? "DIPILIH" : "GUNA",
                stock > 0, selected ? COLOR_GREEN : COLOR_CYAN);
    }

    private void drawShopActionButton(
            Canvas canvas,
            RectF bounds,
            String label,
            boolean enabled,
            int accent
    ) {
        paint.setColor(enabled ? accent : withAlpha(COLOR_PANEL, 210));
        canvas.drawRoundRect(bounds, 13f, 13f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(enabled ? COLOR_INK : withAlpha(COLOR_CREAM, 80));
        canvas.drawRoundRect(bounds, 13f, 13f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(bounds.height() * 0.31f);
        textPaint.setColor(enabled ? COLOR_INK : withAlpha(COLOR_CREAM, 110));
        drawTextCentered(canvas, label, bounds.centerX(), bounds.centerY(), textPaint);
    }

    private void drawToast(Canvas canvas) {
        if (toastTimer <= 0f || toastMessage.isEmpty()) {
            return;
        }
        float height = getHeight() * 0.052f;
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(height * 0.34f);
        float width = Math.min(getWidth() * 0.82f,
                textPaint.measureText(toastMessage) + getWidth() * 0.12f);
        float centerY = mode == Mode.SHOP ? getHeight() * 0.292f : getHeight() * 0.92f;
        RectF toast = new RectF(
                getWidth() / 2f - width / 2f,
                centerY - height / 2f,
                getWidth() / 2f + width / 2f,
                centerY + height / 2f
        );
        int alpha = (int) (clamp(toastTimer * 2.5f, 0f, 1f) * 242f);
        paint.setColor(withAlpha(COLOR_INK, alpha));
        canvas.drawRoundRect(toast, height / 2f, height / 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(withAlpha(COLOR_YELLOW, alpha));
        canvas.drawRoundRect(toast, height / 2f, height / 2f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(withAlpha(COLOR_CREAM, alpha));
        drawTextCentered(canvas, toastMessage, toast.centerX(), toast.centerY(), textPaint);
    }

    private float projectX(float lane, float z) {
        float depth = clamp(z, 0f, 1.15f);
        float spread = getWidth() * (0.048f + 0.27f * pow(depth, 1.3f));
        return getWidth() / 2f + lane * spread;
    }

    private float projectY(float z) {
        float depth = clamp(z, 0f, 1.15f);
        float horizon = getHeight() * 0.35f;
        return horizon + pow(depth, 1.62f) * (getHeight() * 0.94f - horizon);
    }

    private float projectScale(float z) {
        float depth = clamp(z, 0f, 1.15f);
        return 0.18f + 1.08f * pow(depth, 1.42f);
    }

    private static float pow(float value, float power) {
        return (float) Math.pow(value, power);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(
                Math.max(0, Math.min(255, alpha)),
                Color.red(color),
                Color.green(color),
                Color.blue(color)
        );
    }

    private void drawStar(
            Canvas canvas,
            float x,
            float y,
            float outerRadius,
            float innerRadius,
            Paint starPaint
    ) {
        path.reset();
        for (int i = 0; i < 10; i += 1) {
            float radius = i % 2 == 0 ? outerRadius : innerRadius;
            double angle = -Math.PI / 2d + i * Math.PI / 5d;
            float px = x + (float) Math.cos(angle) * radius;
            float py = y + (float) Math.sin(angle) * radius;
            if (i == 0) {
                path.moveTo(px, py);
            } else {
                path.lineTo(px, py);
            }
        }
        path.close();
        canvas.drawPath(path, starPaint);
    }

    private static void drawTextCentered(
            Canvas canvas,
            String text,
            float centerX,
            float centerY,
            Paint paint
    ) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float baseline = centerY - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText(text, centerX, baseline, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = event.getX();
                touchStartY = event.getY();
                trackingTouch = true;
                return true;
            case MotionEvent.ACTION_UP:
                if (!trackingTouch) {
                    return false;
                }
                trackingTouch = false;
                handleTouchRelease(event.getX(), event.getY());
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                trackingTouch = false;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void handleTouchRelease(float endX, float endY) {
        if (pauseButton.contains(endX, endY)
                && (mode == Mode.RUNNING || mode == Mode.PAUSED)) {
            togglePause();
            return;
        }
        if (soundButton.contains(endX, endY)) {
            soundEnabled = !soundEnabled;
            preferences.edit().putBoolean(PREF_SOUND, soundEnabled).apply();
            if (soundEnabled) {
                playSfx(soundUiClick, 0.64f, 1f);
                if (mode == Mode.RUNNING) {
                    startAmbience();
                }
            } else {
                stopAmbience();
            }
            invalidate();
            return;
        }

        if (mode == Mode.SHOP) {
            handleShopTap(endX, endY);
            return;
        }
        if ((mode == Mode.IDLE || mode == Mode.GAME_OVER)
                && shopButton.contains(endX, endY)) {
            openShop();
            return;
        }

        float dx = endX - touchStartX;
        float dy = endY - touchStartY;
        float threshold = 34f * density;

        if (mode != Mode.RUNNING) {
            toggleMainAction();
            return;
        }

        if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) {
            actJump();
            return;
        }
        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx < 0f) {
                actLeft();
            } else {
                actRight();
            }
        } else if (dy < 0f) {
            actJump();
        } else {
            actSlide();
        }
    }

    private void handleShopTap(float x, float y) {
        if (shopCloseButton.contains(x, y)) {
            closeShop();
            return;
        }
        for (int index = 0; index < 3; index += 1) {
            PowerUp powerUp = powerUpForIndex(index);
            if (shopBuyButtons[index].contains(x, y)) {
                buyPowerUp(powerUp);
                invalidate();
                return;
            }
            if (shopUseButtons[index].contains(x, y)) {
                armPowerUp(powerUp);
                invalidate();
                return;
            }
        }
    }
}
