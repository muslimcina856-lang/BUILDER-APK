## v1.0.4 settings/build/runtime deep audit

| Risiko / error | Punca | Pembaikan 1.0.4 |
|---|---|---|
| `settings.gradle.kts: Unresolved reference: Properties` | settings script bergantung pada type Java yang gagal di-resolve pada runner | buang `Properties` sepenuhnya; parse `flutter.sdk` manual + env/PATH fallback |
| `local.properties` runner hanya ada `sdk.dir` | builder tidak menjamin `flutter.sdk` | fallback `FLUTTER_ROOT`, `FLUTTER_HOME`, dan canonical executable `flutter` dalam `PATH` |
| UI menganggap command berjaya terlalu awal | MethodChannel acceptance bukan Baileys acknowledgement | Dart tunggu `command.ack` / `command.error` dengan timeout |
| Native event channel mati tetapi UI tunggu 45–120s | tiada `onError`/`onDone` failure propagation | fail semua completer/pending command serta-merta |
| settings lama/corrupt boleh crash Dropdown/Slider | persisted value di luar item/range UI | normalize delay/retry/maxTargets/auto-reply sebelum digunakan |
| history boleh rosak jika proses mati ketika write | tulis terus ke fail akhir | write temp + flush + rename; corrupt file dikuarantin |
| `stop` semasa retry masih boleh menghantar lagi | stop flag tidak diperiksa pada setiap retry/backoff | interruptible backoff + stop check sebelum setiap percubaan |
| logout berlumba dengan `saveCreds` | credential callback async boleh menulis semula auth selepas delete | serialize `saveCreds`; logout await chain sebelum delete |
| auto-reply socket lama terlepas ke socket baru | async handler tidak mengikat identiti connection | socket epoch/identity check sebelum dan selepas delay |
| media hilang antara picker dan stat | path cache/content sementara | stat dibungkus try/catch + filename basename/control-char hardening |
| dependency staging sensitif gangguan registry | npm fetch tanpa retry/timeout eksplisit | fetch retries + min/max backoff + 120s fetch timeout |
| ikon lama / adaptive double-square | foreground tidak dipisah daripada background | master + density + round + transparent adaptive foreground dijana semula |
| background ketika startup masih boleh membuka socket | `init` Node dahulu auto-connect sebelum Flutter sempat menilai lifecycle | `init` kini socket-free; Flutter connect hanya jika foreground |
| env Flutter SDK stale boleh menutup fallback sah | candidate pertama dipilih sebelum divalidasi | semua candidate divalidasi dan candidate sah pertama digunakan |
| transient GitHub/CDN mematikan native build | runtime Node hanya satu download attempt | 3 attempts + backoff + size/ZIP/version/ABI validation |
| EventChannel map key pelik boleh meletup pada cast | `Map<String,dynamic>.from`/`cast` menganggap semua key String | conversion hanya menerima String key |
| process mati antara history flush dan rename | `.tmp` lengkap dibiarkan tetapi loader hanya baca main file | recover `.tmp` bila main tiada; stale temp dibersihkan |

### Residual yang sengaja tidak disembunyikan

- `pubspec.lock` belum boleh dijana dalam environment audit ini kerana Flutter SDK penuh tidak tersedia.
- `package-lock.json` belum boleh dijana dalam environment audit ini kerana registry npm tidak boleh dicapai; direct dependency dan commit `libsignal` tetap dipin tepat.
- Node.js Mobile 18.20.4 ialah runtime legacy yang sesuai untuk POC/sideload tetapi native 16 KB page-size dan evolusi Baileys/WhatsApp kekal risiko upstream.
- Release Gradle masih menggunakan debug signing untuk memudahkan build ujian; gunakan keystore release sebenar sebelum pengedaran.

## v1.0.3 Gradle Kotlin DSL correction

The Android application script previously used `java.io.ByteArrayOutputStream()` inside the Kotlin DSL. With the Android plugin applied, the generated `java` extension can shadow the root Java package in that scope, producing `Unresolved reference: io` and a cascade of false `unreachable code` diagnostics. The build now imports `ByteArrayOutputStream` and uses the simple class name. Source validation explicitly guards against reintroducing the shadow-prone form.

# Root Fix Audit — 2026-08-07

| Masalah | Punca | Pembaikan 1.0.2 |
|---|---|---|
| `launch_background.xml` AAPT failure | raw hex digunakan pada `android:drawable` | guna `@color/launch_background` |
| `libnode.so` missing semasa CMake | package `node_flutter` tidak membawa runtime native | fork plugin lokal + Gradle auto-prepare Node Mobile 18.20.4 |
| CI bergantung `.pub-cache` | native plugin datang dari hosted pub package | dependency `path: packages/node_flutter` |
| Node headers boleh hilang selepas `.so` ditampal | CMake perlukan `include/node` juga | runtime validator wajib semak headers + semua ABI |
| `libnode.so` link tetapi boleh tak masuk APK | imported CMake library tidak cukup sebagai jaminan packaging semua AGP | `jniLibs.srcDirs = ['libnode/bin']` + `pickFirst` native libs |
| Native C++ runtime mismatch | STL/NDK bridge tidak diselaraskan | NDK 28.2.13676358 + `-DANDROID_STL=c++_shared` + ABI filters |
| `engine.booted` boleh hilang | EventChannel listener belum attach ketika Node boot cepat | bounded native pending-event buffer, flush pada `onListen` |
| App boleh crash sebelum UI bila native load gagal | `System.loadLibrary` dibuat dalam companion initializer | lazy native load dalam startup thread + `engine.error` |
| `libsignal` transitif berubah ikut HEAD GitHub | Baileys 6.7.8 dependency asal tidak pin commit dalam package spec | npm override kepada codeload commit `83a3e3a...` daripada yarn.lock rasmi v6.7.8 |
| Baileys 7 boleh tersalah aktif pada Node18 | helper lama menyalin manifest 7 terus | `use_baileys7.*` kini refuse dengan error |
| `await Nodejs.start()` boleh tersangkut | upstream result dihantar selepas `node::Start()` tamat | local Kotlin returns selepas thread launch; JS readiness melalui event |
| Flutter → Node command tidak sampai | JS bridge hanya register `_EVENTS_` | Dart wrap `{tag,message}` dan hantar ke `_EVENTS_` |
| `process._linkedBinding("flutter_bridge")` boleh gagal pada Node18 | `NAPI_MODULE_X` Node18 mengabaikan flag `NM_F_LINKED` | daftar `napi_module` sendiri sebelum `node::Start()` |
| Race handle native ketika command pertama | Flutter main thread boleh queue semasa Node thread mendaftar channel | publish/read `uv_async_t*` di bawah mutex yang sama |
| App upgrade boleh guna bridge JS lama | builtin bridge pernah disalin sekali ke private storage | refresh builtin bridge setiap process start |
| Command async boleh bertindih | EventEmitter tidak await Promise listener | `commandChain` serialize semua command |
| UI ready terlalu awal | hanya tunggu `engine.booted` | tunggu `engine.booted`, hantar `init`, kemudian tunggu `engine.ready` |
| Native startup failure hanya timeout | tiada immediate Dart failure | `engine.error`/`engine.nativeExit` fail pending startup completer |
| Node assets boleh basi | duplicate root + Android assets | root `nodejs-project/` satu source; generated assets semasa Gradle build |
| `node_modules` tiada dalam generic CI | setup manual tidak dijalankan | `prepareEarlCastNodeProject` menjalankan npm semasa Gradle build |
| First launch boleh gagal pada hidden npm asset | AAPT boleh abaikan dot-files tetapi `file.list` asal masih boleh menyenaraikannya | staging buang semua dot-prefixed file/dir sebelum fingerprint + file list |
| Runner Node terlalu lama memberi error lewat | npm staging tiada preflight version | Gradle/build scripts fail-fast jika host Node <18 |
| First launch copy lambat berulang | recursive assets copy tanpa marker/list | generated `file.list` + non-hidden SHA-256 asset marker |
| security patch boleh dilangkau | npm install luar pipeline | postinstall + explicit Gradle `--verify` |
| Gradle/AGP/Kotlin warning lama | toolchain lama | Gradle 8.14.5 / AGP 8.11.1 / Kotlin 2.2.20 |
| Gradle distribution tidak disahkan | bootstrap downloader biasa | pinned SHA-256 dalam properties + launcher |
| group spinner boleh kekal | `command.error(getGroups)` tidak reset state | reset `groupsLoading` pada failed action |
| setup boleh menimpa root fixes | `flutter create` dijalankan bila wrapper dianggap kurang | bootstrap sekarang validate-only, tidak regenerate scaffold |

## Yang bukan boleh “dipatch” dalam source app semata-mata

- Node.js Mobile 18.20.4 published binary belum menyelesaikan keperluan 16 KB page alignment untuk semua target Play Store moden.
- Baileys ialah protokol WhatsApp Web tidak rasmi dan perubahan server boleh memecahkan keserasian.
- Baileys 7 memerlukan runtime Node lebih baharu daripada official Node Mobile release yang digunakan dalam build standard ini.

Ketiga-tiga perkara ini dilabel sebagai limit upstream, bukan dianggap selesai secara palsu.
