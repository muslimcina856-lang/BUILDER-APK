pluginManagement {
    fun decodeLocalPropertyPath(raw: String): String = raw.trim()
        .replace("\\\\", "\\")
        .replace("\\ ", " ")
        .replace("\\:", ":")
        .replace("\\=", "=")
        .replace("\\#", "#")
        .replace("\\!", "!")

    fun flutterSdkFromLocalProperties(): String? {
        val localPropertiesFile = file("local.properties")
        if (!localPropertiesFile.isFile) return null

        var value: String? = null
        localPropertiesFile.forEachLine { rawLine ->
            if (value == null) {
                val line = rawLine.trim()
                if (line.isNotEmpty() &&
                    !line.startsWith("#") &&
                    !line.startsWith("!") &&
                    line.startsWith("flutter.sdk=")) {
                    value = decodeLocalPropertyPath(line.substringAfter("flutter.sdk="))
                }
            }
        }
        return value?.takeIf { it.isNotBlank() }
    }

    fun flutterSdkFromPath(): String? {
        val path = System.getenv("PATH") ?: return null
        val separator = System.getProperty("path.separator") ?: ":"
        val windows = (System.getProperty("os.name") ?: "")
            .lowercase()
            .contains("windows")
        val executable = if (windows) "flutter.bat" else "flutter"

        return path.split(separator)
            .asSequence()
            .map { it.trim().trim('"') }
            .filter { it.isNotEmpty() }
            .map { file("$it/$executable") }
            .firstOrNull { it.isFile }
            ?.canonicalFile
            ?.parentFile
            ?.parentFile
            ?.absolutePath
    }

    val flutterSdkCandidates = listOfNotNull(
        System.getenv("FLUTTER_ROOT")?.trim()?.takeIf { it.isNotEmpty() },
        System.getenv("FLUTTER_HOME")?.trim()?.takeIf { it.isNotEmpty() },
        flutterSdkFromLocalProperties(),
        flutterSdkFromPath(),
    ).distinct()

    val flutterSdkPath = flutterSdkCandidates.firstOrNull { candidate ->
        file("$candidate/packages/flutter_tools/gradle").isDirectory
    } ?: error(
        "Flutter SDK tidak dapat dikesan atau semua candidate tidak sah. " +
            "Set FLUTTER_ROOT/FLUTTER_HOME, pastikan flutter ada dalam PATH, " +
            "atau tetapkan flutter.sdk dalam local.properties."
    )

    val flutterGradleBuild = file("$flutterSdkPath/packages/flutter_tools/gradle")

    includeBuild(flutterGradleBuild)

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}

rootProject.name = "earlcast"
include(":app")
