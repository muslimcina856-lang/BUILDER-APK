const fs = require('fs');
const path = require('path');
const pino = require('pino');
const { Boom } = require('@hapi/boom');

let baileysModulePromise;

async function loadBaileysModule() {
  if (!baileysModulePromise) {
    baileysModulePromise = (async () => {
      let loaded;
      try {
        loaded = require('baileys');
      } catch (error) {
        if (error?.code !== 'ERR_REQUIRE_ESM') throw error;
        loaded = await import('baileys');
      }

      const defaultExport = loaded?.default;
      const combined = defaultExport && typeof defaultExport === 'object'
        ? { ...defaultExport, ...loaded }
        : loaded;
      const makeWASocket = typeof defaultExport === 'function'
        ? defaultExport
        : combined?.makeWASocket || combined?.default || combined;

      if (typeof makeWASocket !== 'function') {
        throw new Error('Export makeWASocket Baileys tidak dijumpai.');
      }

      return { ...combined, makeWASocket };
    })();
  }
  return baileysModulePromise;
}

const normalizeUserJid = (jid, jidNormalizedUser) => {
  if (typeof jidNormalizedUser === 'function') return jidNormalizedUser(jid || '');
  return String(jid || '').replace(/:\d+@/, '@');
};

const { CampaignQueue } = require('./campaign_queue.cjs');
const { sendContent } = require('./media.cjs');
const {
  ensureDirectory,
  normalizeError,
  safeRemoveDirectory,
  sanitizePhoneNumber,
  sleep,
} = require('./utils.cjs');

class WhatsAppEngine {
  constructor({ emit }) {
    this.emit = emit;
    this.logger = pino({ level: 'silent' });
    this.sock = null;
    this.authState = null;
    this.saveCreds = null;
    this.baileys = null;
    this.disconnectReason = { loggedOut: 401 };
    this.initialized = false;
    this.shuttingDown = false;
    this.manualLogout = false;
    this.dataDir = '';
    this.cacheDir = '';
    this.authDir = '';
    this.autoReply = { enabled: false, text: '' };
    this.autoReplied = new Set();
    this.reconnectTimer = null;
    this.connectPromise = null;
    this.socketEpoch = 0;
    this.autoReplyChain = Promise.resolve();
    this.credsSaveChain = Promise.resolve();
    this.queue = new CampaignQueue({
      emit: this.emit,
      sendTarget: (jid, text, attachments) =>
        this._sendContentToTarget(jid, text, attachments),
    });
  }

  async handleCommand(command) {
    const action = String(command?.action || '');
    const payload = command?.payload || {};

    switch (action) {
      case 'init':
        return this.init(payload);
      case 'connect':
        return this.connect();
      case 'pair':
        return this.pair(payload.phoneNumber);
      case 'logout':
        return this.logout();
      case 'getGroups':
        return this.getGroups();
      case 'startCampaign':
        return this.startCampaign(payload);
      case 'pauseCampaign':
        this.queue.pause();
        return;
      case 'resumeCampaign':
        this.queue.resume();
        return;
      case 'stopCampaign':
        this.queue.stop();
        return;
      case 'setAutoReply':
        return this.setAutoReply(payload);
      case 'shutdown':
        return this.shutdown();
      default:
        throw new Error(`Arahan tidak dikenali: ${action}`);
    }
  }

  async init(payload) {
    this.dataDir = ensureDirectory(path.join(String(payload?.dataDir || process.cwd()), 'earlcast'));
    this.cacheDir = ensureDirectory(String(payload?.cacheDir || path.join(this.dataDir, 'cache')));
    this.authDir = ensureDirectory(path.join(this.dataDir, 'wa-session'));
    this.initialized = true;
    this.shuttingDown = false;
    // Do not open WhatsApp from init. Flutter decides whether the app is
    // actually foreground before issuing `connect`, closing a lifecycle race
    // where startup could finish after Android had already backgrounded us.
    this.emit('engine.ready', {
      nodeVersion: process.version,
      dataDir: this.dataDir,
    });
  }

  async connect() {
    this._assertInitialized();
    this.shuttingDown = false;
    if (this.sock) return;
    if (this.connectPromise) return this.connectPromise;

    const pending = this._createSocket();
    this.connectPromise = pending;
    try {
      await pending;
    } finally {
      if (this.connectPromise === pending) this.connectPromise = null;
    }
  }

  async pair(rawPhoneNumber) {
    this._assertInitialized();
    const phoneNumber = sanitizePhoneNumber(rawPhoneNumber);
    if (phoneNumber.length < 8 || phoneNumber.length > 15) throw new Error('Nombor telefon tidak sah.');

    this.emit('connection.status', { status: 'pairing' });
    await this._closeSocket();
    await this.connect();

    if (this.authState?.creds?.registered) {
      this.emit('notice', {
        message: 'Sesi sedia ada telah berdaftar. Logout dahulu untuk pair nombor lain.',
      });
      return;
    }

    await sleep(1400);
    if (!this.sock) throw new Error('Socket belum tersedia untuk pairing.');
    const code = String(await this.sock.requestPairingCode(phoneNumber) || '').trim();
    if (!code) throw new Error('WhatsApp tidak memulangkan pairing code. Cuba semula.');
    this.emit('pairing.code', { code });
  }

  async getGroups() {
    this._assertConnected();
    const allGroups = await this.sock.groupFetchAllParticipating();
    const normalizeJid = this.baileys?.jidNormalizedUser;
    const ownJid = normalizeUserJid(this.sock.user?.id || '', normalizeJid);
    const groups = Object.values(allGroups || {})
      .filter((group) => String(group?.id || '').endsWith('@g.us'))
      .map((group) => {
        const ownParticipant = Array.isArray(group.participants)
          ? group.participants.find((participant) =>
              normalizeUserJid(participant.id || '', normalizeJid) === ownJid)
          : null;
        return {
          id: group.id,
          name: group.subject || 'Group tanpa nama',
          participantCount: Array.isArray(group.participants)
            ? group.participants.length
            : 0,
          isAdmin: Boolean(ownParticipant?.admin),
        };
      });

    groups.sort((a, b) => a.name.localeCompare(b.name));
    this.emit('groups.list', { groups });
    return groups;
  }

  async startCampaign(payload) {
    this._assertConnected();
    this.queue
      .start(payload)
      .catch((error) => {
        this.emit('campaign.error', { message: normalizeError(error) });
      });
  }

  setAutoReply(payload) {
    this.autoReply = {
      enabled: Boolean(payload?.enabled) && String(payload?.text || '').trim().length > 0,
      text: String(payload?.text || '').trim().slice(0, 1000),
    };
    if (!this.autoReply.enabled) this.autoReplied.clear();
    this.emit('autoreply.status', {
      enabled: this.autoReply.enabled,
      repliedCount: this.autoReplied.size,
    });
  }

  async logout() {
    this.manualLogout = true;
    this.queue.stop();
    try {
      try {
        if (this.sock) await this.sock.logout();
      } catch (_) {
        // Session tetap dibuang secara lokal di bawah.
      }
      await this._closeSocket();
      try {
        await this.credsSaveChain;
      } catch (_) {}
      this.credsSaveChain = Promise.resolve();
      safeRemoveDirectory(this.authDir);
      ensureDirectory(this.authDir);
      this.authState = null;
      this.saveCreds = null;
      this.autoReplied.clear();
      this.emit('connection.status', { status: 'loggedOut' });
    } finally {
      this.manualLogout = false;
    }
  }

  async shutdown() {
    this.shuttingDown = true;
    this.queue.stop();
    clearTimeout(this.reconnectTimer);
    await this._closeSocket();
    this.emit('connection.status', { status: 'disconnected' });
  }

  async _createSocket() {
    this._assertInitialized();
    const epoch = ++this.socketEpoch;
    this.emit('connection.status', { status: 'connecting' });

    const baileys = await loadBaileysModule();
    this.baileys = baileys;
    const {
      Browsers,
      DisconnectReason,
      fetchLatestBaileysVersion,
      makeCacheableSignalKeyStore,
      makeWASocket,
      useMultiFileAuthState,
    } = baileys;
    this.disconnectReason = DisconnectReason || { loggedOut: 401 };

    if (typeof useMultiFileAuthState !== 'function') {
      throw new Error('useMultiFileAuthState Baileys tidak tersedia.');
    }

    const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
    this.authState = state;
    this.saveCreds = saveCreds;

    let version;
    try {
      if (typeof fetchLatestBaileysVersion !== 'function') throw new Error('Version lookup unavailable');
      const latest = await Promise.race([
        fetchLatestBaileysVersion(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Version lookup timeout')), 5000)),
      ]);
      version = latest?.version;
    } catch (_) {
      version = undefined;
    }

    const auth = {
      creds: state.creds,
      keys: typeof makeCacheableSignalKeyStore === 'function'
        ? makeCacheableSignalKeyStore(state.keys, this.logger)
        : state.keys,
    };

    const socketOptions = {
      auth,
      logger: this.logger,
      browser: Browsers?.ubuntu
        ? Browsers.ubuntu('EarlCast')
        : ['EarlCast', 'Chrome', '1.0.0'],
      markOnlineOnConnect: false,
      syncFullHistory: false,
      shouldSyncHistoryMessage: () => false,
      generateHighQualityLinkPreview: false,
      shouldIgnoreJid: (jid) =>
        String(jid || '').endsWith('@broadcast') ||
        String(jid || '').endsWith('@newsletter'),
      getMessage: async () => undefined,
    };
    if (version) socketOptions.version = version;

    if (this.shuttingDown || epoch !== this.socketEpoch) return;

    const socket = makeWASocket(socketOptions);
    this.sock = socket;
    socket.ev.on('creds.update', () => {
      if (this.sock !== socket) return;
      // Serialize credential writes. Logout waits for this chain before deleting
      // wa-session, preventing a late saveCreds() from recreating stale auth.
      this.credsSaveChain = this.credsSaveChain
        .then(() => saveCreds())
        .catch((error) => {
          this.emit('engine.log', {
            level: 'error',
            message: `Gagal simpan credential WhatsApp: ${normalizeError(error)}`,
          });
        });
    });
    socket.ev.on('connection.update', (update) => {
      this._handleConnectionUpdate(socket, update).catch((error) => {
        this.emit('connection.status', {
          status: 'error',
          message: normalizeError(error),
        });
      });
    });
    socket.ev.on('messages.upsert', (upsert) => {
      if (this.sock !== socket) return;
      this.autoReplyChain = this.autoReplyChain
        .then(() => this._handleIncomingMessages(socket, upsert))
        .catch((error) => {
          this.emit('engine.log', {
            level: 'warn',
            message: `Auto-reply handler gagal: ${normalizeError(error)}`,
          });
        });
    });
  }

  async _handleConnectionUpdate(socket, update) {
    if (this.sock !== socket) return;
    const { connection, lastDisconnect } = update || {};
    if (connection === 'connecting') {
      this.emit('connection.status', { status: 'connecting' });
      return;
    }

    if (connection === 'open') {
      const user = this.sock?.user || {};
      this.emit('connection.status', {
        status: 'connected',
        accountName: user.name || 'WhatsApp',
        accountNumber: String(user.id || '').split(':')[0].split('@')[0],
      });
      return;
    }

    if (connection !== 'close') return;

    const statusCode = this._disconnectStatusCode(lastDisconnect?.error);
    const loggedOut = statusCode === this.disconnectReason.loggedOut;
    this.sock = null;

    if (loggedOut || this.manualLogout) {
      this.emit('connection.status', { status: 'loggedOut' });
      return;
    }

    if (this.shuttingDown) {
      this.emit('connection.status', { status: 'disconnected' });
      return;
    }

    this.emit('connection.status', {
      status: 'disconnected',
      message: `Sambungan terputus${statusCode ? ` (${statusCode})` : ''}. Cuba semula...`,
    });
    clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => {
      if (!this.shuttingDown && !this.sock) {
        this.connect().catch((error) => {
          this.emit('connection.status', {
            status: 'error',
            message: normalizeError(error),
          });
        });
      }
    }, 2200);
  }

  async _handleIncomingMessages(socket, upsert) {
    if (!this.autoReply.enabled || !this.autoReply.text || this.sock !== socket) return;
    // Defense-in-depth untuk advisory GHSA-qvv5-jq5g-4cgg.
    if (upsert?.requestId) return;
    if (upsert?.type !== 'notify') return;

    for (const message of Array.isArray(upsert.messages) ? upsert.messages : []) {
      const jid = String(message?.key?.remoteJid || '');
      if (!jid.endsWith('@s.whatsapp.net')) continue;
      if (message?.key?.fromMe || !message?.message) continue;
      if (this.autoReplied.has(jid)) continue;

      // Elak Set berkembang tanpa had jika aplikasi dibiarkan terbuka lama.
      while (this.autoReplied.size >= 5000) {
        const oldest = this.autoReplied.values().next().value;
        if (!oldest) break;
        this.autoReplied.delete(oldest);
      }
      this.autoReplied.add(jid);
      await sleep(650);
      if (this.sock !== socket) {
        this.autoReplied.delete(jid);
        return;
      }
      try {
        await socket.sendMessage(jid, { text: this.autoReply.text });
        this.emit('autoreply.status', {
          enabled: true,
          repliedCount: this.autoReplied.size,
        });
      } catch (error) {
        this.autoReplied.delete(jid);
        this.emit('engine.log', {
          level: 'warn',
          message: `Auto-reply gagal: ${normalizeError(error)}`,
        });
      }
    }
  }

  async _sendContentToTarget(jid, text, attachments) {
    this._assertConnected();
    return sendContent(this.sock, jid, text, attachments);
  }

  async _closeSocket() {
    clearTimeout(this.reconnectTimer);
    this.socketEpoch += 1;

    // Batalkan secara logik percubaan socket yang sedang menunggu auth/version.
    // Tunggu ia selesai supaya resume/pair seterusnya tidak mewarisi
    // connectPromise lama yang sudah invalid.
    const pendingConnect = this.connectPromise;
    if (pendingConnect) {
      try {
        await pendingConnect;
      } catch (_) {}
    }
    this.connectPromise = null;

    const current = this.sock;
    this.sock = null;
    if (!current) return;
    try {
      current.ev?.removeAllListeners?.();
    } catch (_) {}
    try {
      current.ws?.close?.();
    } catch (_) {}
    await sleep(100);
  }

  _disconnectStatusCode(error) {
    try {
      return new Boom(error).output.statusCode;
    } catch (_) {
      return error?.output?.statusCode || 0;
    }
  }

  _assertInitialized() {
    if (!this.initialized) throw new Error('Engine belum diinisialisasi.');
  }

  _assertConnected() {
    this._assertInitialized();
    if (!this.sock?.user) throw new Error('WhatsApp belum connected.');
  }
}

module.exports = { WhatsAppEngine };
