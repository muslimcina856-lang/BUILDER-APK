const fs = require('fs');
const path = require('path');

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms || 0)));
}

function sanitizePhoneNumber(value) {
  return String(value || '').replace(/[^0-9]/g, '');
}

function ensureDirectory(directoryPath) {
  fs.mkdirSync(directoryPath, { recursive: true });
  return directoryPath;
}

function safeRemoveDirectory(directoryPath) {
  if (!directoryPath || !fs.existsSync(directoryPath)) return;
  fs.rmSync(directoryPath, { recursive: true, force: true });
}

function normalizeError(error) {
  if (!error) return 'Ralat tidak diketahui';
  if (typeof error === 'string') return error;
  if (error.message) return String(error.message);
  try {
    return JSON.stringify(error);
  } catch (_) {
    return String(error);
  }
}

function safeBasename(filePath, fallback = 'file.bin') {
  try {
    const name = path.basename(String(filePath || ''))
      .replace(/[\u0000-\u001F\u007F]/g, '_')
      .trim()
      .slice(0, 240);
    return name || fallback;
  } catch (_) {
    return fallback;
  }
}

function uniqueTargets(targets, hardLimit = 50) {
  const seen = new Set();
  const output = [];
  for (const target of Array.isArray(targets) ? targets : []) {
    const id = String(target?.id || '');
    if (!id.endsWith('@g.us') || seen.has(id)) continue;
    seen.add(id);
    output.push({
      id,
      name: String(target?.name || 'Group tanpa nama'),
    });
    if (output.length >= hardLimit) break;
  }
  return output;
}

module.exports = {
  sleep,
  sanitizePhoneNumber,
  ensureDirectory,
  safeRemoveDirectory,
  normalizeError,
  safeBasename,
  uniqueTargets,
};
