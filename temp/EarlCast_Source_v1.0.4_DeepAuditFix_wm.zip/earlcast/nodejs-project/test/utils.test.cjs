const test = require('node:test');
const assert = require('node:assert/strict');
const { safeBasename, sanitizePhoneNumber, uniqueTargets } = require('../engine/utils.cjs');
const { clampInt, isPermanentError } = require('../engine/campaign_queue.cjs');

test('sanitizePhoneNumber keeps digits only', () => {
  assert.equal(sanitizePhoneNumber('+60 12-345 6789'), '60123456789');
});


test('safeBasename strips control characters and path segments', () => {
  assert.equal(safeBasename('/tmp/folder/report\nfinal.pdf'), 'report_final.pdf');
  assert.equal(safeBasename(''), 'file.bin');
});

test('uniqueTargets only keeps unique group JIDs and obeys hard limit', () => {
  const values = uniqueTargets([
    { id: '1@g.us', name: 'A' },
    { id: '1@g.us', name: 'Duplicate' },
    { id: '2@s.whatsapp.net', name: 'Private' },
    { id: '3@g.us', name: 'B' },
  ], 2);
  assert.deepEqual(values, [
    { id: '1@g.us', name: 'A' },
    { id: '3@g.us', name: 'B' },
  ]);
});

test('queue clamps unsafe settings', () => {
  assert.equal(clampInt(100, 1, 50, 30), 50);
  assert.equal(clampInt(100, 1500, 60000, 2500), 1500);
  assert.equal(clampInt('bad', 1, 50, 30), 30);
});

test('permanent error classifier detects authorization failures', () => {
  assert.equal(isPermanentError('403 forbidden'), true);
  assert.equal(isPermanentError('temporary timeout'), false);
});

test('queue stop prevents a retry from sending again', async () => {
  const { CampaignQueue } = require('../engine/campaign_queue.cjs');
  let attempts = 0;
  const events = [];
  const queue = new CampaignQueue({
    emit: (type, payload) => events.push({ type, payload }),
    sendTarget: async () => {
      attempts += 1;
      throw new Error('temporary timeout');
    },
  });

  const run = queue.start({
    targets: [{ id: '1@g.us', name: 'A' }],
    text: 'hello',
    attachments: [],
    retryCount: 2,
    delayMs: 1500,
    maxTargets: 1,
  });
  await new Promise((resolve) => setTimeout(resolve, 50));
  queue.stop();
  const result = await run;

  assert.equal(attempts, 1);
  assert.equal(result.completed, 0);
  assert.equal(events.at(-1).type, 'campaign.stopped');
});
