#!/usr/bin/env python3
"""Dependency-free source validation for EarlCast root-fixed Android source."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = ROOT / "nodejs-project"
LOCAL_PLUGIN = ROOT / "packages" / "node_flutter"


def run(command: list[str], cwd: Path = ROOT) -> None:
    print(">", " ".join(command))
    subprocess.run(command, cwd=cwd, check=True)


def require_file(relative: str) -> Path:
    path = ROOT / relative
    if not path.is_file():
        raise RuntimeError(f"Fail wajib tiada: {relative}")
    return path


def require_contains(relative: str, *needles: str) -> None:
    text = require_file(relative).read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            raise RuntimeError(f"'{needle}' tidak dijumpai dalam {relative}")


def require_not_contains(relative: str, *needles: str) -> None:
    text = require_file(relative).read_text(encoding="utf-8")
    for needle in needles:
        if needle in text:
            raise RuntimeError(f"'{needle}' tidak sepatutnya wujud dalam {relative}")


def validate_json() -> None:
    for file in sorted(NODE.glob("package*.json")):
        json.loads(file.read_text(encoding="utf-8"))
        print(f"[ok] JSON {file.relative_to(ROOT)}")


def validate_xml() -> None:
    for file in sorted((ROOT / "android").rglob("*.xml")):
        ET.parse(file)
    print("[ok] Android XML")


def validate_android_resources() -> None:
    for file in sorted((ROOT / "android" / "app" / "src" / "main" / "res").rglob("*.xml")):
        content = file.read_text(encoding="utf-8")
        if re.search(r'android:drawable\s*=\s*["\']#', content):
            raise RuntimeError(
                f"Raw color tidak sah untuk android:drawable dalam {file.relative_to(ROOT)}"
            )
    require_contains(
        "android/app/src/main/res/values/colors.xml",
        'name="launch_background"',
    )
    print("[ok] Android drawable references")


def validate_secrets() -> None:
    patterns = {
        "Telegram bot token": re.compile(r"\b\d{7,12}:[A-Za-z0-9_-]{30,}\b"),
        "Generic private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    }
    excluded = {"SOURCE_MANIFEST.sha256"}
    for file in ROOT.rglob("*"):
        if not file.is_file() or file.name in excluded or ".git" in file.parts:
            continue
        if file.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".jar", ".zip", ".so"}:
            continue
        try:
            text = file.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for label, pattern in patterns.items():
            if pattern.search(text):
                raise RuntimeError(f"{label} dijumpai dalam {file.relative_to(ROOT)}")
    print("[ok] Imbasan secret asas")


def validate_icons() -> None:
    required = [
        ROOT / "assets/icon/app_icon.png",
        ROOT / "assets/icon/app_icon_foreground.png",
        ROOT / "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png",
    ]
    for file in required:
        if not file.is_file() or file.stat().st_size < 100:
            raise RuntimeError(f"Icon tidak sah: {file.relative_to(ROOT)}")
    print("[ok] Icon assets")


def validate_root_fixes() -> None:
    require_contains(
        "pubspec.yaml",
        "path: packages/node_flutter",
        "version: 1.0.4+4",
    )
    if (ROOT / "android/app/src/main/assets/nodejs-project").exists():
        raise RuntimeError(
            "Salinan statik android/app/src/main/assets/nodejs-project masih wujud; "
            "root nodejs-project mesti menjadi satu-satunya source of truth."
        )

    require_contains(
        "android/app/build.gradle.kts",
        'tasks.register("prepareEarlCastNodeProject")',
        'sourceSets.getByName("main").assets.srcDir(generatedNodeAssetsRoot)',
        '"--registry=https://registry.npmjs.org/"',
        '"--ignore-scripts"',
        '"--fetch-retries=3"',
        '"--fetch-timeout=120000"',
        '"process.versions.node"',
        "hostNodeMajor < 18",
        'commandLine(node, verifier.absolutePath)',
        '"--verify"',
        'dependsOn(prepareEarlCastNodeProject)',
        'ndkVersion = "28.2.13676358"',
        'earlcast_assets.sha256',
        'file.list',
        "part.startsWith('.')",
        "import java.io.ByteArrayOutputStream",
        "val nodeVersionOutput = ByteArrayOutputStream()",
    )
    require_not_contains(
        "android/app/build.gradle.kts",
        "java.io.ByteArrayOutputStream()",
    )
    require_contains(
        "android/settings.gradle.kts",
        'System.getenv("FLUTTER_ROOT")',
        'System.getenv("FLUTTER_HOME")',
        'line.startsWith("flutter.sdk=")',
        'fun flutterSdkFromPath()',
        'System.getenv("PATH")',
        '?.canonicalFile',
        'val flutterSdkCandidates = listOfNotNull(',
        'flutterSdkCandidates.firstOrNull { candidate ->',
        'id("com.android.application") version "8.11.1"',
        'id("org.jetbrains.kotlin.android") version "2.2.20"',
    )
    require_not_contains(
        "android/settings.gradle.kts",
        "val properties = Properties()",
        "java.util.Properties()",
        "import java.util.Properties",
    )
    require_contains(
        "android/gradle/wrapper/gradle-wrapper.properties",
        "gradle-8.14.5-bin.zip",
        "distributionSha256Sum=6f74b601422d6d6fc4e1f9a1ab6522f642c2fdcbc15ae33ebd30ba3d7198e854",
    )
    require_file("android/gradlew")
    require_file("android/gradlew.bat")

    require_contains(
        "packages/node_flutter/pubspec.yaml",
        "version: 0.0.4+earlcast5",
    )

    require_contains(
        "packages/node_flutter/android/build.gradle",
        "nodeMobileVersion = '18.20.4'",
        "nodejs-mobile-v${nodeMobileVersion}-android.zip",
        "outputs.upToDateWhen { nodeRuntimeReady() }",
        "bin/arm64-v8a/libnode.so",
        "bin/armeabi-v7a/libnode.so",
        "bin/x86_64/libnode.so",
        "include/node/node.h",
        "jniLibs.srcDirs = ['libnode/bin']",
        "pickFirsts += ['**/libnode.so', '**/libc++_shared.so']",
        "ndkVersion '28.2.13676358'",
        "abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86_64'",
        "arguments '-DANDROID_STL=c++_shared'",
        "task.name.contains('NativeLib')",
        "NODE_MAJOR_VERSION 18",
        "NODE_MINOR_VERSION 20",
        "NODE_PATCH_VERSION 4",
        "attempt <= 3",
        "retrying in",
        "after 3 attempts",
    )
    require_contains(
        "packages/node_flutter/android/CMakeLists.txt",
        "libnode/include/node",
        'libnode/bin/${ANDROID_ABI}/libnode.so',
    )

    require_contains(
        "packages/node_flutter/android/src/main/cpp/flutter-bridge.cpp",
        "void flutter_register_linked_module()",
        "napi_module_register(&module);",
        "NM_F_LINKED",
    )
    require_not_contains(
        "packages/node_flutter/android/src/main/cpp/flutter-bridge.cpp",
        "NAPI_MODULE_X(",
    )
    native_cpp = require_file(
        "packages/node_flutter/android/src/main/cpp/native-lib.cpp"
    ).read_text(encoding="utf-8")
    linked_index = native_cpp.find("flutter_register_linked_module();")
    node_start_cpp_index = native_cpp.find("return static_cast<jint>(node::Start(")
    if linked_index < 0 or node_start_cpp_index < 0 or linked_index > node_start_cpp_index:
        raise RuntimeError("Linked Node-API module mesti didaftarkan sebelum node::Start().")

    kotlin = require_file(
        "packages/node_flutter/android/src/main/kotlin/org/binbard/node_flutter/NodeFlutterPlugin.kt"
    ).read_text(encoding="utf-8")
    result_index = kotlin.find("result.success(null)", kotlin.find("private fun startNodeProject"))
    node_start_index = kotlin.find("startNodeWithArguments(", kotlin.find("private fun startNodeProject"))
    if result_index < 0 or node_start_index < 0 or result_index > node_start_index:
        raise RuntimeError("Node start bridge masih menunggu node::Start selesai sebelum pulang ke Flutter.")
    if 'val channel = call.argument<String>("channel") ?: "_EVENTS_"' not in kotlin:
        raise RuntimeError("Native bridge tidak menerima fixed _EVENTS_ channel.")
    if "pendingMessages" not in kotlin or "MAX_PENDING_MESSAGES" not in kotlin:
        raise RuntimeError("Native event buffer untuk startup race tiada.")
    if "ensureNativeLibrariesLoaded()" not in kotlin or 'System.loadLibrary("node")' not in kotlin:
        raise RuntimeError("Native library loader tidak dihardening dalam startup thread.")
    if "bridgeTarget.deleteRecursively()" not in kotlin:
        raise RuntimeError("Builtin JS bridge tidak disegarkan pada setiap process start.")
    for required in (
        "nodeRuntimeConsumed",
        '"reusedRuntime":true',
        "isSafeAssetRelativePath",
        "safeTargetFile",
        "earlcast_assets.sha256",
        "node_modules/baileys/lib/index.js",
    ):
        if required not in kotlin:
            raise RuntimeError(f"Kotlin native hardening hilang: {required}")
    general_copy = kotlin.find('for (relative in fileList.filter')
    marker_copy = kotlin.find(
        'copyAssetFile(\n                    "nodejs-project/earlcast_assets.sha256"',
        general_copy,
    )
    if marker_copy < 0 or general_copy < 0 or marker_copy < general_copy:
        raise RuntimeError("Asset completion marker mesti disalin selepas Node files lain.")

    require_contains(
        "packages/node_flutter/lib/node_flutter.dart",
        "jsonEncode(<String, dynamic>{",
        "'_EVENTS_'",
        "'tag': tag",
        "'message': message",
    )
    require_not_contains(
        "packages/node_flutter/lib/node_flutter.dart",
        "Map<String, dynamic>.from(event as Map)",
    )
    require_contains(
        "lib/services/node_engine_service.dart",
        "const Duration(seconds: 120)",
        "const Duration(seconds: 60)",
        "await Nodejs.start();",
        "_readyCompleter",
        "_pendingCommands",
        "command.ack",
        "command.error",
        "if (_disposed) throw StateError",
        "_failPendingCommands",
        "onDone: ()",
        "Channel event Node.js telah ditutup",
    )
    require_contains(
        "lib/controllers/app_controller.dart",
        "failedAction == 'getGroups'",
        "failedAction == 'startCampaign'",
        "failedAction == 'pair' || failedAction == 'connect'",
        "SettingsStore.normalize(value)",
        "_settingsSaveTail",
        "_settingsRevision",
        "selectedGroupIds.removeWhere",
        "].take(100).toList",
        "safeString(event.payload['message']",
        "safeInt(event.payload['success']",
        "_foregroundSuspended = true",
        "if (!_foregroundSuspended) {",
        "if (!_engine.isStarted) return;",
    )
    require_contains(
        "lib/services/settings_store.dart",
        "allowedDelayMs",
        "_closestAllowedDelay",
        ".clamp(0, 2)",
        ".clamp(5, 50)",
        "_normalizeMaxTargets",
    )
    require_contains(
        "lib/utils/safe_values.dart",
        "String safeString",
        "int safeInt",
        "bool safeBool",
        "Map<String, dynamic> safeStringMap",
    )
    require_contains(
        "lib/services/history_store.dart",
        ".corrupt",
        "File('${file.path}.tmp')",
        "flush: true",
        "temporary.rename(file.path)",
        "if (!await file.exists() && await temporary.exists())",
        "File('${file.path}.corrupt')",
    )
    require_contains(
        "lib/screens/settings_screen.dart",
        "ValueKey<int>(settings.delayMs)",
        "ValueKey<int>(settings.retryCount)",
    )
    require_contains(
        "lib/screens/home_shell.dart",
        "assets/icon/app_icon.png",
        "Image.asset(",
    )
    require_contains(
        "nodejs-project/engine/campaign_queue.cjs",
        "if (result.stopped) break;",
        "_interruptibleRetryDelay",
        "if (this.stopRequested)",
    )
    require_contains(
        "nodejs-project/engine/whatsapp_engine.cjs",
        "this.connectPromise",
        "this.socketEpoch",
        "this.autoReplyChain",
        "this.credsSaveChain",
        "await this.credsSaveChain",
        "this._handleIncomingMessages(socket, upsert)",
        "epoch !== this.socketEpoch",
        "this.sock !== socket",
        "this.autoReplied.size >= 5000",
        "Do not open WhatsApp from init",
    )
    whatsapp_engine = require_file("nodejs-project/engine/whatsapp_engine.cjs").read_text(encoding="utf-8")
    init_start = whatsapp_engine.find("  async init(payload) {")
    connect_start = whatsapp_engine.find("  async connect() {", init_start)
    if init_start < 0 or connect_start < 0:
        raise RuntimeError("WhatsAppEngine init/connect structure tidak dijumpai.")
    if "await this.connect()" in whatsapp_engine[init_start:connect_start]:
        raise RuntimeError("WhatsAppEngine.init tidak boleh auto-connect; foreground lifecycle mesti dikawal Flutter.")

    require_contains(
        "nodejs-project/engine/media.cjs",
        "safeBasename",
        "MAX_FILE_BYTES",
        "catch (_) {",
    )
    require_contains(
        "nodejs-project/main.js",
        "let commandChain = Promise.resolve();",
        "commandChain = commandChain",
    )

    for package_name in ("package.json", "package.legacy.json", "package.baileys7.json"):
        package_meta = json.loads(require_file(f"nodejs-project/{package_name}").read_text(encoding="utf-8"))
        if package_meta.get("version") != "1.0.4":
            raise RuntimeError(f"Versi {package_name} mesti 1.0.4 untuk source v1.0.4.")

    package = json.loads(require_file("nodejs-project/package.json").read_text(encoding="utf-8"))
    expected = {
        "@hapi/boom": "10.0.1",
        "baileys": "6.7.8",
        "mime-types": "2.1.35",
        "pino": "8.21.0",
    }
    if package.get("dependencies") != expected:
        raise RuntimeError("Dependency Node direct mesti dipin tepat untuk root-fixed build.")
    if package.get("scripts", {}).get("postinstall") != "node scripts/apply_security_backport.cjs":
        raise RuntimeError("Security backport postinstall tidak dikunci.")
    expected_signal = "https://codeload.github.com/WhiskeySockets/libsignal-node/tar.gz/83a3e3a3864511cb74df1b796373f0d49d071134"
    if package.get("overrides", {}).get("baileys", {}).get("libsignal") != expected_signal:
        raise RuntimeError("Transitive libsignal Baileys mesti dipin kepada commit v6.7.8 yang diketahui.")

    require_contains(
        "scripts/use_baileys7.sh",
        "Baileys 7 TIDAK diaktifkan",
        "exit 2",
    )

    print("[ok] Root build/runtime fixes")


def validate_shell_python() -> None:
    run([sys.executable, "-m", "py_compile", "scripts/bootstrap.py", "scripts/validate_source.py"])
    for script in ("scripts/setup.sh", "scripts/build_apk.sh", "scripts/use_baileys7.sh", "scripts/use_legacy.sh", "android/gradlew"):
        run(["sh", "-n", script])
    print("[ok] Script syntax")


def write_manifest() -> None:
    output = ROOT / "SOURCE_MANIFEST.sha256"
    lines: list[str] = []
    for file in sorted(ROOT.rglob("*")):
        if not file.is_file() or file == output or "__pycache__" in file.parts:
            continue
        # Build/download caches are intentionally excluded from source integrity.
        if "libnode" in file.parts and "packages" in file.parts:
            continue
        digest = hashlib.sha256(file.read_bytes()).hexdigest()
        lines.append(f"{digest}  {file.relative_to(ROOT).as_posix()}")
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[ok] {output.name} ({len(lines)} fail sumber)")


def main() -> int:
    run(["node", "--check", "main.js"], cwd=NODE)
    for file in sorted((NODE / "engine").glob("*.cjs")):
        run(["node", "--check", str(file.relative_to(NODE))], cwd=NODE)
    run(["node", "--check", "scripts/apply_security_backport.cjs"], cwd=NODE)
    test_files = [str(file.relative_to(NODE)) for file in sorted((NODE / "test").glob("*.test.cjs"))]
    run(["node", "--test", *test_files], cwd=NODE)
    validate_json()
    validate_xml()
    validate_android_resources()
    validate_secrets()
    validate_icons()
    validate_root_fixes()
    validate_shell_python()
    write_manifest()
    print("\nSemakan source lulus.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (subprocess.CalledProcessError, RuntimeError, json.JSONDecodeError, ET.ParseError) as error:
        print(f"\nSemakan gagal: {error}", file=sys.stderr)
        raise SystemExit(1)
