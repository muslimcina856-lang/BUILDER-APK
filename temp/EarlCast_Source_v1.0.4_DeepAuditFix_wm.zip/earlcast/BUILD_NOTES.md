# Build Notes — EarlCast 1.0.4


## Fix 1.0.4 — `Unresolved reference: Properties` + deep audit

`settings.gradle.kts` tidak lagi bergantung pada `java.util.Properties`. Flutter SDK dicari melalui environment, parser `local.properties` yang ringkas, dan executable Flutter dalam `PATH` sebagai fallback. Ini menutup kegagalan runner yang mencipta `local.properties` dengan `sdk.dir` sahaja atau mempunyai resolusi Kotlin DSL yang tidak mengenali `Properties`.

Deep audit turut menambah command acknowledgement sebenar, EventChannel failure handling, normalisasi settings, atomic history writes, queue stop hardening, Baileys credential/socket race protection, media path hardening, dan retry/timeout npm staging.
Startup WhatsApp juga kini foreground-gated (Node `init` tidak auto-connect), Flutter SDK candidate divalidasi sebelum dipilih, dan download Node Mobile mempunyai 3 percubaan dengan backoff serta ZIP validation.

## Fix 1.0.3 — `Unresolved reference: io`

Kotlin DSL Android mempunyai accessor/extension bernama `java`. Oleh itu penggunaan `java.io.ByteArrayOutputStream()` dalam scope script boleh di-resolve kepada accessor Gradle dan bukannya package Java. Source kini menggunakan `import java.io.ByteArrayOutputStream` dan `ByteArrayOutputStream()`; validator akan gagal jika pola lama diperkenalkan semula.


## Toolchain yang dipin

- Gradle: `8.14.5`
- AGP: `8.11.1`
- Kotlin Gradle Plugin: `2.2.20`
- App NDK: `28.2.13676358`
- Local Node bridge NDK: `28.2.13676358`
- CMake bridge: `3.22.1`
- Node.js Mobile Android: `18.20.4`
- minSdk: `24`

Gradle launcher menyemak SHA-256 distribution `8.14.5` sebelum extract.

## Clean build prerequisites

Runner perlu mempunyai Flutter, Java 17, Android SDK, Node.js >=18, npm dan internet. Gradle menyemak versi Node host sebelum staging. Build sendiri akan mendapatkan:

- Gradle distribution jika belum cache.
- Maven/Flutter dependencies.
- Node.js Mobile Android archive jika belum ada dalam `packages/node_flutter/android/libnode`.
- npm dependencies untuk generated Node assets. Dot-files npm dibuang sebelum Android asset manifest dijana supaya `file.list` tidak merujuk fail yang AAPT abaikan.

Build tidak lagi memerlukan edit `.pub-cache` atau salinan manual `libnode`.

- Gradle npm staging menggunakan `--ignore-scripts`; hanya security backport EarlCast dijalankan secara eksplisit selepas install.
- Jika source tidak mengandungi `package-lock.json`, fallback `npm install` menggunakan direct pins + pinned `libsignal`, tetapi dependency transitif npm masih diselesaikan ketika build.

## First build

First build lebih berat kerana Node Mobile archive, CMake dan npm assets. Build berikutnya boleh menggunakan Gradle/npm/download cache.

## CI diagnosis

Urutan task yang dijangka:

```text
prepareEarlCastNodeRuntime
prepareEarlCastNodeProject
configure/build CMake
merge assets
assembleDebug / assembleRelease
```

Jika CMake mengadu `libnode.so` hilang, lihat task `prepareEarlCastNodeRuntime`. Jika runtime JavaScript mengadu module hilang, lihat task `prepareEarlCastNodeProject`.

## Source validation yang telah dibuat dalam environment penjanaan

- 7/7 Node tests lulus.
- Semua JS/CJS lulus `node --check`.
- Native bridge C++ `flutter-bridge.cpp` lulus host syntax-check terhadap Node headers.
- `native-lib.cpp` lulus host syntax-check menggunakan JNI headers + stub Android log header.
- Kotlin plugin `NodeFlutterPlugin.kt` lulus compile terhadap stub Android/Flutter API; ini menangkap dan membetulkan incompatibility `ArrayDeque.addLast()`.
- Android XML/resource checks lulus.
- Shell/Python syntax checks lulus.
- Root-fix wiring validator lulus.
- Secret scan asas lulus.

Full Flutter/Android compile tidak dapat dijalankan dalam environment penjanaan kerana Flutter/Android SDK serta DNS download Gradle tidak tersedia di sana. Sebab itu source mempunyai build-time guards supaya runner sebenar memberi error spesifik jika prerequisite gagal.

## Google Play / 16 KB native page size

Node.js Mobile `18.20.4` published Android binary masih mempunyai isu upstream berkaitan 16 KB page alignment. Untuk sideload/test, ini bukan blocker build semasa. Untuk Play Store/target Android moden, jangan anggap APK production-ready sehingga Node Mobile menghasilkan release rasmi yang 16 KB-aligned atau anda membina runtime tersebut sendiri daripada source yang mengandungi fix.

## Device test minimum

1. Install debug APK pada arm64 device sebenar.
2. Pastikan UI melepasi `engine.booted` dan `engine.ready`.
3. Pair nombor ujian.
4. Tutup/buka app dan semak session reconnect.
5. Background app dan semak socket disconnect.
6. Resume dan semak reconnect.
7. Fetch group.
8. Send satu teks ke group ujian.
9. Test image/video/audio/PDF.
10. Test pause/resume/stop + network loss.
11. Logout dan pastikan auth directory dibersihkan.

## APK size

Untuk mengurangkan APK per fail:

```bash
flutter build apk --release --split-per-abi
```
