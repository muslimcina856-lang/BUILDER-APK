import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';

/// Minimal foreground-only Node.js bridge used by EarlCast.
///
/// Flutter-to-Node messages are wrapped in the same `_EVENTS_` envelope used
/// by the upstream bridge. JavaScript then re-emits the embedded `tag`, which
/// lets EarlCast listen with `bridge.on('command', ...)`.
class Nodejs {
  static const MethodChannel _methodChannel = MethodChannel('node_flutter');
  static const EventChannel _eventChannel = EventChannel('node_flutter/events');
  static const String _nodeEventChannel = '_EVENTS_';

  static Stream<Map<String, dynamic>>? _messageStream;

  static Stream<Map<String, dynamic>> get onMessageReceived {
    return _messageStream ??= _eventChannel
        .receiveBroadcastStream()
        .where((event) => event is Map)
        .map((event) {
          final output = <String, dynamic>{};
          (event as Map).forEach((key, value) {
            if (key is String) output[key] = value;
          });
          return output;
        })
        .asBroadcastStream();
  }

  /// Launches the embedded runtime and returns once the native Node thread has
  /// been started. JavaScript readiness is signalled separately by EarlCast's
  /// `engine.booted` event.
  static Future<void> start() async {
    await _methodChannel.invokeMethod<void>('startNodeProject');
  }

  static Future<void> sendMessage(String tag, String message) async {
    final envelope = jsonEncode(<String, dynamic>{
      'tag': tag,
      'message': message,
    });
    await _methodChannel.invokeMethod<void>('sendMessage', <String, dynamic>{
      'channel': _nodeEventChannel,
      'message': envelope,
    });
  }
}
