# Security

- Gunakan nombor ujian/sekunder dan sasaran yang mempunyai izin.
- Jangan kongsi `wa-session` atau data private app.
- Android backup dimatikan.
- Tiada HTTP server/port LAN; Flutter ↔ Node menggunakan bridge JNI/MethodChannel.
- Node source berada dalam APK assets tetapi auth state hanya diwujudkan di private storage ketika runtime.
- App menghentikan queue dan menutup socket ketika background.
- Baileys legacy dipin dan postinstall security backport wajib; Gradle mengesahkannya sekali lagi sebelum merge assets.
- Dependency `libsignal` yang asalnya Git-based turut dipin kepada commit release v6.7.8 yang diketahui, bukan HEAD semasa.
- Build menggunakan `--ignore-scripts` untuk dependency pihak ketiga; selepas install, hanya security backport EarlCast yang telah disemak dijalankan dan diverifikasi secara eksplisit.
- Node Mobile runtime diambil daripada URL release rasmi yang dipin versinya; Gradle runtime task mengesahkan struktur headers/ABI sebelum CMake.
- Gradle 8.14.5 distribution dipin dengan SHA-256.
- Token Telegram ZIP asal tidak termasuk dalam source ini; revoke token lama jika belum dilakukan.

Lihat `SECURITY_PATCH.md` untuk skop backport dan `BUILD_NOTES.md` untuk limit native 16 KB.
