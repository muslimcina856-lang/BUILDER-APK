import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/app_models.dart';
import '../models/engine_event.dart';
import '../services/history_store.dart';
import '../services/node_engine_service.dart';
import '../services/settings_store.dart';
import '../utils/safe_values.dart';

class AppController extends ChangeNotifier {
  AppController({
    NodeEngineService? engine,
    HistoryStore? historyStore,
    SettingsStore? settingsStore,
  })  : _engine = engine ?? NodeEngineService(),
        _historyStore = historyStore ?? HistoryStore(),
        _settingsStore = settingsStore ?? SettingsStore();

  final NodeEngineService _engine;
  final HistoryStore _historyStore;
  final SettingsStore _settingsStore;
  final Uuid _uuid = const Uuid();

  StreamSubscription<EngineEvent>? _eventSubscription;
  Timer? _noticeTimer;
  Future<void> _settingsSaveTail = Future<void>.value();
  int _settingsRevision = 0;
  bool _disposed = false;

  EngineState engineState = EngineState.starting;
  WaConnectionState connectionState = WaConnectionState.disconnected;
  CampaignProgress campaign = const CampaignProgress();
  AppSettings settings = const AppSettings();

  String accountName = '';
  String accountNumber = '';
  String pairingCode = '';
  String notice = '';
  String errorMessage = '';
  String groupSearch = '';
  String draftText = '';
  bool groupsLoading = false;

  List<GroupInfo> groups = <GroupInfo>[];
  final Set<String> selectedGroupIds = <String>{};
  List<MediaAttachment> attachments = <MediaAttachment>[];
  List<CampaignHistory> history = <CampaignHistory>[];

  String _activeDraftPreview = '';
  int _activeMediaCount = 0;
  bool _foregroundSuspended = false;

  bool get isConnected => connectionState == WaConnectionState.connected;
  bool get campaignActive =>
      campaign.state == CampaignState.running ||
      campaign.state == CampaignState.paused ||
      campaign.state == CampaignState.stopping;

  List<GroupInfo> get filteredGroups {
    final query = groupSearch.trim().toLowerCase();
    if (query.isEmpty) return groups;
    return groups
        .where((group) => group.name.toLowerCase().contains(query))
        .toList(growable: false);
  }

  Future<void> initialize() async {
    try {
      settings = await _settingsStore.load();
    } catch (error) {
      settings = const AppSettings();
      errorMessage = 'Tetapan lokal gagal dibaca: ${error.toString()}';
    }

    try {
      history = await _historyStore.load();
    } catch (error) {
      history = <CampaignHistory>[];
      errorMessage = 'History lokal gagal dibaca: ${error.toString()}';
    }
    _notify();

    await _eventSubscription?.cancel();
    _eventSubscription = _engine.events.listen(_handleEngineEvent);
    try {
      await _engine.start();
      engineState = EngineState.ready;
      try {
        // Configure auto-reply before opening the socket so an immediately
        // arriving message cannot race the local setting on first connect.
        await _syncAutoReply();
        if (!_foregroundSuspended) {
          connectionState = WaConnectionState.connecting;
          await _engine.send('connect');
        }
      } catch (error) {
        connectionState = WaConnectionState.error;
        errorMessage = error.toString();
        _showNotice('Engine siap, tetapi sambungan awal gagal: ${error.toString()}');
      }
      _notify();
    } catch (error) {
      engineState = EngineState.error;
      errorMessage = error.toString();
      _notify();
    }
  }

  Future<void> pair(String phoneNumber) async {
    final normalized = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');
    if (normalized.length < 8 || normalized.length > 15) {
      _showNotice('Masukkan nombor penuh bersama kod negara (8–15 digit).');
      return;
    }

    pairingCode = '';
    connectionState = WaConnectionState.pairing;
    errorMessage = '';
    _notify();
    try {
      await _engine.send('pair', {'phoneNumber': normalized});
    } catch (error) {
      connectionState = WaConnectionState.error;
      errorMessage = error.toString();
      _showNotice('Pairing gagal: ${error.toString()}');
      _notify();
    }
  }

  Future<void> reconnect() async {
    connectionState = WaConnectionState.connecting;
    errorMessage = '';
    _notify();
    try {
      await _engine.send('connect');
    } catch (error) {
      connectionState = WaConnectionState.error;
      errorMessage = error.toString();
      _showNotice('Sambungan gagal: ${error.toString()}');
      _notify();
    }
  }

  Future<void> suspendForBackground() async {
    if (_foregroundSuspended) return;
    // Record lifecycle state even if Node is still starting. initialize() will
    // then skip connect if startup finishes while Android is backgrounded.
    _foregroundSuspended = true;
    if (!_engine.isStarted) return;
    if (campaignActive) await stopCampaign();
    try {
      await _engine.send('shutdown');
    } catch (_) {
      // Android mungkin menggantung proses sebelum arahan selesai.
    }
  }

  Future<void> resumeFromBackground() async {
    if (!_foregroundSuspended) return;
    // Clear first: if Node is still starting, initialize() will observe that
    // the app has resumed and perform the initial foreground connect itself.
    _foregroundSuspended = false;
    if (!_engine.isStarted) return;
    try {
      await _syncAutoReply();
      connectionState = WaConnectionState.connecting;
      _notify();
      await _engine.send('connect');
    } catch (error) {
      connectionState = WaConnectionState.error;
      errorMessage = error.toString();
      _notify();
    }
  }

  Future<void> logout() async {
    try {
      await _engine.send('logout');
      accountName = '';
      accountNumber = '';
      pairingCode = '';
      groups = <GroupInfo>[];
      selectedGroupIds.clear();
      connectionState = WaConnectionState.loggedOut;
      _notify();
    } catch (error) {
      connectionState = WaConnectionState.error;
      errorMessage = error.toString();
      _showNotice('Logout gagal: ${error.toString()}');
      _notify();
    }
  }

  Future<void> refreshGroups() async {
    if (!isConnected) return;
    groupsLoading = true;
    _notify();
    try {
      await _engine.send('getGroups');
    } catch (error) {
      groupsLoading = false;
      errorMessage = error.toString();
      _notify();
    }
  }

  void setGroupSearch(String value) {
    groupSearch = value;
    _notify();
  }

  void toggleGroup(String groupId, bool selected) {
    if (selected) {
      if (selectedGroupIds.length >= settings.maxTargets) {
        _showNotice('Had semasa ialah ${settings.maxTargets} group.');
        return;
      }
      selectedGroupIds.add(groupId);
    } else {
      selectedGroupIds.remove(groupId);
    }
    _notify();
  }

  void selectFilteredGroups() {
    for (final group in filteredGroups) {
      if (selectedGroupIds.length >= settings.maxTargets) break;
      selectedGroupIds.add(group.id);
    }
    _notify();
  }

  void clearSelectedGroups() {
    selectedGroupIds.clear();
    _notify();
  }

  void updateDraftText(String value) {
    draftText = value;
  }

  Future<void> pickAttachments() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        withData: false,
        type: FileType.custom,
        allowedExtensions: const [
          'jpg',
          'jpeg',
          'png',
          'webp',
          'gif',
          'mp4',
          'mov',
          'mkv',
          'mp3',
          'm4a',
          'ogg',
          'wav',
          'pdf',
          'doc',
          'docx',
          'xls',
          'xlsx',
          'ppt',
          'pptx',
          'txt',
          'zip',
        ],
      );

      if (result == null) return;

      final selected = <MediaAttachment>[];
      for (final platformFile in result.files.take(10)) {
        final path = platformFile.path;
        if (path == null || path.isEmpty) continue;
        final file = File(path);
        if (!await file.exists()) continue;
        final size = await file.length();
        if (size > 64 * 1024 * 1024) {
          _showNotice('${platformFile.name} melebihi had 64 MB.');
          continue;
        }
        selected.add(MediaAttachment(
          path: path,
          name: platformFile.name,
          sizeBytes: size,
          mimeType: _mimeForName(platformFile.name),
        ));
      }

      attachments = selected;
      _notify();
    } catch (error) {
      errorMessage = error.toString();
      _showNotice('Gagal membaca media: ${error.toString()}');
    }
  }

  void removeAttachment(int index) {
    if (index < 0 || index >= attachments.length) return;
    attachments = List<MediaAttachment>.of(attachments)..removeAt(index);
    _notify();
  }

  void clearComposer() {
    draftText = '';
    attachments = <MediaAttachment>[];
    _notify();
  }

  Future<bool> startCampaign() async {
    if (!isConnected) {
      _showNotice('Sambungkan WhatsApp dahulu.');
      return false;
    }
    // Drop stale selections before any count validation. A group can disappear
    // between refreshes; stale IDs must never cause a false max-target error.
    selectedGroupIds.removeWhere(
      (id) => !groups.any((group) => group.id == id && id.endsWith('@g.us')),
    );
    if (selectedGroupIds.isEmpty) {
      _showNotice('Pilih sekurang-kurangnya satu group.');
      _notify();
      return false;
    }
    if (draftText.trim().isEmpty && attachments.isEmpty) {
      _showNotice('Masukkan teks atau pilih media.');
      return false;
    }
    if (selectedGroupIds.length > settings.maxTargets) {
      _showNotice('Jumlah group melebihi had semasa.');
      return false;
    }

    final selectedGroups = groups
        .where((group) => selectedGroupIds.contains(group.id) && group.id.endsWith('@g.us'))
        .map((group) => group.toJson())
        .toList(growable: false);
    if (selectedGroups.isEmpty) {
      _showNotice('Senarai group berubah. Refresh dan pilih sasaran semula.');
      _notify();
      return false;
    }

    final normalizedPreview = draftText.trim().replaceAll(RegExp(r'\s+'), ' ');
    _activeDraftPreview = normalizedPreview.isEmpty
        ? '(Media sahaja)'
        : normalizedPreview.substring(
            0,
            normalizedPreview.length > 120 ? 120 : normalizedPreview.length,
          );
    _activeMediaCount = attachments.length;

    campaign = CampaignProgress(
      state: CampaignState.running,
      total: selectedGroups.length,
      startedAt: DateTime.now(),
    );
    _notify();

    try {
      await _engine.send('startCampaign', {
        'targets': selectedGroups,
        'text': draftText.trim(),
        'attachments': attachments.map((item) => item.toJson()).toList(),
        'delayMs': settings.delayMs,
        'retryCount': settings.retryCount,
        'maxTargets': settings.maxTargets,
      });
      return true;
    } catch (error) {
      campaign = campaign.copyWith(state: CampaignState.failed);
      errorMessage = error.toString();
      _notify();
      return false;
    }
  }

  Future<void> pauseCampaign() async {
    try {
      await _engine.send('pauseCampaign');
    } catch (error) {
      errorMessage = error.toString();
      _showNotice('Gagal pause penghantaran: ${error.toString()}');
    }
  }

  Future<void> resumeCampaign() async {
    try {
      await _engine.send('resumeCampaign');
    } catch (error) {
      errorMessage = error.toString();
      _showNotice('Gagal sambung penghantaran: ${error.toString()}');
    }
  }

  Future<void> stopCampaign() async {
    final previousState = campaign.state;
    campaign = campaign.copyWith(state: CampaignState.stopping);
    _notify();
    try {
      await _engine.send('stopCampaign');
    } catch (error) {
      campaign = campaign.copyWith(state: previousState);
      errorMessage = error.toString();
      _showNotice('Gagal hentikan penghantaran: ${error.toString()}');
      _notify();
    }
  }

  Future<void> updateSettings(AppSettings value) {
    final previous = settings;
    final previousSelection = Set<String>.of(selectedGroupIds);
    final revision = ++_settingsRevision;
    final normalized = SettingsStore.normalize(value);

    // Update UI immediately, but serialize disk/engine writes. Rapid text or
    // slider changes can otherwise finish out of order and persist stale data.
    settings = normalized;
    if (selectedGroupIds.length > settings.maxTargets) {
      final retained = selectedGroupIds.take(settings.maxTargets).toSet();
      selectedGroupIds
        ..clear()
        ..addAll(retained);
    }
    _notify();

    final task = _settingsSaveTail
        .catchError((_) {})
        .then((_) async {
          // Coalesce queued intermediate values that have not started yet.
          if (revision != _settingsRevision) return;
          try {
            await _settingsStore.save(normalized);
          } catch (error) {
            if (revision == _settingsRevision) {
              settings = previous;
              selectedGroupIds
                ..clear()
                ..addAll(previousSelection);
              errorMessage = error.toString();
              _showNotice('Tetapan gagal disimpan: ${error.toString()}');
              _notify();
            }
            return;
          }

          if (revision != _settingsRevision) return;
          try {
            await _syncAutoReply();
          } catch (error) {
            if (revision == _settingsRevision) {
              errorMessage = error.toString();
              _showNotice(
                'Tetapan disimpan, tetapi engine belum dapat diselaraskan: ${error.toString()}',
              );
            }
          }
        });
    _settingsSaveTail = task;
    return task;
  }

  Future<void> clearHistory() async {
    final previous = List<CampaignHistory>.of(history);
    history = <CampaignHistory>[];
    _notify();
    try {
      await _historyStore.clear();
    } catch (error) {
      history = previous;
      errorMessage = error.toString();
      _showNotice('History gagal dipadam: ${error.toString()}');
      _notify();
    }
  }

  Future<void> _syncAutoReply() async {
    if (!_engine.isStarted) return;
    await _engine.send('setAutoReply', {
      'enabled': settings.autoReplyEnabled,
      'text': settings.autoReplyText.trim(),
    });
  }

  void _handleEngineEvent(EngineEvent event) {
    switch (event.type) {
      case 'engine.ready':
        engineState = EngineState.ready;
        break;
      case 'engine.error':
        engineState = EngineState.error;
        errorMessage = safeString(event.payload['message'], 'Ralat engine.');
        break;
      case 'engine.nativeExit':
        engineState = EngineState.error;
        connectionState = WaConnectionState.disconnected;
        groupsLoading = false;
        if (campaignActive) {
          campaign = campaign.copyWith(state: CampaignState.failed);
        }
        errorMessage = safeString(
          event.payload['message'],
          'Runtime Node.js telah berhenti. Tutup dan buka semula aplikasi.',
        );
        _showNotice(errorMessage);
        break;
      case 'command.error':
        final failedAction = safeString(event.payload['action']);
        if (failedAction == 'getGroups') groupsLoading = false;
        if (failedAction == 'pair' || failedAction == 'connect') {
          connectionState = WaConnectionState.error;
        }
        if (failedAction == 'startCampaign') {
          campaign = campaign.copyWith(state: CampaignState.failed);
        }
        if (failedAction == 'stopCampaign' &&
            campaign.state == CampaignState.stopping) {
          campaign = campaign.copyWith(state: CampaignState.failed);
        }
        errorMessage = safeString(event.payload['message'], 'Arahan gagal.');
        _showNotice(errorMessage);
        break;
      case 'connection.status':
        _applyConnectionStatus(event.payload);
        break;
      case 'pairing.code':
        pairingCode = safeString(event.payload['code']);
        connectionState = WaConnectionState.pairing;
        break;
      case 'groups.list':
        groupsLoading = false;
        final rawGroups = event.payload['groups'];
        if (rawGroups is List) {
          groups = rawGroups
              .whereType<Map>()
              .map((item) => GroupInfo.fromJson(safeStringMap(item)))
              .where((group) => group.id.endsWith('@g.us'))
              .toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          selectedGroupIds.removeWhere(
            (id) => !groups.any((group) => group.id == id),
          );
        }
        break;
      case 'campaign.started':
        campaign = campaign.copyWith(
          state: CampaignState.running,
          total: safeInt(event.payload['total'], campaign.total),
        );
        break;
      case 'campaign.paused':
        campaign = campaign.copyWith(state: CampaignState.paused);
        break;
      case 'campaign.resumed':
        campaign = campaign.copyWith(state: CampaignState.running);
        break;
      case 'campaign.progress':
        campaign = campaign.copyWith(
          state: CampaignState.running,
          completed: safeInt(event.payload['completed']),
          total: safeInt(event.payload['total'], campaign.total),
          success: safeInt(event.payload['success']),
          failed: safeInt(event.payload['failed']),
          skipped: safeInt(event.payload['skipped']),
          currentTarget: safeString(event.payload['currentTarget']),
        );
        break;
      case 'campaign.completed':
      case 'campaign.stopped':
        unawaited(_completeCampaign(event));
        break;
      case 'campaign.error':
        campaign = campaign.copyWith(state: CampaignState.failed);
        errorMessage = safeString(event.payload['message'], 'Kempen gagal.');
        break;
      case 'notice':
        _showNotice(safeString(event.payload['message']));
        break;
    }
    _notify();
  }

  void _applyConnectionStatus(Map<String, dynamic> payload) {
    final status = safeString(payload['status'], 'disconnected');
    connectionState = switch (status) {
      'connecting' => WaConnectionState.connecting,
      'pairing' => WaConnectionState.pairing,
      'connected' => WaConnectionState.connected,
      'loggedOut' => WaConnectionState.loggedOut,
      'error' => WaConnectionState.error,
      _ => WaConnectionState.disconnected,
    };

    accountName = safeString(payload['accountName'], accountName);
    accountNumber = safeString(payload['accountNumber'], accountNumber);
    final message = safeString(payload['message']);
    if (message.isNotEmpty) errorMessage = message;
    if (connectionState == WaConnectionState.connected) {
      pairingCode = '';
      unawaited(refreshGroups());
    }
  }

  Future<void> _completeCampaign(EngineEvent event) async {
    final success = safeInt(event.payload['success'], campaign.success);
    final failed = safeInt(event.payload['failed'], campaign.failed);
    final skipped = safeInt(event.payload['skipped'], campaign.skipped);
    final total = safeInt(event.payload['total'], campaign.total);
    final duration = safeInt(
      event.payload['durationSeconds'],
      DateTime.now().difference(campaign.startedAt ?? DateTime.now()).inSeconds,
    ).clamp(0, 1 << 31).toInt();

    campaign = campaign.copyWith(
      state: CampaignState.completed,
      completed: success + failed + skipped,
      total: total,
      success: success,
      failed: failed,
      skipped: skipped,
      currentTarget: '',
    );

    history = <CampaignHistory>[
      CampaignHistory(
        id: _uuid.v4(),
        createdAt: DateTime.now(),
        preview: _activeDraftPreview,
        targetCount: total,
        success: success,
        failed: failed,
        skipped: skipped,
        mediaCount: _activeMediaCount,
        durationSeconds: duration,
      ),
      ...history,
    ].take(100).toList(growable: false);
    try {
      await _historyStore.save(history);
    } catch (error) {
      errorMessage = error.toString();
      _showNotice('Keputusan penghantaran siap tetapi history gagal disimpan.');
    }
    _notify();
  }

  void _showNotice(String message) {
    if (message.isEmpty) return;
    notice = message;
    _noticeTimer?.cancel();
    _noticeTimer = Timer(const Duration(seconds: 4), () {
      notice = '';
      _notify();
    });
    _notify();
  }

  String _mimeForName(String name) {
    final extension = name.split('.').last.toLowerCase();
    return switch (extension) {
      'jpg' || 'jpeg' => 'image/jpeg',
      'png' => 'image/png',
      'webp' => 'image/webp',
      'gif' => 'image/gif',
      'mp4' => 'video/mp4',
      'mov' => 'video/quicktime',
      'mkv' => 'video/x-matroska',
      'mp3' => 'audio/mpeg',
      'm4a' => 'audio/mp4',
      'ogg' => 'audio/ogg',
      'wav' => 'audio/wav',
      'pdf' => 'application/pdf',
      'doc' => 'application/msword',
      'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls' => 'application/vnd.ms-excel',
      'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt' => 'application/vnd.ms-powerpoint',
      'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'txt' => 'text/plain',
      'zip' => 'application/zip',
      _ => 'application/octet-stream',
    };
  }

  void _notify() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    _noticeTimer?.cancel();
    _eventSubscription?.cancel();
    unawaited(_engine.dispose());
    super.dispose();
  }
}
