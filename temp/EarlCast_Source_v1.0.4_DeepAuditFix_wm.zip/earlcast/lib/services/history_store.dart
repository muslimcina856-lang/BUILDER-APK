import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/app_models.dart';

class HistoryStore {
  static const int _maxEntries = 100;

  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    final historyDirectory = Directory('${directory.path}/earlcast');
    await historyDirectory.create(recursive: true);
    return File('${historyDirectory.path}/campaign_history.json');
  }

  Future<List<CampaignHistory>> load() async {
    final file = await _file();
    final temporary = File('${file.path}.tmp');

    if (!await file.exists() && await temporary.exists()) {
      // A previous process may have died after flushing the temporary file but
      // before the final rename. Recover that complete file instead of losing
      // an otherwise valid history snapshot.
      try {
        await temporary.rename(file.path);
      } catch (_) {
        // If recovery rename is unavailable, normal empty/corrupt handling
        // below remains safe.
      }
    } else if (await file.exists() && await temporary.exists()) {
      // Main file won the previous transaction; stale temp is disposable.
      try {
        await temporary.delete();
      } catch (_) {}
    }

    if (!await file.exists()) return <CampaignHistory>[];

    try {
      final source = await file.readAsString();
      final values = CampaignHistory.decodeList(source);
      values.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return values;
    } catch (_) {
      // Elak fail rosak dibaca berulang kali pada setiap pelancaran.
      try {
        final corrupt = File('${file.path}.corrupt');
        if (await corrupt.exists()) await corrupt.delete();
        await file.rename(corrupt.path);
      } catch (_) {
        // Jika rename gagal, abaikan; app masih boleh terus digunakan.
      }
      return <CampaignHistory>[];
    }
  }

  Future<void> save(List<CampaignHistory> values) async {
    final file = await _file();
    final limited = values.take(_maxEntries).toList(growable: false);
    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(
      CampaignHistory.encodeList(limited),
      flush: true,
    );
    try {
      // Pada filesystem yang menyokong replace atomik, rename terus mengurangkan
      // tetingkap fail history hilang jika proses Android mati di tengah simpan.
      await temporary.rename(file.path);
    } on FileSystemException {
      // Sesetengah Android/filesystem tidak membenarkan replace target sedia ada.
      // Fallback ini hanya digunakan selepas fail temporary sudah flush ke disk.
      if (await file.exists()) await file.delete();
      await temporary.rename(file.path);
    }
  }

  Future<void> clear() async {
    final file = await _file();
    final artifacts = <File>[
      file,
      File('${file.path}.tmp'),
      File('${file.path}.corrupt'),
    ];
    for (final artifact in artifacts) {
      if (await artifact.exists()) await artifact.delete();
    }
  }
}
