import 'dart:async';
import 'dart:convert';

import 'package:node_flutter/node_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/engine_event.dart';
import '../utils/safe_values.dart';

class NodeEngineService {
  final StreamController<EngineEvent> _events =
      StreamController<EngineEvent>.broadcast();
  final Uuid _uuid = const Uuid();

  StreamSubscription<Map<String, dynamic>>? _subscription;
  Completer<void>? _bootCompleter;
  Completer<void>? _readyCompleter;
  final Map<String, Completer<void>> _pendingCommands = <String, Completer<void>>{};
  bool _started = false;
  bool _disposed = false;

  Stream<EngineEvent> get events => _events.stream;
  bool get isStarted => _started;

  Future<void> start() async {
    if (_disposed) throw StateError('Node engine service telah ditutup.');
    if (_started) return;

    await _subscription?.cancel();
    _bootCompleter = Completer<void>();
    _readyCompleter = Completer<void>();
    // Native events can arrive before the later timeout/await statements are
    // attached. Add guarded branches immediately so an early engine failure
    // never becomes an unhandled asynchronous error.
    unawaited(_bootCompleter!.future.catchError((_) {}));
    unawaited(_readyCompleter!.future.catchError((_) {}));
    _subscription = Nodejs.onMessageReceived.listen(
      _handleNativeMessage,
      onError: (Object error, StackTrace stackTrace) {
        final exception = StateError(error.toString());
        _started = false;
        _failPendingStart(exception, stackTrace);
        _failPendingCommands(exception, stackTrace);
        _emit(EngineEvent(
          type: 'engine.error',
          payload: {'message': error.toString()},
          timestamp: DateTime.now(),
        ));
      },
      onDone: () {
        if (_disposed) return;
        _started = false;
        final exception = StateError('Channel event Node.js telah ditutup.');
        _failPendingStart(exception);
        _failPendingCommands(exception);
        _emit(EngineEvent(
          type: 'engine.error',
          payload: {'message': exception.message},
          timestamp: DateTime.now(),
        ));
      },
    );

    try {
      await Nodejs.start();
      await _bootCompleter!.future.timeout(
        const Duration(seconds: 120),
        onTimeout: () => throw TimeoutException(
          'Node engine tidak memberi isyarat boot dalam 120 saat. Semak log EARLCAST-NODE untuk punca native/JavaScript.',
        ),
      );
      if (_disposed) throw StateError('Node engine service ditutup semasa startup.');

      final supportDirectory = await getApplicationSupportDirectory();
      final cacheDirectory = await getTemporaryDirectory();

      // `init` is the only command permitted before _started becomes true.
      // The JavaScript command queue serializes it before later commands.
      await send(
        'init',
        {
          'dataDir': supportDirectory.path,
          'cacheDir': cacheDirectory.path,
          'clientName': 'EarlCast',
        },
      );

      await _readyCompleter!.future.timeout(
        const Duration(seconds: 60),
        onTimeout: () => throw TimeoutException(
          'Node engine booted tetapi init WhatsApp tidak siap dalam 60 saat.',
        ),
      );
      if (_disposed) throw StateError('Node engine service ditutup semasa init.');
      _started = true;
    } catch (_) {
      _started = false;
      await _subscription?.cancel();
      _subscription = null;
      _bootCompleter = null;
      _readyCompleter = null;
      rethrow;
    }
  }

  Future<void> send(String action, [Map<String, dynamic>? payload]) async {
    if (_disposed) throw StateError('Node engine service telah ditutup.');
    if (!_started && action != 'init') {
      throw StateError('Node engine belum dimulakan.');
    }

    final id = _uuid.v4();
    final command = <String, dynamic>{
      'id': id,
      'action': action,
      'payload': payload ?? <String, dynamic>{},
      'timestamp': DateTime.now().toIso8601String(),
    };
    final acknowledgement = Completer<void>();
    _pendingCommands[id] = acknowledgement;
    // JavaScript can ack/error before MethodChannel.sendMessage returns.
    // Guard that short race while preserving the original Future for await.
    unawaited(acknowledgement.future.catchError((_) {}));

    try {
      await Nodejs.sendMessage('command', jsonEncode(command));
      await acknowledgement.future.timeout(
        action == 'init'
            ? const Duration(seconds: 60)
            : const Duration(seconds: 45),
        onTimeout: () => throw TimeoutException(
          'Engine tidak mengesahkan arahan "$action" dalam tempoh ditetapkan.',
        ),
      );
    } finally {
      _pendingCommands.remove(id);
    }
  }

  void _handleNativeMessage(Map<String, dynamic> nativeMessage) {
    final channel = nativeMessage['channelName'] ?? nativeMessage['tag'];
    if (channel != 'event') return;

    dynamic raw = nativeMessage['message'];
    if (raw is Map<String, dynamic>) {
      _addEvent(EngineEvent.fromJson(raw));
      return;
    }

    if (raw is Map) {
      _addEvent(EngineEvent.fromJson(safeStringMap(raw)));
      return;
    }

    if (raw is! String || raw.isEmpty) return;

    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        _addEvent(EngineEvent.fromJson(decoded));
      } else if (decoded is Map) {
        _addEvent(EngineEvent.fromJson(safeStringMap(decoded)));
      }
    } on FormatException {
      _emit(EngineEvent(
        type: 'engine.log',
        payload: {'level': 'info', 'message': raw},
        timestamp: DateTime.now(),
      ));
    }
  }

  void _addEvent(EngineEvent event) {
    final commandId = event.payload['id']?.toString() ?? '';
    if (event.type == 'command.ack' && commandId.isNotEmpty) {
      final pending = _pendingCommands[commandId];
      if (pending != null && !pending.isCompleted) pending.complete();
    }
    if (event.type == 'command.error' && commandId.isNotEmpty) {
      final pending = _pendingCommands[commandId];
      if (pending != null && !pending.isCompleted) {
        pending.completeError(StateError(
          event.payload['message']?.toString() ?? 'Arahan engine gagal.',
        ));
      }
    }

    if (event.type == 'engine.booted' &&
        _bootCompleter != null &&
        !_bootCompleter!.isCompleted) {
      _bootCompleter!.complete();
    }
    if (event.type == 'engine.ready' &&
        _readyCompleter != null &&
        !_readyCompleter!.isCompleted) {
      _readyCompleter!.complete();
    }

    if (event.type == 'engine.error' || event.type == 'engine.nativeExit') {
      final message = event.payload['message']?.toString() ??
          (event.type == 'engine.nativeExit'
              ? 'Embedded Node.js runtime telah berhenti.'
              : 'Embedded Node.js runtime gagal.');
      if (event.type == 'engine.nativeExit') _started = false;
      final failure = StateError(message);
      _failPendingStart(failure);
      // A global engine failure means a command currently waiting for an ACK
      // no longer has a trustworthy completion path. Fail it immediately
      // rather than leaving the UI blocked until its command timeout.
      _failPendingCommands(failure);
    }
    if (event.type == 'command.error' &&
        event.payload['action']?.toString() == 'init') {
      _failPendingStart(StateError(
        event.payload['message']?.toString() ?? 'Init Node engine gagal.',
      ));
    }

    _emit(event);
  }

  void _emit(EngineEvent event) {
    if (!_disposed && !_events.isClosed) _events.add(event);
  }

  void _failPendingCommands(Object error, [StackTrace? stackTrace]) {
    for (final pending in _pendingCommands.values.toList(growable: false)) {
      if (!pending.isCompleted) pending.completeError(error, stackTrace);
    }
    _pendingCommands.clear();
  }

  void _failPendingStart(Object error, [StackTrace? stackTrace]) {
    if (_bootCompleter != null && !_bootCompleter!.isCompleted) {
      _bootCompleter!.completeError(error, stackTrace);
    }
    if (_readyCompleter != null && !_readyCompleter!.isCompleted) {
      _readyCompleter!.completeError(error, stackTrace);
    }
  }

  Future<void> shutdown() async {
    if (!_started) return;
    try {
      await send('shutdown');
    } catch (_) {
      // Proses Android akan menamatkan runtime apabila aplikasi ditutup.
    }
    _started = false;
  }

  Future<void> dispose() async {
    if (_disposed) return;
    final wasStarted = _started;
    _disposed = true;
    _started = false;

    // Mark disposed before awaiting anything so an in-flight start() cannot
    // resurrect this service. Shutdown is best-effort; the embedded runtime is
    // process-scoped and can be reused by a newly created Flutter engine.
    if (wasStarted) {
      try {
        await Nodejs.sendMessage('command', jsonEncode(<String, dynamic>{
          'id': _uuid.v4(),
          'action': 'shutdown',
          'payload': <String, dynamic>{},
          'timestamp': DateTime.now().toIso8601String(),
        }));
      } catch (_) {}
    }

    final closing = StateError('Node engine sedang ditutup.');
    _failPendingStart(closing);
    _failPendingCommands(closing);
    await _subscription?.cancel();
    _subscription = null;
    if (!_events.isClosed) await _events.close();
  }
}
