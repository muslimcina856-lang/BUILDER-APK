import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  const AppSettings({
    this.delayMs = 2500,
    this.retryCount = 1,
    this.maxTargets = 30,
    this.autoReplyEnabled = false,
    this.autoReplyText = '',
  });

  final int delayMs;
  final int retryCount;
  final int maxTargets;
  final bool autoReplyEnabled;
  final String autoReplyText;

  AppSettings copyWith({
    int? delayMs,
    int? retryCount,
    int? maxTargets,
    bool? autoReplyEnabled,
    String? autoReplyText,
  }) =>
      AppSettings(
        delayMs: delayMs ?? this.delayMs,
        retryCount: retryCount ?? this.retryCount,
        maxTargets: maxTargets ?? this.maxTargets,
        autoReplyEnabled: autoReplyEnabled ?? this.autoReplyEnabled,
        autoReplyText: autoReplyText ?? this.autoReplyText,
      );
}

class SettingsStore {
  static const _delayKey = 'delay_ms';
  static const _retryKey = 'retry_count';
  static const _maxTargetsKey = 'max_targets';
  static const _autoReplyEnabledKey = 'auto_reply_enabled';
  static const _autoReplyTextKey = 'auto_reply_text';
  static const allowedDelayMs = <int>[1500, 2500, 5000, 10000];

  static AppSettings normalize(AppSettings value) {
    final text = value.autoReplyText.trim();
    return value.copyWith(
      delayMs: _closestAllowedDelay(value.delayMs),
      retryCount: value.retryCount.clamp(0, 2).toInt(),
      maxTargets: _normalizeMaxTargets(value.maxTargets),
      autoReplyText: text.length <= 1000 ? text : text.substring(0, 1000),
    );
  }

  static int _closestAllowedDelay(int value) {
    var closest = allowedDelayMs.first;
    var distance = (value - closest).abs();
    for (final candidate in allowedDelayMs.skip(1)) {
      final candidateDistance = (value - candidate).abs();
      if (candidateDistance < distance) {
        closest = candidate;
        distance = candidateDistance;
      }
    }
    return closest;
  }

  static int _normalizeMaxTargets(int value) {
    final clamped = value.clamp(5, 50).toInt();
    return ((clamped / 5).round() * 5).clamp(5, 50).toInt();
  }

  Future<AppSettings> load() async {
    final preferences = await SharedPreferences.getInstance();
    return normalize(AppSettings(
      delayMs: preferences.getInt(_delayKey) ?? 2500,
      retryCount: preferences.getInt(_retryKey) ?? 1,
      maxTargets: preferences.getInt(_maxTargetsKey) ?? 30,
      autoReplyEnabled: preferences.getBool(_autoReplyEnabledKey) ?? false,
      autoReplyText: preferences.getString(_autoReplyTextKey) ?? '',
    ));
  }

  Future<void> save(AppSettings value) async {
    final settings = normalize(value);
    final preferences = await SharedPreferences.getInstance();
    final results = await Future.wait([
      preferences.setInt(_delayKey, settings.delayMs),
      preferences.setInt(_retryKey, settings.retryCount),
      preferences.setInt(_maxTargetsKey, settings.maxTargets),
      preferences.setBool(_autoReplyEnabledKey, settings.autoReplyEnabled),
      preferences.setString(_autoReplyTextKey, settings.autoReplyText),
    ]);
    if (results.any((saved) => !saved)) {
      throw StateError('Sebahagian tetapan gagal disimpan ke storan lokal.');
    }
  }
}
