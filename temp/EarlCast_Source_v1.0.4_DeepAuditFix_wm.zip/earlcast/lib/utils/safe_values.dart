String safeString(dynamic value, [String fallback = '']) {
  if (value is String) return value;
  if (value is num || value is bool) return value.toString();
  return fallback;
}

int safeInt(dynamic value, [int fallback = 0]) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '') ?? fallback;
}

bool safeBool(dynamic value, [bool fallback = false]) {
  if (value is bool) return value;
  final normalized = value?.toString().trim().toLowerCase();
  if (normalized == 'true' || normalized == '1') return true;
  if (normalized == 'false' || normalized == '0') return false;
  return fallback;
}

Map<String, dynamic> safeStringMap(dynamic value) {
  if (value is! Map) return <String, dynamic>{};
  final output = <String, dynamic>{};
  value.forEach((key, item) {
    if (key is String) output[key] = item;
  });
  return output;
}
