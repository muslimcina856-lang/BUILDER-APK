import '../utils/safe_values.dart';

class EngineEvent {
  const EngineEvent({
    required this.type,
    required this.payload,
    required this.timestamp,
  });

  final String type;
  final Map<String, dynamic> payload;
  final DateTime timestamp;

  factory EngineEvent.fromJson(Map<String, dynamic> json) => EngineEvent(
        type: safeString(json['type'], 'unknown'),
        payload: safeStringMap(json['payload']),
        timestamp: DateTime.tryParse(safeString(json['timestamp'])) ??
            DateTime.now(),
      );
}
