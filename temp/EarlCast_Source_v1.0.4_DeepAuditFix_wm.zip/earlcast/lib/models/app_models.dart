import 'dart:convert';

import '../utils/safe_values.dart';

enum EngineState { starting, ready, stopped, error }

enum WaConnectionState {
  disconnected,
  connecting,
  pairing,
  connected,
  loggedOut,
  error,
}

enum CampaignState { idle, running, paused, stopping, completed, failed }

class GroupInfo {
  const GroupInfo({
    required this.id,
    required this.name,
    required this.participantCount,
    this.isAdmin = false,
  });

  final String id;
  final String name;
  final int participantCount;
  final bool isAdmin;

  factory GroupInfo.fromJson(Map<String, dynamic> json) => GroupInfo(
        id: safeString(json['id']),
        name: safeString(json['name'], 'Group tanpa nama'),
        participantCount: safeInt(json['participantCount']).clamp(0, 1000000).toInt(),
        isAdmin: safeBool(json['isAdmin']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'participantCount': participantCount,
        'isAdmin': isAdmin,
      };
}

class MediaAttachment {
  const MediaAttachment({
    required this.path,
    required this.name,
    required this.sizeBytes,
    required this.mimeType,
  });

  final String path;
  final String name;
  final int sizeBytes;
  final String mimeType;

  String get category {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    return 'document';
  }

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'sizeBytes': sizeBytes,
        'mimeType': mimeType,
        'category': category,
      };
}

class CampaignProgress {
  const CampaignProgress({
    this.state = CampaignState.idle,
    this.completed = 0,
    this.total = 0,
    this.success = 0,
    this.failed = 0,
    this.skipped = 0,
    this.currentTarget = '',
    this.startedAt,
  });

  final CampaignState state;
  final int completed;
  final int total;
  final int success;
  final int failed;
  final int skipped;
  final String currentTarget;
  final DateTime? startedAt;

  double get fraction {
    if (total <= 0) return 0;
    return (completed / total).clamp(0.0, 1.0).toDouble();
  }

  CampaignProgress copyWith({
    CampaignState? state,
    int? completed,
    int? total,
    int? success,
    int? failed,
    int? skipped,
    String? currentTarget,
    DateTime? startedAt,
  }) =>
      CampaignProgress(
        state: state ?? this.state,
        completed: completed ?? this.completed,
        total: total ?? this.total,
        success: success ?? this.success,
        failed: failed ?? this.failed,
        skipped: skipped ?? this.skipped,
        currentTarget: currentTarget ?? this.currentTarget,
        startedAt: startedAt ?? this.startedAt,
      );
}

class CampaignHistory {
  const CampaignHistory({
    required this.id,
    required this.createdAt,
    required this.preview,
    required this.targetCount,
    required this.success,
    required this.failed,
    required this.skipped,
    required this.mediaCount,
    required this.durationSeconds,
  });

  final String id;
  final DateTime createdAt;
  final String preview;
  final int targetCount;
  final int success;
  final int failed;
  final int skipped;
  final int mediaCount;
  final int durationSeconds;

  factory CampaignHistory.fromJson(Map<String, dynamic> json) => CampaignHistory(
        id: safeString(json['id']),
        createdAt: DateTime.tryParse(safeString(json['createdAt'])) ??
            DateTime.fromMillisecondsSinceEpoch(0),
        preview: safeString(json['preview']),
        targetCount: safeInt(json['targetCount']).clamp(0, 1 << 31).toInt(),
        success: safeInt(json['success']).clamp(0, 1 << 31).toInt(),
        failed: safeInt(json['failed']).clamp(0, 1 << 31).toInt(),
        skipped: safeInt(json['skipped']).clamp(0, 1 << 31).toInt(),
        mediaCount: safeInt(json['mediaCount']).clamp(0, 1 << 31).toInt(),
        durationSeconds: safeInt(json['durationSeconds']).clamp(0, 1 << 31).toInt(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'preview': preview,
        'targetCount': targetCount,
        'success': success,
        'failed': failed,
        'skipped': skipped,
        'mediaCount': mediaCount,
        'durationSeconds': durationSeconds,
      };

  static String encodeList(List<CampaignHistory> values) =>
      jsonEncode(values.map((value) => value.toJson()).toList());

  static List<CampaignHistory> decodeList(String source) {
    final decoded = jsonDecode(source);
    if (decoded is! List) return <CampaignHistory>[];
    return decoded
        .whereType<Map>()
        .map((item) => CampaignHistory.fromJson(safeStringMap(item)))
        .toList();
  }
}
