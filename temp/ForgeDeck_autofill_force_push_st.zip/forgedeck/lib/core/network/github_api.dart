import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:dio/dio.dart';

import '../../models/github_branch.dart';
import '../../models/github_content.dart';
import '../../models/github_issue.dart';
import '../../models/github_repo.dart';
import '../../models/github_user.dart';
import '../../models/github_workflow.dart';
import '../../models/zip_plan.dart';
import 'github_exception.dart';

class ForcePushProgress {
  const ForcePushProgress({
    required this.completed,
    required this.total,
    required this.message,
  });

  final int completed;
  final int total;
  final String message;

  double get fraction => total == 0 ? 0 : completed / total;
}

class GitHubApi {
  GitHubApi(String token)
      : _dio = Dio(
          BaseOptions(
            baseUrl: 'https://api.github.com',
            connectTimeout: const Duration(seconds: 20),
            receiveTimeout: const Duration(seconds: 45),
            sendTimeout: const Duration(seconds: 45),
            headers: <String, dynamic>{
              'Accept': 'application/vnd.github+json',
              'Authorization': 'Bearer $token',
              'X-GitHub-Api-Version': '2026-03-10',
              'User-Agent': 'ForgeDeck-Android',
            },
          ),
        );

  final Dio _dio;

  static String _encodePath(String value) {
    return value.split('/').map(Uri.encodeComponent).join('/');
  }

  static String _contentsEndpoint(String owner, String repo, String path) {
    final base = '/repos/$owner/$repo/contents';
    return path.isEmpty ? base : '$base/${_encodePath(path)}';
  }

  Future<T> _guard<T>(Future<T> Function() action) async {
    try {
      return await action();
    } on DioException catch (error) {
      throw GitHubException.fromDio(error);
    }
  }

  Future<String> _resolveDownloadLocation(String path) async {
    final response = await _dio.get<void>(
      path,
      options: Options(
        followRedirects: false,
        validateStatus: (status) => status != null && status >= 200 && status < 400,
      ),
    );
    final location = response.headers.value('location');
    if (location == null || location.isEmpty) {
      throw const GitHubException(
        message: 'GitHub tidak memulangkan pautan muat turun.',
      );
    }
    return location;
  }

  Dio _publicDownloadClient({required Duration receiveTimeout}) {
    return Dio(
      BaseOptions(
        connectTimeout: const Duration(seconds: 20),
        receiveTimeout: receiveTimeout,
        sendTimeout: const Duration(seconds: 45),
        headers: const <String, dynamic>{'User-Agent': 'ForgeDeck-Android'},
      ),
    );
  }

  Future<GitHubUser> getAuthenticatedUser() {
    return _guard(() async {
      final response = await _dio.get<Map<String, dynamic>>('/user');
      return GitHubUser.fromJson(response.data ?? const {});
    });
  }

  Future<List<Map<String, dynamic>>> _paged(
    String path, {
    Map<String, dynamic>? query,
    int maxPages = 50,
  }) {
    return _guard(() async {
      final output = <Map<String, dynamic>>[];
      for (var page = 1; page <= maxPages; page++) {
        final response = await _dio.get<List<dynamic>>(
          path,
          queryParameters: <String, dynamic>{
            ...?query,
            'per_page': 100,
            'page': page,
          },
        );
        final pageItems = response.data ?? const [];
        output.addAll(pageItems.whereType<Map<String, dynamic>>());
        if (pageItems.length < 100) break;
      }
      return output;
    });
  }

  Future<List<GitHubRepo>> listRepositories() async {
    final items = await _paged(
      '/user/repos',
      query: const <String, dynamic>{
        'affiliation': 'owner,collaborator,organization_member',
        'sort': 'updated',
        'direction': 'desc',
      },
    );
    return items.map(GitHubRepo.fromJson).toList();
  }

  Future<GitHubRepo> getRepository(String owner, String repo) {
    return _guard(() async {
      final response =
          await _dio.get<Map<String, dynamic>>('/repos/$owner/$repo');
      return GitHubRepo.fromJson(response.data ?? const {});
    });
  }

  Future<GitHubRepo> createRepository({
    required String name,
    required String description,
    required bool isPrivate,
    required bool autoInit,
  }) {
    return _guard(() async {
      final response = await _dio.post<Map<String, dynamic>>(
        '/user/repos',
        data: <String, dynamic>{
          'name': name,
          'description': description,
          'private': isPrivate,
          'auto_init': autoInit,
        },
      );
      return GitHubRepo.fromJson(response.data ?? const {});
    });
  }

  Future<GitHubRepo> updateRepository(
    String owner,
    String repo, {
    String? name,
    String? description,
    bool? isPrivate,
    bool? archived,
    String? defaultBranch,
  }) {
    return _guard(() async {
      final response = await _dio.patch<Map<String, dynamic>>(
        '/repos/$owner/$repo',
        data: <String, dynamic>{
          if (name != null) 'name': name,
          if (description != null) 'description': description,
          if (isPrivate != null) 'private': isPrivate,
          if (archived != null) 'archived': archived,
          if (defaultBranch != null) 'default_branch': defaultBranch,
        },
      );
      return GitHubRepo.fromJson(response.data ?? const {});
    });
  }

  Future<void> deleteRepository(String owner, String repo) {
    return _guard(() async {
      await _dio.delete<void>('/repos/$owner/$repo');
    });
  }

  Future<void> downloadRepositoryArchive(
    String owner,
    String repo, {
    required String ref,
    required String destinationPath,
    ProgressCallback? onReceiveProgress,
  }) {
    return _guard(() async {
      final location = await _resolveDownloadLocation(
        '/repos/$owner/$repo/zipball/${_encodePath(ref)}',
      );
      final client = _publicDownloadClient(
        receiveTimeout: const Duration(minutes: 5),
      );
      try {
        await client.download(
          location,
          destinationPath,
          onReceiveProgress: onReceiveProgress,
        );
      } finally {
        client.close(force: true);
      }
    });
  }

  Future<List<GitHubBranch>> listBranches(String owner, String repo) async {
    final items = await _paged('/repos/$owner/$repo/branches');
    return items.map(GitHubBranch.fromJson).toList();
  }

  Future<void> createBranch(
    String owner,
    String repo, {
    required String name,
    required String sourceSha,
  }) {
    return _guard(() async {
      await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/git/refs',
        data: <String, dynamic>{
          'ref': 'refs/heads/$name',
          'sha': sourceSha,
        },
      );
    });
  }

  Future<void> deleteBranch(String owner, String repo, String branch) {
    return _guard(() async {
      await _dio.delete<void>(
        '/repos/$owner/$repo/git/refs/heads/${_encodePath(branch)}',
      );
    });
  }

  Future<List<GitHubContent>> listContents(
    String owner,
    String repo, {
    String path = '',
    required String ref,
  }) {
    return _guard(() async {
      final response = await _dio.get<dynamic>(
        _contentsEndpoint(owner, repo, path),
        queryParameters: <String, dynamic>{'ref': ref},
      );
      final data = response.data;
      if (data is List<dynamic>) {
        return data
            .whereType<Map<String, dynamic>>()
            .map(GitHubContent.fromJson)
            .toList();
      }
      if (data is Map<String, dynamic>) {
        return <GitHubContent>[GitHubContent.fromJson(data)];
      }
      return const <GitHubContent>[];
    });
  }

  Future<GitHubContent> getContent(
    String owner,
    String repo,
    String path, {
    required String ref,
  }) {
    return _guard(() async {
      final response = await _dio.get<Map<String, dynamic>>(
        _contentsEndpoint(owner, repo, path),
        queryParameters: <String, dynamic>{'ref': ref},
      );
      return GitHubContent.fromJson(response.data ?? const {});
    });
  }

  Future<void> putFile(
    String owner,
    String repo,
    String path, {
    required List<int> bytes,
    required String message,
    required String branch,
    String? sha,
  }) {
    return _guard(() async {
      await _dio.put<Map<String, dynamic>>(
        _contentsEndpoint(owner, repo, path),
        data: <String, dynamic>{
          'message': message,
          'content': base64Encode(bytes),
          'branch': branch,
          if (sha != null && sha.isNotEmpty) 'sha': sha,
        },
      );
    });
  }

  Future<void> deleteFile(
    String owner,
    String repo,
    String path, {
    required String sha,
    required String message,
    required String branch,
  }) {
    return _guard(() async {
      await _dio.delete<Map<String, dynamic>>(
        _contentsEndpoint(owner, repo, path),
        data: <String, dynamic>{
          'message': message,
          'sha': sha,
          'branch': branch,
        },
      );
    });
  }

  Future<List<GitHubIssue>> listIssues(
    String owner,
    String repo, {
    String state = 'open',
  }) async {
    final items = await _paged(
      '/repos/$owner/$repo/issues',
      query: <String, dynamic>{'state': state, 'sort': 'updated'},
    );
    return items.map(GitHubIssue.fromJson).toList();
  }

  Future<GitHubIssue> createIssue(
    String owner,
    String repo, {
    required String title,
    required String body,
  }) {
    return _guard(() async {
      final response = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/issues',
        data: <String, dynamic>{'title': title, 'body': body},
      );
      return GitHubIssue.fromJson(response.data ?? const {});
    });
  }

  Future<void> setIssueState(
    String owner,
    String repo,
    int issueNumber, {
    required String state,
  }) {
    return _guard(() async {
      await _dio.patch<Map<String, dynamic>>(
        '/repos/$owner/$repo/issues/$issueNumber',
        data: <String, dynamic>{'state': state},
      );
    });
  }

  Future<List<GitHubIssue>> listPullRequests(
    String owner,
    String repo, {
    String state = 'open',
  }) async {
    final items = await _paged(
      '/repos/$owner/$repo/pulls',
      query: <String, dynamic>{'state': state, 'sort': 'updated'},
    );
    return items.map(GitHubIssue.fromJson).toList();
  }

  Future<GitHubIssue> createPullRequest(
    String owner,
    String repo, {
    required String title,
    required String body,
    required String head,
    required String base,
    bool draft = false,
  }) {
    return _guard(() async {
      final response = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/pulls',
        data: <String, dynamic>{
          'title': title,
          'body': body,
          'head': head,
          'base': base,
          'draft': draft,
        },
      );
      return GitHubIssue.fromJson(response.data ?? const {});
    });
  }

  Future<void> mergePullRequest(
    String owner,
    String repo,
    int pullNumber, {
    required String commitTitle,
    String mergeMethod = 'merge',
  }) {
    return _guard(() async {
      await _dio.put<Map<String, dynamic>>(
        '/repos/$owner/$repo/pulls/$pullNumber/merge',
        data: <String, dynamic>{
          'commit_title': commitTitle,
          'merge_method': mergeMethod,
        },
      );
    });
  }

  Future<List<GitHubWorkflow>> listWorkflows(String owner, String repo) {
    return _guard(() async {
      final response = await _dio.get<Map<String, dynamic>>(
        '/repos/$owner/$repo/actions/workflows',
        queryParameters: const <String, dynamic>{'per_page': 100},
      );
      final items = response.data?['workflows'] as List<dynamic>? ?? const [];
      return items
          .whereType<Map<String, dynamic>>()
          .map(GitHubWorkflow.fromJson)
          .toList();
    });
  }

  Future<List<GitHubWorkflowRun>> listWorkflowRuns(
    String owner,
    String repo,
  ) {
    return _guard(() async {
      final response = await _dio.get<Map<String, dynamic>>(
        '/repos/$owner/$repo/actions/runs',
        queryParameters: const <String, dynamic>{'per_page': 50},
      );
      final items = response.data?['workflow_runs'] as List<dynamic>? ?? const [];
      return items
          .whereType<Map<String, dynamic>>()
          .map(GitHubWorkflowRun.fromJson)
          .toList();
    });
  }

  Future<void> dispatchWorkflow(
    String owner,
    String repo,
    int workflowId, {
    required String ref,
    Map<String, dynamic> inputs = const {},
  }) {
    return _guard(() async {
      await _dio.post<void>(
        '/repos/$owner/$repo/actions/workflows/$workflowId/dispatches',
        data: <String, dynamic>{'ref': ref, 'inputs': inputs},
      );
    });
  }

  Future<void> rerunWorkflow(String owner, String repo, int runId) {
    return _guard(() async {
      await _dio.post<void>('/repos/$owner/$repo/actions/runs/$runId/rerun');
    });
  }

  Future<void> cancelWorkflow(String owner, String repo, int runId) {
    return _guard(() async {
      await _dio.post<void>('/repos/$owner/$repo/actions/runs/$runId/cancel');
    });
  }

  Future<String> getWorkflowRunLogs(String owner, String repo, int runId) {
    return _guard(() async {
      final location = await _resolveDownloadLocation(
        '/repos/$owner/$repo/actions/runs/$runId/logs',
      );
      final client = _publicDownloadClient(
        receiveTimeout: const Duration(minutes: 3),
      );
      late final Response<List<int>> response;
      try {
        response = await client.get<List<int>>(
          location,
          options: Options(responseType: ResponseType.bytes),
        );
      } finally {
        client.close(force: true);
      }
      final bytes = response.data ?? const <int>[];
      if (bytes.isEmpty) {
        throw const GitHubException(message: 'Log run ini kosong.');
      }

      Archive archive;
      try {
        archive = ZipDecoder().decodeBytes(bytes);
      } catch (_) {
        throw const GitHubException(
          message: 'Arkib log GitHub tidak dapat dibaca.',
        );
      }

      final files = archive.where((entry) => entry.isFile).toList()
        ..sort((a, b) => a.name.compareTo(b.name));
      final output = StringBuffer();
      for (final file in files) {
        final content = file.readBytes();
        if (content == null) continue;
        if (output.isNotEmpty) output.writeln('\n');
        output.writeln('===== ${file.name} =====');
        output.write(utf8.decode(content, allowMalformed: true));
      }
      if (output.isEmpty) {
        throw const GitHubException(message: 'Log run ini kosong.');
      }
      return output.toString();
    });
  }

  Future<List<Map<String, dynamic>>> listReleases(String owner, String repo) {
    return _paged('/repos/$owner/$repo/releases');
  }

  Future<Map<String, dynamic>> createRelease(
    String owner,
    String repo, {
    required String tagName,
    required String name,
    required String body,
    required String targetCommitish,
    bool draft = false,
    bool prerelease = false,
  }) {
    return _guard(() async {
      final response = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/releases',
        data: <String, dynamic>{
          'tag_name': tagName,
          'name': name,
          'body': body,
          'target_commitish': targetCommitish,
          'draft': draft,
          'prerelease': prerelease,
        },
      );
      return response.data ?? const {};
    });
  }

  Future<void> deleteRelease(String owner, String repo, int releaseId) {
    return _guard(() async {
      await _dio.delete<void>('/repos/$owner/$repo/releases/$releaseId');
    });
  }

  Future<List<Map<String, dynamic>>> listNotifications() {
    return _paged(
      '/notifications',
      query: const <String, dynamic>{'all': true, 'participating': false},
      maxPages: 10,
    );
  }

  Future<void> markNotificationsRead() {
    return _guard(() async {
      await _dio.put<void>('/notifications');
    });
  }

  Future<Map<String, dynamic>> getNotificationDetails(
    Map<String, dynamic> notification,
  ) async {
    final subject = notification['subject'] as Map<String, dynamic>? ?? const {};
    final subjectUrl = subject['url'] as String?;
    final latestCommentUrl = subject['latest_comment_url'] as String?;

    Future<Map<String, dynamic>> fetchOptional(String? url) async {
      if (url == null || url.isEmpty) return const <String, dynamic>{};
      try {
        final response = await _dio.get<Map<String, dynamic>>(url);
        return response.data ?? const <String, dynamic>{};
      } on DioException {
        return const <String, dynamic>{};
      }
    }

    final results = await Future.wait<Map<String, dynamic>>(<Future<Map<String, dynamic>>>[
      fetchOptional(subjectUrl),
      fetchOptional(latestCommentUrl),
    ]);
    return <String, dynamic>{
      'subject_detail': results[0],
      'latest_comment': results[1],
    };
  }

  Future<String> _createBlob(
    String owner,
    String repo,
    List<int> bytes,
  ) {
    return _guard(() async {
      final response = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/git/blobs',
        data: <String, dynamic>{
          'content': base64Encode(bytes),
          'encoding': 'base64',
        },
      );
      return response.data?['sha'] as String? ?? '';
    });
  }

  Future<String?> _tryGetHeadSha(
    String owner,
    String repo,
    String branch,
  ) async {
    try {
      final response = await _dio.get<Map<String, dynamic>>(
        '/repos/$owner/$repo/git/ref/heads/${_encodePath(branch)}',
      );
      final object = response.data?['object'] as Map<String, dynamic>?;
      return object?['sha'] as String?;
    } on DioException catch (error) {
      if (error.response?.statusCode == 404 ||
          error.response?.statusCode == 409) {
        return null;
      }
      throw GitHubException.fromDio(error);
    }
  }

  Future<void> forceReplaceBranchFromZip(
    String owner,
    String repo, {
    required String branch,
    required String commitMessage,
    required ZipPlan plan,
    required void Function(ForcePushProgress progress) onProgress,
  }) {
    return _guard(() async {
      final totalSteps = plan.entries.length + 4;
      var completed = 0;
      final treeItems = <Map<String, dynamic>>[];

      for (final entry in plan.entries) {
        onProgress(
          ForcePushProgress(
            completed: completed,
            total: totalSteps,
            message: 'Memuat naik ${entry.path}',
          ),
        );
        final sha = await _createBlob(owner, repo, entry.bytes);
        if (sha.isEmpty) {
          throw const GitHubException(message: 'GitHub tidak memulangkan SHA blob.');
        }
        treeItems.add(<String, dynamic>{
          'path': entry.path,
          'mode': entry.executable ? '100755' : '100644',
          'type': 'blob',
          'sha': sha,
        });
        completed++;
      }

      onProgress(
        ForcePushProgress(
          completed: completed,
          total: totalSteps,
          message: 'Membina tree baharu',
        ),
      );
      final treeResponse = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/git/trees',
        data: <String, dynamic>{'tree': treeItems},
      );
      final treeSha = treeResponse.data?['sha'] as String? ?? '';
      if (treeSha.isEmpty) {
        throw const GitHubException(message: 'GitHub tidak memulangkan SHA tree.');
      }
      completed++;

      onProgress(
        ForcePushProgress(
          completed: completed,
          total: totalSteps,
          message: 'Menyemak branch $branch',
        ),
      );
      final previousSha = await _tryGetHeadSha(owner, repo, branch);
      if (previousSha != null) {
        final currentCommit = await _dio.get<Map<String, dynamic>>(
          '/repos/$owner/$repo/git/commits/$previousSha',
        );
        final currentTree = currentCommit.data?['tree'] as Map<String, dynamic>?;
        final currentTreeSha = currentTree?['sha'] as String?;
        if (currentTreeSha == treeSha) {
          throw const GitHubException(
            message: 'Tiada perubahan. Kandungan ZIP sama dengan branch semasa.',
          );
        }
      }
      completed++;

      onProgress(
        ForcePushProgress(
          completed: completed,
          total: totalSteps,
          message: 'Mencipta commit',
        ),
      );
      final commitResponse = await _dio.post<Map<String, dynamic>>(
        '/repos/$owner/$repo/git/commits',
        data: <String, dynamic>{
          'message': commitMessage,
          'tree': treeSha,
          if (previousSha != null) 'parents': <String>[previousSha],
        },
      );
      final commitSha = commitResponse.data?['sha'] as String? ?? '';
      if (commitSha.isEmpty) {
        throw const GitHubException(message: 'GitHub tidak memulangkan SHA commit.');
      }
      completed++;

      onProgress(
        ForcePushProgress(
          completed: completed,
          total: totalSteps,
          message: 'Mengemas kini ref secara force',
        ),
      );
      if (previousSha == null) {
        await _dio.post<Map<String, dynamic>>(
          '/repos/$owner/$repo/git/refs',
          data: <String, dynamic>{
            'ref': 'refs/heads/$branch',
            'sha': commitSha,
          },
        );
      } else {
        await _dio.patch<Map<String, dynamic>>(
          '/repos/$owner/$repo/git/refs/heads/${_encodePath(branch)}',
          data: <String, dynamic>{'sha': commitSha, 'force': true},
        );
      }
      completed++;
      onProgress(
        ForcePushProgress(
          completed: completed,
          total: totalSteps,
          message: 'Selesai',
        ),
      );
    });
  }
}
