package my.tangga.enjin

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import my.tangga.Bahasa
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Runtime bersandbox untuk satu laluan bahasa.
 *
 * JavaScript berjalan terus dalam enjin JS WebView. Python berjalan pada Pyodide
 * (CPython dikompil ke WebAssembly) yang dibundel dalam aset — aplikasi tiada
 * kebenaran internet, jadi tiada apa yang dimuat turun semasa jalanan.
 *
 * WebView ini tidak pernah dipaparkan dan tidak pernah memuatkan URL luar. Aset
 * dihidangkan melalui WebViewAssetLoader kerana Pyodide memerlukan URL asas
 * sebenar untuk mencari fail `.wasm` dan `.zip` di sebelahnya.
 */
class EnjinJs(
    private val konteks: Context,
    private val bahasa: Bahasa,
) {

    private var web: WebView? = null
    private var siap: CompletableDeferred<Unit> = CompletableDeferred()
    private val menunggu = ConcurrentHashMap<String, CompletableDeferred<String>>()
    private val kaunter = AtomicLong(0)

    /**
     * Hanya satu permintaan pada satu masa.
     *
     * Tanpa ini, dua ketukan pantas menghantar dua permintaan serentak. Bila satu
     * tamat masa ia memusnahkan WebView, yang membatalkan permintaan satu lagi —
     * dan ketukan itu kelihatan seperti langsung tidak berfungsi.
     */
    private val kunci = Mutex()

    private val pemuatAset by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(konteks))
            .build()
    }

    private fun bacaAset(nama: String): String =
        konteks.assets.open(nama).bufferedReader().use { it.readText() }

    inner class Jambatan {
        @JavascriptInterface
        fun balas(id: String, json: String) {
            menunggu.remove(id)?.complete(json)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun bina() = withContext(Dispatchers.Main) {
        web?.destroy()
        menunggu.values.forEach {
            it.completeExceptionally(IllegalStateException("enjin dimulakan semula"))
        }
        menunggu.clear()
        siap = CompletableDeferred()

        val w = WebView(konteks)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            blockNetworkLoads = true
        }
        w.addJavascriptInterface(Jambatan(), "AndroidJambatan")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                v: WebView,
                r: WebResourceRequest,
            ): WebResourceResponse? = pemuatAset.shouldInterceptRequest(r.url)

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true

            override fun onPageFinished(v: WebView, url: String) {
                // Skrip disuntik selepas halaman siap, bukan ditanam dalam HTML.
                // Bank tugasan mengandungi rentetan seperti "<script>" yang akan
                // memecahkan dokumen kalau ia ditulis sebagai teks HTML.
                suntikBerturut(v, bahasa.aset.toMutableList())
            }
        }
        w.loadUrl(ASAS + "kosong.html")
        web = w
    }

    /** Aset mesti dinilai mengikut susunan: pyodide.js dahulu, kemudian python.js. */
    private fun suntikBerturut(v: WebView, baki: MutableList<String>) {
        if (baki.isEmpty()) {
            siap.complete(Unit)
            return
        }
        val nama = baki.removeAt(0)
        val sumber = runCatching { bacaAset(nama) }.getOrNull()
        if (sumber == null) {
            // Aset hilang (contohnya Pyodide belum dipasang). Teruskan supaya
            // panggilan seterusnya melaporkan kegagalan sebenar, bukan tergantung.
            siap.complete(Unit)
            return
        }
        v.evaluateJavascript(sumber) { suntikBerturut(v, baki) }
    }

    private suspend fun sediakan() {
        if (web == null) bina()
        siap.await()
    }

    suspend fun mula() = kunci.withLock { sediakan() }

    private suspend fun laksana(js: String, id: String, hadMs: Long): String? = kunci.withLock {
        sediakan()
        val d = CompletableDeferred<String>()
        menunggu[id] = d
        withContext(Dispatchers.Main) { web?.evaluateJavascript(js, null) }
        val hasil = withTimeoutOrNull(hadMs) { runCatching { d.await() }.getOrNull() }
        menunggu.remove(id)
        if (hasil == null) bina() // JS tergantung — buang dan bina semula
        hasil
    }

    private fun idBaharu() = "p" + kaunter.incrementAndGet()

    /** Panggilan segerak: nilai ekspresi dihantar terus ke jambatan. */
    private suspend fun tanya(ekspresi: String, hadMs: Long = 8_000): String? {
        val id = idBaharu()
        return laksana("AndroidJambatan.balas('$id', ${bahasa.global}.$ekspresi);", id, hadMs)
    }

    suspend fun jumlahLevel(): Int =
        tanya("jumlah()")?.filter { it.isDigit() }?.toIntOrNull() ?: 0

    suspend fun bab(): String? = tanya("bab()")

    suspend fun level(n: Int): String? = tanya("level($n)")

    suspend fun semakRamal(n: Int, teks: String): String? =
        tanya("semakRamal($n, ${petik(teks)})")

    /**
     * Menjalankan kod pengguna. Kedua-dua enjin memulangkan Promise, jadi satu
     * bentuk panggilan memadai.
     */
    suspend fun jalan(n: Int, kod: String, hadMs: Long = hadJalan()): String {
        val id = idBaharu()
        val js = "Promise.resolve(${bahasa.global}.jalan($n, ${petik(kod)})).then(" +
            "function (r) { AndroidJambatan.balas('$id', r); }, " +
            "function (e) { AndroidJambatan.balas('$id', JSON.stringify({ fatal: String(e && e.message || e) })); });"
        return laksana(js, id, hadMs)
            ?: "{\"fatal\":\"Masa tamat selepas ${hadMs / 1000} saat \\u2014 kemungkinan besar ada gelung yang tak berhenti.\"}"
    }

    /**
     * Menghangatkan enjin supaya panggilan pertama tidak terasa rosak.
     * Untuk Python ini memuatkan Pyodide, yang mengambil beberapa saat.
     */
    suspend fun panaskan(): Boolean {
        if (bahasa != Bahasa.PYTHON) {
            mula()
            return true
        }
        val id = idBaharu()
        val js = "Promise.resolve(TanggaPython.sedia()).then(" +
            "function () { AndroidJambatan.balas('$id', '{\"ok\":true}'); }, " +
            "function (e) { AndroidJambatan.balas('$id', JSON.stringify({ ok: false, ralat: String(e) })); });"
        return laksana(js, id, 60_000)?.contains("\"ok\":true") == true
    }

    private fun hadJalan() = if (bahasa == Bahasa.PYTHON) 20_000L else 4_000L

    fun lepaskan() {
        web?.destroy()
        web = null
    }

    /** Melarikan rentetan Kotlin dengan selamat menjadi literal JavaScript. */
    private fun petik(s: String): String = JSONObject.quote(s)

    private companion object {
        const val ASAS = "https://appassets.androidplatform.net/assets/"
    }
}
