package my.tangga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Bahasa
import my.tangga.Keadaan

@Composable
fun BahasaSkrin(k: Keadaan, padaPilih: (Bahasa) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Warna.Dasar)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp),
    ) {
        Spacer(Modifier.height(64.dp))
        Text(
            "TANGGA",
            color = Warna.Oker,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            letterSpacing = 8.sp,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Pilih bahasa yang kau nak belajar. Progres setiap laluan disimpan berasingan, " +
                "jadi kau boleh bertukar bila-bila tanpa kehilangan apa-apa.",
            color = Warna.Senyap,
            fontSize = 14.5.sp,
            lineHeight = 23.sp,
        )
        Spacer(Modifier.height(28.dp))

        Bahasa.entries.forEach { b ->
            val progres = k.semua.untuk(b)
            KadBahasa(
                bahasa = b,
                siap = progres.siap.size,
                xp = progres.xp,
                sibuk = k.menyediakanEnjin && k.bahasa == b,
                hidup = !k.menyediakanEnjin,
            ) { padaPilih(b) }
            Spacer(Modifier.height(10.dp))
        }

        k.ralatEnjin?.let {
            Spacer(Modifier.height(6.dp))
            Nota(it, merah = true)
        }

        if (k.menyediakanEnjin && k.bahasa == Bahasa.PYTHON) {
            Spacer(Modifier.height(10.dp))
            Nota(
                "Python berjalan pada CPython sebenar yang dibundel dalam aplikasi. " +
                    "Permulaan pertama mengambil beberapa saat; selepas itu ia serta-merta."
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun KadBahasa(
    bahasa: Bahasa,
    siap: Int,
    xp: Int,
    sibuk: Boolean,
    hidup: Boolean,
    padaKlik: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .border(1.dp, if (sibuk) Warna.Oker else Warna.Garis, RectangleShape)
            .background(Warna.Panel)
            .clickable(enabled = hidup) { padaKlik() },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .width(72.dp)
                .fillMaxHeight()
                .background(if (sibuk) Warna.Oker.copy(alpha = 0.14f) else Warna.Panel2),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                bahasa.kod.uppercase(),
                color = Warna.Oker,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
            )
        }
        Box(Modifier.width(1.dp).fillMaxHeight().background(Warna.Garis))
        Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 14.dp)) {
            Text(
                bahasa.label,
                color = if (hidup) Warna.Dakwat else Warna.Dakwat.copy(alpha = 0.6f),
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (sibuk) "Menyediakan enjin\u2026" else bahasa.nota,
                color = if (sibuk) Warna.Oker else Warna.Senyap,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
            )
            if (siap > 0 && !sibuk) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "$siap level siap \u00b7 $xp XP",
                    color = Warna.Hijau,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
            }
        }
        Text(
            "\u2192",
            color = if (hidup) Warna.Oker else Warna.Senyap,
            fontSize = 20.sp,
            modifier = Modifier.padding(end = 16.dp),
        )
    }
}
