package my.tangga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Keadaan
import my.tangga.KeputusanKes
import my.tangga.Level

@Composable
fun LevelSkrin(
    k: Keadaan,
    padaKembali: () -> Unit,
    padaKodUbah: (String) -> Unit,
    padaTeksUbah: (String) -> Unit,
    padaJalan: () -> Unit,
    padaSemakRamal: () -> Unit,
    padaPilih: (Int) -> Unit,
    padaPetunjuk: () -> Unit,
    padaJawapan: () -> Unit,
    padaSetSemula: () -> Unit,
    padaSebelum: () -> Unit,
    padaSeterusnya: () -> Unit,
) {
    val level = k.level ?: return
    var medan by remember { mutableStateOf(TextFieldValue(k.kod)) }

    // Hanya selaraskan bila kod benar-benar diganti dari luar — tukar level atau
    // butang "Set semula". Mengikut k.kod akan melompatkan kursor semasa menaip.
    LaunchedEffect(k.kodVersi) {
        medan = TextFieldValue(k.kod)
    }

    Column(Modifier.fillMaxSize().background(Warna.Dasar)) {

        Row(
            Modifier
                .fillMaxWidth()
                .background(Warna.Panel)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Butang("\u2190 Peta", hidup = !k.memuatLevel, padaKlik = padaKembali)
            Spacer(Modifier.weight(1f))
            Text(
                "${k.progres.xp} XP  \u00b7  ${k.progres.rentetan} hari",
                color = Warna.Senyap,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp),
        ) {
            item { KepalaLevel(level, k.progres.sudahSiap(level.n)) }

            k.ralatEnjin?.let { mesej ->
                item { Nota(mesej, merah = true) }
            }

            item {
                Text(
                    huraiPenanda(level.brief),
                    color = Warna.Dakwat,
                    fontSize = 14.5.sp,
                    lineHeight = 23.sp,
                )
            }

            when (level.jenis) {
                "ramal" -> {
                    item { BlokKod(level.kod.orEmpty()) }
                    item {
                        BasicTextField(
                            value = k.jawapanTeks,
                            onValueChange = padaTeksUbah,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Warna.Garis, RectangleShape)
                                .background(Warna.Editor)
                                .padding(12.dp),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(
                                color = Warna.Dakwat,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 15.sp,
                            ),
                            cursorBrush = SolidColor(Warna.Oker),
                            decorationBox = { medanDalam ->
                                if (k.jawapanTeks.isEmpty()) {
                                    Text(
                                        "Taip jawapan",
                                        color = Warna.Senyap,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 15.sp,
                                    )
                                }
                                medanDalam()
                            },
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Butang("Semak", utama = true, padaKlik = padaSemakRamal)
                            if (k.petunjukDibuka < level.petunjuk.size) {
                                Butang("Petunjuk", padaKlik = padaPetunjuk)
                            }
                        }
                    }
                    k.hasilRamal?.let { h ->
                        item {
                            Nota(
                                when {
                                    h.lulus -> "Betul."
                                    k.cuba >= 3 -> "Belum betul. Jawapannya: ${h.jangka}"
                                    else -> "Belum betul. Cuba lagi."
                                },
                                merah = !h.lulus,
                            )
                        }
                        if (h.lulus) item { PengesahanSimpan() }
                    }
                }

                "pilih" -> {
                    item {
                        Text(
                            huraiPenanda(level.soalan.orEmpty()),
                            color = Warna.Dakwat,
                            fontSize = 14.5.sp,
                            lineHeight = 23.sp,
                        )
                    }
                    itemsIndexed(level.pilihan) { i, teks ->
                        val warnaSempadan = when {
                            k.pilihanDipilih == null -> Warna.Garis
                            i == level.betul -> Warna.Hijau
                            i == k.pilihanDipilih -> Warna.Bata
                            else -> Warna.Garis
                        }
                        val latar = when {
                            k.pilihanDipilih == null -> Warna.Panel2
                            i == level.betul -> Warna.Hijau.copy(alpha = 0.14f)
                            i == k.pilihanDipilih -> Warna.Bata.copy(alpha = 0.14f)
                            else -> Warna.Panel2
                        }
                        Text(
                            huraiPenanda(teks),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, warnaSempadan, RectangleShape)
                                .background(latar)
                                .clickable(enabled = k.pilihanDipilih == null) { padaPilih(i) }
                                .padding(horizontal = 14.dp, vertical = 13.dp),
                            color = Warna.Dakwat,
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                        )
                    }
                    if (k.pilihanDipilih != null) {
                        item {
                            Nota(
                                level.huraian.orEmpty(),
                                merah = k.pilihanDipilih != level.betul,
                            )
                        }
                        if (k.pilihanDipilih == level.betul) {
                            item { PengesahanSimpan() }
                        }
                    }
                }

                else -> {
                    item {
                        EditorKod(
                            nilai = medan,
                            padaUbah = { baharu ->
                                medan = baharu
                                padaKodUbah(baharu.text)
                            },
                        )
                    }
                    item {
                        FlowBaris {
                            Butang(
                                if (k.berjalan) "Menjalankan\u2026" else "Jalankan ujian",
                                utama = true,
                                hidup = !k.berjalan,
                                padaKlik = padaJalan,
                            )
                            if (k.petunjukDibuka < level.petunjuk.size) {
                                Butang("Petunjuk", padaKlik = padaPetunjuk)
                            }
                            Butang("Set semula", padaKlik = padaSetSemula)
                            if (k.cuba >= 3 && !k.jawapanDibuka && level.jawapan.isNotEmpty()) {
                                Butang("Buka jawapan", padaKlik = padaJawapan)
                            }
                        }
                    }
                    k.keputusan?.fatal?.let { item { Nota(it, merah = true) } }
                    k.keputusan?.results?.let { hasil ->
                        item { JadualKeputusan(level, hasil) }
                    }
                }
            }

            itemsIndexed(level.petunjuk.take(k.petunjukDibuka)) { i, h ->
                Nota(
                    buildAnnotatedString {
                        withStyle(
                            SpanStyle(
                                color = Warna.Senyap,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                            )
                        ) { append("PETUNJUK ${i + 1} \u00b7 ") }
                        append(huraiPenanda(h))
                    }
                )
            }

            if (k.jawapanDibuka && level.jawapan.isNotEmpty()) {
                item {
                    Column {
                        Eyebrow("Satu jawapan yang berfungsi")
                        Spacer(Modifier.height(6.dp))
                        BlokKod(level.jawapan)
                    }
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis))
        Row(
            Modifier
                .fillMaxWidth()
                .background(Warna.Panel)
                .padding(horizontal = 14.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        ) {
            val sibuk = k.memuatLevel || k.berjalan
            Butang(
                "\u2190 Sebelum",
                hidup = level.n > 1 && !sibuk,
            ) { padaSebelum() }
            Butang(
                when {
                    k.memuatLevel -> "Memuat\u2026"
                    !k.bolehKeSeterusnya -> "\ud83d\udd12 Jawab dahulu"
                    else -> "Seterusnya \u2192"
                },
                utama = k.bolehKeSeterusnya,
                hidup = !sibuk && k.bolehKeSeterusnya,
            ) { padaSeterusnya() }
        }
    }
}

@Composable
private fun KepalaLevel(level: Level, siap: Boolean) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Warna.Garis, RectangleShape)
            .background(Warna.Panel)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                Modifier
                    .widthIn(min = 90.dp)
                    .fillMaxHeight()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "${level.n}",
                    color = Warna.Oker,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                )
            }
            Box(Modifier.width(1.dp).fillMaxHeight().background(Warna.Garis))
            Column(
                Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.Center,
            ) {
                Eyebrow(
                    "B%02d \u00b7 %s \u00b7 %s%s".format(
                        level.bab, level.namaBab, level.labelJenis, if (siap) " \u00b7 siap" else ""
                    )
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    level.tajuk,
                    color = Warna.Dakwat,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 21.sp,
                )
            }
        }
    }
}

@Composable
private fun JadualKeputusan(level: Level, hasil: List<KeputusanKes>) {
    val semua = hasil.all { it.lulus }
    Column(Modifier.fillMaxWidth().border(1.dp, Warna.Garis, RectangleShape)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "${hasil.count { it.lulus }} / ${hasil.size} LULUS",
                color = if (semua) Warna.Hijau else Warna.Bata,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.5.sp,
                letterSpacing = 1.2.sp,
            )
            if (semua) {
                Text(
                    "\u2713 SELESAI \u00b7 PROGRES DISIMPAN",
                    color = Warna.Hijau,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    letterSpacing = 1.2.sp,
                )
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis))
        hasil.forEachIndexed { i, r ->
            val kes = level.kes.getOrNull(i)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                Text(
                    if (r.lulus) "\u2713" else "\u2715",
                    color = if (r.lulus) Warna.Hijau else Warna.Bata,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                )
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Warna.Senyap)) { append("masuk ") }
                        append(kes?.hujah.orEmpty())
                        withStyle(SpanStyle(color = Warna.Senyap)) { append("  jangka ") }
                        append(kes?.jangka.orEmpty())
                        if (!r.lulus) {
                            append("\n")
                            withStyle(SpanStyle(color = Warna.Senyap)) { append("dapat ") }
                            append(r.papar)
                        }
                    },
                    color = Warna.Dakwat.copy(alpha = 0.85f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 19.sp,
                )
            }
            if (i < hasil.lastIndex) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Warna.Garis2))
            }
        }
    }
}

@Composable
private fun PengesahanSimpan() {
    Text(
        "\u2713 PROGRES DISIMPAN",
        color = Warna.Hijau,
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        letterSpacing = 1.2.sp,
    )
}

/** Susunan butang ringkas yang berbalut ke baris seterusnya. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun FlowBaris(kandungan: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { kandungan() }
}
