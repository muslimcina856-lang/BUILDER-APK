package my.tangga

import kotlinx.serialization.Serializable

/** Laluan pembelajaran. Setiap satu ada enjin, bank tugasan dan progres sendiri. */
enum class Bahasa(
    val kod: String,
    val label: String,
    val nota: String,
    val aset: List<String>,
    val global: String,
) {
    JAVASCRIPT(
        kod = "js",
        label = "JavaScript",
        nota = "26 bab \u00b7 3,500 level",
        aset = listOf("enjin.js"),
        global = "TanggaEnjin",
    ),
    PYTHON(
        kod = "py",
        label = "Python",
        nota = "12 bab \u00b7 1,800 level",
        aset = listOf("pyodide/pyodide.js", "python.js"),
        global = "TanggaPython",
    );

    companion object {
        fun dari(kod: String?): Bahasa = entries.firstOrNull { it.kod == kod } ?: JAVASCRIPT
    }
}

@Serializable
data class Bab(
    val n: Int,
    val nama: String,
    val dari: Int,
    val hingga: Int,
) {
    val bilanganLevel: Int get() = hingga - dari + 1
}

@Serializable
data class Kes(
    val hujah: String,
    val jangka: String,
)

/** Satu level, sebagaimana dihantar oleh enjin JS. */
@Serializable
data class Level(
    val n: Int,
    val bab: Int,
    val namaBab: String,
    val jenis: String,
    val tajuk: String,
    val brief: String,
    val petunjuk: List<String> = emptyList(),

    // jenis = ramal
    val kod: String? = null,

    // jenis = pilih
    val soalan: String? = null,
    val pilihan: List<String> = emptyList(),
    val betul: Int = -1,
    val huraian: String? = null,

    // jenis = tulis / baiki / kukuh
    val fn: String? = null,
    val starter: String? = null,
    val jawapan: String = "",
    val kes: List<Kes> = emptyList(),
) {
    val adaEditor: Boolean get() = jenis == "tulis" || jenis == "baiki" || jenis == "kukuh"

    val labelJenis: String
        get() = when (jenis) {
            "tulis" -> "Tulis"
            "baiki" -> "Baiki"
            "kukuh" -> "Kukuhkan"
            "ramal" -> "Ramal"
            "pilih" -> "Pilih"
            else -> jenis
        }
}

@Serializable
data class KeputusanKes(
    val lulus: Boolean,
    val papar: String,
)

@Serializable
data class Keputusan(
    val fatal: String? = null,
    val results: List<KeputusanKes>? = null,
) {
    val semuaLulus: Boolean get() = results?.isNotEmpty() == true && results.all { it.lulus }
    val bilanganLulus: Int get() = results?.count { it.lulus } ?: 0
}

@Serializable
data class HasilRamal(
    val lulus: Boolean,
    val jangka: String,
)

/** Progres pengguna. Disimpan sebagai satu blob JSON dalam DataStore. */
@Serializable
data class Progres(
    val siap: Map<String, Int> = emptyMap(),
    val xp: Int = 0,
    val sekarang: Int = 1,
    val hariAkhir: String? = null,
    val rentetan: Int = 0,
) {
    fun sudahSiap(n: Int) = siap.containsKey(n.toString())

    fun siapDalam(b: Bab) = (b.dari..b.hingga).count { sudahSiap(it) }

    /**
     * Bab boleh dimasuki bila-bila masa. Di dalam bab, kau mesti menyelesaikan
     * setiap level sebelum yang seterusnya terbuka.
     */
    fun bolehBuka(n: Int, bab: Bab) = n <= bab.dari || sudahSiap(n - 1)

    /** Level pertama yang belum selesai dalam bab — titik sambung semula. */
    fun sambungDalam(bab: Bab) =
        (bab.dari..bab.hingga).firstOrNull { !sudahSiap(it) } ?: bab.hingga
}

/** Progres disimpan berasingan untuk setiap bahasa. */
@Serializable
data class SemuaProgres(
    val js: Progres = Progres(),
    val py: Progres = Progres(),
    val bahasaAkhir: String? = null,
) {
    fun untuk(b: Bahasa) = if (b == Bahasa.JAVASCRIPT) js else py

    fun tetapkan(b: Bahasa, p: Progres) =
        if (b == Bahasa.JAVASCRIPT) copy(js = p, bahasaAkhir = b.kod)
        else copy(py = p, bahasaAkhir = b.kod)
}
