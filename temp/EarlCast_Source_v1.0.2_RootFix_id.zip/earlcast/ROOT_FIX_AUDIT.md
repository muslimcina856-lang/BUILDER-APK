# Root Fix Audit — 2026-08-07

| Masalah | Punca | Pembaikan 1.0.2 |
|---|---|---|
| `launch_background.xml` AAPT failure | raw hex digunakan pada `android:drawable` | guna `@color/launch_background` |
| `libnode.so` missing semasa CMake | package `node_flutter` tidak membawa runtime native | fork plugin lokal + Gradle auto-prepare Node Mobile 18.20.4 |
| CI bergantung `.pub-cache` | native plugin datang dari hosted pub package | dependency `path: packages/node_flutter` |
| Node headers boleh hilang selepas `.so` ditampal | CMake perlukan `include/node` juga | runtime validator wajib semak headers + semua ABI |
| `libnode.so` link tetapi boleh tak masuk APK | imported CMake library tidak cukup sebagai jaminan packaging semua AGP | `jniLibs.srcDirs = ['libnode/bin']` + `pickFirst` native libs |
| Native C++ runtime mismatch | STL/NDK bridge tidak diselaraskan | NDK 28.2.13676358 + `-DANDROID_STL=c++_shared` + ABI filters |
| `engine.booted` boleh hilang | EventChannel listener belum attach ketika Node boot cepat | bounded native pending-event buffer, flush pada `onListen` |
| App boleh crash sebelum UI bila native load gagal | `System.loadLibrary` dibuat dalam companion initializer | lazy native load dalam startup thread + `engine.error` |
| `libsignal` transitif berubah ikut HEAD GitHub | Baileys 6.7.8 dependency asal tidak pin commit dalam package spec | npm override kepada codeload commit `83a3e3a...` daripada yarn.lock rasmi v6.7.8 |
| Baileys 7 boleh tersalah aktif pada Node18 | helper lama menyalin manifest 7 terus | `use_baileys7.*` kini refuse dengan error |
| `await Nodejs.start()` boleh tersangkut | upstream result dihantar selepas `node::Start()` tamat | local Kotlin returns selepas thread launch; JS readiness melalui event |
| Flutter → Node command tidak sampai | JS bridge hanya register `_EVENTS_` | Dart wrap `{tag,message}` dan hantar ke `_EVENTS_` |
| `process._linkedBinding("flutter_bridge")` boleh gagal pada Node18 | `NAPI_MODULE_X` Node18 mengabaikan flag `NM_F_LINKED` | daftar `napi_module` sendiri sebelum `node::Start()` |
| Race handle native ketika command pertama | Flutter main thread boleh queue semasa Node thread mendaftar channel | publish/read `uv_async_t*` di bawah mutex yang sama |
| App upgrade boleh guna bridge JS lama | builtin bridge pernah disalin sekali ke private storage | refresh builtin bridge setiap process start |
| Command async boleh bertindih | EventEmitter tidak await Promise listener | `commandChain` serialize semua command |
| UI ready terlalu awal | hanya tunggu `engine.booted` | tunggu `engine.booted`, hantar `init`, kemudian tunggu `engine.ready` |
| Native startup failure hanya timeout | tiada immediate Dart failure | `engine.error`/`engine.nativeExit` fail pending startup completer |
| Node assets boleh basi | duplicate root + Android assets | root `nodejs-project/` satu source; generated assets semasa Gradle build |
| `node_modules` tiada dalam generic CI | setup manual tidak dijalankan | `prepareEarlCastNodeProject` menjalankan npm semasa Gradle build |
| First launch boleh gagal pada hidden npm asset | AAPT boleh abaikan dot-files tetapi `file.list` asal masih boleh menyenaraikannya | staging buang semua dot-prefixed file/dir sebelum fingerprint + file list |
| Runner Node terlalu lama memberi error lewat | npm staging tiada preflight version | Gradle/build scripts fail-fast jika host Node <18 |
| First launch copy lambat berulang | recursive assets copy tanpa marker/list | generated `file.list` + non-hidden SHA-256 asset marker |
| security patch boleh dilangkau | npm install luar pipeline | postinstall + explicit Gradle `--verify` |
| Gradle/AGP/Kotlin warning lama | toolchain lama | Gradle 8.14.5 / AGP 8.11.1 / Kotlin 2.2.20 |
| Gradle distribution tidak disahkan | bootstrap downloader biasa | pinned SHA-256 dalam properties + launcher |
| group spinner boleh kekal | `command.error(getGroups)` tidak reset state | reset `groupsLoading` pada failed action |
| setup boleh menimpa root fixes | `flutter create` dijalankan bila wrapper dianggap kurang | bootstrap sekarang validate-only, tidak regenerate scaffold |

## Yang bukan boleh “dipatch” dalam source app semata-mata

- Node.js Mobile 18.20.4 published binary belum menyelesaikan keperluan 16 KB page alignment untuk semua target Play Store moden.
- Baileys ialah protokol WhatsApp Web tidak rasmi dan perubahan server boleh memecahkan keserasian.
- Baileys 7 memerlukan runtime Node lebih baharu daripada official Node Mobile release yang digunakan dalam build standard ini.

Ketiga-tiga perkara ini dilabel sebagai limit upstream, bukan dianggap selesai secara palsu.
