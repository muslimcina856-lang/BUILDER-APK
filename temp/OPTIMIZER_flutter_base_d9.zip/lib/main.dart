
import 'package:flutter/material.dart';

void main() {
  runApp(const OptimizerApp());
}

class OptimizerApp extends StatelessWidget {
  const OptimizerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OPTIMIZER',
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OPTIMIZER')),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: NetworkImage('https://images.unsplash.com/photo-1506744038136-46273834b3fb'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: ElevatedButton(
            child: const Text('Ressolusi'),
            onPressed: () {
              showDialog(
                context: context,
                builder: (c) => AlertDialog(
                  title: const Text('Pengubah Resolusi'),
                  content: const Text(
                    'UI contoh. Mengubah resolusi sistem Android memerlukan hak khusus (root/ADB/device owner).'
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('Tutup'),
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
