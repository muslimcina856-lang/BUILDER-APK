import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:android_intent_plus/android_intent.dart';

void main() => runApp(const BoosterApp());

// ============================================================
//  THEME - BIRU ELEGAN
// ============================================================
class AppColors {
  static const bg = Color(0xFF090D1A);
  static const surface = Color(0xFF0F1526);
  static const cardTop = Color(0xFF141B30);
  static const cardBottom = Color(0xFF0D1322);
  static const border = Color(0xFF1E2C4A);
  static const primary = Color(0xFF3B82F6);
  static const primaryLight = Color(0xFF60A5FA);
  static const accent = Color(0xFF22D3EE);
  static const textPrimary = Color(0xFFE7EDF7);
  static const textSecondary = Color(0xFF7C8AA8);
  static const danger = Color(0xFFFF6B6B);
  static const success = Color(0xFF4ADE80);
}

class BoosterApp extends StatelessWidget {
  const BoosterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Device Booster',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.bg,
        primaryColor: AppColors.primary,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.primary,
          secondary: AppColors.accent,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.bg,
          elevation: 0,
        ),
        textTheme: ThemeData.dark().textTheme.apply(
              bodyColor: AppColors.textPrimary,
              displayColor: AppColors.textPrimary,
            ),
      ),
      home: const SplashGate(),
    );
  }
}

// ============================================================
//  SPLASH GATE - cek status login key
// ============================================================
class SplashGate extends StatefulWidget {
  const SplashGate({super.key});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  @override
  void initState() {
    super.initState();
    _checkUnlocked();
  }

  Future<void> _checkUnlocked() async {
    final prefs = await SharedPreferences.getInstance();
    final unlocked = prefs.getBool('unlocked') ?? false;
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => unlocked ? const DashboardPage() : const KeyPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: CircularProgressIndicator(color: AppColors.primary),
      ),
    );
  }
}

// ============================================================
//  KEY PAGE (GRATIS - bukan berbayar)
// ============================================================
class KeyPage extends StatefulWidget {
  const KeyPage({super.key});

  @override
  State<KeyPage> createState() => _KeyPageState();
}

class _KeyPageState extends State<KeyPage> {
  static const String _validKey = 'BOOSTER-FREE';
  final TextEditingController _keyController = TextEditingController();
  bool _obscure = true;
  bool _isLoading = false;
  String? _error;

  @override
  void dispose() {
    _keyController.dispose();
    super.dispose();
  }

  Future<void> _submitKey() async {
    final input = _keyController.text.trim();
    if (input.isEmpty) {
      setState(() => _error = 'Masukkan key terlebih dahulu');
      return;
    }
    setState(() {
      _isLoading = true;
      _error = null;
    });

    await Future.delayed(const Duration(milliseconds: 500));

    if (input.toUpperCase() == _validKey) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('unlocked', true);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const DashboardPage()),
      );
    } else {
      setState(() {
        _isLoading = false;
        _error = 'Key salah. Gunakan key yang tertera di bawah.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [AppColors.primary, AppColors.accent],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.35),
                        blurRadius: 30,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.shield_outlined,
                      color: Colors.white, size: 44),
                ),
                const SizedBox(height: 24),
                const Text(
                  'DEVICE BOOSTER',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Performance Monitor & Optimizer',
                  style: TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 40),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [AppColors.cardTop, AppColors.cardBottom],
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Masukkan Access Key',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _keyController,
                        obscureText: _obscure,
                        textAlign: TextAlign.left,
                        style: const TextStyle(color: AppColors.textPrimary),
                        onSubmitted: (_) => _submitKey(),
                        decoration: InputDecoration(
                          hintText: 'Contoh: BOOSTER-FREE',
                          hintStyle:
                              const TextStyle(color: AppColors.textSecondary),
                          filled: true,
                          fillColor: AppColors.surface,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide:
                                const BorderSide(color: AppColors.border),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide:
                                const BorderSide(color: AppColors.border),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide:
                                const BorderSide(color: AppColors.primary),
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: AppColors.textSecondary,
                              size: 20,
                            ),
                            onPressed: () =>
                                setState(() => _obscure = !_obscure),
                          ),
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Icon(Icons.error_outline,
                                color: AppColors.danger, size: 16),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _error!,
                                style: const TextStyle(
                                    color: AppColors.danger, fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _submitKey,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            disabledBackgroundColor:
                                AppColors.primary.withOpacity(0.5),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 0,
                          ),
                          child: _isLoading
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2.4,
                                  ),
                                )
                              : const Text(
                                  'MASUK',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 12),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: AppColors.primary.withOpacity(0.25)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.info_outline,
                                color: AppColors.primaryLight, size: 16),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Text(
                                'App ini gratis. Key akses: BOOSTER-FREE',
                                style: TextStyle(
                                  fontSize: 11.5,
                                  color: AppColors.primaryLight,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
//  BOOSTER SERVICE - aksi nyata, non-root
// ============================================================
class BoosterService {
  /// Membersihkan cache directory aplikasi (nyata, aman, non-root)
  static Future<int> clearAppCache() async {
    int filesDeleted = 0;
    try {
      final dir = await getTemporaryDirectory();
      if (await dir.exists()) {
        final entries = dir.listSync(recursive: false);
        for (final entity in entries) {
          try {
            if (entity is File) {
              await entity.delete();
              filesDeleted++;
            } else if (entity is Directory) {
              await entity.delete(recursive: true);
              filesDeleted++;
            }
          } catch (_) {
            // lewati file yang sedang dipakai / tidak bisa dihapus
          }
        }
      }
    } catch (_) {
      // direktori tidak tersedia
    }
    return filesDeleted;
  }

  /// Membaca estimasi pemakaian memori dari /proc/meminfo (Android, non-root)
  /// Mengembalikan null jika tidak bisa diakses (dibatasi OS) - tidak crash.
  static Future<double?> readMemoryUsagePercent() async {
    if (!Platform.isAndroid) return null;
    try {
      final file = File('/proc/meminfo');
      if (!await file.exists()) return null;
      final lines = await file.readAsLines();
      int? total;
      int? available;
      for (final line in lines) {
        if (line.startsWith('MemTotal:')) {
          total = _extractKb(line);
        } else if (line.startsWith('MemAvailable:')) {
          available = _extractKb(line);
        }
      }
      if (total == null || available == null || total == 0) return null;
      final used = total - available;
      return (used / total) * 100;
    } catch (_) {
      return null;
    }
  }

  /// Membaca estimasi beban CPU dari /proc/stat (Android, non-root, best-effort)
  static Future<double?> readCpuLoadPercent() async {
    if (!Platform.isAndroid) return null;
    try {
      final first = await _readCpuTicks();
      if (first == null) return null;
      await Future.delayed(const Duration(milliseconds: 200));
      final second = await _readCpuTicks();
      if (second == null) return null;

      final idleDiff = second.idle - first.idle;
      final totalDiff = second.total - first.total;
      if (totalDiff <= 0) return null;
      final usage = (1 - (idleDiff / totalDiff)) * 100;
      return usage.clamp(0, 100);
    } catch (_) {
      return null;
    }
  }

  static Future<_CpuTicks?> _readCpuTicks() async {
    try {
      final file = File('/proc/stat');
      if (!await file.exists()) return null;
      final firstLine = (await file.readAsLines()).first;
      final parts = firstLine
          .replaceFirst('cpu', '')
          .trim()
          .split(RegExp(r'\s+'))
          .map((e) => int.tryParse(e) ?? 0)
          .toList();
      if (parts.length < 4) return null;
      final idle = parts[3];
      final total = parts.fold<int>(0, (sum, v) => sum + v);
      return _CpuTicks(idle: idle, total: total);
    } catch (_) {
      return null;
    }
  }

  static int? _extractKb(String line) {
    final match = RegExp(r'(\d+)').firstMatch(line);
    if (match == null) return null;
    return int.tryParse(match.group(1)!);
  }
}

class _CpuTicks {
  final int idle;
  final int total;
  _CpuTicks({required this.idle, required this.total});
}

// ============================================================
//  SETTINGS LAUNCHER - shortcut resmi ke halaman Settings Android
// ============================================================
class SettingsLauncher {
  static Future<bool> _open(String action) async {
    if (!Platform.isAndroid) return false;
    try {
      final intent = AndroidIntent(
        action: action,
        flags: <int>[268435456], // FLAG_ACTIVITY_NEW_TASK
      );
      await intent.launch();
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openBattery() =>
      _open('android.settings.BATTERY_SAVER_SETTINGS');
  static Future<bool> openDisplay() =>
      _open('android.settings.DISPLAY_SETTINGS');
  static Future<bool> openWifi() => _open('android.settings.WIFI_SETTINGS');
  static Future<bool> openNotification() =>
      _open('android.settings.APP_NOTIFICATION_SETTINGS');
  static Future<bool> openStorage() =>
      _open('android.settings.INTERNAL_STORAGE_SETTINGS');
  static Future<bool> openAppInfo() =>
      _open('android.settings.APPLICATION_DETAILS_SETTINGS');
  static Future<bool> openDoNotDisturb() =>
      _open('android.settings.ZEN_MODE_SETTINGS');
}

// ============================================================
//  STORAGE DETAIL - ukuran cache sebelum dibersihkan
// ============================================================
class StorageDetailService {
  static Future<int> getCacheSizeBytes() async {
    int totalBytes = 0;
    try {
      final dir = await getTemporaryDirectory();
      if (await dir.exists()) {
        await for (final entity in dir.list(recursive: true)) {
          if (entity is File) {
            try {
              totalBytes += await entity.length();
            } catch (_) {}
          }
        }
      }
    } catch (_) {}
    return totalBytes;
  }

  static String formatBytes(int bytes) {
    if (bytes <= 0) return '0 KB';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

// ============================================================
//  DEVICE INFO SERVICE
// ============================================================
class DeviceInfoData {
  final String model;
  final String androidVersion;
  final String manufacturer;
  final String appVersion;

  DeviceInfoData({
    required this.model,
    required this.androidVersion,
    required this.manufacturer,
    required this.appVersion,
  });
}

class DeviceInfoService {
  static Future<DeviceInfoData> load() async {
    String model = 'Tidak diketahui';
    String version = '-';
    String manufacturer = '-';
    String appVersion = '1.0.0';
    try {
      if (Platform.isAndroid) {
        final info = await DeviceInfoPlugin().androidInfo;
        model = info.model;
        version = 'Android ${info.version.release}';
        manufacturer = info.manufacturer;
      }
    } catch (_) {}
    try {
      final pkg = await PackageInfo.fromPlatform();
      appVersion = pkg.version;
    } catch (_) {}
    return DeviceInfoData(
      model: model,
      androidVersion: version,
      manufacturer: manufacturer,
      appVersion: appVersion,
    );
  }
}

// ============================================================
//  DASHBOARD PAGE
// ============================================================
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool _ramCleaner = false;
  bool _autoClean = false;
  bool _powerSaver = false;
  bool _focusMode = false;
  bool _networkMonitor = false;
  bool _fpsOverlay = false;

  bool _busy = false;
  Timer? _autoCleanTimer;

  final Stopwatch _sessionWatch = Stopwatch();
  Timer? _sessionTimer;
  String _sessionElapsed = '00:00:00';

  int _cacheBytes = 0;
  DeviceInfoData? _deviceInfo;
  bool _blueVariant = true; // true = Deep Blue, false = Midnight Cyan

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _sessionWatch.start();
    _sessionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      final d = _sessionWatch.elapsed;
      final h = d.inHours.toString().padLeft(2, '0');
      final m = (d.inMinutes % 60).toString().padLeft(2, '0');
      final s = (d.inSeconds % 60).toString().padLeft(2, '0');
      if (mounted) setState(() => _sessionElapsed = '$h:$m:$s');
    });
    _loadCacheSize();
    DeviceInfoService.load().then((data) {
      if (mounted) setState(() => _deviceInfo = data);
    });
  }

  Future<void> _loadCacheSize() async {
    final size = await StorageDetailService.getCacheSizeBytes();
    if (mounted) setState(() => _cacheBytes = size);
  }

  @override
  void dispose() {
    _autoCleanTimer?.cancel();
    _sessionTimer?.cancel();
    _sessionWatch.stop();
    super.dispose();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _autoClean = prefs.getBool('autoClean') ?? false;
      _powerSaver = prefs.getBool('powerSaver') ?? false;
      _focusMode = prefs.getBool('focusMode') ?? false;
      _networkMonitor = prefs.getBool('networkMonitor') ?? false;
      _fpsOverlay = prefs.getBool('fpsOverlay') ?? false;
      _blueVariant = prefs.getBool('blueVariant') ?? true;
    });
    if (_autoClean) _startAutoClean();
  }

  Future<void> _toggleThemeVariant(bool value) async {
    setState(() => _blueVariant = value);
    await _savePref('blueVariant', value);
  }

  Future<void> _savePref(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  void _snack(String msg, {Color color = AppColors.primary}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ---- RAM Cleaner: aksi instan nyata ----
  Future<void> _toggleRamCleaner(bool value) async {
    if (!value || _busy) return;
    setState(() {
      _ramCleaner = true;
      _busy = true;
    });
    final deleted = await BoosterService.clearAppCache();
    await _loadCacheSize();
    if (!mounted) return;
    setState(() {
      _ramCleaner = false;
      _busy = false;
    });
    _snack(deleted > 0
        ? 'RAM Cleaner selesai · $deleted item cache dibersihkan'
        : 'RAM Cleaner selesai · tidak ada cache tersisa');
  }

  // ---- Auto Clean berkala (real timer, jalan selama app dibuka) ----
  void _startAutoClean() {
    _autoCleanTimer?.cancel();
    _autoCleanTimer = Timer.periodic(const Duration(minutes: 5), (_) async {
      final deleted = await BoosterService.clearAppCache();
      if (deleted > 0) _snack('Auto Clean · $deleted item dibersihkan');
    });
  }

  Future<void> _toggleAutoClean(bool value) async {
    setState(() => _autoClean = value);
    await _savePref('autoClean', value);
    if (value) {
      _startAutoClean();
      _snack('Auto Clean diaktifkan · berjalan tiap 5 menit');
    } else {
      _autoCleanTimer?.cancel();
      _snack('Auto Clean dinonaktifkan');
    }
  }

  Future<void> _togglePowerSaver(bool value) async {
    setState(() => _powerSaver = value);
    await _savePref('powerSaver', value);
    _snack(value
        ? 'Power Saver aktif · animasi & refresh latar belakang dikurangi'
        : 'Power Saver nonaktif');
  }

  Future<void> _toggleFocusMode(bool value) async {
    setState(() => _focusMode = value);
    await _savePref('focusMode', value);
    _snack(value ? 'Focus Mode aktif' : 'Focus Mode nonaktif');
  }

  Future<void> _toggleNetworkMonitor(bool value) async {
    setState(() => _networkMonitor = value);
    await _savePref('networkMonitor', value);
  }

  Future<void> _toggleFpsOverlay(bool value) async {
    setState(() => _fpsOverlay = value);
    await _savePref('fpsOverlay', value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(sessionTime: _sessionElapsed),
              const SizedBox(height: 20),
              const _SectionLabel('OPTIMIZER'),
              const SizedBox(height: 8),
              ToggleCard(
                title: 'RAM CLEANER',
                desc: _cacheBytes > 0
                    ? 'Cache saat ini: ${StorageDetailService.formatBytes(_cacheBytes)}'
                    : 'Bersihkan cache aplikasi sekarang',
                icon: Icons.memory_rounded,
                color: AppColors.primaryLight,
                value: _ramCleaner,
                loading: _busy,
                onChanged: _toggleRamCleaner,
              ),
              ToggleCard(
                title: 'AUTO CLEAN',
                desc: 'Bersihkan cache otomatis tiap 5 menit',
                icon: Icons.autorenew_rounded,
                color: AppColors.accent,
                value: _autoClean,
                onChanged: _toggleAutoClean,
              ),
              ToggleCard(
                title: 'POWER SAVER',
                desc: 'Kurangi animasi & aktivitas latar belakang',
                icon: Icons.battery_saver_rounded,
                color: AppColors.success,
                value: _powerSaver,
                onChanged: _togglePowerSaver,
              ),
              const SizedBox(height: 16),
              const _SectionLabel('MONITOR'),
              const SizedBox(height: 8),
              ToggleCard(
                title: 'NETWORK MONITOR',
                desc: 'Tampilkan status & jenis koneksi di monitor sesi',
                icon: Icons.wifi_tethering_rounded,
                color: AppColors.primary,
                value: _networkMonitor,
                onChanged: _toggleNetworkMonitor,
              ),
              ToggleCard(
                title: 'FPS OVERLAY',
                desc: 'Tampilkan FPS render aplikasi secara live',
                icon: Icons.speed_rounded,
                color: AppColors.primaryLight,
                value: _fpsOverlay,
                onChanged: _toggleFpsOverlay,
              ),
              ToggleCard(
                title: 'FOCUS MODE',
                desc: 'Sembunyikan notifikasi dalam aplikasi',
                icon: Icons.do_not_disturb_on_rounded,
                color: AppColors.accent,
                value: _focusMode,
                onChanged: _toggleFocusMode,
              ),
              const SizedBox(height: 16),
              const _SectionLabel('PINTASAN SISTEM'),
              const SizedBox(height: 8),
              _ShortcutGrid(),
              const SizedBox(height: 16),
              const _SectionLabel('TAMPILAN'),
              const SizedBox(height: 8),
              ToggleCard(
                title: 'DEEP BLUE THEME',
                desc: _blueVariant
                    ? 'Aktif · varian biru tua elegan'
                    : 'Nonaktif · varian cyan gelap',
                icon: Icons.palette_rounded,
                color: AppColors.primary,
                value: _blueVariant,
                onChanged: _toggleThemeVariant,
              ),
              const SizedBox(height: 16),
              const _SectionLabel('INFO PERANGKAT'),
              const SizedBox(height: 8),
              _DeviceInfoCard(data: _deviceInfo),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => MonitorPage(
                          networkEnabled: _networkMonitor,
                          fpsEnabled: _fpsOverlay,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.monitor_heart_outlined,
                      color: Colors.white),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    elevation: 0,
                  ),
                  label: const Text(
                    'BUKA MONITOR SESI',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Center(
                child: Text(
                  'Device Booster · 100% Non-Root',
                  style: TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textSecondary.withOpacity(0.7),
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String sessionTime;
  const _Header({required this.sessionTime});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [AppColors.primary, AppColors.accent],
            ),
          ),
          child: const Icon(Icons.bolt_rounded, color: Colors.white),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Device Booster',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                'Performance & Monitoring',
                style:
                    TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              const Icon(Icons.timer_outlined,
                  size: 13, color: AppColors.primaryLight),
              const SizedBox(width: 5),
              Text(
                sessionTime,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.primaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================
//  SHORTCUT GRID - pintasan resmi ke Settings Android
// ============================================================
class _ShortcutGrid extends StatelessWidget {
  const _ShortcutGrid();

  void _handleTap(BuildContext context, Future<bool> Function() action,
      String label) async {
    final ok = await action();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok
            ? 'Membuka pengaturan $label...'
            : 'Tidak bisa membuka pengaturan $label di perangkat ini'),
        backgroundColor: ok ? AppColors.primary : AppColors.danger,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = <_ShortcutItem>[
      _ShortcutItem('Baterai', Icons.battery_charging_full_rounded,
          SettingsLauncher.openBattery),
      _ShortcutItem(
          'Display', Icons.brightness_6_rounded, SettingsLauncher.openDisplay),
      _ShortcutItem('WiFi', Icons.wifi_rounded, SettingsLauncher.openWifi),
      _ShortcutItem('Notifikasi', Icons.notifications_none_rounded,
          SettingsLauncher.openNotification),
      _ShortcutItem(
          'Storage', Icons.folder_open_rounded, SettingsLauncher.openStorage),
      _ShortcutItem(
          'Do Not Disturb', Icons.bedtime_rounded, SettingsLauncher.openDoNotDisturb),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.95,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return GestureDetector(
          onTap: () => _handleTap(context, item.action, item.label),
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.cardTop, AppColors.cardBottom],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(item.icon, color: AppColors.primaryLight, size: 22),
                const SizedBox(height: 6),
                Text(
                  item.label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ShortcutItem {
  final String label;
  final IconData icon;
  final Future<bool> Function() action;
  _ShortcutItem(this.label, this.icon, this.action);
}

// ============================================================
//  DEVICE INFO CARD
// ============================================================
class _DeviceInfoCard extends StatelessWidget {
  final DeviceInfoData? data;
  const _DeviceInfoCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.cardTop, AppColors.cardBottom],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: data == null
          ? const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: AppColors.primaryLight),
                ),
              ),
            )
          : Column(
              children: [
                _InfoLine('Perangkat', data!.model),
                _InfoLine('Pabrikan', data!.manufacturer),
                _InfoLine('Sistem', data!.androidVersion),
                _InfoLine('Versi App', data!.appVersion),
              ],
            ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;
  const _InfoLine(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: const TextStyle(
                    fontSize: 12, color: AppColors.textSecondary)),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.bold,
        color: AppColors.primaryLight,
        letterSpacing: 1.2,
      ),
    );
  }
}

// ============================================================
//  TOGGLE CARD (widget switch on/off custom, rapi)
// ============================================================
class ToggleCard extends StatelessWidget {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  final bool value;
  final bool loading;
  final ValueChanged<bool> onChanged;

  const ToggleCard({
    super.key,
    required this.title,
    required this.desc,
    required this.icon,
    required this.color,
    required this.value,
    required this.onChanged,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.cardTop, AppColors.cardBottom],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.14),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  desc,
                  style: const TextStyle(
                    fontSize: 10.8,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          loading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: AppColors.primaryLight,
                  ),
                )
              : AppSwitch(value: value, color: color, onChanged: onChanged),
        ],
      ),
    );
  }
}

// ============================================================
//  CUSTOM SWITCH (tanpa dependency luar, anti error versi)
// ============================================================
class AppSwitch extends StatelessWidget {
  final bool value;
  final Color color;
  final ValueChanged<bool> onChanged;

  const AppSwitch({
    super.key,
    required this.value,
    required this.color,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 46,
        height: 26,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: value ? color.withOpacity(0.9) : AppColors.border,
        ),
        alignment: value ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          width: 20,
          height: 20,
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                  color: Colors.black26, blurRadius: 3, offset: Offset(0, 1)),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
//  MONITOR SESI PAGE
// ============================================================
class MonitorPage extends StatefulWidget {
  final bool networkEnabled;
  final bool fpsEnabled;

  const MonitorPage({
    super.key,
    this.networkEnabled = true,
    this.fpsEnabled = true,
  });

  @override
  State<MonitorPage> createState() => _MonitorPageState();
}

class _MonitorPageState extends State<MonitorPage> {
  final Battery _battery = Battery();
  final Connectivity _connectivity = Connectivity();

  Timer? _timer;
  StreamSubscription<List<int>>? _fpsSub;

  bool _cpuOn = true;
  bool _ramOn = true;
  bool _batteryOn = true;
  bool _networkOn = true;
  bool _fpsOn = true;
  bool _timeOn = true;

  double? _cpuPercent;
  double? _ramPercent;
  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;
  ConnectivityResult _connectivityResult = ConnectivityResult.none;
  int _fps = 0;
  DateTime _now = DateTime.now();

  int _frameCount = 0;

  @override
  void initState() {
    super.initState();
    _networkOn = widget.networkEnabled;
    _fpsOn = widget.fpsEnabled;
    _loadDeviceInfo();
    _startFpsCounter();
    _refreshAll();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _refreshAll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _fpsSub?.cancel();
    SchedulerBinding.instance.removeTimingsCallback(_onFrameTimings);
    super.dispose();
  }

  Future<void> _loadDeviceInfo() async {
    try {
      final info = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        await info.androidInfo;
      }
    } catch (_) {
      // abaikan jika info perangkat tidak tersedia
    }
  }

  void _startFpsCounter() {
    SchedulerBinding.instance.addTimingsCallback(_onFrameTimings);
  }

  void _onFrameTimings(List<FrameTiming> timings) {
    _frameCount += timings.length;
  }

  Future<void> _refreshAll() async {
    final cpu = _cpuOn ? await BoosterService.readCpuLoadPercent() : null;
    final ram = _ramOn ? await BoosterService.readMemoryUsagePercent() : null;

    int battLevel = _batteryLevel;
    BatteryState battState = _batteryState;
    if (_batteryOn) {
      try {
        battLevel = await _battery.batteryLevel;
        battState = await _battery.batteryState;
      } catch (_) {}
    }

    ConnectivityResult conn = _connectivityResult;
    if (_networkOn) {
      try {
        final result = await _connectivity.checkConnectivity();
        conn = result.isNotEmpty ? result.first : ConnectivityResult.none;
      } catch (_) {}
    }

    if (!mounted) return;
    setState(() {
      _cpuPercent = cpu;
      _ramPercent = ram;
      _batteryLevel = battLevel;
      _batteryState = battState;
      _connectivityResult = conn;
      _fps = _frameCount.clamp(0, 120);
      _frameCount = 0;
      _now = DateTime.now();
    });
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    final s = dt.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  String _networkLabel(ConnectivityResult r) {
    switch (r) {
      case ConnectivityResult.wifi:
        return 'WiFi';
      case ConnectivityResult.mobile:
        return 'Data Seluler';
      case ConnectivityResult.ethernet:
        return 'Ethernet';
      case ConnectivityResult.none:
        return 'Tidak Terhubung';
      default:
        return 'Tidak Diketahui';
    }
  }

  String _batteryStateLabel(BatteryState s) {
    switch (s) {
      case BatteryState.charging:
        return 'Mengisi Daya';
      case BatteryState.discharging:
        return 'Menggunakan Baterai';
      case BatteryState.full:
        return 'Penuh';
      default:
        return 'Tidak Diketahui';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text(
          'Monitor Sesi',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 8),
                children: [
                  const Text(
                    'Pantau performa perangkat saat kamu bermain',
                    style: TextStyle(
                        fontSize: 12, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 16),
                  MonitorRow(
                    label: 'CPU Information',
                    value: _cpuPercent != null
                        ? '${_cpuPercent!.toStringAsFixed(0)}%'
                        : 'N/A',
                    checked: _cpuOn,
                    onChanged: (v) => setState(() => _cpuOn = v),
                  ),
                  MonitorRow(
                    label: 'RAM Information',
                    value: _ramPercent != null
                        ? '${_ramPercent!.toStringAsFixed(0)}%'
                        : 'N/A',
                    checked: _ramOn,
                    onChanged: (v) => setState(() => _ramOn = v),
                  ),
                  MonitorRow(
                    label: 'Battery Information',
                    value: '$_batteryLevel% · ${_batteryStateLabel(_batteryState)}',
                    checked: _batteryOn,
                    onChanged: (v) => setState(() => _batteryOn = v),
                  ),
                  MonitorRow(
                    label: 'Network Information',
                    value: _networkLabel(_connectivityResult),
                    checked: _networkOn,
                    onChanged: (v) => setState(() => _networkOn = v),
                  ),
                  MonitorRow(
                    label: 'FPS Information',
                    value: '$_fps fps',
                    checked: _fpsOn,
                    onChanged: (v) => setState(() => _fpsOn = v),
                  ),
                  MonitorRow(
                    label: 'Time Information',
                    value: _formatTime(_now),
                    checked: _timeOn,
                    onChanged: (v) => setState(() => _timeOn = v),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppColors.primary.withOpacity(0.2)),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline,
                            color: AppColors.primaryLight, size: 15),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'CPU & RAM adalah estimasi sistem (non-root). Nilai bisa "N/A" pada beberapa perangkat karena dibatasi Android.',
                            style: TextStyle(
                              fontSize: 10.5,
                              color: AppColors.primaryLight,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            _StatusBar(
              cpu: _cpuPercent,
              ram: _ramPercent,
              battery: _batteryLevel,
              fps: _fps,
              time: _formatTime(_now),
            ),
          ],
        ),
      ),
    );
  }
}

class MonitorRow extends StatelessWidget {
  final String label;
  final String value;
  final bool checked;
  final ValueChanged<bool> onChanged;

  const MonitorRow({
    super.key,
    required this.label,
    required this.value,
    required this.checked,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12.5,
              color: AppColors.primaryLight,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => onChanged(!checked),
            child: Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: checked ? AppColors.primary : Colors.transparent,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                  color: checked ? AppColors.primary : AppColors.border,
                  width: 1.4,
                ),
              ),
              child: checked
                  ? const Icon(Icons.check, color: Colors.white, size: 16)
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  final double? cpu;
  final double? ram;
  final int battery;
  final int fps;
  final String time;

  const _StatusBar({
    required this.cpu,
    required this.ram,
    required this.battery,
    required this.fps,
    required this.time,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatusItem(
              icon: Icons.memory_rounded,
              label: cpu != null ? '${cpu!.toStringAsFixed(0)}%' : 'N/A'),
          _StatusItem(
              icon: Icons.sd_storage_rounded,
              label: ram != null ? '${ram!.toStringAsFixed(0)}%' : 'N/A'),
          _StatusItem(
              icon: Icons.battery_std_rounded, label: '$battery%'),
          _StatusItem(icon: Icons.speed_rounded, label: '$fps fps'),
          _StatusItem(icon: Icons.access_time_rounded, label: time),
        ],
      ),
    );
  }
}

class _StatusItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const _StatusItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: AppColors.primaryLight, size: 16),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(fontSize: 10, color: AppColors.textPrimary),
        ),
      ],
    );
  }
}
