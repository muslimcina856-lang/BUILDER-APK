package com.localupscale.app.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/**
 * Universal Real-ESRGAN TFLite upscaler.
 * Works on all chipsets:
 * 1. Try NNAPI (MediaTek Neuron, Qualcomm Hexagon, Exynos, etc.)
 * 2. Fallback to CPU + XNNPACK
 */
class RealEsrganUpscaler(private val context: Context) {

    companion object {
        private const val TAG = "RealEsrganUpscaler"
        private const val INPUT_SIZE = 128
        private const val SCALE = 4
        private const val OUTPUT_SIZE = INPUT_SIZE * SCALE // 512
        private const val PAD = 8
        private const val MAX_INPUT_SIDE = 768
    }

    private var interpreter: Interpreter? = null
    private var nnApiDelegate: NnApiDelegate? = null
    private var isReady = false
    private var backendName = "none"

    init {
        loadModel()
    }

    private fun loadModel() {
        try {
            val modelFile = ModelManager.getModelFile(context)
            if (!modelFile.exists() || modelFile.length() < 1_000_000) {
                Log.w(TAG, "Model not ready")
                return
            }

            val buffer = loadModelFile(modelFile)

            // Strategy 1: Try NNAPI (works across most modern chipsets)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    val nnOptions = NnApiDelegate.Options().apply {
                        // Prefer faster execution, allow CPU fallback inside NNAPI if needed
                        setAllowFp16(true)
                        setUseNnapiCpu(false)
                    }
                    nnApiDelegate = NnApiDelegate(nnOptions)

                    val options = Interpreter.Options().apply {
                        numThreads = 2
                        addDelegate(nnApiDelegate)
                    }
                    interpreter = Interpreter(buffer, options)
                    isReady = true
                    backendName = "NNAPI"
                    Log.d(TAG, "Using NNAPI backend (universal hardware accel)")
                    return
                } catch (e: Exception) {
                    Log.w(TAG, "NNAPI not available, falling back to CPU", e)
                    try { nnApiDelegate?.close() } catch (_: Exception) {}
                    nnApiDelegate = null
                    interpreter = null
                }
            }

            // Strategy 2: CPU + XNNPACK (works on ALL devices)
            val cpuOptions = Interpreter.Options().apply {
                numThreads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
                setUseXNNPACK(true)
            }
            interpreter = Interpreter(buffer, cpuOptions)
            isReady = true
            backendName = "CPU/XNNPACK"
            Log.d(TAG, "Using CPU/XNNPACK backend")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init interpreter", e)
            close()
            isReady = false
        }
    }

    private fun loadModelFile(file: java.io.File): MappedByteBuffer {
        FileInputStream(file).use { fis ->
            val channel = fis.channel
            return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
        }
    }

    fun isModelLoaded(): Boolean = isReady && interpreter != null

    fun getBackend(): String = backendName

    fun upscale(src: Bitmap, requestedScale: Int = 4): Bitmap? {
        if (!isModelLoaded()) return null

        return try {
            val limited = limitSize(src, MAX_INPUT_SIDE)
            val ai4x = processTiled(limited) ?: return null

            if (requestedScale == 4) {
                return ai4x
            }

            val targetW = (src.width * requestedScale).coerceAtLeast(1)
            val targetH = (src.height * requestedScale).coerceAtLeast(1)
            val finalBmp = Bitmap.createScaledBitmap(ai4x, targetW, targetH, true)
            if (ai4x !== finalBmp) ai4x.recycle()
            finalBmp
        } catch (oom: OutOfMemoryError) {
            Log.e(TAG, "OOM", oom)
            System.gc()
            null
        } catch (e: Exception) {
            Log.e(TAG, "Upscale error", e)
            null
        }
    }

    private fun limitSize(bmp: Bitmap, maxSide: Int): Bitmap {
        if (bmp.width <= maxSide && bmp.height <= maxSide) return bmp
        val ratio = min(maxSide.toFloat() / bmp.width, maxSide.toFloat() / bmp.height)
        val w = max(1, (bmp.width * ratio).toInt())
        val h = max(1, (bmp.height * ratio).toInt())
        return Bitmap.createScaledBitmap(bmp, w, h, true)
    }

    private fun processTiled(input: Bitmap): Bitmap? {
        val interp = interpreter ?: return null
        val inW = input.width
        val inH = input.height
        val outW = inW * SCALE
        val outH = inH * SCALE

        val result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        val stride = INPUT_SIZE - PAD * 2
        var y = 0
        while (y < inH) {
            var x = 0
            while (x < inW) {
                val tileW = min(INPUT_SIZE, inW - x)
                val tileH = min(INPUT_SIZE, inH - y)

                val tile = Bitmap.createBitmap(INPUT_SIZE, INPUT_SIZE, Bitmap.Config.ARGB_8888)
                val tCanvas = Canvas(tile)
                tCanvas.drawColor(Color.BLACK)

                val srcTile = Bitmap.createBitmap(input, x, y, tileW, tileH)
                tCanvas.drawBitmap(srcTile, 0f, 0f, null)
                srcTile.recycle()

                val outTile = inferTile(interp, tile)
                tile.recycle()

                if (outTile != null) {
                    val dstX = x * SCALE
                    val dstY = y * SCALE
                    val validOutW = min(tileW * SCALE, outW - dstX)
                    val validOutH = min(tileH * SCALE, outH - dstY)
                    if (validOutW > 0 && validOutH > 0) {
                        val cropped = Bitmap.createBitmap(outTile, 0, 0, validOutW, validOutH)
                        canvas.drawBitmap(cropped, dstX.toFloat(), dstY.toFloat(), paint)
                        cropped.recycle()
                    }
                    outTile.recycle()
                }

                x += stride
                if (x >= inW) break
            }
            y += stride
            if (y >= inH) break
        }
        return result
    }

    private fun inferTile(interp: Interpreter, tile: Bitmap): Bitmap? {
        return try {
            val inBuf = ByteBuffer.allocateDirect(1 * INPUT_SIZE * INPUT_SIZE * 3 * 4)
            inBuf.order(ByteOrder.nativeOrder())

            val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
            tile.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)

            for (p in pixels) {
                inBuf.putFloat(((p shr 16) and 0xFF) / 255f)
                inBuf.putFloat(((p shr 8) and 0xFF) / 255f)
                inBuf.putFloat((p and 0xFF) / 255f)
            }
            inBuf.rewind()

            val outBuf = ByteBuffer.allocateDirect(1 * OUTPUT_SIZE * OUTPUT_SIZE * 3 * 4)
            outBuf.order(ByteOrder.nativeOrder())

            interp.run(inBuf, outBuf)
            outBuf.rewind()

            val outPixels = IntArray(OUTPUT_SIZE * OUTPUT_SIZE)
            for (i in outPixels.indices) {
                val r = (outBuf.float.coerceIn(0f, 1f) * 255f + 0.5f).toInt().coerceIn(0, 255)
                val g = (outBuf.float.coerceIn(0f, 1f) * 255f + 0.5f).toInt().coerceIn(0, 255)
                val b = (outBuf.float.coerceIn(0f, 1f) * 255f + 0.5f).toInt().coerceIn(0, 255)
                outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }

            Bitmap.createBitmap(outPixels, OUTPUT_SIZE, OUTPUT_SIZE, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            Log.e(TAG, "inferTile failed", e)
            null
        }
    }

    fun close() {
        try { interpreter?.close() } catch (_: Exception) {}
        try { nnApiDelegate?.close() } catch (_: Exception) {}
        interpreter = null
        nnApiDelegate = null
        isReady = false
        backendName = "none"
    }
}
