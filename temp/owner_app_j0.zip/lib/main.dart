import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/dashboard_screen.dart';
import 'screens/owner_login_screen.dart';
import 'services/api_service.dart';
import 'services/owner_auth_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgBase,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  var savedApiKey = await OwnerAuthService.readApiKey();
  if (savedApiKey != null) {
    try {
      final valid = await OwnerApiService.verifyApiKey(savedApiKey);
      if (!valid) {
        await OwnerAuthService.clearApiKey();
        savedApiKey = null;
      }
    } catch (_) {
      // Keep the encrypted key when the device is temporarily offline.
    }
  }
  if (savedApiKey != null) OwnerApiService.setApiKey(savedApiKey);
  runApp(EarlOwnerApp(initialApiKey: savedApiKey));
}

class EarlOwnerApp extends StatefulWidget {
  final String? initialApiKey;
  const EarlOwnerApp({super.key, required this.initialApiKey});

  @override
  State<EarlOwnerApp> createState() => _EarlOwnerAppState();
}

class _EarlOwnerAppState extends State<EarlOwnerApp> {
  late bool _authenticated = widget.initialApiKey != null;

  void _onAuthenticated(String _) {
    setState(() => _authenticated = true);
  }

  Future<void> _logout() async {
    await OwnerAuthService.clearApiKey();
    OwnerApiService.clearApiKey();
    if (mounted) setState(() => _authenticated = false);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Earl Builder - Owner',
      debugShowCheckedModeBanner: false,
      theme: buildOwnerAppTheme(),
      home: _authenticated
          ? DashboardScreen(onLogout: _logout)
          : OwnerLoginScreen(onAuthenticated: _onAuthenticated),
    );
  }
}
