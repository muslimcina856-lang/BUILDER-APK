import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class OwnerAuthService {
  OwnerAuthService._();

  static const _storage = FlutterSecureStorage();
  static const _keyName = 'owner_api_key';

  static Future<String?> readApiKey() async {
    final value = await _storage.read(key: _keyName);
    final trimmed = value?.trim();
    return trimmed == null || trimmed.isEmpty ? null : trimmed;
  }

  static Future<void> saveApiKey(String value) {
    return _storage.write(key: _keyName, value: value.trim());
  }

  static Future<void> clearApiKey() {
    return _storage.delete(key: _keyName);
  }
}
