import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class AdsListScreen extends StatefulWidget {
  const AdsListScreen({super.key});

  @override
  State<AdsListScreen> createState() => _AdsListScreenState();
}

class _AdsListScreenState extends State<AdsListScreen> {
  List<Map<String, dynamic>> _ads = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  String? _error;
  final _searchController = TextEditingController();

  bool _selectionMode = false;
  final Set<int> _selected = {};

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(_filter);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final result = await OwnerApiService.getAds();
      if (!mounted) return;
      setState(() {
        _ads = List<Map<String, dynamic>>.from(result['ads'] ?? <dynamic>[]);
        _filter();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Unable to load ads. The server may be unreachable.');
    }
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  void _filter() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      _filtered = query.isEmpty
          ? _ads
          : _ads.where((ad) {
              final deviceId = (ad['target_device_id'] ?? '').toString().toLowerCase();
              final telegramId = (ad['target_telegram_id'] ?? '').toString().toLowerCase();
              return deviceId.contains(query) || telegramId.contains(query);
            }).toList();
    });
  }

  void _toggleSelectionMode() {
    setState(() {
      _selectionMode = !_selectionMode;
      _selected.clear();
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selected.length == _filtered.length) {
        _selected.clear();
      } else {
        _selected
          ..clear()
          ..addAll(_filtered.map((ad) => ad['id'] as int));
      }
    });
  }

  Future<void> _bulkDelete() async {
    if (_selected.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: const Text('Delete Ads?', style: AppText.heading),
        content: Text(
          '${_selected.length} ad(s) will be permanently deleted. This cannot be undone.',
          style: AppText.body,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final result = await OwnerApiService.deleteAds(_selected.toList());
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _ads.removeWhere((ad) => _selected.contains(ad['id']));
          _selected.clear();
          _selectionMode = false;
          _filter();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text((result['message'] ?? 'Failed to delete.').toString())),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error: could not reach the server.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_selectionMode ? '${_selected.length} selected' : 'Manage Ads'),
        actions: [
          if (_selectionMode) ...[
            TextButton(
              onPressed: _toggleSelectAll,
              child: Text(
                _selected.length == _filtered.length && _filtered.isNotEmpty
                    ? 'Unselect All'
                    : 'Select All',
              ),
            ),
            IconButton(
              onPressed: _selected.isEmpty ? null : _bulkDelete,
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
              tooltip: 'Delete selected',
            ),
            IconButton(
              onPressed: _toggleSelectionMode,
              icon: const Icon(Icons.close_rounded),
              tooltip: 'Cancel',
            ),
          ] else
            IconButton(
              onPressed: _filtered.isEmpty ? null : _toggleSelectionMode,
              icon: const Icon(Icons.checklist_rounded),
              tooltip: 'Select',
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xxl,
                AppSpacing.lg,
                AppSpacing.xxl,
                AppSpacing.md,
              ),
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Search by buyer Device ID or Telegram ID',
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    size: AppIcons.md,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation(AppColors.accent),
                        ),
                      ),
                    )
                  : _error != null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(AppSpacing.xxl),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.cloud_off_rounded,
                                  size: AppIcons.hero,
                                  color: AppColors.error,
                                ),
                                const SizedBox(height: AppSpacing.md),
                                const Text('Unable to Load', style: AppText.heading),
                                const SizedBox(height: AppSpacing.xs),
                                Text(_error!, style: AppText.subtitle, textAlign: TextAlign.center),
                                const SizedBox(height: AppSpacing.lg),
                                OutlinedButton(onPressed: _load, child: const Text('Retry')),
                              ],
                            ),
                          ),
                        )
                      : _filtered.isEmpty
                          ? Center(
                              child: Padding(
                                padding: const EdgeInsets.all(AppSpacing.xxl),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.video_library_outlined,
                                      size: AppIcons.hero,
                                      color: AppColors.textMuted,
                                    ),
                                    const SizedBox(height: AppSpacing.md),
                                    const Text('No Ads', style: AppText.heading),
                                    const SizedBox(height: AppSpacing.xs),
                                    const Text(
                                      'Ads you create will appear here.',
                                      style: AppText.subtitle,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : RefreshIndicator(
                              color: AppColors.accent,
                              backgroundColor: AppColors.bgElevated,
                              onRefresh: _load,
                              child: ListView.separated(
                                padding: const EdgeInsets.fromLTRB(
                                  AppSpacing.xxl,
                                  0,
                                  AppSpacing.xxl,
                                  AppSpacing.huge,
                                ),
                                itemCount: _filtered.length,
                                separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
                                itemBuilder: (_, i) {
                                  final ad = _filtered[i];
                                  final id = ad['id'] as int;
                                  return _AdCard(
                                    ad: ad,
                                    selectionMode: _selectionMode,
                                    selected: _selected.contains(id),
                                    onTap: _selectionMode
                                        ? () => setState(() {
                                              if (_selected.contains(id)) {
                                                _selected.remove(id);
                                              } else {
                                                _selected.add(id);
                                              }
                                            })
                                        : null,
                                  );
                                },
                              ),
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AdCard extends StatelessWidget {
  final Map<String, dynamic> ad;
  final bool selectionMode;
  final bool selected;
  final VoidCallback? onTap;

  const _AdCard({
    required this.ad,
    required this.selectionMode,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOwnerAd = ad['target_device_id'] == null && ad['target_telegram_id'] == null;
    final buyerId = (ad['target_device_id'] ?? ad['target_telegram_id'] ?? '').toString();
    final buyerLabel = isOwnerAd
        ? 'Owner'
        : (ad['target_device_id'] != null ? 'Buyer Device' : 'Buyer Telegram');
    final limitType = (ad['limit_type'] ?? 'views').toString();
    final limitValue = (ad['limit_value'] ?? 0).toString();
    final viewsCount = (ad['views_count'] ?? 0).toString();
    final title = (ad['title'] ?? '').toString();

    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Row(
            children: [
              if (selectionMode) ...[
                Checkbox(
                  value: selected,
                  onChanged: (_) => onTap?.call(),
                  activeColor: AppColors.accent,
                ),
                const SizedBox(width: AppSpacing.sm),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title.isNotEmpty ? title : (isOwnerAd ? 'Owner ad' : '$buyerLabel: $buyerId'),
                      style: AppText.body.copyWith(fontWeight: FontWeight.w700),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isOwnerAd ? 'Owner · no buyer ID' : '$buyerLabel · $buyerId',
                      style: AppText.caption,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$viewsCount / $limitValue $limitType watched',
                      style: AppText.caption,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
