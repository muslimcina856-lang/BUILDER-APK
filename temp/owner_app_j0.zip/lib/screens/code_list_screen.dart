import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class CodeListScreen extends StatefulWidget {
  const CodeListScreen({super.key});

  @override
  State<CodeListScreen> createState() => _CodeListScreenState();
}

class _CodeListScreenState extends State<CodeListScreen> {
  List<Map<String, dynamic>> _codes = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  String? _error;
  final _searchController = TextEditingController();

  bool _selectionMode = false;
  final Set<String> _selected = {};

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(_filter);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final result = await OwnerApiService.getCodes();
      if (!mounted) return;
      setState(() {
        _codes = List<Map<String, dynamic>>.from(result['codes'] ?? <dynamic>[]);
        _filter();
      });
    } catch (e) {
      if (!mounted) return;
      // Do NOT silently show "no active codes" on a failed fetch — that
      // looks identical to genuinely having zero codes and hides real
      // outages (e.g. can't reach the database).
      setState(() => _error = 'Tidak dapat memuatkan senarai kod. Server mungkin tidak dapat dihubungi.');
    }
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  void _filter() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      _filtered = query.isEmpty
          ? _codes
          : _codes.where((c) => (c['code'] ?? '').toString().toLowerCase().contains(query)).toList();
    });
  }

  void _toggleSelectionMode() {
    setState(() {
      _selectionMode = !_selectionMode;
      _selected.clear();
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selected.length == _filtered.length) {
        _selected.clear();
      } else {
        _selected
          ..clear()
          ..addAll(_filtered.map((c) => (c['code'] ?? '').toString()));
      }
    });
  }

  Future<void> _bulkDelete() async {
    if (_selected.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: const Text('Delete Codes?', style: AppText.heading),
        content: Text(
          '${_selected.length} code(s) will be permanently deleted. This cannot be undone.',
          style: AppText.body,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final result = await OwnerApiService.bulkDeleteCodes(_selected.toList());
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _codes.removeWhere((c) => _selected.contains(c['code']));
          _selected.clear();
          _selectionMode = false;
          _filter();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text((result['message'] ?? 'Failed to delete.').toString())),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error: could not reach the server.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_selectionMode ? '${_selected.length} selected' : 'Active Codes'),
        actions: [
          if (_selectionMode) ...[
            TextButton(
              onPressed: _toggleSelectAll,
              child: Text(
                _selected.length == _filtered.length && _filtered.isNotEmpty
                    ? 'Unselect All'
                    : 'Select All',
              ),
            ),
            IconButton(
              onPressed: _selected.isEmpty ? null : _bulkDelete,
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
              tooltip: 'Delete selected',
            ),
            IconButton(
              onPressed: _toggleSelectionMode,
              icon: const Icon(Icons.close_rounded),
              tooltip: 'Cancel',
            ),
          ] else
            IconButton(
              onPressed: _filtered.isEmpty ? null : _toggleSelectionMode,
              icon: const Icon(Icons.checklist_rounded),
              tooltip: 'Select',
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xxl,
                AppSpacing.md,
                AppSpacing.xxl,
                AppSpacing.md,
              ),
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Search by code…',
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    size: AppIcons.md,
                    color: AppColors.textMuted,
                  ),
                ),
                style: AppText.body,
              ),
            ),
            Expanded(
              child: _isLoading
            ? const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(AppColors.accent),
                  ),
                ),
              )
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.xxl),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.cloud_off_rounded,
                            size: AppIcons.hero,
                            color: AppColors.error,
                          ),
                          const SizedBox(height: AppSpacing.md),
                          const Text('Unable to Load', style: AppText.heading),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            _error!,
                            style: AppText.subtitle,
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: AppSpacing.lg),
                          OutlinedButton(
                            onPressed: _load,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    ),
                  )
                : _filtered.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.xxl),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.redeem_rounded,
                            size: AppIcons.hero,
                            color: AppColors.textMuted,
                          ),
                          const SizedBox(height: AppSpacing.md),
                          Text(
                            _searchController.text.isNotEmpty
                                ? 'No matching codes'
                                : 'No active codes',
                            style: AppText.heading,
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          const Text(
                            'Generate codes from the Generate Codes menu.',
                            style: AppText.subtitle,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  )
                : RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.bgElevated,
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(
                        AppSpacing.xxl,
                        AppSpacing.lg,
                        AppSpacing.xxl,
                        AppSpacing.huge,
                      ),
                      itemCount: _filtered.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: AppSpacing.sm),
                      itemBuilder: (_, i) {
                        final code = _filtered[i];
                        final codeStr = (code['code'] ?? '').toString();
                        return _CodeRow(
                          code: code,
                          selectionMode: _selectionMode,
                          selected: _selected.contains(codeStr),
                          onToggleSelect: () => setState(() {
                            if (_selected.contains(codeStr)) {
                              _selected.remove(codeStr);
                            } else {
                              _selected.add(codeStr);
                            }
                          }),
                        );
                      },
                    ),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CodeRow extends StatelessWidget {
  final Map<String, dynamic> code;
  final bool selectionMode;
  final bool selected;
  final VoidCallback onToggleSelect;
  const _CodeRow({
    required this.code,
    required this.selectionMode,
    required this.selected,
    required this.onToggleSelect,
  });

  @override
  Widget build(BuildContext context) {
    final c = (code['code'] ?? '').toString();
    final amount = (code['amount'] ?? 0).toString();
    final createdAt = (code['created_at'] ?? '').toString();

    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: selectionMode ? onToggleSelect : null,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.md,
      ),
      child: Row(
        children: [
          if (selectionMode) ...[
            Checkbox(
              value: selected,
              onChanged: (_) => onToggleSelect(),
              activeColor: AppColors.accent,
            ),
            const SizedBox(width: AppSpacing.xs),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  c,
                  style: AppText.body.copyWith(
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                    color: AppColors.accent,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '$amount credits${createdAt.isNotEmpty ? ' · $createdAt' : ''}',
                  style: AppText.caption,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.sm + 2,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: AppColors.success.withAlpha(20),
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(
              'ACTIVE',
              style: AppText.caption.copyWith(
                color: AppColors.success,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                fontSize: 11,
              ),
            ),
          ),
          if (!selectionMode)
            IconButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: c));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Code copied.'), duration: Duration(seconds: 1)),
                );
              },
              icon: const Icon(
                Icons.copy_rounded,
                size: AppIcons.md,
                color: AppColors.textSecondary,
              ),
              tooltip: 'Copy code',
              visualDensity: VisualDensity.compact,
            ),
        ],
      ),
        ),
      ),
    );
  }
}
