import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  String? _error;
  final _searchController = TextEditingController();

  bool _selectionMode = false;
  final Set<String> _selected = {};

  @override
  void initState() {
    super.initState();
    _loadUsers();
    _searchController.addListener(_filterUsers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUsers() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final result = await OwnerApiService.getUsers();
      if (!mounted) return;
      setState(() {
        _users = List<Map<String, dynamic>>.from(result['users'] ?? <dynamic>[]);
        _filterUsers();
      });
    } catch (e) {
      if (!mounted) return;
      // Do NOT silently show "no registered users" on a failed fetch —
      // that looks identical to genuinely having zero users and hides
      // real outages (e.g. can't reach the database), which is exactly
      // how a user who has already downloaded/paid can appear "missing".
      setState(() => _error = 'Tidak dapat memuatkan senarai pengguna. Server mungkin tidak dapat dihubungi.');
    }
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  void _filterUsers() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      _filtered = query.isEmpty
          ? _users
          : _users.where((u) {
              final devId = (u['device_id'] ?? '').toString().toLowerCase();
              final tgId = (u['telegram_id'] ?? '').toString().toLowerCase();
              return devId.contains(query) || tgId.contains(query);
            }).toList();
    });
  }

  void _toggleSelectionMode() {
    setState(() {
      _selectionMode = !_selectionMode;
      _selected.clear();
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selected.length == _filtered.length) {
        _selected.clear();
      } else {
        _selected
          ..clear()
          ..addAll(_filtered.map((u) => (u['device_id'] ?? '').toString()));
      }
    });
  }

  Future<void> _bulkDelete() async {
    if (_selected.isEmpty) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: const Text('Padam User?', style: AppText.heading),
        content: Text(
          '${_selected.length} rekod pengguna akan dipadam secara kekal, termasuk kredit dan pengikatan Telegram. Tindakan ini tidak boleh dibatalkan.',
          style: AppText.body,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Padam', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final result = await OwnerApiService.bulkDeleteUsers(_selected.toList());
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _users.removeWhere((u) => _selected.contains(u['device_id']));
          _selected.clear();
          _selectionMode = false;
          _filterUsers();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text((result['message'] ?? 'Gagal memadam.').toString())),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ralat: tidak dapat sambung ke server.')),
      );
    }
  }

  Future<void> _confirmDelete(Map<String, dynamic> user) async {
    final deviceId = (user['device_id'] ?? '').toString();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.bgRaised,
        title: const Text('Padam User?', style: AppText.heading),
        content: Text(
          'Rekod pengguna ini ($deviceId) akan dipadam secara kekal, termasuk kredit dan pengikatan Telegram. Tindakan ini tidak boleh dibatalkan.',
          style: AppText.body,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Padam', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final result = await OwnerApiService.deleteUser(deviceId);
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _users.removeWhere((u) => u['device_id'] == deviceId);
          _filterUsers();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text((result['message'] ?? 'Gagal memadam user.').toString())),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ralat: tidak dapat sambung ke server.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_selectionMode ? '${_selected.length} selected' : 'User List'),
        actions: [
          if (_selectionMode) ...[
            TextButton(
              onPressed: _toggleSelectAll,
              child: Text(
                _selected.length == _filtered.length && _filtered.isNotEmpty
                    ? 'Unselect All'
                    : 'Select All',
              ),
            ),
            IconButton(
              onPressed: _selected.isEmpty ? null : _bulkDelete,
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
              tooltip: 'Delete selected',
            ),
            IconButton(
              onPressed: _toggleSelectionMode,
              icon: const Icon(Icons.close_rounded),
              tooltip: 'Cancel',
            ),
          ] else
            IconButton(
              onPressed: _filtered.isEmpty ? null : _toggleSelectionMode,
              icon: const Icon(Icons.checklist_rounded),
              tooltip: 'Select',
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xxl,
                AppSpacing.md,
                AppSpacing.xxl,
                AppSpacing.md,
              ),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search by device ID or Telegram ID…',
                  prefixIcon: const Icon(
                    Icons.search_rounded,
                    size: AppIcons.md,
                    color: AppColors.textMuted,
                  ),
                ),
                style: AppText.body,
              ),
            ),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation(AppColors.accent),
                        ),
                      ),
                    )
                  : _error != null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(AppSpacing.xxl),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.cloud_off_rounded,
                                  size: AppIcons.hero,
                                  color: AppColors.error,
                                ),
                                const SizedBox(height: AppSpacing.md),
                                const Text('Unable to Load', style: AppText.heading),
                                const SizedBox(height: AppSpacing.xs),
                                Text(
                                  _error!,
                                  style: AppText.subtitle,
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: AppSpacing.lg),
                                OutlinedButton(
                                  onPressed: _loadUsers,
                                  child: const Text('Retry'),
                                ),
                              ],
                            ),
                          ),
                        )
                      : _filtered.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(AppSpacing.xxl),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.inbox_rounded,
                                  size: AppIcons.hero,
                                  color: AppColors.textMuted,
                                ),
                                const SizedBox(height: AppSpacing.md),
                                Text(
                                  _searchController.text.isNotEmpty
                                      ? 'No matching users'
                                      : 'No registered users yet',
                                  style: AppText.heading,
                                ),
                              ],
                            ),
                          ),
                        )
                      : RefreshIndicator(
                          color: AppColors.accent,
                          backgroundColor: AppColors.bgElevated,
                          onRefresh: _loadUsers,
                          child: ListView.separated(
                            padding: const EdgeInsets.fromLTRB(
                              AppSpacing.xxl,
                              0,
                              AppSpacing.xxl,
                              AppSpacing.huge,
                            ),
                            itemCount: _filtered.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: AppSpacing.sm),
                            itemBuilder: (_, i) {
                              final user = _filtered[i];
                              final deviceId = (user['device_id'] ?? '').toString();
                              return _UserCard(
                                user: user,
                                onDelete: () => _confirmDelete(user),
                                selectionMode: _selectionMode,
                                selected: _selected.contains(deviceId),
                                onToggleSelect: () => setState(() {
                                  if (_selected.contains(deviceId)) {
                                    _selected.remove(deviceId);
                                  } else {
                                    _selected.add(deviceId);
                                  }
                                }),
                              );
                            },
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final Map<String, dynamic> user;
  final VoidCallback onDelete;
  final bool selectionMode;
  final bool selected;
  final VoidCallback onToggleSelect;
  const _UserCard({
    required this.user,
    required this.onDelete,
    required this.selectionMode,
    required this.selected,
    required this.onToggleSelect,
  });

  @override
  Widget build(BuildContext context) {
    final deviceId = (user['device_id'] ?? '').toString();
    final telegramId = user['telegram_id']?.toString();
    final credits = (user['credits'] ?? 0).toString();
    final uploads = (user['total_uploads'] ?? 0).toString();
    final createdAt = (user['created_at'] ?? '').toString();
    final lastActiveMalaysia = (user['last_active_malaysia'] ?? '').toString();

    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: selectionMode ? onToggleSelect : null,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (selectionMode) ...[
                Checkbox(
                  value: selected,
                  onChanged: (_) => onToggleSelect(),
                  activeColor: AppColors.accent,
                ),
                const SizedBox(width: AppSpacing.xs),
              ] else
                Icon(
                  telegramId != null
                      ? Icons.link_rounded
                      : Icons.link_off_rounded,
                  size: AppIcons.sm,
                  color: telegramId != null
                      ? AppColors.accent
                      : AppColors.textMuted,
                ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  deviceId,
                  style: AppText.mono.copyWith(fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (!selectionMode)
                IconButton(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: deviceId));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Device ID copied.'), duration: Duration(seconds: 1)),
                    );
                  },
                  icon: const Icon(
                    Icons.copy_rounded,
                    size: AppIcons.md,
                    color: AppColors.textSecondary,
                  ),
                  tooltip: 'Copy full Device ID',
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              if (!selectionMode) const SizedBox(width: AppSpacing.sm),
              if (!selectionMode)
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    size: AppIcons.md,
                    color: AppColors.error,
                  ),
                  tooltip: 'Delete user',
                  visualDensity: VisualDensity.compact,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              _MicroStat(label: 'Credits', value: credits, accent: true),
              const SizedBox(width: AppSpacing.lg),
              _MicroStat(label: 'Submits', value: uploads),
              const SizedBox(width: AppSpacing.lg),
              _MicroStat(label: 'TG', value: telegramId ?? '-'),
            ],
          ),
          if (lastActiveMalaysia.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.sm),
            Text('Last active: $lastActiveMalaysia', style: AppText.caption),
          ],
          if (createdAt.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.xs),
            Text('Since: $createdAt', style: AppText.caption),
          ],
        ],
      ),
        ),
      ),
    );
  }
}

class _MicroStat extends StatelessWidget {
  final String label;
  final String value;
  final bool accent;

  const _MicroStat({
    required this.label,
    required this.value,
    this.accent = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: AppText.body.copyWith(
            fontWeight: FontWeight.w600,
            color: accent ? AppColors.accent : AppColors.textPrimary,
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: AppText.caption),
      ],
    );
  }
}
