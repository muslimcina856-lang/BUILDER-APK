# Security Policy — Owner Panel

## Access Model

The owner panel is **single-tenant**. Every `/api/owner/*` request must include
`X-Owner-API-Key`, which is checked against the server-only `OWNER_API_KEY`.
The backend fails closed when that environment variable is absent or too short.
Mitigations applied:

- Owner key stored using encrypted platform storage, not hardcoded in the app
- GitHub repo access via personal access token (rotate quarterly)
- Server-side validation of all admin actions in `vercel-api/`

## Reporting Critical Vulnerabilities

This panel has elevated privileges (can grant credits, generate codes, toggle
maintenance mode). If you find a vulnerability, **report immediately and
privately**:

- **Telegram:** [@earlxz](https://t.me/earlxz)
- Subject: `[SECURITY] Earl Builder Owner Panel`

Do NOT open public issues for anything affecting:
- Code generation endpoints
- Credit grant endpoints
- Maintenance toggle endpoints
- Telegram bot token leakage

## Scope

The owner panel shares the same serverless backend with the user app. Critical
vulnerabilities in `vercel-api/` are applicable to BOTH apps.

## Response Time

| Severity | Acknowledgement | Patch |
|----------|------------------|-------|
| Critical | 24 hours | 7 days |
| High     | 48 hours | 14 days |
| Medium   | 7 days   | 30 days |
| Low      | 30 days  | Best effort |

## Permission Audit

Owner panel requests MINIMIZE permission scope:

| Permission | Why needed |
|-----------|-----------|
| INTERNET | API calls to Vercel |
| ACCESS_NETWORK_STATE | Detect offline state |
| POST_NOTIFICATIONS | Background music notifications |
| WAKE_LOCK | Background music playback |

No camera, contacts, location, or storage permissions requested.

## Defense in Depth

For maximum hardening:
1. Use a long random `OWNER_API_KEY` and rotate it when a device is lost
2. Vercel deploys only from trusted GitHub commits
3. Keep Turso, Telegram and GitHub credentials only in server environment variables
4. Rotate `BOT_TOKEN` and `GITHUB_TOKEN` periodically
