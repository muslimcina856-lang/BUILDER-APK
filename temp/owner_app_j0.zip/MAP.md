# Earl Builder Owner App — MAP

## Peranan

Aplikasi Flutter dalaman untuk pemilik sistem Earl Builder. Aplikasi ini tidak
membina APK secara terus. Ia berhubung dengan Vercel API untuk mengurus pengguna,
kredit, kod tebus, maintenance dan iklan.

## Aliran permulaan

1. `lib/main.dart` membaca `OWNER_API_KEY` daripada encrypted storage.
2. Jika kunci tersimpan wujud, aplikasi mengesahkannya melalui
   `GET /api/owner/server-status`.
3. Kunci sah membuka `DashboardScreen`; kunci tiada atau tidak sah membuka
   `OwnerLoginScreen`.
4. Ralat rangkaian sementara tidak memadam kunci yang tersimpan.
5. Logout memadam kunci daripada encrypted storage dan header API.

## Struktur utama

```text
owner_app/ (projek Flutter untuk pentadbir/pemilik sistem)
├── lib/ (semua kod Dart utama aplikasi)
│   ├── main.dart (entry point, pulihkan sesi owner dan pilih login atau dashboard)
│   ├── config.dart (URL backend, nama aplikasi dan pautan owner/channel)
│   ├── theme/
│   │   └── app_theme.dart (warna, spacing, typography dan gaya UI Owner App)
│   ├── services/
│   │   ├── api_service.dart (semua panggilan ke route /api/owner/*)
│   │   └── owner_auth_service.dart (simpan, baca dan padam owner key secara selamat)
│   └── screens/
│       ├── owner_login_screen.dart (login dan pengesahan owner key)
│       ├── dashboard_screen.dart (ringkasan sistem dan pintasan ke semua modul)
│       ├── user_list_screen.dart (senarai, carian dan pemadaman pengguna)
│       ├── add_credit_screen.dart (tambah kredit melalui Device ID atau Telegram ID)
│       ├── generate_code_screen.dart (jana kod kredit baharu)
│       ├── code_list_screen.dart (senarai, carian, salin dan padam kod aktif)
│       ├── server_toggle_screen.dart (urus maintenance, mesej dan muzik)
│       ├── create_ad_screen.dart (cipta iklan dan rekod identiti pembeli/pemilik)
│       ├── ads_list_screen.dart (senarai, statistik, carian pembeli dan padam iklan)
│       └── about_screen.dart (maklumat aplikasi serta pautan owner/channel)
├── android/ (konfigurasi binaan dan signing Android)
├── ios/ (konfigurasi binaan iOS)
├── web/ (konfigurasi binaan web)
├── windows/ (konfigurasi binaan Windows)
├── linux/ (konfigurasi binaan Linux)
├── macos/ (konfigurasi binaan macOS)
├── pubspec.yaml (dependencies, aset dan metadata projek Flutter)
├── analysis_options.yaml (peraturan lint dan analisis Dart)
├── README.md (panduan umum projek)
├── SECURITY.md (panduan keselamatan)
├── CHANGELOG.md (rekod perubahan versi)
└── MAP.md (peta dan penerangan codebase Owner App)
```

## Skrin

| Skrin | Fail | Fungsi sebenar |
|---|---|---|
| Owner Login | `owner_login_screen.dart` | Terima owner key minimum 16 aksara, sahkan dengan backend dan simpan secara terenkripsi |
| Dashboard | `dashboard_screen.dart` | Papar jumlah pengguna, kod aktif, status maintenance dan pautan ke semua modul |
| User List | `user_list_screen.dart` | Senarai dan carian pengguna, lihat Device ID/Telegram ID/kredit/upload, salin Device ID, padam satu atau ramai pengguna |
| Add Credits | `add_credit_screen.dart` | Tambah kredit menggunakan Device ID atau Telegram ID pengguna |
| Generate Codes | `generate_code_screen.dart` | Jana kod kredit mengikut jumlah kredit dan bilangan kod; salin atau kongsi hasil |
| Active Codes | `code_list_screen.dart` | Senarai kod belum digunakan, carian, salin dan padam secara pukal |
| Server Toggle | `server_toggle_screen.dart` | Hidup/matikan maintenance, tetapkan tajuk, mesej dan URL muzik latar |
| Create Ad | `create_ad_screen.dart` | Cipta iklan imej/video dengan URL klik, tajuk, caption, pemilik/pembeli pilihan dan had views/days |
| Manage Ads | `ads_list_screen.dart` | Senarai iklan, carian berdasarkan ID pembeli, lihat jumlah tontonan/had dan padam secara pukal |
| About | `about_screen.dart` | Maklumat panel serta pautan owner dan channel |

## Maksud medan iklan

Kolum database berikut dikekalkan atas sebab keserasian:

- `target_device_id`
- `target_telegram_id`

Dalam versi semasa, kedua-duanya **bukan sasaran penonton**. Ia hanya menyimpan
identiti pembeli/pemilik iklan untuk rekod, carian dan pemantauan dalam Owner App.

Peraturan semasa:

- Hanya satu ID pembeli boleh diisi: Device ID atau Telegram ID.
- ID pembeli mesti wujud dalam sistem.
- Telegram ID mesti berbentuk nombor dan sudah terikat kepada pengguna.
- Jika kedua-duanya kosong, iklan direkod sebagai iklan milik owner.
- Semua iklan aktif masuk ke pool rawak yang sama untuk semua penonton.
- ID pembeli tidak menentukan siapa yang boleh melihat atau menuntut ganjaran.
- Owner App hanya memantau iklan; pembeli belum mempunyai skrin pemantauan sendiri dalam User App.

## Route backend yang digunakan

| Method | Route | Kegunaan |
|---|---|---|
| `GET` | `/api/owner/server-status` | Sahkan owner key dan baca tetapan server |
| `GET` | `/api/owner/users` | Ambil senarai pengguna |
| `POST` | `/api/owner/delete-user` | Padam seorang pengguna |
| `POST` | `/api/owner/bulk-delete-users` | Padam ramai pengguna |
| `POST` | `/api/owner/add-credit` | Tambah kredit |
| `POST` | `/api/owner/generate-code` | Jana kod kredit |
| `GET` | `/api/owner/codes` | Senarai kod aktif |
| `POST` | `/api/owner/bulk-delete-codes` | Padam kod aktif secara pukal |
| `POST` | `/api/owner/create-ad` | Cipta iklan dan rekod ID pembeli pilihan |
| `GET` | `/api/owner/ads` | Senarai semua iklan |
| `POST` | `/api/owner/delete-ads` | Padam iklan secara pukal |
| `POST` | `/api/owner/toggle-server` | Ubah tetapan maintenance |

Semua route `/api/owner/*` memerlukan header `X-Owner-API-Key`.

## Dependencies

Digunakan dalam source semasa:

- `dio` — HTTP API.
- `flutter_secure_storage` — simpan owner key.
- `url_launcher` — buka pautan owner/channel.
- `share_plus` — kongsi kod kredit.

`shared_preferences` masih dideklarasikan dalam `pubspec.yaml`, tetapi tidak
dirujuk oleh fail dalam `lib/` pada versi semasa.

## Permission Android

Manifest mendeklarasikan:

- `INTERNET`
- `ACCESS_NETWORK_STATE`
- `POST_NOTIFICATIONS`
- `WAKE_LOCK`

Kod Dart Owner App semasa menggunakan internet untuk API dan pautan. Tiada kod
muzik latar atau local notification dalam `lib/` Owner App; dua permission
terakhir masih kekal dalam manifest.

## Konfigurasi

- Tetapkan `OwnerConfig.baseUrl` dalam `lib/config.dart` kepada deployment
  Vercel yang sama dengan User App, tanpa `/` di hujung.
- Tetapkan `OWNER_API_KEY` minimum 16 aksara pada Vercel.
- Masukkan nilai yang sama pada skrin login Owner App.
- Fail signing sebenar tidak disertakan; gunakan template
  `android/key.properties.example` untuk konfigurasi release peribadi.
