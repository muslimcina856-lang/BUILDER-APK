# Earl Builder — Owner App

Aplikasi Flutter dalaman untuk owner mengurus pengguna, kredit, kod tebus,
iklan dan maintenance Earl Builder.

## Backend

Aplikasi menggunakan backend **Next.js/Vercel + Turso** yang sama dengan
`user_app`. Python server, SQLite tempatan dan Cloudflare Tunnel tidak
digunakan.

Tetapkan URL deployment dalam `lib/config.dart`:

```dart
static const String baseUrl = 'https://domain-vercel-anda.vercel.app';
```

Gunakan URL tanpa `/` di hujung.

Semua route owner dilindungi oleh `OWNER_API_KEY`. Tetapkan kunci rawak minimum
16 aksara pada Environment Variables Vercel. Owner app meminta nilai yang sama
pada skrin login dan menyimpannya dalam secure storage peranti; jangan
hardcode kunci tersebut dalam source code.

### Cara login owner berfungsi

1. Tetapkan `OWNER_API_KEY` di Vercel, contohnya satu nilai rawak yang panjang.
2. Redeploy backend selepas menambah atau menukar environment variable itu.
3. Pada kali pertama Owner App dibuka, masukkan **nilai yang tepat sama** pada
   skrin login. Huruf besar, huruf kecil dan simbol mesti sepadan.
4. Selepas berjaya, kunci disimpan dalam secure storage peranti. Pembukaan app
   seterusnya akan mengesahkan kunci tersebut dan terus membuka dashboard jika
   ia masih sah.

Owner App akan meminta kunci semula hanya apabila pengguna menekan Logout,
data aplikasi dipadam, atau nilai `OWNER_API_KEY` di Vercel telah berubah,
tidak sah atau tidak lagi dikonfigurasi. Gangguan internet sementara tidak
memadam kunci yang telah disimpan. Kunci ini tidak perlu dan tidak boleh
dimasukkan ke dalam `lib/config.dart`.

## Fungsi

- Melihat dan memadam pengguna.
- Menambah kredit menggunakan device ID atau Telegram ID.
- Menjana, menyalin dan memadam kod kredit.
- Mengaktifkan atau mematikan maintenance.
- Menetapkan tajuk, mesej dan muzik maintenance.
- Mencipta iklan dan menyimpan Device ID atau Telegram ID pembeli untuk pemantauan.
- Semua iklan aktif dipaparkan secara rawak kepada pengguna; ID pembeli tidak
  menentukan siapa yang melihat iklan.
- Melihat, mencari mengikut ID pembeli dan memadam iklan.

## Konfigurasi

Nilai aplikasi dalam `lib/config.dart`:

| Pembolehubah | Tujuan |
|---|---|
| `baseUrl` | URL deployment Vercel |
| `ownerLink` | Pautan owner |
| `channelLink` | Pautan channel |

Environment variables backend menggunakan `GITHUB_REPO` dalam format
`owner/repo`; `GITHUB_REPO_OWNER`, `GITHUB_REPO_NAME` dan `BOT_USERNAME`
tidak digunakan.

Credential Turso, GitHub dan Telegram tidak boleh dimasukkan dalam aplikasi.
`OWNER_API_KEY` hanya dimasukkan ketika login, bukan dalam `config.dart`.

## Setup dan build

```bash
flutter pub get
flutter build apk --debug
```

Output debug berada di `build/app/outputs/flutter-apk/app-debug.apk`.

Owner app ialah aplikasi dalaman dan bukan untuk edaran awam. Walau begitu,
route `/api/owner/*` tetap disekat oleh middleware backend.

Fail signing sebenar tidak disertakan. Gunakan
`android/key.properties.example` sebagai templat jika mahu menandatangani
release dengan keystore sendiri.

## Struktur utama

```text
lib/
├── config.dart
├── main.dart
├── screens/
│   ├── dashboard_screen.dart
│   ├── owner_login_screen.dart
│   ├── user_list_screen.dart
│   ├── add_credit_screen.dart
│   ├── generate_code_screen.dart
│   ├── code_list_screen.dart
│   ├── server_toggle_screen.dart
│   ├── create_ad_screen.dart
│   ├── ads_list_screen.dart
│   └── about_screen.dart
└── services/
    ├── api_service.dart
    └── owner_auth_service.dart
```
