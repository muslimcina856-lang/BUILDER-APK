#!/usr/bin/env python3
"""Ujian regresi aliran sambung pemasangan PC Windows."""
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "mobile/lib/src/services/windows_runtime_service.dart").read_text(
    encoding="utf-8"
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


configure = SOURCE.split("Future<void> _configureCompatibilityLayer", 1)[1]
configure = configure.split("Future<void> _repairDpkgState", 1)[0]
require(
    configure.index("await _repairDpkgState(linuxRootPath);")
    < configure.index("final installCommand"),
    "dpkg mesti dipulihkan sebelum pemasangan desktop/Box64",
)

repair = SOURCE.split("Future<void> _repairDpkgState", 1)[1]
repair = repair.split("Future<void> _installProotBox64Fallback", 1)[0]
require("apt-get -y -f install" in repair, "apt --fix-broken tiada")
require("dpkg --audit" in repair, "audit dpkg akhir tiada")
require(
    "fail \"dpkg masih mempunyai pakej separuh dikonfigurasi\"" in repair,
    "audit dpkg yang gagal masih diteruskan",
)
require(
    "libxt6t64" in repair and "libpython3.12-stdlib" in repair,
    "rantai dependency daripada laporan peranti belum dibaiki",
)

fallback = SOURCE.split("Future<void> _installProotBox64Fallback", 1)[1]
fallback = fallback.split("Future<_ProcessOutput> _windowsHealthCheck", 1)[0]
require(
    "await _repairDpkgState(linuxRootPath);" in fallback,
    "fallback Box64 mesti bermula daripada dpkg bersih",
)
require("build-essential" not in fallback, "fallback masih memasang meta-package besar")
require("apt-get purge" not in fallback, "fallback tidak boleh purge selepas binaan")
require("apt-get autoremove" not in fallback, "fallback tidak boleh autoremove dependency")

normal_probe = configure.index("Probe Box64 generik gagal")
interpreter_probe = configure.index("Probe Box64 interpreter gagal")
source_fallback = configure.index("await _installProotBox64Fallback(linuxRootPath);")
require(
    normal_probe < interpreter_probe < source_fallback,
    "turutan mesti generik → interpreter → binaan sumber",
)
require(
    "const maxAttempts = 12" in SOURCE
    and "request.persistentConnection = false" in SOURCE,
    "retry rangkaian panjang/non-persistent belum aktif",
)

print("UJIAN PEMULIHAN WINDOWS LULUS")
print("- dpkg dibaiki dan diaudit sebelum desktop/Box64")
print("- probe Box64 generik → interpreter → binaan sumber")
print("- muat turun resume menggunakan 12 cubaan")
