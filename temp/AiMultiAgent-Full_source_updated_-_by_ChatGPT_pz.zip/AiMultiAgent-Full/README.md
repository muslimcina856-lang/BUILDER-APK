# Ai MultiAgent Full

Aplikasi Android BYOK tanpa backend perantara. Package ID `com.aiauto.claw.full`, versi `1.0.0+1`, `compileSdk 36`, `targetSdk 28`.

## Pembetulan utama

- Timeout provider lalai 180 saat dan konfigurasi lama 60 saat dimigrasikan automatik.
- Skrin kekal menyala semasa aplikasi berada di hadapan.
- Tugasan aktif diteruskan melalui foreground service dan partial wake lock sehingga 30 minit apabila Android tidak menyekat aplikasi.
- AI menerima konteks runtime Android/browser sebenar pada setiap tugasan; browser Chromium tersembunyi menggunakan mod desktop secara lalai.
- Build release menghasilkan APK dan AAB, mengaktifkan R8 + resource shrinking, serta mewajibkan `mapping.txt`.
- Target API dipaparkan terus pada skrin Tetapan dan Lagi.

Workspace kini membundel Alpine Linux 3.24.1 ARM64 + PRoot 0.15 secara automatik dalam build Full. Bahagian Linux dipaparkan sebagai **Shell** dan AI memasang/mengesahkannya sebelum arahan terminal pertama serta menggunakan pengurus pakej `apk`. Pemasangan menggunakan transaksi staging/backup, pulih selepas proses terhenti, rollback apabila health check gagal, dan menolak ZIP berbahaya atau melampaui had. Output terminal serta bilangan job juga dihadkan untuk mengelakkan penggunaan memori tanpa had.

Edisi Full turut menyediakan **PC Windows local** sebagai lapisan keserasian yang berasingan. Pada kali pertama Workspace dibuka (atau apabila tool Windows pertama dipanggil), aplikasi memuat turun Ubuntu Base ARM64, memasang Box64 dan Wine WoW64, mencipta prefix Windows serta desktop headless 1280×720. AI boleh menjalankan `cmd.exe`, membuka fail `.exe` daripada `/workspace` atau lampiran chat, dan membuka semula aplikasi yang sudah dipasang dalam drive `C:` Wine. AI juga boleh mengambil screenshot, menyenaraikan/fokus tetingkap, klik, menaip dan menghantar kekunci. Runtime Windows disimpan berasingan daripada Shell supaya reset Shell tidak memadamnya; `/workspace` dikongsi antara kedua-duanya. Box64 generik daripada repository bertandatangan dicuba dahulu; jika probe Wine gagal pada Android/PRoot, pemasang membina fallback Box64 0.4.4 yang dipin dengan `BAD_SIGNAL=ON`. Ini lapisan keserasian Wine + Box64, bukan kernel/VM Windows penuh.

Pemasangan PC Windows tahan gangguan: muat turun Ubuntu dan Wine boleh disambung semula sehingga 12 cubaan, cache/rootfs yang sah digunakan semula, dan butang **Sambung pemasangan** meneruskan tahap yang belum lengkap. Keadaan `dpkg` separuh siap dibaiki dengan `apt --fix-broken`, pemasangan semula dependency libXt/Python yang terjejas dan audit wajib sebelum desktop atau Box64 diteruskan. Box64 generik turut mempunyai mod interpreter tanpa dynarec untuk kernel Android yang ketat sebelum binaan sumber digunakan. Reset hanya diperlukan jika ralat yang sama masih berulang. Desktop hanya ditanda sedia selepas Xvfb, Openbox, scrot, xdotool, Box64, Wine dan prefix lulus pemeriksaan sebenar.

## Pembaikan pengalaman aplikasi

- Halaman **Cara Guna** tersedia dalam tab Lagi. Tiada halaman terma/polisi tambahan dimasukkan dalam perubahan ini.
- Screenshot browser disimpan sebagai satu PNG halaman penuh dan dipaparkan tanpa potongan; tekan untuk skrin penuh, zum/pan atau Simpan.
- Gambar, video dan audio URL terus boleh dihantar melalui `media_preview` dan dipratonton dalam chat tanpa disimpan secara automatik. Media tidak autoplay; Simpan hanya berlaku selepas tindakan pengguna.
- Browser Chromium tersembunyi dipaksa senyap, termasuk laman seperti TikTok/YouTube dan ketika aplikasi berada di latar belakang.
- Kad pratonton halaman web ditutup secara lalai dan tidak menjalankan JavaScript atau media.
- Linux Workspace tidak lagi menggunakan callback `setState` async yang menyebabkan crash.
- AI mengutamakan PC Windows local untuk kerja Windows; server MCP Windows yang dikonfigurasi kekal sebagai pilihan tambahan apabila tugasan memerlukan PC Windows penuh/peranti jauh.
- Ikon edisi Full menggunakan rekaan hitam-ungu premium baharu.

## Build debug dan release

Gunakan Flutter `3.44.8`, Java 17, Python 3, akses Internet dan Android SDK 36. Kedua-dua skrip menyediakan, mengesahkan dan membundel runtime Linux sebelum Flutter bermula. Runtime PC Windows tidak dibundel ke APK; ia dimuat turun ke storan private aplikasi pada penggunaan pertama supaya saiz APK tidak meningkat dengan rootfs/Wine. Selain itu, Gradle kini mengaitkan `prepareBundledLinuxRuntime` dan `verifyBundledLinuxRuntime` terus kepada semua task `compileFlutterBuild*`, jadi panel yang memanggil `flutter build apk/appbundle` secara terus turut menyediakan asset sebelum `pubspec.yaml` diproses:

```bash
# APK debug ARM64
./scripts/build_debug.sh

# APK + AAB release ARM64
./scripts/build_full.sh
```

Build terus juga disokong kerana hook Gradle menyediakan runtime sebelum task Flutter:

```bash
cd mobile
flutter pub get
flutter run
# atau
flutter build apk --debug --target-platform android-arm64 --no-pub
```

Varian debug dan release dibina secara berasingan; `assembleDebug` tidak lagi menjalankan `assembleRelease` sebagai langkah tersembunyi. Gunakan `build_full.sh` apabila artifact release diperlukan.

Penyediaan manual masih boleh digunakan untuk mengisi cache atau menguji runtime tanpa membina Android:

```bash
python3 scripts/linux/prepare_bundled_runtime.py
python3 scripts/linux/prepare_bundled_runtime.py --verify-only
```

Output lengkap berada di `dist/full/`, termasuk APK/AAB ARM64, salinan runtime+manifest, `R8_STATUS.txt`, `SIGNING_INFO.txt`, laporan R8 dan SHA-256. Build gagal jika Linux runtime tidak ditemui dalam kedua-dua artifact. Source ZIP sengaja tidak menyimpan binary runtime yang dijana; skrip build, hook Gradle untuk build terus, dan workflow CI membina asset daripada sumber version/commit-pinned lalu membuktikan asset itu berada dalam APK/AAB. Tanpa `mobile/android/key.properties` yang sah, buildType kekal `release` tetapi menggunakan debug key untuk ujian pemasangan sahaja.

## Semakan source tanpa Flutter

```bash
./scripts/check_project.sh
```

Semakan ini mengesahkan source, XML, konfigurasi release/R8, foreground service, browser context dan fixture carian. Build Flutter sebenar dijalankan oleh workflow CI `.github/workflows/android-release-check.yml`.
