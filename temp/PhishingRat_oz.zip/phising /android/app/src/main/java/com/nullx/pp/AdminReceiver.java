package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.widget.EditText;
import android.content.SharedPreferences;
import android.content.ComponentName;
import android.app.admin.DevicePolicyManager;

public class AdminReceiver extends DeviceAdminReceiver {
    
    private Intent pendingIntent;
    private Context pendingContext;
    
    private boolean checkPin(Context context, String enteredPin) {
        SharedPreferences prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        String savedPin = prefs.getString("flutter.admin_pin", "1234");
        return enteredPin.equals(savedPin);
    }
    
    private void showPinDialog(final Context context, final Intent intent, final PinCallback callback) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Verifikasi PIN");
        builder.setMessage("Masukkan PIN untuk menonaktifkan admin:");
        
        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        builder.setView(input);
        
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String pin = input.getText().toString();
                callback.onPinEntered(pin, context, intent);
            }
        });
        
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                callback.onCancel(context);
            }
        });
        
        builder.setCancelable(false);
        builder.show();
    }
    
    private void reactivateAdmin(Context context) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminName = new ComponentName(context, AdminReceiver.class);
        
        if (!dpm.isAdminActive(adminName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Aktifkan admin untuk melanjutkan");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        Toast.makeText(context, "Device Admin Enabled - Anti Disable Active", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDisabled(final Context context, final Intent intent) {
        showPinDialog(context, intent, new PinCallback() {
            @Override
            public void onPinEntered(String pin, Context ctx, Intent intnt) {
                if (checkPin(ctx, pin)) {
                    Toast.makeText(ctx, "Admin disabled", Toast.LENGTH_SHORT).show();
                    // Panggil super.onDisabled dengan benar
                    AdminReceiver.super.onDisabled(ctx, intnt);
                } else {
                    Toast.makeText(ctx, "PIN salah! Admin tetap aktif.", Toast.LENGTH_LONG).show();
                    reactivateAdmin(ctx);
                }
            }
            
            @Override
            public void onCancel(Context ctx) {
                reactivateAdmin(ctx);
            }
        });
    }
    
    interface PinCallback {
        void onPinEntered(String pin, Context context, Intent intent);
        void onCancel(Context context);
    }
}