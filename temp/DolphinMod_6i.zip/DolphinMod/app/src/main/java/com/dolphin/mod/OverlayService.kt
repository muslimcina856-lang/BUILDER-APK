package com.dolphin.mod

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

/** Floating bubble. Tap = open script list, tap a script = copy it. Drag to move. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        goForeground()
        showBubble()
    }

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null; bubble = null
        super.onDestroy()
    }

    private fun goForeground() {
        val ch = NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_MIN)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        val n = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Dolphin Mod overlay is running")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showBubble() {
        val size = dp(52)
        val tv = TextView(this).apply {
            text = "D"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            alpha = 0.92f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF00B4D8.toInt())
                setStroke(dp(2), 0xFFCAF0F8.toInt())
            }
        }
        val lp = params(size, size).apply { x = dp(8); y = dp(200) }

        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel(lp.y)
                }
                return true
            }
        })
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun togglePanel(y: Int) {
        if (panel != null) { hidePanel(); return }
        val scripts = Store(this).load()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xFF0B2D45.toInt())
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        root.addView(label("DOLPHIN SCRIPTS", 0xFF00B4D8.toInt(), 12f, bold = true))

        if (scripts.isEmpty()) {
            root.addView(label("No scripts saved yet.\nAdd some in the app.", 0xFF8FB8CC.toInt(), 13f))
        } else {
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            scripts.forEach { s -> list.addView(button(s.name) { copy(s) }) }
            val sv = ScrollView(this).apply { addView(list) }
            root.addView(sv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                min(scripts.size * dp(46) + dp(4), dp(260)),
            ))
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("HIDE") { hidePanel() }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("STOP") { stopSelf() }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        val lp = params(dp(240), WindowManager.LayoutParams.WRAP_CONTENT).apply { x = dp(68); this.y = y }
        wm.addView(root, lp)
        panel = root
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun copy(s: Script) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(s.name, s.code))
        Toast.makeText(this, "Copied: ${s.name}", Toast.LENGTH_SHORT).show()
    }

    private fun label(text: String, color: Int, size: Float, bold: Boolean = false) = TextView(this).apply {
        this.text = text; setTextColor(color); textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(0xFF0E3A57.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        setOnClickListener { onClick() }
    }
}
