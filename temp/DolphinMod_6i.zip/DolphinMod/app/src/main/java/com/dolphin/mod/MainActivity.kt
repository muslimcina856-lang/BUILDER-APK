package com.dolphin.mod

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// ---------- data ----------
data class Script(val id: String, val name: String, val code: String)
data class Game(val name: String, val pkg: String)

val GAMES = listOf(
    Game("ML Global", "com.mobile.legends"),
    Game("ML USA", "com.mobile.legends.usa"),
    Game("Roblox", "com.roblox.client"),
    Game("Free Fire", "com.dts.freefireth"),
    Game("Minecraft", "com.mojang.minecraftpe"),
)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("dolphin", Context.MODE_PRIVATE)

    fun load(): List<Script> {
        val arr = JSONArray(p.getString("scripts", "[]"))
        return List(arr.length()) {
            val o = arr.getJSONObject(it)
            Script(o.getString("id"), o.getString("name"), o.getString("code"))
        }
    }

    fun save(list: List<Script>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("code", it.code)) }
        p.edit().putString("scripts", arr.toString()).apply()
    }
}

// ---------- ocean palette (same layout language as the reference, new colours) ----------
private val Bg = Color(0xFF041A2B)        // deep sea
private val CardBg = Color(0xFF0B2D45)    // card
private val TileBg = Color(0xFF0E3A57)    // inner tile
private val Ocean = Color(0xFF0077B6)
private val Accent = Color(0xFF00B4D8)    // aqua
private val Foam = Color(0xFFCAF0F8)
private val Muted = Color(0xFF8FB8CC)
private val Stroke = Color.White.copy(alpha = 0.05f)

@Composable
fun DolphinTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Bg,
            background = Bg, onBackground = Color.White,
            surface = CardBg, onSurface = Color.White,
            surfaceVariant = CardBg, onSurfaceVariant = Muted,
            surfaceContainerHigh = CardBg,
        ),
        content = content,
    )
}

@Composable
fun OceanCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = CardBg,
        border = BorderStroke(1.dp, Stroke),
        content = content,
    )
}

@Composable
fun Chip(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = modifier.background(Accent.copy(alpha = 0.1f)).padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

// ---------- activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        setContent { DolphinApp(store) }
    }
}

@Composable
fun DolphinApp(store: Store) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scripts = remember { mutableStateListOf<Script>().also { it.addAll(store.load()) } }
    var tab by remember { mutableIntStateOf(0) }
    var pendingNew by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    DolphinTheme {
        Column(
            Modifier.fillMaxSize().background(Bg)
                .windowInsetsPadding(WindowInsets.systemBars).padding(10.dp)
        ) {
            Header()
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp)) {
                when (tab) {
                    0 -> MainScreen(onToast = ::toast)
                    1 -> ScriptsScreen(
                        scripts = scripts,
                        openNew = pendingNew,
                        onNewConsumed = { pendingNew = false },
                        onSave = { s ->
                            val idx = scripts.indexOfFirst { it.id == s.id }
                            if (idx >= 0) scripts[idx] = s else scripts.add(0, s)
                            store.save(scripts.toList())
                        },
                        onDelete = { s -> scripts.remove(s); store.save(scripts.toList()) },
                        onCopy = { s -> clipboard.setText(AnnotatedString(s.code)); toast("Copied: ${s.name}") },
                    )
                    2 -> InfoScreen(onClear = { scripts.clear(); store.save(emptyList()); toast("All scripts deleted") })
                    else -> OverlayScreen()
                }
            }
            BottomNav(tab) { tab = it }
        }
    }
}

// ---------- chrome ----------
@Composable
fun Header() {
    OceanCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Ocean, Accent)))
                    .border(2.dp, Foam.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("D", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp) }
            Spacer(Modifier.width(10.dp))
            Text("DOLPHIN MOD", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        "MAIN" to Icons.Filled.SportsEsports,
        "PLUGIN" to Icons.Filled.Extension,
        "INFO" to Icons.Filled.Info,
        "OVERLAY" to Icons.Filled.Layers,
    )
    OceanCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
            items.forEachIndexed { i, (label, icon) ->
                val c = if (selected == i) Accent else Color(0xFF91ADB1)
                Column(
                    Modifier.weight(1f).clickable { onSelect(i) }.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(icon, contentDescription = label, tint = c, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(4.dp))
                    Text(label, color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------- MAIN ----------
@Composable
fun MainScreen(onToast: (String) -> Unit) {
    val ctx = LocalContext.current
    val bit = remember { if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) "64bit" else "32bit" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 10.dp)) {
        Text(
            "Welcome back, Agent", color = Color.White.copy(alpha = 0.8f),
            fontSize = 24.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp),
        )
        Box(Modifier.padding(start = 16.dp, top = 10.dp, bottom = 28.dp).width(80.dp).height(4.dp).background(Accent))

        OceanCard(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("YOUR GAME :", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Chip("STATUS : READY")
                }
                GAMES.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        pair.forEach { g ->
                            val intent = remember(g.pkg) { ctx.packageManager.getLaunchIntentForPackage(g.pkg) }
                            GameTile(g.name, bit, installed = intent != null) {
                                if (intent != null) {
                                    ctx.startActivity(intent)
                                } else {
                                    runCatching {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${g.pkg}")))
                                    }.onFailure { onToast("Play Store not available") }
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.width(112.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun GameTile(name: String, bit: String, installed: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(112.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(112.dp).clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Ocean, TileBg, Accent.copy(alpha = 0.7f))))
                .clickable(onClick = onClick),
        ) {
            Text(
                name.substringBefore(' ').take(2).uppercase(),
                color = Foam.copy(alpha = 0.35f), fontSize = 48.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center),
            )
            Text(
                bit, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
                    .background(Accent).padding(horizontal = 6.dp, vertical = 2.dp),
            )
            Text(
                if (installed) "Open" else "Install", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                    .background(Accent).padding(horizontal = 14.dp, vertical = 5.dp),
            )
        }
        Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------- OVERLAY ----------
@Composable
fun OverlayScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Chip("OVERLAY")
        OverlayCard()
    }
}

// ---------- SCRIPTS ----------
@Composable
fun ScriptsScreen(
    scripts: List<Script>,
    openNew: Boolean,
    onNewConsumed: () -> Unit,
    onSave: (Script) -> Unit,
    onDelete: (Script) -> Unit,
    onCopy: (Script) -> Unit,
) {
    var creating by remember { mutableStateOf(openNew) }
    var editing by remember { mutableStateOf<Script?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { if (openNew) onNewConsumed() }

    if (creating) EditDialog(null, { creating = false }) { onSave(it); creating = false }
    editing?.let { cur -> EditDialog(cur, { editing = null }) { onSave(it); editing = null } }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip("PLUGIN : SCRIPTS", Modifier.weight(1f, fill = false))
            Spacer(Modifier.weight(1f))
            FilledIconButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, "New script") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search") }, singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        )
        val shown = scripts.filter { it.name.contains(query, ignoreCase = true) }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No scripts yet. Tap + to add one.", color = Muted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown, key = { it.id }) { s ->
                    OceanCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(s.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(
                                s.code.take(120), maxLines = 3, color = Muted,
                                fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                                modifier = Modifier.padding(vertical = 6.dp),
                            )
                            Row {
                                TextButton(onClick = { onCopy(s) }) { Text("COPY") }
                                TextButton(onClick = { editing = s }) { Text("EDIT") }
                                TextButton(onClick = { onDelete(s) }) { Text("DELETE") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditDialog(initial: Script?, onDismiss: () -> Unit, onSave: (Script) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var code by remember { mutableStateOf(initial?.code ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        title = { Text(if (initial == null) "New script" else "Edit script") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(code, { code = it }, label = { Text("Code") }, minLines = 6, maxLines = 10, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onSave(Script(initial?.id ?: UUID.randomUUID().toString(), name.trim(), code)) },
            ) { Text("SAVE") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } },
    )
}

// ---------- INFO ----------
@Composable
fun InfoScreen(onClear: () -> Unit) {
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val rows = listOf(
        "Device Model" to Build.MODEL,
        "Manufacturer" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        "Android Version" to Build.VERSION.RELEASE,
        "SDK Level" to Build.VERSION.SDK_INT.toString(),
        "CPU Architecture" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "-"),
        "Screen Resolution" to "${dm.widthPixels} x ${dm.heightPixels}",
    )
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Chip("DEVICE INFO")
        OceanCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("DEVICE INFORMATION", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                rows.forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth()) {
                        Text(k, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(v, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        OceanCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("PRIVACY", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Dolphin Mod requests no permissions. No SMS, contacts, call log, mic or camera. Scripts stay on this device.",
                    color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
        OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("DELETE ALL SCRIPTS") }
        Text("DOLPHIN MOD v1.0", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            shape = RoundedCornerShape(20.dp),
            title = { Text("Delete all scripts?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { onClear(); confirm = false }) { Text("DELETE") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("CANCEL") } },
        )
    }
}

@Composable
fun OverlayCard() {
    val ctx = LocalContext.current
    OceanCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("FLOATING OVERLAY", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(
                "A draggable bubble over other apps. Tap it to copy your saved scripts while you play.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (!Settings.canDrawOverlays(ctx)) {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            )
                        } else {
                            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("START") }
                OutlinedButton(
                    onClick = { ctx.stopService(Intent(ctx, OverlayService::class.java)) },
                    modifier = Modifier.weight(1f),
                ) { Text("STOP") }
            }
        }
    }
}
