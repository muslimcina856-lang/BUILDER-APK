package com.example.prankapp;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout root;
    private TextView mainText, subText, icon;
    private Button closeButton;
    private Handler handler = new Handler(Looper.getMainLooper());

    private boolean[] flickerState = {true};
    private final int FLICKER_DURATION_MS = 3000; // total durasi efek "serem"
    private final int FLICKER_INTERVAL_MS = 150;  // kecepatan kedip

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root_layout);
        mainText = findViewById(R.id.main_text);
        subText = findViewById(R.id.sub_text);
        icon = findViewById(R.id.warning_icon);
        closeButton = findViewById(R.id.close_button);

        // getar singkat biar makin kaget (opsional, tanpa permission khusus)
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(500);
                }
            }
        } catch (Exception ignored) {}

        startFlicker();

        // setelah FLICKER_DURATION_MS, reveal "JK"
        handler.postDelayed(this::revealPrank, FLICKER_DURATION_MS);
    }

    private void startFlicker() {
        Runnable flickerRunnable = new Runnable() {
            @Override
            public void run() {
                if (flickerState[0]) {
                    root.setBackgroundColor(Color.parseColor("#B71C1C")); // merah gelap
                } else {
                    root.setBackgroundColor(Color.parseColor("#FF1744")); // merah terang
                }
                flickerState[0] = !flickerState[0];
                handler.postDelayed(this, FLICKER_INTERVAL_MS);
            }
        };
        handler.post(flickerRunnable);

        // simpan reference biar bisa di-stop nanti
        flickerRunnableRef = flickerRunnable;
    }

    private Runnable flickerRunnableRef;

    private void revealPrank() {
        // stop flicker
        handler.removeCallbacks(flickerRunnableRef);

        root.setBackgroundColor(Color.parseColor("#2E7D32")); // hijau santai
        icon.setText("😂");
        mainText.setText("JK! Cuma Prank!");
        subText.setText("Santai, HP kamu aman kok 😄");
        closeButton.setVisibility(View.VISIBLE);
        closeButton.setOnClickListener(v -> finish());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
