import 'dart:io';
import 'package:ffmpeg_kit_flutter_min_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_min_gpl/return_code.dart';

class AudioResult {
  final String path;
  final int size;
  final double duration;

  AudioResult({
    required this.path,
    required this.size,
    required this.duration,
  });
}

class AudioService {
  bool _isCancelled = false;

  Future<AudioResult> extractAudio(
    String videoPath,
    String outputPath, {
    String format = 'mp3',
  }) async {
    _isCancelled = false;

    final command = '-i "$videoPath" -vn -acodec libmp3lame -ab 192k -ar 44100 -y "$outputPath"';

    final session = await FFmpegKit.execute(command);
    final returnCode = await session.getReturnCode();

    if (_isCancelled) throw Exception('Audio extraction cancelled');
    if (!ReturnCode.isSuccess(returnCode)) {
      throw Exception('Audio extraction failed');
    }

    final file = File(outputPath);
    final size = await file.length();

    // Get duration using ffprobe
    final probeSession = await FFmpegKit.execute('-i "$outputPath" 2>&1 | grep Duration');
    final output = await probeSession.getAllLogsAsString();
    final duration = _parseDuration(output);

    return AudioResult(path: outputPath, size: size, duration: duration);
  }

  Future<AudioResult> mixAudio(
    String videoPath,
    String audioPath,
    String outputPath, {
    double videoVolume = 1.0,
    double bgVolume = 0.5,
  }) async {
    _isCancelled = false;

    final command =
        '-i "$videoPath" -i "$audioPath" '
        '-filter_complex "[0:a]volume=$videoVolume[a0];[1:a]volume=$bgVolume[a1];[a0][a1]amix=inputs=2:duration=first[out]" '
        '-map 0:v -map "[out]" -c:v copy -c:a aac -b:a 192k -shortest -y "$outputPath"';

    final session = await FFmpegKit.execute(command);
    final returnCode = await session.getReturnCode();

    if (_isCancelled) throw Exception('Audio mixing cancelled');
    if (!ReturnCode.isSuccess(returnCode)) {
      throw Exception('Audio mixing failed');
    }

    final file = File(outputPath);
    final size = await file.length();

    return AudioResult(path: outputPath, size: size, duration: 0);
  }

  Future<AudioResult> removeAudio(
    String videoPath,
    String outputPath,
  ) async {
    _isCancelled = false;

    final command = '-i "$videoPath" -c:v copy -an -y "$outputPath"';

    final session = await FFmpegKit.execute(command);
    final returnCode = await session.getReturnCode();

    if (_isCancelled) throw Exception('Audio removal cancelled');
    if (!ReturnCode.isSuccess(returnCode)) {
      throw Exception('Audio removal failed');
    }

    final file = File(outputPath);
    final size = await file.length();

    return AudioResult(path: outputPath, size: size, duration: 0);
  }

  void cancel() {
    _isCancelled = true;
    FFmpegKit.cancel();
  }

  double _parseDuration(String output) {
    final regex = RegExp(r'Duration: (\d+):(\d+):(\d+)\.(\d+)');
    final match = regex.firstMatch(output);
    if (match != null) {
      final hours = int.parse(match.group(1)!);
      final minutes = int.parse(match.group(2)!);
      final seconds = int.parse(match.group(3)!);
      return (hours * 3600 + minutes * 60 + seconds).toDouble();
    }
    return 0;
  }
}
