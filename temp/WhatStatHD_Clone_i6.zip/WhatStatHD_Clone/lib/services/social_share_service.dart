import 'dart:io';
import 'package:social_share/social_share.dart';
import 'package:share_plus/share_plus.dart';

class SocialShareService {
  Future<bool> shareToWhatsAppStatus(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      final ext = filePath.split('.').last.toLowerCase();
      final isVideo = ['mp4', 'mov', 'avi', 'mkv'].contains(ext);

      if (isVideo) {
        await SocialShare.shareWhatsAppStatus(
          filePath: filePath,
          whatsAppType: SocialShareType.video,
        );
      } else {
        await SocialShare.shareWhatsAppStatus(
          filePath: filePath,
          whatsAppType: SocialShareType.image,
        );
      }
      return true;
    } catch (e) {
      // Fallback to general share
      return shareToOtherApps(filePath);
    }
  }

  Future<bool> shareToInstagramStory(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      final ext = filePath.split('.').last.toLowerCase();
      final isVideo = ['mp4', 'mov', 'avi', 'mkv'].contains(ext);

      if (isVideo) {
        await SocialShare.shareInstagramStory(
          filePath: filePath,
          backgroundTopColor: '#000000',
          backgroundBottomColor: '#075E54',
        );
      } else {
        await SocialShare.shareInstagramStory(
          filePath: filePath,
          backgroundTopColor: '#000000',
          backgroundBottomColor: '#075E54',
        );
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToFacebookStory(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await SocialShare.shareFacebookStory(
        filePath: filePath,
        backgroundTopColor: '#000000',
        backgroundBottomColor: '#1877F2',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToSnapchat(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await SocialShare.shareSnapchat(
        filePath: filePath,
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareToOtherApps(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'Shared from WhatStatHD',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> shareMultipleToWhatsApp(List<String> filePaths) async {
    try {
      for (final path in filePaths) {
        await shareToWhatsAppStatus(path);
      }
      return true;
    } catch (e) {
      return false;
    }
  }
}
