import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:gallery_saver/gallery_saver.dart';
import '../config/env_config.dart';

class FileService {
  late Directory _appDir;
  late Directory _videoDir;
  late Directory _imageDir;
  late Directory _audioDir;
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    final base = await getApplicationDocumentsDirectory();
    _appDir = Directory(p.join(base.path, EnvConfig.appName));
    _videoDir = Directory(p.join(_appDir.path, 'Videos'));
    _imageDir = Directory(p.join(_appDir.path, 'Images'));
    _audioDir = Directory(p.join(_appDir.path, 'Audio'));

    await _appDir.create(recursive: true);
    await _videoDir.create(recursive: true);
    await _imageDir.create(recursive: true);
    await _audioDir.create(recursive: true);
    _initialized = true;
  }

  Directory get appDirectory => _appDir;
  Directory get compressedVideoDir => _videoDir;
  Directory get compressedImageDir => _imageDir;
  Directory get audioDir => _audioDir;

  String generateOutputPath(String extension, {Directory? dir}) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final target = dir ?? _videoDir;
    return p.join(target.path, '${EnvConfig.appName}_$timestamp.$extension');
  }

  Future<bool> deleteFile(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<int> getFileSize(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        return await file.length();
      }
      return 0;
    } catch (e) {
      return 0;
    }
  }

  String formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  Future<bool> saveToGallery(String path) async {
    try {
      final ext = p.extension(path).toLowerCase();
      if (['.mp4', '.mov', '.avi', '.mkv'].contains(ext)) {
        return await GallerySaver.saveVideo(path) ?? false;
      } else if (['.jpg', '.jpeg', '.png', '.webp'].contains(ext)) {
        return await GallerySaver.saveImage(path) ?? false;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<int> getFreeSpace() async {
    try {
      final stat = await _appDir.stat();
      return stat.size;
    } catch (e) {
      return 0;
    }
  }

  Future<void> clearAll() async {
    await deleteDirectory(_videoDir);
    await deleteDirectory(_imageDir);
    await deleteDirectory(_audioDir);
    await _videoDir.create(recursive: true);
    await _imageDir.create(recursive: true);
    await _audioDir.create(recursive: true);
  }

  Future<void> deleteDirectory(Directory dir) async {
    try {
      if (await dir.exists()) {
        await dir.delete(recursive: true);
      }
    } catch (e) {
      // Silently handle
    }
  }
}
