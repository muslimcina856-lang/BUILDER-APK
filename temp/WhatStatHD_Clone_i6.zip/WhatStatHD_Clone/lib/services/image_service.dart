import 'dart:io';
import 'dart:math';
import 'package:es_compression/es_compression.dart';
import 'package:path/path.dart' as p;

class ImageCompressionResult {
  final String path;
  final int originalSize;
  final int compressedSize;
  final double compressionRatio;
  final int width;
  final int height;

  ImageCompressionResult({
    required this.path,
    required this.originalSize,
    required this.compressedSize,
    required this.compressionRatio,
    required this.width,
    required this.height,
  });
}

class ImageService {
  bool _isCancelled = false;

  Future<ImageCompressionResult> compressImage(
    String inputPath,
    String outputPath, {
    int quality = 80,
    int maxWidth = 1920,
    int maxHeight = 1080,
  }) async {
    _isCancelled = false;

    final inputFile = File(inputPath);
    if (!await inputFile.exists()) {
      throw Exception('Input file not found: $inputPath');
    }

    final originalSize = await inputFile.length();

    // Use es_compression for actual compression
    final compressor = Compression();
    final result = await compressor.compressImage(
      inputPath,
      outputPath,
      quality: quality,
      maxWidth: maxWidth,
      maxHeight: maxHeight,
    );

    if (_isCancelled) {
      throw Exception('Compression cancelled');
    }

    final compressedFile = File(outputPath);
    final compressedSize = await compressedFile.length();
    final compressionRatio = originalSize > 0
        ? ((originalSize - compressedSize) / originalSize * 100)
        : 0.0;

    return ImageCompressionResult(
      path: outputPath,
      originalSize: originalSize,
      compressedSize: compressedSize,
      compressionRatio: compressionRatio,
      width: result.width ?? maxWidth,
      height: result.height ?? maxHeight,
    );
  }

  Future<List<ImageCompressionResult>> compressBatch(
    List<String> inputPaths,
    String outputDir, {
    int quality = 80,
    int maxWidth = 1920,
    int maxHeight = 1080,
    Function(double progress)? onProgress,
  }) async {
    _isCancelled = false;
    final results = <ImageCompressionResult>[];

    await Directory(outputDir).create(recursive: true);

    for (int i = 0; i < inputPaths.length; i++) {
      if (_isCancelled) break;

      final inputPath = inputPaths[i];
      final ext = p.extension(inputPath);
      final basename = p.basenameWithoutExtension(inputPath);
      final outputPath = p.join(outputDir, '${basename}_compressed$ext');

      try {
        final result = await compressImage(
          inputPath,
          outputPath,
          quality: quality,
          maxWidth: maxWidth,
          maxHeight: maxHeight,
        );
        results.add(result);
      } catch (e) {
        // Add original as fallback
        final size = await File(inputPath).length();
        results.add(ImageCompressionResult(
          path: inputPath,
          originalSize: size,
          compressedSize: size,
          compressionRatio: 0,
          width: 0,
          height: 0,
        ));
      }

      onProgress?.call((i + 1) / inputPaths.length);
    }

    return results;
  }

  void cancel() {
    _isCancelled = true;
  }
}
