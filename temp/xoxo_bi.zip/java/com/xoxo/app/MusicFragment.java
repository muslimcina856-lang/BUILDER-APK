package com.xoxo.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MusicFragment extends Fragment {

    private RecyclerView recyclerView;
    private MusicAdapter adapter;
    private List<MusicTrack> tracks;
    private TextView tvCurrentTrack;
    private ImageButton btnPlayPause, btnPrev, btnNext;
    private SeekBar seekBar;
    private MusicService musicService;
    private boolean bound = false;
    private int currentTrackIndex = -1;

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            musicService = binder.getService();
            bound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) { bound = false; }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_music, container, false);

        recyclerView = view.findViewById(R.id.recyclerMusic);
        tvCurrentTrack = view.findViewById(R.id.tvCurrentTrack);
        btnPlayPause = view.findViewById(R.id.btnPlayPause);
        btnPrev = view.findViewById(R.id.btnPrev);
        btnNext = view.findViewById(R.id.btnNext);
        seekBar = view.findViewById(R.id.seekBar);

        tracks = new ArrayList<>();
        loadTracks();

        adapter = new MusicAdapter(tracks, this::onTrackSelected);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnPrev.setOnClickListener(v -> playPrevious());
        btnNext.setOnClickListener(v -> playNext());

        return view;
    }

    private void loadTracks() {
        // Default tracks - can be expanded via Owner panel or Firebase
        tracks.add(new MusicTrack("1", "Neon Dreams", "Cyber Synth", "https://example.com/music1.mp3"));
        tracks.add(new MusicTrack("2", "Digital Rain", "Night City", "https://example.com/music2.mp3"));
        tracks.add(new MusicTrack("3", "Void Walker", "Dark Matter", "https://example.com/music3.mp3"));
        tracks.add(new MusicTrack("4", "Starlight", "Cosmic Drift", "https://example.com/music4.mp3"));
    }

    private void onTrackSelected(int position) {
        currentTrackIndex = position;
        MusicTrack track = tracks.get(position);
        tvCurrentTrack.setText(track.title + " - " + track.artist);

        if (bound && musicService != null) {
            musicService.playTrack(track.url);
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
        }
    }

    private void togglePlayPause() {
        if (!bound || musicService == null) return;
        if (musicService.isPlaying()) {
            musicService.pause();
            btnPlayPause.setImageResource(android.R.drawable.ic_media_play);
        } else {
            musicService.play();
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
        }
    }

    private void playPrevious() {
        if (currentTrackIndex > 0) {
            onTrackSelected(currentTrackIndex - 1);
        }
    }

    private void playNext() {
        if (currentTrackIndex < tracks.size() - 1) {
            onTrackSelected(currentTrackIndex + 1);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Intent intent = new Intent(getContext(), MusicService.class);
        requireContext().bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (bound) {
            requireContext().unbindService(connection);
            bound = false;
        }
    }

    public static class MusicTrack {
        public String id, title, artist, url;
        public MusicTrack(String id, String title, String artist, String url) {
            this.id = id; this.title = title; this.artist = artist; this.url = url;
        }
    }
}
