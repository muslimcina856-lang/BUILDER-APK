package com.xoxo.app;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class GameSnakeActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_webview);

        webView = findViewById(R.id.webViewGame);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());

        String snakeHtml = getSnakeLadderHtml();
        webView.loadDataWithBaseURL(null, snakeHtml, "text/html", "UTF-8", null);
    }

    private String getSnakeLadderHtml() {
        return "<!DOCTYPE html>" +
            "<html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
            "<style>" +
            "body{margin:0;background:#1a1a2e;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;height:100vh;}" +
            "#board{width:90vmin;height:90vmin;display:grid;grid-template-columns:repeat(10,1fr);grid-template-rows:repeat(10,1fr);border:3px solid #e94560;position:relative;}" +
            ".cell{display:flex;justify-content:center;align-items:center;font-size:3vmin;font-weight:bold;border:1px solid #333;}" +
            ".even{background:#16213e;}.odd{background:#0f3460;}" +
            ".snake{background:#e94560!important;}.ladder{background:#16c79a!important;}" +
            ".player1{background:#ffd700!important;border-radius:50%;width:60%;height:60%;margin:auto;}" +
            ".player2{background:#2196f3!important;border-radius:50%;width:60%;height:60%;margin:auto;}" +
            "#info{padding:10px;font-size:16px;text-align:center;}" +
            "#dice{margin:5px;padding:15px 30px;background:#e94560;border:none;color:#fff;border-radius:10px;font-size:20px;font-weight:bold;}" +
            "#diceArea{display:flex;align-items:center;gap:15px;margin:5px;}" +
            "#diceResult{font-size:40px;}" +
            "</style></head><body>" +
            "<div id='info'>XOXO Snake & Ladder - Roll to move!</div>" +
            "<div id='diceArea'><button id='dice' onclick='rollDice()'>ROLL 🎲</button><span id='diceResult'>-</span></div>" +
            "<div id='board'></div>" +
            "<script>" +
            "const snakes={16:6,47:26,49:11,56:53,62:19,64:60,87:24,93:73,95:75,98:78};" +
            "const ladders={1:38,4:14,9:31,21:42,28:84,36:44,51:67,71:91,80:100};" +
            "let p1=0,p2=0,turn=1;" +
            "function initBoard(){" +
            "const b=document.getElementById('board');b.innerHTML='';" +
            "for(let i=100;i>=1;i--){" +
            "const d=document.createElement('div');d.className='cell';d.id='c'+i;" +
            "let row=Math.floor((100-i)/10);let col=(100-i)%10;" +
            "if(row%2==1)col=9-col;" +
            "d.classList.add((row+col)%2?'even':'odd');" +
            "if(snakes[i]){d.classList.add('snake');d.textContent=i+' 🐍';}" +
            "else if(ladders[i]){d.classList.add('ladder');d.textContent=i+' 🪜';}" +
            "else d.textContent=i;" +
            "b.appendChild(d);}render();}" +
            "function render(){" +
            "document.querySelectorAll('.player1,.player2').forEach(e=>e.remove());" +
            "if(p1>0){const c=document.getElementById('c'+p1);const m=document.createElement('div');m.className='player1';c.appendChild(m);}" +
            "if(p2>0){const c=document.getElementById('c'+p2);const m=document.createElement('div');m.className='player2';c.appendChild(m);}" +
            "document.getElementById('info').textContent='Player '+(turn==1?'1 🟡':'2 🔵')+' turn';}" +
            "function rollDice(){" +
            "const dice=Math.floor(Math.random()*6)+1;" +
            "document.getElementById('diceResult').textContent=dice;" +
            "if(turn==1){p1+=dice;if(p1>100)p1=100-(p1-100);if(snakes[p1])p1=snakes[p1];if(ladders[p1])p1=ladders[p1];turn=2;}" +
            "else{p2+=dice;if(p2>100)p2=100-(p2-100);if(snakes[p2])p2=snakes[p2];if(ladders[p2])p2=ladders[p2];turn=1;}" +
            "render();" +
            "if(p1==100){alert('Player 1 WINS! 🎉');p1=0;p2=0;turn=1;}" +
            "if(p2==100){alert('Player 2 WINS! 🎉');p1=0;p2=0;turn=1;}}" +
            "initBoard();" +
            "</script></body></html>";
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
