package com.xoxo.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class GameFragment extends Fragment {

    private RecyclerView recyclerView;
    private GameAdapter adapter;
    private List<GameItem> games;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_game, container, false);

        recyclerView = view.findViewById(R.id.recyclerGames);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        games = new ArrayList<>();
        games.add(new GameItem("Chess", "Classic strategy game", R.drawable.ic_chess, GameChessActivity.class));
        games.add(new GameItem("Snake & Ladder", "Roll the dice and climb!", R.drawable.ic_snake, GameSnakeActivity.class));

        adapter = new GameAdapter(games);
        recyclerView.setAdapter(adapter);

        return view;
    }

    public static class GameItem {
        public String title, desc;
        public int iconRes;
        public Class<?> activityClass;

        public GameItem(String title, String desc, int iconRes, Class<?> activityClass) {
            this.title = title; this.desc = desc;
            this.iconRes = iconRes; this.activityClass = activityClass;
        }
    }

    class GameAdapter extends RecyclerView.Adapter<GameAdapter.ViewHolder> {
        List<GameItem> items;

        GameAdapter(List<GameItem> items) { this.items = items; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_game, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
            GameItem g = items.get(pos);
            h.tvTitle.setText(g.title);
            h.tvDesc.setText(g.desc);
            h.ivIcon.setImageResource(g.iconRes);
            h.card.setOnClickListener(v -> {
                startActivity(new Intent(getContext(), g.activityClass));
            });
        }

        @Override public int getItemCount() { return items.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDesc;
            ImageView ivIcon;
            CardView card;
            ViewHolder(View v) {
                super(v);
                tvTitle = v.findViewById(R.id.tvGameTitle);
                tvDesc = v.findViewById(R.id.tvGameDesc);
                ivIcon = v.findViewById(R.id.ivGameIcon);
                card = v.findViewById(R.id.cardGame);
            }
        }
    }
}
