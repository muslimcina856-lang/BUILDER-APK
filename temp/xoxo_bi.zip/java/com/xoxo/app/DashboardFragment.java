package com.xoxo.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class DashboardFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        TextView tvInfo = view.findViewById(R.id.tvAppInfo);
        TextView tvWebsite = view.findViewById(R.id.tvWebsite);

        String info = UserSession.getInstance(requireContext()).getString(Constants.KEY_APP_INFO, 
            "XOXO App v1.0\nDigital Companion for the Bold\nBuilt with Chaos & Love");
        String website = UserSession.getInstance(requireContext()).getString(Constants.KEY_APP_WEBSITE, 
            "https://xoxo-app.web.app");

        tvInfo.setText(info);
        tvWebsite.setText("Website: " + website);

        return view;
    }
}
