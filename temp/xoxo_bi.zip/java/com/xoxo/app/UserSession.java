package com.xoxo.app;

import android.content.Context;
import android.content.SharedPreferences;

public class UserSession {
    private static UserSession instance;
    private SharedPreferences prefs;

    private UserSession(Context context) {
        prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized UserSession getInstance(Context context) {
        if (instance == null) {
            instance = new UserSession(context.getApplicationContext());
        }
        return instance;
    }

    public void setUser(String userId, String username, String role) {
        prefs.edit()
            .putString(Constants.KEY_USER_ID, userId)
            .putString(Constants.KEY_USERNAME, username)
            .putString(Constants.KEY_ROLE, role)
            .apply();
    }

    public String getUserId() { return prefs.getString(Constants.KEY_USER_ID, ""); }
    public String getUsername() { return prefs.getString(Constants.KEY_USERNAME, ""); }
    public String getRole() { return prefs.getString(Constants.KEY_ROLE, Constants.ROLE_BASIC); }

    public boolean isLoggedIn() { return !getUserId().isEmpty(); }
    public boolean isOwner() { return ROLE_OWNER.equals(getRole()); }
    public boolean isPremium() { return ROLE_PREMIUM.equals(getRole()) || isOwner(); }

    public void clear() {
        prefs.edit().clear().apply();
    }

    public void setString(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    public String getString(String key, String defaultValue) {
        return prefs.getString(key, defaultValue);
    }
}
