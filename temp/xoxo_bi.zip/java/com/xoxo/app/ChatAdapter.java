package com.xoxo.app;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {

    private List<ChatFragment.ChatMessage> messages;
    private String currentRole;

    public ChatAdapter(List<ChatFragment.ChatMessage> messages, String currentRole) {
        this.messages = messages;
        this.currentRole = currentRole;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatFragment.ChatMessage msg = messages.get(position);

        holder.tvUsername.setText(msg.username);
        holder.tvMessage.setText(msg.message);

        // Role-based styling
        if (Constants.ROLE_OWNER.equals(msg.role)) {
            holder.tvUsername.setTextColor(Color.parseColor("#2196F3"));
            holder.tvUsername.setText(msg.username + " 👑");
        } else if (Constants.ROLE_PREMIUM.equals(msg.role)) {
            holder.tvUsername.setTextColor(Color.parseColor("#FFD700"));
        } else {
            holder.tvUsername.setTextColor(Color.parseColor("#757575"));
        }

        // Premium border customization
        if (Constants.ROLE_PREMIUM.equals(msg.role) || Constants.ROLE_OWNER.equals(msg.role)) {
            holder.itemView.setBackgroundResource(R.drawable.bg_chat_premium);
        } else {
            holder.itemView.setBackgroundResource(R.drawable.bg_chat_basic);
        }
    }

    @Override
    public int getItemCount() { return messages.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername, tvMessage;
        ViewHolder(View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            tvMessage = itemView.findViewById(R.id.tvMessage);
        }
    }
}
