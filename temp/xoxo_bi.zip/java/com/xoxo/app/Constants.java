package com.xoxo.app;

public class Constants {
    public static final String PREFS_NAME = "XOXO_PREFS";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_ROLE = "role";
    public static final String KEY_TOKEN = "token";
    public static final String KEY_GROQ_API = "groq_api_key";
    public static final String KEY_CUSTOM_PROMPT = "custom_prompt";
    public static final String KEY_NETLIFY_TOKEN = "netlify_token";
    public static final String KEY_APP_INFO = "app_info";
    public static final String KEY_APP_WEBSITE = "app_website";

    public static final String ROLE_BASIC = "basic";
    public static final String ROLE_PREMIUM = "premium";
    public static final String ROLE_OWNER = "owner";

    public static final String GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
    public static final String GROQ_MODEL = "llama-3.3-70b-versatile";

    public static final String NETLIFY_API_URL = "https://api.netlify.com/api/v1";

    public static final String FIREBASE_DB_URL = "https://xoxo-app-default-rtdb.firebaseio.com/";

    public static final int COLOR_BASIC = 0xFF757575;
    public static final int COLOR_PREMIUM = 0xFFFFD700;
    public static final int COLOR_OWNER = 0xFF2196F3;
}
