package com.xoxo.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.firebase.database.*;

public class OwnerFragment extends Fragment {

    private EditText etGroqApi, etCustomPrompt, etNetlifyToken, etAppInfo, etAppWebsite;
    private EditText etNewUser, etNewPass;
    private Spinner spinnerRole;
    private Button btnSaveSettings, btnAddUser, btnDeleteUser;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_owner, container, false);

        etGroqApi = view.findViewById(R.id.etGroqApi);
        etCustomPrompt = view.findViewById(R.id.etCustomPrompt);
        etNetlifyToken = view.findViewById(R.id.etNetlifyToken);
        etAppInfo = view.findViewById(R.id.etAppInfo);
        etAppWebsite = view.findViewById(R.id.etAppWebsite);
        etNewUser = view.findViewById(R.id.etNewUser);
        etNewPass = view.findViewById(R.id.etNewPass);
        spinnerRole = view.findViewById(R.id.spinnerRole);
        btnSaveSettings = view.findViewById(R.id.btnSaveSettings);
        btnAddUser = view.findViewById(R.id.btnAddUser);
        btnDeleteUser = view.findViewById(R.id.btnDeleteUser);

        // Load existing settings
        UserSession session = UserSession.getInstance(requireContext());
        etGroqApi.setText(session.getString(Constants.KEY_GROQ_API, ""));
        etCustomPrompt.setText(session.getString(Constants.KEY_CUSTOM_PROMPT, ""));
        etNetlifyToken.setText(session.getString(Constants.KEY_NETLIFY_TOKEN, ""));
        etAppInfo.setText(session.getString(Constants.KEY_APP_INFO, ""));
        etAppWebsite.setText(session.getString(Constants.KEY_APP_WEBSITE, ""));

        btnSaveSettings.setOnClickListener(v -> saveSettings());
        btnAddUser.setOnClickListener(v -> addUser());
        btnDeleteUser.setOnClickListener(v -> deleteUser());

        return view;
    }

    private void saveSettings() {
        UserSession session = UserSession.getInstance(requireContext());
        session.setString(Constants.KEY_GROQ_API, etGroqApi.getText().toString().trim());
        session.setString(Constants.KEY_CUSTOM_PROMPT, etCustomPrompt.getText().toString().trim());
        session.setString(Constants.KEY_NETLIFY_TOKEN, etNetlifyToken.getText().toString().trim());
        session.setString(Constants.KEY_APP_INFO, etAppInfo.getText().toString().trim());
        session.setString(Constants.KEY_APP_WEBSITE, etAppWebsite.getText().toString().trim());
        Toast.makeText(getContext(), "Settings saved!", Toast.LENGTH_SHORT).show();
    }

    private void addUser() {
        String username = etNewUser.getText().toString().trim();
        String password = etNewPass.getText().toString().trim();
        String role = spinnerRole.getSelectedItem().toString().toLowerCase();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(getContext(), "Isi username & password!", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("users");
        String userId = dbRef.push().getKey();
        LoginActivity.User user = new LoginActivity.User(userId, username, password, role);

        dbRef.child(username).setValue(user)
            .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "User added!", Toast.LENGTH_SHORT).show())
            .addOnFailureListener(e -> Toast.makeText(getContext(), "Gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void deleteUser() {
        String username = etNewUser.getText().toString().trim();
        if (username.isEmpty()) {
            Toast.makeText(getContext(), "Masukkan username yang mau dihapus!", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseDatabase.getInstance().getReference("users").child(username).removeValue()
            .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "User deleted!", Toast.LENGTH_SHORT).show())
            .addOnFailureListener(e -> Toast.makeText(getContext(), "Gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
