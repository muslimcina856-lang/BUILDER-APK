package com.xoxo.app;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class GameChessActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_webview);

        webView = findViewById(R.id.webViewGame);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());

        // Load embedded chess game HTML
        String chessHtml = getChessHtml();
        webView.loadDataWithBaseURL(null, chessHtml, "text/html", "UTF-8", null);
    }

    private String getChessHtml() {
        return "<!DOCTYPE html>" +
            "<html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
            "<style>" +
            "body{margin:0;background:#1a1a2e;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;height:100vh;}" +
            "#board{width:90vmin;height:90vmin;display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(8,1fr);border:3px solid #e94560;}" +
            ".cell{display:flex;justify-content:center;align-items:center;font-size:8vmin;cursor:pointer;user-select:none;}" +
            ".white{background:#f0d9b5;color:#000;}.black{background:#b58863;color:#fff;}" +
            ".selected{background:#e94560!important;}" +
            "#info{padding:10px;font-size:18px;text-align:center;}" +
            "#reset{margin:10px;padding:10px 20px;background:#e94560;border:none;color:#fff;border-radius:5px;font-size:16px;}" +
            "</style></head><body>" +
            "<div id='info'>XOXO Chess - Click to move</div>" +
            "<div id='board'></div>" +
            "<button id='reset' onclick='initBoard()'>New Game</button>" +
            "<script>" +
            "const pieces={'r':'♜','n':'♞','b':'♝','q':'♛','k':'♚','p':'♟','R':'♖','N':'♘','B':'♗','Q':'♕','K':'♔','P':'♙'};" +
            "let board=[],selected=null,turn='w';" +
            "function initBoard(){" +
            "const setup=['rnbqkbnr','pppppppp','........','........','........','........','PPPPPPPP','RNBQKBNR'];" +
            "board=setup.map(r=>r.split(''));selected=null;turn='w';render();}" +
            "function render(){" +
            "const b=document.getElementById('board');b.innerHTML='';" +
            "for(let r=0;r<8;r++){for(let c=0;c<8;c++){" +
            "const d=document.createElement('div');d.className='cell '+( (r+c)%2?'black':'white');" +
            "d.dataset.r=r;d.dataset.c=c;" +
            "if(selected&&selected.r==r&&selected.c==c)d.classList.add('selected');" +
            "const p=board[r][c];if(p!='.')d.textContent=pieces[p]||p;" +
            "d.onclick=()=>clickCell(r,c);b.appendChild(d);}}" +
            "document.getElementById('info').textContent='Turn: '+(turn=='w'?'White ♔':'Black ♚');}" +
            "function clickCell(r,c){" +
            "if(!selected){if(board[r][c]!='.'&&((turn=='w'&&board[r][c]<'a')||(turn=='b'&&board[r][c]>='a'))){selected={r,c};render();}}" +
            "else{board[r][c]=board[selected.r][selected.c];board[selected.r][selected.c]='.';selected=null;turn=turn=='w'?'b':'w';render();}}" +
            "initBoard();" +
            "</script></body></html>";
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
