package com.xoxo.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import okhttp3.*;

public class DeployFragment extends Fragment {

    private static final int PICK_FILE = 1;
    private static final int PICK_FOLDER = 2;

    private EditText etSiteName, etHtmlContent;
    private RadioGroup rgDeployType;
    private RadioButton rbHtml, rbFile, rbFolder;
    private Button btnSelectFile, btnSelectFolder, btnDeploy;
    private TextView tvStatus;
    private Uri selectedUri;
    private String deployType = "html";
    private OkHttpClient client;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_deploy, container, false);

        etSiteName = view.findViewById(R.id.etSiteName);
        etHtmlContent = view.findViewById(R.id.etHtmlContent);
        rgDeployType = view.findViewById(R.id.rgDeployType);
        rbHtml = view.findViewById(R.id.rbHtml);
        rbFile = view.findViewById(R.id.rbFile);
        rbFolder = view.findViewById(R.id.rbFolder);
        btnSelectFile = view.findViewById(R.id.btnSelectFile);
        btnSelectFolder = view.findViewById(R.id.btnSelectFolder);
        btnDeploy = view.findViewById(R.id.btnDeploy);
        tvStatus = view.findViewById(R.id.tvStatus);

        client = new OkHttpClient.Builder()
            .connectTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .build();

        rgDeployType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbHtml) {
                deployType = "html";
                etHtmlContent.setVisibility(View.VISIBLE);
                btnSelectFile.setVisibility(View.GONE);
                btnSelectFolder.setVisibility(View.GONE);
            } else if (checkedId == R.id.rbFile) {
                deployType = "file";
                etHtmlContent.setVisibility(View.GONE);
                btnSelectFile.setVisibility(View.VISIBLE);
                btnSelectFolder.setVisibility(View.GONE);
            } else if (checkedId == R.id.rbFolder) {
                deployType = "folder";
                etHtmlContent.setVisibility(View.GONE);
                btnSelectFile.setVisibility(View.GONE);
                btnSelectFolder.setVisibility(View.VISIBLE);
            }
        });

        btnSelectFile.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            startActivityForResult(intent, PICK_FILE);
        });

        btnSelectFolder.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, PICK_FOLDER);
        });

        btnDeploy.setOnClickListener(v -> deployToNetlify());

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            selectedUri = data.getData();
            tvStatus.setText("Selected: " + selectedUri.getLastPathSegment());
        }
    }

    private void deployToNetlify() {
        String token = UserSession.getInstance(requireContext()).getString(Constants.KEY_NETLIFY_TOKEN, "");
        if (token.isEmpty()) {
            Toast.makeText(getContext(), "Set Netlify Token di Owner Panel!", Toast.LENGTH_LONG).show();
            return;
        }

        String siteName = etSiteName.getText().toString().trim();
        if (siteName.isEmpty()) {
            Toast.makeText(getContext(), "Isi nama site!", Toast.LENGTH_SHORT).show();
            return;
        }

        tvStatus.setText("Deploying...");

        try {
            byte[] deployData;
            if (deployType.equals("html")) {
                String html = etHtmlContent.getText().toString();
                if (html.isEmpty()) {
                    Toast.makeText(getContext(), "Isi HTML content!", Toast.LENGTH_SHORT).show();
                    return;
                }
                deployData = createZipFromHtml(html, siteName);
            } else {
                deployData = createZipFromUri(selectedUri);
            }

            // Create site first
            createSite(token, siteName, deployData);

        } catch (Exception e) {
            tvStatus.setText("Error: " + e.getMessage());
        }
    }

    private byte[] createZipFromHtml(String html, String siteName) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);

        ZipEntry entry = new ZipEntry("index.html");
        zos.putNextEntry(entry);
        zos.write(html.getBytes());
        zos.closeEntry();
        zos.close();

        return baos.toByteArray();
    }

    private byte[] createZipFromUri(Uri uri) throws IOException {
        // Simplified - in production, recursively read directory
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);

        if (uri != null) {
            InputStream is = requireContext().getContentResolver().openInputStream(uri);
            if (is != null) {
                String name = uri.getLastPathSegment();
                ZipEntry entry = new ZipEntry(name != null ? name : "file");
                zos.putNextEntry(entry);
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) > 0) {
                    zos.write(buffer, 0, len);
                }
                zos.closeEntry();
                is.close();
            }
        }
        zos.close();
        return baos.toByteArray();
    }

    private void createSite(String token, String siteName, byte[] zipData) {
        try {
            JSONObject siteJson = new JSONObject();
            siteJson.put("name", siteName);

            RequestBody siteBody = RequestBody.create(siteJson.toString(), MediaType.parse("application/json"));
            Request siteRequest = new Request.Builder()
                .url(Constants.NETLIFY_API_URL + "/sites")
                .header("Authorization", "Bearer " + token)
                .post(siteBody)
                .build();

            client.newCall(siteRequest).enqueue(new Callback() {
                @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    updateStatus("Site creation failed: " + e.getMessage());
                }

                @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    String body = response.body() != null ? response.body().string() : "";
                    try {
                        JSONObject site = new JSONObject(body);
                        String siteId = site.getString("site_id");
                        deployZip(token, siteId, zipData);
                    } catch (Exception e) {
                        updateStatus("Parse error: " + e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            updateStatus("Error: " + e.getMessage());
        }
    }

    private void deployZip(String token, String siteId, byte[] zipData) {
        RequestBody body = RequestBody.create(zipData, MediaType.parse("application/zip"));
        Request request = new Request.Builder()
            .url(Constants.NETLIFY_API_URL + "/sites/" + siteId + "/deploys")
            .header("Authorization", "Bearer " + token)
            .header("Content-Type", "application/zip")
            .post(body)
            .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {
                updateStatus("Deploy failed: " + e.getMessage());
            }

            @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String body = response.body() != null ? response.body().string() : "";
                try {
                    JSONObject deploy = new JSONObject(body);
                    String url = deploy.optString("url", deploy.optString("deploy_url", "Unknown"));
                    updateStatus("Deployed! URL: " + url);
                } catch (Exception e) {
                    updateStatus("Deploy response: " + body);
                }
            }
        });
    }

    private void updateStatus(String text) {
        new Handler(Looper.getMainLooper()).post(() -> tvStatus.setText(text));
    }
}
