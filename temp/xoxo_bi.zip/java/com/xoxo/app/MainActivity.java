package com.xoxo.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!UserSession.getInstance(this).isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        // Default fragment
        getSupportFragmentManager().beginTransaction()
            .replace(R.id.fragment_container, new DashboardFragment()).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
        new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selected = null;
                int id = item.getItemId();

                if (id == R.id.nav_dashboard) {
                    selected = new DashboardFragment();
                } else if (id == R.id.nav_chat) {
                    selected = new ChatFragment();
                } else if (id == R.id.nav_ai) {
                    selected = new AIChatFragment();
                } else if (id == R.id.nav_music) {
                    selected = new MusicFragment();
                } else if (id == R.id.nav_profile) {
                    selected = new ProfileFragment();
                } else if (id == R.id.nav_game) {
                    selected = new GameFragment();
                } else if (id == R.id.nav_deploy) {
                    if (UserSession.getInstance(MainActivity.this).isPremium()) {
                        selected = new DeployFragment();
                    } else {
                        Toast.makeText(MainActivity.this, "Premium/Owner only!", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                } else if (id == R.id.nav_owner) {
                    if (UserSession.getInstance(MainActivity.this).isOwner()) {
                        selected = new OwnerFragment();
                    } else {
                        Toast.makeText(MainActivity.this, "Owner only!", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                }

                if (selected != null) {
                    getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selected).commit();
                }
                return true;
            }
        };
}
