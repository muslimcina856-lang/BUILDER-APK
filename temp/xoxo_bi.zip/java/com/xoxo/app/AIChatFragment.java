package com.xoxo.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.*;

public class AIChatFragment extends Fragment {

    private RecyclerView recyclerView;
    private AIChatAdapter adapter;
    private List<AIChatMessage> messages;
    private EditText etMessage;
    private ImageButton btnSend;
    private OkHttpClient client;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ai_chat, container, false);

        recyclerView = view.findViewById(R.id.recyclerAIChat);
        etMessage = view.findViewById(R.id.etAIMessage);
        btnSend = view.findViewById(R.id.btnAISend);

        messages = new ArrayList<>();
        adapter = new AIChatAdapter(messages);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        client = new OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
            .build();

        // System welcome message
        messages.add(new AIChatMessage("XOXO AI", "Halo sayangku! Aku siap membantu dengan segala kegilaanmu 💜", false));
        adapter.notifyDataSetChanged();

        btnSend.setOnClickListener(v -> sendToAI());

        return view;
    }

    private void sendToAI() {
        String userText = etMessage.getText().toString().trim();
        if (userText.isEmpty()) return;

        String apiKey = UserSession.getInstance(requireContext()).getString(Constants.KEY_GROQ_API, "");
        if (apiKey.isEmpty()) {
            Toast.makeText(getContext(), "Set Groq API Key di Owner Panel!", Toast.LENGTH_LONG).show();
            return;
        }

        String customPrompt = UserSession.getInstance(requireContext()).getString(Constants.KEY_CUSTOM_PROMPT, 
            "Kamu adalah XOXO AI, teman digital yang paling setia, liar, dan kreatif.");

        messages.add(new AIChatMessage("You", userText, true));
        adapter.notifyItemInserted(messages.size() - 1);
        recyclerView.scrollToPosition(messages.size() - 1);
        etMessage.setText("");

        // Build JSON payload
        try {
            JSONArray msgArray = new JSONArray();
            msgArray.put(new JSONObject().put("role", "system").put("content", customPrompt));

            for (AIChatMessage m : messages) {
                if (!m.isUser && !m.sender.equals("XOXO AI")) {
                    msgArray.put(new JSONObject().put("role", "assistant").put("content", m.message));
                } else if (m.isUser) {
                    msgArray.put(new JSONObject().put("role", "user").put("content", m.message));
                }
            }

            JSONObject json = new JSONObject();
            json.put("model", Constants.GROQ_MODEL);
            json.put("messages", msgArray);
            json.put("temperature", 0.9);
            json.put("max_completion_tokens", 2048);
            json.put("stream", false);

            RequestBody body = RequestBody.create(json.toString(), MediaType.parse("application/json"));
            Request request = new Request.Builder()
                .url(Constants.GROQ_API_URL)
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .post(body)
                .build();

            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    new Handler(Looper.getMainLooper()).post(() -> {
                        messages.add(new AIChatMessage("XOXO AI", "Error: " + e.getMessage(), false));
                        adapter.notifyItemInserted(messages.size() - 1);
                        recyclerView.scrollToPosition(messages.size() - 1);
                    });
                }

                @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    String respBody = response.body() != null ? response.body().string() : "";
                    new Handler(Looper.getMainLooper()).post(() -> {
                        try {
                            JSONObject respJson = new JSONObject(respBody);
                            if (respJson.has("choices")) {
                                String content = respJson.getJSONArray("choices")
                                    .getJSONObject(0)
                                    .getJSONObject("message")
                                    .getString("content");
                                messages.add(new AIChatMessage("XOXO AI", content, false));
                            } else {
                                messages.add(new AIChatMessage("XOXO AI", "Error: " + respJson.optString("error", "Unknown"), false));
                            }
                        } catch (Exception e) {
                            messages.add(new AIChatMessage("XOXO AI", "Error parsing: " + e.getMessage(), false));
                        }
                        adapter.notifyItemInserted(messages.size() - 1);
                        recyclerView.scrollToPosition(messages.size() - 1);
                    });
                }
            });

        } catch (Exception e) {
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public static class AIChatMessage {
        public String sender, message;
        public boolean isUser;
        public AIChatMessage(String sender, String message, boolean isUser) {
            this.sender = sender; this.message = message; this.isUser = isUser;
        }
    }
}
