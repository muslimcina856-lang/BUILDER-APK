package com.xoxo.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        TextView tvUsername = view.findViewById(R.id.tvProfileUsername);
        TextView tvRole = view.findViewById(R.id.tvProfileRole);
        TextView tvRoleBadge = view.findViewById(R.id.tvRoleBadge);
        Button btnLogout = view.findViewById(R.id.btnLogout);

        UserSession session = UserSession.getInstance(requireContext());
        tvUsername.setText(session.getUsername());
        tvRole.setText("Role: " + session.getRole().toUpperCase());

        String role = session.getRole();
        if (Constants.ROLE_OWNER.equals(role)) {
            tvRoleBadge.setText("👑 OWNER");
            tvRoleBadge.setTextColor(Constants.COLOR_OWNER);
        } else if (Constants.ROLE_PREMIUM.equals(role)) {
            tvRoleBadge.setText("⭐ PREMIUM");
            tvRoleBadge.setTextColor(Constants.COLOR_PREMIUM);
        } else {
            tvRoleBadge.setText("👤 BASIC");
            tvRoleBadge.setTextColor(Constants.COLOR_BASIC);
        }

        btnLogout.setOnClickListener(v -> {
            session.clear();
            startActivity(new Intent(getContext(), LoginActivity.class));
            requireActivity().finish();
        });

        return view;
    }
}
