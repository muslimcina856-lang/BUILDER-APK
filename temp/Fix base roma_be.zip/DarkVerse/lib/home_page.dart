import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  String selectedBugId = "";

  // Mode Target: 'number' untuk nomor HP, 'group' untuk Link Group
  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;

  // Sender
  String _selectedSenderType = "global";
  List<Map<String, dynamic>> _activeSenders = [];
  String? _selectedSenderId;
  bool _loadingSenders = false;

  // --- Tema Warna Hitam Elegan & Merah Tua ---
  final Color primaryBg = const Color(0xFF090909); // Elegant Black
  final Color cardBg = const Color(0xFF141414); // Darker surface for cards
  final Color primaryRed = const Color(0xFF8B0000); // Dark Red (Merah Tua)
  final Color accentRed = const Color(0xFFB22222); // Brighter Dark Red for accents
  final Color textWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;

  // Gradients
  final LinearGradient darkRedGradient = const LinearGradient(
    colors: [Color(0xFF8B0000), Color(0xFFB22222)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
    _fetchActiveSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });
  }

  Future<void> _fetchActiveSenders() async {
    setState(() => _loadingSenders = true);
    try {
      final res = await http.get(
        Uri.parse("http://cillor.pteroq.xyz:2103/mySender?key=${widget.sessionKey}"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final all = List<Map<String, dynamic>>.from(
            (data["connections"] ?? []).map((e) => Map<String, dynamic>.from(e))
          );
          setState(() {
            _activeSenders = all;
            if (_selectedSenderId == null && all.isNotEmpty) {
              _selectedSenderId = all.first["sessionName"]?.toString();
            }
          });
        }
      }
    } catch (_) {}
    setState(() => _loadingSenders = false);
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final senderId = _selectedSenderId ?? '';
      final res = await http.get(Uri.parse(
          "http://cillor.pteroq.xyz:2103/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderType=$_selectedSenderType&senderId=$senderId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: accentRed.withOpacity(0.5)),
        ),
        title: Text(title,
            style: const TextStyle(
              color: Color(0xFFB22222),
              fontFamily: 'Rajdhani',
              fontWeight: FontWeight.bold,
            )),
        content: Text(msg,
            style: TextStyle(
                color: textGrey,
                fontFamily: 'ShareTechMono'
            )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(
                  color: accentRed,
                  fontWeight: FontWeight.bold,
                )),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: primaryRed.withOpacity(0.5),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Pojok Kiri: Username & Role
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "USERNAME",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 10,
                    letterSpacing: 1.2,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: primaryRed.withOpacity(0.5)),
                  ),
                  child: Text(
                    widget.role.toUpperCase(),
                    style: TextStyle(
                      color: accentRed,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Tengah: Foto Profil
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: darkRedGradient,
              boxShadow: [
                BoxShadow(
                  color: accentRed.withOpacity(0.4),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const CircleAvatar(
              radius: 30,
              backgroundColor: Colors.black,
              backgroundImage: AssetImage('assets/images/pp.jpg'),
            ),
          ),

          // Pojok Kanan (Disesuaikan agar simetris): Expired Date
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "EXPIRED DATE",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 10,
                    letterSpacing: 1.2,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.expiredDate,
                  style: TextStyle(
                    color: accentRed,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity,
        height: 200,
        margin: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: primaryRed.withOpacity(0.3)),
        ),
        child: Center(
          child: CircularProgressIndicator(
            color: accentRed,
            strokeWidth: 3,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 1,
          ),
        ],
        border: Border.all(color: accentRed.withOpacity(0.4), width: 1.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: AspectRatio(
          aspectRatio: _videoController.value.aspectRatio,
          child: Stack(
            children: [
              Chewie(controller: _chewieController),
              // Overlay Gradien Hitam di bawah agar teks Ronova terbaca
              Positioned(
                bottom: 0, left: 0, right: 0,
                height: 60,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              // Teks Ronova di pojok kiri bawah
              Positioned(
                bottom: 12,
                left: 16,
                child: Text(
                  "ROMA",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Rajdhani',
                    letterSpacing: 2.0,
                    shadows: [
                      Shadow(
                        color: accentRed,
                        blurRadius: 10,
                      )
                    ]
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "number";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "number"
                    ? primaryRed.withOpacity(0.2)
                    : cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "number" ? accentRed : primaryRed.withOpacity(0.2),
                  width: _selectedBugMode == "number" ? 1.5 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.phone_android_rounded,
                    color: _selectedBugMode == "number" ? accentRed : textGrey,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "BUG NOMOR",
                    style: TextStyle(
                      color: _selectedBugMode == "number" ? textWhite : textGrey,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedBugMode = "group";
                targetController.clear();
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _selectedBugMode == "group"
                    ? primaryRed.withOpacity(0.2)
                    : cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedBugMode == "group" ? accentRed : primaryRed.withOpacity(0.2),
                  width: _selectedBugMode == "group" ? 1.5 : 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.link,
                    color: _selectedBugMode == "group" ? accentRed : textGrey,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "BUG GROUP",
                    style: TextStyle(
                      color: _selectedBugMode == "group" ? textWhite : textGrey,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputContainers() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // KOTAK 1: INPUT TARGET
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: primaryRed.withOpacity(0.4), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Judul Kotak Input
              Row(
                children: [
                  Icon(
                    _selectedBugMode == "number" ? Icons.phone_android : Icons.link,
                    color: accentRed,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _selectedBugMode == "number" ? "Input Number Target" : "Input Link Group",
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1.0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // TextField Input
              TextField(
                controller: targetController,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                cursorColor: accentRed,
                keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
                decoration: InputDecoration(
                  hintText: _selectedBugMode == "number"
                      ? "Contoh: +62xxxxxxxxxx"
                      : "Contoh: https://chat.whatsapp.com/...",
                  hintStyle: TextStyle(color: textGrey.withOpacity(0.4)),
                  filled: true,
                  fillColor: primaryBg, // Latar dalam field lebih gelap
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: primaryRed.withOpacity(0.3)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: accentRed, width: 1.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // KOTAK 2: SELECT PAYLOAD
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: primaryRed.withOpacity(0.4), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Judul Kotak Payload
              Row(
                children: [
                  Icon(
                    Icons.bug_report, // Icon 🐞
                    color: accentRed,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "Select - Payload",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 1.0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Dropdown Payload
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: primaryBg, // Latar dalam field lebih gelap
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: primaryRed.withOpacity(0.3)),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    dropdownColor: cardBg,
                    value: selectedBugId,
                    isExpanded: true,
                    icon: Icon(Icons.arrow_drop_down_circle_outlined, color: accentRed),
                    iconSize: 24,
                    style: const TextStyle(
                      color: Colors.white, 
                      fontSize: 15, 
                      fontFamily: 'ShareTechMono'
                    ),
                    items: widget.listBug.map((bug) {
                      return DropdownMenuItem<String>(
                        value: bug['bug_id'],
                        child: Text(bug['bug_name']),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedBugId = value ?? "";
                      });
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSenderSelector() {
    final globalSenders = _activeSenders.where((s) => s["isGlobal"] == true || s["isGlobal"] == 1).toList();
    final privateSenders = _activeSenders.where((s) => s["isGlobal"] != true && s["isGlobal"] != 1).toList();
    final currentList = _selectedSenderType == "global" ? globalSenders : privateSenders;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryRed.withOpacity(0.4), width: 1),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.wifi_tethering_rounded, color: accentRed, size: 20),
              const SizedBox(width: 10),
              const Text(
                "Select Sender",
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14, fontFamily: 'Rajdhani', letterSpacing: 1.0),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchActiveSenders,
                child: Icon(Icons.refresh_rounded, color: accentRed, size: 18),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() {
                    _selectedSenderType = "global";
                    final g = _activeSenders.where((s) => s["isGlobal"] == true || s["isGlobal"] == 1).toList();
                    _selectedSenderId = g.isNotEmpty ? g.first["sessionName"]?.toString() : null;
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _selectedSenderType == "global" ? primaryRed.withOpacity(0.2) : Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _selectedSenderType == "global" ? accentRed : primaryRed.withOpacity(0.2),
                        width: _selectedSenderType == "global" ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.public_rounded, color: _selectedSenderType == "global" ? accentRed : textGrey, size: 16),
                        const SizedBox(width: 6),
                        Text("GLOBAL", style: TextStyle(color: _selectedSenderType == "global" ? Colors.white : textGrey, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Rajdhani')),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() {
                    _selectedSenderType = "private";
                    final p = _activeSenders.where((s) => s["isGlobal"] != true && s["isGlobal"] != 1).toList();
                    _selectedSenderId = p.isNotEmpty ? p.first["sessionName"]?.toString() : null;
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _selectedSenderType == "private" ? primaryRed.withOpacity(0.2) : Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _selectedSenderType == "private" ? accentRed : primaryRed.withOpacity(0.2),
                        width: _selectedSenderType == "private" ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.lock_rounded, color: _selectedSenderType == "private" ? accentRed : textGrey, size: 16),
                        const SizedBox(width: 6),
                        Text("PRIVATE", style: TextStyle(color: _selectedSenderType == "private" ? Colors.white : textGrey, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Rajdhani')),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_loadingSenders)
            Center(child: SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: accentRed, strokeWidth: 2)))
          else if (currentList.isEmpty)
            Row(children: [
              Icon(Icons.info_outline, color: Colors.white38, size: 14),
              const SizedBox(width: 8),
              Text("Tidak ada $_selectedSenderType sender aktif", style: const TextStyle(color: Colors.white38, fontSize: 12, fontFamily: 'ShareTechMono')),
            ])
          else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: primaryBg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: primaryRed.withOpacity(0.3)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: cardBg,
                  value: _selectedSenderId,
                  isExpanded: true,
                  icon: Icon(Icons.arrow_drop_down_circle_outlined, color: accentRed),
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'ShareTechMono'),
                  items: currentList.map((s) {
                    final name = s["sessionName"]?.toString() ?? "Unknown";
                    return DropdownMenuItem<String>(value: name, child: Text(name));
                  }).toList(),
                  onChanged: (v) => setState(() => _selectedSenderId = v),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: darkRedGradient,
            boxShadow: [
              BoxShadow(
                color: primaryRed.withOpacity(0.5),
                blurRadius: _pulseController.value * 20,
                spreadRadius: _pulseController.value * 1,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 3,
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                      SizedBox(width: 12),
                      Text(
                        "SEND BUG ATTACK",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor;
    Color borderColor;
    Color textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = Colors.green.withOpacity(0.1);
      borderColor = Colors.greenAccent;
      textColor = Colors.greenAccent;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = Colors.red.withOpacity(0.1);
      borderColor = accentRed;
      textColor = accentRed;
      icon = Icons.error_outline_rounded;
    } else {
      bgColor = primaryRed.withOpacity(0.1);
      borderColor = primaryRed;
      textColor = textWhite;
      icon = Icons.info_outline_rounded;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor.withOpacity(0.5), width: 1),
        ),
        child: Row(
          children: [
            Icon(icon, color: textColor, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Header Card
              _buildHeaderPanel(),
              
              // Banner Video (Ronova Text Inside)
              _buildVideoPlayer(),
              
              // Mode Buttons
              _buildModeSelector(),
              const SizedBox(height: 20),
              
              // Input Kotak Target & Kotak Payload
              _buildInputContainers(),
              const SizedBox(height: 35),
              
              // Sender Selector
              _buildSenderSelector(),
              const SizedBox(height: 20),

              // Send Button
              _buildSendButton(),
              
              // Response Message
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}
