Letak binary Railway CLI di sini.

Nama fail: railway
Architecture: Linux arm64 (aarch64)

Cara dapatkan:
1. Download dari https://github.com/railwayapp/cli/releases
2. Pilih versi linux-arm64 (atau linux-amd64 untuk emulator x86)
3. Rename kepada "railway" (tanpa extension)
4. Letak dalam folder ini: app/src/main/assets/cli/railway

Nota:
- Binary official Android tiada.
- Embed binary Linux sering gagal kerana missing .so libraries.
- Cara paling stabil di Android = guna Termux.
