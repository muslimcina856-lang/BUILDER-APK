package com.railway.deck.cli

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream

/**
 * Railway CLI manager.
 * Pertama kali buka app → auto download binary dari GitHub Releases.
 */
class RailwayCli(private val context: Context) {

    companion object {
        private const val TAG = "RailwayCli"
        private const val BINARY_NAME = "railway"
        // Latest known stable pattern (update version bila perlu)
        private const val CLI_VERSION = "v5.41.2"
        private const val BASE_URL =
            "https://github.com/railwayapp/cli/releases/download/$CLI_VERSION"
    }

    private val cliDir: File by lazy {
        File(context.filesDir, "cli").also { it.mkdirs() }
    }

    val binaryFile: File
        get() = File(cliDir, BINARY_NAME)

    fun isInstalled(): Boolean =
        binaryFile.exists() && binaryFile.canExecute() && binaryFile.length() > 1000

    /**
     * Auto-install: download + extract binary mengikut ABI device.
     * @param onProgress callback 0.0 .. 1.0
     */
    fun ensureInstalled(onProgress: ((Float, String) -> Unit)? = null): Result<Unit> {
        if (isInstalled()) {
            onProgress?.invoke(1f, "Railway CLI sudah siap")
            return Result.success(Unit)
        }

        return try {
            onProgress?.invoke(0.05f, "Menyediakan download...")
            val assetName = selectAssetName()
            val url = "$BASE_URL/$assetName"
            Log.i(TAG, "Downloading: $url")

            val tmpTarGz = File(cliDir, "railway.tar.gz")
            downloadFile(url, tmpTarGz, onProgress)

            onProgress?.invoke(0.85f, "Extract binary...")
            extractRailwayBinary(tmpTarGz, binaryFile)
            tmpTarGz.delete()

            binaryFile.setExecutable(true, false)
            // Sesetengah device perlukan world-executable
            try {
                Runtime.getRuntime().exec(arrayOf("chmod", "755", binaryFile.absolutePath)).waitFor()
            } catch (_: Exception) {}

            if (!isInstalled()) {
                return Result.failure(Exception("Binary gagal di-extract atau tidak executable"))
            }

            onProgress?.invoke(1f, "Railway CLI siap")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "ensureInstalled failed", e)
            Result.failure(e)
        }
    }

    private fun selectAssetName(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        val target = when {
            abi.contains("arm64") || abi.contains("aarch64") ->
                "aarch64-unknown-linux-musl"
            abi.contains("x86_64") || abi.contains("amd64") ->
                "x86_64-unknown-linux-musl"
            abi.contains("armeabi") || abi.contains("armv7") ->
                "arm-unknown-linux-musleabihf"
            else ->
                "aarch64-unknown-linux-musl"
        }
        // Contoh: railway-v5.41.2-aarch64-unknown-linux-musl.tar.gz
        return "railway-$CLI_VERSION-$target.tar.gz"
    }

    private fun downloadFile(
        urlStr: String,
        dest: File,
        onProgress: ((Float, String) -> Unit)?
    ) {
        val url = URL(urlStr)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "RailwayDeck-Android")
        }

        conn.connect()
        if (conn.responseCode !in 200..299) {
            throw Exception("Download gagal: HTTP ${conn.responseCode}")
        }

        val total = conn.contentLengthLong.coerceAtLeast(1L)
        BufferedInputStream(conn.inputStream).use { input ->
            FileOutputStream(dest).use { output ->
                val buffer = ByteArray(8192)
                var downloaded = 0L
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    downloaded += read
                    val p = 0.05f + (downloaded.toFloat() / total) * 0.75f
                    onProgress?.invoke(p.coerceIn(0f, 0.85f), "Download ${(p * 100).toInt()}%")
                }
            }
        }
        conn.disconnect()
    }

    /**
     * Extract fail 'railway' dari tar.gz.
     * Guna manual tar parsing tanpa dependency berat (simplified).
     */
    private fun extractRailwayBinary(tarGz: File, outBinary: File) {
        // Simple approach: gunakan Process tar kalau ada, else manual
        try {
            val pb = ProcessBuilder("tar", "-xzf", tarGz.absolutePath, "-C", cliDir.absolutePath)
            pb.redirectErrorStream(true)
            val p = pb.start()
            val ok = p.waitFor(60, TimeUnit.SECONDS)
            if (ok && p.exitValue() == 0) {
                // Cari binary dalam cliDir
                val found = cliDir.walkTopDown()
                    .firstOrNull { it.isFile && it.name == BINARY_NAME && it != outBinary }
                if (found != null && found != outBinary) {
                    found.copyTo(outBinary, overwrite = true)
                    found.delete()
                }
                if (outBinary.exists()) return
            }
        } catch (_: Exception) {
            // fallback manual
        }

        // Manual gzip + tar header parse (minimal)
        GZIPInputStream(BufferedInputStream(FileInputStream(tarGz))).use { gis ->
            val buffer = ByteArray(512)
            while (true) {
                val headerRead = gis.read(buffer)
                if (headerRead < 512) break

                val name = buffer.decodeToString(0, 100).trim { it <= ' ' || it == '\u0000' }
                val sizeOctal = buffer.decodeToString(124, 136).trim { it <= ' ' || it == '\u0000' }
                val size = sizeOctal.toLongOrNull(8) ?: 0L
                val typeFlag = buffer[156].toInt().toChar()

                if (name.isEmpty()) break

                if (typeFlag == '0' || typeFlag == '\u0000') {
                    // regular file
                    if (name.endsWith("/$BINARY_NAME") || name == BINARY_NAME || name.endsWith(BINARY_NAME)) {
                        FileOutputStream(outBinary).use { fos ->
                            var remaining = size
                            val buf = ByteArray(8192)
                            while (remaining > 0) {
                                val toRead = minOf(buf.size.toLong(), remaining).toInt()
                                val r = gis.read(buf, 0, toRead)
                                if (r <= 0) break
                                fos.write(buf, 0, r)
                                remaining -= r
                            }
                        }
                        // skip padding to 512
                        val padding = (512 - (size % 512)) % 512
                        gis.skip(padding)
                        return
                    } else {
                        // skip file content + padding
                        var remaining = size
                        while (remaining > 0) {
                            val skipped = gis.skip(remaining)
                            if (skipped <= 0) break
                            remaining -= skipped
                        }
                        val padding = (512 - (size % 512)) % 512
                        gis.skip(padding)
                    }
                } else {
                    // directory / other — skip
                    val padding = (512 - (size % 512)) % 512
                    if (size > 0) {
                        var remaining = size
                        while (remaining > 0) {
                            val skipped = gis.skip(remaining)
                            if (skipped <= 0) break
                            remaining -= skipped
                        }
                    }
                    gis.skip(padding)
                }
            }
        }

        if (!outBinary.exists()) {
            throw Exception("Gagal extract binary 'railway' dari archive")
        }
    }

    fun run(args: List<String>, timeoutSeconds: Long = 90): CliResult {
        if (!isInstalled()) {
            return CliResult(false, "", "Railway CLI belum dipasang")
        }
        return try {
            val cmd = mutableListOf(binaryFile.absolutePath).apply { addAll(args) }
            val process = ProcessBuilder(cmd)
                .directory(cliDir)
                .redirectErrorStream(true)
                .start()

            val finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return CliResult(false, "", "Timeout")
            }
            val output = BufferedReader(InputStreamReader(process.inputStream)).readText().trim()
            val code = process.exitValue()
            CliResult(code == 0, output, if (code != 0) output else null, code)
        } catch (e: Exception) {
            CliResult(false, "", e.message)
        }
    }

    fun login(): CliResult = run(listOf("login"))
    fun whoami(): CliResult = run(listOf("whoami"))
    fun listProjects(): CliResult = run(listOf("list"))
}

data class CliResult(
    val success: Boolean,
    val output: String,
    val error: String? = null,
    val exitCode: Int = -1
)
