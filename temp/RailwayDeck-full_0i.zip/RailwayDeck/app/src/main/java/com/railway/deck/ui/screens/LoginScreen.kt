package com.railway.deck.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.railway.deck.BuildConfig
import com.railway.deck.ui.theme.*
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.CodeVerifierUtil
import net.openid.appauth.ResponseTypeValues

@Composable
fun LoginScreen(navController: NavController) {
    val context = LocalContext.current
    var status by remember { mutableStateOf("Tekan butang untuk login Railway") }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "Railway Deck",
                color = TextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Login native Android\n(tiada Termux, tiada CLI binary)",
                color = TextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = {
                    isLoading = true
                    status = "Membuka Railway login..."

                    try {
                        val serviceConfig = AuthorizationServiceConfiguration(
                            Uri.parse("https://railway.com/oauth/authorize"),
                            Uri.parse("https://railway.com/oauth/token")
                        )

                        val codeVerifier = CodeVerifierUtil.generateRandomCodeVerifier()
                        val codeChallenge = CodeVerifierUtil.deriveCodeVerifierChallenge(codeVerifier)

                        val clientId = BuildConfig.RAILWAY_CLIENT_ID
                        if (clientId == "YOUR_RAILWAY_CLIENT_ID" || clientId.isBlank()) {
                            status = "Client ID belum diisi. Ganti dalam build.gradle.kts"
                            isLoading = false
                            return@Button
                        }

                        val authRequest = AuthorizationRequest.Builder(
                            serviceConfig,
                            clientId,
                            ResponseTypeValues.CODE,
                            Uri.parse(BuildConfig.RAILWAY_REDIRECT_URI)
                        )
                            .setCodeVerifier(codeVerifier, codeChallenge, "S256")
                            .setScopes(
                                "openid", "email", "profile", "offline_access",
                                "workspace:member", "project:member"
                            )
                            .build()

                        val authService = AuthorizationService(context)
                        val authIntent = authService.getAuthorizationRequestIntent(authRequest)
                        context.startActivity(authIntent)
                        status = "Selesaikan login di browser, kemudian kembali ke app"
                    } catch (e: Exception) {
                        status = "Error: ${e.message}"
                    } finally {
                        isLoading = false
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = Color.Black
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.Black,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = "Login with Railway",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp
                    )
                }
            }

            Text(
                text = status,
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Cara kerja", color = TextPrimary, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. Tekan Login with Railway\n" +
                                "2. Browser Railway dibuka\n" +
                                "3. Login + Allow Access\n" +
                                "4. Automatik kembali ke app\n" +
                                "5. Token disimpan selamat (multi-account)\n\n" +
                                "Tiada Termux. Tiada binary Linux.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
