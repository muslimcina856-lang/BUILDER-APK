package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.railway.deck.cli.TermuxHelper
import com.railway.deck.ui.theme.*

/**
 * Check Termux on first launch.
 * Kalau Termux ada → terus masuk app.
 * Kalau tiada → tunjuk arahan install.
 */
@Composable
fun SetupScreen(onReady: () -> Unit) {
    val context = LocalContext.current
    val termuxInstalled = remember { TermuxHelper.isTermuxInstalled(context) }

    // Kalau Termux sudah ada, terus ready
    LaunchedEffect(termuxInstalled) {
        if (termuxInstalled) {
            onReady()
        }
    }

    if (termuxInstalled) {
        // Sedang redirect — tunjuk loading singkat
        Box(
            modifier = Modifier.fillMaxSize().background(Charcoal),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Accent)
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Railway Deck",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "App ni guna Railway CLI melalui Termux\n(paling stabil di Android)",
                color = TextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Langkah setup (sekali sahaja)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "1. Install Termux (F-Droid recommended)\n" +
                                "2. Buka Termux, taip:\n" +
                                "   pkg update && pkg install curl\n" +
                                "3. Install Railway CLI:\n" +
                                "   bash <(curl -fsSL railway.com/install.sh)\n" +
                                "4. Kembali ke Railway Deck → Login",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            Button(
                onClick = { TermuxHelper.openTermuxInstallPage(context) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
            ) {
                Text("Install Termux", fontWeight = FontWeight.SemiBold)
            }

            OutlinedButton(
                onClick = {
                    // User claim sudah install — cuba teruskan
                    if (TermuxHelper.isTermuxInstalled(context)) {
                        onReady()
                    } else {
                        // Masih tiada — buka semula
                        TermuxHelper.openTermuxInstallPage(context)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Saya sudah ada Termux", color = TextPrimary)
            }
        }
    }
}
