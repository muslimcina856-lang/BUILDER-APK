package com.railway.deck.cli

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log

/**
 * Integrasi Railway CLI melalui Termux.
 * Ini cara paling stabil di Android (binary Linux jalan dalam environment Termux).
 */
object TermuxHelper {

    private const val TAG = "TermuxHelper"

    const val TERMUX_PACKAGE = "com.termux"
    const val TERMUX_ACTIVITY = "com.termux.app.TermuxActivity"
    const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Buka Termux (user boleh taip railway sendiri).
     */
    fun openTermux(context: Context): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(TERMUX_PACKAGE)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (e: Exception) {
            Log.e(TAG, "openTermux failed", e)
            false
        }
    }

    /**
     * Cuba jalankan command dalam Termux melalui RUN_COMMAND intent.
     * Nota: Termux versi baharu mungkin perlukan user allow "Run commands from other apps"
     * dalam Termux settings.
     *
     * Contoh: runCommand(context, "railway login")
     */
    fun runCommand(context: Context, command: String, background: Boolean = false): Boolean {
        if (!isTermuxInstalled(context)) return false

        return try {
            val intent = Intent().apply {
                setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                action = ACTION_RUN_COMMAND
                putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                putExtra(
                    "com.termux.RUN_COMMAND_ARGUMENTS",
                    arrayOf("-c", command)
                )
                putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", background)
                putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
            }
            context.startService(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "runCommand failed, fallback open Termux", e)
            // Fallback: buka Termux sahaja
            openTermux(context)
        }
    }

    /** Shortcut: railway login */
    fun railwayLogin(context: Context): Boolean {
        return runCommand(context, "railway login", background = false)
    }

    /** Shortcut: railway list */
    fun railwayList(context: Context): Boolean {
        return runCommand(context, "railway list", background = false)
    }

    /** Shortcut: railway whoami */
    fun railwayWhoami(context: Context): Boolean {
        return runCommand(context, "railway whoami", background = false)
    }

    /**
     * Buka Play Store / F-Droid untuk install Termux.
     */
    fun openTermuxInstallPage(context: Context) {
        try {
            // Cuba F-Droid dulu (recommended untuk Termux)
            val fdroid = Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/packages/com.termux/"))
            fdroid.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fdroid)
        } catch (_: Exception) {
            try {
                val play = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.termux"))
                play.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(play)
            } catch (_: Exception) {
                val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://termux.dev"))
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(web)
            }
        }
    }
}
