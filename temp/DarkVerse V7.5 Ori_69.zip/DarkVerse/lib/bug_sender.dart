import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with TickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  // === PALETTE ===
  static const Color _bg = Color(0xFF000000);
  static const Color _surface = Color(0xFF080808);
  static const Color _card = Color(0xFF0D0D0D);
  static const Color _red = Color(0xFFFF0040);
  static const Color _redGlow = Color(0xFFFF2255);
  static const Color _redDeep = Color(0xFF7A001E);
  static const Color _line = Color(0xFF1C1C1C);
  static const Color _muted = Color(0xFF5A5A5A);
  static const Color _dim = Color(0xFF2C2C2C);
  static const Color _white = Color(0xFFFFFFFF);

  late AnimationController _pulseCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _entryCtrl;
  late Animation<double> _pulse;
  late Animation<double> _scan;
  late Animation<double> _entry;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _pulse = Tween<double>(begin: 0.15, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _scan = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.linear),
    );
    _entry = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);

    _fetchSenders();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _scanCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final response = await http.get(
        Uri.parse(
            "http://vionmekss.duckdns.top:10158/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          if (mounted) setState(() => senderList = data["connections"] ?? []);
        } else {
          if (mounted)
            setState(() => errorMessage = data["message"] ?? "Failed to fetch");
        }
      } else {
        if (mounted)
          setState(() => errorMessage = "Server error: ${response.statusCode}");
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = "Connection failed: $e");
    } finally {
      if (mounted)
        setState(() {
          isLoading = false;
          isRefreshing = false;
        });
      _entryCtrl
        ..reset()
        ..forward();
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.88),
      builder: (_) => _ModernDialog(
        icon: Icons.add_link_rounded,
        title: "NEW SENDER NODE",
        subtitle:
            "Masukkan nomor WhatsApp target untuk dihubungkan sebagai Sender Node.",
        content: _StyledTextField(
          controller: phoneController,
          label: "Phone Number",
          hint: "628xxx...",
          icon: Icons.phone_android_rounded,
        ),
        cancelLabel: "CANCEL",
        confirmLabel: "GENERATE PAIRING",
        onConfirm: () async {
          final number = phoneController.text.trim();
          if (number.isEmpty) {
            Navigator.pop(context);
            _showSnackBar("Number cannot be empty", isError: true);
            return;
          }
          Navigator.pop(context);
          await _addSender(number);
        },
        onCancel: () => Navigator.pop(context),
      ),
    );
  }

  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse(
          "http://vionmekss.duckdns.top:10158/getPairing?key=${widget.sessionKey}&number=$number"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode']);
          _showSnackBar("Pairing sequence generated!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Pairing failed", isError: true);
        }
      } else {
        _showSnackBar("Server Error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection Fault: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.9),
      builder: (_) => StatefulBuilder(builder: (ctx, setS) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: _red.withValues(alpha: 0.35), width: 1.5),
              boxShadow: [
                BoxShadow(
                    color: _red.withValues(alpha: 0.18),
                    blurRadius: 50,
                    spreadRadius: -5),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top bar
                Container(
                  padding: const EdgeInsets.fromLTRB(24, 28, 24, 20),
                  decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: _line.withValues(alpha: 0.8))),
                  ),
                  child: Row(
                    children: [
                      _GlowIcon(
                          icon: Icons.qr_code_scanner_rounded, size: 22),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "PAIRING REQUIRED",
                            style: TextStyle(
                              color: _red,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 15,
                              letterSpacing: 1.2,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            "TARGET · $number",
                            style: TextStyle(
                              color: _muted,
                              fontFamily: 'ShareTechMono',
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      // Code box
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 28),
                        decoration: BoxDecoration(
                          color: _surface,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _red, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                                color: _red.withValues(alpha: 0.2),
                                blurRadius: 30,
                                spreadRadius: -5),
                          ],
                        ),
                        child: Column(
                          children: [
                            Text(
                              "PAIRING CODE",
                              style: TextStyle(
                                color: _muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 2,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              code,
                              style: const TextStyle(
                                color: _red,
                                fontSize: 36,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 10,
                                fontFamily: 'ShareTechMono',
                                shadows: [
                                  Shadow(color: _red, blurRadius: 16)
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Copy button
                      _ActionButton(
                        icon: Icons.copy_all_rounded,
                        label: "COPY TO CLIPBOARD",
                        onTap: () async {
                          await Clipboard.setData(
                              ClipboardData(text: code));
                          _showSnackBar("Sequence copied to clipboard!",
                              isError: false);
                        },
                      ),
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          _fetchSenders();
                        },
                        child: Text(
                          "CLOSE & REFRESH",
                          style: TextStyle(
                            color: _muted,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.88),
      builder: (_) => _ModernDialog(
        icon: Icons.warning_amber_rounded,
        title: "PURGE NODE",
        subtitle:
            "Apakah Anda yakin ingin menghapus Sender Node ini selamanya?\nProses ini tidak dapat dibatalkan.",
        cancelLabel: "CANCEL",
        confirmLabel: "PURGE",
        onConfirm: () => Navigator.pop(context, true),
        onCancel: () => Navigator.pop(context, false),
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);
      try {
        final response = await http.delete(Uri.parse(
            "http://vionmekss.duckdns.top:10158/deleteSender?key=${widget.sessionKey}&id=$senderId"));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Node purged successfully.", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(
                data["message"] ?? "Failed to purge node",
                isError: true);
          }
        } else {
          _showSnackBar(
              "Server error: ${response.statusCode}",
              isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        if (mounted) setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: _bg,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: _bg,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? const Color(0xFFCC0033) : _red,
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
        elevation: 0,
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final nodeId =
        sender['id']?.toString().substring(0, 8).toUpperCase() ?? 'UNKNOWN';

    return AnimatedBuilder(
      animation: _entry,
      builder: (context, child) {
        final delay = (index * 0.12).clamp(0.0, 0.8);
        final t = ((_entry.value - delay) / (1.0 - delay)).clamp(0.0, 1.0);
        return Transform.translate(
          offset: Offset(0, 32 * (1 - t)),
          child: Opacity(opacity: t, child: child),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _line),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF0F0F0F),
              const Color(0xFF0A0A0A),
            ],
          ),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.6),
                blurRadius: 16,
                offset: const Offset(0, 8)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Column(
            children: [
              // Red accent top strip
              Container(
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      _red.withValues(alpha: 0.6),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
                child: Row(
                  children: [
                    // Icon box
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: _surface,
                        borderRadius: BorderRadius.circular(15),
                        border:
                            Border.all(color: _red.withValues(alpha: 0.2)),
                        boxShadow: [
                          BoxShadow(
                              color: _red.withValues(alpha: 0.1),
                              blurRadius: 15,
                              spreadRadius: -3),
                        ],
                      ),
                      child: const Icon(Icons.hub_rounded,
                          color: _red, size: 22),
                    ),
                    const SizedBox(width: 16),
                    // Name & ID
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name.toUpperCase(),
                            style: const TextStyle(
                              color: _white,
                              fontSize: 14,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.8,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 7, vertical: 3),
                                decoration: BoxDecoration(
                                  color: _dim.withValues(alpha: 0.6),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  "ID · $nodeId",
                                  style: TextStyle(
                                    color: _muted,
                                    fontSize: 10,
                                    fontFamily: 'ShareTechMono',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // Status badge
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (ctx, _) => Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _red.withValues(
                              alpha: _pulse.value * 0.07 + 0.04),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: _red.withValues(
                                  alpha: _pulse.value * 0.3 + 0.1)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: _red,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: _red.withValues(
                                        alpha: _pulse.value * 0.8),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              "LIVE",
                              style: TextStyle(
                                color: _red,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Divider
              Container(
                height: 1,
                margin: const EdgeInsets.symmetric(horizontal: 18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      _line,
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              // Actions
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
                child: Row(
                  children: [
                    _CardAction(
                      icon: Icons.sync_rounded,
                      label: "SYNC",
                      color: _muted,
                      onTap: _refreshSenders,
                    ),
                    Container(
                        width: 1,
                        height: 22,
                        color: _line),
                    _CardAction(
                      icon: Icons.delete_sweep_rounded,
                      label: "PURGE",
                      color: _red,
                      onTap: () => _deleteSender(sender['id']),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        color: _surface,
        border: Border(bottom: BorderSide(color: _line)),
      ),
      child: Row(
        children: [
          // Back button
          _IconBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.pop(context),
          ),
          const SizedBox(width: 14),
          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [_red, _redGlow],
                  ).createShader(bounds),
                  child: const Text(
                    "SENDER NODES",
                    style: TextStyle(
                      color: _white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 19,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "Device Management System",
                  style: TextStyle(
                    color: _muted,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          // Sync
          _IconBtn(
            icon: Icons.sync_rounded,
            disabled: isLoading,
            accent: true,
            onTap: isLoading ? null : _refreshSenders,
          ),
        ],
      ),
    );
  }

  Widget _buildStatsBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Row(
        children: [
          Expanded(
            child: _StatChip(
              icon: Icons.hub_rounded,
              value: "${senderList.length}",
              label: "Active Nodes",
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatChip(
              icon: Icons.shield_rounded,
              value: widget.role.toUpperCase(),
              label: "Access Level",
              valueSize: 12,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatChip(
              icon: Icons.person_outline_rounded,
              value: widget.username,
              label: "Operator",
              valueSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(36),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated ring icon
            AnimatedBuilder(
              animation: _scan,
              builder: (ctx, _) => SizedBox(
                width: 120,
                height: 120,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Rotating ring
                    Transform.rotate(
                      angle: _scan.value * 2 * math.pi,
                      child: Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: SweepGradient(
                            colors: [
                              Colors.transparent,
                              _red.withValues(alpha: 0.4),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: _surface,
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: _line, width: 1.5),
                      ),
                    ),
                    Icon(Icons.router_outlined,
                        color: _red.withValues(alpha: 0.4), size: 34),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
            ShaderMask(
              shaderCallback: (b) =>
                  LinearGradient(colors: [_red, _redGlow]).createShader(b),
              child: const Text(
                "NO ACTIVE NODES",
                style: TextStyle(
                  color: _white,
                  fontSize: 18,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.5,
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              "Sistem tidak mendeteksi koneksi pengirim.\nTambahkan WhatsApp node pertama Anda.",
              style: TextStyle(
                color: _muted,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.7,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            _PrimaryButton(
              icon: Icons.add_link_rounded,
              label: "INITIALIZE SENDER",
              onTap: _showAddSenderDialog,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(36),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                color: _red.withValues(alpha: 0.05),
                shape: BoxShape.circle,
                border:
                    Border.all(color: _red.withValues(alpha: 0.2), width: 1.5),
                boxShadow: [
                  BoxShadow(
                      color: _red.withValues(alpha: 0.1),
                      blurRadius: 40,
                      spreadRadius: 0),
                ],
              ),
              child: const Icon(Icons.wifi_off_rounded, color: _red, size: 48),
            ),
            const SizedBox(height: 28),
            const Text(
              "CONNECTION FAULT",
              style: TextStyle(
                color: _red,
                fontSize: 17,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                letterSpacing: 2.5,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              errorMessage ?? "Unknown error occurred",
              style: TextStyle(
                color: _muted,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.6,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            _PrimaryButton(
              icon: Icons.refresh_rounded,
              label: "RETRY CONNECTION",
              onTap: _fetchSenders,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Stack(
          children: [
            // Subtle grid bg
            Positioned.fill(child: _GridBackground()),
            Column(
              children: [
                _buildHeader(),
                _buildStatsBar(),
                Expanded(
                  child: isLoading && senderList.isEmpty
                      ? Center(
                          child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: 40,
                              height: 40,
                              child: CircularProgressIndicator(
                                color: _red,
                                strokeWidth: 2,
                                backgroundColor:
                                    _red.withValues(alpha: 0.1),
                              ),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              "SCANNING NODES...",
                              style: TextStyle(
                                color: _muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 11,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ))
                      : errorMessage != null && senderList.isEmpty
                          ? _buildErrorState()
                          : senderList.isEmpty
                              ? _buildEmptyState()
                              : RefreshIndicator(
                                  color: _red,
                                  backgroundColor: _card,
                                  onRefresh: _refreshSenders,
                                  child: ListView.builder(
                                    padding: const EdgeInsets.only(
                                        top: 10, bottom: 110),
                                    physics:
                                        const AlwaysScrollableScrollPhysics(),
                                    itemCount: senderList.length,
                                    itemBuilder: (context, index) =>
                                        _buildSenderCard(
                                      Map<String, dynamic>.from(
                                          senderList[index]),
                                      index,
                                    ),
                                  ),
                                ),
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: senderList.isNotEmpty
          ? Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _PrimaryButton(
                icon: Icons.add_link_rounded,
                label: "NEW NODE",
                onTap: _showAddSenderDialog,
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}

// ──────────────────────────────────────────────
// SHARED WIDGET COMPONENTS
// ──────────────────────────────────────────────

class _GridBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _GridPainter());
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0F0F0F)
      ..strokeWidth = 0.5;
    const step = 36.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => false;
}

class _GlowIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  const _GlowIcon({required this.icon, this.size = 22});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFFF0040).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: const Color(0xFFFF0040).withValues(alpha: 0.25)),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFFFF0040).withValues(alpha: 0.12),
              blurRadius: 16,
              spreadRadius: 0),
        ],
      ),
      child: Icon(icon, color: const Color(0xFFFF0040), size: size),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool disabled;
  final bool accent;
  const _IconBtn(
      {required this.icon,
      this.onTap,
      this.disabled = false,
      this.accent = false});

  static const _red = Color(0xFFFF0040);
  static const _muted = Color(0xFF5A5A5A);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: BorderRadius.circular(13),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: const Color(0xFF0D0D0D),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: const Color(0xFF1C1C1C)),
          ),
          child: Icon(
            icon,
            color: disabled
                ? const Color(0xFF2C2C2C)
                : accent
                    ? _red.withValues(alpha: 0.7)
                    : Colors.white,
            size: 17,
          ),
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final double valueSize;
  const _StatChip(
      {required this.icon,
      required this.value,
      required this.label,
      this.valueSize = 14});

  static const _red = Color(0xFFFF0040);
  static const _card = Color(0xFF0D0D0D);
  static const _muted = Color(0xFF5A5A5A);
  static const _line = Color(0xFF1C1C1C);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _line),
      ),
      child: Row(
        children: [
          Icon(icon, color: _red.withValues(alpha: 0.55), size: 16),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontWeight: FontWeight.w900,
                    fontSize: valueSize,
                    fontFamily: 'Orbitron',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  label,
                  style: TextStyle(
                    color: _muted,
                    fontSize: 9,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CardAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  const _CardAction(
      {required this.icon,
      required this.label,
      required this.color,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 11),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 15, color: color),
                const SizedBox(width: 7),
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 10,
                    color: color,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const _PrimaryButton(
      {required this.icon, required this.label, this.onTap});

  static const _red = Color(0xFFFF0040);
  static const _redDeep = Color(0xFF7A001E);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [
                _red.withValues(alpha: 0.14),
                _redDeep.withValues(alpha: 0.06),
              ],
            ),
            border:
                Border.all(color: _red.withValues(alpha: 0.35), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: _red.withValues(alpha: 0.12),
                  blurRadius: 24,
                  spreadRadius: -4),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: _red, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: const TextStyle(
                  color: _red,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const _ActionButton(
      {required this.icon, required this.label, this.onTap});

  static const _red = Color(0xFFFF0040);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: OutlinedButton.icon(
        icon: Icon(icon, color: _red, size: 17),
        label: Text(
          label,
          style: const TextStyle(
            color: _red,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 11,
            letterSpacing: 0.8,
          ),
        ),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: _red.withValues(alpha: 0.3), width: 1.5),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13)),
          backgroundColor: _red.withValues(alpha: 0.05),
        ),
        onPressed: onTap,
      ),
    );
  }
}

class _StyledTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  const _StyledTextField(
      {required this.controller,
      required this.label,
      required this.hint,
      required this.icon});

  static const _red = Color(0xFFFF0040);
  static const _surface = Color(0xFF080808);
  static const _muted = Color(0xFF5A5A5A);
  static const _dim = Color(0xFF2C2C2C);
  static const _line = Color(0xFF1C1C1C);

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.phone,
      style: const TextStyle(
          color: Colors.white,
          fontFamily: 'ShareTechMono',
          fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
            color: _muted, fontFamily: 'ShareTechMono', fontSize: 13),
        hintText: hint,
        hintStyle: TextStyle(color: _dim, fontFamily: 'ShareTechMono'),
        prefixIcon: Icon(icon, color: _red.withValues(alpha: 0.5), size: 20),
        filled: true,
        fillColor: _surface,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: _line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: _line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide:
              BorderSide(color: _red.withValues(alpha: 0.5), width: 1.5),
        ),
      ),
    );
  }
}

class _ModernDialog extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? content;
  final String cancelLabel;
  final String confirmLabel;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  const _ModernDialog({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.content,
    required this.cancelLabel,
    required this.confirmLabel,
    required this.onConfirm,
    required this.onCancel,
  });

  static const _red = Color(0xFFFF0040);
  static const _card = Color(0xFF0D0D0D);
  static const _muted = Color(0xFF5A5A5A);
  static const _line = Color(0xFF1C1C1C);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _red.withValues(alpha: 0.22), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: _red.withValues(alpha: 0.12),
                blurRadius: 50,
                spreadRadius: -8),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header strip
            Container(
              height: 2,
              decoration: BoxDecoration(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(28)),
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    _red.withValues(alpha: 0.6),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _GlowIcon(icon: icon),
                      const SizedBox(width: 14),
                      Text(
                        title,
                        style: const TextStyle(
                          color: _red,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: _muted,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                      height: 1.6,
                    ),
                  ),
                  if (content != null) ...[
                    const SizedBox(height: 18),
                    content!,
                  ],
                  const SizedBox(height: 24),
                ],
              ),
            ),
            Container(
              height: 1,
              color: _line,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: onCancel,
                      child: Text(
                        cancelLabel,
                        style: TextStyle(
                          color: _muted,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: _red.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(
                            color: _red.withValues(alpha: 0.35), width: 1.5),
                      ),
                      child: TextButton(
                        onPressed: onConfirm,
                        child: Text(
                          confirmLabel,
                          style: const TextStyle(
                            color: _red,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
