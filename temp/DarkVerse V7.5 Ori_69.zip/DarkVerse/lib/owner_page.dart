import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─────────────────────────────────────────────
//  OwnerPage  —  Tactical Dark UI  v3.0
// ─────────────────────────────────────────────
class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> with TickerProviderStateMixin {
  // ── Palette ──────────────────────────────────
  static const Color _bg      = Color(0xFF000000);
  static const Color _surface = Color(0xFF0C0C0C);
  static const Color _card    = Color(0xFF111111);
  static const Color _line    = Color(0xFF1E1E1E);
  static const Color _red     = Color(0xFFFF0040);
  static const Color _white   = Color(0xFFEEEEEE);
  static const Color _muted   = Color(0xFF555555);
  static const Color _subtle  = Color(0xFF282828);

  // ── State ────────────────────────────────────
  late final AnimationController _pulseCtrl;
  late final AnimationController _entryCtrl;
  late final Animation<double> _entryAnim;

  late String sessionKey;
  List<dynamic> fullUserList  = [];
  List<dynamic> filteredList  = [];

  final roleOptions = ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member'];
  String selectedRole = 'member';
  String newUserRole  = 'member';

  int currentPage  = 1;
  final int itemsPerPage = 25;

  final createUsernameCtrl = TextEditingController();
  final createPasswordCtrl = TextEditingController();
  final createDayCtrl      = TextEditingController();
  final deleteCtrl         = TextEditingController();
  final editUsernameCtrl   = TextEditingController();
  final editDayCtrl        = TextEditingController();

  bool isLoading = false;

  // Track section expansion
  final Map<int, bool> _sectionOpen = {0: true, 1: false, 2: false, 3: false};

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _entryAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);

    _fetchUsers();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _entryCtrl.dispose();
    createUsernameCtrl.dispose();
    createPasswordCtrl.dispose();
    createDayCtrl.dispose();
    deleteCtrl.dispose();
    editUsernameCtrl.dispose();
    editDayCtrl.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://vionmekss.duckdns.top:10158/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showAlert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _showAlert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage  = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end   = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final u = deleteCtrl.text.trim();
    if (u.isEmpty) { _showAlert("Peringatan", "Masukkan username yang ingin dihapus."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse('http://vionmekss.duckdns.top:10158/deleteUser?key=$sessionKey&username=$u'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showAlert("Sukses", "User berhasil dihapus.");
        deleteCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameCtrl.text.trim();
    final p = createPasswordCtrl.text.trim();
    final d = createDayCtrl.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) { _showAlert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse(
        'http://vionmekss.duckdns.top:10158/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      ));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _showAlert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameCtrl.clear(); createPasswordCtrl.clear(); createDayCtrl.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameCtrl.text.trim();
    final d = editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) { _showAlert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse(
        'http://vionmekss.duckdns.top:10158/editUser?key=$sessionKey&username=$u&addDays=$d',
      ));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showAlert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameCtrl.clear(); editDayCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  // ── Dialogs ───────────────────────────────────
  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _red.withOpacity(0.2)),
            boxShadow: [BoxShadow(color: _red.withOpacity(0.08), blurRadius: 40)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _red.withOpacity(0.2)),
                  ),
                  child: const Icon(Icons.info_outline_rounded, color: _red, size: 18),
                ),
                const SizedBox(width: 12),
                Text(title.toUpperCase(), style: const TextStyle(
                  color: _red, fontFamily: 'Orbitron', fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _line),
              const SizedBox(height: 14),
              Text(msg, style: const TextStyle(
                color: _muted, fontSize: 13, fontFamily: 'ShareTechMono', height: 1.6,
              )),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: _red.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: _red.withOpacity(0.2)),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 13),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text("OK", style: TextStyle(
                    color: _red, fontFamily: 'Orbitron',
                    fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1,
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(String username) async {
    return await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _red.withOpacity(0.25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.warning_amber_rounded, color: _red, size: 18),
                ),
                const SizedBox(width: 12),
                const Text("KONFIRMASI", style: TextStyle(
                  color: _red, fontFamily: 'Orbitron', fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _line),
              const SizedBox(height: 14),
              Text("Hapus user \"$username\"?\nTindakan ini tidak bisa dibatalkan.", style: const TextStyle(
                color: _muted, fontSize: 13, fontFamily: 'ShareTechMono', height: 1.6,
              )),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _subtle,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("BATAL", style: TextStyle(
                      color: _muted, fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _red.withOpacity(0.12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _red.withOpacity(0.3)),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("HAPUS", style: TextStyle(
                      color: _red, fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    ) ?? false;
  }

  // ── Build ─────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _bg,
        body: Stack(
          children: [
            // Ambient glow
            Positioned(
              top: -100, left: -80,
              child: AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Opacity(
                  opacity: 0.05 + _pulseCtrl.value * 0.04,
                  child: Container(
                    width: 280, height: 280,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: _red),
                  ),
                ),
              ),
            ),

            SafeArea(
              child: FadeTransition(
                opacity: _entryAnim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.03), end: Offset.zero,
                  ).animate(_entryAnim),
                  child: CustomScrollView(
                    physics: const BouncingScrollPhysics(),
                    slivers: [
                      const SliverToBoxAdapter(child: SizedBox(height: 20)),
                      SliverToBoxAdapter(child: _buildHeader()),
                      const SliverToBoxAdapter(child: SizedBox(height: 20)),
                      SliverToBoxAdapter(child: _buildStatsRow()),
                      const SliverToBoxAdapter(child: SizedBox(height: 24)),
                      SliverToBoxAdapter(child: _buildSectionDivider("PANEL CONTROLS")),
                      const SliverToBoxAdapter(child: SizedBox(height: 12)),

                      // Section 0 – Delete
                      SliverToBoxAdapter(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: _buildSection(
                          id: 0,
                          icon: FontAwesomeIcons.userSlash,
                          title: "DELETE USER",
                          child: _buildDeleteSection(),
                        ),
                      )),
                      const SliverToBoxAdapter(child: SizedBox(height: 8)),

                      // Section 1 – Create
                      SliverToBoxAdapter(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: _buildSection(
                          id: 1,
                          icon: FontAwesomeIcons.userPlus,
                          title: "CREATE ACCOUNT",
                          child: _buildCreateSection(),
                        ),
                      )),
                      const SliverToBoxAdapter(child: SizedBox(height: 8)),

                      // Section 2 – Extend
                      SliverToBoxAdapter(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: _buildSection(
                          id: 2,
                          icon: FontAwesomeIcons.clock,
                          title: "EXTEND DURATION",
                          child: _buildExtendSection(),
                        ),
                      )),
                      const SliverToBoxAdapter(child: SizedBox(height: 8)),

                      // Section 3 – User List
                      SliverToBoxAdapter(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: _buildSection(
                          id: 3,
                          icon: FontAwesomeIcons.users,
                          title: "USER LIST",
                          child: _buildUserListSection(),
                        ),
                      )),

                      SliverToBoxAdapter(child: _buildFooter()),
                      const SliverToBoxAdapter(child: SizedBox(height: 32)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Header ───────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _line),
        ),
        child: Row(children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => SizedBox(
              width: 52, height: 52,
              child: Stack(alignment: Alignment.center, children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _red.withOpacity(0.1 + _pulseCtrl.value * 0.15), width: 1,
                    ),
                  ),
                ),
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: _red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _red.withOpacity(0.25)),
                  ),
                  child: const Icon(Icons.workspace_premium_rounded, color: _red, size: 22),
                ),
              ]),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("OWNER", style: TextStyle(
                color: _red, fontSize: 22, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, letterSpacing: 4, height: 1,
              )),
              const SizedBox(height: 5),
              Text("Control Panel · ${widget.username}", style: const TextStyle(
                color: _muted, fontSize: 11, fontFamily: 'ShareTechMono', letterSpacing: 1,
              )),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.1),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.amber.withOpacity(0.25)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.military_tech_rounded, color: Colors.amber, size: 12),
              const SizedBox(width: 5),
              const Text("OWNER", style: TextStyle(
                color: Colors.amber, fontSize: 10, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w700, letterSpacing: 1,
              )),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── Stats Row ────────────────────────────────
  Widget _buildStatsRow() {
    final stats = [
      {'val': '${fullUserList.length}', 'lbl': 'TOTAL', 'icon': Icons.people_rounded},
      {'val': '${filteredList.length}', 'lbl': selectedRole.toUpperCase(), 'icon': Icons.filter_list_rounded},
      {'val': '${roleOptions.length}', 'lbl': 'ROLES', 'icon': Icons.verified_user_rounded},
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(stats.length, (i) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i < stats.length - 1 ? 8 : 0),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
              decoration: BoxDecoration(
                color: _surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _line),
              ),
              child: Column(children: [
                Icon(stats[i]['icon'] as IconData, color: _red.withOpacity(0.6), size: 16),
                const SizedBox(height: 6),
                Text(stats[i]['val'] as String, style: const TextStyle(
                  color: _red, fontSize: 14, fontFamily: 'Orbitron', fontWeight: FontWeight.w700,
                )),
                const SizedBox(height: 2),
                Text(stats[i]['lbl'] as String, style: const TextStyle(
                  color: _muted, fontSize: 8, fontFamily: 'ShareTechMono', letterSpacing: 1,
                )),
              ]),
            ),
          ),
        )),
      ),
    );
  }

  // ── Section Divider ──────────────────────────
  Widget _buildSectionDivider(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Container(width: 3, height: 14, decoration: BoxDecoration(
          color: _red, borderRadius: BorderRadius.circular(2),
        )),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(
          color: _muted, fontSize: 10, fontFamily: 'ShareTechMono', letterSpacing: 2,
        )),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 1, decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_line, Colors.transparent]),
        ))),
      ]),
    );
  }

  // ── Accordion Section ────────────────────────
  Widget _buildSection({
    required int id,
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    final isOpen = _sectionOpen[id] ?? false;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isOpen ? _red.withOpacity(0.25) : _line),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(children: [
          // Header
          InkWell(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _sectionOpen[id] = !isOpen);
            },
            borderRadius: BorderRadius.circular(16),
            splashColor: _red.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: isOpen ? _red.withOpacity(0.12) : _subtle,
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: isOpen ? _red.withOpacity(0.25) : _line),
                  ),
                  child: Center(child: FaIcon(icon, color: isOpen ? _red : _muted, size: 16)),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(title, style: TextStyle(
                  color: isOpen ? _red : _white,
                  fontSize: 13, fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700, letterSpacing: 1.5,
                ))),
                AnimatedRotation(
                  turns: isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  child: Icon(Icons.keyboard_arrow_down_rounded,
                    color: isOpen ? _red : _muted, size: 20),
                ),
              ]),
            ),
          ),

          // Body
          AnimatedSize(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            child: isOpen
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Column(children: [
                      Container(height: 1, color: _line),
                      const SizedBox(height: 16),
                      child,
                    ]),
                  )
                : const SizedBox.shrink(),
          ),
        ]),
      ),
    );
  }

  // ── Section Contents ─────────────────────────

  Widget _buildDeleteSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: deleteCtrl, icon: FontAwesomeIcons.user),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "DELETE ACCOUNT",
        icon: Icons.delete_rounded,
        onTap: isLoading ? null : _deleteUser,
        color: _red,
      ),
    ]);
  }

  Widget _buildCreateSection() {
    return Column(children: [
      _buildInput(label: "Username", ctrl: createUsernameCtrl, icon: FontAwesomeIcons.user),
      _buildInput(label: "Password", ctrl: createPasswordCtrl, icon: FontAwesomeIcons.lock, obscure: true),
      _buildInput(label: "Durasi (Hari)", ctrl: createDayCtrl, icon: FontAwesomeIcons.calendarDay, num: true),
      _buildDropdown(
        value: newUserRole,
        onChanged: (v) => setState(() => newUserRole = v ?? 'member'),
        label: "Role",
      ),
      const SizedBox(height: 12),
      _buildActionButton(
        label: "CREATE ACCOUNT",
        icon: Icons.add_circle_rounded,
        onTap: isLoading ? null : _createAccount,
        color: _red,
      ),
    ]);
  }

  Widget _buildExtendSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: editUsernameCtrl, icon: FontAwesomeIcons.userPen),
      _buildInput(label: "Tambah Hari", ctrl: editDayCtrl, icon: FontAwesomeIcons.calendarPlus, num: true),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "ADD DAYS",
        icon: Icons.calendar_month_rounded,
        onTap: isLoading ? null : _editUser,
        color: const Color(0xFF00B4D8),
      ),
    ]);
  }

  Widget _buildUserListSection() {
    return Column(children: [
      _buildDropdown(
        value: selectedRole,
        onChanged: (v) {
          if (v != null) { selectedRole = v; _filterAndPaginate(); }
        },
        label: "Filter Role",
      ),
      const SizedBox(height: 16),

      if (isLoading)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(children: [
            SizedBox(
              width: 28, height: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: _red.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 12),
            const Text("Memuat data...", style: TextStyle(
              color: _muted, fontSize: 11, fontFamily: 'ShareTechMono',
            )),
          ]),
        )
      else if (filteredList.isEmpty)
        Container(
          padding: const EdgeInsets.symmetric(vertical: 28),
          child: Column(children: [
            Icon(Icons.people_outline_rounded, color: _muted.withOpacity(0.3), size: 36),
            const SizedBox(height: 10),
            const Text("Tidak ada user", style: TextStyle(
              color: _muted, fontSize: 12, fontFamily: 'ShareTechMono',
            )),
          ]),
        )
      else
        Column(children: [
          ..._getCurrentPageData().map((u) => _buildUserItem(u as Map)).toList(),
          if (totalPages > 1) ...[
            const SizedBox(height: 16),
            _buildPagination(),
          ],
        ]),
    ]);
  }

  // ── Shared Widgets ───────────────────────────

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    bool obscure = false,
    bool num = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: num ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: _white, fontSize: 13, fontFamily: 'ShareTechMono'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: _muted, fontSize: 12, fontFamily: 'ShareTechMono'),
          prefixIcon: Padding(
            padding: const EdgeInsets.all(14),
            child: FaIcon(icon, color: _red.withOpacity(0.7), size: 15),
          ),
          filled: true,
          fillColor: _surface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _line),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _line),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _red.withOpacity(0.5), width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _line),
      ),
      child: Row(children: [
        Icon(Icons.shield_rounded, color: _red.withOpacity(0.7), size: 16),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              dropdownColor: _card,
              style: const TextStyle(color: _white, fontSize: 13, fontFamily: 'ShareTechMono'),
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: _muted, size: 18),
              items: roleOptions.map((r) => DropdownMenuItem(
                value: r,
                child: Text(r.toUpperCase()),
              )).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback? onTap,
    required Color color,
  }) {
    return SizedBox(
      width: double.infinity,
      child: TextButton(
        onPressed: onTap == null ? null : () {
          HapticFeedback.lightImpact();
          onTap();
        },
        style: TextButton.styleFrom(
          backgroundColor: color.withOpacity(0.1),
          disabledBackgroundColor: _subtle,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: color.withOpacity(0.25)),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        child: isLoading
            ? SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: color),
              )
            : Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 10),
                Text(label, style: TextStyle(
                  color: color, fontFamily: 'Orbitron',
                  fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _line),
      ),
      child: Row(children: [
        // Avatar
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: _red.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _red.withOpacity(0.15)),
          ),
          child: const Icon(Icons.person_rounded, color: _red, size: 18),
        ),
        const SizedBox(width: 12),

        // Info
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(user['username'] ?? '-', style: const TextStyle(
            color: _white, fontSize: 13, fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 3),
          Row(children: [
            _buildMiniChip(user['role']?.toString().toUpperCase() ?? '-', _red),
            const SizedBox(width: 6),
            Text(user['expiredDate'] ?? '-', style: const TextStyle(
              color: _muted, fontSize: 10, fontFamily: 'ShareTechMono',
            )),
          ]),
        ])),

        // Delete button
        InkWell(
          onTap: () async {
            HapticFeedback.mediumImpact();
            final ok = await _confirmDelete(user['username'] ?? '');
            if (ok) {
              deleteCtrl.text = user['username'];
              _deleteUser();
            }
          },
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.06),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _red.withOpacity(0.12)),
            ),
            child: const Icon(Icons.delete_outline_rounded, color: _red, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _buildMiniChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Text(text, style: TextStyle(
        color: color, fontSize: 8, fontFamily: 'Orbitron',
        fontWeight: FontWeight.w800, letterSpacing: 0.5,
      )),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: List.generate(totalPages, (i) {
        final page = i + 1;
        final active = page == currentPage;
        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => currentPage = page);
          },
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: active ? _red.withOpacity(0.12) : _subtle,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: active ? _red.withOpacity(0.35) : _line),
            ),
            child: Center(
              child: Text("$page", style: TextStyle(
                color: active ? _red : _muted,
                fontSize: 11, fontFamily: 'Orbitron', fontWeight: FontWeight.w700,
              )),
            ),
          ),
        );
      }),
    );
  }

  // ── Footer ───────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(children: [
        Container(height: 1, color: _line),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.info_outline_rounded, color: _muted.withOpacity(0.4), size: 12),
          const SizedBox(width: 6),
          Text("v3.0 · OWNER ACCESS · RESTRICTED", style: TextStyle(
            color: _muted.withOpacity(0.4), fontSize: 9,
            fontFamily: 'ShareTechMono', letterSpacing: 1.5,
          )),
        ]),
      ]),
    );
  }
}
