import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'video_splash_page.dart';

const String baseUrl = "http://fanzofficial.rexy-stecu.my.id:10072";

// ─── PALETTE ────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF000000);
  static const surface = Color(0xFF080808);
  static const card    = Color(0xFF0C0C0C);
  static const red     = Color(0xFFFF0040);
  static const redDark = Color(0xFF8B001E);
  static const line    = Color(0xFF161616);
  static const muted   = Color(0xFF4A4A4A);
  static const dim     = Color(0xFF222222);
  static const white   = Color(0xFFFFFFFF);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePass = true;
  String? androidId;

  late AnimationController _entryCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _pulseCtrl;

  late Animation<double> _logoFade;
  late Animation<double> _logoScale;
  late Animation<double> _formFade;
  late Animation<Offset> _formSlide;
  late Animation<double> _orbit;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initAutoLogin();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();

    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
    _logoScale = Tween<double>(begin: 0.88, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutCubic),
      ),
    );
    _formFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.35, 0.85, curve: Curves.easeOut),
      ),
    );
    _formSlide = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entryCtrl,
      curve: const Interval(0.3, 0.9, curve: Curves.easeOutCubic),
    ));
    _orbit = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _orbitCtrl, curve: Curves.linear),
    );
    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  Future<void> _initAutoLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString("username");
    final p = prefs.getString("password");
    final k = prefs.getString("key");

    if (u != null && p != null && k != null) {
      try {
        final res = await http.get(Uri.parse(
            "$baseUrl/myInfo?username=$u&password=$p&androidId=$androidId&key=$k"));
        final data = jsonDecode(res.body);
        if (data['valid'] == true) _goToSplash(_buildArgs(data, u, p));
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final android = await DeviceInfoPlugin().androidInfo;
    return android.id ?? "unknown_device";
  }

  Map<String, dynamic> _buildArgs(dynamic data, String u, String p) => {
        "username": u,
        "password": p,
        "role": data['role'],
        "key": data['key'],
        "expiredDate": data['expiredDate'],
        "listBug": (data['listBug'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "listDoos": (data['listDDoS'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "news": (data['news'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
      };

  void _goToSplash(Map<String, dynamic> args) {
    if (!mounted) return;
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => VideoSplashPage(dashboardArgs: args)));
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final u = userController.text.trim();
    final p = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {"username": u, "password": p, "androidId": androidId ?? "unknown"},
      );
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showAlert("Access Expired",
            "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
            showContact: true);
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? "").toLowerCase();
        _showAlert(
          "Login Gagal",
          msg.contains("perangkat") || msg.contains("device")
              ? "Akun ini sedang login di perangkat lain."
              : "Username atau password salah.",
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", u);
        prefs.setString("password", p);
        prefs.setString("key", data['key']);
        _goToSplash(_buildArgs(data, u, p));
      }
    } catch (_) {
      _showAlert("Connection Error", "Gagal terhubung ke server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _showAlert(String title, String message, {bool showContact = false}) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.red.withValues(alpha: 0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.red.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: _C.red, size: 26),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                    color: _C.red,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 1,
                  )),
              const SizedBox(height: 10),
              Text(message,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _C.muted,
                    fontSize: 13,
                    height: 1.6,
                    fontFamily: 'ShareTechMono',
                  )),
              const SizedBox(height: 22),
              Row(
                children: [
                  if (showContact) ...[
                    Expanded(
                      child: _DialogBtn(
                        label: "CONTACT",
                        onTap: () => launchUrl(
                          Uri.parse("https://t.me/Fahri_Reals01"),
                          mode: LaunchMode.externalApplication,
                        ),
                        isPrimary: false,
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    child: _DialogBtn(
                      label: "TUTUP",
                      onTap: () => Navigator.pop(context),
                      isPrimary: true,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _orbitCtrl.dispose();
    _pulseCtrl.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: _C.bg,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // ── Ambient glow background ────────────────────
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Positioned(
              top: -100,
              left: -60,
              child: Container(
                width: 320,
                height: 320,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _C.red.withValues(alpha: _pulse.value * 0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Positioned(
              bottom: -80,
              right: -60,
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _C.red.withValues(alpha: (_pulse.value * 0.05)),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Rotating orbit ring (background) ──────────
          AnimatedBuilder(
            animation: _orbit,
            builder: (_, __) => Positioned(
              top: h * 0.06,
              left: MediaQuery.of(context).size.width * 0.5 - 140,
              child: Transform.rotate(
                angle: _orbit.value * 2 * math.pi,
                child: Container(
                  width: 280,
                  height: 280,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: SweepGradient(
                      colors: [
                        Colors.transparent,
                        _C.red.withValues(alpha: 0.05),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── Main content ───────────────────────────────
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    SizedBox(height: h * 0.04),

                    // ── Logo ──────────────────────────
                    FadeTransition(
                      opacity: _logoFade,
                      child: ScaleTransition(
                        scale: _logoScale,
                        child: Column(
                          children: [
                            // Logo image
                            SizedBox(
                              width: 110,
                              height: 110,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  // Glow ring behind logo
                                  AnimatedBuilder(
                                    animation: _pulse,
                                    builder: (_, __) => Container(
                                      width: 110,
                                      height: 110,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: _C.red.withValues(
                                                alpha: _pulse.value * 0.25),
                                            blurRadius: 30,
                                            spreadRadius: 0,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  ClipOval(
                                    child: Image.asset(
                                      'assets/images/logo.png',
                                      width: 100,
                                      height: 100,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // App name
                            const Text(
                              "DarkVerse",
                              style: TextStyle(
                                color: _C.white,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 28,
                                letterSpacing: 6,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "A P P S   S Y S T E M",
                              style: TextStyle(
                                color: _C.red.withValues(alpha: 0.7),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 4,
                              ),
                            ),
                            const SizedBox(height: 18),

                            // Thin red divider
                            Container(
                              width: 40,
                              height: 1.5,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Colors.transparent,
                                  _C.red,
                                  Colors.transparent,
                                ]),
                                borderRadius: BorderRadius.circular(1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(height: h * 0.04),

                    // ── Form ──────────────────────────
                    FadeTransition(
                      opacity: _formFade,
                      child: SlideTransition(
                        position: _formSlide,
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Section label
                              Row(
                                children: [
                                  Container(
                                    width: 3,
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: _C.red,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    "SIGN IN",
                                    style: TextStyle(
                                      color: _C.muted,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                      letterSpacing: 3,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 20),

                              // Username field
                              _ModernField(
                                controller: userController,
                                hint: "Username",
                                icon: Icons.person_outline_rounded,
                                validator: (v) => (v == null || v.trim().isEmpty)
                                    ? "Username wajib diisi"
                                    : null,
                              ),

                              const SizedBox(height: 12),

                              // Password field
                              _ModernField(
                                controller: passController,
                                hint: "Password",
                                icon: Icons.lock_outline_rounded,
                                obscure: _obscurePass,
                                validator: (v) => (v == null || v.trim().isEmpty)
                                    ? "Password wajib diisi"
                                    : null,
                                suffix: GestureDetector(
                                  onTap: () => setState(
                                      () => _obscurePass = !_obscurePass),
                                  child: Icon(
                                    _obscurePass
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                    color: _C.muted,
                                    size: 18,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 28),

                              // Login button
                              _LoginButton(
                                  isLoading: isLoading, onTap: _login),

                              const SizedBox(height: 20),

                              // Purchase link
                              Center(
                                child: GestureDetector(
                                  onTap: () => launchUrl(
                                    Uri.parse("https://t.me/Fahri_Reals01"),
                                    mode: LaunchMode.externalApplication,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        "Belum punya akses? ",
                                        style: TextStyle(
                                          color: _C.muted,
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                      Text(
                                        "Beli Disini",
                                        style: TextStyle(
                                          color: _C.red,
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.w700,
                                          decoration: TextDecoration.underline,
                                          decorationColor: _C.red,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: h * 0.06),

                    // Footer
                    FadeTransition(
                      opacity: _formFade,
                      child: Column(
                        children: [
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.transparent,
                                _C.line,
                                Colors.transparent,
                              ]),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            "By continuing you agree to our Terms of Service",
                            style: TextStyle(
                              color: _C.muted.withValues(alpha: 0.5),
                              fontSize: 10,
                              letterSpacing: 0.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "v 7.5",
                            style: TextStyle(
                              color: _C.red.withValues(alpha: 0.3),
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 3,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// WIDGET COMPONENTS
// ════════════════════════════════════════════════════════════

class _ModernField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;

  const _ModernField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.validator,
  });

  @override
  State<_ModernField> createState() => _ModernFieldState();
}

class _ModernFieldState extends State<_ModernField> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused
              ? _C.red.withValues(alpha: 0.45)
              : _C.line,
          width: _focused ? 1.5 : 1,
        ),
        boxShadow: _focused
            ? [
                BoxShadow(
                  color: _C.red.withValues(alpha: 0.08),
                  blurRadius: 20,
                  spreadRadius: 0,
                )
              ]
            : [],
      ),
      child: Focus(
        onFocusChange: (v) => setState(() => _focused = v),
        child: TextFormField(
          controller: widget.controller,
          obscureText: widget.obscure,
          style: const TextStyle(
            color: _C.white,
            fontSize: 15,
            fontFamily: 'ShareTechMono',
          ),
          cursorColor: _C.red,
          cursorWidth: 1.5,
          validator: widget.validator,
          decoration: InputDecoration(
            hintText: widget.hint,
            hintStyle: TextStyle(
              color: _C.muted.withValues(alpha: 0.6),
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
            prefixIcon: Padding(
              padding: const EdgeInsets.only(left: 16, right: 12),
              child: Icon(
                widget.icon,
                color: _focused ? _C.red : _C.muted,
                size: 18,
              ),
            ),
            prefixIconConstraints: const BoxConstraints(),
            suffixIcon: widget.suffix != null
                ? Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: widget.suffix,
                  )
                : null,
            suffixIconConstraints: const BoxConstraints(),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 18),
            errorStyle: const TextStyle(
              color: _C.red,
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Login Button ────────────────────────────────────────────
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;
  const _LoginButton({required this.isLoading, required this.onTap});

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 130),
        height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: widget.isLoading
                ? [_C.redDark, _C.redDark]
                : _pressed
                    ? [_C.red.withValues(alpha: 0.7), _C.redDark]
                    : [_C.red, _C.redDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: (widget.isLoading || _pressed)
              ? []
              : [
                  BoxShadow(
                    color: _C.red.withValues(alpha: 0.3),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                  BoxShadow(
                    color: _C.red.withValues(alpha: 0.1),
                    blurRadius: 50,
                    spreadRadius: 5,
                  ),
                ],
        ),
        child: Center(
          child: widget.isLoading
              ? SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                        Colors.white.withValues(alpha: 0.8)),
                  ),
                )
              : const Text(
                  "LOGIN",
                  style: TextStyle(
                    color: _C.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 4,
                  ),
                ),
        ),
      ),
    );
  }
}

// ─── Dialog Button ───────────────────────────────────────────
class _DialogBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool isPrimary;
  const _DialogBtn(
      {required this.label, required this.onTap, required this.isPrimary});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: isPrimary ? _C.red.withValues(alpha: 0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isPrimary
                ? _C.red.withValues(alpha: 0.35)
                : _C.line,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isPrimary ? _C.red : _C.muted,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 11,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}
