import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}
val releaseSigningKeys = listOf("keyAlias", "keyPassword", "storeFile", "storePassword")
val releaseStorePath = keystoreProperties.getProperty("storeFile")?.trim()
val releaseStoreFile = releaseStorePath
    ?.takeIf { it.isNotEmpty() }
    ?.let { file(it) }
val hasReleaseSigning = keystorePropertiesFile.exists() &&
    releaseSigningKeys.all { !keystoreProperties.getProperty(it).isNullOrBlank() } &&
    releaseStoreFile?.isFile == true

android {
    namespace = "com.aiauto.claw"
    buildFeatures {
        buildConfig = true
    }
    compileSdk = 36
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.aiauto.claw.full"
        minSdk = 24
        targetSdk = 28
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        buildConfigField("boolean", "FULL_LINUX_EDITION", "true")
    }

    signingConfigs {
        create("release") {
            if (hasReleaseSigning) {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = releaseStoreFile
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        release {
            isDebuggable = false
            isJniDebuggable = false
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                logger.warn(
                    "Tiada key.properties lengkap atau fail keystore tidak ditemui; " +
                        "artifact buildType release menggunakan debug key untuk ujian sahaja."
                )
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.webkit:webkit:1.14.0")
}

// Flutter memproses pubspec assets di dalam task compileFlutterBuild*. Panel
// binaan yang memanggil `flutter build` secara terus tidak melalui skrip shell
// projek, jadi runtime Linux mesti disediakan sebagai dependency Gradle juga.
val flutterProjectDir = rootProject.projectDir.parentFile
val repositoryDir = flutterProjectDir.parentFile
val linuxRuntimeBuilder = repositoryDir.resolve("scripts/linux/prepare_bundled_runtime.py")
val linuxRuntimeAssetDir = flutterProjectDir.resolve("assets/linux/full")
val linuxRuntimePack = linuxRuntimeAssetDir.resolve("runtime-pack.zip")
val linuxRuntimeManifest = linuxRuntimeAssetDir.resolve("runtime-manifest.json")
val linuxRuntimeChecksum = linuxRuntimeAssetDir.resolve("runtime-pack.sha256")
val pythonExecutable = System.getenv("PYTHON")
    ?.trim()
    ?.takeIf { it.isNotEmpty() }
    ?: if (System.getProperty("os.name").lowercase().contains("windows")) {
        "python"
    } else {
        "python3"
    }

val prepareBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "build setup"
    description = "Muat turun, sahkan dan bina asset Linux ARM64 sebelum Flutter membungkus assets."
    workingDir(repositoryDir)
    commandLine(pythonExecutable, linuxRuntimeBuilder.absolutePath)
    environment("PYTHONUNBUFFERED", "1")

    inputs.file(linuxRuntimeBuilder)
    inputs.dir(repositoryDir.resolve("scripts/linux/licenses"))
    outputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }

    doFirst {
        if (!linuxRuntimeBuilder.isFile) {
            throw GradleException("Pembina runtime Linux tiada: $linuxRuntimeBuilder")
        }
        linuxRuntimeAssetDir.mkdirs()
    }
}

val verifyBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "verification"
    description = "Sahkan runtime Linux yang akan dibundel ialah ZIP Alpine/PRoot ARM64 yang lengkap."
    dependsOn(prepareBundledLinuxRuntime)
    workingDir(repositoryDir)
    commandLine(
        pythonExecutable,
        linuxRuntimeBuilder.absolutePath,
        "--verify-only",
        "--output",
        linuxRuntimePack.absolutePath,
    )
    environment("PYTHONUNBUFFERED", "1")
    inputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }
}

// Dependency terus pada compileFlutterBuild* penting: `preBuild` sahaja tidak
// menjamin runtime siap sebelum Flutter memeriksa pubspec.yaml.
tasks.configureEach {
    if (name.startsWith("compileFlutterBuild")) {
        dependsOn(verifyBundledLinuxRuntime)
    }
}

// Sesetengah panel binaan pihak ketiga memaksa `flutter build apk --debug`
// dan hanya mengambil app-debug.apk. Untuk projek edaran peribadi ini, pastikan
// permintaan tersebut tetap menghasilkan bytecode/AOT buildType release.
// app-release.apk dikekalkan, manakala app-debug.apk diganti dengan salinan
// artifact release supaya panel yang hard-code nama debug tidak menghantar
// binaan debug sebenar.
val releaseApkForForcedDebugBuilder by tasks.registering {
    group = "build"
    description = "Bina release dan salin artifactnya ke nama output debug untuk builder yang memaksa debug."
    dependsOn("assembleRelease")

    doLast {
        val flutterApkDir = layout.buildDirectory.dir("outputs/flutter-apk").get().asFile
        val releaseApk = flutterApkDir.resolve("app-release.apk")
        val debugApk = flutterApkDir.resolve("app-debug.apk")

        if (!releaseApk.isFile || releaseApk.length() == 0L) {
            throw GradleException("APK release tidak dijana: $releaseApk")
        }

        releaseApk.copyTo(debugApk, overwrite = true)
        logger.lifecycle(
            "Builder meminta debug; app-debug.apk telah diganti dengan artifact buildType release: $releaseApk"
        )
    }
}

tasks.configureEach {
    if (name == "assembleDebug") {
        finalizedBy(releaseApkForForcedDebugBuilder)
    }
}
