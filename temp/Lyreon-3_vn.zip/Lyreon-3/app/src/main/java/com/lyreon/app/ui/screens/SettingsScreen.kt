package com.lyreon.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lyreon.app.R
import com.lyreon.app.core.LocaleHelper
import com.lyreon.app.data.settings.AudioQuality
import com.lyreon.app.ui.theme.LyreonTextSecondary
import com.lyreon.app.ui.theme.LyreonTextPrimary
import com.lyreon.app.ui.theme.LyreonLine
import com.lyreon.app.ui.theme.LyreonSurface
import com.lyreon.app.ui.theme.LyreonBackground
import com.lyreon.app.ui.theme.LyreonCrimson
import com.lyreon.app.ui.theme.LyreonTextMuted
import com.lyreon.app.ui.theme.ThemeMode
import com.lyreon.app.ui.vm.SettingsViewModel

@Composable
fun SettingsScreen(
    vm: SettingsViewModel,
    modifier: Modifier = Modifier,
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(LyreonBackground),
        contentPadding = PaddingValues(bottom = 96.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 28.dp)) {
                Text(stringResource(R.string.settings_kicker), style = MaterialTheme.typography.labelMedium, color = LyreonTextSecondary)
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.settings_title),
                    style = MaterialTheme.typography.displaySmall,
                    color = LyreonTextPrimary,
                )
                Spacer(Modifier.height(8.dp))
                Box(Modifier.width(40.dp).height(2.dp).background(LyreonCrimson))
            }
        }

        // ---- Profil: nama sapaan (disambut di Home) ----
        item {
            ProfileSection(
                displayName = settings.displayName.ifBlank { "Farizy" },
                onSave = vm::setDisplayName,
            )
        }

        item {
            SettingSection(stringResource(R.string.sec_appearance)) {
                Text(stringResource(R.string.theme_label), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Spacer(Modifier.height(10.dp))
                SegmentedRow(
                    options = listOf(
                        ThemeMode.DARK to stringResource(R.string.theme_dark),
                        ThemeMode.LIGHT to stringResource(R.string.theme_light),
                        ThemeMode.SYSTEM to stringResource(R.string.theme_system),
                    ),
                    selected = settings.themeMode,
                    onSelect = vm::setTheme,
                )
                Spacer(Modifier.height(18.dp))
                Text(stringResource(R.string.accent_label), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Spacer(Modifier.height(10.dp))
                AccentPicker(
                    currentArgb = settings.accentArgb,
                    onPick = vm::setAccent,
                )
                Spacer(Modifier.height(18.dp))
                Text(stringResource(R.string.font_label), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Spacer(Modifier.height(10.dp))
                FontPicker(
                    currentKey = settings.fontKey,
                    onPick = vm::setFont,
                )
            }
        }

        item {
            SettingSection(stringResource(R.string.sec_audio)) {
                Text(stringResource(R.string.quality_label), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.quality_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = LyreonTextMuted,
                )
                Spacer(Modifier.height(10.dp))
                SegmentedRow(
                    options = listOf(
                        AudioQuality.HIGH to stringResource(R.string.quality_high),
                        AudioQuality.BALANCED to stringResource(R.string.quality_balanced),
                        AudioQuality.DATA_SAVER to stringResource(R.string.quality_saver),
                    ),
                    selected = settings.audioQuality,
                    onSelect = vm::setQuality,
                )
            }
        }

        item {
            SettingSection(stringResource(R.string.sec_playback)) {
                ToggleRow(
                    title = stringResource(R.string.autoplay_title),
                    body = stringResource(R.string.autoplay_body),
                    checked = settings.autoplayRelated,
                    onChange = vm::setAutoplay,
                )
                Spacer(Modifier.height(14.dp))
                ToggleRow(
                    title = stringResource(R.string.reduce_title),
                    body = stringResource(R.string.reduce_body),
                    checked = settings.reduceMotion,
                    onChange = vm::setReduceMotion,
                )
            }
        }

        item {
            LanguageSection()
        }

        item {
            SettingSection(stringResource(R.string.sec_data)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LyreonLine)
                        .background(LyreonSurface.copy(alpha = 0.3f))
                        .clickable { confirmClear = true }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.clear_history_title), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                        Text(
                            stringResource(R.string.clear_history_body),
                            style = MaterialTheme.typography.bodySmall,
                            color = LyreonTextMuted,
                        )
                    }
                    Text(stringResource(R.string.action_delete), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson)
                }
            }
        }

        item {
            SettingSection(stringResource(R.string.sec_about)) {
                Text(stringResource(R.string.about_version, "3.4.2"), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.about_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = LyreonTextSecondary,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    stringResource(R.string.about_engine),
                    style = MaterialTheme.typography.labelSmall,
                    color = LyreonTextMuted,
                )
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier
                        .border(1.dp, LyreonLine)
                        .clickable {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://achfarizy.biz.id")),
                                )
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Text(stringResource(R.string.about_website), style = MaterialTheme.typography.labelMedium, color = LyreonTextPrimary)
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .border(1.dp, LyreonCrimson)
                        .clickable {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://saweria.co/riznotdev")),
                                )
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Text(stringResource(R.string.about_donate), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson)
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    stringResource(R.string.about_legal),
                    style = MaterialTheme.typography.labelSmall,
                    color = LyreonTextMuted,
                )
            }
        }
    }

    if (confirmClear) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = com.lyreon.app.ui.theme.LyreonElevated,
            title = { Text(stringResource(R.string.clear_history_confirm), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson) },
            text = {
                Text(stringResource(R.string.clear_history_confirm_body), style = MaterialTheme.typography.bodyMedium, color = LyreonTextSecondary)
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    vm.clearHistory()
                    confirmClear = false
                }) { Text(stringResource(R.string.clear_history_yes), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson) }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { confirmClear = false }) {
                    Text(stringResource(R.string.action_cancel), style = MaterialTheme.typography.labelMedium, color = LyreonTextSecondary)
                }
            },
        )
    }
}

/** Profil: nama yang disapa di halaman Home. */
@Composable
private fun ProfileSection(
    displayName: String,
    onSave: (String) -> Unit,
) {
    var editing by remember { mutableStateOf(false) }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.settings_profile), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(1.dp).background(LyreonLine))
        }
        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, LyreonLine)
                .background(LyreonSurface.copy(alpha = 0.3f))
                .clickable { editing = true }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(displayName, style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
                Text(
                    stringResource(R.string.name_edit_body),
                    style = MaterialTheme.typography.bodySmall,
                    color = LyreonTextMuted,
                )
            }
            Text("✎", style = MaterialTheme.typography.titleMedium, color = LyreonCrimson)
        }
    }

    if (editing) {
        var name by remember { mutableStateOf(displayName) }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { editing = false },
            containerColor = com.lyreon.app.ui.theme.LyreonElevated,
            title = { Text(stringResource(R.string.name_edit_title), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson) },
            text = {
                androidx.compose.material3.OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 24) name = it },
                    singleLine = true,
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LyreonCrimson,
                        unfocusedBorderColor = LyreonLine,
                        cursorColor = LyreonTextPrimary,
                        focusedTextColor = LyreonTextPrimary,
                        unfocusedTextColor = LyreonTextPrimary,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    if (name.isNotBlank()) {
                        onSave(name.trim())
                        editing = false
                    }
                }) { Text(stringResource(R.string.action_save), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson) }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { editing = false }) {
                    Text(stringResource(R.string.action_cancel), style = MaterialTheme.typography.labelMedium, color = LyreonTextSecondary)
                }
            },
        )
    }
}

/** Deretan swatch aksen + slider HSV untuk pilihan bebas. */
@Composable
private fun AccentPicker(
    currentArgb: Int,
    onPick: (Int) -> Unit,
) {
    val presets = listOf(
        intArrayOf(0xFF, 0xE9, 0x45, 0x60),
        intArrayOf(0xFF, 0xFF, 0x52, 0x52),
        intArrayOf(0xFF, 0xFF, 0x70, 0x43),
        intArrayOf(0xFF, 0xFF, 0xB3, 0x00),
        intArrayOf(0xFF, 0x9C, 0xCC, 0x65),
        intArrayOf(0xFF, 0x26, 0xA6, 0x9A),
        intArrayOf(0xFF, 0x29, 0xB6, 0xF6),
        intArrayOf(0xFF, 0x5C, 0x6B, 0xC0),
        intArrayOf(0xFF, 0xAB, 0x47, 0xBC),
        intArrayOf(0xFF, 0xEC, 0x40, 0x7A),
        intArrayOf(0xFF, 0xB0, 0xBE, 0xC5),
    )
    fun argb(a: IntArray): Int =
        (a[0] shl 24) or (a[1] shl 16) or (a[2] shl 8) or a[3]

    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        val defaultArgb = argb(intArrayOf(0xFF, 0xE9, 0x45, 0x60))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(androidx.compose.ui.graphics.Color(defaultArgb))
                    .border(
                        width = if (currentArgb < 0) 3.dp else 1.dp,
                        color = if (currentArgb < 0) LyreonTextPrimary else LyreonLine,
                        shape = androidx.compose.foundation.shape.CircleShape,
                    )
                    .clickable { onPick(-1) },
            )
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.accent_default),
                style = MaterialTheme.typography.labelSmall,
                color = if (currentArgb < 0) LyreonTextPrimary else LyreonTextMuted,
            )
        }
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(presets.size) { i ->
                val c = argb(presets[i])
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(androidx.compose.ui.graphics.Color(c))
                        .border(
                            width = if (currentArgb == c) 3.dp else 1.dp,
                            color = if (currentArgb == c) LyreonTextPrimary else LyreonLine,
                            shape = androidx.compose.foundation.shape.CircleShape,
                        )
                        .clickable { onPick(c) },
                )
            }
        }
    }

    Spacer(Modifier.height(14.dp))
    Text(stringResource(R.string.accent_custom), style = MaterialTheme.typography.labelMedium, color = LyreonTextSecondary)
    Spacer(Modifier.height(6.dp))

    // Slider HSV — pratinjau langsung saat digeser
    val initHsv = remember(currentArgb) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(
            if (currentArgb >= 0) currentArgb else argb(intArrayOf(0xFF, 0xE9, 0x45, 0x60)),
            hsv,
        )
        hsv
    }
    var hue by remember { mutableFloatStateOf(initHsv[0]) }
    var sat by remember { mutableFloatStateOf(initHsv[1]) }
    var value by remember { mutableFloatStateOf(initHsv[2]) }
    val preview = androidx.compose.ui.graphics.Color.hsv(hue, sat, value)

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(preview)
                .border(1.dp, LyreonLine, androidx.compose.foundation.shape.CircleShape),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            androidx.compose.material3.Slider(
                value = hue, onValueChange = { hue = it }, valueRange = 0f..360f,
                colors = androidx.compose.material3.SliderDefaults.colors(
                    thumbColor = LyreonTextPrimary, activeTrackColor = preview, inactiveTrackColor = LyreonSurface,
                ),
            )
            androidx.compose.material3.Slider(
                value = sat, onValueChange = { sat = it }, valueRange = 0f..1f,
                colors = androidx.compose.material3.SliderDefaults.colors(
                    thumbColor = LyreonTextPrimary, activeTrackColor = LyreonCrimson, inactiveTrackColor = LyreonSurface,
                ),
            )
            androidx.compose.material3.Slider(
                value = value, onValueChange = { value = it }, valueRange = 0f..1f,
                colors = androidx.compose.material3.SliderDefaults.colors(
                    thumbColor = LyreonTextPrimary, activeTrackColor = LyreonCrimson, inactiveTrackColor = LyreonSurface,
                ),
            )
        }
    }
    Spacer(Modifier.height(8.dp))
    Text(
        stringResource(R.string.accent_apply),
        style = MaterialTheme.typography.labelMedium,
        color = LyreonCrimson,
        modifier = Modifier
            .border(1.dp, LyreonCrimson)
            .clickable {
                var argb = ((255) shl 24) or
                    ((preview.red * 255f).toInt() shl 16) or
                    ((preview.green * 255f).toInt() shl 8) or
                    (preview.blue * 255f).toInt()
                // Putih penuh (0xFFFFFFFF) == -1 == sentinel "bawaan" → geser 1 unit
                if (argb == -1) argb = -2
                onPick(argb)
            }
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

/** Pilihan jenis huruf — label ditampilkan DALAM hurufnya sendiri. */
@Composable
private fun FontPicker(
    currentKey: String,
    onPick: (String) -> Unit,
) {
    val options = listOf(
        "default" to stringResource(R.string.font_default),
        "serif" to "Serif",
        "mono" to "Mono",
        "cursive" to "Cursive",
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (key, label) ->
            val active = key == currentKey
            Box(
                modifier = Modifier
                    .border(1.dp, if (active) LyreonCrimson else LyreonLine)
                    .background(
                        if (active) LyreonCrimson.copy(alpha = 0.18f)
                        else LyreonSurface.copy(alpha = 0.25f),
                    )
                    .clickable { onPick(key) }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = com.lyreon.app.ui.theme.fontFamilyForKey(key),
                    color = if (active) LyreonTextPrimary else LyreonTextSecondary,
                )
            }
        }
    }
}

@Composable
private fun SettingSection(
    title: String,
    content: @Composable () -> Unit,
) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = LyreonCrimson)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(1.dp).background(LyreonLine))
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun <T> SegmentedRow(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            val active = value == selected
            Box(
                modifier = Modifier
                    .border(1.dp, if (active) LyreonCrimson else LyreonLine)
                    .background(
                        if (active) LyreonCrimson.copy(alpha = 0.18f)
                        else LyreonSurface.copy(alpha = 0.25f),
                    )
                    .clickable { onSelect(value) }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (active) LyreonTextPrimary else LyreonTextSecondary,
                )
            }
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    body: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, LyreonLine)
            .background(LyreonSurface.copy(alpha = 0.3f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
            Text(body, style = MaterialTheme.typography.bodySmall, color = LyreonTextMuted)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = LyreonTextPrimary,
                checkedTrackColor = LyreonCrimson,
                uncheckedThumbColor = LyreonTextSecondary,
                uncheckedTrackColor = LyreonSurface,
            ),
        )
    }
}


/** Pemilih bahasa — langsung recreate activity agar locale baru aktif. */
@Composable
private fun LanguageSection() {
    val context = LocalContext.current
    val current = LocaleHelper.currentTag(context)
    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.sec_language), style = MaterialTheme.typography.labelMedium, color = LyreonCrimson)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(1.dp).background(LyreonLine))
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.language_label), style = MaterialTheme.typography.titleSmall, color = LyreonTextPrimary)
        Spacer(Modifier.height(10.dp))
        LocaleHelper.SUPPORTED.forEach { lang ->
            val active = lang.tag == current
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (active) LyreonCrimson else LyreonLine,
                        RoundedCornerShape(12.dp),
                    )
                    .background(if (active) LyreonCrimson.copy(alpha = 0.15f) else LyreonSurface.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .clickable {
                        LocaleHelper.set(context, lang.tag)
                        findActivity(context)?.recreate()
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    lang.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = LyreonTextPrimary,
                    modifier = Modifier.weight(1f),
                )
                if (active) {
                    Text("✓", style = MaterialTheme.typography.titleSmall, color = LyreonCrimson)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun findActivity(context: android.content.Context): android.app.Activity? {
    var ctx = context
    while (ctx is android.content.ContextWrapper) {
        if (ctx is android.app.Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
