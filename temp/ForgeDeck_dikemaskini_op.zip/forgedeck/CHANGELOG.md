# Changelog

## 0.1.3

- Membetulkan AAPT pada `launch_background.xml` dengan rujukan `@color/launch_background`.
- Menetapkan Kotlin Gradle Plugin 2.2.20 dalam `settings.gradle` untuk Flutter 3.44.
- Menaikkan `minSdk` daripada 23 kepada 24.
- Menambah flag template Flutter `android.newDsl=false` dan `android.builtInKotlin=false`.

## 0.1.2

- Membuang semua Flutter plugin Android pihak ketiga yang mencetuskan auto-downgrade build.
- Menukar lapisan native daripada Kotlin kepada Java.
- Menambah pemilih fail Storage Access Framework melalui MethodChannel.
- Menambah penyimpanan PAT AES-GCM menggunakan Android Keystore.
- Menambah permintaan izin storan legacy dan pautan tetapan aplikasi secara native.
- Mengunci API 36, AGP 8.12.1, Gradle 8.14 dan Java 17 melalui build guard.

## 0.1.0

- Multi-akaun PAT dengan secure storage.
- Senarai repository dan pull-to-refresh.
- Pengurusan repository, branch, fail, isu, pull request, Actions dan release.
- Force push ZIP melalui Git Database API.
- Ikon dan tema ForgeDeck tersuai.
