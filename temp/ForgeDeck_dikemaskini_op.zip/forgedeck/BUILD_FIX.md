# ForgeDeck Android build configuration

Pinned configuration:

- Flutter 3.44.x
- compileSdk / targetSdk 36
- minSdk 24
- Android Gradle Plugin 8.12.1
- Kotlin Gradle Plugin 2.2.20 (declared, not applied to the Java-only app module)
- Gradle 8.14
- Java 17

The launch drawable references `@color/launch_background`; raw hexadecimal colors are not placed in `android:drawable`.
