import 'package:flutter_test/flutter_test.dart';
import 'package:forgedeck/core/storage/zip_service.dart';

void main() {
  test('normalize path converts separators', () {
    expect(ZipService.normalizeZipPath(r'root\lib\main.dart'), 'root/lib/main.dart');
  });

  test('normalize path rejects traversal', () {
    expect(
      () => ZipService.normalizeZipPath('../secret.txt'),
      throwsA(isA<ZipPlanException>()),
    );
  });
}
