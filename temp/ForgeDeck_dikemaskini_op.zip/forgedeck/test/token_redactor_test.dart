import 'package:flutter_test/flutter_test.dart';
import 'package:forgedeck/core/utils/token_redactor.dart';

void main() {
  test('redacts common PAT formats', () {
    final classic = <String>['ghp_', '1234567890ABCDEFGHIJ'].join();
    final fineGrained = <String>[
      'github_',
      'pat_',
      '1234567890_ABCDEFGHIJ',
    ].join();

    expect(TokenRedactor.redact('Authorization $classic'), isNot(contains('ghp_')));
    expect(
      TokenRedactor.redact(fineGrained),
      isNot(contains('github_pat_')),
    );
  });
}
