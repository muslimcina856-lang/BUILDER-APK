# Polisi keselamatan

## Rahsia

Jangan commit PAT, token bot, signing key atau credential lain. Jika credential pernah dihantar melalui chat, issue, log atau commit, anggap ia bocor dan revoke segera.

## Reka bentuk token

- PAT dan metadata akaun dienkripsi menggunakan AES-GCM.
- Kunci AES dijana dan disimpan dalam Android Keystore.
- Metadata akaun dan token disimpan sebagai rekod berasingan.
- Token tidak dipaparkan semula selepas disimpan.
- Client HTTP tidak memasang log interceptor.
- Header Authorization menggunakan `Bearer`.
- Force push tidak menyelitkan token dalam remote URL.
- Android backup dimatikan bagi mengelakkan ciphertext dipulihkan tanpa kunci Keystore asal.

## Akses fail

- Fail dipilih menggunakan Storage Access Framework.
- Kandungan yang dipilih disalin ke cache peribadi aplikasi.
- Tiada `MANAGE_EXTERNAL_STORAGE`.
- Nama fail dibersihkan sebelum digunakan sebagai nama fail cache.
- Saiz sumber pemilih dihadkan kepada 512 MB.

## Operasi destruktif

Force push dan delete repository memerlukan pengesahan teks. GitHub masih boleh menolak tindakan berdasarkan permission PAT, branch protection, ruleset atau polisi organisasi.

## Laporan isu

Semasa melaporkan bug, padam semua token, authorization header, URL yang mengandungi credential dan data repository private.
