import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import 'accounts_screen.dart';
import 'activity_screen.dart';
import 'repositories_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final pages = <Widget>[
      const RepositoriesScreen(),
      const ActivityScreen(),
      const AccountsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        backgroundColor: AppColors.surface,
        indicatorColor: AppColors.accentSoft,
        destinations: <NavigationDestination>[
          const NavigationDestination(
            icon: Icon(Icons.folder_copy_outlined),
            selectedIcon: Icon(Icons.folder_copy_rounded, color: AppColors.accent),
            label: 'Repos',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: controller.notifications.isNotEmpty,
              label: Text(controller.notifications.length.toString()),
              child: const Icon(Icons.notifications_none_rounded),
            ),
            selectedIcon: const Icon(Icons.notifications_rounded, color: AppColors.accent),
            label: 'Aktiviti',
          ),
          const NavigationDestination(
            icon: Icon(Icons.people_outline_rounded),
            selectedIcon: Icon(Icons.people_rounded, color: AppColors.accent),
            label: 'Akaun',
          ),
          const NavigationDestination(
            icon: Icon(Icons.tune_rounded),
            selectedIcon: Icon(Icons.tune_rounded, color: AppColors.accent),
            label: 'Tetapan',
          ),
        ],
      ),
    );
  }
}
