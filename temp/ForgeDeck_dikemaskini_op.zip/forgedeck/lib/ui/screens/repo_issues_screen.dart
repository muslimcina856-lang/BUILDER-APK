import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_branch.dart';
import '../../models/github_issue.dart';
import '../../models/github_repo.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class RepoIssuesScreen extends StatefulWidget {
  const RepoIssuesScreen({
    required this.repo,
    required this.branch,
    required this.branches,
    super.key,
  });

  final GitHubRepo repo;
  final String branch;
  final List<GitHubBranch> branches;

  @override
  State<RepoIssuesScreen> createState() => _RepoIssuesScreenState();
}

class _RepoIssuesScreenState extends State<RepoIssuesScreen> {
  String _mode = 'issues';
  String _state = 'open';
  List<GitHubIssue> _items = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RepoIssuesScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.branch != widget.branch ||
        oldWidget.repo.fullName != widget.repo.fullName) {
      _load();
    }
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    try {
      final api = AppScope.of(context, listen: false).api;
      final items = _mode == 'issues'
          ? await api.listIssues(widget.repo.owner, widget.repo.name, state: _state)
          : await api.listPullRequests(widget.repo.owner, widget.repo.name, state: _state);
      if (mounted) {
        setState(() {
          _items = _mode == 'issues'
              ? items.where((item) => !item.isPullRequest).toList()
              : items;
          _error = null;
        });
      }
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _create() async {
    if (_mode == 'issues') {
      final data = await showDialog<_IssueDraft>(
        context: context,
        builder: (_) => const _IssueDialog(),
      );
      if (data == null || !mounted) return;
      try {
        await AppScope.of(context, listen: false).api.createIssue(
              widget.repo.owner,
              widget.repo.name,
              title: data.title,
              body: data.body,
            );
        await _load();
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
        }
      }
      return;
    }

    if (widget.branches.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sekurang-kurangnya dua branch diperlukan untuk pull request.')),
      );
      return;
    }
    final data = await showDialog<_PullDraft>(
      context: context,
      builder: (_) => _PullDialog(
        branches: widget.branches,
        defaultBase: widget.repo.defaultBranch,
        defaultHead: widget.branch,
      ),
    );
    if (data == null || !mounted) return;
    try {
      await AppScope.of(context, listen: false).api.createPullRequest(
            widget.repo.owner,
            widget.repo.name,
            title: data.title,
            body: data.body,
            head: data.head,
            base: data.base,
            draft: data.draft,
          );
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  Future<void> _openItem(GitHubIssue item) async {
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _IssueDetailSheet(
        repo: widget.repo,
        issue: item,
        isPullRequest: _mode == 'pulls',
      ),
    );
    if (changed == true && mounted) await _load();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: SegmentedButton<String>(
                  segments: const <ButtonSegment<String>>[
                    ButtonSegment(value: 'issues', label: Text('Isu'), icon: Icon(Icons.adjust_rounded)),
                    ButtonSegment(value: 'pulls', label: Text('Pull request'), icon: Icon(Icons.call_merge_rounded)),
                  ],
                  selected: <String>{_mode},
                  onSelectionChanged: (selection) {
                    setState(() => _mode = selection.first);
                    _load();
                  },
                ),
              ),
              const SizedBox(width: 10),
              IconButton.filled(
                onPressed: widget.repo.canPush ? _create : null,
                icon: const Icon(Icons.add_rounded),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              ChoiceChip(
                label: const Text('Terbuka'),
                selected: _state == 'open',
                onSelected: (_) {
                  setState(() => _state = 'open');
                  _load();
                },
              ),
              const SizedBox(width: 8),
              ChoiceChip(
                label: const Text('Semua'),
                selected: _state == 'all',
                onSelected: (_) {
                  setState(() => _state = 'all');
                  _load();
                },
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            EmptyState(
              icon: Icons.error_outline_rounded,
              title: 'Gagal memuat data',
              message: _error!,
              action: OutlinedButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Cuba lagi'),
              ),
            )
          else if (_items.isEmpty)
            EmptyState(
              icon: _mode == 'issues' ? Icons.adjust_rounded : Icons.call_merge_rounded,
              title: _mode == 'issues' ? 'Tiada isu' : 'Tiada pull request',
              message: 'Tiada item untuk penapis semasa.',
            )
          else
            Panel(
              padding: EdgeInsets.zero,
              child: ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final item = _items[index];
                  final open = item.state == 'open';
                  return ListTile(
                    onTap: () => _openItem(item),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    leading: Icon(
                      _mode == 'issues' ? Icons.adjust_rounded : Icons.call_merge_rounded,
                      color: open ? AppColors.accent : AppColors.muted,
                    ),
                    title: Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Text(
                        '#${item.number} oleh ${item.author} - ${timeAgo(item.createdAt)}',
                      ),
                    ),
                    trailing: item.comments > 0
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              const Icon(Icons.mode_comment_outlined, size: 16),
                              const SizedBox(width: 4),
                              Text(item.comments.toString()),
                            ],
                          )
                        : null,
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _IssueDetailSheet extends StatefulWidget {
  const _IssueDetailSheet({
    required this.repo,
    required this.issue,
    required this.isPullRequest,
  });

  final GitHubRepo repo;
  final GitHubIssue issue;
  final bool isPullRequest;

  @override
  State<_IssueDetailSheet> createState() => _IssueDetailSheetState();
}

class _IssueDetailSheetState extends State<_IssueDetailSheet> {
  bool _busy = false;

  Future<void> _toggleState() async {
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).api.setIssueState(
            widget.repo.owner,
            widget.repo.name,
            widget.issue.number,
            state: widget.issue.state == 'open' ? 'closed' : 'open',
          );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _merge() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Merge pull request?'),
        content: Text('PR #${widget.issue.number} akan digabungkan ke branch sasaran.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Merge')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).api.mergePullRequest(
            widget.repo.owner,
            widget.repo.name,
            widget.issue.number,
            commitTitle: widget.issue.title,
          );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                StatusPill(
                  label: widget.issue.state == 'open' ? 'Terbuka' : 'Ditutup',
                  color: widget.issue.state == 'open' ? AppColors.accent : AppColors.muted,
                ),
                const Spacer(),
                Text('#${widget.issue.number}', style: const TextStyle(color: AppColors.muted)),
              ],
            ),
            const SizedBox(height: 16),
            Text(widget.issue.title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(
              'oleh ${widget.issue.author} - ${timeAgo(widget.issue.createdAt)}',
              style: const TextStyle(color: AppColors.muted),
            ),
            if (widget.issue.body.isNotEmpty) ...<Widget>[
              const SizedBox(height: 18),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 320),
                child: SingleChildScrollView(
                  child: Text(widget.issue.body, style: const TextStyle(height: 1.5)),
                ),
              ),
            ],
            const SizedBox(height: 20),
            if (widget.isPullRequest && widget.issue.state == 'open')
              FilledButton.icon(
                onPressed: _busy ? null : _merge,
                icon: const Icon(Icons.call_merge_rounded),
                label: const Text('Merge pull request'),
              ),
            if (!widget.isPullRequest) ...<Widget>[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _busy ? null : _toggleState,
                icon: Icon(widget.issue.state == 'open' ? Icons.check_circle_outline : Icons.refresh_rounded),
                label: Text(widget.issue.state == 'open' ? 'Tutup isu' : 'Buka semula'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _IssueDraft {
  const _IssueDraft({required this.title, required this.body});

  final String title;
  final String body;
}

class _IssueDialog extends StatefulWidget {
  const _IssueDialog();

  @override
  State<_IssueDialog> createState() => _IssueDialogState();
}

class _IssueDialogState extends State<_IssueDialog> {
  final _title = TextEditingController();
  final _body = TextEditingController();

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Isu baharu'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(controller: _title, autofocus: true, decoration: const InputDecoration(labelText: 'Tajuk')),
            const SizedBox(height: 10),
            TextField(controller: _body, maxLines: 6, decoration: const InputDecoration(labelText: 'Penerangan')),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        FilledButton(
          onPressed: () {
            if (_title.text.trim().isEmpty) return;
            Navigator.pop(context, _IssueDraft(title: _title.text.trim(), body: _body.text.trim()));
          },
          child: const Text('Cipta isu'),
        ),
      ],
    );
  }
}

class _PullDraft {
  const _PullDraft({
    required this.title,
    required this.body,
    required this.head,
    required this.base,
    required this.draft,
  });

  final String title;
  final String body;
  final String head;
  final String base;
  final bool draft;
}

class _PullDialog extends StatefulWidget {
  const _PullDialog({
    required this.branches,
    required this.defaultBase,
    required this.defaultHead,
  });

  final List<GitHubBranch> branches;
  final String defaultBase;
  final String defaultHead;

  @override
  State<_PullDialog> createState() => _PullDialogState();
}

class _PullDialogState extends State<_PullDialog> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  late String _head;
  late String _base;
  bool _draft = false;

  @override
  void initState() {
    super.initState();
    _head = widget.branches.any((item) => item.name == widget.defaultHead)
        ? widget.defaultHead
        : widget.branches.last.name;
    _base = widget.branches.any((item) => item.name == widget.defaultBase)
        ? widget.defaultBase
        : widget.branches.first.name;
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Pull request baharu'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(controller: _title, decoration: const InputDecoration(labelText: 'Tajuk')),
            const SizedBox(height: 10),
            TextField(controller: _body, maxLines: 4, decoration: const InputDecoration(labelText: 'Penerangan')),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _head,
              decoration: const InputDecoration(labelText: 'Head branch'),
              items: widget.branches
                  .map((branch) => DropdownMenuItem(value: branch.name, child: Text(branch.name)))
                  .toList(),
              onChanged: (value) => setState(() => _head = value ?? _head),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _base,
              decoration: const InputDecoration(labelText: 'Base branch'),
              items: widget.branches
                  .map((branch) => DropdownMenuItem(value: branch.name, child: Text(branch.name)))
                  .toList(),
              onChanged: (value) => setState(() => _base = value ?? _base),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Draft pull request'),
              value: _draft,
              onChanged: (value) => setState(() => _draft = value),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        FilledButton(
          onPressed: () {
            if (_title.text.trim().isEmpty || _head == _base) return;
            Navigator.pop(
              context,
              _PullDraft(
                title: _title.text.trim(),
                body: _body.text.trim(),
                head: _head,
                base: _base,
                draft: _draft,
              ),
            );
          },
          child: const Text('Cipta PR'),
        ),
      ],
    );
  }
}
