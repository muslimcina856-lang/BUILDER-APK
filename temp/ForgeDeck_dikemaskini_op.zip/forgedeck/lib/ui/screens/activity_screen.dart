import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';

class ActivityScreen extends StatelessWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: controller.refreshAll,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: <Widget>[
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 14),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('Aktiviti', style: Theme.of(context).textTheme.headlineMedium),
                          const SizedBox(height: 5),
                          const Text(
                            'Notifikasi daripada akaun aktif.',
                            style: TextStyle(color: AppColors.muted),
                          ),
                        ],
                      ),
                    ),
                    if (controller.notifications.isNotEmpty)
                      TextButton.icon(
                        onPressed: controller.markNotificationsRead,
                        icon: const Icon(Icons.done_all_rounded),
                        label: const Text('Tanda dibaca'),
                      ),
                  ],
                ),
              ),
            ),
            if (controller.notifications.isEmpty)
              const SliverPadding(
                padding: EdgeInsets.all(20),
                sliver: SliverToBoxAdapter(
                  child: EmptyState(
                    icon: Icons.notifications_none_rounded,
                    title: 'Tiada notifikasi',
                    message: 'Tarik ke bawah untuk semak semula.',
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
                sliver: SliverList.separated(
                  itemCount: controller.notifications.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final item = controller.notifications[index];
                    final subject = item['subject'] as Map<String, dynamic>? ?? const {};
                    final repo = item['repository'] as Map<String, dynamic>? ?? const {};
                    final reason = item['reason'] as String? ?? 'notification';
                    return Panel(
                      onTap: () {
                        Navigator.of(context).push<void>(
                          MaterialPageRoute<void>(
                            builder: (_) => _NotificationDetailScreen(item: item),
                          ),
                        );
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: AppColors.accentSoft,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(
                              Icons.notifications_active_outlined,
                              color: AppColors.accent,
                            ),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  subject['title'] as String? ?? 'Aktiviti GitHub',
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  repo['full_name'] as String? ?? '',
                                  style: const TextStyle(color: AppColors.muted),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  reason.replaceAll('_', ' '),
                                  style: const TextStyle(
                                    color: AppColors.accent,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: AppColors.muted,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NotificationDetailScreen extends StatefulWidget {
  const _NotificationDetailScreen({required this.item});

  final Map<String, dynamic> item;

  @override
  State<_NotificationDetailScreen> createState() =>
      _NotificationDetailScreenState();
}

class _NotificationDetailScreenState extends State<_NotificationDetailScreen> {
  bool _loading = true;
  String? _error;
  Map<String, dynamic> _details = const {};

  Map<String, dynamic> get _subject =>
      widget.item['subject'] as Map<String, dynamic>? ?? const {};

  Map<String, dynamic> get _repository =>
      widget.item['repository'] as Map<String, dynamic>? ?? const {};

  Map<String, dynamic> get _subjectDetail =>
      _details['subject_detail'] as Map<String, dynamic>? ?? const {};

  Map<String, dynamic> get _latestComment =>
      _details['latest_comment'] as Map<String, dynamic>? ?? const {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final details = await AppScope.of(context, listen: false)
          .api
          .getNotificationDetails(widget.item);
      if (!mounted) return;
      setState(() => _details = details);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String get _title {
    final original = _subject['title'] as String? ?? '';
    if (original.isNotEmpty) return original;
    return _subjectDetail['title'] as String? ?? 'Aktiviti GitHub';
  }

  String get _body {
    final directBody = _subjectDetail['body'] as String? ?? '';
    if (directBody.trim().isNotEmpty) return directBody;

    final commit = _subjectDetail['commit'] as Map<String, dynamic>?;
    final commitMessage = commit?['message'] as String? ?? '';
    if (commitMessage.trim().isNotEmpty) return commitMessage;

    return _subjectDetail['message'] as String? ?? '';
  }

  String get _latestCommentBody => _latestComment['body'] as String? ?? '';

  String _author(Map<String, dynamic> data) {
    final user = (data['user'] as Map<String, dynamic>?) ??
        (data['author'] as Map<String, dynamic>?) ??
        const <String, dynamic>{};
    return user['login'] as String? ?? '';
  }

  Future<void> _copy() async {
    final reason = (widget.item['reason'] as String? ?? 'notification')
        .replaceAll('_', ' ');
    final repo = _repository['full_name'] as String? ?? '';
    final type = _subject['type'] as String? ?? '';
    final commentAuthor = _author(_latestComment);
    final parts = <String>[
      _title,
      if (repo.isNotEmpty) 'Repository: $repo',
      if (type.isNotEmpty) 'Jenis: $type',
      'Sebab: $reason',
      if (_body.trim().isNotEmpty) _body.trim(),
      if (_latestCommentBody.trim().isNotEmpty)
        '${commentAuthor.isEmpty ? 'Komen terkini' : 'Komen terkini oleh @$commentAuthor'}:\n'
            '${_latestCommentBody.trim()}',
    ];
    await Clipboard.setData(ClipboardData(text: parts.join('\n\n')));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Aktiviti disalin.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final reason = (widget.item['reason'] as String? ?? 'notification')
        .replaceAll('_', ' ');
    final repo = _repository['full_name'] as String? ?? '';
    final type = _subject['type'] as String? ?? '';
    final state = _subjectDetail['state'] as String? ?? '';
    final commentAuthor = _author(_latestComment);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Aktiviti'),
        actions: <Widget>[
          IconButton(
            onPressed: _copy,
            tooltip: 'Salin aktiviti',
            icon: const Icon(Icons.copy_all_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: EmptyState(
                        icon: Icons.error_outline_rounded,
                        title: 'Gagal memuat aktiviti',
                        message: _error!,
                        action: OutlinedButton.icon(
                          onPressed: _load,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Cuba lagi'),
                        ),
                      ),
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
                    children: <Widget>[
                      Text(_title, style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 16),
                      Panel(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            if (repo.isNotEmpty) _DetailLine(label: 'Repository', value: repo),
                            if (type.isNotEmpty) _DetailLine(label: 'Jenis', value: type),
                            _DetailLine(label: 'Sebab', value: reason),
                            if (state.isNotEmpty)
                              _DetailLine(label: 'Status', value: state),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Panel(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('Mesej', style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 12),
                            SelectableText(
                              _body.trim().isEmpty
                                  ? 'GitHub tidak membekalkan kandungan mesej tambahan untuk aktiviti ini.'
                                  : _body.trim(),
                              style: const TextStyle(height: 1.5),
                            ),
                          ],
                        ),
                      ),
                      if (_latestCommentBody.trim().isNotEmpty) ...<Widget>[
                        const SizedBox(height: 14),
                        Panel(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                commentAuthor.isEmpty
                                    ? 'Komen terkini'
                                    : 'Komen terkini oleh @$commentAuthor',
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                              const SizedBox(height: 12),
                              SelectableText(
                                _latestCommentBody.trim(),
                                style: const TextStyle(height: 1.5),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
      ),
    );
  }
}

class _DetailLine extends StatelessWidget {
  const _DetailLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 88,
            child: Text(label, style: const TextStyle(color: AppColors.muted)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}
