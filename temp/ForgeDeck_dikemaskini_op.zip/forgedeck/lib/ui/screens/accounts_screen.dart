import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../models/github_account.dart';
import '../../state/app_scope.dart';
import '../widgets/account_avatar.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class AccountsScreen extends StatelessWidget {
  const AccountsScreen({super.key});

  Future<void> _addAccount(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _AddAccountSheet(),
    );
  }

  Future<void> _remove(BuildContext context, GitHubAccount account) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Buang akaun?'),
        content: Text(
          'Token untuk @${account.login} akan dipadam dari peranti ini. Akaun GitHub sebenar tidak dipadam.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Buang'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await AppScope.of(context, listen: false).removeAccount(account.id);
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    return SafeArea(
      child: CustomScrollView(
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 12),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('Akaun', style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 5),
                        const Text(
                          'Simpan dan tukar PAT tanpa had tetap.',
                          style: TextStyle(color: AppColors.muted),
                        ),
                      ],
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => _addAccount(context),
                    icon: const Icon(Icons.person_add_alt_1_rounded),
                  ),
                ],
              ),
            ),
          ),
          if (controller.accounts.isEmpty)
            const SliverPadding(
              padding: EdgeInsets.all(20),
              sliver: SliverToBoxAdapter(
                child: EmptyState(
                  icon: Icons.people_outline,
                  title: 'Belum ada akaun',
                  message: 'Tambah PAT untuk mula mengurus repository.',
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
              sliver: SliverList.separated(
                itemCount: controller.accounts.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final account = controller.accounts[index];
                  final active = controller.activeAccount?.id == account.id;
                  return Panel(
                    borderColor: active ? AppColors.accent.withValues(alpha: 0.55) : null,
                    onTap: active
                        ? null
                        : () => controller.switchAccount(account.id),
                    child: Row(
                      children: <Widget>[
                        AccountAvatar(
                          url: account.avatarUrl,
                          fallback: account.login,
                          radius: 25,
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                account.displayName,
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                              const SizedBox(height: 3),
                              Text(
                                '@${account.login}',
                                style: const TextStyle(color: AppColors.muted),
                              ),
                              if (active) ...<Widget>[
                                const SizedBox(height: 9),
                                const StatusPill(
                                  label: 'Sedang aktif',
                                  icon: Icons.check_circle_outline_rounded,
                                ),
                              ],
                            ],
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'switch') controller.switchAccount(account.id);
                            if (value == 'remove') _remove(context, account);
                          },
                          itemBuilder: (_) => <PopupMenuEntry<String>>[
                            if (!active)
                              const PopupMenuItem(
                                value: 'switch',
                                child: Text('Jadikan aktif'),
                              ),
                            const PopupMenuItem(
                              value: 'remove',
                              child: Text('Buang dari peranti'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _AddAccountSheet extends StatefulWidget {
  const _AddAccountSheet();

  @override
  State<_AddAccountSheet> createState() => _AddAccountSheetState();
}

class _AddAccountSheetState extends State<_AddAccountSheet> {
  final _token = TextEditingController();
  bool _obscure = true;
  bool _busy = false;

  @override
  void dispose() {
    _token.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final value = _token.text.trim();
    if (value.isEmpty) return;
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).addAccount(value);
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        8,
        20,
        MediaQuery.viewInsetsOf(context).bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Tambah akaun', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          const Text(
            'PAT akan disahkan dahulu sebelum disimpan.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _token,
            obscureText: _obscure,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              labelText: 'Personal access token',
              prefixIcon: const Icon(Icons.key_rounded),
              suffixIcon: IconButton(
                onPressed: () => setState(() => _obscure = !_obscure),
                icon: Icon(
                  _obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _busy ? null : _submit,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.person_add_alt_1_rounded),
            label: const Text('Sahkan dan tambah'),
          ),
        ],
      ),
    );
  }
}
