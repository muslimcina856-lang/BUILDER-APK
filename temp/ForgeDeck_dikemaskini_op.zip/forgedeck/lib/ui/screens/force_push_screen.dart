import 'package:flutter/material.dart';

import '../../core/network/github_api.dart';
import '../../core/storage/zip_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_branch.dart';
import '../../models/github_repo.dart';
import '../../models/zip_plan.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class ForcePushScreen extends StatefulWidget {
  const ForcePushScreen({
    required this.repo,
    required this.branches,
    required this.initialBranch,
    super.key,
  });

  final GitHubRepo repo;
  final List<GitHubBranch> branches;
  final String initialBranch;

  @override
  State<ForcePushScreen> createState() => _ForcePushScreenState();
}

class _ForcePushScreenState extends State<ForcePushScreen> {
  final _zipService = const ZipService();
  final _message = TextEditingController(text: 'Replace branch contents via ForgeDeck');
  final _confirmation = TextEditingController();
  late String _branch;
  ZipPlan? _plan;
  ForcePushProgress? _progress;
  bool _understand = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _branch = widget.branches.any((item) => item.name == widget.initialBranch)
        ? widget.initialBranch
        : widget.branches.isNotEmpty
            ? widget.branches.first.name
            : widget.repo.defaultBranch;
  }

  @override
  void dispose() {
    _message.dispose();
    _confirmation.dispose();
    super.dispose();
  }

  Future<void> _pickZip() async {
    try {
      final plan = await _zipService.pickAndPlan();
      if (plan != null && mounted) {
        setState(() {
          _plan = plan;
          _progress = null;
          _confirmation.clear();
          _understand = false;
        });
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    }
  }

  bool get _canPush {
    return !_busy &&
        _plan != null &&
        _branch.trim().isNotEmpty &&
        _message.text.trim().isNotEmpty &&
        _understand &&
        _confirmation.text.trim() == widget.repo.fullName;
  }

  Future<void> _push() async {
    if (!_canPush) return;
    setState(() => _busy = true);
    try {
      final controller = AppScope.of(context, listen: false);
      await controller.api.forceReplaceBranchFromZip(
        widget.repo.owner,
        widget.repo.name,
        branch: _branch.trim(),
        commitMessage: _message.text.trim(),
        plan: _plan!,
        onProgress: (progress) {
          if (mounted) setState(() => _progress = progress);
        },
      );
      await controller.refreshRepositories();
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Force push selesai'),
          content: Text(
            '${_plan!.entries.length} fail telah menggantikan kandungan branch $_branch.',
          ),
          actions: <Widget>[
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Tutup'),
            ),
          ],
        ),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_busy,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Force push ZIP'),
          bottom: _busy
              ? PreferredSize(
                  preferredSize: const Size.fromHeight(4),
                  child: LinearProgressIndicator(value: _progress?.fraction),
                )
              : null,
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
          children: <Widget>[
            Panel(
              borderColor: AppColors.warning.withValues(alpha: 0.5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Icon(Icons.warning_amber_rounded, color: AppColors.warning),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('Tindakan destruktif', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 6),
                        const Text(
                          'Semua fail sedia ada pada branch sasaran akan diganti oleh kandungan ZIP. Branch protection dan permission PAT masih boleh menyekat operasi ini.',
                          style: TextStyle(color: AppColors.muted, height: 1.45),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('Sasaran', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      const Icon(Icons.folder_copy_outlined, color: AppColors.accent),
                      const SizedBox(width: 10),
                      Expanded(child: Text(widget.repo.fullName)),
                      StatusPill(
                        label: widget.repo.isPrivate ? 'Private' : 'Public',
                        color: widget.repo.isPrivate
                            ? const Color(0xFFB79CFF)
                            : AppColors.accent,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  if (widget.branches.isNotEmpty)
                    DropdownButtonFormField<String>(
                      initialValue: _branch,
                      decoration: const InputDecoration(
                        labelText: 'Branch sasaran',
                        prefixIcon: Icon(Icons.call_split_rounded),
                      ),
                      items: widget.branches
                          .map(
                            (branch) => DropdownMenuItem<String>(
                              value: branch.name,
                              child: Text(branch.name),
                            ),
                          )
                          .toList(),
                      onChanged: _busy
                          ? null
                          : (value) => setState(() => _branch = value ?? _branch),
                    )
                  else
                    InputDecorator(
                      decoration: const InputDecoration(
                        labelText: 'Branch pertama',
                        prefixIcon: Icon(Icons.call_split_rounded),
                      ),
                      child: Text(_branch),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            InkWell(
              onTap: _busy ? null : _pickZip,
              borderRadius: BorderRadius.circular(22),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 30),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: _plan == null ? AppColors.line : AppColors.accent,
                    width: _plan == null ? 1 : 1.5,
                  ),
                ),
                child: _plan == null
                    ? const Column(
                        children: <Widget>[
                          Icon(Icons.cloud_upload_outlined, color: AppColors.accent, size: 42),
                          SizedBox(height: 12),
                          Text('Pilih fail ZIP', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                          SizedBox(height: 5),
                          Text(
                            'ZIP akan diperiksa sebelum sebarang data dihantar.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: AppColors.muted),
                          ),
                        ],
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              const Icon(Icons.archive_outlined, color: AppColors.accent, size: 30),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      _plan!.fileName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context).textTheme.titleMedium,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${_plan!.entries.length} fail - ${formatBytes(_plan!.totalBytes)}',
                                      style: const TextStyle(color: AppColors.muted),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.swap_horiz_rounded, color: AppColors.muted),
                            ],
                          ),
                          if (_plan!.strippedRoot.isNotEmpty) ...<Widget>[
                            const SizedBox(height: 12),
                            Text(
                              'Folder root "${_plan!.strippedRoot}" akan dibuang supaya kandungan masuk terus ke root repository.',
                              style: const TextStyle(color: AppColors.muted, fontSize: 12, height: 1.4),
                            ),
                          ],
                        ],
                      ),
              ),
            ),
            if (_plan != null) ...<Widget>[
              const SizedBox(height: 14),
              Panel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    TextField(
                      controller: _message,
                      enabled: !_busy,
                      onChanged: (_) => setState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Mesej commit',
                        prefixIcon: Icon(Icons.commit_rounded),
                      ),
                    ),
                    const SizedBox(height: 14),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                      value: _understand,
                      onChanged: _busy
                          ? null
                          : (value) => setState(() => _understand = value ?? false),
                      title: const Text('Aku faham kandungan branch akan diganti.'),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _confirmation,
                      enabled: !_busy,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        labelText: 'Taip ${widget.repo.fullName} untuk sahkan',
                        prefixIcon: const Icon(Icons.verified_user_outlined),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              if (_busy)
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(_progress?.message ?? 'Memulakan operasi...'),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(value: _progress?.fraction),
                      const SizedBox(height: 8),
                      Text(
                        _progress == null
                            ? '0%'
                            : '${(_progress!.fraction * 100).clamp(0, 100).toStringAsFixed(0)}%',
                        style: const TextStyle(color: AppColors.muted),
                      ),
                    ],
                  ),
                )
              else
                FilledButton.icon(
                  onPressed: _canPush ? _push : null,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.warning,
                    foregroundColor: const Color(0xFF171105),
                  ),
                  icon: const Icon(Icons.rocket_launch_outlined),
                  label: const Text('Force push sekarang'),
                ),
            ],
            if (_plan == null) ...<Widget>[
              const SizedBox(height: 14),
              const EmptyState(
                icon: Icons.rule_folder_outlined,
                title: 'Apa yang diperiksa',
                message: 'Laluan ../, folder .git, ZIP tanpa fail, jumlah fail berlebihan dan saiz melampau akan ditolak sebelum upload.',
              ),
            ],
          ],
        ),
      ),
    );
  }
}
