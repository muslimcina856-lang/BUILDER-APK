import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/brand_mark.dart';
import 'home_shell.dart';
import 'token_screen.dart';

class RootGate extends StatelessWidget {
  const RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    if (!controller.initialized) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              BrandMark(size: 84),
              SizedBox(height: 24),
              SizedBox(
                width: 120,
                child: LinearProgressIndicator(),
              ),
              SizedBox(height: 14),
              Text(
                'Menyediakan ruang kerja',
                style: TextStyle(color: AppColors.muted),
              ),
            ],
          ),
        ),
      );
    }
    if (controller.accounts.isEmpty || controller.activeAccount == null) {
      return const TokenScreen();
    }
    return const HomeShell();
  }
}
