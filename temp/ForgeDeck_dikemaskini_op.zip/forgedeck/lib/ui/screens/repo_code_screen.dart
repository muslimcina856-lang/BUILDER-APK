import 'dart:convert';

import 'package:flutter/material.dart';

import '../../core/network/github_exception.dart';
import '../../core/storage/native_bridge.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_content.dart';
import '../../models/github_repo.dart';
import '../../state/app_scope.dart';
import '../widgets/empty_state.dart';
import '../widgets/panel.dart';

class RepoCodeScreen extends StatefulWidget {
  const RepoCodeScreen({
    required this.repo,
    required this.branch,
    super.key,
  });

  final GitHubRepo repo;
  final String branch;

  @override
  State<RepoCodeScreen> createState() => _RepoCodeScreenState();
}

class _RepoCodeScreenState extends State<RepoCodeScreen> {
  String _path = '';
  List<GitHubContent> _items = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RepoCodeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.branch != widget.branch ||
        oldWidget.repo.fullName != widget.repo.fullName) {
      _path = '';
      _load();
    }
  }

  Future<void> _load() async {
    if (widget.branch.isEmpty) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    if (mounted) setState(() => _loading = true);
    try {
      final items = await AppScope.of(context, listen: false).api.listContents(
            widget.repo.owner,
            widget.repo.name,
            path: _path,
            ref: widget.branch,
          );
      items.sort((a, b) {
        if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
      if (mounted) {
        setState(() {
          _items = items;
          _error = null;
        });
      }
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _openItem(GitHubContent item) async {
    if (item.isDirectory) {
      setState(() => _path = item.path);
      await _load();
      return;
    }
    final content = await AppScope.of(context, listen: false).api.getContent(
          widget.repo.owner,
          widget.repo.name,
          item.path,
          ref: widget.branch,
        );
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => _FileViewerScreen(
          repo: widget.repo,
          branch: widget.branch,
          content: content,
        ),
      ),
    );
    await _load();
  }

  Future<void> _uploadFile() async {
    final file = await NativeBridge.pickFile();
    if (file == null) return;
    if (file.size > 50 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Fail tunggal dihadkan kepada 50 MB.')),
        );
      }
      return;
    }
    final bytes = await file.readAsBytes();
    if (!mounted) return;

    final target = await showDialog<_UploadTarget>(
      context: context,
      builder: (_) => _UploadFileDialog(
        initialPath: _path.isEmpty ? file.name : '$_path/${file.name}',
      ),
    );
    if (target == null || !mounted) return;
    final safePath = _safeRepoPath(target.path);
    if (safePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Laluan sasaran tidak sah.')),
      );
      return;
    }

    try {
      String? existingSha;
      try {
        final existing = await AppScope.of(context, listen: false).api.getContent(
              widget.repo.owner,
              widget.repo.name,
              safePath,
              ref: widget.branch,
            );
        existingSha = existing.sha;
      } on GitHubException catch (error) {
        if (error.statusCode != 404) rethrow;
      }

      await AppScope.of(context, listen: false).api.putFile(
            widget.repo.owner,
            widget.repo.name,
            safePath,
            bytes: bytes,
            message: target.message,
            branch: widget.branch,
            sha: existingSha,
          );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Fail berjaya dimuat naik.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    }
  }

  void _goUp() {
    if (_path.isEmpty) return;
    final parts = _path.split('/');
    parts.removeLast();
    setState(() => _path = parts.join('/'));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.branch.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: EmptyState(
          icon: Icons.account_tree_outlined,
          title: 'Tiada branch',
          message: 'Cipta branch atau buat commit pertama untuk melihat kod.',
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
        children: <Widget>[
          Row(
            children: <Widget>[
              if (_path.isNotEmpty)
                IconButton.filledTonal(
                  onPressed: _goUp,
                  icon: const Icon(Icons.arrow_upward_rounded),
                ),
              if (_path.isNotEmpty) const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _path.isEmpty ? '/' : '/$_path',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
              IconButton.filled(
                onPressed: widget.repo.canPush ? _uploadFile : null,
                icon: const Icon(Icons.upload_file_rounded),
                tooltip: 'Muat naik fail',
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            EmptyState(
              icon: Icons.error_outline_rounded,
              title: 'Gagal membaca kandungan',
              message: _error!,
              action: OutlinedButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Cuba lagi'),
              ),
            )
          else if (_items.isEmpty)
            const EmptyState(
              icon: Icons.folder_open_outlined,
              title: 'Folder kosong',
              message: 'Muat naik fail untuk menambah kandungan.',
            )
          else
            Panel(
              padding: EdgeInsets.zero,
              child: ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _items.length,
                separatorBuilder: (_, __) => const Divider(height: 1, indent: 58),
                itemBuilder: (context, index) {
                  final item = _items[index];
                  return ListTile(
                    onTap: () => _openItem(item),
                    leading: Icon(
                      item.isDirectory ? Icons.folder_rounded : _fileIcon(item.name),
                      color: item.isDirectory ? AppColors.warning : AppColors.accent,
                    ),
                    title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: item.isFile ? Text(formatBytes(item.size)) : null,
                    trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  String? _safeRepoPath(String input) {
    final normalized = input.replaceAll('\\', '/').trim();
    if (normalized.isEmpty || normalized.startsWith('/')) return null;
    final parts = normalized.split('/');
    if (parts.any((part) => part.isEmpty || part == '.' || part == '..')) {
      return null;
    }
    return parts.join('/');
  }

  IconData _fileIcon(String name) {
    final extension = name.contains('.') ? name.split('.').last.toLowerCase() : '';
    return switch (extension) {
      'md' => Icons.article_outlined,
      'json' || 'yaml' || 'yml' => Icons.data_object_rounded,
      'png' || 'jpg' || 'jpeg' || 'webp' || 'gif' => Icons.image_outlined,
      'zip' || 'tar' || 'gz' => Icons.archive_outlined,
      _ => Icons.insert_drive_file_outlined,
    };
  }
}

class _FileViewerScreen extends StatefulWidget {
  const _FileViewerScreen({
    required this.repo,
    required this.branch,
    required this.content,
  });

  final GitHubRepo repo;
  final String branch;
  final GitHubContent content;

  @override
  State<_FileViewerScreen> createState() => _FileViewerScreenState();
}

class _FileViewerScreenState extends State<_FileViewerScreen> {
  late final String _text;

  @override
  void initState() {
    super.initState();
    try {
      final cleaned = widget.content.content.replaceAll(RegExp(r'\s'), '');
      _text = utf8.decode(base64Decode(cleaned), allowMalformed: true);
    } catch (_) {
      _text = '';
    }
  }

  Future<void> _edit() async {
    if (widget.content.size > 1024 * 1024) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Editor teks dihadkan kepada fail 1 MB.')),
      );
      return;
    }
    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => _TextEditorScreen(
          repo: widget.repo,
          branch: widget.branch,
          content: widget.content,
          initialText: _text,
        ),
      ),
    );
    if (updated == true && mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Padam ${widget.content.name}?'),
        content: const Text('GitHub akan mencipta commit untuk memadam fail ini.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await AppScope.of(context, listen: false).api.deleteFile(
            widget.repo.owner,
            widget.repo.name,
            widget.content.path,
            sha: widget.content.sha,
            message: 'Delete ${widget.content.path} via ForgeDeck',
            branch: widget.branch,
          );
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.content.name),
        actions: <Widget>[
          IconButton(onPressed: widget.repo.canPush ? _edit : null, icon: const Icon(Icons.edit_outlined)),
          IconButton(onPressed: widget.repo.canPush ? _delete : null, icon: const Icon(Icons.delete_outline_rounded)),
        ],
      ),
      body: _text.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: EmptyState(
                  icon: Icons.insert_drive_file_outlined,
                  title: 'Pratonton tidak tersedia',
                  message: 'Fail ini mungkin binari atau terlalu besar. Saiz: ${formatBytes(widget.content.size)}',
                ),
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 40),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SelectableText(
                  _text,
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 13,
                    height: 1.5,
                    color: AppColors.text,
                  ),
                ),
              ),
            ),
    );
  }
}

class _TextEditorScreen extends StatefulWidget {
  const _TextEditorScreen({
    required this.repo,
    required this.branch,
    required this.content,
    required this.initialText,
  });

  final GitHubRepo repo;
  final String branch;
  final GitHubContent content;
  final String initialText;

  @override
  State<_TextEditorScreen> createState() => _TextEditorScreenState();
}

class _TextEditorScreenState extends State<_TextEditorScreen> {
  late final TextEditingController _editor;
  final _message = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _editor = TextEditingController(text: widget.initialText);
    _message.text = 'Update ${widget.content.path} via ForgeDeck';
  }

  @override
  void dispose() {
    _editor.dispose();
    _message.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).api.putFile(
            widget.repo.owner,
            widget.repo.name,
            widget.content.path,
            bytes: utf8.encode(_editor.text),
            message: _message.text.trim(),
            branch: widget.branch,
            sha: widget.content.sha,
          );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit ${widget.content.name}'),
        actions: <Widget>[
          TextButton(onPressed: _busy ? null : _save, child: const Text('Simpan')),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _message,
              decoration: const InputDecoration(labelText: 'Mesej commit'),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: TextField(
                controller: _editor,
                expands: true,
                maxLines: null,
                minLines: null,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.45),
                decoration: const InputDecoration(alignLabelWithHint: true),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _UploadTarget {
  const _UploadTarget({required this.path, required this.message});

  final String path;
  final String message;
}

class _UploadFileDialog extends StatefulWidget {
  const _UploadFileDialog({required this.initialPath});

  final String initialPath;

  @override
  State<_UploadFileDialog> createState() => _UploadFileDialogState();
}

class _UploadFileDialogState extends State<_UploadFileDialog> {
  late final TextEditingController _path;
  final _message = TextEditingController(text: 'Upload file via ForgeDeck');

  @override
  void initState() {
    super.initState();
    _path = TextEditingController(text: widget.initialPath);
  }

  @override
  void dispose() {
    _path.dispose();
    _message.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Muat naik fail'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          TextField(controller: _path, decoration: const InputDecoration(labelText: 'Laluan sasaran')),
          const SizedBox(height: 10),
          TextField(controller: _message, decoration: const InputDecoration(labelText: 'Mesej commit')),
        ],
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        FilledButton(
          onPressed: () {
            if (_path.text.trim().isEmpty || _message.text.trim().isEmpty) return;
            Navigator.pop(
              context,
              _UploadTarget(path: _path.text.trim(), message: _message.text.trim()),
            );
          },
          child: const Text('Muat naik'),
        ),
      ],
    );
  }
}
