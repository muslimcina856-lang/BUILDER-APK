import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/brand_mark.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class TokenScreen extends StatefulWidget {
  const TokenScreen({super.key});

  @override
  State<TokenScreen> createState() => _TokenScreenState();
}

class _TokenScreenState extends State<TokenScreen> {
  final _tokenController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscure = true;

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final controller = AppScope.of(context, listen: false);
    try {
      await controller.addAccount(_tokenController.text);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final permission = controller.storagePermission;
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 28, 22, 32),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight - 60),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const BrandMark(size: 82),
                    const SizedBox(height: 34),
                    Text('Akses GitHub kau,\ndalam satu tempat.',
                        style: Theme.of(context).textTheme.displaySmall),
                    const SizedBox(height: 14),
                    const Text(
                      'Masukkan PAT untuk sahkan akaun pertama. Token disimpan dalam storan selamat peranti dan tidak dipaparkan semula.',
                      style: TextStyle(color: AppColors.muted, height: 1.55),
                    ),
                    const SizedBox(height: 28),
                    Panel(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            const StatusPill(
                              label: 'Sambungan terus ke api.github.com',
                              icon: Icons.shield_outlined,
                            ),
                            const SizedBox(height: 18),
                            TextFormField(
                              controller: _tokenController,
                              obscureText: _obscure,
                              autocorrect: false,
                              enableSuggestions: false,
                              keyboardType: TextInputType.visiblePassword,
                              textInputAction: TextInputAction.done,
                              onFieldSubmitted: (_) => _submit(),
                              decoration: InputDecoration(
                                labelText: 'Personal access token',
                                hintText: 'github_pat_... atau ghp_...',
                                prefixIcon: const Icon(Icons.key_rounded),
                                suffixIcon: IconButton(
                                  onPressed: () => setState(() => _obscure = !_obscure),
                                  icon: Icon(
                                    _obscure
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                  ),
                                ),
                              ),
                              validator: (value) {
                                final token = value?.trim() ?? '';
                                if (token.isEmpty) return 'Masukkan PAT token.';
                                if (token.length < 20) return 'Format token nampak terlalu pendek.';
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            FilledButton.icon(
                              onPressed: controller.loading ? null : _submit,
                              icon: controller.loading
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Icon(Icons.arrow_forward_rounded),
                              label: Text(
                                controller.loading ? 'Menyemak token' : 'Tambah akaun',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    if (permission != null && permission.required && !permission.granted)
                      Panel(
                        borderColor: AppColors.warning.withValues(alpha: 0.45),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            const Icon(Icons.folder_off_outlined, color: AppColors.warning),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                permission.permanentlyDenied
                                    ? 'Izin storan ditolak secara kekal. Pemilih fail sistem masih boleh digunakan, atau buka Settings untuk beri izin pada Android lama.'
                                    : 'Izin storan belum diberi. Pada Android lama, aplikasi akan minta izin ini untuk akses fail ZIP.',
                                style: const TextStyle(color: AppColors.muted, height: 1.45),
                              ),
                            ),
                          ],
                        ),
                      ),
                    const SizedBox(height: 34),
                    const Text(
                      'Akses sebenar sentiasa ikut permission PAT dan polisi organisasi GitHub.',
                      style: TextStyle(color: AppColors.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
