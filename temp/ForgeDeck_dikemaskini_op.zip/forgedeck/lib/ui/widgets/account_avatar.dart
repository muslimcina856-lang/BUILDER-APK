import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

class AccountAvatar extends StatelessWidget {
  const AccountAvatar({
    required this.url,
    required this.fallback,
    this.radius = 22,
    super.key,
  });

  final String url;
  final String fallback;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.line, width: 1.5),
        color: AppColors.surfaceHigh,
      ),
      clipBehavior: Clip.antiAlias,
      child: url.isNotEmpty
          ? Image.network(
              url,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _Fallback(text: fallback),
            )
          : _Fallback(text: fallback),
    );
  }
}

class _Fallback extends StatelessWidget {
  const _Fallback({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final value = text.trim().isEmpty ? '?' : text.trim()[0].toUpperCase();
    return Center(
      child: Text(
        value,
        style: const TextStyle(
          color: AppColors.accent,
          fontSize: 18,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
