import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

class BrandMark extends StatelessWidget {
  const BrandMark({this.size = 72, super.key});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF153049), Color(0xFF08131F)],
        ),
        border: Border.all(color: AppColors.line),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: AppColors.accent.withValues(alpha: 0.16),
            blurRadius: 28,
            spreadRadius: 2,
          ),
        ],
      ),
      child: CustomPaint(painter: _BrandPainter()),
    );
  }
}

class _BrandPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.27;
    final stroke = size.width * 0.065;
    final linePaint = Paint()
      ..color = AppColors.accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final circlePath = Path()
      ..addArc(
        Rect.fromCircle(center: center, radius: radius),
        math.pi * 0.18,
        math.pi * 1.56,
      );
    canvas.drawPath(circlePath, linePaint);

    final arrowTop = Offset(center.dx, size.height * 0.22);
    final arrowMid = Offset(center.dx, size.height * 0.62);
    canvas.drawLine(arrowTop, arrowMid, linePaint);
    canvas.drawLine(
      arrowTop,
      Offset(size.width * 0.36, size.height * 0.37),
      linePaint,
    );
    canvas.drawLine(
      arrowTop,
      Offset(size.width * 0.64, size.height * 0.37),
      linePaint,
    );

    final nodePaint = Paint()..color = AppColors.accent;
    canvas.drawCircle(
      Offset(size.width * 0.25, size.height * 0.66),
      size.width * 0.045,
      nodePaint,
    );
    canvas.drawCircle(
      Offset(size.width * 0.74, size.height * 0.68),
      size.width * 0.045,
      nodePaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
