import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_repo.dart';
import 'panel.dart';

class RepoCard extends StatelessWidget {
  const RepoCard({required this.repo, required this.onTap, super.key});

  final GitHubRepo repo;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Panel(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: repo.isPrivate
                      ? const Color(0xFF2A2543)
                      : AppColors.accentSoft,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  repo.isPrivate ? Icons.lock_outline : Icons.code_rounded,
                  color: repo.isPrivate
                      ? const Color(0xFFB79CFF)
                      : AppColors.accent,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      repo.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${repo.owner}  -  ${timeAgo(repo.updatedAt)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.muted,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
            ],
          ),
          if (repo.description.isNotEmpty) ...<Widget>[
            const SizedBox(height: 14),
            Text(
              repo.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.muted, height: 1.4),
            ),
          ],
          const SizedBox(height: 16),
          Wrap(
            spacing: 14,
            runSpacing: 8,
            children: <Widget>[
              _Meta(icon: Icons.star_border_rounded, value: compactNumber(repo.stargazersCount)),
              _Meta(icon: Icons.call_split_rounded, value: compactNumber(repo.forksCount)),
              _Meta(icon: Icons.adjust_rounded, value: compactNumber(repo.openIssuesCount)),
              if (repo.language.isNotEmpty)
                _Meta(icon: Icons.circle, value: repo.language, iconSize: 9),
              if (repo.isArchived)
                const _Meta(icon: Icons.inventory_2_outlined, value: 'Arkib'),
            ],
          ),
        ],
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({required this.icon, required this.value, this.iconSize = 16});

  final IconData icon;
  final String value;
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, color: AppColors.muted, size: iconSize),
        const SizedBox(width: 5),
        Text(
          value,
          style: const TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ],
    );
  }
}
