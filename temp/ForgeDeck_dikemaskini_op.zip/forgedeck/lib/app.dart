import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'state/app_controller.dart';
import 'ui/screens/root_gate.dart';

class ForgeDeckApp extends StatelessWidget {
  const ForgeDeckApp({required this.controller, super.key});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ForgeDeck',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      themeMode: ThemeMode.dark,
      home: const RootGate(),
    );
  }
}
