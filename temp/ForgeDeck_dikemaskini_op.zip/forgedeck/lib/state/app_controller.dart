import 'dart:math';

import 'package:flutter/foundation.dart';

import '../core/network/github_api.dart';
import '../core/storage/account_vault.dart';
import '../core/storage/storage_permission_service.dart';
import '../models/github_account.dart';
import '../models/github_repo.dart';
import '../models/github_user.dart';

class AppController extends ChangeNotifier {
  AppController({
    AccountVault? vault,
    StoragePermissionService? permissionService,
  })  : _vault = vault ?? AccountVault(),
        _permissionService =
            permissionService ?? const StoragePermissionService();

  final AccountVault _vault;
  final StoragePermissionService _permissionService;

  bool initialized = false;
  bool loading = false;
  String? errorMessage;
  StoragePermissionResult? storagePermission;

  List<GitHubAccount> accounts = const [];
  GitHubAccount? activeAccount;
  GitHubUser? activeUser;
  List<GitHubRepo> repositories = const [];
  List<Map<String, dynamic>> notifications = const [];

  GitHubApi? _api;
  GitHubApi get api {
    final value = _api;
    if (value == null) {
      throw StateError('Tiada akaun aktif.');
    }
    return value;
  }

  Future<void> initialize() async {
    if (initialized) return;
    try {
      try {
        storagePermission = await _permissionService.requestAtStartup();
      } catch (_) {
        storagePermission = const StoragePermissionResult(
          required: false,
          granted: true,
          permanentlyDenied: false,
        );
      }

      accounts = await _vault.readAccounts();
      final activeId = await _vault.readActiveAccountId();
      if (accounts.isNotEmpty) {
        activeAccount = accounts.firstWhere(
          (account) => account.id == activeId,
          orElse: () => accounts.first,
        );
        _api = GitHubApi(activeAccount!.token);
        await refreshAll(silent: true);
      }
    } catch (error) {
      errorMessage = error.toString();
    } finally {
      initialized = true;
      notifyListeners();
    }
  }

  Future<void> addAccount(String rawToken) async {
    final token = rawToken.trim();
    if (token.isEmpty) {
      throw ArgumentError('PAT token diperlukan.');
    }
    if (accounts.any((account) => account.token == token)) {
      throw ArgumentError('Token ini sudah ditambah.');
    }

    loading = true;
    errorMessage = null;
    notifyListeners();
    try {
      final candidateApi = GitHubApi(token);
      final user = await candidateApi.getAuthenticatedUser();

      List<GitHubRepo> candidateRepositories = const [];
      List<Map<String, dynamic>> candidateNotifications = const [];
      try {
        candidateRepositories = await candidateApi.listRepositories();
      } catch (_) {
        candidateRepositories = const [];
      }
      try {
        candidateNotifications = await candidateApi.listNotifications();
      } catch (_) {
        candidateNotifications = const [];
      }

      final account = GitHubAccount(
        id: _newId(),
        login: user.login,
        name: user.name,
        avatarUrl: user.avatarUrl,
        token: token,
        createdAt: DateTime.now(),
      );
      accounts = <GitHubAccount>[...accounts, account];
      await _vault.saveAccounts(accounts);
      await switchAccount(account.id, refresh: false);
      activeUser = user;
      repositories = candidateRepositories;
      notifications = candidateNotifications;
    } catch (error) {
      errorMessage = error.toString();
      rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> switchAccount(String id, {bool refresh = true}) async {
    final next = accounts.firstWhere((account) => account.id == id);
    activeAccount = next;
    _api = GitHubApi(next.token);
    activeUser = null;
    repositories = const [];
    notifications = const [];
    await _vault.writeActiveAccountId(next.id);
    notifyListeners();
    if (refresh) await refreshAll();
  }

  Future<void> removeAccount(String id) async {
    final account = accounts.firstWhere((item) => item.id == id);
    await _vault.removeAccount(account);
    accounts = accounts.where((item) => item.id != id).toList();

    if (activeAccount?.id == id) {
      if (accounts.isEmpty) {
        activeAccount = null;
        activeUser = null;
        repositories = const [];
        notifications = const [];
        _api = null;
        await _vault.writeActiveAccountId(null);
      } else {
        await _vault.saveAccounts(accounts);
        await switchAccount(accounts.first.id);
      }
    } else {
      await _vault.saveAccounts(accounts);
    }
    notifyListeners();
  }

  Future<void> refreshAll({bool silent = false}) async {
    if (_api == null) return;
    if (!silent) {
      loading = true;
      errorMessage = null;
      notifyListeners();
    }
    try {
      final results = await Future.wait<dynamic>(<Future<dynamic>>[
        api.getAuthenticatedUser(),
        api.listRepositories(),
      ]);
      activeUser = results[0] as GitHubUser;
      repositories = results[1] as List<GitHubRepo>;
      try {
        notifications = await api.listNotifications();
      } catch (_) {
        notifications = const [];
      }
    } catch (error) {
      errorMessage = error.toString();
      if (!silent) rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> refreshRepositories() async {
    if (_api == null) return;
    repositories = await api.listRepositories();
    notifyListeners();
  }

  Future<GitHubRepo> createRepository({
    required String name,
    required String description,
    required bool isPrivate,
    required bool autoInit,
  }) async {
    final repo = await api.createRepository(
      name: name,
      description: description,
      isPrivate: isPrivate,
      autoInit: autoInit,
    );
    await refreshRepositories();
    return repo;
  }

  Future<void> markNotificationsRead() async {
    await api.markNotificationsRead();
    notifications = const [];
    notifyListeners();
  }

  Future<void> clearAllAccounts() async {
    await _vault.clear();
    accounts = const [];
    activeAccount = null;
    activeUser = null;
    repositories = const [];
    notifications = const [];
    _api = null;
    notifyListeners();
  }

  String _newId() {
    final random = Random.secure();
    final suffix = List<int>.generate(10, (_) => random.nextInt(256))
        .map((value) => value.toRadixString(16).padLeft(2, '0'))
        .join();
    return '${DateTime.now().microsecondsSinceEpoch}-$suffix';
  }
}
