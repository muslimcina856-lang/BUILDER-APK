import 'package:flutter/material.dart';

import 'app.dart';
import 'state/app_controller.dart';
import 'state/app_scope.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = AppController();
  runApp(
    AppScope(
      controller: controller,
      child: ForgeDeckApp(controller: controller),
    ),
  );
  await controller.initialize();
}
