import 'package:dio/dio.dart';

import '../utils/token_redactor.dart';

class GitHubException implements Exception {
  const GitHubException({
    required this.message,
    this.statusCode,
    this.documentationUrl,
  });

  final String message;
  final int? statusCode;
  final String? documentationUrl;

  factory GitHubException.fromDio(DioException error) {
    final data = error.response?.data;
    String message = 'Permintaan ke GitHub gagal.';
    String? documentationUrl;
    if (data is Map<String, dynamic>) {
      message = data['message'] as String? ?? message;
      documentationUrl = data['documentation_url'] as String?;
    } else if (error.message != null && error.message!.isNotEmpty) {
      message = error.message!;
    }
    return GitHubException(
      message: TokenRedactor.redact(message),
      statusCode: error.response?.statusCode,
      documentationUrl: documentationUrl,
    );
  }

  @override
  String toString() => message;
}
