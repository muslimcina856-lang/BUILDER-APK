class TokenRedactor {
  const TokenRedactor._();

  static String redact(String value) {
    return value
        .replaceAll(RegExp(r'gh[pousr]_[A-Za-z0-9_]{8,}'), '***')
        .replaceAll(RegExp(r'github_pat_[A-Za-z0-9_]{8,}'), '***');
  }
}
