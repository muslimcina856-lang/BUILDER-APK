import 'dart:convert';

import '../../models/github_account.dart';
import 'native_bridge.dart';

class AccountVault {
  const AccountVault();

  static const _metadataKey = 'forgedeck.accounts.metadata.v1';
  static const _activeAccountKey = 'forgedeck.accounts.active.v1';
  static const _tokenPrefix = 'forgedeck.account.token.';

  Future<List<GitHubAccount>> readAccounts() async {
    final raw = await NativeBridge.secureRead(_metadataKey);
    if (raw == null || raw.isEmpty) return const [];

    final decoded = jsonDecode(raw);
    if (decoded is! List<dynamic>) return const [];

    final accounts = <GitHubAccount>[];
    for (final item in decoded) {
      if (item is! Map<String, dynamic>) continue;
      final id = item['id'] as String?;
      if (id == null || id.isEmpty) continue;
      final token = await NativeBridge.secureRead('$_tokenPrefix$id');
      if (token == null || token.isEmpty) continue;
      accounts.add(GitHubAccount.fromMetadataJson(item, token: token));
    }
    return accounts;
  }

  Future<void> saveAccounts(List<GitHubAccount> accounts) async {
    final metadata = accounts.map((account) => account.toMetadataJson()).toList();
    await NativeBridge.secureWrite(_metadataKey, jsonEncode(metadata));
    for (final account in accounts) {
      await NativeBridge.secureWrite(
        '$_tokenPrefix${account.id}',
        account.token,
      );
    }
  }

  Future<void> removeAccount(GitHubAccount account) {
    return NativeBridge.secureDelete('$_tokenPrefix${account.id}');
  }

  Future<String?> readActiveAccountId() {
    return NativeBridge.secureRead(_activeAccountKey);
  }

  Future<void> writeActiveAccountId(String? id) async {
    if (id == null || id.isEmpty) {
      await NativeBridge.secureDelete(_activeAccountKey);
      return;
    }
    await NativeBridge.secureWrite(_activeAccountKey, id);
  }

  Future<void> clear() {
    return NativeBridge.secureDeleteAll();
  }
}
