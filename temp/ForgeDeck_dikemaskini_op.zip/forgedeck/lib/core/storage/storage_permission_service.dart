import 'native_bridge.dart';

class StoragePermissionResult {
  const StoragePermissionResult({
    required this.required,
    required this.granted,
    required this.permanentlyDenied,
  });

  final bool required;
  final bool granted;
  final bool permanentlyDenied;
}

class StoragePermissionService {
  const StoragePermissionService();

  Future<StoragePermissionResult> requestAtStartup() async {
    final result = await NativeBridge.requestLegacyStoragePermission();
    return StoragePermissionResult(
      required: result['required'] == true,
      granted: result['granted'] != false,
      permanentlyDenied: result['permanentlyDenied'] == true,
    );
  }
}
