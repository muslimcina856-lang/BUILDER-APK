class GitHubIssue {
  const GitHubIssue({
    required this.number,
    required this.title,
    required this.body,
    required this.state,
    required this.author,
    required this.comments,
    required this.isPullRequest,
    required this.createdAt,
  });

  final int number;
  final String title;
  final String body;
  final String state;
  final String author;
  final int comments;
  final bool isPullRequest;
  final DateTime createdAt;

  factory GitHubIssue.fromJson(Map<String, dynamic> json) {
    final user = json['user'] as Map<String, dynamic>? ?? const {};
    return GitHubIssue(
      number: json['number'] as int? ?? 0,
      title: json['title'] as String? ?? '',
      body: json['body'] as String? ?? '',
      state: json['state'] as String? ?? '',
      author: user['login'] as String? ?? '',
      comments: json['comments'] as int? ?? 0,
      isPullRequest: json.containsKey('pull_request'),
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
