class GitHubContent {
  const GitHubContent({
    required this.name,
    required this.path,
    required this.sha,
    required this.type,
    required this.size,
    required this.downloadUrl,
    required this.content,
  });

  final String name;
  final String path;
  final String sha;
  final String type;
  final int size;
  final String downloadUrl;
  final String content;

  bool get isDirectory => type == 'dir';
  bool get isFile => type == 'file';

  factory GitHubContent.fromJson(Map<String, dynamic> json) {
    return GitHubContent(
      name: json['name'] as String? ?? '',
      path: json['path'] as String? ?? '',
      sha: json['sha'] as String? ?? '',
      type: json['type'] as String? ?? '',
      size: json['size'] as int? ?? 0,
      downloadUrl: json['download_url'] as String? ?? '',
      content: json['content'] as String? ?? '',
    );
  }
}
