class GitHubRepo {
  const GitHubRepo({
    required this.id,
    required this.name,
    required this.fullName,
    required this.owner,
    required this.description,
    required this.isPrivate,
    required this.isFork,
    required this.isArchived,
    required this.defaultBranch,
    required this.language,
    required this.stargazersCount,
    required this.forksCount,
    required this.openIssuesCount,
    required this.updatedAt,
    required this.htmlUrl,
    required this.permissions,
  });

  final int id;
  final String name;
  final String fullName;
  final String owner;
  final String description;
  final bool isPrivate;
  final bool isFork;
  final bool isArchived;
  final String defaultBranch;
  final String language;
  final int stargazersCount;
  final int forksCount;
  final int openIssuesCount;
  final DateTime updatedAt;
  final String htmlUrl;
  final Map<String, bool> permissions;

  bool get canPush =>
      permissions['push'] ?? permissions['maintain'] ?? permissions['admin'] ?? false;
  bool get canAdmin => permissions['admin'] ?? false;

  factory GitHubRepo.fromJson(Map<String, dynamic> json) {
    final ownerJson = json['owner'] as Map<String, dynamic>? ?? const {};
    final rawPermissions =
        json['permissions'] as Map<String, dynamic>? ?? const {};
    return GitHubRepo(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      owner: ownerJson['login'] as String? ?? '',
      description: json['description'] as String? ?? '',
      isPrivate: json['private'] as bool? ?? false,
      isFork: json['fork'] as bool? ?? false,
      isArchived: json['archived'] as bool? ?? false,
      defaultBranch: json['default_branch'] as String? ?? 'main',
      language: json['language'] as String? ?? '',
      stargazersCount: json['stargazers_count'] as int? ?? 0,
      forksCount: json['forks_count'] as int? ?? 0,
      openIssuesCount: json['open_issues_count'] as int? ?? 0,
      updatedAt: DateTime.tryParse(json['updated_at'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      htmlUrl: json['html_url'] as String? ?? '',
      permissions: rawPermissions.map(
        (key, value) => MapEntry(key, value == true),
      ),
    );
  }
}
