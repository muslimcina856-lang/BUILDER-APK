class GitHubWorkflow {
  const GitHubWorkflow({
    required this.id,
    required this.name,
    required this.path,
    required this.state,
  });

  final int id;
  final String name;
  final String path;
  final String state;

  factory GitHubWorkflow.fromJson(Map<String, dynamic> json) {
    return GitHubWorkflow(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? '',
      path: json['path'] as String? ?? '',
      state: json['state'] as String? ?? '',
    );
  }
}

class GitHubWorkflowRun {
  const GitHubWorkflowRun({
    required this.id,
    required this.name,
    required this.status,
    required this.conclusion,
    required this.branch,
    required this.event,
    required this.createdAt,
  });

  final int id;
  final String name;
  final String status;
  final String conclusion;
  final String branch;
  final String event;
  final DateTime createdAt;

  factory GitHubWorkflowRun.fromJson(Map<String, dynamic> json) {
    return GitHubWorkflowRun(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? json['display_title'] as String? ?? '',
      status: json['status'] as String? ?? '',
      conclusion: json['conclusion'] as String? ?? '',
      branch: json['head_branch'] as String? ?? '',
      event: json['event'] as String? ?? '',
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
