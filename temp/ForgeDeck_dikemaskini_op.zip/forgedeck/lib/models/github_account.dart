class GitHubAccount {
  const GitHubAccount({
    required this.id,
    required this.login,
    required this.name,
    required this.avatarUrl,
    required this.token,
    required this.createdAt,
  });

  final String id;
  final String login;
  final String name;
  final String avatarUrl;
  final String token;
  final DateTime createdAt;

  String get displayName => name.trim().isEmpty ? login : name;

  Map<String, dynamic> toMetadataJson() => <String, dynamic>{
        'id': id,
        'login': login,
        'name': name,
        'avatarUrl': avatarUrl,
        'createdAt': createdAt.toIso8601String(),
      };

  static GitHubAccount fromMetadataJson(
    Map<String, dynamic> json, {
    required String token,
  }) {
    return GitHubAccount(
      id: json['id'] as String,
      login: json['login'] as String? ?? '',
      name: json['name'] as String? ?? '',
      avatarUrl: json['avatarUrl'] as String? ?? '',
      token: token,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
