class GitHubBranch {
  const GitHubBranch({
    required this.name,
    required this.sha,
    required this.protected,
  });

  final String name;
  final String sha;
  final bool protected;

  factory GitHubBranch.fromJson(Map<String, dynamic> json) {
    final commit = json['commit'] as Map<String, dynamic>? ?? const {};
    return GitHubBranch(
      name: json['name'] as String? ?? '',
      sha: commit['sha'] as String? ?? '',
      protected: json['protected'] as bool? ?? false,
    );
  }
}
