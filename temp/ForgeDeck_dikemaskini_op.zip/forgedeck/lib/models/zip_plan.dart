import 'dart:typed_data';

class ZipEntryPlan {
  const ZipEntryPlan({
    required this.path,
    required this.bytes,
    required this.executable,
  });

  final String path;
  final Uint8List bytes;
  final bool executable;
}

class ZipPlan {
  const ZipPlan({
    required this.fileName,
    required this.entries,
    required this.totalBytes,
    required this.strippedRoot,
  });

  final String fileName;
  final List<ZipEntryPlan> entries;
  final int totalBytes;
  final String strippedRoot;
}
