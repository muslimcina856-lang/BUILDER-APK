package com.earlxz.forgedeck;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

public final class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "com.earlxz.forgedeck/native";
    private static final String SECURE_PREFS = "forgedeck_secure_v1";
    private static final String KEY_ALIAS = "forgedeck_master_key_v1";
    private static final int PICK_FILE_REQUEST = 9101;
    private static final int STORAGE_PERMISSION_REQUEST = 9102;
    private static final int SAVE_FILE_REQUEST = 9103;
    private static final long MAX_PICKED_FILE_BYTES = 512L * 1024L * 1024L;

    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private MethodChannel.Result pendingFileResult;
    private MethodChannel.Result pendingPermissionResult;
    private MethodChannel.Result pendingSaveResult;
    private File pendingSaveSource;
    private String pendingSaveName;

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(
                flutterEngine.getDartExecutor().getBinaryMessenger(),
                CHANNEL
        ).setMethodCallHandler(this::handleMethodCall);
    }

    private void handleMethodCall(MethodCall call, MethodChannel.Result result) {
        try {
            switch (call.method) {
                case "pickFile":
                    startFilePicker(call.argument("mimeType"), result);
                    break;
                case "saveFile":
                    startFileSaver(
                            requireString(call, "path"),
                            requireString(call, "name"),
                            call.argument("mimeType"),
                            result
                    );
                    break;
                case "requestLegacyStoragePermission":
                    requestLegacyStoragePermission(result);
                    break;
                case "openAppSettings":
                    openApplicationSettings();
                    result.success(null);
                    break;
                case "secureRead":
                    result.success(readSecure(requireString(call, "key")));
                    break;
                case "secureWrite":
                    writeSecure(
                            requireString(call, "key"),
                            requireString(call, "value")
                    );
                    result.success(null);
                    break;
                case "secureDelete":
                    securePreferences().edit()
                            .remove(requireString(call, "key"))
                            .apply();
                    result.success(null);
                    break;
                case "secureDeleteAll":
                    securePreferences().edit().clear().apply();
                    result.success(null);
                    break;
                default:
                    result.notImplemented();
                    break;
            }
        } catch (Exception error) {
            result.error(
                    "NATIVE_BRIDGE_ERROR",
                    error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage(),
                    null
            );
        }
    }

    private static String requireString(MethodCall call, String name) {
        String value = call.argument(name);
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException(name + " diperlukan.");
        }
        return value;
    }

    private void startFilePicker(String requestedMimeType, MethodChannel.Result result) {
        if (pendingFileResult != null) {
            result.error("PICKER_BUSY", "Pemilih fail sedang digunakan.", null);
            return;
        }

        pendingFileResult = result;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if ("application/zip".equals(requestedMimeType)) {
            intent.setType("*/*");
            intent.putExtra(
                    Intent.EXTRA_MIME_TYPES,
                    new String[]{
                            "application/zip",
                            "application/x-zip-compressed",
                            "application/octet-stream"
                    }
            );
        } else {
            intent.setType(
                    requestedMimeType == null || requestedMimeType.isEmpty()
                            ? "*/*"
                            : requestedMimeType
            );
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

        try {
            startActivityForResult(intent, PICK_FILE_REQUEST);
        } catch (Exception error) {
            MethodChannel.Result callback = pendingFileResult;
            pendingFileResult = null;
            callback.error(
                    "PICKER_UNAVAILABLE",
                    "Tiada pemilih fail yang tersedia pada peranti ini.",
                    null
            );
        }
    }

    private void startFileSaver(
            String sourcePath,
            String displayName,
            String requestedMimeType,
            MethodChannel.Result result
    ) {
        if (pendingSaveResult != null) {
            result.error("SAVER_BUSY", "Penyimpan fail sedang digunakan.", null);
            return;
        }

        File source = new File(sourcePath);
        if (!source.isFile()) {
            result.error("SAVE_SOURCE_MISSING", "Fail sementara tidak ditemui.", null);
            return;
        }

        pendingSaveResult = result;
        pendingSaveSource = source;
        pendingSaveName = sanitizeFileName(displayName);

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(
                requestedMimeType == null || requestedMimeType.trim().isEmpty()
                        ? "application/octet-stream"
                        : requestedMimeType
        );
        intent.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivityForResult(intent, SAVE_FILE_REQUEST);
        } catch (Exception error) {
            MethodChannel.Result callback = pendingSaveResult;
            clearPendingSave();
            callback.error(
                    "SAVER_UNAVAILABLE",
                    "Tiada penyimpan fail yang tersedia pada peranti ini.",
                    null
            );
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST) {
            MethodChannel.Result callback = pendingFileResult;
            pendingFileResult = null;
            if (callback == null) {
                return;
            }
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                callback.success(null);
                return;
            }

            Uri uri = data.getData();
            ioExecutor.execute(() -> copyPickedFile(uri, callback));
            return;
        }

        if (requestCode == SAVE_FILE_REQUEST) {
            MethodChannel.Result callback = pendingSaveResult;
            File source = pendingSaveSource;
            String displayName = pendingSaveName;
            clearPendingSave();
            if (callback == null) {
                return;
            }
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                callback.success(null);
                return;
            }
            if (source == null || !source.isFile()) {
                callback.error("SAVE_SOURCE_MISSING", "Fail sementara tidak ditemui.", null);
                return;
            }

            Uri uri = data.getData();
            ioExecutor.execute(() -> copyFileToUri(source, uri, displayName, callback));
        }
    }

    private void clearPendingSave() {
        pendingSaveResult = null;
        pendingSaveSource = null;
        pendingSaveName = null;
    }

    private void copyPickedFile(Uri uri, MethodChannel.Result callback) {
        File outputFile = null;
        try {
            String displayName = queryDisplayName(uri);
            File pickerDir = new File(getCacheDir(), "forgedeck-picker");
            if (!pickerDir.exists() && !pickerDir.mkdirs()) {
                throw new IOException("Folder cache pemilih fail tidak dapat dibuat.");
            }

            outputFile = new File(
                    pickerDir,
                    UUID.randomUUID() + "-" + sanitizeFileName(displayName)
            );

            long total = 0L;
            try (
                    InputStream input = getContentResolver().openInputStream(uri);
                    FileOutputStream output = new FileOutputStream(outputFile)
            ) {
                if (input == null) {
                    throw new IOException("Fail yang dipilih tidak dapat dibuka.");
                }
                byte[] buffer = new byte[64 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    if (total > MAX_PICKED_FILE_BYTES) {
                        throw new IOException("Fail melebihi had pemilih 512 MB.");
                    }
                    output.write(buffer, 0, count);
                }
                output.flush();
            }

            Map<String, Object> payload = new HashMap<>();
            payload.put("path", outputFile.getAbsolutePath());
            payload.put("name", displayName);
            payload.put("size", total);
            runOnUiThread(() -> callback.success(payload));
        } catch (Exception error) {
            if (outputFile != null && outputFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                outputFile.delete();
            }
            String message = error.getMessage() == null
                    ? "Fail tidak dapat dibaca."
                    : error.getMessage();
            runOnUiThread(() -> callback.error("FILE_READ_FAILED", message, null));
        }
    }

    private void copyFileToUri(
            File source,
            Uri destination,
            String displayName,
            MethodChannel.Result callback
    ) {
        try (
                InputStream input = new FileInputStream(source);
                OutputStream output = getContentResolver().openOutputStream(destination, "w")
        ) {
            if (output == null) {
                throw new IOException("Lokasi simpan tidak dapat dibuka.");
            }
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            output.flush();
            String finalName = displayName == null || displayName.isEmpty()
                    ? queryDisplayName(destination)
                    : displayName;
            runOnUiThread(() -> callback.success(finalName));
        } catch (Exception error) {
            String message = error.getMessage() == null
                    ? "Fail tidak dapat disimpan."
                    : error.getMessage();
            runOnUiThread(() -> callback.error("FILE_SAVE_FAILED", message, null));
        }
    }

    private String queryDisplayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(
                uri,
                new String[]{OpenableColumns.DISPLAY_NAME},
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    name = cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
            // Fallback di bawah.
        }
        if (name == null || name.trim().isEmpty()) {
            String segment = uri.getLastPathSegment();
            name = segment == null || segment.trim().isEmpty()
                    ? "selected-file"
                    : segment;
        }
        return sanitizeFileName(name);
    }

    private static String sanitizeFileName(String input) {
        String sanitized = input
                .replace('\\', '_')
                .replace('/', '_')
                .replace('\u0000', '_')
                .trim();
        if (sanitized.isEmpty() || ".".equals(sanitized) || "..".equals(sanitized)) {
            return "selected-file";
        }
        return sanitized.length() > 180 ? sanitized.substring(sanitized.length() - 180) : sanitized;
    }

    private void requestLegacyStoragePermission(MethodChannel.Result result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Build.VERSION.SDK_INT >= 33) {
            result.success(permissionPayload(false, true, false));
            return;
        }

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            result.success(permissionPayload(true, true, false));
            return;
        }

        if (pendingPermissionResult != null) {
            result.error("PERMISSION_BUSY", "Permintaan izin sedang dipaparkan.", null);
            return;
        }
        pendingPermissionResult = result;
        requestPermissions(
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                STORAGE_PERMISSION_REQUEST
        );
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != STORAGE_PERMISSION_REQUEST) {
            return;
        }

        MethodChannel.Result callback = pendingPermissionResult;
        pendingPermissionResult = null;
        if (callback == null) {
            return;
        }

        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        boolean permanentlyDenied = !granted
                && !shouldShowRequestPermissionRationale(
                Manifest.permission.READ_EXTERNAL_STORAGE
        );
        callback.success(permissionPayload(true, granted, permanentlyDenied));
    }

    private static Map<String, Object> permissionPayload(
            boolean required,
            boolean granted,
            boolean permanentlyDenied
    ) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("required", required);
        payload.put("granted", granted);
        payload.put("permanentlyDenied", permanentlyDenied);
        return payload;
    }

    private void openApplicationSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private SharedPreferences securePreferences() {
        return getSharedPreferences(SECURE_PREFS, MODE_PRIVATE);
    }

    private void writeSecure(String key, String value)
            throws GeneralSecurityException, IOException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String encoded = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)
                + "."
                + Base64.encodeToString(encrypted, Base64.NO_WRAP);
        securePreferences().edit().putString(key, encoded).apply();
    }

    private String readSecure(String key) {
        String encoded = securePreferences().getString(key, null);
        if (encoded == null || encoded.isEmpty()) {
            return null;
        }

        try {
            String[] parts = encoded.split("\\.", 2);
            if (parts.length != 2) {
                throw new GeneralSecurityException("Format storan selamat tidak sah.");
            }
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(
                    Cipher.DECRYPT_MODE,
                    getOrCreateSecretKey(),
                    new GCMParameterSpec(128, iv)
            );
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception error) {
            // Data backup tanpa kunci Keystore tidak boleh dinyahenkripsi.
            securePreferences().edit().remove(key).apply();
            return null;
        }
    }

    private SecretKey getOrCreateSecretKey()
            throws GeneralSecurityException, IOException {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    "AndroidKeyStore"
            );
            generator.init(
                    new KeyGenParameterSpec.Builder(
                            KEY_ALIAS,
                            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
                    )
                            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                            .setRandomizedEncryptionRequired(true)
                            .build()
            );
            generator.generateKey();
        }
        KeyStore.SecretKeyEntry entry = (KeyStore.SecretKeyEntry) keyStore.getEntry(
                KEY_ALIAS,
                null
        );
        return entry.getSecretKey();
    }

    @Override
    protected void onDestroy() {
        ioExecutor.shutdownNow();
        super.onDestroy();
    }
}
