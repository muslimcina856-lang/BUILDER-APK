@echo off
setlocal
set APP_HOME=%~dp0
set LOCK_DIR=%APP_HOME%forgedeck-build-lock
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set REQUIRED_GRADLE=8.14
set REQUIRED_GRADLE_SHA256=61ad310d3c7d3e5da131b76bbf22b5a4c0786e9d892dae8c1658d4b484de3caa

copy /Y "%LOCK_DIR%\settings.gradle.lock" "%APP_HOME%settings.gradle" >nul
copy /Y "%LOCK_DIR%\root-build.gradle.lock" "%APP_HOME%build.gradle" >nul
copy /Y "%LOCK_DIR%\app-build.gradle.lock" "%APP_HOME%app\build.gradle" >nul
copy /Y "%LOCK_DIR%\gradle-wrapper.properties.lock" "%APP_HOME%gradle\wrapper\gradle-wrapper.properties" >nul
copy /Y "%LOCK_DIR%\gradle.properties.lock" "%APP_HOME%gradle.properties" >nul
del /Q "%APP_HOME%settings.gradle.kts" "%APP_HOME%build.gradle.kts" "%APP_HOME%app\build.gradle.kts" 2>nul

echo ForgeDeck build guard: API 36 ^| AGP 8.12.1 ^| Gradle 8.14 ^| Java 17+ ^| native Java bridge

if defined JAVA_HOME (
  set JAVACMD=%JAVA_HOME%\bin\java.exe
) else (
  set JAVACMD=java
)

if exist "%WRAPPER_JAR%" (
  "%JAVACMD%" -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)

if defined GRADLE_USER_HOME (
  set CACHE_ROOT=%GRADLE_USER_HOME%
) else (
  set CACHE_ROOT=%USERPROFILE%\.gradle
)
set BOOTSTRAP_ROOT=%CACHE_ROOT%\forgedeck\dists
set GRADLE_HOME=%BOOTSTRAP_ROOT%\gradle-%REQUIRED_GRADLE%
set GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%BOOTSTRAP_ROOT%" mkdir "%BOOTSTRAP_ROOT%"
  set ARCHIVE=%BOOTSTRAP_ROOT%\gradle-%REQUIRED_GRADLE%-bin.zip
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%REQUIRED_GRADLE%-bin.zip' -OutFile '%ARCHIVE%'; $actual=(Get-FileHash -Algorithm SHA256 '%ARCHIVE%').Hash.ToLowerInvariant(); if($actual -ne '%REQUIRED_GRADLE_SHA256%'){Remove-Item -Force '%ARCHIVE%'; throw 'Checksum Gradle tidak sepadan.'}; Expand-Archive -Force '%ARCHIVE%' '%BOOTSTRAP_ROOT%'; Remove-Item -Force '%ARCHIVE%'"
  if errorlevel 1 exit /b 1
)

pushd "%APP_HOME%"
call "%GRADLE_BIN%" %*
set EXIT_CODE=%ERRORLEVEL%
popd
exit /b %EXIT_CODE%
