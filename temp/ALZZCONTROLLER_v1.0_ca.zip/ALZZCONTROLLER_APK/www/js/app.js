// ============================================================
// ALZZCONTROLLER - MAIN APP
// OWNER: @alzzisbackv2
// ============================================================

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    
    function toggleSidebar() {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    }
    
    menuBtn.addEventListener('click', toggleSidebar);
    overlay.addEventListener('click', toggleSidebar);
    
    // Close sidebar on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && sidebar.classList.contains('open')) {
            toggleSidebar();
        }
    });
    
    // Terminal simulation
    const terminalInput = document.getElementById('terminalInput');
    const terminalOutput = document.getElementById('terminalOutput');
    
    function addTerminalOutput(text, type) {
        const line = document.createElement('div');
        if (type === 'cmd') {
            line.innerHTML = `<span class="prompt">$</span> <span class="cmd">${text}</span>`;
        } else if (type === 'output') {
            line.innerHTML = `<span class="output">${text}</span>`;
        } else if (type === 'error') {
            line.innerHTML = `<span style="color:#ff0000">${text}</span>`;
        }
        terminalOutput.appendChild(line);
        terminalOutput.scrollTop = terminalOutput.scrollHeight;
    }
    
    // Command list
    const commands = {
        'help': 'Available commands: help, clear, devices, connect, status, info, exploit, shell, download',
        'clear': 'CLEAR',
        'devices': 'Connected devices: 0',
        'status': 'ALZZCONTROLLER v1.0 | Status: ONLINE',
        'info': 'ALZZCONTROLLER by @alzzisbackv2',
        'exploit': 'Exploit module ready...',
        'shell': 'Shell access granted...',
        'download': 'Downloading payload...'
    };
    
    terminalInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const cmd = terminalInput.value.trim();
            if (cmd) {
                addTerminalOutput(cmd, 'cmd');
                terminalInput.value = '';
                
                if (cmd === 'clear') {
                    terminalOutput.innerHTML = '';
                    return;
                }
                
                const result = commands[cmd] || `Command not found: ${cmd}`;
                if (result === 'CLEAR') return;
                addTerminalOutput(result, 'output');
            }
        }
    });
    
    // Welcome message
    addTerminalOutput('ALZZCONTROLLER v1.0 ready', 'output');
    addTerminalOutput('Type "help" for commands', 'output');
    
    // Device cards - dynamic
    const deviceGrid = document.getElementById('deviceGrid');
    const devices = [
        { name: 'TARGET_01', status: 'online', info: 'Android 14' },
        { name: 'TARGET_02', status: 'online', info: 'Android 13' },
        { name: 'TARGET_03', status: 'offline', info: 'Android 12' }
    ];
    
    devices.forEach(device => {
        const card = document.createElement('div');
        card.className = 'device-card';
        card.innerHTML = `
            <div class="name">${device.name}</div>
            <div class="info">${device.info}</div>
            <div class="status ${device.status === 'online' ? '' : 'offline'}">● ${device.status}</div>
        `;
        deviceGrid.appendChild(card);
    });
});
