#!/bin/bash

echo ""
echo "🔥 BUILDING ALZZCONTROLLER APK"
echo "========================================"
echo ""

# Check NodeJS
if ! command -v node &> /dev/null; then
    echo "[!] NodeJS not found. Installing..."
    pkg install nodejs -y
fi

# Install Capacitor
echo "[*] Installing Capacitor..."
npm install -g @capacitor/cli
npm install @capacitor/android @capacitor/core

# Sync
echo "[*] Syncing..."
npx cap sync android

# Build
echo "[*] Building APK..."
npx cap build android

echo ""
echo "[✓] APK built successfully!"
echo "[✓] Location: android/app/build/outputs/apk/debug/app-debug.apk"
