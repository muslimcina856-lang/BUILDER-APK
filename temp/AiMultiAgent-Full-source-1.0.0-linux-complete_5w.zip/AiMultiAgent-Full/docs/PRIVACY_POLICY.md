# Polisi Privasi Ai MultiAgent

Tarikh berkuat kuasa: 2 Ogos 2026

Ai MultiAgent ialah aplikasi local/BYOK tanpa akaun dan tanpa backend milik Ai MultiAgent. Data disimpan pada peranti kecuali kandungan yang pengguna atau model hantar terus kepada provider AI, laman web, URL muat turun atau server MCP yang dikonfigurasi.

## Data local

Aplikasi boleh menyimpan:

- Konfigurasi provider, model dan parameter.
- API key dalam secure storage Android.
- Mesej chat, memory, skills, automasi dan MCP.
- Lampiran, fail workspace dan fail muat turun.
- Cookies/sesi laman dalam Android System WebView.
- Metadata serta ringkasan log tool yang melalui redaction asas.
- Audio sementara ketika input suara digunakan.

Backup Android biasa dimatikan melalui `android:allowBackup="false"`.

## Data dihantar keluar

Bergantung pada tindakan dan model aktif, aplikasi boleh menghantar:

- Prompt, konteks, hasil tool dan lampiran kepada Base URL provider.
- API key melalui kaedah autentikasi provider.
- Query kepada DuckDuckGo.
- Permintaan, borang dan cookies kepada laman yang diproses browser tersembunyi.
- Permintaan kepada server MCP local.
- URL untuk memuat turun skill atau fail.

Provider, laman dan skill pihak ketiga mempunyai polisi mereka sendiri. Gunakan hanya endpoint dan sumber yang dipercayai.

## Media dan fail

Imej, video, audio, dokumen, HTML dan fail lain boleh dipilih atau dihasilkan dalam chat. Fail disalin ke storan private aplikasi. Sesuatu provider hanya menerima kandungan atau metadata fail apabila runtime menghantarnya untuk memenuhi arahan pengguna.

## Kawalan pengguna

Pengguna boleh:

- Melihat, mengubah dan memadam provider/API key.
- Memadam chat, memory, skills, automasi, MCP dan fail workspace.
- Menarik balik rule **Sentiasa benarkan**.
- Menghentikan tugasan dan background execution.
- Menggunakan fungsi padam semua data local.

## Mikrofon

Permission mikrofon digunakan hanya apabila input suara diaktifkan. Tiada audio dihantar kepada backend Ai MultiAgent kerana backend tersebut tidak wujud; pemprosesan bergantung pada peranti dan provider yang dipilih.

## Hubungi

Sebelum penerbitan, gantikan bahagian ini dengan nama penerbit, e-mel sokongan dan URL polisi privasi rasmi.
