# Upload keystore Android

Jalankan sekali pada komputer pemilik akaun penerbit:

```bash
keytool -genkeypair -v \
  -keystore mobile/android/app/upload-keystore.jks \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -alias upload
```

Kemudian:

```bash
cp mobile/android/key.properties.example mobile/android/key.properties
```

Isi kata laluan sebenar. Jangan commit `key.properties` atau keystore ke Git awam. Simpan backup terenkripsi. Jika perkhidmatan app signing gedung aplikasi digunakan, fail ini ialah upload key, bukan app signing key yang diurus Google.
