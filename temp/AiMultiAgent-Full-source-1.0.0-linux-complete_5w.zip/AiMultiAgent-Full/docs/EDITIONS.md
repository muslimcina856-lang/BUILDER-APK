# Full Edition

Ini ialah projek standalone Full sahaja. Package ID `com.aiauto.claw.full`, compile API 36 dan compatibility target API 28 untuk executable Linux dalam app-private storage.
