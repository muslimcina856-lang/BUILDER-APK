# Status Projek Ai MultiAgent 1.0.0+1

## Selesai dalam kod sumber

- Dua edisi Android: Standard dan Full dengan package ID berasingan.
- Standard menggunakan `compileSdk/targetSdk 36`; Full menggunakan `compileSdk 36`, compatibility `targetSdk 28`.
- Build Full menyediakan dan membundel Alpine Linux 3.24.1 aarch64 + PRoot 0.15 secara automatik.
- Release Full dihadkan kepada `arm64-v8a` dan build gagal jika runtime tiada daripada APK/AAB.
- Linux dipasang automatik sebelum arahan terminal AI pertama, disahkan melalui health check `aarch64`/Alpine/`apk-tools`, serta dinaik taraf dengan transaksi crash-safe, rollback dan data projek pengguna kekal.
- AI mengetahui distribution, versi, guest architecture, package manager `apk`, terminal tanpa stdin interaktif, guest root tanpa `sudo`, sempadan PRoot dan aliran status/start/poll/stop.
- Linux Workspace berada dalam `getApplicationSupportDirectory()/linux`; tiada permission storan luaran luas atau bind automatik ke shared storage.
- Dashboard Workspace, terminal, proses latar, import pemulihan runtime dan reset+pasang semula tersedia.
- Browser Chromium tersembunyi, UI chat, provider BYOK, orchestrator, tools, skills, automasi, MCP dan approval berasaskan risiko tersedia.
- Java 17, Gradle 8.14.3, AGP 8.11.1, Kotlin 2.2.20, R8 dan resource shrinking dikonfigurasi.
- Workflow CI membina APK/AAB release dan mengesahkan `mapping.txt`, checksum serta runtime Linux dalam artifact.
- Build debug juga menyediakan runtime yang sama, mengehadkan output kepada ARM64 dan mengesahkan asset Linux berada dalam APK.

## Pengesahan

- Struktur source, XML, YAML, shell dan Python diperiksa secara statik.
- Pembina runtime mempunyai pemeriksaan checksum, CRC, nama entri unik, tar/ZIP traversal, symlink, jenis entri, had saiz, permission Unix, ELF64 AArch64 dan manifest.
- Pemasang aplikasi mempunyai had arkib, staging/backup, pemulihan selepas process-kill, permission restore, health check dan rollback.
- Terminal mempunyai rolling output buffer, had 8 job serentak/64 job tersimpan, UTF-8 toleran dan penghentian semua proses pada cancel/reset/had latar belakang.
- Build Android/health check pada peranti tetap perlu dijalankan dalam persekitaran Flutter + Android SDK dan telefon ARM64 sebenar.
