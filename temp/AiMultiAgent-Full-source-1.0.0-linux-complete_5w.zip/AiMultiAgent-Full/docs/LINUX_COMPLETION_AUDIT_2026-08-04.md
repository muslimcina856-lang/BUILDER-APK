# Audit Penyiapan Linux Terbina — 4 Ogos 2026

## Keputusan

Kod sumber Ai MultiAgent Full kini mempunyai pipeline lengkap untuk membina, membundel, memasang dan memberi akses AI kepada Alpine Linux 3.24.1 ARM64 melalui PRoot 0.15. Runtime dijana sebelum build Android dan build akan gagal jika asset Linux hilang, berubah checksum, tidak sah, atau tidak benar-benar berada dalam APK/AAB.

## Linux dan AI

- Guest: Alpine Linux 3.24.1 `aarch64`.
- Enjin: PRoot Android 0.15, binary ELF64 AArch64.
- Pengurus pakej: `apk`; arahan contoh `apk update && apk add --no-cache git python3`.
- Lokasi guest: projek `/workspace`, home `/root`, sementara `/tmp`.
- AI menerima status/version/architecture/package manager setiap permulaan tugasan.
- AI diarahkan menggunakan `linux_workspace_status` -> `terminal_start` -> `terminal_poll`, serta `terminal_stop` apabila perlu.
- Terminal tidak mempunyai stdin interaktif; AI diarahkan mengelakkan editor interaktif dan tidak menggunakan `sudo` kerana guest sudah root.
- Ini bukan root Android, bukan VM/kernel baharu dan bukan akses kepada PC jauh.

## Pemasangan dan pemulihan

- Runtime dipasang automatik sebelum arahan terminal pertama.
- Pemasangan menggunakan direktori staging dan backup.
- Jika proses/telefon mati semasa pertukaran rootfs, transaksi dipulihkan pada permulaan seterusnya.
- Health check menjalankan PRoot sebenar dan mengesahkan token, `uname -m=aarch64`, Alpine 3.24.1, `/sbin/apk` dan output `apk-tools`.
- Health check gagal menyebabkan rollback ke runtime sebelumnya.
- Naik taraf mengekalkan workspace, home, cache browser dan snapshot. Pakej yang mengubah rootfs perlu dipasang semula selepas versi runtime bertukar.
- Reset menghentikan proses aktif, memadam workspace Linux milik aplikasi sahaja, lalu memasang runtime bawaan semula.

## Keselamatan arkib

Pembina dan pemasang Android menolak:

- path traversal dan laluan mutlak yang tidak dibenarkan;
- entri berganda atau laluan ternormalisasi yang bertindih;
- symlink keluar sandbox atau ke storan/data Android sensitif;
- symlink kosong, NUL atau melebihi 4 KiB;
- device/FIFO/sparse/jenis fail asing;
- CRC ZIP rosak;
- arkib terkompres melebihi 512 MiB;
- jumlah ekstrak melebihi 2 GiB;
- lebih 100,000 entri atau satu entri melebihi 512 MiB;
- manifest/version/distribution/ABI/package manager yang salah;
- PRoot tanpa permission executable;
- binary bukan ELF64 little-endian AArch64.

## Terminal dan lifecycle

- Stdout dan stderr setiap job menggunakan rolling buffer 48,000 aksara.
- UTF-8 rosak diterima tanpa menjatuhkan stream.
- Maksimum 8 proses berjalan serentak dan 64 rekod job disimpan.
- Stop menggunakan SIGTERM, kemudian SIGKILL jika proses tidak berhenti.
- Semua job dihentikan apabila larian dibatalkan, sesi ditukar/dipadam, data lokal dipadam, runtime diimport/reset atau had latar belakang 30 minit tamat.

## Build debug/release

- `scripts/build_debug.sh` menjana runtime dan membina APK debug ARM64.
- `scripts/build_full.sh` menjana APK release ARM64 dan AAB release ARM64.
- Kedua-duanya mengesahkan runtime sumber, mengesan tepat satu asset runtime dalam artifact, mengekstraknya, membandingkan SHA-256 dan menjalankan semula verifikasi ZIP/manifest/ELF.
- Release mengaktifkan R8 minify dan resource shrinking serta gagal jika `mapping.txt` tidak dijana.
- Workflow GitHub Actions menggunakan Java 17, Flutter 3.44.8 dan cache sumber runtime yang dipinkan.
- Source ZIP tidak menyimpan `runtime-pack.zip` terjana. Skrip build/CI menjana fail itu daripada sumber version/commit-pinned dan artifact Android akhir mesti mengandunginya.

## Validasi yang dijalankan di persekitaran ini

Lulus:

- `./scripts/check_project.sh`;
- pemeriksaan source/release/R8/manifest/background/browser/AI/Linux;
- parser XML/YAML serta delimiter Dart/Kotlin;
- `bash -n` untuk skrip build;
- kompilasi sintaks Python;
- ujian pembina runtime tanpa rangkaian: traversal, symlink, entri tar/ZIP berganda, mode Unix, kontrak manifest dan ELF AArch64;
- fixture parser DuckDuckGo offline;
- integriti ZIP source akhir dan SHA-256.

Tidak boleh dijalankan di persekitaran ini:

- `flutter pub get`, `flutter analyze`, `flutter test` dan build Gradle kerana Flutter/Android SDK tidak tersedia;
- muat turun binary Alpine/PRoot kerana rangkaian binary container disekat;
- health check PRoot pada telefon Android ARM64 sebenar;
- smoke test APK/AAB release pada vendor/peranti sebenar.

Oleh itu, audit ini mengesahkan kod sumber dan mekanisme fail-fast build. APK/AAB hanya patut dianggap siap produksi selepas `scripts/build_full.sh` lulus dalam CI/mesin Android SDK dan checklist peranti sebenar diselesaikan.
