# Seni Bina Ai MultiAgent 1.0.0

```text
Flutter shared code
├── Chat / Provider / Automasi / Skills / Lain-lain
├── AppState + SQLite + Secure Storage
├── ProviderService + AgentRuntime + ToolEngine
├── DuckDuckGo + Hidden Browser + Files + Terminal + MCP
└── LinuxWorkspaceService
        ├── bundled asset installer
        ├── staging + backup + rollback
        ├── ARM64 ELF/manifest/health validation
        └── PRoot command isolation

Android editions
├── Standard -> com.aiauto.claw (target 36)
│   └── AI tools + browser + private file sandbox
└── Full -> com.aiauto.claw.full (target 28, release ARM64)
    └── Alpine Linux 3.24.1 aarch64 + PRoot 0.15 + apk
```

Setiap edisi mempunyai UID dan direktori data berasingan. Linux Workspace menggunakan direktori support aplikasi. Guest hanya menerima bind `/workspace`, `/root`, `/tmp`, `/proc` dan peranti asas; storan luaran serta data aplikasi lain tidak dibind.

AI menerima konteks Android/browser/ABI pada permulaan tugasan. Untuk Linux, model menerima arahan eksplisit tentang `apk`, terminal non-interaktif tanpa `sudo`, aliran `linux_workspace_status` -> `terminal_start` -> `terminal_poll`/`terminal_stop`, serta batas bahawa PRoot bukan root Android, VM penuh atau PC jauh. Pemasangan rootfs menggunakan staging/backup dengan pemulihan selepas process-kill dan rollback selepas health check gagal.
