# Fix timeout, background, browser context dan release

- Timeout provider lalai dinaikkan daripada 60 saat kepada 180 saat; konfigurasi lama 60 saat dimigrasikan automatik.
- Browser WebView/Chromium menggunakan mod desktop secara lalai dan had operasi native dinaikkan.
- Konteks sebenar Android/browser disuntik pada setiap tugasan dan `runtime_info` membolehkan semakan semula; browser desktop emulasi dibezakan daripada PC jauh.
- Skrin kekal menyala semasa Activity berada di hadapan.
- Tugasan aktif boleh menggunakan foreground service + partial wake lock sehingga 30 minit apabila pilihan latar belakang dihidupkan; pilihan ini aktif secara lalai pada pemasangan baharu.
- Release APK dan AAB dibina untuk edisi Full; R8 minify/resource shrink kekal aktif dan laporan mapping disalin ke `dist`.
- Tanpa `android/key.properties`, artifact release masih boleh diuji menggunakan debug signing tetapi bukan untuk pengedaran produksi.
