# Laporan validasi — 3 Ogos 2026

## Status

**Lulus untuk semakan source/statik.** Kedua-dua arahan `scripts/verify_source.py` dan `scripts/verify_release_config.py` lulus. Fixture DuckDuckGo lulus 6 pemeriksaan.

## Yang disahkan

- `compileSdk 36`; target API edisi ini ialah `28` dan dipaparkan dalam aplikasi.
- Release `isDebuggable=false`, R8 minify aktif, resource shrinking aktif dan rules native disediakan.
- Skrip release membina APK + AAB, menguji integriti ZIP dan gagal jika `mapping.txt` R8 tidak dijana.
- `FLAG_KEEP_SCREEN_ON` aktif hanya ketika Activity berada di hadapan.
- Foreground service `dataSync`, partial wake lock dan timer Dart/native mengehadkan operasi latar belakang kepada 30 minit.
- Kegagalan foreground service OEM tidak meninggalkan UI pada status penghantaran palsu.
- Browser Android System WebView/Chromium mempunyai mod desktop, timeout native lebih panjang dan fallback HTTP.
- Konteks peranti/browser disuntik terus ke prompt model dan juga tersedia melalui `runtime_info`.
- Tiada label gedung lama dalam kod UI; edisi biasa dipaparkan sebagai `Standard`.
- XML manifest, YAML workflow, shell scripts, Python scripts dan keseimbangan delimiter Dart/Kotlin diperiksa.

## Had validasi persekitaran ini

Flutter SDK dan Android SDK tidak tersedia dalam container, jadi `flutter analyze`, `flutter test`, binaan APK/AAB sebenar dan eksekusi R8 sebenar tidak dapat dijalankan secara lokal. Workflow CI dipinkan kepada Flutter 3.44.8 dan memanggil `scripts/build_full.sh`; skrip itu hanya berjaya apabila APK, AAB dan `mapping.txt` benar-benar terhasil.

## Arahan build

```bash
./scripts/build_full.sh
```

Output: `dist/full/`.
