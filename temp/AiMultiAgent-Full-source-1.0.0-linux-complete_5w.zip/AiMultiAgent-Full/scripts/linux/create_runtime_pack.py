#!/usr/bin/env python3
"""Cipta runtime recovery pack tersuai yang serasi dengan edisi Full.

Untuk release biasa, gunakan prepare_bundled_runtime.py atau build_full.sh. Skrip
ini hanya untuk pemulihan/pembangunan apabila binary PRoot Android ARM64 dan
Alpine 3.24.1 rootfs yang dipercayai sudah tersedia secara lokal.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path

from prepare_bundled_runtime import (
    ALPINE_VERSION,
    RUNTIME_SCHEMA,
    RUNTIME_VERSION,
    RuntimeBuildError,
    configure_rootfs,
    create_pack,
    sha256_file,
    validate_arm64_elf,
    verify_pack,
)


def tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(rel + b"\0")
        if path.is_symlink():
            digest.update(b"L" + str(path.readlink()).encode("utf-8") + b"\0")
        elif path.is_file():
            digest.update(b"F")
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
        elif path.is_dir():
            digest.update(b"D")
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Cipta runtime recovery pack Alpine ARM64 untuk Ai MultiAgent Full."
    )
    parser.add_argument("--proot", required=True, type=Path)
    parser.add_argument("--rootfs", required=True, type=Path)
    parser.add_argument("--libs", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    if not args.proot.is_file():
        raise SystemExit("Binary PRoot tidak ditemui.")
    validate_arm64_elf(args.proot)
    if not (args.rootfs / "bin/sh").exists():
        raise SystemExit("rootfs/bin/sh tidak ditemui.")
    if not (args.rootfs / "sbin/apk").exists():
        raise SystemExit("rootfs/sbin/apk tidak ditemui; rootfs mestilah Alpine.")
    release_file = args.rootfs / "etc/alpine-release"
    if not release_file.is_file() or release_file.read_text().strip() != ALPINE_VERSION:
        raise SystemExit(f"Rootfs mestilah Alpine {ALPINE_VERSION} tepat.")

    project_root = Path(__file__).resolve().parents[2]
    licenses = project_root / "scripts/linux/licenses"
    with tempfile.TemporaryDirectory(prefix="ai-linux-custom-") as temp_name:
        stage = Path(temp_name) / "stage"
        shutil.copytree(args.rootfs, stage / "rootfs", symlinks=True)
        runtime_bin = stage / "runtime/bin"
        runtime_bin.mkdir(parents=True, exist_ok=True)
        shutil.copy2(args.proot, runtime_bin / "proot")
        (runtime_bin / "proot").chmod(0o700)
        if args.libs:
            if not args.libs.is_dir():
                raise SystemExit("Direktori --libs tidak sah.")
            shutil.copytree(
                args.libs,
                stage / "runtime/lib",
                dirs_exist_ok=True,
                symlinks=True,
            )
        configure_rootfs(stage, licenses)
        manifest = {
            "schema": RUNTIME_SCHEMA,
            "runtime_version": RUNTIME_VERSION,
            "architecture": "aarch64",
            "android_abi": "arm64-v8a",
            "distribution": "Alpine Linux",
            "distribution_version": ALPINE_VERSION,
            "package_manager": "apk",
            "shell": "/bin/sh",
            "proot_version": "custom-compatible",
            "delivery": "manual_recovery_pack",
            "sources": {
                "proot_sha256": sha256_file(args.proot),
                "rootfs_tree_sha256": tree_digest(args.rootfs),
            },
        }
        manifest_path = stage / "runtime/manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        create_pack(stage, args.output.resolve())

    verified = verify_pack(args.output.resolve())
    digest = sha256_file(args.output.resolve())
    args.output.with_suffix(args.output.suffix + ".sha256").write_text(
        f"{digest}  {args.output.name}\n", encoding="utf-8"
    )
    print(json.dumps({"output": str(args.output), "sha256": digest, "manifest": verified}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except RuntimeBuildError as error:
        raise SystemExit(f"RUNTIME PACK GAGAL: {error}")
