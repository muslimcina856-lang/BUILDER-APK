#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "mobile" / "android"
PROPERTIES = ANDROID / "key.properties"

if not PROPERTIES.is_file():
    print("Build type release ditandatangani dengan debug key untuk ujian pemasangan sahaja.")
    print("Sediakan mobile/android/key.properties dan keystore sebenar sebelum pengedaran produksi.")
    raise SystemExit(0)

values: dict[str, str] = {}
for raw in PROPERTIES.read_text(encoding="utf-8").splitlines():
    line = raw.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, value = line.split("=", 1)
    values[key.strip()] = value.strip()

required = ("keyAlias", "keyPassword", "storeFile", "storePassword")
missing = [key for key in required if not values.get(key)]
store_raw = values.get("storeFile", "")
store = Path(store_raw).expanduser()
if not store.is_absolute():
    # Gradle's file(...) is evaluated from the app module directory.
    store = (ANDROID / "app" / store).resolve()

if missing or not store.is_file():
    print("Build type release menggunakan debug key kerana konfigurasi release tidak lengkap.")
    if missing:
        print("Medan kosong: " + ", ".join(missing))
    if store_raw and not store.is_file():
        print(f"Keystore tidak ditemui pada: {store}")
    print("Sediakan key.properties dan keystore sebenar sebelum pengedaran produksi.")
else:
    print("Build type release ditandatangani menggunakan keystore yang ditetapkan dalam key.properties.")
    print(f"Alias: {values['keyAlias']}")
    print(f"Keystore: {store}")
