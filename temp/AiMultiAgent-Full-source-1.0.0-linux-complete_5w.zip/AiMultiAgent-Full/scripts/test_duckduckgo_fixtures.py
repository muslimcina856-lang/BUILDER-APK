#!/usr/bin/env python3
"""Offline fixture smoke test for the DuckDuckGo result contract.

Only Python's standard library is used so the release workflow does not depend
on packages outside Flutter/Android.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Node:
    tag: str
    attrs: dict[str, str] = field(default_factory=dict)
    children: list["Node"] = field(default_factory=list)
    text_parts: list[str] = field(default_factory=list)
    parent: "Node | None" = None

    @property
    def text(self) -> str:
        values = list(self.text_parts)
        for child in self.children:
            values.append(child.text)
        return " ".join(values)


class TreeParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = Node("document")
        self.stack = [self.root]

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        node = Node(
            tag=tag.lower(),
            attrs={key.lower(): value or "" for key, value in attrs},
            parent=self.stack[-1],
        )
        self.stack[-1].children.append(node)
        if tag.lower() not in {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag.lower():
            self.stack.pop()

    def handle_endtag(self, tag: str) -> None:
        wanted = tag.lower()
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == wanted:
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        if data:
            self.stack[-1].text_parts.append(data)


def walk(node: Node):
    yield node
    for child in node.children:
        yield from walk(child)


def classes(node: Node) -> set[str]:
    return {value for value in node.attrs.get("class", "").split() if value}


def first_descendant(node: Node, *, tag: str | None = None, class_names: set[str] | None = None) -> Node | None:
    for candidate in walk(node):
        if candidate is node:
            continue
        if tag is not None and candidate.tag != tag:
            continue
        if class_names is not None and not (classes(candidate) & class_names):
            continue
        return candidate
    return None


def clean(value: str) -> str:
    return " ".join(value.split())


def decode_redirect(raw: str) -> str:
    value = f"https:{raw}" if raw.startswith("//") else raw
    parsed = urlparse(value)
    redirected = parse_qs(parsed.query).get("uddg", [None])[0]
    return unquote(redirected) if redirected else value


def valid(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def parse_tree(body: str) -> Node:
    parser = TreeParser()
    parser.feed(body)
    parser.close()
    return parser.root


def parse_html(body: str, limit: int = 20) -> list[dict]:
    root = parse_tree(body)
    output: list[dict] = []
    seen: set[str] = set()
    for element in walk(root):
        if element.tag != "div" or not (classes(element) & {"result", "web-result"}):
            continue
        anchor = first_descendant(element, tag="a", class_names={"result__a", "result-link"})
        if anchor is None:
            continue
        url = decode_redirect(anchor.attrs.get("href", ""))
        if not valid(url) or url in seen:
            continue
        seen.add(url)
        display = first_descendant(element, class_names={"result__url", "result-url"})
        snippet = first_descendant(element, class_names={"result__snippet", "result-snippet"})
        output.append(
            {
                "rank": len(output) + 1,
                "title": clean(anchor.text) or url,
                "url": url,
                "display_url": clean(display.text) if display else urlparse(url).netloc,
                "snippet": clean(snippet.text) if snippet else "",
                "source": "html",
            }
        )
        if len(output) >= limit:
            break
    return output


def parse_lite(body: str, limit: int = 20) -> list[dict]:
    root = parse_tree(body)
    output: list[dict] = []
    seen: set[str] = set()
    rows = [node for node in walk(root) if node.tag == "tr"]
    row_index = {id(row): index for index, row in enumerate(rows)}
    for anchor in walk(root):
        if anchor.tag != "a" or "result-link" not in classes(anchor):
            continue
        url = decode_redirect(anchor.attrs.get("href", ""))
        if not valid(url) or url in seen:
            continue
        seen.add(url)
        row = anchor.parent
        while row is not None and row.tag != "tr":
            row = row.parent
        snippet = ""
        if row is not None:
            index = row_index.get(id(row), -1)
            if 0 <= index + 1 < len(rows):
                snippet_node = first_descendant(rows[index + 1], class_names={"result-snippet"})
                snippet = clean((snippet_node or rows[index + 1]).text)
        output.append(
            {
                "rank": len(output) + 1,
                "title": clean(anchor.text),
                "url": url,
                "display_url": urlparse(url).netloc,
                "snippet": snippet,
                "source": "lite",
            }
        )
        if len(output) >= limit:
            break
    return output


def main() -> None:
    html_results = parse_html((ROOT / "mobile/test/fixtures/duckduckgo_html.html").read_text())
    lite_results = parse_lite((ROOT / "mobile/test/fixtures/duckduckgo_lite.html").read_text())

    assert len(html_results) == 2, html_results
    assert html_results[0]["url"] == "https://example.com/alpha?x=1&y=2"
    assert html_results[0]["snippet"] == "Alpha snippet with useful details."
    assert len(lite_results) == 2, lite_results
    assert lite_results[0]["url"] == "https://lite.example.net/one"
    assert lite_results[0]["snippet"] == "A complete Lite result snippet."

    report = {
        "test": "DuckDuckGo offline parser fixture",
        "status": "passed",
        "checks": 6,
        "html_results": html_results,
        "lite_results": lite_results,
        "note": "Live DuckDuckGo network test requires a network-enabled Android/build environment.",
    }
    path = ROOT / "docs/test-results/duckduckgo_fixture_result.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
