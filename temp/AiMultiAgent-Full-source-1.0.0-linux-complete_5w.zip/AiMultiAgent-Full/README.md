# Ai MultiAgent Full

Aplikasi Android BYOK tanpa backend perantara. Package ID `com.aiauto.claw.full`, versi `1.0.0+1`, `compileSdk 36`, `targetSdk 28`.

## Pembetulan utama

- Timeout provider lalai 180 saat dan konfigurasi lama 60 saat dimigrasikan automatik.
- Skrin kekal menyala semasa aplikasi berada di hadapan.
- Tugasan aktif diteruskan melalui foreground service dan partial wake lock sehingga 30 minit apabila Android tidak menyekat aplikasi.
- AI menerima konteks runtime Android/browser sebenar pada setiap tugasan; browser Chromium tersembunyi menggunakan mod desktop secara lalai.
- Build release menghasilkan APK dan AAB, mengaktifkan R8 + resource shrinking, serta mewajibkan `mapping.txt`.
- Target API dipaparkan terus pada skrin Tetapan dan Lagi.

Linux Workspace kini membundel Alpine Linux 3.24.1 ARM64 + PRoot 0.15 secara automatik dalam build Full. AI memasang dan mengesahkannya sebelum arahan terminal pertama serta menggunakan pengurus pakej `apk`. Pemasangan menggunakan transaksi staging/backup, pulih selepas proses terhenti, rollback apabila health check gagal, dan menolak ZIP berbahaya atau melampaui had. Output terminal serta bilangan job juga dihadkan untuk mengelakkan penggunaan memori tanpa had.

## Build debug dan release

Gunakan Flutter `3.44.8`, Java 17, Python 3, akses Internet untuk penyediaan runtime pertama dan Android SDK 36. Kedua-dua skrip menyediakan, mengesahkan dan membundel runtime Linux sebelum Flutter bermula:

```bash
# APK debug ARM64
./scripts/build_debug.sh

# APK + AAB release ARM64
./scripts/build_full.sh
```

Untuk `flutter run` manual, sediakan asset dahulu:

```bash
python3 scripts/linux/prepare_bundled_runtime.py
python3 scripts/linux/prepare_bundled_runtime.py --verify-only
cd mobile
flutter pub get
flutter run
```

Output lengkap berada di `dist/full/`, termasuk APK/AAB ARM64, salinan runtime+manifest, `R8_STATUS.txt`, `SIGNING_INFO.txt`, laporan R8 dan SHA-256. Build gagal jika Linux runtime tidak ditemui dalam kedua-dua artifact. Source ZIP sengaja tidak menyimpan binary runtime yang dijana; `build_debug.sh`, `build_full.sh` dan workflow CI membina asset daripada sumber version/commit-pinned lalu membuktikan asset itu berada dalam APK/AAB. Tanpa `mobile/android/key.properties` yang sah, buildType kekal `release` tetapi menggunakan debug key untuk ujian pemasangan sahaja.

## Semakan source tanpa Flutter

```bash
./scripts/check_project.sh
```

Semakan ini mengesahkan source, XML, konfigurasi release/R8, foreground service, browser context dan fixture carian. Build Flutter sebenar dijalankan oleh workflow CI `.github/workflows/android-release-check.yml`.
