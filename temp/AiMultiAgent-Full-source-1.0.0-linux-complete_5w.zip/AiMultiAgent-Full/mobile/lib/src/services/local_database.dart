import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/app_models.dart';

class LocalDatabase {
  Database? _database;

  Future<Database> get database async {
    final existing = _database;
    if (existing != null) return existing;
    final path = p.join(await getDatabasesPath(), 'ai_multiagent.db');
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE objects(
            type TEXT NOT NULL,
            id TEXT NOT NULL,
            json TEXT NOT NULL,
            updated_at INTEGER NOT NULL,
            PRIMARY KEY(type, id)
          )
        ''');
        await db.execute('''
          CREATE TABLE settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE messages(
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            json TEXT NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_messages_session ON messages(session_id, created_at)');
        await db.execute('''
          CREATE TABLE tool_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            tool_id TEXT NOT NULL,
            scope TEXT NOT NULL,
            success INTEGER NOT NULL,
            summary TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<void> saveObject(String type, String id, Map<String, dynamic> value) async {
    final db = await database;
    await db.insert(
      'objects',
      <String, Object?>{
        'type': type,
        'id': id,
        'json': jsonEncode(value),
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> listObjects(String type) async {
    final db = await database;
    final rows = await db.query('objects', where: 'type = ?', whereArgs: <Object?>[type], orderBy: 'updated_at DESC');
    return rows.map((row) => Map<String, dynamic>.from(jsonDecode(row['json']! as String) as Map)).toList();
  }

  Future<Map<String, dynamic>?> getObject(String type, String id) async {
    final db = await database;
    final rows = await db.query('objects', where: 'type = ? AND id = ?', whereArgs: <Object?>[type, id], limit: 1);
    if (rows.isEmpty) return null;
    return Map<String, dynamic>.from(jsonDecode(rows.first['json']! as String) as Map);
  }

  Future<void> deleteObject(String type, String id) async {
    final db = await database;
    await db.delete('objects', where: 'type = ? AND id = ?', whereArgs: <Object?>[type, id]);
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert('settings', <String, Object?>{'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<String?> getSetting(String key) async {
    final db = await database;
    final rows = await db.query('settings', where: 'key = ?', whereArgs: <Object?>[key], limit: 1);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  Future<void> saveMessage(ChatMessage message) async {
    final db = await database;
    await db.insert(
      'messages',
      <String, Object?>{
        'id': message.id,
        'session_id': message.sessionId,
        'role': message.role.name,
        'content': message.content,
        'created_at': message.createdAt.millisecondsSinceEpoch,
        'json': jsonEncode(message.toJson()),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<ChatMessage>> listMessages(String sessionId) async {
    final db = await database;
    final rows = await db.query('messages', where: 'session_id = ?', whereArgs: <Object?>[sessionId], orderBy: 'created_at ASC');
    return rows.map((row) => ChatMessage.fromJson(Map<String, dynamic>.from(jsonDecode(row['json']! as String) as Map))).toList();
  }

  Future<void> clearMessages(String sessionId) async {
    final db = await database;
    await db.delete('messages', where: 'session_id = ?', whereArgs: <Object?>[sessionId]);
  }

  Future<void> logTool({required String sessionId, required String toolId, required String scope, required bool success, required String summary}) async {
    final db = await database;
    await db.insert('tool_logs', <String, Object?>{
      'session_id': sessionId,
      'tool_id': toolId,
      'scope': scope,
      'success': success ? 1 : 0,
      'summary': summary,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }


  Future<List<ToolLogRecord>> listToolLogs({int limit = 200}) async {
    final db = await database;
    final rows = await db.query('tool_logs', orderBy: 'created_at DESC', limit: limit);
    return rows
        .map((row) => ToolLogRecord(
              id: (row['id'] as num).toInt(),
              sessionId: row['session_id'] as String,
              toolId: row['tool_id'] as String,
              scope: row['scope'] as String,
              success: (row['success'] as num).toInt() == 1,
              summary: row['summary'] as String,
              createdAt: DateTime.fromMillisecondsSinceEpoch((row['created_at'] as num).toInt()),
            ))
        .toList();
  }

  Future<void> clearToolLogs() async {
    final db = await database;
    await db.delete('tool_logs');
  }

  Future<void> deleteAllLocalData() async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('objects');
      await txn.delete('settings');
      await txn.delete('messages');
      await txn.delete('tool_logs');
    });
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
