import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/app_models.dart';

class McpService {
  McpService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  int _requestId = 1;

  Future<Map<String, dynamic>> test(McpServerConfig server) async {
    final initialized = await _rpc(
      server,
      'initialize',
      <String, dynamic>{
        'protocolVersion': '2025-03-26',
        'capabilities': const <String, dynamic>{},
        'clientInfo': const <String, dynamic>{'name': AppConfig.appName, 'version': AppConfig.version},
      },
    );
    final tools = await _rpc(server, 'tools/list', const <String, dynamic>{});
    return <String, dynamic>{'initialize': initialized, 'tools': tools};
  }

  Future<List<Map<String, dynamic>>> listTools(McpServerConfig server) async {
    final result = await _rpc(server, 'tools/list', const <String, dynamic>{});
    final tools = result['tools'] as List? ?? const <dynamic>[];
    return tools.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Future<Map<String, dynamic>> callTool(
    McpServerConfig server, {
    required String name,
    Map<String, dynamic> arguments = const <String, dynamic>{},
  }) =>
      _rpc(server, 'tools/call', <String, dynamic>{'name': name, 'arguments': arguments});

  Future<Map<String, dynamic>> _rpc(
    McpServerConfig server,
    String method,
    Map<String, dynamic> params,
  ) async {
    final uri = _validatedLocalUri(server.baseUrl);
    final id = _requestId++;
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/event-stream',
            'MCP-Protocol-Version': '2025-03-26',
            ...server.headers,
          },
          body: jsonEncode(<String, dynamic>{
            'jsonrpc': '2.0',
            'id': id,
            'method': method,
            'params': params,
          }),
        )
        .timeout(AppConfig.defaultTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw McpException('MCP HTTP ${response.statusCode}: ${response.body}');
    }
    final body = _decodeResponseBody(response.body);
    if (body['error'] is Map) {
      final error = Map<String, dynamic>.from(body['error'] as Map);
      throw McpException(error['message']?.toString() ?? 'Ralat MCP tidak diketahui.');
    }
    return Map<String, dynamic>.from(body['result'] as Map? ?? const <String, dynamic>{});
  }

  Map<String, dynamic> _decodeResponseBody(String body) {
    final trimmed = body.trim();
    if (trimmed.startsWith('{')) {
      return Map<String, dynamic>.from(jsonDecode(trimmed) as Map);
    }
    // Streamable HTTP/SSE boleh memulangkan beberapa event. Ambil data JSON terakhir.
    final dataLines = trimmed
        .split('\n')
        .where((line) => line.startsWith('data:'))
        .map((line) => line.substring(5).trim())
        .where((line) => line.startsWith('{'))
        .toList();
    if (dataLines.isEmpty) throw const McpException('Respons MCP bukan JSON atau SSE yang sah.');
    return Map<String, dynamic>.from(jsonDecode(dataLines.last) as Map);
  }

  Uri _validatedLocalUri(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      throw const FormatException('URL MCP tidak sah.');
    }
    final host = uri.host.toLowerCase();
    final isLocal = host == 'localhost' || host == '127.0.0.1' || host == '::1' || host.endsWith('.local');
    if (!isLocal) throw const FormatException('Versi ini hanya membenarkan MCP local/localhost.');
    return uri;
  }

  void dispose() => _client.close();
}

class McpException implements Exception {
  const McpException(this.message);
  final String message;
  @override
  String toString() => message;
}
