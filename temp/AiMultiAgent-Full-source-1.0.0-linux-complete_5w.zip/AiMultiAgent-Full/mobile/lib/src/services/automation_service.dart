import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:workmanager/workmanager.dart';

import '../models/app_models.dart';
import 'agent_runtime.dart';
import 'local_database.dart';
import 'permission_manager.dart';
import 'provider_service.dart';
import 'secure_vault.dart';
import 'skill_service.dart';
import 'tool_engine.dart';

class AutomationService {
  AutomationService(this.database);
  final LocalDatabase database;

  Future<List<AutomationDefinition>> load() async =>
      (await database.listObjects('automation')).map(AutomationDefinition.fromJson).toList();

  Future<void> save(AutomationDefinition automation) async {
    await database.saveObject('automation', automation.id, automation.toJson());
    await Workmanager().cancelByUniqueName('automation_${automation.id}');
    if (automation.enabled) {
      await Workmanager().registerPeriodicTask(
        'automation_${automation.id}',
        'run_automation',
        frequency: Duration(minutes: automation.intervalMinutes < 15 ? 15 : automation.intervalMinutes),
        inputData: <String, dynamic>{'automationId': automation.id},
        constraints: Constraints(networkType: NetworkType.connected),
      );
    }
  }

  Future<void> delete(AutomationDefinition automation) async {
    await Workmanager().cancelByUniqueName('automation_${automation.id}');
    await database.deleteObject('automation', automation.id);
  }

  Future<void> cancelAll() => Workmanager().cancelAll();

  Future<void> rescheduleAll(List<AutomationDefinition> automations) async {
    for (final automation in automations) {
      await save(automation);
    }
  }
}

class BackgroundAutomationWorker {
  Future<bool> execute({required String task, required Map<String, dynamic> inputData}) async {
    if (task != 'run_automation') return true;
    final automationId = inputData['automationId']?.toString() ?? '';
    if (automationId.isEmpty) return false;

    final database = LocalDatabase();
    final backgroundAllowed = (await database.getSetting('backgroundExecutionAllowed')) == 'true';
    if (!backgroundAllowed) return true;

    final automationJson = await database.getObject('automation', automationId);
    if (automationJson == null) return false;
    final automation = AutomationDefinition.fromJson(automationJson);
    if (!automation.enabled) return true;

    final providerJson = await database.getObject('provider', automation.providerId);
    if (providerJson == null) return false;
    final provider = ProviderConfig.fromJson(providerJson);
    const agent = AgentProfile(
      id: 'orchestrator',
      name: 'Ai MultiAgent',
      description: 'Orchestrator automatik untuk automasi local.',
      systemPrompt:
          'Selesaikan automasi ini menggunakan tools, skills dan sub-agent dinamik apabila diperlukan.',
      iconCode: 0xf1b3,
      isBuiltIn: true,
    );
    final vault = SecureVault();
    final apiKey = await vault.readProviderKey(provider.id);
    final skillService = SkillService(database);
    final skills = await skillService.loadSkills();
    final providerService = ProviderService();
    final toolEngine = ToolEngine(database, skillService: skillService, backgroundMode: true);
    final permissionManager = PermissionManager(
      database,
      backgroundMode: true,
      backgroundAllowedTools: automation.allowedToolIds.toSet(),
    );
    await permissionManager.initialize();
    final runtime = AgentRuntime(
      providerService: providerService,
      toolEngine: toolEngine,
      permissionManager: permissionManager,
      database: database,
    );
    final notifications = FlutterLocalNotificationsPlugin();
    const androidInitialization = AndroidInitializationSettings('@mipmap/ic_launcher');
    await notifications.initialize(const InitializationSettings(android: androidInitialization));
    final notificationId = automation.id.hashCode;

    try {
      if (automation.runAsForeground) {
        const runningDetails = AndroidNotificationDetails(
          'automation_running',
          'Automasi sedang berjalan',
          channelDescription: 'Status tugas automasi panjang Ai MultiAgent',
          importance: Importance.low,
          priority: Priority.low,
          ongoing: true,
          autoCancel: false,
          showWhen: true,
        );
        await notifications.show(
          notificationId,
          automation.name,
          'Agent sedang menjalankan automasi…',
          const NotificationDetails(android: runningDetails),
        );
      }

      final message = await runtime.run(
        sessionId: 'automation_${automation.id}',
        provider: provider,
        apiKey: apiKey,
        agent: agent,
        skills: skills,
        history: const <ChatMessage>[],
        userInput: automation.prompt,
      );
      final updated = automation.copyWith(lastRunAt: DateTime.now(), lastResult: message.content);
      await database.saveObject('automation', updated.id, updated.toJson());
      if (automation.notifyOnComplete) {
        const details = AndroidNotificationDetails(
          'automations',
          'Automasi',
          channelDescription: 'Keputusan automasi Ai MultiAgent',
          importance: Importance.high,
          priority: Priority.high,
        );
        await notifications.show(
          notificationId,
          automation.name,
          message.content.length > 180 ? '${message.content.substring(0, 180)}…' : message.content,
          const NotificationDetails(android: details),
        );
      } else if (automation.runAsForeground) {
        await notifications.cancel(notificationId);
      }
      return true;
    } catch (error) {
      final updated = automation.copyWith(lastRunAt: DateTime.now(), lastResult: 'Gagal: $error');
      await database.saveObject('automation', updated.id, updated.toJson());
      if (automation.runAsForeground) await notifications.cancel(notificationId);
      return false;
    } finally {
      providerService.dispose();
      toolEngine.dispose();
      await database.close();
    }
  }
}
