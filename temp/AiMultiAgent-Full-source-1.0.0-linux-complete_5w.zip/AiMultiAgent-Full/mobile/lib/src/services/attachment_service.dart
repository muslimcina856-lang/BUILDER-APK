import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';

class AttachmentService {
  static const _uuid = Uuid();

  Future<List<ChatAttachment>> pickAndImport(String sessionId) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: false,
      withReadStream: false,
      lockParentWindow: true,
    );
    if (result == null) return const <ChatAttachment>[];

    final root = Directory(
      p.join(
        (await getApplicationDocumentsDirectory()).path,
        'chat_attachments',
        _safeSegment(sessionId),
      ),
    );
    await root.create(recursive: true);

    final output = <ChatAttachment>[];
    for (final selected in result.files) {
      final sourcePath = selected.path;
      if (sourcePath == null || sourcePath.isEmpty) continue;
      final source = File(sourcePath);
      if (!await source.exists()) continue;
      final size = await source.length();
      if (size > AppConfig.maxAttachmentBytes) {
        throw FileSystemException(
          'Fail ${selected.name} melebihi had ${_readableBytes(AppConfig.maxAttachmentBytes)}.',
          source.path,
        );
      }
      final id = _uuid.v4();
      final safeName = _safeFilename(selected.name);
      final destination = File(p.join(root.path, '${id}_$safeName'));
      await source.copy(destination.path);
      final mimeType = lookupMimeType(destination.path) ?? 'application/octet-stream';
      output.add(
        ChatAttachment(
          id: id,
          name: selected.name,
          path: destination.path,
          mimeType: mimeType,
          sizeBytes: size,
          kind: kindForMime(mimeType, selected.name),
        ),
      );
    }
    return output;
  }

  Future<void> delete(ChatAttachment attachment) async {
    if (attachment.path.isEmpty) return;
    final file = File(attachment.path);
    if (await file.exists()) await file.delete();
  }

  static AttachmentKind kindForMime(String mimeType, String name) {
    if (mimeType.startsWith('image/')) return AttachmentKind.image;
    if (mimeType.startsWith('video/')) return AttachmentKind.video;
    if (mimeType.startsWith('audio/')) return AttachmentKind.audio;
    final extension = p.extension(name).toLowerCase();
    if (<String>{'.zip', '.7z', '.rar', '.tar', '.gz', '.bz2', '.xz'}.contains(extension)) {
      return AttachmentKind.archive;
    }
    if (mimeType.startsWith('text/') ||
        mimeType == 'application/pdf' ||
        mimeType.contains('document') ||
        mimeType.contains('sheet') ||
        mimeType.contains('presentation') ||
        mimeType.contains('json') ||
        mimeType.contains('xml')) {
      return AttachmentKind.document;
    }
    return AttachmentKind.other;
  }

  static String _safeFilename(String value) {
    final cleaned = value.replaceAll(RegExp(r'[^A-Za-z0-9._() -]'), '_').trim();
    return cleaned.isEmpty ? 'attachment.bin' : cleaned;
  }

  static String _safeSegment(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');

  static String _readableBytes(int value) {
    if (value >= 1024 * 1024 * 1024) return '${(value / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    if (value >= 1024 * 1024) return '${(value / (1024 * 1024)).toStringAsFixed(1)} MB';
    if (value >= 1024) return '${(value / 1024).toStringAsFixed(1)} KB';
    return '$value B';
  }
}
