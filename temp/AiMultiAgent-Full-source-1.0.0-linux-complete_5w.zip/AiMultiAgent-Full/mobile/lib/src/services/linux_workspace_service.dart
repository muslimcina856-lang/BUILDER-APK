import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config/app_config.dart';

class LinuxWorkspaceStatus {
  const LinuxWorkspaceStatus({
    required this.rootPath,
    required this.runtimeReady,
    required this.rootfsReady,
    required this.usedBytes,
    required this.packageInstallEnabled,
    required this.manifestValid,
    required this.runtimeVersion,
    required this.distribution,
    required this.distributionVersion,
    required this.architecture,
    required this.packageManager,
    required this.healthStatus,
  });

  final String rootPath;
  final bool runtimeReady;
  final bool rootfsReady;
  final int usedBytes;
  final bool packageInstallEnabled;
  final bool manifestValid;
  final String runtimeVersion;
  final String distribution;
  final String distributionVersion;
  final String architecture;
  final String packageManager;
  final String healthStatus;

  bool get ready => runtimeReady && rootfsReady && manifestValid;
}

class LinuxCommandSpec {
  const LinuxCommandSpec({
    required this.executable,
    required this.arguments,
    required this.hostWorkingDirectory,
    required this.environment,
  });

  final String executable;
  final List<String> arguments;
  final String hostWorkingDirectory;
  final Map<String, String> environment;
}

class LinuxWorkspaceService {
  static const int maxRuntimePackBytes = 512 * 1024 * 1024;
  static const int maxExtractedRuntimeBytes = 2 * 1024 * 1024 * 1024;
  static const int maxRuntimeEntries = 100000;
  static const int maxSingleRuntimeEntryBytes = 512 * 1024 * 1024;
  static const int maxSymlinkTargetBytes = 4096;
  static const int runtimeManifestSchema = 1;
  static const String expectedRuntimeVersion =
      '1.0.0-alpine-3.24.1-proot-0.15';
  static const String bundledRuntimeAsset =
      'assets/linux/full/runtime-pack.zip';
  static const String expectedDistribution = 'Alpine Linux';
  static const String expectedDistributionVersion = '3.24.1';
  static const String expectedArchitecture = 'aarch64';
  static const String expectedAndroidAbi = 'arm64-v8a';
  static const String expectedPackageManager = 'apk';

  static Future<bool>? _bundledInstallInFlight;

  static const List<String> _persistentDirectories = <String>[
    'home',
    'workspace',
    'packages',
    'browser',
    'snapshots',
  ];

  Future<Directory> ensurePrivateRoot() async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'Linux Workspace penuh hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final support = await getApplicationSupportDirectory();
    _assertPrivateAppPath(support.path);
    final root = Directory(p.join(support.path, 'linux'));
    await _recoverInterruptedInstall(root);
    await _ensureLayout(root);
    await _writeAndroidDnsFallback(root);
    return root;
  }

  Future<LinuxWorkspaceStatus> status() async {
    if (!AppConfig.isFullEdition) {
      return const LinuxWorkspaceStatus(
        rootPath: '',
        runtimeReady: false,
        rootfsReady: false,
        usedBytes: 0,
        packageInstallEnabled: false,
        manifestValid: false,
        runtimeVersion: '',
        distribution: '',
        distributionVersion: '',
        architecture: '',
        packageManager: '',
        healthStatus: 'unavailable_in_standard',
      );
    }
    final root = await ensurePrivateRoot();
    final prootPath = p.join(root.path, 'runtime/bin/proot');
    final shellPath = p.join(root.path, 'rootfs/bin/sh');
    final manifest = await _readManifest(root);
    final manifestValid = _manifestIsValid(manifest);
    final runtimeReady = _isRegularFile(prootPath);
    final rootfsReady = _isFileOrLink(shellPath);
    final healthStatus = runtimeReady && rootfsReady && manifestValid
        ? await _readHealthStatus(root)
        : 'not_installed';
    return LinuxWorkspaceStatus(
      rootPath: root.path,
      runtimeReady: runtimeReady,
      rootfsReady: rootfsReady,
      usedBytes: await _directorySize(root),
      packageInstallEnabled: AppConfig.linuxPackageInstallEnabled,
      manifestValid: manifestValid,
      runtimeVersion: manifest?['runtime_version']?.toString() ?? '',
      distribution: manifest?['distribution']?.toString() ?? '',
      distributionVersion:
          manifest?['distribution_version']?.toString() ?? '',
      architecture: manifest?['architecture']?.toString() ?? '',
      packageManager: manifest?['package_manager']?.toString() ?? '',
      healthStatus: healthStatus,
    );
  }

  /// Pastikan runtime bawaan APK tersedia sebelum arahan AI pertama.
  ///
  /// Panggilan serentak berkongsi satu pemasangan supaya asset besar tidak
  /// diekstrak dua kali. Runtime lama tanpa manifest atau dengan versi berbeza
  /// dinaik taraf sambil mengekalkan data projek pengguna.
  Future<bool> installBundledRuntimeIfAvailable() {
    if (!AppConfig.isFullEdition) return Future<bool>.value(false);
    final existing = _bundledInstallInFlight;
    if (existing != null) return existing;
    final operation = _installBundledRuntime();
    _bundledInstallInFlight = operation;
    return operation.whenComplete(() {
      if (identical(_bundledInstallInFlight, operation)) {
        _bundledInstallInFlight = null;
      }
    });
  }

  Future<LinuxWorkspaceStatus> ensureBundledRuntimeReady() async {
    if (!AppConfig.isFullEdition) return status();
    final installed = await installBundledRuntimeIfAvailable();
    final current = await status();
    if (!installed || !current.ready) {
      throw const FileSystemException(
        'Runtime Linux bawaan tidak ditemui atau tidak sah. Gunakan scripts/build_full.sh supaya Alpine ARM64 dan PRoot disediakan sebelum APK/AAB dibina.',
      );
    }
    return current;
  }

  Future<bool> _installBundledRuntime() async {
    final current = await status();
    if (current.ready && current.runtimeVersion == expectedRuntimeVersion) {
      final root = await ensurePrivateRoot();
      final backup = Directory('${root.path}.backup');
      if (!Platform.isAndroid || current.healthStatus == 'verified') {
        if (await backup.exists()) await backup.delete(recursive: true);
        return true;
      }
      await _verifyActiveRuntimeAndClearBackup(root);
      return true;
    }

    ByteData data;
    try {
      data = await rootBundle.load(bundledRuntimeAsset);
    } on FlutterError {
      return false;
    }
    final root = await ensurePrivateRoot();
    final temporary = File(p.join(root.path, 'tmp', 'bundled-runtime.zip'));
    await temporary.parent.create(recursive: true);
    await temporary.writeAsBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      flush: true,
    );
    try {
      await installRuntimePack(temporary.path);
      return (await status()).ready;
    } finally {
      if (await temporary.exists()) await temporary.delete();
    }
  }

  /// Memasang runtime pack ZIP ke direktori internal private aplikasi.
  ///
  /// Struktur wajib:
  /// runtime/bin/proot
  /// runtime/manifest.json
  /// rootfs/bin/sh
  /// rootfs/...
  Future<void> installRuntimePack(String archivePath) async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'Import runtime pack hanya dibenarkan pada edisi Full.',
      );
    }
    final source = File(archivePath);
    if (!await source.exists()) {
      throw const FileSystemException('Runtime pack tidak ditemui.');
    }
    final length = await source.length();
    if (length <= 0 || length > maxRuntimePackBytes) {
      throw const FileSystemException('Saiz runtime pack tidak sah.');
    }

    final root = await ensurePrivateRoot();
    final staging = Directory('${root.path}.staging');
    final backup = Directory('${root.path}.backup');
    if (await backup.exists()) {
      await _verifyActiveRuntimeAndClearBackup(root);
    }
    if (await staging.exists()) await staging.delete(recursive: true);
    await staging.create(recursive: true);

    final symbolicLinks = <({String path, String target})>[];
    final chmodGroups = <int, List<String>>{};
    var extractedBytes = 0;
    var entryCount = 0;
    final seenEntries = <String>{};
    InputFileStream? input;
    var rootBackedUp = false;
    var stagingActivated = false;
    try {
      input = InputFileStream(source.path);
      final archive = ZipDecoder().decodeStream(input, verify: true);
      for (final entry in archive) {
        entryCount += 1;
        if (entryCount > maxRuntimeEntries) {
          throw const FileSystemException(
            'Runtime pack mempunyai terlalu banyak entri.',
          );
        }
        if (entry.size < 0 || entry.size > maxSingleRuntimeEntryBytes) {
          throw const FileSystemException(
            'Runtime pack mempunyai entri yang terlalu besar.',
          );
        }
        extractedBytes += entry.size;
        if (extractedBytes > maxExtractedRuntimeBytes) {
          throw const FileSystemException(
            'Saiz ekstrak runtime pack melebihi had keselamatan.',
          );
        }
        final rawName = entry.name.replaceAll('\\', '/');
        final rawParts = rawName.split('/');
        final normalized = p.normalize(rawName);
        if (rawName.contains('\u0000') ||
            rawParts.contains('..') ||
            normalized.isEmpty ||
            normalized == '.' ||
            p.isAbsolute(normalized) ||
            normalized == '..' ||
            normalized.startsWith('../')) {
          throw const FileSystemException(
            'Runtime pack mengandungi laluan tidak selamat.',
          );
        }
        if (!seenEntries.add(normalized)) {
          throw const FileSystemException(
            'Runtime pack mengandungi entri berganda.',
          );
        }
        final destination = p.normalize(p.join(staging.path, normalized));
        if (!p.isWithin(staging.path, destination)) {
          throw const FileSystemException(
            'Runtime pack cuba menulis di luar sandbox.',
          );
        }

        if (entry.isSymbolicLink) {
          final target = entry.symbolicLink;
          if (target == null ||
              target.isEmpty ||
              target.contains('\u0000') ||
              utf8.encode(target).length > maxSymlinkTargetBytes) {
            throw const FileSystemException('Symlink runtime pack tidak sah.');
          }
          _validateSymlinkTarget(staging.path, destination, target);
          symbolicLinks.add((path: destination, target: target));
          continue;
        }

        if (entry.isFile) {
          await File(destination).parent.create(recursive: true);
          final output = OutputFileStream(destination);
          entry.writeContent(output);
          output.closeSync();
          _queueMode(chmodGroups, entry.unixPermissions, destination);
        } else {
          await Directory(destination).create(recursive: true);
          _queueMode(chmodGroups, entry.unixPermissions, destination);
        }
      }

      for (final item in symbolicLinks) {
        final link = Link(item.path);
        await link.parent.create(recursive: true);
        final existingType = FileSystemEntity.typeSync(
          item.path,
          followLinks: false,
        );
        if (existingType != FileSystemEntityType.notFound) {
          await FileSystemEntity.delete(item.path, recursive: true);
        }
        await link.create(item.target, recursive: true);
      }
      await _applyModes(chmodGroups);
      await _ensureLayout(staging);

      final stagedProot = p.join(staging.path, 'runtime/bin/proot');
      final stagedShell = p.join(staging.path, 'rootfs/bin/sh');
      final stagedApk = p.join(staging.path, 'rootfs/sbin/apk');
      final stagedEnv = p.join(staging.path, 'rootfs/usr/bin/env');
      final stagedRelease = File(
        p.join(staging.path, 'rootfs/etc/alpine-release'),
      );
      final stagedManifest = await _readManifest(staging);
      final releaseVersion = await stagedRelease.exists()
          ? (await stagedRelease.readAsString()).trim()
          : '';
      if (!_isRegularFile(stagedProot) ||
          !_isFileOrLink(stagedShell) ||
          !_isFileOrLink(stagedApk) ||
          !_isFileOrLink(stagedEnv) ||
          releaseVersion != expectedDistributionVersion ||
          !_manifestIsValid(stagedManifest)) {
        throw const FileSystemException(
          'Runtime pack tidak lengkap atau manifest tidak sah.',
        );
      }
      await _validateArm64Elf(File(stagedProot));
      await _chmod('700', <String>[stagedProot]);

      if (await root.exists()) {
        await root.rename(backup.path);
        rootBackedUp = true;
        await _movePersistentDirectories(backup, staging);
      }
      await _ensureLayout(staging);
      await _writeAndroidDnsFallback(staging);
      await staging.rename(root.path);
      stagingActivated = true;

      if (Platform.isAndroid) {
        await _runHealthCheck(root);
        await _writeHealthMarker(root, 'verified');
      } else {
        await _writeHealthMarker(root, 'structurally_verified');
      }
      if (await backup.exists()) await backup.delete(recursive: true);
    } catch (_) {
      await _rollbackInstall(
        root: root,
        staging: staging,
        backup: backup,
        rootBackedUp: rootBackedUp,
        stagingActivated: stagingActivated,
      );
      rethrow;
    } finally {
      input?.closeSync();
      if (await staging.exists()) await staging.delete(recursive: true);
    }
  }

  Future<LinuxCommandSpec?> commandSpec({
    required String command,
    required String relativeWorkingDirectory,
    Map<String, String> environment = const <String, String>{},
    bool autoInstallBundledRuntime = false,
  }) async {
    if (!AppConfig.isFullEdition) return null;
    final current = autoInstallBundledRuntime
        ? await ensureBundledRuntimeReady()
        : await status();
    if (!current.ready) return null;
    final root = await ensurePrivateRoot();
    return _commandSpecForRoot(
      root: root,
      command: command,
      relativeWorkingDirectory: relativeWorkingDirectory,
      environment: environment,
    );
  }

  Future<LinuxCommandSpec> _commandSpecForRoot({
    required Directory root,
    required String command,
    required String relativeWorkingDirectory,
    Map<String, String> environment = const <String, String>{},
  }) async {
    final proot = File(p.join(root.path, 'runtime/bin/proot'));
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final workspace = Directory(p.join(root.path, 'workspace'));
    final home = Directory(p.join(root.path, 'home'));
    final tmp = Directory(p.join(root.path, 'tmp'));
    final dns = File(p.join(root.path, 'runtime/android-resolv.conf'));
    final safeRelative = p.normalize(relativeWorkingDirectory);
    if (p.isAbsolute(safeRelative) ||
        safeRelative == '..' ||
        safeRelative.startsWith('../')) {
      throw const FileSystemException('Working directory tidak selamat.');
    }
    final guestCwd = safeRelative == '.' || safeRelative.isEmpty
        ? '/workspace'
        : '/workspace/${safeRelative.replaceAll('\\', '/')}';

    final arguments = <String>[
      '--kill-on-exit',
      '--link2symlink',
      '-0',
      '-r',
      rootfs.path,
      ...await _safeSystemBinds(),
      '-b',
      '${workspace.path}:/workspace',
      '-b',
      '${home.path}:/root',
      '-b',
      '${tmp.path}:/tmp',
      if (await dns.exists()) ...<String>[
        '-b',
        '${dns.path}:/etc/resolv.conf',
      ],
      '-w',
      guestCwd,
      '/usr/bin/env',
      '-i',
      'HOME=/root',
      'USER=root',
      'LOGNAME=root',
      'TERM=xterm-256color',
      'LANG=C.UTF-8',
      'PAGER=cat',
      'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
      ..._sanitizeEnvironment(environment),
      '/bin/sh',
      '-lc',
      command,
    ];

    return LinuxCommandSpec(
      executable: proot.path,
      arguments: arguments,
      hostWorkingDirectory: workspace.path,
      environment: <String, String>{
        'HOME': home.path,
        'TMPDIR': tmp.path,
        'PROOT_TMP_DIR': tmp.path,
        'PROOT_NO_SECCOMP': '1',
      },
    );
  }

  Future<void> reset() async {
    if (!AppConfig.isFullEdition) return;
    final root = await ensurePrivateRoot();
    if (await root.exists()) await root.delete(recursive: true);
    await ensurePrivateRoot();
    await ensureBundledRuntimeReady();
  }

  Future<void> _runHealthCheck(Directory root) async {
    final spec = await _commandSpecForRoot(
      root: root,
      command:
          "printf 'AI_LINUX_OK\\n'; uname -m; cat /etc/alpine-release; command -v apk; apk --version",
      relativeWorkingDirectory: '.',
    );
    final process = await Process.start(
      spec.executable,
      spec.arguments,
      workingDirectory: spec.hostWorkingDirectory,
      environment: spec.environment,
      includeParentEnvironment: false,
      runInShell: false,
    );
    final stdoutFuture = process.stdout.transform(utf8.decoder).join();
    final stderrFuture = process.stderr.transform(utf8.decoder).join();
    int exitCode;
    try {
      exitCode = await process.exitCode.timeout(const Duration(seconds: 25));
    } on TimeoutException {
      process.kill(ProcessSignal.sigkill);
      throw const FileSystemException(
        'Pemeriksaan kesihatan Linux tamat masa.',
      );
    }
    final output = await stdoutFuture;
    final error = await stderrFuture;
    if (exitCode != 0 ||
        !output.contains('AI_LINUX_OK') ||
        !output.contains('aarch64') ||
        !output.contains(expectedDistributionVersion) ||
        !output.contains('/sbin/apk') ||
        !output.contains('apk-tools')) {
      throw FileSystemException(
        'Pemeriksaan kesihatan Linux gagal (exit $exitCode): $output $error',
      );
    }
  }

  Future<void> _rollbackInstall({
    required Directory root,
    required Directory staging,
    required Directory backup,
    required bool rootBackedUp,
    required bool stagingActivated,
  }) async {
    try {
      if (!rootBackedUp || !await backup.exists()) {
        if (stagingActivated && await root.exists()) {
          await root.delete(recursive: true);
        }
        return;
      }
      final active = stagingActivated ? root : staging;
      if (await active.exists()) {
        await _movePersistentDirectories(
          active,
          backup,
          replaceExisting: false,
        );
        if (await active.exists()) await active.delete(recursive: true);
      }
      if (await root.exists()) await root.delete(recursive: true);
      await backup.rename(root.path);
    } catch (rollbackError) {
      throw FileSystemException(
        'Pemasangan gagal dan rollback tidak lengkap: $rollbackError',
      );
    }
  }

  Future<void> _recoverInterruptedInstall(Directory root) async {
    final staging = Directory('${root.path}.staging');
    final backup = Directory('${root.path}.backup');
    if (!await backup.exists()) {
      if (await staging.exists()) await staging.delete(recursive: true);
      return;
    }

    if (!await root.exists()) {
      if (await staging.exists()) {
        await _movePersistentDirectories(
          staging,
          backup,
          replaceExisting: false,
        );
        if (await staging.exists()) await staging.delete(recursive: true);
      }
      await backup.rename(root.path);
      return;
    }

    if (await _isStructurallyReady(root)) {
      if (await staging.exists()) await staging.delete(recursive: true);
      return;
    }

    await _movePersistentDirectories(
      root,
      backup,
      replaceExisting: false,
    );
    if (await staging.exists()) {
      await _movePersistentDirectories(
        staging,
        backup,
        replaceExisting: false,
      );
      if (await staging.exists()) await staging.delete(recursive: true);
    }
    if (await root.exists()) await root.delete(recursive: true);
    await backup.rename(root.path);
  }

  Future<void> _verifyActiveRuntimeAndClearBackup(Directory root) async {
    final backup = Directory('${root.path}.backup');
    try {
      if (Platform.isAndroid) {
        await _runHealthCheck(root);
        await _writeHealthMarker(root, 'verified');
      } else {
        await _writeHealthMarker(root, 'structurally_verified');
      }
      if (await backup.exists()) await backup.delete(recursive: true);
    } catch (_) {
      if (await backup.exists()) {
        await _rollbackInstall(
          root: root,
          staging: Directory('${root.path}.staging'),
          backup: backup,
          rootBackedUp: true,
          stagingActivated: true,
        );
      }
      rethrow;
    }
  }

  Future<bool> _isStructurallyReady(Directory root) async {
    if (!await root.exists()) return false;
    final manifest = await _readManifest(root);
    final release = File(p.join(root.path, 'rootfs/etc/alpine-release'));
    final releaseVersion = await release.exists()
        ? (await release.readAsString()).trim()
        : '';
    return _isRegularFile(p.join(root.path, 'runtime/bin/proot')) &&
        _isFileOrLink(p.join(root.path, 'rootfs/bin/sh')) &&
        _isFileOrLink(p.join(root.path, 'rootfs/sbin/apk')) &&
        _isFileOrLink(p.join(root.path, 'rootfs/usr/bin/env')) &&
        releaseVersion == expectedDistributionVersion &&
        _manifestIsValid(manifest);
  }

  Future<void> _movePersistentDirectories(
    Directory source,
    Directory destination, {
    bool replaceExisting = true,
  }) async {
    for (final name in _persistentDirectories) {
      final from = Directory(p.join(source.path, name));
      if (!await from.exists()) continue;
      final toPath = p.join(destination.path, name);
      final type = FileSystemEntity.typeSync(toPath, followLinks: false);
      if (type != FileSystemEntityType.notFound) {
        if (!replaceExisting) {
          await from.delete(recursive: true);
          continue;
        }
        await FileSystemEntity.delete(toPath, recursive: true);
      }
      await from.rename(toPath);
    }
  }

  Future<void> _ensureLayout(Directory root) async {
    for (final child in <String>[
      'runtime/bin',
      'runtime/lib',
      'rootfs',
      'home',
      'workspace',
      'packages',
      'browser',
      'snapshots',
      'tmp',
    ]) {
      await Directory(p.join(root.path, child)).create(recursive: true);
    }
    final profile = File(p.join(root.path, 'home/.profile'));
    if (!await profile.exists()) {
      await profile.writeAsString(
        '. /etc/profile 2>/dev/null || true\n'
        'cd /workspace 2>/dev/null || true\n',
        flush: true,
      );
    }
  }

  Future<void> _writeAndroidDnsFallback(Directory root) async {
    final output = File(p.join(root.path, 'runtime/android-resolv.conf'));
    var contents = '';
    final host = File('/etc/resolv.conf');
    if (await host.exists()) {
      try {
        contents = await host.readAsString();
      } on FileSystemException {
        contents = '';
      }
    }
    if (!contents.contains('nameserver')) {
      contents =
          'nameserver 1.1.1.1\nnameserver 8.8.8.8\noptions timeout:2 attempts:3\n';
    }
    await output.writeAsString(contents, flush: true);
  }

  Future<String> _readHealthStatus(Directory root) async {
    final file = File(p.join(root.path, 'runtime/health.json'));
    if (!await file.exists()) return 'not_checked';
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map ||
          decoded['runtime_version'] != expectedRuntimeVersion) {
        return 'not_checked';
      }
      return decoded['status']?.toString() ?? 'not_checked';
    } on Object {
      return 'not_checked';
    }
  }

  Future<void> _writeHealthMarker(Directory root, String status) async {
    final file = File(p.join(root.path, 'runtime/health.json'));
    await file.parent.create(recursive: true);
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(<String, dynamic>{
        'runtime_version': expectedRuntimeVersion,
        'status': status,
        'checked_at': DateTime.now().toUtc().toIso8601String(),
      }),
      flush: true,
    );
  }

  Future<Map<String, dynamic>?> _readManifest(Directory root) async {
    final file = File(p.join(root.path, 'runtime/manifest.json'));
    if (!await file.exists()) return null;
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return null;
      return decoded.map(
        (key, value) => MapEntry(key.toString(), value),
      );
    } on Object {
      return null;
    }
  }

  bool _manifestIsValid(Map<String, dynamic>? manifest) {
    if (manifest == null) return false;
    return manifest['schema'] == runtimeManifestSchema &&
        manifest['runtime_version'] == expectedRuntimeVersion &&
        manifest['architecture'] == expectedArchitecture &&
        manifest['android_abi'] == expectedAndroidAbi &&
        manifest['distribution'] == expectedDistribution &&
        manifest['distribution_version'] == expectedDistributionVersion &&
        manifest['package_manager'] == expectedPackageManager &&
        manifest['shell'] == '/bin/sh';
  }

  Future<void> _validateArm64Elf(File binary) async {
    final handle = await binary.open();
    try {
      final header = Uint8List.fromList(await handle.read(20));
      if (header.length < 20 ||
          header[0] != 0x7f ||
          header[1] != 0x45 ||
          header[2] != 0x4c ||
          header[3] != 0x46 ||
          header[4] != 2 ||
          header[5] != 1) {
        throw const FileSystemException(
          'Binary PRoot bukan ELF 64-bit little-endian.',
        );
      }
      final machine = header[18] | (header[19] << 8);
      if (machine != 183) {
        throw FileSystemException(
          'Binary PRoot bukan AArch64 (e_machine=$machine).',
        );
      }
    } finally {
      await handle.close();
    }
  }

  bool _isRegularFile(String path) =>
      FileSystemEntity.typeSync(path, followLinks: false) ==
      FileSystemEntityType.file;

  bool _isFileOrLink(String path) {
    final type = FileSystemEntity.typeSync(path, followLinks: false);
    return type == FileSystemEntityType.file ||
        type == FileSystemEntityType.link;
  }

  Future<List<String>> _safeSystemBinds() async {
    final arguments = <String>[];
    for (final path in <String>[
      '/proc',
      '/dev/null',
      '/dev/zero',
      '/dev/random',
      '/dev/urandom',
      '/dev/tty',
      '/dev/pts',
    ]) {
      final type = FileSystemEntity.typeSync(path, followLinks: false);
      if (type != FileSystemEntityType.notFound) {
        arguments.addAll(<String>['-b', path]);
      }
    }
    return arguments;
  }

  Iterable<String> _sanitizeEnvironment(Map<String, String> environment) sync* {
    final validName = RegExp(r'^[A-Za-z_][A-Za-z0-9_]*$');
    const blocked = <String>{
      'HOME',
      'USER',
      'LOGNAME',
      'PATH',
      'TMPDIR',
      'PROOT_TMP_DIR',
      'PROOT_NO_SECCOMP',
      'LD_PRELOAD',
      'LD_LIBRARY_PATH',
    };
    for (final entry in environment.entries) {
      if (!validName.hasMatch(entry.key) || blocked.contains(entry.key)) {
        continue;
      }
      yield '${entry.key}=${entry.value.replaceAll('\u0000', '')}';
    }
  }

  void _assertPrivateAppPath(String path) {
    if (!Platform.isAndroid) return;
    final normalized = p.normalize(path);
    final privateAndroidPath = normalized.startsWith('/data/user/') ||
        normalized.startsWith('/data/data/');
    if (!privateAndroidPath) {
      throw FileSystemException(
        'Linux Workspace mesti berada dalam storan internal private aplikasi.',
        normalized,
      );
    }
  }

  void _validateSymlinkTarget(
    String stagingRoot,
    String linkPath,
    String target,
  ) {
    final normalizedTarget = target.replaceAll('\\', '/');
    final lower = normalizedTarget.toLowerCase();
    const blockedAbsoluteRoots = <String>[
      '/sdcard',
      '/storage',
      '/mnt/media_rw',
      '/data/media',
      '/data/user',
      '/data/data',
    ];
    if (blockedAbsoluteRoots.any(
      (root) => lower == root || lower.startsWith('$root/'),
    )) {
      throw const FileSystemException(
        'Runtime pack cuba membuat symlink keluar daripada Linux Workspace.',
      );
    }
    if (p.isAbsolute(normalizedTarget)) {
      final rootfs = p.join(stagingRoot, 'rootfs');
      if (linkPath != rootfs && !p.isWithin(rootfs, linkPath)) {
        throw const FileSystemException(
          'Symlink mutlak hanya dibenarkan di dalam rootfs Linux.',
        );
      }
      return;
    }
    final resolved = p.normalize(p.join(p.dirname(linkPath), normalizedTarget));
    if (resolved != stagingRoot && !p.isWithin(stagingRoot, resolved)) {
      throw const FileSystemException(
        'Symlink runtime pack keluar daripada sandbox.',
      );
    }
  }

  void _queueMode(Map<int, List<String>> groups, int mode, String path) {
    final permissions = mode & 0x1FF;
    if (permissions == 0) return;
    groups.putIfAbsent(permissions, () => <String>[]).add(path);
  }

  Future<void> _applyModes(Map<int, List<String>> groups) async {
    for (final entry in groups.entries) {
      final mode = entry.key.toRadixString(8).padLeft(3, '0');
      for (var index = 0; index < entry.value.length; index += 100) {
        final end = (index + 100).clamp(0, entry.value.length).toInt();
        await _chmod(mode, entry.value.sublist(index, end));
      }
    }
  }

  Future<void> _chmod(String mode, List<String> paths) async {
    if (paths.isEmpty) return;
    final executable = Platform.isAndroid ? '/system/bin/chmod' : 'chmod';
    final result = await Process.run(executable, <String>[mode, ...paths]);
    if (result.exitCode != 0) {
      throw FileSystemException(
        'Gagal menetapkan permission runtime pack: ${result.stderr}',
      );
    }
  }

  Future<int> _directorySize(Directory root) async {
    var total = 0;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // Fail yang berubah ketika dikira akan dikira semula kemudian.
        }
      }
    }
    return total;
  }
}
