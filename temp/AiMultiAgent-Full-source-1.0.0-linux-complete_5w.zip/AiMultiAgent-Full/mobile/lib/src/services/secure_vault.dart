import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureVault {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  String _providerKey(String providerId) => 'provider_api_key_$providerId';

  Future<void> writeProviderKey(String providerId, String value) async {
    if (value.trim().isEmpty) {
      await deleteProviderKey(providerId);
      return;
    }
    await _storage.write(key: _providerKey(providerId), value: value.trim());
  }

  Future<String> readProviderKey(String providerId) async => await _storage.read(key: _providerKey(providerId)) ?? '';

  Future<void> deleteProviderKey(String providerId) => _storage.delete(key: _providerKey(providerId));

  Future<void> deleteAll() => _storage.deleteAll();
}
