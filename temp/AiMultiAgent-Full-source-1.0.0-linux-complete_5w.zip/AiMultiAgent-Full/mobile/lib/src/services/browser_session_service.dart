import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class BrowserAction {
  const BrowserAction({required this.type, required this.arguments});

  final String type;
  final Map<String, dynamic> arguments;
}

/// Browser latar belakang berasaskan Android System WebView/Chromium.
///
/// UI browser tidak pernah dipaparkan. Model menerima snapshot berstruktur
/// berupa URL, tajuk, teks, HTML, pautan dan borang. Untuk `open`/`read`, HTTP
/// parser menjadi fallback apabila enjin native tidak tersedia.
class BrowserSessionService extends ChangeNotifier {
  BrowserSessionService({http.Client? client}) : _client = client ?? http.Client();

  static const MethodChannel _channel =
      MethodChannel('com.aiauto.claw/browser');

  final http.Client _client;
  bool _disposed = false;

  String currentUrl = '';
  String currentTitle = '';
  String lastError = '';
  bool busy = false;
  int completedActions = 0;
  bool desktopMode = true;

  bool get isRunning => currentUrl.isNotEmpty;
  bool get isBusy => busy;

  Future<Map<String, dynamic>> execute(
    BrowserAction action, {
    Duration timeout = AppConfig.browserTimeout,
  }) async {
    if (_disposed) throw StateError('Sesi browser telah ditutup.');
    busy = true;
    lastError = '';
    notifyListeners();

    try {
      if (action.type == 'open') {
        desktopMode = action.arguments['desktopMode'] as bool? ?? true;
      }
      final result = await _invokeNative(action).timeout(timeout);
      completedActions++;
      _updateFromResult(result);
      return result;
    } on MissingPluginException catch (error) {
      return _fallback(action, error, timeout);
    } on PlatformException catch (error) {
      if (action.type == 'open' || action.type == 'read') {
        return _fallback(action, error, timeout);
      }
      lastError = error.message ?? error.code;
      rethrow;
    } catch (error) {
      if (action.type == 'open' || action.type == 'read') {
        return _fallback(action, error, timeout);
      }
      lastError = error.toString();
      rethrow;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> _invokeNative(BrowserAction action) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      action.type,
      action.arguments,
    );
    if (raw == null) {
      throw StateError('Browser native tidak memulangkan hasil.');
    }
    return Map<String, dynamic>.from(raw);
  }

  Future<Map<String, dynamic>> _fallback(
    BrowserAction action,
    Object error,
    Duration timeout,
  ) async {
    final rawUrl = action.type == 'open'
        ? action.arguments['url']?.toString() ?? ''
        : currentUrl;
    if (rawUrl.isEmpty) {
      lastError = error.toString();
      throw error;
    }
    final result = await _httpSnapshot(rawUrl).timeout(timeout);
    completedActions++;
    _updateFromResult(result);
    return result;
  }

  Future<Map<String, dynamic>> _httpSnapshot(String rawUrl) async {
    final uri = _validatedUri(rawUrl);
    final response = await _client.get(
      uri,
      headers: <String, String>{
        'User-Agent': desktopMode
            ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0'
            : 'Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 '
                'AiMultiAgent/1.0.0',
        'Accept':
            'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      },
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException(
        'HTTP ${response.statusCode} ketika membaca ${uri.host}.',
        uri: uri,
      );
    }

    final document = html_parser.parse(response.body);
    for (final node in document.querySelectorAll(
      'script,noscript,style,svg,template,canvas',
    )) {
      node.remove();
    }
    final links = document.querySelectorAll('a[href]').take(160).map((node) {
      final href = node.attributes['href'] ?? '';
      final resolved = uri.resolve(href);
      return <String, dynamic>{
        'text': node.text.replaceAll(RegExp(r'\s+'), ' ').trim(),
        'url': resolved.toString(),
      };
    }).where((item) => (item['url']?.toString() ?? '').isNotEmpty).toList();

    final result = <String, dynamic>{
      'success': true,
      'engine': 'http-fallback',
      'mode': 'http-fallback',
      'url': uri.toString(),
      'title': document.querySelector('title')?.text.trim() ?? uri.host,
      'text': document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '',
      'html': response.body,
      'links': links,
      'forms': const <dynamic>[],
      'canGoBack': false,
      'canGoForward': false,
      'desktopMode': desktopMode,
    };
    return result;
  }

  Uri _validatedUri(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null ||
        !<String>{'http', 'https'}.contains(uri.scheme) ||
        uri.host.isEmpty) {
      throw const FormatException('URL HTTP/HTTPS tidak sah.');
    }
    return uri;
  }

  void _updateFromResult(Map<String, dynamic> result) {
    final page = result['page'];
    final source = page is Map
        ? Map<String, dynamic>.from(page)
        : result;
    final url = source['url']?.toString() ?? '';
    final title = source['title']?.toString() ?? '';
    if (url.isNotEmpty) currentUrl = url;
    if (title.isNotEmpty) currentTitle = title;
    lastError = source['success'] == false
        ? source['error']?.toString() ?? 'Tindakan browser gagal.'
        : '';
  }

  Future<void> clearCookies() async {
    try {
      await _channel.invokeMethod<void>('clearCookies');
    } on MissingPluginException {
      // Tiada cookie jar native dalam fallback HTTP.
    }
    currentUrl = '';
    currentTitle = '';
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _client.close();
    super.dispose();
  }
}
