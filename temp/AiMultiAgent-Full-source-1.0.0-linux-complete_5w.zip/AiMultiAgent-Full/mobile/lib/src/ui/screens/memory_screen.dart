import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class MemoryScreen extends StatefulWidget {
  const MemoryScreen({super.key});

  @override
  State<MemoryScreen> createState() => _MemoryScreenState();
}

class _MemoryScreenState extends State<MemoryScreen> {
  final _search = TextEditingController();
  String query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Memori Local'),
        actions: <Widget>[
          IconButton(onPressed: () => _showEditor(context), icon: const Icon(Icons.add_rounded), tooltip: 'Tambah memori'),
        ],
      ),
      body: FutureBuilder<List<MemoryRecord>>(
        future: state.memories(),
        builder: (context, snapshot) {
          final all = snapshot.data ?? const <MemoryRecord>[];
          final values = all.where((item) => '${item.title} ${item.content} ${item.tags.join(' ')}'.toLowerCase().contains(query.toLowerCase())).toList();
          return Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                child: TextField(
                  controller: _search,
                  onChanged: (value) => setState(() => query = value),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Cari memori…'),
                ),
              ),
              Expanded(
                child: snapshot.connectionState == ConnectionState.waiting
                    ? const Center(child: CircularProgressIndicator())
                    : values.isEmpty
                        ? const Center(child: Text('Tiada memori ditemui.'))
                        : ListView.builder(
                            padding: const EdgeInsets.fromLTRB(14, 4, 14, 30),
                            itemCount: values.length,
                            itemBuilder: (context, index) {
                              final item = values[index];
                              return Card(
                                child: ListTile(
                                  leading: const CircleAvatar(child: Icon(Icons.psychology_alt_outlined)),
                                  title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                                  subtitle: Text(item.content, maxLines: 3, overflow: TextOverflow.ellipsis),
                                  onTap: () => _showEditor(context, item),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete_outline_rounded),
                                    onPressed: () => _delete(context, item),
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showEditor(context),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Memori'),
      ),
    );
  }

  Future<void> _showEditor(BuildContext context, [MemoryRecord? memory]) async {
    final name = TextEditingController(text: memory?.title ?? '');
    final content = TextEditingController(text: memory?.content ?? '');
    final tags = TextEditingController(text: memory?.tags.join(', ') ?? '');
    final saved = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(memory == null ? 'Tambah Memori' : 'Edit Memori'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'Tajuk')),
                  const SizedBox(height: 10),
                  TextField(controller: content, minLines: 4, maxLines: 10, decoration: const InputDecoration(labelText: 'Kandungan', alignLabelWithHint: true)),
                  const SizedBox(height: 10),
                  TextField(controller: tags, decoration: const InputDecoration(labelText: 'Tag dipisahkan koma')),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan')),
            ],
          ),
        ) ??
        false;
    if (!saved || !context.mounted || name.text.trim().isEmpty || content.text.trim().isEmpty) {
      name.dispose();
      content.dispose();
      tags.dispose();
      return;
    }
    final record = MemoryRecord(
      id: memory?.id ?? const Uuid().v4(),
      title: name.text.trim(),
      content: content.text.trim(),
      createdAt: memory?.createdAt ?? DateTime.now(),
      tags: tags.text.split(',').map((item) => item.trim()).where((item) => item.isNotEmpty).toList(),
    );
    await AppScope.read(context).saveMemory(record);
    name.dispose();
    content.dispose();
    tags.dispose();
    if (mounted) setState(() {});
  }

  Future<void> _delete(BuildContext context, MemoryRecord memory) async {
    final state = AppScope.of(context);
    final alwaysAllowed = state.permissionManager.isAlwaysAllowed('memory_delete', scope: '*') ||
        state.permissionManager.isAlwaysAllowed('memory_delete', scope: 'local-memory');
    var decision = alwaysAllowed ? PermissionDecision.allowAlways : PermissionDecision.deny;
    if (!alwaysAllowed) {
      decision = await showDialog<PermissionDecision>(
            context: context,
            builder: (context) => AlertDialog(
              icon: const Icon(Icons.warning_amber_rounded, color: Colors.amber),
              title: const Text('Padam memori?'),
              content: Text('“${memory.title}” akan dipadam secara kekal daripada peranti.'),
              actions: <Widget>[
                TextButton(onPressed: () => Navigator.pop(context, PermissionDecision.deny), child: const Text('Batal')),
                OutlinedButton(onPressed: () => Navigator.pop(context, PermissionDecision.allowOnce), child: const Text('Padam sekali')),
                OutlinedButton(onPressed: () => Navigator.pop(context, PermissionDecision.allowSession), child: const Text('Sesi ini')),
                FilledButton(onPressed: () => Navigator.pop(context, PermissionDecision.allowAlways), child: const Text('Sentiasa benarkan')),
              ],
            ),
          ) ??
          PermissionDecision.deny;
    }
    if (decision == PermissionDecision.deny || !context.mounted) return;
    if (decision == PermissionDecision.allowSession) {
      state.grantSessionRiskPermission();
    } else if (decision == PermissionDecision.allowAlways && !alwaysAllowed) {
      await state.setToolPermission('memory_delete', PermissionPolicy.alwaysAllow, scope: '*');
    }
    await state.deleteMemory(memory);
    if (mounted) setState(() {});
  }
}
