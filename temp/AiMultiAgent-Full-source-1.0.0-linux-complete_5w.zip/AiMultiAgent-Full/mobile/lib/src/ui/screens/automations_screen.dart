import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class AutomationsScreen extends StatelessWidget {
  const AutomationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Automasi'),
          actions: <Widget>[
            IconButton(
              tooltip: 'Automasi baharu',
              onPressed: state.providers.isEmpty
                  ? () => _showNeedProvider(context)
                  : () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AutomationEditorScreen())),
              icon: const Icon(Icons.add_rounded),
            ),
          ],
        ),
        body: state.automations.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const Icon(Icons.schedule_rounded, size: 60, color: AppTheme.purpleLight),
                      const SizedBox(height: 14),
                      const Text('Belum ada automasi', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      const Text('Jalankan model pilihan secara berkala. Model mengurus tools, skills dan sub-agent secara automatik.', textAlign: TextAlign.center),
                      const SizedBox(height: 18),
                      FilledButton.icon(
                        onPressed: state.providers.isEmpty
                            ? () => _showNeedProvider(context)
                            : () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AutomationEditorScreen())),
                        icon: const Icon(Icons.add_rounded),
                        label: const Text('Cipta automasi'),
                      ),
                    ],
                  ),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 96),
                itemCount: state.automations.length,
                itemBuilder: (context, index) {
                  final item = state.automations[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: <Widget>[
                          Icon(item.enabled ? Icons.autorenew_rounded : Icons.pause_circle_outline_rounded, color: item.enabled ? AppTheme.success : Colors.white38),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                                const SizedBox(height: 3),
                                Text('Setiap ${_intervalLabel(item.intervalMinutes)} • ${item.runAsForeground ? 'notifikasi aktif' : 'background'} • ${item.allowedToolIds.length} tool berisiko dibenarkan'),
                                if (item.lastRunAt != null) ...<Widget>[
                                  const SizedBox(height: 4),
                                  Text('Terakhir: ${item.lastRunAt}', style: Theme.of(context).textTheme.bodySmall),
                                ],
                              ],
                            ),
                          ),
                          Switch.adaptive(
                            value: item.enabled,
                            onChanged: (value) => state.saveAutomation(item.copyWith(enabled: value)),
                          ),
                          IconButton(
                            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AutomationEditorScreen(automation: item))),
                            icon: const Icon(Icons.tune_rounded),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: state.providers.isEmpty
              ? () => _showNeedProvider(context)
              : () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AutomationEditorScreen())),
          icon: const Icon(Icons.add_rounded),
          label: const Text('Automasi'),
        ),
      ),
    );
  }

  static String _intervalLabel(int minutes) {
    if (minutes % 1440 == 0) return '${minutes ~/ 1440} hari';
    if (minutes % 60 == 0) return '${minutes ~/ 60} jam';
    return '$minutes minit';
  }

  void _showNeedProvider(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tambah provider terlebih dahulu.')));
    AppScope.read(context).selectTab(1);
  }
}

class AutomationEditorScreen extends StatefulWidget {
  const AutomationEditorScreen({this.automation, super.key});
  final AutomationDefinition? automation;

  @override
  State<AutomationEditorScreen> createState() => _AutomationEditorScreenState();
}

class _AutomationEditorScreenState extends State<AutomationEditorScreen> {
  static const _uuid = Uuid();
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _prompt;
  late final TextEditingController _interval;
  late String _providerId;
  late bool _enabled;
  late bool _notify;
  late bool _runAsForeground;
  late Set<String> _allowedRiskyTools;

  @override
  void initState() {
    super.initState();
    final item = widget.automation;
    _name = TextEditingController(text: item?.name ?? 'Automasi Baharu');
    _prompt = TextEditingController(text: item?.prompt ?? 'Jalankan tugasan ini dan berikan ringkasan hasil.');
    _interval = TextEditingController(text: (item?.intervalMinutes ?? 60).toString());
    _providerId = item?.providerId ?? '';
    _enabled = item?.enabled ?? true;
    _notify = item?.notifyOnComplete ?? true;
    _runAsForeground = item?.runAsForeground ?? false;
    _allowedRiskyTools = item?.allowedToolIds.toSet() ?? <String>{};
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final state = AppScope.of(context);
    if (_providerId.isEmpty && state.providers.isNotEmpty) _providerId = state.providers.first.id;
  }

  @override
  void dispose() {
    _name.dispose();
    _prompt.dispose();
    _interval.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final riskyTools = state.toolEngine.definitions.where((tool) => <String>{
          'file_write',
          'file_copy',
          'file_move',
          'file_delete',
          'memory_delete',
          'terminal_start',
          'http_request',
          'mcp_call',
        }.contains(tool.id)).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.automation == null ? 'Automasi Baharu' : 'Edit Automasi'),
        actions: <Widget>[
          if (widget.automation != null)
            IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded), tooltip: 'Padam'),
          TextButton(onPressed: _save, child: const Text('Simpan')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nama automasi'), validator: _required),
            const SizedBox(height: 10),
            TextFormField(controller: _prompt, minLines: 5, maxLines: 14, decoration: const InputDecoration(labelText: 'Arahan kepada agent', alignLabelWithHint: true), validator: _required),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: state.providers.any((item) => item.id == _providerId) ? _providerId : null,
              decoration: const InputDecoration(labelText: 'Provider'),
              items: state.providers.map((item) => DropdownMenuItem(value: item.id, child: Text('${item.name} • ${item.model}'))).toList(),
              onChanged: (value) => setState(() => _providerId = value ?? _providerId),
              validator: (value) => value == null || value.isEmpty ? 'Pilih provider.' : null,
            ),
            const SizedBox(height: 10),
            const Card(
              child: ListTile(
                leading: Icon(Icons.hub_rounded, color: AppTheme.purpleLight),
                title: Text('Orchestrator automatik'),
                subtitle: Text('Model yang dipilih menentukan sendiri tools, skills dan sub-agent yang diperlukan.'),
              ),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _interval,
              decoration: const InputDecoration(labelText: 'Ulang setiap (minit)', helperText: 'Minimum Android WorkManager ialah 15 minit.'),
              keyboardType: TextInputType.number,
              validator: (value) {
                final number = int.tryParse(value ?? '');
                return number == null || number < 15 ? 'Masukkan sekurang-kurangnya 15 minit.' : null;
              },
            ),
            const SizedBox(height: 8),
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, value: _enabled, onChanged: (value) => setState(() => _enabled = value), title: const Text('Aktif')),
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, value: _notify, onChanged: (value) => setState(() => _notify = value), title: const Text('Notifikasi selepas selesai')),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _runAsForeground,
              onChanged: (value) => setState(() => _runAsForeground = value),
              title: const Text('Paparkan notifikasi semasa berjalan'),
              subtitle: const Text('Sesuai untuk tugasan panjang. Android masih mengawal masa sebenar WorkManager.'),
            ),
            const Divider(height: 30),
            const Text('Tool berisiko untuk automasi', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.purpleLight)),
            const SizedBox(height: 4),
            const Text('Tool biasa berjalan terus. Tanda hanya tindakan berisiko yang automasi ini dibenarkan lakukan tanpa dialog.'),
            const SizedBox(height: 6),
            ...riskyTools.map((tool) => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _allowedRiskyTools.contains(tool.id),
                  onChanged: (value) => setState(() => value == true ? _allowedRiskyTools.add(tool.id) : _allowedRiskyTools.remove(tool.id)),
                  title: Text(tool.name),
                  subtitle: Text(tool.description),
                )),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final old = widget.automation;
    final item = AutomationDefinition(
      id: old?.id ?? _uuid.v4(),
      name: _name.text.trim(),
      prompt: _prompt.text.trim(),
      providerId: _providerId,
      agentId: 'orchestrator',
      intervalMinutes: int.parse(_interval.text),
      enabled: _enabled,
      notifyOnComplete: _notify,
      runAsForeground: _runAsForeground,
      allowedToolIds: _allowedRiskyTools.toList(),
      lastRunAt: old?.lastRunAt,
      lastResult: old?.lastResult ?? '',
    );
    await AppScope.read(context).saveAutomation(item);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final item = widget.automation;
    if (item == null) return;
    final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam automasi?'),
            content: Text('${item.name} dan jadual background akan dipadam.'),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Padam')),
            ],
          ),
        ) ??
        false;
    if (!ok || !mounted) return;
    await AppScope.read(context).deleteAutomation(item);
    if (mounted) Navigator.pop(context);
  }
}
