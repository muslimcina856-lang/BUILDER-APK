import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:workmanager/workmanager.dart';

import 'app.dart';
import 'config/app_config.dart';
import 'config/app_edition.dart';
import 'services/automation_service.dart';

@pragma('vm:entry-point')
void callbackDispatcherPlay() {
  AppConfig.configure(AppEdition.play);
  _registerBackgroundWorker();
}

@pragma('vm:entry-point')
void callbackDispatcherFull() {
  AppConfig.configure(AppEdition.full);
  _registerBackgroundWorker();
}

void _registerBackgroundWorker() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    final worker = BackgroundAutomationWorker();
    return worker.execute(
      task: task,
      inputData: inputData ?? const <String, dynamic>{},
    );
  });
}

Future<void> startAiMultiAgent(AppEdition edition) async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConfig.configure(edition);
  ErrorWidget.builder = (details) => AppRuntimeErrorView(details: details);
  await Workmanager().initialize(
    edition.isFull ? callbackDispatcherFull : callbackDispatcherPlay,
  );

  final notifications = FlutterLocalNotificationsPlugin();
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  await notifications.initialize(const InitializationSettings(android: android));
  await notifications
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.requestNotificationsPermission();

  runApp(const AiMultiAgentBootstrap());
}
