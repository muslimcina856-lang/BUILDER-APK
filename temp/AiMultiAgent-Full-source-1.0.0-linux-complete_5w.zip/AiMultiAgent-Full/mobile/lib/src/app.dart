import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'ui/home_shell.dart';

class AiMultiAgentBootstrap extends StatefulWidget {
  const AiMultiAgentBootstrap({super.key});

  @override
  State<AiMultiAgentBootstrap> createState() => _AiMultiAgentBootstrapState();
}

class _AiMultiAgentBootstrapState extends State<AiMultiAgentBootstrap> {
  late final AppState state;

  @override
  void initState() {
    super.initState();
    state = AppState();
    state.initialize();
  }

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.launcherName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      // AppScope diletakkan melalui MaterialApp.builder supaya Navigator,
      // overlay, dialog dan bottom sheet berada dalam lifecycle scope yang sama.
      // Ini mengelakkan inherited dependents tertinggal ketika route ditutup.
      builder: (context, child) => AppScope(
        notifier: state,
        child: Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (_) => state.recordActivity(),
          onPointerSignal: (_) => state.recordActivity(),
          child: child ?? const SizedBox.shrink(),
        ),
      ),
      home: AnimatedBuilder(
        animation: state,
        builder: (context, _) {
          if (!state.initialized) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          return const HomeShell();
        },
      ),
    );
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    required AppState notifier,
    required super.child,
    super.key,
  }) : super(notifier: notifier);

  /// Digunakan dalam build apabila widget perlu dibina semula bersama state.
  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope tidak ditemui.');
    return scope!.notifier!;
  }

  /// Digunakan oleh callback/async action tanpa mendaftarkan inherited
  /// dependency baharu pada route yang mungkin sedang ditutup.
  static AppState read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope tidak ditemui.');
    return scope!.notifier!;
  }
}

class AppRuntimeErrorView extends StatelessWidget {
  const AppRuntimeErrorView({required this.details, super.key});

  final FlutterErrorDetails details;

  @override
  Widget build(BuildContext context) {
    final detail = kDebugMode
        ? details.exceptionAsString()
        : 'Paparan mengalami masalah sementara.';
    return Material(
      color: AppTheme.background,
      child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: AppTheme.outline),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const Icon(
                        Icons.refresh_rounded,
                        size: 38,
                        color: AppTheme.purpleLight,
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'Paparan perlu dimuat semula',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 9),
                      Text(
                        detail,
                        textAlign: TextAlign.center,
                        maxLines: 8,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          height: 1.45,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
