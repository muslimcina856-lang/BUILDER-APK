Folder ini diisi secara automatik oleh scripts/linux/prepare_bundled_runtime.py.
Gunakan scripts/build_full.sh untuk build release; skrip akan memuat turun sumber
version/commit-pinned, mengesahkan runtime dan memastikan runtime-pack.zip benar-
benar dibundel ke dalam APK serta AAB. Jangan letakkan runtime yang tidak diketahui.
