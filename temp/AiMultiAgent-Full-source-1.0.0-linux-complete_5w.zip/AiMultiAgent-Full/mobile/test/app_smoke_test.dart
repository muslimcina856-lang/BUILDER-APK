import 'package:ai_multiagent/src/config/app_config.dart';
import 'package:ai_multiagent/src/data/provider_catalog.dart';
import 'package:ai_multiagent/src/services/local_database.dart';
import 'package:ai_multiagent/src/services/tool_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('katalog mempunyai MiMo, local, custom dan cloud advanced', () {
    final mimo = ProviderCatalog.presets.firstWhere((item) => item.id == 'mimo');
    final ollama = ProviderCatalog.presets.firstWhere((item) => item.id == 'ollama');
    final custom = ProviderCatalog.presets.firstWhere((item) => item.id == 'custom_rest');
    final azure = ProviderCatalog.presets.firstWhere((item) => item.id == 'custom_azure_openai');

    expect(mimo.isCustom, isFalse);
    expect(ollama.isCustom, isFalse);
    expect(custom.isCustom, isTrue);
    expect(azure.isCustom, isTrue);
    expect(mimo.baseUrl, 'https://api.xiaomimimo.com/v1');
  });

  test('hanya tindakan yang benar-benar berisiko meminta kelulusan', () async {
    final engine = ToolEngine(LocalDatabase());
    expect(
      await engine.requiresPermission(
        'web_search',
        const <String, dynamic>{'query': 'test'},
      ),
      isFalse,
    );
    expect(
      await engine.requiresPermission(
        'browser_submit_form',
        const <String, dynamic>{'selector': 'form'},
      ),
      isFalse,
    );
    expect(
      await engine.requiresPermission(
        'memory_delete',
        const <String, dynamic>{'id': '1'},
      ),
      isTrue,
    );
    expect(
      await engine.requiresPermission(
        'http_request',
        const <String, dynamic>{
          'method': 'GET',
          'url': 'https://example.com',
        },
      ),
      isFalse,
    );
    expect(
      await engine.requiresPermission(
        'http_request',
        const <String, dynamic>{
          'method': 'DELETE',
          'url': 'https://example.com',
        },
      ),
      isTrue,
    );
    engine.dispose();
  });

  test('timeout dan tool konteks runtime menggunakan konfigurasi baharu', () {
    expect(AppConfig.defaultTimeout, const Duration(minutes: 3));
    expect(AppConfig.browserTimeout, const Duration(minutes: 2));
    expect(AppConfig.backgroundExecutionLimit, const Duration(minutes: 30));

    final engine = ToolEngine(LocalDatabase());
    final runtimeInfo = engine.definition('runtime_info');
    final browserOpen = engine.definition('browser_open');
    expect(runtimeInfo, isNotNull);
    expect(
      (browserOpen!.parameters['properties'] as Map<String, dynamic>)
          .containsKey('desktop_mode'),
      isTrue,
    );
    engine.dispose();
  });

}
