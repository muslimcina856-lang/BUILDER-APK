import 'dart:io';

import 'package:ai_multiagent/src/services/duckduckgo_search_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('DuckDuckGoSearchService parser', () {
    test('parses full HTML results, redirect URLs and deduplicates', () async {
      final body = await File('test/fixtures/duckduckgo_html.html').readAsString();
      final results = DuckDuckGoSearchService.parseHtmlResults(body, limit: 20);

      expect(results, hasLength(2));
      expect(results.first.rank, 1);
      expect(results.first.title, 'Alpha Result');
      expect(results.first.url, 'https://example.com/alpha?x=1&y=2');
      expect(results.first.displayUrl, 'example.com/alpha');
      expect(results.first.snippet, 'Alpha snippet with useful details.');
      expect(results.first.source, 'html');
      expect(results.last.rank, 2);
    });

    test('parses Lite fallback with complete result fields', () async {
      final body = await File('test/fixtures/duckduckgo_lite.html').readAsString();
      final results = DuckDuckGoSearchService.parseLiteResults(body, limit: 20);

      expect(results, hasLength(2));
      expect(results.first.title, 'Lite One');
      expect(results.first.url, 'https://lite.example.net/one');
      expect(results.first.displayUrl, 'lite.example.net');
      expect(results.first.snippet, contains('A complete Lite result snippet.'));
      expect(results.first.source, 'lite');
      expect(results.last.rank, 2);
    });

    test('respects result limit', () async {
      final body = await File('test/fixtures/duckduckgo_html.html').readAsString();
      final results = DuckDuckGoSearchService.parseHtmlResults(body, limit: 1);
      expect(results, hasLength(1));
    });
  });
}
