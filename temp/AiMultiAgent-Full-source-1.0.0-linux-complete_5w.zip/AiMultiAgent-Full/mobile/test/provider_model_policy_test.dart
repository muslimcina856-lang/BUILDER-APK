import 'package:ai_multiagent/src/models/app_models.dart';
import 'package:ai_multiagent/src/services/provider_model_policy.dart';
import 'package:flutter_test/flutter_test.dart';

ProviderConfig mimoConfig({
  String model = 'mimo-v2-flash',
  List<String> availableModels = const <String>[],
}) =>
    ProviderConfig(
      id: 'mimo-test',
      name: 'Xiaomi MiMo',
      presetId: 'mimo',
      protocol: ProviderProtocol.openAiChat,
      baseUrl: 'https://api.xiaomimimo.com/v1',
      chatPath: '/chat/completions',
      modelsPath: '/models',
      authStyle: AuthStyle.apiKeyHeader,
      apiKeyHeader: 'api-key',
      apiKeyPrefix: '',
      model: model,
      availableModels: availableModels,
    );

void main() {
  group('ProviderModelPolicy Xiaomi MiMo', () {
    test('migrates the unsupported legacy flash model', () {
      final migrated = ProviderModelPolicy.migrateStoredProvider(
        mimoConfig(
          availableModels: const <String>[
            'mimo-v2-flash',
            'mimo-v2.5-pro',
          ],
        ),
      );

      expect(migrated.model, 'mimo-v2.5-pro');
      expect(migrated.availableModels, isNot(contains('mimo-v2-flash')));
      expect(migrated.testStatus, ProviderTestStatus.untested);
    });

    test('keeps only chat-compatible models from a live response', () {
      final values = ProviderModelPolicy.chatModels(
        mimoConfig(),
        const <String>[
          'mimo/mimo-v2.5-pro',
          'mimo-v2.5-asr',
          'mimo-v2.5-tts',
          'mimo-v2-flash',
          'mimo-v2.5',
        ],
      );

      expect(values, <String>['mimo-v2.5-pro', 'mimo-v2.5']);
    });

    test('recognises older MiMo configurations by official host', () {
      final legacy = mimoConfig().copyWith(presetId: 'legacy_provider');
      final migrated = ProviderModelPolicy.migrateStoredProvider(legacy);
      expect(migrated.model, 'mimo-v2.5-pro');
    });


    test('migrates the old 60 second timeout to 180 seconds', () {
      final legacy = mimoConfig().copyWith(timeoutSeconds: 60);
      final migrated = ProviderModelPolicy.migrateStoredProvider(legacy);
      expect(migrated.timeoutSeconds, 180);
    });
  });
}
