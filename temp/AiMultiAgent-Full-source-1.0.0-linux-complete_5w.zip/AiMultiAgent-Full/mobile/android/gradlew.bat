@echo off
setlocal
set GRADLE_VERSION=8.14.3
set CACHE_DIR=%USERPROFILE%\.gradle\bootstrap\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%CACHE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip';$z='%CACHE_DIR%\gradle.zip';Invoke-WebRequest -Uri $u -OutFile $z;Expand-Archive -Path $z -DestinationPath '%CACHE_DIR%' -Force"
)
call "%GRADLE_BIN%" -p "%~dp0" %*
endlocal
