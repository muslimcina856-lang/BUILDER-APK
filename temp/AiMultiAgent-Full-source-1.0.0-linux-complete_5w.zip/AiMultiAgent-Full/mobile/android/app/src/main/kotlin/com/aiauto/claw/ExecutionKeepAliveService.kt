package com.aiauto.claw

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import kotlin.math.max
import kotlin.math.min

class ExecutionKeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val requested = intent?.getLongExtra(EXTRA_MAX_DURATION_MS, MAX_DURATION_MS)
            ?: MAX_DURATION_MS
        val duration = min(MAX_DURATION_MS, max(MIN_DURATION_MS, requested))
        startAsForeground()
        acquireWakeLock(duration)
        stopRunnable?.let(handler::removeCallbacks)
        stopRunnable = Runnable { stopSelf() }.also {
            handler.postDelayed(it, duration)
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Ai MultiAgent sedang berjalan")
            .setContentText("Tugasan AI aktif di latar belakang, maksimum 30 minit.")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun acquireWakeLock(duration: Long) {
        val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = wakeLock ?: manager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "$packageName:AiMultiAgentExecution",
        ).also {
            it.setReferenceCounted(false)
            wakeLock = it
        }
        if (lock.isHeld) lock.release()
        lock.acquire(duration + 5_000L)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Tugasan latar belakang",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Menunjukkan tugasan AI yang sedang diteruskan di latar belakang."
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf(startId)
    }

    override fun onDestroy() {
        stopRunnable?.let(handler::removeCallbacks)
        stopRunnable = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "ai_execution"
        private const val NOTIFICATION_ID = 9104
        private const val ACTION_START = "com.aiauto.claw.action.START_EXECUTION"
        private const val ACTION_STOP = "com.aiauto.claw.action.STOP_EXECUTION"
        private const val EXTRA_MAX_DURATION_MS = "maxDurationMs"
        private const val MIN_DURATION_MS = 60_000L
        private const val MAX_DURATION_MS = 30L * 60L * 1000L

        fun start(context: Context, maxDurationMs: Long) {
            val intent = Intent(context, ExecutionKeepAliveService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_MAX_DURATION_MS, maxDurationMs)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ExecutionKeepAliveService::class.java))
        }
    }
}
