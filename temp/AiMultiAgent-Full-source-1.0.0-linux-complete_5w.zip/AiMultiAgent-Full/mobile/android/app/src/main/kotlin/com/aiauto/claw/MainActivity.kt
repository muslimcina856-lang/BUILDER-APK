package com.aiauto.claw

import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import android.webkit.WebSettings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val deviceChannelName = "com.aiauto.claw/device"
    private val browserChannelName = "com.aiauto.claw/browser"
    private var browserEngine: BackgroundBrowserEngine? = null

    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getDeviceInfo", "getRuntimeContext" -> result.success(runtimeContext())
                    "startExecutionKeepAlive" -> {
                        val maxDurationMs = call.argument<Number>("maxDurationMs")?.toLong()
                            ?: 30L * 60L * 1000L
                        try {
                            ExecutionKeepAliveService.start(this, maxDurationMs)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error(
                                "foreground_service_start_failed",
                                error.message ?: error.javaClass.simpleName,
                                null,
                            )
                        }
                    }
                    "stopExecutionKeepAlive" -> {
                        ExecutionKeepAliveService.stop(this)
                        result.success(null)
                    }
                    "openNotificationSettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            }
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    "openAppSettings" -> {
                        try {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:$packageName"),
                            )
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        browserEngine = BackgroundBrowserEngine(this)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, browserChannelName)
            .setMethodCallHandler { call, result ->
                browserEngine?.handle(call, result)
                    ?: result.error("browser_unavailable", "Enjin browser tidak tersedia.", null)
            }
    }

    private fun runtimeContext(): Map<String, Any?> {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val deviceType = when (uiModeManager.currentModeType) {
            Configuration.UI_MODE_TYPE_TELEVISION -> "android-tv"
            Configuration.UI_MODE_TYPE_CAR -> "android-auto"
            Configuration.UI_MODE_TYPE_WATCH -> "android-watch"
            else -> if (resources.configuration.smallestScreenWidthDp >= 600) {
                "android-tablet"
            } else {
                "android-phone"
            }
        }
        val packageInfo = packageManager.getPackageInfo(packageName, 0)
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toLong()
        }
        return mapOf(
            "platform" to "android",
            "deviceType" to deviceType,
            "manufacturer" to Build.MANUFACTURER,
            "brand" to Build.BRAND,
            "model" to Build.MODEL,
            "androidRelease" to Build.VERSION.RELEASE,
            "sdk" to Build.VERSION.SDK_INT,
            "primaryAbi" to Build.SUPPORTED_ABIS.firstOrNull(),
            "supportedAbis" to Build.SUPPORTED_ABIS.toList(),
            "builtInLinuxGuestAbi" to if (BuildConfig.FULL_LINUX_EDITION) "arm64-v8a" else null,
            "packageName" to packageName,
            "versionName" to packageInfo.versionName,
            "versionCode" to versionCode,
            "applicationTargetSdk" to applicationInfo.targetSdkVersion,
            "fullEdition" to BuildConfig.FULL_LINUX_EDITION,
            "embeddedBrowserAvailable" to true,
            "embeddedBrowserEngine" to "Android System WebView/Chromium",
            "embeddedBrowserUserAgent" to WebSettings.getDefaultUserAgent(this),
            "browserDefaultMode" to "desktop-emulation",
            "remotePcAccess" to false,
            "remotePcNote" to
                "Aplikasi tidak boleh melihat PC jauh atau tab browser sedia ada tanpa sambungan MCP/companion yang dipasang dan diberi akses oleh pengguna.",
        )
    }

    override fun onDestroy() {
        browserEngine?.destroy()
        browserEngine = null
        super.onDestroy()
    }
}
