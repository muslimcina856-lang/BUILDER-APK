# Flutter engine, plugin registration and native entry points.
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.GeneratedPluginRegistrant { *; }
-dontwarn io.flutter.embedding.**

-keep class com.aiauto.claw.MainActivity { *; }
-keep class com.aiauto.claw.BackgroundBrowserEngine { *; }
-keep class com.aiauto.claw.ExecutionKeepAliveService { *; }

# Preserve JavaScript bridges and reflection metadata used by plugins.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable

# Optional TLS providers may not be present on every device.
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
