# Store Listing — Bahasa Melayu

**Nama:** Ai MultiAgent

**Penerangan pendek:** Klien AI local/BYOK premium dengan model pilihan anda, tools, browser dan automasi.

**Penerangan penuh:**

Ai MultiAgent menghubungkan telefon anda terus kepada provider AI pilihan anda. Tiada login dan tiada backend Ai MultiAgent. Masukkan API key, pilih model dan terus berbual melalui antaramuka premium.

Model aktif bertindak sebagai orchestrator. Ia boleh mencari melalui DuckDuckGo, membaca laman melalui browser tersembunyi, mengurus fail, menggunakan skills, menjalankan terminal workspace dan mendelegasikan subtugas kepada sub-agent dinamik apabila diperlukan.

Ciri utama:

- 52 preset provider termasuk Xiaomi MiMo, OpenAI, Claude, Gemini, DeepSeek dan provider local.
- Provider biasa hanya memerlukan API key dan model.
- Custom Provider untuk Base URL/protokol sendiri.
- Chat Markdown yang kemas dengan progres operasi boleh dilipat.
- Paparan imej, video, audio, HTML, dokumen dan pelbagai fail.
- Browser Android System WebView/Chromium berjalan di belakang UI.
- DuckDuckGo Search, memory local, skills dan Skill Creator.
- Terminal latar belakang serta automasi WorkManager.
- Approval hanya untuk tindakan berisiko seperti delete, overwrite atau arahan destruktif.
- API key, data dan permission disimpan local.
- Tiada Accessibility Service.

Kandungan dan API key dihantar terus kepada provider atau laman yang anda pilih. Lengkapkan URL Polisi Privasi serta maklumat sokongan penerbit sebelum diterbitkan.
