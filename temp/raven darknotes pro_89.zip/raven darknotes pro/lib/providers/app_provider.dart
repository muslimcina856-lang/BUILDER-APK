import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppProvider with ChangeNotifier {
  VideoPlayerController? videoController;
  ThemeMode themeMode = ThemeMode.dark;
  Color primaryColor = const Color(0xFF00FFCC); // Default Neon Cyan for Cyberpunk Feel
  
  double tabunganTarget = 0;
  double tabunganTotal = 0;
  List<Map<String, String>> catatanList = [];

  AppProvider() {
    _initVideo();
    _loadData();
  }

  void _initVideo() {
    try {
      videoController = VideoPlayerController.asset('assets/banner.mp4')
        ..initialize().then((_) {
          videoController!.setLooping(true);
          videoController!.setVolume(1.0); // Memastikan audio berjalan
          videoController!.play(); // Mulai otomatis
          notifyListeners();
        }).catchError((e) {
          debugPrint("Video Error: \$e");
        });
    } catch(e) {
      debugPrint("Video init failed: \$e");
    }
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    
    String themeStr = prefs.getString('theme') ?? 'dark';
    if(themeStr == 'light') themeMode = ThemeMode.light;
    else if(themeStr == 'system') themeMode = ThemeMode.system;
    
    int colorVal = prefs.getInt('primaryColor') ?? 0xFF00FFCC;
    primaryColor = Color(colorVal);

    tabunganTarget = prefs.getDouble('tabunganTarget') ?? 0;
    tabunganTotal = prefs.getDouble('tabunganTotal') ?? 0;

    String notesStr = prefs.getString('catatan') ?? '[]';
    List<dynamic> decoded = jsonDecode(notesStr);
    catatanList = decoded.map((e) => Map<String, String>.from(e)).toList();

    notifyListeners();
  }

  void setTheme(String mode) async {
    if(mode == 'dark') themeMode = ThemeMode.dark;
    else if(mode == 'light') themeMode = ThemeMode.light;
    else themeMode = ThemeMode.system;
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('theme', mode);
    notifyListeners();
  }

  void setColor(Color color) async {
    primaryColor = color;
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt('primaryColor', color.value);
    notifyListeners();
  }

  void setTarget(double target) async {
    tabunganTarget = target;
    final prefs = await SharedPreferences.getInstance();
    prefs.setDouble('tabunganTarget', target);
    notifyListeners();
  }

  void addSaldo(double amount) async {
    tabunganTotal += amount;
    final prefs = await SharedPreferences.getInstance();
    prefs.setDouble('tabunganTotal', tabunganTotal);
    notifyListeners();
  }

  void resetTabungan() async {
    tabunganTotal = 0;
    final prefs = await SharedPreferences.getInstance();
    prefs.setDouble('tabunganTotal', tabunganTotal);
    notifyListeners();
  }

  void addCatatan(String title, String content) async {
    catatanList.add({'title': title, 'content': content});
    _saveCatatan();
  }

  void deleteCatatan(int index) async {
    catatanList.removeAt(index);
    _saveCatatan();
  }

  void _saveCatatan() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('catatan', jsonEncode(catatanList));
    notifyListeners();
  }

  @override
  void dispose() {
    videoController?.dispose();
    super.dispose();
  }
}
