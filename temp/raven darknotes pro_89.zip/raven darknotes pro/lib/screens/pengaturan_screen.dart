import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class PengaturanScreen extends StatelessWidget {
  const PengaturanScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: ListView(
        physics: const BouncingScrollPhysics(),
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                child: Icon(Icons.tune, color: theme.primaryColor, size: 28),
              ),
              const SizedBox(width: 15),
              Text('System Config', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: theme.primaryColor)),
            ],
          ),
          const SizedBox(height: 30),
          
          _buildConfigCard(
            theme,
            'Antarmuka & Tema',
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Mode Tampilan', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(color: theme.scaffoldBackgroundColor, borderRadius: BorderRadius.circular(12)),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: appProvider.themeMode == ThemeMode.dark ? 'dark' : (appProvider.themeMode == ThemeMode.light ? 'light' : 'system'),
                      items: const [
                        DropdownMenuItem(value: 'system', child: Text('Mengikuti Sistem (Default)')),
                        DropdownMenuItem(value: 'dark', child: Text('Dark Mode (Cyberpunk)')),
                        DropdownMenuItem(value: 'light', child: Text('Light Mode (Clean)')),
                      ],
                      onChanged: (val) {
                        if(val != null) appProvider.setTheme(val);
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 25),
                const Text('Pilih Warna Aksen Neon', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 15),
                Wrap(
                  spacing: 15,
                  runSpacing: 15,
                  children: [
                    _buildColorDot(context, const Color(0xFF00FFCC), appProvider), // Neon Cyan
                    _buildColorDot(context, const Color(0xFFFF00FF), appProvider), // Neon Pink
                    _buildColorDot(context, const Color(0xFF8A2BE2), appProvider), // Purple
                    _buildColorDot(context, const Color(0xFFFF3366), appProvider), // Red/Pink
                    _buildColorDot(context, const Color(0xFF00E676), appProvider), // Neon Green
                    _buildColorDot(context, const Color(0xFFFFD700), appProvider), // Gold
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          _buildConfigCard(
            theme,
            'Dukungan & Donasi',
            Column(
              children: [
                const Text('Bantu pengembangan aplikasi Raven DarkNote ini agar terus bebas dari iklan dan biaya langganan.', textAlign: TextAlign.center, style: TextStyle(height: 1.5)),
                const SizedBox(height: 20),
                Container(
                  width: 220,
                  height: 220,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: theme.primaryColor, width: 3),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.3), blurRadius: 20, spreadRadius: 2)],
                    image: const DecorationImage(
                      image: AssetImage('assets/donate.jpg'),
                      fit: BoxFit.cover,
                    )
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 40),
          Center(
            child: Column(
              children: [
                Icon(Icons.diamond, color: theme.primaryColor, size: 30),
                const SizedBox(height: 10),
                const Text('Raven DarkNote Pro v1.0.0', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                const Text('Engineered by RavenZy', style: TextStyle(color: Colors.grey, fontSize: 12)),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConfigCard(ThemeData theme, String title, Widget content) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
        border: Border.all(color: theme.primaryColor.withOpacity(0.1))
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: theme.primaryColor)),
          const Divider(height: 30),
          content,
        ],
      ),
    );
  }

  Widget _buildColorDot(BuildContext context, Color color, AppProvider provider) {
    bool isSelected = provider.primaryColor.value == color.value;
    return GestureDetector(
      onTap: () => provider.setColor(color),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: isSelected ? 50 : 40,
        height: isSelected ? 50 : 40,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: isSelected ? Border.all(color: Colors.white, width: 3) : null,
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.6), blurRadius: isSelected ? 15 : 5, spreadRadius: isSelected ? 3 : 1)
          ]
        ),
        child: isSelected ? const Icon(Icons.check, color: Colors.white) : null,
      ),
    );
  }
}
