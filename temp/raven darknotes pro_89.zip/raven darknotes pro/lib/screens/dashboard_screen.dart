import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../providers/app_provider.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final theme = Theme.of(context);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Mewah Video Container
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: theme.primaryColor.withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 2,
                  offset: const Offset(0, 5)
                )
              ],
              border: Border.all(color: theme.primaryColor.withOpacity(0.5), width: 2),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: _buildVideoPlayer(appProvider),
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Dashboard Utama',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: theme.primaryColor,
                    letterSpacing: 1.0
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Selamat datang di Raven DarkNote Pro. Sistem multifungsi premium tanpa API key tambahan. Semua terkontrol di ujung jari Anda.',
                  style: TextStyle(fontSize: 14, color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7), height: 1.5),
                ),
                const SizedBox(height: 25),
                
                // Stats Grid Mewah
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.3,
                  children: [
                    _buildPremiumCard(context, Icons.account_balance_wallet, 'Saldo Tabungan', 'Rp ${appProvider.tabunganTotal.toStringAsFixed(0)}'),
                    _buildPremiumCard(context, Icons.note_alt, 'Catatan Tersimpan', '${appProvider.catatanList.length} File'),
                    _buildPremiumCard(context, Icons.rocket_launch, 'Tools Aktif', '6 Modul'),
                    _buildPremiumCard(context, Icons.verified_user, 'Status Sistem', 'Premium VIP'),
                  ],
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer(AppProvider provider) {
    if (provider.videoController != null && provider.videoController!.value.isInitialized) {
      return AspectRatio(
        aspectRatio: provider.videoController!.value.aspectRatio,
        child: VideoPlayer(provider.videoController!),
      );
    } else {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: Container(
          color: Colors.black87, 
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: Colors.white),
                SizedBox(height: 10),
                Text('Memuat Video...', style: TextStyle(color: Colors.white))
              ],
            )
          )
        ),
      );
    }
  }

  Widget _buildPremiumCard(BuildContext context, IconData icon, String title, String value) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          )
        ],
        border: Border.all(color: theme.primaryColor.withOpacity(0.15)),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -15,
            top: -15,
            child: Icon(icon, size: 80, color: theme.primaryColor.withOpacity(0.05)),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: theme.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: Icon(icon, color: theme.primaryColor, size: 24),
                ),
                const Spacer(),
                Text(title, style: TextStyle(fontSize: 11, color: theme.textTheme.bodyMedium?.color?.withOpacity(0.6), fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: theme.primaryColor)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
