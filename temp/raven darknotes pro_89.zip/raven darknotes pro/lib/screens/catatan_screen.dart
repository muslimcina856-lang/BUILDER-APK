import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class CatatanScreen extends StatefulWidget {
  const CatatanScreen({super.key});

  @override
  State<CatatanScreen> createState() => _CatatanScreenState();
}

class _CatatanScreenState extends State<CatatanScreen> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();

  void _showAddDialog(BuildContext context, AppProvider provider, ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: theme.cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        title: Row(
          children: [
            Icon(Icons.edit_document, color: theme.primaryColor),
            const SizedBox(width: 10),
            const Text('Tulis Catatan', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                hintText: 'Judul Rahasia...',
                filled: true,
                fillColor: theme.scaffoldBackgroundColor,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _contentController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Ketik isi catatan di sini...',
                filled: true,
                fillColor: theme.scaffoldBackgroundColor,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: Colors.grey))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: theme.primaryColor, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () {
              if(_titleController.text.isNotEmpty && _contentController.text.isNotEmpty) {
                provider.addCatatan(_titleController.text, _contentController.text);
                _titleController.clear();
                _contentController.clear();
                Navigator.pop(context);
              }
            },
            child: const Text('Simpan Data', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                  child: Icon(Icons.shield, color: theme.primaryColor, size: 28),
                ),
                const SizedBox(width: 15),
                Text('Catatan Enkripsi', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: theme.primaryColor)),
              ],
            ),
            const SizedBox(height: 25),
            Expanded(
              child: appProvider.catatanList.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inventory_2_outlined, size: 80, color: theme.primaryColor.withOpacity(0.3)),
                        const SizedBox(height: 15),
                        Text('Brankas Catatan Kosong', style: TextStyle(color: theme.primaryColor.withOpacity(0.6), fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    )
                  )
                : ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: appProvider.catatanList.length,
                    itemBuilder: (context, index) {
                      final note = appProvider.catatanList[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        decoration: BoxDecoration(
                          color: theme.cardColor,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
                          border: Border.left(color: theme.primaryColor, width: 5)
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                          title: Text(note['title']!, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: theme.primaryColor)),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(note['content']!, style: const TextStyle(height: 1.5)),
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_sweep, color: Colors.redAccent, size: 28),
                            onPressed: () => appProvider.deleteCatatan(index),
                          ),
                        ),
                      );
                    },
                  ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: theme.primaryColor,
        elevation: 5,
        onPressed: () => _showAddDialog(context, appProvider, theme),
        icon: const Icon(Icons.add_task, color: Colors.white),
        label: const Text('Tulis Baru', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
