import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class TabunganScreen extends StatefulWidget {
  const TabunganScreen({super.key});

  @override
  State<TabunganScreen> createState() => _TabunganScreenState();
}

class _TabunganScreenState extends State<TabunganScreen> {
  final _targetController = TextEditingController();
  final _saldoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final theme = Theme.of(context);
    
    double progress = 0.0;
    if (appProvider.tabunganTarget > 0) {
      progress = appProvider.tabunganTotal / appProvider.tabunganTarget;
      if (progress > 1.0) progress = 1.0;
    }

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(theme),
          const SizedBox(height: 25),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.cardColor,
                borderRadius: BorderRadius.circular(25),
                boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10))],
                border: Border.all(color: theme.primaryColor.withOpacity(0.2)),
              ),
              child: ListView(
                physics: const BouncingScrollPhysics(),
                children: [
                  const Text('Saldo Terkumpul', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey)),
                  const SizedBox(height: 5),
                  Text(
                    'Rp ${appProvider.tabunganTotal.toStringAsFixed(0)}',
                    style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: theme.primaryColor, letterSpacing: 1.0),
                  ),
                  const SizedBox(height: 30),
                  
                  // Premium Progress Bar
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('${(progress * 100).toStringAsFixed(1)}% dari Target', style: TextStyle(fontWeight: FontWeight.bold, color: theme.primaryColor)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 12,
                          backgroundColor: theme.primaryColor.withOpacity(0.1),
                          valueColor: AlwaysStoppedAnimation<Color>(theme.primaryColor),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40),

                  // Inputs Mewah
                  _buildInputField('Target Menabung Baru (Rp)', _targetController, Icons.flag, theme, onSuffixTap: () {
                    if(_targetController.text.isNotEmpty) {
                      appProvider.setTarget(double.parse(_targetController.text));
                      _targetController.clear();
                      FocusScope.of(context).unfocus();
                    }
                  }),
                  const SizedBox(height: 20),
                  _buildInputField('Tambah Saldo (Rp)', _saldoController, Icons.add_card, theme),
                  const SizedBox(height: 25),
                  
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      elevation: 5,
                      shadowColor: theme.primaryColor.withOpacity(0.5)
                    ),
                    onPressed: () {
                      if(_saldoController.text.isNotEmpty) {
                        appProvider.addSaldo(double.parse(_saldoController.text));
                        _saldoController.clear();
                        FocusScope.of(context).unfocus();
                      }
                    },
                    child: const Text('MASUKKAN KE CELENGAN', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  ),
                  const SizedBox(height: 15),
                  TextButton(
                    onPressed: () => appProvider.resetTabungan(),
                    child: const Text('Reset Celengan', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
          child: Icon(Icons.account_balance, color: theme.primaryColor, size: 28),
        ),
        const SizedBox(width: 15),
        Text('Brankas Lokal', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: theme.primaryColor)),
      ],
    );
  }

  Widget _buildInputField(String label, TextEditingController controller, IconData icon, ThemeData theme, {VoidCallback? onSuffixTap}) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      style: const TextStyle(fontWeight: FontWeight.bold),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey.shade500),
        prefixIcon: Icon(icon, color: theme.primaryColor),
        filled: true,
        fillColor: theme.scaffoldBackgroundColor,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: theme.primaryColor, width: 2)),
        suffixIcon: onSuffixTap != null ? IconButton(icon: Icon(Icons.check_circle, color: theme.primaryColor, size: 30), onPressed: onSuffixTap) : null
      ),
    );
  }
}
