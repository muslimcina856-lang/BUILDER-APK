import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ToolsScreen extends StatefulWidget {
  const ToolsScreen({super.key});

  @override
  State<ToolsScreen> createState() => _ToolsScreenState();
}

class _ToolsScreenState extends State<ToolsScreen> {
  final _vidController = TextEditingController();
  final _qrController = TextEditingController();
  final _b64Controller = TextEditingController();
  final _ttsController = TextEditingController();
  
  String _qrData = '';
  String _ipData = '';
  String _b64Result = '';
  FlutterTts flutterTts = FlutterTts();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                child: Icon(Icons.hardware, color: theme.primaryColor, size: 28),
              ),
              const SizedBox(width: 15),
              Text('Cyber Tools', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: theme.primaryColor)),
            ],
          ),
          const SizedBox(height: 10),
          Text('*Semua tools berfungsi 100% lokal & Bypass tanpa API Key khusus.', style: TextStyle(color: theme.textTheme.bodyMedium?.color?.withOpacity(0.6), fontSize: 12)),
          const SizedBox(height: 20),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                _buildToolCard(
                  context, 'Sosmed Video Downloader', Icons.cloud_download,
                  Column(
                    children: [
                      _buildTextField(_vidController, 'Paste URL Video...', theme),
                      const SizedBox(height: 15),
                      _buildButton('Bypass & Download', () async {
                        if(_vidController.text.isNotEmpty) {
                          final url = Uri.parse('https://www.tikwm.com/api/?url=' + _vidController.text);
                          try {
                            final response = await http.get(url);
                            final data = jsonDecode(response.body);
                            if(data['code'] == 0) {
                              final playUrl = Uri.parse(data['data']['play']);
                              launchUrl(playUrl, mode: LaunchMode.externalApplication);
                            }
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Error mengambil video. Pastikan link valid.')));
                          }
                        }
                      }, theme)
                    ],
                  ), theme
                ),
                
                _buildToolCard(
                  context, 'QR Code Generator', Icons.qr_code_2,
                  Column(
                    children: [
                      _buildTextField(_qrController, 'Teks atau URL...', theme),
                      const SizedBox(height: 15),
                      _buildButton('Generate QR', () => setState(() => _qrData = _qrController.text), theme),
                      if(_qrData.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
                          child: QrImageView(data: _qrData, version: QrVersions.auto, size: 200),
                        ),
                      ]
                    ],
                  ), theme
                ),

                _buildToolCard(
                  context, 'Smart QR Scanner', Icons.document_scanner,
                  Column(
                    children: [
                      const Text('Scan kode QR secara langsung menggunakan kamera utama.', textAlign: TextAlign.center),
                      const SizedBox(height: 15),
                      _buildButton('Buka Kamera', () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const QRScannerPage()));
                      }, theme)
                    ],
                  ), theme
                ),

                _buildToolCard(
                  context, 'IP Tracker', Icons.radar,
                  Column(
                    children: [
                      _buildButton('Lacak IP Publik Saya', () async {
                        try {
                          final res = await http.get(Uri.parse('https://api.ipify.org?format=json'));
                          setState(() {
                            _ipData = jsonDecode(res.body)['ip'];
                          });
                        } catch(e) {
                          setState(() => _ipData = 'Gagal melacak IP');
                        }
                      }, theme),
                      if(_ipData.isNotEmpty) ...[
                        const SizedBox(height: 15),
                        Container(
                          padding: const EdgeInsets.all(15),
                          width: double.infinity,
                          decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                          child: Text('IP Address: $_ipData', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: theme.primaryColor)),
                        )
                      ]
                    ],
                  ), theme
                ),

                _buildToolCard(
                  context, 'Base64 Cryptography', Icons.security,
                  Column(
                    children: [
                      _buildTextField(_b64Controller, 'Masukkan Teks...', theme, maxLines: 2),
                      const SizedBox(height: 15),
                      Row(
                        children: [
                          Expanded(child: _buildButton('Encode', () {
                            setState(() {
                              _b64Result = base64Encode(utf8.encode(_b64Controller.text));
                            });
                          }, theme)),
                          const SizedBox(width: 10),
                          Expanded(child: _buildButton('Decode', () {
                            try {
                              setState(() {
                                _b64Result = utf8.decode(base64Decode(_b64Controller.text));
                              });
                            } catch(e) {
                              setState(() => _b64Result = 'Error: Format Invalid');
                            }
                          }, theme)),
                        ],
                      ),
                      if(_b64Result.isNotEmpty) ...[
                        const SizedBox(height: 15),
                        _buildTextField(TextEditingController(text: _b64Result), 'Hasil Output', theme, maxLines: 3, readOnly: true),
                      ]
                    ],
                  ), theme
                ),

                _buildToolCard(
                  context, 'AI Text to Speech (TTS)', Icons.record_voice_over,
                  Column(
                    children: [
                      _buildTextField(_ttsController, 'Teks untuk disuarakan...', theme, maxLines: 2),
                      const SizedBox(height: 15),
                      _buildButton('Bacakan Teks', () async {
                        if(_ttsController.text.isNotEmpty) {
                          await flutterTts.setLanguage("id-ID");
                          await flutterTts.setPitch(1.0);
                          await flutterTts.speak(_ttsController.text);
                        }
                      }, theme)
                    ],
                  ), theme
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, ThemeData theme, {int maxLines = 1, bool readOnly = false}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      readOnly: readOnly,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: theme.scaffoldBackgroundColor,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: theme.primaryColor, width: 1.5))
      ),
    );
  }

  Widget _buildButton(String text, VoidCallback onPressed, ThemeData theme) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: theme.primaryColor,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        minimumSize: const Size(double.infinity, 50)
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.0)),
    );
  }

  Widget _buildToolCard(BuildContext context, String title, IconData icon, Widget content, ThemeData theme) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ExpansionTile(
        collapsedIconColor: theme.primaryColor,
        iconColor: theme.primaryColor,
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
          child: Icon(icon, color: theme.primaryColor)
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: content,
          )
        ],
      ),
    );
  }
}

class QRScannerPage extends StatelessWidget {
  const QRScannerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kamera Scanner')),
      body: MobileScanner(
        onDetect: (capture) {
          final List<Barcode> barcodes = capture.barcodes;
          if(barcodes.isNotEmpty) {
            final String code = barcodes.first.rawValue ?? '---';
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: const Text('Hasil Scan', textAlign: TextAlign.center),
                content: SelectableText(code, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))
                ],
              )
            );
          }
        },
      ),
    );
  }
}
