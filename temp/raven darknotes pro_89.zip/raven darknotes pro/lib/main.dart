import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'screens/main_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: const RavenApp(),
    ),
  );
}

class RavenApp extends StatelessWidget {
  const RavenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, appProvider, child) {
        return MaterialApp(
          title: 'Raven DarkNote Pro',
          debugShowCheckedModeBanner: false,
          themeMode: appProvider.themeMode,
          theme: _buildTheme(Brightness.light, appProvider.primaryColor),
          darkTheme: _buildTheme(Brightness.dark, appProvider.primaryColor),
          home: const MainScreen(),
        );
      },
    );
  }

  ThemeData _buildTheme(Brightness brightness, Color primary) {
    final isDark = brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF0F0F13) : const Color(0xFFF0F2F5);
    final cardColor = isDark ? const Color(0xFF1C1C24) : Colors.white;

    return ThemeData(
      brightness: brightness,
      primaryColor: primary,
      scaffoldBackgroundColor: bgColor,
      cardColor: cardColor,
      fontFamily: 'Roboto',
      appBarTheme: AppBarTheme(
        backgroundColor: bgColor,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: primary),
        titleTextStyle: TextStyle(color: primary, fontSize: 20, fontWeight: FontWeight.bold),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: cardColor,
        selectedItemColor: primary,
        unselectedItemColor: Colors.grey.withOpacity(0.5),
        type: BottomNavigationBarType.fixed,
        elevation: 10,
      ),
      colorScheme: ColorScheme.fromSeed(seedColor: primary, brightness: brightness),
    );
  }
}
