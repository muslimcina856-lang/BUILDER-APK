# Seni Bina Ai MultiAgent 1.0.0

```text
Flutter shared code
├── Chat / Provider / Automasi / Skills / Lain-lain
├── AppState + SQLite + Secure Storage
├── ProviderService + AgentRuntime + ToolEngine
├── DuckDuckGo + Hidden Browser + Files + Terminal + MCP
└── LinuxWorkspaceService
        │
        ▼
Android product flavors
├── play  -> com.aiauto.claw (target 36)
│   └── AI tools + browser + private file sandbox
└── full  -> com.aiauto.claw.full (compatibility target 28)
    └── PRoot + apt/binary ARM64 inside private rootfs
```

## Pengasingan data

Setiap flavor mempunyai application ID berbeza, jadi Android memberi UID dan direktori data berasingan. Linux Workspace menggunakan direktori support aplikasi, tanpa bind mount storan luaran secara automatik.

## Build

- `play` menggunakan `lib/main_play.dart`.
- `full` menggunakan `lib/main_full.dart`.
- Manifest mengambil nama melalui `@string/app_name` yang dihasilkan oleh flavor.
- Ikon launcher Play dan Full datang daripada source set masing-masing.
- R8 dan resource shrinking diaktifkan untuk release.
