# Spesifikasi Fungsi Ai MultiAgent 1.0.0

## Identiti

| Edisi | Package | Entry point |
|---|---|---|
| Google Play | `com.aiauto.claw` | `lib/main_play.dart` |
| Full | `com.aiauto.claw.full` | `lib/main_full.dart` |

Tiada login, backend atau akaun Ai MultiAgent. Data dan API key disimpan local.

## Chat dan orchestrator

- Header ringkas menunjukkan provider dan model aktif.
- Tiada General Agent atau pemilih agent tetap.
- Model aktif menentukan sendiri bila tool, skill atau sub-agent diperlukan.
- Markdown, pautan, senarai, code block, imej, video, audio, HTML dan fail dipaparkan dalam chat.
- Status operasi dipaparkan di bawah perbualan dan dilipat selepas selesai.

## Provider

Provider preset hanya meminta API key dan model apabila sesuai. Custom Provider menyediakan Base URL, protokol, endpoint, auth, header serta template JSON. Sambungan diuji ketika disimpan.

## Browser dan tools

- DuckDuckGo HTML dengan Lite fallback.
- Android System WebView/Chromium tersembunyi.
- Buka, baca, klik, isi, submit, DOM/HTML snapshot, screenshot PNG dan muat turun.
- Terminal latar belakang dengan stdout, stderr, exit code dan kawalan stop.
- Skill Creator default, skills ZIP/URL, automasi WorkManager dan MCP local.

## Linux Workspace

- Semua data berada dalam `getApplicationSupportDirectory()/linux`.
- Tiada permission storan luaran luas.
- Root hanya dalam rootfs private, bukan root Android.
- Google Play (target 36): tiada Linux PRoot; tools aplikasi dan sandbox fail local kekal tersedia.
- Full (compatibility target 28): package/binary ARM64 dibenarkan dalam rootfs private.
- Reset Workspace hanya memadam direktori Linux milik aplikasi.

## Kelulusan

Tool biasa berjalan terus. Approval hanya untuk delete, overwrite, arahan terminal destruktif, HTTP DELETE atau tool remote yang dikesan merosakkan data. Pilihan: Sekali, Sesi ini, Sentiasa atau Tolak.
