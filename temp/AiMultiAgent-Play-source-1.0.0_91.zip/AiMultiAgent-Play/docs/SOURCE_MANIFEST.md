# Manifest Sumber Ai MultiAgent 1.0.0+1

## Edisi

| Flavor | Package | Launcher | Compile/Target | Entry point |
|---|---|---|---|---|
| `play` | `com.aiauto.claw` | Ai MultiAgent | 36 / 36 | `lib/main_play.dart` |
| `full` | `com.aiauto.claw.full` | Ai MultiAgent Full | 36 / 28 | `lib/main_full.dart` |

Minimum SDK 24, Java 17, Flutter + Kotlin Android.

## Komponen

- 52 provider preset + Custom Provider.
- 31 tools termasuk DuckDuckGo, browser, screenshot web, fail, memory, terminal, skills dan MCP.
- Model pilihan pengguna sebagai orchestrator dan sub-agent dinamik.
- SQLite local, secure API key vault dan approval berasaskan risiko.
- Linux Workspace Full dalam internal support directory aplikasi.
- Dashboard terminal dan proses background bersama.
- Ikon Play dan ikon premium Full tanpa teks.
- Skrip build dan CI untuk kedua-dua flavor.

## Fail penting

- `mobile/lib/main_play.dart`
- `mobile/lib/main_full.dart`
- `mobile/lib/src/config/app_edition.dart`
- `mobile/lib/src/config/app_config.dart`
- `mobile/lib/src/services/linux_workspace_service.dart`
- `mobile/lib/src/ui/screens/linux_workspace_screen.dart`
- `mobile/android/app/build.gradle.kts`
- `mobile/android/app/src/play/res/`
- `mobile/android/app/src/full/res/`
- `scripts/build_play.sh`
- `scripts/build_full.sh`
- `.github/workflows/android-release-check.yml`
- `assets/branding/icon_play_master.png`
- `assets/branding/icon_full_master.png`
