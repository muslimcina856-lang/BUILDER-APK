# Google Play Edition

Ini ialah projek standalone Google Play sahaja. Package ID `com.aiauto.claw`, target API 36.
