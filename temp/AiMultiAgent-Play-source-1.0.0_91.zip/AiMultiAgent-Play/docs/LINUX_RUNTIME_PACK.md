# Linux Runtime Pack — Ai MultiAgent Full

Edisi Full boleh memasang satu ZIP runtime ke direktori internal private aplikasi. Pack boleh dibundel sebagai:

```text
mobile/assets/linux/full/runtime-pack.zip
```

atau dipilih melalui Android File Picker.

Struktur wajib:

```text
runtime/bin/proot
runtime/lib/...       # pilihan, library host proot
rootfs/bin/sh
rootfs/...
```

Cipta pack:

```bash
python3 scripts/linux/create_runtime_pack.py \
  --proot /path/to/proot-arm64 \
  --libs /path/to/proot-libs \
  --rootfs /path/to/debian-rootfs \
  --output mobile/assets/linux/full/runtime-pack.zip
```

Pemeriksaan pemasangan:

- ZIP path traversal ditolak.
- Saiz pack dihadkan kepada 3 GiB.
- `runtime/bin/proot` dan `rootfs/bin/sh` wajib ada.
- Permission Unix serta symlink dipulihkan.
- Pemasangan menggunakan staging dan rollback sekiranya gagal.
- Pack diekstrak hanya ke storan internal private aplikasi Full.
- Symlink ke shared storage atau direktori data Android ditolak.

Selepas runtime tersedia, `terminal_start` menggunakan PRoot secara automatik dengan bind terhad kepada peranti asas yang wujud (`/dev/null`, `/dev/zero`, random, tty/pts), `/proc`, dan folder private aplikasi (`/workspace`, `/root`, `/tmp`). `/sys`, `/sdcard`, `/storage` dan folder aplikasi lain tidak dibind.

## Nota target SDK

Binary yang dipasang ke direktori writable aplikasi tidak boleh dipanggil melalui `execve()` oleh app yang menyasarkan API 29 atau lebih tinggi. Oleh itu APK Full menggunakan compatibility `targetSdk 28` dan tidak diterbitkan melalui Google Play. `compileSdk` kekal 36.
