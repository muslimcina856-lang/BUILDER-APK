# Ai MultiAgent — Google Play Edition

Aplikasi Android BYOK tanpa backend. Package ID `com.aiauto.claw`, versi `1.0.0+1`, `compileSdk 36`, `targetSdk 36`.

## Build

```bash
./scripts/build_debug.sh
./scripts/build_play.sh
```

Edisi ini menggunakan tools yang dibundel dan tidak menjalankan pemasangan binary Linux baharu. Data aplikasi kekal dalam storan private aplikasi.
