#!/usr/bin/env python3
from __future__ import annotations

import argparse
import stat
import zipfile
from pathlib import Path


def zip_info(name: str, mode: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name)
    info.create_system = 3
    info.external_attr = (mode & 0xFFFF) << 16
    return info


def add_tree(zf: zipfile.ZipFile, source: Path, prefix: str) -> None:
    for path in sorted(source.rglob('*')):
        rel = path.relative_to(source).as_posix()
        arcname = f'{prefix}/{rel}'
        stat_result = path.lstat()
        mode = stat_result.st_mode
        if path.is_symlink():
            target = path.readlink().as_posix()
            info = zip_info(arcname, stat.S_IFLNK | 0o777)
            zf.writestr(info, target.encode('utf-8'), compress_type=zipfile.ZIP_STORED)
            continue
        if path.is_dir():
            info = zip_info(f'{arcname}/', stat.S_IFDIR | stat.S_IMODE(mode))
            zf.writestr(info, b'', compress_type=zipfile.ZIP_STORED)
            continue
        if path.is_file():
            info = zip_info(arcname, stat.S_IFREG | stat.S_IMODE(mode))
            with path.open('rb') as handle:
                zf.writestr(info, handle.read(), compress_type=zipfile.ZIP_DEFLATED)


def main() -> None:
    parser = argparse.ArgumentParser(description='Cipta runtime pack Linux Workspace Ai MultiAgent Full.')
    parser.add_argument('--proot', required=True, type=Path, help='Binary proot ARM64 Android.')
    parser.add_argument('--rootfs', required=True, type=Path, help='Direktori rootfs Linux yang mempunyai bin/sh.')
    parser.add_argument('--libs', type=Path, help='Direktori library host untuk proot, jika diperlukan.')
    parser.add_argument('--output', required=True, type=Path, help='Fail ZIP output.')
    args = parser.parse_args()

    if not args.proot.is_file():
        raise SystemExit('Binary proot tidak ditemui.')
    if not (args.rootfs / 'bin/sh').exists():
        raise SystemExit('rootfs/bin/sh tidak ditemui.')
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(args.output, 'w', allowZip64=True) as zf:
        info = zip_info('runtime/bin/proot', stat.S_IFREG | 0o700)
        zf.writestr(info, args.proot.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
        if args.libs:
            add_tree(zf, args.libs, 'runtime/lib')
        add_tree(zf, args.rootfs, 'rootfs')

    print(args.output)


if __name__ == '__main__':
    main()
