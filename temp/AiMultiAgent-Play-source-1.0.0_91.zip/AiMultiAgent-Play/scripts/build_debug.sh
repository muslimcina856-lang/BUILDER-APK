#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK tidak ditemui." >&2; exit 1; }
"$ROOT/scripts/check_project.sh"
cd "$ROOT/mobile"
flutter pub get
flutter build apk --debug
printf 'Play debug: %s\n' "$ROOT/mobile/build/app/outputs/flutter-apk/app-debug.apk"
