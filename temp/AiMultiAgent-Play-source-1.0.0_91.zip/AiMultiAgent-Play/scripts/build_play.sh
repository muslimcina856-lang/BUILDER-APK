#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MOBILE="$ROOT/mobile"
DIST="$ROOT/dist/play"
command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK tidak ditemui." >&2; exit 1; }
"$ROOT/scripts/check_project.sh"
mkdir -p "$DIST"
cd "$MOBILE"
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk "$DIST/AiMultiAgent-Play-1.0.0.apk"
if [[ -f android/key.properties ]]; then
  flutter build appbundle --release
  cp build/app/outputs/bundle/release/app-release.aab "$DIST/AiMultiAgent-Play-1.0.0.aab"
fi
(cd "$DIST" && sha256sum ./* > SHA256SUMS.txt)
echo "Edisi Google Play siap: $DIST"
