#!/usr/bin/env python3
"""Offline fixture smoke test for the expected DuckDuckGo result contract.

The canonical implementation is in Dart and has matching Flutter unit tests.
This script is runnable in source-only environments where Flutter/Dart is absent.
"""
from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]


def decode_redirect(raw: str) -> str:
    value = f"https:{raw}" if raw.startswith("//") else raw
    parsed = urlparse(value)
    redirected = parse_qs(parsed.query).get("uddg", [None])[0]
    return unquote(redirected) if redirected else value


def clean(value: str) -> str:
    return " ".join(value.split())


def valid(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def parse_html(body: str, limit: int = 20) -> list[dict]:
    soup = BeautifulSoup(body, "html.parser")
    output: list[dict] = []
    seen: set[str] = set()
    for element in soup.select(".result, .web-result"):
        anchor = element.select_one(".result__a, a.result-link, h2 a")
        if not anchor:
            continue
        url = decode_redirect(anchor.get("href", ""))
        if not valid(url) or url in seen:
            continue
        seen.add(url)
        display = element.select_one(".result__url, .result-url")
        snippet = element.select_one(".result__snippet, .result-snippet")
        output.append(
            {
                "rank": len(output) + 1,
                "title": clean(anchor.get_text()) or url,
                "url": url,
                "display_url": clean(display.get_text()) if display else urlparse(url).netloc,
                "snippet": clean(snippet.get_text()) if snippet else "",
                "source": "html",
            }
        )
        if len(output) >= limit:
            break
    return output


def parse_lite(body: str, limit: int = 20) -> list[dict]:
    soup = BeautifulSoup(body, "html.parser")
    output: list[dict] = []
    seen: set[str] = set()
    for anchor in soup.select("a.result-link"):
        url = decode_redirect(anchor.get("href", ""))
        if not valid(url) or url in seen:
            continue
        seen.add(url)
        title = clean(anchor.get_text())
        row = anchor.find_parent("tr")
        snippet = ""
        if row:
            next_row = row.find_next_sibling("tr")
            if next_row:
                node = next_row.select_one(".result-snippet") or next_row
                snippet = clean(node.get_text())
        output.append(
            {
                "rank": len(output) + 1,
                "title": title,
                "url": url,
                "display_url": urlparse(url).netloc,
                "snippet": snippet,
                "source": "lite",
            }
        )
        if len(output) >= limit:
            break
    return output


def main() -> None:
    html_results = parse_html((ROOT / "mobile/test/fixtures/duckduckgo_html.html").read_text())
    lite_results = parse_lite((ROOT / "mobile/test/fixtures/duckduckgo_lite.html").read_text())

    assert len(html_results) == 2, html_results
    assert html_results[0]["url"] == "https://example.com/alpha?x=1&y=2"
    assert html_results[0]["snippet"] == "Alpha snippet with useful details."
    assert len(lite_results) == 2, lite_results
    assert lite_results[0]["url"] == "https://lite.example.net/one"
    assert lite_results[0]["snippet"] == "A complete Lite result snippet."

    report = {
        "test": "DuckDuckGo offline parser fixture",
        "status": "passed",
        "checks": 6,
        "html_results": html_results,
        "lite_results": lite_results,
        "note": "Live DuckDuckGo network test requires a network-enabled Android/build environment.",
    }
    path = ROOT / "docs/test-results/duckduckgo_fixture_result.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
