# Changelog

## 1.0.0+1 — Dual Edition Final

- Menggantikan ikon edisi Full dengan ikon premium tanpa teks.
- Menetapkan Play kepada target API 36 dan Full sideload kepada compatibility target API 28.
- Menambah dashboard Linux Workspace Full, terminal manual dan paparan proses AI bersama.
- Mengasingkan seluruh rootfs, apt, projek, cache dan screenshot dalam storan internal private aplikasi.
- Membuang bind `/sys` serta menghadkan bind device PRoot kepada device asas sahaja.
- Menambah pemasangan runtime asset automatik atau import runtime pack melalui File Picker.
- Menambah screenshot browser Chromium tersembunyi sebagai artifact imej dalam chat.
- Menambah staging, rollback, semakan symlink dan pemulihan permission ketika memasang runtime.

## 1.0.0+1 — Dual Edition

- Menambah flavor Google Play (`com.aiauto.claw`) dan Full (`com.aiauto.claw.full`).
- Menambah entry point, nama launcher dan ikon tanpa teks yang berasingan.
- Menambah Linux Workspace private dalam storan dalaman aplikasi.
- Menyekat package manager sistem pada edisi Play dan membenarkannya pada edisi Full.
- Menambah skrip build APK/AAB mengikut flavor dan workflow CI dua edisi.
- Memastikan tiada permission akses storan luaran luas.

## 1.0.0+1 — Versi 1

- Mengekalkan versi paparan aplikasi sebagai `1.0.0`.
- Menggunakan `versionCode`/build number `1` sebagai build pertama aplikasi.
- Membetulkan ikon Material yang tidak wujud.
- Menambah pelaksanaan lengkap Skill Creator.
- Membetulkan pemeriksaan atribut HTML yang menyebabkan kompilasi gagal.
- Menggunakan UI chat premium, orchestrator model utama dan sub-agent dinamik.
- Menyokong provider BYOK, browser latar belakang, DuckDuckGo, media, fail, skills, automasi dan terminal.
- Mengunci `compileSdk` kepada API 36; edisi Play menyasarkan API 36 dan Full menggunakan compatibility target 28 untuk PRoot.
- Membuang `mimo-v2-flash` daripada pilihan chat selepas endpoint MiMo menolaknya.
- Menapis model ASR/TTS daripada pemilih model chat dan menyegar model terus daripada provider.
- Memindahkan lifecycle `AppScope` ke atas Navigator dan menggunakan akses state tanpa dependency dalam callback async.
- Menambah key stabil pada mesej/media untuk mengelakkan state widget berpindah ketika senarai chat berubah.
- Menambah migrasi automatik konfigurasi MiMo lama serta fallback model satu kali.
