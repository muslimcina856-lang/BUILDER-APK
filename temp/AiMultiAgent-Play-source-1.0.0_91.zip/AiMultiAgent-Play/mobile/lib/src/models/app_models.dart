import 'dart:convert';

import 'package:flutter/material.dart';

enum ProviderProtocol { openAiChat, openAiResponses, anthropic, gemini, customRest }
enum AuthStyle { bearer, apiKeyHeader, xApiKey, queryParameter, none }
enum ProviderTestStatus { untested, testing, success, failed }
enum MessageRole { system, user, assistant, tool }
enum PermissionDecision { deny, allowOnce, allowSession, allowAlways }
enum PermissionPolicy { ask, alwaysAllow, alwaysDeny }
enum ToolRisk { readOnly, localWrite, externalWrite, sensitive }
enum RunStatus { idle, planning, waitingPermission, runningTool, completed, failed, cancelled }
enum McpTransport { streamableHttp, legacySse }
enum AttachmentKind { image, video, audio, document, archive, code, other }
enum ArtifactKind { image, video, audio, webpage, html, searchResults, file }
enum RunEventState { running, success, failed, waiting, info }

T enumByName<T extends Enum>(List<T> values, Object? value, T fallback) {
  final name = value?.toString();
  return values.firstWhere((item) => item.name == name, orElse: () => fallback);
}

class ProviderPreset {
  const ProviderPreset({
    required this.id,
    required this.name,
    required this.category,
    required this.protocol,
    required this.baseUrl,
    required this.chatPath,
    this.modelsPath = '/models',
    this.authStyle = AuthStyle.bearer,
    this.apiKeyHeader = 'Authorization',
    this.apiKeyPrefix = 'Bearer ',
    this.defaultModels = const <String>[],
    this.defaultHeaders = const <String, String>{},
    this.supportsModelList = true,
    this.notes = '',
  });

  final String id;
  final String name;
  final String category;
  final ProviderProtocol protocol;
  final String baseUrl;
  final String chatPath;
  final String modelsPath;
  final AuthStyle authStyle;
  final String apiKeyHeader;
  final String apiKeyPrefix;
  final List<String> defaultModels;
  final Map<String, String> defaultHeaders;
  final bool supportsModelList;
  final String notes;

  bool get isCustom => id.startsWith('custom_') || id == 'custom';
}

class ProviderConfig {
  const ProviderConfig({
    required this.id,
    required this.name,
    required this.presetId,
    required this.protocol,
    required this.baseUrl,
    required this.chatPath,
    required this.modelsPath,
    required this.authStyle,
    required this.apiKeyHeader,
    required this.apiKeyPrefix,
    required this.model,
    this.extraHeaders = const <String, String>{},
    this.availableModels = const <String>[],
    this.temperature = .3,
    this.maxTokens = 4096,
    this.timeoutSeconds = 60,
    this.enabled = true,
    this.supportsStreaming = true,
    this.supportsTools = true,
    this.supportsVision = false,
    this.testStatus = ProviderTestStatus.untested,
    this.lastTestMessage = '',
    this.lastLatencyMs,
    this.customRequestTemplate = '',
    this.customResponsePath = 'choices.0.message.content',
    this.createdAt,
    this.updatedAt,
  });

  final String id;
  final String name;
  final String presetId;
  final ProviderProtocol protocol;
  final String baseUrl;
  final String chatPath;
  final String modelsPath;
  final AuthStyle authStyle;
  final String apiKeyHeader;
  final String apiKeyPrefix;
  final String model;
  final Map<String, String> extraHeaders;
  final List<String> availableModels;
  final double temperature;
  final int maxTokens;
  final int timeoutSeconds;
  final bool enabled;
  final bool supportsStreaming;
  final bool supportsTools;
  final bool supportsVision;
  final ProviderTestStatus testStatus;
  final String lastTestMessage;
  final int? lastLatencyMs;
  final String customRequestTemplate;
  final String customResponsePath;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  bool get isCustom => presetId.startsWith('custom_') || presetId == 'custom';

  ProviderConfig copyWith({
    String? name,
    String? presetId,
    ProviderProtocol? protocol,
    String? baseUrl,
    String? chatPath,
    String? modelsPath,
    AuthStyle? authStyle,
    String? apiKeyHeader,
    String? apiKeyPrefix,
    String? model,
    Map<String, String>? extraHeaders,
    List<String>? availableModels,
    double? temperature,
    int? maxTokens,
    int? timeoutSeconds,
    bool? enabled,
    bool? supportsStreaming,
    bool? supportsTools,
    bool? supportsVision,
    ProviderTestStatus? testStatus,
    String? lastTestMessage,
    int? lastLatencyMs,
    String? customRequestTemplate,
    String? customResponsePath,
    DateTime? updatedAt,
  }) =>
      ProviderConfig(
        id: id,
        name: name ?? this.name,
        presetId: presetId ?? this.presetId,
        protocol: protocol ?? this.protocol,
        baseUrl: baseUrl ?? this.baseUrl,
        chatPath: chatPath ?? this.chatPath,
        modelsPath: modelsPath ?? this.modelsPath,
        authStyle: authStyle ?? this.authStyle,
        apiKeyHeader: apiKeyHeader ?? this.apiKeyHeader,
        apiKeyPrefix: apiKeyPrefix ?? this.apiKeyPrefix,
        model: model ?? this.model,
        extraHeaders: extraHeaders ?? this.extraHeaders,
        availableModels: availableModels ?? this.availableModels,
        temperature: temperature ?? this.temperature,
        maxTokens: maxTokens ?? this.maxTokens,
        timeoutSeconds: timeoutSeconds ?? this.timeoutSeconds,
        enabled: enabled ?? this.enabled,
        supportsStreaming: supportsStreaming ?? this.supportsStreaming,
        supportsTools: supportsTools ?? this.supportsTools,
        supportsVision: supportsVision ?? this.supportsVision,
        testStatus: testStatus ?? this.testStatus,
        lastTestMessage: lastTestMessage ?? this.lastTestMessage,
        lastLatencyMs: lastLatencyMs ?? this.lastLatencyMs,
        customRequestTemplate: customRequestTemplate ?? this.customRequestTemplate,
        customResponsePath: customResponsePath ?? this.customResponsePath,
        createdAt: createdAt,
        updatedAt: updatedAt ?? DateTime.now(),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'presetId': presetId,
        'protocol': protocol.name,
        'baseUrl': baseUrl,
        'chatPath': chatPath,
        'modelsPath': modelsPath,
        'authStyle': authStyle.name,
        'apiKeyHeader': apiKeyHeader,
        'apiKeyPrefix': apiKeyPrefix,
        'model': model,
        'extraHeaders': extraHeaders,
        'availableModels': availableModels,
        'temperature': temperature,
        'maxTokens': maxTokens,
        'timeoutSeconds': timeoutSeconds,
        'enabled': enabled,
        'supportsStreaming': supportsStreaming,
        'supportsTools': supportsTools,
        'supportsVision': supportsVision,
        'testStatus': testStatus.name,
        'lastTestMessage': lastTestMessage,
        'lastLatencyMs': lastLatencyMs,
        'customRequestTemplate': customRequestTemplate,
        'customResponsePath': customResponsePath,
        'createdAt': createdAt?.toIso8601String(),
        'updatedAt': updatedAt?.toIso8601String(),
      };

  factory ProviderConfig.fromJson(Map<String, dynamic> json) => ProviderConfig(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Provider',
        presetId: json['presetId']?.toString() ?? 'custom',
        protocol: enumByName(ProviderProtocol.values, json['protocol'], ProviderProtocol.openAiChat),
        baseUrl: json['baseUrl']?.toString() ?? '',
        chatPath: json['chatPath']?.toString() ?? '/chat/completions',
        modelsPath: json['modelsPath']?.toString() ?? '/models',
        authStyle: enumByName(AuthStyle.values, json['authStyle'], AuthStyle.bearer),
        apiKeyHeader: json['apiKeyHeader']?.toString() ?? 'Authorization',
        apiKeyPrefix: json['apiKeyPrefix']?.toString() ?? 'Bearer ',
        model: json['model']?.toString() ?? '',
        extraHeaders: Map<String, String>.from(json['extraHeaders'] as Map? ?? const <String, String>{}),
        availableModels: (json['availableModels'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        temperature: (json['temperature'] as num?)?.toDouble() ?? .3,
        maxTokens: (json['maxTokens'] as num?)?.toInt() ?? 4096,
        timeoutSeconds: (json['timeoutSeconds'] as num?)?.toInt() ?? 60,
        enabled: json['enabled'] as bool? ?? true,
        supportsStreaming: json['supportsStreaming'] as bool? ?? true,
        supportsTools: json['supportsTools'] as bool? ?? true,
        supportsVision: json['supportsVision'] as bool? ?? false,
        testStatus: enumByName(ProviderTestStatus.values, json['testStatus'], ProviderTestStatus.untested),
        lastTestMessage: json['lastTestMessage']?.toString() ?? '',
        lastLatencyMs: (json['lastLatencyMs'] as num?)?.toInt(),
        customRequestTemplate: json['customRequestTemplate']?.toString() ?? '',
        customResponsePath: json['customResponsePath']?.toString() ?? 'choices.0.message.content',
        createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? ''),
        updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? ''),
      );
}

class AgentProfile {
  const AgentProfile({
    required this.id,
    required this.name,
    required this.description,
    required this.systemPrompt,
    required this.iconCode,
    this.providerId,
    this.modelOverride,
    this.toolIds = const <String>[],
    this.skillIds = const <String>[],
    this.enabled = true,
    this.isBuiltIn = false,
  });

  final String id;
  final String name;
  final String description;
  final String systemPrompt;
  final int iconCode;
  final String? providerId;
  final String? modelOverride;
  final List<String> toolIds;
  final List<String> skillIds;
  final bool enabled;
  final bool isBuiltIn;

  IconData get icon => IconData(iconCode, fontFamily: 'MaterialIcons');

  AgentProfile copyWith({String? providerId, String? modelOverride, List<String>? toolIds, List<String>? skillIds, bool? enabled}) => AgentProfile(
        id: id,
        name: name,
        description: description,
        systemPrompt: systemPrompt,
        iconCode: iconCode,
        providerId: providerId ?? this.providerId,
        modelOverride: modelOverride ?? this.modelOverride,
        toolIds: toolIds ?? this.toolIds,
        skillIds: skillIds ?? this.skillIds,
        enabled: enabled ?? this.enabled,
        isBuiltIn: isBuiltIn,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'description': description,
        'systemPrompt': systemPrompt,
        'iconCode': iconCode,
        'providerId': providerId,
        'modelOverride': modelOverride,
        'toolIds': toolIds,
        'skillIds': skillIds,
        'enabled': enabled,
        'isBuiltIn': isBuiltIn,
      };

  factory AgentProfile.fromJson(Map<String, dynamic> json) => AgentProfile(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Agent',
        description: json['description']?.toString() ?? '',
        systemPrompt: json['systemPrompt']?.toString() ?? '',
        iconCode: (json['iconCode'] as num?)?.toInt() ?? Icons.smart_toy_rounded.codePoint,
        providerId: json['providerId']?.toString(),
        modelOverride: json['modelOverride']?.toString(),
        toolIds: (json['toolIds'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        skillIds: (json['skillIds'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        enabled: json['enabled'] as bool? ?? true,
        isBuiltIn: json['isBuiltIn'] as bool? ?? false,
      );
}

class ChatAttachment {
  const ChatAttachment({
    required this.id,
    required this.name,
    required this.path,
    required this.mimeType,
    required this.sizeBytes,
    required this.kind,
    this.sourceUrl,
  });

  final String id;
  final String name;
  final String path;
  final String mimeType;
  final int sizeBytes;
  final AttachmentKind kind;
  final String? sourceUrl;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'path': path,
        'mimeType': mimeType,
        'sizeBytes': sizeBytes,
        'kind': kind.name,
        'sourceUrl': sourceUrl,
      };

  factory ChatAttachment.fromJson(Map<String, dynamic> json) => ChatAttachment(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Lampiran',
        path: json['path']?.toString() ?? '',
        mimeType: json['mimeType']?.toString() ?? 'application/octet-stream',
        sizeBytes: (json['sizeBytes'] as num?)?.toInt() ?? 0,
        kind: enumByName(
          AttachmentKind.values,
          json['kind'],
          AttachmentKind.other,
        ),
        sourceUrl: json['sourceUrl']?.toString(),
      );
}

class ChatArtifact {
  const ChatArtifact({
    required this.id,
    required this.kind,
    required this.title,
    this.subtitle = '',
    this.localPath = '',
    this.url = '',
    this.mimeType = 'application/octet-stream',
    this.html = '',
    this.data = const <String, dynamic>{},
  });

  final String id;
  final ArtifactKind kind;
  final String title;
  final String subtitle;
  final String localPath;
  final String url;
  final String mimeType;
  final String html;
  final Map<String, dynamic> data;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'kind': kind.name,
        'title': title,
        'subtitle': subtitle,
        'localPath': localPath,
        'url': url,
        'mimeType': mimeType,
        'html': html,
        'data': data,
      };

  factory ChatArtifact.fromJson(Map<String, dynamic> json) => ChatArtifact(
        id: json['id']?.toString() ?? '',
        kind: enumByName(
          ArtifactKind.values,
          json['kind'],
          ArtifactKind.file,
        ),
        title: json['title']?.toString() ?? 'Hasil',
        subtitle: json['subtitle']?.toString() ?? '',
        localPath: json['localPath']?.toString() ?? '',
        url: json['url']?.toString() ?? '',
        mimeType: json['mimeType']?.toString() ?? 'application/octet-stream',
        html: json['html']?.toString() ?? '',
        data: Map<String, dynamic>.from(
          json['data'] as Map? ?? const <String, dynamic>{},
        ),
      );
}

class RunEvent {
  const RunEvent({
    required this.id,
    required this.title,
    required this.detail,
    required this.state,
    required this.createdAt,
    this.toolId,
    this.agentRole,
  });

  final String id;
  final String title;
  final String detail;
  final RunEventState state;
  final DateTime createdAt;
  final String? toolId;
  final String? agentRole;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'detail': detail,
        'state': state.name,
        'createdAt': createdAt.toIso8601String(),
        'toolId': toolId,
        'agentRole': agentRole,
      };

  factory RunEvent.fromJson(Map<String, dynamic> json) => RunEvent(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? 'Proses',
        detail: json['detail']?.toString() ?? '',
        state: enumByName(
          RunEventState.values,
          json['state'],
          RunEventState.info,
        ),
        createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
            DateTime.now(),
        toolId: json['toolId']?.toString(),
        agentRole: json['agentRole']?.toString(),
      );
}

class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.sessionId,
    required this.role,
    required this.content,
    required this.createdAt,
    this.name,
    this.toolCallId,
    this.metadata = const <String, dynamic>{},
  });

  final String id;
  final String sessionId;
  final MessageRole role;
  final String content;
  final DateTime createdAt;
  final String? name;
  final String? toolCallId;
  final Map<String, dynamic> metadata;

  List<ChatAttachment> get attachments =>
      (metadata['attachments'] as List? ?? const <dynamic>[])
          .whereType<Map>()
          .map(
            (item) => ChatAttachment.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList(growable: false);

  List<ChatArtifact> get artifacts =>
      (metadata['artifacts'] as List? ?? const <dynamic>[])
          .whereType<Map>()
          .map(
            (item) => ChatArtifact.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList(growable: false);

  List<RunEvent> get runEvents =>
      (metadata['runEvents'] as List? ?? const <dynamic>[])
          .whereType<Map>()
          .map(
            (item) => RunEvent.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList(growable: false);

  ChatMessage copyWith({
    String? content,
    Map<String, dynamic>? metadata,
  }) =>
      ChatMessage(
        id: id,
        sessionId: sessionId,
        role: role,
        content: content ?? this.content,
        createdAt: createdAt,
        name: name,
        toolCallId: toolCallId,
        metadata: metadata ?? this.metadata,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'sessionId': sessionId,
        'role': role.name,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
        'name': name,
        'toolCallId': toolCallId,
        'metadata': metadata,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id']?.toString() ?? '',
        sessionId: json['sessionId']?.toString() ?? '',
        role: enumByName(MessageRole.values, json['role'], MessageRole.user),
        content: json['content']?.toString() ?? '',
        createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
            DateTime.now(),
        name: json['name']?.toString(),
        toolCallId: json['toolCallId']?.toString(),
        metadata: Map<String, dynamic>.from(
          json['metadata'] as Map? ?? const <String, dynamic>{},
        ),
      );
}

class ToolDefinition {
  const ToolDefinition({
    required this.id,
    required this.name,
    required this.description,
    required this.risk,
    required this.parameters,
    this.category = 'Umum',
    this.enabled = true,
  });

  final String id;
  final String name;
  final String description;
  final ToolRisk risk;
  final Map<String, dynamic> parameters;
  final String category;
  final bool enabled;

  Map<String, dynamic> toOpenAiJson() => <String, dynamic>{
        'type': 'function',
        'function': <String, dynamic>{
          'name': id,
          'description': description,
          'parameters': parameters,
        },
      };
}

class ToolCall {
  const ToolCall({required this.id, required this.name, required this.arguments});
  final String id;
  final String name;
  final Map<String, dynamic> arguments;
}

class ModelTurn {
  const ModelTurn({required this.text, this.toolCalls = const <ToolCall>[], this.raw = const <String, dynamic>{}});
  final String text;
  final List<ToolCall> toolCalls;
  final Map<String, dynamic> raw;
}

class ProviderTestResult {
  const ProviderTestResult({
    required this.success,
    required this.message,
    required this.latencyMs,
    this.models = const <String>[],
  });
  final bool success;
  final String message;
  final int latencyMs;
  final List<String> models;
}

class PermissionRequest {
  const PermissionRequest({
    required this.id,
    required this.tool,
    required this.scope,
    required this.description,
    required this.risk,
  });
  final String id;
  final ToolDefinition tool;
  final String scope;
  final String description;
  final ToolRisk risk;
}

class PermissionRule {
  const PermissionRule({
    required this.id,
    required this.toolId,
    required this.scope,
    required this.policy,
    required this.updatedAt,
  });

  final String id;
  final String toolId;
  final String scope;
  final PermissionPolicy policy;
  final DateTime updatedAt;

  bool matches(String requestedToolId, String requestedScope) {
    final toolMatches = toolId == '*' || toolId == requestedToolId;
    final scopeMatches = scope == '*' || scope == requestedScope;
    return toolMatches && scopeMatches;
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'toolId': toolId,
        'scope': scope,
        'policy': policy.name,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory PermissionRule.fromJson(Map<String, dynamic> json) => PermissionRule(
        id: json['id']?.toString() ?? '',
        toolId: json['toolId']?.toString() ?? '',
        scope: json['scope']?.toString() ?? '*',
        policy: enumByName(PermissionPolicy.values, json['policy'], PermissionPolicy.ask),
        updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? '') ?? DateTime.now(),
      );
}

class ToolResult {
  const ToolResult({required this.success, required this.output, this.data = const <String, dynamic>{}});
  final bool success;
  final String output;
  final Map<String, dynamic> data;

  String toModelText() => jsonEncode(<String, dynamic>{'success': success, 'output': output, 'data': data});
}

class SkillDefinition {
  const SkillDefinition({
    required this.id,
    required this.name,
    required this.description,
    required this.instructions,
    this.triggers = const <String>[],
    this.toolIds = const <String>[],
    this.enabled = true,
    this.sourcePath = '',
    this.isBuiltIn = false,
  });
  final String id;
  final String name;
  final String description;
  final String instructions;
  final List<String> triggers;
  final List<String> toolIds;
  final bool enabled;
  final String sourcePath;
  final bool isBuiltIn;

  SkillDefinition copyWith({bool? enabled}) => SkillDefinition(
        id: id,
        name: name,
        description: description,
        instructions: instructions,
        triggers: triggers,
        toolIds: toolIds,
        enabled: enabled ?? this.enabled,
        sourcePath: sourcePath,
        isBuiltIn: isBuiltIn,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'description': description,
        'instructions': instructions,
        'triggers': triggers,
        'toolIds': toolIds,
        'enabled': enabled,
        'sourcePath': sourcePath,
        'isBuiltIn': isBuiltIn,
      };

  factory SkillDefinition.fromJson(Map<String, dynamic> json) => SkillDefinition(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Skill',
        description: json['description']?.toString() ?? '',
        instructions: json['instructions']?.toString() ?? '',
        triggers: (json['triggers'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        toolIds: (json['toolIds'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        enabled: json['enabled'] as bool? ?? true,
        sourcePath: json['sourcePath']?.toString() ?? '',
        isBuiltIn: json['isBuiltIn'] as bool? ?? false,
      );
}

class AutomationDefinition {
  const AutomationDefinition({
    required this.id,
    required this.name,
    required this.prompt,
    required this.providerId,
    required this.agentId,
    required this.intervalMinutes,
    this.enabled = true,
    this.notifyOnComplete = true,
    this.runAsForeground = false,
    this.allowedToolIds = const <String>[],
    this.lastRunAt,
    this.lastResult = '',
  });
  final String id;
  final String name;
  final String prompt;
  final String providerId;
  final String agentId;
  final int intervalMinutes;
  final bool enabled;
  final bool notifyOnComplete;
  final bool runAsForeground;
  final List<String> allowedToolIds;
  final DateTime? lastRunAt;
  final String lastResult;

  AutomationDefinition copyWith({bool? enabled, bool? notifyOnComplete, bool? runAsForeground, List<String>? allowedToolIds, DateTime? lastRunAt, String? lastResult}) => AutomationDefinition(
        id: id,
        name: name,
        prompt: prompt,
        providerId: providerId,
        agentId: agentId,
        intervalMinutes: intervalMinutes,
        enabled: enabled ?? this.enabled,
        notifyOnComplete: notifyOnComplete ?? this.notifyOnComplete,
        runAsForeground: runAsForeground ?? this.runAsForeground,
        allowedToolIds: allowedToolIds ?? this.allowedToolIds,
        lastRunAt: lastRunAt ?? this.lastRunAt,
        lastResult: lastResult ?? this.lastResult,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'prompt': prompt,
        'providerId': providerId,
        'agentId': agentId,
        'intervalMinutes': intervalMinutes,
        'enabled': enabled,
        'notifyOnComplete': notifyOnComplete,
        'runAsForeground': runAsForeground,
        'allowedToolIds': allowedToolIds,
        'lastRunAt': lastRunAt?.toIso8601String(),
        'lastResult': lastResult,
      };

  factory AutomationDefinition.fromJson(Map<String, dynamic> json) => AutomationDefinition(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Automasi',
        prompt: json['prompt']?.toString() ?? '',
        providerId: json['providerId']?.toString() ?? '',
        agentId: json['agentId']?.toString() ?? 'orchestrator',
        intervalMinutes: (json['intervalMinutes'] as num?)?.toInt() ?? 60,
        enabled: json['enabled'] as bool? ?? true,
        notifyOnComplete: json['notifyOnComplete'] as bool? ?? true,
        runAsForeground: json['runAsForeground'] as bool? ?? false,
        allowedToolIds: (json['allowedToolIds'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
        lastRunAt: DateTime.tryParse(json['lastRunAt']?.toString() ?? ''),
        lastResult: json['lastResult']?.toString() ?? '',
      );
}

class MemoryRecord {
  const MemoryRecord({required this.id, required this.title, required this.content, required this.createdAt, this.tags = const <String>[]});
  final String id;
  final String title;
  final String content;
  final DateTime createdAt;
  final List<String> tags;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
        'tags': tags,
      };

  factory MemoryRecord.fromJson(Map<String, dynamic> json) => MemoryRecord(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? 'Memori',
        content: json['content']?.toString() ?? '',
        createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
        tags: (json['tags'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      );
}


class McpServerConfig {
  const McpServerConfig({
    required this.id,
    required this.name,
    required this.baseUrl,
    this.transport = McpTransport.streamableHttp,
    this.enabled = true,
    this.headers = const <String, String>{},
    this.lastTestMessage = '',
    this.lastTestAt,
  });

  final String id;
  final String name;
  final String baseUrl;
  final McpTransport transport;
  final bool enabled;
  final Map<String, String> headers;
  final String lastTestMessage;
  final DateTime? lastTestAt;

  McpServerConfig copyWith({
    String? name,
    String? baseUrl,
    McpTransport? transport,
    bool? enabled,
    Map<String, String>? headers,
    String? lastTestMessage,
    DateTime? lastTestAt,
  }) =>
      McpServerConfig(
        id: id,
        name: name ?? this.name,
        baseUrl: baseUrl ?? this.baseUrl,
        transport: transport ?? this.transport,
        enabled: enabled ?? this.enabled,
        headers: headers ?? this.headers,
        lastTestMessage: lastTestMessage ?? this.lastTestMessage,
        lastTestAt: lastTestAt ?? this.lastTestAt,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'baseUrl': baseUrl,
        'transport': transport.name,
        'enabled': enabled,
        'headers': headers,
        'lastTestMessage': lastTestMessage,
        'lastTestAt': lastTestAt?.toIso8601String(),
      };

  factory McpServerConfig.fromJson(Map<String, dynamic> json) => McpServerConfig(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'MCP Local',
        baseUrl: json['baseUrl']?.toString() ?? 'http://127.0.0.1:3000/mcp',
        transport: enumByName(McpTransport.values, json['transport'], McpTransport.streamableHttp),
        enabled: json['enabled'] as bool? ?? true,
        headers: Map<String, String>.from(json['headers'] as Map? ?? const <String, String>{}),
        lastTestMessage: json['lastTestMessage']?.toString() ?? '',
        lastTestAt: DateTime.tryParse(json['lastTestAt']?.toString() ?? ''),
      );
}

class ToolLogRecord {
  const ToolLogRecord({
    required this.id,
    required this.sessionId,
    required this.toolId,
    required this.scope,
    required this.success,
    required this.summary,
    required this.createdAt,
  });

  final int id;
  final String sessionId;
  final String toolId;
  final String scope;
  final bool success;
  final String summary;
  final DateTime createdAt;
}
