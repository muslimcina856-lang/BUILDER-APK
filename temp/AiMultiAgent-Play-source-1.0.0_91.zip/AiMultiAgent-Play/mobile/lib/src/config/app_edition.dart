enum AppEdition {
  play,
  full;

  bool get isFull => this == AppEdition.full;
  bool get isPlay => this == AppEdition.play;

  String get displayName => switch (this) {
        AppEdition.play => 'Google Play',
        AppEdition.full => 'Full',
      };
}
