import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config/app_config.dart';

class LinuxWorkspaceStatus {
  const LinuxWorkspaceStatus({
    required this.rootPath,
    required this.runtimeReady,
    required this.rootfsReady,
    required this.usedBytes,
    required this.packageInstallEnabled,
  });

  final String rootPath;
  final bool runtimeReady;
  final bool rootfsReady;
  final int usedBytes;
  final bool packageInstallEnabled;

  bool get ready => runtimeReady && rootfsReady;
}

class LinuxCommandSpec {
  const LinuxCommandSpec({
    required this.executable,
    required this.arguments,
    required this.hostWorkingDirectory,
    required this.environment,
  });

  final String executable;
  final List<String> arguments;
  final String hostWorkingDirectory;
  final Map<String, String> environment;
}

class LinuxWorkspaceService {
  static const int maxRuntimePackBytes = 3 * 1024 * 1024 * 1024;
  static const String bundledRuntimeAsset =
      'assets/linux/full/runtime-pack.zip';

  Future<Directory> ensurePrivateRoot() async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'Linux Workspace penuh hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final support = await getApplicationSupportDirectory();
    _assertPrivateAppPath(support.path);
    final root = Directory(p.join(support.path, 'linux'));
    for (final child in <String>[
      'runtime/bin',
      'runtime/lib',
      'rootfs',
      'home',
      'workspace',
      'packages',
      'browser',
      'snapshots',
      'tmp',
    ]) {
      await Directory(p.join(root.path, child)).create(recursive: true);
    }
    return root;
  }

  Future<LinuxWorkspaceStatus> status() async {
    if (!AppConfig.isFullEdition) {
      return const LinuxWorkspaceStatus(
        rootPath: '',
        runtimeReady: false,
        rootfsReady: false,
        usedBytes: 0,
        packageInstallEnabled: false,
      );
    }
    final root = await ensurePrivateRoot();
    final proot = File(p.join(root.path, 'runtime/bin/proot'));
    final shell = File(p.join(root.path, 'rootfs/bin/sh'));
    return LinuxWorkspaceStatus(
      rootPath: root.path,
      runtimeReady: await proot.exists(),
      rootfsReady: await shell.exists(),
      usedBytes: await _directorySize(root),
      packageInstallEnabled: AppConfig.linuxPackageInstallEnabled,
    );
  }

  /// Cuba memasang runtime yang dibundel bersama APK Full.
  ///
  /// Kaedah ini memulangkan `false` apabila pembina aplikasi tidak meletakkan
  /// `assets/linux/full/runtime-pack.zip` dalam projek. Pengguna masih boleh
  /// memilih runtime pack melalui Android File Picker.
  Future<bool> installBundledRuntimeIfAvailable() async {
    if (!AppConfig.isFullEdition) return false;
    final current = await status();
    if (current.ready) return true;
    ByteData data;
    try {
      data = await rootBundle.load(bundledRuntimeAsset);
    } on FlutterError {
      return false;
    }
    final root = await ensurePrivateRoot();
    final temporary = File(p.join(root.path, 'tmp', 'bundled-runtime.zip'));
    await temporary.parent.create(recursive: true);
    await temporary.writeAsBytes(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      flush: true,
    );
    try {
      await installRuntimePack(temporary.path);
      return true;
    } finally {
      if (await temporary.exists()) await temporary.delete();
    }
  }

  /// Memasang runtime pack ZIP ke direktori internal private aplikasi.
  ///
  /// Struktur pack:
  /// runtime/bin/proot
  /// runtime/lib/...
  /// rootfs/bin/sh
  /// rootfs/...
  Future<void> installRuntimePack(String archivePath) async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'Import runtime pack hanya dibenarkan pada edisi Full.',
      );
    }
    final source = File(archivePath);
    if (!await source.exists()) {
      throw const FileSystemException('Runtime pack tidak ditemui.');
    }
    final length = await source.length();
    if (length <= 0 || length > maxRuntimePackBytes) {
      throw const FileSystemException('Saiz runtime pack tidak sah.');
    }

    final root = await ensurePrivateRoot();
    final staging = Directory('${root.path}.staging');
    final backup = Directory('${root.path}.backup');
    if (await staging.exists()) await staging.delete(recursive: true);
    if (await backup.exists()) await backup.delete(recursive: true);
    await staging.create(recursive: true);

    final symbolicLinks = <({String path, String target})>[];
    final chmodGroups = <int, List<String>>{};
    InputFileStream? input;
    try {
      input = InputFileStream(source.path);
      final archive = ZipDecoder().decodeStream(input, verify: true);
      for (final entry in archive) {
        final normalized = p.normalize(entry.name.replaceAll('\\', '/'));
        if (normalized.isEmpty ||
            normalized == '.' ||
            p.isAbsolute(normalized) ||
            normalized == '..' ||
            normalized.startsWith('../')) {
          throw const FileSystemException(
            'Runtime pack mengandungi laluan tidak selamat.',
          );
        }
        final destination = p.normalize(p.join(staging.path, normalized));
        if (!p.isWithin(staging.path, destination)) {
          throw const FileSystemException(
            'Runtime pack cuba menulis di luar sandbox.',
          );
        }

        if (entry.isSymbolicLink) {
          final target = entry.symbolicLink;
          if (target == null || target.isEmpty) {
            throw const FileSystemException('Symlink runtime pack tidak sah.');
          }
          _validateSymlinkTarget(staging.path, destination, target);
          symbolicLinks.add((path: destination, target: target));
          continue;
        }

        if (entry.isFile) {
          await File(destination).parent.create(recursive: true);
          final output = OutputFileStream(destination);
          entry.writeContent(output);
          output.closeSync();
          _queueMode(chmodGroups, entry.unixPermissions, destination);
        } else {
          await Directory(destination).create(recursive: true);
          _queueMode(chmodGroups, entry.unixPermissions, destination);
        }
      }

      for (final item in symbolicLinks) {
        final link = Link(item.path);
        await link.parent.create(recursive: true);
        await link.create(item.target, recursive: true);
      }
      await _applyModes(chmodGroups);

      final stagedProot = File(p.join(staging.path, 'runtime/bin/proot'));
      final stagedShell = File(p.join(staging.path, 'rootfs/bin/sh'));
      if (!await stagedProot.exists() || !await stagedShell.exists()) {
        throw const FileSystemException(
          'Runtime pack tidak lengkap: proot atau rootfs/bin/sh tiada.',
        );
      }

      await _chmod('700', <String>[stagedProot.path]);
      if (await root.exists()) await root.rename(backup.path);
      try {
        await staging.rename(root.path);
        if (await backup.exists()) await backup.delete(recursive: true);
      } catch (_) {
        if (await root.exists()) await root.delete(recursive: true);
        if (await backup.exists()) await backup.rename(root.path);
        rethrow;
      }
    } catch (_) {
      if (await staging.exists()) await staging.delete(recursive: true);
      rethrow;
    } finally {
      input?.closeSync();
    }
  }

  Future<LinuxCommandSpec?> commandSpec({
    required String command,
    required String relativeWorkingDirectory,
    Map<String, String> environment = const <String, String>{},
  }) async {
    if (!AppConfig.isFullEdition) return null;
    final root = await ensurePrivateRoot();
    final proot = File(p.join(root.path, 'runtime/bin/proot'));
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final shell = File(p.join(rootfs.path, 'bin/sh'));
    if (!await proot.exists() || !await shell.exists()) return null;

    final workspace = Directory(p.join(root.path, 'workspace'));
    final home = Directory(p.join(root.path, 'home'));
    final tmp = Directory(p.join(root.path, 'tmp'));
    final libs = Directory(p.join(root.path, 'runtime/lib'));
    final safeRelative = p.normalize(relativeWorkingDirectory);
    if (p.isAbsolute(safeRelative) ||
        safeRelative == '..' ||
        safeRelative.startsWith('../')) {
      throw const FileSystemException('Working directory tidak selamat.');
    }
    final guestCwd = safeRelative == '.' || safeRelative.isEmpty
        ? '/workspace'
        : '/workspace/${safeRelative.replaceAll('\\', '/')}';

    final arguments = <String>[
      '--kill-on-exit',
      '-0',
      '-r',
      rootfs.path,
      ...await _safeSystemBinds(),
      '-b',
      '${workspace.path}:/workspace',
      '-b',
      '${home.path}:/root',
      '-b',
      '${tmp.path}:/tmp',
      '-w',
      guestCwd,
      '/usr/bin/env',
      '-i',
      'HOME=/root',
      'USER=root',
      'LOGNAME=root',
      'TERM=xterm-256color',
      'LANG=C.UTF-8',
      'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
      ..._sanitizeEnvironment(environment),
      '/bin/sh',
      '-lc',
      command,
    ];

    return LinuxCommandSpec(
      executable: proot.path,
      arguments: arguments,
      hostWorkingDirectory: workspace.path,
      environment: <String, String>{
        'HOME': home.path,
        'TMPDIR': tmp.path,
        'PROOT_TMP_DIR': tmp.path,
        if (await libs.exists()) 'LD_LIBRARY_PATH': libs.path,
      },
    );
  }

  Future<void> reset() async {
    if (!AppConfig.isFullEdition) return;
    final root = await ensurePrivateRoot();
    if (await root.exists()) await root.delete(recursive: true);
    await ensurePrivateRoot();
  }

  Future<List<String>> _safeSystemBinds() async {
    final arguments = <String>[];
    for (final path in <String>[
      '/proc',
      '/dev/null',
      '/dev/zero',
      '/dev/random',
      '/dev/urandom',
      '/dev/tty',
      '/dev/pts',
    ]) {
      final type = FileSystemEntity.typeSync(path, followLinks: false);
      if (type != FileSystemEntityType.notFound) {
        arguments.addAll(<String>['-b', path]);
      }
    }
    return arguments;
  }

  Iterable<String> _sanitizeEnvironment(Map<String, String> environment) sync* {
    final validName = RegExp(r'^[A-Za-z_][A-Za-z0-9_]*$');
    const blocked = <String>{
      'HOME',
      'USER',
      'LOGNAME',
      'PATH',
      'TMPDIR',
      'PROOT_TMP_DIR',
      'LD_PRELOAD',
      'LD_LIBRARY_PATH',
    };
    for (final entry in environment.entries) {
      if (!validName.hasMatch(entry.key) || blocked.contains(entry.key)) {
        continue;
      }
      yield '${entry.key}=${entry.value.replaceAll('\u0000', '')}';
    }
  }

  void _assertPrivateAppPath(String path) {
    if (!Platform.isAndroid) return;
    final normalized = p.normalize(path);
    final privateAndroidPath = normalized.startsWith('/data/user/') ||
        normalized.startsWith('/data/data/');
    if (!privateAndroidPath) {
      throw FileSystemException(
        'Linux Workspace mesti berada dalam storan internal private aplikasi.',
        normalized,
      );
    }
  }

  void _validateSymlinkTarget(
    String stagingRoot,
    String linkPath,
    String target,
  ) {
    final normalizedTarget = target.replaceAll('\\', '/');
    final lower = normalizedTarget.toLowerCase();
    const blockedAbsoluteRoots = <String>[
      '/sdcard',
      '/storage',
      '/mnt/media_rw',
      '/data/media',
      '/data/user',
      '/data/data',
    ];
    if (blockedAbsoluteRoots.any(
      (root) => lower == root || lower.startsWith('$root/'),
    )) {
      throw const FileSystemException(
        'Runtime pack cuba membuat symlink keluar daripada Linux Workspace.',
      );
    }
    if (!p.isAbsolute(normalizedTarget)) {
      final resolved = p.normalize(p.join(p.dirname(linkPath), normalizedTarget));
      if (resolved != stagingRoot && !p.isWithin(stagingRoot, resolved)) {
        throw const FileSystemException(
          'Symlink runtime pack keluar daripada sandbox.',
        );
      }
    }
  }

  void _queueMode(Map<int, List<String>> groups, int mode, String path) {
    final permissions = mode & 0x1FF;
    if (permissions == 0) return;
    groups.putIfAbsent(permissions, () => <String>[]).add(path);
  }

  Future<void> _applyModes(Map<int, List<String>> groups) async {
    for (final entry in groups.entries) {
      final mode = entry.key.toRadixString(8).padLeft(3, '0');
      for (var index = 0; index < entry.value.length; index += 100) {
        final end = (index + 100).clamp(0, entry.value.length).toInt();
        await _chmod(mode, entry.value.sublist(index, end));
      }
    }
  }

  Future<void> _chmod(String mode, List<String> paths) async {
    final result = await Process.run(
      '/system/bin/chmod',
      <String>[mode, ...paths],
    );
    if (result.exitCode != 0) {
      throw FileSystemException(
        'Gagal menetapkan permission runtime pack: ${result.stderr}',
      );
    }
  }

  Future<int> _directorySize(Directory root) async {
    var total = 0;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // Fail yang berubah ketika dikira akan dikira semula kemudian.
        }
      }
    }
    return total;
  }
}
