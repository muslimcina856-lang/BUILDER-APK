import 'package:flutter/material.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../theme/app_theme.dart';
import 'linux_workspace_screen.dart';
import 'memory_screen.dart';
import 'mcp_servers_screen.dart';
import 'settings_screen.dart';
import 'skills_screen.dart';
import 'tool_logs_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Lain-lain')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 120),
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: <Color>[Color(0xFF21143C), Color(0xFF111A29)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: AppTheme.outline),
              ),
              child: Row(
                children: <Widget>[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset(
                      AppConfig.iconAsset,
                      width: 64,
                      height: 64,
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          AppConfig.appName,
                          style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Local · BYOK · ${AppConfig.editionName} · target ${AppConfig.androidTargetSdk}',
                          style: const TextStyle(color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (AppConfig.isFullEdition) ...<Widget>[
              _MoreTile(
                icon: Icons.desktop_windows_rounded,
                title: 'Linux Workspace',
                subtitle: 'Rootfs private, terminal dan pemasangan pakej bebas',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const LinuxWorkspaceScreen(),
                  ),
                ),
              ),
              _MoreTile(
                icon: Icons.auto_awesome_rounded,
                title: 'Skills',
                subtitle: 'Urus Skill Creator dan kemahiran agent',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const SkillsScreen()),
                ),
              ),
            ] else
              const _EditionNotice(),
            _MoreTile(
              icon: Icons.psychology_alt_rounded,
              title: 'Memori local',
              subtitle: 'Urus fakta dan konteks yang disimpan pada peranti',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const MemoryScreen()),
              ),
            ),
            _MoreTile(
              icon: Icons.hub_rounded,
              title: 'MCP local',
              subtitle: '${state.mcpServers.length} server dikonfigurasi',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const McpServersScreen(),
                ),
              ),
            ),
            _MoreTile(
              icon: Icons.receipt_long_rounded,
              title: 'Aktiviti tools',
              subtitle: 'Log operasi dengan token dan rahsia ditapis',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const ToolLogsScreen()),
              ),
            ),
            _MoreTile(
              icon: Icons.security_rounded,
              title: 'Tetapan & kelulusan',
              subtitle:
                  '${state.permissionRules.length} peraturan risiko disimpan',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
              ),
            ),
            const SizedBox(height: 18),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                'Browser Chromium berjalan di latar belakang dan tidak membuka skrin berasingan. Chat, provider, API key, skills, automasi dan memori disimpan secara local.',
                style: TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12.5,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MoreTile extends StatelessWidget {
  const _MoreTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppTheme.purple.withValues(alpha: .13),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(icon, color: AppTheme.purpleLight),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      ),
    );
  }
}


class _EditionNotice extends StatelessWidget {
  const _EditionNotice();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.outlineSoft),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.verified_user_rounded, color: AppTheme.purpleLight),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Edisi Google Play menggunakan tools aplikasi, browser latar dan sandbox fail local. Linux PRoot dengan apt bebas tersedia dalam Ai MultiAgent Full.',
              style: TextStyle(color: AppTheme.textSecondary, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }
}
