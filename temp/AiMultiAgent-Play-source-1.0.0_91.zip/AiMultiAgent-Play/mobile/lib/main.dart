import 'src/bootstrap.dart';
import 'src/config/app_edition.dart';

Future<void> main() => startAiMultiAgent(AppEdition.play);
