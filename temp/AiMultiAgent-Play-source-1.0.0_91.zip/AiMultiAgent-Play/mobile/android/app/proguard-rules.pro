# Flutter engine dan registrasi plugin.
-keep class io.flutter.** { *; }
-dontwarn io.flutter.embedding.**

# Entry point native dan enjin browser latar belakang.
-keep class com.aiauto.claw.MainActivity { *; }
-keep class com.aiauto.claw.BackgroundBrowserEngine { *; }

# Kekalkan metadata yang digunakan oleh plugin/reflection pada build minified.
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault,Signature,InnerClasses,EnclosingMethod

# Provider TLS pilihan boleh tidak hadir pada sesetengah peranti.
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
