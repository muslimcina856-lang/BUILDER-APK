import com.earlxz.resitku.core.ReceiptItem;
import com.earlxz.resitku.core.ReceiptMath;
import java.util.*;

public class ReceiptMathTest {
    private static void assertEquals(long expected, long actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
    public static void main(String[] args) {
        List<ReceiptItem> items = Arrays.asList(
            new ReceiptItem("Nasi Lemak", 2, 350),
            new ReceiptItem("Teh Ais", 1, 250)
        );
        assertEquals(950, ReceiptMath.subtotalCents(items), "subtotal");
        assertEquals(850, ReceiptMath.totalCents(items, 100), "discount total");
        assertEquals(0, ReceiptMath.totalCents(items, 5000), "total cannot be negative");
        assertEquals(1234, ReceiptMath.parseMoneyToCents("12.34"), "money parsing");
        assertEquals(1200, ReceiptMath.parseMoneyToCents("12"), "whole money parsing");
        System.out.println("ReceiptMathTest PASS");
    }
}
