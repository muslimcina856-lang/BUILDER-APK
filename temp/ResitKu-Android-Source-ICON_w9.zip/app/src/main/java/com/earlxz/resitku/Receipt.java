package com.earlxz.resitku;

import com.earlxz.resitku.core.ReceiptItem;
import com.earlxz.resitku.core.ReceiptMath;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class Receipt {
    public final String id;
    public final long createdAt;
    public final String customer;
    public final String paymentMethod;
    public final long discountCents;
    public final List<ReceiptItem> items;

    public Receipt(String id, long createdAt, String customer, String paymentMethod, long discountCents, List<ReceiptItem> items) {
        this.id = id;
        this.createdAt = createdAt;
        this.customer = customer == null ? "" : customer.trim();
        this.paymentMethod = paymentMethod == null ? "Tunai" : paymentMethod;
        this.discountCents = Math.max(0, discountCents);
        this.items = items == null ? new ArrayList<>() : new ArrayList<>(items);
    }

    public long subtotalCents() { return ReceiptMath.subtotalCents(items); }
    public long totalCents() { return ReceiptMath.totalCents(items, discountCents); }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("createdAt", createdAt);
            o.put("customer", customer);
            o.put("paymentMethod", paymentMethod);
            o.put("discountCents", discountCents);
            JSONArray a = new JSONArray();
            for (ReceiptItem item : items) {
                JSONObject i = new JSONObject();
                i.put("name", item.getName());
                i.put("quantity", item.getQuantity());
                i.put("unitPriceCents", item.getUnitPriceCents());
                a.put(i);
            }
            o.put("items", a);
        } catch (Exception ignored) {}
        return o;
    }

    public static Receipt fromJson(JSONObject o) {
        try {
            ArrayList<ReceiptItem> items = new ArrayList<>();
            JSONArray a = o.optJSONArray("items");
            if (a != null) {
                for (int x = 0; x < a.length(); x++) {
                    JSONObject i = a.optJSONObject(x);
                    if (i != null) {
                        items.add(new ReceiptItem(i.optString("name"), i.optInt("quantity", 1), i.optLong("unitPriceCents", 0)));
                    }
                }
            }
            return new Receipt(
                    o.optString("id"),
                    o.optLong("createdAt", System.currentTimeMillis()),
                    o.optString("customer"),
                    o.optString("paymentMethod", "Tunai"),
                    o.optLong("discountCents", 0),
                    items
            );
        } catch (Exception e) {
            return null;
        }
    }
}
