package com.earlxz.resitku;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(244,247,251);
    public static final int TEXT = Color.rgb(11,19,32);
    public static final int MUTED = Color.rgb(96,112,134);
    public static final int ACCENT = Color.rgb(15,159,152);
    public static final int LINE = Color.rgb(220,228,236);
    private Ui() {}

    public static int dp(Context c, int dp) { return Math.round(dp * c.getResources().getDisplayMetrics().density); }

    public static LinearLayout page(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,20), dp(c,22), dp(c,20), dp(c,36));
        l.setBackgroundColor(BG);
        return l;
    }

    public static TextView title(Context c, String text, int sp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTextSize(sp);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    public static TextView body(Context c, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(14);
        t.setLineSpacing(0,1.15f);
        return t;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,16), dp(c,16), dp(c,16), dp(c,16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(c,18));
        bg.setStroke(dp(c,1), LINE);
        l.setBackground(bg);
        l.setElevation(dp(c,2));
        return l;
    }

    public static Button primary(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c,52));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ACCENT);
        bg.setCornerRadius(dp(c,16));
        b.setBackground(bg);
        return b;
    }

    public static Button secondary(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c,48));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(c,15));
        bg.setStroke(dp(c,1), LINE);
        b.setBackground(bg);
        return b;
    }

    public static EditText field(Context c, String hint, int type) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(145,156,171));
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setPadding(dp(c,14),0,dp(c,14),0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(250,252,254));
        bg.setCornerRadius(dp(c,14));
        bg.setStroke(dp(c,1), LINE);
        e.setBackground(bg);
        e.setMinHeight(dp(c,50));
        return e;
    }

    public static EditText textField(Context c, String hint) { return field(c, hint, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); }

    public static void addSpace(LinearLayout parent, Context c, int dp) {
        View v = new View(c);
        parent.addView(v, new LinearLayout.LayoutParams(1, Ui.dp(c, dp)));
    }

    public static void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(parent.getContext(), top);
        parent.addView(child, p);
    }
}
