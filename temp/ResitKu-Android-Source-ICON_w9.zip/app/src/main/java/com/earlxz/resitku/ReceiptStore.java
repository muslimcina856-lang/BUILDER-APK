package com.earlxz.resitku;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ReceiptStore {
    private static final String PREFS = "resitku";
    private static final String HISTORY = "receipt_history";
    private ReceiptStore() {}

    public static synchronized String nextId(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int seq = p.getInt("receipt_seq", 0) + 1;
        p.edit().putInt("receipt_seq", seq).apply();
        return String.format(Locale.US, "R%06d", seq);
    }

    public static void save(Context context, Receipt receipt) {
        List<Receipt> all = loadAll(context);
        all.removeIf(r -> r.id.equals(receipt.id));
        all.add(0, receipt);
        JSONArray out = new JSONArray();
        for (int i = 0; i < Math.min(all.size(), 200); i++) out.put(all.get(i).toJson());
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(HISTORY, out.toString()).apply();
    }

    public static List<Receipt> loadAll(Context context) {
        ArrayList<Receipt> list = new ArrayList<>();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HISTORY, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) {
                    Receipt r = Receipt.fromJson(o);
                    if (r != null && !r.id.isEmpty()) list.add(r);
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static Receipt find(Context context, String id) {
        for (Receipt receipt : loadAll(context)) if (receipt.id.equals(id)) return receipt;
        return null;
    }

    public static long revenue(Context context) {
        long total = 0;
        for (Receipt r : loadAll(context)) total += r.totalCents();
        return total;
    }
}
