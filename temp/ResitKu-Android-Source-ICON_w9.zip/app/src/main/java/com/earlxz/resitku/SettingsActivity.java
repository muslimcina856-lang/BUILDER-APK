package com.earlxz.resitku;

import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public final class SettingsActivity extends BaseActivity {
    private EditText name, registration, phone, address, footer;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    private void render() {
        StoreProfile p = StoreProfile.load(this);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.page(this);
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button back = Ui.secondary(this, "‹  Kembali");
        back.setOnClickListener(v -> finish());
        page.addView(back, new LinearLayout.LayoutParams(Ui.dp(this,120), Ui.dp(this,44)));
        Ui.add(page, Ui.title(this, "Profil Kedai", 28), 22);
        Ui.add(page, Ui.body(this, "Maklumat ini akan muncul pada setiap resit baharu dan PDF."), 6);

        name = addField(page, "Nama kedai", "Contoh: Kedai Earl", p.name, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        registration = addField(page, "No. pendaftaran / SSM", "Pilihan", p.registration, InputType.TYPE_CLASS_TEXT);
        phone = addField(page, "Telefon", "01X-XXXXXXX", p.phone, InputType.TYPE_CLASS_PHONE);
        address = addField(page, "Alamat", "Alamat kedai (pilihan)", p.address, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        address.setSingleLine(false);
        address.setMinLines(2);
        footer = addField(page, "Nota kaki resit", "Terima kasih atas pembelian anda.", p.footer, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        footer.setSingleLine(false);
        footer.setMinLines(2);

        Button save = Ui.primary(this, "Simpan Profil Kedai");
        save.setOnClickListener(v -> save());
        Ui.add(page, save, 26);
        setPageContent(scroll);
    }

    private EditText addField(LinearLayout page, String label, String hint, String value, int inputType) {
        Ui.add(page, Ui.title(this, label, 15), 20);
        EditText e = Ui.field(this, hint, inputType);
        e.setText(value);
        Ui.add(page, e, 8);
        return e;
    }

    private void save() {
        String storeName = name.getText().toString().trim();
        if (storeName.isEmpty()) {
            name.setError("Nama kedai diperlukan");
            return;
        }
        new StoreProfile(storeName, registration.getText().toString(), phone.getText().toString(), address.getText().toString(), footer.getText().toString()).save(this);
        Toast.makeText(this, "Profil kedai disimpan.", Toast.LENGTH_SHORT).show();
        finish();
    }
}
