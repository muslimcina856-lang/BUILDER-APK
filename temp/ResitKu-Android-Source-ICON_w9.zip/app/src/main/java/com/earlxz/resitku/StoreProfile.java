package com.earlxz.resitku;

import android.content.Context;
import android.content.SharedPreferences;

public final class StoreProfile {
    public String name;
    public String registration;
    public String phone;
    public String address;
    public String footer;

    public StoreProfile(String name, String registration, String phone, String address, String footer) {
        this.name = name;
        this.registration = registration;
        this.phone = phone;
        this.address = address;
        this.footer = footer;
    }

    public static StoreProfile load(Context context) {
        SharedPreferences p = context.getSharedPreferences("resitku", Context.MODE_PRIVATE);
        return new StoreProfile(
                p.getString("store_name", "Kedai Saya"),
                p.getString("store_registration", ""),
                p.getString("store_phone", ""),
                p.getString("store_address", ""),
                p.getString("store_footer", "Terima kasih atas pembelian anda.")
        );
    }

    public void save(Context context) {
        context.getSharedPreferences("resitku", Context.MODE_PRIVATE).edit()
                .putString("store_name", clean(name, "Kedai Saya"))
                .putString("store_registration", clean(registration, ""))
                .putString("store_phone", clean(phone, ""))
                .putString("store_address", clean(address, ""))
                .putString("store_footer", clean(footer, "Terima kasih atas pembelian anda."))
                .apply();
    }

    private static String clean(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        return value.trim();
    }
}
