package com.earlxz.resitku;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import com.earlxz.resitku.core.ReceiptItem;
import com.earlxz.resitku.core.ReceiptMath;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class PdfExporter {
    private PdfExporter() {}

    public static File export(Context context, Receipt receipt, StoreProfile store) throws Exception {
        File dir = new File(context.getCacheDir(), "shared_receipts");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Tidak dapat cipta folder PDF");
        File file = new File(dir, "ResitKu-" + receipt.id + ".pdf");

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = document.startPage(info);
        Canvas c = page.getCanvas();
        c.drawColor(Color.WHITE);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(11,19,32));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(24);
        float y = 60;
        c.drawText(store.name, 48, y, paint);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(11);
        paint.setColor(Color.rgb(96,112,134));
        y += 22;
        if (!store.registration.isEmpty()) { c.drawText("SSM: " + store.registration, 48, y, paint); y += 16; }
        if (!store.phone.isEmpty()) { c.drawText(store.phone, 48, y, paint); y += 16; }
        if (!store.address.isEmpty()) { y = drawWrapped(c, paint, store.address, 48, y, 500, 14); }

        paint.setColor(Color.rgb(15,159,152));
        paint.setStrokeWidth(2);
        y += 12;
        c.drawLine(48, y, 547, y, paint);
        y += 30;

        paint.setColor(Color.rgb(11,19,32));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(18);
        c.drawText("RESIT", 48, y, paint);
        paint.setTextSize(11);
        paint.setTypeface(Typeface.DEFAULT);
        c.drawText(receipt.id, 420, y, paint);
        y += 20;
        String date = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(receipt.createdAt));
        c.drawText(date, 48, y, paint);
        if (!receipt.customer.isEmpty()) { y += 17; c.drawText("Pelanggan: " + receipt.customer, 48, y, paint); }
        y += 30;

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        c.drawText("Item", 48, y, paint);
        c.drawText("Qty", 330, y, paint);
        c.drawText("Harga", 390, y, paint);
        c.drawText("Jumlah", 485, y, paint);
        paint.setTypeface(Typeface.DEFAULT);
        y += 12;
        paint.setColor(Color.rgb(220,228,236));
        c.drawLine(48, y, 547, y, paint);
        y += 22;
        paint.setColor(Color.rgb(11,19,32));

        for (ReceiptItem item : receipt.items) {
            if (y > 690) break;
            c.drawText(trim(item.getName(), 32), 48, y, paint);
            c.drawText(String.valueOf(item.getQuantity()), 338, y, paint);
            c.drawText(ReceiptMath.formatRm(item.getUnitPriceCents()).replace("RM ", ""), 390, y, paint);
            c.drawText(ReceiptMath.formatRm(item.getLineTotalCents()).replace("RM ", ""), 485, y, paint);
            y += 22;
        }

        y += 6;
        paint.setColor(Color.rgb(220,228,236));
        c.drawLine(300, y, 547, y, paint);
        y += 24;
        paint.setColor(Color.rgb(96,112,134));
        c.drawText("Subtotal", 350, y, paint);
        c.drawText(ReceiptMath.formatRm(receipt.subtotalCents()), 460, y, paint);
        if (receipt.discountCents > 0) {
            y += 20;
            c.drawText("Diskaun", 350, y, paint);
            c.drawText("- " + ReceiptMath.formatRm(receipt.discountCents), 460, y, paint);
        }
        y += 28;
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Color.rgb(11,19,32));
        paint.setTextSize(16);
        c.drawText("JUMLAH", 350, y, paint);
        c.drawText(ReceiptMath.formatRm(receipt.totalCents()), 455, y, paint);
        y += 34;
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(11);
        paint.setColor(Color.rgb(96,112,134));
        c.drawText("Bayaran: " + receipt.paymentMethod, 48, y, paint);
        y += 34;
        paint.setColor(Color.rgb(15,159,152));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        c.drawText(store.footer, 48, y, paint);

        document.finishPage(page);
        try (FileOutputStream out = new FileOutputStream(file)) { document.writeTo(out); }
        document.close();
        return file;
    }

    public static Uri shareUri(Context context, File file) {
        return new Uri.Builder()
                .scheme("content")
                .authority(context.getPackageName() + ".fileprovider")
                .appendPath("shared_receipts")
                .appendPath(file.getName())
                .build();
    }

    private static String trim(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max - 1) + "…";
    }

    private static float drawWrapped(Canvas c, Paint paint, String text, float x, float y, float width, float lineHeight) {
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(candidate) > width && line.length() > 0) {
                c.drawText(line.toString(), x, y, paint);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (line.length() > 0) { c.drawText(line.toString(), x, y, paint); y += lineHeight; }
        return y;
    }
}
