package com.earlxz.resitku;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

public abstract class BaseActivity extends Activity {
    protected void setPageContent(View root) {
        final int left = root.getPaddingLeft();
        final int top = root.getPaddingTop();
        final int right = root.getPaddingRight();
        final int bottom = root.getPaddingBottom();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(left, top + topInset, right, bottom + bottomInset);
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
    }
}
