package com.earlxz.resitku;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.earlxz.resitku.core.ReceiptItem;
import com.earlxz.resitku.core.ReceiptMath;
import java.util.ArrayList;
import java.util.List;

public final class CreateReceiptActivity extends BaseActivity {
    private final List<ItemRow> itemRows = new ArrayList<>();
    private LinearLayout itemsContainer;
    private EditText customerField;
    private EditText discountField;
    private Spinner paymentSpinner;
    private TextView subtotalValue;
    private TextView totalValue;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = Ui.page(this);
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button back = Ui.secondary(this, "‹  Kembali");
        back.setOnClickListener(v -> finish());
        page.addView(back, new LinearLayout.LayoutParams(Ui.dp(this,120), Ui.dp(this,44)));

        Ui.add(page, Ui.title(this, "Resit Baru", 28), 24);
        Ui.add(page, Ui.body(this, "Masukkan pelanggan jika perlu, kemudian tambah item jualan."), 6);

        TextView customerLabel = Ui.title(this, "Pelanggan", 15);
        Ui.add(page, customerLabel, 24);
        customerField = Ui.textField(this, "Nama pelanggan (pilihan)");
        Ui.add(page, customerField, 8);

        LinearLayout itemsHeader = new LinearLayout(this);
        itemsHeader.setOrientation(LinearLayout.HORIZONTAL);
        itemsHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView itemsTitle = Ui.title(this, "Item", 18);
        itemsHeader.addView(itemsTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button add = Ui.secondary(this, "+ Tambah");
        add.setOnClickListener(v -> addItemRow());
        itemsHeader.addView(add, new LinearLayout.LayoutParams(Ui.dp(this,110), Ui.dp(this,44)));
        Ui.add(page, itemsHeader, 26);

        itemsContainer = new LinearLayout(this);
        itemsContainer.setOrientation(LinearLayout.VERTICAL);
        Ui.add(page, itemsContainer, 4);
        addItemRow();

        TextView discountLabel = Ui.title(this, "Diskaun", 15);
        Ui.add(page, discountLabel, 22);
        discountField = Ui.field(this, "0.00", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        discountField.addTextChangedListener(watcher(this::recalculate));
        Ui.add(page, discountField, 8);

        TextView payLabel = Ui.title(this, "Kaedah bayaran", 15);
        Ui.add(page, payLabel, 20);
        paymentSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Tunai", "DuitNow QR", "Bank Transfer", "Kad", "Lain-lain"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        paymentSpinner.setAdapter(adapter);
        android.graphics.drawable.GradientDrawable spinnerBg = new android.graphics.drawable.GradientDrawable();
        spinnerBg.setColor(Color.WHITE);
        spinnerBg.setCornerRadius(Ui.dp(this,14));
        spinnerBg.setStroke(Ui.dp(this,1), Ui.LINE);
        paymentSpinner.setBackground(spinnerBg);
        paymentSpinner.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        Ui.add(page, paymentSpinner, 8);
        paymentSpinner.getLayoutParams().height = Ui.dp(this,52);

        LinearLayout summary = Ui.card(this);
        subtotalValue = summaryRow(summary, "Subtotal", "RM 0.00", false);
        totalValue = summaryRow(summary, "Jumlah", "RM 0.00", true);
        Ui.add(page, summary, 24);

        Button generate = Ui.primary(this, "Jana & Simpan Resit");
        generate.setOnClickListener(v -> generateReceipt());
        Ui.add(page, generate, 18);

        setPageContent(scroll);
    }

    private TextView summaryRow(LinearLayout parent, String label, String value, boolean strong) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = strong ? Ui.title(this, label, 17) : Ui.body(this, label);
        TextView v = strong ? Ui.title(this, value, 20) : Ui.title(this, value, 15);
        if (strong) v.setTextColor(Ui.ACCENT);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v);
        if (parent.getChildCount() > 0) Ui.add(parent, row, 14); else parent.addView(row);
        return v;
    }

    private void addItemRow() {
        LinearLayout card = Ui.card(this);
        EditText name = Ui.textField(this, "Nama item / servis");
        card.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this,50)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        EditText qty = Ui.field(this, "Qty", InputType.TYPE_CLASS_NUMBER);
        qty.setText("1");
        EditText price = Ui.field(this, "Harga RM", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(0, Ui.dp(this,50), 0.32f);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, Ui.dp(this,50), 0.68f);
        pp.leftMargin = Ui.dp(this,8);
        row.addView(qty, qp);
        row.addView(price, pp);
        Ui.add(card, row, 10);

        Button remove = Ui.secondary(this, "Buang item");
        remove.setTextColor(Color.rgb(196,58,67));
        Ui.add(card, remove, 10);

        ItemRow model = new ItemRow(card, name, qty, price);
        itemRows.add(model);
        remove.setOnClickListener(v -> {
            if (itemRows.size() == 1) {
                name.setText(""); qty.setText("1"); price.setText("");
            } else {
                itemRows.remove(model);
                itemsContainer.removeView(card);
            }
            recalculate();
        });
        name.addTextChangedListener(watcher(this::recalculate));
        qty.addTextChangedListener(watcher(this::recalculate));
        price.addTextChangedListener(watcher(this::recalculate));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = Ui.dp(this, itemRows.size() == 1 ? 8 : 12);
        itemsContainer.addView(card, cp);
    }

    private List<ReceiptItem> collectItems() {
        ArrayList<ReceiptItem> result = new ArrayList<>();
        for (ItemRow row : itemRows) {
            String name = row.name.getText().toString().trim();
            int qty = 1;
            try { qty = Math.max(1, Integer.parseInt(row.qty.getText().toString().trim())); } catch (Exception ignored) {}
            long price = ReceiptMath.parseMoneyToCents(row.price.getText().toString());
            if (!name.isEmpty() && price > 0) result.add(new ReceiptItem(name, qty, price));
        }
        return result;
    }

    private void recalculate() {
        if (subtotalValue == null || totalValue == null) return;
        List<ReceiptItem> items = collectItems();
        long discount = ReceiptMath.parseMoneyToCents(discountField == null ? "" : discountField.getText().toString());
        subtotalValue.setText(ReceiptMath.formatRm(ReceiptMath.subtotalCents(items)));
        totalValue.setText(ReceiptMath.formatRm(ReceiptMath.totalCents(items, discount)));
    }

    private void generateReceipt() {
        List<ReceiptItem> items = collectItems();
        if (items.isEmpty()) {
            Toast.makeText(this, "Tambah sekurang-kurangnya satu item dengan harga.", Toast.LENGTH_LONG).show();
            return;
        }
        long discount = ReceiptMath.parseMoneyToCents(discountField.getText().toString());
        Receipt receipt = new Receipt(
                ReceiptStore.nextId(this),
                System.currentTimeMillis(),
                customerField.getText().toString(),
                String.valueOf(paymentSpinner.getSelectedItem()),
                discount,
                items
        );
        ReceiptStore.save(this, receipt);
        android.content.Intent i = new android.content.Intent(this, ReceiptPreviewActivity.class);
        i.putExtra("receipt_id", receipt.id);
        startActivity(i);
        finish();
    }

    private static TextWatcher watcher(Runnable runnable) {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { runnable.run(); }
        };
    }

    private static final class ItemRow {
        final View card;
        final EditText name;
        final EditText qty;
        final EditText price;
        ItemRow(View card, EditText name, EditText qty, EditText price) {
            this.card = card; this.name = name; this.qty = qty; this.price = price;
        }
    }
}
