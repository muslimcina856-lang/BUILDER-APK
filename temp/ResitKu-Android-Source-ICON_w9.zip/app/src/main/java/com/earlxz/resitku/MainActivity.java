package com.earlxz.resitku;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.earlxz.resitku.core.ReceiptMath;

public final class MainActivity extends BaseActivity {
    private boolean firstResume = true;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (firstResume) firstResume = false;
        else render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = Ui.page(this);
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = Ui.title(this, "R", 19);
        mark.setTextColor(Color.WHITE);
        mark.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable markBg = new android.graphics.drawable.GradientDrawable();
        markBg.setColor(Ui.ACCENT);
        markBg.setCornerRadius(Ui.dp(this, 14));
        mark.setBackground(markBg);
        brand.addView(mark, new LinearLayout.LayoutParams(Ui.dp(this,44), Ui.dp(this,44)));
        TextView brandName = Ui.title(this, "ResitKu", 22);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.leftMargin = Ui.dp(this,12);
        brand.addView(brandName, bp);
        page.addView(brand);

        Ui.add(page, Ui.title(this, "Urus resit tanpa pening.", 29), 30);
        Ui.add(page, Ui.body(this, "Jana resit profesional, simpan rekod jualan dan kongsi PDF terus kepada pelanggan."), 8);

        LinearLayout stats = Ui.card(this);
        TextView statLabel = Ui.body(this, "JUMLAH JUALAN TEREKOD");
        statLabel.setTextSize(12);
        stats.addView(statLabel);
        TextView total = Ui.title(this, ReceiptMath.formatRm(ReceiptStore.revenue(this)), 28);
        Ui.add(stats, total, 8);
        TextView count = Ui.body(this, ReceiptStore.loadAll(this).size() + " resit disimpan pada peranti ini");
        Ui.add(stats, count, 6);
        Ui.add(page, stats, 24);

        Button newReceipt = Ui.primary(this, "+  Resit Baru");
        newReceipt.setOnClickListener(v -> startActivity(new Intent(this, CreateReceiptActivity.class)));
        Ui.add(page, newReceipt, 20);

        TextView quick = Ui.title(this, "Pengurusan", 18);
        Ui.add(page, quick, 28);

        LinearLayout historyCard = actionCard("Sejarah resit", "Buka semula dan kongsi resit terdahulu", "›");
        historyCard.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        Ui.add(page, historyCard, 12);

        LinearLayout settingsCard = actionCard("Profil kedai", "Nama kedai, SSM, telefon, alamat & nota kaki", "›");
        settingsCard.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        Ui.add(page, settingsCard, 12);

        TextView privacy = Ui.body(this, "Offline dahulu • Data resit disimpan dalam telefon • Tiada akaun diperlukan");
        privacy.setGravity(Gravity.CENTER);
        Ui.add(page, privacy, 30);

        setPageContent(scroll);
    }

    private LinearLayout actionCard(String title, String subtitle, String arrow) {
        LinearLayout card = Ui.card(this);
        card.setClickable(true);
        card.setFocusable(true);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.title(this, title, 16);
        TextView s = Ui.body(this, subtitle);
        texts.addView(t);
        Ui.add(texts, s, 4);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView a = Ui.title(this, arrow, 26);
        a.setTextColor(Ui.ACCENT);
        row.addView(a);
        card.addView(row);
        return card;
    }
}
