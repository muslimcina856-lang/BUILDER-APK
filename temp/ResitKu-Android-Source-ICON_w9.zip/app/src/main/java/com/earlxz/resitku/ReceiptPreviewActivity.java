package com.earlxz.resitku;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.earlxz.resitku.core.ReceiptItem;
import com.earlxz.resitku.core.ReceiptMath;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ReceiptPreviewActivity extends BaseActivity {
    private Receipt receipt;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        receipt = ReceiptStore.find(this, getIntent().getStringExtra("receipt_id"));
        if (receipt == null) {
            Toast.makeText(this, "Resit tidak ditemui.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        render();
    }

    private void render() {
        StoreProfile store = StoreProfile.load(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = Ui.page(this);
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button back = Ui.secondary(this, "‹  Kembali");
        back.setOnClickListener(v -> finish());
        page.addView(back, new LinearLayout.LayoutParams(Ui.dp(this,120), Ui.dp(this,44)));
        Ui.add(page, Ui.title(this, "Resit siap", 28), 22);
        Ui.add(page, Ui.body(this, "Semak dahulu. Resit ini sudah disimpan dalam sejarah."), 6);

        LinearLayout paper = Ui.card(this);
        paper.setPadding(Ui.dp(this,22), Ui.dp(this,24), Ui.dp(this,22), Ui.dp(this,24));
        TextView storeName = Ui.title(this, store.name, 22);
        storeName.setGravity(Gravity.CENTER);
        paper.addView(storeName);
        if (!store.registration.isEmpty()) centered(paper, "SSM: " + store.registration, 5);
        if (!store.phone.isEmpty()) centered(paper, store.phone, 3);
        if (!store.address.isEmpty()) centered(paper, store.address, 3);

        TextView receiptTitle = Ui.title(this, "RESIT", 16);
        receiptTitle.setTextColor(Ui.ACCENT);
        receiptTitle.setGravity(Gravity.CENTER);
        Ui.add(paper, receiptTitle, 24);
        centered(paper, receipt.id + "  •  " + new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(receipt.createdAt)), 6);
        if (!receipt.customer.isEmpty()) centered(paper, "Pelanggan: " + receipt.customer, 4);

        android.view.View divider = new android.view.View(this);
        divider.setBackgroundColor(Ui.LINE);
        Ui.add(paper, divider, 20);
        divider.getLayoutParams().height = Ui.dp(this,1);

        for (ReceiptItem item : receipt.items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.TOP);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            TextView name = Ui.title(this, item.getName(), 14);
            TextView detail = Ui.body(this, item.getQuantity() + " × " + ReceiptMath.formatRm(item.getUnitPriceCents()));
            left.addView(name);
            Ui.add(left, detail, 3);
            row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView amount = Ui.title(this, ReceiptMath.formatRm(item.getLineTotalCents()), 14);
            row.addView(amount);
            Ui.add(paper, row, 16);
        }

        android.view.View divider2 = new android.view.View(this);
        divider2.setBackgroundColor(Ui.LINE);
        Ui.add(paper, divider2, 18);
        divider2.getLayoutParams().height = Ui.dp(this,1);

        addTotalRow(paper, "Subtotal", ReceiptMath.formatRm(receipt.subtotalCents()), false);
        if (receipt.discountCents > 0) addTotalRow(paper, "Diskaun", "- " + ReceiptMath.formatRm(receipt.discountCents), false);
        addTotalRow(paper, "JUMLAH", ReceiptMath.formatRm(receipt.totalCents()), true);

        TextView pay = Ui.body(this, "Bayaran: " + receipt.paymentMethod);
        pay.setGravity(Gravity.CENTER);
        Ui.add(paper, pay, 24);
        TextView footer = Ui.title(this, store.footer, 13);
        footer.setTextColor(Ui.ACCENT);
        footer.setGravity(Gravity.CENTER);
        Ui.add(paper, footer, 10);

        Ui.add(page, paper, 22);

        Button share = Ui.primary(this, "Kongsi PDF");
        share.setOnClickListener(v -> sharePdf());
        Ui.add(page, share, 18);

        Button another = Ui.secondary(this, "+ Buat resit baru");
        another.setOnClickListener(v -> {
            startActivity(new Intent(this, CreateReceiptActivity.class));
            finish();
        });
        Ui.add(page, another, 10);

        setPageContent(scroll);
    }

    private void centered(LinearLayout parent, String text, int top) {
        TextView t = Ui.body(this, text);
        t.setGravity(Gravity.CENTER);
        Ui.add(parent, t, top);
    }

    private void addTotalRow(LinearLayout parent, String label, String value, boolean strong) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = strong ? Ui.title(this, label, 17) : Ui.body(this, label);
        TextView v = strong ? Ui.title(this, value, 20) : Ui.title(this, value, 14);
        if (strong) v.setTextColor(Ui.ACCENT);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v);
        Ui.add(parent, row, strong ? 16 : 12);
    }

    private void sharePdf() {
        try {
            File file = PdfExporter.export(this, receipt, StoreProfile.load(this));
            Uri uri = PdfExporter.shareUri(this, file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, "Resit " + receipt.id + " • " + ReceiptMath.formatRm(receipt.totalCents()));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setClipData(ClipData.newRawUri("ResitKu", uri));
            startActivity(Intent.createChooser(share, "Kongsi resit"));
        } catch (Exception e) {
            Toast.makeText(this, "PDF gagal dijana: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
