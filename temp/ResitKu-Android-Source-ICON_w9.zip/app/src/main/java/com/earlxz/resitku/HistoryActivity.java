package com.earlxz.resitku;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.earlxz.resitku.core.ReceiptMath;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class HistoryActivity extends BaseActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.page(this);
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button back = Ui.secondary(this, "‹  Kembali");
        back.setOnClickListener(v -> finish());
        page.addView(back, new LinearLayout.LayoutParams(Ui.dp(this,120), Ui.dp(this,44)));
        Ui.add(page, Ui.title(this, "Sejarah Resit", 28), 22);

        List<Receipt> receipts = ReceiptStore.loadAll(this);
        Ui.add(page, Ui.body(this, receipts.size() + " resit tersimpan pada peranti ini."), 6);
        if (receipts.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            TextView e = Ui.body(this, "Belum ada resit. Buat resit pertama dari halaman utama.");
            e.setGravity(Gravity.CENTER);
            empty.addView(e);
            Ui.add(page, empty, 24);
        } else {
            for (Receipt receipt : receipts) Ui.add(page, receiptCard(receipt), 12);
        }
        setPageContent(scroll);
    }

    private LinearLayout receiptCard(Receipt receipt) {
        LinearLayout card = Ui.card(this);
        card.setClickable(true);
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(Ui.title(this, receipt.id, 16));
        String meta = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(receipt.createdAt));
        if (!receipt.customer.isEmpty()) meta += " • " + receipt.customer;
        Ui.add(left, Ui.body(this, meta), 4);
        top.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView amount = Ui.title(this, ReceiptMath.formatRm(receipt.totalCents()), 16);
        amount.setTextColor(Ui.ACCENT);
        top.addView(amount);
        card.addView(top);
        card.setOnClickListener(v -> {
            Intent i = new Intent(this, ReceiptPreviewActivity.class);
            i.putExtra("receipt_id", receipt.id);
            startActivity(i);
        });
        return card;
    }
}
