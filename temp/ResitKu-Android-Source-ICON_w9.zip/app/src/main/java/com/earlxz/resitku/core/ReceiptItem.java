package com.earlxz.resitku.core;

public final class ReceiptItem {
    private final String name;
    private final int quantity;
    private final long unitPriceCents;

    public ReceiptItem(String name, int quantity, long unitPriceCents) {
        this.name = name == null ? "" : name.trim();
        this.quantity = Math.max(1, quantity);
        this.unitPriceCents = Math.max(0, unitPriceCents);
    }

    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public long getUnitPriceCents() { return unitPriceCents; }
    public long getLineTotalCents() { return unitPriceCents * quantity; }
}
