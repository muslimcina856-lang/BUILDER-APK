package com.earlxz.resitku.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public final class ReceiptMath {
    private ReceiptMath() {}

    public static long subtotalCents(List<ReceiptItem> items) {
        long total = 0;
        if (items == null) return 0;
        for (ReceiptItem item : items) {
            if (item != null) total += item.getLineTotalCents();
        }
        return Math.max(0, total);
    }

    public static long totalCents(List<ReceiptItem> items, long discountCents) {
        return Math.max(0, subtotalCents(items) - Math.max(0, discountCents));
    }

    public static long parseMoneyToCents(String input) {
        if (input == null || input.trim().isEmpty()) return 0;
        try {
            String normalized = input.trim().replace(",", "");
            return new BigDecimal(normalized)
                    .multiply(new BigDecimal("100"))
                    .setScale(0, RoundingMode.HALF_UP)
                    .longValueExact();
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static String formatRm(long cents) {
        long safe = Math.max(0, cents);
        return String.format(java.util.Locale.US, "RM %d.%02d", safe / 100, safe % 100);
    }
}
