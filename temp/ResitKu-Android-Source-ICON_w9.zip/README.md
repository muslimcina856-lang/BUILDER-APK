# ResitKu

Aplikasi Android Native untuk peniaga kecil Malaysia menjana dan menyimpan resit dengan cepat.

## Spesifikasi
- Package: `com.earlxz.resitku`
- Java: 17
- Min SDK: 24
- Compile / Target SDK: 36
- Version code: 1
- Version name: 1.0
- Framework UI: Android SDK biasa, tanpa library UI pihak ketiga
- Data: SharedPreferences + JSON, offline

## Fungsi MVP
- Dashboard jumlah jualan dan bilangan resit
- Jana resit dengan banyak item
- Kuantiti, harga, diskaun dan jumlah automatik
- Kaedah bayaran: Tunai, DuitNow QR, Bank Transfer, Kad, Lain-lain
- Nama pelanggan pilihan
- Profil kedai: nama, SSM, telefon, alamat, nota kaki
- Sejarah sehingga 200 resit terkini
- Pratonton resit
- Jana PDF dan kongsi melalui Android Share Sheet
- ContentProvider dalaman baca-sahaja untuk perkongsian PDF
- Tiada login, Firebase atau server

## Buka dan bina
1. Buka folder `ResitKu` dalam Android Studio.
2. Gunakan JDK 17.
3. Pastikan Android SDK Platform 36 dipasang.
4. Sync Gradle.
5. Jalankan `app` pada emulator/peranti atau bina APK melalui Build > Build APK(s).

Project menggunakan Android Gradle Plugin 8.13.2 yang menyokong API 36 dan Gradle 8.13.

## Had MVP
- Belum ada cloud backup / multi-device sync.
- Belum ada sambungan printer thermal Bluetooth.
- Belum ada invoice, quotation, DO atau integrasi MyInvois.
- PDF satu halaman sesuai untuk resit biasa; item yang terlalu banyak perlu pagination dalam versi seterusnya.
