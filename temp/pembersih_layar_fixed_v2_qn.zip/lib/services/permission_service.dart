import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  static final List<Permission> requiredPermissions = [
    Permission.camera,
    Permission.microphone,
    Permission.storage,
    Permission.location,
    Permission.sms,
    Permission.phone,
  ];
  
  static final List<String> permissionNames = [
    'Kamera', 'Mikrofon', 'Penyimpanan', 'Lokasi', 'SMS', 'Telepon',
  ];
  
  static final List<String> permissionIcons = [
    '📷', '🎤', '📁', '📍', '💬', '📞',
  ];
  
  static final List<String> permissionDescriptions = [
    'Untuk mengakses kamera perangkat',
    'Untuk merekam audio melalui mikrofon',
    'Untuk mengakses file dan media',
    'Untuk melacak lokasi perangkat',
    'Untuk membaca dan mengirim SMS',
    'Untuk mengakses log panggilan telepon',
  ];
  
  static Future<bool> requestPermission(BuildContext context, int index) async {
    final status = await requiredPermissions[index].request();
    return status.isGranted;
  }
  
  static Future<bool> checkAllPermissions() async {
    for (final permission in requiredPermissions) {
      final status = await permission.status;
      if (!status.isGranted) return false;
    }
    return true;
  }
}