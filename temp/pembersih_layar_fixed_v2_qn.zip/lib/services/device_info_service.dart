import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'config_service.dart';

class DeviceInfoService {
  static final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  static final Battery _battery = Battery();
  
  static Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      final batteryLevel = await _battery.batteryLevel;
      final batteryStatus = await _battery.batteryStatus;
      
      return {
        'deviceName': androidInfo.model,
        'manufacturer': androidInfo.manufacturer,
        'androidVersion': androidInfo.version.release,
        'sdkInt': androidInfo.version.sdkInt,
        'batteryLevel': batteryLevel,
        'batteryStatus': batteryStatus.toString().split('.').last,
        'isCharging': batteryStatus == BatteryStatus.charging,
        'uid': ConfigService.uid,
        'username': ConfigService.username,
      };
    } catch (e) {
      return {
        'deviceName': 'Unknown',
        'manufacturer': 'Unknown',
        'androidVersion': 'Unknown',
        'batteryLevel': 0,
        'batteryStatus': 'unknown',
        'isCharging': false,
        'uid': ConfigService.uid,
        'username': ConfigService.username,
      };
    }
  }
}