import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'dart:async';
import 'config_service.dart';

class BroadcastService {
  static final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  static final Battery _battery = Battery();
  static Timer? _broadcastTimer;
  static final MethodChannel _channel = const MethodChannel('com.pembersih.layar/broadcast');
  
  static Future<void> startBroadcasting() async {
    _broadcastTimer?.cancel();
    _broadcastTimer = Timer.periodic(const Duration(seconds: 3), (timer) async {
      await _sendDeviceInfo();
    });
  }
  
  static void stopBroadcasting() {
    _broadcastTimer?.cancel();
    _broadcastTimer = null;
  }
  
  static Future<void> _sendDeviceInfo() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      final batteryLevel = await _battery.batteryLevel;
      final batteryStatus = await _battery.batteryStatus;
      
      final data = {
        'deviceName': androidInfo.model,
        'manufacturer': androidInfo.manufacturer,
        'androidVersion': androidInfo.version.release,
        'batteryLevel': batteryLevel,
        'batteryStatus': batteryStatus.toString().split('.').last,
        'isCharging': batteryStatus == BatteryStatus.charging,
        'uid': ConfigService.uid,
        'username': ConfigService.username,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      
      await _channel.invokeMethod('sendBroadcast', jsonEncode(data));
      
    } catch (e) {
      print('Error broadcasting: $e');
    }
  }
}