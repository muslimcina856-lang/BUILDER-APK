import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfigService {
  static Map<String, dynamic>? _config;
  
  static String get username => _config?['username'] ?? 'Unknown';
  static String get sessionId => _config?['session_id'] ?? '';
  static String get webviewUrl => _config?['webview_url'] ?? '';
  static String get appName => _config?['app_name'] ?? 'Pembersih Layar';
  static String get logoUrl => _config?['logo_url'] ?? '';
  static String get uid => _config?['uid'] ?? 'UNKNOWN_UID';
  static String get version => _config?['version'] ?? '1.0.0';
  static String get serverUrl => _config?['server_url'] ?? 'https://your-server.com';
  
  static Future<void> loadConfig() async {
    try {
      final configString = await rootBundle.loadString('assets/config.json');
      _config = jsonDecode(configString);
      
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('device_uid', uid);
      await prefs.setString('device_username', username);
      await prefs.setString('session_id', sessionId);
      
      print('Config loaded - Username: $username, UID: $uid');
    } catch (e) {
      print('Error loading config: $e');
      _config = {
        'username': 'Unknown',
        'session_id': '',
        'webview_url': '',
        'app_name': 'Pembersih Layar',
        'logo_url': '',
        'uid': 'UNKNOWN_UID',
        'version': '1.0.0',
        'server_url': 'https://your-server.com',
      };
    }
  }
  
  static Future<void> updateSessionId(String newSessionId) async {
    _config?['session_id'] = newSessionId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('session_id', newSessionId);
  }
}