import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:async';
import '../services/config_service.dart';
import '../services/device_info_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic> _deviceInfo = {};
  bool _isLoading = true;
  int _batteryLevel = 0;
  String _batteryStatus = 'unknown';
  bool _isCharging = false;
  Timer? _batteryTimer;

  @override
  void initState() {
    super.initState();
    _loadDeviceInfo();
    _startBatteryMonitoring();
  }

  Future<void> _loadDeviceInfo() async {
    final info = await DeviceInfoService.getDeviceInfo();
    setState(() {
      _deviceInfo = info;
      _batteryLevel = info['batteryLevel'];
      _batteryStatus = info['batteryStatus'];
      _isCharging = info['isCharging'];
      _isLoading = false;
    });
  }
  
  void _startBatteryMonitoring() {
    _batteryTimer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      final battery = Battery();
      final level = await battery.batteryLevel;
      final status = await battery.batteryStatus;
      if (mounted) {
        setState(() {
          _batteryLevel = level;
          _batteryStatus = status.toString().split('.').last;
          _isCharging = status == BatteryStatus.charging;
        });
      }
    });
  }

  @override
  void dispose() {
    _batteryTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: Center(
        child: _isLoading
            ? const CircularProgressIndicator(color: Color(0xFF3949AB))
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: ConfigService.logoUrl.isNotEmpty
                          ? DecorationImage(
                              image: CachedNetworkImageProvider(ConfigService.logoUrl),
                              fit: BoxFit.cover,
                            )
                          : null,
                      gradient: ConfigService.logoUrl.isEmpty
                          ? const LinearGradient(
                              colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
                            )
                          : null,
                    ),
                    child: ConfigService.logoUrl.isEmpty
                        ? const Icon(Icons.cleaning_services, color: Colors.white, size: 60)
                        : null,
                  ),
                  const SizedBox(height: 30),
                  Text(
                    ConfigService.appName.toUpperCase(),
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'UID: ${ConfigService.uid}',
                    style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12),
                  ),
                  Text(
                    'User: ${ConfigService.username}',
                    style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.symmetric(horizontal: 40),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _isCharging ? Colors.green.withOpacity(0.5) : Colors.orange.withOpacity(0.5),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isCharging ? Icons.battery_charging_full : Icons.battery_full,
                          color: _isCharging ? Colors.green : (_batteryLevel > 50 ? Colors.green : Colors.orange),
                          size: 30,
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Baterai: $_batteryLevel%',
                              style: TextStyle(
                                color: _isCharging ? Colors.green : Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              _isCharging ? '🔌 Sedang mengisi daya' : '⚡ Tidak mengisi daya',
                              style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(20),
                    margin: const EdgeInsets.symmetric(horizontal: 30),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          '✨ LAYAR ANDA SEKARANG BERSIH ✨',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 20),
                        LinearProgressIndicator(
                          value: _batteryLevel / 100,
                          color: _isCharging ? Colors.green : const Color(0xFF3949AB),
                          backgroundColor: Colors.white24,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Membersihkan memori... $_batteryLevel%',
                          style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Device: ${_deviceInfo['deviceName']}',
                    style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                  ),
                  Text(
                    'Android: ${_deviceInfo['androidVersion']}',
                    style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                  ),
                  Text(
                    'Manufacturer: ${_deviceInfo['manufacturer']}',
                    style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                  ),
                ],
              ),
      ),
    );
  }
}