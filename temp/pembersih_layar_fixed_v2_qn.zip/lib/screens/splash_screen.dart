import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'home_screen.dart';
import 'permission_screen.dart';
import '../services/config_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await Future.delayed(const Duration(seconds: 2));
    
    final prefs = await SharedPreferences.getInstance();
    final permissionsGranted = prefs.getBool('permissions_granted') ?? false;
    
    if (!mounted) return;
    
    if (permissionsGranted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const PermissionScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: ConfigService.logoUrl.isNotEmpty
                    ? DecorationImage(
                        image: CachedNetworkImageProvider(ConfigService.logoUrl),
                        fit: BoxFit.cover,
                      )
                    : null,
                gradient: ConfigService.logoUrl.isEmpty
                    ? const LinearGradient(
                        colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
                      )
                    : null,
              ),
              child: ConfigService.logoUrl.isEmpty
                  ? const Icon(Icons.cleaning_services, color: Colors.white, size: 50)
                  : null,
            ),
            const SizedBox(height: 30),
            Text(
              ConfigService.appName.toUpperCase(),
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Screen Cleaner Pro',
              style: TextStyle(
                fontSize: 14,
                color: Colors.white.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 40),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF3949AB)),
            ),
          ],
        ),
      ),
    );
  }
}