package com.pembersih.layar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
