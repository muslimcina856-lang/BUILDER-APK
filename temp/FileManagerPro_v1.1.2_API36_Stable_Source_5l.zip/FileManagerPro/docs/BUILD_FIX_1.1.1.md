> **Historical note:** This file documents an older API 37 / AGP 9.x build path. The current v1.1.2 release branch uses API 36, AGP 8.10.1 and Gradle 8.11.1. See `BUILD_STACK_API36.md`.

# File Manager Pro 1.1.1 build fix

## Fixed

- `mergeDebugJavaResource` duplicate `META-INF/LICENSE.md` / `NOTICE.md` collisions from Bouncy Castle modules.
- Uses AGP 9 `android.packaging.resources` DSL rather than deprecated packaging APIs.
- Preserves/merges `META-INF/services/**` service descriptors.
- Excludes only repackaging metadata that is safe to omit from the APK: license/notice/index/dependency files and invalidated JAR signature files (`*.SF`, `*.RSA`, `*.DSA`, `*.EC`).
- Switched Bouncy Castle Android dependencies from multi-release `jdk18on` to `jdk15to18` 1.85 to avoid Android issues involving `META-INF/versions/...` while retaining the APIs used by the signing module.
- Gradle wrapper remains pinned to Gradle 9.5.0 for AGP 9.3.0.

## Dependency alignment

- Android Gradle Plugin: 9.3.0
- Gradle distribution: 9.5.0
- Java compile target: 17
- compileSdk / targetSdk: 37
- Bouncy Castle: bcprov/bcpkix/bcutil `jdk15to18:1.85`
- apksig: 9.2.0

## Important

Do not replace the resource exclusions with `META-INF/**`: Bouncy Castle and other libraries may carry useful service-provider metadata under `META-INF/services`, which is intentionally merged instead.
