# Stable Android 16 build stack

Use this exact toolchain for the release branch:

- Android SDK Platform 36 installed
- JDK 17
- Gradle 8.11.1
- Android Gradle Plugin 8.10.1
- Kotlin Gradle Plugin 2.3.21

The project applies `org.jetbrains.kotlin.android` because AGP 8.x does not provide AGP 9 built-in Kotlin.

Do not raise Lifecycle Compose to 2.11.x on this branch; that line requires API 37 / AGP 9.2+.
