# Release Build Guide — API 36 stable branch

## Toolchain expected
- Android SDK Platform 36
- JDK 17
- Gradle 8.11.1
- Android Gradle Plugin 8.10.1
- Kotlin Gradle Plugin / Compose Compiler plugin 2.3.21

This branch does not require Android 17 / API 37 preview SDKs.

## Build from Android Studio
1. Open the `FileManagerPro` directory as a Gradle project.
2. Install Android SDK Platform 36 if Android Studio requests it.
3. Use JDK 17 for Gradle.
4. Let Gradle sync resolve AndroidX/Compose dependencies.
5. Run the app on an Android 8.0+ device/emulator for UI verification.
6. Grant All Files Access from the in-app Storage Access card when testing full file-manager behavior.
7. For APK installation tests, Android will require the normal per-app permission to install unknown apps.

## Important dependency pins
- Lifecycle Compose is pinned to 2.10.0. Do not upgrade this branch to 2.11.x because those Compose artifacts moved to compileSdk 37 / AGP 9.2+.
- `apksig` is pinned to 8.10.1 to stay on the same Android build-tools generation as AGP 8.10.1.
- Bouncy Castle uses the `jdk15to18` 1.85 artifacts and keeps the Java-resource packaging exclusions/merges needed to avoid duplicate META-INF failures.

## Release signing
Create/use your own signing key. Do not commit private keystore files or passwords into this source archive.

In Android Studio use the signed app bundle/APK flow, choose the release variant, then protect the keystore outside the project repository.

## Command line
If your builder already provides Gradle 8.11.1, it can build this project directly. The included `gradle-wrapper.properties` is also pinned to Gradle 8.11.1 for wrapper-aware builders.
