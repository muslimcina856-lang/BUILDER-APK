# File Manager Pro v1.1.2 — API 36 Stable Build

This build line intentionally targets stable Android 16 / API 36 rather than Android 17 / API 37 preview.

## Build stack
- compileSdk: 36
- targetSdk: 36
- minSdk: 26
- Android Gradle Plugin: 8.10.1
- Gradle: 8.11.1
- JDK: 17
- Kotlin / Compose compiler plugin: 2.3.21
- Lifecycle Compose: 2.10.0
- apksig: 8.10.1
- Bouncy Castle: 1.85 jdk15to18 variants

## Why Lifecycle was pinned to 2.10.0
Lifecycle 2.11.0 Compose artifacts moved their compileSdk to API 37 and require AGP 9.2+. That conflicts with the API 36 / AGP 8.10 stable build line.

## Packaging
The Bouncy Castle META-INF duplicate-resource fix from v1.1.1 is retained. Service provider descriptors are merged rather than removed.
