# Changelog

## 0.1.0 - Vertical Slice

- Added a playable top-down town built with Flame components.
- Added player movement, world collision, camera follow, and touch controls.
- Added twelve named NPCs with jobs, homes, daily schedules, contextual dialogue, and emergency behavior.
- Added game time, shop attendance, automatic customer sales, warehouse stock, scarcity pricing, and daily accounting.
- Added the first hero-caused town event, persistent damage, material-based repair, reputation, and relationship consequences.
- Added local save/load, autosave points, end-of-day summaries, and app lifecycle saving.
- Added unit tests for time, state serialization, economy constraints, and event triggering.
