# NPC LIFE

A cozy top-down fantasy life simulation built with Flutter and Flame.

Hero menyelamatkan dunia. Penduduk biasa mengurus kesannya.

## Current playable slice

- Walk around Pekan Luma using a touch joystick.
- Meet twelve residents who follow distinct daily routines.
- Operate a shop only when the counter is attended.
- Restock bread, potions, and repair wood from a warehouse with opening hours.
- Experience a hero-caused accident at 16:30 on day one.
- Watch residents react according to their real responsibilities.
- Repair persistent damage using actual materials.
- Earn reputation and relationship changes that are saved locally.
- End the day after 20:00 or automatically at 23:00.

## Simulation principles

1. NPC behavior follows role, time, location, and emergency context.
2. Businesses have opening hours and do not operate magically while unattended.
3. Missed customers are lost rather than queued forever.
4. Scarcity can change prices during emergencies.
5. Damage persists across days until repaired.
6. Relationship gains are capped by meaningful daily interactions.
7. Save data records economy, relationships, event flags, inventory, and time.

## Project versions

- Flutter target: 3.44.x stable
- Dart target: 3.12.x
- Flame: 1.38.0
- Shared Preferences: 2.5.5

## Automatic build

On Linux with Java and an Android SDK installed:

```bash
automatic_command="bash tool/bootstrap_and_build.sh"
$automatic_command
```

The script generates missing Android platform files, creates an upload keystore, runs formatting, analysis, and tests, then outputs files into `release/`.

## Controls

- Left virtual joystick: movement.
- TINDAKAN: talk, inspect, enter a shop panel, buy supplies, repair, or sleep.
- Home icon: save and return to the main menu.

## Source map

- `lib/game/npc_life_game.dart`: central game loop and interactions.
- `lib/data/town_data.dart`: buildings, locations, NPC identities, schedules, and dialogue.
- `lib/game/systems/`: navigation, economy, and event rules.
- `lib/game/components/`: player, NPCs, buildings, ground, and damaged objects.
- `lib/ui/`: main menu, HUD, touch controls, panels, dialogue, and day summary.
- `test/`: deterministic model and simulation tests.
