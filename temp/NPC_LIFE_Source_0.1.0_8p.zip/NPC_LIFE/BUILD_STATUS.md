# Build Status

Source milestone: **0.1.0 vertical slice implemented**.

The current execution environment did not contain Flutter or the Android SDK. Network access available to the build shell was also restricted, so an APK/AAB could not be compiled in this session.

The included `tool/bootstrap_and_build.sh` automates Flutter SDK setup, Android wrapper generation, formatting, analysis, tests, release signing, APK build, and AAB build on a Linux machine that has an Android SDK and Java installed.
