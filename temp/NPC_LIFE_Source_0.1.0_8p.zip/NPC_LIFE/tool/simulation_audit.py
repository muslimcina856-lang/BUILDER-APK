#!/usr/bin/env python3
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
text = (ROOT / 'lib/data/town_data.dart').read_text(encoding='utf-8')

profiles = []
current = None
for line in text.splitlines():
    id_match = re.search(r"^\s+id: '([^']+)',", line)
    if id_match and current is None:
        # Building ids appear before NPC profiles; only start after the NPC list marker.
        continue
    if line.startswith('const List<NpcProfile> npcProfiles'):
        current = {'id': None, 'entries': []}
        continue
    if current is None:
        continue
    if id_match and current['id'] is None:
        current['id'] = id_match.group(1)
        continue
    schedule_match = re.search(
        r'ScheduleEntry\(startMinute: (\d+), endMinute: (\d+),', line
    )
    if schedule_match and current['id']:
        current['entries'].append((int(schedule_match.group(1)), int(schedule_match.group(2))))
    if line.strip() == '),' and current['id'] and current['entries']:
        # A profile ends only after its schedule list; identify the next profile lazily.
        next_nonempty = current
        if len(next_nonempty['entries']) >= 4:
            profiles.append(next_nonempty)
            current = {'id': None, 'entries': []}

# De-duplicate any accidental captures while preserving order.
seen = set()
unique_profiles = []
for profile in profiles:
    if profile['id'] not in seen:
        seen.add(profile['id'])
        unique_profiles.append(profile)
profiles = unique_profiles

if len(profiles) != 12:
    raise SystemExit(f'Expected 12 NPC profiles, found {len(profiles)}')

for profile in profiles:
    entries = profile['entries']
    if entries[0][0] != 360 or entries[-1][1] != 1440:
        raise SystemExit(f"{profile['id']} schedule does not cover 06:00-24:00: {entries}")
    for previous, following in zip(entries, entries[1:]):
        if previous[1] != following[0]:
            raise SystemExit(f"{profile['id']} schedule gap/overlap: {previous} -> {following}")

minutes_per_second = 1.2
play_seconds = (1380 - 360) / minutes_per_second
if not (600 <= play_seconds <= 900):
    raise SystemExit(f'Day duration outside 10-15 minute target: {play_seconds}s')

if 990 >= 1080:
    raise SystemExit('Market event must happen before the warehouse closes')

print(f'Audited {len(profiles)} contiguous NPC schedules.')
print(f'One full day lasts {play_seconds / 60:.2f} real minutes.')
print('The first emergency leaves 90 game minutes before warehouse closing.')
