#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

required = [
    ROOT / 'pubspec.yaml',
    ROOT / 'lib/main.dart',
    ROOT / 'lib/game/npc_life_game.dart',
    ROOT / 'lib/data/town_data.dart',
]
for path in required:
    if not path.exists() or path.stat().st_size == 0:
        raise SystemExit(f'Missing required file: {path}')

for path in (ROOT / 'assets/data').glob('*.json'):
    with path.open(encoding='utf-8') as handle:
        json.load(handle)

for path in ROOT.rglob('*.dart'):
    text = path.read_text(encoding='utf-8')
    pairs = {'{': '}', '(': ')', '[': ']'}
    stack = []
    quote = None
    escaped = False
    for char in text:
        if quote:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in ('\'', '"'):
            quote = char
        elif char in pairs:
            stack.append(pairs[char])
        elif char in pairs.values():
            if not stack or stack.pop() != char:
                raise SystemExit(f'Unbalanced delimiter in {path}')
    if stack or quote:
        raise SystemExit(f'Unclosed delimiter or string in {path}')

print('Project structure, JSON data, and Dart delimiters passed basic checks.')
