import 'dart:async';
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../data/town_data.dart';
import '../models/day_summary.dart';
import '../models/dialogue_message.dart';
import '../models/game_panel.dart';
import '../models/game_state.dart';
import '../models/game_ui_state.dart';
import '../models/item.dart';
import '../models/world_point.dart';
import '../services/save_service.dart';
import 'components/building_component.dart';
import 'components/damageable_object.dart';
import 'components/npc_component.dart';
import 'components/player_component.dart';
import 'components/town_ground.dart';
import 'systems/economy_system.dart';
import 'systems/event_director.dart';
import 'systems/grid_navigator.dart';

class NpcLifeGame extends FlameGame {
  NpcLifeGame({
    required this.state,
    required this.saveService,
  });

  final GameState state;
  final SaveService saveService;

  late final PlayerComponent player;
  late final GridNavigator navigator;
  late final EconomySystem economy;
  late final EventDirector eventDirector;
  final List<NpcComponent> npcs = <NpcComponent>[];

  final ValueNotifier<GameUiState?> uiState = ValueNotifier<GameUiState?>(null);
  final ValueNotifier<DialogueMessage?> dialogue = ValueNotifier<DialogueMessage?>(null);
  final ValueNotifier<GamePanelMode?> panel = ValueNotifier<GamePanelMode?>(null);
  final ValueNotifier<DaySummary?> daySummary = ValueNotifier<DaySummary?>(null);
  final ValueNotifier<String?> toast = ValueNotifier<String?>(null);

  DamageableObject? _marketDamage;
  bool _endingDay = false;
  bool _ready = false;
  bool _disposed = false;

  bool get isEmergencyActive =>
      _ready && eventDirector.marketBlastStarted && !eventDirector.marketBlastRepaired;

  bool get shopAttended {
    if (!_ready) {
      return false;
    }
    final WorldPoint counter = townLocations['player_counter']!;
    return state.clock.isBusinessHours &&
        player.position.distanceTo(Vector2(counter.x, counter.y)) <= 105;
  }

  @override
  Color backgroundColor() => const Color(0xFF42533F);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final List<Rect> obstacles = townBuildings.map((BuildingDefinition b) => b.rect).toList();
    navigator = GridNavigator(
      worldWidth: townWidth,
      worldHeight: townHeight,
      obstacles: obstacles,
    );
    economy = EconomySystem(state);
    eventDirector = EventDirector(state);

    final TownGround ground = TownGround()..priority = -20;
    await world.add(ground);
    for (final BuildingDefinition definition in townBuildings) {
      await world.add(BuildingComponent(definition)..priority = 0);
    }

    player = PlayerComponent(obstacles: obstacles)..priority = 30;
    await world.add(player);

    for (final profile in npcProfiles) {
      final NpcComponent npc = NpcComponent(
        profile: profile,
        state: state,
        navigator: navigator,
        isEmergencyActive: () => isEmergencyActive,
      )..priority = 20;
      npcs.add(npc);
      await world.add(npc);
    }

    if (eventDirector.marketBlastStarted && !eventDirector.marketBlastRepaired) {
      await _spawnMarketDamage();
    }

    camera.viewfinder.zoom = 0.72;
    camera.follow(player);
    _ready = true;
    _refreshUi();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_endingDay || daySummary.value != null) {
      return;
    }

    final bool minuteChanged = state.clock.advance(dt);
    if (minuteChanged && eventDirector.shouldTriggerMarketBlast()) {
      unawaited(_triggerMarketBlast());
    }

    final SaleResult? sale = economy.update(
      minuteChanged: minuteChanged,
      shopAttended: shopAttended,
      emergencyActive: isEmergencyActive,
    );
    if (sale != null) {
      final String name = itemCatalog[sale.itemId]!.nameMs;
      _showToast('$name terjual: +${sale.price} syiling');
    }

    if (minuteChanged && state.clock.shouldEndDay) {
      unawaited(endDay());
      return;
    }
    if (minuteChanged || sale != null) {
      _refreshUi();
    }
  }

  void setMovement(Vector2 movement) {
    if (!_ready) {
      return;
    }
    if (dialogue.value != null || panel.value != null || daySummary.value != null) {
      player.movement.setZero();
      return;
    }
    player.movement.setFrom(movement);
  }

  Future<void> interact() async {
    if (!_ready) {
      return;
    }
    if (dialogue.value != null || panel.value != null || daySummary.value != null) {
      return;
    }
    player.movement.setZero();

    if (_marketDamage != null &&
        player.position.distanceTo(_marketDamage!.position) <= 105) {
      await _repairMarketStall();
      return;
    }

    NpcComponent? nearestNpc;
    double nearestDistance = double.infinity;
    for (final NpcComponent npc in npcs) {
      final double distance = player.position.distanceTo(npc.position);
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestNpc = npc;
      }
    }
    if (nearestNpc != null && nearestDistance <= 82) {
      _talkToNpc(nearestNpc);
      return;
    }

    final WorldPoint home = townLocations['player_home']!;
    if (player.position.distanceTo(Vector2(home.x, home.y)) <= 65) {
      if (state.clock.minute >= 1200) {
        await endDay();
      } else {
        showDialogue(const DialogueMessage(
          speaker: 'Pemikiran',
          text: 'Masih terlalu awal untuk tidur. Kedai dan penduduk masih memerlukan perhatian.',
          detail: 'Waktu sesuai untuk pulang ialah selepas 20:00.',
        ));
      }
      return;
    }

    BuildingDefinition? nearestBuilding;
    double nearestDoorDistance = double.infinity;
    for (final BuildingDefinition building in townBuildings) {
      final double distance = player.position.distanceTo(
        Vector2(building.door.x, building.door.y),
      );
      if (distance < nearestDoorDistance) {
        nearestDoorDistance = distance;
        nearestBuilding = building;
      }
    }
    if (nearestBuilding != null && nearestDoorDistance <= 95) {
      _interactWithBuilding(nearestBuilding);
      return;
    }

    showDialogue(const DialogueMessage(
      speaker: 'Pemikiran',
      text: 'Tiada apa yang boleh digunakan dari sini.',
      detail: 'Dekati penduduk, pintu bangunan, kaunter kedai, atau objek rosak.',
    ));
  }

  void _talkToNpc(NpcComponent npc) {
    final String dailyFlag = 'talk_${state.clock.day}_${npc.profile.id}';
    if (!state.flags.contains(dailyFlag)) {
      state.flags.add(dailyFlag);
      state.changeRelationship(npc.profile.id, 1);
    }
    final int lineIndex = (state.clock.day + state.clock.hour + npc.profile.id.length) %
        npc.profile.dialogueMs.length;
    final String text = isEmergencyActive
        ? '${npc.profile.name} sedang ${npc.profile.eventResponseMs}. '
            '${npc.profile.dialogueMs[lineIndex]}'
        : npc.profile.dialogueMs[lineIndex];
    showDialogue(DialogueMessage(
      speaker: '${npc.profile.name} - ${npc.profile.roleMs}',
      text: text,
      detail: 'Sekarang: ${npc.currentActivity}. Hubungan: '
          '${state.relationships[npc.profile.id] ?? 0}/100.',
    ));
    unawaited(saveService.save(state));
    _refreshUi();
  }

  void _interactWithBuilding(BuildingDefinition building) {
    switch (building.id) {
      case 'player_shop':
        panel.value = GamePanelMode.playerShop;
        pauseEngine();
        return;
      case 'warehouse':
        if (state.clock.minute >= 480 && state.clock.minute < 1080) {
          panel.value = GamePanelMode.warehouse;
          pauseEngine();
        } else {
          showDialogue(const DialogueMessage(
            speaker: 'Gudang Bekalan',
            text: 'Gudang sudah ditutup.',
            detail: 'Waktu operasi: 08:00 hingga 18:00.',
          ));
        }
        return;
      case 'guild':
        showDialogue(const DialogueMessage(
          speaker: 'Guild Hero',
          text: 'Kaunter tuntutan kerosakan hanya menerima laporan lengkap dengan saksi dan resit.',
          detail: 'Elin dan Sera mungkin membantu menyediakan bukti.',
        ));
        return;
      case 'mayor_hall':
        showDialogue(DialogueMessage(
          speaker: 'Dewan Bandar',
          text: 'Reputasi semasa: ${state.reputation}. Penduduk menilai tindakan, bukan sekadar keuntungan.',
          detail: 'Membantu ketika krisis meningkatkan kepercayaan bandar.',
        ));
        return;
      default:
        showDialogue(DialogueMessage(
          speaker: building.nameMs,
          text: 'Bangunan ini sedang beroperasi mengikut jadual penduduknya.',
          detail: 'Bercakap dengan pemilik untuk mengetahui keadaan semasa.',
        ));
        return;
    }
  }

  int warehousePrice(String itemId) {
    final ItemDefinition item = itemCatalog[itemId]!;
    final int scarcity = isEmergencyActive && itemId == 'potion' ? 2 : 0;
    return item.baseBuyPrice + scarcity;
  }

  void buyFromWarehouse(String itemId) {
    final int price = warehousePrice(itemId);
    if (state.coins < price) {
      _showToast('Syiling tidak mencukupi');
      return;
    }
    state.coins -= price;
    state.addItem(itemId, 1);
    _showToast('${itemCatalog[itemId]!.nameMs} dibeli: -$price syiling');
    _refreshUi();
    unawaited(saveService.save(state));
  }

  Future<void> _repairMarketStall() async {
    if (state.itemCount('wood') < 2) {
      showDialogue(const DialogueMessage(
        speaker: 'Gerai Rosak',
        text: 'Dua unit kayu pembaikan diperlukan untuk menguatkan rangka gerai.',
        detail: 'Kayu boleh dibeli di Gudang Bekalan sebelum 18:00.',
      ));
      return;
    }

    state.removeItem('wood', 2);
    state.reputation += 5;
    state.changeRelationship('sera', 2);
    state.changeRelationship('borin', 1);
    economy.ledger.reputationChange += 5;
    eventDirector.markMarketBlastRepaired();
    _marketDamage?.removeFromParent();
    _marketDamage = null;
    await saveService.save(state);
    _refreshUi();
    showDialogue(const DialogueMessage(
      speaker: 'Pekan Luma',
      text: 'Gerai berjaya dikuatkan dan laluan kembali selamat.',
      detail: 'Digunakan: 2 kayu. Reputasi +5. Sera dan Borin menghargai bantuan itu.',
    ));
  }

  Future<void> _triggerMarketBlast() async {
    eventDirector.markMarketBlastStarted();
    await _spawnMarketDamage();
    await saveService.save(state);
    _refreshUi();
    showDialogue(const DialogueMessage(
      speaker: 'Kejadian Bandar',
      text: 'Satu mantera hero tersasar ketika mengejar slime. Gerai di dataran runtuh, tetapi tiada penduduk cedera parah.',
      detail: 'Penduduk bertindak mengikut peranan mereka. Dekati gerai rosak untuk menilai bahan pembaikan.',
    ));
  }

  Future<void> _spawnMarketDamage() async {
    if (_marketDamage != null) {
      return;
    }
    final WorldPoint point = townLocations['damage_site']!;
    _marketDamage = DamageableObject(
      objectId: 'market_stall',
      position: Vector2(point.x, point.y),
    )..priority = 25;
    await world.add(_marketDamage!);
  }

  void showDialogue(DialogueMessage message) {
    player.movement.setZero();
    dialogue.value = message;
    pauseEngine();
  }

  void closeDialogue() {
    dialogue.value = null;
    _resumeWhenClear();
  }

  void closePanel() {
    panel.value = null;
    _resumeWhenClear();
  }

  void _resumeWhenClear() {
    if (dialogue.value == null && panel.value == null && daySummary.value == null) {
      resumeEngine();
    }
  }

  Future<void> endDay() async {
    if (_endingDay || daySummary.value != null) {
      return;
    }
    _endingDay = true;
    player.movement.setZero();
    pauseEngine();
    final String eventNote;
    if (state.clock.day == 1 && eventDirector.marketBlastStarted) {
      eventNote = eventDirector.marketBlastRepaired
          ? 'Gerai dataran dibaiki sebelum keadaan menjadi lebih buruk.'
          : 'Gerai dataran masih rosak dan akan menjejaskan esok.';
    } else {
      eventNote = 'Bandar melalui hari yang tenang tanpa kerosakan besar.';
    }
    daySummary.value = DaySummary(
      day: state.clock.day,
      salesRevenue: economy.ledger.salesRevenue,
      itemsSold: economy.ledger.itemsSold,
      reputationChange: economy.ledger.reputationChange,
      eventNote: eventNote,
    );
    await saveService.save(state);
    _endingDay = false;
  }

  Future<void> continueNextDay() async {
    state.clock.startNextDay();
    economy.ledger.reset();
    final WorldPoint home = townLocations['player_home']!;
    player.position.setValues(home.x, home.y);
    daySummary.value = null;
    await saveService.save(state);
    _refreshUi();
    resumeEngine();
  }

  Future<void> saveNow() async {
    await saveService.save(state);
  }

  String _objective() {
    if (isEmergencyActive) {
      return 'Baiki gerai dataran: perlukan 2 kayu pembaikan.';
    }
    if (state.clock.minute < 480) {
      return 'Kenali penduduk sebelum kedai dibuka pada 08:00.';
    }
    if (state.clock.minute < 1200) {
      return shopAttended
          ? 'Kedai sedang dijaga. Tunggu pelanggan atau urus bekalan.'
          : 'Berdiri berhampiran kaunter supaya pelanggan boleh dilayan.';
    }
    return 'Pulang ke Rumah Pemain di barat daya bandar untuk menamatkan hari.';
  }

  void _refreshUi() {
    uiState.value = GameUiState(
      day: state.clock.day,
      time: state.clock.formattedTime,
      coins: state.coins,
      reputation: state.reputation,
      bread: state.itemCount('bread'),
      potion: state.itemCount('potion'),
      wood: state.itemCount('wood'),
      objective: _objective(),
      shopAttended: shopAttended,
    );
  }

  void _showToast(String message) {
    toast.value = message;
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (!_disposed && toast.value == message) {
        toast.value = null;
      }
    });
  }

  @override
  void onRemove() {
    _disposed = true;
    uiState.dispose();
    dialogue.dispose();
    panel.dispose();
    daySummary.dispose();
    toast.dispose();
    super.onRemove();
  }
}
