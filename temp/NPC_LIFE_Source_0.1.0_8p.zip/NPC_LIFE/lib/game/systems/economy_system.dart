import '../../models/game_state.dart';
import '../../models/item.dart';

class DayLedger {
  int salesRevenue = 0;
  int itemsSold = 0;
  int reputationChange = 0;

  void reset() {
    salesRevenue = 0;
    itemsSold = 0;
    reputationChange = 0;
  }
}

class SaleResult {
  const SaleResult({required this.itemId, required this.price});

  final String itemId;
  final int price;
}

class EconomySystem {
  EconomySystem(this.state);

  final GameState state;
  final DayLedger ledger = DayLedger();
  int _lastCustomerAbsoluteMinute = -1;
  bool _sellPotionNext = false;

  SaleResult? update({
    required bool minuteChanged,
    required bool shopAttended,
    required bool emergencyActive,
  }) {
    if (!minuteChanged) {
      return null;
    }
    final int absoluteMinute = state.clock.day * 1440 + state.clock.minute;
    if (_lastCustomerAbsoluteMinute < 0) {
      _lastCustomerAbsoluteMinute = absoluteMinute;
      return null;
    }
    if (absoluteMinute - _lastCustomerAbsoluteMinute < 45) {
      return null;
    }
    _lastCustomerAbsoluteMinute = absoluteMinute;

    if (!state.clock.isBusinessHours || !shopAttended) {
      return null;
    }

    final String preferred = emergencyActive
        ? 'potion'
        : (_sellPotionNext ? 'potion' : 'bread');
    _sellPotionNext = !_sellPotionNext;
    final String? itemId = state.itemCount(preferred) > 0
        ? preferred
        : (state.itemCount('bread') > 0
            ? 'bread'
            : (state.itemCount('potion') > 0 ? 'potion' : null));
    if (itemId == null) {
      return null;
    }

    final ItemDefinition definition = itemCatalog[itemId]!;
    state.removeItem(itemId, 1);
    state.coins += definition.baseSellPrice;
    ledger.salesRevenue += definition.baseSellPrice;
    ledger.itemsSold += 1;
    return SaleResult(itemId: itemId, price: definition.baseSellPrice);
  }
}
