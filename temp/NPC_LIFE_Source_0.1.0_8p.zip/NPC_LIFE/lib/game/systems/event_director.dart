import '../../models/game_state.dart';

class EventDirector {
  EventDirector(this.state);

  final GameState state;

  bool shouldTriggerMarketBlast() {
    const String started = 'day1_market_blast_started';
    if (state.flags.contains(started)) {
      return false;
    }
    return state.clock.day == 1 && state.clock.minute >= 990;
  }

  bool get marketBlastStarted => state.flags.contains('day1_market_blast_started');
  bool get marketBlastRepaired => state.flags.contains('day1_market_blast_repaired');

  void markMarketBlastStarted() {
    state.flags.add('day1_market_blast_started');
  }

  void markMarketBlastRepaired() {
    state.flags.add('day1_market_blast_repaired');
  }
}
