import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class PlayerComponent extends PositionComponent {
  PlayerComponent({required this.obstacles})
      : super(
          position: Vector2(310, 680),
          size: Vector2.all(34),
          anchor: Anchor.center,
        );

  final List<Rect> obstacles;
  Vector2 movement = Vector2.zero();
  final double speed = 190;

  Rect _boundsAt(Vector2 point) => Rect.fromCenter(
        center: Offset(point.x, point.y),
        width: size.x,
        height: size.y,
      );

  bool _isBlocked(Vector2 point) =>
      obstacles.any((Rect obstacle) => obstacle.inflate(5).overlaps(_boundsAt(point)));

  @override
  void update(double dt) {
    super.update(dt);
    if (movement.length2 == 0) {
      return;
    }
    final Vector2 direction = movement.normalized();
    final Vector2 delta = direction * speed * dt;
    final Vector2 xMove = Vector2(position.x + delta.x, position.y);
    if (!_isBlocked(xMove)) {
      position.x = xMove.x;
    }
    final Vector2 yMove = Vector2(position.x, position.y + delta.y);
    if (!_isBlocked(yMove)) {
      position.y = yMove.y;
    }
    position.x = position.x.clamp(20, 1780).toDouble();
    position.y = position.y.clamp(20, 1180).toDouble();
  }

  @override
  void render(Canvas canvas) {
    final Paint shadow = Paint()..color = const Color(0x44000000);
    final Paint coat = Paint()..color = const Color(0xFF3D6F68);
    final Paint skin = Paint()..color = const Color(0xFFD6A77A);
    final Paint outline = Paint()
      ..color = const Color(0xFF26231E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawOval(const Rect.fromLTWH(4, 25, 27, 11), shadow);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(5, 12, 24, 21), const Radius.circular(7)),
      coat,
    );
    canvas.drawCircle(const Offset(17, 9), 8, skin);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(5, 2, 24, 31), const Radius.circular(8)),
      outline,
    );
  }
}
