import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class DamageableObject extends PositionComponent {
  DamageableObject({required this.objectId, required Vector2 position})
      : super(
          position: position,
          size: Vector2(88, 68),
          anchor: Anchor.center,
        );

  final String objectId;

  @override
  void render(Canvas canvas) {
    final Paint wood = Paint()..color = const Color(0xFF755034);
    final Paint darkWood = Paint()..color = const Color(0xFF4B3122);
    final Paint warning = Paint()..color = const Color(0xFFD65C46);
    final Paint dust = Paint()..color = const Color(0x66765A42);

    canvas.drawOval(const Rect.fromLTWH(2, 45, 84, 18), dust);
    canvas.save();
    canvas.translate(8, 10);
    canvas.rotate(-0.22);
    canvas.drawRect(const Rect.fromLTWH(0, 0, 70, 17), wood);
    canvas.drawRect(const Rect.fromLTWH(4, 17, 12, 36), darkWood);
    canvas.drawRect(const Rect.fromLTWH(53, 17, 12, 31), darkWood);
    canvas.restore();
    canvas.drawCircle(const Offset(70, 12), 11, warning);

    final TextPainter marker = TextPainter(
      text: const TextSpan(
        text: '!',
        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    marker.paint(canvas, Offset(70 - marker.width / 2, 12 - marker.height / 2));
  }
}
