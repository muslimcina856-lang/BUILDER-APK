import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/material.dart';

import '../../data/town_data.dart';
import '../../models/game_state.dart';
import '../../models/npc_profile.dart';
import '../../models/world_point.dart';
import '../systems/grid_navigator.dart';

class NpcComponent extends PositionComponent {
  NpcComponent({
    required this.profile,
    required this.state,
    required this.navigator,
    required this.isEmergencyActive,
  }) : super(
          position: _initialPosition(profile),
          size: Vector2(32, 38),
          anchor: Anchor.center,
        );

  final NpcProfile profile;
  final GameState state;
  final GridNavigator navigator;
  final bool Function() isEmergencyActive;

  final List<Vector2> _path = <Vector2>[];
  String _targetLocationId = '';
  int _pathIndex = 0;
  int _lastScheduleMinute = -1;
  bool _lastEmergencyState = false;
  String currentActivity = 'bersiap untuk hari ini';

  static Vector2 _initialPosition(NpcProfile profile) {
    final WorldPoint point = townLocations[profile.homeLocationId] ?? const WorldPoint(900, 600);
    return Vector2(point.x, point.y);
  }

  Color get _bodyColor {
    const List<Color> palette = <Color>[
      Color(0xFFB65F5A),
      Color(0xFF4E7189),
      Color(0xFF7F6755),
      Color(0xFF816A93),
      Color(0xFF4F8262),
      Color(0xFFC18C43),
    ];
    return palette[profile.id.hashCode.abs() % palette.length];
  }

  @override
  void update(double dt) {
    super.update(dt);
    final int minute = state.clock.minute;
    final bool emergency = isEmergencyActive();
    if (_lastScheduleMinute != minute || emergency != _lastEmergencyState) {
      _lastScheduleMinute = minute;
      _lastEmergencyState = emergency;
      final ScheduleEntry scheduled = profile.scheduleAt(minute);
      final String desiredLocation = emergency
          ? profile.eventResponseLocationId
          : scheduled.locationId;
      currentActivity = emergency ? profile.eventResponseMs : scheduled.activityMs;
      if (desiredLocation != _targetLocationId) {
        _targetLocationId = desiredLocation;
        _rebuildPath(desiredLocation);
      }
    }

    if (_pathIndex >= _path.length) {
      return;
    }
    final Vector2 target = _path[_pathIndex];
    final Vector2 difference = target - position;
    if (difference.length < 5) {
      _pathIndex += 1;
      return;
    }
    final Vector2 step = difference.normalized() * 55 * dt;
    if (step.length >= difference.length) {
      position.setFrom(target);
      _pathIndex += 1;
    } else {
      position.add(step);
    }
  }

  void _rebuildPath(String locationId) {
    final WorldPoint destination = townLocations[locationId] ?? const WorldPoint(900, 600);
    _path
      ..clear()
      ..addAll(navigator.findPath(position, Vector2(destination.x, destination.y)));
    _pathIndex = 0;
  }

  @override
  void render(Canvas canvas) {
    final Paint shadow = Paint()..color = const Color(0x3D000000);
    final Paint body = Paint()..color = _bodyColor;
    final Paint skin = Paint()..color = const Color(0xFFD5A27B);
    final Paint outline = Paint()
      ..color = const Color(0xFF2B2722)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;

    canvas.drawOval(const Rect.fromLTWH(3, 29, 27, 8), shadow);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(5, 14, 22, 20), const Radius.circular(6)),
      body,
    );
    canvas.drawCircle(const Offset(16, 10), 7, skin);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(5, 3, 22, 31), const Radius.circular(7)),
      outline,
    );

    final TextPainter label = TextPainter(
      text: TextSpan(
        text: profile.name,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.w800,
          shadows: <Shadow>[Shadow(blurRadius: 3, color: Colors.black)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    label.paint(canvas, Offset((size.x - label.width) / 2, -17));
  }
}
