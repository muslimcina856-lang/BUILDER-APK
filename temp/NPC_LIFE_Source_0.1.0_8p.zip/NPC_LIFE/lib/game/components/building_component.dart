import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/material.dart';

import '../../data/town_data.dart';

class BuildingComponent extends PositionComponent {
  BuildingComponent(this.definition)
      : super(
          position: Vector2(definition.rect.left, definition.rect.top),
          size: Vector2(definition.rect.width, definition.rect.height),
        );

  final BuildingDefinition definition;

  Color get _wallColor {
    switch (definition.kind) {
      case 'clinic':
        return const Color(0xFFE7E0D2);
      case 'guild':
        return const Color(0xFF8B7866);
      case 'blacksmith':
        return const Color(0xFF77736E);
      case 'warehouse':
        return const Color(0xFF9A805C);
      case 'hall':
        return const Color(0xFFD0B47C);
      default:
        return const Color(0xFFC99D6A);
    }
  }

  @override
  void render(Canvas canvas) {
    final Paint shadow = Paint()..color = const Color(0x33000000);
    final Paint wall = Paint()..color = _wallColor;
    final Paint roof = Paint()..color = const Color(0xFF7A3F35);
    final Paint outline = Paint()
      ..color = const Color(0xFF3E332A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5;
    final Paint door = Paint()..color = const Color(0xFF5D3B28);

    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(10, 14, size.x, size.y), const Radius.circular(14)),
      shadow,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.x, size.y), const Radius.circular(12)),
      wall,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(-8, -18, size.x + 16, 62), const Radius.circular(14)),
      roof,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.x, size.y), const Radius.circular(12)),
      outline,
    );

    final double localDoorX = definition.door.x - definition.rect.left;
    final bool doorOnBottom = definition.door.y >= definition.rect.bottom;
    final bool doorOnTop = definition.door.y <= definition.rect.top;
    final bool doorOnLeft = definition.door.x <= definition.rect.left;
    final bool doorOnRight = definition.door.x >= definition.rect.right;
    final double localDoorY = definition.door.y - definition.rect.top;
    if (doorOnLeft) {
      canvas.drawRect(Rect.fromLTWH(-3, localDoorY - 22, 18, 44), door);
    } else if (doorOnRight) {
      canvas.drawRect(Rect.fromLTWH(size.x - 15, localDoorY - 22, 18, 44), door);
    } else if (doorOnTop) {
      canvas.drawRect(Rect.fromLTWH(localDoorX - 18, -3, 36, 25), door);
    } else if (doorOnBottom) {
      canvas.drawRect(Rect.fromLTWH(localDoorX - 18, size.y - 6, 36, 34), door);
    }

    final TextPainter label = TextPainter(
      text: TextSpan(
        text: definition.nameMs,
        style: const TextStyle(
          color: Color(0xFF241F1A),
          fontSize: 17,
          fontWeight: FontWeight.w800,
          backgroundColor: Color(0xCCF4E7C5),
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: size.x - 24);
    label.paint(canvas, Offset((size.x - label.width) / 2, 62));
  }
}
