import 'package:flutter/material.dart';

class AppTheme {
  AppTheme._();

  static const Color parchment = Color(0xFFF4E7C5);
  static const Color ink = Color(0xFF2C261E);
  static const Color moss = Color(0xFF596B45);
  static const Color amber = Color(0xFFD99B3D);
  static const Color danger = Color(0xFFA94C3D);
  static const Color night = Color(0xFF263245);

  static ThemeData get theme {
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: moss,
      brightness: Brightness.light,
      surface: parchment,
    );
    return ThemeData(
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFF18231C),
      useMaterial3: true,
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: parchment,
          fontWeight: FontWeight.w900,
          letterSpacing: 2,
        ),
        titleLarge: TextStyle(fontWeight: FontWeight.w800),
        bodyLarge: TextStyle(height: 1.35),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
          textStyle: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}
