import 'package:flutter/material.dart';

import '../services/save_service.dart';
import '../ui/main_menu_screen.dart';
import 'app_theme.dart';

class NpcLifeApp extends StatelessWidget {
  const NpcLifeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NPC LIFE',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: MainMenuScreen(saveService: SaveService()),
    );
  }
}
