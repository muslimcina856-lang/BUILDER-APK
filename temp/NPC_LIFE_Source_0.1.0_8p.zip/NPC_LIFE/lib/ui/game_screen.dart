import 'dart:async';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../app/app_theme.dart';
import '../game/npc_life_game.dart';
import '../models/day_summary.dart';
import '../models/dialogue_message.dart';
import '../models/game_panel.dart';
import '../models/game_state.dart';
import '../models/game_ui_state.dart';
import '../models/item.dart';
import '../services/save_service.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    required this.initialState,
    required this.saveService,
    super.key,
  });

  final GameState initialState;
  final SaveService saveService;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with WidgetsBindingObserver {
  late final NpcLifeGame game;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    game = NpcLifeGame(
      state: widget.initialState,
      saveService: widget.saveService,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      game.pauseEngine();
      unawaited(game.saveNow());
    } else if (state == AppLifecycleState.resumed &&
        game.dialogue.value == null &&
        game.panel.value == null &&
        game.daySummary.value == null) {
      game.resumeEngine();
    }
  }

  Future<void> _returnToMenu() async {
    game.pauseEngine();
    await game.saveNow();
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(game.saveNow());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          unawaited(_returnToMenu());
        }
      },
      child: Scaffold(
        body: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            GameWidget<NpcLifeGame>(game: game),
            _Hud(game: game),
            Positioned(
              left: 20,
              bottom: 18,
              child: VirtualJoystick(
                onChanged: game.setMovement,
              ),
            ),
            Positioned(
              right: 28,
              bottom: 28,
              child: _InteractionButton(onPressed: game.interact),
            ),
            Positioned(
              top: 18,
              right: 18,
              child: IconButton.filledTonal(
                tooltip: 'Simpan dan kembali ke menu',
                onPressed: _returnToMenu,
                icon: const Icon(Icons.home_rounded),
              ),
            ),
            _ToastLayer(game: game),
            _DialogueLayer(game: game),
            _PanelLayer(game: game),
            _DaySummaryLayer(game: game),
          ],
        ),
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SafeArea(
        child: ValueListenableBuilder<GameUiState?>(
          valueListenable: game.uiState,
          builder: (BuildContext context, GameUiState? state, Widget? child) {
            if (state == null) {
              return const SizedBox.shrink();
            }
            return Stack(
              children: <Widget>[
                Positioned(
                  top: 14,
                  left: 18,
                  child: _ParchmentPanel(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text('HARI ${state.day}', style: const TextStyle(fontWeight: FontWeight.w900)),
                        const SizedBox(width: 14),
                        Text(state.time, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                        const SizedBox(width: 18),
                        const Icon(Icons.monetization_on_rounded, size: 20),
                        const SizedBox(width: 4),
                        Text('${state.coins}'),
                        const SizedBox(width: 12),
                        const Icon(Icons.handshake_rounded, size: 20),
                        const SizedBox(width: 4),
                        Text('${state.reputation}'),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 76,
                  left: 18,
                  child: _ParchmentPanel(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        _ItemCount(label: 'Roti', count: state.bread),
                        const SizedBox(width: 14),
                        _ItemCount(label: 'Ramuan', count: state.potion),
                        const SizedBox(width: 14),
                        _ItemCount(label: 'Kayu', count: state.wood),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 76,
                  right: 78,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 430),
                    child: _ParchmentPanel(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(
                            state.shopAttended ? Icons.storefront_rounded : Icons.assignment_rounded,
                            size: 22,
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              state.objective,
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ParchmentPanel extends StatelessWidget {
  const _ParchmentPanel({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.parchment.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.ink, width: 2),
        boxShadow: const <BoxShadow>[
          BoxShadow(offset: Offset(3, 4), blurRadius: 0, color: Colors.black38),
        ],
      ),
      child: DefaultTextStyle(
        style: const TextStyle(color: AppTheme.ink, fontSize: 15),
        child: child,
      ),
    );
  }
}

class _ItemCount extends StatelessWidget {
  const _ItemCount({required this.label, required this.count});

  final String label;
  final int count;

  @override
  Widget build(BuildContext context) {
    return Text('$label: $count', style: const TextStyle(fontWeight: FontWeight.w800));
  }
}

class VirtualJoystick extends StatefulWidget {
  const VirtualJoystick({required this.onChanged, super.key});

  final ValueChanged<Vector2> onChanged;

  @override
  State<VirtualJoystick> createState() => _VirtualJoystickState();
}

class _VirtualJoystickState extends State<VirtualJoystick> {
  static const double _size = 132;
  static const double _radius = 45;
  Offset _knob = Offset.zero;

  void _update(Offset localPosition) {
    const Offset center = Offset(_size / 2, _size / 2);
    Offset delta = localPosition - center;
    if (delta.distance > _radius) {
      delta = Offset.fromDirection(delta.direction, _radius);
    }
    setState(() => _knob = delta);
    widget.onChanged(Vector2(delta.dx / _radius, delta.dy / _radius));
  }

  void _reset() {
    setState(() => _knob = Offset.zero);
    widget.onChanged(Vector2.zero());
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (DragStartDetails details) => _update(details.localPosition),
      onPanUpdate: (DragUpdateDetails details) => _update(details.localPosition),
      onPanEnd: (DragEndDetails details) => _reset(),
      onPanCancel: _reset,
      child: SizedBox(
        width: _size,
        height: _size,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            Container(
              width: 112,
              height: 112,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withValues(alpha: 0.28),
                border: Border.all(color: Colors.white54, width: 3),
              ),
            ),
            Transform.translate(
              offset: _knob,
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.parchment.withValues(alpha: 0.92),
                  border: Border.all(color: AppTheme.ink, width: 3),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(offset: Offset(2, 3), blurRadius: 0, color: Colors.black38),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InteractionButton extends StatelessWidget {
  const _InteractionButton({required this.onPressed});

  final Future<void> Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 104,
      height: 104,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          shape: const CircleBorder(),
          padding: const EdgeInsets.all(12),
          backgroundColor: AppTheme.amber,
          foregroundColor: AppTheme.ink,
          side: const BorderSide(color: AppTheme.ink, width: 4),
          elevation: 8,
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.touch_app_rounded, size: 31),
            Text('TINDAKAN', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class _ToastLayer extends StatelessWidget {
  const _ToastLayer({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: ValueListenableBuilder<String?>(
        valueListenable: game.toast,
        builder: (BuildContext context, String? message, Widget? child) {
          if (message == null) {
            return const SizedBox.shrink();
          }
          return Align(
            alignment: const Alignment(0, -0.65),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: AppTheme.ink.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: AppTheme.parchment, width: 2),
              ),
              child: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            ),
          );
        },
      ),
    );
  }
}

class _DialogueLayer extends StatelessWidget {
  const _DialogueLayer({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DialogueMessage?>(
      valueListenable: game.dialogue,
      builder: (BuildContext context, DialogueMessage? message, Widget? child) {
        if (message == null) {
          return const SizedBox.shrink();
        }
        return _ModalScrim(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppTheme.parchment,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppTheme.ink, width: 4),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(message.speaker, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  Text(message.text, style: const TextStyle(fontSize: 19, height: 1.4)),
                  if (message.detail != null) ...<Widget>[
                    const SizedBox(height: 12),
                    Text(
                      message.detail!,
                      style: const TextStyle(fontSize: 15, height: 1.35, color: Colors.black65),
                    ),
                  ],
                  const SizedBox(height: 22),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton(
                      onPressed: game.closeDialogue,
                      child: const Text('TERUSKAN'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _PanelLayer extends StatelessWidget {
  const _PanelLayer({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GamePanelMode?>(
      valueListenable: game.panel,
      builder: (BuildContext context, GamePanelMode? mode, Widget? child) {
        if (mode == null) {
          return const SizedBox.shrink();
        }
        return _ModalScrim(
          child: mode == GamePanelMode.warehouse
              ? _WarehousePanel(game: game)
              : _PlayerShopPanel(game: game),
        );
      },
    );
  }
}

class _PlayerShopPanel extends StatelessWidget {
  const _PlayerShopPanel({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return _LargePanel(
      title: 'Kedai NPC LIFE',
      onClose: game.closePanel,
      child: ValueListenableBuilder<GameUiState?>(
        valueListenable: game.uiState,
        builder: (BuildContext context, GameUiState? state, Widget? child) {
          if (state == null) {
            return const CircularProgressIndicator();
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                state.shopAttended
                    ? 'Kau berada cukup dekat dengan kaunter. Pelanggan boleh dilayan.'
                    : 'Pelanggan tidak akan membeli jika kedai ditinggalkan tanpa penjaga.',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: state.shopAttended ? AppTheme.moss : AppTheme.danger,
                ),
              ),
              const SizedBox(height: 18),
              _StockRow(name: 'Roti Luma', quantity: state.bread, price: itemCatalog['bread']!.baseSellPrice),
              _StockRow(name: 'Ramuan Kecil', quantity: state.potion, price: itemCatalog['potion']!.baseSellPrice),
              const SizedBox(height: 18),
              const Text(
                'Logik kedai: pelanggan datang kira-kira setiap 45 minit permainan. '
                'Jika tiada penjaga atau stok habis, jualan itu hilang dan tidak ditunda.',
                style: TextStyle(height: 1.4),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _WarehousePanel extends StatelessWidget {
  const _WarehousePanel({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return _LargePanel(
      title: 'Gudang Bekalan',
      onClose: game.closePanel,
      child: ValueListenableBuilder<GameUiState?>(
        valueListenable: game.uiState,
        builder: (BuildContext context, GameUiState? state, Widget? child) {
          if (state == null) {
            return const CircularProgressIndicator();
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Syiling tersedia: ${state.coins}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              _BuyRow(
                name: 'Roti Luma',
                description: 'Stok asas; untung kecil tetapi permintaan stabil.',
                price: game.warehousePrice('bread'),
                onBuy: () => game.buyFromWarehouse('bread'),
              ),
              _BuyRow(
                name: 'Ramuan Kecil',
                description: 'Lebih mahal ketika kecemasan kerana permintaan meningkat.',
                price: game.warehousePrice('potion'),
                onBuy: () => game.buyFromWarehouse('potion'),
              ),
              _BuyRow(
                name: 'Kayu Pembaikan',
                description: 'Bahan penting untuk gerai dan perabot rosak.',
                price: game.warehousePrice('wood'),
                onBuy: () => game.buyFromWarehouse('wood'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _StockRow extends StatelessWidget {
  const _StockRow({required this.name, required this.quantity, required this.price});

  final String name;
  final int quantity;
  final int price;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
          Text('Stok $quantity'),
          const SizedBox(width: 18),
          Text('Jual $price syiling'),
        ],
      ),
    );
  }
}

class _BuyRow extends StatelessWidget {
  const _BuyRow({
    required this.name,
    required this.description,
    required this.price,
    required this.onBuy,
  });

  final String name;
  final String description;
  final int price;
  final VoidCallback onBuy;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text(description, style: const TextStyle(color: Colors.black65)),
                ],
              ),
            ),
            const SizedBox(width: 20),
            FilledButton(
              onPressed: onBuy,
              child: Text('BELI $price'),
            ),
          ],
        ),
      ),
    );
  }
}

class _LargePanel extends StatelessWidget {
  const _LargePanel({required this.title, required this.onClose, required this.child});

  final String title;
  final VoidCallback onClose;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 760, maxHeight: 520),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: AppTheme.parchment,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.ink, width: 4),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                IconButton(onPressed: onClose, icon: const Icon(Icons.close_rounded)),
              ],
            ),
            const Divider(thickness: 2),
            Flexible(child: SingleChildScrollView(child: child)),
          ],
        ),
      ),
    );
  }
}

class _DaySummaryLayer extends StatelessWidget {
  const _DaySummaryLayer({required this.game});

  final NpcLifeGame game;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DaySummary?>(
      valueListenable: game.daySummary,
      builder: (BuildContext context, DaySummary? summary, Widget? child) {
        if (summary == null) {
          return const SizedBox.shrink();
        }
        return _ModalScrim(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                color: AppTheme.parchment,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppTheme.ink, width: 4),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text('RINGKASAN HARI ${summary.day}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 18),
                  _SummaryLine(label: 'Barang terjual', value: '${summary.itemsSold}'),
                  _SummaryLine(label: 'Hasil jualan', value: '+${summary.salesRevenue} syiling'),
                  _SummaryLine(label: 'Perubahan reputasi', value: '+${summary.reputationChange}'),
                  const Divider(height: 28, thickness: 2),
                  Text(summary.eventNote, style: const TextStyle(fontSize: 17, height: 1.4)),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: game.continueNextDay,
                    icon: const Icon(Icons.wb_sunny_rounded),
                    label: const Text('MULAKAN HARI SETERUSNYA'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SummaryLine extends StatelessWidget {
  const _SummaryLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(label)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _ModalScrim extends StatelessWidget {
  const _ModalScrim({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.black.withValues(alpha: 0.58),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: child,
        ),
      ),
    );
  }
}
