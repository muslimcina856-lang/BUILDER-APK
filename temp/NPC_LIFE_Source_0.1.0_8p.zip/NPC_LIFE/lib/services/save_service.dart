import 'package:shared_preferences/shared_preferences.dart';

import '../models/game_state.dart';

class SaveService {
  static const String _saveKey = 'npc_life_save_v1';

  Future<bool> hasSave() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_saveKey);
  }

  Future<GameState?> load() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? raw = prefs.getString(_saveKey);
    if (raw == null || raw.isEmpty) {
      return null;
    }
    try {
      return GameState.decode(raw);
    } on FormatException {
      return null;
    } on TypeError {
      return null;
    }
  }

  Future<void> save(GameState state) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_saveKey, state.encode());
  }

  Future<void> delete() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove(_saveKey);
  }
}
