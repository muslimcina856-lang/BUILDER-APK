enum ItemCategory { food, medicine, material, quest }

class ItemDefinition {
  const ItemDefinition({
    required this.id,
    required this.nameMs,
    required this.nameEn,
    required this.category,
    required this.baseBuyPrice,
    required this.baseSellPrice,
    required this.descriptionMs,
  });

  final String id;
  final String nameMs;
  final String nameEn;
  final ItemCategory category;
  final int baseBuyPrice;
  final int baseSellPrice;
  final String descriptionMs;
}

const Map<String, ItemDefinition> itemCatalog = <String, ItemDefinition>{
  'bread': ItemDefinition(
    id: 'bread',
    nameMs: 'Roti Luma',
    nameEn: 'Luma Bread',
    category: ItemCategory.food,
    baseBuyPrice: 3,
    baseSellPrice: 5,
    descriptionMs: 'Makanan harian yang murah dan sentiasa diperlukan.',
  ),
  'potion': ItemDefinition(
    id: 'potion',
    nameMs: 'Ramuan Kecil',
    nameEn: 'Small Potion',
    category: ItemCategory.medicine,
    baseBuyPrice: 8,
    baseSellPrice: 12,
    descriptionMs: 'Ramuan asas untuk luka ringan dan pengembara cuai.',
  ),
  'wood': ItemDefinition(
    id: 'wood',
    nameMs: 'Kayu Pembaikan',
    nameEn: 'Repair Wood',
    category: ItemCategory.material,
    baseBuyPrice: 4,
    baseSellPrice: 2,
    descriptionMs: 'Papan kering yang sesuai untuk membaiki rak dan gerai.',
  ),
};
