class DaySummary {
  const DaySummary({
    required this.day,
    required this.salesRevenue,
    required this.itemsSold,
    required this.reputationChange,
    required this.eventNote,
  });

  final int day;
  final int salesRevenue;
  final int itemsSold;
  final int reputationChange;
  final String eventNote;
}
