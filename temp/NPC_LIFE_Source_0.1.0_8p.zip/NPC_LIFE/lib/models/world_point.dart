class WorldPoint {
  const WorldPoint(this.x, this.y);

  final double x;
  final double y;
}
