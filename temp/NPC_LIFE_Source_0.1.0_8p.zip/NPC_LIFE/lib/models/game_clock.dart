class GameClock {
  GameClock({
    this.day = 1,
    this.minuteOfDay = 360,
    this.minutesPerSecond = 1.2,
  });

  int day;
  double minuteOfDay;
  final double minutesPerSecond;

  int get minute => minuteOfDay.floor();
  int get hour => minute ~/ 60;
  int get minutePart => minute % 60;
  bool get isNight => hour < 6 || hour >= 20;
  bool get isBusinessHours => minute >= 480 && minute < 1200;
  bool get shouldEndDay => minute >= 1380;

  String get formattedTime =>
      '${hour.toString().padLeft(2, '0')}:${minutePart.toString().padLeft(2, '0')}';

  bool advance(double dt) {
    final int before = minute;
    minuteOfDay += dt * minutesPerSecond;
    return minute != before;
  }

  void startNextDay() {
    day += 1;
    minuteOfDay = 360;
  }

  Map<String, Object> toJson() => <String, Object>{
        'day': day,
        'minuteOfDay': minuteOfDay,
      };

  factory GameClock.fromJson(Map<String, dynamic> json) => GameClock(
        day: json['day'] as int? ?? 1,
        minuteOfDay: (json['minuteOfDay'] as num?)?.toDouble() ?? 360,
      );
}
