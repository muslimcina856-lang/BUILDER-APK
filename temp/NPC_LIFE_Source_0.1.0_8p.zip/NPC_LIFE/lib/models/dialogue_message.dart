class DialogueMessage {
  const DialogueMessage({
    required this.speaker,
    required this.text,
    this.detail,
  });

  final String speaker;
  final String text;
  final String? detail;
}
