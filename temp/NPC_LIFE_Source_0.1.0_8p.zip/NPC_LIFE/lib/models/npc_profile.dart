class ScheduleEntry {
  const ScheduleEntry({
    required this.startMinute,
    required this.endMinute,
    required this.locationId,
    required this.activityMs,
  });

  final int startMinute;
  final int endMinute;
  final String locationId;
  final String activityMs;

  bool contains(int minute) => minute >= startMinute && minute < endMinute;
}

class NpcProfile {
  const NpcProfile({
    required this.id,
    required this.name,
    required this.roleMs,
    required this.personalityMs,
    required this.homeLocationId,
    required this.schedule,
    required this.dialogueMs,
    required this.eventResponseLocationId,
    required this.eventResponseMs,
  });

  final String id;
  final String name;
  final String roleMs;
  final String personalityMs;
  final String homeLocationId;
  final List<ScheduleEntry> schedule;
  final List<String> dialogueMs;
  final String eventResponseLocationId;
  final String eventResponseMs;

  ScheduleEntry scheduleAt(int minute) {
    for (final ScheduleEntry entry in schedule) {
      if (entry.contains(minute)) {
        return entry;
      }
    }
    return ScheduleEntry(
      startMinute: 0,
      endMinute: 1440,
      locationId: homeLocationId,
      activityMs: 'berehat di rumah',
    );
  }
}
