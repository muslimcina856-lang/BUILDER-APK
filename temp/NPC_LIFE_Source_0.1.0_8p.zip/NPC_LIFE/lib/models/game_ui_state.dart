class GameUiState {
  const GameUiState({
    required this.day,
    required this.time,
    required this.coins,
    required this.reputation,
    required this.bread,
    required this.potion,
    required this.wood,
    required this.objective,
    required this.shopAttended,
  });

  final int day;
  final String time;
  final int coins;
  final int reputation;
  final int bread;
  final int potion;
  final int wood;
  final String objective;
  final bool shopAttended;
}
