enum GamePanelMode { playerShop, warehouse }
