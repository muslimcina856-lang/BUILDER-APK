import 'dart:convert';

import 'game_clock.dart';

class GameState {
  GameState({
    GameClock? clock,
    this.coins = 40,
    this.reputation = 0,
    Map<String, int>? inventory,
    Map<String, int>? relationships,
    Set<String>? flags,
  })  : clock = clock ?? GameClock(),
        inventory = inventory ?? <String, int>{'bread': 5, 'potion': 3, 'wood': 3},
        relationships = relationships ?? <String, int>{},
        flags = flags ?? <String>{};

  final GameClock clock;
  int coins;
  int reputation;
  final Map<String, int> inventory;
  final Map<String, int> relationships;
  final Set<String> flags;

  int itemCount(String itemId) => inventory[itemId] ?? 0;

  void addItem(String itemId, int amount) {
    inventory[itemId] = itemCount(itemId) + amount;
  }

  bool removeItem(String itemId, int amount) {
    if (itemCount(itemId) < amount) {
      return false;
    }
    inventory[itemId] = itemCount(itemId) - amount;
    return true;
  }

  void changeRelationship(String npcId, int delta) {
    relationships[npcId] = ((relationships[npcId] ?? 0) + delta).clamp(0, 100).toInt();
  }

  String encode() => jsonEncode(toJson());

  Map<String, Object> toJson() => <String, Object>{
        'clock': clock.toJson(),
        'coins': coins,
        'reputation': reputation,
        'inventory': inventory,
        'relationships': relationships,
        'flags': flags.toList(growable: false),
      };

  factory GameState.decode(String value) {
    final Map<String, dynamic> json = jsonDecode(value) as Map<String, dynamic>;
    return GameState.fromJson(json);
  }

  factory GameState.fromJson(Map<String, dynamic> json) => GameState(
        clock: GameClock.fromJson(json['clock'] as Map<String, dynamic>? ?? <String, dynamic>{}),
        coins: json['coins'] as int? ?? 40,
        reputation: json['reputation'] as int? ?? 0,
        inventory: (json['inventory'] as Map<String, dynamic>? ?? <String, dynamic>{})
            .map((String key, dynamic value) => MapEntry<String, int>(key, value as int)),
        relationships: (json['relationships'] as Map<String, dynamic>? ?? <String, dynamic>{})
            .map((String key, dynamic value) => MapEntry<String, int>(key, value as int)),
        flags: (json['flags'] as List<dynamic>? ?? <dynamic>[]).cast<String>().toSet(),
      );
}
