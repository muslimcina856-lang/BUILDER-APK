import 'package:flutter_test/flutter_test.dart';
import 'package:npc_life/game/systems/economy_system.dart';
import 'package:npc_life/models/game_state.dart';

void main() {
  test('jualan hanya berlaku apabila kaunter dijaga', () {
    final GameState state = GameState();
    state.clock.minuteOfDay = 540;
    final EconomySystem economy = EconomySystem(state);

    expect(
      economy.update(
        minuteChanged: true,
        shopAttended: true,
        emergencyActive: false,
      ),
      isNull,
    );

    state.clock.minuteOfDay = 585;
    expect(
      economy.update(
        minuteChanged: true,
        shopAttended: false,
        emergencyActive: false,
      ),
      isNull,
    );
    expect(state.coins, 40);

    state.clock.minuteOfDay = 630;
    final SaleResult? sale = economy.update(
      minuteChanged: true,
      shopAttended: true,
      emergencyActive: false,
    );
    expect(sale, isNotNull);
    expect(state.coins, greaterThan(40));
    expect(economy.ledger.itemsSold, 1);
  });
}
