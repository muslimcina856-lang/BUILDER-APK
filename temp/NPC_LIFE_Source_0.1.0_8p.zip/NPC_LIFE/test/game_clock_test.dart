import 'package:flutter_test/flutter_test.dart';
import 'package:npc_life/models/game_clock.dart';

void main() {
  test('masa bergerak pada kadar yang ditetapkan', () {
    final GameClock clock = GameClock(minuteOfDay: 360, minutesPerSecond: 1.2);
    clock.advance(50);
    expect(clock.minute, 420);
    expect(clock.formattedTime, '07:00');
  });

  test('hari baharu bermula pada 06:00', () {
    final GameClock clock = GameClock(day: 3, minuteOfDay: 1380);
    clock.startNextDay();
    expect(clock.day, 4);
    expect(clock.formattedTime, '06:00');
  });
}
