import 'package:flutter_test/flutter_test.dart';
import 'package:npc_life/game/systems/event_director.dart';
import 'package:npc_life/models/game_state.dart';

void main() {
  test('kejadian hero hanya bermula sekali pada hari pertama', () {
    final GameState state = GameState();
    final EventDirector director = EventDirector(state);
    state.clock.minuteOfDay = 989;
    expect(director.shouldTriggerMarketBlast(), isFalse);

    state.clock.minuteOfDay = 990;
    expect(director.shouldTriggerMarketBlast(), isTrue);
    director.markMarketBlastStarted();
    expect(director.shouldTriggerMarketBlast(), isFalse);
  });
}
