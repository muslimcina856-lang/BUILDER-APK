import 'package:flutter_test/flutter_test.dart';
import 'package:npc_life/models/game_state.dart';

void main() {
  test('inventori tidak boleh menjadi negatif', () {
    final GameState state = GameState();
    expect(state.removeItem('wood', 4), isFalse);
    expect(state.itemCount('wood'), 3);
    expect(state.removeItem('wood', 2), isTrue);
    expect(state.itemCount('wood'), 1);
  });

  test('save state boleh dipulihkan tanpa kehilangan data', () {
    final GameState state = GameState();
    state.coins = 91;
    state.reputation = 12;
    state.flags.add('event_complete');
    state.changeRelationship('mira', 7);

    final GameState restored = GameState.decode(state.encode());
    expect(restored.coins, 91);
    expect(restored.reputation, 12);
    expect(restored.flags, contains('event_complete'));
    expect(restored.relationships['mira'], 7);
  });
}
