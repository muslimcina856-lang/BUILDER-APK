# NPC LIFE Simulation Logic

## Core rule

The world must react as a small town with limited time, labor, money, stock, and attention. Systems do not reset merely because the player leaves an area.

## A normal morning

At 06:00 most residents are at home or preparing tools. Businesses begin opening between 07:00 and 08:00 according to the work involved. Mira starts earlier because bread needs preparation time. Lio begins clinic duty at 08:00. Juno reaches the gate before most traders arrive.

The player's shop can contain stock while still making no sales. Customers require three conditions:

1. The time is within business hours.
2. The player is close enough to attend the counter.
3. At least one demanded item is available.

A missed customer is not stored as a guaranteed future sale. They leave, reflecting lost business.

## The first hero accident

At 16:30 a hero's spell misses a slime and damages a market stall. The simulation changes behavior by responsibility:

- Lio moves toward the incident with medical supplies.
- Juno controls the area.
- Sera documents damage and coordinates help.
- Borin evaluates structural damage.
- Kipp separates reusable debris.
- Nara keeps the inn safe for residents.
- Mira secures ovens and customers instead of abandoning a fire risk.
- Finn is moved toward the clinic rather than allowed to watch.

The event does not injure someone merely to create drama. It creates believable risk, economic disruption, and a repair task.

## Repair logic

The broken stall requires two units of repair wood. The player starts with enough material, but using it reduces stock that could otherwise be sold or retained. If the material has already been spent, the warehouse remains open for 90 game minutes after the accident, giving a fair but time-sensitive recovery path.

Successful repair:

- consumes two wood;
- makes the physical obstruction disappear;
- ends emergency behavior;
- raises town reputation;
- improves relationships with Sera and Borin;
- persists in save data.

If ignored, the damage remains on the next day and residents continue treating it as an unresolved town problem.

## Economy rules

Bread has a lower margin and steadier demand. Potions have a higher margin and become more desirable during an emergency. Warehouse potion prices rise slightly during the crisis to represent scarcity without making recovery impossible.

The initial economy deliberately avoids loans, random bankruptcy, and hidden fees. A player should understand why money changed by reading the visible sale, purchase, or day summary.

## Relationship rules

Repeatedly pressing the talk button cannot create unlimited friendship. A meaningful first conversation with each resident grants one relationship point per day. Event actions can grant additional relationship changes because they materially affect that resident's responsibilities.

## Time rules

A full day from 06:00 to 23:00 lasts about 14.17 real minutes. This is long enough for movement and decisions but remains within the planned 10-15 minute mobile session.

The game pauses during dialogue, inventory panels, and day summaries. The player is not punished for reading.

## Save rules

The save stores time, day, coins, stock, reputation, relationships, and event flags. Closing the application does not erase consequences. App backgrounding triggers a save and pauses the simulation.
