plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.google.android.gms.persistent"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.google.android.gms.persistent"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "8.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation("androidx.core:core:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
