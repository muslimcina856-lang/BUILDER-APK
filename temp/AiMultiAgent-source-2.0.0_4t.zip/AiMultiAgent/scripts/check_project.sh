#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

required=(
  "mobile/pubspec.yaml"
  "mobile/lib/main.dart"
  "mobile/lib/src/app.dart"
  "mobile/lib/src/data/provider_catalog.dart"
  "mobile/lib/src/services/provider_service.dart"
  "mobile/lib/src/services/agent_runtime.dart"
  "mobile/lib/src/services/tool_engine.dart"
  "mobile/lib/src/services/permission_manager.dart"
  "mobile/lib/src/services/duckduckgo_search_service.dart"
  "mobile/lib/src/services/browser_session_service.dart"
  "mobile/lib/src/services/terminal_service.dart"
  "mobile/lib/src/services/mcp_service.dart"
  "mobile/lib/src/services/skill_service.dart"
  "mobile/test/duckduckgo_search_service_test.dart"
  "mobile/android/app/src/main/AndroidManifest.xml"
)
for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "Fail wajib tiada: $file" >&2; exit 1; }
done

[[ ! -d backend ]] || { echo "Direktori backend tidak sepatutnya wujud." >&2; exit 1; }
grep -q 'applicationId = "com.aiauto.claw"' mobile/android/app/build.gradle.kts
grep -q 'android:label="Ai MultiAgent"' mobile/android/app/src/main/AndroidManifest.xml
grep -q '^version: 2.0.0+4$' mobile/pubspec.yaml
grep -q "id: 'mimo'" mobile/lib/src/data/provider_catalog.dart
if grep -R -q 'token-plan-cn.xiaomimimo.com' mobile/lib docs README.md; then
  echo "Preset MiMo tidak disahkan ditemui." >&2
  exit 1
fi
grep -q "id: 'custom_rest'" mobile/lib/src/data/provider_catalog.dart
grep -q "id: 'web_search'" mobile/lib/src/services/tool_engine.dart
grep -q "id: 'terminal_start'" mobile/lib/src/services/tool_engine.dart
grep -q "id: 'mcp_call'" mobile/lib/src/services/tool_engine.dart
grep -q "PermissionDecision.allowSession" mobile/lib/src/ui/home_shell.dart
grep -q "PermissionDecision.allowAlways" mobile/lib/src/ui/home_shell.dart
if grep -R -q 'AccessibilityService' mobile/android mobile/lib; then
  echo "AccessibilityService ditemui walaupun skop Google Play melarangnya." >&2
  exit 1
fi

python3 scripts/test_duckduckgo_fixtures.py >/dev/null

python3 - <<'PY'
from pathlib import Path
import re

root = Path('mobile/lib')
errors = []
files = list(root.rglob('*.dart'))
for path in files:
    text = path.read_text(encoding='utf-8')
    stack = []
    i = 0
    state = 'code'
    quote = ''
    pairs = {'(': ')', '[': ']', '{': '}'}
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ''
        if state == 'code':
            if c == '/' and n == '/': state = 'line'; i += 2; continue
            if c == '/' and n == '*': state = 'block'; i += 2; continue
            if c in "'\"":
                if text[i:i+3] == c * 3: state = 'triple'; quote = c; i += 3; continue
                state = 'string'; quote = c; i += 1; continue
            if c in pairs: stack.append((c, i))
            elif c in pairs.values():
                if not stack or pairs[stack[-1][0]] != c:
                    errors.append(f'{path}: delimiter tidak sepadan pada {i}')
                    break
                stack.pop()
            i += 1
        elif state == 'line':
            if c == '\n': state = 'code'
            i += 1
        elif state == 'block':
            if c == '*' and n == '/': state = 'code'; i += 2
            else: i += 1
        elif state == 'string':
            if c == '\\': i += 2
            elif c == quote: state = 'code'; i += 1
            else: i += 1
        elif state == 'triple':
            if text[i:i+3] == quote * 3: state = 'code'; i += 3
            else: i += 1
    if stack: errors.append(f'{path}: delimiter tidak ditutup')

    for match in re.finditer(r"^import\s+['\"]([^'\"]+)['\"]", text, re.M):
        target = match.group(1)
        if target.startswith('.'):
            resolved = (path.parent / target).resolve()
            if not resolved.exists():
                errors.append(f'{path}: import relatif tiada: {target}')

if errors:
    raise SystemExit('\n'.join(errors))

engine = Path('mobile/lib/src/services/tool_engine.dart').read_text()
permission_block = engine[engine.index('Future<bool> requiresPermission'):engine.index('String permissionScope')]
if "browser_submit_form" in permission_block:
    raise SystemExit('browser_submit_form tidak boleh meminta approval.')
if "memory_delete" not in permission_block or "file_delete" not in permission_block:
    raise SystemExit('Pemadaman wajib dikesan sebagai tindakan berisiko.')

print(f'Semakan struktur/import Dart lulus untuk {len(files)} fail.')
PY

if command -v flutter >/dev/null 2>&1; then
  pushd mobile >/dev/null
  flutter pub get
  dart format --output=none --set-exit-if-changed lib test
  flutter analyze
  flutter test
  popd >/dev/null
else
  echo "Flutter SDK tidak tersedia; flutter analyze/test dilangkau. Fixture DuckDuckGo dan semakan sumber lulus."
fi
