# Changelog

## 2.0.0+4 — 2026-08-02

- Menukar aplikasi kepada local/BYOK sepenuhnya tanpa login dan tanpa backend.
- Menambah katalog provider luas, Xiaomi MiMo, model dinamik dan Custom Provider.
- Menambah ujian sambungan automatik ketika provider disimpan.
- Menambah OpenAI Chat, OpenAI Responses, Anthropic, Gemini dan Custom REST adapters.
- Menambah DuckDuckGo Search HTML/Lite dengan hasil JSON penuh dan fixture tests.
- Menambah browser WebView kelihatan, cookies local, DOM, klik, input dan submit borang.
- Menambah terminal latar belakang dengan polling `stdout`/`stderr` untuk AI.
- Menambah MCP local, pemasangan skill URL automatik dan skrip skill sandbox.
- Menambah delegasi sub-agent tanpa had tetap aplikasi.
- Mengubah kelulusan supaya hanya tindakan destruktif/penimpaan meminta dialog.
- Menambah kelulusan sekali, sesi menyeluruh dan persistent tool+skop.
- Menambah sesi tamat selepas 30 minit dan proses baharu apabila background tidak dibenarkan.
- Menambah log tool local dengan ringkasan secret-redacted.
- Mengekalkan build Google Play tanpa Accessibility Service.

## 1.0.0 — 2026-08-02

- Release candidate awal sebelum reka bentuk local/BYOK dimuktamadkan.
