# Adaptive Chess

Adaptive Chess ialah aplikasi catur Android luar talian yang membina profil tabiat pemain dan
menggunakan profil itu untuk mengubah strategi lawan dari satu permainan ke permainan berikutnya.

## Ciri utama

- Papan dan bidak OpenGL ES 3D sebenar dengan mesh Staunton prosedural, depth buffer, pencahayaan,
  bayang, gerakan perlahan yang lancar, variasi bunyi kayu semula jadi dan kamera hampir pandangan atas.
- Pemain memilih bidak putih atau hitam sebelum permainan pertama dan selepas kalah atau seri;
  kemenangan meneruskan warna yang sama ke level berikutnya.
- Enjin minimax alpha-beta dengan iterative deepening dan had masa.
- Peraturan castling, en passant, promosi, stalemate, material tidak mencukupi, peraturan 50 langkah
  dan pengulangan tiga kali.
- FEN lengkap termasuk giliran, hak castling, en passant dan kiraan langkah.
- Pembelajaran berterusan untuk corak pembukaan, menteri keluar awal, gerakan bidak berlebihan,
  kelemahan sisi raja, kelewatan castling dan kecenderungan pertukaran.
- Sejarah permainan dan statistik pemain disimpan secara setempat menggunakan Room.
- Sejarah hanya memaparkan satu permainan aktif selepas langkah pertama pemain; setiap rekod
  boleh ditekan untuk melihat analisis yang dipelajari bot.
- Tempoh bermain hanya mula dikira selepas langkah pertama pemain, termasuk apabila bot memulakan
  permainan kerana pemain memilih bidak hitam.
- Halaman Prestasi menyediakan bahagian About dengan kredit kepada Earlxz dan pilihan sokongan
  pembangunan secara sukarela, serta butang chat dan channel Telegram yang dibuka melalui intent
  luaran dengan pengendalian kegagalan yang selamat.
- Kemenangan Level 999 membuka Hall of Mastery kekal dengan penghargaan, analisis akhir dan
  mesej daripada bot; tiada butang permainan baharu selepas tahap tertinggi ditakluki.

## Cara pembelajaran berfungsi

Selepas permainan tamat, `PatternAnalyzer` mengesan beberapa corak daripada langkah pemain.
`AnalyzePatternsUseCase` menyimpan kekerapan dan keberkesanan strategi balas. Pada permainan
seterusnya, `AdaptiveLearner` menggabungkan data tersebut ke dalam berat agresif, pertahanan dan
posisi yang digunakan terus oleh `MinimaxEngine`.

## Build

1. Buka folder projek dalam Android Studio dengan JDK 17.
2. Sync Gradle.
3. Jalankan `testDebugUnitTest` untuk ujian peraturan dan pembelajaran.
4. Jalankan konfigurasi `app` pada peranti atau emulator Android 8.0 ke atas.

APK release sengaja tidak menggunakan debug signing. Sediakan signing config sendiri sebelum
menerbitkan aplikasi. Binaan release menggunakan R8 full mode, pengoptimuman, obfuscation dan
resource shrinking; simpan fail `mapping.txt` bagi setiap keluaran untuk proses retrace. Ikon
512×512 untuk Play Console tersedia di `play-store-assets/icon-512.png`, manakala panduan
perlindungan penerbitan berada dalam `PLAY_STORE_SECURITY.md`.
