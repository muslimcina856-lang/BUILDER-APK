package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.dao.PatternDefinitionDao
import com.chessbot.adapt.data.local.dao.PlayerPatternStatsDao
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.PatternDefinition
import com.chessbot.adapt.data.local.entity.PlayerPatternStats
import com.chessbot.adapt.domain.model.*
import com.chessbot.adapt.domain.usecase.AnalyzePatternsUseCase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalyzePatternsUseCaseTest {

    @Test
    fun detectedPatternsArePersistedAndEvolveAfterAnotherGame() = runBlocking {
        val definitions = listOf(
            definition(1, "OPENING_KING_PAWN"),
            definition(2, "EARLY_QUEEN"),
            definition(3, "OPENING_UNSTRUCTURED")
        )
        val definitionDao = FakePatternDefinitionDao(definitions)
        val statsDao = FakeStatsDao()
        val learningDao = FakeLearningDao()
        val useCase = AnalyzePatternsUseCase(
            PatternAnalyzer(), definitionDao, statsDao, learningDao
        )
        val pawn = Piece(PieceType.PAWN, Color.WHITE)
        val queen = Piece(PieceType.QUEEN, Color.WHITE)
        val moves = listOf(
            Move(Square(4, 1), Square(4, 3), pawn),
            Move(Square(3, 0), Square(7, 4), queen)
        )

        useCase(1, Color.WHITE, moves, "WIN")
        val first = learningDao.rows.values.first { it.counterStrategy == "EARLY_QUEEN" }
        assertTrue(first.aggressionModifier > 0f)
        assertEquals(1, first.timesApplied)

        useCase(1, Color.WHITE, moves, "LOSS")
        val evolved = learningDao.rows.values.first { it.counterStrategy == "EARLY_QUEEN" }
        assertEquals(2, evolved.timesApplied)
        assertEquals(1, evolved.successfulApplies)
        assertTrue(evolved.effectivenessScore > first.effectivenessScore)
        assertTrue(evolved.aggressionModifier != first.aggressionModifier)
        assertTrue(evolved.aggressionModifier > 0f)
    }

    private fun definition(id: Long, key: String) = PatternDefinition(
        id = id,
        patternKey = key,
        category = "TEST",
        name = key,
        detectionRules = "{}"
    )
}

private class FakePatternDefinitionDao(
    private val rows: List<PatternDefinition>
) : PatternDefinitionDao {
    override suspend fun getAllPatterns() = rows
    override suspend fun getPatternsByCategory(category: String) = rows.filter { it.category == category }
    override suspend fun getByKey(key: String) = rows.firstOrNull { it.patternKey == key }
    override suspend fun insertAll(patterns: List<PatternDefinition>) = Unit
}

private class FakeStatsDao : PlayerPatternStatsDao {
    private val rows = mutableMapOf<Pair<Long, Long>, PlayerPatternStats>()
    override suspend fun getStatsForPlayer(playerId: Long) = rows.values.filter { it.playerId == playerId }
    override suspend fun upsert(stats: PlayerPatternStats) {
        rows[stats.playerId to stats.patternId] = stats
    }
    override suspend fun getStats(playerId: Long, patternId: Long) = rows[playerId to patternId]
}

private class FakeLearningDao : BotLearningDataDao {
    val rows = mutableMapOf<Pair<Long, Long>, BotLearningData>()
    override suspend fun getLearningDataForPlayer(playerId: Long) =
        rows.values.filter { it.playerId == playerId }
    override suspend fun getLearningData(playerId: Long, patternId: Long) = rows[playerId to patternId]
    override suspend fun upsert(data: BotLearningData) {
        rows[data.playerId to data.patternId] = data
    }
}
