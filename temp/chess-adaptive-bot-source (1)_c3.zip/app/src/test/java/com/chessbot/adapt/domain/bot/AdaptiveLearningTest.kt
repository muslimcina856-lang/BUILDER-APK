package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Piece
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Square
import org.junit.Assert.assertTrue
import org.junit.Test

class AdaptiveLearningTest {

    @Test
    fun earlyQueenAndPawnHeavyPatternsAreDetected() {
        val whitePawn = Piece(PieceType.PAWN, Color.WHITE)
        val blackPawn = Piece(PieceType.PAWN, Color.BLACK)
        val whiteQueen = Piece(PieceType.QUEEN, Color.WHITE)
        val moves = listOf(
            Move(Square(4, 1), Square(4, 3), whitePawn),
            Move(Square(4, 6), Square(4, 4), blackPawn),
            Move(Square(3, 0), Square(7, 4), whiteQueen),
            Move(Square(1, 6), Square(1, 5), blackPawn),
            Move(Square(0, 1), Square(0, 2), whitePawn),
            Move(Square(2, 6), Square(2, 5), blackPawn),
            Move(Square(1, 1), Square(1, 2), whitePawn),
            Move(Square(3, 6), Square(3, 5), blackPawn),
            Move(Square(2, 1), Square(2, 2), whitePawn),
            Move(Square(5, 6), Square(5, 5), blackPawn),
            Move(Square(5, 1), Square(5, 2), whitePawn)
        )

        val keys = PatternAnalyzer().detectPlayerPatterns(moves, Color.WHITE).map { it.key }
        assertTrue("EARLY_QUEEN" in keys)
        assertTrue("PAWN_HEAVY" in keys)
        assertTrue("OPENING_KING_PAWN" in keys)
    }

    @Test
    fun storedLearningChangesEngineWeights() {
        val base = EvalWeights(aggression = 0.6f, defense = 0.6f, position = 1f)
        val learned = BotLearningData(
            playerId = 1,
            patternId = 1,
            counterStrategy = "EARLY_QUEEN",
            timesApplied = 6,
            effectivenessScore = 0.5f,
            aggressionModifier = 0.2f,
            defenseModifier = 0.1f,
            positionWeightModifier = 0.15f
        )
        val adjusted = AdaptiveLearner().adjustWeights(base, listOf(learned), enabled = true)
        assertTrue(adjusted.aggression > base.aggression)
        assertTrue(adjusted.defense > base.defense)
        assertTrue(adjusted.position > base.position)
    }
}
