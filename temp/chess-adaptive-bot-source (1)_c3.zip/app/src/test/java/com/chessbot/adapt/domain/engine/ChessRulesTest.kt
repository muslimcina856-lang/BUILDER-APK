package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Square
import org.junit.Assert.*
import org.junit.Test

class ChessRulesTest {
    private val engine = ChessEngineImpl()

    @Test
    fun initialPositionHasTwentyLegalWhiteMoves() {
        val board = engine.initializeBoard()
        val moves = (0..7).flatMap { rank ->
            (0..7).flatMap { file ->
                val square = Square(file, rank)
                if (board.squares[rank][file]?.color == Color.WHITE) engine.getValidMoves(board, square)
                else emptyList()
            }
        }
        assertEquals(20, moves.size)
        assertEquals(400L, perft(board, 2))
    }

    @Test
    fun castlingIsGeneratedAndMovesTheRook() {
        val board = engine.fromFEN("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        val kingMoves = engine.getValidMoves(board, Square.fromAlgebraic("e1")!!)
        assertTrue(kingMoves.any { it.toSquare == Square.fromAlgebraic("g1") && it.isCastleKingSide })
        assertTrue(kingMoves.any { it.toSquare == Square.fromAlgebraic("c1") && it.isCastleQueenSide })

        val castling = kingMoves.first { it.isCastleKingSide }
        val next = engine.makeMove(board, castling)
        assertEquals(PieceType.KING, next.squares[0][6]?.type)
        assertEquals(PieceType.ROOK, next.squares[0][5]?.type)
        assertNull(next.squares[0][7])
        assertFalse(next.whiteCanCastleKingSide)
        assertFalse(next.whiteCanCastleQueenSide)
    }

    @Test
    fun castlingThroughAnAttackedSquareIsRejected() {
        val board = engine.fromFEN("r3kr1r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        val kingMoves = engine.getValidMoves(board, Square.fromAlgebraic("e1")!!)
        assertFalse(kingMoves.any { it.isCastleKingSide })
    }

    @Test
    fun enPassantRemovesThePassedPawn() {
        val board = engine.fromFEN("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2")
        val move = engine.getValidMoves(board, Square.fromAlgebraic("e5")!!)
            .first { it.toSquare == Square.fromAlgebraic("d6") }
        assertTrue(move.isEnPassant)

        val next = engine.makeMove(board, move)
        assertEquals(PieceType.PAWN, next.squares[5][3]?.type)
        assertNull(next.squares[4][3])
    }

    @Test
    fun fenRoundTripPreservesCompletePositionState() {
        val fen = "r3k2r/ppp2ppp/2n5/3pp3/3PP3/2N5/PPP2PPP/R3K2R b KQkq e3 17 24"
        assertEquals(fen, engine.toFEN(engine.fromFEN(fen)))
    }

    @Test
    fun fiftyMoveRuleIsDetected() {
        val board = engine.fromFEN("4k3/8/8/8/8/8/8/4K2R w - - 100 61")
        assertTrue(engine.isDraw(board))
    }

    @Test
    fun threefoldRepetitionIsDetected() {
        var board = engine.initializeBoard()
        repeat(2) {
            board = play(board, "g1", "f3")
            board = play(board, "g8", "f6")
            board = play(board, "f3", "g1")
            board = play(board, "f6", "g8")
        }
        assertTrue(engine.isDraw(board))
    }

    private fun play(
        board: com.chessbot.adapt.domain.model.Board,
        from: String,
        to: String
    ): com.chessbot.adapt.domain.model.Board {
        val move = engine.getValidMoves(board, Square.fromAlgebraic(from)!!)
            .first { it.toSquare == Square.fromAlgebraic(to) }
        return engine.makeMove(board, move)
    }

    private fun perft(board: com.chessbot.adapt.domain.model.Board, depth: Int): Long {
        if (depth == 0) return 1
        var nodes = 0L
        for (rank in 0..7) for (file in 0..7) {
            if (board.squares[rank][file]?.color != board.activeColor) continue
            engine.getValidMoves(board, Square(file, rank)).forEach { move ->
                nodes += perft(engine.makeMove(board, move), depth - 1)
            }
        }
        return nodes
    }
}
