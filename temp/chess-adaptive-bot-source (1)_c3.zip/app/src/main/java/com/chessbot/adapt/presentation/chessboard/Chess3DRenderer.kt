package com.chessbot.adapt.presentation.chessboard

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Piece
import com.chessbot.adapt.domain.model.Square
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Board
import kotlin.math.*

// ══════════════════════════════════════════════════════════════════════════════
//  VECTOR MATH  (inlined for performance — no boxing)
// ══════════════════════════════════════════════════════════════════════════════

internal data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3)     = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3)    = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    infix fun dot(o: V3)         = x*o.x + y*o.y + z*o.z
    infix fun cross(o: V3)       = V3(y*o.z - z*o.y, z*o.x - x*o.z, x*o.y - y*o.x)
    fun len()  = sqrt(x*x + y*y + z*z)
    fun norm() = len().let { l -> if (l > 1e-7f) this*(1f/l) else V3(0f,0f,0f) }
}

// Column-major 4×4 matrix multiply (a × b)
private fun mm(a: FloatArray, b: FloatArray): FloatArray {
    val r = FloatArray(16)
    for (row in 0..3) for (col in 0..3) {
        var s = 0f
        for (k in 0..3) s += a[row + k*4] * b[k + col*4]
        r[row + col*4] = s
    }
    return r
}

private fun perspM(fovDeg: Float, asp: Float, n: Float, f: Float): FloatArray {
    val h = 1f / tan(fovDeg * PI.toFloat() / 360f)
    return floatArrayOf(
        h/asp, 0f, 0f,  0f,
        0f,    h,  0f,  0f,
        0f,    0f, (f+n)/(n-f), -1f,
        0f,    0f, (2f*f*n)/(n-f), 0f
    )
}

private fun lookM(eye: V3): FloatArray {
    val f = (V3(0f,0f,0f) - eye).norm()
    val r = (f cross V3(0f,1f,0f)).norm()
    val u = r cross f
    return floatArrayOf(
        r.x, u.x, -f.x, 0f,
        r.y, u.y, -f.y, 0f,
        r.z, u.z, -f.z, 0f,
        -(r dot eye), -(u dot eye), (f dot eye), 1f
    )
}

// ── Public helpers used by ChessBoard3DView ───────────────────────────────────

internal fun camPos(theta: Float, phi: Float, radius: Float = 11.5f) = V3(
    radius * sin(phi) * sin(theta),
    radius * cos(phi),
    radius * sin(phi) * cos(theta)
)

internal fun vpMat(theta: Float, phi: Float, w: Float, h: Float): FloatArray {
    val eye = camPos(theta, phi)
    return mm(perspM(52f, w / h.coerceAtLeast(1f), 0.5f, 50f), lookM(eye))
}

internal fun prj(w: V3, vp: FloatArray, sw: Float, sh: Float): Offset? {
    val m  = vp
    val cx = m[0]*w.x + m[4]*w.y + m[8]*w.z  + m[12]
    val cy = m[1]*w.x + m[5]*w.y + m[9]*w.z  + m[13]
    val cw = m[3]*w.x + m[7]*w.y + m[11]*w.z + m[15]
    if (cw <= 0.01f) return null
    return Offset((cx/cw + 1f)*0.5f*sw, (1f - cy/cw)*0.5f*sh)
}

/** Ray-plane intersection → board Square. Returns null if tap misses board. */
internal fun tapToSquare(
    tx: Float, ty: Float, sw: Float, sh: Float,
    theta: Float, phi: Float
): Square? {
    if (sw <= 0f || sh <= 0f) return null
    val eye = camPos(theta, phi)
    val fwd = (V3(0f,0f,0f) - eye).norm()
    val rgt = (fwd cross V3(0f,1f,0f)).norm()
    val up  = rgt cross fwd
    val tanH = tan(52f * PI.toFloat() / 360f)
    val tanW = tanH * (sw / sh)
    val ndcX = (tx / sw) * 2f - 1f
    val ndcY = 1f - (ty / sh) * 2f
    val dv   = V3(ndcX * tanW, ndcY * tanH, -1f).norm()
    val dw   = V3(
        rgt.x*dv.x + up.x*dv.y - fwd.x*dv.z,
        rgt.y*dv.x + up.y*dv.y - fwd.y*dv.z,
        rgt.z*dv.x + up.z*dv.y - fwd.z*dv.z
    ).norm()
    if (abs(dw.y) < 1e-6f) return null
    val t = (TILE_H - eye.y) / dw.y
    if (t < 0f || t > 200f) return null
    val file = floor(eye.x + dw.x*t + 4f).toInt()
    val rank = floor(eye.z + dw.z*t + 4f).toInt()
    return if (file in 0..7 && rank in 0..7) Square(file, rank) else null
}

// ══════════════════════════════════════════════════════════════════════════════
//  CONSTANTS & PALETTE
// ══════════════════════════════════════════════════════════════════════════════

private const val TILE_HS  = 0.47f
internal const val TILE_H  = 0.18f
private const val FRAME_EX = 0.62f

// Background
private val cBg1 = Color(0xFF0D0F12); private val cBg2 = Color(0xFF171A1F)

// Board frame — dark walnut
private val cFrameTop  = Color(0xFF3E2008); private val cFrameSide = Color(0xFF261304)

// Light squares — warm maple
private val cLtTop  = Color(0xFFE2BF88); private val cLtTopHi = Color(0xFFF0D4A2)
private val cLtSide = Color(0xFFBB9865)

// Dark squares — rich mahogany
private val cDkTop  = Color(0xFF8C5726); private val cDkTopHi = Color(0xFF9E6330)
private val cDkSide = Color(0xFF6A3E18)

// White pieces — polished ivory
private val cWBase = Color(0xFFF3EDD8); private val cWHi = Color(0xFFFFFFFF)
private val cWShade= Color(0xFFC0B488)

// Black pieces — polished ebony
private val cBBase = Color(0xFF292724); private val cBHi = Color(0xFF74695A)
private val cBShade= Color(0xFF0B0C0D)

// UI accents
private val cSelect  = Color(0xFF76C8A5); private val cValid   = Color(0xFFD8B477)
private val cLast    = Color(0xFFE3C78F); private val cCheck   = Color(0xFFE07171)
private val cCapture = Color(0xFFE07171)

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN RENDER
// ══════════════════════════════════════════════════════════════════════════════

fun DrawScope.draw3DChessBoard(
    board:          Board?,
    selected:       Square?,
    validMoves:     List<Move>,
    lastMove:       Move?,
    isCheck:        Boolean,
    checkSideColor: com.chessbot.adapt.domain.model.Color?,
    cameraTheta:    Float,
    cameraPhi:      Float,
    selectedLift:   Float,
    animMove:       Move?,
    animProgress:   Float
) {
    val sw = size.width;  val sh = size.height
    if (sw <= 0f || sh <= 0f) return

    val vp  = vpMat(cameraTheta, cameraPhi, sw, sh)
    val eye = camPos(cameraTheta, cameraPhi)
    val cameraForward = (V3(0f, 0f, 0f) - eye).norm()
    val cameraRight = (cameraForward cross V3(0f, 1f, 0f)).norm()

    fun p(w: V3): Offset? = prj(w, vp, sw, sh)
    fun dist(w: V3): Float = (w - eye).len()

    val validTargets = validMoves.mapTo(HashSet()) { it.toSquare }

    // ── Background ────────────────────────────────────────────────────────────
    drawRect(Brush.radialGradient(
        listOf(cBg2, cBg1),
        center = Offset(sw*0.5f, sh*0.5f),
        radius = sw * 0.9f
    ))

    // ── Collect items ─────────────────────────────────────────────────────────
    data class RItem(val depth: Float, val fn: DrawScope.() -> Unit)
    val items = ArrayList<RItem>(100)

    // Board frame
    items += RItem(dist(V3(0f,0f,0f)) + 35f) {
        val hs = 4f + FRAME_EX
        val yT = TILE_H * 0.05f; val yB = -0.14f
        val c0 = arrayOf(V3(-hs,yT,-hs), V3(hs,yT,-hs), V3(hs,yT,hs), V3(-hs,yT,hs))
        val t  = c0.mapNotNull { p(it) }
        val b  = c0.mapNotNull { p(it.copy(y = yB)) }
        if (t.size == 4 && b.size == 4) {
            quad4(t[0],t[1],t[2],t[3], cFrameTop)
            quad4(t[2],t[3],b[3],b[2], cFrameSide)
            quad4(t[1],t[2],b[2],b[1], cFrameSide.copy(alpha=0.85f))
        }
    }

    // Tiles
    for (rank in 0..7) for (file in 0..7) {
        val sq    = Square(file, rank)
        val cx    = file - 3.5f;  val cz = rank - 3.5f
        val light = (file + rank) % 2 == 0
        val isSel     = selected == sq
        val isLastF   = lastMove?.fromSquare == sq
        val isLastT   = lastMove?.toSquare   == sq
        val isVT      = sq in validTargets
        val isKingChk = isCheck && checkSideColor != null &&
            board?.squares?.getOrNull(rank)?.getOrNull(file)?.let {
                it.type == PieceType.KING && it.color == checkSideColor
            } == true

        items += RItem(dist(V3(cx, TILE_H, cz))) {
            val x0 = cx-TILE_HS; val x1 = cx+TILE_HS
            val z0 = cz-TILE_HS; val z1 = cz+TILE_HS

            val tfl = p(V3(x0,TILE_H,z0)) ?: return@RItem
            val tfr = p(V3(x1,TILE_H,z0)) ?: return@RItem
            val tbr = p(V3(x1,TILE_H,z1)) ?: return@RItem
            val tbl = p(V3(x0,TILE_H,z1)) ?: return@RItem

            val side = if (light) cLtSide else cDkSide

            // Near side face
            val bbl = p(V3(x0,0f,z1)) ?: return@RItem
            val bbr = p(V3(x1,0f,z1)) ?: return@RItem
            quad4(tbl,tbr,bbr,bbl, side)
            // Right side face
            val bfr = p(V3(x1,0f,z0)) ?: return@RItem
            quad4(tfr,tbr,bbr,bfr, side.copy(alpha=0.88f))

            // Top face — diagonal wood-grain gradient
            val tilePath = Path().apply {
                moveTo(tfl.x,tfl.y); lineTo(tfr.x,tfr.y)
                lineTo(tbr.x,tbr.y); lineTo(tbl.x,tbl.y); close()
            }
            drawPath(tilePath, Brush.linearGradient(
                if (light) listOf(cLtTopHi, cLtTop) else listOf(cDkTopHi, cDkTop),
                start = tfl, end = tbr
            ))

            // Overlay
            val tint = when {
                isKingChk           -> cCheck
                isSel               -> cSelect
                isLastF || isLastT  -> cLast
                else                -> null
            }
            if (tint != null) quad4(tfl,tfr,tbr,tbl, tint, alpha=0.38f)

            // Valid-move: cyan dot (kosong) atau merah ring (boleh tangkap)
            if (isVT) {
                val cc      = p(V3(cx, TILE_H+0.01f, cz)) ?: return@RItem
                val rr      = ((tfr.x - tfl.x).absoluteValue * 0.15f).coerceIn(5f, 18f)
                val isCapSq = board?.squares?.getOrNull(rank)?.getOrNull(file) != null
                if (isCapSq) {
                    // MERAH — bidak musuh boleh ditangkap
                    drawCircle(cCapture, rr * 1.7f, cc, alpha = 0.18f)
                    drawCircle(cCapture, rr * 1.4f, cc, style = Stroke(rr * 0.34f), alpha = 0.95f)
                } else {
                    // CYAN — petak kosong boleh diduduki
                    drawCircle(cValid, rr * 1.1f, cc, alpha = 0.90f)
                    drawCircle(cValid, rr * 0.45f, cc, alpha = 0.55f)
                }
            }
        }
    }

    // Pieces
    if (board != null) {
        val movingAnimation = animMove
        val isAnimating = movingAnimation != null && animProgress < 1f
        val animDstSq = if (isAnimating) movingAnimation?.toSquare else null
        val castleRank = movingAnimation?.let {
            if (it.piece.color == com.chessbot.adapt.domain.model.Color.WHITE) 0 else 7
        }
        val castleRookDst = when {
            !isAnimating -> null
            movingAnimation?.isCastleKingSide == true -> Square(5, castleRank ?: 0)
            movingAnimation?.isCastleQueenSide == true -> Square(3, castleRank ?: 0)
            else -> null
        }

        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            val sq    = Square(file, rank)
            if (sq == selected || sq == animDstSq || sq == castleRookDst) continue

            val cx = file - 3.5f; val cz = rank - 3.5f
            val ph = pHeight(piece.type)
            items += RItem(dist(V3(cx, TILE_H + ph*0.5f, cz))) {
                piece3D(piece, cx, cz, 0f, ph, ::p, cameraRight)
            }
        }

        // Animated piece — arcing through air
        if (movingAnimation != null && isAnimating) {
            val dstPiece = board.squares.getOrNull(movingAnimation.toSquare.rank)
                ?.getOrNull(movingAnimation.toSquare.file)
                ?: movingAnimation.piece
            if (dstPiece != null) {
                val fx = movingAnimation.fromSquare.file - 3.5f
                val fz = movingAnimation.fromSquare.rank - 3.5f
                val tx = movingAnimation.toSquare.file - 3.5f
                val tz = movingAnimation.toSquare.rank - 3.5f
                val arc = sin(animProgress * PI.toFloat()) * 0.48f
                val ix  = fx + (tx - fx) * animProgress
                val iz  = fz + (tz - fz) * animProgress
                val ph  = pHeight(dstPiece.type)
                items += RItem(dist(V3(ix, TILE_H + arc + ph*0.5f, iz))) {
                    piece3D(dstPiece, ix, iz, arc, ph, ::p, cameraRight)
                }
            }

            if (movingAnimation.isCastling && castleRank != null && castleRookDst != null) {
                val rook = board.squares[castleRank][castleRookDst.file]
                if (rook?.type == PieceType.ROOK) {
                    val rookFromFile = if (movingAnimation.isCastleKingSide) 7 else 0
                    val rookProgress = ((animProgress - 0.42f) / 0.58f).coerceIn(0f, 1f)
                    val rookX = rookFromFile - 3.5f +
                        (castleRookDst.file - rookFromFile) * rookProgress
                    val rookZ = castleRank - 3.5f
                    val rookLift = sin(rookProgress * PI.toFloat()) * 0.22f
                    val rookHeight = pHeight(PieceType.ROOK)
                    items += RItem(dist(V3(rookX, TILE_H + rookLift + rookHeight * 0.5f, rookZ))) {
                        piece3D(rook, rookX, rookZ, rookLift, rookHeight, ::p, cameraRight)
                    }
                }
            }
        }

        // Selected piece — lifted with glow ring
        if (selected != null) {
            val piece = board.squares.getOrNull(selected.rank)?.getOrNull(selected.file)
            if (piece != null) {
                val cx = selected.file - 3.5f; val cz = selected.rank - 3.5f
                val ph = pHeight(piece.type)
                items += RItem(dist(V3(cx, TILE_H + selectedLift + ph*0.5f, cz))) {
                    val bc = p(V3(cx, TILE_H + selectedLift*0.05f, cz)) ?: return@RItem
                    val refR = p(V3(cx + pRadius(piece.type)*1.7f, TILE_H, cz))?.x
                        ?: (bc.x + 22f)
                    val glowR = (refR - bc.x).absoluteValue.coerceIn(14f, 50f)
                    drawCircle(cSelect, glowR, bc, alpha=0.22f)
                    drawCircle(cSelect, glowR*0.68f, bc, style=Stroke(3.5f), alpha=0.85f)
                    piece3D(piece, cx, cz, selectedLift, ph, ::p, cameraRight)
                }
            }
        }
    }

    // Depth sort → draw back-to-front
    items.sortByDescending { it.depth }
    for (item in items) item.fn(this)
}

// ══════════════════════════════════════════════════════════════════════════════
//  PIECE RENDERER — 3-D cylinder with Phong-like gradient shading
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
//  PIECE RENDERER — silhouette bidak catur sebenar + Phong shading
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Lukis bidak catur 3D berkualiti premium.
 * Setiap bidak ada: tapak lebar → leher sempit → badan/kepala → hiasan atas.
 * Ini adalah profil silhouette bidak Staunton klasik dalam pandangan perspektif.
 */
private fun DrawScope.piece3D(
    piece: Piece, cx: Float, cz: Float, lift: Float, ph: Float,
    proj: (V3) -> Offset?, cameraRight: V3
) {
    val isW  = piece.color == com.chessbot.adapt.domain.model.Color.WHITE
    val rad  = pRadius(piece.type)
    val yBot = TILE_H + lift
    val yTop = yBot + ph

    // Titik-titik penting dalam ruang dunia
    val bc   = proj(V3(cx, yBot, cz))            ?: return
    val tc   = proj(V3(cx, yTop, cz))            ?: return
    val sc   = proj(V3(cx, TILE_H + 0.004f, cz)) ?: return

    // Helper: jejari unjuran dalam ruang skrin pada ketinggian tertentu
    fun pr(rWorld: Float, y: Float = yTop): Float {
        val center = V3(cx, y, cz)
        val left = proj(center - cameraRight * rWorld) ?: return 7f
        val right = proj(center + cameraRight * rWorld) ?: return 7f
        val dx = right.x - left.x
        val dy = right.y - left.y
        return (sqrt(dx * dx + dy * dy) * 0.5f).coerceIn(4f, 52f)
    }

    // Jejari di pelbagai ketinggian bidak
    val yNeck = yBot + ph * 0.28f                // kedudukan leher
    val yHead = yBot + ph * 0.52f                // mula kepala membesar
    val prBase  = pr(rad * 1.52f, yBot)          // tapak lebar
    val prNeck  = pr(rad * 0.52f, yNeck)         // leher sempit
    val prHead  = pr(rad * 1.05f, yHead)         // kepala membesar
    val prCap   = pr(rad * 0.82f, yTop)          // penutup atas
    val prShad  = pr(rad * 1.70f, TILE_H + 0.004f)

    // Warna mengikut jenis: gading (putih) atau kayu hitam (hitam)
    val base  = if (isW) cWBase  else cBBase
    val hi    = if (isW) cWHi    else cBHi
    val shade = if (isW) cWShade else cBShade

    // ── 1. Bayang lembut di atas petak ────────────────────────────────────
    drawOval(
        Brush.radialGradient(
            listOf(Color(0f, 0f, 0f, 0.60f), Color(0f, 0f, 0f, 0f)),
            center = sc, radius = prShad * 1.3f
        ),
        topLeft = Offset(sc.x - prShad, sc.y - prShad * 0.35f),
        size    = Size(prShad * 2f, prShad * 0.70f)
    )

    // ── 2. Tapak lebar rata (ciri utama bidak Staunton) ────────────────────
    drawOval(
        Brush.horizontalGradient(
            listOf(hi.copy(alpha = 0.7f), base, shade.copy(alpha = 0.85f)),
            startX = bc.x - prBase, endX = bc.x + prBase
        ),
        topLeft = Offset(bc.x - prBase, bc.y - prBase * 0.33f),
        size    = Size(prBase * 2f, prBase * 0.66f)
    )
    drawOval(
        color = if (isW) cWShade.copy(alpha = 0.42f) else cBHi.copy(alpha = 0.48f),
        topLeft = Offset(bc.x - prBase, bc.y - prBase * 0.33f),
        size = Size(prBase * 2f, prBase * 0.66f),
        style = Stroke((prBase * 0.055f).coerceAtLeast(1f))
    )

    // ── 3. Badan bertirus: tapak → leher (mengecil) ────────────────────────
    val stemPath = Path().apply {
        moveTo(bc.x - prBase * 0.85f, bc.y)
        lineTo(bc.x + prBase * 0.85f, bc.y)
        val neckY = proj(V3(cx, yNeck, cz))?.y ?: ((bc.y + tc.y) * 0.28f)
        lineTo(tc.x + prNeck, neckY)
        lineTo(tc.x - prNeck, neckY)
        close()
    }
    drawPath(stemPath, Brush.horizontalGradient(
        listOf(hi.copy(alpha = 0.55f), base, shade),
        startX = bc.x - prBase, endX = bc.x + prBase
    ))
    drawPath(
        stemPath,
        if (isW) cWShade.copy(alpha = 0.32f) else cBHi.copy(alpha = 0.34f),
        style = Stroke((prBase * 0.045f).coerceAtLeast(0.8f))
    )

    // ── 4. Kepala bidak: leher → kepala membesar (cawan terbalik) ─────────
    val neckOffset = proj(V3(cx, yNeck, cz)) ?: return
    val headOffset = proj(V3(cx, yHead, cz)) ?: return
    val headPath = Path().apply {
        moveTo(neckOffset.x - prNeck, neckOffset.y)
        lineTo(neckOffset.x + prNeck, neckOffset.y)
        lineTo(headOffset.x + prHead, headOffset.y)
        lineTo(tc.x      + prCap,   tc.y)
        lineTo(tc.x      - prCap,   tc.y)
        lineTo(headOffset.x - prHead, headOffset.y)
        close()
    }
    drawPath(headPath, Brush.horizontalGradient(
        listOf(hi, base, base.copy(alpha = 0.92f), shade),
        startX = tc.x - prHead * 1.1f, endX = tc.x + prHead * 1.1f
    ))
    drawPath(
        headPath,
        if (isW) cWShade.copy(alpha = 0.28f) else cBHi.copy(alpha = 0.32f),
        style = Stroke((prBase * 0.04f).coerceAtLeast(0.75f))
    )

    // ── 5. Penutup atas berkubah (glint cahaya) ────────────────────────────
    drawOval(
        Brush.radialGradient(
            listOf(hi, hi.copy(alpha = 0.85f), base, shade),
            center = Offset(tc.x - prCap * 0.25f, tc.y - prCap * 0.15f),
            radius = prCap * 1.6f
        ),
        topLeft = Offset(tc.x - prCap, tc.y - prCap * 0.44f),
        size    = Size(prCap * 2f, prCap * 0.88f)
    )

    // ── 6. Titik specular (glint terang — kesan kilat premium) ─────────────
    val specR = prCap * 0.18f
    val specX = tc.x - prCap * 0.30f
    val specY = tc.y - prCap * 0.32f
    drawCircle(
        Brush.radialGradient(
            listOf(Color.White.copy(alpha = if (isW) 0.95f else 0.55f),
                   Color.White.copy(alpha = 0f)),
            center = Offset(specX, specY), radius = specR * 2.2f
        ),
        radius = specR, center = Offset(specX, specY)
    )

    // ── 7. Hiasan atas khusus setiap bidak ────────────────────────────────
    drawPieceTop(piece.type, tc, prCap, base, hi, shade, isW)
}

/** Hiasan bahagian atas — setiap bidak mesti berbeza dan mudah dikenali */
private fun DrawScope.drawPieceTop(
    type: PieceType, tc: Offset, pr: Float,
    base: Color, hi: Color, shade: Color, isW: Boolean
) {
    val accent = if (isW) Color(0xFFF5ECD0) else Color(0xFF3A3A3A)

    when (type) {

        // ── PION: kepala bulat (dome rendah) ──────────────────────────────
        PieceType.PAWN -> {
            val dR = pr * 0.94f
            drawOval(
                Brush.radialGradient(
                    listOf(hi, base, shade),
                    center = Offset(tc.x - dR * 0.25f, tc.y - dR * 0.70f),
                    radius = dR * 1.50f
                ),
                topLeft = Offset(tc.x - dR, tc.y - dR * 1.90f),
                size    = Size(dR * 2f, dR * 1.95f)
            )
            // Glint pion
            drawCircle(Color.White.copy(alpha = if (isW) 0.7f else 0.3f),
                radius = dR * 0.15f,
                center = Offset(tc.x - dR * 0.32f, tc.y - dR * 1.62f))
        }

        // ── BENTENG: merlon kastil ─────────────────────────────────────────
        PieceType.ROOK -> {
            val mW    = pr * 0.46f
            val mH    = pr * 0.72f
            val gap   = pr * 0.19f
            val startX = tc.x - pr * 1.00f
            // Pelantar bawah merlon
            drawRect(
                Brush.horizontalGradient(listOf(hi, base, shade),
                    startX = startX, endX = startX + 3 * mW + 2 * gap),
                topLeft = Offset(startX, tc.y - mH * 0.28f),
                size    = Size(3 * mW + 2 * gap, mH * 0.28f)
            )
            // 3 merlon
            repeat(3) { i ->
                val mx = startX + i * (mW + gap)
                drawRect(
                    Brush.verticalGradient(
                        listOf(hi, accent, shade),
                        startY = tc.y - mH, endY = tc.y - mH * 0.28f
                    ),
                    topLeft = Offset(mx, tc.y - mH),
                    size    = Size(mW, mH * 0.75f)
                )
            }
        }

        // ── GAJAH: topi runcing (mitre) ───────────────────────────────────
        PieceType.BISHOP -> {
            val bH = pr * 2.25f
            // Badan mitre
            val mitrePath = Path().apply {
                moveTo(tc.x, tc.y - bH)
                lineTo(tc.x + pr * 0.42f, tc.y - pr * 0.50f)
                cubicTo(
                    tc.x + pr * 0.32f, tc.y - pr * 0.30f,
                    tc.x - pr * 0.32f, tc.y - pr * 0.30f,
                    tc.x - pr * 0.42f, tc.y - pr * 0.50f
                )
                close()
            }
            drawPath(mitrePath, Brush.verticalGradient(
                listOf(hi, base, shade),
                startY = tc.y - bH, endY = tc.y
            ))
            // Jalur mendatar mitre
            drawLine(
                color  = accent,
                start  = Offset(tc.x - pr * 0.38f, tc.y - pr * 1.0f),
                end    = Offset(tc.x + pr * 0.38f, tc.y - pr * 1.0f),
                strokeWidth = pr * 0.11f
            )
            // Bola hujung
            drawCircle(
                Brush.radialGradient(listOf(hi, base),
                    center = Offset(tc.x, tc.y - bH + pr * 0.12f),
                    radius = pr * 0.24f),
                radius = pr * 0.20f,
                center = Offset(tc.x, tc.y - bH + pr * 0.12f)
            )
        }

        // ── KUDA: profil kepala kuda ───────────────────────────────────────
        PieceType.KNIGHT -> {
            val kH = pr * 1.62f
            // Kepala kuda (blok beraya ke hadapan)
            val knightPath = Path().apply {
                moveTo(tc.x - pr * 0.30f, tc.y - pr * 0.28f) // bawah kiri
                quadraticBezierTo(
                    tc.x - pr * 0.35f, tc.y - kH * 0.55f,    // bengkok kiri
                    tc.x - pr * 0.15f, tc.y - kH              // atas kiri
                )
                lineTo(tc.x + pr * 0.48f, tc.y - kH)          // atas kanan
                quadraticBezierTo(
                    tc.x + pr * 0.72f, tc.y - kH * 0.45f,    // muncung
                    tc.x + pr * 0.70f, tc.y - pr * 0.28f      // bawah kanan
                )
                close()
            }
            drawPath(knightPath, Brush.horizontalGradient(
                listOf(hi, base, shade),
                startX = tc.x - pr * 0.35f, endX = tc.x + pr * 0.72f
            ))
            // Telinga kuda
            val earPath = Path().apply {
                moveTo(tc.x + pr * 0.38f, tc.y - kH)
                lineTo(tc.x + pr * 0.72f, tc.y - kH - pr * 0.52f)
                lineTo(tc.x + pr * 0.58f, tc.y - kH + pr * 0.08f)
                close()
            }
            drawPath(earPath, hi.copy(alpha = 0.72f))
            // Mata kuda (titik kecil)
            drawCircle(shade, pr * 0.08f,
                Offset(tc.x + pr * 0.38f, tc.y - kH + pr * 0.25f))
        }

        // ── RATU: mahkota 5 mata berlian ──────────────────────────────────
        PieceType.QUEEN -> {
            val baseH = pr * 0.55f
            // Rim mahkota
            drawRect(
                Brush.horizontalGradient(listOf(hi, base, shade),
                    startX = tc.x - pr * 0.92f, endX = tc.x + pr * 0.92f),
                topLeft = Offset(tc.x - pr * 0.92f, tc.y - baseH),
                size    = Size(pr * 1.84f, baseH)
            )
            // 5 mata mahkota (garis + bola)
            val xMul = listOf(-0.80f, -0.40f, 0.0f, 0.40f, 0.80f)
            val yMul = listOf(1.42f, 1.88f, 2.20f, 1.88f, 1.42f)
            xMul.forEachIndexed { i, xm ->
                val px = tc.x + xm * pr
                val pH = pr * yMul[i]
                // Batang
                drawLine(base.copy(alpha = 0.75f),
                    Offset(px, tc.y - baseH), Offset(px, tc.y - pH + pr * 0.23f),
                    strokeWidth = pr * 0.14f)
                // Bola berlian
                drawCircle(
                    Brush.radialGradient(listOf(hi, base, shade),
                        center = Offset(px - pr * 0.05f, tc.y - pH - pr * 0.05f),
                        radius = pr * 0.28f),
                    radius = pr * 0.23f,
                    center = Offset(px, tc.y - pH)
                )
            }
        }

        // ── RAJA: mahkota + salib suci ────────────────────────────────────
        PieceType.KING -> {
            val baseH = pr * 0.62f
            // Rim mahkota (lebih lebar dari ratu)
            drawRect(
                Brush.horizontalGradient(listOf(hi, base, shade),
                    startX = tc.x - pr * 0.96f, endX = tc.x + pr * 0.96f),
                topLeft = Offset(tc.x - pr * 0.96f, tc.y - baseH),
                size    = Size(pr * 1.92f, baseH)
            )
            // Tiang menegak salib
            val cH  = pr * 2.10f;  val cW  = pr * 0.29f
            val cBase = tc.y - baseH
            drawRect(
                Brush.verticalGradient(listOf(hi, base, shade),
                    startY = cBase - cH, endY = cBase),
                topLeft = Offset(tc.x - cW * 0.5f, cBase - cH),
                size    = Size(cW, cH)
            )
            // Tiang melintang salib
            val armW = pr * 1.18f; val armH = pr * 0.33f
            drawRect(
                Brush.horizontalGradient(listOf(shade, hi, shade),
                    startX = tc.x - armW * 0.5f, endX = tc.x + armW * 0.5f),
                topLeft = Offset(tc.x - armW * 0.5f, cBase - cH * 0.66f - armH * 0.5f),
                size    = Size(armW, armH)
            )
            // Sfera kecil di puncak salib
            drawCircle(
                Brush.radialGradient(listOf(hi, base),
                    center = Offset(tc.x, cBase - cH), radius = pr * 0.22f),
                radius = pr * 0.18f,
                center = Offset(tc.x, cBase - cH)
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════════════════════════════════════════

private fun DrawScope.quad4(
    a: Offset, b: Offset, c: Offset, d: Offset,
    color: Color, alpha: Float = 1f
) = drawPath(Path().apply {
    moveTo(a.x, a.y); lineTo(b.x, b.y)
    lineTo(c.x, c.y); lineTo(d.x, d.y); close()
}, color, alpha = alpha)

// Ketinggian bidak dalam ruang dunia
private fun pHeight(t: PieceType) = when (t) {
    PieceType.PAWN   -> 0.55f
    PieceType.ROOK   -> 0.65f
    PieceType.KNIGHT -> 0.72f
    PieceType.BISHOP -> 0.82f
    PieceType.QUEEN  -> 0.94f
    PieceType.KING   -> 1.06f
}

// Jejari asas bidak dalam ruang dunia
private fun pRadius(t: PieceType) = when (t) {
    PieceType.PAWN   -> 0.20f
    PieceType.ROOK   -> 0.24f
    PieceType.KNIGHT -> 0.22f
    PieceType.BISHOP -> 0.20f
    PieceType.QUEEN  -> 0.24f
    PieceType.KING   -> 0.23f
}
