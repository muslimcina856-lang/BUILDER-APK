package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.model.*

interface BotEngine {
    suspend fun getBestMove(
        board: Board,
        color: Color,
        config: BotConfig,
        learningData: List<BotLearningData>
    ): Move

    fun evaluatePosition(board: Board, color: Color, weights: EvalWeights): Int
}

data class EvalWeights(
    val material: Float = 1.0f,
    val position: Float = 1.0f,
    val kingSafety: Float = 1.0f,
    val pawnStructure: Float = 1.0f,
    val mobility: Float = 1.0f,
    val centerControl: Float = 1.0f,
    val tactical: Float = 1.0f,
    val aggression: Float = 0.6f,
    val defense: Float = 0.65f
)
