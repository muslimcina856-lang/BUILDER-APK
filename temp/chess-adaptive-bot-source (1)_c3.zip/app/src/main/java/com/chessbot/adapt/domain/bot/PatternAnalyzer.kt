package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.domain.model.*

data class DetectedPlayerPattern(
    val key: String,
    val label: String,
    val explanation: String,
    val aggressionModifier: Float,
    val defenseModifier: Float,
    val positionModifier: Float
)

/** Mengesan tabiat yang boleh diterjemahkan terus kepada strategi balas bot. */
class PatternAnalyzer {

    fun identifyOpening(moves: List<Move>, playerColor: Color? = null): String {
        val relevant = moves.asSequence()
            .filter { playerColor == null || it.piece.color == playerColor }
            .take(6)
            .toList()
        val firstPawn = relevant.firstOrNull { it.piece.type == PieceType.PAWN } ?: return "UNKNOWN_OPENING"
        return when (firstPawn.fromSquare.file) {
            4 -> "KING_PAWN_GAME"
            3 -> "QUEEN_PAWN_GAME"
            0, 1, 2, 5, 6, 7 -> "FLANK_OPENING"
            else -> "UNKNOWN_OPENING"
        }
    }

    fun detectPlayerPatterns(moves: List<Move>, playerColor: Color): List<DetectedPlayerPattern> {
        val playerMoves = moves.filter { it.piece.color == playerColor }
        if (playerMoves.isEmpty()) return emptyList()
        val patterns = mutableListOf<DetectedPlayerPattern>()

        patterns += when (identifyOpening(moves, playerColor)) {
            "KING_PAWN_GAME" -> pattern(
                "OPENING_KING_PAWN", "Pembukaan bidak raja",
                "Kamu kerap membuka ruang dengan bidak e. Bot akan mengawal pusat dan laluan raja.",
                aggression = 0.08f, defense = 0.10f, position = 0.10f
            )
            "QUEEN_PAWN_GAME" -> pattern(
                "OPENING_QUEEN_PAWN", "Pembukaan bidak menteri",
                "Kamu cenderung membina pusat yang kukuh. Bot akan meningkatkan tekanan posisi.",
                aggression = 0.04f, defense = 0.12f, position = 0.16f
            )
            "FLANK_OPENING" -> pattern(
                "OPENING_FLANK", "Pembukaan sisi",
                "Kamu kerap bermula dari sisi papan. Bot akan mengambil lebih banyak ruang di tengah.",
                aggression = 0.05f, defense = 0.04f, position = 0.20f
            )
            else -> pattern(
                "OPENING_UNSTRUCTURED", "Pembukaan tidak tetap",
                "Corak pembukaan kamu berubah-ubah. Bot akan bermain seimbang sambil mengumpul data.",
                aggression = 0.04f, defense = 0.04f, position = 0.06f
            )
        }

        if (playerMoves.take(5).any { it.piece.type == PieceType.QUEEN }) {
            patterns += pattern(
                "EARLY_QUEEN", "Menteri keluar awal",
                "Kamu menggerakkan menteri awal. Bot akan membangunkan bidak sambil menyerang menteri.",
                aggression = 0.18f, defense = 0.02f, position = 0.14f
            )
        }

        val earlyMoves = playerMoves.take(8)
        if (earlyMoves.count { it.piece.type == PieceType.PAWN } >= 5) {
            patterns += pattern(
                "PAWN_HEAVY", "Terlalu banyak langkah bidak",
                "Kamu menggunakan banyak tempo untuk bidak. Bot akan mempercepat pembangunan buah.",
                aggression = 0.10f, defense = 0.04f, position = 0.18f
            )
        }

        if (earlyMoves.count {
                it.piece.type == PieceType.PAWN && it.fromSquare.file in 5..7
            } >= 2
        ) {
            patterns += pattern(
                "KING_SIDE_PAWN_PUSH", "Bidak sisi raja mara awal",
                "Perisai raja kamu kerap dibuka. Bot akan menambah tekanan ke arah raja.",
                aggression = 0.24f, defense = 0.02f, position = 0.08f
            )
        }

        if (playerMoves.size >= 10 && playerMoves.none { it.isCastling }) {
            patterns += pattern(
                "UNCLOSED_KING", "Raja lambat berlindung",
                "Kamu jarang castling pada awal permainan. Bot akan membuka garisan serangan lebih awal.",
                aggression = 0.20f, defense = 0.03f, position = 0.10f
            )
        }

        val captureRate = playerMoves.count { it.isCapture }.toFloat() / playerMoves.size
        if (playerMoves.size >= 8 && captureRate >= 0.35f) {
            patterns += pattern(
                "CAPTURE_HUNGRY", "Kerap mencari pertukaran",
                "Kamu gemar menangkap apabila ada peluang. Bot akan mempertahankan bidak dan menyediakan balasan.",
                aggression = 0.04f, defense = 0.22f, position = 0.10f
            )
        }

        return patterns.distinctBy { it.key }
    }

    fun getCounterStrategy(opening: String): EvalWeights = when (opening) {
        "KING_PAWN_GAME" -> EvalWeights(aggression = 0.72f, defense = 0.78f, centerControl = 1.15f)
        "QUEEN_PAWN_GAME" -> EvalWeights(aggression = 0.60f, defense = 0.82f, position = 1.15f)
        "FLANK_OPENING" -> EvalWeights(aggression = 0.65f, defense = 0.68f, centerControl = 1.25f)
        else -> EvalWeights(aggression = 0.60f, defense = 0.65f)
    }

    private fun pattern(
        key: String,
        label: String,
        explanation: String,
        aggression: Float,
        defense: Float,
        position: Float
    ) = DetectedPlayerPattern(key, label, explanation, aggression, defense, position)
}
