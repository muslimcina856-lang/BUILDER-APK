package com.chessbot.adapt.presentation.chessboard

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ViewConfiguration
import com.chessbot.adapt.domain.model.Board
import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Square
import kotlin.math.abs
import kotlin.math.hypot

@SuppressLint("ViewConstructor")
internal class ChessOpenGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private val chessRenderer = ChessOpenGLRenderer()
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var previousX = 0f
    private var previousY = 0f
    private var dragging = false

    var onSquareTap: (Square) -> Unit = {}

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        preserveEGLContextOnPause = true
        setRenderer(chessRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        isFocusable = true
        isClickable = true
    }

    fun updateScene(
        board: Board?,
        selectedSquare: Square?,
        validMoves: List<Move>,
        lastMove: Move?,
        isCheck: Boolean,
        checkColor: Color?,
        playerColor: Color,
        selectedLift: Float,
        animatedMove: Move?,
        animationProgress: Float
    ) {
        val updated = ChessOpenGLScene(
            board = board,
            selectedSquare = selectedSquare,
            validMoves = validMoves,
            lastMove = lastMove,
            isCheck = isCheck,
            checkColor = checkColor,
            playerColor = playerColor,
            selectedLift = selectedLift,
            animatedMove = animatedMove,
            animationProgress = animationProgress
        )
        queueEvent { chessRenderer.updateScene(updated) }
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                downY = event.y
                previousX = event.x
                previousY = event.y
                dragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val totalDistance = hypot(event.x - downX, event.y - downY)
                if (totalDistance > touchSlop) dragging = true
                if (dragging) {
                    val deltaX = event.x - previousX
                    val rawDeltaY = event.y - previousY
                    val deltaY = if (abs(rawDeltaY) > abs(deltaX) * 1.25f) rawDeltaY else 0f
                    chessRenderer.orbit(deltaX, deltaY)
                    requestRender()
                    previousX = event.x
                    previousY = event.y
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (!dragging) {
                    chessRenderer.pickSquare(event.x, event.y)?.let(onSquareTap)
                    performClick()
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
