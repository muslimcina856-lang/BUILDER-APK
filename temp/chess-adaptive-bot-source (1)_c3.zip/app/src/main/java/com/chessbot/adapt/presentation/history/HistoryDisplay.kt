package com.chessbot.adapt.presentation.history

import com.chessbot.adapt.data.local.entity.GameSession

private val completedResults = setOf("WIN", "LOSS", "DRAW")

/** Hanya satu sesi aktif yang sudah bermula; sesi kosong dan sesi terbiar tidak memenuhi sejarah. */
internal fun historyGamesForDisplay(games: List<GameSession>): List<GameSession> {
    val currentGameId = games.firstOrNull {
        it.result == "IN_PROGRESS" && it.playStartedAt != null
    }?.id
    return games.filter { game ->
        game.result in completedResults || game.id == currentGameId
    }
}
