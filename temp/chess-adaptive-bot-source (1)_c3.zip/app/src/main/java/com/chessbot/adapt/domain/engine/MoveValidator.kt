package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*
import kotlin.math.abs

/** Menjana pergerakan pseudo-sah dan peta serangan untuk semua peraturan utama. */
class MoveValidator {

    fun validateMove(board: Board, move: Move, color: Color): Boolean {
        if (!move.fromSquare.isOnBoard() || !move.toSquare.isOnBoard()) return false
        val piece = board.squares[move.fromSquare.rank][move.fromSquare.file] ?: return false
        if (piece.color != color) return false
        return generatePieceMoves(board, move.fromSquare).any {
            it.toSquare == move.toSquare && it.promotionPiece == move.promotionPiece
        }
    }

    fun generatePieceMoves(board: Board, square: Square): List<Move> {
        if (!square.isOnBoard()) return emptyList()
        val piece = board.squares[square.rank][square.file] ?: return emptyList()
        return when (piece.type) {
            PieceType.PAWN -> generatePawnMoves(board, square, piece)
            PieceType.KNIGHT -> generateKnightMoves(board, square, piece)
            PieceType.BISHOP -> generateSlidingMoves(board, square, piece, DIAGONALS)
            PieceType.ROOK -> generateSlidingMoves(board, square, piece, ORTHOGONALS)
            PieceType.QUEEN -> generateSlidingMoves(board, square, piece, ORTHOGONALS + DIAGONALS)
            PieceType.KING -> generateKingMoves(board, square, piece)
        }
    }

    private fun generatePawnMoves(board: Board, square: Square, piece: Piece): List<Move> {
        val moves = mutableListOf<Move>()
        val direction = if (piece.color == Color.WHITE) 1 else -1
        val startRank = if (piece.color == Color.WHITE) 1 else 6
        val promotionRank = if (piece.color == Color.WHITE) 7 else 0

        val oneStep = Square(square.file, square.rank + direction)
        if (oneStep.isOnBoard() && board.squares[oneStep.rank][oneStep.file] == null) {
            addPawnMove(moves, square, oneStep, piece, promotionRank)
            val twoStep = Square(square.file, square.rank + 2 * direction)
            if (square.rank == startRank && board.squares[twoStep.rank][twoStep.file] == null) {
                moves += Move(square, twoStep, piece)
            }
        }

        for (df in listOf(-1, 1)) {
            val targetSquare = Square(square.file + df, square.rank + direction)
            if (!targetSquare.isOnBoard()) continue
            val target = board.squares[targetSquare.rank][targetSquare.file]
            when {
                target != null && target.color != piece.color && target.type != PieceType.KING ->
                    addPawnMove(moves, square, targetSquare, piece, promotionRank, target)

                target == null && targetSquare == board.enPassantTarget -> {
                    val adjacent = board.squares[square.rank][targetSquare.file]
                    if (adjacent?.type == PieceType.PAWN && adjacent.color != piece.color) {
                        moves += Move(
                            fromSquare = square,
                            toSquare = targetSquare,
                            piece = piece,
                            capturedPiece = adjacent,
                            isEnPassant = true
                        )
                    }
                }
            }
        }
        return moves
    }

    private fun addPawnMove(
        moves: MutableList<Move>,
        from: Square,
        to: Square,
        pawn: Piece,
        promotionRank: Int,
        captured: Piece? = null
    ) {
        if (to.rank == promotionRank) {
            listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)
                .forEach { moves += Move(from, to, pawn, it, captured) }
        } else {
            moves += Move(from, to, pawn, capturedPiece = captured)
        }
    }

    private fun generateKnightMoves(board: Board, square: Square, piece: Piece): List<Move> =
        KNIGHT_OFFSETS.mapNotNull { (dr, df) ->
            val targetSquare = Square(square.file + df, square.rank + dr)
            if (!targetSquare.isOnBoard()) return@mapNotNull null
            val target = board.squares[targetSquare.rank][targetSquare.file]
            if (target?.color == piece.color || target?.type == PieceType.KING) null
            else Move(square, targetSquare, piece, capturedPiece = target)
        }

    private fun generateSlidingMoves(
        board: Board,
        square: Square,
        piece: Piece,
        directions: List<Pair<Int, Int>>
    ): List<Move> {
        val moves = mutableListOf<Move>()
        for ((dr, df) in directions) {
            var rank = square.rank + dr
            var file = square.file + df
            while (rank in 0..7 && file in 0..7) {
                val target = board.squares[rank][file]
                if (target == null) {
                    moves += Move(square, Square(file, rank), piece)
                } else {
                    if (target.color != piece.color && target.type != PieceType.KING) {
                        moves += Move(square, Square(file, rank), piece, capturedPiece = target)
                    }
                    break
                }
                rank += dr
                file += df
            }
        }
        return moves
    }

    private fun generateKingMoves(board: Board, square: Square, piece: Piece): List<Move> {
        val moves = mutableListOf<Move>()
        for (dr in -1..1) for (df in -1..1) {
            if (dr == 0 && df == 0) continue
            val targetSquare = Square(square.file + df, square.rank + dr)
            if (!targetSquare.isOnBoard()) continue
            val target = board.squares[targetSquare.rank][targetSquare.file]
            if (target?.color != piece.color && target?.type != PieceType.KING) {
                moves += Move(square, targetSquare, piece, capturedPiece = target)
            }
        }
        moves += generateCastlingMoves(board, square, piece)
        return moves
    }

    private fun generateCastlingMoves(board: Board, square: Square, king: Piece): List<Move> {
        val homeRank = if (king.color == Color.WHITE) 0 else 7
        if (square != Square(4, homeRank)) return emptyList()
        if (isSquareAttacked(board, square, king.color.opposite())) return emptyList()

        val result = mutableListOf<Move>()
        val canKingSide = if (king.color == Color.WHITE) board.whiteCanCastleKingSide
            else board.blackCanCastleKingSide
        val canQueenSide = if (king.color == Color.WHITE) board.whiteCanCastleQueenSide
            else board.blackCanCastleQueenSide

        if (canKingSide &&
            board.squares[homeRank][5] == null && board.squares[homeRank][6] == null &&
            board.squares[homeRank][7] == Piece(PieceType.ROOK, king.color) &&
            !isSquareAttacked(board, Square(5, homeRank), king.color.opposite()) &&
            !isSquareAttacked(board, Square(6, homeRank), king.color.opposite())
        ) {
            result += Move(square, Square(6, homeRank), king, isCastleKingSide = true)
        }

        if (canQueenSide &&
            board.squares[homeRank][1] == null && board.squares[homeRank][2] == null &&
            board.squares[homeRank][3] == null &&
            board.squares[homeRank][0] == Piece(PieceType.ROOK, king.color) &&
            !isSquareAttacked(board, Square(3, homeRank), king.color.opposite()) &&
            !isSquareAttacked(board, Square(2, homeRank), king.color.opposite())
        ) {
            result += Move(square, Square(2, homeRank), king, isCastleQueenSide = true)
        }
        return result
    }

    /** Peta serangan tidak menggunakan move generator untuk mengelakkan rekursi castling. */
    fun isSquareAttacked(board: Board, target: Square, byColor: Color): Boolean {
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            if (piece.color != byColor) continue
            val dr = target.rank - rank
            val df = target.file - file
            val attacks = when (piece.type) {
                PieceType.PAWN -> dr == (if (byColor == Color.WHITE) 1 else -1) && abs(df) == 1
                PieceType.KNIGHT -> (abs(dr) == 2 && abs(df) == 1) || (abs(dr) == 1 && abs(df) == 2)
                PieceType.KING -> maxOf(abs(dr), abs(df)) == 1
                PieceType.BISHOP -> abs(dr) == abs(df) && pathIsClear(board, file, rank, target)
                PieceType.ROOK -> (dr == 0 || df == 0) && pathIsClear(board, file, rank, target)
                PieceType.QUEEN -> (dr == 0 || df == 0 || abs(dr) == abs(df)) &&
                    pathIsClear(board, file, rank, target)
            }
            if (attacks) return true
        }
        return false
    }

    private fun pathIsClear(board: Board, fromFile: Int, fromRank: Int, to: Square): Boolean {
        val df = (to.file - fromFile).coerceIn(-1, 1)
        val dr = (to.rank - fromRank).coerceIn(-1, 1)
        if (df == 0 && dr == 0) return false
        var file = fromFile + df
        var rank = fromRank + dr
        while (file != to.file || rank != to.rank) {
            if (board.squares[rank][file] != null) return false
            file += df
            rank += dr
        }
        return true
    }

    private companion object {
        val ORTHOGONALS = listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
        val DIAGONALS = listOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
        val KNIGHT_OFFSETS = listOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
    }
}
