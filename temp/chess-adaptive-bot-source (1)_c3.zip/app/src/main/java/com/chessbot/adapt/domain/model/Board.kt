package com.chessbot.adapt.domain.model

enum class PieceType { KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN }
enum class Color { WHITE, BLACK }

data class Square(val file: Int, val rank: Int) {
    fun isOnBoard(): Boolean = file in 0..7 && rank in 0..7

    fun toAlgebraic(): String = "${('a' + file)}${rank + 1}"

    companion object {
        fun fromAlgebraic(value: String): Square? {
            if (value.length != 2) return null
            val file = value[0].lowercaseChar() - 'a'
            val rank = value[1] - '1'
            return Square(file, rank).takeIf { it.isOnBoard() }
        }
    }
}

data class Piece(val type: PieceType, val color: Color)

/**
 * Keadaan penuh sebuah posisi catur. Maklumat giliran, castling, en-passant dan
 * kiraan langkah disimpan bersama papan supaya carian bot dan FEN sentiasa sah.
 */
data class Board(
    val squares: Array<Array<Piece?>>,
    val activeColor: Color = Color.WHITE,
    val whiteCanCastleKingSide: Boolean = true,
    val whiteCanCastleQueenSide: Boolean = true,
    val blackCanCastleKingSide: Boolean = true,
    val blackCanCastleQueenSide: Boolean = true,
    val enPassantTarget: Square? = null,
    val halfmoveClock: Int = 0,
    val fullmoveNumber: Int = 1,
    val positionHistory: List<String> = emptyList()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Board) return false
        return squares.contentDeepEquals(other.squares) &&
            activeColor == other.activeColor &&
            whiteCanCastleKingSide == other.whiteCanCastleKingSide &&
            whiteCanCastleQueenSide == other.whiteCanCastleQueenSide &&
            blackCanCastleKingSide == other.blackCanCastleKingSide &&
            blackCanCastleQueenSide == other.blackCanCastleQueenSide &&
            enPassantTarget == other.enPassantTarget &&
            halfmoveClock == other.halfmoveClock &&
            fullmoveNumber == other.fullmoveNumber
    }

    override fun hashCode(): Int {
        var result = squares.contentDeepHashCode()
        result = 31 * result + activeColor.hashCode()
        result = 31 * result + whiteCanCastleKingSide.hashCode()
        result = 31 * result + whiteCanCastleQueenSide.hashCode()
        result = 31 * result + blackCanCastleKingSide.hashCode()
        result = 31 * result + blackCanCastleQueenSide.hashCode()
        result = 31 * result + (enPassantTarget?.hashCode() ?: 0)
        result = 31 * result + halfmoveClock
        result = 31 * result + fullmoveNumber
        return result
    }
}
