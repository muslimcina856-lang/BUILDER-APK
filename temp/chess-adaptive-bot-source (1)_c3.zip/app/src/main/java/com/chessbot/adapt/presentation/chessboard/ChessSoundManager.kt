package com.chessbot.adapt.presentation.chessboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * Bunyi bidak kayu yang dijana secara fizikal: sentuhan pendek, geseran halus dan resonans
 * papan yang tidak harmonik. Beberapa variasi mengelakkan setiap langkah berbunyi serupa.
 */
class ChessSoundManager(@Suppress("UNUSED_PARAMETER") context: Context) {

    private val sampleRate = 44_100
    private val liftTracks = mutableListOf<AudioTrack>()
    private val placeTracks = mutableListOf<AudioTrack>()
    private val captureTracks = mutableListOf<AudioTrack>()
    private var liftIndex = -1
    private var placeIndex = -1
    private var captureIndex = -1

    init {
        runCatching {
            repeat(VARIANT_COUNT) { variant ->
                liftTracks += buildTrack(generateLift(41 + variant * 19, variant))
                placeTracks += buildTrack(generatePlace(73 + variant * 23, variant))
                captureTracks += buildTrack(generateCapture(97 + variant * 29, variant))
            }
        }
    }

    fun playLift() {
        liftIndex = playNext(liftTracks, liftIndex)
    }

    fun playPlace() {
        placeIndex = playNext(placeTracks, placeIndex)
    }

    fun playCapture() {
        captureIndex = playNext(captureTracks, captureIndex)
    }

    fun release() {
        (liftTracks + placeTracks + captureTracks).forEach { track ->
            runCatching { track.release() }
        }
    }

    private fun playNext(tracks: List<AudioTrack>, currentIndex: Int): Int {
        if (tracks.isEmpty()) return currentIndex
        val nextIndex = (currentIndex + 1) % tracks.size
        runCatching {
            tracks[nextIndex].takeIf { it.state == AudioTrack.STATE_INITIALIZED }?.also {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) it.stop()
                it.reloadStaticData()
                it.play()
            }
        }
        return nextIndex
    }

    private fun buildTrack(samples: ShortArray): AudioTrack = AudioTrack.Builder()
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
        )
        .setBufferSizeInBytes(samples.size * 2)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()
        .also { it.write(samples, 0, samples.size) }

    private fun generateLift(seed: Int, variant: Int): ShortArray = renderWoodSound(
        durationMs = 105,
        seed = seed,
        impacts = listOf(WoodImpact(0.0, 0.20, 155.0 + variant * 5.0, 48.0)),
        scrapeStart = 0.008,
        scrapeDuration = 0.050,
        scrapeLevel = 0.055
    )

    private fun generatePlace(seed: Int, variant: Int): ShortArray = renderWoodSound(
        durationMs = 255,
        seed = seed,
        impacts = listOf(WoodImpact(0.0, 0.58, 142.0 + variant * 4.5, 18.0)),
        scrapeStart = 0.0,
        scrapeDuration = 0.012,
        scrapeLevel = 0.025
    )

    private fun generateCapture(seed: Int, variant: Int): ShortArray = renderWoodSound(
        durationMs = 190,
        seed = seed,
        impacts = listOf(WoodImpact(0.0, 0.32, 168.0 + variant * 5.0, 27.0)),
        scrapeStart = 0.013,
        scrapeDuration = 0.065,
        scrapeLevel = 0.070
    )

    private fun renderWoodSound(
        durationMs: Int,
        seed: Int,
        impacts: List<WoodImpact>,
        scrapeStart: Double,
        scrapeDuration: Double,
        scrapeLevel: Double
    ): ShortArray {
        val random = Random(seed)
        val phases = impacts.map {
            DoubleArray(WOOD_MODE_RATIOS.size) { random.nextDouble(0.0, 2.0 * PI) }
        }
        var filteredNoise = 0.0
        var previousInput = 0.0
        var previousHighPassed = 0.0
        var smoothed = 0.0
        return ShortArray(sampleRate * durationMs / 1_000) { index ->
            val time = index.toDouble() / sampleRate
            val white = random.nextDouble() * 2.0 - 1.0
            filteredNoise += 0.14 * (white - filteredNoise)

            var signal = 0.0
            impacts.forEachIndexed { impactIndex, impact ->
                val localTime = time - impact.atSeconds
                if (localTime >= 0.0) {
                    val attack = white * exp(-190.0 * localTime) * impact.level * 0.52
                    val modes = WOOD_MODE_RATIOS.indices.sumOf { modeIndex ->
                        val frequency = impact.baseFrequency * WOOD_MODE_RATIOS[modeIndex]
                        sin(2.0 * PI * frequency * localTime + phases[impactIndex][modeIndex]) *
                            WOOD_MODE_LEVELS[modeIndex] * exp(-impact.decay * localTime)
                    }
                    signal += attack + modes * impact.level
                }
            }

            val scrapeTime = time - scrapeStart
            if (scrapeTime in 0.0..scrapeDuration) {
                val envelope = sin(PI * scrapeTime / scrapeDuration).coerceAtLeast(0.0)
                signal += (filteredNoise * 0.78 + white * 0.22) * envelope * scrapeLevel
            }

            // Buang frekuensi paling rendah dan lembutkan puncak seperti rakaman mikrofon sebenar.
            val highPassed = 0.985 * (previousHighPassed + signal - previousInput)
            previousInput = signal
            previousHighPassed = highPassed
            smoothed += 0.36 * (highPassed - smoothed)
            val softened = tanh(smoothed * 2.15) * 0.72
            (softened * 24_000.0).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()
        }
    }

    private data class WoodImpact(
        val atSeconds: Double,
        val level: Double,
        val baseFrequency: Double,
        val decay: Double
    )

    companion object {
        private const val VARIANT_COUNT = 3
        private val WOOD_MODE_RATIOS = doubleArrayOf(1.0, 1.73, 2.61, 4.08, 5.44)
        private val WOOD_MODE_LEVELS = doubleArrayOf(0.48, 0.25, 0.14, 0.075, 0.035)
    }
}
