package com.chessbot.adapt.data.repository

import com.chessbot.adapt.data.local.dao.GameSessionDao
import com.chessbot.adapt.data.local.dao.MoveDao
import com.chessbot.adapt.data.local.entity.GameSession
import com.chessbot.adapt.data.local.entity.MoveEntity
import com.chessbot.adapt.domain.repository.GameRepository
import kotlinx.coroutines.flow.Flow

class GameRepositoryImpl(
    private val gameSessionDao: GameSessionDao,
    private val moveDao: MoveDao
) : GameRepository {

    override suspend fun saveGame(session: GameSession): Long {
        return gameSessionDao.insert(session)
    }

    override suspend fun updateGame(session: GameSession) {
        gameSessionDao.update(session)
    }

    override suspend fun getGame(gameId: Long): GameSession? {
        return gameSessionDao.getGame(gameId)
    }

    override fun getGamesByPlayer(playerId: Long): Flow<List<GameSession>> {
        return gameSessionDao.getGamesByPlayer(playerId)
    }

    override suspend fun abandonInProgressGames(playerId: Long, endedAt: Long) {
        gameSessionDao.abandonInProgressGames(playerId, endedAt)
    }

    override suspend fun saveMove(move: MoveEntity): Long {
        return moveDao.insert(move)
    }

    override suspend fun getMovesForGame(gameId: Long): List<MoveEntity> {
        return moveDao.getMovesForGameSync(gameId)
    }
}
