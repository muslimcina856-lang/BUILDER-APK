package com.chessbot.adapt.presentation.chessboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chessbot.adapt.data.local.dao.BotConfigDao
import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.GameSession
import com.chessbot.adapt.data.local.entity.MoveEntity
import com.chessbot.adapt.data.local.entity.PlayerProfile
import com.chessbot.adapt.domain.engine.ChessEngineImpl
import com.chessbot.adapt.domain.engine.opposite
import com.chessbot.adapt.domain.model.*
import com.chessbot.adapt.domain.repository.GameRepository
import com.chessbot.adapt.domain.repository.PlayerRepository
import com.chessbot.adapt.domain.usecase.AnalyzePatternsUseCase
import com.chessbot.adapt.domain.usecase.GetBotMoveUseCase
import com.chessbot.adapt.domain.usecase.UpdateBotLevelUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChessBoardUiState(
    val board: Board? = null,
    val validMoves: List<Move> = emptyList(),
    val selectedSquare: Square? = null,
    val pendingPromotionMoves: List<Move> = emptyList(),
    val isBotThinking: Boolean = false,
    val isMoveAnimating: Boolean = false,
    val isResultProcessing: Boolean = false,
    val gameResult: String? = null,
    val isMasteryVictory: Boolean = false,
    val currentLevel: Int = 1,
    val moveHistory: List<Move> = emptyList(),
    val lastMove: Move? = null,
    val playerColor: Color = Color.WHITE,
    val botColor: Color = Color.BLACK,
    val currentTurn: Color = Color.WHITE,
    val isCheck: Boolean = false,
    val isCheckmate: Boolean = false,
    val isReady: Boolean = false,
    val isColorSelectionVisible: Boolean = false,
    val learningInsights: List<String> = emptyList(),
    val learnedPatternCount: Int = 0,
    val games: List<GameSession> = emptyList(),
    val playerProfile: PlayerProfile? = null,
    val errorMessage: String? = null
)

@HiltViewModel
class ChessBoardViewModel @Inject constructor(
    private val getBotMoveUseCase: GetBotMoveUseCase,
    private val updateBotLevelUseCase: UpdateBotLevelUseCase,
    private val analyzePatternsUseCase: AnalyzePatternsUseCase,
    private val gameRepository: GameRepository,
    private val playerRepository: PlayerRepository,
    private val botConfigDao: BotConfigDao,
    private val botLearningDataDao: BotLearningDataDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChessBoardUiState())
    val uiState: StateFlow<ChessBoardUiState> = _uiState.asStateFlow()

    private val engine = ChessEngineImpl()
    private var currentGameId = 0L
    private var currentPlayerId = 0L
    private var currentPlayer: PlayerProfile? = null
    private var botConfig = BotConfig()
    private var learningData = emptyList<BotLearningData>()
    private var botMoveJob: Job? = null
    private var gameSetupJob: Job? = null
    private var historyJob: Job? = null
    private var pendingResult: String? = null
    private var currentPlayStartedAt: Long? = null

    private val errorHandler = CoroutineExceptionHandler { _, error ->
        android.util.Log.e("ChessVM", "Coroutine error: ${error.message}", error)
        _uiState.value = _uiState.value.copy(
            isBotThinking = false,
            isMoveAnimating = false,
            isResultProcessing = false,
            errorMessage = "Sesuatu tidak menjadi. Cuba mulakan permainan semula."
        )
    }

    init {
        viewModelScope.launch(errorHandler) { initializePlayer() }
    }

    private suspend fun initializePlayer() {
        val now = System.currentTimeMillis()
        val player = playerRepository.getFirstPlayer() ?: run {
            val id = playerRepository.savePlayer(
                PlayerProfile(username = "Player", createdAt = now, updatedAt = now)
            )
            playerRepository.getPlayer(id) ?: PlayerProfile(
                id = id,
                username = "Player",
                createdAt = now,
                updatedAt = now
            )
        }
        currentPlayer = player
        currentPlayerId = player.id
        botConfig = botConfigDao.getConfig(player.id) ?: BotConfig(playerId = player.id).also {
            botConfigDao.upsert(it)
        }
        learningData = botLearningDataDao.getLearningDataForPlayer(player.id)
        // Permainan lama tidak boleh dipulihkan selepas proses aplikasi ditutup.
        gameRepository.abandonInProgressGames(player.id, now)

        _uiState.value = _uiState.value.copy(
            currentLevel = botConfig.currentLevel,
            playerProfile = player,
            isMasteryVictory = player.hasMasteredLevel999,
            learnedPatternCount = learningData.size,
            isColorSelectionVisible = !player.hasMasteredLevel999,
            isReady = true
        )
        observeHistory(player.id)
    }

    private fun observeHistory(playerId: Long) {
        historyJob?.cancel()
        historyJob = viewModelScope.launch(errorHandler) {
            gameRepository.getGamesByPlayer(playerId).collectLatest { games ->
                _uiState.value = _uiState.value.copy(games = games)
            }
        }
    }

    fun startNewGame(playerColor: Color = _uiState.value.playerColor) {
        if (currentPlayerId == 0L || currentPlayer?.hasMasteredLevel999 == true) return
        botMoveJob?.cancel()
        gameSetupJob?.cancel()
        pendingResult = null
        currentGameId = 0L
        currentPlayStartedAt = null

        val board = engine.initializeBoard()
        val botColor = playerColor.opposite()
        _uiState.value = ChessBoardUiState(
            board = board,
            playerColor = playerColor,
            botColor = botColor,
            currentTurn = Color.WHITE,
            currentLevel = botConfig.currentLevel,
            isReady = false,
            games = _uiState.value.games,
            playerProfile = currentPlayer,
            learnedPatternCount = learningData.size
        )

        gameSetupJob = viewModelScope.launch(errorHandler) {
            currentGameId = gameRepository.saveGame(
                GameSession(
                    playerId = currentPlayerId,
                    playerColor = playerColor.name,
                    result = "IN_PROGRESS",
                    botLevelStart = botConfig.currentLevel,
                    botLevelEnd = botConfig.currentLevel,
                    startedAt = System.currentTimeMillis()
                )
            )
            _uiState.value = _uiState.value.copy(isReady = true)
            if (playerColor == Color.BLACK) makeBotMove()
        }
    }

    fun advanceOrRetry() {
        val state = _uiState.value
        if (state.isResultProcessing) return
        if (state.gameResult == "WIN") {
            startNewGame(state.playerColor)
        } else if (state.gameResult == "LOSS" || state.gameResult == "DRAW") {
            _uiState.value = state.copy(isColorSelectionVisible = true)
        }
    }

    fun choosePlayerColor(color: Color) {
        if (!_uiState.value.isColorSelectionVisible) return
        startNewGame(color)
    }

    fun onSquareTapped(square: Square) {
        val state = _uiState.value
        if (!state.isReady || state.isBotThinking || state.isMoveAnimating) return
        if (state.pendingPromotionMoves.isNotEmpty()) return
        if (state.gameResult != null || state.currentTurn != state.playerColor) return
        val board = state.board ?: return
        if (!square.isOnBoard()) return

        val tappedPiece = board.squares[square.rank][square.file]
        if (state.selectedSquare == null) {
            if (tappedPiece?.color == state.playerColor) {
                _uiState.value = state.copy(
                    selectedSquare = square,
                    validMoves = engine.getValidMoves(board, square)
                )
            }
            return
        }

        val matchingMoves = state.validMoves.filter {
            it.fromSquare == state.selectedSquare && it.toSquare == square
        }
        when {
            matchingMoves.size > 1 && matchingMoves.all { it.promotionPiece != null } ->
                _uiState.value = state.copy(pendingPromotionMoves = matchingMoves)
            matchingMoves.isNotEmpty() -> executePlayerMove(matchingMoves.first())
            tappedPiece?.color == state.playerColor -> _uiState.value = state.copy(
                selectedSquare = square,
                validMoves = engine.getValidMoves(board, square)
            )
            else -> _uiState.value = state.copy(selectedSquare = null, validMoves = emptyList())
        }
    }

    fun choosePromotion(pieceType: PieceType) {
        val state = _uiState.value
        val move = state.pendingPromotionMoves.firstOrNull { it.promotionPiece == pieceType } ?: return
        _uiState.value = state.copy(pendingPromotionMoves = emptyList())
        executePlayerMove(move)
    }

    fun dismissPromotion() {
        _uiState.value = _uiState.value.copy(
            pendingPromotionMoves = emptyList(),
            selectedSquare = null,
            validMoves = emptyList()
        )
    }

    private fun executePlayerMove(move: Move) {
        val state = _uiState.value
        val board = state.board ?: return
        markPlayStartedIfNeeded()
        val nextBoard = engine.makeMove(board, move)
        val history = state.moveHistory + move
        val opponent = state.playerColor.opposite()
        val check = engine.isCheck(nextBoard, opponent)
        val mate = engine.isCheckmate(nextBoard, opponent)
        val stale = engine.isStalemate(nextBoard, opponent)
        val draw = engine.isDraw(nextBoard)

        saveMove(state.playerColor, move, history.size, check, mate, nextBoard)
        pendingResult = when {
            mate -> "WIN"
            stale || draw -> "DRAW"
            else -> null
        }
        _uiState.value = state.copy(
            board = nextBoard,
            selectedSquare = null,
            validMoves = emptyList(),
            pendingPromotionMoves = emptyList(),
            moveHistory = history,
            lastMove = move,
            currentTurn = opponent,
            isCheck = check,
            isCheckmate = mate,
            isMoveAnimating = true
        )
    }

    private fun makeBotMove() {
        val state = _uiState.value
        val board = state.board ?: return
        if (state.currentTurn != state.botColor || state.gameResult != null) return
        _uiState.value = state.copy(isBotThinking = true)

        botMoveJob = viewModelScope.launch(errorHandler) {
            try {
                val botMove = getBotMoveUseCase(board, state.botColor, botConfig, learningData)
                val current = _uiState.value
                val currentBoard = current.board ?: return@launch
                if (currentBoard != board || current.gameResult != null) return@launch

                val nextBoard = engine.makeMove(currentBoard, botMove)
                val history = current.moveHistory + botMove
                val check = engine.isCheck(nextBoard, current.playerColor)
                val mate = engine.isCheckmate(nextBoard, current.playerColor)
                val stale = engine.isStalemate(nextBoard, current.playerColor)
                val draw = engine.isDraw(nextBoard)

                saveMove(current.botColor, botMove, history.size, check, mate, nextBoard)
                pendingResult = when {
                    mate -> "LOSS"
                    stale || draw -> "DRAW"
                    else -> null
                }
                _uiState.value = current.copy(
                    board = nextBoard,
                    isBotThinking = false,
                    isMoveAnimating = true,
                    moveHistory = history,
                    lastMove = botMove,
                    currentTurn = current.playerColor,
                    isCheck = check,
                    isCheckmate = mate
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                android.util.Log.e("ChessVM", "Bot move error: ${error.message}", error)
                _uiState.value = _uiState.value.copy(
                    isBotThinking = false,
                    errorMessage = "Bot tidak dapat memilih langkah. Mulakan permainan baharu."
                )
            }
        }
    }

    /** Dipanggil oleh papan selepas animasi mendarat; mengawal urutan giliran. */
    fun onMoveAnimationFinished() {
        val state = _uiState.value
        if (!state.isMoveAnimating) return
        _uiState.value = state.copy(isMoveAnimating = false)
        val result = pendingResult
        pendingResult = null
        when {
            result != null -> finishGame(result)
            state.currentTurn == state.botColor -> makeBotMove()
        }
    }

    private fun finishGame(result: String) {
        val finishedState = _uiState.value
        val levelPlayed = botConfig.currentLevel
        val isMasteryVictory = result == "WIN" && levelPlayed >= 999
        _uiState.value = finishedState.copy(
            gameResult = result,
            isMasteryVictory = isMasteryVictory,
            isBotThinking = false,
            isResultProcessing = true
        )

        viewModelScope.launch(errorHandler) {
            try {
                val patterns = analyzePatternsUseCase(
                    currentPlayerId,
                    finishedState.playerColor,
                    finishedState.moveHistory,
                    result
                )
                learningData = botLearningDataDao.getLearningDataForPlayer(currentPlayerId)
                botConfig = updateBotLevelUseCase(
                    botConfig.copy(playerId = currentPlayerId),
                    playerWon = result == "WIN"
                )

                val session = if (currentGameId > 0) gameRepository.getGame(currentGameId) else null
                val playStartedAt = session?.playStartedAt ?: currentPlayStartedAt
                if (session != null) {
                    gameRepository.updateGame(
                        session.copy(
                            result = result,
                            botLevelEnd = botConfig.currentLevel,
                            totalMoves = finishedState.moveHistory.size,
                            openingUsed = patterns.firstOrNull()?.label,
                            learningSummary = patterns.take(3)
                                .joinToString("\n") { it.explanation }
                                .takeIf { it.isNotBlank() },
                            playStartedAt = playStartedAt,
                            endedAt = System.currentTimeMillis()
                        )
                    )
                }

                currentPlayer = updatePlayerStats(
                    currentPlayer,
                    result,
                    playStartedAt,
                    isMasteryVictory
                )
                currentPlayer?.let { playerRepository.updatePlayer(it) }

                _uiState.value = _uiState.value.copy(
                    currentLevel = botConfig.currentLevel,
                    playerProfile = currentPlayer,
                    isMasteryVictory = isMasteryVictory,
                    learningInsights = patterns.map { it.explanation }.take(2),
                    learnedPatternCount = learningData.size,
                    isResultProcessing = false
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                android.util.Log.e("ChessVM", "Game finish error: ${error.message}", error)
                _uiState.value = _uiState.value.copy(
                    isResultProcessing = false,
                    errorMessage = "Keputusan permainan tidak dapat disimpan sepenuhnya."
                )
            }
        }
    }

    private fun updatePlayerStats(
        player: PlayerProfile?,
        result: String,
        playStartedAt: Long?,
        isMasteryVictory: Boolean
    ): PlayerProfile? {
        player ?: return null
        val now = System.currentTimeMillis()
        val streakType = when (result) {
            "WIN" -> "WIN"
            "LOSS" -> "LOSS"
            else -> "DRAW"
        }
        val nextStreak = if (player.streakType == streakType) player.currentStreak + 1 else 1
        return player.copy(
            totalGames = player.totalGames + 1,
            wins = player.wins + if (result == "WIN") 1 else 0,
            losses = player.losses + if (result == "LOSS") 1 else 0,
            draws = player.draws + if (result == "DRAW") 1 else 0,
            currentStreak = nextStreak,
            streakType = streakType,
            totalPlayTimeMs = player.totalPlayTimeMs +
                (playStartedAt?.let { (now - it).coerceAtLeast(0L) } ?: 0L),
            hasMasteredLevel999 = player.hasMasteredLevel999 || isMasteryVictory,
            masteredAt = when {
                player.masteredAt != null -> player.masteredAt
                isMasteryVictory -> now
                else -> null
            },
            updatedAt = now
        )
    }

    private fun markPlayStartedIfNeeded() {
        if (currentPlayStartedAt != null || currentGameId <= 0L) return
        currentPlayStartedAt = System.currentTimeMillis()
    }

    private fun saveMove(
        color: Color,
        move: Move,
        moveNumber: Int,
        isCheck: Boolean,
        isMate: Boolean,
        board: Board
    ) {
        val gameId = currentGameId
        if (gameId <= 0) return
        viewModelScope.launch(errorHandler) {
            gameRepository.saveMove(
                MoveEntity(
                    gameId = gameId,
                    moveNumber = moveNumber,
                    color = color.name,
                    fromSquare = move.fromSquare.toAlgebraic(),
                    toSquare = move.toSquare.toAlgebraic(),
                    pieceType = move.piece.type.name,
                    promotionPiece = move.promotionPiece?.name,
                    capturedPiece = move.capturedPiece?.type?.name,
                    isCheck = isCheck,
                    isCheckmate = isMate,
                    isCastling = move.isCastling,
                    isEnPassant = move.isEnPassant,
                    fenAfter = engine.toFEN(board)
                )
            )
            gameRepository.getGame(gameId)?.let { session ->
                if (session.result == "IN_PROGRESS") {
                    gameRepository.updateGame(
                        session.copy(
                            totalMoves = maxOf(session.totalMoves, moveNumber),
                            playStartedAt = session.playStartedAt ?: currentPlayStartedAt
                        )
                    )
                }
            }
        }
    }
}
