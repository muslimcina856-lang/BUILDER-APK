package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*
import kotlin.math.abs

class GameStateDetector(private val validator: MoveValidator) {

    fun isInCheck(board: Board, color: Color): Boolean {
        val king = findKing(board, color) ?: return true
        return validator.isSquareAttacked(board, king, color.opposite())
    }

    fun isCheckmate(board: Board, color: Color): Boolean =
        isInCheck(board, color) && !hasAnyLegalMove(board, color)

    fun isStalemate(board: Board, color: Color): Boolean =
        !isInCheck(board, color) && !hasAnyLegalMove(board, color)

    fun isDraw(board: Board): Boolean =
        board.halfmoveClock >= 100 || isThreefoldRepetition(board) || isInsufficientMaterial(board)

    private fun hasAnyLegalMove(board: Board, color: Color): Boolean {
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            if (piece.color != color) continue
            if (validator.generatePieceMoves(board, Square(file, rank)).any {
                    !isInCheck(applyMove(board, it), color)
                }) return true
        }
        return false
    }

    fun findKing(board: Board, color: Color): Square? {
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file]
            if (piece?.type == PieceType.KING && piece.color == color) return Square(file, rank)
        }
        return null
    }

    fun applyMove(board: Board, move: Move): Board {
        val movingPiece = board.squares[move.fromSquare.rank][move.fromSquare.file]
            ?: throw IllegalArgumentException("Tiada bidak di ${move.fromSquare.toAlgebraic()}")
        val squares = Array(8) { rank -> Array<Piece?>(8) { file -> board.squares[rank][file] } }

        val enPassant = move.isEnPassant || (
            movingPiece.type == PieceType.PAWN &&
                move.fromSquare.file != move.toSquare.file &&
                squares[move.toSquare.rank][move.toSquare.file] == null &&
                move.toSquare == board.enPassantTarget
            )
        val capturedSquare = if (enPassant) Square(move.toSquare.file, move.fromSquare.rank) else move.toSquare
        val capturedPiece = squares[capturedSquare.rank][capturedSquare.file]

        squares[move.fromSquare.rank][move.fromSquare.file] = null
        if (enPassant) squares[capturedSquare.rank][capturedSquare.file] = null
        squares[move.toSquare.rank][move.toSquare.file] = move.promotionPiece
            ?.let { Piece(it, movingPiece.color) } ?: movingPiece

        val isCastleKing = move.isCastleKingSide ||
            (movingPiece.type == PieceType.KING && move.toSquare.file - move.fromSquare.file == 2)
        val isCastleQueen = move.isCastleQueenSide ||
            (movingPiece.type == PieceType.KING && move.fromSquare.file - move.toSquare.file == 2)
        if (isCastleKing) moveRookForCastle(squares, movingPiece.color, 7, 5)
        if (isCastleQueen) moveRookForCastle(squares, movingPiece.color, 0, 3)

        var whiteKingSide = board.whiteCanCastleKingSide
        var whiteQueenSide = board.whiteCanCastleQueenSide
        var blackKingSide = board.blackCanCastleKingSide
        var blackQueenSide = board.blackCanCastleQueenSide

        if (movingPiece.type == PieceType.KING) {
            if (movingPiece.color == Color.WHITE) {
                whiteKingSide = false; whiteQueenSide = false
            } else {
                blackKingSide = false; blackQueenSide = false
            }
        }
        if (movingPiece.type == PieceType.ROOK) {
            when (move.fromSquare) {
                Square(0, 0) -> whiteQueenSide = false
                Square(7, 0) -> whiteKingSide = false
                Square(0, 7) -> blackQueenSide = false
                Square(7, 7) -> blackKingSide = false
            }
        }
        if (capturedPiece?.type == PieceType.ROOK) {
            when (capturedSquare) {
                Square(0, 0) -> whiteQueenSide = false
                Square(7, 0) -> whiteKingSide = false
                Square(0, 7) -> blackQueenSide = false
                Square(7, 7) -> blackKingSide = false
            }
        }

        val nextEnPassant = if (movingPiece.type == PieceType.PAWN &&
            abs(move.toSquare.rank - move.fromSquare.rank) == 2
        ) Square(move.fromSquare.file, (move.fromSquare.rank + move.toSquare.rank) / 2) else null

        val next = Board(
            squares = squares,
            activeColor = movingPiece.color.opposite(),
            whiteCanCastleKingSide = whiteKingSide,
            whiteCanCastleQueenSide = whiteQueenSide,
            blackCanCastleKingSide = blackKingSide,
            blackCanCastleQueenSide = blackQueenSide,
            enPassantTarget = nextEnPassant,
            halfmoveClock = if (movingPiece.type == PieceType.PAWN || capturedPiece != null) 0
                else board.halfmoveClock + 1,
            fullmoveNumber = board.fullmoveNumber + if (movingPiece.color == Color.BLACK) 1 else 0
        )
        val previous = board.positionHistory.ifEmpty { listOf(board.repetitionKey()) }
        return next.copy(positionHistory = previous + next.repetitionKey())
    }

    private fun moveRookForCastle(
        squares: Array<Array<Piece?>>,
        color: Color,
        rookFromFile: Int,
        rookToFile: Int
    ) {
        val rank = if (color == Color.WHITE) 0 else 7
        val rook = squares[rank][rookFromFile]
        if (rook?.type == PieceType.ROOK && rook.color == color) {
            squares[rank][rookFromFile] = null
            squares[rank][rookToFile] = rook
        }
    }

    private fun isThreefoldRepetition(board: Board): Boolean {
        val current = board.repetitionKey()
        return board.positionHistory.count { it == current } >= 3
    }

    private fun isInsufficientMaterial(board: Board): Boolean {
        val nonKings = mutableListOf<Pair<Piece, Square>>()
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            if (piece.type != PieceType.KING) nonKings += piece to Square(file, rank)
        }
        if (nonKings.isEmpty()) return true
        if (nonKings.size == 1) {
            return nonKings.first().first.type in setOf(PieceType.BISHOP, PieceType.KNIGHT)
        }
        if (nonKings.all { it.first.type == PieceType.BISHOP }) {
            val squareColors = nonKings.map { (_, square) -> (square.file + square.rank) % 2 }.distinct()
            return squareColors.size == 1
        }
        return false
    }
}

fun Color.opposite() = if (this == Color.WHITE) Color.BLACK else Color.WHITE

internal fun Board.repetitionKey(): String {
    val placement = buildString {
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val piece = squares[rank][file]
                if (piece == null) {
                    empty++
                } else {
                    if (empty > 0) append(empty).also { empty = 0 }
                    val symbol = when (piece.type) {
                        PieceType.KING -> 'k'; PieceType.QUEEN -> 'q'; PieceType.ROOK -> 'r'
                        PieceType.BISHOP -> 'b'; PieceType.KNIGHT -> 'n'; PieceType.PAWN -> 'p'
                    }
                    append(if (piece.color == Color.WHITE) symbol.uppercaseChar() else symbol)
                }
            }
            if (empty > 0) append(empty)
            if (rank > 0) append('/')
        }
    }
    val rights = buildString {
        if (whiteCanCastleKingSide) append('K')
        if (whiteCanCastleQueenSide) append('Q')
        if (blackCanCastleKingSide) append('k')
        if (blackCanCastleQueenSide) append('q')
    }.ifEmpty { "-" }
    return "$placement ${if (activeColor == Color.WHITE) "w" else "b"} $rights ${enPassantTarget?.toAlgebraic() ?: "-"}"
}
