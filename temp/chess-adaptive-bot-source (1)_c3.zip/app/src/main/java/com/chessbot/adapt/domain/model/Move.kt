package com.chessbot.adapt.domain.model

data class Move(
    val fromSquare: Square,
    val toSquare: Square,
    val piece: Piece,
    val promotionPiece: PieceType? = null,
    val capturedPiece: Piece? = null,
    val isCastleKingSide: Boolean = false,
    val isCastleQueenSide: Boolean = false,
    val isEnPassant: Boolean = false
) {
    val isCapture: Boolean get() = capturedPiece != null || isEnPassant
    val isCastling: Boolean get() = isCastleKingSide || isCastleQueenSide
}
