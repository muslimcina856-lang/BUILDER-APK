package com.chessbot.adapt.presentation.mastery

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun MasteryVictoryScreen(
    evolutionData: List<Int>,
    victoryNote: String,
    onEasterEggTriggered: () -> Unit,
    onViewHistory: () -> Unit
) {
    var tapCount by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "MASTERED",
            style = MaterialTheme.typography.displayLarge,
            modifier = Modifier.clickable {
                tapCount++
                if (tapCount >= 10) onEasterEggTriggered()
            }
        )
        Spacer(Modifier.height(16.dp))
        if (evolutionData.isNotEmpty()) {
            VictoryEvolutionGraph(evolutionData)
        }
        Spacer(Modifier.height(16.dp))
        Text(victoryNote, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onViewHistory) {
            Text("Lihat Sejarah Evolusi")
        }
    }
}

@Composable
fun VictoryEvolutionGraph(data: List<Int>) {
    if (data.size < 2) return

    val maxVal = data.max().toFloat().coerceAtLeast(1f)

    Canvas(modifier = Modifier.fillMaxWidth().height(120.dp)) {
        val w = size.width
        val h = size.height
        val stepX = w / (data.size - 1).toFloat()

        val path = Path()
        data.forEachIndexed { i, value ->
            val x = i * stepX
            val y = h - (value / maxVal) * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(path, Color(0xFF4CAF50), style = Stroke(width = 3.dp.toPx()))

        // Dot pada setiap titik
        data.forEachIndexed { i, value ->
            drawCircle(
                Color(0xFF2196F3),
                radius = 4.dp.toPx(),
                center = Offset(i * stepX, h - (value / maxVal) * h)
            )
        }
    }
}
