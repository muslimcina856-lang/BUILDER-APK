package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotLearningData

/** Menggabungkan corak sejarah dengan tahap keyakinan dan keberkesanan strategi. */
class AdaptiveLearner {

    fun adjustWeights(
        currentWeights: EvalWeights,
        learningData: List<BotLearningData>,
        enabled: Boolean
    ): EvalWeights {
        if (!enabled || learningData.isEmpty()) return currentWeights

        var aggression = currentWeights.aggression
        var defense = currentWeights.defense
        var position = currentWeights.position

        learningData.forEach { data ->
            val confidence = (data.timesApplied / 6f).coerceIn(0.15f, 1f)
            // Strategi yang belum berjaya diberi sedikit dorongan untuk bereksperimen lagi.
            val adjustment = (1.15f - data.effectivenessScore * 0.35f).coerceIn(0.8f, 1.15f)
            aggression += data.aggressionModifier * confidence * adjustment
            defense += data.defenseModifier * confidence * adjustment
            position += data.positionWeightModifier * confidence * adjustment
        }

        return currentWeights.copy(
            aggression = aggression.coerceIn(0.35f, 1.65f),
            defense = defense.coerceIn(0.35f, 1.65f),
            position = position.coerceIn(0.55f, 1.80f)
        )
    }
}
