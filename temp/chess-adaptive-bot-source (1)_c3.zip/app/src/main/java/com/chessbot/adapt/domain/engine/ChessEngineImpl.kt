package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

/** Enjin peraturan catur dan penukaran FEN. */
class ChessEngineImpl(
    private val validator: MoveValidator = MoveValidator(),
    private val stateDetector: GameStateDetector = GameStateDetector(validator)
) : ChessEngine {

    override fun initializeBoard(): Board {
        val squares = Array(8) { Array<Piece?>(8) { null } }
        val backRank = listOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
        )
        backRank.forEachIndexed { file, type ->
            squares[0][file] = Piece(type, Color.WHITE)
            squares[7][file] = Piece(type, Color.BLACK)
        }
        for (file in 0..7) {
            squares[1][file] = Piece(PieceType.PAWN, Color.WHITE)
            squares[6][file] = Piece(PieceType.PAWN, Color.BLACK)
        }
        val board = Board(squares)
        return board.copy(positionHistory = listOf(board.repetitionKey()))
    }

    override fun getValidMoves(board: Board, square: Square): List<Move> {
        if (!square.isOnBoard()) return emptyList()
        val piece = board.squares[square.rank][square.file] ?: return emptyList()
        return validator.generatePieceMoves(board, square).filter { move ->
            !stateDetector.isInCheck(stateDetector.applyMove(board, move), piece.color)
        }
    }

    override fun makeMove(board: Board, move: Move): Board = stateDetector.applyMove(board, move)
    override fun isCheck(board: Board, color: Color): Boolean = stateDetector.isInCheck(board, color)
    override fun isCheckmate(board: Board, color: Color): Boolean = stateDetector.isCheckmate(board, color)
    override fun isStalemate(board: Board, color: Color): Boolean = stateDetector.isStalemate(board, color)
    override fun isDraw(board: Board): Boolean = stateDetector.isDraw(board)

    override fun toFEN(board: Board): String =
        "${board.repetitionKey()} ${board.halfmoveClock} ${board.fullmoveNumber}"

    override fun fromFEN(fen: String): Board {
        val parts = fen.trim().split(Regex("\\s+"))
        require(parts.size >= 4) { "FEN tidak lengkap" }
        val rows = parts[0].split('/')
        require(rows.size == 8) { "FEN mesti mempunyai 8 rank" }
        val squares = Array(8) { Array<Piece?>(8) { null } }

        rows.forEachIndexed { rowIndex, row ->
            val rank = 7 - rowIndex
            var file = 0
            for (char in row) {
                if (char.isDigit()) {
                    file += char.digitToInt()
                } else {
                    require(file in 0..7) { "FEN mempunyai terlalu banyak petak" }
                    val color = if (char.isUpperCase()) Color.WHITE else Color.BLACK
                    val type = when (char.lowercaseChar()) {
                        'k' -> PieceType.KING; 'q' -> PieceType.QUEEN; 'r' -> PieceType.ROOK
                        'b' -> PieceType.BISHOP; 'n' -> PieceType.KNIGHT; 'p' -> PieceType.PAWN
                        else -> throw IllegalArgumentException("Bidak FEN tidak dikenali: $char")
                    }
                    squares[rank][file++] = Piece(type, color)
                }
            }
            require(file == 8) { "Setiap rank FEN mesti mempunyai 8 petak" }
        }

        val rights = parts[2]
        val board = Board(
            squares = squares,
            activeColor = if (parts[1] == "b") Color.BLACK else Color.WHITE,
            whiteCanCastleKingSide = 'K' in rights,
            whiteCanCastleQueenSide = 'Q' in rights,
            blackCanCastleKingSide = 'k' in rights,
            blackCanCastleQueenSide = 'q' in rights,
            enPassantTarget = parts[3].takeUnless { it == "-" }?.let(Square::fromAlgebraic),
            halfmoveClock = parts.getOrNull(4)?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
            fullmoveNumber = parts.getOrNull(5)?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        )
        return board.copy(positionHistory = listOf(board.repetitionKey()))
    }
}
