package com.chessbot.adapt.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.chessbot.adapt.presentation.chessboard.ChessBoardViewModel
import com.chessbot.adapt.presentation.chessboard.ChessScreen
import com.chessbot.adapt.presentation.history.HistoryScreen
import com.chessbot.adapt.presentation.stats.StatsScreen
import com.chessbot.adapt.ui.theme.ChessBotTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            ChessBotTheme { AdaptiveChessApp() }
        }
    }
}

private enum class AppTab { PLAY, HISTORY, STATS }

@Composable
private fun AdaptiveChessApp(viewModel: ChessBoardViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.PLAY) }

    Scaffold(
        containerColor = Color(0xFF0D0F12),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF14171B), tonalElevation = 0.dp) {
                NavigationBarItem(
                    selected = selectedTab == AppTab.PLAY,
                    onClick = { selectedTab = AppTab.PLAY },
                    icon = { Icon(Icons.Rounded.SportsEsports, null) },
                    label = { Text("Main") },
                    colors = navColors()
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.HISTORY,
                    onClick = { selectedTab = AppTab.HISTORY },
                    icon = { Icon(Icons.Rounded.History, null) },
                    label = { Text("Sejarah") },
                    colors = navColors()
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.STATS,
                    onClick = { selectedTab = AppTab.STATS },
                    icon = { Icon(Icons.Rounded.BarChart, null) },
                    label = { Text("Prestasi") },
                    colors = navColors()
                )
            }
        }
    ) { padding ->
        when (selectedTab) {
            AppTab.PLAY -> ChessScreen(Modifier.padding(padding), viewModel)
            AppTab.HISTORY -> HistoryScreen(
                games = state.games,
                modifier = Modifier.padding(padding)
            )
            AppTab.STATS -> StatsScreen(
                player = state.playerProfile,
                botLevel = state.currentLevel,
                learnedPatterns = state.learnedPatternCount,
                modifier = Modifier.padding(padding)
            )
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Color(0xFFD8B477),
    selectedTextColor = Color(0xFFD8B477),
    indicatorColor = Color(0xFFD8B477).copy(alpha = 0.13f),
    unselectedIconColor = Color(0xFF858681),
    unselectedTextColor = Color(0xFF858681)
)
