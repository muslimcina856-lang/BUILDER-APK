package com.chessbot.adapt.domain.repository

import com.chessbot.adapt.data.local.entity.GameSession
import com.chessbot.adapt.data.local.entity.MoveEntity
import kotlinx.coroutines.flow.Flow

interface GameRepository {
    suspend fun saveGame(session: GameSession): Long
    suspend fun updateGame(session: GameSession)
    suspend fun getGame(gameId: Long): GameSession?
    fun getGamesByPlayer(playerId: Long): Flow<List<GameSession>>
    suspend fun abandonInProgressGames(playerId: Long, endedAt: Long)
    suspend fun saveMove(move: MoveEntity): Long
    suspend fun getMovesForGame(gameId: Long): List<MoveEntity>
}
