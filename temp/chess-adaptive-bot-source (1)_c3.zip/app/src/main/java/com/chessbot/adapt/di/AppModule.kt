package com.chessbot.adapt.di

import com.chessbot.adapt.data.local.dao.*
import com.chessbot.adapt.data.local.database.ChessDatabase
import com.chessbot.adapt.data.repository.GameRepositoryImpl
import com.chessbot.adapt.data.repository.PlayerRepositoryImpl
import com.chessbot.adapt.domain.bot.MinimaxEngine
import com.chessbot.adapt.domain.bot.PatternAnalyzer
import com.chessbot.adapt.domain.engine.ChessEngineImpl
import com.chessbot.adapt.domain.repository.GameRepository
import com.chessbot.adapt.domain.repository.PlayerRepository
import com.chessbot.adapt.domain.usecase.AnalyzePatternsUseCase
import com.chessbot.adapt.domain.usecase.GetBotMoveUseCase
import com.chessbot.adapt.domain.usecase.UpdateBotLevelUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideChessDatabase(application: android.app.Application): ChessDatabase {
        return ChessDatabase.create(application)
    }

    @Provides fun providePlayerProfileDao(db: ChessDatabase): PlayerProfileDao = db.playerProfileDao()
    @Provides fun provideGameSessionDao(db: ChessDatabase): GameSessionDao = db.gameSessionDao()
    @Provides fun provideMoveDao(db: ChessDatabase): MoveDao = db.moveDao()
    @Provides fun provideBotConfigDao(db: ChessDatabase): BotConfigDao = db.botConfigDao()
    @Provides fun providePatternDefinitionDao(db: ChessDatabase): PatternDefinitionDao = db.patternDefinitionDao()
    @Provides fun providePlayerPatternStatsDao(db: ChessDatabase): PlayerPatternStatsDao = db.playerPatternStatsDao()
    @Provides fun provideBotLearningDataDao(db: ChessDatabase): BotLearningDataDao = db.botLearningDataDao()

    @Provides
    @Singleton
    fun provideGameRepository(
        gameSessionDao: GameSessionDao,
        moveDao: MoveDao
    ): GameRepository = GameRepositoryImpl(gameSessionDao, moveDao)

    @Provides
    @Singleton
    fun providePlayerRepository(
        playerProfileDao: PlayerProfileDao
    ): PlayerRepository = PlayerRepositoryImpl(playerProfileDao)

    @Provides
    @Singleton
    fun provideChessEngine(): ChessEngineImpl = ChessEngineImpl()

    @Provides
    @Singleton
    fun providePatternAnalyzer(): PatternAnalyzer = PatternAnalyzer()

    @Provides
    @Singleton
    fun provideMinimaxEngine(): MinimaxEngine = MinimaxEngine()

    @Provides
    @Singleton
    fun provideGetBotMoveUseCase(
        minimaxEngine: MinimaxEngine
    ): GetBotMoveUseCase = GetBotMoveUseCase(minimaxEngine)

    @Provides
    @Singleton
    fun provideUpdateBotLevelUseCase(
        botConfigDao: BotConfigDao
    ): UpdateBotLevelUseCase = UpdateBotLevelUseCase(botConfigDao)

    // Fix — AnalyzePatternsUseCase disediakan untuk inject ke ViewModel
    @Provides
    @Singleton
    fun provideAnalyzePatternsUseCase(
        patternAnalyzer: PatternAnalyzer,
        patternDefinitionDao: PatternDefinitionDao,
        playerPatternStatsDao: PlayerPatternStatsDao,
        botLearningDataDao: BotLearningDataDao
    ): AnalyzePatternsUseCase = AnalyzePatternsUseCase(
        patternAnalyzer,
        patternDefinitionDao,
        playerPatternStatsDao,
        botLearningDataDao
    )
}
