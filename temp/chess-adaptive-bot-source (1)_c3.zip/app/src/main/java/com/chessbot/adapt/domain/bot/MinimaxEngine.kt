package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.engine.GameStateDetector
import com.chessbot.adapt.domain.engine.MoveValidator
import com.chessbot.adapt.domain.engine.opposite
import com.chessbot.adapt.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MinimaxEngine(
    private val adaptiveLearner: AdaptiveLearner = AdaptiveLearner()
) : BotEngine {

    private val validator = MoveValidator()
    private val stateDetector = GameStateDetector(validator)
    private val timeLimitMs = 2_200L
    private var deadlineMs = 0L

    override suspend fun getBestMove(
        board: Board,
        color: Color,
        config: BotConfig,
        learningData: List<BotLearningData>
    ): Move = withContext(Dispatchers.Default) {
        deadlineMs = System.currentTimeMillis() + timeLimitMs
        val weights = buildWeights(config, learningData)
        val maximumDepth = config.searchDepth.coerceIn(1, 5)
        val legalMoves = getAllLegalMoves(board, color)
        require(legalMoves.isNotEmpty()) { "Tiada langkah sah untuk $color" }
        if (legalMoves.size == 1) return@withContext legalMoves.first()

        var completedBest = legalMoves.first()
        for (depth in 1..maximumDepth) {
            coroutineContext.ensureActive()
            var depthBest = completedBest
            var depthBestScore = Int.MIN_VALUE + 1
            var alpha = Int.MIN_VALUE + 1
            var completed = true

            try {
                for (move in orderedMoves(board, legalMoves)) {
                    checkTime()
                    val score = alphaBeta(
                        board = stateDetector.applyMove(board, move),
                        depth = depth - 1,
                        alphaIn = alpha,
                        betaIn = Int.MAX_VALUE - 1,
                        maximizing = false,
                        botColor = color,
                        weights = weights
                    )
                    if (score > depthBestScore) {
                        depthBestScore = score
                        depthBest = move
                    }
                    alpha = max(alpha, score)
                }
            } catch (_: SearchTimeout) {
                completed = false
            }

            if (completed) completedBest = depthBest else break
        }
        completedBest
    }

    private fun alphaBeta(
        board: Board,
        depth: Int,
        alphaIn: Int,
        betaIn: Int,
        maximizing: Boolean,
        botColor: Color,
        weights: EvalWeights
    ): Int {
        checkTime()
        val turn = if (maximizing) botColor else botColor.opposite()
        val legalMoves = getAllLegalMoves(board, turn)

        if (legalMoves.isEmpty()) {
            return if (stateDetector.isInCheck(board, turn)) {
                if (turn == botColor) -MATE_SCORE - depth else MATE_SCORE + depth
            } else 0
        }
        if (stateDetector.isDraw(board)) return 0
        if (depth == 0) return evaluatePosition(board, botColor, weights)

        var alpha = alphaIn
        var beta = betaIn
        if (maximizing) {
            var value = Int.MIN_VALUE + 1
            for (move in orderedMoves(board, legalMoves)) {
                value = max(value, alphaBeta(
                    stateDetector.applyMove(board, move), depth - 1,
                    alpha, beta, false, botColor, weights
                ))
                alpha = max(alpha, value)
                if (alpha >= beta) break
            }
            return value
        }

        var value = Int.MAX_VALUE - 1
        for (move in orderedMoves(board, legalMoves)) {
            value = min(value, alphaBeta(
                stateDetector.applyMove(board, move), depth - 1,
                alpha, beta, true, botColor, weights
            ))
            beta = min(beta, value)
            if (alpha >= beta) break
        }
        return value
    }

    override fun evaluatePosition(board: Board, color: Color, weights: EvalWeights): Int {
        val opponent = color.opposite()
        val material = materialScore(board, color) - materialScore(board, opponent)
        val position = positionalScore(board, color) - positionalScore(board, opponent)
        val mobility = mobilityScore(board, color) - mobilityScore(board, opponent)
        val pawns = pawnStructureScore(board, color) - pawnStructureScore(board, opponent)
        val center = centerControlScore(board, color) - centerControlScore(board, opponent)
        val tactics = tacticalPressure(board, color) - tacticalPressure(board, opponent)
        val ownSafety = kingSafetyScore(board, color)
        val opponentSafety = kingSafetyScore(board, opponent)

        return (material * weights.material).toInt() +
            (position * weights.position).toInt() +
            (mobility * weights.mobility).toInt() +
            (pawns * weights.pawnStructure).toInt() +
            (center * weights.centerControl).toInt() +
            (tactics * weights.tactical).toInt() +
            (ownSafety * weights.kingSafety * weights.defense).toInt() -
            (opponentSafety * weights.kingSafety * weights.aggression).toInt()
    }

    private fun getAllLegalMoves(board: Board, color: Color): List<Move> {
        val moves = ArrayList<Move>(40)
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            if (piece.color != color) continue
            for (move in validator.generatePieceMoves(board, Square(file, rank))) {
                if (!stateDetector.isInCheck(stateDetector.applyMove(board, move), color)) moves += move
            }
        }
        return moves
    }

    private fun orderedMoves(board: Board, moves: List<Move>): List<Move> = moves.sortedByDescending { move ->
        val captured = move.capturedPiece ?: board.squares[move.toSquare.rank][move.toSquare.file]
        val captureScore = captured?.let { pieceValue(it.type) * 10 - pieceValue(move.piece.type) } ?: 0
        captureScore + if (move.promotionPiece != null) pieceValue(move.promotionPiece) else 0
    }

    private fun materialScore(board: Board, color: Color): Int = pieces(board, color).sumOf {
        pieceValue(it.first.type)
    }

    private fun positionalScore(board: Board, color: Color): Int = pieces(board, color).sumOf { (piece, square) ->
        val centerDistance = abs(3.5 - square.rank) + abs(3.5 - square.file)
        when (piece.type) {
            PieceType.KNIGHT, PieceType.BISHOP -> max(0, ((7 - centerDistance) * 5).toInt())
            PieceType.PAWN -> {
                val progress = if (color == Color.WHITE) square.rank else 7 - square.rank
                max(0, ((7 - centerDistance) * 2).toInt()) + progress * 2
            }
            PieceType.ROOK -> if (square.rank == if (color == Color.WHITE) 6 else 1) 12 else 0
            PieceType.QUEEN -> max(0, ((7 - centerDistance) * 1.5).toInt())
            PieceType.KING -> 0
        }
    }

    private fun mobilityScore(board: Board, color: Color): Int = pieces(board, color).sumOf { (_, square) ->
        validator.generatePieceMoves(board, square).size * 2
    }

    private fun kingSafetyScore(board: Board, color: Color): Int {
        val king = stateDetector.findKing(board, color) ?: return -1_000
        val direction = if (color == Color.WHITE) 1 else -1
        var score = if (king.file in setOf(2, 6)) 30 else 0
        for (df in -1..1) {
            val file = king.file + df
            val rank = king.rank + direction
            if (file in 0..7 && rank in 0..7) {
                val shield = board.squares[rank][file]
                if (shield?.type == PieceType.PAWN && shield.color == color) score += 14
            }
        }
        if (validator.isSquareAttacked(board, king, color.opposite())) score -= 45
        return score
    }

    private fun pawnStructureScore(board: Board, color: Color): Int {
        val pawnFiles = IntArray(8)
        val pawns = pieces(board, color).filter { it.first.type == PieceType.PAWN }
        pawns.forEach { pawnFiles[it.second.file]++ }
        var score = 0
        pawnFiles.forEachIndexed { file, count ->
            if (count > 1) score -= (count - 1) * 14
            if (count > 0) {
                val hasNeighbor = (file > 0 && pawnFiles[file - 1] > 0) ||
                    (file < 7 && pawnFiles[file + 1] > 0)
                if (!hasNeighbor) score -= count * 9
            }
        }
        return score
    }

    private fun centerControlScore(board: Board, color: Color): Int {
        val centers = listOf(Square(3, 3), Square(4, 3), Square(3, 4), Square(4, 4))
        var score = 0
        centers.forEach { square ->
            val occupant = board.squares[square.rank][square.file]
            if (occupant?.color == color) score += 12
            if (validator.isSquareAttacked(board, square, color)) score += 5
        }
        return score
    }

    private fun tacticalPressure(board: Board, color: Color): Int = pieces(board, color).sumOf { (_, square) ->
        validator.generatePieceMoves(board, square).sumOf { move ->
            move.capturedPiece?.let { (pieceValue(it.type) / 25).coerceAtMost(30) } ?: 0
        }
    }

    private fun pieces(board: Board, color: Color): List<Pair<Piece, Square>> {
        val result = ArrayList<Pair<Piece, Square>>(16)
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            if (piece.color == color) result += piece to Square(file, rank)
        }
        return result
    }

    private fun buildWeights(config: BotConfig, learningData: List<BotLearningData>): EvalWeights {
        val configured = EvalWeights(
            material = 1.0f,
            position = 0.65f + config.evalPositional,
            kingSafety = 0.75f + config.evalDefense * 0.5f,
            pawnStructure = 0.8f,
            mobility = 0.8f + config.evalTactical * 0.25f,
            centerControl = 0.9f + config.patternRecognitionWeight * 0.5f,
            tactical = 0.75f + config.evalTactical * 0.5f,
            aggression = 0.45f + config.evalAggression * 0.5f,
            defense = 0.45f + config.evalDefense * 0.5f
        )
        return adaptiveLearner.adjustWeights(configured, learningData, config.learningEnabled)
    }

    private fun checkTime() {
        if (System.currentTimeMillis() >= deadlineMs) throw SearchTimeout()
    }

    private fun pieceValue(type: PieceType) = when (type) {
        PieceType.PAWN -> 100; PieceType.KNIGHT -> 320; PieceType.BISHOP -> 330
        PieceType.ROOK -> 500; PieceType.QUEEN -> 900; PieceType.KING -> 20_000
    }

    private class SearchTimeout : RuntimeException()

    private companion object {
        const val MATE_SCORE = 100_000
    }
}
