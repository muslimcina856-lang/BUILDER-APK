package com.chessbot.adapt.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.RoomDatabase.Callback
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.chessbot.adapt.data.local.dao.*
import com.chessbot.adapt.data.local.entity.*

@Database(
    entities = [
        PlayerProfile::class,
        GameSession::class,
        MoveEntity::class,
        PatternDefinition::class,
        PlayerPatternStats::class,
        BotLearningData::class,
        BotConfig::class,
        OpeningBook::class
    ],
    version = 6,
    exportSchema = true
)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun playerProfileDao(): PlayerProfileDao
    abstract fun gameSessionDao(): GameSessionDao
    abstract fun moveDao(): MoveDao
    abstract fun patternDefinitionDao(): PatternDefinitionDao
    abstract fun playerPatternStatsDao(): PlayerPatternStatsDao
    abstract fun botLearningDataDao(): BotLearningDataDao
    abstract fun botConfigDao(): BotConfigDao
    abstract fun openingBookDao(): OpeningBookDao

    companion object {
        @Volatile
        private var INSTANCE: ChessDatabase? = null

        fun create(context: Context): ChessDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ChessDatabase::class.java, "chess_bot.db"
                )
                    .addCallback(PrepopulateCallback())
                    .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        class PrepopulateCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Queen Gambit', 'D06', '["d4","d5","c4"]', 'OPENING', 80)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Sicilian Defense', 'B20', '["e4","c5"]', 'OPENING', 90)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Ruy Lopez', 'C60', '["e4","e5","Nf3","Nc6","Bb5"]', 'OPENING', 85)
            """)
            seedAdaptivePatterns(db)
        }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS bot_config_new (
                        player_id INTEGER NOT NULL PRIMARY KEY,
                        current_level INTEGER NOT NULL,
                        search_depth INTEGER NOT NULL,
                        eval_aggression REAL NOT NULL,
                        eval_defense REAL NOT NULL,
                        eval_positional REAL NOT NULL,
                        eval_tactical REAL NOT NULL,
                        pattern_recognition_weight REAL NOT NULL,
                        learning_enabled INTEGER NOT NULL,
                        last_updated_at INTEGER NOT NULL,
                        FOREIGN KEY(player_id) REFERENCES player_profile(id) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT OR REPLACE INTO bot_config_new (
                        player_id, current_level, search_depth, eval_aggression, eval_defense,
                        eval_positional, eval_tactical, pattern_recognition_weight,
                        learning_enabled, last_updated_at
                    )
                    SELECT player_id, current_level, search_depth, eval_aggression, eval_defense,
                        eval_positional, eval_tactical, pattern_recognition_weight,
                        learning_enabled, last_updated_at
                    FROM bot_config ORDER BY id
                """.trimIndent())
                db.execSQL("DROP TABLE bot_config")
                db.execSQL("ALTER TABLE bot_config_new RENAME TO bot_config")
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_bot_config_player_id ON bot_config(player_id)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_pattern_definitions_pattern_key " +
                        "ON pattern_definitions(pattern_key)"
                )
                seedAdaptivePatterns(db)
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE player_profile ADD COLUMN " +
                        "has_mastered_level_999 INTEGER NOT NULL DEFAULT 0"
                )
                db.execSQL("ALTER TABLE player_profile ADD COLUMN mastered_at INTEGER DEFAULT NULL")
                db.execSQL(
                    """UPDATE player_profile
                       SET has_mastered_level_999 = 1,
                           mastered_at = (
                               SELECT MAX(ended_at) FROM game_sessions
                               WHERE game_sessions.player_id = player_profile.id
                                 AND result = 'WIN' AND bot_level_start >= 999
                           )
                       WHERE EXISTS (
                           SELECT 1 FROM game_sessions
                           WHERE game_sessions.player_id = player_profile.id
                             AND result = 'WIN' AND bot_level_start >= 999
                       )""".trimIndent()
                )
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE game_sessions ADD COLUMN play_started_at INTEGER DEFAULT NULL"
                )
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE game_sessions ADD COLUMN learning_summary TEXT DEFAULT NULL"
                )
            }
        }

        private fun seedAdaptivePatterns(db: SupportSQLiteDatabase) {
            val patterns = listOf(
                arrayOf("OPENING_KING_PAWN", "OPENING", "Pembukaan bidak raja"),
                arrayOf("OPENING_QUEEN_PAWN", "OPENING", "Pembukaan bidak menteri"),
                arrayOf("OPENING_FLANK", "OPENING", "Pembukaan sisi"),
                arrayOf("OPENING_UNSTRUCTURED", "OPENING", "Pembukaan tidak tetap"),
                arrayOf("EARLY_QUEEN", "TACTICAL", "Menteri keluar awal"),
                arrayOf("PAWN_HEAVY", "POSITIONAL", "Terlalu banyak langkah bidak"),
                arrayOf("KING_SIDE_PAWN_PUSH", "KING_SAFETY", "Bidak sisi raja mara awal"),
                arrayOf("UNCLOSED_KING", "KING_SAFETY", "Raja lambat berlindung"),
                arrayOf("CAPTURE_HUNGRY", "TACTICAL", "Kerap mencari pertukaran")
            )
            patterns.forEach { (key, category, name) ->
                db.execSQL(
                    """INSERT OR IGNORE INTO pattern_definitions
                       (pattern_key, category, name, detection_rules, base_weight)
                       VALUES (?, ?, ?, '{}', 1.0)""".trimIndent(),
                    arrayOf(key, category, name)
                )
            }
        }
    }
}
