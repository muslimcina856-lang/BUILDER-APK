package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "bot_config",
    foreignKeys = [ForeignKey(
        entity        = PlayerProfile::class,
        parentColumns = ["id"],
        childColumns  = ["player_id"],
        onDelete      = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["player_id"], unique = true)]
)
data class BotConfig(
    @PrimaryKey
    @ColumnInfo(name = "player_id")                  val playerId: Long = 0L,
    @ColumnInfo(name = "current_level")              val currentLevel: Int = 1,
    @ColumnInfo(name = "search_depth")               val searchDepth: Int = 2,
    @ColumnInfo(name = "eval_aggression")            val evalAggression: Float = 0.5f,
    @ColumnInfo(name = "eval_defense")               val evalDefense: Float = 0.5f,
    @ColumnInfo(name = "eval_positional")            val evalPositional: Float = 0.5f,
    @ColumnInfo(name = "eval_tactical")              val evalTactical: Float = 0.5f,
    @ColumnInfo(name = "pattern_recognition_weight") val patternRecognitionWeight: Float = 0.3f,
    @ColumnInfo(name = "learning_enabled")           val learningEnabled: Boolean = true,
    @ColumnInfo(name = "last_updated_at")            val lastUpdatedAt: Long = System.currentTimeMillis()
)
