package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "bot_learning_data",
    foreignKeys = [
        ForeignKey(
            entity        = PlayerProfile::class,
            parentColumns = ["id"],
            childColumns  = ["player_id"],
            onDelete      = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity        = PatternDefinition::class,
            parentColumns = ["id"],
            childColumns  = ["pattern_id"],
            onDelete      = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["player_id"]),
        Index(value = ["pattern_id"]),
        Index(value = ["player_id", "pattern_id"], unique = true)
    ]
)
data class BotLearningData(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")                val playerId: Long,
    @ColumnInfo(name = "pattern_id")               val patternId: Long,
    @ColumnInfo(name = "counter_strategy")         val counterStrategy: String,
    @ColumnInfo(name = "effectiveness_score")      val effectivenessScore: Float = 0.5f,
    @ColumnInfo(name = "times_applied")            val timesApplied: Int = 0,
    @ColumnInfo(name = "successful_applies")       val successfulApplies: Int = 0,
    @ColumnInfo(name = "aggression_modifier")      val aggressionModifier: Float = 0.0f,
    @ColumnInfo(name = "defense_modifier")         val defenseModifier: Float = 0.0f,
    @ColumnInfo(name = "position_weight_modifier") val positionWeightModifier: Float = 0.0f,
    @ColumnInfo(name = "created_at")               val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")               val updatedAt: Long = System.currentTimeMillis()
)
