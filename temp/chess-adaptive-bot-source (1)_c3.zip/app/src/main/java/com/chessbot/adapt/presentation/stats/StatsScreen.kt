package com.chessbot.adapt.presentation.stats

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessbot.adapt.R
import com.chessbot.adapt.data.local.entity.PlayerProfile

@Composable
fun StatsScreen(
    player: PlayerProfile?,
    botLevel: Int,
    learnedPatterns: Int,
    modifier: Modifier = Modifier
) {
    var showAbout by remember { mutableStateOf(false) }
    var showSupport by remember { mutableStateOf(false) }

    if (showAbout) {
        AboutDialog(
            onDismiss = { showAbout = false },
            onSupport = {
                showAbout = false
                showSupport = true
            }
        )
    }
    if (showSupport) {
        SupportDialog(onDismiss = { showSupport = false })
    }

    Column(
        modifier = modifier.fillMaxSize().background(Color(0xFF0D0F12))
            .padding(horizontal = 18.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(Modifier.height(22.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Prestasi", color = Color(0xFFF3EEE4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Kemajuan kamu menentang bot adaptif.", color = Color(0xFFA6A39C), fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = { showAbout = true },
                contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Color(0xFFD8B477).copy(alpha = 0.42f)
                ),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD8B477)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("About", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))

        if (player == null) {
            CircularProgressIndicator(color = Color(0xFFD8B477))
            return@Column
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Permainan", player.totalGames.toString(), Modifier.weight(1f))
            StatCard("Kadar menang", "${winRate(player)}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Level bot", botLevel.toString(), Modifier.weight(1f), Color(0xFFD8B477))
            StatCard("Corak dipelajari", learnedPatterns.toString(), Modifier.weight(1f), Color(0xFF76C8A5))
        }
        Spacer(Modifier.height(18.dp))

        Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("RINGKASAN", color = Color(0xFFD8B477), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                SummaryRow("Menang", player.wins, Color(0xFF76C8A5))
                SummaryRow("Kalah", player.losses, Color(0xFFE07171))
                SummaryRow("Seri", player.draws, Color(0xFFD8B477))
                HorizontalDivider(color = Color(0xFF292D33))
                Text(
                    "Rentak semasa: ${player.currentStreak} ${streakLabel(player.streakType)}",
                    color = Color(0xFFA6A39C),
                    fontSize = 12.sp
                )
                Text(
                    "Masa bermain: ${formatDuration(player.totalPlayTimeMs)}",
                    color = Color(0xFFA6A39C),
                    fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AboutDialog(onDismiss: () -> Unit, onSupport: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF171A1F),
        titleContentColor = Color(0xFFF3EEE4),
        textContentColor = Color(0xFFA6A39C),
        title = { Text("Tentang Adaptive Chess", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Permainan catur 3D luar talian dengan lawan adaptif yang mempelajari corak permainan daripada setiap keputusan.",
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Surface(
                    color = Color(0xFFD8B477).copy(alpha = 0.10f),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(13.dp)) {
                        Text(
                            "DIBANGUNKAN OLEH",
                            color = Color(0xFFD8B477),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            "Earlxz",
                            color = Color(0xFFF3EEE4),
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text("Versi 1.0", color = Color(0xFFA6A39C), fontSize = 10.sp)
                    }
                }
                Text(
                    "HUBUNGI & KOMUNITI",
                    color = Color(0xFF76C8A5),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
                OutlinedButton(
                    onClick = { openExternalLink(context, "https://t.me/earlxz") },
                    modifier = Modifier.fillMaxWidth(),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Color(0xFF76C8A5).copy(alpha = 0.42f)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF3EEE4)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Chat, contentDescription = null, tint = Color(0xFF76C8A5))
                    Spacer(Modifier.width(8.dp))
                    Text("Chat Earlxz", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { openExternalLink(context, "https://t.me/earlstore2004") },
                    modifier = Modifier.fillMaxWidth(),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Color(0xFFD8B477).copy(alpha = 0.42f)
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF3EEE4)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Campaign, contentDescription = null, tint = Color(0xFFD8B477))
                    Spacer(Modifier.width(8.dp))
                    Text("Channel Earlxz", fontWeight = FontWeight.Bold)
                }
                HorizontalDivider(color = Color(0xFF292D33))
                Button(
                    onClick = onSupport,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD8B477),
                        contentColor = Color(0xFF17130D)
                    ),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Icon(Icons.Rounded.FavoriteBorder, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Sokong pembangunan",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }
                Text(
                    "Sokongan adalah pilihan dan membantu penambahbaikan pada keluaran akan datang.",
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF858681),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold)
            }
        }
    )
}

private fun openExternalLink(context: Context, url: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addCategory(Intent.CATEGORY_BROWSABLE)
    }
    runCatching { context.startActivity(intent) }
        .onFailure {
            Toast.makeText(
                context,
                "Tiada aplikasi yang boleh membuka pautan ini.",
                Toast.LENGTH_SHORT
            ).show()
        }
}

@Composable
private fun SupportDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF171A1F),
        titleContentColor = Color(0xFFF3EEE4),
        textContentColor = Color(0xFFA6A39C),
        title = { Text("Sokong pembangunan", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Jika mahu menyokong pembangunan Adaptive Chess, imbas kod DuitNow di bawah.",
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    textAlign = TextAlign.Center
                )
                Image(
                    painter = painterResource(R.drawable.earlxz_support_qr),
                    contentDescription = "Kod QR sokongan Earlxz Store",
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Fit
                )
                Text(
                    "Pastikan nama penerima yang dipaparkan ialah MUHAMMAD FADHIL sebelum meneruskan.",
                    color = Color(0xFFD8B477),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Selesai", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color = Color(0xFFF3EEE4)) {
    Surface(modifier = modifier, color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = Color(0xFF858681), fontSize = 10.sp)
            Text(value, color = accent, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: Int, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFFF3EEE4), fontSize = 13.sp)
        Text(value.toString(), color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

private fun winRate(player: PlayerProfile): Int =
    if (player.totalGames == 0) 0 else player.wins * 100 / player.totalGames

private fun streakLabel(type: String): String = when (type) {
    "WIN" -> "kemenangan"
    "LOSS" -> "kekalahan"
    "DRAW" -> "seri"
    else -> "permainan"
}

private fun formatDuration(milliseconds: Long): String {
    val minutes = milliseconds / 60_000
    return if (minutes < 60) "$minutes minit" else "${minutes / 60}j ${minutes % 60}m"
}
