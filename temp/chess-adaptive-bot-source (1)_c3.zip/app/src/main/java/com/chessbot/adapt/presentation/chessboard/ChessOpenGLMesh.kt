package com.chessbot.adapt.presentation.chessboard

import com.chessbot.adapt.domain.model.PieceType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

internal data class GlMeshData(
    val vertices: FloatArray,
    val indices: ShortArray
)

/** Mesh ringan yang dibina terus pada peranti; tiada fail model luar diperlukan. */
internal object ChessOpenGLMeshFactory {
    fun cube(): GlMeshData = MeshBuilder().apply {
        addBox(0f, 0f, 0f, 1f, 1f, 1f)
    }.build()

    fun disc(): GlMeshData = MeshBuilder().apply {
        addAnnulus(0f, 0f, 0f, 0f, 1f, 40)
    }.build()

    fun ring(): GlMeshData = MeshBuilder().apply {
        addAnnulus(0f, 0f, 0f, 0.68f, 1f, 40)
    }.build()

    fun piece(type: PieceType): GlMeshData = MeshBuilder().apply {
        when (type) {
            PieceType.PAWN -> pawn()
            PieceType.ROOK -> rook()
            PieceType.KNIGHT -> knight()
            PieceType.BISHOP -> bishop()
            PieceType.QUEEN -> queen()
            PieceType.KING -> king()
        }
    }.build()
}

private data class ProfilePoint(val radius: Float, val y: Float)

private class MeshBuilder {
    private val vertices = ArrayList<Float>(8_192)
    private val indices = ArrayList<Short>(12_288)

    fun build(): GlMeshData = GlMeshData(
        vertices = FloatArray(vertices.size) { vertices[it] },
        indices = ShortArray(indices.size) { indices[it] }
    )

    private fun vertex(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float): Short {
        val index = (vertices.size / FLOATS_PER_VERTEX).toShort()
        vertices += x
        vertices += y
        vertices += z
        vertices += nx
        vertices += ny
        vertices += nz
        return index
    }

    private fun triangle(a: Short, b: Short, c: Short) {
        indices += a
        indices += b
        indices += c
    }

    fun addLathe(
        profile: List<ProfilePoint>,
        centerX: Float = 0f,
        centerZ: Float = 0f,
        segments: Int = 28
    ) {
        val start = vertices.size / FLOATS_PER_VERTEX
        profile.forEachIndexed { i, point ->
            val previous = profile[max(0, i - 1)]
            val next = profile[min(profile.lastIndex, i + 1)]
            val dr = next.radius - previous.radius
            val dy = next.y - previous.y
            val normalLength = sqrt(dy * dy + dr * dr).coerceAtLeast(0.0001f)
            val radialNormal = dy / normalLength
            val verticalNormal = -dr / normalLength

            repeat(segments) { segment ->
                val angle = segment * (2f * PI.toFloat() / segments)
                val c = cos(angle)
                val s = sin(angle)
                vertex(
                    centerX + point.radius * c,
                    point.y,
                    centerZ + point.radius * s,
                    radialNormal * c,
                    verticalNormal,
                    radialNormal * s
                )
            }
        }

        for (row in 0 until profile.lastIndex) {
            for (segment in 0 until segments) {
                val nextSegment = (segment + 1) % segments
                val a = (start + row * segments + segment).toShort()
                val b = (start + row * segments + nextSegment).toShort()
                val c = (start + (row + 1) * segments + segment).toShort()
                val d = (start + (row + 1) * segments + nextSegment).toShort()
                triangle(a, c, b)
                triangle(b, c, d)
            }
        }
    }

    fun addSphere(
        centerX: Float,
        centerY: Float,
        centerZ: Float,
        radius: Float,
        rings: Int = 12,
        segments: Int = 24,
        verticalScale: Float = 1f
    ) {
        val start = vertices.size / FLOATS_PER_VERTEX
        for (ring in 0..rings) {
            val phi = PI.toFloat() * ring / rings
            val yNormal = cos(phi)
            val radial = sin(phi)
            for (segment in 0..segments) {
                val theta = 2f * PI.toFloat() * segment / segments
                val nx = radial * cos(theta)
                val nz = radial * sin(theta)
                val normalY = yNormal / verticalScale.coerceAtLeast(0.01f)
                val length = sqrt(nx * nx + normalY * normalY + nz * nz).coerceAtLeast(0.001f)
                vertex(
                    centerX + radius * nx,
                    centerY + radius * verticalScale * yNormal,
                    centerZ + radius * nz,
                    nx / length,
                    normalY / length,
                    nz / length
                )
            }
        }

        val rowWidth = segments + 1
        for (ring in 0 until rings) {
            for (segment in 0 until segments) {
                val a = (start + ring * rowWidth + segment).toShort()
                val b = (start + ring * rowWidth + segment + 1).toShort()
                val c = (start + (ring + 1) * rowWidth + segment).toShort()
                val d = (start + (ring + 1) * rowWidth + segment + 1).toShort()
                triangle(a, c, b)
                triangle(b, c, d)
            }
        }
    }

    fun addBox(
        centerX: Float,
        centerY: Float,
        centerZ: Float,
        width: Float,
        height: Float,
        depth: Float
    ) {
        val x0 = centerX - width * 0.5f
        val x1 = centerX + width * 0.5f
        val y0 = centerY - height * 0.5f
        val y1 = centerY + height * 0.5f
        val z0 = centerZ - depth * 0.5f
        val z1 = centerZ + depth * 0.5f

        addFace(floatArrayOf(x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1), 0f, 0f, 1f)
        addFace(floatArrayOf(x1,y0,z0, x0,y0,z0, x0,y1,z0, x1,y1,z0), 0f, 0f, -1f)
        addFace(floatArrayOf(x1,y0,z1, x1,y0,z0, x1,y1,z0, x1,y1,z1), 1f, 0f, 0f)
        addFace(floatArrayOf(x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0), -1f, 0f, 0f)
        addFace(floatArrayOf(x0,y1,z1, x1,y1,z1, x1,y1,z0, x0,y1,z0), 0f, 1f, 0f)
        addFace(floatArrayOf(x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1), 0f, -1f, 0f)
    }

    private fun addFace(points: FloatArray, nx: Float, ny: Float, nz: Float) {
        val start = (vertices.size / FLOATS_PER_VERTEX).toShort()
        for (i in 0 until 4) {
            vertex(points[i * 3], points[i * 3 + 1], points[i * 3 + 2], nx, ny, nz)
        }
        triangle(start, (start + 1).toShort(), (start + 2).toShort())
        triangle(start, (start + 2).toShort(), (start + 3).toShort())
    }

    fun addCylinder(
        centerX: Float,
        bottomY: Float,
        centerZ: Float,
        radius: Float,
        height: Float
    ) {
        val bevel = min(0.035f, height * 0.16f)
        addLathe(
            listOf(
                ProfilePoint(0f, bottomY),
                ProfilePoint(radius * 0.88f, bottomY),
                ProfilePoint(radius, bottomY + bevel),
                ProfilePoint(radius, bottomY + height - bevel),
                ProfilePoint(radius * 0.88f, bottomY + height),
                ProfilePoint(0f, bottomY + height)
            ),
            centerX,
            centerZ
        )
    }

    fun addCone(
        centerX: Float,
        bottomY: Float,
        centerZ: Float,
        radius: Float,
        height: Float
    ) {
        addLathe(
            listOf(
                ProfilePoint(0f, bottomY),
                ProfilePoint(radius * 0.92f, bottomY),
                ProfilePoint(radius, bottomY + height * 0.10f),
                ProfilePoint(radius * 0.62f, bottomY + height * 0.55f),
                ProfilePoint(0f, bottomY + height)
            ),
            centerX,
            centerZ,
            segments = 18
        )
    }

    fun addAnnulus(
        centerX: Float,
        y: Float,
        centerZ: Float,
        innerRadius: Float,
        outerRadius: Float,
        segments: Int
    ) {
        repeat(segments) { segment ->
            val a0 = 2f * PI.toFloat() * segment / segments
            val a1 = 2f * PI.toFloat() * (segment + 1) / segments
            val outer0 = vertex(
                centerX + cos(a0) * outerRadius, y, centerZ + sin(a0) * outerRadius,
                0f, 1f, 0f
            )
            val outer1 = vertex(
                centerX + cos(a1) * outerRadius, y, centerZ + sin(a1) * outerRadius,
                0f, 1f, 0f
            )
            val inner1 = vertex(
                centerX + cos(a1) * innerRadius, y, centerZ + sin(a1) * innerRadius,
                0f, 1f, 0f
            )
            val inner0 = vertex(
                centerX + cos(a0) * innerRadius, y, centerZ + sin(a0) * innerRadius,
                0f, 1f, 0f
            )
            triangle(outer0, inner1, outer1)
            triangle(outer0, inner0, inner1)
        }
    }

    /** Kepala kuda: profil cembung pada satah Z/Y dengan ketebalan sebenar pada paksi X. */
    fun addExtrudedKnightHead(points: List<Pair<Float, Float>>, halfWidth: Float) {
        val front = ArrayList<Short>(points.size)
        val back = ArrayList<Short>(points.size)
        points.forEach { (z, y) -> front += vertex(halfWidth, y, z, 1f, 0f, 0f) }
        points.forEach { (z, y) -> back += vertex(-halfWidth, y, z, -1f, 0f, 0f) }

        for (i in 1 until points.lastIndex) {
            triangle(front[0], front[i], front[i + 1])
            triangle(back[0], back[i + 1], back[i])
        }

        points.indices.forEach { i ->
            val next = (i + 1) % points.size
            val dz = points[next].first - points[i].first
            val dy = points[next].second - points[i].second
            val length = sqrt(dz * dz + dy * dy).coerceAtLeast(0.001f)
            val ny = dz / length
            val nz = -dy / length
            val a = vertex(halfWidth, points[i].second, points[i].first, 0f, ny, nz)
            val b = vertex(-halfWidth, points[i].second, points[i].first, 0f, ny, nz)
            val c = vertex(-halfWidth, points[next].second, points[next].first, 0f, ny, nz)
            val d = vertex(halfWidth, points[next].second, points[next].first, 0f, ny, nz)
            triangle(a, b, c)
            triangle(a, c, d)
        }
    }

    private fun commonBody(topY: Float, waist: Float = 0.15f) {
        addLathe(
            listOf(
                ProfilePoint(0f, 0f),
                ProfilePoint(0.28f, 0f),
                ProfilePoint(0.36f, 0.045f),
                ProfilePoint(0.38f, 0.10f),
                ProfilePoint(0.35f, 0.16f),
                ProfilePoint(0.28f, 0.22f),
                ProfilePoint(0.23f, 0.26f),
                ProfilePoint(waist, topY * 0.70f),
                ProfilePoint(waist * 0.95f, topY * 0.79f),
                ProfilePoint(0.24f, topY * 0.86f),
                ProfilePoint(0.28f, topY * 0.92f),
                ProfilePoint(0.23f, topY),
                ProfilePoint(0f, topY)
            )
        )
    }

    fun pawn() {
        commonBody(0.60f, 0.14f)
        addSphere(0f, 0.79f, 0f, 0.205f, verticalScale = 1.02f)
    }

    fun rook() {
        commonBody(0.64f, 0.18f)
        addCylinder(0f, 0.60f, 0f, 0.29f, 0.25f)
        listOf(
            -0.19f to -0.19f,
            0.19f to -0.19f,
            0.19f to 0.19f,
            -0.19f to 0.19f
        ).forEach { (x, z) -> addBox(x, 0.91f, z, 0.17f, 0.22f, 0.17f) }
    }

    fun knight() {
        commonBody(0.59f, 0.17f)
        addExtrudedKnightHead(
            listOf(
                -0.18f to 0.54f,
                0.14f to 0.58f,
                0.34f to 0.76f,
                0.38f to 1.03f,
                0.22f to 1.24f,
                -0.02f to 1.36f,
                -0.22f to 1.15f,
                -0.25f to 0.79f
            ),
            halfWidth = 0.17f
        )
        addCone(0f, 1.22f, -0.08f, 0.075f, 0.28f)
    }

    fun bishop() {
        commonBody(0.70f, 0.145f)
        addLathe(
            listOf(
                ProfilePoint(0f, 0.68f),
                ProfilePoint(0.19f, 0.70f),
                ProfilePoint(0.25f, 0.82f),
                ProfilePoint(0.22f, 1.00f),
                ProfilePoint(0.13f, 1.22f),
                ProfilePoint(0f, 1.43f)
            )
        )
    }

    fun queen() {
        commonBody(0.80f, 0.15f)
        addCylinder(0f, 0.76f, 0f, 0.27f, 0.18f)
        repeat(8) { index ->
            val angle = 2f * PI.toFloat() * index / 8f
            val x = cos(angle) * 0.22f
            val z = sin(angle) * 0.22f
            val spikeHeight = if (index % 2 == 0) 0.37f else 0.30f
            addCone(x, 0.90f, z, 0.055f, spikeHeight)
            addSphere(x, 0.90f + spikeHeight, z, 0.058f, rings = 8, segments = 14)
        }
        addSphere(0f, 1.35f, 0f, 0.075f, rings = 8, segments = 14)
    }

    fun king() {
        commonBody(0.88f, 0.16f)
        addCylinder(0f, 0.84f, 0f, 0.27f, 0.18f)
        addSphere(0f, 1.08f, 0f, 0.13f, rings = 10, segments = 18)
        addBox(0f, 1.34f, 0f, 0.105f, 0.48f, 0.105f)
        addBox(0f, 1.39f, 0f, 0.38f, 0.105f, 0.105f)
    }

    companion object {
        private const val FLOATS_PER_VERTEX = 6
    }
}
