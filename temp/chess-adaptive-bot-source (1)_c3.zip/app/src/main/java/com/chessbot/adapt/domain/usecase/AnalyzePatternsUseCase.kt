package com.chessbot.adapt.domain.usecase

import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.dao.PatternDefinitionDao
import com.chessbot.adapt.data.local.dao.PlayerPatternStatsDao
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.PlayerPatternStats
import com.chessbot.adapt.domain.bot.DetectedPlayerPattern
import com.chessbot.adapt.domain.bot.PatternAnalyzer
import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.Move

/** Menganalisis permainan lengkap dan menyimpan strategi yang benar-benar digunakan enjin. */
class AnalyzePatternsUseCase(
    private val patternAnalyzer: PatternAnalyzer,
    private val patternDefinitionDao: PatternDefinitionDao,
    private val playerPatternStatsDao: PlayerPatternStatsDao,
    private val botLearningDataDao: BotLearningDataDao
) {
    suspend operator fun invoke(
        playerId: Long,
        playerColor: Color,
        moves: List<Move>,
        result: String
    ): List<DetectedPlayerPattern> {
        val detected = patternAnalyzer.detectPlayerPatterns(moves, playerColor)
        val playerWon = result == "WIN"
        val playerLost = result == "LOSS"
        val botOutcome = when (result) {
            "LOSS" -> 1f
            "DRAW" -> 0.5f
            else -> 0f
        }
        val now = System.currentTimeMillis()

        detected.forEach { pattern ->
            val definition = patternDefinitionDao.getByKey(pattern.key) ?: return@forEach
            val existingStats = playerPatternStatsDao.getStats(playerId, definition.id)
            val encountered = (existingStats?.timesEncountered ?: 0) + 1
            val successful = (existingStats?.timesSuccessful ?: 0) + if (playerWon) 1 else 0
            val failed = (existingStats?.timesFailed ?: 0) + if (playerLost) 1 else 0
            playerPatternStatsDao.upsert(
                (existingStats ?: PlayerPatternStats(
                    playerId = playerId,
                    patternId = definition.id
                )).copy(
                    timesEncountered = encountered,
                    timesSuccessful = successful,
                    timesFailed = failed,
                    successRate = successful.toFloat() / encountered,
                    lastSeenAt = now,
                    updatedAt = now
                )
            )

            val existing = botLearningDataDao.getLearningData(playerId, definition.id)
            val applied = (existing?.timesApplied ?: 0) + 1
            val previousEffectiveness = existing?.effectivenessScore ?: 0.5f
            val effectiveness = ((previousEffectiveness * (applied - 1)) + botOutcome) / applied
            // Kekalahan bot menguatkan strategi balas; kemenangan mengekalkan strategi yang berjaya.
            val outcomeScale = when (result) {
                "WIN" -> 1.10f
                "DRAW" -> 1.03f
                else -> 1.0f
            }
            val blend = if (existing == null) 1f else 0.30f
            fun evolve(old: Float, target: Float): Float =
                old * (1f - blend) + target * outcomeScale * blend

            botLearningDataDao.upsert(
                (existing ?: BotLearningData(
                    playerId = playerId,
                    patternId = definition.id,
                    counterStrategy = pattern.key
                )).copy(
                    counterStrategy = pattern.key,
                    effectivenessScore = effectiveness.coerceIn(0f, 1f),
                    timesApplied = applied,
                    successfulApplies = (existing?.successfulApplies ?: 0) + if (playerLost) 1 else 0,
                    aggressionModifier = evolve(existing?.aggressionModifier ?: 0f, pattern.aggressionModifier),
                    defenseModifier = evolve(existing?.defenseModifier ?: 0f, pattern.defenseModifier),
                    positionWeightModifier = evolve(
                        existing?.positionWeightModifier ?: 0f,
                        pattern.positionModifier
                    ),
                    updatedAt = now
                )
            )
        }
        return detected
    }
}
