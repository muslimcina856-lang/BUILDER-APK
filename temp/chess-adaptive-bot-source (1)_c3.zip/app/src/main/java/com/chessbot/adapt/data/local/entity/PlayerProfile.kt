package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(tableName = "player_profile")
data class PlayerProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    @ColumnInfo(name = "total_games")     val totalGames: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val draws: Int = 0,
    @ColumnInfo(name = "current_streak")  val currentStreak: Int = 0,
    @ColumnInfo(name = "streak_type")     val streakType: String = "NONE",
    @ColumnInfo(name = "total_play_time_ms") val totalPlayTimeMs: Long = 0,
    @ColumnInfo(name = "has_mastered_level_999") val hasMasteredLevel999: Boolean = false,
    @ColumnInfo(name = "mastered_at") val masteredAt: Long? = null,
    @ColumnInfo(name = "created_at")      val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")      val updatedAt: Long = System.currentTimeMillis()
)
