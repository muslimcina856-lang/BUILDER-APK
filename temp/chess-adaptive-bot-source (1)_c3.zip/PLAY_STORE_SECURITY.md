# Keselamatan keluaran Google Play

## Perlindungan yang sudah aktif dalam projek

- Binaan `release` menggunakan R8 full mode melalui Android Gradle Plugin 8.3.2.
- `minifyEnabled true`, `shrinkResources true` dan `proguard-android-optimize.txt` aktif.
- Binaan release tidak boleh didebug dan akan dizip-align.
- Keep rules hanya melindungi metadata dan pemalar pangkalan data yang diperlukan; kod aplikasi
  lain masih boleh dioptimumkan dan dikaburkan.
- Simpan `app/build/outputs/mapping/release/mapping.txt` untuk setiap versi yang diterbitkan.

R8 menyukarkan proses reverse engineering, tetapi ia bukan perlindungan anti-tamper lengkap.

## Pilihan paling sesuai untuk aplikasi ini

### 1. Play App Signing dan Automatic Protection

1. Bina dan muat naik Android App Bundle (`.aab`), bukan APK terus.
2. Daftar aplikasi dalam Play App Signing.
3. Dalam Play Console, buka **Protected with Play**.
4. Di bahagian **Automatic protection**, tekan **Get started** dan hidupkan perlindungan.
5. Uji versi yang dilindungi melalui internal atau closed testing sebelum production.

Installer check tidak memerlukan backend. Ciri anti-tamper lanjutan Google hanya tersedia kepada
Play partners yang layak. Projek ini sudah menggunakan `minSdk 26`, jadi syarat minimum API untuk
perlindungan tersebut dipenuhi.

Panduan rasmi:
https://support.google.com/googleplay/android-developer/answer/10183279

### 2. Play Integrity API untuk tindakan sensitif

Play Integrity bukan pemeriksaan yang patut disahkan sepenuhnya di dalam aplikasi. Token mesti
dihantar kepada backend sendiri supaya keputusan tidak mudah dipalsukan.

1. Cipta Google Cloud project.
2. Dalam Play Console, buka **Protected with Play > Play Integrity API** dan pautkan Cloud project.
3. Apabila backend sudah tersedia, tambah dependency semasa rasmi:

   `implementation 'com.google.android.play:integrity:1.6.0'`

4. Gunakan standard request dengan `requestHash` yang terikat kepada tindakan sebenar.
5. Hantar token ke backend, kemudian sahkan sekurang-kurangnya:
   - `requestDetails` dan `requestHash` sepadan;
   - `appRecognitionVerdict` ialah `PLAY_RECOGNIZED`;
   - `appLicensingVerdict` ialah `LICENSED`;
   - verdict integriti peranti memenuhi tahap risiko yang ditetapkan.
6. Mulakan dalam mod pemantauan dan gunakan tindakan bertingkat sebelum menyekat pengguna.

Jangan simpan credential Cloud atau rahsia backend di dalam APK/AAB.

Panduan rasmi:
https://developer.android.com/google/play/integrity/setup
https://developer.android.com/google/play/integrity/standard

## Susunan penerbitan yang disyorkan

1. Uji binaan release R8 pada beberapa peranti.
2. Hasilkan signing key muat naik dan aktifkan Play App Signing.
3. Muat naik AAB ke internal testing.
4. Hidupkan Automatic Protection dan uji aplikasi yang diproses oleh Play.
5. Simpan AAB, upload key dan `mapping.txt` secara selamat.
6. Tambah Play Integrity API hanya selepas backend verifikasi tersedia.
