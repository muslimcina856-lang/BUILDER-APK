import 'package:flutter/material.dart';

import '../game/combat/health_pool.dart';
import '../game/skybound_game.dart';

class CombatHud extends StatefulWidget {
  const CombatHud({
    super.key,
    required this.game,
    required this.onExit,
  });

  final SkyboundGame game;
  final VoidCallback onExit;

  @override
  State<CombatHud> createState() => _CombatHudState();
}

class _CombatHudState extends State<CombatHud> {
  bool _soundEnabled = true;

  SkyboundGame get game => widget.game;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: const EdgeInsets.all(10),
      child: Stack(
        children: [
          Positioned(left: 0, top: 0, child: _Vitals(game: game)),
          Positioned(left: 278, right: 80, top: 2, child: _ObjectivePanel(game: game)),
          Positioned(
            right: 0,
            top: 0,
            child: _SquareHudButton(
              icon: Icons.pause_rounded,
              onPressed: game.togglePause,
            ),
          ),
          Positioned(left: 285, right: 88, top: 57, child: _BossBar(game: game)),
          Positioned.fill(child: _Banner(game: game)),
          Positioned.fill(child: _Controls(game: game)),
          Positioned.fill(
            child: _PhaseOverlay(
              game: game,
              onExit: widget.onExit,
              soundEnabled: _soundEnabled,
              onSoundChanged: (value) {
                setState(() => _soundEnabled = value);
                game.setSoundEnabled(value);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Vitals extends StatelessWidget {
  const _Vitals({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    final avatar = game.selectedAvatar;
    return _PixelPanel(
      width: 266,
      padding: const EdgeInsets.all(9),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: const Color(0xFF0B1727),
              border: Border.all(color: const Color(0xFF70E0D1), width: 2),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Image.asset(
              'assets/images/${avatar.spriteFrames.first}',
              fit: BoxFit.contain,
              filterQuality: FilterQuality.none,
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        avatar.name.toUpperCase(),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    ValueListenableBuilder<int>(
                      valueListenable: game.relicCount,
                      builder: (_, count, __) => Text(
                        '◆ $count/3',
                        style: const TextStyle(
                          color: Color(0xFF7EEBFF),
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                ValueListenableBuilder<HealthSnapshot>(
                  valueListenable: game.heroHealth,
                  builder: (context, health, _) => _Meter(
                    value: health.ratio,
                    color: const Color(0xFFFF5B66),
                    secondaryValue: health.maximum == 0
                        ? 0
                        : (health.shield / health.maximum).clamp(0, 1).toDouble(),
                    label: 'HP ${health.current.ceil()} / ${health.maximum.ceil()}',
                  ),
                ),
                const SizedBox(height: 5),
                ValueListenableBuilder<double>(
                  valueListenable: game.heroResource,
                  builder: (context, resource, _) => _Meter(
                    value: resource,
                    color: const Color(0xFF4FD7FF),
                    label: 'TENAGA ${(resource * 100).ceil()}%',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ObjectivePanel extends StatelessWidget {
  const _ObjectivePanel({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _PixelPanel(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: ValueListenableBuilder<String>(
          valueListenable: game.objective,
          builder: (context, objective, _) {
            return ValueListenableBuilder<int>(
              valueListenable: game.enemiesRemaining,
              builder: (context, enemies, _) => Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.explore_rounded, color: Color(0xFFFFD166), size: 18),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      objective.toUpperCase(),
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.7,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '☠ $enemies',
                    style: const TextStyle(
                      color: Color(0xFFFF8A8F),
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BossBar extends StatelessWidget {
  const _BossBar({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: game.bossEncounter,
      builder: (context, active, _) {
        if (!active) return const SizedBox.shrink();
        return ValueListenableBuilder<double>(
          valueListenable: game.bossHealth,
          builder: (context, health, _) => _PixelPanel(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 7),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'MONITOR GOLEM · PENJAGA PORTAL',
                  style: TextStyle(
                    color: Color(0xFF8DEBFF),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 4),
                _Meter(
                  value: health,
                  color: const Color(0xFF38CFF4),
                  label: '${(health * 100).ceil()}%',
                  height: 11,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Align(
        alignment: const Alignment(0, -0.25),
        child: ValueListenableBuilder<String?>(
          valueListenable: game.banner,
          builder: (context, message, _) {
            return AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              child: message == null
                  ? const SizedBox.shrink()
                  : Container(
                      key: ValueKey(message),
                      constraints: const BoxConstraints(maxWidth: 620),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xEE0B1C31),
                        border: Border.all(color: const Color(0xFF7EEBFF), width: 2),
                        borderRadius: BorderRadius.circular(6),
                        boxShadow: const [
                          BoxShadow(color: Color(0x6600D9FF), blurRadius: 16),
                        ],
                      ),
                      child: Text(
                        message,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
            );
          },
        ),
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.game});

  final SkyboundGame game;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GamePhase>(
      valueListenable: game.phase,
      builder: (context, phase, _) {
        final enabled = phase == GamePhase.playing;
        return IgnorePointer(
          ignoring: !enabled,
          child: AnimatedOpacity(
            opacity: enabled ? 1.0 : 0.0,
            duration: const Duration(milliseconds: 150),
            child: Stack(
              children: [
                Positioned(
                  left: 4,
                  bottom: 2,
                  child: Row(
                    children: [
                      _TouchButton(
                        icon: Icons.chevron_left_rounded,
                        asset: 'assets/images/controls/direction_left.png',
                        color: const Color(0xFF50B8A6),
                        onDown: () => game.input.setLeft(true),
                        onUp: () => game.input.setLeft(false),
                      ),
                      const SizedBox(width: 10),
                      _TouchButton(
                        icon: Icons.chevron_right_rounded,
                        asset: 'assets/images/controls/direction_right.png',
                        color: const Color(0xFF50B8A6),
                        onDown: () => game.input.setRight(true),
                        onUp: () => game.input.setRight(false),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: 4,
                  bottom: 0,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _TouchButton(
                        icon: Icons.auto_awesome_rounded,
                        label: 'SKILL',
                        asset: 'assets/images/controls/button_diamond.png',
                        size: 66,
                        color: const Color(0xFF9C6CFF),
                        cooldown: game.secondaryCooldown,
                        onDown: game.input.queueSecondary,
                      ),
                      const SizedBox(width: 13),
                      _TouchButton(
                        icon: Icons.gps_fixed_rounded,
                        label: 'SERANG',
                        asset: 'assets/images/controls/button_circle.png',
                        size: 74,
                        color: const Color(0xFFFF5964),
                        cooldown: game.primaryCooldown,
                        onDown: game.input.queuePrimary,
                      ),
                      const SizedBox(width: 13),
                      _TouchButton(
                        icon: Icons.arrow_upward_rounded,
                        label: 'LOMPAT',
                        asset: 'assets/images/controls/button_circle.png',
                        size: 86,
                        color: const Color(0xFF4AB8F5),
                        onDown: () => game.input.setJump(true),
                        onUp: () => game.input.setJump(false),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _PhaseOverlay extends StatelessWidget {
  const _PhaseOverlay({
    required this.game,
    required this.onExit,
    required this.soundEnabled,
    required this.onSoundChanged,
  });

  final SkyboundGame game;
  final VoidCallback onExit;
  final bool soundEnabled;
  final ValueChanged<bool> onSoundChanged;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<GamePhase>(
      valueListenable: game.phase,
      builder: (context, phase, _) {
        if (phase == GamePhase.playing) return const SizedBox.shrink();
        if (phase == GamePhase.loading) {
          return const ColoredBox(
            color: Color(0xF2071225),
            child: Center(
              child: _PixelPanel(
                width: 320,
                padding: EdgeInsets.symmetric(horizontal: 28, vertical: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox.square(
                      dimension: 34,
                      child: CircularProgressIndicator(
                        strokeWidth: 4,
                        color: Color(0xFF66E2C4),
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      'MEMUATKAN AETHER RUINS',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Menyediakan arena, audio dan musuh...',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFFB8CDDB), fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          );
        }
        final victory = phase == GamePhase.victory;
        final defeat = phase == GamePhase.defeat;
        final title = victory
            ? 'MISI SELESAI'
            : defeat
                ? '${game.selectedAvatar.name.toUpperCase()} TUMBANG'
                : 'PERMAINAN DIJEDA';
        final subtitle = victory
            ? 'Portal Aether berjaya distabilkan.'
            : defeat
                ? 'Gunakan timing, lompat dan skill khas untuk mencuba lagi.'
                : 'Kawalan: A/D · W/Space · J · K';
        return ColoredBox(
          color: const Color(0xB8040B16),
          child: Center(
            child: _PixelPanel(
              width: 430,
              padding: const EdgeInsets.fromLTRB(30, 24, 30, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    victory
                        ? Icons.workspace_premium_rounded
                        : defeat
                            ? Icons.broken_image_rounded
                            : Icons.pause_circle_filled_rounded,
                    color: victory
                        ? const Color(0xFFFFD166)
                        : defeat
                            ? const Color(0xFFFF6673)
                            : const Color(0xFF7EEBFF),
                    size: 48,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    subtitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Color(0xFFB8CDDB), fontSize: 12),
                  ),
                  if (victory || defeat) ...[
                    const SizedBox(height: 14),
                    Text(
                      'MASA ${game.elapsedTimeLabel}   ·   RELIK ${game.progress.relicsCollected}/3   ·   MUSUH ${game.progress.enemiesDefeated}',
                      style: const TextStyle(
                        color: Color(0xFF7EEBFF),
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  if (phase == GamePhase.paused)
                    _MenuButton(
                      label: 'SAMBUNG',
                      icon: Icons.play_arrow_rounded,
                      primary: true,
                      onPressed: game.resumeGame,
                    ),
                  if (phase == GamePhase.paused) const SizedBox(height: 9),
                  _MenuButton(
                    label: victory || defeat ? 'MAIN SEMULA' : 'MULA SEMULA',
                    icon: Icons.refresh_rounded,
                    primary: victory || defeat,
                    onPressed: game.restartLevel,
                  ),
                  const SizedBox(height: 9),
                  _MenuButton(
                    label: 'PILIH WATAK',
                    icon: Icons.people_alt_rounded,
                    onPressed: onExit,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.volume_up_rounded, size: 18, color: Color(0xFFB8CDDB)),
                      const SizedBox(width: 7),
                      const Text('BUNYI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 7),
                      Switch.adaptive(value: soundEnabled, onChanged: onSoundChanged),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    this.primary = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback onPressed;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 270,
      height: 44,
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: primary ? const Color(0xFF66E2C4) : const Color(0xFF233B55),
          foregroundColor: primary ? const Color(0xFF071225) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
            side: BorderSide(
              color: primary ? Colors.white : const Color(0xFF58718A),
              width: 2,
            ),
          ),
        ),
        onPressed: onPressed,
        icon: Icon(icon),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.8)),
      ),
    );
  }
}

class _Meter extends StatelessWidget {
  const _Meter({
    required this.value,
    required this.color,
    required this.label,
    this.secondaryValue = 0,
    this.height = 14,
  });

  final double value;
  final Color color;
  final String label;
  final double secondaryValue;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Stack(
        fit: StackFit.expand,
        alignment: Alignment.center,
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              color: const Color(0xFF050B12),
              borderRadius: BorderRadius.circular(3),
              border: Border.all(color: Colors.white12),
            ),
          ),
          FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: value.clamp(0, 1).toDouble(),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          if (secondaryValue > 0)
            FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: secondaryValue.clamp(0, 1).toDouble(),
              child: Align(
                alignment: Alignment.centerRight,
                child: Container(width: 4, color: const Color(0xFFB5F5FF)),
              ),
            ),
          Center(
            child: Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: height <= 11 ? 8.0 : 9.0,
                fontWeight: FontWeight.w900,
                shadows: const [Shadow(color: Colors.black, blurRadius: 2)],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TouchButton extends StatefulWidget {
  const _TouchButton({
    required this.icon,
    required this.asset,
    required this.color,
    this.label,
    required this.onDown,
    this.onUp,
    this.cooldown,
    this.size = 70,
  });

  final IconData icon;
  final String asset;
  final Color color;
  final String? label;
  final VoidCallback onDown;
  final VoidCallback? onUp;
  final ValueListenable<double>? cooldown;
  final double size;

  @override
  State<_TouchButton> createState() => _TouchButtonState();
}

class _TouchButtonState extends State<_TouchButton> {
  bool _pressed = false;

  void _down() {
    setState(() => _pressed = true);
    widget.onDown();
  }

  void _up() {
    if (_pressed) setState(() => _pressed = false);
    widget.onUp?.call();
  }

  @override
  Widget build(BuildContext context) {
    final button = Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _down(),
      onPointerUp: (_) => _up(),
      onPointerCancel: (_) => _up(),
      child: AnimatedScale(
        scale: _pressed ? 0.88 : 1.0,
        duration: const Duration(milliseconds: 70),
        child: SizedBox.square(
          dimension: widget.size,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(
                widget.asset,
                width: widget.size,
                height: widget.size,
                color: widget.color,
                filterQuality: FilterQuality.none,
              ),
              Icon(
                widget.icon,
                color: Colors.white,
                size: widget.size * 0.4,
                shadows: const [Shadow(color: Colors.black, blurRadius: 4)],
              ),
              if (widget.label != null)
                Positioned(
                  bottom: widget.size * 0.1,
                  child: Text(
                    widget.label!,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: widget.size * 0.105,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                      shadows: const [Shadow(color: Colors.black, blurRadius: 3)],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
    final cooldown = widget.cooldown;
    if (cooldown == null) return button;
    return ValueListenableBuilder<double>(
      valueListenable: cooldown,
      builder: (context, value, _) => Stack(
        alignment: Alignment.center,
        children: [
          button,
          if (value > 0.001)
            IgnorePointer(
              child: SizedBox.square(
                dimension: widget.size * 0.82,
                child: CircularProgressIndicator(
                  value: value,
                  strokeWidth: widget.size * 0.11,
                  color: const Color(0xCC09111E),
                  backgroundColor: Colors.transparent,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SquareHudButton extends StatelessWidget {
  const _SquareHudButton({required this.icon, required this.onPressed});

  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: 52,
      child: IconButton.filled(
        style: IconButton.styleFrom(
          backgroundColor: const Color(0xDD10243A),
          foregroundColor: Colors.white,
          side: const BorderSide(color: Color(0xFF5F8298), width: 2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        onPressed: onPressed,
        icon: Icon(icon),
      ),
    );
  }
}

class _PixelPanel extends StatelessWidget {
  const _PixelPanel({
    required this.child,
    this.width,
    this.padding = const EdgeInsets.all(10),
  });

  final Widget child;
  final double? width;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xE8112238),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0xFF48677D), width: 2),
        boxShadow: const [
          BoxShadow(color: Color(0x66000000), blurRadius: 8, offset: Offset(0, 4)),
        ],
      ),
      child: child,
    );
  }
}
