package com.earlxz.railrush;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class RailRushView extends View {
    private static final int COLOR_INK = Color.rgb(18, 9, 31);
    private static final int COLOR_NIGHT = Color.rgb(23, 11, 46);
    private static final int COLOR_PANEL = Color.rgb(36, 18, 63);
    private static final int COLOR_PURPLE = Color.rgb(90, 36, 168);
    private static final int COLOR_YELLOW = Color.rgb(255, 216, 61);
    private static final int COLOR_GREEN = Color.rgb(98, 232, 74);
    private static final int COLOR_PINK = Color.rgb(255, 59, 157);
    private static final int COLOR_CREAM = Color.rgb(255, 247, 214);
    private static final int COLOR_CYAN = Color.rgb(95, 245, 255);

    private static final String PREFS_NAME = "rail_rush";
    private static final String PREF_BEST_SCORE = "best_score";

    private enum Mode {
        IDLE,
        RUNNING,
        PAUSED,
        GAME_OVER
    }

    private enum Kind {
        COIN,
        BARRIER,
        GATE,
        TRAIN
    }

    private static final class Entity {
        final Kind kind;
        final int lane;
        float z;
        boolean passed;

        Entity(Kind kind, int lane, float z) {
            this.kind = kind;
            this.lane = lane;
            this.z = z;
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Path path = new Path();
    private final RectF mainButton = new RectF();
    private final RectF pauseButton = new RectF();
    private final RectF gameBounds = new RectF();
    private final List<Entity> entities = new ArrayList<>();
    private final Random random = new Random();
    private final SharedPreferences preferences;
    private final float density;

    private Mode mode = Mode.IDLE;
    private int targetLane;
    private float laneVisual;
    private float jump;
    private float jumpVelocity;
    private float slideTimer;
    private float spawnTimer;
    private float speed;
    private float distance;
    private float flash;
    private float shake;
    private float trackOffset;
    private int coins;
    private int bestScore;
    private long previousFrameTime;
    private float touchStartX;
    private float touchStartY;
    private boolean trackingTouch;

    public RailRushView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        bestScore = preferences.getInt(PREF_BEST_SCORE, 0);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        setFocusable(true);
        setFocusableInTouchMode(true);
        setContentDescription(context.getString(R.string.game_description));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        resetAttractScene();
    }

    public void resumeRendering() {
        previousFrameTime = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    public void pauseGame() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
        }
        invalidate();
    }

    public boolean handleKeyEvent(KeyEvent event) {
        if (event.getAction() != KeyEvent.ACTION_DOWN || event.getRepeatCount() > 0) {
            return false;
        }

        switch (event.getKeyCode()) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_A:
                actLeft();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_D:
                actRight();
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_W:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_BUTTON_A:
                actJump();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_S:
            case KeyEvent.KEYCODE_BUTTON_B:
                actSlide();
                return true;
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_START:
                toggleMainAction();
                return true;
            case KeyEvent.KEYCODE_P:
            case KeyEvent.KEYCODE_ESCAPE:
                togglePause();
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        long now = SystemClock.uptimeMillis();
        if (previousFrameTime == 0L) {
            previousFrameTime = now;
        }
        float dt = Math.min(0.034f, Math.max(0f, (now - previousFrameTime) / 1000f));
        previousFrameTime = now;

        if (mode == Mode.RUNNING) {
            updateGame(dt);
        } else {
            laneVisual += (targetLane - laneVisual) * Math.min(1f, dt * 8f);
        }

        drawBackdrop(canvas);
        drawControlPanel(canvas);
        drawGameArea(canvas, now);
        if (mode != Mode.RUNNING) {
            drawOverlay(canvas);
        }

        postInvalidateOnAnimation();
    }

    private void updateGame(float dt) {
        distance += dt * (74f + speed * 96f);
        speed = Math.min(0.72f, 0.34f + distance / 3600f);
        trackOffset = (trackOffset + dt * speed * 1.25f) % 1f;
        laneVisual += (targetLane - laneVisual) * Math.min(1f, dt * 12f);
        flash = Math.max(0f, flash - dt * 3.2f);
        shake = Math.max(0f, shake - dt * 4.2f);

        if (jump > 0f || jumpVelocity > 0f) {
            jump += jumpVelocity * dt;
            jumpVelocity -= 5.2f * dt;
            if (jump <= 0f) {
                jump = 0f;
                jumpVelocity = 0f;
            }
        }
        slideTimer = Math.max(0f, slideTimer - dt);

        spawnTimer -= dt;
        if (spawnTimer <= 0f) {
            spawnWave();
            spawnTimer = Math.max(0.72f, 1.16f - speed * 0.38f);
        }

        for (Entity entity : entities) {
            entity.z += dt * speed;
            if (entity.passed || entity.z < 0.79f) {
                continue;
            }

            boolean sameLane = entity.lane == targetLane
                    && Math.abs(laneVisual - entity.lane) < 0.36f;

            if (entity.kind == Kind.COIN) {
                if (sameLane && entity.z < 1.04f) {
                    entity.passed = true;
                    coins += 1;
                    flash = 0.42f;
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                } else if (entity.z > 1.04f) {
                    entity.passed = true;
                }
                continue;
            }

            if (entity.z > 0.98f) {
                entity.passed = true;
                continue;
            }
            if (!sameLane) {
                continue;
            }

            boolean safe = (entity.kind == Kind.BARRIER && jump > 0.36f)
                    || (entity.kind == Kind.GATE && slideTimer > 0.08f);
            if (safe) {
                entity.passed = true;
                continue;
            }

            entity.passed = true;
            endRun();
            break;
        }

        Iterator<Entity> iterator = entities.iterator();
        while (iterator.hasNext()) {
            Entity entity = iterator.next();
            if (entity.passed || entity.z > 1.2f) {
                iterator.remove();
            }
        }
    }

    private void spawnWave() {
        int obstacleLane = random.nextInt(3) - 1;
        float roll = random.nextFloat();
        Kind obstacle = roll < 0.38f
                ? Kind.BARRIER
                : roll < 0.68f ? Kind.GATE : Kind.TRAIN;
        entities.add(new Entity(obstacle, obstacleLane, 0f));

        int firstSafeLane = obstacleLane == -1 ? 0 : -1;
        int secondSafeLane = obstacleLane == 1 ? 0 : 1;
        int coinLane = random.nextBoolean() ? firstSafeLane : secondSafeLane;
        for (int i = 0; i < 4; i += 1) {
            entities.add(new Entity(Kind.COIN, coinLane, -0.08f - i * 0.105f));
        }
    }

    private void startGame() {
        targetLane = 0;
        laneVisual = 0f;
        jump = 0f;
        jumpVelocity = 0f;
        slideTimer = 0f;
        spawnTimer = 0.72f;
        speed = 0.34f;
        distance = 0f;
        flash = 0f;
        shake = 0f;
        trackOffset = 0f;
        coins = 0;
        entities.clear();
        mode = Mode.RUNNING;
        previousFrameTime = SystemClock.uptimeMillis();
        announceForAccessibility("Permainan bermula");
    }

    private void resetAttractScene() {
        targetLane = 0;
        laneVisual = 0f;
        speed = 0.34f;
        entities.clear();
        entities.add(new Entity(Kind.TRAIN, -1, 0.28f));
        entities.add(new Entity(Kind.BARRIER, 1, 0.5f));
        entities.add(new Entity(Kind.COIN, 0, 0.2f));
        entities.add(new Entity(Kind.COIN, 0, 0.34f));
        entities.add(new Entity(Kind.COIN, 0, 0.48f));
    }

    private void endRun() {
        mode = Mode.GAME_OVER;
        shake = 1f;
        int score = getScore();
        if (score > bestScore) {
            bestScore = score;
            preferences.edit().putInt(PREF_BEST_SCORE, bestScore).apply();
        }
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        announceForAccessibility("Larian tamat. Skor " + score);
    }

    private int getScore() {
        return (int) distance + coins * 35;
    }

    private void toggleMainAction() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
        } else if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
        } else {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
        }
        invalidate();
    }

    private void togglePause() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
        } else if (mode == Mode.PAUSED) {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
        }
        invalidate();
    }

    private boolean ensureRunning() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
            return false;
        }
        return mode == Mode.RUNNING;
    }

    private void actLeft() {
        if (!ensureRunning()) {
            return;
        }
        targetLane = Math.max(-1, targetLane - 1);
    }

    private void actRight() {
        if (!ensureRunning()) {
            return;
        }
        targetLane = Math.min(1, targetLane + 1);
    }

    private void actJump() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.001f) {
            jumpVelocity = 2.35f;
            slideTimer = 0f;
        }
    }

    private void actSlide() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.12f) {
            slideTimer = 0.58f;
        }
    }

    private void drawBackdrop(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();

        paint.setShader(new LinearGradient(
                0f,
                0f,
                width,
                height,
                new int[]{Color.rgb(8, 5, 15), COLOR_NIGHT, Color.rgb(8, 5, 13)},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);

        paint.setColor(withAlpha(COLOR_PINK, 42));
        canvas.drawCircle(width * 0.78f, height * 0.12f, width * 0.18f, paint);
        paint.setColor(withAlpha(COLOR_GREEN, 28));
        canvas.drawCircle(width * 0.1f, height * 0.85f, width * 0.15f, paint);
    }

    private void drawControlPanel(Canvas canvas) {
        float width = getWidth();
        float height = getHeight();
        float panelWidth = width * 0.305f;
        gameBounds.set(panelWidth, 0f, width, height);

        paint.setShader(new LinearGradient(
                0f,
                0f,
                panelWidth,
                height,
                new int[]{Color.rgb(31, 14, 55), Color.rgb(9, 6, 17)},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, panelWidth, height, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3f, width * 0.0022f));
        paint.setColor(COLOR_PURPLE);
        canvas.drawLine(panelWidth, 0f, panelWidth, height, paint);
        paint.setColor(withAlpha(COLOR_PINK, 86));
        canvas.drawRoundRect(
                width * 0.012f,
                height * 0.025f,
                panelWidth - width * 0.012f,
                height * 0.975f,
                18f,
                18f,
                paint
        );
        paint.setStyle(Paint.Style.FILL);

        float left = panelWidth * 0.1f;
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setColor(COLOR_CREAM);
        textPaint.setShadowLayer(9f, 8f, 9f, Color.BLACK);
        textPaint.setTextSize(clamp(panelWidth * 0.22f, 42f, height * 0.15f));
        canvas.save();
        canvas.rotate(-2f, left, height * 0.16f);
        canvas.drawText("RAIL", left, height * 0.15f, textPaint);
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(7f, -6f, 5f, COLOR_PINK);
        canvas.drawText("RUSH", left, height * 0.265f, textPaint);
        canvas.restore();
        textPaint.clearShadowLayer();

        float buttonLeft = panelWidth * 0.1f;
        float buttonRight = panelWidth * 0.9f;
        float buttonTop = height * 0.34f;
        float buttonBottom = height * 0.49f;
        mainButton.set(buttonLeft, buttonTop, buttonRight, buttonBottom);
        drawArcadeButton(canvas, mainButton, mainActionLabel());

        drawControlGuide(canvas, panelWidth, height);
    }

    private void drawArcadeButton(Canvas canvas, RectF bounds, String label) {
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(
                bounds.left + 10f,
                bounds.top + 12f,
                bounds.right + 10f,
                bounds.bottom + 12f,
                14f,
                14f,
                paint
        );
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(
                bounds.left + 6f,
                bounds.top + 8f,
                bounds.right + 6f,
                bounds.bottom + 8f,
                14f,
                14f,
                paint
        );

        paint.setShader(new LinearGradient(
                0f,
                bounds.top,
                0f,
                bounds.bottom,
                new int[]{Color.rgb(255, 235, 114), COLOR_YELLOW, Color.rgb(245, 173, 20)},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(bounds, 14f, 14f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f);
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(bounds, 14f, 14f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(COLOR_INK);
        textPaint.setTextSize(Math.min(bounds.height() * 0.54f, bounds.width() * 0.2f));
        drawTextCentered(canvas, label, bounds.centerX(), bounds.centerY(), textPaint);
    }

    private void drawControlGuide(Canvas canvas, float panelWidth, float height) {
        float centerX = panelWidth * 0.5f;
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(clamp(panelWidth * 0.065f, 18f, 32f));
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText("KAWALAN", centerX, height * 0.57f, textPaint);

        paint.setColor(COLOR_GREEN);
        canvas.drawRect(panelWidth * 0.1f, height * 0.555f, panelWidth * 0.3f, height * 0.56f, paint);
        canvas.drawRect(panelWidth * 0.7f, height * 0.555f, panelWidth * 0.9f, height * 0.56f, paint);

        float key = Math.min(panelWidth * 0.12f, height * 0.06f);
        float gap = key * 0.15f;
        float baseY = height * 0.62f;
        drawKey(canvas, centerX, baseY, key, "↑");
        drawKey(canvas, centerX - key - gap, baseY + key + gap, key, "←");
        drawKey(canvas, centerX, baseY + key + gap, key, "↓");
        drawKey(canvas, centerX + key + gap, baseY + key + gap, key, "→");

        textPaint.setTextSize(clamp(panelWidth * 0.045f, 13f, 21f));
        textPaint.setColor(COLOR_YELLOW);
        canvas.drawText("WASD / ANAK PANAH", centerX, height * 0.82f, textPaint);
        textPaint.setTextSize(clamp(panelWidth * 0.035f, 11f, 17f));
        textPaint.setColor(withAlpha(COLOR_CREAM, 180));
        canvas.drawText("Tukar lorong • Lompat • Gelongsor", centerX, height * 0.855f, textPaint);

        textPaint.setTextSize(clamp(panelWidth * 0.052f, 15f, 24f));
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText("↔  SWIPE  ↕", centerX, height * 0.92f, textPaint);
    }

    private void drawKey(Canvas canvas, float centerX, float top, float size, String label) {
        RectF box = new RectF(centerX - size / 2f, top, centerX + size / 2f, top + size);
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(box.left + 3f, box.top + 5f, box.right + 3f, box.bottom + 5f, 8f, 8f, paint);
        paint.setColor(Color.rgb(55, 28, 91));
        canvas.drawRoundRect(box, 8f, 8f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(Color.rgb(183, 120, 250));
        canvas.drawRoundRect(box, 8f, 8f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(size * 0.5f);
        textPaint.setColor(COLOR_YELLOW);
        drawTextCentered(canvas, label, centerX, top + size / 2f, textPaint);
    }

    private void drawGameArea(Canvas canvas, long now) {
        float left = gameBounds.left;
        float width = gameBounds.width();
        float height = gameBounds.height();

        canvas.save();
        float shakeX = shake > 0f ? (float) Math.sin(now * 0.08f) * shake * 8f : 0f;
        canvas.translate(shakeX, 0f);
        canvas.clipRect(gameBounds);

        paint.setShader(new LinearGradient(
                left,
                0f,
                left,
                height,
                new int[]{
                        Color.rgb(17, 8, 33),
                        Color.rgb(90, 21, 119),
                        Color.rgb(240, 58, 135),
                        Color.rgb(22, 11, 45)
                },
                new float[]{0f, 0.42f, 0.68f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(gameBounds, paint);
        paint.setShader(null);

        drawStars(canvas, left, width, height);
        drawCity(canvas, left, width, height);
        drawTracks(canvas, left, width, height);

        entities.sort(Comparator.comparingDouble(entity -> entity.z));
        for (Entity entity : entities) {
            if (entity.passed || entity.z < -0.02f || entity.z > 1.18f) {
                continue;
            }
            float x = projectX(left, width, entity.lane, entity.z);
            float y = projectY(height, entity.z);
            float scale = projectScale(entity.z);

            switch (entity.kind) {
                case COIN:
                    drawCoin(canvas, x, y, scale, now);
                    break;
                case BARRIER:
                    drawBarrier(canvas, x, y, scale);
                    break;
                case GATE:
                    drawGate(canvas, x, y, scale);
                    break;
                case TRAIN:
                    drawTrain(canvas, x, y, scale);
                    break;
            }
        }

        float runnerX = left + width / 2f + laneVisual * width * 0.25f;
        float runnerY = height * 0.91f - jump * height * 0.22f;
        drawRunner(canvas, runnerX, runnerY, clamp(width * 0.09f, 54f, 112f), now);

        if (flash > 0f) {
            paint.setColor(withAlpha(COLOR_YELLOW, (int) (flash * 74f)));
            canvas.drawRect(gameBounds, paint);
        }
        canvas.restore();

        drawHud(canvas, left, width, height);
        drawPauseButton(canvas, left, width, height);
    }

    private void drawStars(Canvas canvas, float left, float width, float height) {
        for (int i = 0; i < 44; i += 1) {
            float x = left + (((i * 97) % 991) / 991f) * width;
            float y = 18f + (((i * 53) % 233) / 233f) * height * 0.25f;
            int alpha = 70 + (i * 17) % 110;
            paint.setColor(withAlpha(Color.rgb(255, 240, 116), alpha));
            float size = i % 4 == 0 ? 3f : 1.5f;
            canvas.drawCircle(x, y, size, paint);
        }
    }

    private void drawCity(Canvas canvas, float left, float width, float height) {
        float horizon = height * 0.29f;
        float buildingWidth = Math.max(28f, width / 22f);
        int count = (int) (width / buildingWidth) + 3;

        for (int i = 0; i < count; i += 1) {
            float x = left + i * buildingWidth - buildingWidth;
            float buildingHeight = height * (0.09f + ((i * 37) % 15) / 100f);
            paint.setColor(i % 3 == 0 ? Color.rgb(36, 17, 62) : COLOR_NIGHT);
            canvas.drawRect(x, horizon - buildingHeight, x + buildingWidth + 2f, horizon, paint);

            paint.setColor(i % 2 == 0 ? COLOR_PINK : COLOR_GREEN);
            int rows = Math.max(1, (int) (buildingHeight / 17f));
            for (int row = 0; row < rows; row += 1) {
                paint.setAlpha(65 + ((row + i) % 3) * 45);
                canvas.drawRect(x + 7f, horizon - buildingHeight + 8f + row * 15f, x + 11f,
                        horizon - buildingHeight + 14f + row * 15f, paint);
                canvas.drawRect(x + 20f, horizon - buildingHeight + 8f + row * 15f, x + 24f,
                        horizon - buildingHeight + 14f + row * 15f, paint);
            }
            paint.setAlpha(255);
        }
    }

    private void drawTracks(Canvas canvas, float left, float width, float height) {
        float horizon = height * 0.29f;
        paint.setShader(new LinearGradient(
                0f,
                horizon,
                0f,
                height,
                new int[]{Color.rgb(28, 17, 49), Color.rgb(8, 5, 15)},
                null,
                Shader.TileMode.CLAMP
        ));
        path.reset();
        path.moveTo(left + width * 0.34f, horizon);
        path.lineTo(left + width * 0.02f, height);
        path.lineTo(left + width * 0.98f, height);
        path.lineTo(left + width * 0.66f, horizon);
        path.close();
        canvas.drawPath(path, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3f, width * 0.004f));
        float[] boundaries = {-1.5f, -0.5f, 0.5f, 1.5f};
        for (int i = 0; i < boundaries.length; i += 1) {
            float lane = boundaries[i];
            paint.setColor(i == 0 || i == 3 ? COLOR_PINK : Color.rgb(110, 74, 145));
            canvas.drawLine(
                    projectX(left, width, lane, 0f),
                    projectY(height, 0f),
                    projectX(left, width, lane, 1f),
                    projectY(height, 1f),
                    paint
            );
        }

        paint.setStrokeWidth(Math.max(2f, width * 0.005f));
        paint.setColor(withAlpha(COLOR_YELLOW, 92));
        for (int i = 0; i < 12; i += 1) {
            float z = ((i / 12f + trackOffset) % 1f) * 1.05f;
            canvas.drawLine(
                    projectX(left, width, -1.52f, z),
                    projectY(height, z),
                    projectX(left, width, 1.52f, z),
                    projectY(height, z),
                    paint
            );
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawCoin(Canvas canvas, float x, float y, float scale, long now) {
        float pulse = 0.94f + (float) Math.sin(now * 0.008f + y) * 0.06f;
        float radius = 20f * scale * pulse;

        paint.setShadowLayer(22f * scale, 0f, 0f, COLOR_YELLOW);
        paint.setColor(Color.rgb(255, 184, 0));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, 4f * scale));
        paint.setColor(Color.rgb(255, 243, 163));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(255, 240, 116));
        drawStar(canvas, x, y - radius, radius * 0.52f, radius * 0.23f, paint);
    }

    private void drawBarrier(Canvas canvas, float x, float y, float scale) {
        float width = 78f * scale;
        float height = 48f * scale;
        canvas.save();
        canvas.translate(x, y - height);
        paint.setShadowLayer(12f * scale, 0f, 0f, COLOR_PINK);
        paint.setColor(Color.rgb(232, 226, 207));
        RectF body = new RectF(-width / 2f, -height / 2f, width / 2f, height / 2f);
        canvas.drawRoundRect(body, 7f * scale, 7f * scale, paint);
        paint.clearShadowLayer();
        canvas.save();
        canvas.clipRect(body);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(16f * scale);
        paint.setColor(Color.rgb(230, 58, 79));
        for (float offset = -width; offset < width; offset += 34f * scale) {
            canvas.drawLine(offset, height / 2f, offset + 35f * scale, -height / 2f, paint);
        }
        canvas.restore();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, 5f * scale));
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(body, 7f * scale, 7f * scale, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_YELLOW);
        canvas.drawCircle(-width * 0.4f, -height * 0.38f, 6f * scale, paint);
        canvas.drawCircle(width * 0.4f, -height * 0.38f, 6f * scale, paint);
        canvas.restore();
    }

    private void drawGate(Canvas canvas, float x, float y, float scale) {
        float width = 86f * scale;
        float height = 80f * scale;
        canvas.save();
        canvas.translate(x, y);
        paint.setShadowLayer(15f * scale, 0f, 0f, COLOR_GREEN);
        paint.setColor(COLOR_PANEL);
        canvas.drawRect(-width / 2f, -height, -width / 2f + 9f * scale, 0f, paint);
        canvas.drawRect(width / 2f - 9f * scale, -height, width / 2f, 0f, paint);
        RectF header = new RectF(-width / 2f, -height, width / 2f, -height + 27f * scale);
        canvas.drawRoundRect(header, 5f * scale, 5f * scale, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, 5f * scale));
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(header, 5f * scale, 5f * scale, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(Math.max(8f, 12f * scale));
        textPaint.setColor(COLOR_YELLOW);
        canvas.drawText("TUNDUK!", 0f, -height + 18f * scale, textPaint);
        canvas.restore();
    }

    private void drawTrain(Canvas canvas, float x, float y, float scale) {
        float width = 90f * scale;
        float height = 118f * scale;
        canvas.save();
        canvas.translate(x, y);
        paint.setShadowLayer(18f * scale, 0f, 0f, COLOR_PINK);
        paint.setColor(Color.rgb(42, 23, 73));
        RectF body = new RectF(-width / 2f, -height, width / 2f, 0f);
        canvas.drawRoundRect(body, 13f * scale, 13f * scale, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, 4f * scale));
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(body, 13f * scale, 13f * scale, paint);
        paint.setStyle(Paint.Style.FILL);

        paint.setColor(Color.rgb(8, 6, 17));
        RectF window = new RectF(-width * 0.34f, -height * 0.82f, width * 0.34f, -height * 0.57f);
        canvas.drawRoundRect(window, 5f * scale, 5f * scale, paint);
        paint.setColor(COLOR_CYAN);
        canvas.drawRect(-width * 0.28f, -height * 0.77f, -width * 0.07f, -height * 0.63f, paint);
        canvas.drawRect(width * 0.07f, -height * 0.77f, width * 0.28f, -height * 0.63f, paint);
        paint.setColor(COLOR_YELLOW);
        canvas.drawCircle(0f, -height * 0.43f, 11f * scale, paint);
        paint.setColor(COLOR_GREEN);
        canvas.drawRect(-width * 0.38f, -height * 0.18f, width * 0.38f, -height * 0.11f, paint);
        canvas.restore();
    }

    private void drawRunner(Canvas canvas, float x, float y, float size, long now) {
        boolean sliding = slideTimer > 0f;
        float stride = mode == Mode.RUNNING ? (float) Math.sin(now * 0.018f) * size * 0.14f : 0f;
        canvas.save();
        canvas.translate(x, y);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(size * 0.12f);
        paint.setColor(Color.rgb(23, 16, 31));

        if (sliding) {
            path.reset();
            path.moveTo(-size * 0.05f, -size * 0.28f);
            path.lineTo(size * 0.38f, -size * 0.08f);
            path.lineTo(size * 0.56f, 0f);
            canvas.drawPath(path, paint);
        } else {
            canvas.drawLine(-size * 0.08f, -size * 0.45f,
                    -size * 0.13f + stride, -size * 0.03f, paint);
            canvas.drawLine(size * 0.08f, -size * 0.45f,
                    size * 0.16f - stride, -size * 0.02f, paint);
        }

        paint.setStrokeWidth(size * 0.095f);
        paint.setColor(COLOR_YELLOW);
        canvas.drawLine(-size * 0.25f, -size * 0.67f,
                -size * 0.42f - stride * 0.4f, -size * 0.42f, paint);
        canvas.drawLine(size * 0.25f, -size * 0.67f,
                size * 0.42f + stride * 0.4f, -size * 0.46f, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(16f, 0f, 0f, COLOR_GREEN);
        paint.setColor(COLOR_PURPLE);
        RectF jacket = new RectF(
                -size * 0.27f,
                sliding ? -size * 0.63f : -size * 0.84f,
                size * 0.27f,
                sliding ? -size * 0.15f : -size * 0.36f
        );
        canvas.drawRoundRect(jacket, size * 0.13f, size * 0.13f, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(size * 0.07f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(jacket, size * 0.13f, size * 0.13f, paint);
        paint.setStyle(Paint.Style.FILL);

        paint.setColor(COLOR_GREEN);
        path.reset();
        path.moveTo(0f, sliding ? -size * 0.54f : -size * 0.73f);
        path.lineTo(-size * 0.12f, sliding ? -size * 0.42f : -size * 0.52f);
        path.lineTo(size * 0.04f, sliding ? -size * 0.46f : -size * 0.55f);
        path.lineTo(size * 0.13f, sliding ? -size * 0.62f : -size * 0.73f);
        path.close();
        canvas.drawPath(path, paint);

        float headY = sliding ? -size * 0.72f : -size * 0.99f;
        paint.setColor(Color.rgb(217, 140, 95));
        canvas.drawCircle(0f, headY, size * 0.18f, paint);
        paint.setColor(COLOR_INK);
        RectF hair = new RectF(-size * 0.18f, headY - size * 0.18f,
                size * 0.18f, headY + size * 0.02f);
        canvas.drawArc(hair, 180f, 180f, true, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
        canvas.restore();
    }

    private void drawHud(Canvas canvas, float left, float width, float height) {
        float gap = width * 0.012f;
        float cardWidth = width * 0.21f;
        float cardHeight = Math.min(height * 0.115f, 98f * density);
        float top = height * 0.035f;
        float right = left + width - gap;

        RectF coinCard = new RectF(right - cardWidth, top, right, top + cardHeight);
        RectF scoreCard = new RectF(
                coinCard.left - gap - cardWidth * 1.2f,
                top,
                coinCard.left - gap,
                top + cardHeight
        );

        drawHudCard(canvas, scoreCard, "SKOR", String.format(Locale.US, "%06d", getScore()), false);
        drawHudCard(canvas, coinCard, "SYILING", String.valueOf(coins), true);

        float bestWidth = width * 0.15f;
        RectF bestCard = new RectF(left + gap, top, left + gap + bestWidth, top + cardHeight);
        drawHudCard(canvas, bestCard, "TERBAIK",
                String.format(Locale.US, "%06d", bestScore), false);
    }

    private void drawHudCard(Canvas canvas, RectF bounds, String label, String value, boolean coin) {
        paint.setColor(withAlpha(Color.rgb(8, 5, 15), 226));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(Color.rgb(110, 50, 173));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setColor(COLOR_GREEN);
        textPaint.setTextSize(Math.max(11f * density, bounds.height() * 0.18f));
        canvas.drawText(label, bounds.left + bounds.width() * 0.1f,
                bounds.top + bounds.height() * 0.3f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setColor(COLOR_CREAM);
        textPaint.setTextSize(bounds.height() * 0.45f);
        float valueX = bounds.left + bounds.width() * 0.1f;
        if (coin) {
            float radius = bounds.height() * 0.16f;
            float coinX = valueX + radius;
            float coinY = bounds.top + bounds.height() * 0.69f;
            paint.setColor(COLOR_YELLOW);
            canvas.drawCircle(coinX, coinY, radius, paint);
            paint.setColor(Color.rgb(200, 121, 0));
            drawStar(canvas, coinX, coinY, radius * 0.56f, radius * 0.25f, paint);
            valueX += radius * 2.5f;
        }
        canvas.drawText(value, valueX, bounds.top + bounds.height() * 0.82f, textPaint);
    }

    private void drawPauseButton(Canvas canvas, float left, float width, float height) {
        float size = Math.min(width * 0.065f, height * 0.09f);
        float margin = width * 0.02f;
        pauseButton.set(
                left + width - margin - size,
                height - margin - size,
                left + width - margin,
                height - margin
        );
        paint.setColor(withAlpha(Color.rgb(11, 6, 18), 225));
        canvas.drawRoundRect(pauseButton, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(pauseButton, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(size * 0.42f);
        textPaint.setColor(mode == Mode.IDLE || mode == Mode.GAME_OVER
                ? withAlpha(COLOR_YELLOW, 90)
                : COLOR_YELLOW);
        drawTextCentered(canvas, mode == Mode.PAUSED ? "▶" : "Ⅱ",
                pauseButton.centerX(), pauseButton.centerY(), textPaint);
    }

    private void drawOverlay(Canvas canvas) {
        float left = gameBounds.left;
        float width = gameBounds.width();
        float height = gameBounds.height();

        paint.setColor(withAlpha(Color.BLACK, 95));
        canvas.drawRect(gameBounds, paint);

        float cardWidth = Math.min(width * 0.58f, 620f * density);
        float cardHeight = Math.min(height * 0.5f, 340f * density);
        RectF card = new RectF(
                left + (width - cardWidth) / 2f,
                (height - cardHeight) / 2f,
                left + (width + cardWidth) / 2f,
                (height + cardHeight) / 2f
        );

        paint.setColor(withAlpha(Color.rgb(10, 6, 18), 242));
        paint.setShadowLayer(28f, 0f, 16f, Color.BLACK);
        canvas.drawRoundRect(card, 20f, 20f, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(card, 20f, 20f, paint);
        paint.setStrokeWidth(2f);
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(
                card.left + 8f,
                card.top + 8f,
                card.right - 8f,
                card.bottom - 8f,
                16f,
                16f,
                paint
        );
        paint.setStyle(Paint.Style.FILL);

        String kicker;
        String title;
        String description;
        if (mode == Mode.GAME_OVER) {
            kicker = "LARIAN TAMAT";
            title = "PECAHKAN REKOD!";
            description = "Tukar lorong lebih awal • Lompat • Gelongsor";
        } else if (mode == Mode.PAUSED) {
            kicker = "DIJEDA";
            title = "TARIK NAFAS.";
            description = "Tekan P atau butang sambung untuk kembali";
        } else {
            kicker = "ENDLESS RUNNER 3 LORONG";
            title = "BERSEDIA MELURU?";
            description = "Kutip syiling • Elak tren • Bertahan lebih lama";
        }

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.07f);
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText(kicker, card.centerX(), card.top + cardHeight * 0.2f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(Math.min(cardHeight * 0.19f, cardWidth * 0.085f));
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(5f, 5f, 5f, COLOR_PURPLE);
        canvas.drawText(title, card.centerX(), card.top + cardHeight * 0.45f, textPaint);
        textPaint.clearShadowLayer();

        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.052f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 190));
        canvas.drawText(description, card.centerX(), card.top + cardHeight * 0.61f, textPaint);

        RectF overlayButton = new RectF(
                card.centerX() - cardWidth * 0.24f,
                card.top + cardHeight * 0.7f,
                card.centerX() + cardWidth * 0.24f,
                card.top + cardHeight * 0.9f
        );
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(
                overlayButton.left + 6f,
                overlayButton.top + 7f,
                overlayButton.right + 6f,
                overlayButton.bottom + 7f,
                10f,
                10f,
                paint
        );
        paint.setColor(COLOR_YELLOW);
        canvas.drawRoundRect(overlayButton, 10f, 10f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(overlayButton, 10f, 10f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(overlayButton.height() * 0.45f);
        textPaint.setColor(COLOR_INK);
        drawTextCentered(canvas, mainActionLabel(), overlayButton.centerX(),
                overlayButton.centerY(), textPaint);
    }

    private String mainActionLabel() {
        switch (mode) {
            case RUNNING:
                return "JEDA";
            case PAUSED:
                return "SAMBUNG";
            case GAME_OVER:
                return "CUBA LAGI";
            default:
                return "MULA";
        }
    }

    private float projectX(float left, float width, float lane, float z) {
        float depth = clamp(z, 0f, 1.15f);
        float spread = width * (0.045f + 0.25f * pow(depth, 1.28f));
        return left + width / 2f + lane * spread;
    }

    private float projectY(float height, float z) {
        float depth = clamp(z, 0f, 1.15f);
        float horizon = height * 0.29f;
        return horizon + pow(depth, 1.65f) * (height * 0.95f - horizon);
    }

    private float projectScale(float z) {
        float depth = clamp(z, 0f, 1.15f);
        return 0.16f + 1.05f * pow(depth, 1.42f);
    }

    private static float pow(float value, float power) {
        return (float) Math.pow(value, power);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(
                Math.max(0, Math.min(255, alpha)),
                Color.red(color),
                Color.green(color),
                Color.blue(color)
        );
    }

    private void drawStar(
            Canvas canvas,
            float x,
            float y,
            float outerRadius,
            float innerRadius,
            Paint starPaint
    ) {
        path.reset();
        for (int i = 0; i < 10; i += 1) {
            float radius = i % 2 == 0 ? outerRadius : innerRadius;
            double angle = -Math.PI / 2d + i * Math.PI / 5d;
            float px = x + (float) Math.cos(angle) * radius;
            float py = y + (float) Math.sin(angle) * radius;
            if (i == 0) {
                path.moveTo(px, py);
            } else {
                path.lineTo(px, py);
            }
        }
        path.close();
        canvas.drawPath(path, starPaint);
    }

    private static void drawTextCentered(
            Canvas canvas,
            String text,
            float centerX,
            float centerY,
            Paint paint
    ) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float baseline = centerY - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText(text, centerX, baseline, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = event.getX();
                touchStartY = event.getY();
                trackingTouch = true;
                return true;
            case MotionEvent.ACTION_UP:
                if (!trackingTouch) {
                    return false;
                }
                trackingTouch = false;
                handleTouchRelease(event.getX(), event.getY());
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                trackingTouch = false;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void handleTouchRelease(float endX, float endY) {
        if (mainButton.contains(endX, endY)) {
            toggleMainAction();
            return;
        }
        if (pauseButton.contains(endX, endY)
                && mode != Mode.IDLE
                && mode != Mode.GAME_OVER) {
            togglePause();
            return;
        }

        float dx = endX - touchStartX;
        float dy = endY - touchStartY;
        float threshold = 34f * density;
        if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) {
            if (mode == Mode.RUNNING) {
                actJump();
            } else {
                toggleMainAction();
            }
            return;
        }

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx < 0f) {
                actLeft();
            } else {
                actRight();
            }
        } else if (dy < 0f) {
            actJump();
        } else {
            actSlide();
        }
    }
}
