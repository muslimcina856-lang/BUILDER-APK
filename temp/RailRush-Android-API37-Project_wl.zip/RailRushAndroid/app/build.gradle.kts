plugins {
    id("com.android.application")
}

android {
    namespace = "com.earlxz.railrush"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.earlxz.railrush"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}
