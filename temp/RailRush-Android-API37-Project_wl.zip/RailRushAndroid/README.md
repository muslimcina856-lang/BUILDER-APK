# Rail Rush untuk Android

Versi Android asli bagi game endless runner **Rail Rush**, dibina dengan Java dan Canvas Android tanpa enjin permainan atau pustaka pihak ketiga.

## Tetapan Android

- compileSdk = 37
- targetSdk = 37
- minSdk = 26
- Android Gradle Plugin 9.3.0
- Gradle 9.5.0
- Java 17
- Application ID: com.earlxz.railrush
- Orientasi: landskap

## Ciri permainan

- Tiga lorong dengan kawalan swipe dan papan kekunci
- Lompat penghadang, gelongsor di bawah palang, dan elak tren
- Kutipan syiling, skor, rekod terbaik setempat, jeda dan mula semula
- Kelajuan meningkat secara berperingkat
- Haptic feedback, antaramuka skrin penuh dan gaya retro arcade
- Tiada Internet, akaun atau kebenaran sensitif diperlukan

## Cara buka

1. Pasang Android Studio Quail 3 atau lebih baharu.
2. Dalam SDK Manager, pasang Android 17 / API 37 dan Build Tools 36.0.0 atau lebih baharu.
3. Buka folder projek ini dalam Android Studio.
4. Tunggu Gradle Sync selesai, kemudian tekan **Run**.

Untuk membina APK debug:

    ./gradlew assembleDebug

APK akan terhasil di:

    app/build/outputs/apk/debug/app-debug.apk

Dokumentasi rasmi:

- https://developer.android.com/about/versions/17/setup-sdk
- https://developer.android.com/build/releases/agp-9-3-0-release-notes
