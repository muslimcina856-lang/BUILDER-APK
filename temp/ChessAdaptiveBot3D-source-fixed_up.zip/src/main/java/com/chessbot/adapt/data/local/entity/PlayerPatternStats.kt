package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "player_pattern_stats",
    foreignKeys = [
        ForeignKey(entity = PlayerProfile::class, parentColumns = ["id"], childColumns = ["player_id"]),
        ForeignKey(entity = PatternDefinition::class, parentColumns = ["id"], childColumns = ["pattern_id"])
    ],
    indices = [Index(value = ["player_id", "pattern_id"], unique = true)]
)
data class PlayerPatternStats(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")
    val playerId: Long,
    @ColumnInfo(name = "pattern_id")
    val patternId: Long,
    @ColumnInfo(name = "times_encountered")
    val timesEncountered: Int = 0,
    @ColumnInfo(name = "times_successful")
    val timesSuccessful: Int = 0,
    @ColumnInfo(name = "times_failed")
    val timesFailed: Int = 0,
    @ColumnInfo(name = "success_rate")
    val successRate: Float = 0.5f,
    @ColumnInfo(name = "last_seen_at")
    val lastSeenAt: Long? = null,
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)
