package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "moves",
    foreignKeys = [ForeignKey(
        entity = GameSession::class,
        parentColumns = ["id"],
        childColumns = ["game_id"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["game_id"])]
)
data class MoveEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "game_id")
    val gameId: Long,
    @ColumnInfo(name = "move_number")
    val moveNumber: Int,
    val color: String,
    @ColumnInfo(name = "from_square")
    val fromSquare: String,
    @ColumnInfo(name = "to_square")
    val toSquare: String,
    @ColumnInfo(name = "piece_type")
    val pieceType: String,
    @ColumnInfo(name = "promotion_piece")
    val promotionPiece: String? = null,
    @ColumnInfo(name = "captured_piece")
    val capturedPiece: String? = null,
    @ColumnInfo(name = "is_check")
    val isCheck: Boolean = false,
    @ColumnInfo(name = "is_checkmate")
    val isCheckmate: Boolean = false,
    @ColumnInfo(name = "is_castling")
    val isCastling: Boolean = false,
    @ColumnInfo(name = "is_en_passant")
    val isEnPassant: Boolean = false,
    @ColumnInfo(name = "think_time_ms")
    val thinkTimeMs: Int = 0,
    @ColumnInfo(name = "fen_after")
    val fenAfter: String
)
