# Da1chi Terminal — Python Interpreter Flutter App

Terminal Python berbasis Flutter dengan desain cyberpunk dark green.

## Fitur

### ✅ Auto-pair Brackets
Mengetik `(`, `[`, `{`, `"`, `'` → otomatis ditutup

### ✅ Saran Kata (Autocomplete)
Mengetik prefix Python → muncul chip saran di atas input:
- `pr` → `print()`, `property`, dll
- `de` → `def `, `def __init__`, dll
- `im` → `import os`, `import sys`, dll
- `fo` → `for i in range():`, dll
- 50+ keyword lainnya

**Tab** = apply saran pertama
**Tap chip** = apply saran tersebut

### ✅ Mode Multi-baris
Baris diakhiri `:` (if, for, def, class, dll) → masuk mode blok otomatis
- Indentasi otomatis 4 spasi
- Enter kosong → jalankan seluruh blok
- Esc → batal

### ✅ History Perintah
- ↑ / ↓ di keyboard untuk navigasi history
- Disimpan ke SharedPreferences (persisten)

### ✅ Multi-sesi
Buka banyak sesi terminal sekaligus via tab di atas

### ✅ Eksekusi Python
1. Snowping API (`/api/tools/python`) — executor langsung
2. Fallback → TurboAI sebagai Python interpreter
3. Fallback → Claude AI sebagai Python interpreter

### ✅ Warna Output
| Warna | Arti |
|-------|------|
| 🟢 Hijau | Input (`>>>`) |
| 🔵 Cyan | Output normal |
| 🔴 Merah | Error / exception |
| 🟡 Kuning | Warning / multiline |
| 🟣 Violet | Pesan sistem |

### Perintah Built-in
- `cls` / `clear` → bersihkan terminal
- `help` → tampilkan bantuan

## Setup

```yaml
# pubspec.yaml dependencies:
http: ^1.2.0
provider: ^6.1.2
google_fonts: ^6.2.1
shared_preferences: ^2.3.0
```

## Font
- **JetBrains Mono** — semua teks terminal (monospace)
- **Space Grotesk** — judul / label UI

## Color Palette
```
bg950    #060608  — pure void black (body)
bg900    #0D0E12  — terminal bg
bg800    #13151C  — panel / bar bg
green    #00FF87  — prompt / output utama
cyan     #00D4FF  — output Python
violet   #8B5CF6  — aksen / sistem
amber    #FFB800  — warning / multiline
red      #FF3B5C  — error
```

## Struktur File
```
lib/
├── main.dart
├── theme/
│   └── term_theme.dart       # Palette & TextStyle
├── models/
│   └── term_model.dart       # TermLine, TermSession
├── services/
│   ├── terminal_provider.dart # State + API execution
│   └── python_suggest.dart   # Autocomplete engine
├── widgets/
│   ├── term_output.dart      # Render output lines
│   ├── term_input.dart       # Input bar + suggestions
│   └── session_tabs.dart     # Tab bar sessions
└── screens/
    └── terminal_screen.dart  # Main screen
```
