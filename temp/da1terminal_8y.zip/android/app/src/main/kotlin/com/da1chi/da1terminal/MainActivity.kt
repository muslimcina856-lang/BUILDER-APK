package com.da1chi.da1terminal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
