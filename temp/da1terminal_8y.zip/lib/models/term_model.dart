enum LineType { input, output, error, info, system, result }

class TermLine {
  final String text;
  final LineType type;
  final DateTime timestamp;

  TermLine({
    required this.text,
    required this.type,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class TermSession {
  final String id;
  final String name;
  final List<TermLine> lines;
  final DateTime createdAt;
  bool isRunning;

  TermSession({
    required this.id,
    required this.name,
    List<TermLine>? lines,
    DateTime? createdAt,
    this.isRunning = false,
  })  : lines = lines ?? [],
        createdAt = createdAt ?? DateTime.now();
}
