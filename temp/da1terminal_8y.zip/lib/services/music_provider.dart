import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:file_picker/file_picker.dart';

class MusicTrack {
  final String path;
  final String name;

  MusicTrack({required this.path, required this.name});

  String get displayName {
    // Remove extension and clean up name
    final withoutExt = name.endsWith('.mp3')
        ? name.substring(0, name.length - 4)
        : name;
    return withoutExt;
  }
}

class MusicProvider extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();

  List<MusicTrack> _playlist = [];
  int _currentIndex = -1;
  bool _isVisible = false;
  bool _isMinimized = false;

  // Expose player stream states
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<Duration> get positionStream => _player.positionStream;
  Stream<double> get volumeStream => _player.volumeStream;

  List<MusicTrack> get playlist => _playlist;
  int get currentIndex => _currentIndex;
  bool get isVisible => _isVisible;
  bool get isMinimized => _isMinimized;
  bool get hasTrack => _currentIndex >= 0 && _currentIndex < _playlist.length;
  MusicTrack? get currentTrack =>
      hasTrack ? _playlist[_currentIndex] : null;
  bool get isPlaying => _player.playing;
  double get volume => _player.volume;

  MusicProvider() {
    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _playNext();
      }
      notifyListeners();
    });
  }

  Future<void> pickAndAddFiles() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: true,
      allowedExtensions: ['mp3', 'aac', 'm4a', 'wav', 'ogg', 'flac'],
    );
    if (result == null || result.files.isEmpty) return;

    for (final file in result.files) {
      final path = file.path;
      if (path == null) continue;
      // Avoid duplicates
      if (_playlist.any((t) => t.path == path)) continue;
      _playlist.add(MusicTrack(path: path, name: file.name));
    }

    // Auto-play first if nothing playing
    if (_currentIndex < 0 && _playlist.isNotEmpty) {
      await playAt(0);
    }

    _isVisible = true;
    notifyListeners();
  }

  Future<void> playAt(int index) async {
    if (index < 0 || index >= _playlist.length) return;
    _currentIndex = index;
    try {
      await _player.setFilePath(_playlist[index].path);
      await _player.play();
    } catch (e) {
      debugPrint('Music error: $e');
    }
    notifyListeners();
  }

  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      if (!hasTrack && _playlist.isNotEmpty) {
        await playAt(0);
        return;
      }
      await _player.play();
    }
    notifyListeners();
  }

  Future<void> _playNext() async {
    if (_playlist.isEmpty) return;
    final next = (_currentIndex + 1) % _playlist.length;
    await playAt(next);
  }

  Future<void> playNext() => _playNext();

  Future<void> playPrev() async {
    if (_playlist.isEmpty) return;
    final pos = await _player.position;
    // If >3s into track, restart it
    if (pos.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    final prev =
        (_currentIndex - 1 + _playlist.length) % _playlist.length;
    await playAt(prev);
  }

  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  Future<void> setVolume(double v) async {
    await _player.setVolume(v.clamp(0.0, 1.0));
    notifyListeners();
  }

  void removeTrack(int index) {
    if (index == _currentIndex) {
      _player.stop();
      _currentIndex = -1;
    } else if (index < _currentIndex) {
      _currentIndex--;
    }
    _playlist.removeAt(index);
    if (_playlist.isEmpty) {
      _isVisible = false;
    }
    notifyListeners();
  }

  void clearPlaylist() {
    _player.stop();
    _playlist.clear();
    _currentIndex = -1;
    _isVisible = false;
    notifyListeners();
  }

  void toggleVisibility() {
    _isVisible = !_isVisible;
    notifyListeners();
  }

  void show() {
    _isVisible = true;
    notifyListeners();
  }

  void toggleMinimize() {
    _isMinimized = !_isMinimized;
    notifyListeners();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
