/// Python autocomplete & auto-pair engine

class PythonSuggest {
  // Keyword suggestions: trigger -> completions[]
  static const Map<String, List<String>> _kw = {
    'pr': ['print()', 'print(f"")', 'property', 'pass', 'protected'],
    'pri': ['print()', 'print(f"")'],
    'prin': ['print()', 'print(f"")'],
    'print': ['print()', 'print(f"")', 'print(end="")', 'print(sep="")'],
    'de': ['def ', 'del ', 'def __init__(self):', 'def main():'],
    'def': ['def ', 'def __init__(self):', 'def main():', 'def __str__(self):'],
    'im': ['import ', 'import os', 'import sys', 'import json', 'import re'],
    'imp': ['import ', 'import os', 'import sys', 'import json'],
    'fr': ['from ', 'from os import ', 'from sys import '],
    'fro': ['from ', 'from os import '],
    'from': ['from os import ', 'from sys import ', 'from typing import '],
    'cl': ['class ', 'class MyClass:', 'clear()'],
    'cla': ['class ', 'class MyClass:'],
    'clas': ['class ', 'class MyClass(object):'],
    'class': ['class MyClass:', 'class MyClass(object):'],
    'if': ['if ', 'if __name__ == "__main__":', 'if True:', 'if x is None:'],
    'el': ['else:', 'elif ', 'elif x > 0:'],
    'eli': ['elif '],
    'els': ['else:'],
    'fo': ['for ', 'for i in range():', 'for item in :', 'for k, v in .items():'],
    'for': ['for i in range():', 'for item in :', 'for k, v in .items():'],
    'wh': ['while ', 'while True:'],
    'whi': ['while True:', 'while '],
    'ret': ['return ', 'return None', 'return True', 'return False'],
    'retu': ['return ', 'return None'],
    'retur': ['return ', 'return None'],
    'try': ['try:\n    \nexcept Exception as e:\n    print(e)'],
    'exc': ['except Exception as e:', 'except (TypeError, ValueError):'],
    'exce': ['except Exception as e:'],
    'wit': ['with open() as f:', 'with '],
    'with': ['with open() as f:', 'with open("file.txt", "r") as f:'],
    'lis': ['list()', 'list(map(, ))', 'list(filter(, ))'],
    'dict': ['dict()', '{}', '.items()', '.keys()', '.values()'],
    'set': ['set()', 'set([])'],
    'tup': ['tuple()', '()'],
    'str': ['str()', 'string', '.strip()', '.split()', '.replace()'],
    'int': ['int()', 'isinstance(x, int)'],
    'len': ['len()', 'len([])'],
    'ran': ['range()', 'range(10)', 'range(1, 11)', 'random'],
    'rang': ['range()', 'range(10)', 'range(1, 11)'],
    'lam': ['lambda x: x', 'lambda x, y: x + y'],
    'lamb': ['lambda x: x'],
    'op': ['open()', 'open("file.txt", "r")', 'os.path.'],
    'ope': ['open("file.txt", "r")', 'open("file.txt", "w")'],
    'inp': ['input()', 'input("Masukkan: ")'],
    'inpu': ['input()', 'input("Masukkan: ")'],
    'enu': ['enumerate()', 'enumerate(list, start=0)'],
    'zip': ['zip()', 'zip(list1, list2)'],
    'map': ['map(func, iterable)', 'map(lambda x: x, list)'],
    'fil': ['filter(func, iterable)', 'filter(lambda x: x, list)'],
    'sor': ['sorted()', 'sort()', '.sort()', 'sorted(list, reverse=True)'],
    'max': ['max()', 'max(list)', 'max(a, b)'],
    'min': ['min()', 'min(list)', 'min(a, b)'],
    'sum': ['sum()', 'sum(list)'],
    'abs': ['abs()', 'abs(x)'],
    'rou': ['round()', 'round(x, 2)'],
    'typ': ['type()', 'type(x)', 'isinstance(x, type)'],
    'has': ['hasattr(obj, "attr")', 'hash()'],
    'get': ['getattr(obj, "attr")', '.get(key, default)'],
    'set': ['setattr(obj, "attr", val)', 'set()', '.add()', '.update()'],
    'ass': ['assert ', 'assert x == y, "message"'],
    'glo': ['global ', 'global var'],
    'non': ['nonlocal ', 'None', 'nonlocal var'],
    'yie': ['yield ', 'yield from '],
    'asy': ['async def ', 'async with ', 'async for '],
    'awa': ['await '],
    '#': ['# TODO: ', '# FIXME: ', '# NOTE: ', '# type: ignore'],
    '__': ['__init__', '__str__', '__repr__', '__len__', '__main__', '__name__', '__doc__'],
  };

  /// Get suggestions for a given prefix (last word being typed)
  static List<String> getSuggestions(String prefix) {
    if (prefix.isEmpty) return [];
    final lower = prefix.toLowerCase();
    final results = <String>{};
    for (final key in _kw.keys) {
      if (key.startsWith(lower) || lower.startsWith(key)) {
        results.addAll(_kw[key]!);
      }
    }
    // Also filter so suggestions start with the prefix
    return results
        .where((s) => s.toLowerCase().startsWith(lower) || s.contains(lower))
        .take(6)
        .toList();
  }

  /// Auto-pair characters: returns the closing pair or null
  static String? getAutoPair(String char) {
    const pairs = {
      '(': ')',
      '[': ']',
      '{': '}',
      '"': '"',
      "'": "'",
    };
    return pairs[char];
  }

  /// Check if input should trigger auto-indent (ends with ':')
  static bool shouldAutoIndent(String line) {
    final trimmed = line.trimRight();
    return trimmed.endsWith(':') || trimmed.endsWith('\\');
  }

  /// Get indent to prepend based on current line
  static String getAutoIndent(String currentLine) {
    final indent = RegExp(r'^(\s*)').firstMatch(currentLine)?.group(1) ?? '';
    final extraIndent = shouldAutoIndent(currentLine) ? '    ' : '';
    return '$indent$extraIndent';
  }

  /// Extract the "current token" (last word being typed) from full input
  static String getCurrentToken(String text) {
    final match = RegExp(r'[\w#_\.]+$').firstMatch(text);
    return match?.group(0) ?? '';
  }
}
