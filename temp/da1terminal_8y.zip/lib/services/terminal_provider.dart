import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/term_model.dart';

class TerminalProvider extends ChangeNotifier {
  final List<TermSession> _sessions = [];
  int _activeIndex = 0;
  bool _isExecuting = false;
  String? _lastError;

  List<TermSession> get sessions => _sessions;
  TermSession? get active => _sessions.isEmpty ? null : _sessions[_activeIndex];
  bool get isExecuting => _isExecuting;
  String? get lastError => _lastError;

  // Command history
  final List<String> _history = [];
  int _historyIndex = -1;
  List<String> get history => _history;

  TerminalProvider() {
    _init();
  }

  void _init() {
    newSession();
    _loadHistory();
  }

  // ── Sessions ────────────────────────────────────────────────
  void newSession({String? name}) {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final sess = TermSession(
      id: id,
      name: name ?? 'session-${_sessions.length + 1}',
    );
    sess.lines.add(TermLine(
      text: 'Da1chi Python Terminal v1.0 — ketik kode Python lalu Enter',
      type: LineType.system,
    ));
    sess.lines.add(TermLine(
      text: 'Tip: (, [, { otomatis ditutup • ketik "cls" untuk clear • Ctrl+C batalkan',
      type: LineType.info,
    ));
    _sessions.add(sess);
    _activeIndex = _sessions.length - 1;
    notifyListeners();
  }

  void switchSession(int index) {
    if (index >= 0 && index < _sessions.length) {
      _activeIndex = index;
      notifyListeners();
    }
  }

  void closeSession(int index) {
    if (_sessions.length <= 1) return;
    _sessions.removeAt(index);
    _activeIndex = (_activeIndex >= _sessions.length)
        ? _sessions.length - 1
        : _activeIndex;
    notifyListeners();
  }

  void clearSession() {
    active?.lines.clear();
    active?.lines.add(TermLine(
      text: 'Terminal dibersihkan.',
      type: LineType.system,
    ));
    notifyListeners();
  }

  // ── Execution ───────────────────────────────────────────────
  Future<void> runCode(String code) async {
    if (code.trim().isEmpty) return;
    final sess = active;
    if (sess == null) return;

    // Add to history
    _addHistory(code);

    // Handle built-in commands
    if (code.trim().toLowerCase() == 'cls' || code.trim().toLowerCase() == 'clear') {
      clearSession();
      return;
    }
    if (code.trim().toLowerCase() == 'help') {
      _addHelp();
      return;
    }

    sess.lines.add(TermLine(text: '>>> $code', type: LineType.input));
    notifyListeners();

    _isExecuting = true;
    _lastError = null;
    notifyListeners();

    try {
      final result = await _execPython(code);
      if (result.stdout.isNotEmpty) {
        for (final line in result.stdout.split('\n')) {
          if (line.isNotEmpty) {
            sess.lines.add(TermLine(text: line, type: LineType.output));
          }
        }
      }
      if (result.stderr.isNotEmpty) {
        for (final line in result.stderr.split('\n')) {
          if (line.isNotEmpty) {
            sess.lines.add(TermLine(text: line, type: LineType.error));
          }
        }
      }
      if (result.stdout.isEmpty && result.stderr.isEmpty) {
        sess.lines.add(TermLine(text: '(no output)', type: LineType.info));
      }
    } catch (e) {
      _lastError = e.toString();
      sess.lines.add(TermLine(
        text: 'Error: $_lastError',
        type: LineType.error,
      ));
    }

    _isExecuting = false;
    notifyListeners();
  }

  // ── Python exec via Snowping API ────────────────────────────
  Future<_ExecResult> _execPython(String code) async {
    // Coba Snowping python executor
    try {
      return await _trySnowping(code);
    } catch (e) {
      // Fallback: evaluasi via AI interpreter (Claude/TurboAI)
      return await _tryAIInterpreter(code);
    }
  }

  Future<_ExecResult> _trySnowping(String code) async {
    final uri = Uri.parse('https://apis.snowping.eu.cc/api/tools/python').replace(
      queryParameters: {'code': code},
    );
    final res = await http.get(uri).timeout(const Duration(seconds: 30));
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final output = data['result']?.toString() ??
          data['output']?.toString() ??
          data['stdout']?.toString() ??
          '';
      final err = data['error']?.toString() ??
          data['stderr']?.toString() ??
          '';
      return _ExecResult(stdout: output, stderr: err);
    }
    throw Exception('Snowping ${res.statusCode}');
  }

  Future<_ExecResult> _tryAIInterpreter(String code) async {
    // Gunakan TurboAI untuk "menjalankan" Python secara simulasi
    final prompt =
        'Kamu adalah Python interpreter. Jalankan kode berikut dan HANYA tampilkan outputnya saja (persis seperti terminal Python), tanpa penjelasan apapun. Jika ada error, tampilkan error tracebacknya saja.\n\nKode:\n```python\n$code\n```';

    final uri = Uri.parse('https://apis.snowping.eu.cc/api/aichat/turboai').replace(
      queryParameters: {'q': prompt},
    );
    final res = await http.get(uri).timeout(const Duration(seconds: 30));

    String output = '';
    String err = '';

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final raw = data['result']?.toString() ??
          data['response']?.toString() ??
          data['message']?.toString() ??
          '';

      // Pisahkan output dari error
      if (raw.contains('Error') || raw.contains('Traceback') || raw.contains('Exception')) {
        err = raw;
      } else {
        // Bersihkan markdown code blocks jika ada
        output = raw
            .replaceAll(RegExp(r'```[a-z]*\n?'), '')
            .replaceAll('```', '')
            .trim();
      }
    } else {
      // Fallback ke Claude
      final claudeUri = Uri.parse('https://apis.snowping.eu.cc/api/aichat/aiclaude').replace(
        queryParameters: {'q': prompt},
      );
      final cRes = await http.get(claudeUri).timeout(const Duration(seconds: 30));
      if (cRes.statusCode == 200) {
        final data = jsonDecode(cRes.body) as Map<String, dynamic>;
        output = data['result']?.toString() ??
            data['response']?.toString() ??
            data['message']?.toString() ??
            '(API tidak tersedia)';
        output = output
            .replaceAll(RegExp(r'```[a-z]*\n?'), '')
            .replaceAll('```', '')
            .trim();
      } else {
        throw Exception('Semua API tidak tersedia (${cRes.statusCode})');
      }
    }

    return _ExecResult(stdout: output, stderr: err);
  }

  void _addHelp() {
    final sess = active;
    if (sess == null) return;
    final helps = [
      '╔══════════════════════════════════════╗',
      '║    Da1chi Terminal — Bantuan          ║',
      '╠══════════════════════════════════════╣',
      '║  cls / clear   → bersihkan terminal  ║',
      '║  help          → tampilkan ini       ║',
      '║  ↑ / ↓         → history perintah   ║',
      '║  (  [  {       → auto-tutup          ║',
      '║  Tab           → autocomplete        ║',
      '║  Ctrl+L        → clear (shortcut)    ║',
      '╚══════════════════════════════════════╝',
    ];
    for (final h in helps) {
      sess.lines.add(TermLine(text: h, type: LineType.info));
    }
    notifyListeners();
  }

  // ── History ─────────────────────────────────────────────────
  void _addHistory(String cmd) {
    if (_history.isEmpty || _history.last != cmd) {
      _history.add(cmd);
      if (_history.length > 100) _history.removeAt(0);
      _saveHistory();
    }
    _historyIndex = _history.length;
  }

  String? historyPrev(String currentInput) {
    if (_history.isEmpty) return null;
    if (_historyIndex > 0) _historyIndex--;
    return _history[_historyIndex];
  }

  String? historyNext() {
    if (_historyIndex < _history.length - 1) {
      _historyIndex++;
      return _history[_historyIndex];
    }
    _historyIndex = _history.length;
    return '';
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('da1term_history') ?? [];
    _history.addAll(saved);
    _historyIndex = _history.length;
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('da1term_history', _history.takeLast(100).toList());
  }
}

class _ExecResult {
  final String stdout;
  final String stderr;
  _ExecResult({required this.stdout, required this.stderr});
}

extension TakeLast<T> on List<T> {
  List<T> takeLast(int n) => length <= n ? this : sublist(length - n);
}
