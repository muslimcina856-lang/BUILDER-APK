import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../services/music_provider.dart';
import '../theme/term_theme.dart';

class MusicPlayerWidget extends StatelessWidget {
  const MusicPlayerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    if (!music.isVisible) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        color: TermTheme.bg800,
        border: Border(
          top: BorderSide(color: TermTheme.violet.withOpacity(0.4), width: 1),
        ),
      ),
      child: music.isMinimized
          ? _MiniBar(music: music)
          : _FullPlayer(music: music),
    );
  }
}

// ─── Mini bar (collapsed state) ─────────────────────────────────────────────

class _MiniBar extends StatelessWidget {
  final MusicProvider music;
  const _MiniBar({required this.music});

  @override
  Widget build(BuildContext context) {
    final track = music.currentTrack;
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Icon(Icons.music_note_rounded, size: 14, color: TermTheme.violet),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              track?.displayName ?? 'No track',
              style: GoogleFonts.jetBrainsMono(
                  fontSize: 12, color: TermTheme.textSub),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          _ControlBtn(
            icon: music.isPlaying
                ? Icons.pause_rounded
                : Icons.play_arrow_rounded,
            color: TermTheme.violet,
            onTap: music.togglePlayPause,
          ),
          _ControlBtn(
            icon: Icons.skip_next_rounded,
            onTap: music.playNext,
          ),
          const SizedBox(width: 4),
          _ControlBtn(
            icon: Icons.expand_less_rounded,
            onTap: music.toggleMinimize,
            tooltip: 'Perluas player',
          ),
          _ControlBtn(
            icon: Icons.close_rounded,
            onTap: music.toggleVisibility,
            tooltip: 'Tutup',
          ),
        ],
      ),
    );
  }
}

// ─── Full player ─────────────────────────────────────────────────────────────

class _FullPlayer extends StatelessWidget {
  final MusicProvider music;
  const _FullPlayer({required this.music});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _PlayerHeader(music: music),
        _NowPlaying(music: music),
        _ProgressBar(music: music),
        _Controls(music: music),
        _VolumeBar(music: music),
        if (music.playlist.isNotEmpty) _Playlist(music: music),
      ],
    );
  }
}

// ─── Header ──────────────────────────────────────────────────────────────────

class _PlayerHeader extends StatelessWidget {
  final MusicProvider music;
  const _PlayerHeader({required this.music});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: TermTheme.bg900,
        border: Border(
          bottom: BorderSide(color: TermTheme.bg600),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(
              color: TermTheme.violetDim,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                  color: TermTheme.violet.withOpacity(0.4), width: 1),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.music_note_rounded,
                    size: 11, color: TermTheme.violet),
                const SizedBox(width: 4),
                Text(
                  'MUSIC PLAYER',
                  style: GoogleFonts.jetBrainsMono(
                      fontSize: 10,
                      color: TermTheme.violet,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5),
                ),
              ],
            ),
          ),
          const Spacer(),
          Text(
            '${music.playlist.length} lagu',
            style: GoogleFonts.jetBrainsMono(
                fontSize: 10, color: TermTheme.textMuted),
          ),
          const SizedBox(width: 8),
          _ControlBtn(
            icon: Icons.playlist_add_rounded,
            color: TermTheme.violet,
            tooltip: 'Tambah MP3',
            onTap: music.pickAndAddFiles,
          ),
          _ControlBtn(
            icon: Icons.remove_rounded,
            tooltip: 'Minimalkan',
            onTap: music.toggleMinimize,
          ),
          _ControlBtn(
            icon: Icons.close_rounded,
            tooltip: 'Tutup',
            onTap: music.toggleVisibility,
          ),
        ],
      ),
    );
  }
}

// ─── Now Playing display ──────────────────────────────────────────────────────

class _NowPlaying extends StatelessWidget {
  final MusicProvider music;
  const _NowPlaying({required this.music});

  @override
  Widget build(BuildContext context) {
    final track = music.currentTrack;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
      child: Row(
        children: [
          // Album art placeholder
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: TermTheme.violetDim,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: TermTheme.violet.withOpacity(0.3), width: 1),
            ),
            child: Center(
              child: StreamBuilder<PlayerState>(
                stream: music.playerStateStream,
                builder: (ctx, snap) {
                  final playing = snap.data?.playing ?? false;
                  return AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Icon(
                      playing
                          ? Icons.graphic_eq_rounded
                          : Icons.music_note_rounded,
                      key: ValueKey(playing),
                      size: 22,
                      color: TermTheme.violet,
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  track?.displayName ?? '— tidak ada lagu —',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 13,
                    color:
                        track != null ? TermTheme.textPrime : TermTheme.textMuted,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  track != null
                      ? 'Track ${music.currentIndex + 1} / ${music.playlist.length}'
                      : 'Unggah file MP3 untuk mulai',
                  style: GoogleFonts.jetBrainsMono(
                      fontSize: 10, color: TermTheme.textMuted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Progress bar ─────────────────────────────────────────────────────────────

class _ProgressBar extends StatelessWidget {
  final MusicProvider music;
  const _ProgressBar({required this.music});

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: StreamBuilder<Duration>(
        stream: music.positionStream,
        builder: (ctx, posSnap) {
          return StreamBuilder<Duration?>(
            stream: music.durationStream,
            builder: (ctx2, durSnap) {
              final pos = posSnap.data ?? Duration.zero;
              final dur = durSnap.data ?? Duration.zero;
              final progress =
                  dur.inMilliseconds > 0 ? pos.inMilliseconds / dur.inMilliseconds : 0.0;

              return Column(
                children: [
                  SliderTheme(
                    data: SliderThemeData(
                      trackHeight: 3,
                      thumbRadius: 6,
                      activeTrackColor: TermTheme.violet,
                      inactiveTrackColor: TermTheme.bg600,
                      thumbColor: TermTheme.violet,
                      overlayColor: TermTheme.violetDim,
                    ),
                    child: Slider(
                      value: progress.clamp(0.0, 1.0),
                      onChanged: (v) {
                        if (dur.inMilliseconds > 0) {
                          music.seek(
                              Duration(milliseconds: (v * dur.inMilliseconds).round()));
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_fmt(pos),
                            style: GoogleFonts.jetBrainsMono(
                                fontSize: 10, color: TermTheme.textMuted)),
                        Text(_fmt(dur),
                            style: GoogleFonts.jetBrainsMono(
                                fontSize: 10, color: TermTheme.textMuted)),
                      ],
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

// ─── Playback controls ────────────────────────────────────────────────────────

class _Controls extends StatelessWidget {
  final MusicProvider music;
  const _Controls({required this.music});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: StreamBuilder<PlayerState>(
        stream: music.playerStateStream,
        builder: (ctx, snap) {
          final playing = snap.data?.playing ?? false;
          final loading =
              snap.data?.processingState == ProcessingState.loading ||
                  snap.data?.processingState == ProcessingState.buffering;

          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _ControlBtn(
                icon: Icons.skip_previous_rounded,
                size: 26,
                onTap: music.playPrev,
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: music.togglePlayPause,
                child: Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: TermTheme.violetDim,
                    border: Border.all(
                        color: TermTheme.violet.withOpacity(0.6), width: 1.5),
                  ),
                  child: loading
                      ? Padding(
                          padding: const EdgeInsets.all(14),
                          child: CircularProgressIndicator(
                              color: TermTheme.violet, strokeWidth: 2),
                        )
                      : Icon(
                          playing
                              ? Icons.pause_rounded
                              : Icons.play_arrow_rounded,
                          color: TermTheme.violet,
                          size: 24,
                        ),
                ),
              ),
              const SizedBox(width: 8),
              _ControlBtn(
                icon: Icons.skip_next_rounded,
                size: 26,
                onTap: music.playNext,
              ),
            ],
          );
        },
      ),
    );
  }
}

// ─── Volume bar ───────────────────────────────────────────────────────────────

class _VolumeBar extends StatelessWidget {
  final MusicProvider music;
  const _VolumeBar({required this.music});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 2, 14, 8),
      child: StreamBuilder<double>(
        stream: music.volumeStream,
        builder: (ctx, snap) {
          final vol = snap.data ?? 1.0;
          return Row(
            children: [
              Icon(
                vol == 0
                    ? Icons.volume_off_rounded
                    : vol < 0.5
                        ? Icons.volume_down_rounded
                        : Icons.volume_up_rounded,
                size: 14,
                color: TermTheme.textMuted,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 2,
                    thumbRadius: 5,
                    activeTrackColor: TermTheme.textSub,
                    inactiveTrackColor: TermTheme.bg600,
                    thumbColor: TermTheme.textSub,
                    overlayColor: TermTheme.bg500,
                  ),
                  child: Slider(
                    value: vol,
                    onChanged: music.setVolume,
                  ),
                ),
              ),
              Text(
                '${(vol * 100).round()}%',
                style: GoogleFonts.jetBrainsMono(
                    fontSize: 10, color: TermTheme.textMuted),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ─── Playlist ────────────────────────────────────────────────────────────────

class _Playlist extends StatelessWidget {
  final MusicProvider music;
  const _Playlist({required this.music});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxHeight: 160),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: TermTheme.bg600),
        ),
      ),
      child: ListView.builder(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 4),
        itemCount: music.playlist.length,
        itemBuilder: (ctx, i) {
          final track = music.playlist[i];
          final isActive = i == music.currentIndex;
          return GestureDetector(
            onTap: () => music.playAt(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: isActive ? TermTheme.violetDim : Colors.transparent,
              ),
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                    child: isActive
                        ? Icon(Icons.graphic_eq_rounded,
                            size: 13, color: TermTheme.violet)
                        : Text(
                            '${i + 1}',
                            style: GoogleFonts.jetBrainsMono(
                                fontSize: 10, color: TermTheme.textMuted),
                          ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      track.displayName,
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 12,
                        color: isActive
                            ? TermTheme.violet
                            : TermTheme.textSub,
                        fontWeight: isActive
                            ? FontWeight.w600
                            : FontWeight.normal,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => music.removeTrack(i),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: Icon(Icons.close_rounded,
                          size: 13, color: TermTheme.textMuted),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─── Shared control button ───────────────────────────────────────────────────

class _ControlBtn extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final double size;
  final String? tooltip;
  final VoidCallback onTap;

  const _ControlBtn({
    required this.icon,
    required this.onTap,
    this.color,
    this.size = 20,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    final btn = GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        alignment: Alignment.center,
        child: Icon(icon, size: size, color: color ?? TermTheme.textMuted),
      ),
    );
    if (tooltip != null) return Tooltip(message: tooltip!, child: btn);
    return btn;
  }
}
