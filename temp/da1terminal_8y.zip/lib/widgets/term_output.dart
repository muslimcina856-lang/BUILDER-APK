import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/term_model.dart';
import '../theme/term_theme.dart';

class TermOutputView extends StatefulWidget {
  final List<TermLine> lines;
  final bool isExecuting;

  const TermOutputView({
    super.key,
    required this.lines,
    required this.isExecuting,
  });

  @override
  State<TermOutputView> createState() => _TermOutputViewState();
}

class _TermOutputViewState extends State<TermOutputView> {
  final ScrollController _scroll = ScrollController();

  @override
  void didUpdateWidget(covariant TermOutputView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.lines.length != oldWidget.lines.length) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }
  }

  void _scrollToBottom() {
    if (_scroll.hasClients) {
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: widget.lines.length + (widget.isExecuting ? 1 : 0),
      itemBuilder: (ctx, i) {
        if (i == widget.lines.length && widget.isExecuting) {
          return _RunningIndicator();
        }
        return _TermLineWidget(line: widget.lines[i]);
      },
    );
  }
}

class _TermLineWidget extends StatelessWidget {
  final TermLine line;
  const _TermLineWidget({required this.line});

  Color _getColor() {
    switch (line.type) {
      case LineType.input:   return TermTheme.green;
      case LineType.output:  return TermTheme.cyan;
      case LineType.error:   return TermTheme.red;
      case LineType.info:    return TermTheme.textSub;
      case LineType.system:  return TermTheme.violet;
      case LineType.result:  return TermTheme.amber;
    }
  }

  Color? _getBg() {
    switch (line.type) {
      case LineType.error:  return TermTheme.redDim;
      case LineType.system: return TermTheme.violetDim;
      default:              return null;
    }
  }

  IconData? _getIcon() {
    switch (line.type) {
      case LineType.input:  return null; // handled in text prefix (>>>)
      case LineType.error:  return Icons.error_outline_rounded;
      case LineType.system: return Icons.info_outline_rounded;
      case LineType.info:   return null;
      default:              return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _getColor();
    final bg = _getBg();
    final icon = _getIcon();

    return Container(
      margin: const EdgeInsets.only(bottom: 2),
      padding: bg != null
          ? const EdgeInsets.symmetric(horizontal: 10, vertical: 4)
          : const EdgeInsets.symmetric(vertical: 1),
      decoration: bg != null
          ? BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(4),
            )
          : null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (icon != null) ...[
            Padding(
              padding: const EdgeInsets.only(top: 2, right: 6),
              child: Icon(icon, size: 13, color: color),
            ),
          ],
          Expanded(
            child: SelectableText(
              line.text,
              style: GoogleFonts.jetBrainsMono(
                fontSize: 13,
                color: color,
                height: 1.55,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RunningIndicator extends StatefulWidget {
  @override
  State<_RunningIndicator> createState() => _RunningIndicatorState();
}

class _RunningIndicatorState extends State<_RunningIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _anim = Tween(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          FadeTransition(
            opacity: _anim,
            child: Row(
              children: [
                Container(
                  width: 8, height: 8,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: TermTheme.green,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: TermTheme.greenDim,
                        blurRadius: 8,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
                Text(
                  'menjalankan...',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 12,
                    color: TermTheme.green.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
