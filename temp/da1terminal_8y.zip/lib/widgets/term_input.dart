import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/python_suggest.dart';
import '../theme/term_theme.dart';

class TermInputBar extends StatefulWidget {
  final bool isExecuting;
  final void Function(String code) onSubmit;
  final String? Function() onHistoryPrev;
  final String? Function() onHistoryNext;

  const TermInputBar({
    super.key,
    required this.isExecuting,
    required this.onSubmit,
    required this.onHistoryPrev,
    required this.onHistoryNext,
  });

  @override
  State<TermInputBar> createState() => _TermInputBarState();
}

class _TermInputBarState extends State<TermInputBar> {
  final TextEditingController _ctrl = TextEditingController();
  final FocusNode _focus = FocusNode();
  List<String> _suggestions = [];
  bool _multiline = false;
  final List<String> _multiLines = [];

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    final text = _ctrl.text;
    final token = PythonSuggest.getCurrentToken(text);
    final newSuggestions = PythonSuggest.getSuggestions(token);
    if (!_listEquals(newSuggestions, _suggestions)) {
      setState(() => _suggestions = newSuggestions);
    }
  }

  bool _listEquals(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  void _applySuggestion(String suggestion) {
    final text = _ctrl.text;
    final token = PythonSuggest.getCurrentToken(text);
    final newText = text.substring(0, text.length - token.length) + suggestion;
    _ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
    setState(() => _suggestions = []);
    _focus.requestFocus();
  }

  void _handleAutoPair(String char) {
    final pair = PythonSuggest.getAutoPair(char);
    if (pair == null) return;
    final sel = _ctrl.selection;
    final text = _ctrl.text;
    final before = text.substring(0, sel.start);
    final after = text.substring(sel.end);
    final newText = '$before$char$pair$after';
    _ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: sel.start + 1),
    );
  }

  void _handleSubmit() {
    final code = _ctrl.text.trim();
    if (code.isEmpty) return;

    if (_multiline) {
      if (code.isEmpty) {
        // Execute multiline block
        final fullCode = _multiLines.join('\n');
        _multiLines.clear();
        setState(() => _multiline = false);
        _ctrl.clear();
        widget.onSubmit(fullCode);
      } else {
        _multiLines.add(code);
        final indent = PythonSuggest.getAutoIndent(code);
        _ctrl.value = TextEditingValue(
          text: indent,
          selection: TextSelection.collapsed(offset: indent.length),
        );
      }
    } else {
      // Check if line needs multiline mode (ends with ':')
      if (PythonSuggest.shouldAutoIndent(code)) {
        _multiLines.clear();
        _multiLines.add(code);
        setState(() => _multiline = true);
        final indent = PythonSuggest.getAutoIndent(code);
        _ctrl.value = TextEditingValue(
          text: indent,
          selection: TextSelection.collapsed(offset: indent.length),
        );
      } else {
        _ctrl.clear();
        setState(() {
          _suggestions = [];
          _multiline = false;
        });
        widget.onSubmit(code);
      }
    }
  }

  KeyEventResult _handleKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;

    // History navigation
    if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      final prev = widget.onHistoryPrev();
      if (prev != null) {
        _ctrl.value = TextEditingValue(
          text: prev,
          selection: TextSelection.collapsed(offset: prev.length),
        );
      }
      return KeyEventResult.handled;
    }
    if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      final next = widget.onHistoryNext();
      if (next != null) {
        _ctrl.value = TextEditingValue(
          text: next,
          selection: TextSelection.collapsed(offset: next.length),
        );
      }
      return KeyEventResult.handled;
    }

    // Tab → apply first suggestion
    if (event.logicalKey == LogicalKeyboardKey.tab && _suggestions.isNotEmpty) {
      _applySuggestion(_suggestions.first);
      return KeyEventResult.handled;
    }

    // Ctrl+L → clear
    if (event.logicalKey == LogicalKeyboardKey.keyL &&
        HardwareKeyboard.instance.isControlPressed) {
      // Handled by parent via onSubmit('cls')
      widget.onSubmit('cls');
      return KeyEventResult.handled;
    }

    // Escape → cancel multiline
    if (event.logicalKey == LogicalKeyboardKey.escape) {
      setState(() {
        _multiline = false;
        _multiLines.clear();
        _suggestions = [];
      });
      _ctrl.clear();
      return KeyEventResult.handled;
    }

    // Auto-pair for (, [, {, ", '
    final char = event.character;
    if (char != null && '([{"\''.contains(char)) {
      // Let the default insert happen, then add closing pair
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // Check if auto-pair should apply (no existing closing char)
        _handleAutoPair(char);
      });
    }

    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Suggestions bar
        if (_suggestions.isNotEmpty) _SuggestionsBar(
          suggestions: _suggestions,
          onTap: _applySuggestion,
        ),

        // Multiline indicator
        if (_multiline) _MultilineIndicator(lineCount: _multiLines.length),

        // Input row
        Container(
          decoration: BoxDecoration(
            color: TermTheme.bg800,
            border: Border(
              top: BorderSide(color: TermTheme.bg600, width: 1),
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Prompt marker
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text(
                  _multiline ? '...' : '>>>',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 13,
                    color: _multiline ? TermTheme.amber : TermTheme.green,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              // Input field
              Expanded(
                child: Focus(
                  onKeyEvent: _handleKeyEvent,
                  child: TextField(
                    controller: _ctrl,
                    focusNode: _focus,
                    enabled: !widget.isExecuting,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 14,
                      color: TermTheme.green,
                      height: 1.4,
                    ),
                    cursorColor: TermTheme.green,
                    cursorWidth: 8,
                    cursorHeight: 14,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      hintText: null,
                    ),
                    onSubmitted: (_) => _handleSubmit(),
                  ),
                ),
              ),

              // Run button
              GestureDetector(
                onTap: widget.isExecuting ? null : _handleSubmit,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: widget.isExecuting
                        ? TermTheme.bg700
                        : TermTheme.greenDim,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: widget.isExecuting
                          ? TermTheme.bg500
                          : TermTheme.green.withOpacity(0.5),
                      width: 1,
                    ),
                  ),
                  child: widget.isExecuting
                      ? SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            color: TermTheme.green,
                            strokeWidth: 1.5,
                          ),
                        )
                      : Icon(
                          Icons.play_arrow_rounded,
                          size: 18,
                          color: TermTheme.green,
                        ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SuggestionsBar extends StatelessWidget {
  final List<String> suggestions;
  final void Function(String) onTap;

  const _SuggestionsBar({
    required this.suggestions,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 38,
      decoration: BoxDecoration(
        color: TermTheme.bg700,
        border: Border(
          top: BorderSide(color: TermTheme.bg500, width: 1),
        ),
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        itemCount: suggestions.length,
        itemBuilder: (ctx, i) => _SuggestionChip(
          text: suggestions[i],
          isFirst: i == 0,
          onTap: () => onTap(suggestions[i]),
        ),
      ),
    );
  }
}

class _SuggestionChip extends StatelessWidget {
  final String text;
  final bool isFirst;
  final VoidCallback onTap;

  const _SuggestionChip({
    required this.text,
    required this.isFirst,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: isFirst ? TermTheme.greenGlow : TermTheme.bg600,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(
            color: isFirst
                ? TermTheme.green.withOpacity(0.4)
                : TermTheme.bg500,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isFirst)
              Padding(
                padding: const EdgeInsets.only(right: 4),
                child: Text(
                  'Tab',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 9,
                    color: TermTheme.green.withOpacity(0.7),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            Text(
              text,
              style: GoogleFonts.jetBrainsMono(
                fontSize: 12,
                color: isFirst ? TermTheme.green : TermTheme.textSub,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MultilineIndicator extends StatelessWidget {
  final int lineCount;
  const _MultilineIndicator({required this.lineCount});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: TermTheme.amber.withOpacity(0.08),
        border: Border(top: BorderSide(color: TermTheme.amber.withOpacity(0.3))),
      ),
      child: Row(
        children: [
          Icon(Icons.code_rounded, size: 12, color: TermTheme.amber),
          const SizedBox(width: 6),
          Text(
            'Mode blok — $lineCount baris. Enter kosong untuk jalankan, Esc untuk batal.',
            style: GoogleFonts.jetBrainsMono(
              fontSize: 11,
              color: TermTheme.amber.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }
}
