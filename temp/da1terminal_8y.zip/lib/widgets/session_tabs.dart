import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/term_model.dart';
import '../theme/term_theme.dart';

class SessionTabs extends StatelessWidget {
  final List<TermSession> sessions;
  final int activeIndex;
  final void Function(int) onSwitch;
  final void Function(int) onClose;
  final VoidCallback onNew;

  const SessionTabs({
    super.key,
    required this.sessions,
    required this.activeIndex,
    required this.onSwitch,
    required this.onClose,
    required this.onNew,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      color: TermTheme.bg900,
      child: Row(
        children: [
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: sessions.length,
              itemBuilder: (ctx, i) => _Tab(
                session: sessions[i],
                isActive: i == activeIndex,
                canClose: sessions.length > 1,
                onTap: () => onSwitch(i),
                onClose: () => onClose(i),
              ),
            ),
          ),
          // New session button
          GestureDetector(
            onTap: onNew,
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              child: Icon(
                Icons.add_rounded,
                size: 18,
                color: TermTheme.textMuted,
              ),
            ),
          ),
          Container(width: 1, height: 24, color: TermTheme.bg600),
        ],
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final TermSession session;
  final bool isActive;
  final bool canClose;
  final VoidCallback onTap;
  final VoidCallback onClose;

  const _Tab({
    required this.session,
    required this.isActive,
    required this.canClose,
    required this.onTap,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: isActive ? TermTheme.bg800 : Colors.transparent,
          border: Border(
            bottom: BorderSide(
              color: isActive ? TermTheme.green : Colors.transparent,
              width: 2,
            ),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.terminal_rounded,
              size: 13,
              color: isActive ? TermTheme.green : TermTheme.textMuted,
            ),
            const SizedBox(width: 6),
            Text(
              session.name,
              style: GoogleFonts.jetBrainsMono(
                fontSize: 12,
                color: isActive ? TermTheme.textPrime : TermTheme.textMuted,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
            if (canClose) ...[
              const SizedBox(width: 6),
              GestureDetector(
                onTap: onClose,
                child: Icon(
                  Icons.close_rounded,
                  size: 12,
                  color: TermTheme.textMuted,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
