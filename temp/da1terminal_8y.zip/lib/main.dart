import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/terminal_provider.dart';
import 'services/music_provider.dart';
import 'theme/term_theme.dart';
import 'screens/terminal_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: TermTheme.bg900,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const Da1TerminalApp());
}

class Da1TerminalApp extends StatelessWidget {
  const Da1TerminalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => TerminalProvider()),
        ChangeNotifierProvider(create: (_) => MusicProvider()),
      ],
      child: MaterialApp(
        title: 'Da1chi Terminal',
        debugShowCheckedModeBanner: false,
        theme: TermTheme.dark,
        home: const TerminalScreen(),
      ),
    );
  }
}
