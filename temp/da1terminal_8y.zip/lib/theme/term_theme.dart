import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TermTheme {
  // ── Core Palette ───────────────────────────────────────────
  static const Color bg950    = Color(0xFF060608);  // pure void black
  static const Color bg900    = Color(0xFF0D0E12);  // terminal bg
  static const Color bg800    = Color(0xFF13151C);  // panel bg
  static const Color bg700    = Color(0xFF1C1F29);  // card / input bg
  static const Color bg600    = Color(0xFF252836);  // border default
  static const Color bg500    = Color(0xFF333649);  // border hover

  static const Color green    = Color(0xFF00FF87);  // terminal green
  static const Color greenDim = Color(0x4000FF87);
  static const Color greenGlow= Color(0x2000FF87);
  static const Color cyan     = Color(0xFF00D4FF);  // output cyan
  static const Color cyanDim  = Color(0x3300D4FF);
  static const Color violet   = Color(0xFF8B5CF6);  // accent violet
  static const Color violetDim= Color(0x338B5CF6);
  static const Color amber    = Color(0xFFFFB800);  // warning / number
  static const Color red      = Color(0xFFFF3B5C);  // error
  static const Color redDim   = Color(0x33FF3B5C);

  static const Color textPrime= Color(0xFFE2E8F0);
  static const Color textSub  = Color(0xFF8892A4);
  static const Color textMuted= Color(0xFF4A5568);
  static const Color white    = Color(0xFFFFFFFF);

  // ── Text Styles ────────────────────────────────────────────
  static TextStyle get monoLg => GoogleFonts.jetBrainsMono(
    fontSize: 14, color: textPrime, height: 1.6,
  );
  static TextStyle get monoMd => GoogleFonts.jetBrainsMono(
    fontSize: 13, color: textPrime, height: 1.5,
  );
  static TextStyle get monoSm => GoogleFonts.jetBrainsMono(
    fontSize: 12, color: textMuted, height: 1.5,
  );
  static TextStyle get monoInput => GoogleFonts.jetBrainsMono(
    fontSize: 14, color: green, height: 1.4,
  );

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg950,
    colorScheme: const ColorScheme.dark(
      surface: bg800,
      primary: green,
      secondary: cyan,
      tertiary: violet,
      onPrimary: bg950,
      onSurface: textPrime,
      error: red,
    ),
    textTheme: GoogleFonts.spaceGroteskTextTheme(
      ThemeData.dark().textTheme,
    ).copyWith(
      bodyLarge: const TextStyle(color: textPrime),
      bodyMedium: const TextStyle(color: textSub),
      bodySmall: const TextStyle(color: textMuted),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: bg900,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    dividerTheme: const DividerThemeData(color: bg600, thickness: 1),
  );
}
