import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_colors.dart';
import '../../models/sender_model.dart';
import '../../providers/report_provider.dart';
import '../../providers/sender_provider.dart';
import '../../providers/settings_provider.dart';
import 'target_picker_sheet.dart';

/// Halaman Kirim Laporan - PALING PENTING (section 10.E).
/// Segmented Email|Telegram, dropdown sender, pilih target, subject+body,
/// lampiran, tombol kirim.
class SendReportScreen extends ConsumerStatefulWidget {
  const SendReportScreen({super.key});

  @override
  ConsumerState<SendReportScreen> createState() => _SendReportScreenState();
}

class _SendReportScreenState extends ConsumerState<SendReportScreen> {
  String _senderType = 'email';
  int? _selectedSenderId;
  String? _selectedSenderLabel;

  Set<int> _selectedTargetIds = {};
  bool _selectAllTargets = false;

  final _subjectCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();

  File? _attachmentFile;
  bool _sending = false;

  @override
  void dispose() {
    _subjectCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  String get _subjectPrefix => ref.read(settingsControllerProvider).subjectPrefix;

  Future<void> _pickSender() async {
    final isEmail = _senderType == 'email';

    final senders = isEmail
        ? ref.read(senderEmailListProvider).value ?? []
        : ref.read(senderTelegramListProvider).value ?? [];

    if (senders.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Belum ada sender ${isEmail ? 'email' : 'telegram'}. Tambah dulu di menu Sender.')),
      );
      return;
    }

    final searchCtrl = TextEditingController();

    final selected = await showModalBottomSheet<dynamic>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheetState) {
          final filtered = senders.where((s) {
            final q = searchCtrl.text.toLowerCase();
            if (q.isEmpty) return true;
            final label = isEmail
                ? (s as SenderEmailModel).email.toLowerCase()
                : (s as SenderTelegramModel).phoneNumber.toLowerCase();
            return label.contains(q);
          }).toList();

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('Pilih Sender ${isEmail ? "Email" : "Telegram"}', style: Theme.of(ctx).textTheme.headlineSmall),
                const SizedBox(height: 12),
                TextField(
                  controller: searchCtrl,
                  decoration: const InputDecoration(hintText: 'Cari sender...', prefixIcon: Icon(Icons.search)),
                  onChanged: (_) => setSheetState(() {}),
                ),
                const SizedBox(height: 12),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 320),
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: filtered.length,
                    itemBuilder: (c, i) {
                      final s = filtered[i];
                      final label = isEmail ? (s as SenderEmailModel).email : (s as SenderTelegramModel).phoneNumber;
                      return ListTile(
                        title: Text(label),
                        onTap: () => Navigator.pop(ctx, s),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        });
      },
    );

    if (selected != null) {
      setState(() {
        if (isEmail) {
          _selectedSenderId = (selected as SenderEmailModel).id;
          _selectedSenderLabel = selected.email;
        } else {
          _selectedSenderId = (selected as SenderTelegramModel).id;
          _selectedSenderLabel = selected.phoneNumber;
        }
      });
    }
  }

  Future<void> _pickTargets() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => TargetPickerSheet(
        isEmail: _senderType == 'email',
        initialSelectedIds: _selectedTargetIds,
        initialSelectAll: _selectAllTargets,
      ),
    );

    if (result != null) {
      setState(() {
        _selectAllTargets = result['selectAll'];
        _selectedTargetIds = result['ids'];
      });
    }
  }

  Future<void> _pickAttachment() async {
    final result = await FilePicker.platform.pickFiles();
    if (result?.files.single.path != null) {
      setState(() => _attachmentFile = File(result!.files.single.path!));
    }
  }

  /// Konversi plain text menjadi HTML sederhana (paragraf per baris).
  String _bodyToHtml() {
    final text = _bodyCtrl.text.trim();
    if (text.isEmpty) return '';
    final lines = text.split('\n').where((l) => l.trim().isNotEmpty);
    return lines.map((l) => '<p>$l</p>').join();
  }

  Future<void> _send() async {
    if (_selectedSenderId == null) {
      _showError('Pilih sender terlebih dahulu.');
      return;
    }
    if (!_selectAllTargets && _selectedTargetIds.isEmpty) {
      _showError('Pilih minimal satu target.');
      return;
    }
    if (_senderType == 'email' && _subjectCtrl.text.trim().isEmpty) {
      _showError('Subject laporan tidak boleh kosong.');
      return;
    }

    setState(() => _sending = true);

    try {
      String? attachmentBase64;
      if (_attachmentFile != null) {
        final bytes = await _attachmentFile!.readAsBytes();
        attachmentBase64 = base64Encode(bytes);
      }

      final result = await ref.read(reportServiceProvider).sendReport(
            senderType: _senderType,
            senderId: _selectedSenderId!,
            targetIds: _selectedTargetIds.toList(),
            selectAll: _selectAllTargets,
            subject: _senderType == 'email' ? _subjectCtrl.text.trim() : null,
            body: _bodyToHtml(),
            attachmentBase64: attachmentBase64,
          );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Laporan #${result.reportId} sedang diproses (${result.totalTargets} target).')),
        );
        Navigator.pop(context);
      }
    } catch (_) {
      _showError('Gagal mengirim laporan. Periksa koneksi atau data anda.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final prefix = _subjectPrefix;

    return Scaffold(
      appBar: AppBar(title: const Text('Kirim Laporan')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'email', label: Text('Email'), icon: Icon(Icons.email_outlined)),
                ButtonSegment(value: 'telegram', label: Text('Telegram'), icon: Icon(Icons.send_outlined)),
              ],
              selected: {_senderType},
              onSelectionChanged: (s) => setState(() {
                _senderType = s.first;
                _selectedSenderId = null;
                _selectedSenderLabel = null;
                _selectedTargetIds = {};
                _selectAllTargets = false;
              }),
            ),
            const SizedBox(height: 16),

            Text('Sender', style: Theme.of(context).textTheme.labelSmall),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: _pickSender,
              icon: const Icon(Icons.outgoing_mail),
              label: Text(_selectedSenderLabel ?? 'Pilih sender ${_senderType == "email" ? "email" : "telegram"}'),
            ),
            const SizedBox(height: 16),

            Text('Target', style: Theme.of(context).textTheme.labelSmall),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: _pickTargets,
              icon: const Icon(Icons.groups_outlined),
              label: Text(
                _selectAllTargets
                    ? 'Semua target dipilih'
                    : _selectedTargetIds.isEmpty
                        ? 'Pilih target'
                        : '${_selectedTargetIds.length} target dipilih',
              ),
            ),
            const SizedBox(height: 16),

            if (_senderType == 'email') ...[
              Text('Subject', style: Theme.of(context).textTheme.labelSmall),
              const SizedBox(height: 6),
              if (prefix.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    'Prefix otomatis: "$prefix" (akan ditambahkan oleh sistem)',
                    style: const TextStyle(fontSize: 11, color: AppColors.goldPremiumAlt),
                  ),
                ),
              TextField(
                controller: _subjectCtrl,
                decoration: const InputDecoration(hintText: 'Judul inti laporan, contoh: Laporan Bulanan Maret'),
              ),
              const SizedBox(height: 16),
            ],

            Text('Isi Laporan', style: Theme.of(context).textTheme.labelSmall),
            const SizedBox(height: 6),
            TextField(
              controller: _bodyCtrl,
              maxLines: 8,
              minLines: 5,
              decoration: InputDecoration(
                hintText: 'Tulis isi laporan di sini...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                contentPadding: const EdgeInsets.all(12),
              ),
            ),
            const SizedBox(height: 16),

            Text('Lampiran', style: Theme.of(context).textTheme.labelSmall),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: _pickAttachment,
              icon: const Icon(Icons.attach_file),
              label: Text(_attachmentFile != null ? _attachmentFile!.path.split('/').last : 'Pilih Berkas'),
            ),
            const SizedBox(height: 28),

            ElevatedButton(
              onPressed: _sending ? null : _send,
              child: _sending
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Kirim Laporan'),
            ),
          ],
        ),
      ),
    );
  }
}
