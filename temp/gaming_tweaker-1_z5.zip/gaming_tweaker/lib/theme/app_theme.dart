import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palet warna terinspirasi tema dark premium Samsung.com:
/// hitam pekat sebagai kanvas, dengan aksen biru elektrik terang
/// dan sedikit sentuhan ungu untuk elemen performa/gaming.
class AppColors {
  static const Color background = Color(0xFF0B0B0D);
  static const Color surface = Color(0xFF16171B);
  static const Color surfaceElevated = Color(0xFF1E1F24);
  static const Color primary = Color(0xFF4F8CFF); // biru elektrik khas Samsung
  static const Color primaryDim = Color(0xFF2D5CD6);
  static const Color accent = Color(0xFF7C5CFF); // ungu aksen gaming
  static const Color success = Color(0xFF34D399);
  static const Color warning = Color(0xFFFBBF24);
  static const Color danger = Color(0xFFFF5470);
  static const Color textPrimary = Color(0xFFF5F6F8);
  static const Color textSecondary = Color(0xFF9A9CA5);
  static const Color divider = Color(0xFF2A2B31);
}

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primary,
        secondary: AppColors.accent,
        surface: AppColors.surface,
        error: AppColors.danger,
      ),
      textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).apply(
        bodyColor: AppColors.textPrimary,
        displayColor: AppColors.textPrimary,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.inter(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
          letterSpacing: -0.3,
        ),
      ),
      dividerColor: AppColors.divider,
    );
  }
}
