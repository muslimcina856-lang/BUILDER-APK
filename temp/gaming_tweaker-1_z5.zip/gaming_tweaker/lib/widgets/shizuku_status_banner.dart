import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/shizuku_service.dart';
import '../theme/app_theme.dart';

class ShizukuStatusBanner extends StatelessWidget {
  final ShizukuStatus status;
  final VoidCallback onRequestPermission;
  final VoidCallback onRefreshStatus;

  const ShizukuStatusBanner({
    super.key,
    required this.status,
    required this.onRequestPermission,
    required this.onRefreshStatus,
  });

  Future<void> _openShizukuGuide() async {
    final uri = Uri.parse('https://shizuku.rikka.app/guide/setup/');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (status == ShizukuStatus.ready) {
      return _buildBanner(
        color: AppColors.success,
        icon: Icons.check_circle_rounded,
        title: 'Shizuku Aktif',
        subtitle: 'Semua fitur siap digunakan.',
        trailing: null,
      );
    }

    if (status == ShizukuStatus.permissionDenied) {
      return _buildBanner(
        color: AppColors.warning,
        icon: Icons.warning_rounded,
        title: 'Izin Belum Diberikan',
        subtitle: 'Shizuku aktif, tapi aplikasi ini belum diizinkan.',
        trailing: TextButton(
          onPressed: onRequestPermission,
          child: const Text('Izinkan'),
        ),
      );
    }

    return _buildBanner(
      color: AppColors.danger,
      icon: Icons.error_rounded,
      title: 'Shizuku Belum Aktif',
      subtitle: 'Aktifkan Shizuku terlebih dahulu agar tweak bisa dipakai.',
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextButton(
            onPressed: _openShizukuGuide,
            child: const Text('Panduan'),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, size: 20),
            onPressed: onRefreshStatus,
            tooltip: 'Cek ulang status',
          ),
        ],
      ),
    );
  }

  Widget _buildBanner({
    required Color color,
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget? trailing,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          if (trailing != null) trailing,
        ],
      ),
    );
  }
}
