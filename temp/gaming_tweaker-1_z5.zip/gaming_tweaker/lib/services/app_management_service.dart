import 'shizuku_service.dart';

class InstalledApp {
  final String packageName;
  bool selected;

  InstalledApp({required this.packageName, this.selected = false});
}

/// Mengelola daftar aplikasi terpasang serta aksi force-stop dan
/// pembersihan cache massal via Shizuku.
class AppManagementService {
  final ShizukuService _shizuku = ShizukuService();

  /// Paket sistem inti yang tidak boleh diutak-atik supaya perangkat
  /// tidak jadi tidak stabil.
  static const Set<String> _protectedPrefixes = {
    'com.android.systemui',
    'com.android.settings',
    'android',
    'com.google.android.gms',
    'com.google.android.gsf',
    'com.android.phone',
    'com.android.shell',
    'rikka.shizuku',
    'moe.shizuku',
  };

  bool _isProtected(String packageName) {
    return _protectedPrefixes.any((prefix) => packageName == prefix || packageName.startsWith('$prefix.'));
  }

  /// Mengambil daftar aplikasi pihak ketiga (non-sistem) yang terpasang,
  /// supaya user hanya melihat aplikasi yang relevan untuk di-force-stop/cache-clear.
  Future<List<InstalledApp>> getThirdPartyApps() async {
    final output = await _shizuku.runCommand('pm list packages -3');
    final lines = output.split('\n');
    final apps = <InstalledApp>[];

    for (final line in lines) {
      final trimmed = line.trim();
      if (!trimmed.startsWith('package:')) continue;
      final packageName = trimmed.replaceFirst('package:', '').trim();
      if (packageName.isEmpty || _isProtected(packageName)) continue;
      apps.add(InstalledApp(packageName: packageName));
    }

    apps.sort((a, b) => a.packageName.compareTo(b.packageName));
    return apps;
  }

  /// Force-stop satu aplikasi berdasarkan nama paketnya.
  Future<void> forceStopApp(String packageName) async {
    if (_isProtected(packageName)) return;
    await _shizuku.runCommand('am force-stop $packageName');
  }

  /// Force-stop banyak aplikasi sekaligus. Mengembalikan jumlah yang berhasil.
  Future<int> forceStopApps(List<String> packageNames) async {
    var successCount = 0;
    for (final pkg in packageNames) {
      try {
        await forceStopApp(pkg);
        successCount++;
      } catch (_) {
        // Lanjut ke app berikutnya meski satu gagal.
      }
    }
    return successCount;
  }

  /// Membersihkan cache satu aplikasi (bukan data, hanya cache).
  Future<void> clearAppCache(String packageName) async {
    if (_isProtected(packageName)) return;
    await _shizuku.runCommand('pm clear --cache-only $packageName');
  }

  /// Membersihkan cache banyak aplikasi sekaligus. Mengembalikan jumlah yang berhasil.
  Future<int> clearAppsCache(List<String> packageNames) async {
    var successCount = 0;
    for (final pkg in packageNames) {
      try {
        await clearAppCache(pkg);
        successCount++;
      } catch (_) {
        // Lanjut ke app berikutnya meski satu gagal.
      }
    }
    return successCount;
  }
}
