import 'shizuku_service.dart';

class RefreshRateOption {
  final String label;
  final double value;
  const RefreshRateOption(this.label, this.value);
}

/// Mengelola refresh rate layar via Shizuku (setara perintah ADB
/// `settings put system peak_refresh_rate` / `min_refresh_rate`).
class RefreshRateService {
  final ShizukuService _shizuku = ShizukuService();

  static const List<RefreshRateOption> commonOptions = [
    RefreshRateOption('60 Hz', 60.0),
    RefreshRateOption('90 Hz', 90.0),
    RefreshRateOption('120 Hz', 120.0),
    RefreshRateOption('144 Hz', 144.0),
  ];

  /// Memaksa refresh rate ke nilai tertentu (min = peak, supaya terkunci
  /// dan tidak diturunkan otomatis oleh sistem saat idle).
  Future<void> setRefreshRate(double hz) async {
    await _shizuku.runCommands([
      'settings put system peak_refresh_rate $hz',
      'settings put system min_refresh_rate $hz',
    ]);
  }

  /// Mengembalikan ke perilaku default sistem (adaptive).
  Future<void> resetToDefault() async {
    await _shizuku.runCommands([
      'settings delete system peak_refresh_rate',
      'settings delete system min_refresh_rate',
    ]);
  }

  /// Membaca nilai peak_refresh_rate yang sedang aktif, jika ada.
  Future<double?> getCurrentPeakRate() async {
    final output = await _shizuku.runCommand('settings get system peak_refresh_rate');
    final trimmed = output.trim();
    if (trimmed.isEmpty || trimmed == 'null') return null;
    return double.tryParse(trimmed);
  }
}
