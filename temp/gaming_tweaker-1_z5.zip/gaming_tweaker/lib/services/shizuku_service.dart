import 'package:flutter/services.dart';
import 'package:shizuku_api/shizuku_api.dart';

enum ShizukuStatus {
  /// Shizuku belum terpasang atau service belum jalan sama sekali.
  notRunning,

  /// Shizuku jalan tapi user belum kasih izin ke aplikasi ini.
  permissionDenied,

  /// Shizuku jalan dan izin sudah diberikan — siap dipakai.
  ready,
}

class ShizukuService {
  static final ShizukuService _instance = ShizukuService._internal();
  factory ShizukuService() => _instance;
  ShizukuService._internal();

  final ShizukuApi _api = ShizukuApi();

  /// Mengecek status Shizuku saat ini tanpa memicu popup permintaan izin.
  Future<ShizukuStatus> checkStatus() async {
    try {
      final hasPermission = await _api.checkPermission() ?? false;
      if (hasPermission) return ShizukuStatus.ready;
      return ShizukuStatus.permissionDenied;
    } on PlatformException {
      return ShizukuStatus.notRunning;
    } catch (_) {
      return ShizukuStatus.notRunning;
    }
  }

  /// Memicu popup permintaan izin Shizuku ke pengguna.
  Future<bool> requestPermission() async {
    try {
      return await _api.requestPermission() ?? false;
    } on PlatformException {
      return false;
    } catch (_) {
      return false;
    }
  }

  /// Menjalankan satu shell command lewat Shizuku dan mengembalikan output-nya.
  /// Melempar [ShizukuCommandException] jika command gagal dieksekusi.
  Future<String> runCommand(String command) async {
    try {
      final result = await _api.runCommand(command);
      return result?.toString() ?? '';
    } on PlatformException catch (e) {
      throw ShizukuCommandException(
        'Gagal menjalankan perintah: ${e.message ?? command}',
      );
    } catch (e) {
      throw ShizukuCommandException('Terjadi kesalahan tak terduga saat menjalankan perintah.');
    }
  }

  /// Menjalankan beberapa command secara berurutan. Berhenti di command
  /// pertama yang gagal dan melempar exception dengan info command mana yang gagal.
  Future<void> runCommands(List<String> commands) async {
    for (final cmd in commands) {
      await runCommand(cmd);
    }
  }
}

class ShizukuCommandException implements Exception {
  final String message;
  ShizukuCommandException(this.message);

  @override
  String toString() => message;
}
