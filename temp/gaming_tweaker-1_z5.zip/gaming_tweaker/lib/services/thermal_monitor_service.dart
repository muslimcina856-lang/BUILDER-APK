import 'shizuku_service.dart';

class ThermalSnapshot {
  final double? batteryTempCelsius;
  final double cpuUsagePercent;
  final DateTime timestamp;

  ThermalSnapshot({
    required this.batteryTempCelsius,
    required this.cpuUsagePercent,
    required this.timestamp,
  });
}

/// Membaca informasi suhu & beban CPU perangkat via Shizuku,
/// menggunakan `dumpsys battery` (suhu, dalam persepuluh derajat Celsius)
/// dan `dumpsys cpuinfo` (ringkasan beban CPU).
class ThermalMonitorService {
  final ShizukuService _shizuku = ShizukuService();

  Future<double?> _readBatteryTemperature() async {
    final output = await _shizuku.runCommand('dumpsys battery');
    // Contoh baris output: "  temperature: 290" -> 29.0 derajat Celsius
    final match = RegExp(r'temperature:\s*(-?\d+)').firstMatch(output);
    if (match == null) return null;
    final raw = int.tryParse(match.group(1) ?? '');
    if (raw == null) return null;
    return raw / 10.0;
  }

  Future<double> _readCpuUsage() async {
    // Baris pertama dumpsys cpuinfo biasanya berisi ringkasan total,
    // contoh: "58% TOTAL: 30% user + 20% kernel + ..."
    final output = await _shizuku.runCommand('dumpsys cpuinfo');
    final match = RegExp(r'(\d+(?:\.\d+)?)%\s*TOTAL').firstMatch(output);
    if (match == null) return 0.0;
    return double.tryParse(match.group(1) ?? '0') ?? 0.0;
  }

  /// Mengambil satu snapshot data thermal & CPU saat ini.
  Future<ThermalSnapshot> getSnapshot() async {
    final temp = await _readBatteryTemperature();
    final cpu = await _readCpuUsage();
    return ThermalSnapshot(
      batteryTempCelsius: temp,
      cpuUsagePercent: cpu,
      timestamp: DateTime.now(),
    );
  }
}
