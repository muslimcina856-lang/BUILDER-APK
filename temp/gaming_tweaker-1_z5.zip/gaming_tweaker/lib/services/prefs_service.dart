import 'package:shared_preferences/shared_preferences.dart';

class PrefsService {
  static const _keyLastRefreshRate = 'last_refresh_rate';
  static const _keyLastPerfMode = 'last_perf_mode';

  Future<void> saveLastRefreshRate(double hz) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyLastRefreshRate, hz);
  }

  Future<double?> getLastRefreshRate() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyLastRefreshRate);
  }

  Future<void> saveLastPerfMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyLastPerfMode, mode);
  }

  Future<String?> getLastPerfMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyLastPerfMode);
  }
}
