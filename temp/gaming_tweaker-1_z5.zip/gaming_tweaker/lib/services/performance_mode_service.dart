import 'shizuku_service.dart';

enum PerformanceMode {
  /// Mode hemat baterai — batasi performa demi daya tahan.
  batterySaver,

  /// Mode normal/default sistem.
  balanced,

  /// Fixed performance mode — kunci clock CPU/GPU di level tinggi
  /// untuk performa maksimal & konsisten (cocok untuk gaming berat).
  performance,
}

/// Mengelola mode performa perangkat via Shizuku, menggunakan command
/// resmi ADPF `cmd power set-fixed-performance-mode-enabled` untuk mode
/// performa, dan `settings put global low_power` untuk battery saver.
class PerformanceModeService {
  final ShizukuService _shizuku = ShizukuService();

  Future<void> applyMode(PerformanceMode mode) async {
    switch (mode) {
      case PerformanceMode.performance:
        await _shizuku.runCommands([
          'settings put global low_power 0',
          'cmd power set-fixed-performance-mode-enabled true',
        ]);
        break;
      case PerformanceMode.balanced:
        await _shizuku.runCommands([
          'cmd power set-fixed-performance-mode-enabled false',
          'settings put global low_power 0',
        ]);
        break;
      case PerformanceMode.batterySaver:
        await _shizuku.runCommands([
          'cmd power set-fixed-performance-mode-enabled false',
          'settings put global low_power 1',
        ]);
        break;
    }
  }

  /// Membaca status low_power (battery saver) saat ini.
  Future<bool> isBatterySaverOn() async {
    final output = await _shizuku.runCommand('settings get global low_power');
    return output.trim() == '1';
  }
}
