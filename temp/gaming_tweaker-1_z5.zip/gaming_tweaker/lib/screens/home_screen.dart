import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import '../services/shizuku_service.dart';
import '../services/refresh_rate_service.dart';
import '../services/performance_mode_service.dart';
import '../services/thermal_monitor_service.dart';
import '../services/app_management_service.dart';
import '../services/prefs_service.dart';
import '../theme/app_theme.dart';
import '../widgets/shizuku_status_banner.dart';
import '../widgets/feature_card.dart';
import 'app_selection_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ShizukuService _shizukuService = ShizukuService();
  final RefreshRateService _refreshRateService = RefreshRateService();
  final PerformanceModeService _perfModeService = PerformanceModeService();
  final ThermalMonitorService _thermalService = ThermalMonitorService();
  final AppManagementService _appManagementService = AppManagementService();
  final PrefsService _prefsService = PrefsService();

  ShizukuStatus _status = ShizukuStatus.notRunning;
  bool _checkingStatus = true;

  double? _selectedRefreshRate;
  PerformanceMode? _selectedPerfMode;

  ThermalSnapshot? _thermalSnapshot;
  bool _monitorEnabled = false;

  bool _isBusy = false;

  @override
  void initState() {
    super.initState();
    _loadInitialState();
  }

  Future<void> _loadInitialState() async {
    setState(() => _checkingStatus = true);
    final status = await _shizukuService.checkStatus();
    final lastRate = await _prefsService.getLastRefreshRate();
    final lastMode = await _prefsService.getLastPerfMode();

    setState(() {
      _status = status;
      _selectedRefreshRate = lastRate;
      _selectedPerfMode = _perfModeFromString(lastMode);
      _checkingStatus = false;
    });
  }

  PerformanceMode? _perfModeFromString(String? value) {
    switch (value) {
      case 'performance':
        return PerformanceMode.performance;
      case 'balanced':
        return PerformanceMode.balanced;
      case 'batterySaver':
        return PerformanceMode.batterySaver;
      default:
        return null;
    }
  }

  Future<void> _refreshStatus() async {
    final status = await _shizukuService.checkStatus();
    setState(() => _status = status);
  }

  Future<void> _requestPermission() async {
    final granted = await _shizukuService.requestPermission();
    setState(() => _status = granted ? ShizukuStatus.ready : ShizukuStatus.permissionDenied);
  }

  bool get _isReady => _status == ShizukuStatus.ready;

  void _showSnack(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? AppColors.danger : AppColors.success,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _guardedAction(Future<void> Function() action) async {
    if (!_isReady) {
      _showSnack('Shizuku belum siap. Aktifkan dulu izinnya.', isError: true);
      return;
    }
    setState(() => _isBusy = true);
    try {
      await action();
    } catch (e) {
      _showSnack(e.toString(), isError: true);
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  Future<void> _applyRefreshRate(double hz) async {
    await _guardedAction(() async {
      await _refreshRateService.setRefreshRate(hz);
      await _prefsService.saveLastRefreshRate(hz);
      setState(() => _selectedRefreshRate = hz);
      _showSnack('Refresh rate diset ke ${hz.toStringAsFixed(0)} Hz');
    });
  }

  Future<void> _applyPerfMode(PerformanceMode mode) async {
    await _guardedAction(() async {
      await _perfModeService.applyMode(mode);
      await _prefsService.saveLastPerfMode(mode.name);
      setState(() => _selectedPerfMode = mode);
      _showSnack('Mode performa diubah ke ${_perfModeLabel(mode)}');
    });
  }

  String _perfModeLabel(PerformanceMode mode) {
    switch (mode) {
      case PerformanceMode.performance:
        return 'Performa Maksimal';
      case PerformanceMode.balanced:
        return 'Seimbang';
      case PerformanceMode.batterySaver:
        return 'Hemat Baterai';
    }
  }

  Future<void> _toggleMonitor() async {
    if (!_isReady) {
      _showSnack('Shizuku belum siap. Aktifkan dulu izinnya.', isError: true);
      return;
    }
    setState(() => _monitorEnabled = !_monitorEnabled);
    if (_monitorEnabled) {
      await _refreshThermalSnapshot();
    }
  }

  Future<void> _refreshThermalSnapshot() async {
    if (!_monitorEnabled) return;
    try {
      final snapshot = await _thermalService.getSnapshot();
      if (mounted) setState(() => _thermalSnapshot = snapshot);
    } catch (_) {
      // Diamkan error monitor supaya tidak spam snackbar tiap refresh.
    }
  }

  Future<void> _openForceStopScreen() async {
    if (!_isReady) {
      _showSnack('Shizuku belum siap. Aktifkan dulu izinnya.', isError: true);
      return;
    }
    if (!mounted) return;
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(
        builder: (_) => AppSelectionScreen(
          mode: AppSelectionMode.forceStop,
          appManagementService: _appManagementService,
        ),
      ),
    );
    if (result != null && result > 0) {
      _showSnack('$result aplikasi berhasil dihentikan');
    }
  }

  Future<void> _openClearCacheScreen() async {
    if (!_isReady) {
      _showSnack('Shizuku belum siap. Aktifkan dulu izinnya.', isError: true);
      return;
    }
    if (!mounted) return;
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(
        builder: (_) => AppSelectionScreen(
          mode: AppSelectionMode.clearCache,
          appManagementService: _appManagementService,
        ),
      ),
    );
    if (result != null && result > 0) {
      _showSnack('Cache $result aplikasi berhasil dibersihkan');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gaming Tweaker'),
        actions: [
          if (_isBusy)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: _checkingStatus
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _refreshStatus,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      FadeInDown(
                        duration: const Duration(milliseconds: 400),
                        child: ShizukuStatusBanner(
                          status: _status,
                          onRequestPermission: _requestPermission,
                          onRefreshStatus: _refreshStatus,
                        ),
                      ),
                      const SizedBox(height: 24),
                      FadeInUp(
                        duration: const Duration(milliseconds: 400),
                        child: _buildRefreshRateCard(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 450),
                        child: _buildPerfModeCard(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 500),
                        child: _buildThermalCard(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 550),
                        child: _buildForceStopCard(),
                      ),
                      const SizedBox(height: 16),
                      FadeInUp(
                        duration: const Duration(milliseconds: 600),
                        child: _buildClearCacheCard(),
                      ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _buildRefreshRateCard() {
    return FeatureCard(
      icon: Icons.speed_rounded,
      iconColor: AppColors.primary,
      title: 'Refresh Rate Switcher',
      subtitle: 'Paksa layar ke refresh rate tertinggi untuk gaming.',
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: RefreshRateService.commonOptions.map((option) {
          final isSelected = _selectedRefreshRate == option.value;
          return ChoiceChip(
            label: Text('${option.value.toStringAsFixed(0)} Hz'),
            selected: isSelected,
            onSelected: (_) => _applyRefreshRate(option.value),
            selectedColor: AppColors.primary,
            backgroundColor: AppColors.surfaceElevated,
            labelStyle: TextStyle(
              color: isSelected ? Colors.white : AppColors.textSecondary,
              fontWeight: FontWeight.w600,
            ),
            side: BorderSide(color: isSelected ? AppColors.primary : AppColors.divider),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPerfModeCard() {
    return FeatureCard(
      icon: Icons.bolt_rounded,
      iconColor: AppColors.accent,
      title: 'Performance Mode',
      subtitle: 'Ganti mode performa perangkat secara instan.',
      child: Column(
        children: PerformanceMode.values.map((mode) {
          final isSelected = _selectedPerfMode == mode;
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _applyPerfMode(mode),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.accent.withOpacity(0.15) : AppColors.surfaceElevated,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: isSelected ? AppColors.accent : AppColors.divider),
                ),
                child: Row(
                  children: [
                    Icon(
                      isSelected ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
                      color: isSelected ? AppColors.accent : AppColors.textSecondary,
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _perfModeLabel(mode),
                      style: TextStyle(
                        color: isSelected ? AppColors.textPrimary : AppColors.textSecondary,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildThermalCard() {
    return FeatureCard(
      icon: Icons.thermostat_rounded,
      iconColor: AppColors.warning,
      title: 'CPU & Thermal Monitor',
      subtitle: 'Pantau suhu baterai & beban CPU secara real-time.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: _buildStatBox(
                  label: 'Suhu Baterai',
                  value: _thermalSnapshot?.batteryTempCelsius != null
                      ? '${_thermalSnapshot!.batteryTempCelsius!.toStringAsFixed(1)}°C'
                      : '—',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildStatBox(
                  label: 'Beban CPU',
                  value: _thermalSnapshot != null
                      ? '${_thermalSnapshot!.cpuUsagePercent.toStringAsFixed(0)}%'
                      : '—',
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _toggleMonitor,
              icon: Icon(_monitorEnabled ? Icons.stop_circle_rounded : Icons.play_circle_rounded),
              label: Text(_monitorEnabled ? 'Hentikan Monitor' : 'Mulai Monitor'),
              style: OutlinedButton.styleFrom(
                foregroundColor: _monitorEnabled ? AppColors.danger : AppColors.warning,
                side: BorderSide(color: _monitorEnabled ? AppColors.danger : AppColors.warning),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          if (_monitorEnabled) ...[
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: _refreshThermalSnapshot,
              icon: const Icon(Icons.refresh_rounded, size: 16),
              label: const Text('Refresh data'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatBox({required String label, required String value}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _buildForceStopCard() {
    return FeatureCard(
      icon: Icons.memory_rounded,
      iconColor: AppColors.danger,
      title: 'Force-Stop Aplikasi',
      subtitle: 'Bebasin RAM dengan menghentikan aplikasi latar belakang.',
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _openForceStopScreen,
          icon: const Icon(Icons.close_rounded),
          label: const Text('Pilih Aplikasi untuk Dihentikan'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.danger,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
    );
  }

  Widget _buildClearCacheCard() {
    return FeatureCard(
      icon: Icons.cleaning_services_rounded,
      iconColor: AppColors.success,
      title: 'Bersihkan Cache Massal',
      subtitle: 'Hapus cache banyak aplikasi sekaligus untuk lega penyimpanan.',
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _openClearCacheScreen,
          icon: const Icon(Icons.delete_sweep_rounded),
          label: const Text('Pilih Aplikasi untuk Dibersihkan'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.success,
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
    );
  }
}
