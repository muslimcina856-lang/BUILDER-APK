import 'package:flutter/material.dart';
import '../services/app_management_service.dart';
import '../theme/app_theme.dart';

enum AppSelectionMode { forceStop, clearCache }

class AppSelectionScreen extends StatefulWidget {
  final AppSelectionMode mode;
  final AppManagementService appManagementService;

  const AppSelectionScreen({
    super.key,
    required this.mode,
    required this.appManagementService,
  });

  @override
  State<AppSelectionScreen> createState() => _AppSelectionScreenState();
}

class _AppSelectionScreenState extends State<AppSelectionScreen> {
  List<InstalledApp> _apps = [];
  bool _loading = true;
  bool _processing = false;
  String? _error;

  bool get _isForceStop => widget.mode == AppSelectionMode.forceStop;

  @override
  void initState() {
    super.initState();
    _loadApps();
  }

  Future<void> _loadApps() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final apps = await widget.appManagementService.getThirdPartyApps();
      setState(() {
        _apps = apps;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Gagal memuat daftar aplikasi: $e';
        _loading = false;
      });
    }
  }

  void _toggleAll(bool value) {
    setState(() {
      for (final app in _apps) {
        app.selected = value;
      }
    });
  }

  int get _selectedCount => _apps.where((a) => a.selected).length;

  Future<void> _runAction() async {
    final selectedPackages = _apps.where((a) => a.selected).map((a) => a.packageName).toList();
    if (selectedPackages.isEmpty) return;

    setState(() => _processing = true);
    try {
      final count = _isForceStop
          ? await widget.appManagementService.forceStopApps(selectedPackages)
          : await widget.appManagementService.clearAppsCache(selectedPackages);

      if (mounted) Navigator.pop(context, count);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Terjadi kesalahan: $e'), backgroundColor: AppColors.danger),
        );
        setState(() => _processing = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final actionColor = _isForceStop ? AppColors.danger : AppColors.success;
    final actionLabel = _isForceStop ? 'Hentikan' : 'Bersihkan Cache';

    return Scaffold(
      appBar: AppBar(
        title: Text(_isForceStop ? 'Force-Stop Aplikasi' : 'Bersihkan Cache'),
        actions: [
          if (!_loading && _apps.isNotEmpty)
            TextButton(
              onPressed: () => _toggleAll(_selectedCount != _apps.length),
              child: Text(
                _selectedCount == _apps.length ? 'Batalkan Semua' : 'Pilih Semua',
                style: const TextStyle(fontSize: 13),
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? _buildErrorState()
                : _apps.isEmpty
                    ? _buildEmptyState()
                    : _buildAppList(),
      ),
      bottomNavigationBar: (!_loading && _apps.isNotEmpty)
          ? SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: (_selectedCount == 0 || _processing) ? null : _runAction,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: actionColor,
                      foregroundColor: _isForceStop ? Colors.white : Colors.black,
                      disabledBackgroundColor: AppColors.surfaceElevated,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: _processing
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : Text(
                            _selectedCount > 0 ? '$actionLabel ($_selectedCount)' : actionLabel,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, color: AppColors.danger, size: 48),
            const SizedBox(height: 12),
            Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _loadApps, child: const Text('Coba Lagi')),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.apps_rounded, size: 48, color: Colors.grey[700]),
          const SizedBox(height: 12),
          const Text('Tidak ada aplikasi ditemukan', style: TextStyle(color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  Widget _buildAppList() {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _apps.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final app = _apps[index];
        return Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.divider),
          ),
          child: CheckboxListTile(
            value: app.selected,
            onChanged: (value) => setState(() => app.selected = value ?? false),
            title: Text(
              app.packageName,
              style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
            ),
            activeColor: AppColors.primary,
            controlAffinity: ListTileControlAffinity.leading,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        );
      },
    );
  }
}
