package com.example.gaming_tweaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
