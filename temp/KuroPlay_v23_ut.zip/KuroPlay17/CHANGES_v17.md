# 2.7.1 - transisi nav diganti dari fade (opasitas) menjadi geser (slide) antar-tab dan layar detail.

# 2.7.2
- Daftar/hasil/posisi scroll dipertahankan saat membuka detail lalu kembali: Katalog Anime, Cari, Beranda (termasuk baris geser), Manga, Library (core/state/RetainedState.kt). Dibersihkan saat logout.
- Beranda memuat ulang data hanya bila sudah lebih dari 5 menit.
- Genre "Hentai" ditambahkan (ada konfirmasi 18+ sekali per sesi).

## v19 (2.7.3)
- Toggle "Konten dewasa (18+)" di tab Tentang (default mati, semua user bisa).
- Kursor input search putih.
- Thumbnail riwayat: cover diambil otomatis dari detail anime (riwayat lama diisi ulang).
- Episode terakhir ditonton: gaya outline (bukan blok putih).
- Transisi geser 220 ms.

## v20 (2.7.4)
- Pindah tab: konten layar berat (Beranda/Cari/Manga/Library) baru dibuat setelah animasi geser selesai, supaya geseran tidak ngestuck di tengah.

## v21 (2.7.5)
- Beranda: riwayat di-cache sebagai nilai awal, tidak lagi melompat/"bekas scroll" saat riwayat ter-load.
- Geser tab 320 ms.

## v22 (2.7.6)
- Geser tab kembali 220 ms (cepat semua).

## v23 (2.8.0)
- Tentang: baris Key (ikon kunci + jumlah/∞), pil biru "Premium X,XX Hari" / "Beli Premium" -> buka halaman Premium.
- Halaman baru KuroPlay Premium (kartu akun, paket, fitur, QRIS).
- Centang biru untuk akun Premium/Owner.
