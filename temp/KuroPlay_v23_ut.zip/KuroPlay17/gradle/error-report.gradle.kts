// Menampilkan error kompilasi (baris "e: ...") di AKHIR log build,
// supaya tidak terpotong oleh bot build yang hanya mengirim ~80 baris terakhir.
import org.gradle.api.logging.StandardOutputListener

val kuroErrors: MutableSet<String> = java.util.Collections.synchronizedSet(LinkedHashSet<String>())

val kuroListener = StandardOutputListener { msg ->
    msg.toString().lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
        if (line.startsWith("e: ") || line.contains("error:", ignoreCase = true)) {
            kuroErrors.add(line)
        }
    }
}

allprojects {
    tasks.configureEach {
        logging.addStandardErrorListener(kuroListener)
    }
}

gradle.buildFinished {
    if (failure != null && kuroErrors.isNotEmpty()) {
        println("")
        println("===== KURO: DAFTAR ERROR (${kuroErrors.size}) =====")
        synchronized(kuroErrors) {
            kuroErrors.take(30).forEach { line ->
                println(line.replace(Regex("file:///\\S*/com/kano/playjv/"), "").take(230))
            }
        }
        println("===== AKHIR DAFTAR ERROR =====")
    }
}
