// Top-level build file for KuroPlay. Keep plugins centralized for AndroidIDE.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.google.devtools.ksp) apply false
}

// Cetak daftar error kompilasi di akhir log (bot build hanya mengirim ekor log)
apply(from = "gradle/error-report.gradle.kts")

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
