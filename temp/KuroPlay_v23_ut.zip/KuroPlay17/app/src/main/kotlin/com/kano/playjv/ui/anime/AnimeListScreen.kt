package com.kano.playjv.ui.anime

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.LazyGridState
import com.kano.playjv.core.state.rememberRetained
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.home.AnimeCard
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.collect
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.launch

private val FALLBACK_ANIME_GENRES = listOf(
    "Live Action", "Movie", "Tokusatsu", "Action", "Adventure", "Comedy", "Demons",
    "Drama", "Ecchi", "Fantasy", "Game", "Harem", "Horror", "Kids", "Magic",
    "Martial Arts", "Mecha", "Military", "Music", "Mystery", "Parody", "Police",
    "Psychological", "Romance", "Samurai", "School", "Sci-Fi", "Shoujo", "Shounen",
    "Slice Of Life", "Sports", "Supernatural", "Super Power", "Thriller", "Vampire", "Hentai"
)

/** Katalog anime/donghua. Pencarian teks berada di AnimeSearchScreen yang terpisah. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeListScreen(
    repository: KuroRepository,
    onNavigateToDetail: (String) -> Unit,
    initialMediaType: String = "anime"
) {
    // State dipertahankan (RetainedState) agar kembali dari halaman detail tidak mengulang dari atas.
    val p = "anime_list:" + if (initialMediaType.equals("donghua", true)) "donghua" else "anime"
    var selectedMediaType by rememberRetained("$p.type") {
        mutableStateOf(if (initialMediaType.equals("donghua", true)) "donghua" else "anime")
    }
    var selectedTab by rememberRetained("$p.tab") { mutableStateOf("ongoing") }
    var availableGenres by rememberRetained("$p.genres") { mutableStateOf(FALLBACK_ANIME_GENRES) }
    var selectedGenre by rememberRetained("$p.genre") { mutableStateOf<String?>(null) }
    var showGenreSheet by remember { mutableStateOf(false) }
    val adultEnabled by com.kano.playjv.core.state.AdultContentGate.enabledFlow.collectAsState()

    var animeList by rememberRetained("$p.list") { mutableStateOf<List<AnimeItem>>(emptyList()) }
    var currentPage by rememberRetained("$p.page") { mutableIntStateOf(1) }
    var hasNext by rememberRetained("$p.hasNext") { mutableStateOf(true) }
    var loadedKey by rememberRetained("$p.loadedKey") { mutableStateOf("") }
    var isLoadingInitial by remember { mutableStateOf(animeList.isEmpty()) }
    var isCatalogProcessing by remember { mutableStateOf(false) }
    var isLoadingMore by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var reloadKey by rememberRetained("$p.reload") { mutableIntStateOf(0) }

    val gridState = rememberRetained("$p.grid") { LazyGridState() }
    val scope = rememberCoroutineScope()
    var loadMoreJob by remember { mutableStateOf<Job?>(null) }
    var requestGeneration by remember { mutableIntStateOf(0) }

    // Mengikuti pager referensi: satu request aktif, cursor maju setelah sukses,
    // dan item baru digabung berdasarkan URL agar tidak ada duplikasi.
    fun loadNextPage() {
        if (isLoadingInitial || isLoadingMore || loadMoreJob?.isActive == true || !hasNext || animeList.isEmpty()) return
        val generation = requestGeneration
        val requestedType = selectedMediaType
        val requestedTab = selectedTab
        val requestedGenre = selectedGenre
        val pageToLoad = currentPage + 1
        isLoadingMore = true
        errorMessage = null
        loadMoreJob = scope.launch {
            try {
                val result = repository.getAnimePage(
                    mode = requestedTab,
                    genre = requestedGenre,
                    page = pageToLoad,
                    mediaType = requestedType
                )
                if (generation == requestGeneration &&
                    selectedMediaType == requestedType && selectedTab == requestedTab && selectedGenre == requestedGenre
                ) {
                    result.onSuccess { page ->
                        val knownUrls = animeList.mapTo(HashSet()) { it.url }
                        val additions = page.items.filter { it.url.isNotBlank() && knownUrls.add(it.url) }
                        animeList = animeList + additions
                        currentPage = pageToLoad
                        hasNext = page.hasNext && page.items.isNotEmpty()
                    }.onFailure {
                        errorMessage = it.message ?: "Gagal memuat halaman berikutnya"
                    }
                }
            } finally {
                if (generation == requestGeneration) isLoadingMore = false
            }
        }
    }

    LaunchedEffect(Unit) {
        repository.getAnimeGenres().onSuccess { genres ->
            if (genres.isNotEmpty()) availableGenres = genres
        }
    }

    // Ganti jenis media/status/genre selalu memulai katalog dari awal.
    LaunchedEffect(selectedMediaType, selectedTab, selectedGenre, reloadKey) {
        val stateKey = "$selectedMediaType|$selectedTab|$selectedGenre|$reloadKey"
        if (loadedKey == stateKey && animeList.isNotEmpty()) {
            // Kembali dari halaman lain: daftar & posisi scroll masih utuh, jangan muat ulang.
            isLoadingInitial = false
            isCatalogProcessing = false
            return@LaunchedEffect
        }
        requestGeneration += 1
        val generation = requestGeneration
        loadMoreJob?.cancel()
        isLoadingMore = false
        animeList = emptyList()
        currentPage = 1
        hasNext = false
        errorMessage = null
        isLoadingInitial = true
        isCatalogProcessing = false
        // requestScrollToItem tidak menunggu layout. scrollToItem (suspend) menunggu grid
        // pertama kali di-layout; grid belum tampil selama loading, sehingga efek ini menggantung
        // selamanya dan data tidak pernah dimuat.
        gridState.requestScrollToItem(0)

        val requestedType = selectedMediaType
        val requestedTab = selectedTab
        val requestedGenre = selectedGenre
        try {
            repository.observeAnimePage(
                mode = requestedTab,
                genre = requestedGenre,
                mediaType = requestedType
            ).collect { page ->
                if (generation == requestGeneration && selectedMediaType == requestedType &&
                    selectedTab == requestedTab && selectedGenre == requestedGenre
                ) {
                    // Flow boleh mengirim preview lalu hasil final halaman pertama. Karena
                    // next-page baru aktif setelah katalog final, halaman 2 tidak akan tertimpa.
                    if (currentPage <= 1) animeList = page.items
                    currentPage = 1
                    hasNext = page.hasNext
                    isCatalogProcessing = !page.isComplete
                    if (page.isComplete && animeList.isNotEmpty()) loadedKey = stateKey
                    if (animeList.isNotEmpty()) isLoadingInitial = false
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            if (generation == requestGeneration && selectedMediaType == requestedType &&
                selectedTab == requestedTab && selectedGenre == requestedGenre
            ) {
                errorMessage = error.message ?: "Gagal memuat katalog"
            }
        } finally {
            if (generation == requestGeneration) {
                isLoadingInitial = false
                isCatalogProcessing = false
            }
        }
    }

    // Infinite scroll: 1 halaman = 10 judul. Halaman berikutnya dimuat saat scroll mentok di kartu terakhir.
    LaunchedEffect(gridState, animeList.size, hasNext, isLoadingInitial, isLoadingMore, errorMessage) {
        snapshotFlow {
            gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        }.distinctUntilChanged().collect { lastVisible ->
            if (animeList.isNotEmpty() && hasNext && errorMessage == null && !isLoadingInitial && !isLoadingMore &&
                lastVisible >= (animeList.size - 1).coerceAtLeast(0)
            ) {
                loadNextPage()
            }
        }
    }

    val genreSelected = selectedGenre != null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(top = 10.dp, bottom = 5.dp)
        ) {
            Text(
                text = if (selectedMediaType == "donghua") "Jelajahi Donghua" else "Jelajahi Anime",
                color = KuroTextPrimary,
                fontSize = 20.sp,
                lineHeight = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Pilih jenis tontonan dan genre favoritmu.",
                color = KuroTextTertiary,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterTabChip(
                title = "Anime",
                selected = selectedMediaType == "anime",
                onClick = {
                    if (selectedMediaType != "anime") {
                        selectedMediaType = "anime"
                        selectedGenre = null
                        selectedTab = "ongoing"
                    }
                },
                modifier = Modifier.weight(1f)
            )
            FilterTabChip(
                title = "Donghua",
                selected = selectedMediaType == "donghua",
                onClick = {
                    if (selectedMediaType != "donghua") {
                        selectedMediaType = "donghua"
                        selectedGenre = null
                        selectedTab = "ongoing"
                    }
                },
                modifier = Modifier.weight(1f)
            )
        }

        // Ongoing/Populer hanya tersedia saat Semua Genre dipilih.
        if (!genreSelected) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterTabChip(
                    title = "Ongoing",
                    selected = selectedTab == "ongoing",
                    onClick = { selectedTab = "ongoing" },
                    modifier = Modifier.weight(1f)
                )
                FilterTabChip(
                    title = "Populer",
                    selected = selectedTab == "popular",
                    onClick = { selectedTab = "popular" },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        OutlinedButton(
            onClick = { showGenreSheet = true },
            shape = RoundedCornerShape(13.dp),
            border = BorderStroke(1.dp, if (genreSelected) KuroTextPrimary else KuroBorder),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = KuroSurface,
                contentColor = KuroTextPrimary
            ),
            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 0.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(top = 5.dp, bottom = 5.dp)
                .height(42.dp)
                .testTag("anime_genre_selector")
        ) {
            Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(9.dp))
            Text(
                text = selectedGenre ?: "Semua Genre",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.weight(1f))
            if (genreSelected) {
                IconButton(
                    onClick = {
                        selectedGenre = null
                        selectedTab = "ongoing"
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "Hapus genre", modifier = Modifier.size(17.dp))
                }
            } else {
                Icon(Icons.Default.ExpandMore, contentDescription = "Pilih genre", modifier = Modifier.size(20.dp))
            }
        }

        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                isLoadingInitial && animeList.isEmpty() -> KuroContainedLoadingState(
                    statusText = if (selectedMediaType == "donghua") "Memuat katalog Donghua..." else "Memuat katalog Anime...",
                    modifier = Modifier.fillMaxSize().padding(16.dp)
                )
                errorMessage != null && animeList.isEmpty() -> ErrorStateView(
                    message = errorMessage ?: "Terjadi kesalahan",
                    onRetry = {
                        reloadKey++
                    },
                    modifier = Modifier.align(Alignment.Center)
                )
                !isLoadingInitial && animeList.isEmpty() -> EmptyStateView(
                    message = if (selectedGenre != null) {
                        "Tidak ada ${if (selectedMediaType == "donghua") "Donghua" else "Anime"} bergenre $selectedGenre"
                    } else "Belum ada daftar untuk ditampilkan"
                )
                else -> LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().testTag("anime_grid_list")
                ) {
                    items(animeList, key = { it.url }) { anime ->
                        AnimeCard(
                            anime = anime,
                            onClick = { onNavigateToDetail(anime.url) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (isLoadingMore || isCatalogProcessing) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            GearProgressIndicator(
                                progress = 75,
                                statusText = if (isLoadingMore) "Memuat halaman berikutnya..." else "Menyiapkan katalog...",
                                size = 48.dp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    } else if (errorMessage != null && animeList.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            TextButton(
                                onClick = { if (hasNext) loadNextPage() else reloadKey++ },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Gagal memuat. Ketuk untuk mencoba lagi", color = KuroTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showGenreSheet) {
        ModalBottomSheet(
            onDismissRequest = { showGenreSheet = false },
            containerColor = KuroSurfaceContainerLow,
            contentColor = KuroTextPrimary,
            dragHandle = { BottomSheetDefaults.DragHandle(color = KuroTextTertiary) }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp)
            ) {
                Text(
                    text = if (selectedMediaType == "donghua") "Pilih Genre Donghua" else "Pilih Genre Anime",
                    color = KuroTextPrimary,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(14.dp))
                androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 390.dp).testTag("anime_genre_grid")
                ) {
                    item {
                        GenreChoiceChip(
                            title = "Semua",
                            selected = selectedGenre == null,
                            onClick = {
                                selectedGenre = null
                                selectedTab = "ongoing"
                                showGenreSheet = false
                            }
                        )
                    }
                    items(availableGenres.filter { adultEnabled || !com.kano.playjv.core.state.AdultContentGate.isAdultGenre(it) }) { genre ->
                        GenreChoiceChip(
                            title = genre,
                            selected = selectedGenre == genre,
                            onClick = {
                                selectedGenre = genre
                                // Genre spesifik otomatis mengunci katalog pada urutan populer.
                                selectedTab = "popular"
                                showGenreSheet = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GenreChoiceChip(title: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) KuroTextPrimary else KuroSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (selected) KuroTextPrimary else KuroBorder),
        modifier = Modifier.fillMaxWidth().height(42.dp).clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = if (selected) KuroBgPrimary else KuroTextSecondary,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (selected) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.Check, contentDescription = null, tint = KuroBgPrimary, modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
fun FilterTabChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) KuroTextPrimary else KuroSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (selected) KuroTextPrimary else KuroBorder),
        modifier = modifier.clickable(onClick = onClick).testTag("filter_tab_$title")
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 9.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                color = if (selected) KuroBgPrimary else KuroTextSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
