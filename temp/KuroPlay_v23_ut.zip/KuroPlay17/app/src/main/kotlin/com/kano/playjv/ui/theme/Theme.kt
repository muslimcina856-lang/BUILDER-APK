package com.kano.playjv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — DARK COLOR SCHEME
//  All 30 MD3 color roles fully populated from the black/gray palette.
// ─────────────────────────────────────────────────────────────────────────────
private val KuroColorScheme = darkColorScheme(
    // ── Primary ──────────────────────────────────────────────────────────────
    primary                 = KuroPrimary,
    onPrimary               = KuroOnPrimary,
    primaryContainer        = KuroPrimaryContainer,
    onPrimaryContainer      = KuroOnPrimaryContainer,

    // ── Secondary ────────────────────────────────────────────────────────────
    secondary               = KuroSecondary,
    onSecondary             = KuroOnSecondary,
    secondaryContainer      = KuroSecondaryContainer,
    onSecondaryContainer    = KuroOnSecondaryContainer,

    // ── Tertiary ─────────────────────────────────────────────────────────────
    tertiary                = KuroTertiary,
    onTertiary              = KuroOnTertiary,
    tertiaryContainer       = KuroTertiaryContainer,
    onTertiaryContainer     = KuroOnTertiaryContainer,

    // ── Error ────────────────────────────────────────────────────────────────
    error                   = KuroErrorColor,
    onError                 = KuroOnError,
    errorContainer          = KuroErrorContainer,
    onErrorContainer        = KuroOnErrorContainer,

    // ── Background ───────────────────────────────────────────────────────────
    background              = KuroBgPrimary,
    onBackground            = KuroOnBackground,

    // ── Surface ──────────────────────────────────────────────────────────────
    surface                 = KuroSurface,
    onSurface               = KuroOnSurface,
    surfaceVariant          = KuroSurfaceVariant,
    onSurfaceVariant        = KuroOnSurfaceVariant,

    // MD3 Surface tiers
    surfaceDim              = KuroSurfaceDim,
    surfaceBright           = KuroSurfaceBright,
    surfaceContainerLowest  = KuroSurfaceContainerLowest,
    surfaceContainerLow     = KuroSurfaceContainerLow,
    surfaceContainer        = KuroSurfaceContainer,
    surfaceContainerHigh    = KuroSurfaceContainerHigh,
    surfaceContainerHighest = KuroSurfaceContainerHighest,

    // ── Outline ──────────────────────────────────────────────────────────────
    outline                 = KuroOutline,
    outlineVariant          = KuroOutlineVariant,

    // ── Inverse ──────────────────────────────────────────────────────────────
    inverseSurface          = KuroInverseSurface,
    inverseOnSurface        = KuroInverseOnSurface,
    inversePrimary          = KuroInversePrimary,

    // ── Scrim ────────────────────────────────────────────────────────────────
    scrim                   = KuroScrim
)

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — SHAPE SYSTEM
//  Expressive uses larger radii than the baseline MD3 defaults.
//  ExtraSmall: 4dp  Small: 10dp  Medium: 18dp  Large: 28dp  ExtraLarge: 36dp
// ─────────────────────────────────────────────────────────────────────────────
private val KuroShapes = Shapes(
    extraSmall  = RoundedCornerShape(4.dp),
    small       = RoundedCornerShape(10.dp),
    medium      = RoundedCornerShape(18.dp),
    large       = RoundedCornerShape(28.dp),
    extraLarge  = RoundedCornerShape(36.dp)
)

@Composable
fun KuroPlayTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KuroColorScheme,
        shapes      = KuroShapes,
        typography  = Typography,
        content     = content
    )
}
