package com.kano.playjv.ui.anime

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.LazyGridState
import com.kano.playjv.core.state.rememberRetained
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.home.AnimeCard
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.launch

/** Pencarian teks mandiri. Tidak mencampur genre atau filter Ongoing/Populer di layar ini. */
@Composable
fun AnimeSearchScreen(
    repository: KuroRepository,
    onNavigateToDetail: (String) -> Unit,
    onOpenCatalog: (String) -> Unit
) {
    // State dipertahankan agar kembali dari halaman detail tidak mengulang pencarian/scroll dari atas.
    var selectedMediaType by rememberRetained("anime_search.type") { mutableStateOf("anime") }
    var query by rememberRetained("anime_search.query") { mutableStateOf("") }
    var activeQuery by rememberRetained("anime_search.activeQuery") { mutableStateOf("") }
    var results by rememberRetained("anime_search.results") { mutableStateOf<List<AnimeItem>>(emptyList()) }
    var currentPage by rememberRetained("anime_search.page") { mutableIntStateOf(1) }
    var hasNext by rememberRetained("anime_search.hasNext") { mutableStateOf(false) }
    var loadedKey by rememberRetained("anime_search.loadedKey") { mutableStateOf("") }
    var isLoadingInitial by remember { mutableStateOf(false) }
    var isCatalogProcessing by remember { mutableStateOf(false) }
    var isLoadingMore by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var retryKey by rememberRetained("anime_search.retry") { mutableIntStateOf(0) }

    val gridState = rememberRetained("anime_search.grid") { LazyGridState() }
    val scope = rememberCoroutineScope()
    var loadMoreJob by remember { mutableStateOf<Job?>(null) }
    var requestGeneration by remember { mutableIntStateOf(0) }

    fun loadNextPage() {
        if (activeQuery.isBlank() || isLoadingInitial || isLoadingMore ||
            loadMoreJob?.isActive == true || !hasNext || results.isEmpty()
        ) return
        val generation = requestGeneration
        val requestedQuery = activeQuery
        val requestedType = selectedMediaType
        val pageToLoad = currentPage + 1
        isLoadingMore = true
        errorMessage = null
        loadMoreJob = scope.launch {
            try {
                val result = repository.searchAnimePage(requestedQuery, pageToLoad, requestedType)
                if (generation == requestGeneration && activeQuery == requestedQuery && selectedMediaType == requestedType) {
                    result.onSuccess { page ->
                        val knownUrls = results.mapTo(HashSet()) { it.url }
                        val additions = page.items.filter { it.url.isNotBlank() && knownUrls.add(it.url) }
                        results = results + additions
                        currentPage = pageToLoad
                        hasNext = page.hasNext && page.items.isNotEmpty()
                    }.onFailure {
                        errorMessage = it.message ?: "Gagal memuat hasil berikutnya"
                    }
                }
            } finally {
                if (generation == requestGeneration) isLoadingMore = false
            }
        }
    }

    // Input di-debounce agar API/katalog tidak diproses setiap ketukan.
    LaunchedEffect(query, selectedMediaType, retryKey) {
        val stateKey = "${query.trim()}|$selectedMediaType|$retryKey"
        if (loadedKey == stateKey && results.isNotEmpty()) {
            // Kembali dari halaman detail: hasil & posisi scroll masih utuh, jangan cari ulang.
            activeQuery = query.trim()
            isLoadingInitial = false
            isCatalogProcessing = false
            return@LaunchedEffect
        }
        requestGeneration += 1
        val generation = requestGeneration
        loadMoreJob?.cancel()
        isLoadingMore = false
        val normalized = query.trim()
        activeQuery = ""
        results = emptyList()
        currentPage = 1
        hasNext = false
        errorMessage = null
        isLoadingInitial = normalized.isNotBlank()
        isCatalogProcessing = false
        // requestScrollToItem tidak menunggu layout. scrollToItem (suspend) menunggu grid
        // pertama kali di-layout; grid belum tampil selama loading, sehingga efek ini menggantung
        // selamanya dan data tidak pernah dimuat.
        gridState.requestScrollToItem(0)
        delay(350)
        activeQuery = normalized
        if (normalized.isBlank()) {
            isLoadingInitial = false
            return@LaunchedEffect
        }

        val requestedType = selectedMediaType
        try {
            repository.observeSearchAnimePage(normalized, requestedType).collect { page ->
                if (generation == requestGeneration && activeQuery == normalized && selectedMediaType == requestedType) {
                    // Halaman pertama (10 judul) langsung ditampilkan begitu tiba.
                    if (currentPage <= 1) results = page.items
                    currentPage = 1
                    hasNext = page.hasNext
                    isCatalogProcessing = !page.isComplete
                    if (page.isComplete && results.isNotEmpty()) loadedKey = stateKey
                    if (results.isNotEmpty()) isLoadingInitial = false
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            if (generation == requestGeneration && activeQuery == normalized && selectedMediaType == requestedType) {
                errorMessage = error.message ?: "Pencarian gagal"
            }
        } finally {
            if (generation == requestGeneration) {
                isLoadingInitial = false
                isCatalogProcessing = false
            }
        }
    }

    LaunchedEffect(gridState, results.size, hasNext, isLoadingInitial, isLoadingMore, errorMessage) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .distinctUntilChanged()
            .collect { lastVisible ->
                if (results.isNotEmpty() && hasNext && errorMessage == null && !isLoadingInitial && !isLoadingMore &&
                    lastVisible >= results.size
                ) loadNextPage()
            }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(KuroBgPrimary)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 12.dp, bottom = 8.dp)
        ) {
            Text(
                text = "Cari Anime & Donghua",
                color = KuroTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Cari judul favoritmu secara langsung.",
                color = KuroTextTertiary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterTabChip(
                title = "Anime",
                selected = selectedMediaType == "anime",
                onClick = { selectedMediaType = "anime" },
                modifier = Modifier.weight(1f)
            )
            FilterTabChip(
                title = "Donghua",
                selected = selectedMediaType == "donghua",
                onClick = { selectedMediaType = "donghua" },
                modifier = Modifier.weight(1f)
            )
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                .height(50.dp).testTag("anime_search_field"),
            color = KuroSurface,
            contentColor = KuroTextPrimary,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, KuroBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = "Cari", tint = KuroTextSecondary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = KuroTextPrimary, fontSize = 14.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(androidx.compose.ui.graphics.Color.White),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.weight(1f),
                    decorationBox = { innerTextField ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isBlank()) {
                                Text(
                                    text = if (selectedMediaType == "donghua") "Cari judul donghua..." else "Cari judul anime...",
                                    color = KuroTextTertiary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            innerTextField()
                        }
                    }
                )
                if (query.isNotBlank()) {
                    IconButton(onClick = { query = "" }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Hapus pencarian", tint = KuroTextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        if (query.isBlank()) {
            OutlinedButton(
                onClick = { onOpenCatalog(selectedMediaType) },
                shape = RoundedCornerShape(13.dp),
                border = BorderStroke(1.dp, KuroBorder),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = KuroSurface, contentColor = KuroTextPrimary),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 10.dp).height(44.dp)
            ) {
                Text("Jelajahi katalog berdasarkan genre", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
        }

        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                query.isBlank() -> Column(
                    modifier = Modifier.align(Alignment.Center).padding(horizontal = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = KuroTextTertiary, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Masukkan judul anime atau donghua untuk mulai mencari.",
                        color = KuroTextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
                isLoadingInitial && results.isEmpty() -> KuroContainedLoadingState(
                    statusText = if (selectedMediaType == "donghua") "Mencari Donghua..." else "Mencari Anime...",
                    modifier = Modifier.fillMaxSize().padding(16.dp)
                )
                errorMessage != null && results.isEmpty() -> ErrorStateView(
                    message = errorMessage ?: "Pencarian gagal",
                    onRetry = { retryKey++ },
                    modifier = Modifier.align(Alignment.Center)
                )
                !isLoadingInitial && results.isEmpty() -> EmptyStateView(
                    message = "Tidak ditemukan hasil untuk \"$activeQuery\""
                )
                else -> LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().testTag("anime_search_results")
                ) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            text = "Hasil untuk \"$activeQuery\" (${results.size}${if (hasNext) "+" else ""})",
                            color = KuroTextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                    items(results, key = { it.url }) { anime ->
                        AnimeCard(
                            anime = anime,
                            onClick = { onNavigateToDetail(anime.url) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (isLoadingMore || isCatalogProcessing) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            GearProgressIndicator(
                                progress = 75,
                                statusText = if (isLoadingMore) "Memuat halaman berikutnya..." else "Menyiapkan hasil lainnya...",
                                size = 48.dp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    } else if (errorMessage != null && results.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            TextButton(
                                onClick = { if (hasNext) loadNextPage() else retryKey++ },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Gagal memuat. Ketuk untuk mencoba lagi", color = KuroTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
