package com.kano.playjv.data.source

import com.kano.playjv.core.model.AnimeDetail
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.core.model.EpisodeStreamData
import com.kano.playjv.core.model.StreamSource
import com.kano.playjv.core.network.NetworkClient
import android.util.JsonReader
import android.util.Log
import android.util.JsonToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.transformWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.io.BufferedReader

/**
 * Client untuk API yang direkam pada HAR pencarinafkah.xyz.
 * Header sengaja mengikuti request HAR. API key dikosongkan agar pemilik proyek mengisinya sendiri.
 */
object PencariNafkahApiSource {
    const val BASE_URL = "https://pencarinafkah.xyz/vA6//api/"
    const val API_KEY = "cda11y63tfI7rwln8BLeiKTvjsD5g2Mox01RzkhQCEXSGWbqYO" // Isi sendiri dengan API key milik aplikasi.

    private const val USER_AGENT = "Dalvik/7.1.12.1.0 (com.newanimeku.animechanneldonghuasubindosubenglish U; Android ; 20175 Build/NMF260)"
    private const val ACCEPT = "application/vnd.yourapi.v1.full+json"
    private const val IMAGE_BASE = "http://elara.whatbox.ca:29318/Duljanah/"
    private const val DEFAULT_COUNT = 20

    /** Satu halaman daftar genre / hasil pencarian = 10 judul. */
    const val LIST_PAGE_SIZE = 10

    // Endpoint daftar genre + pencarian (sama dengan yang terekam di HAR: get_category_genre).
    // Bila nama parameter di server berbeda, cukup ubah konstanta di bawah ini.
    private const val LIST_ENDPOINT = "get_category_genre"
    private const val PARAM_SEARCH = "search"
    private const val PARAM_GENRE = "genre"
    private const val PARAM_PAGE = "page"
    private const val PARAM_COUNT = "count"
    private const val LIST_SORT = "c.category_name ASC"
    private const val LOG_TAG = "PencariNafkah"
    private const val CATALOG_TTL_MS = 15 * 60_000L
    private const val CATALOG_PUBLISH_BATCH_SIZE = 64
    private const val VIDEO_TTL_MS = 3 * 60_000L

    private val apiClient by lazy {
        NetworkClient.httpClient.newBuilder()
            .readTimeout(60, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }
    // Request halaman kecil: timeout pendek supaya UI menampilkan error + tombol coba lagi,
    // bukan loading tanpa akhir.
    private val listClient by lazy {
        NetworkClient.httpClient.newBuilder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private enum class ListMode { SERVER, LOCAL }

    /** "genre" / "search" -> mode yang terdeteksi. SERVER = server mendukung page/count/filter. */
    private val listModes = ConcurrentHashMap<String, ListMode>()

    private val videosMutex = Mutex()
    private val genresMutex = Mutex()

    @Volatile private var catalogCache: List<AnimeItem> = emptyList()
    @Volatile private var catalogWorkingItems: ArrayList<AnimeItem>? = null
    @Volatile private var catalogCachedAt = 0L
    private val catalogItemsLock = Any()

    /** StateFlow only publishes a small cursor, never a full copy of the catalog. */
    private data class CatalogSnapshot(
        val itemCount: Int = 0,
        val complete: Boolean = false,
        val error: String? = null,
        val version: Int = 0
    )

    private data class CatalogBatch(val items: List<AnimeItem>, val complete: Boolean)

    // Pengunduhan katalog berjalan terpisah dari layar pemanggil. Pindah query/genre
    // tidak membatalkan unduhan besar dan tidak memaksa aplikasi mengunduh ulang.
    private val catalogScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val catalogState = MutableStateFlow(CatalogSnapshot())
    private var catalogLoadJob: Job? = null
    private var catalogEvictionJob: Job? = null
    private var catalogVersion = 0
    private var activeCatalogVersion = 0
    private var catalogLastAccessAt = 0L
    @Volatile private var videoCache: List<AnimeItem> = emptyList()
    @Volatile private var videoCachedAt = 0L
    @Volatile private var genreCache: List<String> = emptyList()

    data class CategoryPage(
        val items: List<AnimeItem>,
        val page: Int,
        val pages: Int,
        val total: Int
    ) {
        val hasNext: Boolean get() = page < pages
    }

    private suspend fun getText(
        endpoint: String,
        params: List<Pair<String, String>> = emptyList(),
        needsApiKey: Boolean = false
    ): String = withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (needsApiKey && API_KEY.isBlank()) {
            throw IllegalStateException("API key belum diisi. Isi PencariNafkahApiSource.API_KEY terlebih dahulu.")
        }

        val urlBuilder = (BASE_URL + endpoint).toHttpUrl().newBuilder()
        params.forEach { (key, value) -> urlBuilder.addQueryParameter(key, value) }
        if (needsApiKey) urlBuilder.addQueryParameter("api_key", API_KEY)

        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("User-Agent", USER_AGENT)
            .header("Accept", ACCEPT)
            .get()
            .build()

        apiClient.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = text.take(180).replace(Regex("\\s+"), " ")
                throw IllegalStateException("PencariNafkah HTTP ${response.code}${if (detail.isNotBlank()) ": $detail" else ""}")
            }
            if (text.isBlank()) throw IllegalStateException("Respons API kosong")
            if (text.trimStart().startsWith("<")) throw IllegalStateException("API mengembalikan HTML, bukan JSON")
            text
        }
    }

    private fun JSONObject.stringValue(key: String): String {
        if (!has(key) || isNull(key)) return ""
        val value = opt(key)
        return when (value) {
            is String -> value.trim()
            is Number -> value.toString().removeSuffix(".0")
            is Boolean -> value.toString()
            else -> ""
        }
    }

    private fun JSONObject.longValue(key: String): Long {
        val value = opt(key)
        return when (value) {
            is Number -> value.toLong()
            is String -> value.toLongOrNull() ?: value.toDoubleOrNull()?.toLong() ?: 0L
            else -> 0L
        }
    }

    private fun JSONObject.doubleValue(key: String): Double {
        val value = opt(key)
        return when (value) {
            is Number -> value.toDouble()
            is String -> value.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    private fun JSONObject.intValue(key: String): Int = longValue(key).coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()

    private fun imageUrl(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        if (value.startsWith("http://", true) || value.startsWith("https://", true)) return value
        val fileName = value.substringAfterLast('/').trim()
        val encoded = java.net.URLEncoder.encode(fileName, Charsets.UTF_8.name()).replace("+", "%20")
        return IMAGE_BASE + encoded
    }

    private fun genreParts(raw: String): List<String> = raw
        .split(',')
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .distinctBy { it.lowercase() }

    private fun isDonghuaGenres(genres: List<String>): Boolean =
        genres.any { it.equals("Donghua", ignoreCase = true) }

    private fun parseAnimeType(description: String, genres: List<String>): String {
        if (isDonghuaGenres(genres)) return "Donghua"
        val match = Regex("(?i)Type:\\s*([^<\\r\\n]+)").find(description)
        return match?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() } ?: "TV"
    }

    private fun extractSynopsis(html: String): String {
        if (html.isBlank()) return ""
        val marker = Regex("(?is)(?:<strong>|<em><strong>)\\s*(?:Synopsis|Sinopsis)\\s*</strong>(?:</em>)?(?:\\s*<br\\s*/?>)?(?:\\s*</p>)?")
        val synopsisHtml = marker.find(html)?.let { html.substring(it.range.last + 1) } ?: html
        return android.text.Html.fromHtml(synopsisHtml, android.text.Html.FROM_HTML_MODE_LEGACY)
            .toString()
            .replace(Regex("[\\t ]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun episodeNumber(title: String, fallback: Int): String {
        val found = Regex("(?i)(?:eps?|episode)\\s*([0-9]+(?:\\.[0-9]+)?)").find(title)
            ?.groupValues?.getOrNull(1)
        return found ?: fallback.toString().padStart(2, '0')
    }

    private fun mapCategory(row: JSONObject, includeSynopsis: Boolean = false): AnimeItem {
        val name = row.stringValue("category_name")
        val genres = genreParts(row.stringValue("genre"))
        val description = row.stringValue("desc_anime")
        val id = row.stringValue("cid")
        val rating = row.doubleValue("rating").let { if (it > 0.0) it.toString() else "-" }
        return AnimeItem(
            judul = name,
            cover = imageUrl(row.stringValue("category_image")),
            url = id,
            lastch = "",
            type = parseAnimeType(description, genres),
            status = row.stringValue("status_video").ifBlank { "Unknown" },
            score = rating,
            rating = rating,
            sinopsis = if (includeSynopsis) extractSynopsis(description) else "",
            genre = genres,
            totalViews = row.longValue("total_views"),
            updatedAt = row.stringValue("update_date_time").ifBlank { row.stringValue("new_date_time") }
        )
    }

    private fun mapVideo(row: JSONObject): AnimeItem {
        val genres = genreParts(row.stringValue("genre"))
        val title = row.stringValue("category_name")
        val ep = Regex("(?i)(?:eps?|episode)\\s*([0-9]+(?:\\.[0-9]+)?)")
            .find(row.stringValue("video_title"))?.groupValues?.getOrNull(1)
        val rating = row.doubleValue("rating").let { if (it > 0.0) it.toString() else "-" }
        return AnimeItem(
            judul = title,
            cover = imageUrl(row.stringValue("category_image").ifBlank { row.stringValue("video_thumbnail") }),
            url = row.stringValue("cat_id"),
            lastch = ep?.let { "Ep $it" }.orEmpty(),
            type = if (isDonghuaGenres(genres)) "Donghua" else parseAnimeType(row.stringValue("video_description"), genres),
            status = row.stringValue("status_video").ifBlank { row.stringValue("video_duration") },
            score = rating,
            rating = rating,
            sinopsis = "",
            genre = genres,
            totalViews = row.longValue("total_views"),
            updatedAt = row.stringValue("update_date_time").ifBlank { row.stringValue("date_time") }
        )
    }

    private suspend fun categoryResponse(endpoint: String, page: Int, count: Int): CategoryPage {
        val text = getText(
            endpoint,
            listOf("page" to page.coerceAtLeast(1).toString(), "count" to count.coerceIn(1, 100).toString()),
            needsApiKey = true
        )
        val root = JSONObject(text)
        val array = root.optJSONArray("new_anime") ?: root.optJSONArray("categories") ?: JSONArray()
        val items = buildList {
            for (i in 0 until array.length()) {
                val row = array.optJSONObject(i) ?: continue
                val mapped = mapCategory(row)
                if (mapped.url.isNotBlank() && mapped.judul.isNotBlank()) add(mapped)
            }
        }
        // Beberapa respons API/HAR melaporkan pages=1 walaupun count_total berisi
        // seluruh katalog. Hitung jumlah halaman dari total dan ukuran halaman aktual.
        // root.count adalah jumlah item yang dikirim pada respons saat ini; pada halaman
        // terakhir nilainya bisa lebih kecil. Gunakan count request sebagai ukuran halaman.
        val total = root.intValue("count_total").takeIf { it > 0 }
            ?: root.intValue("count").takeIf { it > 0 }
            ?: items.size
        val reportedPages = root.intValue("pages").coerceAtLeast(1)
        val requestedPageSize = count.coerceIn(1, 100)
        val calculatedPages = if (total > 0) {
            ((total.toLong() + requestedPageSize - 1L) / requestedPageSize).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        } else {
            reportedPages
        }
        val pages = maxOf(page, reportedPages, calculatedPages)
        return CategoryPage(
            items = items,
            page = page,
            pages = pages,
            total = total
        )
    }

    /** Endpoint kategori yang terekam: new, popular, complete, coming, favorite. */
    suspend fun getCategoryPage(kind: String, page: Int = 1, count: Int = DEFAULT_COUNT): CategoryPage {
        val endpoint = when (kind.lowercase()) {
            "new", "latest", "ongoing" -> "get_category_new"
            "popular", "populer" -> "get_category_popular"
            "complete", "completed" -> "get_category_complete"
            "coming", "upcoming" -> "get_category_coming"
            "favorite", "favourite" -> "get_category_favorite"
            else -> throw IllegalArgumentException("Kategori anime tidak dikenal: $kind")
        }
        return categoryResponse(endpoint, page, count)
    }

    private fun readScalar(reader: JsonReader): String = when (reader.peek()) {
        JsonToken.STRING -> reader.nextString().trim()
        JsonToken.NUMBER -> reader.nextString().removeSuffix(".0")
        JsonToken.BOOLEAN -> reader.nextBoolean().toString()
        JsonToken.NULL -> {
            reader.nextNull()
            ""
        }
        else -> {
            reader.skipValue()
            ""
        }
    }

    private fun readIntLenient(reader: JsonReader): Int = when (reader.peek()) {
        JsonToken.NUMBER, JsonToken.STRING ->
            reader.nextString().trim().toDoubleOrNull()?.toInt() ?: 0
        else -> {
            reader.skipValue()
            0
        }
    }

    /**
     * Membaca satu baris kategori langsung dari JsonReader menjadi AnimeItem, tanpa membuat
     * JSONObject per baris. Field berat (desc_anime) hanya dipakai untuk membaca "Type:" lalu
     * dibuang, sehingga parsing 5.946 judul jauh lebih ringan di RAM dan CPU.
     */
    private fun readCategoryItem(reader: JsonReader): AnimeItem? {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
            reader.skipValue()
            return null
        }
        var cid = ""
        var name = ""
        var image = ""
        var status = ""
        var rating = 0.0
        var genreRaw = ""
        var desc = ""
        var views = 0L
        var updated = ""
        var created = ""
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "cid" -> cid = readScalar(reader)
                "category_name" -> name = readScalar(reader)
                "category_image" -> image = readScalar(reader)
                "status_video" -> status = readScalar(reader)
                "rating" -> rating = readScalar(reader).toDoubleOrNull() ?: 0.0
                "genre" -> genreRaw = readScalar(reader)
                "desc_anime" -> desc = readScalar(reader)
                "total_views" -> views = readScalar(reader).toDoubleOrNull()?.toLong() ?: 0L
                "update_date_time" -> updated = readScalar(reader)
                "new_date_time" -> created = readScalar(reader)
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        if (cid.isBlank() || name.isBlank()) return null
        val genres = genreParts(genreRaw)
        val ratingText = if (rating > 0.0) rating.toString() else "-"
        return AnimeItem(
            judul = name,
            cover = imageUrl(image),
            url = cid,
            lastch = "",
            type = parseAnimeType(desc, genres),
            status = status.ifBlank { "Unknown" },
            score = ratingText,
            rating = ratingText,
            sinopsis = "",
            genre = genres,
            totalViews = views,
            updatedAt = updated.ifBlank { created }
        )
    }

    @Synchronized
    private fun ensureCatalogLoad(): Int {
        val now = System.currentTimeMillis()
        if (catalogCache.isNotEmpty() && now - catalogCachedAt < CATALOG_TTL_MS) {
            catalogLastAccessAt = now
            val current = catalogState.value
            if (current.complete && current.itemCount == catalogCache.size) {
                scheduleCatalogEviction(current.version)
                return current.version
            }
            val version = ++catalogVersion
            activeCatalogVersion = version
            catalogState.value = CatalogSnapshot(
                itemCount = catalogCache.size,
                complete = true,
                version = version
            )
            scheduleCatalogEviction(version)
            return version
        }

        if (catalogLoadJob?.isActive == true) return activeCatalogVersion

        catalogCache = emptyList()
        catalogWorkingItems = null
        catalogCachedAt = 0L
        val version = ++catalogVersion
        activeCatalogVersion = version
        catalogState.value = CatalogSnapshot(version = version)
        catalogLoadJob = catalogScope.launch {
            try {
                val loaded = downloadCatalogStreaming(version)
                if (activeCatalogVersion == version) {
                    synchronized(catalogItemsLock) {
                        catalogCache = loaded
                        catalogWorkingItems = null
                        catalogCachedAt = System.currentTimeMillis()
                        catalogLastAccessAt = catalogCachedAt
                    }
                    catalogState.value = CatalogSnapshot(
                        itemCount = loaded.size,
                        complete = true,
                        version = version
                    )
                    scheduleCatalogEviction(version)
                }
            } catch (e: Exception) {
                if (activeCatalogVersion == version) {
                    val partialCount = synchronized(catalogItemsLock) {
                        catalogWorkingItems?.size ?: catalogCache.size
                    }
                    catalogState.value = CatalogSnapshot(
                        itemCount = partialCount,
                        complete = true,
                        error = e.message ?: "Gagal memuat katalog anime",
                        version = version
                    )
                }
            }
        }
        return version
    }

    /** Lepas snapshot katalog dari RAM setelah tidak dipakai selama TTL. */
    @Synchronized
    private fun scheduleCatalogEviction(version: Int) {
        catalogEvictionJob?.cancel()
        catalogEvictionJob = catalogScope.launch {
            kotlinx.coroutines.delay(CATALOG_TTL_MS)
            synchronized(this@PencariNafkahApiSource) {
                val idleFor = System.currentTimeMillis() - catalogLastAccessAt
                if (activeCatalogVersion == version && catalogCache.isNotEmpty() && idleFor >= CATALOG_TTL_MS) {
                    synchronized(catalogItemsLock) {
                        catalogCache = emptyList()
                        catalogWorkingItems = null
                        catalogCachedAt = 0L
                        catalogLastAccessAt = 0L
                    }
                    val emptyVersion = ++catalogVersion
                    activeCatalogVersion = emptyVersion
                    catalogState.value = CatalogSnapshot(version = emptyVersion)
                }
            }
        }
    }

    private suspend fun downloadCatalogStreaming(version: Int): List<AnimeItem> = withContext(Dispatchers.IO) {
        if (API_KEY.isBlank()) {
            throw IllegalStateException("API key belum diisi. Isi PencariNafkahApiSource.API_KEY terlebih dahulu.")
        }
        val url = (BASE_URL + "get_category_genre")
            .toHttpUrl().newBuilder()
            .addQueryParameter("sort", "c.category_name ASC")
            .addQueryParameter("api_key", API_KEY)
            .build()

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", ACCEPT)
            .get()
            .build()

        apiClient.newCall(request).execute().use { response ->
            val body = response.body ?: throw IllegalStateException("Respons katalog kosong")
            if (!response.isSuccessful) {
                val detail = body.string().take(180).replace(Regex("\\s+"), " ")
                throw IllegalStateException("PencariNafkah HTTP ${response.code}${if (detail.isNotBlank()) ": $detail" else ""}")
            }

            val all = ArrayList<AnimeItem>(6000)
            synchronized(catalogItemsLock) { catalogWorkingItems = all }
            var foundCategories = false
            JsonReader(BufferedReader(body.charStream(), 64 * 1024)).use { reader ->
                reader.isLenient = true
                reader.beginObject()
                while (reader.hasNext()) {
                    when (reader.nextName()) {
                        "categories" -> {
                            foundCategories = true
                            reader.beginArray()
                            while (reader.hasNext()) {
                                currentCoroutineContext().ensureActive()
                                val item = readCategoryItem(reader) ?: continue
                                val size = synchronized(catalogItemsLock) {
                                    all.add(item)
                                    all.size
                                }
                                if (size % CATALOG_PUBLISH_BATCH_SIZE == 0) {
                                    // Hanya angka progress yang dipancarkan; item tidak disalin berulang.
                                    catalogState.value = CatalogSnapshot(
                                        itemCount = size,
                                        complete = false,
                                        version = version
                                    )
                                }
                            }
                            reader.endArray()
                        }
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()
            }
            if (!foundCategories) throw IllegalStateException("Daftar kategori tidak ditemukan pada respons API")
            if (all.isEmpty()) throw IllegalStateException("Katalog anime kosong")
            all
        }
    }

    /**
     * Memancarkan delta item saja. Subscriber yang datang terlambat mendapat bagian yang
     * belum pernah diterima, bukan snapshot penuh yang disalin ulang setiap 64 record.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun streamFullCatalog(onBatch: suspend (List<AnimeItem>, Boolean) -> Unit) {
        val version = ensureCatalogLoad()
        var delivered = 0
        catalogState.transformWhile { snapshot ->
            if (snapshot.version != version) {
                throw IllegalStateException("Sesi pemuatan katalog berubah. Silakan coba lagi.")
            }

            val delta = synchronized(catalogItemsLock) {
                val source = catalogWorkingItems ?: catalogCache
                val end = source.size
                val start = delivered.coerceAtMost(end)
                val items = if (end > start) source.subList(start, end).toList() else emptyList()
                delivered = end
                items
            }

            // Sampaikan data parsial lebih dulu, baru laporkan kegagalan jika ada.
            if (delta.isNotEmpty()) emit(CatalogBatch(delta, complete = false))
            if (snapshot.error != null) throw IllegalStateException(snapshot.error)
            if (snapshot.complete) emit(CatalogBatch(emptyList(), complete = true))
            !snapshot.complete
        }.collect { batch -> onBatch(batch.items, batch.complete) }
    }

    /** Menunggu katalog selesai hanya untuk pemanggil yang memang membutuhkan seluruh snapshot. */
    suspend fun getFullCatalog(): List<AnimeItem> {
        val version = ensureCatalogLoad()
        val snapshot = catalogState.first { it.version == version && (it.complete || it.error != null) }
        snapshot.error?.let { throw IllegalStateException(it) }
        return synchronized(catalogItemsLock) { catalogCache }
    }

    // ------------------------------------------------------------------------------------
    // Daftar genre + pencarian, 1 halaman = LIST_PAGE_SIZE (10) judul.
    //
    // Cara kerja:
    //  1. Minta langsung ke server: get_category_genre?search=..&genre=..&page=N&count=10.
    //     Halaman 10 judul tiba dalam satu request kecil dan langsung ditampilkan.
    //  2. Respons divalidasi saat dibaca. Bila server ternyata mengabaikan page/count/filter
    //     (mengirim seluruh katalog atau hasil yang tidak cocok), pembacaan dihentikan
    //     seketika dan mode otomatis pindah ke LOCAL untuk kategori itu.
    //  3. Mode LOCAL memakai satu unduhan katalog di latar belakang. Halaman 1 muncul begitu
    //     10 judul yang cocok ditemukan, tanpa menunggu seluruh katalog selesai diproses.
    // ------------------------------------------------------------------------------------

    /** Nama genre di server punya salah ketik / variasi; samakan agar filter tidak kosong. */
    private val GENRE_KEY_ALIASES = mapOf(
        "demonds" to "demons",
        "pyscological" to "psychological",
        "horor" to "horror",
        "games" to "game",
        "actions" to "action",
        "fanstasy" to "fantasy"
    )

    private val GENRE_DISPLAY_FIXES = mapOf(
        "demonds" to "Demons",
        "pyscological" to "Psychological"
    )

    /** Genre di daftar server yang sebenarnya disimpan di kolom status_video, bukan di kolom genre. */
    private val STATUS_BASED_GENRES = setOf("movie", "live action", "ongoing")

    private fun genreKey(raw: String): String {
        val key = raw.trim().lowercase()
        return GENRE_KEY_ALIASES[key] ?: key
    }

    /** Perbaiki nama genre dari get_genre_index (mis. "Demonds" -> "Demons"). */
    fun fixGenreName(raw: String): String = GENRE_DISPLAY_FIXES[raw.trim().lowercase()] ?: raw.trim()

    /**
     * Apakah item termasuk genre ini? "Movie" dan "Live Action" ada di kolom status_video,
     * sehingga sebelumnya dua genre itu tidak pernah cocok dan loading tanpa akhir.
     */
    fun itemHasGenre(item: AnimeItem, genre: String): Boolean {
        val key = genreKey(genre)
        if (key.isEmpty()) return true
        if (key in STATUS_BASED_GENRES) return item.status.trim().lowercase() == key
        return item.genre.any { genreKey(it) == key }
    }

    private fun titleMatches(title: String, rawQuery: String, normalizedQuery: String): Boolean =
        if (normalizedQuery.isNotEmpty()) normalizeTitle(title).contains(normalizedQuery)
        else title.contains(rawQuery, ignoreCase = true)

    private sealed class ServerListResult {
        class Ok(val page: CategoryPage) : ServerListResult()
        class Unsupported(val reason: String) : ServerListResult()
    }

    private class EnoughResults : RuntimeException() {
        override fun fillInStackTrace(): Throwable = this
    }

    /**
     * Satu halaman (default 10 judul) untuk genre dan/atau pencarian judul.
     * Urutan A-Z mengikuti server. Item yang dikembalikan belum difilter jenis media
     * (Anime/Donghua) atau status; itu tugas pemanggil.
     */
    suspend fun getCatalogListPage(
        genre: String?,
        query: String,
        page: Int,
        count: Int = LIST_PAGE_SIZE
    ): CategoryPage {
        val safePage = page.coerceAtLeast(1)
        val safeCount = count.coerceIn(1, 50)
        val cleanGenre = genre?.trim()?.takeIf { it.isNotEmpty() }?.let(::fixGenreName)
        val cleanQuery = query.trim()
        val modeKey = if (cleanQuery.isNotEmpty()) "search" else "genre"

        if (listModes[modeKey] != ListMode.LOCAL) {
            when (val result = fetchServerListPage(cleanGenre, cleanQuery, safePage, safeCount)) {
                is ServerListResult.Ok -> {
                    if (listModes.put(modeKey, ListMode.SERVER) == null) {
                        Log.d(LOG_TAG, "Mode daftar '$modeKey' = SERVER (paginasi dari server aktif)")
                    }
                    return result.page
                }
                is ServerListResult.Unsupported -> {
                    listModes[modeKey] = ListMode.LOCAL
                    Log.w(LOG_TAG, "Mode daftar '$modeKey' = LOCAL: ${result.reason}")
                }
            }
        }
        return localListPage(cleanGenre, cleanQuery, safePage, safeCount)
    }

    private suspend fun fetchServerListPage(
        genre: String?,
        query: String,
        page: Int,
        count: Int
    ): ServerListResult = withContext(Dispatchers.IO) {
        if (API_KEY.isBlank()) {
            throw IllegalStateException("API key belum diisi. Isi PencariNafkahApiSource.API_KEY terlebih dahulu.")
        }
        val url = (BASE_URL + LIST_ENDPOINT).toHttpUrl().newBuilder()
            .addQueryParameter(PARAM_SEARCH, query)
            .addQueryParameter("sort", LIST_SORT)
            .addQueryParameter(PARAM_PAGE, page.toString())
            .addQueryParameter(PARAM_COUNT, count.toString())
            .apply { if (!genre.isNullOrBlank()) addQueryParameter(PARAM_GENRE, genre) }
            .addQueryParameter("api_key", API_KEY)
            .build()

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", ACCEPT)
            .get()
            .build()

        listClient.newCall(request).execute().use { response ->
            handleServerListResponse(response, genre, query, page, count)
        }
    }

    private fun handleServerListResponse(
        response: Response,
        genre: String?,
        query: String,
        page: Int,
        count: Int
    ): ServerListResult {
        if (!response.isSuccessful) {
            if (response.code == 400 || response.code == 404 || response.code == 422) {
                return ServerListResult.Unsupported("HTTP ${response.code}")
            }
            val detail = response.body?.string().orEmpty().take(180).replace(Regex("\\s+"), " ")
            throw IllegalStateException("PencariNafkah HTTP ${response.code}${if (detail.isNotBlank()) ": $detail" else ""}")
        }
        val body = response.body ?: throw IllegalStateException("Respons daftar kosong")
        return JsonReader(BufferedReader(body.charStream(), 16 * 1024)).use { reader ->
            parseServerListBody(reader, genre, query, page, count)
        }
    }

    private fun parseServerListBody(
        reader: JsonReader,
        genre: String?,
        query: String,
        page: Int,
        count: Int
    ): ServerListResult {
        reader.isLenient = true
        val items = ArrayList<AnimeItem>(count)
        var reportedTotal = 0
        var reportedPages = 0
        var foundArray = false

        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "categories" -> {
                    foundArray = true
                    reader.beginArray()
                    while (reader.hasNext()) {
                        val item = readCategoryItem(reader)
                        if (item != null) items.add(item)
                        // Lebih banyak dari yang diminta = server mengabaikan page/count.
                        // Berhenti membaca sekarang agar tidak mengunduh 9 MB.
                        if (items.size > count) {
                            return ServerListResult.Unsupported("server mengabaikan page/count")
                        }
                    }
                    reader.endArray()
                }
                "count_total" -> reportedTotal = readIntLenient(reader)
                "pages" -> reportedPages = readIntLenient(reader)
                else -> reader.skipValue()
            }
        }
        reader.endObject()

        if (!foundArray) throw IllegalStateException("Daftar kategori tidak ditemukan pada respons API")

        if (items.isNotEmpty()) {
            if (genre != null && items.none { itemHasGenre(it, genre) }) {
                return ServerListResult.Unsupported("server mengabaikan filter genre")
            }
            if (query.isNotEmpty()) {
                val normalized = normalizeTitle(query)
                if (items.none { titleMatches(it.judul, query, normalized) }) {
                    return ServerListResult.Unsupported("server mengabaikan pencarian")
                }
            }
        }

        val calculatedPages = if (reportedTotal > 0) {
            ((reportedTotal.toLong() + count - 1L) / count).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        } else 0
        var pages = when {
            reportedTotal > 0 -> maxOf(calculatedPages, reportedPages)
            reportedPages > 0 -> reportedPages
            else -> page
        }
        // Halaman penuh tanpa info total yang meyakinkan: anggap masih ada halaman berikutnya.
        // Bila ternyata kosong, halaman berikutnya akan mengakhiri daftar dengan aman.
        if (items.size >= count && pages <= page) pages = page + 1

        return ServerListResult.Ok(
            CategoryPage(items = items, page = page, pages = pages, total = maxOf(reportedTotal, items.size))
        )
    }

    /** Cadangan bila server tidak mendukung paginasi: saring dari katalog yang diunduh sekali. */
    private suspend fun localListPage(
        genre: String?,
        query: String,
        page: Int,
        count: Int
    ): CategoryPage {
        val needed = (page.toLong() * count + 1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val normalizedQuery = normalizeTitle(query)
        val matched = ArrayList<AnimeItem>()
        val seen = HashSet<String>()
        try {
            streamFullCatalog { batch, _ ->
                for (item in batch) {
                    if (genre != null && !itemHasGenre(item, genre)) continue
                    if (query.isNotEmpty() && !titleMatches(item.judul, query, normalizedQuery)) continue
                    if (seen.add(item.url)) matched.add(item)
                    // Cukup sampai 1 judul melewati batas halaman (untuk tahu masih ada halaman berikutnya).
                    if (matched.size >= needed) throw EnoughResults()
                }
            }
        } catch (_: EnoughResults) {
            // Unduhan katalog tetap berjalan di latar belakang untuk halaman berikutnya.
        }

        val start = ((page - 1L) * count).coerceAtMost(matched.size.toLong()).toInt()
        val end = (start + count).coerceAtMost(matched.size)
        val pageItems = if (start < end) matched.subList(start, end).toList() else emptyList()
        val hasNext = matched.size > end
        return CategoryPage(
            items = pageItems,
            page = page,
            pages = if (hasNext) page + 1 else page,
            total = matched.size
        )
    }

    /** get_genre_index pada HAR berisi array mirip JSON tetapi key tidak diberi tanda kutip. */
    suspend fun getGenreIndex(): List<String> = genresMutex.withLock {
        if (genreCache.isNotEmpty()) return@withLock genreCache
        val text = getText("get_genre_index", needsApiKey = true)
        val parsed = runCatching {
            val array = JSONArray(text)
            buildList {
                for (i in 0 until array.length()) {
                    val row = array.optJSONObject(i) ?: continue
                    row.stringValue("genre_anime").takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }.getOrElse {
            Regex("(?is)genre_anime\\s*:\\s*\"([^\"]+)\"")
                .findAll(text)
                .map { it.groupValues[1].trim() }
                .filter { it.isNotBlank() }
                .toList()
        }
        genreCache = parsed.distinctBy { it.lowercase() }
        genreCache
    }

    private data class VideoPage(val items: List<AnimeItem>, val pages: Int)

    private suspend fun videoPage(page: Int, count: Int = DEFAULT_COUNT): VideoPage {
        val text = getText(
            "get_videos",
            listOf("page" to page.coerceAtLeast(1).toString(), "count" to count.toString()),
            needsApiKey = true
        )
        val root = JSONObject(text)
        val array = root.optJSONArray("latest_anime") ?: JSONArray()
        val items = buildList {
            for (i in 0 until array.length()) {
                val row = array.optJSONObject(i) ?: continue
                val mapped = mapVideo(row)
                if (mapped.url.isNotBlank() && mapped.judul.isNotBlank()) add(mapped)
            }
        }
        return VideoPage(items, root.intValue("pages").coerceAtLeast(page))
    }

    /** Recent update feed. Multiple halaman digabung lalu satu kartu per serial. */
    suspend fun getLatestUpdateCategories(maxPages: Int = 3): List<AnimeItem> = videosMutex.withLock {
        if (videoCache.isNotEmpty() && System.currentTimeMillis() - videoCachedAt < VIDEO_TTL_MS) {
            return@withLock videoCache
        }
        val first = videoPage(1)
        val lastPage = minOf(first.pages, maxPages.coerceAtLeast(1))
        val otherPages = if (lastPage > 1) coroutineScope {
            (2..lastPage).map { p -> async { videoPage(p).items } }.awaitAll().flatten()
        } else emptyList()
        val all = (first.items + otherPages).distinctBy { it.url }
        videoCache = all
        videoCachedAt = System.currentTimeMillis()
        all
    }

    suspend fun getAnimeDetail(categoryId: String): AnimeDetail {
        val resolvedCategoryId = resolveCategoryId(categoryId)
        val text = getText("get_anime_detail", listOf("id" to resolvedCategoryId), needsApiKey = true)
        val root = JSONObject(text)
        if (!root.optString("status", "ok").equals("ok", true)) {
            throw IllegalStateException(root.optString("message").ifBlank { "Detail anime tidak ditemukan" })
        }
        val category = root.optJSONObject("category") ?: throw IllegalStateException("Data serial tidak ditemukan")
        val cid = category.stringValue("cid").ifBlank { resolvedCategoryId }
        val genres = genreParts(category.stringValue("genre"))
        val description = category.stringValue("desc_anime")
        val suggested = root.optJSONArray("suggested") ?: JSONArray()
        val episodes = buildList {
            val seen = HashSet<String>()
            for (i in 0 until suggested.length()) {
                val row = suggested.optJSONObject(i) ?: continue
                val vid = row.stringValue("vid")
                if (vid.isBlank() || !seen.add(vid)) continue
                val episode = episodeNumber(row.stringValue("video_title"), i + 1)
                add(AnimeEpisode(ch = episode, url = "$vid|$cid|$episode"))
            }
        }
        val rating = category.doubleValue("rating").let { if (it > 0.0) it.toString() else "-" }
        return AnimeDetail(
            judul = category.stringValue("category_name"),
            cover = imageUrl(category.stringValue("category_image")),
            sinopsis = extractSynopsis(description),
            rating = rating,
            type = parseAnimeType(description, genres),
            status = category.stringValue("status_video"),
            published = category.stringValue("update_date_time"),
            series_id = cid,
            genre = genres,
            chapter = episodes
        )
    }


    private fun normalizeTitle(value: String): String = value
        .lowercase()
        .filter { it.isLetterOrDigit() }

    private suspend fun resolveCategoryId(rawId: String): String {
        if (rawId.toLongOrNull() != null) return rawId
        val slug = rawId.substringBefore('?').substringAfterLast('/').substringAfterLast('\\')
        val normalized = normalizeTitle(slug)
        if (normalized.isBlank()) return rawId
        val catalog = getFullCatalog()
        return catalog.firstOrNull { normalizeTitle(it.judul) == normalized }?.url
            ?: catalog.firstOrNull {
                val title = normalizeTitle(it.judul)
                title.isNotBlank() && (title.contains(normalized) || normalized.contains(title))
            }?.url
            ?: rawId
    }

    private suspend fun postObject(endpoint: String, id: String, categoryId: String?): JSONObject {
        val params = buildList {
            add("id" to id)
            if (!categoryId.isNullOrBlank()) add("cat_id" to categoryId)
        }
        val root = JSONObject(getText(endpoint, params, needsApiKey = false))
        return root.optJSONObject("post") ?: throw IllegalStateException("Data episode tidak ditemukan")
    }

    /** Mengambil detail episode; endpoint next_provious menjadi fallback sesuai rekaman HAR. */
    suspend fun getPostDetail(episodeId: String, categoryId: String? = null): JSONObject {
        return try {
            postObject("get_post_detail", episodeId, null)
        } catch (primary: Exception) {
            if (categoryId.isNullOrBlank()) throw primary
            try {
                postObject("get_post_detail_next_provious", episodeId, categoryId)
            } catch (_: Exception) {
                throw primary
            }
        }
    }

    /** Endpoint terpisah yang menyediakan data episode beserta daftar rekomendasi/relasi. */
    suspend fun getPostDetailNextPrevious(episodeId: String, categoryId: String): JSONObject {
        val root = JSONObject(getText(
            "get_post_detail_next_provious",
            listOf("id" to episodeId, "cat_id" to categoryId),
            needsApiKey = false
        ))
        return root
    }

    suspend fun getEpisodeStreams(channelId: String): EpisodeStreamData {
        val parts = channelId.split('|')
        if (parts.size < 2) throw IllegalArgumentException("ID episode tidak valid")
        val episodeId = parts[0]
        val categoryId = parts[1]
        val post = getPostDetail(episodeId, categoryId)

        val streams = buildList<StreamSource> {
            fun addIfAvailable(label: String, field: String, suffix: String = "") {
                val link = post.stringValue(field)
                if (link.isNotBlank() && none { it.link == link }) {
                    add(StreamSource(name = label + suffix, link = link))
                }
            }
            addIfAvailable("1080p", "video_url_fullhd")
            addIfAvailable("720p", "video_url_hd")
            addIfAvailable("Mini HD", "video_url_minihd")
            val standard = post.stringValue("video_url")
            if (standard.isNotBlank() && none { it.link == standard }) {
                val resolution = Regex("(?i)(360p|480p|540p|720p|1080p)").find(standard)?.value ?: "Standar"
                add(StreamSource(name = resolution, link = standard))
            }
            addIfAvailable("English HD", "video_url_hdeng")
            addIfAvailable("English", "video_url_eng")
        }
        if (streams.isEmpty()) throw IllegalStateException("Tidak ada link video yang tersedia untuk episode ini")
        return EpisodeStreamData(
            title = post.stringValue("video_title").ifBlank { "Episode ${parts.getOrNull(2).orEmpty()}" },
            streams = mapOf("Video" to streams)
        )
    }

    fun isDonghua(item: AnimeItem): Boolean = isDonghuaGenres(item.genre)
}
