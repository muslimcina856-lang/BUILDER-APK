package com.kano.playjv.core.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

/**
 * Penyimpan state layar yang hidup selama proses aplikasi berjalan, TIDAK ikut hilang saat layar
 * keluar dari komposisi (mis. membuka halaman detail lalu kembali). Dipakai agar daftar, hasil
 * pencarian, dan posisi scroll tidak diulang dari awal.
 */
object RetainedStateStore {
    private val values = HashMap<String, Any?>()

    @Synchronized
    @Suppress("UNCHECKED_CAST")
    fun <T> getOrPut(key: String, init: () -> T): T {
        if (!values.containsKey(key)) values[key] = init()
        return values[key] as T
    }

    @Synchronized
    fun clear() = values.clear()
}

/** Seperti remember, tetapi nilainya bertahan walau layar keluar dari komposisi. */
@Composable
fun <T> rememberRetained(key: String, init: () -> T): T =
    remember(key) { RetainedStateStore.getOrPut(key, init) }
