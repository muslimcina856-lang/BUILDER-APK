package com.kano.playjv.core.state

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Saklar konten dewasa (18+). Default MATI. Dinyalakan pengguna dari tab Tentang (dengan
 * konfirmasi usia). Saat mati, genre "Hentai" disembunyikan dan judul bergenre itu disaring
 * dari semua daftar (beranda, katalog, pencarian).
 */
object AdultContentGate {
    private val _enabled = MutableStateFlow(false)
    val enabledFlow: StateFlow<Boolean> = _enabled
    val enabled: Boolean get() = _enabled.value

    fun set(value: Boolean) { _enabled.value = value }

    fun isAdultGenre(genre: String): Boolean = genre.trim().equals("hentai", ignoreCase = true)
    fun isAdult(genres: List<String>): Boolean = genres.any { isAdultGenre(it) }
}
