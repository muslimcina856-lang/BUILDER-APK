package com.kano.playjv.ui.navigation

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.kano.playjv.core.components.KuroBottomBar
import com.kano.playjv.core.components.KuroTopBar
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.account.AccountScreen
import com.kano.playjv.ui.anime.AnimeDetailScreen
import com.kano.playjv.ui.anime.AnimeListScreen
import com.kano.playjv.ui.anime.AnimeSearchScreen
import com.kano.playjv.ui.home.HomeScreen
import com.kano.playjv.ui.library.LibraryScreen
import com.kano.playjv.ui.manga.MangaDetailScreen
import com.kano.playjv.ui.manga.MangaListScreen
import com.kano.playjv.ui.manga.MangaReaderScreen
import com.kano.playjv.ui.player.VideoPlayerScreen
import com.kano.playjv.core.model.UserProfile
import com.kano.playjv.ui.theme.KuroBgPrimary
import kotlinx.coroutines.flow.map

const val ROUTE_HOME = "beranda"
const val ROUTE_ANIME = "anime_catalog/{mediaType}"
const val ROUTE_SEARCH = "search"
const val ROUTE_MANGA = "manga"
const val ROUTE_LIBRARY = "library"
const val ROUTE_ACCOUNT = "akun"

/** Urutan tab pada nav bawah; -1 untuk layar non-tab (detail, pemutar, pembaca). */
private fun tabIndexOf(route: String?): Int = when {
    route == null -> -1
    route == ROUTE_HOME -> 0
    route == ROUTE_SEARCH || route.startsWith("anime_catalog") -> 1
    route == ROUTE_MANGA -> 2
    route == ROUTE_LIBRARY -> 3
    route == ROUTE_ACCOUNT -> 4
    else -> -1
}

private data class ProfileHolder(val profile: UserProfile?)

/**
 * Gerbang login: aplikasi hanya bisa dipakai setelah login.
 * holder == null  -> DataStore belum selesai dibaca (layar kosong sebentar)
 * profile == null -> belum login -> tampilkan layar login/daftar
 */
@Composable
fun KuroApp(
    repository: KuroRepository,
    authRepository: AuthRepository,
    preferences: UserPreferences
) {
    val holder by remember { authRepository.userProfileFlow.map { ProfileHolder(it) } }
        .collectAsState(initial = null)
    val current = holder

    when {
        current == null -> Box(modifier = Modifier.fillMaxSize().background(KuroBgPrimary))
        current.profile == null -> Box(
            modifier = Modifier
                .fillMaxSize()
                .background(KuroBgPrimary)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            AccountScreen(authRepository = authRepository, preferences = preferences)
        }
        else -> KuroMainApp(repository, authRepository, preferences)
    }
}

@Composable
private fun KuroMainApp(
    repository: KuroRepository,
    authRepository: AuthRepository,
    preferences: UserPreferences
) {
    val navController = rememberNavController()
    val focusManager = LocalFocusManager.current
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME

    val userProfile by authRepository.userProfileFlow.collectAsState(initial = null)
    val currentUid = userProfile?.uid ?: "guest_user"
    val isLoggedIn = userProfile != null

    // Ambil kunci/premium terbaru dari server saat aplikasi dibuka
    LaunchedEffect(userProfile?.uid) {
        if (userProfile != null) authRepository.refreshProfile()
    }

    /**
     * Satu-satunya jalan pindah antar tab.
     * Beranda: cukup buang semua layar di atasnya (popBackStack). Memakai navigate + restoreState untuk
     * tujuan yang sama dengan popUpTo membuat layar yang baru dibuang (mis. Anime dari ikon search)
     * ikut dipulihkan, sehingga tombol Beranda "tidak bisa ditekan".
     */
    fun goToTab(route: String) {
        focusManager.clearFocus()
        if (route == ROUTE_HOME) {
            if (!navController.popBackStack(ROUTE_HOME, inclusive = false)) {
                navController.navigate(ROUTE_HOME) { launchSingleTop = true }
            }
        } else {
            navController.navigate(route) {
                popUpTo(ROUTE_HOME) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    // Determine if top/bottom bars should be visible
    val isFullScreen = currentRoute.startsWith("player/") || currentRoute.startsWith("reader/")
    val isTopLevelTab = currentRoute in listOf(ROUTE_HOME, ROUTE_SEARCH, ROUTE_ANIME, ROUTE_MANGA, ROUTE_LIBRARY, ROUTE_ACCOUNT)

    Scaffold(
        containerColor = KuroBgPrimary,
        topBar = {
            if (!isFullScreen && isTopLevelTab) {
                KuroTopBar(
                    title = "KuroPlay",
                    keysLabel = when {
                        userProfile?.isOwner == true -> "∞"
                        userProfile?.premium?.active == true -> "∞"
                        userProfile != null -> "${userProfile?.keys ?: 0}"
                        else -> null
                    },
                    onKeysClick = { goToTab(ROUTE_ACCOUNT) },
                    onSearchClick = { goToTab(ROUTE_SEARCH) }
                )
            }
        },
        bottomBar = {
            if (!isFullScreen && isTopLevelTab) {
                KuroBottomBar(
                    currentRoute = if (currentRoute == ROUTE_ANIME) ROUTE_SEARCH else currentRoute,
                    onNavigate = { route -> goToTab(route) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isFullScreen) androidx.compose.foundation.layout.PaddingValues() else innerPadding)
        ) {
            // Transisi geser (bukan fade/opasitas): antar-tab mengikuti urutan nav bawah, layar detail
            // masuk dari kanan dan keluar ke kanan saat kembali.
            val slideSpec = tween<androidx.compose.ui.unit.IntOffset>(220, easing = FastOutSlowInEasing)
            NavHost(
                navController = navController,
                startDestination = ROUTE_HOME,
                enterTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0 && from != to) {
                        slideIntoContainer(
                            if (to > from) AnimatedContentTransitionScope.SlideDirection.Start
                            else AnimatedContentTransitionScope.SlideDirection.End,
                            animationSpec = slideSpec
                        )
                    } else {
                        slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, animationSpec = slideSpec)
                    }
                },
                exitTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0 && from != to) {
                        slideOutOfContainer(
                            if (to > from) AnimatedContentTransitionScope.SlideDirection.Start
                            else AnimatedContentTransitionScope.SlideDirection.End,
                            animationSpec = slideSpec
                        )
                    } else {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Start,
                            animationSpec = slideSpec,
                            targetOffset = { it / 4 }
                        )
                    }
                },
                popEnterTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0 && from != to) {
                        slideIntoContainer(
                            if (to > from) AnimatedContentTransitionScope.SlideDirection.Start
                            else AnimatedContentTransitionScope.SlideDirection.End,
                            animationSpec = slideSpec
                        )
                    } else {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.End,
                            animationSpec = slideSpec,
                            initialOffset = { it / 4 }
                        )
                    }
                },
                popExitTransition = {
                    val from = tabIndexOf(initialState.destination.route)
                    val to = tabIndexOf(targetState.destination.route)
                    if (from >= 0 && to >= 0 && from != to) {
                        slideOutOfContainer(
                            if (to > from) AnimatedContentTransitionScope.SlideDirection.Start
                            else AnimatedContentTransitionScope.SlideDirection.End,
                            animationSpec = slideSpec
                        )
                    } else {
                        slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, animationSpec = slideSpec)
                    }
                }
            ) {
                composable(ROUTE_HOME) {
                    DeferUntilSettled {
                    HomeScreen(
                        repository = repository,
                        currentUid = currentUid,
                        onNavigateToAnimeDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        },
                        onNavigateToMangaDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        },
                        onNavigateToPlayer = { slug, ep, channelId, title ->
                            navController.navigate("player/${Uri.encode(slug)}/${Uri.encode(ep)}/${Uri.encode(channelId)}/${Uri.encode(title)}")
                        },
                        onNavigateToReader = { idSeries, idChapter, title ->
                            navController.navigate("reader/${Uri.encode(idSeries)}/${Uri.encode(idChapter)}/${Uri.encode(title)}")
                        },
                        onNavigateToAnimeCatalog = { mediaType ->
                            navController.navigate("anime_catalog/${Uri.encode(mediaType)}") { launchSingleTop = true }
                        },
                        onNavigateToMangaTab = { goToTab(ROUTE_MANGA) }
                    )
                    }
                }

                composable(ROUTE_SEARCH) {
                    DeferUntilSettled {
                    AnimeSearchScreen(
                        repository = repository,
                        onNavigateToDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        },
                        onOpenCatalog = { mediaType ->
                            navController.navigate("anime_catalog/${Uri.encode(mediaType)}")
                        }
                    )
                    }
                }

                composable(
                    route = ROUTE_ANIME,
                    arguments = listOf(navArgument("mediaType") { type = NavType.StringType })
                ) { backStackEntry ->
                    val mediaType = backStackEntry.arguments?.getString("mediaType") ?: "anime"
                    AnimeListScreen(
                        repository = repository,
                        initialMediaType = mediaType,
                        onNavigateToDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        }
                    )
                }

                composable(ROUTE_MANGA) {
                    DeferUntilSettled {
                    MangaListScreen(
                        repository = repository,
                        onNavigateToDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        }
                    )
                    }
                }

                composable(ROUTE_LIBRARY) {
                    DeferUntilSettled {
                    LibraryScreen(
                        repository = repository,
                        currentUid = currentUid,
                        isLoggedIn = isLoggedIn,
                        onNavigateToAnimeDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        },
                        onNavigateToMangaDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        }
                    )
                    }
                }

                composable(ROUTE_ACCOUNT) {
                    AccountScreen(
                        authRepository = authRepository,
                        preferences = preferences,
                        onOpenPremium = { navController.navigate("premium") { launchSingleTop = true } }
                    )
                }

                composable("premium") {
                    com.kano.playjv.ui.account.PremiumScreen(
                        authRepository = authRepository,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = "anime_detail/{slug}",
                    arguments = listOf(navArgument("slug") { type = NavType.StringType })
                ) { backStackEntry ->
                    val slug = backStackEntry.arguments?.getString("slug") ?: ""
                    AnimeDetailScreen(
                        animeId = slug,
                        repository = repository,
                        currentUid = currentUid,
                        onBack = { navController.popBackStack() },
                        onPlayEpisode = { s, ep, channelId, title ->
                            navController.navigate("player/${Uri.encode(s)}/${Uri.encode(ep)}/${Uri.encode(channelId)}/${Uri.encode(title)}")
                        }
                    )
                }

                composable(
                    route = "manga_detail/{idSeries}",
                    arguments = listOf(navArgument("idSeries") { type = NavType.StringType })
                ) { backStackEntry ->
                    val idSeries = backStackEntry.arguments?.getString("idSeries") ?: ""
                    MangaDetailScreen(
                        idSeries = idSeries,
                        repository = repository,
                        currentUid = currentUid,
                        onBack = { navController.popBackStack() },
                        onReadChapter = { sId, chId, title ->
                            navController.navigate("reader/${Uri.encode(sId)}/${Uri.encode(chId)}/${Uri.encode(title)}")
                        }
                    )
                }

                composable(
                    route = "player/{slug}/{epNumber}/{channelId}/{title}",
                    arguments = listOf(
                        navArgument("slug") { type = NavType.StringType },
                        navArgument("epNumber") { type = NavType.StringType },
                        navArgument("channelId") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val slug = backStackEntry.arguments?.getString("slug") ?: ""
                    val epNumber = backStackEntry.arguments?.getString("epNumber") ?: ""
                    val channelId = backStackEntry.arguments?.getString("channelId") ?: ""
                    val title = backStackEntry.arguments?.getString("title") ?: ""

                    VideoPlayerScreen(
                        slug = slug,
                        epNumber = epNumber,
                        channelId = channelId,
                        animeTitle = title,
                        repository = repository,
                        preferences = preferences,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = "reader/{idSeries}/{idChapter}/{title}",
                    arguments = listOf(
                        navArgument("idSeries") { type = NavType.StringType },
                        navArgument("idChapter") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val idSeries = backStackEntry.arguments?.getString("idSeries") ?: ""
                    val idChapter = backStackEntry.arguments?.getString("idChapter") ?: ""
                    val title = backStackEntry.arguments?.getString("title") ?: ""

                    MangaReaderScreen(
                        idSeries = idSeries,
                        idChapter = idChapter,
                        chapterTitle = title,
                        repository = repository,
                        preferences = preferences,
                        onBack = { navController.popBackStack() },
                        onNavigateToChapter = { newChId, newTitle ->
                            navController.navigate("reader/${Uri.encode(idSeries)}/${Uri.encode(newChId)}/${Uri.encode(newTitle)}") {
                                popUpTo("reader/{idSeries}/{idChapter}/{title}") { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }
}


/**
 * Tampilkan konten layar berat baru setelah animasi geser selesai, supaya animasi tidak tersendat
 * karena composition awal. Setelah tampil, konten tidak dibuang lagi (animasi keluar tetap utuh).
 */
@Composable
private fun AnimatedContentScope.DeferUntilSettled(content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    if (!shown && transition.currentState == transition.targetState) shown = true
    if (shown) content() else Box(Modifier.fillMaxSize().background(KuroBgPrimary))
}
