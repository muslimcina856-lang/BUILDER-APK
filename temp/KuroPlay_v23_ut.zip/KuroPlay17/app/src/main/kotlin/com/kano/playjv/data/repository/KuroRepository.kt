package com.kano.playjv.data.repository

import com.kano.playjv.BuildConfig
import com.kano.playjv.core.model.*
import com.kano.playjv.core.network.NetworkClient
import com.kano.playjv.data.local.*
import com.kano.playjv.data.remote.*
import com.kano.playjv.data.source.PencariNafkahApiSource
import com.kano.playjv.data.source.KanoApiSource
import com.kano.playjv.data.source.MangaDexSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class KuroRepository(
    private val dao: KuroDao,
    private val preferences: UserPreferences,
    private val authRepository: AuthRepository
) {
    /** Session pagination memakai endpoint server, bukan membagi seluruh katalog lokal. */
    private data class CatalogFeedSession(
        val items: MutableList<AnimeItem> = ArrayList(),
        val seenSourceUrls: MutableSet<String> = HashSet(),
        val seenMatchUrls: MutableSet<String> = HashSet(),
        val mutex: Mutex = Mutex(),
        var nextRemotePage: Int = 1,
        var remoteHasNext: Boolean = true,
        @Volatile var lastAccessAt: Long = System.currentTimeMillis()
    )

    private val feedSessionLock = Any()
    private val catalogFeedSessions = LinkedHashMap<String, CatalogFeedSession>(6, 0.75f, true)

    private suspend fun getCurrentUid(): String {
        return preferences.userProfileFlow.firstOrNull()?.uid ?: "guest_user"
    }

    suspend fun unlockEpisode(slug: String, ep: String): UnlockResult = authRepository.unlockEpisode(slug, ep)

    suspend fun grantAdKeys(): Result<Int> = authRepository.grantAdKeys()

    // ===== ANIME + DONGHUA (PencariNafkah API) =====
    suspend fun getAnimeList(
        action: String,
        page: Int = 1,
        mediaType: String = "anime"
    ): Result<List<AnimeItem>> = getAnimePage(action, null, page, mediaType).map { it.items }

    /**
     * Feed beranda dari get_videos. Satu kartu per serial; Anime dan Donghua selalu dipisah
     * berdasarkan token genre "Donghua" yang dikirim server.
     */
    suspend fun getLatestAnimeUpdates(mediaType: String): Result<List<AnimeItem>> = try {
        val items = PencariNafkahApiSource.getLatestUpdateCategories(maxPages = 4)
            .filter { matchesMediaType(it, mediaType) }
            .take(20)
        Result.success(items)
    } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "Gagal memuat update anime"))
    }

    suspend fun getAnimeGenres(): Result<List<String>> = try {
        val genres = PencariNafkahApiSource.getGenreIndex()
            .filterNot { it.equals("OnGoing", true) || it.equals("Donghua", true) }
            // Daftar genre dari server punya salah ketik ("Demonds", "Pyscological").
            .map { PencariNafkahApiSource.fixGenreName(it) }
            .distinctBy { it.lowercase() }
            .let { list -> if (list.any { it.equals("Hentai", true) }) list else list + "Hentai" }
        Result.success(genres)
    } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "Gagal memuat genre"))
    }

    /**
     * Halaman pertama memakai endpoint kategori yang memang dipaginasi server.
     * Ini menghindari unduhan katalog 5.946 judul hanya untuk menampilkan grid.
     */
    fun observeAnimePage(
        mode: String,
        genre: String?,
        mediaType: String = "anime"
    ): Flow<AnimePage> = flow {
        val result = getAnimePage(mode, genre, page = 1, mediaType = mediaType)
        emit(result.getOrThrow())
    }.flowOn(Dispatchers.IO)

    /**
     * Satu halaman = 10 judul (ANIME_PAGE_SIZE). Genre dipilih -> daftar diambil per halaman dari
     * endpoint genre; "Semua Genre" tetap memakai endpoint kategori Ongoing/Populer.
     * Halaman berikutnya dimuat saat daftar di-scroll sampai ujung bawah.
     */
    suspend fun getAnimePage(
        mode: String,
        genre: String?,
        page: Int,
        mediaType: String = "anime"
    ): Result<AnimePage> = try {
        Result.success(loadFeedPage(mode, genre, "", mediaType, page))
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "Gagal memuat daftar anime"))
    }

    /**
     * Pager per sesi (jenis media + mode + genre + kata kunci). Kursor halaman server hanya maju
     * setelah request sukses, hasil di-append unik, dan UI menerima potongan 10 judul per halaman.
     */
    private suspend fun loadFeedPage(
        mode: String,
        genre: String?,
        query: String,
        mediaType: String,
        page: Int
    ): AnimePage {
        val safePage = page.coerceAtLeast(1)
        val sessionKey = listOf(
            mediaType.lowercase(java.util.Locale.ROOT),
            mode.lowercase(java.util.Locale.ROOT),
            genre.orEmpty().trim().lowercase(java.util.Locale.ROOT),
            query.trim().lowercase(java.util.Locale.ROOT),
            com.kano.playjv.core.state.AdultContentGate.enabled.toString()
        ).joinToString("|")
        val session = getCatalogFeedSession(sessionKey)
        val requiredCount = (safePage.toLong() * ANIME_PAGE_SIZE)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        fillCatalogFeedSession(session, mode, genre, query, mediaType, requiredCount)

        return session.mutex.withLock {
            val start = ((safePage - 1L) * ANIME_PAGE_SIZE)
                .coerceAtMost(session.items.size.toLong()).toInt()
            val end = (start + ANIME_PAGE_SIZE).coerceAtMost(session.items.size)
            val pageItems = if (start < end) session.items.subList(start, end).toList() else emptyList()
            AnimePage(
                items = pageItems,
                hasNext = end < session.items.size || session.remoteHasNext
            )
        }
    }

    private fun getCatalogFeedSession(key: String): CatalogFeedSession = synchronized(feedSessionLock) {
        val now = System.currentTimeMillis()
        val iterator = catalogFeedSessions.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.lastAccessAt >= CATALOG_FEED_SESSION_TTL_MS && !entry.value.mutex.isLocked) {
                iterator.remove()
            }
        }
        catalogFeedSessions[key]?.also { it.lastAccessAt = now } ?: run {
            // Jaga jumlah kombinasi filter yang disimpan agar sesi lama tidak menumpuk di RAM.
            while (catalogFeedSessions.size >= MAX_CATALOG_FEED_SESSIONS) {
                val removable = catalogFeedSessions.entries.firstOrNull { !it.value.mutex.isLocked } ?: break
                catalogFeedSessions.remove(removable.key)
            }
            CatalogFeedSession().also { catalogFeedSessions[key] = it }
        }
    }

    /**
     * Genre yang dikirim ke server. Donghua dengan genre luas (Action, Fantasy, ...) lebih cepat
     * dicari lewat genre "Donghua" lalu disaring genre-nya, karena Donghua jauh lebih sedikit.
     */
    private fun listEngineGenre(genre: String?, query: String, mediaType: String): String? {
        val cleanGenre = genre?.trim().orEmpty()
        if (query.isNotBlank() || cleanGenre.isEmpty()) return cleanGenre.ifEmpty { null }
        val isDonghuaTab = mediaType.equals("donghua", true)
        return if (isDonghuaTab && cleanGenre.lowercase(java.util.Locale.ROOT) in BROAD_GENRE_KEYS) "Donghua" else cleanGenre
    }

    private suspend fun fillCatalogFeedSession(
        session: CatalogFeedSession,
        mode: String,
        genre: String?,
        query: String,
        mediaType: String,
        requiredCount: Int
    ) {
        session.mutex.withLock {
            session.lastAccessAt = System.currentTimeMillis()
            val useListEngine = query.isNotBlank() || !genre.isNullOrBlank()
            val endpointKind = when (mode.lowercase()) {
                "ongoing", "new", "latest" -> "new"
                "complete", "completed" -> "complete"
                "coming", "upcoming" -> "coming"
                "favorite", "favourite" -> "favorite"
                else -> "popular"
            }
            val serverGenre = if (useListEngine) listEngineGenre(genre, query, mediaType) else null

            var requests = 0
            while (session.items.size < requiredCount && session.remoteHasNext) {
                currentCoroutineContext().ensureActive()
                // Batas pengaman: tidak pernah memindai tanpa akhir.
                if (++requests > MAX_REMOTE_REQUESTS_PER_FILL) break
                val requestedPage = session.nextRemotePage
                val response = if (useListEngine) {
                    PencariNafkahApiSource.getCatalogListPage(
                        genre = serverGenre,
                        query = query,
                        page = requestedPage,
                        count = PencariNafkahApiSource.LIST_PAGE_SIZE
                    )
                } else {
                    PencariNafkahApiSource.getCategoryPage(
                        kind = endpointKind,
                        page = requestedPage,
                        count = REMOTE_CATEGORY_PAGE_SIZE
                    )
                }

                if (response.items.isEmpty()) {
                    session.remoteHasNext = false
                    break
                }

                var foundNewSourceItem = false
                response.items.forEach { item ->
                    if (item.url.isNotBlank() && session.seenSourceUrls.add(item.url)) {
                        foundNewSourceItem = true
                        if (matchesCatalogFilters(item, mode, genre, mediaType) &&
                            session.seenMatchUrls.add(item.url)
                        ) {
                            session.items.add(item)
                        }
                    }
                }

                // Jangan mengulang selamanya bila backend mengabaikan parameter page.
                session.nextRemotePage = requestedPage + 1
                session.remoteHasNext = response.hasNext && foundNewSourceItem
                session.lastAccessAt = System.currentTimeMillis()
            }
        }
    }

    private fun matchesCatalogFilters(
        item: AnimeItem,
        mode: String,
        genre: String?,
        mediaType: String
    ): Boolean {
        if (!matchesMediaType(item, mediaType)) return false
        val matchesStatus = when (mode.lowercase()) {
            "ongoing", "new" -> item.status.contains("ongoing", true)
            "complete", "completed" -> item.status.contains("complete", true)
            "coming", "upcoming" -> item.status.contains("coming", true) || item.status.contains("not yet", true)
            else -> true
        }
        if (!matchesStatus) return false
        return genre.isNullOrBlank() || PencariNafkahApiSource.itemHasGenre(item, genre)
    }

    /** Akses endpoint kategori asli untuk layar/fitur kategori tambahan di masa depan. */
    suspend fun getAnimeCategoryPage(
        category: String,
        page: Int = 1,
        mediaType: String = "anime"
    ): Result<AnimePage> = try {
        val response = PencariNafkahApiSource.getCategoryPage(category, page, REMOTE_CATEGORY_PAGE_SIZE)
        Result.success(AnimePage(response.items.filter { matchesMediaType(it, mediaType) }, response.hasNext))
    } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "Gagal memuat kategori anime"))
    }

    private fun matchesMediaType(item: AnimeItem, mediaType: String): Boolean {
        // Konten dewasa disaring di semua daftar bila saklar 18+ (Tentang) mati.
        if (!com.kano.playjv.core.state.AdultContentGate.enabled &&
            com.kano.playjv.core.state.AdultContentGate.isAdult(item.genre)
        ) return false
        val isDonghua = PencariNafkahApiSource.isDonghua(item)
        return if (mediaType.equals("donghua", true)) isDonghua else !isDonghua
    }

    /** Hasil halaman pertama pencarian (10 judul) langsung ditampilkan begitu halaman itu tiba. */
    fun observeSearchAnimePage(query: String, mediaType: String = "anime"): Flow<AnimePage> = flow {
        emit(searchAnimePage(query, 1, mediaType).getOrThrow())
    }.flowOn(Dispatchers.IO)

    /** Satu halaman (10 judul) hasil pencarian judul; halaman berikutnya diminta saat scroll mentok. */
    suspend fun searchAnimePage(
        query: String,
        page: Int = 1,
        mediaType: String = "anime"
    ): Result<AnimePage> = try {
        val normalized = query.trim()
        if (normalized.isBlank()) {
            Result.success(AnimePage(emptyList(), false))
        } else {
            Result.success(loadFeedPage("search", null, normalized, mediaType, page))
        }
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (e: Exception) {
        Result.failure(Exception(e.message ?: "Pencarian anime gagal"))
    }

    suspend fun searchAnime(query: String, page: Int = 1, mediaType: String = "anime"): Result<List<AnimeItem>> =
        searchAnimePage(query, page, mediaType).map { it.items }

    suspend fun getAnimeDetail(id: String): Result<AnimeDetail> {
        return try {
            Result.success(PencariNafkahApiSource.getAnimeDetail(id))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Detail anime tidak ditemukan"))
        }
    }

    suspend fun getAnimeStream(channelId: String): Result<EpisodeStreamData> {
        return try {
            Result.success(PencariNafkahApiSource.getEpisodeStreams(channelId))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Stream tidak ditemukan"))
        }
    }

    // ===== MANGA (kano-api dulu, jatuh ke MangaDex langsung bila gagal) =====
    private suspend fun <T> mangaCall(errMsg: String, kano: (suspend () -> T)?, direct: suspend () -> T): Result<T> {
        if (kano != null) {
            try { return Result.success(kano()) } catch (_: Exception) { /* fallback */ }
        }
        return try { Result.success(direct()) } catch (e: Exception) { Result.failure(Exception(e.message ?: errMsg)) }
    }

    suspend fun getLatestManga(): Result<List<MangaItem>> =
        mangaCall("Gagal memuat komik terbaru", { KanoApiSource.latest() }) { MangaDexSource.latest() }

    suspend fun getPopularManga(): Result<List<MangaItem>> =
        mangaCall("Gagal memuat komik populer", { KanoApiSource.popular() }) { MangaDexSource.popular() }

    suspend fun getRecommendedManga(): Result<List<MangaItem>> =
        mangaCall("Gagal memuat rekomendasi komik", { KanoApiSource.popular() }) { MangaDexSource.recommended() }

    suspend fun searchManga(query: String): Result<List<MangaItem>> =
        mangaCall("Pencarian komik gagal", { KanoApiSource.search(query).also { require(it.isNotEmpty()) } }) { MangaDexSource.search(query) }

    suspend fun getMangaDetail(idSeries: String): Result<MangaDetail> =
        mangaCall("Detail komik tidak ditemukan", { KanoApiSource.detail(idSeries) }) { MangaDexSource.detail(idSeries) }

    suspend fun getMangaChapterPages(idChapter: String): Result<MangaChapterPages> =
        mangaCall("Halaman chapter tidak ditemukan", { KanoApiSource.chapterPages(idChapter) }) { MangaDexSource.chapterPages(idChapter) }

    suspend fun getMangaGenres(): Result<List<MangaGenre>> =
        mangaCall("Gagal memuat genre", null) { MangaDexSource.genres() }

    suspend fun getMangaByGenre(genreId: String): Result<List<MangaItem>> =
        mangaCall("Gagal memuat genre komik", null) { MangaDexSource.byGenre(genreId) }

    // ===== LOCAL ROOM + FIRESTORE LIBRARY SYNC =====
    fun getAnimeHistoryFlow(uid: String): Flow<List<AnimeHistoryItem>> =
        dao.getAnimeHistoryFlow(uid).map { list -> list.map { it.toModel() } }

    fun getAnimeBookmarksFlow(uid: String): Flow<List<AnimeBookmarkItem>> =
        dao.getAnimeBookmarksFlow(uid).map { list -> list.map { it.toModel() } }

    fun isAnimeBookmarkedFlow(slug: String, uid: String): Flow<Boolean> =
        dao.isAnimeBookmarkedFlow(slug, uid)

    fun getMangaHistoryFlow(uid: String): Flow<List<MangaHistoryItem>> =
        dao.getMangaHistoryFlow(uid).map { list -> list.map { it.toModel() } }

    fun getMangaBookmarksFlow(uid: String): Flow<List<MangaBookmarkItem>> =
        dao.getMangaBookmarksFlow(uid).map { list -> list.map { it.toModel() } }

    fun isMangaBookmarkedFlow(idSeries: String, uid: String): Flow<Boolean> =
        dao.isMangaBookmarkedFlow(idSeries, uid)

    // Library disimpan lokal (Room) dan disinkronkan ke Firestore: users/{uid}/<koleksi>/{id}
    private val fs = NetworkClient.firestoreApi
    private val project = BuildConfig.FIREBASE_PROJECT_ID
    private val docBase get() = "projects/$project/databases/(default)/documents"

    private suspend fun session(): Pair<String, String>? {
        val token = authRepository.getValidToken() ?: return null
        val uid = preferences.userProfileFlow.firstOrNull()?.uid ?: return null
        return uid to "Bearer $token"
    }

    private suspend fun putDoc(collection: String, id: String, fields: Map<String, FsValue>) {
        val (uid, auth) = session() ?: return
        try {
            fs.setDocument(project, "users/$uid/$collection/${fsDocId(id)}", auth, FsDocument(fields = fields))
        } catch (_: Exception) {}
    }

    private suspend fun deleteDoc(collection: String, id: String) {
        val (uid, auth) = session() ?: return
        try {
            fs.commit(
                project, auth,
                FsCommitRequest(listOf(FsWrite(delete = "$docBase/users/$uid/$collection/${fsDocId(id)}")))
            )
        } catch (_: Exception) {}
    }

    private suspend fun clearCollection(collection: String) {
        val (uid, auth) = session() ?: return
        try {
            val docs = fs.listDocuments(project, "users/$uid/$collection", auth).documents.orEmpty()
            docs.mapNotNull { it.name }.chunked(100).forEach { chunk ->
                fs.commit(project, auth, FsCommitRequest(chunk.map { FsWrite(delete = it) }))
            }
        } catch (_: Exception) {}
    }

    private suspend fun listFields(collection: String, uid: String, auth: String): List<Map<String, FsValue>?> =
        fs.listDocuments(project, "users/$uid/$collection", auth).documents.orEmpty().map { it.fields }

    /** Ambil cover dari detail anime bila kosong (riwayat lama/baru). */
    private suspend fun resolveCover(item: AnimeHistoryItem): AnimeHistoryItem {
        if (item.cover.isNotBlank()) return item
        val cover = try { PencariNafkahApiSource.getAnimeDetail(item.slug).cover } catch (_: Exception) { "" }
        return if (cover.isNotBlank()) item.copy(cover = cover) else item
    }

    /** Isi cover riwayat yang masih kosong (dipanggil dari Beranda/Library). */
    suspend fun backfillHistoryCovers(items: List<AnimeHistoryItem>) {
        items.filter { it.cover.isBlank() }.take(8).forEach { recordAnimeHistoryRaw(resolveCover(it)) }
    }

    suspend fun recordAnimeHistory(item: AnimeHistoryItem) = recordAnimeHistoryRaw(resolveCover(item))

    private suspend fun recordAnimeHistoryRaw(item: AnimeHistoryItem) {
        if (item.cover.isBlank() && item.slug.isBlank()) return
        val uid = getCurrentUid()
        dao.insertAnimeHistory(AnimeHistoryEntity.fromModel(item, uid))
        dao.trimAnimeHistory(uid)
        putDoc(
            "animeHistory", item.slug,
            mapOf(
                "slug" to fsStr(item.slug), "title" to fsStr(item.title), "cover" to fsStr(item.cover),
                "lastEp" to fsStr(item.lastEp), "seriesUrl" to fsStr(item.seriesUrl),
                "timestamp" to fsLong(item.timestamp)
            )
        )
    }

    suspend fun toggleAnimeBookmark(item: AnimeBookmarkItem, isBookmarked: Boolean) {
        val uid = getCurrentUid()
        if (isBookmarked) {
            dao.deleteAnimeBookmark(item.slug, uid)
            deleteDoc("animeBookmarks", item.slug)
        } else {
            dao.insertAnimeBookmark(AnimeBookmarkEntity.fromModel(item, uid))
            putDoc(
                "animeBookmarks", item.slug,
                mapOf(
                    "slug" to fsStr(item.slug), "title" to fsStr(item.title), "cover" to fsStr(item.cover),
                    "timestamp" to fsLong(item.timestamp)
                )
            )
        }
    }

    suspend fun recordMangaHistory(item: MangaHistoryItem) {
        val uid = getCurrentUid()
        dao.insertMangaHistory(MangaHistoryEntity.fromModel(item, uid))
        dao.trimMangaHistory(uid)
        putDoc(
            "mangaHistory", item.id_series,
            mapOf(
                "id_series" to fsStr(item.id_series), "title" to fsStr(item.title), "image" to fsStr(item.image),
                "lastChapter" to fsDouble(item.lastChapter), "id_chapter" to fsStr(item.id_chapter),
                "time" to fsLong(item.time)
            )
        )
    }

    suspend fun toggleMangaBookmark(item: MangaBookmarkItem, isBookmarked: Boolean) {
        val uid = getCurrentUid()
        if (isBookmarked) {
            dao.deleteMangaBookmark(item.id_series, uid)
            deleteDoc("mangaBookmarks", item.id_series)
        } else {
            dao.insertMangaBookmark(MangaBookmarkEntity.fromModel(item, uid))
            putDoc(
                "mangaBookmarks", item.id_series,
                mapOf(
                    "id_series" to fsStr(item.id_series), "title" to fsStr(item.title), "image" to fsStr(item.image),
                    "timestamp" to fsLong(item.timestamp)
                )
            )
        }
    }

    suspend fun syncLibraryFromServer(): Result<Unit> {
        val (uid, auth) = session() ?: return Result.failure(Exception("Belum login"))
        return try {
            val animeHistory = listFields("animeHistory", uid, auth).map { f ->
                AnimeHistoryItem(
                    slug = f.getStr("slug"), title = f.getStr("title"), cover = f.getStr("cover"),
                    lastEp = f.getStr("lastEp"), seriesUrl = f.getStr("seriesUrl"), timestamp = f.getLong("timestamp")
                )
            }.filter { it.slug.isNotBlank() }
            val animeBookmarks = listFields("animeBookmarks", uid, auth).map { f ->
                AnimeBookmarkItem(
                    slug = f.getStr("slug"), title = f.getStr("title"), cover = f.getStr("cover"),
                    timestamp = f.getLong("timestamp")
                )
            }.filter { it.slug.isNotBlank() }
            val mangaHistory = listFields("mangaHistory", uid, auth).map { f ->
                MangaHistoryItem(
                    id_series = f.getStr("id_series"), title = f.getStr("title"), image = f.getStr("image"),
                    lastChapter = f.getDouble("lastChapter"), id_chapter = f.getStr("id_chapter"), time = f.getLong("time")
                )
            }.filter { it.id_series.isNotBlank() }
            val mangaBookmarks = listFields("mangaBookmarks", uid, auth).map { f ->
                MangaBookmarkItem(
                    id_series = f.getStr("id_series"), title = f.getStr("title"), image = f.getStr("image"),
                    timestamp = f.getLong("timestamp")
                )
            }.filter { it.id_series.isNotBlank() }

            dao.insertAllAnimeHistory(animeHistory.map { AnimeHistoryEntity.fromModel(it, uid) })
            dao.trimAnimeHistory(uid)
            dao.insertAllAnimeBookmarks(animeBookmarks.map { AnimeBookmarkEntity.fromModel(it, uid) })
            dao.insertAllMangaHistory(mangaHistory.map { MangaHistoryEntity.fromModel(it, uid) })
            dao.trimMangaHistory(uid)
            dao.insertAllMangaBookmarks(mangaBookmarks.map { MangaBookmarkEntity.fromModel(it, uid) })
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("Gagal sinkron library: ${e.message}"))
        }
    }

    suspend fun deleteAnimeHistory(slug: String) {
        dao.deleteAnimeHistory(slug, getCurrentUid())
        deleteDoc("animeHistory", slug)
    }

    suspend fun deleteMangaHistory(idSeries: String) {
        dao.deleteMangaHistory(idSeries, getCurrentUid())
        deleteDoc("mangaHistory", idSeries)
    }

    suspend fun clearHistory(which: String) {
        val uid = getCurrentUid()
        when (which) {
            "anime" -> {
                dao.clearAnimeHistory(uid)
                clearCollection("animeHistory")
            }
            "manga" -> {
                dao.clearMangaHistory(uid)
                clearCollection("mangaHistory")
            }
            else -> {
                dao.clearAnimeHistory(uid)
                dao.clearMangaHistory(uid)
                clearCollection("animeHistory")
                clearCollection("mangaHistory")
            }
        }
    }
}

data class AnimePage(
    val items: List<AnimeItem>,
    val hasNext: Boolean,
    val isComplete: Boolean = true
)

/** 1 halaman daftar genre / hasil pencarian = 10 judul. */
private const val ANIME_PAGE_SIZE = 10
private const val REMOTE_CATEGORY_PAGE_SIZE = 20
private const val MAX_REMOTE_REQUESTS_PER_FILL = 80
private val BROAD_GENRE_KEYS = setOf(
    "action", "fantasy", "comedy", "adventure", "romance", "drama", "sci-fi", "supernatural"
)
private const val MAX_CATALOG_FEED_SESSIONS = 5
private const val CATALOG_FEED_SESSION_TTL_MS = 10 * 60_000L
