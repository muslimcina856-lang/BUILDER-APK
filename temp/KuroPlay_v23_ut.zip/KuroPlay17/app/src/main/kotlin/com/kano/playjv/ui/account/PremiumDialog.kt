package com.kano.playjv.ui.account

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.KuroContainedLoadingState
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.source.PremiumClient
import com.kano.playjv.data.source.PremiumOrder
import com.kano.playjv.data.source.PremiumPlan
import com.kano.playjv.ui.theme.KuroError
import com.kano.playjv.ui.theme.KuroSurfaceElevated
import com.kano.playjv.ui.theme.KuroTextPrimary
import com.kano.playjv.ui.theme.KuroTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun rupiah(amount: Int): String {
    val digits = amount.toString().reversed()
    return "Rp" + digits.chunked(3).joinToString(".").reversed()
}

/** Dialog Premium: pilih paket, tampilkan QRIS, lalu periksa status ke server. */
@Composable
fun PremiumDialog(
    authRepository: AuthRepository,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var plans by remember { mutableStateOf(PremiumClient.fallbackPlans) }
    var order by remember { mutableStateOf<PremiumOrder?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }

    // Muat paket dari backend. Tidak memakai harga fallback buatan di aplikasi.
    LaunchedEffect(Unit) {
        try {
            plans = PremiumClient.plans()
            if (plans.isEmpty()) {
                message = "Paket Premium belum tersedia saat ini."
            }
        } catch (error: Exception) {
            plans = PremiumClient.fallbackPlans
            message = error.message ?: "Gagal memuat paket Premium."
        }
    }

    // Periksa status order setiap 4 detik selama dialog masih aktif.
    LaunchedEffect(order?.orderId) {
        val currentOrder = order ?: return@LaunchedEffect

        while (!done) {
            delay(4_000)

            if (currentOrder.expiresAt > 0L &&
                System.currentTimeMillis() >= currentOrder.expiresAt
            ) {
                order = null
                message = "Pesanan kedaluwarsa. Silakan pilih paket lagi."
                break
            }

            val token = authRepository.getValidToken()
            if (token.isNullOrBlank()) {
                message = "Sesi login berakhir. Login ulang untuk memeriksa pembayaran."
                break
            }

            val state = try {
                PremiumClient.check(currentOrder.orderId, token)
            } catch (_: Exception) {
                // Gangguan jaringan bukan bukti pembayaran berhasil atau gagal.
                "pending"
            }

            when (state) {
                "paid" -> {
                    val refreshedProfile = authRepository.refreshProfile().getOrNull()
                    val premiumIsActive = refreshedProfile?.isOwner == true ||
                        refreshedProfile?.premium?.active == true

                    done = true
                    message = if (premiumIsActive) {
                        "Pembayaran berhasil, Premium sudah aktif!"
                    } else {
                        "Pembayaran telah dikonfirmasi server, tetapi status Premium belum tercatat di akun. Silakan hubungi admin."
                    }
                }

                "expired" -> {
                    order = null
                    message = "Pesanan kedaluwarsa. Silakan pilih paket lagi."
                    break
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = {
            if (!busy) onDismiss()
        },
        containerColor = KuroSurfaceElevated,
        title = {
            Text(
                text = "Premium",
                fontWeight = FontWeight.Bold,
                color = KuroTextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (done) {
                    Text(message.orEmpty(), color = KuroTextPrimary)
                } else if (order == null) {
                    Text(
                        text = "Nonton semua episode tanpa batas kunci.",
                        fontSize = 13.sp,
                        color = KuroTextSecondary
                    )

                    if (plans.isEmpty()) {
                        Text(
                            text = message ?: "Paket Premium belum tersedia.",
                            color = KuroError,
                            fontSize = 12.sp
                        )
                    } else {
                        plans.forEach { plan: PremiumPlan ->
                            OutlinedButton(
                                enabled = !busy,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    scope.launch {
                                        busy = true
                                        message = null

                                        try {
                                            val token = authRepository.getValidToken()
                                            if (token.isNullOrBlank()) {
                                                message = "Sesi habis, silakan login ulang."
                                            } else {
                                                order = PremiumClient.create(plan.id, token)
                                            }
                                        } catch (error: Exception) {
                                            message = error.message ?: "Gagal membuat pesanan."
                                        } finally {
                                            busy = false
                                        }
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(plan.label, color = KuroTextPrimary)
                                    Text(
                                        text = rupiah(plan.price),
                                        color = KuroTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (busy) {
                        KuroContainedLoadingState(
                            statusText = "Membuat pesanan...",
                            modifier = Modifier.fillMaxWidth(),
                            indicatorSize = 44.dp
                        )
                    }
                    message?.let { text ->
                        Text(text, color = KuroError, fontSize = 12.sp)
                    }
                } else {
                    val currentOrder = order!!

                    Text(
                        text = "${currentOrder.planLabel} • ${rupiah(currentOrder.amount)}",
                        fontWeight = FontWeight.Bold,
                        color = KuroTextPrimary
                    )
                    Text(
                        text = "Scan QRIS dengan aplikasi bank/e-wallet. Status dicek otomatis.",
                        fontSize = 12.sp,
                        color = KuroTextSecondary
                    )

                    if (currentOrder.qrisImage.isNotBlank()) {
                        AsyncImage(
                            model = currentOrder.qrisImage,
                            contentDescription = "QRIS pembayaran",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .size(220.dp)
                                .align(Alignment.CenterHorizontally)
                        )
                    } else {
                        Text(
                            text = "QRIS tidak tersedia. Gunakan halaman pembayaran.",
                            color = KuroTextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    if (currentOrder.paymentUrl.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(currentOrder.paymentUrl)
                                )
                                context.startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Buka halaman pembayaran")
                        }
                    }

                    KuroContainedLoadingState(
                        statusText = "Menunggu pembayaran…",
                        modifier = Modifier.fillMaxWidth(),
                        indicatorSize = 40.dp
                    )

                    message?.let { text ->
                        Text(text, color = KuroError, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    if (!busy) onDismiss()
                }
            ) {
                Text(
                    text = if (done) "Selesai" else "Tutup",
                    color = KuroTextPrimary
                )
            }
        }
    )
}
