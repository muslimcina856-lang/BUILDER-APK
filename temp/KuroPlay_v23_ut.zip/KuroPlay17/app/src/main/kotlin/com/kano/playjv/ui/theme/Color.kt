package com.kano.playjv.ui.theme

import androidx.compose.ui.graphics.Color

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — BLACK / GRAY GRADIENT PALETTE
//  Seed: achromatic dark (no hue bias). Every token maps to an MD3 role.
// ─────────────────────────────────────────────────────────────────────────────

// ── Primary ──────────────────────────────────────────────────────────────────
val KuroPrimary              = Color(0xFFEAEAEA)   // near-white primary on dark
val KuroOnPrimary            = Color(0xFF0F0F0F)   // text on primary
val KuroPrimaryContainer     = Color(0xFF272727)   // subtle elevated container
val KuroOnPrimaryContainer   = Color(0xFFF2F2F2)   // text on container

// ── Secondary ────────────────────────────────────────────────────────────────
val KuroSecondary            = Color(0xFFBBBBBB)   // mid-gray
val KuroOnSecondary          = Color(0xFF0F0F0F)
val KuroSecondaryContainer   = Color(0xFF303030)
val KuroOnSecondaryContainer = Color(0xFFE2E2E2)

// ── Tertiary ─────────────────────────────────────────────────────────────────
val KuroTertiary             = Color(0xFF8E8E8E)   // graphite
val KuroOnTertiary           = Color(0xFF111111)
val KuroTertiaryContainer    = Color(0xFF232323)
val KuroOnTertiaryContainer  = Color(0xFFD0D0D0)

// ── Error ────────────────────────────────────────────────────────────────────
val KuroErrorColor           = Color(0xFFFF5252)
val KuroOnError              = Color(0xFF000000)
val KuroErrorContainer       = Color(0xFF3D0F0F)
val KuroOnErrorContainer     = Color(0xFFFF8A80)

// ── Background ───────────────────────────────────────────────────────────────
val KuroBgPrimary            = Color(0xFF080808)   // true black — MD3 background
val KuroOnBackground         = Color(0xFFF5F5F5)

// ── Surface tier system (MD3 Expressive) ─────────────────────────────────────
val KuroSurfaceDim                 = Color(0xFF0C0C0C)
val KuroSurface                    = Color(0xFF111111)   // base surface
val KuroSurfaceBright              = Color(0xFF252525)
val KuroSurfaceContainerLowest     = Color(0xFF090909)
val KuroSurfaceContainerLow        = Color(0xFF131313)
val KuroSurfaceContainer           = Color(0xFF1A1A1A)
val KuroSurfaceContainerHigh       = Color(0xFF202020)
val KuroSurfaceContainerHighest    = Color(0xFF282828)

// Surface variant & outline
val KuroSurfaceVariant       = Color(0xFF2A2A2A)
val KuroOnSurface            = Color(0xFFF0F0F0)
val KuroOnSurfaceVariant     = Color(0xFFAAAAAA)

// ── Outline ──────────────────────────────────────────────────────────────────
val KuroOutline              = Color(0xFF444444)
val KuroOutlineVariant       = Color(0xFF2E2E2E)

// Scrim / inverse
val KuroScrim                = Color(0xFF000000)
val KuroInverseSurface       = Color(0xFFEEEEEE)
val KuroInverseOnSurface     = Color(0xFF1C1C1C)
val KuroInversePrimary       = Color(0xFF3D3D3D)

// ── Gradient tokens (black → gray) ───────────────────────────────────────────
val KuroGradientBlack        = Color(0xFF080808)
val KuroGradientDark         = Color(0xFF161616)
val KuroGradientMid          = Color(0xFF242424)
val KuroGradientLight        = Color(0xFF343434)

// ── Text ─────────────────────────────────────────────────────────────────────
val KuroTextPrimary          = Color(0xFFF5F5F5)
val KuroTextSecondary        = Color(0xFFA0A0A0)
val KuroTextTertiary         = Color(0xFF626262)

// ── Semantic / accent ────────────────────────────────────────────────────────
val KuroGold                 = Color(0xFFFFD700)
val KuroGoldContainer        = Color(0xFF2A2000)
val KuroSuccess              = Color(0xFF81C784)
val KuroSuccessContainer     = Color(0xFF1A3320)
val KuroError                = KuroErrorColor   // compat alias

// ── Legacy compatibility aliases (used across existing screens) ───────────────
val KuroBgSecondary          = KuroSurfaceContainerLow
val KuroSurfaceElevated      = KuroSurfaceContainerHigh
val KuroBorder               = KuroOutlineVariant
val KuroAccent               = KuroPrimary
val KuroAccentSecondary      = KuroSecondary
