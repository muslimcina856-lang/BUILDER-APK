package com.kano.playjv.ui.account

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.KuroContainedLoadingState
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.source.PremiumClient
import com.kano.playjv.data.source.PremiumOrder
import com.kano.playjv.data.source.PremiumPlan
import com.kano.playjv.ui.theme.KuroBgPrimary
import com.kano.playjv.ui.theme.KuroBorder
import com.kano.playjv.ui.theme.KuroError
import com.kano.playjv.ui.theme.KuroSuccess
import com.kano.playjv.ui.theme.KuroSurface
import com.kano.playjv.ui.theme.KuroSurfaceElevated
import com.kano.playjv.ui.theme.KuroTextPrimary
import com.kano.playjv.ui.theme.KuroTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private val VerifiedBlue = Color(0xFF1D9BF0)

/** Centang biru untuk akun Premium. */
@Composable
fun VerifiedBadge(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 18.dp) {
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(VerifiedBlue),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Premium",
            tint = Color.White,
            modifier = Modifier.size(size * 0.66f)
        )
    }
}

/** Sisa hari premium dengan 2 desimal, mis. "5,47". */
fun premiumDaysLabel(expiresAt: Long, fallbackDays: Int): String {
    val days = if (expiresAt > 0L) {
        ((expiresAt - System.currentTimeMillis()).coerceAtLeast(0L)) / 86_400_000.0
    } else fallbackDays.toDouble()
    return String.format(Locale("id", "ID"), "%.2f", days)
}

private fun rupiahFmt(amount: Int): String =
    "Rp " + amount.toString().reversed().chunked(3).joinToString(".").reversed()

/** Halaman pembelian Premium: kartu akun, daftar paket, fitur. Pembayaran lewat QRIS. */
@Composable
fun PremiumScreen(
    authRepository: AuthRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by authRepository.userProfileFlow.collectAsState(initial = null)

    var plans by remember { mutableStateOf(PremiumClient.fallbackPlans) }
    var plansError by remember { mutableStateOf<String?>(null) }
    var order by remember { mutableStateOf<PremiumOrder?>(null) }
    var busyPlanId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val loaded = PremiumClient.plans()
            plans = loaded
            if (loaded.isEmpty()) plansError = "Paket Premium belum tersedia saat ini."
        } catch (e: Exception) {
            plans = PremiumClient.fallbackPlans
            plansError = e.message ?: "Gagal memuat paket Premium."
        }
    }
    LaunchedEffect(plans) {
        if (selectedId == null) selectedId = (plans.getOrNull(2) ?: plans.firstOrNull())?.id
    }

    // Cek status pembayaran tiap 4 detik selama ada pesanan aktif.
    LaunchedEffect(order?.orderId) {
        val current = order ?: return@LaunchedEffect
        while (!done) {
            delay(4_000)
            if (current.expiresAt > 0L && System.currentTimeMillis() >= current.expiresAt) {
                order = null
                message = "Pesanan kedaluwarsa. Silakan pilih paket lagi."
                break
            }
            val token = authRepository.getValidToken()
            if (token.isNullOrBlank()) {
                message = "Sesi login berakhir. Login ulang untuk memeriksa pembayaran."
                break
            }
            val state = try { PremiumClient.check(current.orderId, token) } catch (_: Exception) { "pending" }
            when (state) {
                "paid" -> {
                    val refreshed = authRepository.refreshProfile().getOrNull()
                    val active = refreshed?.isOwner == true || refreshed?.premium?.active == true
                    done = true
                    message = if (active) "Pembayaran berhasil, Premium sudah aktif!"
                    else "Pembayaran dikonfirmasi server, tetapi status Premium belum tercatat di akun. Hubungi admin."
                }
                "expired" -> {
                    order = null
                    message = "Pesanan kedaluwarsa. Silakan pilih paket lagi."
                    break
                }
            }
        }
    }

    val profile = user
    val unlimited = profile?.isOwner == true || profile?.premium?.active == true
    val basePerMonth = plans.firstOrNull()?.let { it.price.toDouble() / (it.days / 30.0) }

    Box(modifier = Modifier.fillMaxSize().background(KuroBgPrimary)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = KuroTextPrimary)
                }
                Text("KuroPlay Premium", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = KuroTextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Pilih paket premium kamu, tenang ini bukan berlangganan",
                    fontSize = 13.sp, color = KuroTextSecondary
                )
            }

            // Kartu akun + sisa premium
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = KuroSurface,
                    border = BorderStroke(1.dp, KuroBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(shape = CircleShape, color = KuroSurfaceElevated, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    profile?.username?.firstOrNull()?.uppercase() ?: "U",
                                    fontWeight = FontWeight.Bold, color = KuroTextPrimary
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(profile?.username ?: "-", fontWeight = FontWeight.Bold, color = KuroTextPrimary, fontSize = 16.sp)
                                if (unlimited) VerifiedBadge(size = 16.dp)
                            }
                            Text(
                                if (profile?.isOwner == true) "Owner" else if (unlimited) "Member Premium" else "Member",
                                fontSize = 12.sp, color = KuroTextSecondary
                            )
                        }
                        Surface(shape = RoundedCornerShape(24.dp), color = VerifiedBlue) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (profile?.isOwner == true) {
                                    Text("∞", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                } else if (profile?.premium?.active == true) {
                                    Text(
                                        premiumDaysLabel(profile.premium.expiresAt, profile.premium.daysLeft),
                                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                                    )
                                } else {
                                    Text("0", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                Text("Sisa Premium", color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Paket
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = KuroSurface,
                    border = BorderStroke(1.dp, KuroBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Pilih Paket", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = KuroTextPrimary)
                        if (plans.isEmpty()) {
                            Text(plansError ?: "Paket Premium belum tersedia.", color = KuroError, fontSize = 12.sp)
                        }
                        plans.forEachIndexed { index, plan: PremiumPlan ->
                            val selected = plan.id == selectedId
                            val saving = basePerMonth?.let {
                                val full = it * (plan.days / 30.0)
                                if (full > 0) ((1 - plan.price / full) * 100).toInt() else 0
                            } ?: 0
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (selected) VerifiedBlue.copy(alpha = 0.14f) else KuroBgPrimary,
                                border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) VerifiedBlue else KuroBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = busyPlanId == null) {
                                        selectedId = plan.id
                                        scope.launch {
                                            busyPlanId = plan.id
                                            message = null
                                            try {
                                                val token = authRepository.getValidToken()
                                                if (token.isNullOrBlank()) message = "Sesi habis, silakan login ulang."
                                                else order = PremiumClient.create(plan.id, token)
                                            } catch (e: Exception) {
                                                message = e.message ?: "Gagal membuat pesanan."
                                            } finally {
                                                busyPlanId = null
                                            }
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(plan.label, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = KuroTextPrimary)
                                            if (index == 2 && plans.size >= 3) {
                                                Surface(shape = RoundedCornerShape(8.dp), color = VerifiedBlue) {
                                                    Text("Best", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                                }
                                            }
                                        }
                                        Text("${plan.days} hari premium", fontSize = 12.sp, color = KuroTextSecondary)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        if (busyPlanId == plan.id) {
                                            Text("Memproses…", fontSize = 13.sp, color = KuroTextSecondary)
                                        } else {
                                            Text(rupiahFmt(plan.price), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = KuroTextPrimary)
                                            if (saving > 0) {
                                                Text("Hemat $saving%", fontSize = 12.sp, color = KuroSuccess, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        message?.let { Text(it, color = if (done) KuroSuccess else KuroError, fontSize = 12.sp) }
                    }
                }
            }

            // Fitur
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = KuroSurface,
                    border = BorderStroke(1.dp, KuroBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Fitur Premium", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = KuroTextPrimary)
                        listOf(
                            "Centang biru di profil",
                            "Key tak terbatas (∞)",
                            "Buka semua episode tanpa kunci",
                            "Tanpa nonton iklan reward"
                        ).forEach { f ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = VerifiedBlue, modifier = Modifier.size(18.dp))
                                Text(f, color = KuroTextPrimary, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog QRIS setelah pesanan dibuat
    val currentOrder = order
    if (currentOrder != null || done) {
        AlertDialog(
            onDismissRequest = { if (done) { order = null; done = false } },
            containerColor = KuroSurfaceElevated,
            title = { Text(if (done) "Premium" else "Bayar dengan QRIS", fontWeight = FontWeight.Bold, color = KuroTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (done) {
                        Text(message.orEmpty(), color = KuroTextPrimary)
                    } else if (currentOrder != null) {
                        Text("${currentOrder.planLabel} • ${rupiahFmt(currentOrder.amount)}", fontWeight = FontWeight.Bold, color = KuroTextPrimary)
                        Text("Scan QRIS dengan aplikasi bank/e-wallet. Status dicek otomatis.", fontSize = 12.sp, color = KuroTextSecondary)
                        if (currentOrder.qrisImage.isNotBlank()) {
                            AsyncImage(
                                model = currentOrder.qrisImage,
                                contentDescription = "QRIS pembayaran",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(220.dp).align(Alignment.CenterHorizontally)
                            )
                        } else {
                            Text("QRIS tidak tersedia. Gunakan halaman pembayaran.", color = KuroTextSecondary, fontSize = 12.sp)
                        }
                        if (currentOrder.paymentUrl.isNotBlank()) {
                            OutlinedButton(
                                onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentOrder.paymentUrl))) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Buka halaman pembayaran") }
                        }
                        KuroContainedLoadingState(
                            statusText = "Menunggu pembayaran…",
                            modifier = Modifier.fillMaxWidth(),
                            indicatorSize = 40.dp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { order = null; if (done) { done = false; onBack() } }) {
                    Text(if (done) "Selesai" else "Tutup", color = KuroTextPrimary)
                }
            }
        )
    }
}
