package com.kano.playjv.core.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.R
import com.kano.playjv.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — TOP APP BAR
//  Uses CenterAlignedTopAppBar with tonal surface and gradient underline.
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KuroTopBar(
    title: String = "KuroPlay",
    keysLabel: String? = null,
    onKeysClick: (() -> Unit)? = null,
    onSearchClick: (() -> Unit)? = null
) {
    Surface(
        color = KuroSurfaceContainerLow,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // ── Logo + title ──────────────────────────────────────────────
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = KuroSurfaceContainerHigh,
                        tonalElevation = 2.dp,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.kuro_icon),
                            contentDescription = "KuroPlay Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(10.dp))
                        )
                    }
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.sp
                        ),
                        color = KuroTextPrimary
                    )
                }

                // ── Actions ───────────────────────────────────────────────────
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (keysLabel != null && onKeysClick != null) {
                        // MD3 Expressive: FilledTonalButton shape = extraLarge
                        Surface(
                            color = KuroGoldContainer,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .clickable { onKeysClick() }
                                .testTag("topbar_keys_chip")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VpnKey,
                                    contentDescription = "Keys",
                                    tint = KuroGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = keysLabel,
                                    color = KuroGold,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }

                    if (onSearchClick != null) {
                        // MD3 Expressive: IconButton with container
                        FilledTonalIconButton(
                            onClick = onSearchClick,
                            shape = RoundedCornerShape(14.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = KuroSurfaceContainerHigh,
                                contentColor   = KuroTextPrimary
                            ),
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("topbar_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // ── Gradient divider (MD3 Expressive flair) ───────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                KuroOutlineVariant,
                                KuroOutlineVariant,
                                Color.Transparent
                            )
                        )
                    )
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — NAVIGATION BAR
//  Pill-shaped indicator, rounded top corners, tonal surface.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun KuroBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    val topCorner = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)

    Surface(
        color = KuroSurfaceContainerLow,
        shape = topCorner,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(topCorner)
    ) {
        Column {
            // ── Gradient divider ──────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                KuroOutlineVariant,
                                KuroOutlineVariant,
                                Color.Transparent
                            )
                        )
                    )
            )

            NavigationBar(
                containerColor    = Color.Transparent,
                contentColor      = KuroTextSecondary,
                tonalElevation    = 0.dp,
                modifier          = Modifier.fillMaxWidth()
            ) {
                val items = listOf(
                    NavigationItem("beranda", "Beranda",
                        Icons.Default.Home,        Icons.Outlined.Home),
                    NavigationItem("search",  "Cari",
                        Icons.Default.Search,      Icons.Outlined.Search),
                    NavigationItem("manga",   "Manga",
                        Icons.Default.AutoStories, Icons.Outlined.AutoStories),
                    NavigationItem("library", "Library",
                        Icons.Default.Bookmark,    Icons.Outlined.BookmarkBorder),
                    NavigationItem("akun",    "Tentang",
                        Icons.Default.Info,        Icons.Outlined.Info)
                )

                items.forEach { item ->
                    val selected = currentRoute == item.route
                    NavigationBarItem(
                        selected = selected,
                        onClick  = { onNavigate(item.route) },
                        icon = {
                            Icon(
                                imageVector = if (selected) item.selectedIcon
                                              else          item.unselectedIcon,
                                contentDescription = item.label,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text       = item.label,
                                style      = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (selected) FontWeight.Bold
                                               else FontWeight.Normal
                                )
                            )
                        },
                        // MD3 Expressive: pill indicator, tonal on/off colors
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor   = KuroOnPrimary,
                            selectedTextColor   = KuroTextPrimary,
                            unselectedIconColor = KuroTextTertiary,
                            unselectedTextColor = KuroTextTertiary,
                            indicatorColor      = KuroPrimary
                        ),
                        modifier = Modifier.testTag("nav_item_${item.route}")
                    )
                }
            }
        }
    }
}

data class NavigationItem(
    val route: String,
    val label: String,
    val selectedIcon:   androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — SHIMMER BRUSH
//  Multi-stop gradient sweep for richer skeleton skeleton effect.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun shimmerBrush(): Brush {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue  = 1400f,
        animationSpec = infiniteRepeatable(
            animation  = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )
    return Brush.linearGradient(
        colors = listOf(
            KuroSurfaceContainerLow,
            KuroSurfaceContainer,
            KuroSurfaceContainerHigh,
            KuroSurfaceContainer,
            KuroSurfaceContainerLow
        ),
        start = Offset(0f, 0f),
        end   = Offset(translateAnim, translateAnim * 0.3f)
    )
}

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — SKELETON CARD
//  ElevatedCard base, gradient shimmer, expressive rounded shape.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun SkeletonCard(
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 190.dp
) {
    val brush = shimmerBrush()
    ElevatedCard(
        shape  = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = KuroSurfaceContainerLow
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.dp),
        modifier  = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ── Image placeholder ─────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(brush)
            )

            // ── Text lines ───────────────────────────────────────────────────
            Column(
                modifier = Modifier.padding(
                    horizontal = 10.dp, vertical = 10.dp
                ),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.82f)
                        .height(13.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(brush)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.54f)
                        .height(11.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(brush)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — ERROR STATE
//  ElevatedCard container, FilledTonalButton retry, spring icon pop-in.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ErrorStateView(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp)
            .testTag("error_state_view"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // ── Icon in tonal container ───────────────────────────────────────────
        Surface(
            shape  = RoundedCornerShape(24.dp),
            color  = KuroErrorContainer,
            modifier = Modifier.size(72.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector   = Icons.Default.CloudOff,
                    contentDescription = "Error",
                    tint          = KuroOnErrorContainer,
                    modifier      = Modifier.size(32.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text  = "Gagal Memuat Konten",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = KuroTextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text  = message,
            style = MaterialTheme.typography.bodyMedium,
            color = KuroTextSecondary,
            textAlign = TextAlign.Center,
            modifier  = Modifier.widthIn(max = 260.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // MD3 Expressive: FilledTonalButton with large shape
        FilledTonalButton(
            onClick = onRetry,
            shape   = RoundedCornerShape(20.dp),
            colors  = ButtonDefaults.filledTonalButtonColors(
                containerColor = KuroSurfaceContainerHigh,
                contentColor   = KuroTextPrimary
            ),
            modifier = Modifier
                .height(44.dp)
                .testTag("error_retry_button")
        ) {
            Icon(
                imageVector   = Icons.Default.Refresh,
                contentDescription = null,
                modifier      = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Coba Lagi",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — EMPTY STATE
//  Centered, minimal — icon in tonal surface, body text below.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun EmptyStateView(
    message: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Inbox,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp)
            .testTag("empty_state_view"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape    = RoundedCornerShape(20.dp),
            color    = KuroSurfaceContainerHigh,
            modifier = Modifier.size(60.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector   = icon,
                    contentDescription = "Empty",
                    tint          = KuroTextTertiary,
                    modifier      = Modifier.size(26.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text     = message,
            style    = MaterialTheme.typography.bodyMedium,
            color    = KuroTextSecondary,
            textAlign = TextAlign.Center,
            modifier  = Modifier.widthIn(max = 220.dp)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MD3 EXPRESSIVE — STATUS BADGE
//  Chip-style label with subtle tonal container and soft outline.
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun StatusBadge(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = KuroSurfaceContainerHigh
) {
    Surface(
        color    = color,
        shape    = RoundedCornerShape(6.dp),
        border   = androidx.compose.foundation.BorderStroke(
            width = 0.5.dp,
            color = KuroOutlineVariant
        ),
        modifier = modifier
    ) {
        Text(
            text     = text,
            color    = KuroTextPrimary,
            style    = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.3.sp
            ),
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}
