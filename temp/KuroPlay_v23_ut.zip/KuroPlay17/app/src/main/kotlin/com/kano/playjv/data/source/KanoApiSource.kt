package com.kano.playjv.data.source

import com.kano.playjv.core.model.MangaChapterItem
import com.kano.playjv.core.model.MangaChapterPages
import com.kano.playjv.core.model.MangaDetail
import com.kano.playjv.core.model.MangaInfo
import com.kano.playjv.core.model.MangaItem
import com.kano.playjv.core.model.MangaLatestChapter
import com.kano.playjv.core.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Sumber manga dari API buatan sendiri (kano-api, data asal MangaDex).
 * Parser dibuat toleran terhadap beberapa bentuk respons; bila gagal, repository
 * otomatis jatuh ke MangaDexSource.
 *
 * Catatan: API key di aplikasi bisa diekstrak dari APK. Gunakan key khusus aplikasi
 * yang bisa dicabut/dibatasi di dashboard.
 */
object KanoApiSource {
    const val BASE = "https://api.kano-api.abrdns.com"
    private const val API_KEY = "kano_7c5fe9c347064354af10d0fab143e552"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun getJson(path: String): Any = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(BASE + path)
            .header("Accept", "application/json")
            .header("X-API-Key", API_KEY)
            .header("Authorization", "Bearer $API_KEY")
            .build()
        NetworkClient.httpClient.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty().trim()
            if (!res.isSuccessful) throw Exception("kano-api HTTP ${res.code}")
            if (text.startsWith("<")) throw Exception("kano-api membalas HTML")
            if (text.startsWith("[")) JSONArray(text) else JSONObject(text)
        }
    }

    private fun JSONObject.s(vararg keys: String): String {
        for (k in keys) if (has(k) && !isNull(k)) {
            val v = opt(k)
            if (v is String && v.isNotBlank()) return v
            if (v is Number) return v.toString().removeSuffix(".0")
        }
        return ""
    }

    private fun payload(root: Any): Any {
        if (root is JSONObject) {
            for (k in listOf("data", "result", "results", "items")) {
                if (root.has(k) && !root.isNull(k)) return root.get(k)
            }
        }
        return root
    }

    private fun asArray(root: Any): JSONArray {
        val p = payload(root)
        if (p is JSONArray) return p
        if (p is JSONObject) {
            for (k in listOf("data", "results", "items", "list", "manga", "komik")) {
                p.optJSONArray(k)?.let { return it }
            }
        }
        return JSONArray()
    }

    private fun mapItem(o: JSONObject): MangaItem {
        val chs = mutableListOf<MangaLatestChapter>()
        val la = o.optJSONArray("latestChapters")
        if (la != null) {
            for (i in 0 until la.length()) {
                val c = la.optJSONObject(i) ?: continue
                chs += MangaLatestChapter(
                    chapter = c.s("chapter", "number", "title"),
                    id_chapter = c.s("id_chapter", "id"),
                    releaseTime = c.s("releaseTime", "time")
                )
            }
        } else {
            val last = o.s("lastChapter", "latestChapter", "chapter")
            if (last.isNotBlank()) chs += MangaLatestChapter(chapter = last)
        }
        return MangaItem(
            title = o.s("title", "name").ifBlank { "Untitled" },
            id_series = o.s("id_series", "id", "slug"),
            image = o.s("image", "cover", "thumbnail", "poster"),
            latestChapters = chs
        )
    }

    private fun items(root: Any): List<MangaItem> {
        val a = asArray(root)
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { mapItem(it) }
            .filter { it.id_series.isNotBlank() }
    }

    suspend fun latest(): List<MangaItem> = items(getJson("/api/komik/latest")).also { require(it.isNotEmpty()) { "kosong" } }
    suspend fun popular(): List<MangaItem> = items(getJson("/api/komik/popular")).also { require(it.isNotEmpty()) { "kosong" } }
    suspend fun search(q: String): List<MangaItem> =
        items(getJson("/api/komik/search?q=${enc(q)}&query=${enc(q)}&keyword=${enc(q)}"))

    suspend fun detail(id: String): MangaDetail {
        val root = getJson("/api/komik/series/${enc(id)}")
        val o = payload(root) as? JSONObject ?: throw Exception("detail kosong")
        val genres = mutableListOf<String>()
        o.optJSONArray("genres")?.let { a ->
            for (i in 0 until a.length()) {
                val g = a.opt(i)
                val n = if (g is JSONObject) g.s("name", "title") else g?.toString().orEmpty()
                if (n.isNotBlank()) genres += n
            }
        }
        val chapters = mutableListOf<MangaChapterItem>()
        val ca = o.optJSONArray("chapters") ?: o.optJSONArray("chapter") ?: JSONArray()
        for (i in 0 until ca.length()) {
            val c = ca.optJSONObject(i) ?: continue
            val no = c.s("number", "chapter")
            val title = c.s("title")
            chapters += MangaChapterItem(
                title = title.ifBlank { "Chapter $no" },
                number = no.toDoubleOrNull() ?: 0.0,
                id_chapter = c.s("id_chapter", "id"),
                time = c.s("time", "releaseTime", "publishAt")
            )
        }
        if (chapters.isEmpty()) throw Exception("chapter kosong")
        val st = o.optJSONObject("info")?.opt("status")
        val status = when (st) {
            is Number -> st.toInt()
            is String -> when (st.lowercase()) { "completed", "tamat" -> 2; "hiatus" -> 3; "cancelled" -> 4; else -> 1 }
            else -> 1
        }
        return MangaDetail(
            title = o.s("title", "name").ifBlank { "Untitled" },
            id_series = o.s("id_series", "id").ifBlank { id },
            image = o.s("image", "cover", "thumbnail"),
            synopsis = o.s("synopsis", "description", "sinopsis"),
            info = MangaInfo(status = status, rating = null),
            genres = genres,
            chapters = chapters
        )
    }

    suspend fun chapterPages(id: String): MangaChapterPages {
        val root = getJson("/api/komik/chapter/${enc(id)}")
        val o = payload(root) as? JSONObject ?: throw Exception("chapter kosong")
        val arr = o.optJSONArray("images") ?: o.optJSONArray("pages") ?: JSONArray()
        val images = (0 until arr.length()).mapNotNull {
            val v = arr.opt(it)
            if (v is JSONObject) v.s("url", "src", "image") else v?.toString()
        }.filter { it.isNotBlank() }
        if (images.isEmpty()) throw Exception("halaman kosong")
        return MangaChapterPages(
            title = o.s("title"),
            id_chapter = id,
            images = images,
            next_chapter = o.s("next_chapter", "next").ifBlank { null },
            prev_chapter = o.s("prev_chapter", "prev").ifBlank { null }
        )
    }
}
