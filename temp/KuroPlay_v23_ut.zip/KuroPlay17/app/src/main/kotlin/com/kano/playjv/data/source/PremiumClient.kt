package com.kano.playjv.data.source

import com.kano.playjv.BuildConfig
import com.kano.playjv.core.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder

data class PremiumPlan(
    val id: String,
    val label: String,
    val days: Int,
    val price: Int
)

data class PremiumOrder(
    val orderId: String,
    val planLabel: String,
    val amount: Int,
    val paymentUrl: String,
    val qrisImage: String,
    val expiredAt: Long
) {
    val expiresAt: Long
        get() = expiredAt
}

/**
 * Klien pembelian premium yang memanggil endpoint
 * premium di Cloudflare Pages (_worker.js).
 */
object PremiumClient {

    private val base: String
        get() = BuildConfig.API_BASE_URL.removeSuffix("/") + "/api/app/premium"

    val fallbackPlans = listOf(
        PremiumPlan("1month", "1 Bulan", 30, 5000),
        PremiumPlan("3month", "3 Bulan", 90, 13500),
        PremiumPlan("6month", "6 Bulan", 180, 24000),
        PremiumPlan("12month", "12 Bulan", 365, 42000)
    )

    private fun encodeQueryValue(value: String): String =
        URLEncoder.encode(value, Charsets.UTF_8.name())

    private suspend fun call(
        path: String,
        token: String?
    ): JSONObject = withContext(Dispatchers.IO) {

        val requestBuilder = Request.Builder()
            .url(base + path)
            .post("".toRequestBody())

        if (!token.isNullOrBlank()) {
            requestBuilder.header("Authorization", "Bearer $token")
        }

        NetworkClient.httpClient
            .newCall(requestBuilder.build())
            .execute()
            .use { response ->

                val responseText = response.body?.string().orEmpty()

                val json = try {
                    JSONObject(responseText)
                } catch (_: Exception) {
                    throw Exception(
                        "Server pembayaran tidak memberikan respons JSON yang valid " +
                            "(HTTP ${response.code})"
                    )
                }

                if (!response.isSuccessful) {
                    throw Exception(
                        json.optString("message").takeIf {
                            it.isNotBlank()
                        } ?: "Permintaan pembayaran gagal (HTTP ${response.code})"
                    )
                }

                if (!json.optBoolean("status", false)) {
                    throw Exception(
                        json.optString("message").takeIf {
                            it.isNotBlank()
                        } ?: "Permintaan pembayaran gagal"
                    )
                }

                json
            }
    }

    suspend fun plans(): List<PremiumPlan> = try {

        withContext(Dispatchers.IO) {

            val request = Request.Builder()
                .url("$base/plans")
                .get()
                .build()

            NetworkClient.httpClient
                .newCall(request)
                .execute()
                .use { response ->

                    val responseText = response.body?.string().orEmpty()

                    if (!response.isSuccessful) {
                        throw Exception(
                            "Gagal memuat paket premium (HTTP ${response.code})"
                        )
                    }

                    val json = JSONObject(responseText)
                    val plansArray = json.getJSONArray("plans")

                    (0 until plansArray.length()).map { index ->

                        val item = plansArray.getJSONObject(index)

                        PremiumPlan(
                            id = item.getString("id"),
                            label = item.getString("label"),
                            days = item.getInt("days"),
                            price = item.getInt("price")
                        )
                    }.ifEmpty {
                        fallbackPlans
                    }
                }
        }

    } catch (_: Exception) {
        fallbackPlans
    }

    suspend fun create(
        planId: String,
        token: String
    ): PremiumOrder {

        val encodedPlanId = encodeQueryValue(planId)

        val json = call(
            path = "/create?plan=$encodedPlanId",
            token = token
        )

        return PremiumOrder(
            orderId = json.getString("orderId"),
            planLabel = json.optString("planLabel"),
            amount = json.optInt("amount"),
            paymentUrl = json.optString("paymentUrl"),
            qrisImage = json.optString("qrisImage"),
            expiredAt = json.optLong("expiredAt")
        )
    }

    /**
     * Mengembalikan status pesanan:
     * pending, paid, atau expired.
     */
    suspend fun check(
        orderId: String,
        token: String
    ): String {

        val encodedOrderId = encodeQueryValue(orderId)

        return call(
            path = "/check?id=$encodedOrderId",
            token = token
        ).optString("state", "pending")
    }
}