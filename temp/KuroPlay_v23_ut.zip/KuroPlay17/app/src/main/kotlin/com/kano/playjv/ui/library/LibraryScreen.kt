package com.kano.playjv.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import com.kano.playjv.core.state.rememberRetained
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.*
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LibraryScreen(
    repository: KuroRepository,
    currentUid: String,
    isLoggedIn: Boolean,
    onNavigateToAnimeDetail: (String) -> Unit,
    onNavigateToMangaDetail: (String) -> Unit
) {
    var selectedTab by rememberRetained("library.tab") { mutableIntStateOf(0) }
    val tabTitles = listOf("Riwayat Anime", "Simpan Anime", "Riwayat Manga", "Simpan Manga")

    val animeHistory by repository.getAnimeHistoryFlow(currentUid).collectAsState(initial = emptyList())
    androidx.compose.runtime.LaunchedEffect(animeHistory.count { it.cover.isBlank() }) {
        if (animeHistory.any { it.cover.isBlank() }) repository.backfillHistoryCovers(animeHistory)
    }
    val animeBookmarks by repository.getAnimeBookmarksFlow(currentUid).collectAsState(initial = emptyList())
    val mangaHistory by repository.getMangaHistoryFlow(currentUid).collectAsState(initial = emptyList())
    val mangaBookmarks by repository.getMangaBookmarksFlow(currentUid).collectAsState(initial = emptyList())

    var isSyncing by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    fun syncLibrary() {
        if (!isLoggedIn) {
            syncMessage = "Login diperlukan untuk sinkronisasi akun"
            return
        }
        coroutineScope.launch {
            isSyncing = true
            syncMessage = null
            val res = repository.syncLibraryFromServer()
            if (res.isSuccess) {
                syncMessage = "Berhasil disinkronkan dengan server!"
            } else {
                syncMessage = res.exceptionOrNull()?.message ?: "Gagal sinkronisasi"
            }
            isSyncing = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        // Sync Bar & Clear Action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isLoggedIn) {
                    OutlinedButton(
                        onClick = { syncLibrary() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = KuroTextPrimary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        modifier = Modifier.testTag("library_sync_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Sync",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isSyncing) "Sinkron..." else "Sinkron Server", fontSize = 12.sp)
                    }
                } else {
                    Text(
                        text = "Data tersimpan di perangkat lokal",
                        fontSize = 11.sp,
                        color = KuroTextTertiary
                    )
                }
            }

            IconButton(
                onClick = {
                    coroutineScope.launch {
                        when (selectedTab) {
                            0 -> repository.clearHistory("anime")
                            2 -> repository.clearHistory("manga")
                            else -> repository.clearHistory("all")
                        }
                    }
                },
                modifier = Modifier.testTag("library_clear_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Hapus Riwayat",
                    tint = KuroTextSecondary
                )
            }
        }

        if (syncMessage != null) {
            Text(
                text = syncMessage!!,
                color = if (syncMessage!!.contains("Berhasil")) KuroSuccess else KuroError,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Pilihan Library dibuat sebagai chip horizontal agar setiap kategori
        // terlihat jelas, tidak memiliki underline yang terlalu panjang, dan
        // tetap dapat digeser pada layar yang lebih sempit.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(KuroBgSecondary)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 11.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabTitles.forEachIndexed { index, title ->
                val selected = selectedTab == index
                Surface(
                    color = if (selected) KuroTextPrimary else KuroSurface,
                    contentColor = if (selected) KuroBgPrimary else KuroTextSecondary,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (selected) KuroTextPrimary else KuroBorder
                    ),
                    modifier = Modifier
                        .height(42.dp)
                        .clickable { selectedTab = index }
                        .testTag("library_tab_$index")
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 15.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) KuroBgPrimary else KuroTextSecondary,
                            maxLines = 1
                        )
                    }
                }
            }
        }
        HorizontalDivider(color = KuroBorder.copy(alpha = 0.75f), thickness = 1.dp)

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (selectedTab) {
                0 -> { // Anime History
                    if (animeHistory.isEmpty()) {
                        EmptyStateView(
                            message = "Belum ada riwayat anime",
                            icon = Icons.Default.History,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else {
                        LazyColumn(
                            state = rememberRetained("library.list1") { LazyListState() },
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(animeHistory, key = { it.slug }) { item ->
                                LibraryRowItem(
                                    title = item.title,
                                    subtitle = if (item.lastEp.isNotBlank()) "Terakhir: Ep ${item.lastEp}" else "Tonton",
                                    imageUrl = item.cover,
                                    onClick = { onNavigateToAnimeDetail(item.slug) },
                                    onDelete = {
                                        coroutineScope.launch {
                                            repository.deleteAnimeHistory(item.slug)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                1 -> { // Anime Bookmark
                    if (animeBookmarks.isEmpty()) {
                        EmptyStateView(
                            message = "Belum ada anime yang disimpan",
                            icon = Icons.Default.BookmarkBorder,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else {
                        LazyColumn(
                            state = rememberRetained("library.list2") { LazyListState() },
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(animeBookmarks, key = { it.slug }) { item ->
                                LibraryRowItem(
                                    title = item.title,
                                    subtitle = "Tersimpan",
                                    imageUrl = item.cover,
                                    onClick = { onNavigateToAnimeDetail(item.slug) },
                                    onDelete = {
                                        coroutineScope.launch {
                                            repository.toggleAnimeBookmark(item, true)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                2 -> { // Manga History
                    if (mangaHistory.isEmpty()) {
                        EmptyStateView(
                            message = "Belum ada riwayat baca komik",
                            icon = Icons.Default.History,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else {
                        LazyColumn(
                            state = rememberRetained("library.list3") { LazyListState() },
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(mangaHistory, key = { it.id_series }) { item ->
                                LibraryRowItem(
                                    title = item.title,
                                    subtitle = if (item.lastChapter > 0) "Terakhir: Ch. ${item.lastChapter}" else "Lanjut baca",
                                    imageUrl = item.image,
                                    onClick = { onNavigateToMangaDetail(item.id_series) },
                                    onDelete = {
                                        coroutineScope.launch {
                                            repository.deleteMangaHistory(item.id_series)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                3 -> { // Manga Bookmark
                    if (mangaBookmarks.isEmpty()) {
                        EmptyStateView(
                            message = "Belum ada komik yang disimpan",
                            icon = Icons.Default.BookmarkBorder,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else {
                        LazyColumn(
                            state = rememberRetained("library.list4") { LazyListState() },
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(mangaBookmarks, key = { it.id_series }) { item ->
                                LibraryRowItem(
                                    title = item.title,
                                    subtitle = "Tersimpan",
                                    imageUrl = item.image,
                                    onClick = { onNavigateToMangaDetail(item.id_series) },
                                    onDelete = {
                                        coroutineScope.launch {
                                            repository.toggleMangaBookmark(item, true)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            GearLoadingOverlay(
                isLoading = isSyncing,
                statusText = "Sinkronisasi riwayat & koleksi...",
                onCancel = { isSyncing = false }
            )
        }
    }
}

@Composable
fun LibraryRowItem(
    title: String,
    subtitle: String,
    imageUrl: String,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AsyncImage(
                model = imageUrl,
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(50.dp, 68.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(KuroBorder)
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = KuroGold
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Hapus",
                    tint = KuroTextTertiary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
