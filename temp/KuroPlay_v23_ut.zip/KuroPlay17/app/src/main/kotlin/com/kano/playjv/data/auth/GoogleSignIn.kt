package com.kano.playjv.data.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.kano.playjv.BuildConfig

/** Meminta Google ID token lewat Credential Manager (dialog "Masuk dengan Google"). */
suspend fun requestGoogleIdToken(context: Context): Result<String> {
    return try {
        val option = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = CredentialManager.create(context).getCredential(context, request)
        val credential = result.credential
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            Result.success(GoogleIdTokenCredential.createFrom(credential.data).idToken)
        } else {
            Result.failure(Exception("Kredensial Google tidak dikenali"))
        }
    } catch (e: GetCredentialCancellationException) {
        Result.failure(
            Exception(
                "Login Google dibatalkan atau ditolak (${e.message ?: e.type}). " +
                    "Jika Anda tidak membatalkannya, cek SHA-1 dan OAuth client Android di Firebase/Google Cloud."
            )
        )
    } catch (e: NoCredentialException) {
        Result.failure(Exception("Tidak ada akun Google yang bisa dipakai. Pastikan SHA-1 aplikasi sudah didaftarkan di Firebase."))
    } catch (e: GetCredentialException) {
        Result.failure(Exception("Login Google gagal: ${e.message ?: e.type}"))
    } catch (e: GoogleIdTokenParsingException) {
        Result.failure(Exception("Token Google tidak valid"))
    } catch (e: Exception) {
        Result.failure(Exception("Login Google gagal: ${e.message}"))
    }
}
