package com.kano.playjv.ui.anime

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeBookmarkItem
import com.kano.playjv.core.model.AnimeDetail
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AnimeDetailScreen(
    animeId: String,
    repository: KuroRepository,
    currentUid: String,
    onBack: () -> Unit,
    onPlayEpisode: (slug: String, epNumber: String, channelId: String, animeTitle: String) -> Unit
) {
    BackHandler { onBack() }

    var animeDetail by remember { mutableStateOf<AnimeDetail?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSynopsisExpanded by remember { mutableStateOf(false) }
    var newestFirst by remember { mutableStateOf(true) }
    var keepDetailLoaderVisible by remember(animeId) { mutableStateOf(true) }

    val isBookmarked by repository.isAnimeBookmarkedFlow(animeId, currentUid).collectAsState(initial = false)
    val history by repository.getAnimeHistoryFlow(currentUid).collectAsState(initial = emptyList())
    val lastEp = history.firstOrNull { it.slug == animeId }?.lastEp.orEmpty()
    val coroutineScope = rememberCoroutineScope()

    fun loadDetail() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res = repository.getAnimeDetail(animeId)
            if (res.isSuccess) {
                animeDetail = res.getOrNull()
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat detail anime"
            }
            isLoading = false
        }
    }

    LaunchedEffect(animeId) { loadDetail() }

    // Tahan indikator sebentar setelah request selesai agar animasi dapat mencapai 100%.
    LaunchedEffect(animeId, isLoading) {
        if (isLoading) {
            keepDetailLoaderVisible = true
        } else if (keepDetailLoaderVisible) {
            delay(700L)
            keepDetailLoaderVisible = false
        }
    }

    fun play(ep: AnimeEpisode) {
        val detail = animeDetail ?: return
        onPlayEpisode(animeId, ep.ch, ep.url, detail.judul)
    }

    Box(modifier = Modifier.fillMaxSize().background(KuroBgPrimary)) {
        val detail = animeDetail
        when {
            keepDetailLoaderVisible -> WavyLoadingProgressIndicator(
                isLoading = isLoading,
                statusText = "Memuat detail anime...",
                modifier = Modifier.align(Alignment.Center)
            )
            errorMessage != null && detail == null -> ErrorStateView(
                message = errorMessage ?: "Terjadi kesalahan",
                onRetry = { loadDetail() },
                modifier = Modifier.align(Alignment.Center)
            )
            detail != null -> {
                val episodes = remember(detail, newestFirst) {
                    // urutan sumber: terbaru di atas; balik bila ingin dari Ep 1
                    if (newestFirst) detail.chapter else detail.chapter.reversed()
                }
                val firstEp = detail.chapter.lastOrNull()
                val resumeEp = detail.chapter.firstOrNull { it.ch == lastEp }
                val ctaEp = resumeEp ?: firstEp

                LazyColumn(
                    modifier = Modifier.fillMaxSize().testTag("anime_detail_content"),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // HERO
                    item {
                        Box(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                            AsyncImage(
                                model = detail.cover,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier.fillMaxSize().background(
                                    Brush.verticalGradient(
                                        0f to Color.Black.copy(alpha = 0.45f),
                                        0.45f to KuroBgPrimary.copy(alpha = 0.75f),
                                        1f to KuroBgPrimary
                                    )
                                )
                            )
                            // top actions
                            Row(
                                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                IconButton(
                                    onClick = onBack,
                                    modifier = Modifier.testTag("detail_back_button")
                                        .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White)
                                }
                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            repository.toggleAnimeBookmark(
                                                AnimeBookmarkItem(slug = animeId, title = detail.judul, cover = detail.cover),
                                                isBookmarked
                                            )
                                        }
                                    },
                                    modifier = Modifier.testTag("detail_bookmark_button")
                                        .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                                ) {
                                    Icon(
                                        if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                                        "Bookmark",
                                        tint = if (isBookmarked) KuroGold else Color.White
                                    )
                                }
                            }
                            // poster + title
                            Row(
                                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                AsyncImage(
                                    model = detail.cover,
                                    contentDescription = detail.judul,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .width(112.dp).height(160.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .border(1.dp, KuroOutlineVariant, RoundedCornerShape(14.dp))
                                )
                                Column(
                                    modifier = Modifier.weight(1f).padding(bottom = 4.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        detail.judul,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = KuroTextPrimary,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        if (detail.rating.isNotBlank() && detail.rating != "-") {
                                            InfoChip(text = detail.rating, icon = Icons.Default.Star, iconTint = KuroGold)
                                        }
                                        StatusBadge(text = detail.type.ifBlank { "TV" })
                                        if (detail.status.isNotBlank()) StatusBadge(text = detail.status)
                                        if (detail.published.isNotBlank()) InfoChip(text = detail.published)
                                    }
                                }
                            }
                        }
                    }

                    // CTA
                    item {
                        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                            Button(
                                onClick = { ctaEp?.let { play(it) } },
                                enabled = ctaEp != null,
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = KuroPrimary,
                                    contentColor = KuroOnPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("anime_cta_play")
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    when {
                                        ctaEp == null -> "Belum ada episode"
                                        resumeEp != null -> "Lanjutkan Episode ${ctaEp.ch}"
                                        else -> "Mulai Episode ${ctaEp.ch}"
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Genre
                    if (detail.genre.isNotEmpty()) {
                        item {
                            FlowRow(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                detail.genre.forEach { g ->
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = KuroSurfaceContainerHigh,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroOutlineVariant)
                                    ) {
                                        Text(
                                            g,
                                            fontSize = 12.sp,
                                            color = KuroTextSecondary,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Synopsis
                    if (detail.sinopsis.isNotBlank()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .padding(horizontal = 16.dp, vertical = 14.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(KuroSurfaceContainer)
                                    .clickable { isSynopsisExpanded = !isSynopsisExpanded }
                                    .padding(14.dp)
                            ) {
                                Text("Sinopsis", fontWeight = FontWeight.Bold, color = KuroTextPrimary, fontSize = 14.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    detail.sinopsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = KuroTextSecondary,
                                    maxLines = if (isSynopsisExpanded) Int.MAX_VALUE else 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    if (isSynopsisExpanded) "Tutup" else "Baca selengkapnya",
                                    color = KuroTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }

                    // Episode header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "Daftar Episode",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = KuroTextPrimary
                                )
                                Text("${detail.chapter.size} episode", fontSize = 12.sp, color = KuroTextSecondary)
                            }
                            TextButton(onClick = { newestFirst = !newestFirst }) {
                                Icon(Icons.Default.SwapVert, null, tint = KuroTextPrimary, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (newestFirst) "Terbaru" else "Terlama", color = KuroTextPrimary, fontSize = 12.sp)
                            }
                        }
                    }

                    if (episodes.isEmpty()) {
                        item { EmptyStateView(message = "Belum ada episode tersedia") }
                    } else {
                        // grid manual (baris berisi 4 tile) agar tetap di dalam satu LazyColumn
                        val rows = episodes.chunked(4)
                        items(rows.size, key = { rows[it].first().url }) { r ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rows[r].forEach { ep ->
                                    EpisodeTile(
                                        episode = ep,
                                        isLast = ep.ch == lastEp,
                                        onClick = { play(ep) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(4 - rows[r].size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, iconTint: Color = KuroTextSecondary) {
    Surface(shape = RoundedCornerShape(8.dp), color = KuroSurfaceContainerHighest) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) Icon(icon, null, tint = iconTint, modifier = Modifier.size(14.dp))
            Text(text, fontSize = 11.sp, color = KuroTextPrimary, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun EpisodeTile(
    episode: AnimeEpisode,
    isLast: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .height(48.dp)
            .clip(shape)
            .background(KuroSurfaceContainerHigh)
            .border(if (isLast) 2.dp else 1.dp, if (isLast) KuroPrimary else KuroOutlineVariant, shape)
            .clickable { onClick() }
            .testTag("episode_item_${episode.ch}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = episode.ch,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = if (isLast) KuroPrimary else KuroTextPrimary,
            maxLines = 1
        )
    }
}
