package com.kano.playjv.core.components

import android.view.LayoutInflater
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ProgressIndicatorDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.material.loadingindicator.LoadingIndicator
import com.kano.playjv.R
import com.kano.playjv.ui.theme.*
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * Progress bar detail anime/manga/episode.
 *
 * Material3 1.4 pada BOM project ini belum memiliki LinearWavyProgressIndicator.
 * Gunakan LinearProgressIndicator resmi yang kompatibel dengan compileSdk 36,
 * sambil mempertahankan progress dan status dari pemanggil.
 */
@Composable
fun GearProgressIndicator(
    progress: Int,
    statusText: String = "Memuat data...",
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    onCancel: (() -> Unit)? = null
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0, 100) / 100f,
        animationSpec = ProgressIndicatorDefaults.ProgressAnimationSpec,
        label = "gear_progress"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 28.dp)
            .testTag("gear_progress_indicator"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier
                .widthIn(max = if (size < 70.dp) 180.dp else 240.dp)
                .fillMaxWidth(),
            color = KuroPrimary,
            trackColor = KuroSurfaceContainerHigh
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "${progress.coerceIn(0, 100)}%",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = KuroTextPrimary,
            modifier = Modifier.testTag("gear_progress_percentage")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyMedium,
            color = KuroTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .widthIn(max = 260.dp)
                .testTag("gear_progress_status")
        )

        if (onCancel != null) {
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onCancel,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = KuroTextSecondary),
                border = androidx.compose.foundation.BorderStroke(1.dp, KuroOutlineVariant),
                modifier = Modifier.testTag("gear_progress_cancel_button")
            ) {
                Text("Batal", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/**
 * Indikator loading bergelombang dengan animasi progres simulasi.
 *
 * Progres naik halus dari 0 sampai sekitar 94% selama proses masih berlangsung.
 * Saat pemuatan selesai, indikator menyelesaikan animasi ke 100%.
 * Ini merupakan estimasi visual, bukan persentase byte atau data jaringan.
 * Dibuat dengan Canvas agar tetap kompatibel dengan Material3 1.4.0.
 */
@Composable
fun WavyLoadingProgressIndicator(
    isLoading: Boolean,
    statusText: String,
    modifier: Modifier = Modifier,
    size: Dp = 96.dp
) {
    var targetProgress by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }

    LaunchedEffect(isLoading) {
        if (isLoading) {
            targetProgress = 0f
            val durationMs = 5_200L
            var elapsedMs = 0L

            while (elapsedMs < durationMs) {
                delay(40L)
                elapsedMs = (elapsedMs + 40L).coerceAtMost(durationMs)
                val fraction = elapsedMs.toFloat() / durationMs.toFloat()
                val eased = 1f - (1f - fraction) * (1f - fraction)
                targetProgress = 0.94f * eased
            }
        } else {
            // ProgressAnimationSpec membuat penyelesaian ke 100% tetap halus.
            targetProgress = 1f
        }
    }

    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = ProgressIndicatorDefaults.ProgressAnimationSpec,
        label = "wavy_loading_progress"
    )

    val waveTransition = rememberInfiniteTransition(label = "wavy_loading_motion")
    val wavePhase by waveTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1_350, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavy_loading_phase"
    )

    val waveStrength by animateFloatAsState(
        targetValue = if (animatedProgress >= 0.995f) 0f else 1f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "wavy_loading_finish"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 28.dp)
            .testTag("wavy_loading_indicator"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Canvas(
            modifier = Modifier
                .widthIn(max = if (size < 70.dp) 180.dp else 240.dp)
                .fillMaxWidth()
                .height(18.dp)
                .testTag("wavy_loading_progress_bar")
        ) {
            val strokeWidth = 5.dp.toPx()
            val centerY = this.size.height / 2f
            val progressWidth = this.size.width * animatedProgress.coerceIn(0f, 1f)
            val amplitude = 3.dp.toPx() * waveStrength
            val wavelength = 26.dp.toPx()

            // Track tetap terlihat di belakang bagian yang sudah terisi.
            drawLine(
                color = KuroSurfaceContainerHigh,
                start = Offset(strokeWidth / 2f, centerY),
                end = Offset(this.size.width - strokeWidth / 2f, centerY),
                strokeWidth = strokeWidth,
                cap = StrokeCap.Round
            )

            if (progressWidth >= strokeWidth) {
                val startX = strokeWidth / 2f
                val endX = (progressWidth - strokeWidth / 2f).coerceAtLeast(startX)
                val path = Path()
                var x = startX

                fun waveY(position: Float): Float {
                    val angle = (position / wavelength) * (2f * PI).toFloat() + wavePhase
                    return centerY + sin(angle.toDouble()).toFloat() * amplitude
                }

                path.moveTo(startX, waveY(startX))
                while (x < endX) {
                    x = (x + 2.dp.toPx()).coerceAtMost(endX)
                    path.lineTo(x, waveY(x))
                }

                drawPath(
                    path = path,
                    color = KuroPrimary,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "${(animatedProgress * 100f).roundToInt().coerceIn(0, 100)}%",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = KuroTextPrimary,
            modifier = Modifier.testTag("wavy_loading_percentage")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyMedium,
            color = KuroTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .widthIn(max = 260.dp)
                .testTag("wavy_loading_status")
        )
    }
}

/**
 * Contained loading indicator resmi dari Material Components for Android 1.14.
 * View tersebut memakai implementasi morphing Material 3 Expressive dari Google,
 * lalu dibungkus AndroidView agar tetap dapat digunakan dari Jetpack Compose
 * tanpa menarik Compose Material3 1.5 yang memerlukan AGP 9.1 / SDK 37.
 */
@Composable
fun KuroContainedLoadingState(
    statusText: String? = null,
    modifier: Modifier = Modifier,
    indicatorSize: Dp = 72.dp
) {
    val context = LocalContext.current
    val density = context.resources.displayMetrics.density
    val containerPx = (indicatorSize.value * density).toInt().coerceAtLeast(1)
    val shapePx = (containerPx * 0.68f).toInt().coerceAtLeast(1)
    val indicatorColor = KuroPrimary.toArgb()
    val containerColor = KuroSurfaceContainerHigh.toArgb()

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AndroidView(
            modifier = Modifier.size(indicatorSize),
            factory = { viewContext ->
                (LayoutInflater.from(viewContext)
                    .inflate(R.layout.view_contained_loading_indicator, null, false)
                    as LoadingIndicator).apply {
                    setContainerWidth(containerPx)
                    setContainerHeight(containerPx)
                    setIndicatorSize(shapePx)
                    setIndicatorColor(indicatorColor)
                    setContainerColor(containerColor)
                }
            },
            update = { view ->
                view.setContainerWidth(containerPx)
                view.setContainerHeight(containerPx)
                view.setIndicatorSize(shapePx)
                view.setIndicatorColor(indicatorColor)
                view.setContainerColor(containerColor)
            }
        )

        if (!statusText.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = KuroTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .widthIn(max = 260.dp)
                    .testTag("contained_loading_status")
            )
        }
    }
}

/**
 * Simulasi progress dipertahankan untuk layar yang sebelumnya memakai
 * GearProgressIndicator. Ini hanya estimasi visual, bukan byte download.
 */
@Composable
fun rememberSimulatedProgress(
    isLoading: Boolean,
    isSuccess: Boolean = false,
    baseDurationMs: Long = 3500L
): State<Int> {
    val progressState = remember { mutableIntStateOf(1) }

    LaunchedEffect(isLoading, isSuccess) {
        if (!isLoading) {
            if (isSuccess) {
                progressState.intValue = 100
                delay(250)
            } else {
                progressState.intValue = 1
            }
            return@LaunchedEffect
        }

        progressState.intValue = 1
        var current = 1
        val startTime = System.currentTimeMillis()

        while (isLoading) {
            val elapsed = System.currentTimeMillis() - startTime
            val fraction = (elapsed.toFloat() / baseDurationMs.coerceAtLeast(1L))
                .coerceIn(0f, 1f)
            val target = when {
                fraction < 0.20f -> (1 + fraction / 0.20f * 36).toInt()
                fraction < 0.50f -> (37 + ((fraction - 0.20f) / 0.30f) * 33).toInt()
                fraction < 0.80f -> (70 + ((fraction - 0.50f) / 0.30f) * 18).toInt()
                else -> (88 + ((fraction - 0.80f) / 0.20f) * 10).toInt().coerceAtMost(98)
            }
            if (target > current) {
                current = target
                progressState.intValue = current
            }
            delay(50)
        }
    }

    return progressState
}

/**
 * Full-screen loading overlay. Hanya tampilan indikator yang berubah;
 * visibilitas, pembatalan, dan pemanggil tetap sama.
 */
@Composable
fun GearLoadingOverlay(
    isLoading: Boolean,
    statusText: String = "Memuat...",
    onCancel: (() -> Unit)? = null
) {
    AnimatedVisibility(
        visible = isLoading,
        enter = fadeIn(tween(220)) + scaleIn(
            tween(280, easing = FastOutSlowInEasing),
            initialScale = 0.96f
        ),
        exit = fadeOut(tween(180)) + scaleOut(
            tween(180),
            targetScale = 0.98f
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            KuroBgPrimary.copy(alpha = 0.88f),
                            KuroScrim.copy(alpha = 0.96f)
                        )
                    )
                )
                .testTag("gear_loading_overlay"),
            contentAlignment = Alignment.Center
        ) {
            ElevatedCard(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = KuroSurfaceContainer
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .padding(40.dp)
                    .widthIn(min = 220.dp, max = 300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    KuroGradientBlack,
                                    KuroPrimary.copy(alpha = 0.6f),
                                    KuroGradientLight,
                                    KuroPrimary.copy(alpha = 0.6f),
                                    KuroGradientBlack
                                )
                            )
                        )
                )

                KuroContainedLoadingState(
                    statusText = statusText,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 26.dp),
                    indicatorSize = 76.dp
                )

                if (onCancel != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = KuroTextSecondary
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                KuroOutlineVariant
                            ),
                            modifier = Modifier.testTag("gear_progress_cancel_button")
                        ) {
                            Text("Batal", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}
