package com.kano.playjv.ui.manga

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.LazyGridState
import com.kano.playjv.core.state.rememberRetained
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.MangaGenre
import com.kano.playjv.core.model.MangaItem
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.anime.FilterTabChip
import com.kano.playjv.ui.home.MangaCard
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MangaListScreen(
    repository: KuroRepository,
    onNavigateToDetail: (String) -> Unit
) {
    // State dipertahankan agar kembali dari detail tidak memuat ulang & scroll ke atas.
    var selectedFilter by rememberRetained("manga_list.filter") { mutableStateOf("latest") } // "latest", "popular", "recommended"
    var selectedGenreId by rememberRetained("manga_list.genre") { mutableStateOf<String?>(null) }
    var searchQuery by rememberRetained("manga_list.query") { mutableStateOf("") }

    var mangaList by rememberRetained("manga_list.list") { mutableStateOf<List<MangaItem>>(emptyList()) }
    var genres by rememberRetained("manga_list.genres") { mutableStateOf<List<MangaGenre>>(emptyList()) }
    var loadedKey by rememberRetained("manga_list.loadedKey") { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val gridState = rememberRetained("manga_list.grid") { LazyGridState() }
    val genreRowState = rememberRetained("manga_list.genreRow") { LazyListState() }

    val coroutineScope = rememberCoroutineScope()
    var searchJob by remember { mutableStateOf<Job?>(null) }

    fun loadManga() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null

            val res = when {
                searchQuery.isNotBlank() -> repository.searchManga(searchQuery)
                selectedGenreId != null -> repository.getMangaByGenre(selectedGenreId!!)
                selectedFilter == "popular" -> repository.getPopularManga()
                selectedFilter == "recommended" -> repository.getRecommendedManga()
                else -> repository.getLatestManga()
            }

            if (res.isSuccess) {
                mangaList = res.getOrDefault(emptyList())
                if (mangaList.isNotEmpty()) loadedKey = "$searchQuery|$selectedGenreId|$selectedFilter"
                isLoading = false
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat komik"
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (genres.isNotEmpty()) return@LaunchedEffect
        val genresRes = repository.getMangaGenres()
        if (genresRes.isSuccess) {
            genres = genresRes.getOrDefault(emptyList())
        }
    }

    LaunchedEffect(selectedFilter, selectedGenreId) {
        // Kembali dari halaman detail dengan filter yang sama: pakai daftar yang sudah ada.
        if (mangaList.isNotEmpty() && loadedKey == "$searchQuery|$selectedGenreId|$selectedFilter") {
            return@LaunchedEffect
        }
        if (searchQuery.isBlank()) {
            loadManga()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { query ->
                searchQuery = query
                searchJob?.cancel()
                searchJob = coroutineScope.launch {
                    delay(400) // debounce
                    loadManga()
                }
            },
            placeholder = { Text("Cari judul manga / komik...", color = KuroTextTertiary) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = KuroTextSecondary
                )
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = {
                        searchQuery = ""
                        loadManga()
                    }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = KuroTextSecondary)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = KuroSurface,
                unfocusedContainerColor = KuroSurface,
                focusedBorderColor = KuroTextPrimary,
                unfocusedBorderColor = KuroBorder,
                focusedTextColor = KuroTextPrimary,
                unfocusedTextColor = KuroTextPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("manga_search_field")
        )

        // Filter Tabs
        if (searchQuery.isBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterTabChip(
                    title = "Terbaru",
                    selected = selectedFilter == "latest" && selectedGenreId == null,
                    onClick = {
                        selectedFilter = "latest"
                        selectedGenreId = null
                    }
                )
                FilterTabChip(
                    title = "Populer",
                    selected = selectedFilter == "popular" && selectedGenreId == null,
                    onClick = {
                        selectedFilter = "popular"
                        selectedGenreId = null
                    }
                )
                FilterTabChip(
                    title = "Rekomendasi",
                    selected = selectedFilter == "recommended" && selectedGenreId == null,
                    onClick = {
                        selectedFilter = "recommended"
                        selectedGenreId = null
                    }
                )
            }

            // Genre Horizontal Chips
            if (genres.isNotEmpty()) {
                LazyRow(
                    state = genreRowState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(genres, key = { it.id }) { genre ->
                        val isSelected = selectedGenreId == genre.id
                        FilterTabChip(
                            title = genre.name,
                            selected = isSelected,
                            onClick = {
                                selectedGenreId = if (isSelected) null else genre.id
                            }
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (isLoading && mangaList.isEmpty()) {
                KuroContainedLoadingState(
                    statusText = if (searchQuery.isNotBlank()) "Mencari manga..." else "Memuat daftar manga...",
                    modifier = Modifier.fillMaxSize().padding(16.dp)
                )
            } else if (errorMessage != null && mangaList.isEmpty()) {
                ErrorStateView(
                    message = errorMessage ?: "Terjadi kesalahan",
                    onRetry = { loadManga() },
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (!isLoading && mangaList.isEmpty()) {
                EmptyStateView(
                    message = if (searchQuery.isNotBlank()) "Manga \"$searchQuery\" tidak ditemukan" else "Daftar manga kosong",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("manga_grid_list")
                ) {
                    items(mangaList, key = { it.id_series }) { manga ->
                        MangaCard(
                            manga = manga,
                            onClick = { onNavigateToDetail(manga.id_series) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            GearLoadingOverlay(
                isLoading = isLoading && mangaList.isNotEmpty(),
                statusText = "Memuat manga...",
                onCancel = { isLoading = false }
            )
        }
    }
}
