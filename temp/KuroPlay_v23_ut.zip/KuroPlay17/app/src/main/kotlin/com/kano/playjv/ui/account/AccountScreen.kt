package com.kano.playjv.ui.account

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kano.playjv.BuildConfig
import com.kano.playjv.R
import com.kano.playjv.core.ads.AdManager
import com.kano.playjv.core.ads.findHostActivity
import com.kano.playjv.core.components.GearLoadingOverlay
import com.kano.playjv.core.components.StatusBadge
import com.kano.playjv.core.model.UserProfile
import com.kano.playjv.data.auth.requestGoogleIdToken
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.repository.NeedUsernameException
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Layar login/daftar (saat belum login) dan layar "Tentang" (setelah login):
 * profil, pengaturan (auto next), info aplikasi, keluar.
 */
@Composable
fun AccountScreen(
    authRepository: AuthRepository,
    preferences: UserPreferences,
    onOpenPremium: () -> Unit = {}
) {
    val userProfile by authRepository.userProfileFlow.collectAsState(initial = null)
    val autoNext by preferences.autoNextFlow.collectAsState(initial = true)
    val adultEnabled by preferences.adultEnabledFlow.collectAsState(initial = false)
    var showAdultDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var isLoggingIn by remember { mutableStateOf(false) }
    var isAdLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var authSuccessMsg by remember { mutableStateOf<String?>(null) }

    var authMode by remember { mutableStateOf("LOGIN") } // "LOGIN" atau "REGISTER"
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var usernameInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var usernameStatusMsg by remember { mutableStateOf<String?>(null) }

    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var forgotPasswordEmail by remember { mutableStateOf("") }

    var needUsername by remember { mutableStateOf(false) }
    var pickedUsername by remember { mutableStateOf("") }
    var pickedUsernameMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(userProfile?.uid) {
        if (userProfile != null) authRepository.refreshProfile()
    }

    fun handleAuthResult(res: Result<UserProfile>, defaultMsg: String) {
        val err = res.exceptionOrNull()
        if (err is NeedUsernameException) {
            pickedUsername = ""
            pickedUsernameMsg = null
            needUsername = true
        } else if (err != null) {
            authError = err.message ?: defaultMsg
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            val user = userProfile
            if (user != null) {
                // ===== Profil =====
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = KuroSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = KuroSurfaceElevated,
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, KuroBorder),
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = user.username.firstOrNull()?.uppercase() ?: "U",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 28.sp,
                                        color = KuroTextPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = user.username,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = KuroTextPrimary
                                )
                                if (user.isOwner || user.premium?.active == true) VerifiedBadge(size = 18.dp)
                                val roleLabel = when {
                                    user.isOwner -> "OWNER"
                                    user.isAdmin -> "ADMIN"
                                    else -> "MEMBER"
                                }
                                val roleColor = when {
                                    user.isOwner -> KuroGold
                                    user.isAdmin -> Color(0xFF3B82F6)
                                    else -> KuroSurfaceElevated
                                }
                                StatusBadge(text = roleLabel, color = roleColor)
                            }

                            Text(
                                text = user.email,
                                fontSize = 12.sp,
                                color = KuroTextSecondary
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            val hasPremium = user.isOwner || user.premium?.active == true
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    androidx.compose.material3.Icon(
                                        imageVector = androidx.compose.material.icons.Icons.Default.Key,
                                        contentDescription = "Key",
                                        tint = KuroGold,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Column {
                                        Text(
                                            text = if (hasPremium) "∞" else "${user.keys}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp,
                                            color = KuroTextPrimary
                                        )
                                        Text("Key", fontSize = 11.sp, color = KuroTextSecondary)
                                    }
                                }
                                if (!user.isOwner) {
                                    Surface(
                                        shape = RoundedCornerShape(24.dp),
                                        color = Color(0xFF1D9BF0),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { onOpenPremium() }
                                            .testTag("premium_pill")
                                    ) {
                                        Text(
                                            text = if (user.premium?.active == true)
                                                "Premium ${premiumDaysLabel(user.premium.expiresAt, user.premium.daysLeft)} Hari"
                                            else "Beli Premium",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // ===== Pengaturan =====
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = KuroSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Pengaturan",
                                fontWeight = FontWeight.Bold,
                                color = KuroTextPrimary,
                                fontSize = 15.sp
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Auto next episode", color = KuroTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Text(
                                        "Putar episode berikutnya otomatis setelah episode selesai",
                                        color = KuroTextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                Switch(
                                    checked = autoNext,
                                    onCheckedChange = { coroutineScope.launch { preferences.setAutoNext(it) } },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = KuroBgPrimary,
                                        checkedTrackColor = KuroTextPrimary,
                                        uncheckedThumbColor = KuroTextSecondary,
                                        uncheckedTrackColor = KuroSurfaceElevated
                                    ),
                                    modifier = Modifier.testTag("auto_next_switch")
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Konten dewasa (18+)", color = KuroTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Text(
                                        "Tampilkan genre & judul dewasa (Hentai). Mati secara default",
                                        color = KuroTextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                                Switch(
                                    checked = adultEnabled,
                                    onCheckedChange = { wantOn ->
                                        if (wantOn) {
                                            showAdultDialog = true
                                        } else {
                                            coroutineScope.launch {
                                                preferences.setAdultEnabled(false)
                                                com.kano.playjv.core.state.RetainedStateStore.clear()
                                            }
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = KuroBgPrimary,
                                        checkedTrackColor = KuroTextPrimary,
                                        uncheckedThumbColor = KuroTextSecondary,
                                        uncheckedTrackColor = KuroSurfaceElevated
                                    ),
                                    modifier = Modifier.testTag("adult_switch")
                                )
                            }
                        }
                    }
                }

                // ===== Tentang aplikasi =====
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = KuroSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Tentang Aplikasi",
                                fontWeight = FontWeight.Bold,
                                color = KuroTextPrimary,
                                fontSize = 15.sp
                            )

                            @Composable
                            fun InfoRow(label: String, value: String) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(label, color = KuroTextSecondary, fontSize = 13.sp)
                                    Text(value, color = KuroTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            }

                            InfoRow("Aplikasi", "KuroPlay")
                            InfoRow("Versi", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                            InfoRow("Developer", "Kano")
                            InfoRow("Paket", BuildConfig.APPLICATION_ID)
                            val unlimited = user.isOwner || user.premium?.active == true
                            InfoRow("Status", if (user.isOwner) "Owner" else if (unlimited) "Premium" else "Biasa")
                            InfoRow("Kunci", if (unlimited) "∞" else "${user.keys}")
                            if (user.premium?.active == true && !user.isOwner) {
                                InfoRow("Premium sampai", "${user.premium.daysLeft} hari lagi")
                            }
                            if (!user.isOwner) {
                                Button(
                                    onClick = { onOpenPremium() },
                                    modifier = Modifier.fillMaxWidth().testTag("buy_premium_button")
                                ) { Text(if (unlimited) "Perpanjang Premium" else "Beli Premium") }
                            }
                            if (!unlimited) {
                                val ctx = LocalContext.current
                                val scope = rememberCoroutineScope()
                                Button(
                                    enabled = !isAdLoading,
                                    onClick = {
                                        val act = ctx.findHostActivity() ?: return@Button
                                        isAdLoading = true
                                        AdManager.show(
                                            act,
                                            onReward = {
                                                scope.launch {
                                                    val r = authRepository.grantAdKeys()
                                                    isAdLoading = false
                                                    android.widget.Toast.makeText(
                                                        ctx,
                                                        r.fold({ "Kunci sekarang: $it" }, { it.message ?: "Gagal menambah kunci" }),
                                                        android.widget.Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                            },
                                            onFail = { msg ->
                                                isAdLoading = false
                                                android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Tonton iklan (+3 kunci)") }
                            }

                            Text(
                                text = "Streaming anime dan baca manga dalam satu aplikasi.",
                                color = KuroTextTertiary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // ===== Keluar =====
                item {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isLoggingIn = true
                                try {
                                    authRepository.logout()
                                    com.kano.playjv.core.state.RetainedStateStore.clear()
                                } finally {
                                    isLoggingIn = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = KuroSurfaceElevated,
                            contentColor = KuroError
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("logout_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Keluar dari Akun", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // ===== Belum login: login / daftar =====
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = KuroSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.kuro_logo),
                                contentDescription = "KuroPlay Logo",
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            )

                            Text(
                                text = "Selamat Datang di KuroPlay",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KuroTextPrimary
                            )
                            Text(
                                text = "Masuk untuk sinkronisasi riwayat dan koleksi kamu.",
                                style = MaterialTheme.typography.bodySmall,
                                color = KuroTextSecondary,
                                textAlign = TextAlign.Center
                            )

                            // Toggle Login / Daftar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(KuroSurfaceElevated, RoundedCornerShape(10.dp))
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Button(
                                    onClick = { authMode = "LOGIN"; authError = null },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (authMode == "LOGIN") KuroTextPrimary else Color.Transparent,
                                        contentColor = if (authMode == "LOGIN") KuroBgPrimary else KuroTextSecondary
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Login", fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { authMode = "REGISTER"; authError = null },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (authMode == "REGISTER") KuroTextPrimary else Color.Transparent,
                                        contentColor = if (authMode == "REGISTER") KuroBgPrimary else KuroTextSecondary
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Daftar", fontWeight = FontWeight.Bold)
                                }
                            }

                            if (authError != null) {
                                Text(
                                    text = authError!!,
                                    color = KuroError,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                            if (authSuccessMsg != null) {
                                Text(
                                    text = authSuccessMsg!!,
                                    color = KuroSuccess,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                            }

                            if (authMode == "REGISTER") {
                                OutlinedTextField(
                                    value = usernameInput,
                                    onValueChange = {
                                        usernameInput = it.trim().lowercase()
                                        if (usernameInput.length >= 3) {
                                            coroutineScope.launch {
                                                delay(300)
                                                val chk = authRepository.checkUsername(usernameInput)
                                                usernameStatusMsg = chk.getOrNull()?.message
                                            }
                                        } else {
                                            usernameStatusMsg = null
                                        }
                                    },
                                    label = { Text("Username") },
                                    placeholder = { Text("huruf kecil, angka, underscore") },
                                    supportingText = {
                                        if (usernameStatusMsg != null) {
                                            Text(
                                                text = usernameStatusMsg!!,
                                                color = if (usernameStatusMsg == "Username tersedia") KuroSuccess else KuroError
                                            )
                                        }
                                    },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = KuroSurfaceElevated,
                                        unfocusedContainerColor = KuroSurfaceElevated,
                                        focusedTextColor = KuroTextPrimary,
                                        unfocusedTextColor = KuroTextPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("reg_username_field")
                                )
                            }

                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text("Email") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = KuroSurfaceElevated,
                                    unfocusedContainerColor = KuroSurfaceElevated,
                                    focusedTextColor = KuroTextPrimary,
                                    unfocusedTextColor = KuroTextPrimary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("auth_email_field")
                            )

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Password") },
                                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = "Toggle password"
                                        )
                                    }
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = KuroSurfaceElevated,
                                    unfocusedContainerColor = KuroSurfaceElevated,
                                    focusedTextColor = KuroTextPrimary,
                                    unfocusedTextColor = KuroTextPrimary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("auth_password_field")
                            )

                            if (authMode == "LOGIN") {
                                TextButton(
                                    onClick = { showForgotPasswordDialog = true },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("Lupa Password?", fontSize = 12.sp, color = KuroTextSecondary)
                                }
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isLoggingIn = true
                                        authError = null
                                        if (authMode == "LOGIN") {
                                            handleAuthResult(authRepository.login(emailInput, passwordInput), "Login gagal")
                                        } else {
                                            handleAuthResult(
                                                authRepository.register(usernameInput, emailInput, passwordInput),
                                                "Registrasi gagal"
                                            )
                                        }
                                        isLoggingIn = false
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = KuroTextPrimary,
                                    contentColor = KuroBgPrimary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("auth_submit_button")
                            ) {
                                Text(
                                    text = if (authMode == "LOGIN") "Masuk" else "Daftar Akun",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }

                            if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()) {
                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            isLoggingIn = true
                                            authError = null
                                            val tokenRes = requestGoogleIdToken(context)
                                            if (tokenRes.isFailure) {
                                                authError = tokenRes.exceptionOrNull()?.message
                                            } else {
                                                handleAuthResult(
                                                    authRepository.loginWithGoogle(tokenRes.getOrThrow()),
                                                    "Login Google gagal"
                                                )
                                            }
                                            isLoggingIn = false
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = KuroTextPrimary),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("google_login_button")
                                ) {
                                    Text(
                                        text = "Masuk dengan Google",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        GearLoadingOverlay(
            isLoading = isLoggingIn || isAdLoading,
            statusText = if (isAdLoading) "Memproses hadiah iklan..." else "Memproses akun..."
        )
    }

    // ===== Pilih username (akun yang belum punya profil) =====
    if (needUsername) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = KuroSurfaceElevated,
            title = { Text("Pilih Username", fontWeight = FontWeight.Bold, color = KuroTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Akun kamu belum punya username. Pilih username untuk melanjutkan.",
                        fontSize = 13.sp,
                        color = KuroTextSecondary
                    )
                    OutlinedTextField(
                        value = pickedUsername,
                        onValueChange = { pickedUsername = it.trim().lowercase(); pickedUsernameMsg = null },
                        placeholder = { Text("huruf kecil, angka, underscore") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pickedUsernameMsg != null) {
                        Text(pickedUsernameMsg!!, color = KuroError, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isLoggingIn = true
                            val res = authRepository.completeProfile(pickedUsername)
                            isLoggingIn = false
                            if (res.isSuccess) {
                                needUsername = false
                            } else {
                                pickedUsernameMsg = res.exceptionOrNull()?.message ?: "Gagal menyimpan username"
                            }
                        }
                    },
                    enabled = pickedUsername.length >= 3 && !isLoggingIn,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = KuroTextPrimary,
                        contentColor = KuroBgPrimary
                    )
                ) {
                    Text("Lanjutkan")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    needUsername = false
                    coroutineScope.launch {
                        isLoggingIn = true
                        try {
                            authRepository.logout()
                                    com.kano.playjv.core.state.RetainedStateStore.clear()
                        } finally {
                            isLoggingIn = false
                        }
                    }
                }) {
                    Text("Batal", color = KuroTextSecondary)
                }
            }
        )
    }

    if (showAdultDialog) {
        AlertDialog(
            onDismissRequest = { showAdultDialog = false },
            containerColor = KuroSurfaceElevated,
            title = { Text("Konten dewasa (18+)", color = KuroTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Genre ini berisi konten dewasa eksplisit. Aktifkan hanya jika usiamu 18 tahun ke atas.",
                    color = KuroTextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showAdultDialog = false
                    coroutineScope.launch {
                        preferences.setAdultEnabled(true)
                        com.kano.playjv.core.state.RetainedStateStore.clear()
                    }
                }) { Text("Saya 18+", color = KuroTextPrimary) }
            },
            dismissButton = {
                TextButton(onClick = { showAdultDialog = false }) { Text("Batal", color = KuroTextSecondary) }
            }
        )
    }


    // ===== Lupa password =====
    if (showForgotPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showForgotPasswordDialog = false },
            containerColor = KuroSurfaceElevated,
            title = { Text("Reset Password", fontWeight = FontWeight.Bold, color = KuroTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Masukkan email kamu. Link reset password akan dikirim ke email tersebut.",
                        fontSize = 13.sp,
                        color = KuroTextSecondary
                    )
                    OutlinedTextField(
                        value = forgotPasswordEmail,
                        onValueChange = { forgotPasswordEmail = it },
                        placeholder = { Text("Email kamu") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showForgotPasswordDialog = false
                        coroutineScope.launch {
                            isLoggingIn = true
                            try {
                                authRepository.resetPassword(forgotPasswordEmail)
                                authSuccessMsg = "Link reset password telah dikirim ke $forgotPasswordEmail"
                            } finally {
                                isLoggingIn = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = KuroTextPrimary,
                        contentColor = KuroBgPrimary
                    )
                ) {
                    Text("Kirim")
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPasswordDialog = false }) {
                    Text("Batal", color = KuroTextSecondary)
                }
            }
        )
    }
}
