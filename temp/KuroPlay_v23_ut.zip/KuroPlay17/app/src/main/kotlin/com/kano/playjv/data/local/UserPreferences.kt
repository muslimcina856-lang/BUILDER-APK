package com.kano.playjv.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.kano.playjv.core.model.PremiumStatus
import com.kano.playjv.core.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "kuro_preferences")

class UserPreferences(private val context: Context) {

    companion object {
        private val KEY_ID_TOKEN = stringPreferencesKey("id_token")
        private val KEY_REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        private val KEY_TOKEN_EXPIRY = longPreferencesKey("token_expiry")
        private val KEY_UID = stringPreferencesKey("uid")
        private val KEY_USERNAME = stringPreferencesKey("username")
        private val KEY_EMAIL = stringPreferencesKey("email")
        private val KEY_IS_OWNER = booleanPreferencesKey("is_owner")
        private val KEY_IS_ADMIN = booleanPreferencesKey("is_admin")
        private val KEY_KEYS = intPreferencesKey("keys")
        private val KEY_PREMIUM_ACTIVE = booleanPreferencesKey("premium_active")
        private val KEY_PREMIUM_PLAN = stringPreferencesKey("premium_plan")
        private val KEY_PREMIUM_EXPIRES = longPreferencesKey("premium_expires")
        private val KEY_AVATAR = stringPreferencesKey("avatar")
        private val KEY_MANGA_READER_MODE = stringPreferencesKey("manga_reader_mode")
        private val KEY_AUTO_NEXT = booleanPreferencesKey("auto_next")
        private val KEY_ADULT_ENABLED = booleanPreferencesKey("adult_enabled")
    }

    val userProfileFlow: Flow<UserProfile?> = context.dataStore.data.map { prefs ->
        val uid = prefs[KEY_UID] ?: return@map null
        val username = prefs[KEY_USERNAME] ?: ""
        val email = prefs[KEY_EMAIL] ?: ""
        val isOwner = prefs[KEY_IS_OWNER] ?: false
        val isAdmin = prefs[KEY_IS_ADMIN] ?: false
        val keys = prefs[KEY_KEYS] ?: 0
        val premiumActive = prefs[KEY_PREMIUM_ACTIVE] ?: false
        val premiumPlan = prefs[KEY_PREMIUM_PLAN]
        val premiumExpires = prefs[KEY_PREMIUM_EXPIRES] ?: 0L
        val avatar = prefs[KEY_AVATAR]

        UserProfile(
            uid = uid,
            username = username,
            email = email,
            isOwner = isOwner,
            isAdmin = isAdmin,
            premium = if (premiumActive || isOwner) {
                PremiumStatus(
                    active = true,
                    plan = if (isOwner) "owner" else premiumPlan,
                    expiresAt = if (isOwner) Long.MAX_VALUE else premiumExpires,
                    daysLeft = if (isOwner) 9999 else Math.max(0, ((premiumExpires - System.currentTimeMillis()) / 86400000).toInt()),
                    owner = isOwner
                )
            } else null,
            keys = keys,
            avatar = avatar
        )
    }

    val idTokenFlow: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[KEY_ID_TOKEN]
    }

    val refreshTokenFlow: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[KEY_REFRESH_TOKEN]
    }

    val tokenExpiryFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_TOKEN_EXPIRY] ?: 0L
    }

    val mangaReaderModeFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_MANGA_READER_MODE] ?: "VERTICAL"
    }

    val autoNextFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_AUTO_NEXT] ?: true
    }

    val adultEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ADULT_ENABLED] ?: false
    }

    suspend fun setAdultEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_ADULT_ENABLED] = enabled }
    }

    suspend fun setAutoNext(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_AUTO_NEXT] = enabled }
    }

    suspend fun saveAuthTokens(idToken: String, refreshToken: String, expiresInSec: Long = 3600) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ID_TOKEN] = idToken
            prefs[KEY_REFRESH_TOKEN] = refreshToken
            prefs[KEY_TOKEN_EXPIRY] = System.currentTimeMillis() + (expiresInSec * 1000)
        }
    }

    suspend fun saveUserProfile(profile: UserProfile) {
        context.dataStore.edit { prefs ->
            prefs[KEY_UID] = profile.uid
            prefs[KEY_USERNAME] = profile.username
            prefs[KEY_EMAIL] = profile.email
            prefs[KEY_IS_OWNER] = profile.isOwner
            prefs[KEY_IS_ADMIN] = profile.isAdmin
            prefs[KEY_KEYS] = profile.keys
            prefs[KEY_PREMIUM_ACTIVE] = profile.isOwner || (profile.premium?.active == true)
            prefs[KEY_PREMIUM_PLAN] = profile.premium?.plan ?: ""
            prefs[KEY_PREMIUM_EXPIRES] = profile.premium?.expiresAt ?: 0L
            profile.avatar?.let { prefs[KEY_AVATAR] = it }
        }
    }

    suspend fun updateKeys(newBalance: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_KEYS] = newBalance
        }
    }

    suspend fun updatePremiumStatus(status: PremiumStatus) {
        context.dataStore.edit { prefs ->
            prefs[KEY_PREMIUM_ACTIVE] = status.active
            status.plan?.let { prefs[KEY_PREMIUM_PLAN] = it }
            prefs[KEY_PREMIUM_EXPIRES] = status.expiresAt
        }
    }

    suspend fun setMangaReaderMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MANGA_READER_MODE] = mode
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.remove(KEY_ID_TOKEN)
            prefs.remove(KEY_REFRESH_TOKEN)
            prefs.remove(KEY_TOKEN_EXPIRY)
            prefs.remove(KEY_UID)
            prefs.remove(KEY_USERNAME)
            prefs.remove(KEY_EMAIL)
            prefs.remove(KEY_IS_OWNER)
            prefs.remove(KEY_IS_ADMIN)
            prefs.remove(KEY_KEYS)
            prefs.remove(KEY_PREMIUM_ACTIVE)
            prefs.remove(KEY_PREMIUM_PLAN)
            prefs.remove(KEY_PREMIUM_EXPIRES)
            prefs.remove(KEY_AVATAR)
        }
    }
}
