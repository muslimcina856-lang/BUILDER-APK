# Security

- Gunakan nombor ujian atau nombor sekunder.
- Jangan commit atau kongsi folder `wa-session`.
- Jangan log credential, key store atau fail auth.
- Android backup dimatikan dalam manifest.
- Aplikasi tidak membuka HTTP server atau port LAN.
- Flutter dan Node berkomunikasi melalui native bridge.
- App menghentikan queue dan socket apabila masuk background.
- Jangan jalankan npm dengan `--ignore-scripts`; manifest legacy memerlukan backport keselamatan.
- Jangan menaik taraf/menurunkan Baileys tanpa membaca advisory dan menguji semula patch.
- Revoke token Telegram yang pernah berada dalam ZIP asal.

Lihat `SECURITY_PATCH.md` untuk had dan mekanisme backport Baileys legacy.
