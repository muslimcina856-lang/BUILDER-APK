# Third-party components

Komponen utama yang dipasang ketika build:

- Flutter SDK — BSD-style license.
- `node_flutter` — MIT; package Android daripada uploader pub.dev yang belum disahkan.
- Node.js Mobile — MIT dan lesen komponen Node.js/V8 berkaitan.
- Baileys — MIT.
- Dependency Signal/libsignal tertentu mungkin menggunakan GPL-3.0.
- pino, mime-types, @hapi/boom dan dependency transitif — lesen masing-masing.

`node_modules` tidak disertakan dalam ZIP source ini. Selepas `npm install`, semak semua fail `LICENSE`, output `npm ls`, dan implikasi GPL sebelum mengedar APK kepada pihak lain.
