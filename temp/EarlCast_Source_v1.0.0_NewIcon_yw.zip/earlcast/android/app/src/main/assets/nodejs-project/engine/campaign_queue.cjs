const { normalizeError, sleep, uniqueTargets } = require('./utils.cjs');

class CampaignQueue {
  constructor({ emit, sendTarget }) {
    this.emit = emit;
    this.sendTarget = sendTarget;
    this.running = false;
    this.paused = false;
    this.stopRequested = false;
  }

  async start(options) {
    if (this.running) throw new Error('Satu penghantaran masih aktif.');

    const maxTargets = clampInt(options?.maxTargets, 1, 50, 30);
    const targets = uniqueTargets(options?.targets, maxTargets);
    const delayMs = clampInt(options?.delayMs, 1500, 60000, 2500);
    const retryCount = clampInt(options?.retryCount, 0, 2, 1);

    if (targets.length === 0) throw new Error('Tiada group sasaran yang sah.');

    this.running = true;
    this.paused = false;
    this.stopRequested = false;

    const stats = {
      total: targets.length,
      completed: 0,
      success: 0,
      failed: 0,
      skipped: 0,
    };
    const startedAt = Date.now();

    this.emit('campaign.started', { total: stats.total });

    try {
      for (const target of targets) {
        await this._waitWhilePaused();
        if (this.stopRequested) break;

        this.emit('campaign.progress', {
          ...stats,
          currentTarget: target.name,
        });

        const result = await this._sendWithRetry(target, options, retryCount);
        stats.completed += 1;
        if (result.ok) stats.success += 1;
        else if (result.permanent) stats.skipped += 1;
        else stats.failed += 1;

        this.emit('campaign.progress', {
          ...stats,
          currentTarget: target.name,
          lastError: result.error || '',
        });

        if (!this.stopRequested && stats.completed < stats.total) {
          await this._interruptibleDelay(delayMs);
        }
      }

      const durationSeconds = Math.max(0, Math.round((Date.now() - startedAt) / 1000));
      const payload = { ...stats, durationSeconds };
      if (this.stopRequested) this.emit('campaign.stopped', payload);
      else this.emit('campaign.completed', payload);
      return payload;
    } finally {
      this.running = false;
      this.paused = false;
      this.stopRequested = false;
    }
  }

  pause() {
    if (!this.running || this.paused) return;
    this.paused = true;
    this.emit('campaign.paused', {});
  }

  resume() {
    if (!this.running || !this.paused) return;
    this.paused = false;
    this.emit('campaign.resumed', {});
  }

  stop() {
    if (!this.running) return;
    this.stopRequested = true;
    this.paused = false;
  }

  async _sendWithRetry(target, options, retryCount) {
    let lastError = '';
    for (let attempt = 0; attempt <= retryCount; attempt += 1) {
      try {
        await this.sendTarget(target.id, options?.text, options?.attachments);
        return { ok: true, permanent: false, error: '' };
      } catch (error) {
        lastError = normalizeError(error);
        const permanent = isPermanentError(lastError);
        if (permanent || attempt >= retryCount) {
          return { ok: false, permanent, error: lastError };
        }
        await sleep(1500 * (attempt + 1));
      }
    }
    return { ok: false, permanent: false, error: lastError };
  }

  async _waitWhilePaused() {
    while (this.paused && !this.stopRequested) await sleep(200);
  }

  async _interruptibleDelay(delayMs) {
    const step = 200;
    let elapsed = 0;
    while (elapsed < delayMs && !this.stopRequested) {
      await this._waitWhilePaused();
      if (this.stopRequested) return;
      const wait = Math.min(step, delayMs - elapsed);
      await sleep(wait);
      elapsed += wait;
    }
  }
}

function isPermanentError(message) {
  const value = String(message || '').toLowerCase();
  return [
    'not-authorized',
    'not authorized',
    'forbidden',
    '401',
    '403',
    'group not found',
    'item-not-found',
    'not a participant',
  ].some((part) => value.includes(part));
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

module.exports = {
  CampaignQueue,
  isPermanentError,
  clampInt,
};
