const fs = require('fs');
const mime = require('mime-types');
const { safeBasename, sleep } = require('./utils.cjs');

const MAX_FILE_BYTES = 64 * 1024 * 1024;

function normalizeAttachments(rawAttachments) {
  const output = [];
  for (const item of Array.isArray(rawAttachments) ? rawAttachments : []) {
    if (output.length >= 10) break;
    const filePath = String(item?.path || '');
    if (!filePath || !fs.existsSync(filePath)) continue;
    const stats = fs.statSync(filePath);
    if (!stats.isFile() || stats.size > MAX_FILE_BYTES) continue;
    const mimeType = String(item?.mimeType || mime.lookup(filePath) || 'application/octet-stream');
    const category = inferCategory(mimeType);
    output.push({
      path: filePath,
      name: String(item?.name || safeBasename(filePath)),
      sizeBytes: stats.size,
      mimeType,
      category,
    });
  }
  return output;
}

function inferCategory(mimeType) {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  return 'document';
}

async function sendContent(sock, jid, text, rawAttachments) {
  const messageText = String(text || '').trim();
  const attachments = normalizeAttachments(rawAttachments);

  if (attachments.length === 0) {
    if (!messageText) throw new Error('Mesej kosong.');
    await sock.sendMessage(jid, { text: messageText });
    return { messagesSent: 1 };
  }

  let sent = 0;
  let captionUsed = false;

  for (let index = 0; index < attachments.length; index += 1) {
    const attachment = attachments[index];
    const canUseCaption = attachment.category !== 'audio';
    const caption = !captionUsed && canUseCaption ? messageText : '';

    if (attachment.category === 'audio' && !captionUsed && messageText) {
      await sock.sendMessage(jid, { text: messageText });
      sent += 1;
      captionUsed = true;
      await sleep(250);
    }

    const source = { url: attachment.path };
    let payload;
    switch (attachment.category) {
      case 'image':
        payload = {
          image: source,
          caption,
          mimetype: attachment.mimeType,
        };
        break;
      case 'video':
        payload = {
          video: source,
          caption,
          mimetype: attachment.mimeType,
        };
        break;
      case 'audio':
        payload = {
          audio: source,
          mimetype: attachment.mimeType,
          ptt: false,
          fileName: attachment.name,
        };
        break;
      default:
        payload = {
          document: source,
          mimetype: attachment.mimeType,
          fileName: attachment.name,
          caption,
        };
        break;
    }

    await sock.sendMessage(jid, payload);
    sent += 1;
    if (caption) captionUsed = true;
    if (index < attachments.length - 1) await sleep(350);
  }

  if (!captionUsed && messageText) {
    await sock.sendMessage(jid, { text: messageText });
    sent += 1;
  }

  return { messagesSent: sent };
}

module.exports = {
  MAX_FILE_BYTES,
  normalizeAttachments,
  inferCategory,
  sendContent,
};
