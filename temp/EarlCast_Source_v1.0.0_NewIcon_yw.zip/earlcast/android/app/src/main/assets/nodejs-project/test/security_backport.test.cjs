'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  PATCH_MARKER,
  patchSource,
} = require('../scripts/apply_security_backport.cjs');

test('security backport inserts self-only protocol guard', () => {
  const fixture = `
const protocolMsg = content?.protocolMessage
if(protocolMsg) {
  switch(protocolMsg.type) {}
}`;
  const result = patchSource(fixture);
  assert.equal(result.changed, true);
  assert.match(result.source, new RegExp(PATCH_MARKER));
  assert.match(result.source, /!message\.key\.fromMe/);
  assert.match(result.source, /PEER_DATA_OPERATION_REQUEST_RESPONSE_MESSAGE/);
});

test('security backport is idempotent', () => {
  const fixture = `
const protocolMsg = content?.protocolMessage
if(protocolMsg) {
  switch(protocolMsg.type) {}
}`;
  const first = patchSource(fixture);
  const second = patchSource(first.source);
  assert.equal(second.changed, false);
  assert.equal(second.alreadyPatched, true);
  assert.equal(second.source, first.source);
});

test('security backport refuses unknown source layout', () => {
  assert.throws(
    () => patchSource('const unrelated = true;'),
    /tidak dikenali/,
  );
});
