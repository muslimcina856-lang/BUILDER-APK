'use strict';

/**
 * Backports the guard from WhiskeySockets/Baileys commit
 * 3beb08eecfcb4e65722e674034bd84fb11a9de35 to the Node 18-compatible
 * Baileys 6.7.8 build used by this experimental mobile project.
 *
 * The install MUST fail when the patch cannot be applied. Shipping the
 * unpatched dependency would leave CVE-2026-48063 exposed.
 */

const fs = require('fs');
const path = require('path');

const PATCH_MARKER = 'EARLCAST_CVE_2026_48063_BACKPORT';
const ADVISORY = 'GHSA-qvv5-jq5g-4cgg / CVE-2026-48063';

function candidateFiles(projectRoot) {
  return [
    path.join(projectRoot, 'node_modules', 'baileys', 'lib', 'Utils', 'process-message.js'),
    path.join(projectRoot, 'node_modules', '@whiskeysockets', 'baileys', 'lib', 'Utils', 'process-message.js'),
  ];
}

function patchSource(source) {
  if (source.includes(PATCH_MARKER)) {
    return { source, changed: false, alreadyPatched: true };
  }

  const anchor = /(const protocolMsg\s*=\s*content\?\.protocolMessage\s*;?\s*\r?\n\s*if\s*\(protocolMsg\)\s*\{)/;
  const match = source.match(anchor);
  if (!match) {
    throw new Error('Struktur process-message.js tidak dikenali; patch keselamatan tidak diterapkan.');
  }

  const guard = `${match[1]}\n\t\t// ${PATCH_MARKER}\n\t\t// Backport guard rasmi: self-only protocol messages mesti datang daripada peranti sendiri.\n\t\tconst selfOnlyProtocolTypes = new Set([\n\t\t\tproto.Message.ProtocolMessage.Type.HISTORY_SYNC_NOTIFICATION,\n\t\t\tproto.Message.ProtocolMessage.Type.APP_STATE_SYNC_KEY_SHARE,\n\t\t\tproto.Message.ProtocolMessage.Type.LID_MIGRATION_MAPPING_SYNC,\n\t\t\tproto.Message.ProtocolMessage.Type.PEER_DATA_OPERATION_REQUEST_RESPONSE_MESSAGE\n\t\t].filter(type => type !== null && type !== undefined));\n\t\tif(\n\t\t\tprotocolMsg.type !== null\n\t\t\t&& protocolMsg.type !== undefined\n\t\t\t&& selfOnlyProtocolTypes.has(protocolMsg.type)\n\t\t\t&& !message.key.fromMe\n\t\t) {\n\t\t\tlogger?.warn?.({\n\t\t\t\tmsgId: message.key.id,\n\t\t\t\ttype: protocolMsg.type,\n\t\t\t\tfrom: message.key.participant || message.key.remoteJid\n\t\t\t}, 'dropping spoofed self-only protocolMessage from non-self origin');\n\t\t\treturn;\n\t\t}`;

  const patched = source.replace(anchor, guard);
  if (!patched.includes(PATCH_MARKER)) {
    throw new Error('Patch keselamatan gagal disahkan selepas pengubahsuaian.');
  }
  return { source: patched, changed: true, alreadyPatched: false };
}

function applyPatch(projectRoot = path.resolve(__dirname, '..')) {
  const target = candidateFiles(projectRoot).find((file) => fs.existsSync(file));
  if (!target) {
    throw new Error('Baileys process-message.js tidak dijumpai. Jalankan npm install daripada folder nodejs-project.');
  }

  const original = fs.readFileSync(target, 'utf8');
  const result = patchSource(original);
  if (result.changed) {
    fs.writeFileSync(target, result.source, 'utf8');
    console.log(`[security] ${ADVISORY} backport diterapkan pada ${path.relative(projectRoot, target)}`);
  } else {
    console.log(`[security] ${ADVISORY} backport sudah tersedia.`);
  }
  return target;
}

function verifyPatch(projectRoot = path.resolve(__dirname, '..')) {
  const target = candidateFiles(projectRoot).find((file) => fs.existsSync(file));
  if (!target) return false;
  return fs.readFileSync(target, 'utf8').includes(PATCH_MARKER);
}

if (require.main === module) {
  const root = path.resolve(__dirname, '..');
  if (process.argv.includes('--verify')) {
    if (!verifyPatch(root)) {
      console.error(`[security] ${ADVISORY} backport TIADA.`);
      process.exit(1);
    }
    console.log(`[security] ${ADVISORY} backport disahkan.`);
  } else {
    try {
      applyPatch(root);
    } catch (error) {
      console.error(`[security] Pemasangan dihentikan: ${error.message}`);
      process.exit(1);
    }
  }
}

module.exports = {
  ADVISORY,
  PATCH_MARKER,
  applyPatch,
  patchSource,
  verifyPatch,
};
