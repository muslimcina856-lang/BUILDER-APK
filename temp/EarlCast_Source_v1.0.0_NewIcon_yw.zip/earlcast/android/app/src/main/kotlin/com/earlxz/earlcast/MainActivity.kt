package com.earlxz.earlcast

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
