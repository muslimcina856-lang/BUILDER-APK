# Changelog

## 1.0.0

- Projek Flutter Android foreground-only.
- Embedded Node.js bridge menggunakan `node_flutter`.
- Pairing code, sesi lokal, reconnect dan logout.
- Group selector, search dan had sasaran.
- Composer teks dan multi-media lokal.
- Queue berurutan, delay, retry, pause, resume dan stop.
- Progress serta history lokal.
- Auto-reply private sekali satu sesi.
- Ikon EarlCast original.
- Manifest Baileys legacy dengan backport keselamatan wajib.
- Manifest pilihan Baileys 7 untuk runtime Node 20/22 custom.
