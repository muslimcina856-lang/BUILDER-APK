# Build Notes

## Binaan pertama

Binaan pertama mengambil masa lebih lama kerana npm memasang dependency Node ke dalam asset APK dan Gradle memproses library native Node.js bagi beberapa ABI.

## Perintah utama

Windows:

```powershell
.\scripts\build_apk.ps1
```

Linux/macOS:

```bash
./scripts/build_apk.sh
```

## Saiz APK

Embedded Node.js dan `node_modules` menjadikan APK lebih besar daripada aplikasi Flutter biasa. Gunakan split ABI:

```bash
flutter build apk --release --split-per-abi
```

## Pengujian minimum pada peranti sebenar

1. Pair nombor ujian.
2. Tutup dan buka semula app; sesi perlu reconnect.
3. Letak app di background; sambungan mesti diputuskan.
4. Buka semula app; sambungan mesti dicuba semula.
5. Refresh sekurang-kurangnya satu group.
6. Hantar satu teks kepada group ujian yang dibenarkan.
7. Uji gambar, video pendek, audio dan PDF.
8. Uji pause, resume dan stop.
9. Matikan internet semasa queue dan semak retry.
10. Logout dan pastikan sesi perlu dipair semula.

## Had pengesahan source ini

Pemeriksaan dalam persekitaran penjanaan meliputi:

- Syntax JavaScript/CJS.
- Ujian queue, utiliti dan patch keselamatan.
- Parse JSON, XML dan YAML asas.
- Imbasan token/secret tertanam.
- Pemeriksaan struktur ikon dan asset Android.

APK tidak dikompil di sini kerana Flutter SDK dan Android SDK tidak tersedia. Pemasangan npm penuh juga tidak dapat diselesaikan akibat registry/DNS persekitaran, jadi keserasian runtime sebenar mesti dibuktikan melalui build pertama pada PC dan peranti Android anda.
