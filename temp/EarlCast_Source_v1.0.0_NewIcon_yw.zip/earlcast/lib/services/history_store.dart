import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/app_models.dart';

class HistoryStore {
  static const int _maxEntries = 100;

  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    final historyDirectory = Directory('${directory.path}/earlcast');
    await historyDirectory.create(recursive: true);
    return File('${historyDirectory.path}/campaign_history.json');
  }

  Future<List<CampaignHistory>> load() async {
    final file = await _file();
    if (!await file.exists()) return <CampaignHistory>[];

    try {
      final source = await file.readAsString();
      final values = CampaignHistory.decodeList(source);
      values.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return values;
    } catch (_) {
      return <CampaignHistory>[];
    }
  }

  Future<void> save(List<CampaignHistory> values) async {
    final file = await _file();
    final limited = values.take(_maxEntries).toList(growable: false);
    await file.writeAsString(CampaignHistory.encodeList(limited), flush: true);
  }

  Future<void> clear() async {
    final file = await _file();
    if (await file.exists()) await file.delete();
  }
}
