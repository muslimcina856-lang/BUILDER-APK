import 'dart:async';

import 'package:flutter/material.dart';

import 'controllers/app_controller.dart';
import 'screens/home_shell.dart';
import 'theme/app_theme.dart';

class EarlCastApp extends StatefulWidget {
  const EarlCastApp({super.key});

  @override
  State<EarlCastApp> createState() => _EarlCastAppState();
}

class _EarlCastAppState extends State<EarlCastApp>
    with WidgetsBindingObserver {
  late final AppController controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    controller = AppController()..initialize();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        unawaited(controller.resumeFromBackground());
        break;
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        unawaited(controller.suspendForBackground());
        break;
      case AppLifecycleState.inactive:
        // Tidak hentikan sambungan untuk dialog sistem yang singkat.
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'EarlCast',
      theme: AppTheme.dark(),
      home: HomeShell(controller: controller),
    );
  }
}
