import 'dart:convert';

enum EngineState { starting, ready, stopped, error }

enum WaConnectionState {
  disconnected,
  connecting,
  pairing,
  connected,
  loggedOut,
  error,
}

enum CampaignState { idle, running, paused, stopping, completed, failed }

class GroupInfo {
  const GroupInfo({
    required this.id,
    required this.name,
    required this.participantCount,
    this.isAdmin = false,
  });

  final String id;
  final String name;
  final int participantCount;
  final bool isAdmin;

  factory GroupInfo.fromJson(Map<String, dynamic> json) => GroupInfo(
        id: json['id'] as String? ?? '',
        name: json['name'] as String? ?? 'Group tanpa nama',
        participantCount: (json['participantCount'] as num?)?.toInt() ?? 0,
        isAdmin: json['isAdmin'] as bool? ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'participantCount': participantCount,
        'isAdmin': isAdmin,
      };
}

class MediaAttachment {
  const MediaAttachment({
    required this.path,
    required this.name,
    required this.sizeBytes,
    required this.mimeType,
  });

  final String path;
  final String name;
  final int sizeBytes;
  final String mimeType;

  String get category {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    return 'document';
  }

  Map<String, dynamic> toJson() => {
        'path': path,
        'name': name,
        'sizeBytes': sizeBytes,
        'mimeType': mimeType,
        'category': category,
      };
}

class CampaignProgress {
  const CampaignProgress({
    this.state = CampaignState.idle,
    this.completed = 0,
    this.total = 0,
    this.success = 0,
    this.failed = 0,
    this.skipped = 0,
    this.currentTarget = '',
    this.startedAt,
  });

  final CampaignState state;
  final int completed;
  final int total;
  final int success;
  final int failed;
  final int skipped;
  final String currentTarget;
  final DateTime? startedAt;

  double get fraction => total == 0 ? 0 : completed / total;

  CampaignProgress copyWith({
    CampaignState? state,
    int? completed,
    int? total,
    int? success,
    int? failed,
    int? skipped,
    String? currentTarget,
    DateTime? startedAt,
  }) =>
      CampaignProgress(
        state: state ?? this.state,
        completed: completed ?? this.completed,
        total: total ?? this.total,
        success: success ?? this.success,
        failed: failed ?? this.failed,
        skipped: skipped ?? this.skipped,
        currentTarget: currentTarget ?? this.currentTarget,
        startedAt: startedAt ?? this.startedAt,
      );
}

class CampaignHistory {
  const CampaignHistory({
    required this.id,
    required this.createdAt,
    required this.preview,
    required this.targetCount,
    required this.success,
    required this.failed,
    required this.skipped,
    required this.mediaCount,
    required this.durationSeconds,
  });

  final String id;
  final DateTime createdAt;
  final String preview;
  final int targetCount;
  final int success;
  final int failed;
  final int skipped;
  final int mediaCount;
  final int durationSeconds;

  factory CampaignHistory.fromJson(Map<String, dynamic> json) => CampaignHistory(
        id: json['id'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
        preview: json['preview'] as String? ?? '',
        targetCount: (json['targetCount'] as num?)?.toInt() ?? 0,
        success: (json['success'] as num?)?.toInt() ?? 0,
        failed: (json['failed'] as num?)?.toInt() ?? 0,
        skipped: (json['skipped'] as num?)?.toInt() ?? 0,
        mediaCount: (json['mediaCount'] as num?)?.toInt() ?? 0,
        durationSeconds: (json['durationSeconds'] as num?)?.toInt() ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'preview': preview,
        'targetCount': targetCount,
        'success': success,
        'failed': failed,
        'skipped': skipped,
        'mediaCount': mediaCount,
        'durationSeconds': durationSeconds,
      };

  static String encodeList(List<CampaignHistory> values) =>
      jsonEncode(values.map((value) => value.toJson()).toList());

  static List<CampaignHistory> decodeList(String source) {
    final decoded = jsonDecode(source);
    if (decoded is! List) return <CampaignHistory>[];
    return decoded
        .whereType<Map>()
        .map((item) => CampaignHistory.fromJson(item.cast<String, dynamic>()))
        .toList();
  }
}
