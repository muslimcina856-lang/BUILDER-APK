class EngineEvent {
  const EngineEvent({
    required this.type,
    required this.payload,
    required this.timestamp,
  });

  final String type;
  final Map<String, dynamic> payload;
  final DateTime timestamp;

  factory EngineEvent.fromJson(Map<String, dynamic> json) => EngineEvent(
        type: json['type'] as String? ?? 'unknown',
        payload: (json['payload'] as Map?)?.cast<String, dynamic>() ??
            <String, dynamic>{},
        timestamp: DateTime.tryParse(json['timestamp'] as String? ?? '') ??
            DateTime.now(),
      );
}
