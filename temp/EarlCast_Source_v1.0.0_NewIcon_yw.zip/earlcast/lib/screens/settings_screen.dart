import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../services/settings_store.dart';
import '../widgets/common_widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.controller});

  final AppController controller;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController autoReplyController;
  late final FocusNode autoReplyFocusNode;

  @override
  void initState() {
    super.initState();
    autoReplyController = TextEditingController(
      text: widget.controller.settings.autoReplyText,
    );
    autoReplyFocusNode = FocusNode();
  }

  @override
  void dispose() {
    autoReplyController.dispose();
    autoReplyFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = widget.controller.settings;
    if (!autoReplyFocusNode.hasFocus &&
        autoReplyController.text != settings.autoReplyText) {
      autoReplyController.value = TextEditingValue(
        text: settings.autoReplyText,
        selection: TextSelection.collapsed(offset: settings.autoReplyText.length),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
      children: [
        const SectionHeader(
          title: 'Tetapan',
          subtitle: 'Kawalan queue dan auto-reply semasa app dibuka.',
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Queue penghantaran',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int>(
                  initialValue: settings.delayMs,
                  decoration: const InputDecoration(
                    labelText: 'Delay antara group',
                    prefixIcon: Icon(Icons.timer_outlined),
                  ),
                  items: const [
                    DropdownMenuItem(value: 1500, child: Text('1.5 saat')),
                    DropdownMenuItem(value: 2500, child: Text('2.5 saat')),
                    DropdownMenuItem(value: 5000, child: Text('5 saat')),
                    DropdownMenuItem(value: 10000, child: Text('10 saat')),
                  ],
                  onChanged: widget.controller.campaignActive
                      ? null
                      : (value) {
                          if (value == null) return;
                          _save(settings.copyWith(delayMs: value));
                        },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: settings.retryCount,
                  decoration: const InputDecoration(
                    labelText: 'Retry apabila gagal sementara',
                    prefixIcon: Icon(Icons.replay_rounded),
                  ),
                  items: const [
                    DropdownMenuItem(value: 0, child: Text('Tiada retry')),
                    DropdownMenuItem(value: 1, child: Text('1 kali')),
                    DropdownMenuItem(value: 2, child: Text('2 kali')),
                  ],
                  onChanged: widget.controller.campaignActive
                      ? null
                      : (value) {
                          if (value == null) return;
                          _save(settings.copyWith(retryCount: value));
                        },
                ),
                const SizedBox(height: 18),
                Text('Had sasaran: ${settings.maxTargets} group'),
                Slider(
                  value: settings.maxTargets.toDouble(),
                  min: 5,
                  max: 50,
                  divisions: 9,
                  label: settings.maxTargets.toString(),
                  onChanged: widget.controller.campaignActive
                      ? null
                      : (value) => _save(
                            settings.copyWith(maxTargets: value.round()),
                          ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: settings.autoReplyEnabled,
                  title: const Text(
                    'Auto-reply private',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'Balas sekali bagi setiap nombor dalam satu sesi aplikasi.',
                  ),
                  onChanged: (value) => _save(
                    settings.copyWith(autoReplyEnabled: value),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: autoReplyController,
                  focusNode: autoReplyFocusNode,
                  minLines: 3,
                  maxLines: 6,
                  maxLength: 1000,
                  decoration: const InputDecoration(
                    labelText: 'Teks auto-reply',
                    alignLabelWithHint: true,
                  ),
                  onChanged: (value) => _save(
                    settings.copyWith(autoReplyText: value),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.warning_amber_rounded,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Penggunaan bertanggungjawab',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Gunakan hanya untuk group yang anda urus atau mempunyai kebenaran. Aplikasi tidak menyediakan scrape ahli, hidden mention, autojoin, DM pukal atau mod penghantaran agresif.',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _save(AppSettings value) {
    widget.controller.updateSettings(value);
  }
}
