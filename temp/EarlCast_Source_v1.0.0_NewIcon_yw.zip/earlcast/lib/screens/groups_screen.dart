import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../widgets/common_widgets.dart';

class GroupsScreen extends StatelessWidget {
  const GroupsScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final filtered = controller.filteredGroups;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
          child: Column(
            children: [
              SectionHeader(
                title: 'Pilih group',
                subtitle:
                    '${controller.selectedGroupIds.length}/${controller.settings.maxTargets} dipilih',
                trailing: IconButton.filledTonal(
                  onPressed: controller.isConnected && !controller.groupsLoading
                      ? controller.refreshGroups
                      : null,
                  icon: controller.groupsLoading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.refresh_rounded),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                onChanged: controller.setGroupSearch,
                decoration: const InputDecoration(
                  hintText: 'Cari nama group',
                  prefixIcon: Icon(Icons.search_rounded),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: filtered.isEmpty
                          ? null
                          : controller.selectFilteredGroups,
                      icon: const Icon(Icons.done_all_rounded),
                      label: const Text('Pilih hasil carian'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: controller.selectedGroupIds.isEmpty
                          ? null
                          : controller.clearSelectedGroups,
                      icon: const Icon(Icons.clear_all_rounded),
                      label: const Text('Kosongkan'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: !controller.isConnected
              ? const EmptyState(
                  icon: Icons.link_off_rounded,
                  title: 'WhatsApp belum disambungkan',
                  message: 'Sambungkan akaun untuk mendapatkan senarai group.',
                )
              : controller.groupsLoading && controller.groups.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : filtered.isEmpty
                      ? const EmptyState(
                          icon: Icons.groups_outlined,
                          title: 'Tiada group ditemukan',
                          message: 'Refresh senarai atau ubah kata carian.',
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
                          itemCount: filtered.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final group = filtered[index];
                            final selected =
                                controller.selectedGroupIds.contains(group.id);
                            return Card(
                              margin: EdgeInsets.zero,
                              child: CheckboxListTile(
                                value: selected,
                                onChanged: (value) => controller.toggleGroup(
                                  group.id,
                                  value ?? false,
                                ),
                                controlAffinity:
                                    ListTileControlAffinity.trailing,
                                secondary: CircleAvatar(
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withValues(alpha: 0.12),
                                  child: Text(
                                    group.name.isEmpty
                                        ? '?'
                                        : group.name.substring(0, 1).toUpperCase(),
                                  ),
                                ),
                                title: Text(
                                  group.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                subtitle: Text(
                                  '${group.participantCount} ahli${group.isAdmin ? ' • Anda admin' : ''}',
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ],
    );
  }
}
