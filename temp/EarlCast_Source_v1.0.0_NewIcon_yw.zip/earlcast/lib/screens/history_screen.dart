import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../controllers/app_controller.dart';
import '../widgets/common_widgets.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
          child: SectionHeader(
            title: 'History penghantaran',
            subtitle: 'Disimpan lokal pada peranti ini sahaja.',
            trailing: IconButton.filledTonal(
              onPressed: controller.history.isEmpty
                  ? null
                  : () => _confirmClear(context),
              icon: const Icon(Icons.delete_outline_rounded),
            ),
          ),
        ),
        Expanded(
          child: controller.history.isEmpty
              ? const EmptyState(
                  icon: Icons.history_toggle_off_rounded,
                  title: 'Belum ada history',
                  message: 'Ringkasan penghantaran akan muncul di sini.',
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
                  itemCount: controller.history.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final item = controller.history[index];
                    final date = DateFormat('dd MMM yyyy, HH:mm').format(item.createdAt);
                    return Card(
                      margin: EdgeInsets.zero,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    item.preview,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  '${item.durationSeconds}s',
                                  style: const TextStyle(color: Colors.white54),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '$date • ${item.targetCount} group • ${item.mediaCount} media',
                              style: const TextStyle(color: Colors.white54),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _ResultChip(
                                  label: '${item.success} berjaya',
                                  icon: Icons.check_circle_outline_rounded,
                                ),
                                _ResultChip(
                                  label: '${item.failed} gagal',
                                  icon: Icons.error_outline_rounded,
                                ),
                                _ResultChip(
                                  label: '${item.skipped} skip',
                                  icon: Icons.skip_next_rounded,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Future<void> _confirmClear(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Padam semua history?'),
        content: const Text('Tindakan ini tidak boleh dipulihkan.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (confirmed == true) await controller.clearHistory();
  }
}

class _ResultChip extends StatelessWidget {
  const _ResultChip({required this.label, required this.icon});

  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15),
          const SizedBox(width: 5),
          Text(label, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
