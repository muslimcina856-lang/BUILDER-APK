import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import 'composer_screen.dart';
import 'connection_screen.dart';
import 'groups_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.controller});

  final AppController controller;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        final controller = widget.controller;
        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.bolt_rounded, color: Colors.black),
                ),
                const SizedBox(width: 12),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'EarlCast',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    Text(
                      'Local • Foreground only',
                      style: TextStyle(fontSize: 10, color: Colors.white54),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Tooltip(
                  message: _engineLabel(controller.engineState),
                  child: Center(
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _engineColor(controller.engineState),
                        boxShadow: [
                          BoxShadow(
                            color: _engineColor(controller.engineState)
                                .withValues(alpha: 0.35),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: Stack(
            children: [
              IndexedStack(
                index: index,
                children: [
                  ConnectionScreen(controller: controller),
                  GroupsScreen(controller: controller),
                  ComposerScreen(controller: controller),
                  HistoryScreen(controller: controller),
                  SettingsScreen(controller: controller),
                ],
              ),
              if (controller.notice.isNotEmpty)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 12,
                  child: SafeArea(
                    child: Material(
                      elevation: 10,
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF183D30),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.info_outline_rounded, size: 20),
                            const SizedBox(width: 10),
                            Expanded(child: Text(controller.notice)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (value) => setState(() => index = value),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.link_rounded),
                selectedIcon: Icon(Icons.link_rounded),
                label: 'Sambung',
              ),
              NavigationDestination(
                icon: Icon(Icons.groups_outlined),
                selectedIcon: Icon(Icons.groups_rounded),
                label: 'Group',
              ),
              NavigationDestination(
                icon: Icon(Icons.send_outlined),
                selectedIcon: Icon(Icons.send_rounded),
                label: 'Hantar',
              ),
              NavigationDestination(
                icon: Icon(Icons.history_rounded),
                label: 'History',
              ),
              NavigationDestination(
                icon: Icon(Icons.tune_rounded),
                label: 'Tetapan',
              ),
            ],
          ),
        );
      },
    );
  }

  String _engineLabel(EngineState state) => switch (state) {
        EngineState.starting => 'Engine sedang dimulakan',
        EngineState.ready => 'Engine tersedia',
        EngineState.stopped => 'Engine berhenti',
        EngineState.error => 'Engine bermasalah',
      };

  Color _engineColor(EngineState state) => switch (state) {
        EngineState.starting => Colors.amber,
        EngineState.ready => const Color(0xFF19C37D),
        EngineState.stopped => Colors.grey,
        EngineState.error => Colors.redAccent,
      };
}
