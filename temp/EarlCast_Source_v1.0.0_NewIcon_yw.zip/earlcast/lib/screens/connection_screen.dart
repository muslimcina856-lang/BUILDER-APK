import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';

class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({super.key, required this.controller});

  final AppController controller;

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  final phoneController = TextEditingController(text: '60');

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      children: [
        const SectionHeader(
          title: 'Sambungan WhatsApp',
          subtitle: 'Runtime berjalan hanya semasa aplikasi dibuka.',
        ),
        const SizedBox(height: 16),
        _ConnectionCard(controller: controller),
        const SizedBox(height: 16),
        if (!controller.isConnected) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Pair peranti',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Masukkan nombor bersama kod negara tanpa simbol +. Contoh: 60123456789.',
                    style: TextStyle(color: Colors.white60),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: const InputDecoration(
                      labelText: 'Nombor WhatsApp',
                      prefixIcon: Icon(Icons.phone_android_rounded),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: controller.engineState == EngineState.ready
                        ? () => controller.pair(phoneController.text)
                        : null,
                    icon: const Icon(Icons.password_rounded),
                    label: const Text('Jana pairing code'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: controller.engineState == EngineState.ready
                        ? controller.reconnect
                        : null,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Cuba sesi tersimpan'),
                  ),
                ],
              ),
            ),
          ),
        ],
        if (controller.pairingCode.isNotEmpty) ...[
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.phonelink_lock_rounded, size: 38),
                  const SizedBox(height: 12),
                  const Text('Pairing code'),
                  const SizedBox(height: 8),
                  SelectableText(
                    controller.pairingCode,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                  ),
                  const SizedBox(height: 12),
                  TextButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: controller.pairingCode),
                      );
                    },
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('Salin code'),
                  ),
                  const Text(
                    'WhatsApp → Linked devices → Link a device → Link with phone number.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60),
                  ),
                ],
              ),
            ),
          ),
        ],
        if (controller.isConnected) ...[
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: controller.groupsLoading
                      ? null
                      : controller.refreshGroups,
                  icon: controller.groupsLoading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.sync_rounded),
                  label: const Text('Refresh group'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _confirmLogout(context, controller),
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('Logout'),
                ),
              ),
            ],
          ),
        ],
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.shield_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'Sesi disimpan dalam storan private aplikasi. Jangan kongsi folder sesi atau fail backup dengan orang lain.',
                    style: TextStyle(color: Colors.white70),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _confirmLogout(
    BuildContext context,
    AppController controller,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Logout WhatsApp?'),
        content: const Text(
          'Sesi lokal akan dipadam dan perlu pair semula selepas ini.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
    if (confirmed == true) await controller.logout();
  }
}

class _ConnectionCard extends StatelessWidget {
  const _ConnectionCard({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final status = switch (controller.connectionState) {
      WaConnectionState.connected => ('Connected', const Color(0xFF19C37D)),
      WaConnectionState.connecting => ('Connecting', Colors.amber),
      WaConnectionState.pairing => ('Menunggu pairing', Colors.amber),
      WaConnectionState.loggedOut => ('Logged out', Colors.orange),
      WaConnectionState.error => ('Ralat', Colors.redAccent),
      WaConnectionState.disconnected => ('Disconnected', Colors.grey),
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: status.$2.withValues(alpha: 0.14),
                  child: Icon(Icons.chat_bubble_rounded, color: status.$2),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        controller.accountName.isEmpty
                            ? 'Belum disambungkan'
                            : controller.accountName,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                      ),
                      Text(
                        controller.accountNumber.isEmpty
                            ? status.$1
                            : controller.accountNumber,
                        style: TextStyle(color: status.$2),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: status.$2,
                  ),
                ),
              ],
            ),
            if (controller.errorMessage.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  controller.errorMessage,
                  style: const TextStyle(color: Colors.redAccent),
                ),
              ),
            ],
            const SizedBox(height: 16),
            Row(
              children: [
                MetricTile(
                  label: 'Group',
                  value: controller.groups.length.toString(),
                  icon: Icons.groups_rounded,
                ),
                const SizedBox(width: 10),
                MetricTile(
                  label: 'Dipilih',
                  value: controller.selectedGroupIds.length.toString(),
                  icon: Icons.check_circle_outline_rounded,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
