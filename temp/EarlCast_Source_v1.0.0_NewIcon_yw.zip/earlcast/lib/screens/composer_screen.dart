import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/app_models.dart';
import '../widgets/common_widgets.dart';

class ComposerScreen extends StatefulWidget {
  const ComposerScreen({super.key, required this.controller});

  final AppController controller;

  @override
  State<ComposerScreen> createState() => _ComposerScreenState();
}

class _ComposerScreenState extends State<ComposerScreen> {
  late final TextEditingController textController;

  @override
  void initState() {
    super.initState();
    textController = TextEditingController(text: widget.controller.draftText);
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
      children: [
        SectionHeader(
          title: 'Tulis mesej',
          subtitle:
              '${controller.selectedGroupIds.length} group • delay ${(controller.settings.delayMs / 1000).toStringAsFixed(1)} saat',
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: textController,
                  minLines: 5,
                  maxLines: 12,
                  maxLength: 4096,
                  enabled: !controller.campaignActive,
                  onChanged: controller.updateDraftText,
                  decoration: const InputDecoration(
                    hintText: 'Masukkan mesej. Teks akan dihantar sebagai caption media pertama apabila sesuai.',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: controller.campaignActive
                      ? null
                      : controller.pickAttachments,
                  icon: const Icon(Icons.attach_file_rounded),
                  label: const Text('Pilih gambar, video, audio atau dokumen'),
                ),
              ],
            ),
          ),
        ),
        if (controller.attachments.isNotEmpty) ...[
          const SizedBox(height: 16),
          const SectionHeader(
            title: 'Media dipilih',
            subtitle: 'Maksimum 10 fail dan 64 MB setiap fail.',
          ),
          const SizedBox(height: 10),
          ...List.generate(controller.attachments.length, (index) {
            final attachment = controller.attachments[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(_iconForCategory(attachment.category)),
                ),
                title: Text(
                  attachment.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: Text(
                  '${attachment.category.toUpperCase()} • ${_formatBytes(attachment.sizeBytes)}',
                ),
                trailing: IconButton(
                  onPressed: controller.campaignActive
                      ? null
                      : () => controller.removeAttachment(index),
                  icon: const Icon(Icons.close_rounded),
                ),
              ),
            );
          }),
        ],
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: _SummaryItem(
                    label: 'Sasaran',
                    value: '${controller.selectedGroupIds.length}',
                    icon: Icons.groups_rounded,
                  ),
                ),
                Expanded(
                  child: _SummaryItem(
                    label: 'Media',
                    value: '${controller.attachments.length}',
                    icon: Icons.perm_media_rounded,
                  ),
                ),
                Expanded(
                  child: _SummaryItem(
                    label: 'Retry',
                    value: '${controller.settings.retryCount}',
                    icon: Icons.replay_rounded,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (controller.campaign.state != CampaignState.idle)
          _CampaignProgressCard(controller: controller),
        const SizedBox(height: 16),
        if (!controller.campaignActive)
          FilledButton.icon(
            onPressed: controller.isConnected
                ? () => _confirmAndSend(context, controller)
                : null,
            icon: const Icon(Icons.send_rounded),
            label: const Text('Semak dan mula penghantaran'),
          )
        else
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: controller.campaign.state == CampaignState.paused
                      ? controller.resumeCampaign
                      : controller.pauseCampaign,
                  icon: Icon(
                    controller.campaign.state == CampaignState.paused
                        ? Icons.play_arrow_rounded
                        : Icons.pause_rounded,
                  ),
                  label: Text(
                    controller.campaign.state == CampaignState.paused
                        ? 'Sambung'
                        : 'Pause',
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: controller.stopCampaign,
                  icon: const Icon(Icons.stop_rounded),
                  label: const Text('Stop'),
                ),
              ),
            ],
          ),
        const SizedBox(height: 10),
        TextButton.icon(
          onPressed: controller.campaignActive
              ? null
              : () {
                  controller.clearComposer();
                  textController.clear();
                },
          icon: const Icon(Icons.delete_sweep_outlined),
          label: const Text('Kosongkan composer'),
        ),
      ],
    );
  }

  Future<void> _confirmAndSend(
    BuildContext context,
    AppController controller,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Sahkan penghantaran'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Sasaran: ${controller.selectedGroupIds.length} group'),
            Text('Media: ${controller.attachments.length} fail'),
            Text(
              'Delay: ${(controller.settings.delayMs / 1000).toStringAsFixed(1)} saat',
            ),
            const SizedBox(height: 12),
            const Text(
              'Pastikan group tersebut memang diurus oleh anda dan penerima menjangka mesej ini.',
              style: TextStyle(color: Colors.white60),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.send_rounded),
            label: const Text('Mula'),
          ),
        ],
      ),
    );

    if (confirmed == true) await controller.startCampaign();
  }

  IconData _iconForCategory(String category) => switch (category) {
        'image' => Icons.image_rounded,
        'video' => Icons.movie_rounded,
        'audio' => Icons.audio_file_rounded,
        _ => Icons.description_rounded,
      };

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

class _SummaryItem extends StatelessWidget {
  const _SummaryItem({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 6),
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
              ),
        ),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _CampaignProgressCard extends StatelessWidget {
  const _CampaignProgressCard({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final progress = controller.campaign;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    _statusLabel(progress.state),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
                Text('${(progress.fraction * 100).round()}%'),
              ],
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress.total == 0 ? null : progress.fraction,
              minHeight: 9,
              borderRadius: BorderRadius.circular(20),
            ),
            const SizedBox(height: 12),
            Text(
              '${progress.completed}/${progress.total} selesai${progress.currentTarget.isEmpty ? '' : ' • ${progress.currentTarget}'}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: Text('✅ ${progress.success} berjaya')),
                Expanded(child: Text('❌ ${progress.failed} gagal')),
                Expanded(child: Text('⏭ ${progress.skipped} skip')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _statusLabel(CampaignState state) => switch (state) {
        CampaignState.idle => 'Belum bermula',
        CampaignState.running => 'Sedang menghantar',
        CampaignState.paused => 'Dijeda',
        CampaignState.stopping => 'Sedang dihentikan',
        CampaignState.completed => 'Selesai',
        CampaignState.failed => 'Gagal',
      };
}
