import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/app_models.dart';
import '../models/engine_event.dart';
import '../services/history_store.dart';
import '../services/node_engine_service.dart';
import '../services/settings_store.dart';

class AppController extends ChangeNotifier {
  AppController({
    NodeEngineService? engine,
    HistoryStore? historyStore,
    SettingsStore? settingsStore,
  })  : _engine = engine ?? NodeEngineService(),
        _historyStore = historyStore ?? HistoryStore(),
        _settingsStore = settingsStore ?? SettingsStore();

  final NodeEngineService _engine;
  final HistoryStore _historyStore;
  final SettingsStore _settingsStore;
  final Uuid _uuid = const Uuid();

  StreamSubscription<EngineEvent>? _eventSubscription;
  Timer? _noticeTimer;

  EngineState engineState = EngineState.starting;
  WaConnectionState connectionState = WaConnectionState.disconnected;
  CampaignProgress campaign = const CampaignProgress();
  AppSettings settings = const AppSettings();

  String accountName = '';
  String accountNumber = '';
  String pairingCode = '';
  String notice = '';
  String errorMessage = '';
  String groupSearch = '';
  String draftText = '';
  bool groupsLoading = false;

  List<GroupInfo> groups = <GroupInfo>[];
  final Set<String> selectedGroupIds = <String>{};
  List<MediaAttachment> attachments = <MediaAttachment>[];
  List<CampaignHistory> history = <CampaignHistory>[];

  String _activeDraftPreview = '';
  int _activeMediaCount = 0;
  bool _foregroundSuspended = false;

  bool get isConnected => connectionState == WaConnectionState.connected;
  bool get campaignActive =>
      campaign.state == CampaignState.running ||
      campaign.state == CampaignState.paused ||
      campaign.state == CampaignState.stopping;

  List<GroupInfo> get filteredGroups {
    final query = groupSearch.trim().toLowerCase();
    if (query.isEmpty) return groups;
    return groups
        .where((group) => group.name.toLowerCase().contains(query))
        .toList(growable: false);
  }

  Future<void> initialize() async {
    settings = await _settingsStore.load();
    history = await _historyStore.load();
    notifyListeners();

    _eventSubscription = _engine.events.listen(_handleEngineEvent);
    try {
      await _engine.start();
      engineState = EngineState.ready;
      await _syncAutoReply();
      notifyListeners();
    } catch (error) {
      engineState = EngineState.error;
      errorMessage = error.toString();
      notifyListeners();
    }
  }

  Future<void> pair(String phoneNumber) async {
    final normalized = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');
    if (normalized.length < 8) {
      _showNotice('Masukkan nombor penuh bersama kod negara.');
      return;
    }

    pairingCode = '';
    connectionState = WaConnectionState.pairing;
    errorMessage = '';
    notifyListeners();
    await _engine.send('pair', {'phoneNumber': normalized});
  }

  Future<void> reconnect() async {
    connectionState = WaConnectionState.connecting;
    errorMessage = '';
    notifyListeners();
    await _engine.send('connect');
  }

  Future<void> suspendForBackground() async {
    if (_foregroundSuspended || !_engine.isStarted) return;
    _foregroundSuspended = true;
    if (campaignActive) await stopCampaign();
    try {
      await _engine.send('shutdown');
    } catch (_) {
      // Android mungkin menggantung proses sebelum arahan selesai.
    }
  }

  Future<void> resumeFromBackground() async {
    if (!_foregroundSuspended || !_engine.isStarted) return;
    _foregroundSuspended = false;
    try {
      connectionState = WaConnectionState.connecting;
      notifyListeners();
      await _engine.send('connect');
      await _syncAutoReply();
    } catch (error) {
      connectionState = WaConnectionState.error;
      errorMessage = error.toString();
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await _engine.send('logout');
    accountName = '';
    accountNumber = '';
    pairingCode = '';
    groups = <GroupInfo>[];
    selectedGroupIds.clear();
    connectionState = WaConnectionState.loggedOut;
    notifyListeners();
  }

  Future<void> refreshGroups() async {
    if (!isConnected) return;
    groupsLoading = true;
    notifyListeners();
    await _engine.send('getGroups');
  }

  void setGroupSearch(String value) {
    groupSearch = value;
    notifyListeners();
  }

  void toggleGroup(String groupId, bool selected) {
    if (selected) {
      if (selectedGroupIds.length >= settings.maxTargets) {
        _showNotice('Had semasa ialah ${settings.maxTargets} group.');
        return;
      }
      selectedGroupIds.add(groupId);
    } else {
      selectedGroupIds.remove(groupId);
    }
    notifyListeners();
  }

  void selectFilteredGroups() {
    for (final group in filteredGroups) {
      if (selectedGroupIds.length >= settings.maxTargets) break;
      selectedGroupIds.add(group.id);
    }
    notifyListeners();
  }

  void clearSelectedGroups() {
    selectedGroupIds.clear();
    notifyListeners();
  }

  void updateDraftText(String value) {
    draftText = value;
  }

  Future<void> pickAttachments() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: false,
      type: FileType.custom,
      allowedExtensions: const [
        'jpg',
        'jpeg',
        'png',
        'webp',
        'gif',
        'mp4',
        'mov',
        'mkv',
        'mp3',
        'm4a',
        'ogg',
        'wav',
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'ppt',
        'pptx',
        'txt',
        'zip',
      ],
    );

    if (result == null) return;

    final selected = <MediaAttachment>[];
    for (final platformFile in result.files.take(10)) {
      final path = platformFile.path;
      if (path == null || path.isEmpty) continue;
      final file = File(path);
      if (!await file.exists()) continue;
      final size = await file.length();
      if (size > 64 * 1024 * 1024) {
        _showNotice('${platformFile.name} melebihi had 64 MB.');
        continue;
      }
      selected.add(MediaAttachment(
        path: path,
        name: platformFile.name,
        sizeBytes: size,
        mimeType: _mimeForName(platformFile.name),
      ));
    }

    attachments = selected;
    notifyListeners();
  }

  void removeAttachment(int index) {
    if (index < 0 || index >= attachments.length) return;
    attachments = List<MediaAttachment>.of(attachments)..removeAt(index);
    notifyListeners();
  }

  void clearComposer() {
    draftText = '';
    attachments = <MediaAttachment>[];
    notifyListeners();
  }

  Future<bool> startCampaign() async {
    if (!isConnected) {
      _showNotice('Sambungkan WhatsApp dahulu.');
      return false;
    }
    if (selectedGroupIds.isEmpty) {
      _showNotice('Pilih sekurang-kurangnya satu group.');
      return false;
    }
    if (draftText.trim().isEmpty && attachments.isEmpty) {
      _showNotice('Masukkan teks atau pilih media.');
      return false;
    }
    if (selectedGroupIds.length > settings.maxTargets) {
      _showNotice('Jumlah group melebihi had semasa.');
      return false;
    }

    final selectedGroups = groups
        .where((group) => selectedGroupIds.contains(group.id))
        .map((group) => group.toJson())
        .toList(growable: false);

    final normalizedPreview = draftText.trim().replaceAll(RegExp(r'\s+'), ' ');
    _activeDraftPreview = normalizedPreview.isEmpty
        ? '(Media sahaja)'
        : normalizedPreview.substring(
            0,
            normalizedPreview.length > 120 ? 120 : normalizedPreview.length,
          );
    _activeMediaCount = attachments.length;

    campaign = CampaignProgress(
      state: CampaignState.running,
      total: selectedGroups.length,
      startedAt: DateTime.now(),
    );
    notifyListeners();

    await _engine.send('startCampaign', {
      'targets': selectedGroups,
      'text': draftText.trim(),
      'attachments': attachments.map((item) => item.toJson()).toList(),
      'delayMs': settings.delayMs,
      'retryCount': settings.retryCount,
      'maxTargets': settings.maxTargets,
    });
    return true;
  }

  Future<void> pauseCampaign() async {
    await _engine.send('pauseCampaign');
  }

  Future<void> resumeCampaign() async {
    await _engine.send('resumeCampaign');
  }

  Future<void> stopCampaign() async {
    campaign = campaign.copyWith(state: CampaignState.stopping);
    notifyListeners();
    await _engine.send('stopCampaign');
  }

  Future<void> updateSettings(AppSettings value) async {
    settings = value.copyWith(
      delayMs: value.delayMs.clamp(1500, 60000).toInt(),
      retryCount: value.retryCount.clamp(0, 2).toInt(),
      maxTargets: value.maxTargets.clamp(1, 50).toInt(),
    );
    if (selectedGroupIds.length > settings.maxTargets) {
      final retained = selectedGroupIds.take(settings.maxTargets).toSet();
      selectedGroupIds
        ..clear()
        ..addAll(retained);
    }
    await _settingsStore.save(settings);
    await _syncAutoReply();
    notifyListeners();
  }

  Future<void> clearHistory() async {
    history = <CampaignHistory>[];
    await _historyStore.clear();
    notifyListeners();
  }

  Future<void> _syncAutoReply() async {
    if (!_engine.isStarted) return;
    await _engine.send('setAutoReply', {
      'enabled': settings.autoReplyEnabled,
      'text': settings.autoReplyText.trim(),
    });
  }

  void _handleEngineEvent(EngineEvent event) {
    switch (event.type) {
      case 'engine.ready':
        engineState = EngineState.ready;
        break;
      case 'engine.error':
        engineState = EngineState.error;
        errorMessage = event.payload['message'] as String? ?? 'Ralat engine.';
        break;
      case 'command.error':
        errorMessage = event.payload['message'] as String? ?? 'Arahan gagal.';
        _showNotice(errorMessage);
        break;
      case 'connection.status':
        _applyConnectionStatus(event.payload);
        break;
      case 'pairing.code':
        pairingCode = event.payload['code'] as String? ?? '';
        connectionState = WaConnectionState.pairing;
        break;
      case 'groups.list':
        groupsLoading = false;
        final rawGroups = event.payload['groups'];
        if (rawGroups is List) {
          groups = rawGroups
              .whereType<Map>()
              .map((item) => GroupInfo.fromJson(item.cast<String, dynamic>()))
              .toList()
            ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
          selectedGroupIds.removeWhere(
            (id) => !groups.any((group) => group.id == id),
          );
        }
        break;
      case 'campaign.started':
        campaign = campaign.copyWith(
          state: CampaignState.running,
          total: (event.payload['total'] as num?)?.toInt() ?? campaign.total,
        );
        break;
      case 'campaign.paused':
        campaign = campaign.copyWith(state: CampaignState.paused);
        break;
      case 'campaign.resumed':
        campaign = campaign.copyWith(state: CampaignState.running);
        break;
      case 'campaign.progress':
        campaign = campaign.copyWith(
          state: CampaignState.running,
          completed: (event.payload['completed'] as num?)?.toInt() ?? 0,
          total: (event.payload['total'] as num?)?.toInt() ?? campaign.total,
          success: (event.payload['success'] as num?)?.toInt() ?? 0,
          failed: (event.payload['failed'] as num?)?.toInt() ?? 0,
          skipped: (event.payload['skipped'] as num?)?.toInt() ?? 0,
          currentTarget: event.payload['currentTarget'] as String? ?? '',
        );
        break;
      case 'campaign.completed':
      case 'campaign.stopped':
        unawaited(_completeCampaign(event));
        break;
      case 'campaign.error':
        campaign = campaign.copyWith(state: CampaignState.failed);
        errorMessage = event.payload['message'] as String? ?? 'Kempen gagal.';
        break;
      case 'notice':
        _showNotice(event.payload['message'] as String? ?? '');
        break;
    }
    notifyListeners();
  }

  void _applyConnectionStatus(Map<String, dynamic> payload) {
    final status = payload['status'] as String? ?? 'disconnected';
    connectionState = switch (status) {
      'connecting' => WaConnectionState.connecting,
      'pairing' => WaConnectionState.pairing,
      'connected' => WaConnectionState.connected,
      'loggedOut' => WaConnectionState.loggedOut,
      'error' => WaConnectionState.error,
      _ => WaConnectionState.disconnected,
    };

    accountName = payload['accountName'] as String? ?? accountName;
    accountNumber = payload['accountNumber'] as String? ?? accountNumber;
    final message = payload['message'] as String?;
    if (message != null && message.isNotEmpty) errorMessage = message;
    if (connectionState == WaConnectionState.connected) {
      pairingCode = '';
      unawaited(refreshGroups());
    }
  }

  Future<void> _completeCampaign(EngineEvent event) async {
    final success = (event.payload['success'] as num?)?.toInt() ?? campaign.success;
    final failed = (event.payload['failed'] as num?)?.toInt() ?? campaign.failed;
    final skipped = (event.payload['skipped'] as num?)?.toInt() ?? campaign.skipped;
    final total = (event.payload['total'] as num?)?.toInt() ?? campaign.total;
    final duration = (event.payload['durationSeconds'] as num?)?.toInt() ??
        DateTime.now().difference(campaign.startedAt ?? DateTime.now()).inSeconds;

    campaign = campaign.copyWith(
      state: CampaignState.completed,
      completed: success + failed + skipped,
      total: total,
      success: success,
      failed: failed,
      skipped: skipped,
      currentTarget: '',
    );

    history = <CampaignHistory>[
      CampaignHistory(
        id: _uuid.v4(),
        createdAt: DateTime.now(),
        preview: _activeDraftPreview,
        targetCount: total,
        success: success,
        failed: failed,
        skipped: skipped,
        mediaCount: _activeMediaCount,
        durationSeconds: duration,
      ),
      ...history,
    ];
    await _historyStore.save(history);
  }

  void _showNotice(String message) {
    if (message.isEmpty) return;
    notice = message;
    _noticeTimer?.cancel();
    _noticeTimer = Timer(const Duration(seconds: 4), () {
      notice = '';
      notifyListeners();
    });
    notifyListeners();
  }

  String _mimeForName(String name) {
    final extension = name.split('.').last.toLowerCase();
    return switch (extension) {
      'jpg' || 'jpeg' => 'image/jpeg',
      'png' => 'image/png',
      'webp' => 'image/webp',
      'gif' => 'image/gif',
      'mp4' => 'video/mp4',
      'mov' => 'video/quicktime',
      'mkv' => 'video/x-matroska',
      'mp3' => 'audio/mpeg',
      'm4a' => 'audio/mp4',
      'ogg' => 'audio/ogg',
      'wav' => 'audio/wav',
      'pdf' => 'application/pdf',
      'doc' => 'application/msword',
      'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xls' => 'application/vnd.ms-excel',
      'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'ppt' => 'application/vnd.ms-powerpoint',
      'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'txt' => 'text/plain',
      'zip' => 'application/zip',
      _ => 'application/octet-stream',
    };
  }

  @override
  void dispose() {
    _noticeTimer?.cancel();
    _eventSubscription?.cancel();
    unawaited(_engine.dispose());
    super.dispose();
  }
}
