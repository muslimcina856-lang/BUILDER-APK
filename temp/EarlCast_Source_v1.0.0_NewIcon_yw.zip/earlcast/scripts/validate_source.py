#!/usr/bin/env python3
"""Dependency-free source validation for EarlCast."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = ROOT / "nodejs-project"


def run(command: list[str], cwd: Path = ROOT) -> None:
    print(">", " ".join(command))
    subprocess.run(command, cwd=cwd, check=True)


def validate_json() -> None:
    for file in sorted(NODE.glob("package*.json")):
        json.loads(file.read_text(encoding="utf-8"))
        print(f"[ok] JSON {file.relative_to(ROOT)}")


def validate_xml() -> None:
    for file in sorted((ROOT / "android").rglob("*.xml")):
        ET.parse(file)
    print("[ok] Android XML")


def validate_secrets() -> None:
    patterns = {
        "Telegram bot token": re.compile(r"\b\d{7,12}:[A-Za-z0-9_-]{30,}\b"),
        "Generic private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    }
    excluded = {"SOURCE_MANIFEST.sha256"}
    for file in ROOT.rglob("*"):
        if not file.is_file() or file.name in excluded or ".git" in file.parts:
            continue
        if file.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".jar", ".zip"}:
            continue
        try:
            text = file.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for label, pattern in patterns.items():
            if pattern.search(text):
                raise RuntimeError(f"{label} dijumpai dalam {file.relative_to(ROOT)}")
    print("[ok] Imbasan secret asas")


def validate_icons() -> None:
    required = [
        ROOT / "assets/icon/app_icon.png",
        ROOT / "assets/icon/app_icon_foreground.png",
        ROOT / "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png",
    ]
    for file in required:
        if not file.is_file() or file.stat().st_size < 100:
            raise RuntimeError(f"Icon tidak sah: {file.relative_to(ROOT)}")
    print("[ok] Icon assets")


def write_manifest() -> None:
    output = ROOT / "SOURCE_MANIFEST.sha256"
    lines: list[str] = []
    for file in sorted(ROOT.rglob("*")):
        if not file.is_file() or file == output or "__pycache__" in file.parts:
            continue
        digest = hashlib.sha256(file.read_bytes()).hexdigest()
        lines.append(f"{digest}  {file.relative_to(ROOT).as_posix()}")
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[ok] {output.name} ({len(lines)} fail)")


def main() -> int:
    run(["node", "--check", "main.js"], cwd=NODE)
    for file in sorted((NODE / "engine").glob("*.cjs")):
        run(["node", "--check", str(file.relative_to(NODE))], cwd=NODE)
    run(["node", "--check", "scripts/apply_security_backport.cjs"], cwd=NODE)
    test_files = [str(file.relative_to(NODE)) for file in sorted((NODE / "test").glob("*.test.cjs"))]
    run(["node", "--test", *test_files], cwd=NODE)
    validate_json()
    validate_xml()
    validate_secrets()
    validate_icons()
    write_manifest()
    print("\nSemakan source lulus.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (subprocess.CalledProcessError, RuntimeError, json.JSONDecodeError, ET.ParseError) as error:
        print(f"\nSemakan gagal: {error}", file=sys.stderr)
        raise SystemExit(1)
