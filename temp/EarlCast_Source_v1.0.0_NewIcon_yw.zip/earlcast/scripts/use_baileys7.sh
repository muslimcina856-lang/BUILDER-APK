#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cp "$ROOT/nodejs-project/package.baileys7.json" "$ROOT/nodejs-project/package.json"
rm -f "$ROOT/nodejs-project/package-lock.json"
printf '%s\n' 'Manifest Baileys 7 diaktifkan. Gunakan hanya dengan runtime Node.js Mobile 20/22 custom.'
