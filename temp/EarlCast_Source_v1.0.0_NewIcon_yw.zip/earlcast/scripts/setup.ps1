$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (Get-Command py -ErrorAction SilentlyContinue) {
    py -3 scripts\bootstrap.py
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    python scripts\bootstrap.py
} else {
    throw "Python 3 tidak dijumpai dalam PATH."
}
