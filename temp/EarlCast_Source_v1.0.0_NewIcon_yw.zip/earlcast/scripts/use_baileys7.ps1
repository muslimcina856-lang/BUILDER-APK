$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Copy-Item "$Root\nodejs-project\package.baileys7.json" "$Root\nodejs-project\package.json" -Force
Remove-Item "$Root\nodejs-project\package-lock.json" -ErrorAction SilentlyContinue
Write-Host "Manifest Baileys 7 diaktifkan." -ForegroundColor Yellow
Write-Host "Ia hanya sesuai dengan runtime Node.js Mobile 20/22 custom dan masih perlu diuji pada Android." -ForegroundColor Yellow
