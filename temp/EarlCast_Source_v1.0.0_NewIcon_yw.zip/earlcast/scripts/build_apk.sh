#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
./scripts/setup.sh
flutter build apk --release
printf '\nAPK: build/app/outputs/flutter-apk/app-release.apk\n'
