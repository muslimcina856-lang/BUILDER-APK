#!/usr/bin/env python3
"""Prepare the Flutter Android project and embedded Node.js assets."""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android"
ASSET_TARGET = ANDROID / "app" / "src" / "main" / "assets" / "nodejs-project"
NODE_SOURCE = ROOT / "nodejs-project"


def run(command: list[str], cwd: Path = ROOT) -> None:
    print(f"\n> {' '.join(command)}")
    subprocess.run(command, cwd=cwd, check=True)


def executable(name: str) -> str:
    located = shutil.which(name)
    if not located:
        raise SystemExit(f"Perintah '{name}' tidak dijumpai dalam PATH.")
    return located


def ensure_android_scaffold() -> None:
    wrapper_jar = ANDROID / "gradle" / "wrapper" / "gradle-wrapper.jar"
    gradlew_bat = ANDROID / "gradlew.bat"
    gradlew = ANDROID / "gradlew"
    if wrapper_jar.exists() and (gradlew_bat.exists() or gradlew.exists()):
        return

    print("Android Gradle wrapper belum lengkap; menjana semula melalui Flutter...")
    run([
        executable("flutter"),
        "create",
        "--platforms=android",
        "--org=com.earlxz",
        "--project-name=earlcast",
        "--no-pub",
        ".",
    ])


def patch_android_build() -> None:
    kts = ANDROID / "app" / "build.gradle.kts"
    groovy = ANDROID / "app" / "build.gradle"

    if kts.exists():
        text = kts.read_text(encoding="utf-8")
        if "ndkVersion = flutter.ndkVersion" in text:
            text = text.replace(
                "ndkVersion = flutter.ndkVersion",
                'ndkVersion = "27.0.12077973"',
            )
        elif "ndkVersion" not in text:
            text = text.replace(
                "compileSdk = flutter.compileSdkVersion",
                'compileSdk = flutter.compileSdkVersion\n    ndkVersion = "27.0.12077973"',
            )
        text = re.sub(
            r"minSdk\s*=\s*flutter\.minSdkVersion",
            "minSdk = 24",
            text,
        )
        if 'namespace = "com.earlxz.earlcast"' not in text:
            text = re.sub(
                r'namespace\s*=\s*"[^"]+"',
                'namespace = "com.earlxz.earlcast"',
                text,
            )
        text = re.sub(
            r'applicationId\s*=\s*"[^"]+"',
            'applicationId = "com.earlxz.earlcast"',
            text,
        )
        kts.write_text(text, encoding="utf-8")
        return

    if groovy.exists():
        text = groovy.read_text(encoding="utf-8")
        text = text.replace(
            "ndkVersion flutter.ndkVersion",
            'ndkVersion "27.0.12077973"',
        )
        if "ndkVersion" not in text:
            text = text.replace(
                "compileSdk flutter.compileSdkVersion",
                'compileSdk flutter.compileSdkVersion\n    ndkVersion "27.0.12077973"',
            )
        text = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", text)
        text = re.sub(r'applicationId\s+"[^"]+"', 'applicationId "com.earlxz.earlcast"', text)
        groovy.write_text(text, encoding="utf-8")


def patch_manifest() -> None:
    manifest = ANDROID / "app" / "src" / "main" / "AndroidManifest.xml"
    text = manifest.read_text(encoding="utf-8")

    if "android.permission.INTERNET" not in text:
        text = text.replace(
            "<manifest",
            "<manifest",
            1,
        )
        insert_at = text.find(">") + 1
        text = (
            text[:insert_at]
            + '\n    <uses-permission android:name="android.permission.INTERNET" />'
            + '\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
            + text[insert_at:]
        )

    text = re.sub(r'android:label="[^"]*"', 'android:label="EarlCast"', text)
    text = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', text)
    if "android:allowBackup=" not in text:
        text = text.replace(
            "<application",
            '<application\n        android:allowBackup="false"',
            1,
        )
    if "android:fullBackupContent=" not in text:
        text = text.replace(
            'android:allowBackup="false"',
            'android:allowBackup="false"\n        android:fullBackupContent="false"',
            1,
        )
    if "android:usesCleartextTraffic=" not in text:
        text = text.replace(
            'android:fullBackupContent="false"',
            'android:fullBackupContent="false"\n        android:usesCleartextTraffic="false"',
            1,
        )
    if "android:roundIcon=" not in text:
        text = text.replace(
            'android:icon="@mipmap/ic_launcher"',
            'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"',
            1,
        )
    manifest.write_text(text, encoding="utf-8")


def sync_node_project() -> None:
    if ASSET_TARGET.exists():
        shutil.rmtree(ASSET_TARGET)
    shutil.copytree(
        NODE_SOURCE,
        ASSET_TARGET,
        ignore=shutil.ignore_patterns("node_modules", "package-lock.json"),
    )


def install_node_dependencies() -> None:
    npm = executable("npm")
    run([npm, "install", "--omit=dev", "--omit=optional", "--no-audit", "--no-fund"], cwd=ASSET_TARGET)


def main() -> None:
    executable("flutter")
    executable("dart")
    executable("node")
    ensure_android_scaffold()
    patch_android_build()
    patch_manifest()

    run([executable("flutter"), "pub", "get"])
    sync_node_project()
    install_node_dependencies()
    run([executable("dart"), "run", "flutter_launcher_icons"])

    print("\nPersediaan selesai.")
    print("Build APK: flutter build apk --release")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode) from exc
