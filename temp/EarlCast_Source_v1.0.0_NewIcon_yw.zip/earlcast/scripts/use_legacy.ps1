$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Copy-Item "$Root\nodejs-project\package.legacy.json" "$Root\nodejs-project\package.json" -Force
Remove-Item "$Root\nodejs-project\package-lock.json" -ErrorAction SilentlyContinue
Write-Host "Manifest keserasian Node 18 (Baileys 6.7.8 + backport wajib) diaktifkan." -ForegroundColor Green
