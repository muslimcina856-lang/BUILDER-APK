#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cp "$ROOT/nodejs-project/package.legacy.json" "$ROOT/nodejs-project/package.json"
rm -f "$ROOT/nodejs-project/package-lock.json"
printf '%s\n' 'Manifest keserasian Node 18 (Baileys 6.7.8 + backport wajib) diaktifkan.'
