$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

& "$PSScriptRoot\setup.ps1"
flutter build apk --release
Write-Host "`nAPK: build\app\outputs\flutter-apk\app-release.apk" -ForegroundColor Green
