# Adapt Pool — implementation status

## Implemented in this source drop

- Official identity: Adapt Pool / `com.adaptez.pool`.
- **Version lock:** `versionCode 1`, `versionName "1"` — do not change unless explicitly requested.
- User-selected billiards icon exported to Android launcher densities and Play Store 512 px asset.
- Adapt Chess-style shell outside the match: Main, Sejarah, Prestasi.
- True OpenGL ES 2.0 3D pool table with perspective camera, depth buffer, glossy sphere meshes, stripe shader, numbered balls, cue, cushions, layered pocket mouths, shadows and lighting.
- Sphere mesh upgraded to 24×48 segments; pockets/rings use 64 segments.
- Fixed-step pool physics at 120 Hz, presented at approximately 60 Hz during ball motion.
- Ball/rail collision, rolling friction, pocket detection, cushion rebound and side/follow/draw response.
- Direct cue interaction: touch the 3D cue, move sideways to aim, pull the cue backward to build power, release to strike. Two-finger drag orbits the camera.
- Cue-ball in hand is manipulated by touching and dragging the cue ball itself using screen-to-3D-table unprojection.
- New rack always starts with HUMAN as breaker (explicit Adapt Pool house rule), with cue-ball in hand above/behind the Head String.
- Standard scratch/foul gives the incoming side cue-ball in hand anywhere; break-specific fouls can restrict placement above/behind the Head String.
- The same cue-ball placement rules apply to AI. AI searches legal placement positions before its shot.
- WPA 8-Ball digital rules engine: rack requirements, legal/illegal break choices, 8-ball-on-break cases, object-ball-off-table break cases, open table, group assignment, standard call shot, safety, legal first contact, rail-after-contact, Head String restrictions, cue-ball in hand, spotting, 8-ball win/loss, and stalemate re-rack primitive.
- Standard obvious called shots are inferred from aim; ambiguous bank/combo shots can use optional manual **CALL** (called ball + called pocket), while explicit safety and 8-ball pocket calls remain available. Physical-only fouls that cannot exist through digital input are structurally prevented rather than silently omitted.
- AI core uses recursive **minimax with alpha-beta pruning**. Search depth, aim error, power error and search budget are level-based (1–999).
- Player learning is a separate additive **counter layer only**: aggression, safety, power, spin, bank use and pot success can alter tactical counter weights but never core difficulty/search depth/aim or power error.
- High-level AI search runs on `Dispatchers.Default` so minimax work does not block the UI thread.
- Local Room history and performance statistics.
- Procedural low-latency AudioTrack PCM for cue, collision and pocket sounds.

## Verification performed here

- Pure Kotlin domain harness: `ALL_DOMAIN_CHECKS_PASS`.
- Harness covers first-break policy, cue-ball placement, called shots, groups, safety, scratch, 8-ball win, open-table 8-ball edge, illegal break choices, 8-ball off-table break choices, spotting, Head String play, AI placement, level-only core difficulty and counter-layer separation.
- Renderer + touch surface compile against Android/OpenGL API stubs: `RENDERER_SURFACE_SYNTAX_PASS`.
- ViewModel compiles against lifecycle/data stubs plus real coroutines: `VIEWMODEL_SYNTAX_PASS`.
- Level 999 tactical minimax benchmark on the JVM completed without UI-thread involvement; Android runtime timing will vary by device.
- Version declaration rechecked: `versionCode 1`, `versionName "1"`.

## Environment limitation

A full Android Gradle build cannot run in this sandbox because the Gradle wrapper tries to download Gradle 8.6 from `services.gradle.org`, while outbound access for that dependency is unavailable. The failed verification is environmental (`UnknownHostException`), not presented as a successful APK build. Run `./gradlew testDebugUnitTest assembleDebug` on a machine with normal Gradle/Google Maven access for final device verification.
