# Adapt Pool

Adapt Pool ialah permainan 8-Ball 3D Android luar talian dengan lawan AI minimax Level 1–999. Profil pembelajaran pemain tidak menentukan kekuatan asas AI; ia hanya menjadi lapisan counter tambahan terhadap corak permainan pemain.

## Identiti projek

- Nama: `Adapt Pool`
- Package / applicationId: `com.adaptez.pool`
- `versionCode`: `1`
- `versionName`: `1`
- Level AI: `1–999`
- UI luar perlawanan: struktur ringkas Adapt Chess — `Main`, `Sejarah`, `Prestasi`
- Gameplay: OpenGL ES 2.0 + fizik fixed-step 120 Hz
- Penyimpanan: Room, lokal

> Version code dan version name dikunci pada `1` sehingga pemilik projek meminta perubahan.

## Kawalan match 3D

- **Break pertama:** manusia sentiasa breaker. Cue ball boleh disentuh dan diseret dalam kawasan sah di belakang Head String sebelum break.
- **Aim:** sentuh batang cue 3D dan gerakkan jari ke sisi. Batang dan guideline berputar terus bersama input.
- **Power:** masih memegang batang cue, tarik ke belakang. Jarak tarik menentukan kuasa; lepaskan untuk strike.
- **Kamera:** dua jari untuk orbit kamera tanpa mengganggu aim/power cue.
- **Spin / English:** Left, Draw, Center, Follow, Right.
- **Ball-in-hand:** sentuh **cue ball** dan drag terus pada meja. Posisi disahkan terhadap rail, overlap dan sekatan Head String. Ini digunakan semasa setup break serta selepas scratch/foul yang memberikan ball-in-hand.
- **AI ball-in-hand:** AI menggunakan search penempatan sah sebelum minimax memilih pukulan.

Objek lain tidak boleh diseret sesuka hati. Hanya cue ball boleh dipindahkan apabila rules memberi cue-ball in hand.

## Ruleset 8-Ball

Engine mengikut WPA 8-Ball untuk permainan digital, dengan satu house rule projek: **manusia sentiasa melakukan break pertama**.

Dilaksanakan termasuk:
- susunan rack (8 di tengah; sudut belakang satu solid + satu stripe),
- cue-ball in hand di belakang Head String untuk break,
- legal break / illegal break dan pilihan pemain masuk,
- 8-ball masuk pada legal break,
- 8-ball masuk pada foul break,
- object ball atau 8-ball keluar meja pada break dan pilihan/spot yang betul,
- open table dan pemilihan solids/stripes,
- called shot pada setiap non-break shot; obvious ball+pocket boleh diinfer daripada aim, manakala bank/combo/shot ambigu boleh ditetapkan melalui **CALL** manual (called ball + called pocket),
- explicit safety,
- legal first contact,
- no-rail-after-contact,
- cue-ball scratch / off-table,
- object-ball off-table,
- cue-ball in hand anywhere selepas standard foul,
- Bad Play from Above/Behind Head String selepas break-foul restriction,
- pilihan meminta legal object ball terdekat Head String di-spot apabila semua sasaran sah berada di kawasan itu,
- continuation selepas called shot yang sah,
- 8-ball called-pocket win/loss,
- stalemate re-rack primitive yang mengekalkan breaker asal.

Foul fizikal seperti touched ball, double-hit/push input manual, bermain ketika bola masih bergerak dan out-of-turn tidak “dipadam”; UI/engine menghalang tindakan tersebut daripada boleh dihantar sebagai input permainan.

## AI: minimax core + learning counter

### Core AI
Kekuatan asas hanya datang daripada level:
- Level 1–999,
- aim error,
- power error,
- search budget,
- minimax depth,
- alpha-beta pruning.

Minimax menilai tree tactical pukulan untuk kedua-dua pihak (AI maximize, manusia minimize), termasuk pot, continuation, safety, kumpulan, 8-ball dan keadaan giliran. Pengiraan AI dijalankan pada background dispatcher supaya UI tidak tersekat.

### Counter layer
Profil pembelajaran menyimpan:
- aggression,
- safety tendency,
- average power,
- spin usage,
- bank usage,
- pot success.

Data ini hanya menambah counter weights pada evaluation. Ia **tidak** menukar search depth, aim error, power error atau base difficulty pada level yang sama.

## 3D dan kelancaran

- Perspective OpenGL camera + depth buffer.
- 3D sphere mesh 24×48 bagi setiap bola, specular/rim lighting, stripe shader dan label nombor.
- Pocket berlapis rim/mouth/inner untuk memberi kedalaman visual.
- Cue benar-benar berada dalam world 3D; hit-testing dibuat daripada projection world→screen.
- Drag cue ball menggunakan inverse view-projection screen→table, bukan pemetaan 2D palsu.
- Cue preview dirender terus ketika drag sebelum state Compose round-trip, jadi aim/pull terasa responsif.
- Physics fixed-step 120 Hz; presentation state sekitar 60 Hz ketika bola bergerak.
- Minimax berat dijalankan di background thread.

## Build

Keperluan:
- Android Studio / Android SDK 36
- JDK 17
- Gradle wrapper 8.6

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

## Struktur utama

- `domain/model/PoolModels.kt` — state, rules state, break decisions
- `domain/engine/PoolPhysics.kt` — fizik fixed-step
- `domain/engine/PoolRules.kt` — WPA-style 8-Ball rules engine
- `domain/engine/ShotCallResolver.kt` — obvious digital call-shot resolver
- `domain/ai/AdaptivePoolAi.kt` — minimax + alpha-beta + counter profile
- `presentation/pool/PoolOpenGLRenderer.kt` — 3D renderer / projection / unprojection
- `presentation/pool/PoolOpenGLSurfaceView.kt` — direct cue, cue-ball drag, camera gestures
- `presentation/pool/PoolViewModel.kt` — match orchestration, AI, rules and persistence
- `presentation/history/HistoryScreen.kt` — sejarah
- `presentation/stats/StatsScreen.kt` — prestasi dan counter insights
