package com.adaptez.pool.presentation.pool

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import kotlin.math.hypot
import kotlin.math.max

internal class PoolOpenGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private enum class GestureMode { NONE, CUE, BALL_IN_HAND, CAMERA }

    private val poolRenderer = PoolOpenGLRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var cueAxisX = 0f
    private var cueAxisY = 1f
    private var cueNormalX = -1f
    private var cueNormalY = 0f
    private var pullPixels = 0f
    private var currentPower = 0.08
    private var mode = GestureMode.NONE

    private var canAim = false
    private var ballInHandMode = false
    private var onAimDrag: ((Double) -> Unit)? = null
    private var onCueBallMove: ((Double, Double) -> Unit)? = null
    private var onCuePull: ((Double) -> Unit)? = null
    private var onCueRelease: ((Double) -> Unit)? = null
    private var onCueCancel: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val cueHitThresholdPx get() = 30f * density
    private val cueBallHitThresholdPx get() = 34f * density
    private val fireThresholdPx get() = 18f * density
    private val maxPullPx get() = max(120f * density, minOf(width, height) * 0.30f)

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8,8,8,8,24,0)
        setRenderer(poolRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        preserveEGLContextOnPause = true
    }

    fun bindInteraction(
        canAim: Boolean,
        ballInHandMode: Boolean,
        onAimDrag: (Double) -> Unit,
        onCueBallMove: (Double, Double) -> Unit,
        onCuePull: (Double) -> Unit,
        onCueRelease: (Double) -> Unit,
        onCueCancel: () -> Unit
    ) {
        this.canAim = canAim
        this.ballInHandMode = ballInHandMode
        this.onAimDrag = onAimDrag
        this.onCueBallMove = onCueBallMove
        this.onCuePull = onCuePull
        this.onCueRelease = onCueRelease
        this.onCueCancel = onCueCancel
    }

    fun updateScene(scene: PoolOpenGLScene) {
        queueEvent { poolRenderer.updateScene(scene) }
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                pullPixels = 0f
                currentPower = 0.08
                mode = when {
                    canAim && poolRenderer.isCueHit(event.x, event.y, cueHitThresholdPx) -> {
                        captureCueAxis()
                        GestureMode.CUE
                    }
                    ballInHandMode && poolRenderer.isCueBallHit(event.x, event.y, cueBallHitThresholdPx) -> GestureMode.BALL_IN_HAND
                    else -> GestureMode.CAMERA
                }
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                mode = GestureMode.CAMERA
                lastX = averageX(event)
                lastY = averageY(event)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    if (mode == GestureMode.CUE) cancelCueGesture()
                    mode = GestureMode.CAMERA
                    val x = averageX(event)
                    val y = averageY(event)
                    val dx = x - lastX
                    val dy = y - lastY
                    lastX = x
                    lastY = y
                    queueEvent { poolRenderer.orbit(dx, dy) }
                    requestRender()
                    return true
                }

                val dx = event.x - lastX
                val dy = event.y - lastY
                lastX = event.x
                lastY = event.y
                when (mode) {
                    GestureMode.CUE -> {
                        val normalMove = dx * cueNormalX + dy * cueNormalY
                        val aimDelta = normalMove * 0.115
                        if (kotlin.math.abs(aimDelta) > 0.001) {
                            poolRenderer.previewAimDelta(aimDelta)
                            onAimDrag?.invoke(aimDelta)
                        }
                        val totalDx = event.x - downX
                        val totalDy = event.y - downY
                        pullPixels = max(0f, totalDx * cueAxisX + totalDy * cueAxisY)
                        currentPower = (0.08 + 0.92 * (pullPixels / maxPullPx).coerceIn(0f, 1f)).toDouble()
                        poolRenderer.previewCuePullback(currentPower)
                        onCuePull?.invoke(currentPower)
                        requestRender()
                        return true
                    }
                    GestureMode.BALL_IN_HAND -> {
                        dispatchCueBallMove(event.x, event.y)
                        requestRender()
                        return true
                    }
                    GestureMode.CAMERA -> {
                        queueEvent { poolRenderer.orbit(dx, dy) }
                        requestRender()
                        return true
                    }
                    GestureMode.NONE -> Unit
                }
            }

            MotionEvent.ACTION_UP -> {
                if (mode == GestureMode.CUE) {
                    if (pullPixels >= fireThresholdPx) {
                        onCueRelease?.invoke(currentPower)
                    } else {
                        cancelCueGesture()
                    }
                }
                mode = GestureMode.NONE
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                if (mode == GestureMode.CUE) cancelCueGesture()
                mode = GestureMode.NONE
                return true
            }
        }
        return true
    }

    private fun captureCueAxis() {
        val geometry = poolRenderer.cueScreenGeometry() ?: return
        val vx = geometry.buttX - geometry.tipX
        val vy = geometry.buttY - geometry.tipY
        val length = hypot(vx, vy).coerceAtLeast(0.001f)
        cueAxisX = vx / length
        cueAxisY = vy / length
        cueNormalX = -cueAxisY
        cueNormalY = cueAxisX
    }

    private fun cancelCueGesture() {
        currentPower = 0.08
        pullPixels = 0f
        poolRenderer.previewCuePullback(currentPower)
        onCueCancel?.invoke()
        requestRender()
    }

    private fun dispatchCueBallMove(screenX: Float, screenY: Float) {
        val table = poolRenderer.tablePositionFromScreen(screenX, screenY) ?: return
        onCueBallMove?.invoke(table.x, table.y)
    }

    private fun averageX(event: MotionEvent): Float {
        var total = 0f
        for (i in 0 until event.pointerCount) total += event.getX(i)
        return total / event.pointerCount.coerceAtLeast(1)
    }

    private fun averageY(event: MotionEvent): Float {
        var total = 0f
        for (i in 0 until event.pointerCount) total += event.getY(i)
        return total / event.pointerCount.coerceAtLeast(1)
    }
}
