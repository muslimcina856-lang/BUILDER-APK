package com.adaptez.pool.domain.model

import kotlin.math.hypot

data class Vec2(val x: Double, val y: Double) {
    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
    operator fun times(scale: Double) = Vec2(x * scale, y * scale)
    operator fun div(scale: Double) = Vec2(x / scale, y / scale)
    fun length(): Double = hypot(x, y)
    fun normalized(): Vec2 = length().takeIf { it > 1e-9 }?.let { this / it } ?: ZERO
    fun dot(other: Vec2): Double = x * other.x + y * other.y
    companion object { val ZERO = Vec2(0.0, 0.0) }
}

enum class BallGroup { OPEN, SOLIDS, STRIPES }
enum class PlayerSeat { HUMAN, AI }
enum class CueBallPlacementRule { NONE, ANYWHERE, BEHIND_HEAD_STRING }

enum class BreakChoice {
    ACCEPT_TABLE,
    TAKE_CUE_BALL_HEAD_STRING,
    RERACK_AND_BREAK_SELF,
    RERACK_AND_BREAK_OPPONENT,
    SPOT_EIGHT_AND_CONTINUE,
    SPOT_EIGHT_AND_ACCEPT_TABLE,
    SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING,
    REBREAK
}

data class BreakDecision(
    val chooser: PlayerSeat,
    val originalBreaker: PlayerSeat,
    val reason: String,
    val options: List<BreakChoice>
)

data class PoolBall(
    val number: Int,
    val position: Vec2,
    val velocity: Vec2 = Vec2.ZERO,
    val angularVelocity: Vec2 = Vec2.ZERO,
    val pocketed: Boolean = false
) {
    val group: BallGroup
        get() = when (number) {
            in 1..7 -> BallGroup.SOLIDS
            in 9..15 -> BallGroup.STRIPES
            else -> BallGroup.OPEN
        }
}

data class PoolGameState(
    val balls: List<PoolBall>,
    val turn: PlayerSeat = PlayerSeat.HUMAN,
    val breaker: PlayerSeat = PlayerSeat.HUMAN,
    val humanGroup: BallGroup = BallGroup.OPEN,
    val aiGroup: BallGroup = BallGroup.OPEN,
    val isBreakShot: Boolean = true,
    val ballInHand: Boolean = false,
    val cueBallPlacementRule: CueBallPlacementRule = CueBallPlacementRule.NONE,
    val shotNumber: Int = 0,
    val calledBall: Int? = null,
    val calledPocket: Int? = null,
    val safetyCalled: Boolean = false,
    val gameOver: Boolean = false,
    val winner: PlayerSeat? = null
) {
    fun groupFor(player: PlayerSeat): BallGroup = if (player == PlayerSeat.HUMAN) humanGroup else aiGroup
    fun remaining(group: BallGroup): Int = balls.count { !it.pocketed && it.group == group }
    fun ball(number: Int): PoolBall? = balls.firstOrNull { it.number == number }

    companion object {
        const val TABLE_HALF_LENGTH = 1.42
        const val TABLE_HALF_WIDTH = 0.71
        const val BALL_RADIUS = 0.028575
        const val HEAD_STRING_X = -TABLE_HALF_LENGTH / 2.0
        const val FOOT_SPOT_X = 0.72

        fun playerBreakRack(): PoolGameState = standardRack().copy(
            turn = PlayerSeat.HUMAN,
            breaker = PlayerSeat.HUMAN,
            isBreakShot = true,
            ballInHand = true,
            cueBallPlacementRule = CueBallPlacementRule.BEHIND_HEAD_STRING,
            shotNumber = 0,
            calledBall = null,
            calledPocket = null,
            safetyCalled = false,
            gameOver = false,
            winner = null
        )

        fun standardRack(): PoolGameState {
            val cue = PoolBall(0, Vec2(-0.92, 0.0))
            // WPA 8-ball rack essentials: 8 in the center of the rack and one solid + one stripe
            // on the two rear corners. Other balls are deliberately not arranged by group pattern.
            val rackNumbers = listOf(1, 9, 2, 10, 8, 3, 4, 11, 12, 5, 7, 13, 6, 14, 15)
            val balls = mutableListOf(cue)
            val startX = FOOT_SPOT_X
            val rowGap = BALL_RADIUS * 1.74
            var index = 0
            for (row in 0 until 5) {
                val x = startX + row * rowGap
                for (slot in 0..row) {
                    val y = (slot - row / 2.0) * BALL_RADIUS * 2.03
                    balls += PoolBall(rackNumbers[index++], Vec2(x, y))
                }
            }
            return PoolGameState(balls = balls)
        }
    }
}

data class PocketedBall(val number: Int, val pocket: Int)

data class ShotResult(
    val firstContact: Int? = null,
    val pocketedBalls: List<PocketedBall> = emptyList(),
    val cueBallPocketed: Boolean = false,
    val cueBallOffTable: Boolean = false,
    val objectBallsDrivenOffTable: Set<Int> = emptySet(),
    val cueCrossedHeadStringBeforeFirstContact: Boolean = true,
    val railAfterContact: Boolean = false,
    val objectBallsToRail: Int = 0,
    val calledBall: Int? = null,
    val calledPocket: Int? = null,
    val safetyCalled: Boolean = false
)

data class RuleOutcome(
    val state: PoolGameState,
    val foul: Boolean,
    val foulReason: String? = null,
    val message: String = "",
    val breakDecision: BreakDecision? = null
)

data class ShotObservation(
    val power: Double,
    val spinMagnitude: Double,
    val usedBank: Boolean,
    val safetyIntent: Boolean,
    val pottedBall: Boolean
)

data class PlayerLearningProfile(
    val aggression: Double = 0.5,
    val safety: Double = 0.5,
    val averagePower: Double = 0.5,
    val spinUsage: Double = 0.0,
    val bankUsage: Double = 0.0,
    val potSuccess: Double = 0.5,
    val samples: Int = 0
)

data class AiParameters(
    val aimErrorDegrees: Double,
    val powerErrorFraction: Double,
    val aggression: Double,
    val safetyBias: Double,
    val spinConfidence: Double,
    val planningSamples: Int
)

data class CounterStrategy(
    val safetyCounter: Double = 0.0,
    val pressureCounter: Double = 0.0,
    val spinCounter: Double = 0.0,
    val bankCounter: Double = 0.0
)

data class ShotCall(val ball: Int?, val pocket: Int?, val safety: Boolean = false)

data class PlannedShot(
    val direction: Vec2,
    val power: Double,
    val spin: Vec2 = Vec2.ZERO,
    val calledBall: Int? = null,
    val calledPocket: Int? = null,
    val safetyIntent: Boolean = false
)
