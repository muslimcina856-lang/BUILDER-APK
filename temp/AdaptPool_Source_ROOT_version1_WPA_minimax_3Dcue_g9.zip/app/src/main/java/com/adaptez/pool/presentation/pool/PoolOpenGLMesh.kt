package com.adaptez.pool.presentation.pool

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal data class PoolMeshData(val vertices: FloatArray, val indices: ShortArray)

internal object PoolMeshFactory {
    fun cube(): PoolMeshData = MeshBuilder().apply { addBox(1f, 1f, 1f) }.build()
    fun sphere(): PoolMeshData = MeshBuilder().apply { addSphere(1f, 24, 48) }.build()
    fun disc(): PoolMeshData = MeshBuilder().apply { addAnnulus(0f, 1f, 64) }.build()
    fun ring(): PoolMeshData = MeshBuilder().apply { addAnnulus(0.72f, 1f, 64) }.build()
}

private class MeshBuilder {
    private val vertices = ArrayList<Float>(12000)
    private val indices = ArrayList<Short>(18000)

    fun build() = PoolMeshData(
        FloatArray(vertices.size) { vertices[it] },
        ShortArray(indices.size) { indices[it] }
    )

    private fun vertex(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float): Short {
        val i = (vertices.size / 6).toShort()
        vertices += x; vertices += y; vertices += z
        vertices += nx; vertices += ny; vertices += nz
        return i
    }

    private fun tri(a: Short, b: Short, c: Short) { indices += a; indices += b; indices += c }

    fun addSphere(radius: Float, rings: Int, segments: Int) {
        val start = vertices.size / 6
        for (ring in 0..rings) {
            val phi = PI.toFloat() * ring / rings
            val ny = cos(phi)
            val radial = sin(phi)
            for (segment in 0..segments) {
                val theta = 2f * PI.toFloat() * segment / segments
                val nx = radial * cos(theta)
                val nz = radial * sin(theta)
                vertex(radius * nx, radius * ny, radius * nz, nx, ny, nz)
            }
        }
        val row = segments + 1
        for (ring in 0 until rings) for (segment in 0 until segments) {
            val a = (start + ring * row + segment).toShort()
            val b = (start + ring * row + segment + 1).toShort()
            val c = (start + (ring + 1) * row + segment).toShort()
            val d = (start + (ring + 1) * row + segment + 1).toShort()
            tri(a, c, b); tri(b, c, d)
        }
    }

    fun addBox(width: Float, height: Float, depth: Float) {
        val x0 = -width/2; val x1 = width/2
        val y0 = -height/2; val y1 = height/2
        val z0 = -depth/2; val z1 = depth/2
        face(floatArrayOf(x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1),0f,0f,1f)
        face(floatArrayOf(x1,y0,z0, x0,y0,z0, x0,y1,z0, x1,y1,z0),0f,0f,-1f)
        face(floatArrayOf(x1,y0,z1, x1,y0,z0, x1,y1,z0, x1,y1,z1),1f,0f,0f)
        face(floatArrayOf(x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0),-1f,0f,0f)
        face(floatArrayOf(x0,y1,z1, x1,y1,z1, x1,y1,z0, x0,y1,z0),0f,1f,0f)
        face(floatArrayOf(x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1),0f,-1f,0f)
    }

    private fun face(p: FloatArray, nx: Float, ny: Float, nz: Float) {
        val s = (vertices.size / 6).toShort()
        for (i in 0 until 4) vertex(p[i*3], p[i*3+1], p[i*3+2], nx, ny, nz)
        tri(s,(s+1).toShort(),(s+2).toShort()); tri(s,(s+2).toShort(),(s+3).toShort())
    }

    fun addAnnulus(inner: Float, outer: Float, segments: Int) {
        repeat(segments) { i ->
            val a0 = 2f*PI.toFloat()*i/segments
            val a1 = 2f*PI.toFloat()*(i+1)/segments
            val o0 = vertex(cos(a0)*outer,0f,sin(a0)*outer,0f,1f,0f)
            val o1 = vertex(cos(a1)*outer,0f,sin(a1)*outer,0f,1f,0f)
            val i1 = vertex(cos(a1)*inner,0f,sin(a1)*inner,0f,1f,0f)
            val i0 = vertex(cos(a0)*inner,0f,sin(a0)*inner,0f,1f,0f)
            tri(o0,i1,o1); tri(o0,i0,i1)
        }
    }
}
