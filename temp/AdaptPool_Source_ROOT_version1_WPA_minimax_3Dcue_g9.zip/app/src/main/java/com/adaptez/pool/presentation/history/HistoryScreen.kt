package com.adaptez.pool.presentation.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adaptez.pool.data.local.MatchEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    games: List<MatchEntity>,
    modifier: Modifier = Modifier
) {
    var selectedGame by remember { mutableStateOf<MatchEntity?>(null) }

    selectedGame?.let { game ->
        MatchLearningDialog(game = game, onDismiss = { selectedGame = null })
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0F12))
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Text(
            "Sejarah Permainan",
            color = Color(0xFFF3EEE4),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Lihat bagaimana lawan kamu berkembang.",
            color = Color(0xFFA6A39C),
            fontSize = 12.sp
        )
        Spacer(Modifier.height(18.dp))

        if (games.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada permainan direkodkan.", color = Color(0xFFA6A39C))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(games, key = { it.id }) { game ->
                    MatchHistoryCard(game, onClick = { selectedGame = game })
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }
    }
}

@Composable
private fun MatchHistoryCard(game: MatchEntity, onClick: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()) }
    val resultColor = if (game.result == "WIN") Color(0xFF76C8A5) else Color(0xFFE07171)
    val resultLabel = if (game.result == "WIN") "MENANG" else "KALAH"
    val group = when (game.playerGroup) {
        "SOLIDS" -> "Solids 1–7"
        "STRIPES" -> "Stripes 9–15"
        else -> "Meja terbuka"
    }

    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        color = Color(0xFF171A1F),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(resultColor.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Text(resultLabel.first().toString(), color = resultColor, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(resultLabel, color = resultColor, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "8-Ball • $group",
                    color = Color(0xFFF3EEE4),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(dateFormat.format(Date(game.playedAt)), color = Color(0xFF858681), fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Lv ${game.level}", color = Color(0xFFD8B477), fontSize = 11.sp)
                Text("${game.totalShots} pukulan", color = Color(0xFF858681), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MatchLearningDialog(game: MatchEntity, onDismiss: () -> Unit) {
    val resultLabel = if (game.result == "WIN") "Menang" else "Kalah"
    val details = game.learningSummary.lineSequence().filter { it.isNotBlank() }.toList()
    val group = when (game.playerGroup) {
        "SOLIDS" -> "Solids 1–7"
        "STRIPES" -> "Stripes 9–15"
        else -> "Meja terbuka"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF171A1F),
        titleContentColor = Color(0xFFF3EEE4),
        textContentColor = Color(0xFFA6A39C),
        title = { Text("Analisis Permainan", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(color = Color(0xFFD8B477).copy(alpha = 0.10f), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(
                            "$resultLabel • Level ${game.level}",
                            color = Color(0xFFD8B477),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "$group • ${game.totalShots} pukulan • ${game.pottedBalls} bola dipot",
                            color = Color(0xFFA6A39C),
                            fontSize = 11.sp
                        )
                        Text(
                            "Ketepatan ${"%.1f".format(game.shotAccuracy)}% • ${formatDuration(game.durationMs)}",
                            color = Color(0xFFA6A39C),
                            fontSize = 11.sp
                        )
                    }
                }

                Text(
                    "APA YANG AI PELAJARI",
                    color = Color(0xFF76C8A5),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.7.sp
                )
                if (details.isEmpty()) {
                    Text("AI menyimpan corak permainan ini untuk pelarasan strategi seterusnya.", fontSize = 12.sp)
                } else {
                    details.forEach { detail ->
                        Text("• $detail", color = Color(0xFFF3EEE4), fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold)
            }
        }
    )
}

private fun formatDuration(milliseconds: Long): String {
    val minutes = milliseconds / 60_000
    return if (minutes < 60) "$minutes minit" else "${minutes / 60}j ${minutes % 60}m"
}
