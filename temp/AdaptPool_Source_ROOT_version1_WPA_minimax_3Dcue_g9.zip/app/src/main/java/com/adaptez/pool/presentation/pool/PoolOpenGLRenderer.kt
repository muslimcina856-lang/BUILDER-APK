package com.adaptez.pool.presentation.pool

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.adaptez.pool.domain.model.PoolBall
import com.adaptez.pool.domain.model.PoolGameState
import com.adaptez.pool.domain.model.Vec2
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

internal data class PoolOpenGLScene(
    val balls: List<PoolBall> = emptyList(),
    val aimDegrees: Double = 0.0,
    val showAim: Boolean = false,
    val showCue: Boolean = false,
    val cuePullback: Double = 0.08
)

internal data class CueScreenGeometry(
    val buttX: Float,
    val buttY: Float,
    val tipX: Float,
    val tipY: Float
) {
    fun distanceToSegment(x: Float, y: Float): Float {
        val vx = buttX - tipX
        val vy = buttY - tipY
        val lengthSq = vx * vx + vy * vy
        if (lengthSq <= 0.0001f) return Float.MAX_VALUE
        val t = (((x - tipX) * vx + (y - tipY) * vy) / lengthSq).coerceIn(0f, 1f)
        val px = tipX + vx * t
        val py = tipY + vy * t
        val dx = x - px
        val dy = y - py
        return sqrt(dx * dx + dy * dy)
    }
}

internal class PoolOpenGLRenderer : GLSurfaceView.Renderer {
    @Volatile private var scene = PoolOpenGLScene()
    @Volatile private var cameraYaw = 0f
    @Volatile private var cameraPitch = 0.82f
    @Volatile private var viewportWidth = 1
    @Volatile private var viewportHeight = 1
    @Volatile private var cueGeometry: CueScreenGeometry? = null
    @Volatile private var cueBallScreen: Pair<Float, Float>? = null
    @Volatile private var inverseViewProjectionSnapshot: FloatArray? = null

    private var program = 0
    private var positionLocation = -1
    private var normalLocation = -1
    private var mvpLocation = -1
    private var modelLocation = -1
    private var colorLocation = -1
    private var secondaryColorLocation = -1
    private var patternModeLocation = -1
    private var lightLocation = -1
    private var cameraLocation = -1
    private var shininessLocation = -1

    private lateinit var cube: GlMesh
    private lateinit var sphere: GlMesh
    private lateinit var disc: GlMesh
    private lateinit var ring: GlMesh

    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val viewProjection = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    fun updateScene(updated: PoolOpenGLScene) { scene = updated }

    fun previewAimDelta(deltaDegrees: Double) {
        scene = scene.copy(aimDegrees = normalizeDegrees(scene.aimDegrees + deltaDegrees))
    }

    fun previewCuePullback(power: Double) {
        scene = scene.copy(cuePullback = power.coerceIn(0.08, 1.0))
    }

    fun cueScreenGeometry(): CueScreenGeometry? = cueGeometry

    fun isCueHit(x: Float, y: Float, thresholdPx: Float): Boolean =
        cueGeometry?.distanceToSegment(x, y)?.let { it <= thresholdPx } ?: false

    fun isCueBallHit(x: Float, y: Float, thresholdPx: Float): Boolean {
        val point = cueBallScreen ?: return false
        val dx = x - point.first
        val dy = y - point.second
        return dx * dx + dy * dy <= thresholdPx * thresholdPx
    }

    fun tablePositionFromScreen(screenX: Float, screenY: Float): Vec2? {
        val inverse = inverseViewProjectionSnapshot ?: return null
        val width = viewportWidth.coerceAtLeast(1).toFloat()
        val height = viewportHeight.coerceAtLeast(1).toFloat()
        val ndcX = screenX / width * 2f - 1f
        val ndcY = 1f - screenY / height * 2f
        val near = unproject(inverse, ndcX, ndcY, -1f) ?: return null
        val far = unproject(inverse, ndcX, ndcY, 1f) ?: return null
        val dy = far.y - near.y
        if (abs(dy) < 1e-5f) return null
        val t = (TABLE_TOUCH_Y - near.y) / dy
        if (t < 0f || t > 1.5f) return null
        val wx = near.x + (far.x - near.x) * t
        val wz = near.z + (far.z - near.z) * t
        return Vec2((-wz / WORLD_SCALE).toDouble(), (wx / WORLD_SCALE).toDouble())
    }

    fun orbit(dx: Float, dy: Float) {
        cameraYaw = (cameraYaw - dx * 0.0032f).coerceIn(-0.62f, 0.62f)
        cameraPitch = (cameraPitch - dy * 0.0025f).coerceIn(0.58f, 1.04f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.025f, 0.032f, 0.036f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (program == 0) return
        positionLocation = GLES20.glGetAttribLocation(program, "aPosition")
        normalLocation = GLES20.glGetAttribLocation(program, "aNormal")
        mvpLocation = GLES20.glGetUniformLocation(program, "uMvp")
        modelLocation = GLES20.glGetUniformLocation(program, "uModel")
        colorLocation = GLES20.glGetUniformLocation(program, "uColor")
        secondaryColorLocation = GLES20.glGetUniformLocation(program, "uSecondaryColor")
        patternModeLocation = GLES20.glGetUniformLocation(program, "uPatternMode")
        lightLocation = GLES20.glGetUniformLocation(program, "uLightPosition")
        cameraLocation = GLES20.glGetUniformLocation(program, "uCameraPosition")
        shininessLocation = GLES20.glGetUniformLocation(program, "uShininess")
        cube = GlMesh(PoolMeshFactory.cube())
        sphere = GlMesh(PoolMeshFactory.sphere())
        disc = GlMesh(PoolMeshFactory.disc())
        ring = GlMesh(PoolMeshFactory.ring())
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width.coerceAtLeast(1)
        viewportHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0,0,viewportWidth,viewportHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (program == 0) return
        val eye = cameraPosition()
        Matrix.setLookAtM(view,0, eye.x,eye.y,eye.z, 0f,0.1f,-0.2f, 0f,1f,0f)
        Matrix.perspectiveM(projection,0,42f,viewportWidth.toFloat()/viewportHeight.toFloat(),0.4f,30f)
        Matrix.multiplyMM(viewProjection,0,projection,0,view,0)
        val inv = FloatArray(16)
        if (Matrix.invertM(inv,0,viewProjection,0)) inverseViewProjectionSnapshot = inv
        GLES20.glUseProgram(program)
        GLES20.glUniform3f(lightLocation,-3.6f,8.8f,4.3f)
        GLES20.glUniform3f(cameraLocation,eye.x,eye.y,eye.z)
        drawTable()
        cueBallScreen = null
        drawBalls()
        if (scene.showAim) drawAimAndCue() else cueGeometry = null
    }

    private fun drawTable() {
        drawCube(0f,-0.12f,0f,4.55f,0.42f,8.45f,WOOD_DARK,34f)
        drawCube(0f,0.10f,0f,4.05f,0.18f,7.92f,FELT,10f)
        drawCube(-2.04f,0.28f,0f,0.24f,0.34f,7.92f,CUSHION,18f)
        drawCube(2.04f,0.28f,0f,0.24f,0.34f,7.92f,CUSHION,18f)
        drawCube(0f,0.28f,-3.96f,4.08f,0.34f,0.24f,CUSHION,18f)
        drawCube(0f,0.28f,3.96f,4.08f,0.34f,0.24f,CUSHION,18f)
        drawCube(-2.27f,-0.30f,0f,0.20f,0.36f,8.48f,WOOD_EDGE,42f)
        drawCube(2.27f,-0.30f,0f,0.20f,0.36f,8.48f,WOOD_EDGE,42f)
        drawCube(0f,-0.30f,-4.20f,4.55f,0.36f,0.20f,WOOD_EDGE,42f)
        drawCube(0f,-0.30f,4.20f,4.55f,0.36f,0.20f,WOOD_EDGE,42f)

        val pockets = arrayOf(
            Triple(-2.02f, -3.94f, 0.35f), Triple(0f, -4.02f, 0.33f), Triple(2.02f, -3.94f, 0.35f),
            Triple(2.02f, 3.94f, 0.35f), Triple(0f, 4.02f, 0.33f), Triple(-2.02f, 3.94f, 0.35f)
        )
        GLES20.glDepthMask(false)
        pockets.forEach { (x,z,scale) ->
            drawFlat(ring,x,0.228f,z,scale,POCKET_RIM,14f)
            drawFlat(disc,x,0.211f,z,scale * 0.93f,POCKET_MOUTH,5f)
            drawFlat(disc,x,0.180f,z,scale * 0.76f,POCKET_INNER,2f)
        }
        GLES20.glDepthMask(true)
    }

    private fun drawBalls() {
        val visible = scene.balls.filterNot { it.pocketed }
        GLES20.glDepthMask(false)
        visible.forEach { ball ->
            val (x,z) = world(ball)
            drawFlat(disc,x,0.205f,z,0.148f,SHADOW,1f)
        }
        GLES20.glDepthMask(true)
        visible.sortedBy { world(it).second }.forEach { ball -> drawBall(ball) }
    }

    private fun drawBall(ball: PoolBall) {
        val (x,z) = world(ball)
        val y = 0.405f
        val r = 0.164f
        val color = ballColor(ball.number)
        if (ball.number == 0) cueBallScreen = projectPoint(x, y, z)
        when {
            ball.number == 0 -> {
                drawSphere(x,y,z,r,r,r,CUE_IVORY,104f)
                GLES20.glDepthMask(false)
                drawFlat(disc,x,y+r*0.973f,z,0.026f,CUE_GLEAM,20f)
                GLES20.glDepthMask(true)
            }
            ball.number in 9..15 -> drawSphere(x,y,z,r,r,r,color,98f, patternMode = 1f, secondary = STRIPE_WHITE)
            else -> drawSphere(x,y,z,r,r,r,color,102f)
        }
        if (ball.number != 0) {
            GLES20.glDepthMask(false)
            val patchScale = if (ball.number >= 10) 0.066f else 0.060f
            drawFlat(disc,x,y+r*0.986f,z,patchScale,NUMBER_PATCH,14f)
            drawFlat(ring,x,y+r*0.991f,z,patchScale*1.10f,LABEL_RING,10f)
            drawBallNumber(ball.number, x, y+r*1.015f, z)
            GLES20.glDepthMask(true)
        }
    }

    private fun drawBallNumber(number: Int, x: Float, y: Float, z: Float) {
        val text = number.toString()
        val scale = if (text.length == 1) 1.0f else 0.72f
        val spacing = 0.035f * scale
        val start = if (text.length == 1) 0f else -spacing * 0.5f
        text.forEachIndexed { index, ch ->
            drawDigit(ch - '0', x + start + index * spacing, y, z, scale)
        }
    }

    private fun drawDigit(digit: Int, x: Float, y: Float, z: Float, scale: Float) {
        val mask = DIGIT_MASKS[digit.coerceIn(0,9)]
        val hw = 0.014f * scale
        val vh = 0.015f * scale
        val thick = 0.0045f * scale
        fun horizontal(bit: Int, dz: Float) {
            if (mask and (1 shl bit) != 0) drawCube(x,y,z+dz,hw*2f,0.0022f,thick,BLACK,5f)
        }
        fun vertical(bit: Int, dx: Float, dz: Float) {
            if (mask and (1 shl bit) != 0) drawCube(x+dx,y,z+dz,thick,0.0022f,vh,BLACK,5f)
        }
        horizontal(0,-vh)
        vertical(1, hw, -vh*0.52f)
        vertical(2, hw, vh*0.52f)
        horizontal(3, vh)
        vertical(4,-hw, vh*0.52f)
        vertical(5,-hw,-vh*0.52f)
        horizontal(6,0f)
    }

    private fun drawAimAndCue() {
        val cue = scene.balls.firstOrNull { it.number == 0 && !it.pocketed } ?: return
        val angle = Math.toRadians(scene.aimDegrees)
        val engineDx = cos(angle).toFloat()
        val engineDy = sin(angle).toFloat()
        val worldDx = engineDy
        val worldDz = -engineDx
        val (cx,cz) = world(cue)
        val lineLength = 3.55f
        val targetX = cx + worldDx * lineLength
        val targetZ = cz + worldDz * lineLength
        drawSegment(cx,0.39f,cz,targetX,0.39f,targetZ,0.015f,AIM,4f)
        drawFlat(ring,targetX,0.405f,targetZ,0.105f,AIM_RING,4f)
        if (scene.showCue) {
            val cueLength = 2.48f
            val pullback = ((scene.cuePullback - 0.08) / 0.92).coerceIn(0.0,1.0).toFloat()
            val tipGap = 0.205f + pullback * 0.78f
            val farX = cx - worldDx * (cueLength + tipGap)
            val farZ = cz - worldDz * (cueLength + tipGap)
            val nearX = cx - worldDx * tipGap
            val nearZ = cz - worldDz * tipGap
            drawSegment(farX,0.40f,farZ,nearX,0.40f,nearZ,0.052f,CUE_WOOD,54f)
            val tipEndX = cx - worldDx * (tipGap - 0.055f)
            val tipEndZ = cz - worldDz * (tipGap - 0.055f)
            drawSegment(nearX,0.40f,nearZ,tipEndX,0.40f,tipEndZ,0.058f,CUE_BLUE,48f)
            val buttScreen = projectPoint(farX,0.40f,farZ)
            val tipScreen = projectPoint(nearX,0.40f,nearZ)
            cueGeometry = if (buttScreen != null && tipScreen != null) {
                CueScreenGeometry(buttScreen.first,buttScreen.second,tipScreen.first,tipScreen.second)
            } else null
        } else cueGeometry = null
    }

    private fun drawSegment(x0:Float,y0:Float,z0:Float,x1:Float,y1:Float,z1:Float,thickness:Float,color:FloatArray,shininess:Float) {
        val dx=x1-x0; val dz=z1-z0
        val len=sqrt(dx*dx+dz*dz).coerceAtLeast(0.001f)
        val angle=(atan2(dx,dz)*180f/PI.toFloat())
        setModel((x0+x1)/2f,(y0+y1)/2f,(z0+z1)/2f,thickness,thickness,len,angle)
        draw(cube,color,shininess)
    }

    private fun drawCube(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,color:FloatArray,shine:Float) {
        setModel(x,y,z,sx,sy,sz,0f); draw(cube,color,shine)
    }

    private fun drawSphere(
        x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,
        color:FloatArray,shine:Float,patternMode:Float=0f,secondary:FloatArray=color
    ) {
        setModel(x,y,z,sx,sy,sz,0f); draw(sphere,color,shine,patternMode,secondary)
    }

    private fun drawFlat(mesh:GlMesh,x:Float,y:Float,z:Float,scale:Float,color:FloatArray,shine:Float) {
        setModel(x,y,z,scale,1f,scale,0f); draw(mesh,color,shine)
    }

    private fun setModel(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,rotationY:Float) {
        Matrix.setIdentityM(model,0)
        Matrix.translateM(model,0,x,y,z)
        if (rotationY != 0f) Matrix.rotateM(model,0,rotationY,0f,1f,0f)
        Matrix.scaleM(model,0,sx,sy,sz)
    }

    private fun draw(mesh:GlMesh,color:FloatArray,shininess:Float,patternMode:Float=0f,secondary:FloatArray=color) {
        Matrix.multiplyMM(mvp,0,viewProjection,0,model,0)
        GLES20.glUniformMatrix4fv(mvpLocation,1,false,mvp,0)
        GLES20.glUniformMatrix4fv(modelLocation,1,false,model,0)
        GLES20.glUniform4fv(colorLocation,1,color,0)
        GLES20.glUniform4fv(secondaryColorLocation,1,secondary,0)
        GLES20.glUniform1f(patternModeLocation,patternMode)
        GLES20.glUniform1f(shininessLocation,shininess)
        mesh.draw(positionLocation,normalLocation)
    }

    private fun projectPoint(x: Float, y: Float, z: Float): Pair<Float,Float>? {
        val out = FloatArray(4)
        Matrix.multiplyMV(out,0,viewProjection,0,floatArrayOf(x,y,z,1f),0)
        if (out[3] <= 0.0001f) return null
        val ndcX = out[0] / out[3]
        val ndcY = out[1] / out[3]
        return ((ndcX * 0.5f + 0.5f) * viewportWidth) to ((1f - (ndcY * 0.5f + 0.5f)) * viewportHeight)
    }

    private fun unproject(inverse: FloatArray, x: Float, y: Float, z: Float): V3? {
        val out = FloatArray(4)
        Matrix.multiplyMV(out,0,inverse,0,floatArrayOf(x,y,z,1f),0)
        if (abs(out[3]) <= 1e-6f) return null
        return V3(out[0]/out[3], out[1]/out[3], out[2]/out[3])
    }

    private fun world(ball: PoolBall): Pair<Float,Float> =
        (ball.position.y * WORLD_SCALE).toFloat() to (-ball.position.x * WORLD_SCALE).toFloat()

    private fun cameraPosition(): V3 {
        val radius = 10.6f
        val baseZ = radius * sin(cameraPitch)
        return V3(
            sin(cameraYaw) * 3.0f,
            radius * cos(cameraPitch) + 0.6f,
            baseZ * cos(cameraYaw)
        )
    }

    private fun createProgram(v:String,f:String):Int {
        val vs=compile(GLES20.GL_VERTEX_SHADER,v); val fs=compile(GLES20.GL_FRAGMENT_SHADER,f)
        if(vs==0||fs==0) return 0
        val p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,vs); GLES20.glAttachShader(p,fs); GLES20.glLinkProgram(p)
        val linked=IntArray(1); GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,linked,0)
        if(linked[0]==0){Log.e(TAG,"link: ${GLES20.glGetProgramInfoLog(p)}");GLES20.glDeleteProgram(p);return 0}
        GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);return p
    }

    private fun compile(type:Int,src:String):Int {
        val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s)
        val ok=IntArray(1);GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0)
        if(ok[0]==0){Log.e(TAG,"shader: ${GLES20.glGetShaderInfoLog(s)}");GLES20.glDeleteShader(s);return 0};return s
    }

    private class GlMesh(data:PoolMeshData){
        private val vb:FloatBuffer=ByteBuffer.allocateDirect(data.vertices.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(data.vertices);position(0)}
        private val ib:ShortBuffer=ByteBuffer.allocateDirect(data.indices.size*2).order(ByteOrder.nativeOrder()).asShortBuffer().apply{put(data.indices);position(0)}
        private val count=data.indices.size
        fun draw(pos:Int,norm:Int){
            vb.position(0);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(pos)
            vb.position(3);GLES20.glVertexAttribPointer(norm,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(norm)
            ib.position(0);GLES20.glDrawElements(GLES20.GL_TRIANGLES,count,GLES20.GL_UNSIGNED_SHORT,ib)
        }
    }

    companion object {
        private const val TAG="AdaptPoolGL"
        private const val WORLD_SCALE=2.60f
        private const val TABLE_TOUCH_Y=0.22f
        private fun c(r:Int,g:Int,b:Int,a:Int=255)=floatArrayOf(r/255f,g/255f,b/255f,a/255f)
        private val FELT=c(22,121,94); private val CUSHION=c(13,82,64); private val WOOD_DARK=c(31,20,14)
        private val WOOD_EDGE=c(102,64,30); private val SHADOW=c(0,0,0,92)
        private val POCKET_RIM=c(94,74,52,230); private val POCKET_MOUTH=c(15,17,19,240); private val POCKET_INNER=c(3,4,5)
        private val CUE_IVORY=c(242,238,226); private val CUE_GLEAM=c(255,255,255,210); private val STRIPE_WHITE=c(240,236,225); private val NUMBER_PATCH=c(247,243,232)
        private val LABEL_RING=c(210,202,188,150); private val BLACK=c(18,18,20); private val AIM=c(216,180,119,188); private val AIM_RING=c(118,200,165,205)
        private val CUE_WOOD=c(184,124,62); private val CUE_BLUE=c(45,95,110)
        private val BALL_COLORS=arrayOf(
            c(242,236,225), c(237,193,55), c(48,98,184), c(200,58,56), c(118,67,164), c(232,131,45), c(62,144,81), c(137,52,50), c(18,18,22),
            c(237,193,55), c(48,98,184), c(200,58,56), c(118,67,164), c(232,131,45), c(62,144,81), c(137,52,50)
        )
        private val DIGIT_MASKS=intArrayOf(
            0b0111111, // 0
            0b0000110, // 1
            0b1011011, // 2
            0b1001111, // 3
            0b1100110, // 4
            0b1101101, // 5
            0b1111101, // 6
            0b0000111, // 7
            0b1111111, // 8
            0b1101111  // 9
        )
        private fun ballColor(number:Int)=BALL_COLORS[number.coerceIn(0,15)]
        private fun normalizeDegrees(value: Double): Double {
            var result = value % 360.0
            if (result > 180.0) result -= 360.0
            if (result < -180.0) result += 360.0
            return result
        }
        private const val VERTEX_SHADER="""
            uniform mat4 uMvp; uniform mat4 uModel; attribute vec3 aPosition; attribute vec3 aNormal;
            varying vec3 vWorldPosition; varying vec3 vNormal; varying vec3 vLocalPosition;
            void main(){vec4 w=uModel*vec4(aPosition,1.0);vWorldPosition=w.xyz;vNormal=normalize(mat3(uModel)*aNormal);vLocalPosition=aPosition;gl_Position=uMvp*vec4(aPosition,1.0);}
        """
        private const val FRAGMENT_SHADER="""
            precision mediump float; uniform vec4 uColor; uniform vec4 uSecondaryColor; uniform float uPatternMode;
            uniform vec3 uLightPosition; uniform vec3 uCameraPosition; uniform float uShininess;
            varying vec3 vWorldPosition; varying vec3 vNormal; varying vec3 vLocalPosition;
            void main(){vec4 base=uColor;if(uPatternMode>0.5&&abs(vLocalPosition.y)>0.46)base=uSecondaryColor;
            vec3 n=normalize(vNormal);vec3 l=normalize(uLightPosition-vWorldPosition);vec3 v=normalize(uCameraPosition-vWorldPosition);vec3 h=normalize(l+v);
            float d=max(dot(n,l),0.0);float s=pow(max(dot(n,h),0.0),uShininess);float rim=pow(1.0-max(dot(n,v),0.0),2.0);
            float light=0.24+d*0.76;vec3 rgb=base.rgb*light+vec3(s*0.55)+base.rgb*rim*0.12;gl_FragColor=vec4(rgb,base.a);}
        """
    }
}

private data class V3(val x:Float,val y:Float,val z:Float)
