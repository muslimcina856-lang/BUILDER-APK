package com.adaptez.pool.presentation.pool

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Rule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.BallGroup
import com.adaptez.pool.domain.model.BreakChoice
import com.adaptez.pool.domain.model.CueBallPlacementRule
import com.adaptez.pool.domain.model.PoolGameState
import com.adaptez.pool.domain.model.PlayerSeat
import kotlin.math.abs

private val AppBackground = Color(0xFF0D0F12)
private val Panel = Color(0xFF171A1F)
private val PanelSoft = Color(0xFF1E2228)
private val Ivory = Color(0xFFF3EEE4)
private val Muted = Color(0xFFA6A39C)
private val Gold = Color(0xFFD8B477)
private val Mint = Color(0xFF76C8A5)
private val Danger = Color(0xFFE07171)

@Composable
fun PoolScreen(modifier: Modifier = Modifier, viewModel: PoolViewModel) {
    val state by viewModel.uiState.collectAsState()
    var showRules by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val sound = remember(context) { PoolSoundManager(context) }
    DisposableEffect(sound) { onDispose { sound.release() } }
    LaunchedEffect(state.cuePulse) { if (state.cuePulse > 0) sound.playCue() }
    LaunchedEffect(state.collisionPulse) { if (state.collisionPulse > 0) sound.playCollision() }
    LaunchedEffect(state.pocketPulse) { if (state.pocketPulse > 0) sound.playPocket() }

    LaunchedEffect(state.phase, state.player?.id) {
        if (state.phase == MatchPhase.SETUP && state.player != null) viewModel.startMatch()
    }
    if (showRules) RulesDialog { showRules = false }

    val previewGame = state.game ?: PoolGameState.standardRack()
    Column(
        modifier = modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF11151A), AppBackground, Color(0xFF0A0C0F)))
        )
    ) {
        TopBar(state, onRules = { showRules = true })

        BoxWithConstraints(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Pool3DView(
                game = previewGame,
                aimDegrees = state.aimDegrees,
                showAim = state.canShoot,
                canInteract = state.canShoot,
                ballInHand = previewGame.ballInHand,
                cuePullback = state.power,
                onAimDrag = viewModel::nudgeAim,
                onCueBallDrag = { x, y -> viewModel.setCueBallPosition(x = x, y = y) },
                onCuePull = viewModel::setPower,
                onCueRelease = { power ->
                    viewModel.setPower(power)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.shoot()
                },
                onCueCancel = viewModel::resetCuePull,
                modifier = Modifier.fillMaxSize()
            )
        }

        ControlPanel(state, viewModel)
    }
}

@Composable
private fun TopBar(state: PoolUiState, onRules: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("ADAPT POOL", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            Text("AI minimax + counter pembelajaran pemain", color = Muted, fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Surface(
                color = Gold.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.38f))
            ) {
                Text(
                    "LEVEL ${state.currentLevel} / 999",
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                    color = Gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.6.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(statusColor(state)))
                Spacer(Modifier.width(6.dp))
                Text(statusText(state), color = Muted, fontSize = 10.sp)
                IconButton(onClick = onRules, modifier = Modifier.size(27.dp)) {
                    Icon(Icons.Rounded.Rule, "Peraturan", tint = Muted, modifier = Modifier.size(17.dp))
                }
            }
        }
    }
}

@Composable
private fun ControlPanel(state: PoolUiState, viewModel: PoolViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        color = Panel,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 1.dp
    ) {
        when (state.phase) {
            MatchPhase.SETUP -> SetupStatus()
            MatchPhase.BREAK_DECISION -> BreakDecisionCard(state, viewModel)
            MatchPhase.RESULT -> ResultCard(state, viewModel::nextOrRetry)
            else -> PlayingControls(state, viewModel)
        }
    }
}

@Composable
private fun SetupStatus() {
    Column(
        Modifier.fillMaxWidth().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("8-Ball • WPA ruleset", color = Ivory, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("House rule Adapt Pool: pemain manusia sentiasa melakukan break pertama.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun BreakDecisionCard(state: PoolUiState, viewModel: PoolViewModel) {
    val decision = state.pendingBreakDecision ?: return
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("KEPUTUSAN SELEPAS BREAK", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
        Text(decision.reason, color = Ivory, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text("Pilih salah satu pilihan sah mengikut situasi break:", color = Muted, fontSize = 10.sp)
        decision.options.forEach { choice ->
            OutlinedButton(
                onClick = { viewModel.chooseBreakOption(choice) },
                modifier = Modifier.fillMaxWidth(),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.45f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Ivory)
            ) {
                Text(breakChoiceLabel(choice), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PlayingControls(state: PoolUiState, viewModel: PoolViewModel) {
    val game = state.game ?: return
    var showManualCall by remember(game.shotNumber) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(statusColor(state)))
                Spacer(Modifier.width(7.dp))
                Text(statusText(state), color = if (state.phase == MatchPhase.AI_THINKING) Mint else Ivory, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Text("${groupLabel(game.humanGroup)} • ${state.totalShots} pukulan", color = Muted, fontSize = 10.sp)
        }

        Surface(color = PanelSoft, shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("KAWALAN CUE 3D", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
                val guide = when {
                    game.ballInHand && game.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING ->
                        "Seret cue ball di belakang Head String. Tekan batang cue, gerak sisi untuk aim, tarik batang ke belakang untuk kuasa, lepaskan untuk pukul."
                    game.ballInHand ->
                        "Cue-ball in hand: seret bola putih ke mana-mana posisi sah. Tekan batang cue dan tarik ke belakang untuk pukul."
                    state.canShoot ->
                        "Tekan batang cue. Gerak sisi untuk ubah aim, tarik batang ke belakang untuk bina kuasa, kemudian lepaskan. Seret dua jari untuk kamera."
                    else -> state.statusMessage
                }
                Text(guide, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }

        if (state.canShoot) {
            val onEight = !game.isBreakShot && PoolRules.isOnEight(game, PlayerSeat.HUMAN)
            val headStringSpotCandidates = PoolRules.headStringSpotCandidates(game, PlayerSeat.HUMAN)

            if (headStringSpotCandidates.isNotEmpty()) {
                Surface(color = Gold.copy(alpha = 0.08f), shape = RoundedCornerShape(11.dp)) {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text("SEMUA SASARAN DI BELAKANG HEAD STRING", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
                        Text("WPA membenarkan bola sah terdekat Head String diminta untuk di-spot.", color = Muted, fontSize = 9.sp)
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            headStringSpotCandidates.forEach { ball ->
                                AssistChip(
                                    onClick = { viewModel.requestHeadStringSpot(ball) },
                                    label = { Text("Spot $ball", fontSize = 8.sp) }
                                )
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("CALLED SHOT", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        when {
                            game.isBreakShot -> "Break: tiada call diperlukan"
                            state.safetyCalled -> "SAFETY dipanggil • giliran akan bertukar"
                            onEight -> "8-ball • pilih poket di bawah"
                            state.selectedCalledBall != null || state.selectedPocket != null ->
                                "Manual: bola ${state.selectedCalledBall ?: "?"} • poket ${(state.selectedPocket?.plus(1)) ?: "?"}"
                            else -> "Obvious ball + pocket didaftarkan daripada line aim; guna CALL untuk bank/combo yang ambiguous"
                        },
                        color = Muted,
                        fontSize = 9.sp
                    )
                }
                if (!game.isBreakShot) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (!onEight && !state.safetyCalled) {
                            FilterChip(
                                selected = showManualCall,
                                onClick = {
                                    showManualCall = !showManualCall
                                    if (!showManualCall) {
                                        viewModel.selectCalledBall(null)
                                        viewModel.selectPocket(null)
                                    }
                                },
                                label = { Text("CALL", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Gold.copy(alpha = 0.18f),
                                    selectedLabelColor = Gold,
                                    labelColor = Muted
                                )
                            )
                        }
                        FilterChip(
                            selected = state.safetyCalled,
                            onClick = {
                                if (!state.safetyCalled) {
                                    showManualCall = false
                                    viewModel.selectCalledBall(null)
                                    viewModel.selectPocket(null)
                                }
                                viewModel.toggleSafety()
                            },
                            label = { Text("SAFETY", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Mint.copy(alpha = 0.18f),
                                selectedLabelColor = Mint,
                                labelColor = Muted
                            )
                        )
                    }
                }
            }

            if (showManualCall && !game.isBreakShot && !onEight && !state.safetyCalled) {
                val legalBalls = game.balls.filter { ball ->
                    !ball.pocketed && ball.number != 0 && PoolRules.isLegalCalledBall(game, PlayerSeat.HUMAN, ball.number)
                }.map { it.number }.sorted()
                Surface(color = Gold.copy(alpha = 0.07f), shape = RoundedCornerShape(11.dp)) {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text("MANUAL CALL • untuk bank / combo / shot tidak obvious", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            legalBalls.forEach { ball ->
                                FilterChip(
                                    selected = state.selectedCalledBall == ball,
                                    onClick = { viewModel.selectCalledBall(ball) },
                                    label = { Text("Bola $ball", fontSize = 8.sp) },
                                    modifier = Modifier.height(29.dp)
                                )
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            (0..5).forEach { pocket ->
                                FilterChip(
                                    selected = state.selectedPocket == pocket,
                                    onClick = { viewModel.selectPocket(pocket) },
                                    label = { Text("Poket ${pocket + 1}", fontSize = 8.sp) },
                                    modifier = Modifier.height(29.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (onEight && !state.safetyCalled) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("CALL 8", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    (0..5).forEach { pocket ->
                        FilterChip(
                            selected = state.selectedPocket == pocket,
                            onClick = { viewModel.selectPocket(pocket) },
                            label = { Text("${pocket + 1}", fontSize = 9.sp) },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }

            SpinPad(
                spinX = state.spinX,
                spinY = state.spinY,
                onSelect = viewModel::setSpin
            )

            CuePowerReadout(state.power)
        } else {
            Text(state.statusMessage, color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            if (state.phase == MatchPhase.AI_THINKING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Mint, trackColor = PanelSoft)
            }
        }

        if (state.learningInsights.isNotEmpty()) {
            Surface(color = PanelSoft, shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("COUNTER INSIGHT", color = Mint, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
                    Text(state.learningInsights.first(), color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun CuePowerReadout(power: Double) {
    val normalized = (((power - 0.08) / 0.92).coerceIn(0.0, 1.0)).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TEKAN + TARIK BATANG CUE", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
            Text("${(normalized * 100).toInt()}%", color = Ivory, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = normalized,
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = Mint,
            trackColor = Color(0xFF2A2E34)
        )
    }
}

@Composable
private fun SpinPad(spinX: Double, spinY: Double, onSelect: (Double, Double) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text("SPIN / ENGLISH", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            SpinChip("Left", spinX < -0.2, Modifier.weight(1f)) { onSelect(-0.58, 0.0) }
            SpinChip("Draw", spinY < -0.2, Modifier.weight(1f)) { onSelect(0.0, -0.62) }
            SpinChip("Center", abs(spinX) < 0.1 && abs(spinY) < 0.1, Modifier.weight(1.15f)) { onSelect(0.0, 0.0) }
            SpinChip("Follow", spinY > 0.2, Modifier.weight(1f)) { onSelect(0.0, 0.62) }
            SpinChip("Right", spinX > 0.2, Modifier.weight(1f)) { onSelect(0.58, 0.0) }
        }
    }
}

@Composable
private fun SpinChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 8.sp, maxLines = 1) },
        modifier = modifier.height(30.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold.copy(alpha = 0.18f),
            selectedLabelColor = Gold,
            labelColor = Muted
        )
    )
}

@Composable
private fun ResultCard(state: PoolUiState, onAgain: () -> Unit) {
    val won = state.game?.winner == PlayerSeat.HUMAN
    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (won) "Level Ditakluki" else "AI Menang", color = Ivory, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(state.statusMessage, color = Muted, fontSize = 11.sp)
            }
            Surface(color = (if (won) Mint else Danger).copy(alpha = 0.13f), shape = CircleShape) {
                Text(if (won) "W" else "L", Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = if (won) Mint else Danger, fontWeight = FontWeight.Black)
            }
        }
        if (state.learningInsights.isNotEmpty()) {
            Surface(color = PanelSoft, shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("COUNTER YANG DIPELAJARI", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    state.learningInsights.forEach { Text("• $it", color = Ivory.copy(alpha = 0.86f), fontSize = 10.sp) }
                }
            }
        }
        Button(
            onClick = onAgain,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF17130D)),
            shape = RoundedCornerShape(13.dp)
        ) { Text(if (won) "Level Seterusnya" else "Cuba Semula", fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
private fun RulesDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        titleContentColor = Ivory,
        textContentColor = Muted,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text("Peraturan 8-Ball Lengkap", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                RuleLine("1", "Adapt Pool menggunakan 8-Ball WPA sebagai ruleset. Satu pengecualian tetap projek: pemain manusia sentiasa menjadi breaker pertama; tiada lag atau pilihan siapa mula.")
                RuleLine("2", "Rack mengandungi 15 bola objek. Apex berada pada Foot Spot, 8-ball berada di tengah rack, dan dua sudut belakang mesti mengandungi satu solid dan satu stripe. Bola lain tidak disusun dengan pola kumpulan yang disengajakan.")
                RuleLine("3", "Sebelum break, cue ball ialah in-hand tetapi terhad di belakang Head String. Pemain boleh menyeret cue ball dalam kawasan sah sebelum melakukan break.")
                RuleLine("4", "Break tidak memerlukan called ball atau called pocket. Jika breaker memot sekurang-kurangnya satu bola secara sah, breaker terus bermain dan meja masih OPEN. Jika tiada bola dipot, sekurang-kurangnya empat bola objek mesti sampai ke rail.")
                RuleLine("5", "Illegal break memberi pemain masuk pilihan rasmi: terima kedudukan meja, rack semula dan break sendiri, atau rack semula dan suruh breaker asal break lagi. Untuk pilihan yang melibatkan AI, AI membuat keputusan melalui evaluasi minimax.")
                RuleLine("6", "Jika 8-ball masuk pada break yang sah, breaker boleh spot semula 8-ball di Spot Line dan menerima kedudukan semasa, atau rack semula dan break lagi. Jika 8-ball masuk pada break yang juga foul, pemain masuk boleh memilih spot 8-ball + cue-ball in-hand di belakang Head String atau re-break.")
                RuleLine("7", "Jika mana-mana bola objek keluar meja ketika break, ia foul dan bola itu kekal keluar kecuali 8-ball yang mesti di-spot. Jika 8-ball sendiri keluar meja, pemain masuk memilih sama ada spot 8-ball dan menerima meja, atau spot 8-ball + cue-ball in-hand di belakang Head String. Untuk object-ball off-table lain/foul break lain, pemain masuk boleh menerima meja atau mengambil cue-ball in-hand di belakang Head String.")
                RuleLine("8", "Selepas break meja OPEN. Setiap pukulan bukan break ialah called shot. Untuk shot obvious, Adapt Pool mendaftarkan bola + poket secara automatik daripada line aim. Untuk bank, combo atau shot yang boleh mengelirukan, buka CALL dan pilih sendiri called ball + called pocket. Detail cushion, kiss atau carom tidak perlu dipanggil. Safety mesti dipanggil secara eksplisit.")
                RuleLine("9", "Ketika meja OPEN, mana-mana solid atau stripe boleh menjadi bola pertama, tetapi 8-ball tidak boleh disentuh dahulu kecuali satu kumpulan telah habis dan pemain secara sah sedang menembak 8-ball.")
                RuleLine("10", "Kumpulan hanya ditetapkan apabila called ball masuk ke called pocket secara sah. Selepas itu pemain mesti menyentuh bola daripada kumpulan sendiri dahulu sehingga kumpulan habis, kemudian sasaran sah pertama ialah 8-ball.")
                RuleLine("11", "Pemain kekal di meja hanya apabila called ball daripada kumpulan yang sah dibuat. Bola tambahan yang masuk kekal di poket. Jika called shot tidak dibuat tanpa foul, giliran berpindah.")
                RuleLine("12", "Safety yang sah sentiasa menamatkan giliran pemain selepas pukulan, walaupun ada bola objek yang masuk. Bola yang masuk ketika safety kekal dipoket.")
                RuleLine("13", "Foul standard digital: cue ball scratch/keluar meja, tidak menyentuh bola objek, bola pertama salah, tiada bola masuk dan tiada rail selepas contact, bola objek keluar meja, atau cue-ball placement tidak sah. Lawan mendapat cue-ball in-hand di seluruh meja kecuali sekatan khas selepas break.")
                RuleLine("14", "Foul fizikal seperti double-hit, push shot, menyentuh bola dengan badan/peralatan, bermain ketika bola masih bergerak dan bermain di luar giliran tidak dipendekkan; kawalan digital menghalang tindakan itu daripada boleh dilakukan. Shot hanya dilepaskan sebagai satu impulse cue yang sah selepas semua bola berhenti.")
                RuleLine("15", "Untuk menang, semua tujuh bola kumpulan sendiri mesti sudah tiada di meja, kemudian 8-ball mesti menjadi called ball dan masuk ke called pocket tanpa foul.")
                RuleLine("16", "Pemain kalah rack jika memot 8-ball sambil foul, memot 8-ball sebelum kumpulan sendiri habis, memasukkannya ke poket yang tidak dipanggil, atau menyebabkan 8-ball keluar meja. Peraturan kalah ini tidak digunakan pada break; break mempunyai pilihan khas di atas.")
                RuleLine("17", "Selepas standard foul, cue ball boleh diseret ke mana-mana posisi sah. Selepas foul break yang memberikan cue-ball in-hand di belakang Head String, seretan dihadkan kepada kawasan tersebut. Jika first-contact ball juga berada di belakang Head String, cue ball mesti melintasi Head String terlebih dahulu sebelum kembali menyentuhnya; jika semua sasaran sah berada di belakang Head String, pemain boleh meminta sasaran sah terdekat Head String untuk di-spot. Peraturan dan pilihan penempatan yang sama digunakan oleh AI.")
                RuleLine("18", "Jika keadaan benar-benar stalemate dan rack perlu dimulakan semula, breaker asal untuk rack tersebut kekal sebagai breaker. Dalam Adapt Pool, breaker asal disimpan dalam state supaya keputusan re-rack tidak mengubah hak break secara salah.")
                HorizontalDivider(color = Color(0xFF292D33))
                Text(
                    "Nota engine: fizik menggunakan fixed-step 120 Hz; UI tidak membenarkan pukulan baru ketika bola sedang bergerak. Ini menjadikan foul yang bergantung pada tindakan fizikal mustahil melalui input, bukannya dibuang daripada logik permainan.",
                    fontSize = 10.sp,
                    color = Muted.copy(alpha = 0.82f),
                    lineHeight = 14.sp
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Gold, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
private fun RuleLine(n: String, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
        Surface(color = Gold.copy(alpha = 0.13f), shape = CircleShape) {
            Text(n, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Text(text, color = Ivory.copy(alpha = 0.88f), fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.weight(1f))
    }
}

private fun statusColor(state: PoolUiState) = when (state.phase) {
    MatchPhase.READY -> Mint
    MatchPhase.AI_THINKING -> Gold
    MatchPhase.BALLS_MOVING -> Mint
    MatchPhase.BREAK_DECISION -> Gold
    MatchPhase.RESULT -> if (state.game?.winner == PlayerSeat.HUMAN) Mint else Danger
    MatchPhase.SETUP -> Muted
}

private fun statusText(state: PoolUiState) = when (state.phase) {
    MatchPhase.READY -> if (state.game?.turn == PlayerSeat.HUMAN) "Giliran kamu" else "Giliran AI"
    MatchPhase.AI_THINKING -> "AI minimax"
    MatchPhase.BALLS_MOVING -> "Bola bergerak"
    MatchPhase.BREAK_DECISION -> "Keputusan break"
    MatchPhase.RESULT -> "Perlawanan tamat"
    MatchPhase.SETUP -> "Sedia"
}

private fun groupLabel(group: BallGroup) = when (group) {
    BallGroup.OPEN -> "Meja terbuka"
    BallGroup.SOLIDS -> "Solids 1–7"
    BallGroup.STRIPES -> "Stripes 9–15"
}

private fun breakChoiceLabel(choice: BreakChoice) = when (choice) {
    BreakChoice.ACCEPT_TABLE -> "Terima kedudukan meja"
    BreakChoice.TAKE_CUE_BALL_HEAD_STRING -> "Cue-ball in hand di belakang Head String"
    BreakChoice.RERACK_AND_BREAK_SELF -> "Rack semula • saya ambil break"
    BreakChoice.RERACK_AND_BREAK_OPPONENT -> "Rack semula • breaker asal break lagi"
    BreakChoice.SPOT_EIGHT_AND_CONTINUE -> "Spot 8-ball • teruskan meja"
    BreakChoice.SPOT_EIGHT_AND_ACCEPT_TABLE -> "Spot 8-ball • terima meja"
    BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING -> "Spot 8-ball + cue-ball in hand"
    BreakChoice.REBREAK -> "Rack semula • break lagi"
}
