package com.adaptez.pool.domain.engine

import com.adaptez.pool.domain.model.*
import kotlin.math.abs

object PoolRules {
    fun evaluateShot(state: PoolGameState, result: ShotResult): RuleOutcome {
        if (state.gameOver) return RuleOutcome(state, false, message = "Perlawanan telah tamat")

        val shooter = state.turn
        val opponent = shooter.other()
        val shooterGroup = state.groupFor(shooter)
        val pocketedNumbers = result.pocketedBalls.map { it.number }
        val cueScratch = result.cueBallPocketed || result.cueBallOffTable || 0 in pocketedNumbers
        val eightPocket = result.pocketedBalls.firstOrNull { it.number == 8 }
        val eightOffTable = 8 in result.objectBallsDrivenOffTable

        var foulReason: String? = when {
            cueScratch -> "Cue ball masuk poket atau keluar meja"
            result.firstContact == null -> "Cue ball tidak menyentuh bola objek"
            result.objectBallsDrivenOffTable.isNotEmpty() -> "Bola objek keluar dari meja"
            else -> null
        }

        if (!state.isBreakShot && result.firstContact != null && foulReason == null) {
            val correctFirstContact = when (shooterGroup) {
                BallGroup.OPEN -> result.firstContact != 8 || openTableClearedGroup(state) != null
                BallGroup.SOLIDS, BallGroup.STRIPES -> {
                    if (state.remaining(shooterGroup) == 0) result.firstContact == 8
                    else state.ball(result.firstContact)?.group == shooterGroup
                }
            }
            if (!correctFirstContact) foulReason = "Bola pertama yang disentuh bukan sasaran sah"
        }

        if (!state.isBreakShot && result.firstContact != null && foulReason == null &&
            state.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING
        ) {
            val firstBall = state.ball(result.firstContact)
            val firstBallAboveHeadString = firstBall != null && firstBall.position.x < PoolGameState.HEAD_STRING_X
            if (firstBallAboveHeadString && !result.cueCrossedHeadStringBeforeFirstContact) {
                foulReason = "Bad play from above Head String: cue ball mesti melintasi Head String sebelum kembali menyentuh bola sasaran di kawasan yang sama"
            }
        }

        val noBallPocketed = result.pocketedBalls.isEmpty()
        if (!state.isBreakShot && foulReason == null && noBallPocketed && !result.railAfterContact) {
            foulReason = "Selepas sentuhan, sekurang-kurangnya satu bola mesti masuk poket atau menyentuh rail"
        }

        if (state.isBreakShot) {
            return evaluateBreak(state, result, foulReason)
        }

        if (eightPocket != null || eightOffTable) {
            val cleared = if (shooterGroup == BallGroup.OPEN) {
                openTableClearedGroup(state) != null
            } else {
                state.remaining(shooterGroup) == 0
            }
            val calledCorrectly = eightPocket != null &&
                result.calledBall == 8 &&
                result.calledPocket == eightPocket.pocket &&
                !result.safetyCalled
            val legalEight = foulReason == null && cleared && calledCorrectly && !eightOffTable
            val balls = applyOutcomes(state.balls, result.pocketedBalls, result.objectBallsDrivenOffTable)
            return RuleOutcome(
                state = state.copy(
                    balls = balls,
                    gameOver = true,
                    winner = if (legalEight) shooter else opponent,
                    isBreakShot = false,
                    ballInHand = false,
                    cueBallPlacementRule = CueBallPlacementRule.NONE,
                    shotNumber = state.shotNumber + 1,
                    calledBall = null,
                    calledPocket = null,
                    safetyCalled = false
                ),
                foul = !legalEight,
                foulReason = if (legalEight) null else foulReason ?: when {
                    eightOffTable -> "8-ball keluar dari meja"
                    !cleared -> "8-ball dipot sebelum kumpulan sendiri habis"
                    !calledCorrectly -> "8-ball tidak masuk ke poket yang dipanggil"
                    else -> "8-ball tidak sah"
                },
                message = if (legalEight) "8-ball sah. Menang." else "8-ball tidak sah. Kalah."
            )
        }

        val balls = applyOutcomes(state.balls, result.pocketedBalls, result.objectBallsDrivenOffTable)
        val foul = foulReason != null
        val legalCalledBall = result.calledBall?.let { isLegalCalledBall(state, shooter, it) } == true
        val callMade = !result.safetyCalled && legalCalledBall && result.calledPocket != null &&
            result.pocketedBalls.any { it.number == result.calledBall && it.pocket == result.calledPocket }

        var humanGroup = state.humanGroup
        var aiGroup = state.aiGroup
        if (shooterGroup == BallGroup.OPEN && !foul && callMade) {
            val calledGroup = state.ball(result.calledBall!!)?.group ?: BallGroup.OPEN
            if (calledGroup == BallGroup.SOLIDS || calledGroup == BallGroup.STRIPES) {
                if (shooter == PlayerSeat.HUMAN) {
                    humanGroup = calledGroup
                    aiGroup = calledGroup.oppositeGroup()
                } else {
                    aiGroup = calledGroup
                    humanGroup = calledGroup.oppositeGroup()
                }
            }
        }

        val nextTurn = when {
            foul -> opponent
            result.safetyCalled -> opponent
            callMade -> shooter
            else -> opponent
        }

        return RuleOutcome(
            state = state.copy(
                balls = balls,
                turn = nextTurn,
                humanGroup = humanGroup,
                aiGroup = aiGroup,
                isBreakShot = false,
                ballInHand = foul,
                cueBallPlacementRule = if (foul) CueBallPlacementRule.ANYWHERE else CueBallPlacementRule.NONE,
                shotNumber = state.shotNumber + 1,
                calledBall = null,
                calledPocket = null,
                safetyCalled = false
            ),
            foul = foul,
            foulReason = foulReason,
            message = when {
                foul -> "Foul: $foulReason • lawan mendapat cue-ball in hand"
                result.safetyCalled -> "Safety sah. Giliran bertukar."
                callMade -> "Called shot sah. Teruskan giliran."
                else -> "Called shot tidak dibuat. Giliran bertukar."
            }
        )
    }

    private fun evaluateBreak(state: PoolGameState, result: ShotResult, incomingFoul: String?): RuleOutcome {
        val shooter = state.turn
        val opponent = shooter.other()
        val pocketedNumbers = result.pocketedBalls.map { it.number }
        val eightPocket = result.pocketedBalls.firstOrNull { it.number == 8 }
        val eightOff = 8 in result.objectBallsDrivenOffTable
        val anyObjectPocketed = pocketedNumbers.any { it in 1..15 }
        val legalSpread = anyObjectPocketed || result.objectBallsToRail >= 4
        var foulReason = incomingFoul

        val balls = applyOutcomes(state.balls, result.pocketedBalls, result.objectBallsDrivenOffTable)
        val provisional = state.copy(
            balls = balls,
            isBreakShot = false,
            ballInHand = false,
            cueBallPlacementRule = CueBallPlacementRule.NONE,
            shotNumber = state.shotNumber + 1,
            calledBall = null,
            calledPocket = null,
            safetyCalled = false
        )

        if (!legalSpread && foulReason == null) {
            val decision = BreakDecision(
                chooser = opponent,
                originalBreaker = shooter,
                reason = "Break tidak sah: tiada bola dipot dan kurang daripada empat bola objek sampai ke rail",
                options = listOf(
                    BreakChoice.ACCEPT_TABLE,
                    BreakChoice.RERACK_AND_BREAK_SELF,
                    BreakChoice.RERACK_AND_BREAK_OPPONENT
                )
            )
            return RuleOutcome(provisional.copy(turn = opponent), true, decision.reason, decision.reason, decision)
        }

        if (eightOff && eightPocket == null) {
            val decision = BreakDecision(
                chooser = opponent,
                originalBreaker = shooter,
                reason = "8-ball keluar meja pada break; 8-ball mesti di-spot",
                options = listOf(BreakChoice.SPOT_EIGHT_AND_ACCEPT_TABLE, BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING)
            )
            return RuleOutcome(provisional.copy(turn = opponent), true, foulReason ?: decision.reason, decision.reason, decision)
        }

        if (eightPocket != null) {
            if (foulReason == null) {
                val decision = BreakDecision(
                    chooser = shooter,
                    originalBreaker = shooter,
                    reason = "8-ball masuk pada break yang sah",
                    options = listOf(BreakChoice.SPOT_EIGHT_AND_CONTINUE, BreakChoice.REBREAK)
                )
                return RuleOutcome(provisional.copy(turn = shooter), false, message = decision.reason, breakDecision = decision)
            }
            val decision = BreakDecision(
                chooser = opponent,
                originalBreaker = shooter,
                reason = "8-ball masuk pada break yang turut mengandungi foul",
                options = listOf(BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING, BreakChoice.REBREAK)
            )
            return RuleOutcome(provisional.copy(turn = opponent), true, foulReason, decision.reason, decision)
        }

        if (foulReason != null) {
            val decision = BreakDecision(
                chooser = opponent,
                originalBreaker = shooter,
                reason = foulReason,
                options = listOf(BreakChoice.ACCEPT_TABLE, BreakChoice.TAKE_CUE_BALL_HEAD_STRING)
            )
            return RuleOutcome(provisional.copy(turn = opponent), true, foulReason, "Foul pada break: $foulReason", decision)
        }

        val breakerContinues = anyObjectPocketed
        return RuleOutcome(
            state = provisional.copy(turn = if (breakerContinues) shooter else opponent),
            foul = false,
            message = if (breakerContinues) "Break sah. Meja kekal terbuka dan breaker meneruskan giliran." else "Break sah. Giliran bertukar."
        )
    }

    fun resolveBreakDecision(state: PoolGameState, decision: BreakDecision, choice: BreakChoice): PoolGameState {
        require(choice in decision.options) { "Pilihan break tidak sah untuk situasi ini" }
        return when (choice) {
            BreakChoice.ACCEPT_TABLE -> state.copy(
                turn = decision.chooser,
                isBreakShot = false,
                ballInHand = false,
                cueBallPlacementRule = CueBallPlacementRule.NONE,
                calledBall = null,
                calledPocket = null,
                safetyCalled = false
            )
            BreakChoice.TAKE_CUE_BALL_HEAD_STRING -> state.copy(
                balls = ensureCueBallOnTable(state.balls),
                turn = decision.chooser,
                isBreakShot = false,
                ballInHand = true,
                cueBallPlacementRule = CueBallPlacementRule.BEHIND_HEAD_STRING,
                calledBall = null,
                calledPocket = null,
                safetyCalled = false
            )
            BreakChoice.RERACK_AND_BREAK_SELF -> freshRackFor(decision.chooser)
            BreakChoice.RERACK_AND_BREAK_OPPONENT -> freshRackFor(decision.originalBreaker)
            BreakChoice.SPOT_EIGHT_AND_CONTINUE -> state.copy(
                balls = spotEight(state.balls),
                turn = decision.originalBreaker,
                isBreakShot = false,
                ballInHand = false,
                cueBallPlacementRule = CueBallPlacementRule.NONE
            )
            BreakChoice.SPOT_EIGHT_AND_ACCEPT_TABLE -> state.copy(
                balls = spotEight(state.balls),
                turn = decision.chooser,
                isBreakShot = false,
                ballInHand = false,
                cueBallPlacementRule = CueBallPlacementRule.NONE
            )
            BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING -> state.copy(
                balls = ensureCueBallOnTable(spotEight(state.balls)),
                turn = decision.chooser,
                isBreakShot = false,
                ballInHand = true,
                cueBallPlacementRule = CueBallPlacementRule.BEHIND_HEAD_STRING
            )
            BreakChoice.REBREAK -> freshRackFor(decision.chooser)
        }
    }

    private fun freshRackFor(breaker: PlayerSeat): PoolGameState = PoolGameState.standardRack().copy(
        turn = breaker,
        breaker = breaker,
        isBreakShot = true,
        ballInHand = true,
        cueBallPlacementRule = CueBallPlacementRule.BEHIND_HEAD_STRING,
        shotNumber = 0
    )

    private fun applyOutcomes(
        balls: List<PoolBall>,
        pocketed: List<PocketedBall>,
        offTable: Set<Int>
    ): List<PoolBall> {
        val removed = pocketed.map { it.number }.toSet() + offTable
        return balls.map { ball ->
            if (ball.number in removed) ball.copy(pocketed = true, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else ball
        }
    }

    private fun ensureCueBallOnTable(balls: List<PoolBall>): List<PoolBall> = balls.map { ball ->
        if (ball.number == 0) ball.copy(
            position = Vec2(-0.92, 0.0),
            pocketed = false,
            velocity = Vec2.ZERO,
            angularVelocity = Vec2.ZERO
        ) else ball
    }

    private fun spotEight(balls: List<PoolBall>): List<PoolBall> = spotObjectBall(balls, 8)

    private fun spotObjectBall(balls: List<PoolBall>, number: Int): List<PoolBall> {
        val base = Vec2(PoolGameState.FOOT_SPOT_X, 0.0)
        val occupied = balls.filter { !it.pocketed && it.number != number }
        val step = PoolGameState.BALL_RADIUS * 2.01
        val candidates = buildList {
            // Standard spot line: Foot Spot toward foot rail first, then above Foot Spot if blocked.
            for (index in 0 until 30) add(Vec2((base.x + index * step).coerceAtMost(PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS), 0.0))
            for (index in 1 until 30) add(Vec2((base.x - index * step).coerceAtLeast(-PoolGameState.TABLE_HALF_LENGTH + PoolGameState.BALL_RADIUS), 0.0))
        }
        val spot = candidates.firstOrNull { candidate -> occupied.none { (it.position - candidate).length() < step } } ?: base
        return balls.map { ball ->
            if (ball.number == number) ball.copy(position = spot, pocketed = false, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else ball
        }
    }

    fun isLegalCueBallPlacement(state: PoolGameState, candidate: Vec2): Boolean {
        val xLimit = PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS * 1.2
        val yLimit = PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS * 1.2
        if (abs(candidate.x) > xLimit || abs(candidate.y) > yLimit) return false
        if (state.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING && candidate.x > PoolGameState.HEAD_STRING_X) return false
        return state.balls.none { ball ->
            ball.number != 0 && !ball.pocketed && (ball.position - candidate).length() < PoolGameState.BALL_RADIUS * 2.05
        }
    }


    fun headStringSpotCandidates(state: PoolGameState, player: PlayerSeat): List<Int> {
        if (state.cueBallPlacementRule != CueBallPlacementRule.BEHIND_HEAD_STRING) return emptyList()
        val legal = state.balls.filter { ball ->
            !ball.pocketed && ball.number != 0 && isLegalCalledBall(state, player, ball.number)
        }
        if (legal.isEmpty() || legal.any { it.position.x >= PoolGameState.HEAD_STRING_X }) return emptyList()
        val nearestX = legal.maxOf { it.position.x }
        return legal.filter { abs(it.position.x - nearestX) <= 1e-6 }.map { it.number }.sorted()
    }

    fun requestHeadStringSpot(state: PoolGameState, player: PlayerSeat, ballNumber: Int): PoolGameState {
        require(ballNumber in headStringSpotCandidates(state, player)) { "Bola ini tidak layak diminta spot dari kawasan Head String" }
        return state.copy(balls = spotObjectBall(state.balls, ballNumber))
    }

    fun isOnEight(state: PoolGameState, player: PlayerSeat): Boolean {
        val group = state.groupFor(player)
        return when (group) {
            BallGroup.OPEN -> openTableClearedGroup(state) != null
            BallGroup.SOLIDS, BallGroup.STRIPES -> state.remaining(group) == 0
        }
    }

    fun isLegalCalledBall(state: PoolGameState, player: PlayerSeat, ballNumber: Int): Boolean {
        if (ballNumber !in 1..15) return false
        val group = state.groupFor(player)
        return when (group) {
            BallGroup.OPEN -> if (ballNumber == 8) isOnEight(state, player) else true
            BallGroup.SOLIDS, BallGroup.STRIPES -> if (isOnEight(state, player)) ballNumber == 8 else state.ball(ballNumber)?.group == group
        }
    }

    private fun openTableClearedGroup(state: PoolGameState): BallGroup? = when {
        state.humanGroup != BallGroup.OPEN || state.aiGroup != BallGroup.OPEN -> null
        state.remaining(BallGroup.SOLIDS) == 0 -> BallGroup.SOLIDS
        state.remaining(BallGroup.STRIPES) == 0 -> BallGroup.STRIPES
        else -> null
    }

    fun resolveStalemate(state: PoolGameState): PoolGameState = freshRackFor(state.breaker)

    private fun PlayerSeat.other() = if (this == PlayerSeat.HUMAN) PlayerSeat.AI else PlayerSeat.HUMAN
    private fun BallGroup.oppositeGroup() = when (this) {
        BallGroup.SOLIDS -> BallGroup.STRIPES
        BallGroup.STRIPES -> BallGroup.SOLIDS
        BallGroup.OPEN -> BallGroup.OPEN
    }
}
