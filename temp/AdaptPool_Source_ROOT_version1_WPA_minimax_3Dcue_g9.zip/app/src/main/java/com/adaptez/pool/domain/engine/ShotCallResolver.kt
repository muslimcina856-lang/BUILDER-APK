package com.adaptez.pool.domain.engine

import com.adaptez.pool.domain.model.*
import kotlin.math.cos
import kotlin.math.sin

/** Resolves the obvious called ball + pocket from the actual aim line for digital call-shot play. */
object ShotCallResolver {
    fun resolve(state: PoolGameState, aimDegrees: Double, safety: Boolean = false): ShotCall {
        if (state.isBreakShot) return ShotCall(null, null, safety = false)
        val cue = state.ball(0)?.takeUnless { it.pocketed } ?: return ShotCall(null, null, safety)
        val radians = Math.toRadians(aimDegrees)
        val aim = Vec2(cos(radians), sin(radians)).normalized()
        val targets = state.balls.filter { ball ->
            !ball.pocketed && ball.number != 0 && PoolRules.isLegalCalledBall(state, state.turn, ball.number)
        }
        if (targets.isEmpty()) return ShotCall(null, null, safety)

        val target = targets.mapNotNull { ball ->
            val delta = ball.position - cue.position
            val forward = delta.dot(aim)
            if (forward <= 0.0) null else {
                val closest = cue.position + aim * forward
                val lateral = (ball.position - closest).length()
                Triple(ball, forward, lateral)
            }
        }.sortedWith(compareBy<Triple<PoolBall, Double, Double>> { it.third }.thenBy { it.second })
            .firstOrNull { it.third <= PoolGameState.BALL_RADIUS * 2.8 }
            ?.first
            ?: targets.maxByOrNull { ball ->
                val d = (ball.position - cue.position).normalized()
                d.dot(aim)
            }
            ?: return ShotCall(null, null, safety)

        if (safety) return ShotCall(target.number, null, safety = true)

        val pockets = pocketCenters()
        val bestPocket = pockets.indices.maxByOrNull { index ->
            val pocket = pockets[index]
            val objectDir = (pocket - target.position).normalized()
            val ghost = target.position - objectDir * (PoolGameState.BALL_RADIUS * 2.03)
            val cueDir = (ghost - cue.position).normalized()
            val alignment = cueDir.dot(aim)
            val clearBonus = if (
                pathClear(cue.position, ghost, state.balls, setOf(0, target.number), PoolGameState.BALL_RADIUS * 2.08) &&
                pathClear(target.position, pocket, state.balls, setOf(target.number), PoolGameState.BALL_RADIUS * 1.92)
            ) 0.4 else -0.4
            alignment + clearBonus - (pocket - target.position).length() * 0.08
        }
        return ShotCall(target.number, bestPocket, safety = false)
    }

    private fun pathClear(start: Vec2, end: Vec2, balls: List<PoolBall>, ignored: Set<Int>, clearance: Double): Boolean {
        val segment = end - start
        val lengthSquared = segment.dot(segment)
        if (lengthSquared <= 1e-10) return false
        return balls.asSequence().filter { !it.pocketed && it.number !in ignored }.all { ball ->
            val t = ((ball.position - start).dot(segment) / lengthSquared).coerceIn(0.0, 1.0)
            val closest = start + segment * t
            (ball.position - closest).length() >= clearance
        }
    }

    private fun pocketCenters() = listOf(
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH)
    )
}
