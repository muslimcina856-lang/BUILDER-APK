package com.adaptez.pool.presentation.pool

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.adaptez.pool.domain.model.PoolGameState

@Composable
fun Pool3DView(
    game: PoolGameState,
    aimDegrees: Double,
    showAim: Boolean,
    canInteract: Boolean,
    ballInHand: Boolean,
    cuePullback: Double,
    onAimDrag: (Double) -> Unit,
    onCueBallDrag: (Double, Double) -> Unit,
    onCuePull: (Double) -> Unit,
    onCueRelease: (Double) -> Unit,
    onCueCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier,
        factory = { context -> PoolOpenGLSurfaceView(context) },
        update = { view ->
            view.bindInteraction(
                canAim = canInteract,
                ballInHandMode = canInteract && ballInHand,
                onAimDrag = onAimDrag,
                onCueBallMove = onCueBallDrag,
                onCuePull = onCuePull,
                onCueRelease = onCueRelease,
                onCueCancel = onCueCancel
            )
            view.updateScene(
                PoolOpenGLScene(
                    balls = game.balls,
                    aimDegrees = aimDegrees,
                    showAim = showAim,
                    showCue = showAim,
                    cuePullback = cuePullback
                )
            )
        }
    )
}
