package com.adaptez.pool.presentation.pool

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adaptez.pool.data.local.*
import com.adaptez.pool.domain.ai.AdaptivePoolAi
import com.adaptez.pool.domain.engine.PoolPhysics
import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.engine.ShotCallResolver
import com.adaptez.pool.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import javax.inject.Inject

enum class MatchPhase { SETUP, READY, BALLS_MOVING, AI_THINKING, BREAK_DECISION, RESULT }

data class PoolUiState(
    val game: PoolGameState? = null,
    val phase: MatchPhase = MatchPhase.SETUP,
    val player: PlayerProfileEntity? = null,
    val learning: PlayerLearningProfile = PlayerLearningProfile(),
    val history: List<MatchEntity> = emptyList(),
    val aimDegrees: Double = 0.0,
    val power: Double = 0.08,
    val spinX: Double = 0.0,
    val spinY: Double = 0.0,
    val selectedCalledBall: Int? = null,
    val selectedPocket: Int? = null,
    val safetyCalled: Boolean = false,
    val pendingBreakDecision: BreakDecision? = null,
    val humanShots: Int = 0,
    val humanSuccessfulShots: Int = 0,
    val totalShots: Int = 0,
    val statusMessage: String = "Sedia untuk 8-Ball",
    val learningInsights: List<String> = listOf("AI akan belajar corak kamu sebagai lapisan counter"),
    val collisionPulse: Int = 0,
    val pocketPulse: Int = 0,
    val cuePulse: Int = 0,
    val errorMessage: String? = null
) {
    val currentLevel: Int get() = player?.currentLevel ?: 1
    val isHumanTurn: Boolean get() = game?.turn == PlayerSeat.HUMAN
    val canShoot: Boolean get() = phase == MatchPhase.READY && isHumanTurn && game?.gameOver == false
}

@HiltViewModel
class PoolViewModel @Inject constructor(
    private val dao: PoolDao
) : ViewModel() {
    private val _uiState = MutableStateFlow(PoolUiState())
    val uiState: StateFlow<PoolUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null
    private var matchStartedAt = 0L

    init {
        viewModelScope.launch {
            val player = dao.getPlayer() ?: PlayerProfileEntity().also { dao.savePlayer(it) }
            val learningEntity = dao.getLearningProfile() ?: LearningProfileEntity().also { dao.saveLearningProfile(it) }
            _uiState.value = _uiState.value.copy(
                player = player,
                learning = learningEntity.toDomain(),
                learningInsights = AdaptivePoolAi.profileSummary(learningEntity.toDomain())
            )
            dao.observeMatches().collectLatest { matches ->
                _uiState.value = _uiState.value.copy(history = matches)
            }
        }
    }

    fun startMatch() {
        simulationJob?.cancel()
        matchStartedAt = System.currentTimeMillis()
        val game = PoolGameState.playerBreakRack()
        _uiState.value = _uiState.value.copy(
            game = game,
            phase = MatchPhase.READY,
            aimDegrees = 0.0,
            power = 0.08,
            spinX = 0.0,
            spinY = 0.0,
            selectedCalledBall = null,
            selectedPocket = null,
            safetyCalled = false,
            pendingBreakDecision = null,
            humanShots = 0,
            humanSuccessfulShots = 0,
            totalShots = 0,
            statusMessage = "Giliran kamu • letak cue ball di belakang Head String dan break",
            learningInsights = AdaptivePoolAi.profileSummary(_uiState.value.learning),
            errorMessage = null
        )
    }

    fun returnToSetup() {
        simulationJob?.cancel()
        _uiState.value = _uiState.value.copy(game = null, phase = MatchPhase.SETUP, statusMessage = "Sedia untuk 8-Ball")
    }

    fun setAimDegrees(value: Double) {
        if (!_uiState.value.canShoot) return
        _uiState.value = _uiState.value.copy(aimDegrees = normalizeDegrees(value))
    }

    fun nudgeAim(delta: Double) = setAimDegrees(_uiState.value.aimDegrees + delta)

    fun setPower(value: Double) {
        if (!_uiState.value.canShoot) return
        _uiState.value = _uiState.value.copy(power = value.coerceIn(0.08, 1.0))
    }

    fun resetCuePull() {
        if (!_uiState.value.canShoot) return
        _uiState.value = _uiState.value.copy(power = 0.08)
    }

    fun setSpin(x: Double, y: Double) {
        if (!_uiState.value.canShoot) return
        _uiState.value = _uiState.value.copy(spinX = x.coerceIn(-1.0, 1.0), spinY = y.coerceIn(-1.0, 1.0))
    }

    fun toggleSafety() {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot || game.isBreakShot) return
        _uiState.value = state.copy(safetyCalled = !state.safetyCalled)
    }

    fun setCueBallPosition(x: Double? = null, y: Double? = null) {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot || !game.ballInHand) return
        val cue = game.ball(0) ?: return
        val candidate = Vec2(x ?: cue.position.x, y ?: cue.position.y)
        if (!PoolRules.isLegalCueBallPlacement(game, candidate)) {
            _uiState.value = state.copy(statusMessage = if (game.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING) {
                "Cue ball mesti berada di belakang Head String dan tidak bertindih dengan bola lain"
            } else "Cue ball tidak boleh bertindih dengan bola lain atau keluar meja")
            return
        }
        val balls = game.balls.map {
            if (it.number == 0) it.copy(position = candidate, pocketed = false, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else it
        }
        _uiState.value = state.copy(
            game = game.copy(balls = balls),
            statusMessage = if (game.isBreakShot) "Posisi break dipilih • sentuh cue dan tarik" else "Ball-in-hand • posisi dipilih"
        )
    }

    fun selectCalledBall(number: Int?) {
        val state = _uiState.value
        val game = state.game ?: return
        if (number == null) {
            _uiState.value = state.copy(selectedCalledBall = null)
            return
        }
        if (!state.canShoot || game.isBreakShot || !PoolRules.isLegalCalledBall(game, PlayerSeat.HUMAN, number)) return
        _uiState.value = state.copy(selectedCalledBall = number)
    }

    fun selectPocket(index: Int?) {
        _uiState.value = _uiState.value.copy(selectedPocket = index?.coerceIn(0, 5))
    }

    fun requestHeadStringSpot(ballNumber: Int) {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot || game.turn != PlayerSeat.HUMAN) return
        if (ballNumber !in PoolRules.headStringSpotCandidates(game, PlayerSeat.HUMAN)) return
        val resolved = PoolRules.requestHeadStringSpot(game, PlayerSeat.HUMAN, ballNumber)
        _uiState.value = state.copy(game = resolved, statusMessage = "Bola $ballNumber di-spot pada Spot Line")
    }

    fun shoot() {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot) return
        val radians = state.aimDegrees * PI / 180.0
        val direction = Vec2(cos(radians), sin(radians)).normalized()
        val safety = state.safetyCalled && !game.isBreakShot
        val autoCall = ShotCallResolver.resolve(game, state.aimDegrees, safety)
        val onEight = !game.isBreakShot && PoolRules.isOnEight(game, PlayerSeat.HUMAN)
        val calledBall = when {
            game.isBreakShot || safety -> null
            onEight -> 8
            state.selectedCalledBall != null -> state.selectedCalledBall
            else -> autoCall.ball
        }
        val calledPocket = when {
            game.isBreakShot || safety -> null
            onEight -> state.selectedPocket
            state.selectedCalledBall != null || state.selectedPocket != null -> state.selectedPocket
            else -> autoCall.pocket
        }
        if (onEight && !safety && calledPocket == null) {
            _uiState.value = state.copy(statusMessage = "Pilih poket panggilan untuk 8-ball")
            return
        }
        if (!game.isBreakShot && !safety && (state.selectedCalledBall != null || state.selectedPocket != null) &&
            (state.selectedCalledBall == null || state.selectedPocket == null)
        ) {
            _uiState.value = state.copy(statusMessage = "Manual Call memerlukan satu bola dan satu poket")
            return
        }
        val start = game.copy(
            ballInHand = false,
            calledBall = calledBall,
            calledPocket = calledPocket,
            safetyCalled = safety
        )
        simulateShot(
            actor = PlayerSeat.HUMAN,
            startState = start,
            direction = direction,
            power = state.power,
            spin = Vec2(state.spinX, state.spinY),
            calledBall = calledBall,
            calledPocket = calledPocket,
            safetyIntent = safety
        )
    }

    private fun scheduleAiShot(waitMs: Long = 650L) {
        simulationJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(phase = MatchPhase.AI_THINKING, statusMessage = "AI minimax sedang membaca meja…")
            delay(waitMs)
            var state = _uiState.value
            var game = state.game ?: return@launch
            if (game.turn != PlayerSeat.AI || game.gameOver) return@launch

            if (game.ballInHand) {
                val spotCandidates = PoolRules.headStringSpotCandidates(game, PlayerSeat.AI)
                if (spotCandidates.isNotEmpty()) {
                    // WPA 1.6 gives the shooter this option. AI uses it when every legal target is above the Head String.
                    game = PoolRules.requestHeadStringSpot(game, PlayerSeat.AI, spotCandidates.first())
                    _uiState.value = state.copy(game = game, statusMessage = "AI meminta bola ${spotCandidates.first()} di-spot…")
                    delay(180L)
                }
                val placement = withContext(Dispatchers.Default) {
                    AdaptivePoolAi.chooseCueBallPlacement(game, state.currentLevel, state.learning)
                }
                val balls = game.balls.map { ball ->
                    if (ball.number == 0) ball.copy(position = placement, pocketed = false, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else ball
                }
                game = game.copy(
                    balls = balls,
                    ballInHand = false
                )
                _uiState.value = state.copy(game = game, statusMessage = "AI memilih posisi cue ball…")
                delay(220L)
                state = _uiState.value
            }

            val plan = withContext(Dispatchers.Default) {
                AdaptivePoolAi.chooseShot(game, state.currentLevel, state.learning)
            }
            simulateShot(
                actor = PlayerSeat.AI,
                startState = game.copy(
                    calledBall = plan.calledBall,
                    calledPocket = plan.calledPocket,
                    safetyCalled = plan.safetyIntent
                ),
                direction = plan.direction,
                power = plan.power,
                spin = plan.spin,
                calledBall = plan.calledBall,
                calledPocket = plan.calledPocket,
                safetyIntent = plan.safetyIntent,
                launchNewJob = false
            )
        }
    }

    private fun simulateShot(
        actor: PlayerSeat,
        startState: PoolGameState,
        direction: Vec2,
        power: Double,
        spin: Vec2,
        calledBall: Int?,
        calledPocket: Int?,
        safetyIntent: Boolean,
        launchNewJob: Boolean = true
    ) {
        if (launchNewJob) simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            executeShot(actor, startState, direction, power, spin, calledBall, calledPocket, safetyIntent)
        }
    }

    private suspend fun executeShot(
        actor: PlayerSeat,
        startState: PoolGameState,
        direction: Vec2,
        power: Double,
        spin: Vec2,
        calledBall: Int?,
        calledPocket: Int?,
        safetyIntent: Boolean
    ) {
        var balls = PoolPhysics.strike(startState.balls, direction, power, spin)
        var firstContact: Int? = null
        var cueCrossedHeadStringBeforeFirstContact = startState.cueBallPlacementRule != CueBallPlacementRule.BEHIND_HEAD_STRING
        var railAfterContact = false
        val objectRails = linkedSetOf<Int>()
        val pockets = linkedMapOf<Int, PocketedBall>()
        var collisionPulse = _uiState.value.collisionPulse
        var pocketPulse = _uiState.value.pocketPulse

        _uiState.value = _uiState.value.copy(
            game = startState.copy(balls = balls, calledBall = calledBall, calledPocket = calledPocket, safetyCalled = safetyIntent),
            phase = MatchPhase.BALLS_MOVING,
            totalShots = _uiState.value.totalShots + 1,
            humanShots = _uiState.value.humanShots + if (actor == PlayerSeat.HUMAN) 1 else 0,
            statusMessage = if (actor == PlayerSeat.HUMAN) "Pukulan bergerak…" else "AI melakukan pukulan…",
            cuePulse = _uiState.value.cuePulse + 1
        )

        for (renderFrame in 0 until 900) {
            repeat(2) {
                val frame = PoolPhysics.step(balls)
                balls = frame.balls
                if (firstContact == null && startState.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING) {
                    val cueNow = balls.firstOrNull { it.number == 0 && !it.pocketed }
                    if (cueNow != null && cueNow.position.x >= PoolGameState.HEAD_STRING_X) {
                        cueCrossedHeadStringBeforeFirstContact = true
                    }
                }
                if (firstContact == null) {
                    frame.collisions.firstOrNull { (a, b) -> a == 0 || b == 0 }?.let { pair ->
                        firstContact = if (pair.first == 0) pair.second else pair.first
                    }
                }
                if (firstContact != null && frame.railContacts.isNotEmpty()) railAfterContact = true
                objectRails += frame.railContacts.filter { it != 0 }
                if (frame.collisions.isNotEmpty()) collisionPulse += frame.collisions.size
                frame.pocketed.forEach { pocketed ->
                    if (pocketed.number !in pockets) {
                        pockets[pocketed.number] = pocketed
                        pocketPulse++
                    }
                }
            }
            _uiState.value = _uiState.value.copy(
                game = _uiState.value.game?.copy(balls = balls),
                collisionPulse = collisionPulse,
                pocketPulse = pocketPulse
            )
            if (PoolPhysics.isAtRest(balls)) break
            delay(16L)
        }

        balls = balls.map { if (!it.pocketed) it.copy(velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else it }
        val shotResult = ShotResult(
            firstContact = firstContact,
            pocketedBalls = pockets.values.toList(),
            cueBallPocketed = pockets.containsKey(0),
            railAfterContact = railAfterContact,
            objectBallsToRail = objectRails.size,
            cueCrossedHeadStringBeforeFirstContact = cueCrossedHeadStringBeforeFirstContact,
            calledBall = calledBall,
            calledPocket = calledPocket,
            safetyCalled = safetyIntent
        )
        val outcome = PoolRules.evaluateShot(startState, shotResult)
        var resolvedBalls = mergeFinalPositions(outcome.state.balls, balls)
        if (outcome.state.ballInHand) {
            val defaultPosition = if (outcome.state.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING) Vec2(-0.92, 0.0) else Vec2(-0.72, 0.0)
            resolvedBalls = PoolPhysics.respotCueBall(resolvedBalls, defaultPosition)
        }
        var resolvedGame = outcome.state.copy(balls = resolvedBalls)

        var learning = _uiState.value.learning
        var successfulShots = _uiState.value.humanSuccessfulShots
        if (actor == PlayerSeat.HUMAN) {
            val pottedCalled = calledBall != null && pockets[calledBall]?.pocket == calledPocket && !outcome.foul
            if (pottedCalled) successfulShots++
            learning = AdaptivePoolAi.learn(
                learning,
                ShotObservation(
                    power = power,
                    spinMagnitude = spin.length().coerceIn(0.0, 1.0),
                    usedBank = objectRails.isNotEmpty(),
                    safetyIntent = safetyIntent,
                    pottedBall = pottedCalled
                )
            )
            dao.saveLearningProfile(learning.toEntity())
        }

        val decision = outcome.breakDecision
        if (decision != null) {
            if (decision.chooser == PlayerSeat.AI) {
                val choice = withContext(Dispatchers.Default) {
                    AdaptivePoolAi.chooseBreakChoice(resolvedGame, decision, _uiState.value.currentLevel, learning)
                }
                resolvedGame = PoolRules.resolveBreakDecision(resolvedGame, decision, choice)
                if (resolvedGame.ballInHand) {
                    val defaultPosition = if (resolvedGame.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING) Vec2(-0.92, 0.0) else Vec2(-0.72, 0.0)
                    resolvedGame = resolvedGame.copy(balls = PoolPhysics.respotCueBall(resolvedGame.balls, defaultPosition))
                }
                _uiState.value = _uiState.value.copy(
                    game = resolvedGame,
                    learning = learning,
                    humanSuccessfulShots = successfulShots,
                    selectedCalledBall = null,
                    selectedPocket = null,
                    safetyCalled = false,
                    pendingBreakDecision = null,
                    power = 0.08,
                    phase = if (resolvedGame.turn == PlayerSeat.AI) MatchPhase.AI_THINKING else MatchPhase.READY,
                    statusMessage = "AI memilih: ${breakChoiceLabel(choice)}",
                    learningInsights = AdaptivePoolAi.profileSummary(learning)
                )
                if (resolvedGame.turn == PlayerSeat.AI) scheduleAiShot(520L)
                return
            }

            _uiState.value = _uiState.value.copy(
                game = resolvedGame,
                learning = learning,
                humanSuccessfulShots = successfulShots,
                selectedCalledBall = null,
                selectedPocket = null,
                safetyCalled = false,
                pendingBreakDecision = decision,
                power = 0.08,
                phase = MatchPhase.BREAK_DECISION,
                statusMessage = decision.reason,
                learningInsights = AdaptivePoolAi.profileSummary(learning)
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            game = resolvedGame,
            learning = learning,
            humanSuccessfulShots = successfulShots,
            selectedCalledBall = null,
            selectedPocket = null,
            safetyCalled = false,
            pendingBreakDecision = null,
            power = 0.08,
            phase = when {
                resolvedGame.gameOver -> MatchPhase.RESULT
                resolvedGame.turn == PlayerSeat.AI -> MatchPhase.AI_THINKING
                else -> MatchPhase.READY
            },
            statusMessage = outcome.message,
            learningInsights = AdaptivePoolAi.profileSummary(learning)
        )

        if (resolvedGame.gameOver) {
            finishMatch(resolvedGame.winner == PlayerSeat.HUMAN)
        } else if (resolvedGame.turn == PlayerSeat.AI) {
            scheduleAiShot(700L)
        }
    }

    fun chooseBreakOption(choice: BreakChoice) {
        val state = _uiState.value
        val decision = state.pendingBreakDecision ?: return
        val game = state.game ?: return
        if (decision.chooser != PlayerSeat.HUMAN || choice !in decision.options) return
        var resolved = PoolRules.resolveBreakDecision(game, decision, choice)
        if (resolved.ballInHand) {
            val defaultPosition = if (resolved.cueBallPlacementRule == CueBallPlacementRule.BEHIND_HEAD_STRING) Vec2(-0.92, 0.0) else Vec2(-0.72, 0.0)
            resolved = resolved.copy(balls = PoolPhysics.respotCueBall(resolved.balls, defaultPosition))
        }
        _uiState.value = state.copy(
            game = resolved,
            pendingBreakDecision = null,
            power = 0.08,
            phase = if (resolved.turn == PlayerSeat.AI) MatchPhase.AI_THINKING else MatchPhase.READY,
            statusMessage = breakChoiceLabel(choice)
        )
        if (resolved.turn == PlayerSeat.AI) scheduleAiShot(520L)
    }

    private suspend fun finishMatch(playerWon: Boolean) {
        val state = _uiState.value
        val oldPlayer = state.player ?: return
        val duration = (System.currentTimeMillis() - matchStartedAt).coerceAtLeast(0L)
        val newStreak = if (playerWon) oldPlayer.currentStreak + 1 else 0
        val levelPlayed = oldPlayer.currentLevel
        val nextLevel = if (playerWon) (levelPlayed + 1).coerceAtMost(999) else levelPlayed
        val updatedPlayer = oldPlayer.copy(
            currentLevel = nextLevel,
            totalMatches = oldPlayer.totalMatches + 1,
            wins = oldPlayer.wins + if (playerWon) 1 else 0,
            losses = oldPlayer.losses + if (playerWon) 0 else 1,
            currentStreak = newStreak,
            bestStreak = maxOf(oldPlayer.bestStreak, newStreak),
            totalPlayTimeMs = oldPlayer.totalPlayTimeMs + duration,
            masteredLevel999 = oldPlayer.masteredLevel999 || (playerWon && levelPlayed == 999),
            updatedAt = System.currentTimeMillis()
        )
        dao.savePlayer(updatedPlayer)
        val game = state.game
        val playerGroup = game?.humanGroup?.name ?: BallGroup.OPEN.name
        val pottedCount = game?.balls?.count { it.number in 1..15 && it.pocketed } ?: 0
        val accuracy = if (state.humanShots == 0) 0.0 else state.humanSuccessfulShots * 100.0 / state.humanShots
        val summary = AdaptivePoolAi.profileSummary(state.learning).joinToString("\n")
        dao.saveMatch(
            MatchEntity(
                result = if (playerWon) "WIN" else "LOSS",
                level = levelPlayed,
                playerGroup = playerGroup,
                totalShots = state.humanShots,
                pottedBalls = pottedCount,
                shotAccuracy = accuracy,
                durationMs = duration,
                learningSummary = summary
            )
        )
        _uiState.value = _uiState.value.copy(
            player = updatedPlayer,
            phase = MatchPhase.RESULT,
            statusMessage = if (playerWon) {
                if (levelPlayed >= 999) "Level 999 dikuasai." else "Level $levelPlayed ditakluki • Level $nextLevel dibuka"
            } else "AI menang pada Level $levelPlayed • Cuba lagi"
        )
    }

    fun nextOrRetry() {
        val state = _uiState.value
        if (state.phase != MatchPhase.RESULT) return
        startMatch()
    }

    private fun mergeFinalPositions(ruleBalls: List<PoolBall>, finalBalls: List<PoolBall>): List<PoolBall> {
        val positions = finalBalls.associateBy { it.number }
        return ruleBalls.map { ball ->
            val final = positions[ball.number]
            if (final == null) ball else ball.copy(position = final.position, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO)
        }
    }

    private fun normalizeDegrees(value: Double): Double {
        var result = value % 360.0
        if (result > 180.0) result -= 360.0
        if (result < -180.0) result += 360.0
        return result
    }

    private fun breakChoiceLabel(choice: BreakChoice) = when (choice) {
        BreakChoice.ACCEPT_TABLE -> "Terima kedudukan meja"
        BreakChoice.TAKE_CUE_BALL_HEAD_STRING -> "Cue-ball in hand di belakang Head String"
        BreakChoice.RERACK_AND_BREAK_SELF -> "Rack semula dan ambil break"
        BreakChoice.RERACK_AND_BREAK_OPPONENT -> "Rack semula dan beri breaker asal break semula"
        BreakChoice.SPOT_EIGHT_AND_CONTINUE -> "Spot 8-ball dan teruskan meja"
        BreakChoice.SPOT_EIGHT_AND_ACCEPT_TABLE -> "Spot 8-ball dan terima kedudukan meja"
        BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING -> "Spot 8-ball + cue-ball in hand di belakang Head String"
        BreakChoice.REBREAK -> "Rack semula dan break semula"
    }

    private fun LearningProfileEntity.toDomain() = PlayerLearningProfile(
        aggression = aggression,
        safety = safety,
        averagePower = averagePower,
        spinUsage = spinUsage,
        bankUsage = bankUsage,
        potSuccess = potSuccess,
        samples = samples
    )

    private fun PlayerLearningProfile.toEntity() = LearningProfileEntity(
        aggression = aggression,
        safety = safety,
        averagePower = averagePower,
        spinUsage = spinUsage,
        bankUsage = bankUsage,
        potSuccess = potSuccess,
        samples = samples,
        updatedAt = System.currentTimeMillis()
    )
}
