package com.adaptez.pool.domain.ai

import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.*
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object AdaptivePoolAi {
    fun learn(profile: PlayerLearningProfile, observation: ShotObservation): PlayerLearningProfile {
        val nextSamples = profile.samples + 1
        val alpha = if (profile.samples < 8) 0.24 else 0.12
        val aggressiveSignal = when {
            observation.safetyIntent -> 0.08
            observation.power >= 0.72 -> 0.95
            else -> 0.56
        }
        val safetySignal = if (observation.safetyIntent) 1.0 else 0.12
        val spinSignal = if (observation.spinMagnitude >= 0.12) 1.0 else 0.0
        val bankSignal = if (observation.usedBank) 1.0 else 0.0
        val potSignal = if (observation.pottedBall) 1.0 else 0.0
        return profile.copy(
            aggression = ema(profile.aggression, aggressiveSignal, alpha),
            safety = ema(profile.safety, safetySignal, alpha),
            averagePower = ema(profile.averagePower, observation.power.coerceIn(0.0, 1.0), alpha),
            spinUsage = ema(profile.spinUsage, spinSignal, alpha),
            bankUsage = ema(profile.bankUsage, bankSignal, alpha),
            potSuccess = ema(profile.potSuccess, potSignal, alpha),
            samples = nextSamples
        )
    }

    /** Core AI strength is level-only. Player learning never changes search depth, aim error or power error. */
    @Suppress("UNUSED_PARAMETER")
    fun parametersFor(level: Int, profile: PlayerLearningProfile = PlayerLearningProfile()): AiParameters = difficultyFor(level)

    fun difficultyFor(level: Int): AiParameters {
        val l = level.coerceIn(1, 999)
        val mastery = (l - 1) / 998.0
        return AiParameters(
            aimErrorDegrees = lerp(7.2, 0.10, mastery),
            powerErrorFraction = lerp(0.20, 0.004, mastery),
            aggression = lerp(0.38, 0.88, mastery),
            safetyBias = lerp(0.24, 0.70, mastery),
            spinConfidence = lerp(0.08, 0.98, mastery),
            planningSamples = (16 + mastery * 560).toInt()
        )
    }

    /** Learning is an additive counter layer only; it does not alter the base difficulty model. */
    fun counterStrategy(profile: PlayerLearningProfile): CounterStrategy {
        if (profile.samples < 3) return CounterStrategy()
        return CounterStrategy(
            safetyCounter = ((profile.aggression - 0.5) * 0.90).coerceIn(-0.35, 0.35),
            pressureCounter = ((profile.safety - 0.5) * 0.55).coerceIn(-0.24, 0.24),
            spinCounter = ((profile.spinUsage - 0.35) * 0.30).coerceIn(-0.15, 0.15),
            bankCounter = ((profile.bankUsage - 0.25) * 0.28).coerceIn(-0.14, 0.14)
        )
    }

    fun minimaxDepthForLevel(level: Int): Int = when (level.coerceIn(1, 999)) {
        in 1..149 -> 1
        in 150..449 -> 2
        in 450..799 -> 3
        else -> 4
    }

    fun chooseShot(
        state: PoolGameState,
        level: Int,
        profile: PlayerLearningProfile,
        random: Random = Random.Default
    ): PlannedShot {
        val params = difficultyFor(level)
        val cue = state.ball(0)?.takeUnless { it.pocketed }
            ?: return PlannedShot(Vec2(1.0, 0.0), 0.4)

        if (state.isBreakShot) {
            val apex = state.balls.filter { !it.pocketed && it.number != 0 }.minByOrNull { it.position.x }
                ?: return PlannedShot(Vec2(1.0, 0.0), 0.82)
            var direction = (apex.position - cue.position).normalized()
            val errorRad = Math.toRadians(params.aimErrorDegrees * 0.34 * random.nextDouble(-1.0, 1.0))
            direction = rotate(direction, errorRad)
            val mastery = (level.coerceIn(1, 999) - 1) / 998.0
            return PlannedShot(direction, power = lerp(0.80, 0.98, mastery))
        }

        val depth = minimaxDepthForLevel(level)
        val branchLimit = (4 + params.planningSamples / 70).coerceIn(4, 12)
        val counter = counterStrategy(profile)
        val search = minimaxRoot(state, depth, branchLimit, counter)
        val chosen = search ?: fallbackContact(state, params)

        var direction = chosen.shot.direction
        val errorRad = Math.toRadians(params.aimErrorDegrees * random.nextDouble(-1.0, 1.0))
        direction = rotate(direction, errorRad)
        val noisyPower = (chosen.shot.power * (1.0 + params.powerErrorFraction * random.nextDouble(-1.0, 1.0)))
            .coerceIn(0.18, 1.0)
        val spin = if (params.spinConfidence >= 0.50 && !chosen.shot.safetyIntent) {
            val base = chosen.shot.spin
            Vec2(
                (base.x + random.nextDouble(-0.10, 0.10) * params.spinConfidence).coerceIn(-0.55, 0.55),
                (base.y + random.nextDouble(-0.12, 0.14) * params.spinConfidence).coerceIn(-0.60, 0.65)
            )
        } else chosen.shot.spin

        return chosen.shot.copy(direction = direction, power = noisyPower, spin = spin)
    }

    fun chooseCueBallPlacement(
        state: PoolGameState,
        level: Int,
        profile: PlayerLearningProfile
    ): Vec2 {
        if (!state.ballInHand) return state.ball(0)?.position ?: Vec2(-0.92, 0.0)
        val xMin = -PoolGameState.TABLE_HALF_LENGTH + PoolGameState.BALL_RADIUS * 1.4
        val xMax = when (state.cueBallPlacementRule) {
            CueBallPlacementRule.BEHIND_HEAD_STRING -> PoolGameState.HEAD_STRING_X
            else -> PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS * 1.4
        }
        val yMax = PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS * 1.4
        val counter = counterStrategy(profile)
        val branch = (5 + difficultyFor(level).planningSamples / 100).coerceIn(5, 10)
        var best = state.ball(0)?.position ?: Vec2(-0.92, 0.0)
        var bestScore = Double.NEGATIVE_INFINITY

        for (xi in 0..7) for (yi in 0..8) {
            val x = xMin + (xMax - xMin) * xi / 7.0
            val y = -yMax + (2.0 * yMax) * yi / 8.0
            val p = Vec2(x, y)
            if (!PoolRules.isLegalCueBallPlacement(state, p)) continue
            val placed = moveCue(state, p).copy(ballInHand = false, cueBallPlacementRule = CueBallPlacementRule.NONE)
            val top = generateCandidates(placed, PlayerSeat.AI, branch).maxOfOrNull { candidateImmediateScore(it, PlayerSeat.AI, counter) }
                ?: -100.0
            if (top > bestScore) {
                bestScore = top
                best = p
            }
        }
        return best
    }

    fun chooseBreakChoice(
        state: PoolGameState,
        decision: BreakDecision,
        level: Int,
        profile: PlayerLearningProfile
    ): BreakChoice {
        val counter = counterStrategy(profile)
        val params = difficultyFor(level)
        val depth = minimaxDepthForLevel(level).coerceAtMost(3)
        val branchLimit = (4 + params.planningSamples / 100).coerceIn(4, 9)
        return decision.options.maxByOrNull { choice ->
            val resolved = PoolRules.resolveBreakDecision(state, decision, choice)
            val tactical = when {
                resolved.isBreakShot -> if (resolved.turn == PlayerSeat.AI) 1.15 else -1.15
                resolved.ballInHand -> if (resolved.turn == PlayerSeat.AI) 1.0 else -1.0
                else -> minimax(
                    resolved,
                    depth,
                    Double.NEGATIVE_INFINITY,
                    Double.POSITIVE_INFINITY,
                    branchLimit,
                    counter
                )
            }
            evaluateState(resolved, counter) + tactical
        } ?: decision.options.first()
    }

    private data class Candidate(
        val shot: PlannedShot,
        val targetNumber: Int,
        val pocketIndex: Int?,
        val baseScore: Double,
        val potLikelihood: Double,
        val travelDistance: Double
    )

    private data class RootChoice(val shot: PlannedShot, val score: Double)

    private fun minimaxRoot(
        state: PoolGameState,
        depth: Int,
        branchLimit: Int,
        counter: CounterStrategy
    ): RootChoice? {
        val candidates = generateCandidates(state, PlayerSeat.AI, branchLimit)
        if (candidates.isEmpty()) return null
        var alpha = Double.NEGATIVE_INFINITY
        val beta = Double.POSITIVE_INFINITY
        var best: RootChoice? = null
        for (candidate in candidates) {
            val child = approximateApply(state, PlayerSeat.AI, candidate)
            val immediate = candidateImmediateScore(candidate, PlayerSeat.AI, counter)
            val score = immediate + minimax(child, depth - 1, alpha, beta, branchLimit, counter)
            if (best == null || score > best.score) best = RootChoice(candidate.shot, score)
            alpha = maxOf(alpha, score)
        }
        return best
    }

    private fun minimax(
        state: PoolGameState,
        depth: Int,
        alphaStart: Double,
        betaStart: Double,
        branchLimit: Int,
        counter: CounterStrategy
    ): Double {
        if (depth <= 0 || state.gameOver) return evaluateState(state, counter)
        val actor = state.turn
        val candidates = generateCandidates(state, actor, branchLimit)
        if (candidates.isEmpty()) return evaluateState(state, counter)
        var alpha = alphaStart
        var beta = betaStart
        if (actor == PlayerSeat.AI) {
            var value = Double.NEGATIVE_INFINITY
            for (candidate in candidates) {
                val child = approximateApply(state, actor, candidate)
                value = maxOf(value, candidateImmediateScore(candidate, actor, counter) + minimax(child, depth - 1, alpha, beta, branchLimit, counter))
                alpha = maxOf(alpha, value)
                if (alpha >= beta) break
            }
            return value
        } else {
            var value = Double.POSITIVE_INFINITY
            for (candidate in candidates) {
                val child = approximateApply(state, actor, candidate)
                val humanImmediate = candidateImmediateScore(candidate, actor, CounterStrategy())
                value = minOf(value, -humanImmediate + minimax(child, depth - 1, alpha, beta, branchLimit, counter))
                beta = minOf(beta, value)
                if (alpha >= beta) break
            }
            return value
        }
    }

    private fun generateCandidates(state: PoolGameState, actor: PlayerSeat, branchLimit: Int): List<Candidate> {
        val cue = state.ball(0)?.takeUnless { it.pocketed } ?: return emptyList()
        val targets = legalTargets(state, actor)
        val pockets = pocketCenters()
        val candidates = ArrayList<Candidate>(targets.size * 6 + 1)

        for (target in targets) for (pocketIndex in pockets.indices) {
            val pocket = pockets[pocketIndex]
            val targetToPocket = (pocket - target.position).normalized()
            val ghost = target.position - targetToPocket * (PoolGameState.BALL_RADIUS * 2.03)
            if (!insidePlayableArea(ghost)) continue
            if (!pathClear(cue.position, ghost, state.balls, setOf(0, target.number), PoolGameState.BALL_RADIUS * 2.08)) continue
            if (!pathClear(target.position, pocket, state.balls, setOf(target.number), PoolGameState.BALL_RADIUS * 1.92)) continue

            val cueDirection = (ghost - cue.position).normalized()
            val objectDirection = (pocket - target.position).normalized()
            val cutDot = cueDirection.dot(objectDirection).coerceIn(-1.0, 1.0)
            val angleQuality = ((cutDot + 1.0) * 0.5).coerceIn(0.0, 1.0)
            val cueDistance = (ghost - cue.position).length()
            val objectDistance = (pocket - target.position).length()
            val travel = cueDistance + objectDistance
            val pocketBonus = if (pocketIndex == 1 || pocketIndex == 4) 0.07 else 0.0
            val base = angleQuality * 3.4 - cueDistance * 0.43 - objectDistance * 0.31 + pocketBonus
            val likelihood = (0.18 + angleQuality * 0.72 - travel * 0.075).coerceIn(0.05, 0.97)
            val power = (0.28 + travel / 4.7).coerceIn(0.25, 0.94)
            val spin = if (objectDistance > 1.0) Vec2(0.0, 0.15) else Vec2.ZERO
            candidates += Candidate(
                shot = PlannedShot(cueDirection, power, spin, calledBall = target.number, calledPocket = pocketIndex),
                targetNumber = target.number,
                pocketIndex = pocketIndex,
                baseScore = base,
                potLikelihood = likelihood,
                travelDistance = travel
            )
        }

        val nearest = targets.minByOrNull { (it.position - cue.position).length() }
        if (nearest != null) {
            val dir = (nearest.position - cue.position).normalized()
            candidates += Candidate(
                shot = PlannedShot(dir, 0.30, Vec2(0.0, -0.18), calledBall = nearest.number, calledPocket = null, safetyIntent = true),
                targetNumber = nearest.number,
                pocketIndex = null,
                baseScore = 0.28,
                potLikelihood = 0.0,
                travelDistance = (nearest.position - cue.position).length()
            )
        }
        return candidates.sortedByDescending { it.baseScore }.take(branchLimit)
    }

    private fun legalTargets(state: PoolGameState, actor: PlayerSeat): List<PoolBall> = state.balls.filter { ball ->
        !ball.pocketed && ball.number != 0 && PoolRules.isLegalCalledBall(state, actor, ball.number)
    }

    private fun candidateImmediateScore(candidate: Candidate, actor: PlayerSeat, counter: CounterStrategy): Double {
        val potValue = candidate.baseScore + candidate.potLikelihood * 2.3
        if (actor != PlayerSeat.AI) return potValue
        val counterBonus = if (candidate.shot.safetyIntent) {
            counter.safetyCounter + counter.bankCounter * 0.30
        } else {
            counter.pressureCounter + counter.spinCounter * abs(candidate.shot.spin.y)
        }
        return potValue + counterBonus
    }

    private fun approximateApply(state: PoolGameState, actor: PlayerSeat, candidate: Candidate): PoolGameState {
        val opponent = actor.other()
        if (candidate.shot.safetyIntent || candidate.potLikelihood < 0.52) {
            return state.copy(turn = opponent, calledBall = null, calledPocket = null, safetyCalled = false)
        }
        val target = state.ball(candidate.targetNumber) ?: return state.copy(turn = opponent)
        val balls = state.balls.map { if (it.number == target.number) it.copy(pocketed = true) else it }
        val group = state.groupFor(actor)
        if (target.number == 8) {
            return state.copy(balls = balls, gameOver = true, winner = actor, turn = actor)
        }
        var humanGroup = state.humanGroup
        var aiGroup = state.aiGroup
        if (group == BallGroup.OPEN && (target.group == BallGroup.SOLIDS || target.group == BallGroup.STRIPES)) {
            if (actor == PlayerSeat.AI) {
                aiGroup = target.group
                humanGroup = opposite(target.group)
            } else {
                humanGroup = target.group
                aiGroup = opposite(target.group)
            }
        }
        return state.copy(balls = balls, turn = actor, humanGroup = humanGroup, aiGroup = aiGroup)
    }

    private fun evaluateState(state: PoolGameState, counter: CounterStrategy): Double {
        if (state.gameOver) return when (state.winner) {
            PlayerSeat.AI -> 10000.0
            PlayerSeat.HUMAN -> -10000.0
            else -> 0.0
        }
        val aiGroup = state.aiGroup
        val humanGroup = state.humanGroup
        val aiRemaining = if (aiGroup == BallGroup.OPEN) 7 else state.remaining(aiGroup)
        val humanRemaining = if (humanGroup == BallGroup.OPEN) 7 else state.remaining(humanGroup)
        var score = (humanRemaining - aiRemaining) * 3.2
        score += if (state.turn == PlayerSeat.AI) 0.45 else -0.45
        if (state.ballInHand) score += if (state.turn == PlayerSeat.AI) 1.2 else -1.2
        score += counter.safetyCounter * 0.18 + counter.pressureCounter * 0.12
        return score
    }

    private fun fallbackContact(state: PoolGameState, params: AiParameters): RootChoice {
        val cue = state.ball(0)?.takeUnless { it.pocketed }
        val targets = legalTargets(state, PlayerSeat.AI)
        val target = cue?.let { c -> targets.minByOrNull { (it.position - c.position).length() } }
        val direction = if (cue != null && target != null) (target.position - cue.position).normalized() else Vec2(1.0, 0.0)
        return RootChoice(
            PlannedShot(direction, (0.25 + params.aggression * 0.18).coerceIn(0.22, 0.48), safetyIntent = true),
            -1.0
        )
    }

    private fun moveCue(state: PoolGameState, position: Vec2): PoolGameState = state.copy(
        balls = state.balls.map { ball ->
            if (ball.number == 0) ball.copy(position = position, pocketed = false, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO) else ball
        }
    )

    private fun insidePlayableArea(point: Vec2): Boolean =
        abs(point.x) < PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS &&
            abs(point.y) < PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS

    private fun pathClear(start: Vec2, end: Vec2, balls: List<PoolBall>, ignored: Set<Int>, clearance: Double): Boolean {
        val segment = end - start
        val lengthSquared = segment.dot(segment)
        if (lengthSquared <= 1e-10) return false
        return balls.asSequence().filter { !it.pocketed && it.number !in ignored }.all { ball ->
            val t = ((ball.position - start).dot(segment) / lengthSquared).coerceIn(0.0, 1.0)
            val closest = start + segment * t
            (ball.position - closest).length() >= clearance
        }
    }

    fun profileSummary(profile: PlayerLearningProfile): List<String> {
        if (profile.samples < 3) return listOf("AI sedang mengumpul data gaya pukulan kamu untuk lapisan counter")
        val result = mutableListOf<String>()
        if (profile.aggression >= 0.66) result += "Counter aktif: AI lebih menghargai safety terhadap serangan kuasa tinggi kamu"
        if (profile.safety >= 0.58) result += "Counter aktif: AI meningkatkan tekanan apabila kamu cenderung bermain safety"
        if (profile.spinUsage >= 0.42) result += "AI mengesan penggunaan spin kamu untuk merancang posisi balas"
        if (profile.bankUsage >= 0.30) result += "AI mengesan kecenderungan bank shot sebagai maklumat counter"
        if (profile.potSuccess >= 0.65) result += "AI menganggap ketepatan pot kamu sebagai ancaman dalam evaluasi minimax"
        return result.take(3).ifEmpty { listOf("Counter profile seimbang; core minimax kekal ditentukan oleh level") }
    }

    private fun pocketCenters() = listOf(
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH)
    )

    private fun rotate(v: Vec2, radians: Double): Vec2 {
        val c = cos(radians); val s = sin(radians)
        return Vec2(v.x * c - v.y * s, v.x * s + v.y * c).normalized()
    }

    private fun PlayerSeat.other() = if (this == PlayerSeat.HUMAN) PlayerSeat.AI else PlayerSeat.HUMAN
    private fun opposite(group: BallGroup) = when (group) {
        BallGroup.SOLIDS -> BallGroup.STRIPES
        BallGroup.STRIPES -> BallGroup.SOLIDS
        BallGroup.OPEN -> BallGroup.OPEN
    }
    private fun ema(current: Double, sample: Double, alpha: Double) = current + (sample - current) * alpha
    private fun lerp(a: Double, b: Double, t: Double) = a + (b - a) * t
}
