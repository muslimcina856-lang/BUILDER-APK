package com.adaptez.pool.domain

import com.adaptez.pool.domain.model.CueBallPlacementRule
import com.adaptez.pool.domain.model.PlayerSeat
import com.adaptez.pool.domain.model.PoolGameState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MatchStartPolicyTest {
    @Test
    fun `new match always starts with human break and draggable cue ball behind head string`() {
        val game = PoolGameState.playerBreakRack()

        assertEquals(PlayerSeat.HUMAN, game.turn)
        assertTrue(game.isBreakShot)
        assertTrue(game.ballInHand)
        assertEquals(CueBallPlacementRule.BEHIND_HEAD_STRING, game.cueBallPlacementRule)
        assertEquals(0, game.shotNumber)
        assertFalse(game.gameOver)
    }
}
