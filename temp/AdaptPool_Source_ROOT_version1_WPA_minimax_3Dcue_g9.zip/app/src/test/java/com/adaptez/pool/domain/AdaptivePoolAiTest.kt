package com.adaptez.pool.domain

import com.adaptez.pool.domain.ai.AdaptivePoolAi
import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class AdaptivePoolAiTest {
    @Test fun `difficulty scales from level 1 to 999`() {
        val beginner = AdaptivePoolAi.parametersFor(1)
        val master = AdaptivePoolAi.parametersFor(999)
        assertTrue(master.aimErrorDegrees < beginner.aimErrorDegrees)
        assertTrue(master.powerErrorFraction < beginner.powerErrorFraction)
        assertTrue(master.planningSamples > beginner.planningSamples)
        assertTrue(AdaptivePoolAi.minimaxDepthForLevel(999) > AdaptivePoolAi.minimaxDepthForLevel(1))
    }

    @Test fun `learning never changes core difficulty at same level`() {
        val aggressive = PlayerLearningProfile(aggression = 0.95, safety = 0.10, samples = 50)
        val defensive = PlayerLearningProfile(aggression = 0.10, safety = 0.95, samples = 50)
        assertEquals(AdaptivePoolAi.parametersFor(600, aggressive), AdaptivePoolAi.parametersFor(600, defensive))
        assertNotEquals(AdaptivePoolAi.counterStrategy(aggressive), AdaptivePoolAi.counterStrategy(defensive))
    }

    @Test fun `learning profile tracks aggressive high power player only as counter data`() {
        var profile = PlayerLearningProfile()
        repeat(12) {
            profile = AdaptivePoolAi.learn(
                profile,
                ShotObservation(power = 0.92, spinMagnitude = 0.35, usedBank = false, safetyIntent = false, pottedBall = true)
            )
        }
        assertTrue(profile.aggression > 0.70)
        assertTrue(profile.averagePower > 0.70)
        assertTrue(profile.samples >= 12)
    }

    @Test fun `ai ball in hand placement is legal`() {
        val state = PoolGameState.standardRack().copy(
            turn = PlayerSeat.AI,
            isBreakShot = false,
            ballInHand = true,
            cueBallPlacementRule = CueBallPlacementRule.ANYWHERE,
            humanGroup = BallGroup.SOLIDS,
            aiGroup = BallGroup.STRIPES
        )
        val placement = AdaptivePoolAi.chooseCueBallPlacement(state, 800, PlayerLearningProfile(samples = 20))
        assertTrue(PoolRules.isLegalCueBallPlacement(state, placement))
    }
}
