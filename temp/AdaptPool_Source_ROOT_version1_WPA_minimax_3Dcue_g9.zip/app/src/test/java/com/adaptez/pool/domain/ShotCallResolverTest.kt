package com.adaptez.pool.domain

import com.adaptez.pool.domain.engine.ShotCallResolver
import com.adaptez.pool.domain.model.PoolGameState
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShotCallResolverTest {
    @Test fun `break never requires a call`() {
        val call = ShotCallResolver.resolve(PoolGameState.playerBreakRack(), 0.0)
        assertNull(call.ball)
        assertNull(call.pocket)
    }

    @Test fun `normal obvious aim resolves a legal object ball`() {
        val state = PoolGameState.standardRack().copy(isBreakShot = false)
        val call = ShotCallResolver.resolve(state, 0.0)
        assertTrue(call.ball == null || call.ball in 1..15)
    }
}
