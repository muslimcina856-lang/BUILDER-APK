package com.adaptez.pool.domain

import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class PoolRulesTest {
    private fun state(
        turn: PlayerSeat = PlayerSeat.HUMAN,
        humanGroup: BallGroup = BallGroup.OPEN,
        aiGroup: BallGroup = BallGroup.OPEN,
        pocketed: Set<Int> = emptySet(),
        breakShot: Boolean = false
    ): PoolGameState = PoolGameState.standardRack().copy(
        turn = turn,
        humanGroup = humanGroup,
        aiGroup = aiGroup,
        balls = PoolGameState.standardRack().balls.map { it.copy(pocketed = it.number in pocketed) },
        isBreakShot = breakShot
    )

    @Test fun `called open-table pot assigns solids`() {
        val outcome = PoolRules.evaluateShot(
            state(),
            ShotResult(
                firstContact = 1,
                pocketedBalls = listOf(PocketedBall(1, 0)),
                railAfterContact = true,
                calledBall = 1,
                calledPocket = 0
            )
        )
        assertFalse(outcome.foul)
        assertEquals(BallGroup.SOLIDS, outcome.state.humanGroup)
        assertEquals(BallGroup.STRIPES, outcome.state.aiGroup)
        assertEquals(PlayerSeat.HUMAN, outcome.state.turn)
    }

    @Test fun `wrongly pocketed ball stays down but does not assign group`() {
        val outcome = PoolRules.evaluateShot(
            state(),
            ShotResult(
                firstContact = 1,
                pocketedBalls = listOf(PocketedBall(2, 0)),
                railAfterContact = true,
                calledBall = 1,
                calledPocket = 0
            )
        )
        assertFalse(outcome.foul)
        assertEquals(BallGroup.OPEN, outcome.state.humanGroup)
        assertTrue(outcome.state.ball(2)!!.pocketed)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
    }

    @Test fun `called safety passes turn even when own ball is pocketed`() {
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES),
            ShotResult(
                firstContact = 1,
                pocketedBalls = listOf(PocketedBall(1, 0)),
                railAfterContact = true,
                calledBall = 1,
                safetyCalled = true
            )
        )
        assertFalse(outcome.foul)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
        assertTrue(outcome.state.ball(1)!!.pocketed)
    }

    @Test fun `wrong first contact is foul after groups assigned`() {
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES),
            ShotResult(firstContact = 10, railAfterContact = true, calledBall = 1, calledPocket = 0)
        )
        assertTrue(outcome.foul)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
        assertTrue(outcome.state.ballInHand)
        assertEquals(CueBallPlacementRule.ANYWHERE, outcome.state.cueBallPlacementRule)
    }

    @Test fun `eight ball after clearing group and correct call wins`() {
        val solidsPocketed = (1..7).toSet()
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES, pocketed = solidsPocketed),
            ShotResult(firstContact = 8, pocketedBalls = listOf(PocketedBall(8, 3)), railAfterContact = true, calledBall = 8, calledPocket = 3)
        )
        assertFalse(outcome.foul)
        assertTrue(outcome.state.gameOver)
        assertEquals(PlayerSeat.HUMAN, outcome.state.winner)
    }

    @Test fun `eight ball on open table is legal when one temporary group is fully cleared`() {
        val outcome = PoolRules.evaluateShot(
            state(pocketed = (1..7).toSet()),
            ShotResult(firstContact = 8, pocketedBalls = listOf(PocketedBall(8, 4)), railAfterContact = true, calledBall = 8, calledPocket = 4)
        )
        assertFalse(outcome.foul)
        assertEquals(PlayerSeat.HUMAN, outcome.state.winner)
    }

    @Test fun `illegal dry break exposes all official incoming choices`() {
        val outcome = PoolRules.evaluateShot(
            state(breakShot = true),
            ShotResult(firstContact = 1, railAfterContact = false, objectBallsToRail = 2)
        )
        assertNotNull(outcome.breakDecision)
        assertTrue(BreakChoice.ACCEPT_TABLE in outcome.breakDecision!!.options)
        assertTrue(BreakChoice.RERACK_AND_BREAK_SELF in outcome.breakDecision!!.options)
        assertTrue(BreakChoice.RERACK_AND_BREAK_OPPONENT in outcome.breakDecision!!.options)
    }

    @Test fun `legal eight on break offers spot or rebreak`() {
        val outcome = PoolRules.evaluateShot(
            state(breakShot = true),
            ShotResult(firstContact = 1, pocketedBalls = listOf(PocketedBall(8, 2)), objectBallsToRail = 4)
        )
        assertNotNull(outcome.breakDecision)
        assertEquals(PlayerSeat.HUMAN, outcome.breakDecision!!.chooser)
        assertTrue(BreakChoice.SPOT_EIGHT_AND_CONTINUE in outcome.breakDecision!!.options)
        assertTrue(BreakChoice.REBREAK in outcome.breakDecision!!.options)
    }

    @Test fun `eight ball driven off table on break is spotted and incoming chooses table or head-string ball in hand`() {
        val outcome = PoolRules.evaluateShot(
            state(breakShot = true),
            ShotResult(firstContact = 1, objectBallsDrivenOffTable = setOf(8), objectBallsToRail = 4)
        )
        assertNotNull(outcome.breakDecision)
        assertTrue(BreakChoice.SPOT_EIGHT_AND_ACCEPT_TABLE in outcome.breakDecision!!.options)
        assertTrue(BreakChoice.SPOT_EIGHT_AND_CUE_BALL_HEAD_STRING in outcome.breakDecision!!.options)
        assertFalse(BreakChoice.REBREAK in outcome.breakDecision!!.options)
    }

    @Test fun `called opponent group ball never earns continuation`() {
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES),
            ShotResult(
                firstContact = 1,
                pocketedBalls = listOf(PocketedBall(9, 0)),
                railAfterContact = true,
                calledBall = 9,
                calledPocket = 0
            )
        )
        assertFalse(outcome.foul)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
    }

    @Test fun `head-string ball in hand cannot directly contact legal ball also behind head string`() {
        val base = state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES)
        val balls = base.balls.map { ball ->
            if (ball.number == 1) ball.copy(position = Vec2(-1.05, 0.0)) else ball
        }
        val restricted = base.copy(
            balls = balls,
            ballInHand = false,
            cueBallPlacementRule = CueBallPlacementRule.BEHIND_HEAD_STRING
        )
        val outcome = PoolRules.evaluateShot(
            restricted,
            ShotResult(
                firstContact = 1,
                railAfterContact = true,
                calledBall = 1,
                calledPocket = 0,
                cueCrossedHeadStringBeforeFirstContact = false
            )
        )
        assertTrue(outcome.foul)
        assertEquals(CueBallPlacementRule.ANYWHERE, outcome.state.cueBallPlacementRule)
    }

}
