# Adapt Pool

Adapt Pool ialah permainan 8-Ball 3D Android luar talian dengan lawan AI adaptif yang mempelajari gaya pemain dari setiap pukulan.

## Identiti projek

- Nama aplikasi: `Adapt Pool`
- Package / applicationId: `com.adaptez.pool`
- Level AI: `1–999`
- UI luar perlawanan: mengikuti struktur ringkas Adapt Chess — `Main`, `Sejarah`, `Prestasi`
- Gameplay: OpenGL ES 2.0, fizik fixed-step 120 Hz, audio PCM low-latency
- Penyimpanan: Room, sepenuhnya lokal

## Apa yang sudah dibina

### Gameplay 3D
- Meja pool 3D OpenGL dengan depth, diffuse/specular lighting, rail, pocket, cue, bayang dan bola glossy.
- Solids dan stripes dibezakan secara visual.
- Kamera boleh di-orbit dengan drag.
- Aim guideline 3D, power control, spin/English, follow/draw dan ball-in-hand positioning.
- Fizik fixed-step 120 Hz: friction, cushion rebound, ball-ball collision, pocket detection dan spin response asas.
- Procedural pool sound yang dipra-muat ke `AudioTrack.MODE_STATIC` untuk cue strike, collision dan pocket.

### Peraturan 8-Ball
- Legal break.
- Open table dan assignment solids/stripes.
- First-contact legality.
- Rail-after-contact / pot requirement.
- Scratch dan ball-in-hand.
- 8-ball early loss.
- Called pocket untuk 8-ball.
- 8-ball pada break di-respot.

### AI adaptif
AI tidak mengubah fizik dan tidak membaca input tersembunyi. Ia mengubah keputusan berdasarkan profil pemain:
- aggression,
- safety tendency,
- average power,
- spin usage,
- bank-shot usage,
- pot success.

Kesukaran meningkat secara berterusan dari Level 1 hingga 999 dengan:
- aim error semakin kecil,
- power error semakin kecil,
- lebih banyak planning samples,
- safety/aggression bias yang bertindak balas kepada gaya pemain.

### Sejarah & prestasi
- Keputusan perlawanan.
- Level AI.
- Jumlah pukulan.
- Bola dipot.
- Ketepatan pukulan.
- Tempoh perlawanan.
- Learning summary AI.
- Win rate, streak, masa bermain dan profil adaptif.

## Build

Keperluan:
- Android Studio / Android SDK 36
- JDK 17
- Gradle wrapper 8.6

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Debug APK akan berada di:

`app/build/outputs/apk/debug/app-debug.apk`

## Struktur utama

- `domain/model/PoolModels.kt` — state dan model game
- `domain/engine/PoolPhysics.kt` — fizik
- `domain/engine/PoolRules.kt` — rules engine
- `domain/ai/AdaptivePoolAi.kt` — profil pembelajaran dan pemilihan shot AI
- `presentation/pool/PoolOpenGLRenderer.kt` — renderer 3D
- `presentation/pool/PoolViewModel.kt` — orchestration match, AI, persistence
- `presentation/history/HistoryScreen.kt` — sejarah
- `presentation/stats/StatsScreen.kt` — prestasi dan AI insights
