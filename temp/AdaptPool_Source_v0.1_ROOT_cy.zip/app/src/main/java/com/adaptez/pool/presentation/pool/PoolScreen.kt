package com.adaptez.pool.presentation.pool

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Rule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adaptez.pool.domain.model.BallGroup
import com.adaptez.pool.domain.model.PoolGameState
import com.adaptez.pool.domain.model.PlayerSeat

private val AppBackground = Color(0xFF0D0F12)
private val Panel = Color(0xFF171A1F)
private val PanelSoft = Color(0xFF1E2228)
private val Ivory = Color(0xFFF3EEE4)
private val Muted = Color(0xFFA6A39C)
private val Gold = Color(0xFFD8B477)
private val Mint = Color(0xFF76C8A5)
private val Danger = Color(0xFFE07171)

@Composable
fun PoolScreen(modifier: Modifier = Modifier, viewModel: PoolViewModel) {
    val state by viewModel.uiState.collectAsState()
    var showRules by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val sound = remember(context) { PoolSoundManager(context) }
    DisposableEffect(sound) { onDispose { sound.release() } }
    LaunchedEffect(state.cuePulse) { if (state.cuePulse > 0) sound.playCue() }
    LaunchedEffect(state.collisionPulse) { if (state.collisionPulse > 0) sound.playCollision() }
    LaunchedEffect(state.pocketPulse) { if (state.pocketPulse > 0) sound.playPocket() }

    if (state.phase == MatchPhase.SETUP) {
        BreakChoiceDialog(state.currentLevel, onHumanBreak = { viewModel.startMatch(true) }, onAiBreak = { viewModel.startMatch(false) })
    }
    if (showRules) RulesDialog { showRules = false }

    val previewGame = state.game ?: PoolGameState.standardRack()
    Column(
        modifier = modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF11151A), AppBackground, Color(0xFF0A0C0F)))
        )
    ) {
        TopBar(state, onRules = { showRules = true })

        BoxWithConstraints(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Pool3DView(
                game = previewGame,
                aimDegrees = state.aimDegrees,
                showAim = state.canShoot,
                modifier = Modifier.fillMaxSize()
            )
        }

        ControlPanel(state, viewModel)
    }
}

@Composable
private fun TopBar(state: PoolUiState, onRules: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("ADAPT POOL", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            Text("AI membina strategi daripada permainanmu", color = Muted, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(
                color = Gold.copy(alpha = 0.14f), shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.38f))
            ) {
                Text(
                    "LEVEL ${state.currentLevel} / 999",
                    Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    color = Gold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold
                )
            }
            IconButton(onClick = onRules, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Rounded.Rule, "Peraturan", tint = Muted)
            }
        }
    }
}

@Composable
private fun ControlPanel(state: PoolUiState, viewModel: PoolViewModel) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        color = Panel, shape = RoundedCornerShape(20.dp), tonalElevation = 1.dp
    ) {
        when (state.phase) {
            MatchPhase.SETUP -> SetupStatus()
            MatchPhase.RESULT -> ResultCard(state, viewModel::nextOrRetry, viewModel::returnToSetup)
            else -> PlayingControls(state, viewModel)
        }
    }
}

@Composable
private fun SetupStatus() {
    Column(
        Modifier.fillMaxWidth().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("8-Ball Standard", color = Ivory, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("Pilih siapa melakukan break untuk mula.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun PlayingControls(state: PoolUiState, viewModel: PoolViewModel) {
    val game = state.game ?: return
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(statusColor(state)))
                Spacer(Modifier.width(7.dp))
                Text(statusText(state), color = if (state.phase == MatchPhase.AI_THINKING) Mint else Ivory, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Text("${groupLabel(game.humanGroup)} • ${state.totalShots} pukulan", color = Muted, fontSize = 10.sp)
        }

        if (state.canShoot) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AIM", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(42.dp))
                TextButton(onClick = { viewModel.nudgeAim(-1.0) }, contentPadding = PaddingValues(4.dp)) { Text("−1°") }
                Slider(
                    value = state.aimDegrees.toFloat(),
                    onValueChange = { viewModel.setAimDegrees(it.toDouble()) },
                    valueRange = -180f..180f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = PanelSoft)
                )
                TextButton(onClick = { viewModel.nudgeAim(1.0) }, contentPadding = PaddingValues(4.dp)) { Text("+1°") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("POWER", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(42.dp))
                Slider(
                    value = state.power.toFloat(), onValueChange = { viewModel.setPower(it.toDouble()) },
                    valueRange = 0.08f..1f, modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Mint, activeTrackColor = Mint, inactiveTrackColor = PanelSoft)
                )
                Text("${(state.power * 100).toInt()}%", color = Muted, fontSize = 10.sp, modifier = Modifier.width(38.dp), textAlign = TextAlign.End)
            }

            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("SPIN / ENGLISH", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    SmallSpinButton("L", state.spinX < -0.2, Modifier.weight(1f)) { viewModel.setSpin(-0.58, state.spinY) }
                    SmallSpinButton("Draw", state.spinY < -0.2, Modifier.weight(1f)) { viewModel.setSpin(state.spinX, -0.62) }
                    SmallSpinButton("Center", kotlin.math.abs(state.spinX) < 0.1 && kotlin.math.abs(state.spinY) < 0.1, Modifier.weight(1.25f)) { viewModel.setSpin(0.0, 0.0) }
                    SmallSpinButton("Follow", state.spinY > 0.2, Modifier.weight(1f)) { viewModel.setSpin(state.spinX, 0.62) }
                    SmallSpinButton("R", state.spinX > 0.2, Modifier.weight(1f)) { viewModel.setSpin(0.58, state.spinY) }
                }
            }

            if (game.ballInHand) {
                val cue = game.ball(0)
                if (cue != null) {
                    Surface(color = Gold.copy(alpha = 0.08f), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("BALL-IN-HAND • letak cue ball", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Panjang", color = Muted, fontSize = 9.sp, modifier = Modifier.width(50.dp))
                                Slider(
                                    value = cue.position.x.toFloat(),
                                    onValueChange = { viewModel.setCueBallPosition(x = it.toDouble()) },
                                    valueRange = -1.34f..1.34f,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Lebar", color = Muted, fontSize = 9.sp, modifier = Modifier.width(50.dp))
                                Slider(
                                    value = cue.position.y.toFloat(),
                                    onValueChange = { viewModel.setCueBallPosition(y = it.toDouble()) },
                                    valueRange = -0.63f..0.63f,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            val onEight = game.humanGroup != BallGroup.OPEN && game.remaining(game.humanGroup) == 0
            if (onEight) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("CALL 8", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    (0..5).forEach { p ->
                        FilterChip(
                            selected = state.selectedPocket == p,
                            onClick = { viewModel.selectPocket(p) },
                            label = { Text("${p + 1}", fontSize = 9.sp) },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }

            Button(
                onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); viewModel.shoot() },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF17130D)),
                shape = RoundedCornerShape(13.dp)
            ) { Text("PUKUL", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp) }
        } else {
            Text(state.statusMessage, color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            if (state.phase == MatchPhase.AI_THINKING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Mint, trackColor = PanelSoft)
            }
        }

        if (state.learningInsights.isNotEmpty()) {
            Surface(color = PanelSoft, shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("AI INSIGHT", color = Mint, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
                    Text(state.learningInsights.first(), color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ResultCard(state: PoolUiState, onAgain: () -> Unit, onSetup: () -> Unit) {
    val won = state.game?.winner == PlayerSeat.HUMAN
    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (won) "Level Ditakluki" else "AI Menang", color = Ivory, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(state.statusMessage, color = Muted, fontSize = 11.sp)
            }
            Surface(color = (if (won) Mint else Danger).copy(alpha = 0.13f), shape = CircleShape) {
                Text(if (won) "W" else "L", Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = if (won) Mint else Danger, fontWeight = FontWeight.Black)
            }
        }
        if (state.learningInsights.isNotEmpty()) {
            Surface(color = PanelSoft, shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("APA YANG AI PELAJARI", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    state.learningInsights.forEach { Text("• $it", color = Ivory.copy(alpha = 0.86f), fontSize = 10.sp) }
                }
            }
        }
        Button(
            onClick = onAgain, modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF17130D)),
            shape = RoundedCornerShape(13.dp)
        ) { Text(if (won) "Level Seterusnya" else "Cuba Semula", fontWeight = FontWeight.ExtraBold) }
        OutlinedButton(onClick = onSetup, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
            Icon(Icons.Rounded.RestartAlt, null); Spacer(Modifier.width(7.dp)); Text("Tukar Break")
        }
    }
}

@Composable
private fun BreakChoiceDialog(level: Int, onHumanBreak: () -> Unit, onAiBreak: () -> Unit) {
    AlertDialog(
        onDismissRequest = {}, containerColor = Panel, titleContentColor = Ivory, textContentColor = Muted,
        title = { Text("Adapt Pool • Level $level", fontWeight = FontWeight.Bold) },
        text = { Text("8-Ball standard. AI akan belajar kuasa pukulan, spin, bank shot, safety dan kadar pot kamu sepanjang perlawanan.", fontSize = 12.sp, lineHeight = 18.sp) },
        confirmButton = { TextButton(onClick = onHumanBreak) { Text("Saya Pecah", color = Gold, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onAiBreak) { Text("AI Pecah", color = Mint, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
private fun RulesDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Panel, titleContentColor = Ivory, textContentColor = Muted,
        title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Info, null, tint = Gold); Spacer(Modifier.width(8.dp)); Text("Peraturan 8-Ball", fontWeight = FontWeight.Bold) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RuleLine("1", "Break sah jika sekurang-kurangnya satu bola objek dipot atau 4 bola objek menyentuh rail.")
                RuleLine("2", "Selepas break, meja masih terbuka. Solids 1–7 dan stripes 9–15 ditentukan selepas pot sah berikutnya.")
                RuleLine("3", "Selepas kumpulan ditentukan, bola pertama disentuh mesti daripada kumpulan sendiri. Selepas semua habis, sasaran pertama ialah 8-ball.")
                RuleLine("4", "Selepas sentuhan, mesti ada bola masuk poket atau sekurang-kurangnya satu bola menyentuh rail.")
                RuleLine("5", "Cue ball masuk poket, tiada sentuhan sah, atau sentuhan kumpulan salah ialah foul. Lawan mendapat ball-in-hand.")
                RuleLine("6", "Pot bola kumpulan sendiri secara sah mengekalkan giliran. Jika tiada pot sah, giliran bertukar.")
                RuleLine("7", "8-ball hanya boleh dipot selepas semua bola kumpulan sendiri selesai. Pilih poket panggilan sebelum pukulan 8-ball.")
                RuleLine("8", "8-ball terlalu awal, pada foul, atau ke poket yang salah menyebabkan kalah serta-merta.")
                RuleLine("9", "Jika 8-ball masuk ketika break, ia diletakkan semula dan permainan diteruskan.")
                HorizontalDivider(color = Color(0xFF292D33))
                Text("Adapt Pool menggunakan fizik digital: fouls berkaitan kaki, pakaian, cue menyentuh bola secara fizikal, dan timeout kejohanan tidak digunakan.", fontSize = 10.sp, color = Muted.copy(alpha = 0.8f))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Gold, fontWeight = FontWeight.Bold) } }
    )
}

@Composable private fun RuleLine(n: String, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
        Surface(color = Gold.copy(alpha = 0.13f), shape = CircleShape) { Text(n, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
        Text(text, color = Ivory.copy(alpha = 0.88f), fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SmallSpinButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 8.sp, maxLines = 1) },
        modifier = modifier.height(28.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Gold.copy(alpha = 0.18f),
            selectedLabelColor = Gold,
            labelColor = Muted
        )
    )
}

private fun statusColor(state: PoolUiState) = when (state.phase) {
    MatchPhase.READY -> Mint
    MatchPhase.AI_THINKING -> Gold
    MatchPhase.BALLS_MOVING -> Mint
    MatchPhase.RESULT -> if (state.game?.winner == PlayerSeat.HUMAN) Mint else Danger
    MatchPhase.SETUP -> Muted
}

private fun statusText(state: PoolUiState) = when (state.phase) {
    MatchPhase.READY -> if (state.game?.turn == PlayerSeat.HUMAN) "Giliran kamu" else "Giliran AI"
    MatchPhase.AI_THINKING -> "AI sedang berfikir"
    MatchPhase.BALLS_MOVING -> "Bola sedang bergerak"
    MatchPhase.RESULT -> "Perlawanan tamat"
    MatchPhase.SETUP -> "Sedia"
}

private fun groupLabel(group: BallGroup) = when (group) {
    BallGroup.OPEN -> "Meja terbuka"
    BallGroup.SOLIDS -> "Solids 1–7"
    BallGroup.STRIPES -> "Stripes 9–15"
}
