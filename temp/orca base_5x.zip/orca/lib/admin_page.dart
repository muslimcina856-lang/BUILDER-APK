import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> userList = [];

  final deleteController = TextEditingController();

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String selectedRole = 'member';

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://kenzz.xv.jwxhost.site:2004/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        setState(() {
          userList = data['users'] ?? [];
        });
      } else {
        _showDialog("⚠️ Error", data['message'] ?? 'Tidak diizinkan melihat daftar user.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Gagal memuat user list.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _showDialog("⚠️ Error", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://kenzz.xv.jwxhost.site:2004/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showDialog("✅ Berhasil", "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showDialog("⚠️ Error", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          'http://kenzz.xv.jwxhost.site:2004/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$selectedRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showDialog("✅ Sukses", "Akun '${data['user']['username']}' berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        selectedRole = 'member';
        _fetchUsers();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        title: Text(title, style: const TextStyle(color: Colors.blue)), // Diubah ke biru
        content: Text(message, style: const TextStyle(color: Colors.blueAccent)), // Diubah ke biru
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.blue)), // Diubah ke biru
          )
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Card(
      color: Colors.grey[900],
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ListTile(
        title: Text(user['username'], style: const TextStyle(color: Colors.blue)), // Diubah ke biru
        subtitle: Text(
          "Role: ${user['role']} | Exp: ${user['expiredDate']}",
          style: const TextStyle(color: Colors.blueAccent), // Diubah ke biru
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {TextInputType type = TextInputType.text}) {
    return TextField(
      controller: controller,
      keyboardType: type,
      style: const TextStyle(color: Colors.blue), // Diubah ke biru
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.blue), // Diubah ke biru
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.blue), // Diubah ke biru
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.blue, width: 2), // Diubah ke biru dengan width 2
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  Widget _buildActionButton(String label, VoidCallback onPressed, {bool isLoading = false}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          )
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue, // Diubah dari putih ke biru
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          elevation: 5,
        ),
        child: this.isLoading
            ? const CircularProgressIndicator(color: Colors.white)
            : Text(
                label,
                style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                  color: Colors.black, // Text hitam untuk kontras
                  fontWeight: FontWeight.bold,
                ),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "Admin Control",
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: Colors.blue, // Diubah ke biru
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.blue), // Diubah ke biru
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // DELETE USER SECTION
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(left: BorderSide(color: Colors.blue, width: 4)), // Aksen biru
                ),
                child: const Text(
                  "Delete User",
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _buildTextField("Username untuk dihapus", deleteController),
              const SizedBox(height: 10),
              _buildActionButton("DELETE USER", _deleteUser),

              // CREATE ACCOUNT SECTION
              const SizedBox(height: 30),
              Divider(
                color: Colors.blue.withOpacity(0.5), // Diubah ke biru dengan opacity
                thickness: 1,
                height: 30,
              ),
              
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(left: BorderSide(color: Colors.blue, width: 4)), // Aksen biru
                ),
                child: const Text(
                  "Create Account",
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              _buildTextField("Username", createUsernameController),
              const SizedBox(height: 10),

              _buildTextField("Password", createPasswordController),
              const SizedBox(height: 10),

              _buildTextField("Durasi (hari)", createDayController, type: TextInputType.number),
              const SizedBox(height: 10),

              // Dropdown Role
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blue), // Border biru
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButtonFormField<String>(
                  dropdownColor: Colors.black,
                  value: selectedRole,
                  decoration: const InputDecoration(
                    labelText: "Role",
                    labelStyle: TextStyle(color: Colors.blue),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 12),
                  ),
                  style: const TextStyle(color: Colors.blue),
                  icon: const Icon(Icons.arrow_drop_down, color: Colors.blue),
                  items: ['member', 'reseller', 'owner'].map((role) {
                    return DropdownMenuItem<String>(
                      value: role,
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(color: Colors.blue),
                      ),
                    );
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => selectedRole = val);
                    }
                  },
                ),
              ),
              const SizedBox(height: 10),

              _buildActionButton("CREATE ACCOUNT", _createAccount),

              // USER LIST SECTION
              const SizedBox(height: 20),
              Divider(
                color: Colors.blue.withOpacity(0.5), // Diubah ke biru dengan opacity
                thickness: 1,
                height: 30,
              ),
              
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(left: BorderSide(color: Colors.blue, width: 4)), // Aksen biru
                ),
                child: const Text(
                  "User List",
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: Colors.blue, // Diubah ke biru
                      ),
                    )
                  : ListView(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      children: userList.map((u) => _buildUserItem(u)).toList(),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}