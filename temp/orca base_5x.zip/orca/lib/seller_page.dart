import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _newUserController = TextEditingController();
  final _newPassController = TextEditingController();
  final _dayController = TextEditingController();

  final _editUserController = TextEditingController();
  final _editDayController = TextEditingController();

  bool isLoading = false;

  Future<void> _createAccount() async {
    final newUser = _newUserController.text.trim();
    final newPass = _newPassController.text.trim();
    final days = _dayController.text.trim();

    if (newUser.isEmpty || newPass.isEmpty || days.isEmpty) {
      _showDialog("⚠️ Error", "Semua field harus diisi.");
      return;
    }

    setState(() => isLoading = true);

    final uri = Uri.parse(
      'http://kenzz.xv.jwxhost.site:2004/createAccount?key=${widget.keyToken}&newUser=$newUser&pass=$newPass&day=$days',
    );

    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showDialog("✅ Success", "Akun berhasil dibuat!");
        _newUserController.clear();
        _newPassController.clear();
        _dayController.clear();
      } else {
        _showDialog("❌ Failed", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat terhubung ke server.");
    }

    setState(() => isLoading = false);
  }

  Future<void> _editDuration() async {
    final username = _editUserController.text.trim();
    final newDays = _editDayController.text.trim();

    if (username.isEmpty || newDays.isEmpty) {
      _showDialog("⚠️ Error", "Isi username dan durasi.");
      return;
    }

    setState(() => isLoading = true);

    final uri = Uri.parse(
      'http://kenzz.xv.jwxhost.site:2004/editUser?key=${widget.keyToken}&username=$username&addDays=$newDays',
    );

    try {
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _showDialog("✅ Success", "Durasi berhasil diperbarui.");
        _editUserController.clear();
        _editDayController.clear();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal memperbarui durasi.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat menghubungi server.");
    }

    setState(() => isLoading = false);
  }

  void _showDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        title: Text(title, style: const TextStyle(color: Colors.blue)), // Diubah ke biru
        content: Text(msg, style: const TextStyle(color: Colors.blueAccent)), // Diubah ke biru
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.blue)), // Diubah ke biru
          ),
        ],
      ),
    );
  }

  Widget _buildInput(String label, TextEditingController controller, {TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(color: Colors.blue), // Diubah ke biru
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.blue), // Diubah ke biru
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.blue), // Diubah ke biru
            borderRadius: BorderRadius.circular(12),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.blue, width: 2), // Diubah ke biru dengan ketebalan 2
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          "Reseller Panel", 
          style: TextStyle(
            fontFamily: 'Orbitron',
            color: Colors.blue, // Diubah ke biru
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.blue), // Diubah ke biru
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header Buat Akun Baru
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
              decoration: BoxDecoration(
                border: Border(left: BorderSide(color: Colors.blue, width: 4)), // Tambahan aksen biru
              ),
              child: const Text(
                "Buat Akun Baru", 
                style: TextStyle(
                  color: Colors.blue, // Diubah ke biru
                  fontFamily: 'Orbitron', 
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 8),
            _buildInput("Username Baru", _newUserController),
            _buildInput("Password Baru", _newPassController),
            _buildInput("Durasi (hari)", _dayController, type: TextInputType.number),
            
            // Button Buat Akun
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 2,
                  )
                ],
              ),
              child: ElevatedButton(
                onPressed: isLoading ? null : _createAccount,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, // Diubah dari putih ke biru
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        "BUAT AKUN", 
                        style: TextStyle(
                          fontFamily: 'Orbitron', 
                          fontSize: 16,
                          color: Colors.black, // Text hitam untuk kontras
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),

            const SizedBox(height: 30),
            
            // Divider
            Divider(
              color: Colors.blue.withOpacity(0.5), // Diubah ke biru dengan opacity
              thickness: 1,
              height: 30,
            ),
            
            // Header Edit Durasi
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
              decoration: BoxDecoration(
                border: Border(left: BorderSide(color: Colors.blue, width: 4)), // Tambahan aksen biru
              ),
              child: const Text(
                "Edit Durasi Akun", 
                style: TextStyle(
                  color: Colors.blue, // Diubah ke biru
                  fontFamily: 'Orbitron', 
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 8),
            _buildInput("Username yang diedit", _editUserController),
            _buildInput("Tambah Durasi (hari)", _editDayController, type: TextInputType.number),
            
            // Button Edit Durasi
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 2,
                  )
                ],
              ),
              child: ElevatedButton(
                onPressed: isLoading ? null : _editDuration,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, // Diubah dari putih ke biru
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        "UBAH DURASI", 
                        style: TextStyle(
                          fontFamily: 'Orbitron', 
                          fontSize: 16,
                          color: Colors.black, // Text hitam untuk kontras
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}