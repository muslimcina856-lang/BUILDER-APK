import 'package:flutter/material.dart';
import 'home_page.dart';
import 'admin_page.dart';
import 'seller_page.dart';

class LoaderPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const LoaderPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.sessionKey,
  });

  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeScaleAnim;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;

  Widget _selectedPage = const Placeholder();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _fadeScaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildMyInfo();
  }

  String _calculateAccountAge() {
    try {
      final expired = DateTime.parse(expiredDate);
      final now = DateTime.now();
      final age = expired.difference(now).inDays;
      return age > 0 ? "$age days remaining" : "Expired";
    } catch (_) {
      return "Unknown";
    }
  }

  Route smoothPageTransition(Widget page) {
    return PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 500),
      reverseTransitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeInOut);
        return ScaleTransition(
          scale: Tween<double>(begin: 0.92, end: 1.0).animate(curved),
          child: FadeTransition(opacity: curved, child: child),
        );
      },
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Card(
        color: Colors.black,
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Icon(icon, color: color),
              const SizedBox(height: 6),
              Text(value, style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 14)), // Diubah ke biru
              const SizedBox(height: 2),
              Text(title, style: const TextStyle(color: Colors.blueAccent, fontSize: 12)), // Diubah ke biru
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoItem(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: Colors.blue), // Diubah ke biru
          const SizedBox(width: 10),
          Text("$label:", style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.w600)), // Diubah ke biru
          const SizedBox(width: 8),
          Expanded(
            child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: Colors.blueAccent)), // Diubah ke biru
          ),
        ],
      ),
    );
  }

  Widget _buildMyInfo() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ScaleTransition(
              scale: Tween(begin: 0.9, end: 1.0).animate(_fadeScaleAnim),
              child: FadeTransition(
                opacity: _fadeScaleAnim,
                child: Image.asset('assets/images/logo.jpg', height: 180),
              ),
            ),
            Card(
              elevation: 8,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: SizedBox(
                width: double.infinity,
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        'assets/images/logo.jpg',
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: 200,
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: 200,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _infoItem(Icons.person, "Username", username),
                          _infoItem(Icons.lock, "Password", "******"),
                          _infoItem(Icons.verified_user, "Role", role),
                          _infoItem(Icons.timer, "Expired", expiredDate),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _statCard("Role", role.toUpperCase(), Icons.security, Colors.blue), // Diubah ke biru
                _statCard("Session", sessionKey.substring(0, 5) + "...", Icons.vpn_key, Colors.blue), // Diubah ke biru
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _statCard("Account Age", _calculateAccountAge(), Icons.calendar_today, Colors.blue), // Diubah ke biru
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.black87,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            padding: EdgeInsets.zero,
            child: Stack(
              fit: StackFit.expand,
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                  child: Image.asset('assets/images/logo.jpg', fit: BoxFit.cover, gaplessPlayback: true),
                ),
                Container(color: Colors.black.withOpacity(0.5)),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Orca Malignant",
                        style: TextStyle(fontSize: 22, fontFamily: 'Orbitron', color: Colors.blue, fontWeight: FontWeight.bold), // Diubah ke biru
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "@$username",
                        style: const TextStyle(fontSize: 16, fontFamily: 'Orbitron', color: Colors.blueAccent), // Diubah ke biru
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.info, color: Colors.blue), // Diubah ke biru
            title: const Text("My Info", style: TextStyle(color: Colors.blue)), // Diubah ke biru
            onTap: () {
              Navigator.pop(context);
              setState(() => _selectedPage = _buildMyInfo());
            },
          ),
          ListTile(
            leading: const Icon(Icons.bug_report, color: Colors.blue), // Diubah ke biru
            title: const Text("Attack Menu", style: TextStyle(color: Colors.blue)), // Diubah ke biru
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, smoothPageTransition(HomePage(
                username: username,
                password: password,
                listBug: listBug,
                role: role,
                expiredDate: expiredDate,
                sessionKey: sessionKey,
              )));
            },
          ),

          if (role.toLowerCase() == "reseller" || role.toLowerCase() == "owner" || role.toLowerCase() == "reseller1")
            ListTile(
              leading: const Icon(Icons.person_add, color: Colors.blue), // Diubah ke biru
              title: const Text("Reseller Menu", style: TextStyle(color: Colors.blue)), // Diubah ke biru
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, smoothPageTransition(SellerPage(keyToken: sessionKey)));
              },
            ),
          if (role.toLowerCase() == "owner")
            ListTile(
              leading: const Icon(Icons.admin_panel_settings, color: Colors.blue), // Diubah ke biru
              title: const Text("Admin Control", style: TextStyle(color: Colors.blue)), // Diubah ke biru
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, smoothPageTransition(AdminPage(sessionKey: sessionKey)));
              },
            ),

          const Divider(color: Colors.blue), // Diubah ke biru
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 4),
            child: Text("Credits:", style: TextStyle(color: Colors.blue, fontFamily: 'Orbitron', fontSize: 14)), // Diubah ke biru
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("@Fahri_Reals01 < Dev >", style: TextStyle(color: Colors.blueAccent)), // Diubah ke biru
                Text("@kizzyytsx < Dev2 >", style: TextStyle(color: Colors.blueAccent)), // Diubah ke biru
                Text("@Fahri_Reals01 < Back-end >", style: TextStyle(color: Colors.blueAccent)), // Diubah ke biru
                SizedBox(height: 4),
                Text("Copyright 2026 By @Fahri_Reals01", style: TextStyle(color: Colors.blue, fontSize: 11)), // Diubah ke biru
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildDrawer(),
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Dashboard", style: TextStyle(fontFamily: 'Orbitron', color: Colors.blue)), // Diubah ke biru
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.blue), // Tambahan untuk icon drawer
      ),
      body: FadeTransition(
        opacity: _fadeScaleAnim,
        child: _selectedPage,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}