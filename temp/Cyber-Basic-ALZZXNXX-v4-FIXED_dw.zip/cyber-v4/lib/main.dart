import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ─── THEME ───────────────────────────────────────────────
const Color kBg       = Color(0xFFF5F7FA);
const Color kInk      = Color(0xFF0F172A);
const Color kCard     = Color(0xFFFFFFFF);
const Color kAccent   = Color(0xFF1E293B);
const Color kSub      = Color(0xFF64748B);
const Color kBorder   = Color(0xFFE2E8F0);

// ─── HELPERS ─────────────────────────────────────────────
void push(BuildContext c, Widget p) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => p));

Future<void> copy(BuildContext c, String s) async {
  await Clipboard.setData(ClipboardData(text: s));
  if (!c.mounted) return;
  ScaffoldMessenger.of(c).showSnackBar(
    const SnackBar(content: Text('Copied!'), duration: Duration(seconds: 1)),
  );
}

Future<void> openUrl(String s) async {
  final u = Uri.parse(s);
  if (await canLaunchUrl(u)) {
    await launchUrl(u, mode: LaunchMode.externalApplication);
  }
}

// ─── APP ─────────────────────────────────────────────────
void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Cyber Basic',
    theme: ThemeData(
      useMaterial3: true,
      fontFamily: 'sans-serif',
      colorScheme: ColorScheme.fromSeed(
        seedColor: kInk,
        brightness: Brightness.light,
        surface: kBg,
      ),
      scaffoldBackgroundColor: kBg,
      appBarTheme: const AppBarTheme(
        backgroundColor: kCard,
        foregroundColor: kInk,
        elevation: 0,
        shadowColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: kInk,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      cardTheme: CardThemeData(
        color: kCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: kBorder, width: 1),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: kInk,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
      ),
    ),
    home: const Shell(),
  );
}

// ─── SHELL ───────────────────────────────────────────────
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _idx = 0;
  final _pages = const [HomePage(), ToolsPage(), LearnPage(), MorePage()];

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        leading: Builder(
          builder: (x) => IconButton(
            icon: const Icon(Icons.menu_rounded),
            onPressed: () => Scaffold.of(x).openDrawer(),
          ),
        ),
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/cyber_basic_icon.png',
                width: 32,
                height: 32,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Cyber Basic',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => push(c, const SettingsPage()),
          ),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: kBorder),
        ),
      ),
      drawer: const SideMenu(),
      body: _pages[_idx],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: kBorder, width: 1)),
          color: kCard,
        ),
        child: NavigationBar(
          selectedIndex: _idx,
          backgroundColor: kCard,
          surfaceTintColor: Colors.transparent,
          indicatorColor: kInk.withOpacity(0.08),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (v) => setState(() => _idx = v),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home_rounded),
              label: 'Home',
            ),
            NavigationDestination(
              icon: Icon(Icons.grid_view_outlined),
              selectedIcon: Icon(Icons.grid_view_rounded),
              label: 'Tools',
            ),
            NavigationDestination(
              icon: Icon(Icons.school_outlined),
              selectedIcon: Icon(Icons.school_rounded),
              label: 'Learn',
            ),
            NavigationDestination(
              icon: Icon(Icons.more_horiz_rounded),
              label: 'More',
            ),
          ],
        ),
      ),
    );
  }
}

// ─── SIDE MENU ───────────────────────────────────────────
class SideMenu extends StatelessWidget {
  const SideMenu({super.key});
  @override
  Widget build(BuildContext c) {
    final items = [
      ['Home', Icons.home_rounded, const HomePage()],
      ['Tools', Icons.grid_view_rounded, const ToolsPage()],
      ['Learn', Icons.school_rounded, const LearnPage()],
      ['Roadmap', Icons.route_rounded, const RoadmapPage()],
      ['CTF Checklist', Icons.checklist_rounded, const CtfPage()],
      ['About', Icons.info_rounded, const AboutPage()],
    ];
    return Drawer(
      backgroundColor: kCard,
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: kInk,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      'assets/cyber_basic_logo.png',
                      height: 80,
                      width: 80,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Cyber Basic',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Text(
                    'Advanced Cyber Security Tools',
                    style: TextStyle(color: Colors.white60, fontSize: 12),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'BY ALZZXNXX',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 11,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Nav items
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: items.map((x) {
                  return ListTile(
                    leading: Icon(x[1] as IconData, color: kInk, size: 22),
                    title: Text(
                      x[0] as String,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                    horizontalTitleGap: 8,
                    onTap: () {
                      Navigator.pop(c);
                      push(c, x[2] as Widget);
                    },
                  );
                }).toList(),
              ),
            ),
            // Footer
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: kBorder)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.telegram, size: 18, color: kSub),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => openUrl('https://t.me/alzzxnxx'),
                    child: const Text(
                      '@alzzxnxx',
                      style: TextStyle(
                        color: kSub,
                        fontSize: 13,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── HOME PAGE ───────────────────────────────────────────
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext c) {
    final quick = [
      ['ENC APK', Icons.android, const VaultPage()],
      ['Password\nGenerator', Icons.password, const PasswordPage()],
      ['ASCII\nGenerator', Icons.text_fields, const AsciiPage()],
      ['Hash Tools', Icons.tag, const HashPage()],
      ['Cyber Learn', Icons.school, const LearnPage()],
      ['CTF Checklist', Icons.checklist, const CtfPage()],
      ['Network\nTools', Icons.wifi, const UrlPage()],
      ['Web Tools', Icons.language, const UrlPage()],
      ['File Analyzer', Icons.folder, const FilePage()],
      ['Crypto Tools', Icons.lock, const Base64Page()],
      ['System Info', Icons.phone_android, const DevicePage()],
      ['More Tools', Icons.more_horiz, const ToolsPage()],
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // HERO BANNER
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kInk,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Welcome to',
                      style: TextStyle(color: Colors.white60, fontSize: 13),
                    ),
                    const Text(
                      'Cyber Basic',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Text(
                      'All Cyber Tools in One App',
                      style: TextStyle(color: Colors.white60, fontSize: 12),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        _StatBadge('50+', 'Tools'),
                        const SizedBox(width: 12),
                        _StatBadge('10K+', 'Users'),
                        const SizedBox(width: 12),
                        _StatBadge('Aktif', 'Update'),
                      ],
                    ),
                  ],
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(
                  'assets/cyber_basic_icon.png',
                  width: 90,
                  height: 90,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // MAIN FEATURES GRID
        const Text(
          '| Main Features',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w900,
            color: kInk,
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.0,
          ),
          itemCount: quick.length,
          itemBuilder: (c, i) {
            final item = quick[i];
            return GestureDetector(
              onTap: () => push(c, item[2] as Widget),
              child: Container(
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kBorder),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: kBg,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        item[1] as IconData,
                        color: kInk,
                        size: 22,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item[0] as String,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: kInk,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 20),

        // QUICK ACCESS
        const Text(
          '| Quick Access',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w900,
            color: kInk,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _QuickBtn(
                'ENC APK',
                Icons.android,
                () => push(c, const VaultPage()),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _QuickBtn(
                'Password',
                Icons.password,
                () => push(c, const PasswordPage()),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _QuickBtn(
                'ASCII Gen',
                Icons.text_fields,
                () => push(c, const AsciiPage()),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _QuickBtn(
                'Cyber Learn',
                Icons.school,
                () => push(c, const LearnPage()),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _QuickBtn(
                'Network',
                Icons.wifi,
                () => push(c, const UrlPage()),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _QuickBtn(
                'Web Tools',
                Icons.language,
                () => push(c, const UrlPage()),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // PROMO BANNER
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kBorder),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: kInk,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.shield, color: Colors.white),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Cyber Basic',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      'Stronger Knowledge, Stronger Security',
                      style: TextStyle(color: kSub, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: kSub),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

class _StatBadge extends StatelessWidget {
  final String val, label;
  const _StatBadge(this.val, this.label);
  @override
  Widget build(BuildContext c) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        val,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 16,
        ),
      ),
      Text(
        label,
        style: const TextStyle(color: Colors.white60, fontSize: 10),
      ),
    ],
  );
}

class _QuickBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _QuickBtn(this.label, this.icon, this.onTap);
  @override
  Widget build(BuildContext c) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: kInk,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    ),
  );
}

// ─── TOOLS PAGE ──────────────────────────────────────────
class ToolsPage extends StatelessWidget {
  const ToolsPage({super.key});
  @override
  Widget build(BuildContext c) {
    final tools = [
      ['Password Generator', Icons.password, const PasswordPage()],
      ['Password Strength', Icons.shield_outlined, const StrengthPage()],
      ['ASCII Generator', Icons.text_fields, const AsciiPage()],
      ['ASCII Faces', Icons.face, const FacesPage()],
      ['SHA-256 Hash', Icons.tag, const HashPage()],
      ['Base64', Icons.code, const Base64Page()],
      ['Hex Encoder', Icons.hexagon_outlined, const HexPage()],
      ['JSON Formatter', Icons.data_object, const JsonPage()],
      ['URL Analyzer', Icons.link, const UrlPage()],
      ['UUID Generator', Icons.fingerprint, const UuidPage()],
      ['Token Generator', Icons.key, const TokenPage()],
      ['Timestamp', Icons.schedule, const TimePage()],
      ['File Analyzer', Icons.folder_open, const FilePage()],
      ['File Vault', Icons.lock_outline, const VaultPage()],
      ['Security Roadmap', Icons.route, const RoadmapPage()],
      ['CTF Checklist', Icons.checklist, const CtfPage()],
      ['Device Info', Icons.phone_android, const DevicePage()],
      ['Secure Notes', Icons.note_alt_outlined, const NotesPage()],
      ['Activity Log', Icons.history, const ActivityPage()],
      ['About', Icons.info_outline, const AboutPage()],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'All Tools',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
        ),
        const Text(
          'Security & CTF utilities',
          style: TextStyle(color: kSub, fontSize: 13),
        ),
        const SizedBox(height: 16),
        ...tools.map(
          (a) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: kBg,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(a[1] as IconData, color: kInk, size: 20),
                ),
                title: Text(
                  a[0] as String,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
                trailing: const Icon(Icons.chevron_right, color: kSub),
                onTap: () => push(c, a[2] as Widget),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── LEARN PAGE ──────────────────────────────────────────
class LearnPage extends StatelessWidget {
  const LearnPage({super.key});
  @override
  Widget build(BuildContext c) {
    final cats = ['Semua', 'SQLi', 'XSS', 'RCE', 'IDOR', 'Lainnya'];
    final lessons = [
      ['Apa itu SQL Injection?', 'Belajar tentang celah SQL Injection dan cara kerjanya.', 'SQLi', Icons.storage],
      ['Apa itu XSS?', 'Belajar tentang Cross Site Scripting dan dampaknya.', 'XSS', Icons.code],
      ['Apa itu RCE?', 'Belajar tentang Remote Code Execution dan eksploitasi.', 'RCE', Icons.terminal],
      ['Apa itu IDOR?', 'Belajar tentang Insecure Direct Object Reference.', 'IDOR', Icons.lock_open],
      ['Apa itu Shell?', 'Belajar tentang Web Shell dan cara memanfaatkannya.', 'Lainnya', Icons.code_off],
      ['Cyber Security Dasar', 'Pengenalan dasar dunia keamanan siber.', 'Lainnya', Icons.shield],
      ['Ethical Hacking Roadmap', 'Panduan langkah menjadi ethical hacker.', 'Lainnya', Icons.route],
      ['Kriptografi Dasar', 'Memahami enkripsi dan bagaimana data diamankan.', 'Lainnya', Icons.enhanced_encryption],
      ['Network Security', 'Keamanan jaringan dan protokol umum.', 'Lainnya', Icons.wifi],
      ['OSINT Fundamentals', 'Open Source Intelligence untuk keamanan.', 'Lainnya', Icons.search],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Cyber Learn',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 12),
        // Category chips
        SizedBox(
          height: 36,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: cats.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (c, i) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: i == 0 ? kInk : kCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: i == 0 ? kInk : kBorder),
              ),
              child: Text(
                cats[i],
                style: TextStyle(
                  color: i == 0 ? Colors.white : kInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        ...lessons.map(
          (e) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: kInk,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(e[3] as IconData, color: Colors.white, size: 22),
                ),
                title: Text(
                  e[0] as String,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 2),
                    Text(e[1] as String, style: const TextStyle(fontSize: 12, color: kSub)),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: kBg,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        e[2] as String,
                        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: kInk),
                      ),
                    ),
                  ],
                ),
                trailing: const Icon(Icons.chevron_right, color: kSub),
                onTap: () => push(c, LessonPage(e[0] as String, e[2] as String, e[1] as String)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class LessonPage extends StatelessWidget {
  final String title, tag, desc;
  const LessonPage(this.title, this.tag, this.desc, {super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: kInk,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            tag,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
          ),
        ),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(desc, style: const TextStyle(fontSize: 15, height: 1.6, color: kSub)),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Checklist Pertahanan:\n\n• Validasi semua input\n• Gunakan API yang aman\n• Terapkan authorization di server\n• Log semua security events\n• Test hanya pada sistem yang diizinkan',
              style: TextStyle(fontSize: 14, height: 1.6),
            ),
          ),
        ),
      ],
    ),
  );
}

// ─── MORE PAGE ───────────────────────────────────────────
class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext c) {
    final items = [
      ['Security Roadmap', Icons.route, const RoadmapPage()],
      ['CTF Checklist', Icons.checklist, const CtfPage()],
      ['Device Info', Icons.phone_android, const DevicePage()],
      ['Secure Notes', Icons.note_alt, const NotesPage()],
      ['Activity Log', Icons.history, const ActivityPage()],
      ['About', Icons.info, const AboutPage()],
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        ...items.map(
          (x) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Card(
              child: ListTile(
                leading: Icon(x[1] as IconData, color: kInk),
                title: Text(x[0] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: const Icon(Icons.chevron_right, color: kSub),
                onTap: () => push(c, x[2] as Widget),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── TOOL PAGES ──────────────────────────────────────────

// Password Generator
class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key});
  @override
  State<PasswordPage> createState() => _PasswordState();
}
class _PasswordState extends State<PasswordPage> {
  final _seed = TextEditingController();
  String _out = '';
  int _len = 20;

  void _gen() {
    const ch = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#\$%^&*_-+=';
    final r = Random.secure();
    final s = _seed.text;
    final core = List.generate(max(8, _len - s.length), (_) => ch[r.nextInt(ch.length)]).join();
    final salt = List.generate(6, (_) => ch[r.nextInt(ch.length)]).join();
    setState(() => _out = '$s$core$salt');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Password Generator')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(
          controller: _seed,
          decoration: const InputDecoration(labelText: 'Seed opsional (mis. alzzxnxx)'),
        ),
        const SizedBox(height: 12),
        Text('Panjang: $_len', style: const TextStyle(fontWeight: FontWeight.w600)),
        Slider(
          value: _len.toDouble(),
          min: 12,
          max: 48,
          divisions: 36,
          activeColor: kInk,
          onChanged: (v) => setState(() => _len = v.round()),
        ),
        const SizedBox(height: 8),
        FilledButton(onPressed: _gen, child: const Text('Generate')),
        const SizedBox(height: 20),
        if (_out.isNotEmpty) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Password:', style: TextStyle(color: kSub, fontSize: 12)),
                  const SizedBox(height: 6),
                  SelectableText(
                    _out,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1),
                  ),
                ],
              ),
            ),
          ),
          TextButton.icon(
            onPressed: () => copy(c, _out),
            icon: const Icon(Icons.copy),
            label: const Text('Copy'),
          ),
        ],
      ],
    ),
  );
}

// Password Strength
class StrengthPage extends StatefulWidget {
  const StrengthPage({super.key});
  @override
  State<StrengthPage> createState() => _StrengthState();
}
class _StrengthState extends State<StrengthPage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _check() {
    final p = _ctrl.text;
    int s = 0;
    if (p.length >= 12) s++;
    if (RegExp('[A-Z]').hasMatch(p)) s++;
    if (RegExp('[a-z]').hasMatch(p)) s++;
    if (RegExp(r'\d').hasMatch(p)) s++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(p)) s++;
    setState(() => _out = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'][s]);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Password Strength')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _ctrl,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Masukkan password'),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _check, child: const Text('Check')),
          const SizedBox(height: 24),
          if (_out.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  _out,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                ),
              ),
            ),
        ],
      ),
    ),
  );
}

// ASCII Generator
class AsciiPage extends StatefulWidget {
  const AsciiPage({super.key});
  @override
  State<AsciiPage> createState() => _AsciiState();
}
class _AsciiState extends State<AsciiPage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _gen() {
    final s = _ctrl.text.length > 16 ? _ctrl.text.substring(0, 16) : _ctrl.text;
    setState(() => _out = '+------------------+\n| ${s.padRight(16)} |\n+------------------+');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('ASCII Generator')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, decoration: const InputDecoration(labelText: 'Teks')),
        const SizedBox(height: 10),
        FilledButton(onPressed: _gen, child: const Text('Generate')),
        const SizedBox(height: 16),
        if (_out.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace', fontSize: 14)),
            ),
          ),
      ],
    ),
  );
}

// ASCII Faces
class FacesPage extends StatelessWidget {
  const FacesPage({super.key});
  @override
  Widget build(BuildContext c) {
    final faces = {
      'Cyber': '.-""""-.\\n/  .--.  \\\\n|  ( XX )  |\\n|   \\\\__/   |\\n \\\\  /||\\\\  /',
      'Cute':  ' /\\_/\\\\n( o.o )\\n > ^ <',
      'Hero':  '  _____\\n / ___ \\\\n| / _ \\ |\\n|| (_) ||\\n| \\\\___/ |\\n \\_____/',
    };
    return Scaffold(
      appBar: AppBar(title: const Text('ASCII Faces')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: faces.entries.map((e) => Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.key, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 8),
                SelectableText(e.value, style: const TextStyle(fontFamily: 'monospace')),
              ],
            ),
          ),
        )).toList(),
      ),
    );
  }
}

// Hash Page
class HashPage extends StatefulWidget {
  const HashPage({super.key});
  @override
  State<HashPage> createState() => _HashState();
}
class _HashState extends State<HashPage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _hashText() => setState(() => _out = sha256.convert(utf8.encode(_ctrl.text)).toString());

  Future<void> _hashFile() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null) return;
    final b = r.files.single.bytes;
    if (b == null) return;
    setState(() => _out = sha256.convert(b).toString());
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('SHA-256 Hash')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, maxLines: 4, decoration: const InputDecoration(labelText: 'Teks')),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          children: [
            FilledButton(onPressed: _hashText, child: const Text('Hash Teks')),
            OutlinedButton(onPressed: _hashFile, child: const Text('Hash File')),
          ],
        ),
        const SizedBox(height: 16),
        if (_out.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('SHA-256:', style: TextStyle(color: kSub, fontSize: 12)),
                  const SizedBox(height: 6),
                  SelectableText(_out, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: () => copy(c, _out),
                    icon: const Icon(Icons.copy, size: 16),
                    label: const Text('Copy'),
                  ),
                ],
              ),
            ),
          ),
      ],
    ),
  );
}

// Base64
class Base64Page extends StatefulWidget {
  const Base64Page({super.key});
  @override
  State<Base64Page> createState() => _Base64State();
}
class _Base64State extends State<Base64Page> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _enc() => setState(() => _out = base64Encode(utf8.encode(_ctrl.text)));
  void _dec() {
    try {
      setState(() => _out = utf8.decode(base64Decode(_ctrl.text)));
    } catch (_) {
      setState(() => _out = 'Base64 tidak valid');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Base64')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, maxLines: 5),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [
          FilledButton(onPressed: _enc, child: const Text('Encode')),
          OutlinedButton(onPressed: _dec, child: const Text('Decode')),
        ]),
        const SizedBox(height: 16),
        if (_out.isNotEmpty) Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace')),
          ),
        ),
      ],
    ),
  );
}

// Hex
class HexPage extends StatefulWidget {
  const HexPage({super.key});
  @override
  State<HexPage> createState() => _HexState();
}
class _HexState extends State<HexPage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _enc() => setState(() => _out = utf8.encode(_ctrl.text).map((b) => b.toRadixString(16).padLeft(2, '0')).join(' '));
  void _dec() {
    try {
      setState(() => _out = utf8.decode(_ctrl.text.trim().split(RegExp(r'\s+')).map((p) => int.parse(p, radix: 16)).toList()));
    } catch (_) {
      setState(() => _out = 'Hex tidak valid');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Hex Encoder')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, maxLines: 4),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [
          FilledButton(onPressed: _enc, child: const Text('Encode')),
          OutlinedButton(onPressed: _dec, child: const Text('Decode')),
        ]),
        const SizedBox(height: 16),
        if (_out.isNotEmpty) Card(
          child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace'))),
        ),
      ],
    ),
  );
}

// JSON Formatter
class JsonPage extends StatefulWidget {
  const JsonPage({super.key});
  @override
  State<JsonPage> createState() => _JsonState();
}
class _JsonState extends State<JsonPage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _fmt(bool minify) {
    try {
      final o = jsonDecode(_ctrl.text);
      setState(() => _out = minify ? jsonEncode(o) : const JsonEncoder.withIndent('  ').convert(o));
    } catch (e) {
      setState(() => _out = 'JSON tidak valid: $e');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('JSON Formatter')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, maxLines: 8),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [
          FilledButton(onPressed: () => _fmt(false), child: const Text('Format')),
          OutlinedButton(onPressed: () => _fmt(true), child: const Text('Minify')),
        ]),
        const SizedBox(height: 16),
        if (_out.isNotEmpty) Card(
          child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace', fontSize: 12))),
        ),
      ],
    ),
  );
}

// URL Analyzer
class UrlPage extends StatefulWidget {
  const UrlPage({super.key});
  @override
  State<UrlPage> createState() => _UrlState();
}
class _UrlState extends State<UrlPage> {
  final _ctrl = TextEditingController();
  Map<String, String> _out = {};

  void _analyze() {
    final u = Uri.tryParse(_ctrl.text);
    setState(() => _out = u == null
      ? {'error': 'URL tidak valid'}
      : {
          'scheme': u.scheme,
          'host': u.host,
          'port': u.hasPort ? '${u.port}' : 'default',
          'path': u.path,
          'query': u.query,
          'fragment': u.fragment,
        });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('URL Analyzer')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, decoration: const InputDecoration(labelText: 'https://example.com/path')),
        const SizedBox(height: 10),
        FilledButton(onPressed: _analyze, child: const Text('Analyze')),
        ..._out.entries.map((e) => Card(
          child: ListTile(
            title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            subtitle: Text(e.value.isEmpty ? '—' : e.value),
          ),
        )),
      ],
    ),
  );
}

// UUID
String _makeUuid() {
  final r = Random.secure();
  final h = List.generate(32, (_) => r.nextInt(16).toRadixString(16));
  h[12] = '4';
  h[16] = ((int.parse(h[16], radix: 16) & 3) | 8).toRadixString(16);
  return '${h.sublist(0, 8).join()}-${h.sublist(8, 12).join()}-${h.sublist(12, 16).join()}-${h.sublist(16, 20).join()}-${h.sublist(20).join()}';
}

class UuidPage extends StatelessWidget {
  const UuidPage({super.key});
  @override
  Widget build(BuildContext c) => _SimpleTool('UUID Generator', 'Generate UUID random.', () => copy(c, _makeUuid()));
}

class TokenPage extends StatelessWidget {
  const TokenPage({super.key});
  @override
  Widget build(BuildContext c) => _SimpleTool('Token Generator', 'Generate token random.', () => copy(c, List.generate(48, (_) => Random.secure().nextInt(36).toRadixString(36)).join()));
}

class _SimpleTool extends StatelessWidget {
  final String title, desc;
  final VoidCallback onTap;
  const _SimpleTool(this.title, this.desc, this.onTap);
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(desc, textAlign: TextAlign.center, style: const TextStyle(color: kSub)),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: onTap,
              icon: const Icon(Icons.refresh),
              label: const Text('Generate & Copy'),
            ),
          ],
        ),
      ),
    ),
  );
}

// Timestamp
class TimePage extends StatefulWidget {
  const TimePage({super.key});
  @override
  State<TimePage> createState() => _TimeState();
}
class _TimeState extends State<TimePage> {
  final _ctrl = TextEditingController();
  String _out = '';

  void _now() => setState(() => _out = '${DateTime.now().millisecondsSinceEpoch}');
  void _convert() {
    final n = int.tryParse(_ctrl.text);
    setState(() => _out = n == null ? 'Timestamp tidak valid' : DateTime.fromMillisecondsSinceEpoch(n).toLocal().toString());
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Timestamp')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        FilledButton(onPressed: _now, child: const Text('Unix MS Sekarang')),
        const SizedBox(height: 12),
        TextField(controller: _ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Unix milliseconds')),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: _convert, child: const Text('Convert')),
        const SizedBox(height: 16),
        if (_out.isNotEmpty) Card(
          child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace'))),
        ),
      ],
    ),
  );
}

// File Analyzer
class FilePage extends StatefulWidget {
  const FilePage({super.key});
  @override
  State<FilePage> createState() => _FileState();
}
class _FileState extends State<FilePage> {
  String _out = '';

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null) return;
    final f = r.files.single;
    final e = (f.extension ?? '').toLowerCase();
    final b = f.bytes;
    final flags = <String>[];
    if ({'exe','bat','cmd','scr','vbs','ps1','apk','jar','dll','so'}.contains(e)) {
      flags.add('Ekstensi executable: .$e');
    }
    if (f.size > 100 * 1024 * 1024) flags.add('File besar (>100MB)');
    final h = b == null ? 'Unavailable' : sha256.convert(b).toString();
    setState(() => _out = 'Nama: ${f.name}\nUkuran: ${f.size} bytes\nEkstensi: .$e\nSHA-256: $h\n\nFlag:\n${flags.isEmpty ? "Tidak ada" : flags.join("\n")}\n\nBukan hasil antivirus.');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('File Analyzer')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          FilledButton.icon(onPressed: _pick, icon: const Icon(Icons.folder_open), label: const Text('Pilih File')),
          const SizedBox(height: 16),
          Expanded(child: SingleChildScrollView(child: SelectableText(_out))),
        ],
      ),
    ),
  );
}

// File Vault
class VaultPage extends StatefulWidget {
  const VaultPage({super.key});
  @override
  State<VaultPage> createState() => _VaultState();
}
class _VaultState extends State<VaultPage> {
  String _out = '';

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null) return;
    final b = r.files.single.bytes;
    setState(() => _out = b == null
      ? 'Bytes tidak tersedia.'
      : 'File: ${r.files.single.name}\nSHA-256: ${sha256.convert(b)}\n\nFingerprint integritas siap.');
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('File Vault')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Pilih APK, ZIP, HTML, atau file apapun untuk verifikasi integritas.', style: TextStyle(color: kSub)),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: _pick, icon: const Icon(Icons.lock), label: const Text('Pilih File')),
        const SizedBox(height: 16),
        if (_out.isNotEmpty) Card(
          child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(_out, style: const TextStyle(fontFamily: 'monospace'))),
        ),
      ],
    ),
  );
}

// Device Info
class DevicePage extends StatelessWidget {
  const DevicePage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Device Info')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _InfoCard('OS', Platform.operatingSystem),
        _InfoCard('OS Version', Platform.operatingSystemVersion),
        _InfoCard('Dart Version', Platform.version.split(' ').first),
        _InfoCard('Executable', Platform.executable),
      ],
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final String label, value;
  const _InfoCard(this.label, this.value);
  @override
  Widget build(BuildContext c) => Card(
    child: ListTile(
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: kSub)),
      subtitle: Text(value, style: const TextStyle(color: kInk, fontWeight: FontWeight.w600)),
    ),
  );
}

// Secure Notes
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesState();
}
class _NotesState extends State<NotesPage> {
  final _ctrl = TextEditingController();
  String _saved = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() => _saved = p.getString('notes') ?? '');
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('notes', _ctrl.text);
    setState(() => _saved = _ctrl.text);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Secure Notes')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        TextField(controller: _ctrl, maxLines: 10, decoration: const InputDecoration(labelText: 'Catatan lokal')),
        const SizedBox(height: 10),
        FilledButton(onPressed: _save, child: const Text('Simpan')),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(_saved.isEmpty ? 'Belum ada catatan.' : _saved),
          ),
        ),
      ],
    ),
  );
}

// Activity
class ActivityPage extends StatelessWidget {
  const ActivityPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Activity Log')),
    body: const Center(child: Text('Log aktivitas lokal.', style: TextStyle(color: kSub))),
  );
}

// Roadmap
class RoadmapPage extends StatelessWidget {
  const RoadmapPage({super.key});
  @override
  Widget build(BuildContext c) {
    final steps = ['Networking', 'Linux', 'Python', 'Web Basics', 'OWASP Top 10', 'Secure Coding', 'Forensics', 'Reverse Engineering', 'CTFs', 'Responsible Disclosure'];
    return Scaffold(
      appBar: AppBar(title: const Text('Security Roadmap')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: steps.asMap().entries.map((e) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: kInk,
                child: Text('${e.key + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
              title: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        )).toList(),
      ),
    );
  }
}

// CTF
class CtfPage extends StatefulWidget {
  const CtfPage({super.key});
  @override
  State<CtfPage> createState() => _CtfState();
}
class _CtfState extends State<CtfPage> {
  final _cats = ['Web', 'Crypto', 'Forensics', 'OSINT', 'Reverse Engineering', 'Pwn', 'Mobile', 'Misc', 'Steganography', 'Networking'];
  final _done = <String>{};

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('CTF Checklist')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('${_done.length}/${_cats.length} selesai', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          ),
        ),
        const SizedBox(height: 8),
        ..._cats.map((s) => Card(
          child: CheckboxListTile(
            value: _done.contains(s),
            onChanged: (v) => setState(() => v == true ? _done.add(s) : _done.remove(s)),
            title: Text(s, style: const TextStyle(fontWeight: FontWeight.w600)),
            activeColor: kInk,
          ),
        )),
      ],
    ),
  );
}

// Settings
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        Card(child: ListTile(title: Text('Privacy-first'), subtitle: Text('File hanya dibaca setelah dipilih user.'))),
        Card(child: ListTile(title: Text('Author'), subtitle: Text('ALZZXNXX'))),
        Card(child: ListTile(title: Text('Telegram'), subtitle: Text('@alzzxnxx'))),
      ],
    ),
  );
}

// About
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('About')),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Image.asset('assets/cyber_basic_icon.png', width: 110, height: 110, fit: BoxFit.cover),
            ),
            const SizedBox(height: 16),
            const Text('Cyber Basic', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            const Text('Advanced Cyber Security Tools', style: TextStyle(color: kSub)),
            const SizedBox(height: 12),
            const Text('Author: ALZZXNXX', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            GestureDetector(
              onTap: () => openUrl('https://t.me/alzzxnxx'),
              child: const Text('Telegram: @alzzxnxx', style: TextStyle(color: Colors.blue, decoration: TextDecoration.underline)),
            ),
          ],
        ),
      ),
    ),
  );
}
