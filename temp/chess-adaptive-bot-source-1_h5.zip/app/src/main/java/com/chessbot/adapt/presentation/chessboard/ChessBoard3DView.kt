package com.chessbot.adapt.presentation.chessboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.chessbot.adapt.domain.model.*
import kotlin.math.PI

@Composable
fun ChessBoard3DView(
    board:          Board?,
    selectedSquare: Square?,
    validMoves:     List<Move>,
    lastMove:       Move?,
    isCheck:        Boolean,
    checkColor:     com.chessbot.adapt.domain.model.Color?,
    playerColor:    com.chessbot.adapt.domain.model.Color,
    boardSize:      Dp = 360.dp,
    onSquareTap:    (Square) -> Unit
) {
    // Camera — reset when player side changes
    val initTheta = if (playerColor == com.chessbot.adapt.domain.model.Color.WHITE)
        PI.toFloat() * 1.2f else PI.toFloat() * 0.2f

    var camTheta by remember(playerColor) { mutableFloatStateOf(initTheta) }
    var camPhi   by remember { mutableFloatStateOf(PI.toFloat() / 3.2f) } // ~56°

    // Selection lift — spring physics
    val selLift by animateFloatAsState(
        targetValue   = if (selectedSquare != null) 0.48f else 0f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow),
        label         = "selLift"
    )

    // Move arc animation
    var animMove     by remember { mutableStateOf<Move?>(null) }
    var animProgress by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(lastMove) {
        lastMove ?: return@LaunchedEffect
        animMove     = lastMove
        animProgress = 0f
        animate(0f, 1f, animationSpec = tween(420, easing = FastOutSlowInEasing)) { v, _ ->
            animProgress = v
        }
        animMove     = null
        animProgress = 1f
    }

    val density = LocalDensity.current
    val sizePx  = with(density) { boardSize.toPx() }

    Canvas(
        modifier = Modifier
            .size(boardSize)
            // Orbit gesture
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, _, _ ->
                    camTheta -= pan.x * 0.009f
                    camPhi    = (camPhi - pan.y * 0.006f).coerceIn(0.22f, 1.15f)
                }
            }
            // Tap gesture — uses current camera state
            .pointerInput(board, selectedSquare, camTheta, camPhi) {
                detectTapGestures { offset ->
                    if (sizePx > 0f) {
                        tapToSquare(offset.x, offset.y, sizePx, sizePx, camTheta, camPhi)
                            ?.let { onSquareTap(it) }
                    }
                }
            }
    ) {
        draw3DChessBoard(
            board          = board,
            selected       = selectedSquare,
            validMoves     = validMoves,
            lastMove       = lastMove,
            isCheck        = isCheck,
            checkSideColor = checkColor,
            cameraTheta    = camTheta,
            cameraPhi      = camPhi,
            selectedLift   = selLift,
            animMove       = animMove,
            animProgress   = animProgress
        )
    }
}
