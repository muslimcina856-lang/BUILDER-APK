package com.metro.rush;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class MetroRushView extends View {
    private static final int COLOR_INK = Color.rgb(18, 9, 31);
    private static final int COLOR_NIGHT = Color.rgb(23, 11, 46);
    private static final int COLOR_PANEL = Color.rgb(36, 18, 63);
    private static final int COLOR_PURPLE = Color.rgb(90, 36, 168);
    private static final int COLOR_YELLOW = Color.rgb(255, 216, 61);
    private static final int COLOR_GREEN = Color.rgb(98, 232, 74);
    private static final int COLOR_PINK = Color.rgb(255, 59, 157);
    private static final int COLOR_CREAM = Color.rgb(255, 247, 214);
    private static final int COLOR_CYAN = Color.rgb(95, 245, 255);

    private static final String PREFS_NAME = "metro_rush";
    private static final String PREF_BEST_SCORE = "best_score";
    private static final String PREF_SOUND = "sound_enabled";

    private enum Mode {
        IDLE,
        RUNNING,
        PAUSED,
        GAME_OVER
    }

    private enum Kind {
        COIN,
        BARRIER,
        GATE,
        TRAIN
    }

    private static final class Entity {
        final Kind kind;
        final int lane;
        float z;
        boolean passed;

        Entity(Kind kind, int lane, float z) {
            this.kind = kind;
            this.lane = lane;
            this.z = z;
        }
    }

    private static final class Spark {
        float x;
        float y;
        float vx;
        float vy;
        float life;

        Spark(float x, float y, float vx, float vy) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            life = 1f;
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Path path = new Path();
    private final Rect bitmapSource = new Rect();
    private final RectF bitmapTarget = new RectF();
    private final RectF pauseButton = new RectF();
    private final RectF soundButton = new RectF();
    private final List<Entity> entities = new ArrayList<>();
    private final List<Spark> sparks = new ArrayList<>();
    private final Random random = new Random();
    private final SharedPreferences preferences;
    private final Bitmap backgroundBitmap;
    private final Bitmap runnerBitmap;
    private final Bitmap trainBitmap;
    private final ToneGenerator toneGenerator;
    private final float density;

    private Mode mode = Mode.IDLE;
    private int targetLane;
    private float laneVisual;
    private float jump;
    private float jumpVelocity;
    private float slideTimer;
    private float spawnTimer;
    private float speed;
    private float distance;
    private float flash;
    private float shake;
    private float trackOffset;
    private int coins;
    private int bestScore;
    private long previousFrameTime;
    private float touchStartX;
    private float touchStartY;
    private boolean trackingTouch;
    private boolean soundEnabled;

    public MetroRushView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        bestScore = preferences.getInt(PREF_BEST_SCORE, 0);
        soundEnabled = preferences.getBoolean(PREF_SOUND, true);

        backgroundBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.metro_background);
        runnerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.metro_runner);
        trainBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.metro_train);
        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 82);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        setFocusable(true);
        setFocusableInTouchMode(true);
        setContentDescription(context.getString(R.string.game_description));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        resetAttractScene();
    }

    public void resumeRendering() {
        previousFrameTime = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    public void pauseGame() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
        }
        invalidate();
    }

    public void release() {
        toneGenerator.release();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        long now = SystemClock.uptimeMillis();
        if (previousFrameTime == 0L) {
            previousFrameTime = now;
        }
        float dt = Math.min(0.034f, Math.max(0f, (now - previousFrameTime) / 1000f));
        previousFrameTime = now;

        if (mode == Mode.RUNNING) {
            updateGame(dt);
        } else {
            laneVisual += (targetLane - laneVisual) * Math.min(1f, dt * 8f);
        }
        updateSparks(dt);

        drawGeneratedBackground(canvas);
        drawSpeedLayer(canvas, now);
        drawEntities(canvas, now);
        drawRunner(canvas, now);
        drawSparks(canvas);
        drawHeaderAndHud(canvas);
        drawActionButtons(canvas);
        drawSwipeHint(canvas);
        if (mode != Mode.RUNNING) {
            drawOverlay(canvas);
        }

        postInvalidateOnAnimation();
    }

    private void updateGame(float dt) {
        distance += dt * (78f + speed * 100f);
        speed = Math.min(0.76f, 0.34f + distance / 3400f);
        trackOffset = (trackOffset + dt * speed * 1.25f) % 1f;
        laneVisual += (targetLane - laneVisual) * Math.min(1f, dt * 12f);
        flash = Math.max(0f, flash - dt * 3.2f);
        shake = Math.max(0f, shake - dt * 4.2f);

        if (jump > 0f || jumpVelocity > 0f) {
            jump += jumpVelocity * dt;
            jumpVelocity -= 5.2f * dt;
            if (jump <= 0f) {
                jump = 0f;
                jumpVelocity = 0f;
            }
        }
        slideTimer = Math.max(0f, slideTimer - dt);

        spawnTimer -= dt;
        if (spawnTimer <= 0f) {
            spawnWave();
            spawnTimer = Math.max(0.72f, 1.15f - speed * 0.36f);
        }

        for (Entity entity : entities) {
            entity.z += dt * speed;
            if (entity.passed || entity.z < 0.79f) {
                continue;
            }

            boolean sameLane = entity.lane == targetLane
                    && Math.abs(laneVisual - entity.lane) < 0.36f;

            if (entity.kind == Kind.COIN) {
                if (sameLane && entity.z < 1.04f) {
                    entity.passed = true;
                    coins += 1;
                    flash = 0.42f;
                    emitCoinSparks(entity.lane);
                    playSound(ToneGenerator.TONE_PROP_PROMPT, 55);
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                } else if (entity.z > 1.04f) {
                    entity.passed = true;
                }
                continue;
            }

            if (entity.z > 0.98f) {
                entity.passed = true;
                continue;
            }
            if (!sameLane) {
                continue;
            }

            boolean safe = (entity.kind == Kind.BARRIER && jump > 0.36f)
                    || (entity.kind == Kind.GATE && slideTimer > 0.08f);
            if (safe) {
                entity.passed = true;
                continue;
            }

            entity.passed = true;
            endRun();
            break;
        }

        Iterator<Entity> iterator = entities.iterator();
        while (iterator.hasNext()) {
            Entity entity = iterator.next();
            if (entity.passed || entity.z > 1.2f) {
                iterator.remove();
            }
        }
    }

    private void updateSparks(float dt) {
        Iterator<Spark> iterator = sparks.iterator();
        while (iterator.hasNext()) {
            Spark spark = iterator.next();
            spark.x += spark.vx * dt;
            spark.y += spark.vy * dt;
            spark.vy += 220f * dt;
            spark.life -= dt * 2.4f;
            if (spark.life <= 0f) {
                iterator.remove();
            }
        }
    }

    private void spawnWave() {
        int obstacleLane = random.nextInt(3) - 1;
        float roll = random.nextFloat();
        Kind obstacle = roll < 0.38f
                ? Kind.BARRIER
                : roll < 0.68f ? Kind.GATE : Kind.TRAIN;
        entities.add(new Entity(obstacle, obstacleLane, 0f));

        int firstSafeLane = obstacleLane == -1 ? 0 : -1;
        int secondSafeLane = obstacleLane == 1 ? 0 : 1;
        int coinLane = random.nextBoolean() ? firstSafeLane : secondSafeLane;
        for (int i = 0; i < 4; i += 1) {
            entities.add(new Entity(Kind.COIN, coinLane, -0.08f - i * 0.105f));
        }
    }

    private void startGame() {
        targetLane = 0;
        laneVisual = 0f;
        jump = 0f;
        jumpVelocity = 0f;
        slideTimer = 0f;
        spawnTimer = 0.72f;
        speed = 0.34f;
        distance = 0f;
        flash = 0f;
        shake = 0f;
        trackOffset = 0f;
        coins = 0;
        entities.clear();
        sparks.clear();
        mode = Mode.RUNNING;
        previousFrameTime = SystemClock.uptimeMillis();
        playSound(ToneGenerator.TONE_PROP_ACK, 130);
        announceForAccessibility("Metro Rush bermula");
    }

    private void resetAttractScene() {
        targetLane = 0;
        laneVisual = 0f;
        speed = 0.34f;
        entities.clear();
        entities.add(new Entity(Kind.TRAIN, -1, 0.28f));
        entities.add(new Entity(Kind.BARRIER, 1, 0.5f));
        entities.add(new Entity(Kind.COIN, 0, 0.2f));
        entities.add(new Entity(Kind.COIN, 0, 0.34f));
        entities.add(new Entity(Kind.COIN, 0, 0.48f));
    }

    private void endRun() {
        mode = Mode.GAME_OVER;
        shake = 1f;
        int score = getScore();
        if (score > bestScore) {
            bestScore = score;
            preferences.edit().putInt(PREF_BEST_SCORE, bestScore).apply();
        }
        playSound(ToneGenerator.TONE_SUP_ERROR, 340);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        announceForAccessibility("Larian tamat. Skor " + score);
    }

    private int getScore() {
        return (int) distance + coins * 35;
    }

    private void toggleMainAction() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
        } else if (mode == Mode.PAUSED) {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
            playSound(ToneGenerator.TONE_PROP_ACK, 80);
        }
        invalidate();
    }

    private void togglePause() {
        if (mode == Mode.RUNNING) {
            mode = Mode.PAUSED;
        } else if (mode == Mode.PAUSED) {
            mode = Mode.RUNNING;
            previousFrameTime = SystemClock.uptimeMillis();
            playSound(ToneGenerator.TONE_PROP_ACK, 80);
        }
        invalidate();
    }

    private boolean ensureRunning() {
        if (mode == Mode.IDLE || mode == Mode.GAME_OVER) {
            startGame();
            return false;
        }
        return mode == Mode.RUNNING;
    }

    private void actLeft() {
        if (ensureRunning()) {
            targetLane = Math.max(-1, targetLane - 1);
        }
    }

    private void actRight() {
        if (ensureRunning()) {
            targetLane = Math.min(1, targetLane + 1);
        }
    }

    private void actJump() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.001f) {
            jumpVelocity = 2.35f;
            slideTimer = 0f;
            playSound(ToneGenerator.TONE_PROP_BEEP, 85);
        }
    }

    private void actSlide() {
        if (!ensureRunning()) {
            return;
        }
        if (jump <= 0.12f) {
            slideTimer = 0.58f;
            playSound(ToneGenerator.TONE_PROP_BEEP2, 70);
        }
    }

    private void playSound(int tone, int durationMs) {
        if (soundEnabled) {
            toneGenerator.startTone(tone, durationMs);
        }
    }

    private void drawGeneratedBackground(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        float screenRatio = width / (float) height;
        float imageRatio = backgroundBitmap.getWidth() / (float) backgroundBitmap.getHeight();

        if (imageRatio > screenRatio) {
            int sourceWidth = Math.round(backgroundBitmap.getHeight() * screenRatio);
            int left = (backgroundBitmap.getWidth() - sourceWidth) / 2;
            bitmapSource.set(left, 0, left + sourceWidth, backgroundBitmap.getHeight());
        } else {
            int sourceHeight = Math.round(backgroundBitmap.getWidth() / screenRatio);
            int top = Math.max(0, (backgroundBitmap.getHeight() - sourceHeight) / 2);
            bitmapSource.set(0, top, backgroundBitmap.getWidth(),
                    Math.min(backgroundBitmap.getHeight(), top + sourceHeight));
        }

        float parallax = mode == Mode.RUNNING ? (trackOffset - 0.5f) * 7f * density : 0f;
        bitmapTarget.set(-3f * density, -3f * density + parallax,
                width + 3f * density, height + 7f * density + parallax);
        canvas.drawBitmap(backgroundBitmap, bitmapSource, bitmapTarget, paint);

        paint.setShader(new LinearGradient(
                0f,
                0f,
                0f,
                height,
                new int[]{
                        withAlpha(COLOR_INK, 80),
                        withAlpha(COLOR_INK, 8),
                        withAlpha(COLOR_INK, 42),
                        withAlpha(COLOR_INK, 110)
                },
                new float[]{0f, 0.35f, 0.72f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);
    }

    private void drawSpeedLayer(Canvas canvas, long now) {
        if (mode != Mode.RUNNING) {
            return;
        }
        int width = getWidth();
        int height = getHeight();
        float centerX = width / 2f;
        paint.setStrokeWidth(Math.max(2f, width * 0.004f));
        paint.setStrokeCap(Paint.Cap.ROUND);

        for (int i = 0; i < 12; i += 1) {
            float phase = ((now * 0.0005f * speed + i * 0.083f) % 1f);
            float y = height * (0.34f + phase * 0.62f);
            float spread = width * (0.06f + phase * 0.46f);
            int color = i % 3 == 0 ? COLOR_GREEN : i % 2 == 0 ? COLOR_YELLOW : COLOR_PINK;
            paint.setColor(withAlpha(color, (int) (35f + phase * 95f)));
            canvas.drawLine(centerX - spread, y, centerX - spread - width * 0.05f * phase,
                    y + height * 0.025f, paint);
            canvas.drawLine(centerX + spread, y, centerX + spread + width * 0.05f * phase,
                    y + height * 0.025f, paint);
        }
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawEntities(Canvas canvas, long now) {
        canvas.save();
        if (shake > 0f) {
            canvas.translate((float) Math.sin(now * 0.08f) * shake * 8f, 0f);
        }

        entities.sort(Comparator.comparingDouble(entity -> entity.z));
        for (Entity entity : entities) {
            if (entity.passed || entity.z < -0.02f || entity.z > 1.18f) {
                continue;
            }
            float x = projectX(entity.lane, entity.z);
            float y = projectY(entity.z);
            float scale = projectScale(entity.z);
            switch (entity.kind) {
                case COIN:
                    drawCoin(canvas, x, y, scale, now);
                    break;
                case BARRIER:
                    drawBarrier(canvas, x, y, scale);
                    break;
                case GATE:
                    drawGate(canvas, x, y, scale);
                    break;
                case TRAIN:
                    drawTrainSprite(canvas, x, y, scale);
                    break;
            }
        }
        canvas.restore();

        if (flash > 0f) {
            paint.setColor(withAlpha(COLOR_YELLOW, (int) (flash * 72f)));
            canvas.drawRect(0f, 0f, getWidth(), getHeight(), paint);
        }
    }

    private void drawTrainSprite(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.255f * scale;
        float ratio = trainBitmap.getHeight() / (float) trainBitmap.getWidth();
        float height = width * ratio;

        paint.setColor(withAlpha(Color.BLACK, 120));
        canvas.drawOval(x - width * 0.36f, y - height * 0.08f,
                x + width * 0.36f, y + height * 0.08f, paint);

        bitmapTarget.set(x - width / 2f, y - height, x + width / 2f, y);
        paint.setAlpha(255);
        canvas.drawBitmap(trainBitmap, null, bitmapTarget, paint);
    }

    private void drawRunner(Canvas canvas, long now) {
        float width = getWidth() * 0.35f;
        float ratio = runnerBitmap.getHeight() / (float) runnerBitmap.getWidth();
        float height = width * ratio;
        float x = getWidth() / 2f + laneVisual * getWidth() * 0.275f;
        float bob = mode == Mode.RUNNING ? (float) Math.sin(now * 0.018f) * 4f * density : 0f;
        float y = getHeight() * 0.92f - jump * getHeight() * 0.18f + bob;

        if (slideTimer > 0f) {
            height *= 0.58f;
            width *= 1.16f;
        }

        paint.setColor(withAlpha(Color.BLACK, 120));
        canvas.drawOval(x - width * 0.25f, y - height * 0.025f,
                x + width * 0.25f, y + height * 0.045f, paint);

        if (mode == Mode.RUNNING) {
            bitmapTarget.set(x - width * 0.54f, y - height - 8f * density,
                    x + width * 0.54f, y + 6f * density);
            paint.setAlpha(34);
            canvas.drawBitmap(runnerBitmap, null, bitmapTarget, paint);
        }

        bitmapTarget.set(x - width / 2f, y - height, x + width / 2f, y);
        paint.setAlpha(255);
        canvas.drawBitmap(runnerBitmap, null, bitmapTarget, paint);
    }

    private void drawCoin(Canvas canvas, float x, float y, float scale, long now) {
        float pulse = 0.94f + (float) Math.sin(now * 0.008f + y) * 0.06f;
        float radius = getWidth() * 0.042f * scale * pulse;

        paint.setShadowLayer(22f * scale, 0f, 0f, COLOR_YELLOW);
        paint.setColor(Color.rgb(255, 174, 0));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, radius * 0.16f));
        paint.setColor(Color.rgb(255, 245, 166));
        canvas.drawCircle(x, y - radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_YELLOW);
        drawStar(canvas, x, y - radius, radius * 0.54f, radius * 0.24f, paint);
    }

    private void drawBarrier(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.18f * scale;
        float height = width * 0.58f;
        canvas.save();
        canvas.translate(x, y - height);

        paint.setColor(withAlpha(Color.BLACK, 120));
        canvas.drawOval(-width * 0.55f, height * 0.42f, width * 0.55f, height * 0.68f, paint);

        paint.setShader(new LinearGradient(
                0f,
                -height / 2f,
                0f,
                height / 2f,
                new int[]{Color.WHITE, Color.rgb(180, 180, 195)},
                null,
                Shader.TileMode.CLAMP
        ));
        RectF body = new RectF(-width / 2f, -height / 2f, width / 2f, height / 2f);
        canvas.drawRoundRect(body, height * 0.14f, height * 0.14f, paint);
        paint.setShader(null);

        canvas.save();
        canvas.clipRect(body);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(height * 0.32f);
        paint.setColor(Color.rgb(225, 48, 80));
        for (float offset = -width; offset < width; offset += width * 0.4f) {
            canvas.drawLine(offset, height / 2f, offset + width * 0.36f, -height / 2f, paint);
        }
        canvas.restore();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, width * 0.045f));
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(body, height * 0.14f, height * 0.14f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(COLOR_YELLOW);
        canvas.drawCircle(-width * 0.4f, -height * 0.38f, width * 0.065f, paint);
        canvas.drawCircle(width * 0.4f, -height * 0.38f, width * 0.065f, paint);
        canvas.restore();
    }

    private void drawGate(Canvas canvas, float x, float y, float scale) {
        float width = getWidth() * 0.2f * scale;
        float height = width * 0.92f;
        canvas.save();
        canvas.translate(x, y);

        paint.setColor(withAlpha(Color.BLACK, 110));
        canvas.drawOval(-width * 0.52f, -height * 0.05f,
                width * 0.52f, height * 0.13f, paint);

        paint.setShader(new LinearGradient(
                -width / 2f,
                0f,
                width / 2f,
                0f,
                new int[]{COLOR_PURPLE, COLOR_PANEL, COLOR_PURPLE},
                null,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(-width / 2f, -height, -width / 2f + width * 0.13f,
                0f, 8f, 8f, paint);
        canvas.drawRoundRect(width / 2f - width * 0.13f, -height, width / 2f,
                0f, 8f, 8f, paint);
        RectF header = new RectF(-width / 2f, -height, width / 2f, -height * 0.66f);
        canvas.drawRoundRect(header, 10f, 10f, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, width * 0.04f));
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(header, 10f, 10f, paint);
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(Math.max(7f, width * 0.13f));
        textPaint.setColor(COLOR_YELLOW);
        canvas.drawText("TUNDUK", 0f, -height * 0.76f, textPaint);
        canvas.restore();
    }

    private void emitCoinSparks(int lane) {
        float x = projectX(lane, 0.9f);
        float y = projectY(0.9f);
        for (int i = 0; i < 10; i += 1) {
            float angle = (float) (Math.PI * 2d * i / 10d);
            float force = 70f + random.nextFloat() * 100f;
            sparks.add(new Spark(x, y, (float) Math.cos(angle) * force,
                    (float) Math.sin(angle) * force - 70f));
        }
    }

    private void drawSparks(Canvas canvas) {
        for (Spark spark : sparks) {
            paint.setColor(withAlpha(COLOR_YELLOW, (int) (spark.life * 255f)));
            canvas.drawCircle(spark.x, spark.y, 3f * density * spark.life, paint);
        }
    }

    private void drawHeaderAndHud(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        textPaint.setTextSize(width * 0.11f);
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(8f, 5f, 7f, COLOR_PURPLE);
        canvas.drawText("METRO RUSH", width / 2f, height * 0.085f, textPaint);
        textPaint.clearShadowLayer();

        float gap = width * 0.018f;
        float margin = width * 0.035f;
        float cardWidth = (width - margin * 2f - gap * 2f) / 3f;
        float cardHeight = height * 0.068f;
        float top = height * 0.105f;

        drawHudCard(canvas, new RectF(margin, top, margin + cardWidth, top + cardHeight),
                "SKOR", String.format(Locale.US, "%06d", getScore()), false);
        drawHudCard(canvas, new RectF(margin + cardWidth + gap, top,
                        margin + cardWidth * 2f + gap, top + cardHeight),
                "SYILING", String.valueOf(coins), true);
        drawHudCard(canvas, new RectF(margin + cardWidth * 2f + gap * 2f, top,
                        width - margin, top + cardHeight),
                "TERBAIK", String.format(Locale.US, "%06d", bestScore), false);
    }

    private void drawHudCard(Canvas canvas, RectF bounds, String label, String value, boolean coin) {
        paint.setColor(withAlpha(Color.rgb(8, 5, 15), 218));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(Color.rgb(145, 72, 214));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(COLOR_GREEN);
        textPaint.setTextSize(bounds.height() * 0.22f);
        canvas.drawText(label, bounds.centerX(), bounds.top + bounds.height() * 0.31f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setColor(COLOR_CREAM);
        textPaint.setTextSize(bounds.height() * 0.39f);
        String shownValue = coin ? "★ " + value : value;
        canvas.drawText(shownValue, bounds.centerX(), bounds.top + bounds.height() * 0.8f, textPaint);
    }

    private void drawActionButtons(Canvas canvas) {
        float size = getWidth() * 0.105f;
        float margin = getWidth() * 0.035f;
        float top = getHeight() * 0.02f;

        pauseButton.set(margin, top, margin + size, top + size);
        soundButton.set(getWidth() - margin - size, top, getWidth() - margin, top + size);
        drawMiniButton(canvas, pauseButton, mode == Mode.PAUSED ? "▶" : "Ⅱ",
                mode != Mode.IDLE && mode != Mode.GAME_OVER);
        drawMiniButton(canvas, soundButton, soundEnabled ? "SFX" : "OFF", true);
    }

    private void drawMiniButton(Canvas canvas, RectF bounds, String label, boolean enabled) {
        paint.setColor(withAlpha(COLOR_INK, enabled ? 225 : 150));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.5f);
        paint.setColor(enabled ? COLOR_PINK : withAlpha(COLOR_PINK, 80));
        canvas.drawRoundRect(bounds, 12f, 12f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(bounds.width() * (label.length() > 2 ? 0.24f : 0.38f));
        textPaint.setColor(enabled ? COLOR_YELLOW : withAlpha(COLOR_YELLOW, 90));
        drawTextCentered(canvas, label, bounds.centerX(), bounds.centerY(), textPaint);
    }

    private void drawSwipeHint(Canvas canvas) {
        if (mode == Mode.RUNNING) {
            return;
        }
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(getWidth() * 0.038f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 180));
        canvas.drawText("SWIPE  ←  ↑  ↓  →", getWidth() / 2f, getHeight() * 0.965f, textPaint);
    }

    private void drawOverlay(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        paint.setColor(withAlpha(Color.BLACK, 98));
        canvas.drawRect(0f, 0f, width, height, paint);

        float cardWidth = width * 0.84f;
        float cardHeight = height * 0.28f;
        RectF card = new RectF(
                (width - cardWidth) / 2f,
                height * 0.54f,
                (width + cardWidth) / 2f,
                height * 0.54f + cardHeight
        );

        paint.setColor(withAlpha(COLOR_INK, 242));
        paint.setShadowLayer(30f, 0f, 16f, Color.BLACK);
        canvas.drawRoundRect(card, 24f, 24f, paint);
        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_PINK);
        canvas.drawRoundRect(card, 24f, 24f, paint);
        paint.setStrokeWidth(2f);
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(card.left + 8f, card.top + 8f, card.right - 8f,
                card.bottom - 8f, 18f, 18f, paint);
        paint.setStyle(Paint.Style.FILL);

        String kicker;
        String title;
        String description;
        String action;
        if (mode == Mode.GAME_OVER) {
            kicker = "LARIAN TAMAT";
            title = "PECAHKAN REKOD!";
            description = "Swipe lebih awal dan fokus pada lorong selamat";
            action = "CUBA LAGI";
        } else if (mode == Mode.PAUSED) {
            kicker = "DIJEDA";
            title = "TARIK NAFAS.";
            description = "Ketuk untuk kembali ke landasan";
            action = "SAMBUNG";
        } else {
            kicker = "ENDLESS RUNNER 3 LORONG";
            title = "BERSEDIA MELURU?";
            description = "Kutip syiling • Elak tren • Teruskan larian";
            action = "MULA";
        }

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.06f);
        textPaint.setColor(COLOR_GREEN);
        canvas.drawText(kicker, card.centerX(), card.top + cardHeight * 0.16f, textPaint);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(Math.min(cardHeight * 0.17f, cardWidth * 0.09f));
        textPaint.setColor(COLOR_YELLOW);
        textPaint.setShadowLayer(5f, 4f, 5f, COLOR_PURPLE);
        canvas.drawText(title, card.centerX(), card.top + cardHeight * 0.38f, textPaint);
        textPaint.clearShadowLayer();

        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        textPaint.setTextSize(cardHeight * 0.045f);
        textPaint.setColor(withAlpha(COLOR_CREAM, 190));
        canvas.drawText(description, card.centerX(), card.top + cardHeight * 0.55f, textPaint);

        RectF actionButton = new RectF(
                card.centerX() - cardWidth * 0.27f,
                card.top + cardHeight * 0.66f,
                card.centerX() + cardWidth * 0.27f,
                card.top + cardHeight * 0.88f
        );
        paint.setColor(COLOR_GREEN);
        canvas.drawRoundRect(actionButton.left + 7f, actionButton.top + 8f,
                actionButton.right + 7f, actionButton.bottom + 8f, 13f, 13f, paint);
        paint.setColor(COLOR_YELLOW);
        canvas.drawRoundRect(actionButton, 13f, 13f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setColor(COLOR_INK);
        canvas.drawRoundRect(actionButton, 13f, 13f, paint);
        paint.setStyle(Paint.Style.FILL);

        textPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        textPaint.setTextSize(actionButton.height() * 0.44f);
        textPaint.setColor(COLOR_INK);
        drawTextCentered(canvas, action, actionButton.centerX(), actionButton.centerY(), textPaint);
    }

    private float projectX(float lane, float z) {
        float depth = clamp(z, 0f, 1.15f);
        float spread = getWidth() * (0.048f + 0.27f * pow(depth, 1.3f));
        return getWidth() / 2f + lane * spread;
    }

    private float projectY(float z) {
        float depth = clamp(z, 0f, 1.15f);
        float horizon = getHeight() * 0.35f;
        return horizon + pow(depth, 1.62f) * (getHeight() * 0.94f - horizon);
    }

    private float projectScale(float z) {
        float depth = clamp(z, 0f, 1.15f);
        return 0.18f + 1.08f * pow(depth, 1.42f);
    }

    private static float pow(float value, float power) {
        return (float) Math.pow(value, power);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(
                Math.max(0, Math.min(255, alpha)),
                Color.red(color),
                Color.green(color),
                Color.blue(color)
        );
    }

    private void drawStar(
            Canvas canvas,
            float x,
            float y,
            float outerRadius,
            float innerRadius,
            Paint starPaint
    ) {
        path.reset();
        for (int i = 0; i < 10; i += 1) {
            float radius = i % 2 == 0 ? outerRadius : innerRadius;
            double angle = -Math.PI / 2d + i * Math.PI / 5d;
            float px = x + (float) Math.cos(angle) * radius;
            float py = y + (float) Math.sin(angle) * radius;
            if (i == 0) {
                path.moveTo(px, py);
            } else {
                path.lineTo(px, py);
            }
        }
        path.close();
        canvas.drawPath(path, starPaint);
    }

    private static void drawTextCentered(
            Canvas canvas,
            String text,
            float centerX,
            float centerY,
            Paint paint
    ) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float baseline = centerY - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText(text, centerX, baseline, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = event.getX();
                touchStartY = event.getY();
                trackingTouch = true;
                return true;
            case MotionEvent.ACTION_UP:
                if (!trackingTouch) {
                    return false;
                }
                trackingTouch = false;
                handleTouchRelease(event.getX(), event.getY());
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                trackingTouch = false;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void handleTouchRelease(float endX, float endY) {
        if (pauseButton.contains(endX, endY)
                && mode != Mode.IDLE
                && mode != Mode.GAME_OVER) {
            togglePause();
            return;
        }
        if (soundButton.contains(endX, endY)) {
            soundEnabled = !soundEnabled;
            preferences.edit().putBoolean(PREF_SOUND, soundEnabled).apply();
            if (soundEnabled) {
                playSound(ToneGenerator.TONE_PROP_ACK, 90);
            }
            invalidate();
            return;
        }

        float dx = endX - touchStartX;
        float dy = endY - touchStartY;
        float threshold = 34f * density;

        if (mode != Mode.RUNNING) {
            toggleMainAction();
            return;
        }

        if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) {
            actJump();
            return;
        }
        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx < 0f) {
                actLeft();
            } else {
                actRight();
            }
        } else if (dy < 0f) {
            actJump();
        } else {
            actSlide();
        }
    }
}
