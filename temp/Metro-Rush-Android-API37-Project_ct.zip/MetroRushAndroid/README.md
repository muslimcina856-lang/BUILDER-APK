# Metro Rush untuk Android

Game endless runner Android asli dalam mod potret, dibina menggunakan Java dan Canvas Android.

## Identiti aplikasi

- Nama: Metro Rush
- Package / Application ID: com.metro.rush
- Orientasi: potret
- compileSdk: 37
- targetSdk: 37
- minSdk: 26
- Android Gradle Plugin: 9.3.0
- Gradle: 9.5.0
- Java: 17

## Ciri

- Tiga lorong dengan kawalan sentuhan dan swipe sahaja
- Swipe kiri atau kanan untuk menukar lorong
- Swipe ke atas untuk melompat
- Swipe ke bawah untuk gelongsor
- Tren 3D, penghadang, palang, syiling, skor dan rekod terbaik
- Aset latar, pelari, tren dan ikon aplikasi yang dijana khusus
- Kesan bunyi untuk mula, lompat, syiling, gelongsor dan pelanggaran
- Skrin penuh serta gaya metro retro neon
- Tiada Internet, akaun atau kebenaran sensitif diperlukan

## Cara buka

1. Pasang Android Studio Quail 3 atau lebih baharu.
2. Dalam SDK Manager, pasang Android 17 / API 37.
3. Buka folder projek ini.
4. Tunggu Gradle Sync selesai dan tekan Run.

Untuk membina APK debug:

    ./gradlew assembleDebug

APK akan terhasil di:

    app/build/outputs/apk/debug/app-debug.apk
