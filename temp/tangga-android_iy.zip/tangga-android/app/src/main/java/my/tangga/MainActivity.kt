package my.tangga

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import my.tangga.ui.BahasaSkrin
import my.tangga.ui.Gerak
import my.tangga.ui.LatarAurora
import my.tangga.ui.LevelSkrin
import my.tangga.ui.PetaSkrin
import my.tangga.ui.Warna

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AplikasiTangga() }
    }
}

private val skema = darkColorScheme(
    primary = Warna.Oker,
    background = Warna.Dasar,
    surface = Warna.Panel,
    onBackground = Warna.Dakwat,
    onSurface = Warna.Dakwat,
    error = Warna.Bata,
)

@Composable
fun AplikasiTangga(vm: TanggaViewModel = viewModel()) {
    val k by vm.keadaan.collectAsState()

    MaterialTheme(colorScheme = skema) {
        // Aurora hidup di bawah setiap skrin. Ia tidak pernah dibina semula
        // semasa navigasi, jadi gerakannya berterusan merentas peralihan.
        LatarAurora(Modifier.fillMaxSize()) {
            BackHandler(enabled = k.skrin != Skrin.BAHASA) {
                if (k.skrin == Skrin.LEVEL) vm.kePeta() else vm.tukarBahasa()
            }

            AnimatedContent(
                targetState = k.skrin,
                modifier = Modifier.fillMaxSize().systemBarsPadding(),
                transitionSpec = {
                    (fadeIn(Gerak.masa(Gerak.MASUK_MS)) +
                        scaleIn(Gerak.biasa(), initialScale = 0.97f)) togetherWith
                        (fadeOut(Gerak.masa(Gerak.KELUAR_MS)) +
                            scaleOut(Gerak.biasa(), targetScale = 1.02f))
                },
                label = "skrin",
            ) { skrin ->
                when (skrin) {
                    Skrin.BAHASA -> BahasaSkrin(k, vm::pilihBahasa)
                    Skrin.PETA -> PetaSkrin(
                        k = k,
                        padaBuka = vm::bukaLevel,
                        padaBukaBab = vm::bukaBab,
                        padaTukarBahasa = vm::tukarBahasa,
                    )
                    Skrin.LEVEL -> LevelSkrin(
                        k = k,
                        padaKembali = vm::kePeta,
                        padaKodUbah = vm::tetapkanKod,
                        padaTeksUbah = vm::tetapkanJawapanTeks,
                        padaJalan = vm::jalankan,
                        padaSemakRamal = vm::semakRamal,
                        padaPilih = vm::pilih,
                        padaPetunjuk = vm::bukaPetunjuk,
                        padaJawapan = vm::bukaJawapan,
                        padaSetSemula = vm::setSemula,
                        padaSebelum = vm::sebelum,
                        padaSeterusnya = vm::seterusnya,
                    )
                }
            }
        }
    }
}
