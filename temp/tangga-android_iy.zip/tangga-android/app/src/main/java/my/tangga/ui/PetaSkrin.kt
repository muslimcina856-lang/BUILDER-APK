package my.tangga.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Bab
import my.tangga.Keadaan
import my.tangga.Progres

@Composable
fun PetaSkrin(
    k: Keadaan,
    padaBuka: (Int) -> Unit,
    padaBukaBab: (Bab) -> Unit,
    padaTukarBahasa: () -> Unit,
) {
    var lompat by remember { mutableStateOf("") }
    var masuk by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { masuk = true }
    val siapSemua = k.progres.siap.size

    Column(Modifier.fillMaxSize()) {

        KacaChrome(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    Modifier
                        .clip(Bentuk.Cip)
                        .background(Warna.KacaIsiPekat, Bentuk.Cip)
                        .clickable { padaTukarBahasa() }
                        .padding(horizontal = 13.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        k.bahasa?.label ?: "Tangga",
                        color = Warna.Oker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                    )
                    Spacer(Modifier.width(7.dp))
                    Text("\u21c4", color = Warna.Senyap, fontSize = 11.sp)
                }
                Spacer(Modifier.width(10.dp))
                StatusEnjin(k.memanaskan, k.enjinPanas)
                Spacer(Modifier.weight(1f))
                Text(
                    "$siapSemua/${k.jumlahLevel}",
                    color = Warna.Dakwat,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
            }
        }

        if (k.memuat) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Eyebrow("Memuatkan enjin\u2026")
            }
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp),
        ) {
            item {
                Berperingkat(masuk, 0) {
                    KadSambung(k, lompat, { lompat = it }) { padaBuka(it) }
                }
            }

            item {
                AnimatedVisibility(
                    visible = k.kemajuan != null,
                    enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                    exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
                ) {
                    k.kemajuan?.let { PapanKemajuan(it) }
                }
            }

            item {
                AnimatedVisibility(
                    visible = k.ralatEnjin != null,
                    enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                    exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
                ) {
                    Nota(k.ralatEnjin.orEmpty(), merah = true)
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Eyebrow("${k.bab.size} bab \u00b7 ${k.jumlahLevel} level")
            }

            itemsIndexed(k.bab) { i, b ->
                Berperingkat(masuk, (i + 1).coerceAtMost(8)) {
                    BarisBab(b, k.progres, k.memuatLevel) { padaBukaBab(b) }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Nota(
                    "Mana-mana bab boleh dimasuki bila-bila. Tetapi di dalam bab tiada lompat " +
                        "\u2014 level seterusnya hanya terbuka selepas level semasa dijawab betul. " +
                        "Progres disimpan sebaik jawapan disahkan."
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun Berperingkat(masuk: Boolean, indeks: Int, kandungan: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = masuk,
        enter = fadeIn(Gerak.peringkat(indeks)) +
            slideInVertically(Gerak.peringkat(indeks)) { it / 5 },
        exit = fadeOut(Gerak.biasa()),
    ) { kandungan() }
}

@Composable
private fun KadSambung(
    k: Keadaan,
    lompat: String,
    padaLompatUbah: (String) -> Unit,
    padaBuka: (Int) -> Unit,
) {
    Kaca(Modifier.fillMaxWidth(), aksen = Warna.Oker) {
        Column {
            Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .width(104.dp)
                        .fillMaxHeight()
                        .background(Warna.OkerRedup),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "${k.progres.sekarang}",
                        color = Warna.Oker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                    )
                }
                Column(Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 18.dp)) {
                    Eyebrow("Sambung di sini")
                    Spacer(Modifier.height(5.dp))
                    Text(
                        k.bab.firstOrNull { k.progres.sekarang in it.dari..it.hingga }?.nama ?: "",
                        color = Warna.Dakwat,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 22.sp,
                    )
                }
            }
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
                Butang(
                    if (k.memuatLevel) "Memuat\u2026" else "Mula belajar",
                    Modifier.fillMaxWidth(),
                    utama = true,
                    hidup = !k.memuatLevel,
                ) { padaBuka(k.progres.sekarang) }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    BasicTextField(
                        value = lompat,
                        onValueChange = { padaLompatUbah(it.filter { c -> c.isDigit() }.take(5)) },
                        modifier = Modifier
                            .weight(1f)
                            .clip(Bentuk.Butang)
                            .background(Warna.Editor, Bentuk.Butang)
                            .padding(horizontal = 14.dp, vertical = 13.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(
                            color = Warna.Dakwat,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                        ),
                        cursorBrush = SolidColor(Warna.Oker),
                        decorationBox = { medan ->
                            if (lompat.isEmpty()) {
                                Text(
                                    "Lompat ke level",
                                    color = Warna.SenyapGelap,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                )
                            }
                            medan()
                        },
                    )
                    Butang("Pergi") {
                        val n = lompat.toIntOrNull() ?: 1
                        padaLompatUbah("")
                        padaBuka(n)
                    }
                }
            }
        }
    }
}

@Composable
private fun BarisBab(b: Bab, progres: Progres, sibuk: Boolean, padaKlik: () -> Unit) {
    val siap = progres.siapDalam(b)
    val sambung = progres.sambungDalam(b)
    val peratus = if (b.bilanganLevel == 0) 0 else siap * 100 / b.bilanganLevel

    val interaksi = remember { MutableInteractionSource() }
    val ditekan by interaksi.collectIsPressedAsState()
    val skala by animateFloatAsState(
        targetValue = if (ditekan && !sibuk) 0.98f else 1f,
        animationSpec = Gerak.pantas(),
        label = "bab",
    )
    val lebar by animateFloatAsState(
        targetValue = peratus / 100f,
        animationSpec = Gerak.lantun(),
        label = "kemajuanBab",
    )

    Kaca(
        modifier = Modifier
            .graphicsLayer(scaleX = skala, scaleY = skala)
            .fillMaxWidth()
            .clickable(enabled = !sibuk) { padaKlik() },
        bentuk = Bentuk.KadKecil,
        aksen = if (peratus == 100) Warna.Hijau else null,
    ) {
        Row(
            Modifier.padding(horizontal = 15.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "%02d".format(b.n),
                color = Warna.SenyapGelap,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                modifier = Modifier.width(30.dp),
            )
            Column(Modifier.weight(1f)) {
                Text(
                    b.nama,
                    color = Warna.Dakwat,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(9.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(Bentuk.Cip)
                        .background(Warna.KacaTepiGelap, Bentuk.Cip)
                ) {
                    if (lebar > 0f) {
                        Box(
                            Modifier
                                .fillMaxWidth(lebar.coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .background(
                                    if (peratus == 100) Warna.Hijau else Warna.Oker,
                                    Bentuk.Cip,
                                )
                        )
                    }
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(
                if (siap == 0) "mula" else if (peratus == 100) "siap" else "\u21b3 $sambung",
                color = when {
                    peratus == 100 -> Warna.Hijau
                    siap > 0 -> Warna.Oker
                    else -> Warna.SenyapGelap
                },
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
            )
        }
    }
}
