@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.graphics

import androidx.compose.ui.geometry.Offset


class Color(val nilai: Long) {
    fun copy(alpha: Float = 1f): Color = this
    companion object
}


interface Shape
val RectangleShape: Shape = object : Shape {}

interface Brush {
    companion object
}

class SolidColor(warna: Color) : Brush

// ---------------------------------------------------------------------



fun Brush.Companion.linearGradient(
    colors: List<Color>,
    start: Offset = Offset.Zero,
    end: Offset = Offset.Zero,
): Brush = object : Brush {}

fun Brush.Companion.verticalGradient(colors: List<Color>): Brush = object : Brush {}

fun Brush.Companion.horizontalGradient(colors: List<Color>): Brush = object : Brush {}

fun Brush.Companion.radialGradient(
    colors: List<Color>,
    center: Offset = Offset.Zero,
    radius: Float = 0f,
): Brush = object : Brush {}

fun androidx.compose.ui.Modifier.graphicsLayer(
    scaleX: Float = 1f,
    scaleY: Float = 1f,
    alpha: Float = 1f,
    translationX: Float = 0f,
    translationY: Float = 0f,
    rotationZ: Float = 0f,
): androidx.compose.ui.Modifier = this

// ---------------------------------------------------------------------
