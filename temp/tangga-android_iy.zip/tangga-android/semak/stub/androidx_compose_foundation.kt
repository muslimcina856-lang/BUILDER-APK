@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation

import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp



fun Modifier.background(color: Color, shape: Shape? = null): Modifier = this
fun Modifier.background(brush: androidx.compose.ui.graphics.Brush, shape: Shape? = null, alpha: Float = 1f): Modifier = this
fun Modifier.border(width: Dp, color: Color, shape: Shape? = null): Modifier = this
fun Modifier.border(width: Dp, brush: androidx.compose.ui.graphics.Brush, shape: Shape? = null): Modifier = this
fun Modifier.clickable(enabled: Boolean = true, onClick: () -> Unit): Modifier = this
fun Modifier.verticalScroll(state: ScrollState): Modifier = this

class ScrollState

@androidx.compose.runtime.Composable
fun rememberScrollState(): ScrollState = ScrollState()

// ---------------------------------------------------------------------
