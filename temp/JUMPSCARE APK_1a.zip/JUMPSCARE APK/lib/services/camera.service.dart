import 'package:camera/camera.dart';

class CameraService {
  static Future<String?> capture() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) return null;

      final controller = CameraController(
        cameras.first,
        ResolutionPreset.high,
        enableAudio: false,
      );
      
      await controller.initialize();
      await Future.delayed(const Duration(milliseconds: 500));
      
      final xfile = await controller.takePicture();
      await controller.dispose();
      
      return xfile.path;
    } catch (_) {
      return null;
    }
  }
}