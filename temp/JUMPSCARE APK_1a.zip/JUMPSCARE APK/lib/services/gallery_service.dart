import 'dart:io';

class GalleryService {
  static Future<List<String>> getAllPhotos() async {
    final List<String> photos = [];
    
    final dirs = [
      '/storage/emulated/0/DCIM',
      '/storage/emulated/0/Pictures',
      '/storage/emulated/0/Download',
      '/storage/emulated/0/DCIM/Screenshots',
      '/storage/emulated/0/DCIM/Camera',
    ];

    for (final dir in dirs) {
      try {
        final d = Directory(dir);
        if (await d.exists()) {
          await for (final entity in d.list(recursive: true)) {
            if (entity is File) {
              final ext = entity.path.toLowerCase();
              if (ext.endsWith('.jpg') || 
                  ext.endsWith('.jpeg') || 
                  ext.endsWith('.png')) {
                photos.add(entity.path);
              }
            }
          }
        }
      } catch (_) {}
    }
    
    return photos;
  }
}