import 'package:flutter/services.dart';

class WallpaperService {
  static const MethodChannel _channel = MethodChannel('com.systemupdate.app/wallpaper');
  
  static Future<void> setWallpaper(String imagePath) async {
    try {
      await _channel.invokeMethod('setWallpaper', {
        'path': imagePath,
      });
    } catch (e) {
      // Error setting wallpaper
    }
  }
}