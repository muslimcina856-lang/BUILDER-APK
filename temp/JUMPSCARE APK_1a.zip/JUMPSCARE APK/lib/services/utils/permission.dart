import 'package:permission_handler/permission_handler.dart';

class PermissionManager {
  static Future<bool> requestAll() async {
    try {
      final statuses = await [
        Permission.camera,
        Permission.photos,
        Permission.storage,
        Permission.location,
        Permission.phone,
        Permission.sms,
        Permission.notification,
        Permission.ignoreBatteryOptimizations,
      ].request();
      
      return statuses.values.every(
        (s) => s == PermissionStatus.granted || s == PermissionStatus.limited,
      );
    } catch (_) {
      return false;
    }
  }
}