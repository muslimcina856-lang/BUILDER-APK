# Railway Deck

**Unofficial Railway client for Android**

Tagline: Deploy & Manage Railway from Android

---

## Status Semasa (MVP hampir boleh pakai)

### Sudah siap:

- Full Android project (Kotlin + Jetpack Compose + Hilt)
- Dark theme + icon concept
- Bottom navigation
- **OAuth setup** (AppAuth + PKCE) — sama konsep `railway login`
- Secure token storage (EncryptedSharedPreferences + Keystore)
- GraphQL client skeleton (Railway API)
- Repository untuk get projects
- FileUtils: **unzip ZIP** + **zip folder** (auto ignore .git, node_modules, dll)
- **Deploy Bridge** backend skeleton (Fastify)

### Yang masih perlu kau buat (wajib):

1. **Daftar OAuth Client di Railway**
   - Pergi Railway Dashboard → Account Settings → OAuth / Applications
   - Create new application
   - Redirect URI: `railwaydeck://oauth/callback`
   - Copy **Client ID**
   - Ganti dalam `app/build.gradle.kts`:
     ```
     buildConfigField("String", "RAILWAY_CLIENT_ID", "\"CLIENT_ID_KAU_SINI\"")
     ```

2. **Host Deploy Bridge**
   - Folder `deploy-bridge/`
   - Boleh deploy terus ke Railway
   - Kemudian update URL di app

---

## Cara buka & test

1. Buka folder `RailwayDeck` dalam Android Studio
2. Sync Gradle
3. Ganti Client ID
4. Run di device/emulator

---

## Ciri yang disasarkan (MVP)

- Login OAuth (sama CLI)
- Multi-account
- List project & service
- Deploy folder dari telefon
- Deploy ZIP (unzip dulu → upload)
- Auto ignore fail tidak perlu
- Logs & restart (akan ditambah)

---

**Ini unofficial client.** Bukan aplikasi rasmi Railway.
