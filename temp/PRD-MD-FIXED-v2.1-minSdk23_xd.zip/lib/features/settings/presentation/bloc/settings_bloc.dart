import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:sqflite/sqflite.dart';
import '../../../../core/utils/mimo_key_manager.dart';
import '../../../../services/database_service.dart';
import '../../domain/entities/mimo_api_key.dart';
import '../../../chat/domain/repositories/chat_repository.dart';
import '../../../chat/data/repositories/chat_repository_impl.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override
  List<Object?> get props => [];
}

class LoadSettings extends SettingsEvent {}

/// Menambah kunci API MiMo AI baharu ke senarai fallback.
class AddApiKey extends SettingsEvent {
  final String rawKey;
  const AddApiKey(this.rawKey);
  @override
  List<Object?> get props => [rawKey];
}

/// Memadam satu kunci API mengikut id.
class DeleteApiKey extends SettingsEvent {
  final String keyId;
  const DeleteApiKey(this.keyId);
  @override
  List<Object?> get props => [keyId];
}

/// Menguji sambungan satu kunci API tertentu.
class TestApiKey extends SettingsEvent {
  final String keyId;
  const TestApiKey(this.keyId);
  @override
  List<Object?> get props => [keyId];
}

/// Menetapkan semula kunci yang ditanda `error` kembali kepada `active`.
class ReactivateApiKey extends SettingsEvent {
  final String keyId;
  const ReactivateApiKey(this.keyId);
  @override
  List<Object?> get props => [keyId];
}

/// Menukar pilihan tindakan apabila kunci API gagal: padam automatik,
/// atau simpan dengan penanda ralat.
class SetKeyErrorAction extends SettingsEvent {
  final KeyErrorAction action;
  const SetKeyErrorAction(this.action);
  @override
  List<Object?> get props => [action];
}

class UpdateDefaultModel extends SettingsEvent {
  final String model;
  const UpdateDefaultModel(this.model);
  @override
  List<Object?> get props => [model];
}

class ClearAllData extends SettingsEvent {}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class SettingsState extends Equatable {
  const SettingsState();
  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final List<MimoApiKey> apiKeys;
  final String defaultModel;
  final KeyErrorAction keyErrorAction;

  const SettingsLoaded({
    required this.apiKeys,
    required this.defaultModel,
    required this.keyErrorAction,
  });

  /// `true` jika sekurang-kurangnya satu kunci API wujud dalam senarai.
  bool get hasAnyKey => apiKeys.isNotEmpty;

  SettingsLoaded copyWith({
    List<MimoApiKey>? apiKeys,
    String? defaultModel,
    KeyErrorAction? keyErrorAction,
  }) {
    return SettingsLoaded(
      apiKeys: apiKeys ?? this.apiKeys,
      defaultModel: defaultModel ?? this.defaultModel,
      keyErrorAction: keyErrorAction ?? this.keyErrorAction,
    );
  }

  @override
  List<Object?> get props => [apiKeys, defaultModel, keyErrorAction];
}

class SettingsSaving extends SettingsState {}

class SettingsError extends SettingsState {
  final String message;
  const SettingsError(this.message);
  @override
  List<Object?> get props => [message];
}

class ApiTestResult extends SettingsState {
  final String keyId;
  final bool success;
  final String message;

  const ApiTestResult({
    required this.keyId,
    required this.success,
    required this.message,
  });

  @override
  List<Object?> get props => [keyId, success, message];
}

class DataCleared extends SettingsState {}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  final MimoKeyManager _keyManager;
  final DatabaseService _dbService;
  final ChatRepository _chatRepository;

  SettingsBloc({
    MimoKeyManager? keyManager,
    DatabaseService? dbService,
    ChatRepository? chatRepository,
  })  : _keyManager = keyManager ?? MimoKeyManager(),
        _dbService = dbService ?? DatabaseService(),
        _chatRepository = chatRepository ?? ChatRepositoryImpl(),
        super(SettingsInitial()) {
    on<LoadSettings>(_onLoadSettings);
    on<AddApiKey>(_onAddApiKey);
    on<DeleteApiKey>(_onDeleteApiKey);
    on<TestApiKey>(_onTestApiKey);
    on<ReactivateApiKey>(_onReactivateApiKey);
    on<SetKeyErrorAction>(_onSetKeyErrorAction);
    on<UpdateDefaultModel>(_onUpdateDefaultModel);
    on<ClearAllData>(_onClearAllData);
  }

  Future<void> _onLoadSettings(LoadSettings event, Emitter<SettingsState> emit) async {
    try {
      final List<MimoApiKey> apiKeys = await _keyManager.getAllKeys();
      final String defaultModel = await _loadDefaultModel();
      final KeyErrorAction keyErrorAction = await _keyManager.getKeyErrorAction();

      emit(SettingsLoaded(
        apiKeys: apiKeys,
        defaultModel: defaultModel,
        keyErrorAction: keyErrorAction,
      ));
    } catch (e) {
      emit(SettingsError('Gagal memuatkan tetapan: $e'));
    }
  }

  Future<String> _loadDefaultModel() async {
    try {
      final Database db = await _dbService.database;
      final List<Map<String, dynamic>> rows = await db.query(
        'settings',
        where: 'key = ?',
        whereArgs: ['default_model'],
        limit: 1,
      );
      if (rows.isNotEmpty) {
        return rows.first['value'] as String;
      }
    } catch (_) {
      // Jadual settings mungkin belum diisi lagi — guna lalai.
    }
    return 'mimo-v2.5';
  }

  Future<void> _onAddApiKey(AddApiKey event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    try {
      await _keyManager.addKey(event.rawKey);
      final List<MimoApiKey> updated = await _keyManager.getAllKeys();
      emit(currentState.copyWith(apiKeys: updated));
    } on DuplicateKeyException catch (e) {
      emit(SettingsError(e.message));
      add(LoadSettings());
    } on InvalidKeyException catch (e) {
      emit(SettingsError(e.message));
      add(LoadSettings());
    } catch (e) {
      emit(SettingsError('Gagal menambah kunci API: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onDeleteApiKey(DeleteApiKey event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    try {
      await _keyManager.deleteKey(event.keyId);
      final List<MimoApiKey> updated = await _keyManager.getAllKeys();
      emit(currentState.copyWith(apiKeys: updated));
    } catch (e) {
      emit(SettingsError('Gagal memadam kunci API: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onTestApiKey(TestApiKey event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    final MimoApiKey? targetKey = currentState.apiKeys
        .cast<MimoApiKey?>()
        .firstWhere((k) => k?.id == event.keyId, orElse: () => null);

    if (targetKey == null) return;

    try {
      final bool isValid = await _chatRepository.testApiConnection(targetKey.key);

      if (isValid) {
        await _keyManager.recordSuccess(targetKey.id);
        emit(ApiTestResult(
          keyId: targetKey.id,
          success: true,
          message: '${targetKey.label} sah dan berfungsi.',
        ));
      } else {
        emit(ApiTestResult(
          keyId: targetKey.id,
          success: false,
          message: '${targetKey.label} gagal disahkan. Sila semak kunci tersebut.',
        ));
      }
      add(LoadSettings());
    } catch (e) {
      emit(ApiTestResult(
        keyId: targetKey.id,
        success: false,
        message: 'Ralat menguji ${targetKey.label}: $e',
      ));
      add(LoadSettings());
    }
  }

  Future<void> _onReactivateApiKey(ReactivateApiKey event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is! SettingsLoaded) return;

    try {
      await _keyManager.reactivateKey(event.keyId);
      final List<MimoApiKey> updated = await _keyManager.getAllKeys();
      emit(currentState.copyWith(apiKeys: updated));
    } catch (e) {
      emit(SettingsError('Gagal mengaktifkan semula kunci: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onSetKeyErrorAction(SetKeyErrorAction event, Emitter<SettingsState> emit) async {
    await _keyManager.setKeyErrorAction(event.action);
    final SettingsState currentState = state;
    if (currentState is SettingsLoaded) {
      emit(currentState.copyWith(keyErrorAction: event.action));
    }
  }

  Future<void> _onUpdateDefaultModel(UpdateDefaultModel event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is SettingsLoaded) {
      try {
        final Database db = await _dbService.database;
        await db.insert(
          'settings',
          {'key': 'default_model', 'value': event.model},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
        emit(currentState.copyWith(defaultModel: event.model));
      } catch (e) {
        emit(SettingsError('Gagal menukar model lalai: $e'));
      }
    }
  }

  Future<void> _onClearAllData(ClearAllData event, Emitter<SettingsState> emit) async {
    emit(SettingsSaving());
    try {
      // Padam semua kunci API MiMo AI tersimpan
      await _keyManager.clearAll();

      // Padam database SQLite
      await _dbService.deleteAllSessions();

      // Padam settings kustom & skills
      final Database db = await _dbService.database;
      await db.delete('ai_skills');
      await db.delete('settings');

      emit(DataCleared());
      add(LoadSettings());
    } catch (e) {
      emit(SettingsError('Gagal memadam semua data: $e'));
    }
  }
}
