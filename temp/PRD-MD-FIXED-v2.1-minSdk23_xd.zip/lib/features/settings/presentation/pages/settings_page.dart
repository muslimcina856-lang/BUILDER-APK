import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/mimo_key_manager.dart';
import '../../domain/entities/mimo_api_key.dart';
import '../bloc/settings_bloc.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _newKeyController = TextEditingController();

  @override
  void dispose() {
    _newKeyController.dispose();
    super.dispose();
  }

  void _handleAddKey(BuildContext context) {
    final String rawKey = _newKeyController.text.trim();
    if (rawKey.isEmpty) return;

    context.read<SettingsBloc>().add(AddApiKey(rawKey));
    _newKeyController.clear();
    FocusScope.of(context).unfocus();
  }

  void _showKeyErrorDialog(BuildContext context, MimoApiKey key) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: AppColors.error),
              const SizedBox(width: 8),
              Text('${key.label} Bermasalah'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                key.lastErrorReason ?? 'Sebab tidak direkodkan.',
                style: const TextStyle(color: AppColors.textMuted),
              ),
              if (key.lastErrorAt != null) ...[
                const SizedBox(height: 8),
                Text(
                  'Kali terakhir: ${_formatDateTime(key.lastErrorAt!)}',
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<SettingsBloc>().add(ReactivateApiKey(key.id));
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent),
              child: const Text('Aktifkan Semula'),
            ),
          ],
        );
      },
    );
  }

  void _confirmDeleteKey(BuildContext context, MimoApiKey key) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Padam Kunci API?'),
          content: Text(
            'Adakah anda pasti mahu memadam ${key.label} (${key.maskedKey})? '
            'Tindakan ini tidak boleh dibatalkan.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<SettingsBloc>().add(DeleteApiKey(key.id));
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  void _confirmDeleteAll(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: AppColors.error),
              SizedBox(width: 8),
              Text('Danger Zone: Padam Semua?'),
            ],
          ),
          content: const Text(
            'Adakah anda benar-benar pasti mahu memadamkan semua rekod sembang, '
            'kunci API, dan tetapan dari peranti secara kekal? Tindakan ini tidak boleh diundurkan.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<SettingsBloc>().add(ClearAllData());
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Ya, Padam Semua'),
            ),
          ],
        );
      },
    );
  }

  String _formatDateTime(DateTime dt) {
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SettingsBloc, SettingsState>(
      listener: (context, state) {
        if (state is ApiTestResult) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: state.success ? AppColors.success : AppColors.error,
              duration: const Duration(seconds: 4),
            ),
          );
        } else if (state is DataCleared) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Semua data peranti telah dipadamkan secara kekal.'),
              backgroundColor: AppColors.error,
            ),
          );
        } else if (state is SettingsError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: AppColors.error,
            ),
          );
        }
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            tooltip: 'Kembali',
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text(
            AppStrings.titleSettings,
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppColors.scaffold.withOpacity(0.9),
                  AppColors.scaffold.withOpacity(0.0),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: AppColors.backgroundGradient,
          ),
          child: BlocBuilder<SettingsBloc, SettingsState>(
            builder: (context, state) {
              List<MimoApiKey> apiKeys = [];
              String defaultModel = 'mimo-v2.5';
              KeyErrorAction keyErrorAction = KeyErrorAction.keepWithMarker;

              if (state is SettingsLoaded) {
                apiKeys = state.apiKeys;
                defaultModel = state.defaultModel;
                keyErrorAction = state.keyErrorAction;
              }

              return SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ─── Kunci API MiMo AI (Multi-Key) ─────────────────
                      _buildSectionHeader('Kunci API MiMo AI', Icons.vpn_key_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Anda boleh mendaftar berbilang kunci API. Apabila satu kunci '
                              'kehabisan kredit atau ralat berulang, sistem akan beralih '
                              'secara automatik ke kunci seterusnya.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                            ),
                            const SizedBox(height: 16),
                            if (apiKeys.isEmpty)
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                child: Text(
                                  'Belum ada kunci API didaftarkan.',
                                  style: TextStyle(color: AppColors.textMuted.withOpacity(0.7), fontSize: 13),
                                ),
                              )
                            else
                              ...apiKeys.map((key) => _buildKeyListTile(context, key)),
                            const Divider(color: AppColors.cardBorder, height: 24),
                            Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    controller: _newKeyController,
                                    style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
                                    decoration: const InputDecoration(
                                      hintText: 'Tampal kunci API baharu...',
                                      prefixIcon: Icon(Icons.add_circle_outline, color: AppColors.accent),
                                      isDense: true,
                                    ),
                                    onSubmitted: (_) => _handleAddKey(context),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: () => _handleAddKey(context),
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                                  ),
                                  child: const Text('Tambah'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // ─── Tindakan Bila Kunci Bermasalah ─────────────────
                      _buildSectionHeader('Tindakan Bila Kunci Bermasalah', Icons.rule_rounded),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Pilih apa yang berlaku apabila satu kunci API kehabisan '
                              'kredit atau gagal berulang kali.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                            ),
                            const SizedBox(height: 12),
                            RadioListTile<KeyErrorAction>(
                              contentPadding: EdgeInsets.zero,
                              title: const Text('Simpan dengan penanda'),
                              subtitle: const Text(
                                'Kunci kekal dalam senarai dengan ikon amaran, senang dikenal pasti',
                                style: TextStyle(fontSize: 12),
                              ),
                              value: KeyErrorAction.keepWithMarker,
                              groupValue: keyErrorAction,
                              activeColor: AppColors.accent,
                              onChanged: (val) {
                                if (val != null) {
                                  context.read<SettingsBloc>().add(SetKeyErrorAction(val));
                                }
                              },
                            ),
                            RadioListTile<KeyErrorAction>(
                              contentPadding: EdgeInsets.zero,
                              title: const Text('Padam automatik'),
                              subtitle: const Text(
                                'Kunci terus dibuang daripada senarai apabila bermasalah',
                                style: TextStyle(fontSize: 12),
                              ),
                              value: KeyErrorAction.autoDelete,
                              groupValue: keyErrorAction,
                              activeColor: AppColors.accent,
                              onChanged: (val) {
                                if (val != null) {
                                  context.read<SettingsBloc>().add(SetKeyErrorAction(val));
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // ─── Konfigurasi Model Lalai ─────────────────────────
                      _buildSectionHeader('Konfigurasi Model Lalai', Icons.psychology_outlined),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Pilih model MiMo AI lalai untuk setiap perbualan baru. '
                              'Model ini akan dikunci apabila sembang dimulakan.',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                _buildModelOption(
                                  title: 'MiMo Flash',
                                  subtitle: 'Pantas & Jimat',
                                  model: 'mimo-v2.5',
                                  selected: defaultModel == 'mimo-v2.5',
                                  onTap: () {
                                    context.read<SettingsBloc>().add(
                                          const UpdateDefaultModel('mimo-v2.5'),
                                        );
                                  },
                                ),
                                const SizedBox(width: 12),
                                _buildModelOption(
                                  title: 'MiMo Pro',
                                  subtitle: 'Penaakulan Khas',
                                  model: 'mimo-v2.5-pro',
                                  selected: defaultModel == 'mimo-v2.5-pro',
                                  onTap: () {
                                    context.read<SettingsBloc>().add(
                                          const UpdateDefaultModel('mimo-v2.5-pro'),
                                        );
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // ─── Danger Zone ──────────────────────────────────────
                      _buildSectionHeader('Danger Zone', Icons.report_problem_outlined, color: AppColors.error),
                      const SizedBox(height: 12),
                      _buildGlassCard(
                        borderColor: AppColors.error.withOpacity(0.3),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Padamkan semua rekod sembang, kunci API, dan tetapan kustom dari peranti secara kekal.',
                                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                              ),
                            ),
                            const SizedBox(width: 16),
                            ElevatedButton(
                              onPressed: () => _confirmDeleteAll(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.error,
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                              ),
                              child: const Text('Padam Semua'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildKeyListTile(BuildContext context, MimoApiKey key) {
    final bool hasError = key.status == MimoKeyStatus.error;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.scaffold,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: Text(
              '${key.order}',
              style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              key.maskedKey,
              style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
            ),
          ),
          if (hasError)
            IconButton(
              icon: const Icon(Icons.warning_amber_rounded, color: AppColors.error, size: 20),
              tooltip: 'Lihat sebab ralat',
              onPressed: () => _showKeyErrorDialog(context, key),
            ),
          IconButton(
            icon: const Icon(Icons.network_ping, color: AppColors.accent, size: 20),
            tooltip: 'Uji Sambungan',
            onPressed: () {
              context.read<SettingsBloc>().add(TestApiKey(key.id));
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            tooltip: 'Padam',
            onPressed: () => _confirmDeleteKey(context, key),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, {Color color = AppColors.textPrimary}) {
    return Row(
      children: [
        Icon(icon, color: color == AppColors.textPrimary ? AppColors.accent : color, size: 20),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.inter(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: color,
            letterSpacing: 0.5,
          ),
        ),
      ],
    ).animate().fadeIn(duration: 300.ms).slideX(begin: -0.1, end: 0);
  }

  Widget _buildGlassCard({required Widget child, Color borderColor = AppColors.cardBorder}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    ).animate().fadeIn(duration: 400.ms).scaleY(begin: 0.9, end: 1.0);
  }

  Widget _buildModelOption({
    required String title,
    required String subtitle,
    required String model,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.accent.withOpacity(0.15) : AppColors.scaffold,
            borderRadius: BorderRadius.circular(AppTheme.radiusSm),
            border: Border.all(
              color: selected ? AppColors.accent : AppColors.cardBorder,
              width: selected ? 1.5 : 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.inter(
                      fontWeight: FontWeight.bold,
                      color: selected ? Colors.white : AppColors.textPrimary,
                      fontSize: 14,
                    ),
                  ),
                  if (selected)
                    const Icon(Icons.check_circle, color: AppColors.accent, size: 16),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  color: selected ? Colors.white.withOpacity(0.7) : AppColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}