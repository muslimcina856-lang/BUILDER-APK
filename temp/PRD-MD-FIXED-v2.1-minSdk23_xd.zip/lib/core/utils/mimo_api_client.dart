import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';

/// MiMo AI API client (Xiaomi MiMo) with SSE streaming support for chat,
/// and non-streaming audio synthesis for voice cloning.
///
/// Endpoint reference: https://mimo.mi.com/docs (chat completions is
/// OpenAI-SDK compatible; auth uses the `api-key` header, not
/// `Authorization: Bearer`).
class MimoApiClient {
  static const String _baseUrl = 'https://api.xiaomimimo.com/v1';
  static const double _temperature = 0.2;

  /// Model model ID untuk teks/chat (penjanaan PRD & README).
  static const String modelFlash = 'mimo-v2.5';
  static const String modelPro = 'mimo-v2.5-pro';

  /// Model ID untuk sintesis suara klon (voice cloning).
  static const String modelVoiceClone = 'mimo-v2.5-tts-voiceclone';

  final Dio _dio;
  final String _apiKey;
  final String _model;

  CancelToken? _activeCancelToken;

  /// Creates a new [MimoApiClient].
  ///
  /// [apiKey] – MiMo AI API key for authentication.
  /// [model] – Model identifier (e.g. [modelFlash], [modelPro]).
  MimoApiClient({
    required String apiKey,
    String model = modelFlash,
    Dio? dio,
  })  : _apiKey = apiKey,
        _model = model,
        _dio = dio ??
            Dio(
              BaseOptions(
                baseUrl: _baseUrl,
                connectTimeout: const Duration(seconds: 30),
                receiveTimeout: const Duration(minutes: 5),
                headers: <String, dynamic>{
                  'Content-Type': 'application/json',
                  'Accept': 'text/event-stream',
                },
              ),
            );

  /// Sends a chat message to MiMo AI and returns a [Stream] of content tokens.
  ///
  /// When [stream] is `true` (default), responses are streamed via SSE.
  /// When `false`, the full response is awaited and returned as a single chunk.
  Stream<String> sendChatMessage(
    List<Map<String, String>> messages, {
    bool stream = true,
  }) {
    if (stream) {
      return _streamChat(messages);
    }
    return _nonStreamChat(messages);
  }

  /// Streams SSE chunks from the MiMo `/chat/completions` endpoint.
  Stream<String> _streamChat(List<Map<String, String>> messages) async* {
    _activeCancelToken?.cancel('New request started');
    _activeCancelToken = CancelToken();

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': _model,
      'messages': messages,
      'temperature': _temperature,
      'stream': true,
    };

    Response<ResponseBody> response;

    try {
      response = await _dio.post<ResponseBody>(
        '/chat/completions',
        data: payload,
        options: Options(
          responseType: ResponseType.stream,
          headers: <String, dynamic>{
            'api-key': _apiKey,
          },
        ),
        cancelToken: _activeCancelToken,
      );
    } on DioException catch (e) {
      yield* _handleDioError(e);
      return;
    }

    final ResponseBody? body = response.data;
    if (body == null) {
      yield '[ERROR] Tiada data diterima daripada pelayan.';
      return;
    }

    // Buffer for incomplete SSE lines across chunks.
    String buffer = '';

    await for (final List<int> chunk in body.stream) {
      if (_activeCancelToken?.isCancelled ?? false) break;

      buffer += utf8.decode(chunk, allowMalformed: true);

      // Split by double-newline (SSE event boundary) or single newline.
      final List<String> lines = buffer.split('\n');

      // Keep the last element in buffer in case it's an incomplete line.
      buffer = lines.removeLast();

      for (final String line in lines) {
        final String trimmed = line.trim();
        if (trimmed.isEmpty) continue;

        if (!trimmed.startsWith('data:')) continue;

        final String data = trimmed.substring(5).trim();

        if (data == '[DONE]') return;

        try {
          final Map<String, dynamic> json =
              jsonDecode(data) as Map<String, dynamic>;

          final List<dynamic>? choices =
              json['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) continue;

          final Map<String, dynamic> choice =
              choices.first as Map<String, dynamic>;

          final Map<String, dynamic>? delta =
              choice['delta'] as Map<String, dynamic>?;
          if (delta == null) continue;

          final String? reasoning =
              delta['reasoning_content'] as String?;
          if (reasoning != null && reasoning.isNotEmpty) {
            yield reasoning;
          }

          final String? content = delta['content'] as String?;
          if (content != null && content.isNotEmpty) {
            yield content;
          }
        } on FormatException {
          // Malformed JSON – skip this chunk silently.
          continue;
        }
      }
    }

    // Process any remaining buffer content.
    if (buffer.trim().isNotEmpty) {
      final String trimmed = buffer.trim();
      if (trimmed.startsWith('data:')) {
        final String data = trimmed.substring(5).trim();
        if (data != '[DONE]') {
          try {
            final Map<String, dynamic> json =
                jsonDecode(data) as Map<String, dynamic>;
            final List<dynamic>? choices =
                json['choices'] as List<dynamic>?;
            if (choices != null && choices.isNotEmpty) {
              final Map<String, dynamic> choice =
                  choices.first as Map<String, dynamic>;
              final Map<String, dynamic>? delta =
                  choice['delta'] as Map<String, dynamic>?;
              if (delta != null) {
                final String? content = delta['content'] as String?;
                if (content != null && content.isNotEmpty) {
                  yield content;
                }
              }
            }
          } on FormatException {
            // Ignore trailing malformed data.
          }
        }
      }
    }
  }

  /// Non-streaming completion – returns the full message at once.
  Stream<String> _nonStreamChat(
      List<Map<String, String>> messages) async* {
    _activeCancelToken?.cancel('New request started');
    _activeCancelToken = CancelToken();

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': _model,
      'messages': messages,
      'temperature': _temperature,
      'stream': false,
    };

    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '/chat/completions',
        data: payload,
        options: Options(
          headers: <String, dynamic>{
            'api-key': _apiKey,
          },
        ),
        cancelToken: _activeCancelToken,
      );

      final Map<String, dynamic>? body = response.data;
      if (body == null) {
        yield '[ERROR] Tiada data diterima daripada pelayan.';
        return;
      }

      final List<dynamic>? choices =
          body['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) {
        yield '[ERROR] Tiada jawapan dijana oleh model.';
        return;
      }

      final Map<String, dynamic> choice =
          choices.first as Map<String, dynamic>;
      final Map<String, dynamic>? message =
          choice['message'] as Map<String, dynamic>?;

      final String content =
          (message?['content'] as String?) ?? '';
      if (content.isNotEmpty) {
        yield content;
      }
    } on DioException catch (e) {
      yield* _handleDioError(e);
    }
  }

  /// Menjana audio suara klon menggunakan model [modelVoiceClone].
  ///
  /// [text] – Teks yang perlu disebut (diletakkan pada `role: assistant`
  /// mengikut keperluan API MiMo — teks TIDAK boleh diletakkan pada
  /// `role: user`).
  /// [referenceAudioBase64] – Data audio rujukan (sampel suara asal untuk
  /// diklon) sebagai base64 tulen (TANPA prefix data URI).
  /// [referenceMimeType] – MIME type sampel audio rujukan, cth
  /// `audio/mpeg` atau `audio/wav`.
  /// [styleInstruction] – Arahan gaya pertuturan pilihan (natural language),
  /// diletakkan pada `role: user`. Boleh dibiarkan kosong.
  /// [outputFormat] – Format audio output yang diminta (`wav` lalai).
  ///
  /// Memulangkan bytes audio mentah (telah di-decode daripada base64)
  /// yang sedia untuk ditulis ke fail.
  ///
  /// Nota: streaming untuk model voiceclone belum disokong oleh MiMo AI
  /// setakat dokumentasi terkini, jadi kaedah ini sentiasa membuat
  /// panggilan tanpa strim (non-streaming).
  Future<List<int>> synthesizeVoiceClone({
    required String text,
    required String referenceAudioBase64,
    required String referenceMimeType,
    String styleInstruction = '',
    String outputFormat = 'wav',
  }) async {
    final String voiceDataUri =
        'data:$referenceMimeType;base64,$referenceAudioBase64';

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': modelVoiceClone,
      'messages': <Map<String, String>>[
        <String, String>{
          'role': 'user',
          'content': styleInstruction,
        },
        <String, String>{
          'role': 'assistant',
          'content': text,
        },
      ],
      'audio': <String, String>{
        'format': outputFormat,
        'voice': voiceDataUri,
      },
    };

    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '/chat/completions',
        data: payload,
        options: Options(
          headers: <String, dynamic>{
            'api-key': _apiKey,
          },
          // Sintesis suara klon boleh ambil masa lebih lama daripada chat.
          receiveTimeout: const Duration(minutes: 3),
        ),
      );

      final Map<String, dynamic>? body = response.data;
      if (body == null) {
        throw const MimoVoiceCloneException(
          'Tiada data diterima daripada pelayan MiMo AI.',
        );
      }

      final List<dynamic>? choices = body['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) {
        throw const MimoVoiceCloneException(
          'Tiada audio dijana oleh model. Sila cuba semula.',
        );
      }

      final Map<String, dynamic> choice =
          choices.first as Map<String, dynamic>;
      final Map<String, dynamic>? message =
          choice['message'] as Map<String, dynamic>?;
      final Map<String, dynamic>? audio =
          message?['audio'] as Map<String, dynamic>?;
      final String? audioDataBase64 = audio?['data'] as String?;

      if (audioDataBase64 == null || audioDataBase64.isEmpty) {
        throw const MimoVoiceCloneException(
          'Respons tidak mengandungi data audio yang sah.',
        );
      }

      return base64Decode(audioDataBase64);
    } on DioException catch (e) {
      final int? statusCode = e.response?.statusCode;
      throw MimoVoiceCloneException(_mapDioErrorToMessage(e, statusCode));
    }
  }

  /// Tests whether the API key is valid by sending a minimal request.
  ///
  /// Returns `true` if the API responds successfully, `false` otherwise.
  Future<bool> testConnection() async {
    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '/chat/completions',
        data: <String, dynamic>{
          'model': _model,
          'messages': <Map<String, String>>[
            <String, String>{
              'role': 'user',
              'content': 'Hi',
            },
          ],
          'temperature': _temperature,
          'stream': false,
          'max_tokens': 5,
        },
        options: Options(
          headers: <String, dynamic>{
            'api-key': _apiKey,
          },
          receiveTimeout: const Duration(seconds: 15),
        ),
      );

      return response.statusCode == 200;
    } on DioException {
      return false;
    } catch (_) {
      return false;
    }
  }

  /// Cancels any active streaming request.
  void cancelActiveRequest() {
    _activeCancelToken?.cancel('Request cancelled by user');
    _activeCancelToken = null;
  }

  /// Releases resources held by the Dio instance.
  void dispose() {
    cancelActiveRequest();
    _dio.close(force: true);
  }

  /// Maps [DioException] to user-friendly error messages in Bahasa Melayu.
  Stream<String> _handleDioError(DioException e) async* {
    if (e.type == DioExceptionType.cancel) {
      // Cancelled deliberately – no error to surface.
      return;
    }
    yield '[ERROR] ${_mapDioErrorToMessage(e, e.response?.statusCode)}';
  }

  String _mapDioErrorToMessage(DioException e, int? statusCode) {
    switch (statusCode) {
      case 401:
        return 'Kunci API MiMo AI tidak sah atau telah tamat tempoh.';
      case 402:
        return 'Kredit akaun MiMo AI telah habis.';
      case 429:
        return 'Had kadar API MiMo AI telah dicapai. Sila tunggu sebentar.';
      case 500:
        return 'Ralat pelayan MiMo AI (500). Sila cuba lagi kemudian.';
      case 502:
        return 'Pelayan MiMo AI tidak tersedia (502). Sila cuba lagi kemudian.';
      case 503:
        return 'Perkhidmatan MiMo AI sedang penyelenggaraan (503).';
      default:
        if (e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.sendTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          return 'Sambungan tamat masa. Sila semak sambungan internet anda.';
        } else if (e.type == DioExceptionType.connectionError) {
          return 'Gagal menyambung ke pelayan. Sila semak sambungan internet anda.';
        }
        return 'Ralat tidak dijangka: ${e.message ?? 'Tiada maklumat lanjut.'}';
    }
  }
}

/// Dilontar apabila sintesis suara klon MiMo AI gagal.
class MimoVoiceCloneException implements Exception {
  final String message;
  const MimoVoiceCloneException(this.message);
  @override
  String toString() => message;
}
