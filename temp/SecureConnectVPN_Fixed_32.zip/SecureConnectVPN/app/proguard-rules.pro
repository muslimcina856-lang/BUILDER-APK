# OkHttp3 rules
-keepattributes Signature
-keepattributes *Annotation*
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-dontwarn okhttp3.**

# Okio rules
-dontwarn okio.**

# JSON rules
-keep class org.json.** { *; }

# Gson rules (if used later)
-keep class com.google.gson.** { *; }
