const String BaseUrl = "http://dapzyprivate.pteroq.biz.id:10002";
