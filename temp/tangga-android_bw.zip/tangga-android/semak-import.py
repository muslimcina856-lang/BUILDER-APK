#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Menyemak setiap import Compose menunjuk pakej yang betul.

Wujud kerana binaan pertama gagal 14 kali dengan satu punca: `RectangleShape`
diimport dari `androidx.compose.foundation.shape` (yang hanya mengandungi bentuk
bersudut bulat) sedangkan ia sebenarnya dalam `androidx.compose.ui.graphics`.

Jalankan sebelum commit:  python3 semak-import.py
"""

import pathlib
import re
import sys

# Simbol yang mudah disalah-import. Kunci = nama simbol, nilai = pakej sebenar.
PAKEJ = {
    # ui.graphics — bukan foundation.shape
    "Color": "androidx.compose.ui.graphics",
    "SolidColor": "androidx.compose.ui.graphics",
    "RectangleShape": "androidx.compose.ui.graphics",
    "Brush": "androidx.compose.ui.graphics",
    "Shape": "androidx.compose.ui.graphics",
    # foundation.shape — bentuk bersudut sahaja
    "RoundedCornerShape": "androidx.compose.foundation.shape",
    "CircleShape": "androidx.compose.foundation.shape",
    "CutCornerShape": "androidx.compose.foundation.shape",
    # ui teras
    "Modifier": "androidx.compose.ui",
    "Alignment": "androidx.compose.ui",
    # teks
    "AnnotatedString": "androidx.compose.ui.text",
    "SpanStyle": "androidx.compose.ui.text",
    "TextStyle": "androidx.compose.ui.text",
    "buildAnnotatedString": "androidx.compose.ui.text",
    "withStyle": "androidx.compose.ui.text",
    "TextRange": "androidx.compose.ui.text",
    "FontFamily": "androidx.compose.ui.text.font",
    "FontWeight": "androidx.compose.ui.text.font",
    "TextOverflow": "androidx.compose.ui.text.style",
    "TextAlign": "androidx.compose.ui.text.style",
    "TextFieldValue": "androidx.compose.ui.text.input",
    "KeyboardType": "androidx.compose.ui.text.input",
    "VisualTransformation": "androidx.compose.ui.text.input",
    # foundation
    "BasicTextField": "androidx.compose.foundation.text",
    "KeyboardOptions": "androidx.compose.foundation.text",
    "background": "androidx.compose.foundation",
    "border": "androidx.compose.foundation",
    "clickable": "androidx.compose.foundation",
    "IntrinsicSize": "androidx.compose.foundation.layout",
    "Arrangement": "androidx.compose.foundation.layout",
    "PaddingValues": "androidx.compose.foundation.layout",
    "FlowRow": "androidx.compose.foundation.layout",
    "ExperimentalLayoutApi": "androidx.compose.foundation.layout",
    "systemBarsPadding": "androidx.compose.foundation.layout",
    "LazyColumn": "androidx.compose.foundation.lazy",
    "LazyRow": "androidx.compose.foundation.lazy",
    "items": "androidx.compose.foundation.lazy",
    "itemsIndexed": "androidx.compose.foundation.lazy",
    # material3
    "Text": "androidx.compose.material3",
    "Surface": "androidx.compose.material3",
    "MaterialTheme": "androidx.compose.material3",
    "LocalTextStyle": "androidx.compose.material3",
    "darkColorScheme": "androidx.compose.material3",
    # runtime
    "Composable": "androidx.compose.runtime",
    "remember": "androidx.compose.runtime",
    "mutableStateOf": "androidx.compose.runtime",
    "collectAsState": "androidx.compose.runtime",
    "LaunchedEffect": "androidx.compose.runtime",
    # activity & lifecycle
    "setContent": "androidx.activity.compose",
    "BackHandler": "androidx.activity.compose",
    "enableEdgeToEdge": "androidx.activity",
    "ComponentActivity": "androidx.activity",
    "viewModel": "androidx.lifecycle.viewmodel.compose",
}

IMPORT = re.compile(r"^import\s+([\w.]+)\.(\w+)\s*$", re.M)


def semak(akar: pathlib.Path) -> int:
    masalah = 0
    for fail in sorted(akar.rglob("*.kt")):
        teks = fail.read_text(encoding="utf-8")
        for pakej, simbol in IMPORT.findall(teks):
            betul = PAKEJ.get(simbol)
            if betul and pakej != betul:
                masalah += 1
                print(f"  X {fail.name}: {simbol} diimport dari `{pakej}`")
                print(f"      sepatutnya `{betul}`")
    print(f"Import Compose disemak. Masalah: {masalah}")
    return masalah


if __name__ == "__main__":
    akar = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "app/src/main/java")
    sys.exit(1 if semak(akar) else 0)
