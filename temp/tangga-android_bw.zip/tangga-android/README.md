# Tangga — Android native

Aplikasi belajar coding. 26 bab, 3,500 level, 212 template tugasan.
Kod yang kau tulis dijalankan sungguh-sungguh terhadap kes ujian.

## Dua laluan

| Laluan | Level | Bab | Templat | Enjin |
|---|---|---|---|---|
| JavaScript | 3,500 | 26 | 212 | WebView JS terbina |
| Python | 1,800 | 12 | 69 | Pyodide (CPython ke WebAssembly) |

Setiap jawapan rujukan Python disahkan dengan CPython 3.12 sebelum penjanaan:
218 penegasan, sifar kegagalan. Setiap tugasan "baiki" juga disahkan benar-benar
bermula dalam keadaan rosak.

## Memasang Pyodide

Aplikasi tiada kebenaran internet, jadi Python mesti dibundel, bukan dimuat turun
semasa jalanan. Jalankan sekali sebelum binaan pertama:

```bash
./ambil-pyodide.sh
```

Ini menambah kira-kira 12 MB kepada APK. Tanpanya laluan JavaScript tetap
berfungsi sepenuhnya; laluan Python akan melaporkan enjin tidak dapat dimuatkan.

## Timbunan

| Lapisan | Teknologi |
|---|---|
| UI | Jetpack Compose (Material 3), Kotlin |
| Keadaan | `ViewModel` + `StateFlow` |
| Simpanan | DataStore Preferences (satu blob JSON, semuanya pada peranti) |
| Enjin ujian | `WebView` tanpa skrin sebagai runtime JavaScript bersandbox |
| Bank tugasan | `assets/enjin.js` |

Tiada kebenaran diminta. Tiada rangkaian. Tiada analitis. Tiada iklan.

## Kenapa ada WebView dalam aplikasi "native"

Aplikasi ini mengajar JavaScript, jadi ia mesti **menjalankan** JavaScript yang
ditulis pengguna. Android tiada jurubahasa JS yang boleh dicapai dari Kotlin, dan
tiada jurubahasa Kotlin di atas peranti — jadi tidak ada jalan untuk "menjadikan
semuanya Kotlin" tanpa menukar bahasa yang diajar.

`EnjinJs` mencipta satu `WebView` yang **tidak pernah dipaparkan**, tidak pernah
memuatkan URL, dan mempunyai `blockNetworkLoads = true`. Ia semata-mata runtime.
Semua UI, navigasi, tema, simpanan dan logik aplikasi adalah Kotlin/Compose tulen.

Alternatif kalau kau mahu membuang WebView sepenuhnya: benamkan QuickJS atau
Rhino sebagai perpustakaan native. Ia berfungsi, tetapi menambah beban binaan
tanpa faedah keselamatan yang bermakna berbanding pendekatan ini.

### Sandbox

Kod pengguna dinilai dalam `new Function(...)` yang **membayangi**
`AndroidJambatan`, `window`, `document`, `fetch`, `XMLHttpRequest`, `WebSocket`,
`localStorage`, `indexedDB` dan `importScripts` sebagai parameter kosong. Ia tidak
boleh mencapai jambatan Android mahupun rangkaian.

### Gelung tak berhenti

`evaluateJavascript` tidak menyekat urutan UI, tetapi gelung tak berhenti akan
menggantung urutan JS WebView selamanya. Selepas 4 saat tanpa balasan, `EnjinJs`
memusnahkan WebView itu dan membina yang baharu. Pengguna nampak mesej masa tamat
dan aplikasi kekal responsif. Level 244 sengaja mengandungi gelung sebegini
sebagai pengajaran.

## Membina

```bash
# Perlukan Android Studio (Ladybug ke atas) atau Android SDK + JDK 17
./gradlew assembleDebug          # APG nyahpepijat
./gradlew bundleRelease          # AAB untuk Play Store
```

Buka folder ini dalam Android Studio dan biarkan ia menjana pembalut Gradle
(`gradlew`) — ia tidak disertakan di sini.

**Versi dalam `gradle/libs.versions.toml` mungkin sudah lapuk.** Jalankan AGP
Upgrade Assistant dan terima cadangan kemas kini kebergantungan sebelum kau
membazir masa menyahpepijat ralat binaan.

## Sebelum menghantar ke Play Store

- [ ] `targetSdk = 36` — dituntut untuk penghantaran baharu mulai 31 Ogos 2026
- [ ] Naikkan `versionCode` pada setiap muat naik
- [ ] Jana kunci penandatanganan upload dan aktifkan Play App Signing
- [ ] Borang Data Safety: isytihar **tiada data dikumpul** (itu benar di sini)
- [ ] Dasar privasi — Play Console menuntut pautan walaupun kau tak kumpul apa-apa
- [ ] Soal selidik penilaian kandungan
- [ ] Akaun pembangun peribadi yang dibuka selepas 13 Nov 2023: ujian tertutup
      dengan 12 penguji selama 14 hari berturut-turut sebelum akses pengeluaran

## Apa yang belum siap

- Tiada pembalut Gradle (`gradlew`) — Android Studio akan menjananya
- Tiada ujian berinstrumen atau ujian unit
- Editor kod ialah `BasicTextField`, tiada penyerlahan sintaks. Untuk itu,
  pertimbangkan `compose-code-editor` atau tulis `VisualTransformation` sendiri
- Tiada carian level atau penanda buku
- Tiada sokongan tablet khusus (susun atur satu lajur pada semua saiz)
