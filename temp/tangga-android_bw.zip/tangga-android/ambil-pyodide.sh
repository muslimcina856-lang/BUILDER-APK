#!/usr/bin/env bash
# Memuat turun Pyodide ke dalam assets supaya Python berfungsi luar talian.
# Jalankan sekali sebelum binaan pertama. APK akan bertambah kira-kira 12 MB.
set -euo pipefail
VERSI="${1:-0.28.0}"
DEST="app/src/main/assets/pyodide"
mkdir -p "$DEST"
URL="https://github.com/pyodide/pyodide/releases/download/${VERSI}/pyodide-core-${VERSI}.tar.bz2"
echo "Memuat turun Pyodide ${VERSI}..."
curl -fL "$URL" -o /tmp/pyodide.tar.bz2
tar -xjf /tmp/pyodide.tar.bz2 -C /tmp
cp /tmp/pyodide/pyodide.asm.wasm /tmp/pyodide/pyodide.asm.js \
   /tmp/pyodide/pyodide.js /tmp/pyodide/python_stdlib.zip \
   /tmp/pyodide/pyodide-lock.json "$DEST/"
rm -rf /tmp/pyodide /tmp/pyodide.tar.bz2
echo "Siap. Saiz aset:"
du -sh "$DEST"
