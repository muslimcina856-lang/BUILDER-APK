# Antara muka JavaScript dipanggil melalui pantulan oleh WebView.
-keepclassmembers class my.tangga.enjin.EnjinJs$Jambatan {
    public *;
}
-keepattributes JavascriptInterface
