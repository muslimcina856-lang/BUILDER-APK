package my.tangga.enjin

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Enjin JavaScript bersandbox.
 *
 * Kenapa WebView: aplikasi ini mengajar JavaScript, jadi ia mesti menjalankan
 * JavaScript yang ditulis pengguna. Android tiada jurubahasa JS terbina dalam
 * yang boleh dicapai dari Kotlin. WebView ini tiada skrin, tidak pernah memuat
 * sebarang URL, dan tidak menyentuh rangkaian — ia semata-mata runtime.
 *
 * Sandbox: kod pengguna dinilai dalam `new Function(...)` yang membayangi
 * `AndroidJambatan`, `window`, `document`, `fetch` dan rakan-rakannya, jadi ia
 * tidak boleh mencapai jambatan atau rangkaian. Lihat assets/enjin.js.
 *
 * Gelung tak berhenti: `evaluateJavascript` tidak menyekat urutan UI, tetapi ia
 * menggantung urutan JS WebView selamanya. Bila had masa tamat, kita musnahkan
 * WebView itu dan bina yang baharu.
 */
class EnjinJs(private val konteks: Context) {

    private var web: WebView? = null
    private var siap: CompletableDeferred<Unit> = CompletableDeferred()
    private val menunggu = ConcurrentHashMap<String, CompletableDeferred<String>>()
    private val kaunter = AtomicLong(0)

    private val sumberEnjin: String by lazy {
        konteks.assets.open("enjin.js").bufferedReader().use { it.readText() }
    }

    inner class Jambatan {
        @JavascriptInterface
        fun balas(id: String, json: String) {
            menunggu.remove(id)?.complete(json)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun bina() = withContext(Dispatchers.Main) {
        web?.destroy()
        menunggu.values.forEach { it.completeExceptionally(IllegalStateException("enjin dimulakan semula")) }
        menunggu.clear()
        siap = CompletableDeferred()

        val w = WebView(konteks)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            blockNetworkLoads = true
        }
        w.addJavascriptInterface(Jambatan(), "AndroidJambatan")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true

            override fun onPageFinished(v: WebView, url: String) {
                // Enjin disuntik selepas halaman siap, bukan ditanam dalam HTML.
                // Bank tugasan mengandungi rentetan seperti "<script>" yang akan
                // memecahkan dokumen kalau ia ditulis sebagai teks HTML.
                v.evaluateJavascript(sumberEnjin) { siap.complete(Unit) }
            }
        }
        w.loadDataWithBaseURL(
            null,
            "<html><head><meta charset=\"utf-8\"></head><body></body></html>",
            "text/html",
            "utf-8",
            null,
        )
        web = w
    }

    suspend fun mula() {
        if (web == null) bina()
        siap.await()
    }

    private suspend fun laksana(js: String, id: String, hadMs: Long): String? {
        mula()
        val d = CompletableDeferred<String>()
        menunggu[id] = d
        withContext(Dispatchers.Main) { web?.evaluateJavascript(js, null) }
        val hasil = withTimeoutOrNull(hadMs) { runCatching { d.await() }.getOrNull() }
        menunggu.remove(id)
        if (hasil == null) bina() // JS tergantung — buang dan bina semula
        return hasil
    }

    private fun idBaharu() = "p" + kaunter.incrementAndGet()

    /** Panggilan segerak: nilai ekspresi dihantar terus ke jambatan. */
    private suspend fun tanya(ekspresi: String, hadMs: Long = 5_000): String? {
        val id = idBaharu()
        return laksana("AndroidJambatan.balas('$id', $ekspresi);", id, hadMs)
    }

    suspend fun jumlahLevel(): Int =
        tanya("String(TanggaEnjin.jumlah())")?.toIntOrNull() ?: 0

    suspend fun bab(): String? = tanya("TanggaEnjin.bab()")

    suspend fun level(n: Int): String? = tanya("TanggaEnjin.level($n)")

    suspend fun semakRamal(n: Int, teks: String): String? =
        tanya("TanggaEnjin.semakRamal($n, ${petik(teks)})")

    /** Menjalankan kod pengguna terhadap kes ujian level itu. */
    suspend fun jalan(n: Int, kod: String, hadMs: Long = 4_000): String {
        val id = idBaharu()
        val js = "TanggaEnjin.jalan($n, ${petik(kod)}, '$id');"
        return laksana(js, id, hadMs)
            ?: """{"fatal":"Masa tamat selepas ${hadMs / 1000} saat — kemungkinan besar ada gelung yang tak berhenti."}"""
    }

    fun lepaskan() {
        web?.destroy()
        web = null
    }

    /** Melarikan rentetan Kotlin dengan selamat menjadi literal JavaScript. */
    private fun petik(s: String): String = JSONObject.quote(s)
}
