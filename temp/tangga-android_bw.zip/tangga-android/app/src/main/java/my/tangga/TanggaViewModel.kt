package my.tangga

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import my.tangga.data.SimpananProgres
import my.tangga.enjin.EnjinJs
import java.time.LocalDate

enum class Skrin { PETA, LEVEL }

data class Keadaan(
    val memuat: Boolean = true,
    val skrin: Skrin = Skrin.PETA,
    val bab: List<Bab> = emptyList(),
    val jumlahLevel: Int = 0,
    val progres: Progres = Progres(),
    val level: Level? = null,
    val kod: String = "",
    val jawapanTeks: String = "",
    val keputusan: Keputusan? = null,
    val hasilRamal: HasilRamal? = null,
    val pilihanDipilih: Int? = null,
    val berjalan: Boolean = false,
    val petunjukDibuka: Int = 0,
    val jawapanDibuka: Boolean = false,
    val cuba: Int = 0,
)

class TanggaViewModel(app: Application) : AndroidViewModel(app) {

    private val enjin = EnjinJs(app)
    private val simpanan = SimpananProgres(app)
    private val json = Json { ignoreUnknownKeys = true }

    private val _keadaan = MutableStateFlow(Keadaan())
    val keadaan: StateFlow<Keadaan> = _keadaan.asStateFlow()

    init {
        viewModelScope.launch {
            enjin.mula()
            val senaraiBab = enjin.bab()?.let { json.decodeFromString<List<Bab>>(it) } ?: emptyList()
            val jumlah = enjin.jumlahLevel()
            _keadaan.value = _keadaan.value.copy(bab = senaraiBab, jumlahLevel = jumlah, memuat = false)
        }
        viewModelScope.launch {
            simpanan.aliran.collect { p ->
                _keadaan.value = _keadaan.value.copy(progres = p)
            }
        }
    }

    fun bukaLevel(n: Int) {
        viewModelScope.launch {
            val had = _keadaan.value.jumlahLevel.takeIf { it > 0 } ?: 1
            val nombor = n.coerceIn(1, had)
            val mentah = enjin.level(nombor) ?: return@launch
            val level = runCatching { json.decodeFromString<Level>(mentah) }.getOrNull() ?: return@launch
            _keadaan.value = _keadaan.value.copy(
                skrin = Skrin.LEVEL,
                level = level,
                kod = level.starter.orEmpty(),
                jawapanTeks = "",
                keputusan = null,
                hasilRamal = null,
                pilihanDipilih = null,
                petunjukDibuka = 0,
                jawapanDibuka = false,
                cuba = 0,
            )
            simpan(_keadaan.value.progres.copy(sekarang = nombor))
        }
    }

    fun kePeta() {
        _keadaan.value = _keadaan.value.copy(skrin = Skrin.PETA)
    }

    fun tetapkanKod(baharu: String) {
        _keadaan.value = _keadaan.value.copy(kod = baharu)
    }

    fun tetapkanJawapanTeks(baharu: String) {
        _keadaan.value = _keadaan.value.copy(jawapanTeks = baharu)
    }

    fun bukaPetunjuk() {
        _keadaan.value = _keadaan.value.copy(petunjukDibuka = _keadaan.value.petunjukDibuka + 1)
    }

    fun bukaJawapan() {
        _keadaan.value = _keadaan.value.copy(jawapanDibuka = true)
    }

    fun setSemula() {
        val l = _keadaan.value.level ?: return
        _keadaan.value = _keadaan.value.copy(kod = l.starter.orEmpty())
    }

    fun jalankan() {
        val k = _keadaan.value
        val level = k.level ?: return
        if (k.berjalan) return
        _keadaan.value = k.copy(berjalan = true, keputusan = null, cuba = k.cuba + 1)
        viewModelScope.launch {
            val mentah = enjin.jalan(level.n, _keadaan.value.kod)
            val hasil = runCatching { json.decodeFromString<Keputusan>(mentah) }
                .getOrElse { Keputusan(fatal = "Tidak dapat membaca keputusan ujian.") }
            _keadaan.value = _keadaan.value.copy(berjalan = false, keputusan = hasil)
            if (hasil.semuaLulus) tandaSiap(level.n, _keadaan.value.cuba)
        }
    }

    fun semakRamal() {
        val k = _keadaan.value
        val level = k.level ?: return
        _keadaan.value = k.copy(cuba = k.cuba + 1)
        viewModelScope.launch {
            val mentah = enjin.semakRamal(level.n, _keadaan.value.jawapanTeks) ?: return@launch
            val hasil = runCatching { json.decodeFromString<HasilRamal>(mentah) }.getOrNull() ?: return@launch
            _keadaan.value = _keadaan.value.copy(hasilRamal = hasil)
            if (hasil.lulus) tandaSiap(level.n, _keadaan.value.cuba)
        }
    }

    fun pilih(indeks: Int) {
        val k = _keadaan.value
        val level = k.level ?: return
        if (k.pilihanDipilih != null) return
        _keadaan.value = k.copy(pilihanDipilih = indeks, cuba = k.cuba + 1)
        if (indeks == level.betul) tandaSiap(level.n, _keadaan.value.cuba)
    }

    private fun tandaSiap(n: Int, percubaan: Int) {
        val p = _keadaan.value.progres
        val hariIni = LocalDate.now().toString()
        val semalam = LocalDate.now().minusDays(1).toString()
        val rentetan = when {
            p.hariAkhir == hariIni -> p.rentetan
            p.hariAkhir == semalam -> p.rentetan + 1
            else -> 1
        }
        val baharu = !p.sudahSiap(n)
        simpan(
            p.copy(
                siap = p.siap + (n.toString() to percubaan),
                xp = p.xp + if (baharu) (if (percubaan <= 1) 15 else 10) else 0,
                hariAkhir = hariIni,
                rentetan = rentetan,
                sekarang = n,
            )
        )
    }

    private fun simpan(p: Progres) {
        _keadaan.value = _keadaan.value.copy(progres = p)
        viewModelScope.launch { simpanan.simpan(p) }
    }

    override fun onCleared() {
        enjin.lepaskan()
        super.onCleared()
    }
}
