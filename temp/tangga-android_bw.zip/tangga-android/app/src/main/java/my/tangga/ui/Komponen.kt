package my.tangga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ---------- Palet: pelan biru juruukur ---------- */
object Warna {
    val Dasar = Color(0xFF12203A)
    val Panel = Color(0xFF0B1626)
    val Panel2 = Color(0xFF152742)
    val Garis = Color(0xFF22406B)
    val Garis2 = Color(0xFF1A3155)
    val Dakwat = Color(0xFFDDE7F7)
    val Senyap = Color(0xFF7B95BC)
    val Oker = Color(0xFFF0B429)
    val Bata = Color(0xFFE4695B)
    val Hijau = Color(0xFF7FBF8F)
    val Editor = Color(0xFF08111E)
}

/**
 * Brief tugasan datang dari bank JS dengan penanda ringan: `kod` dan **tebal**.
 * Ini menghuraikannya menjadi AnnotatedString.
 */
fun huraiPenanda(teks: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < teks.length) {
        val c = teks[i]
        if (c == '`') {
            val tutup = teks.indexOf('`', i + 1)
            if (tutup > i) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = Warna.Oker, fontSize = 13.sp)) {
                    append(teks.substring(i + 1, tutup))
                }
                i = tutup + 1
                continue
            }
        }
        if (c == '*' && i + 1 < teks.length && teks[i + 1] == '*') {
            val tutup = teks.indexOf("**", i + 2)
            if (tutup > i) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    append(teks.substring(i + 2, tutup))
                }
                i = tutup + 2
                continue
            }
        }
        append(c)
        i++
    }
}

@Composable
fun Eyebrow(teks: String, modifier: Modifier = Modifier) {
    Text(
        teks.uppercase(),
        modifier = modifier,
        color = Warna.Senyap,
        fontSize = 10.sp,
        letterSpacing = 1.6.sp,
        fontFamily = FontFamily.Monospace,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun Butang(
    teks: String,
    modifier: Modifier = Modifier,
    utama: Boolean = false,
    hidup: Boolean = true,
    padaKlik: () -> Unit,
) {
    val bg = if (utama) Warna.Oker else Warna.Panel2
    val fg = if (utama) Warna.Panel else Warna.Dakwat
    Box(
        modifier
            .border(1.dp, if (utama) Warna.Oker else Warna.Garis, RectangleShape)
            .background(if (hidup) bg else bg.copy(alpha = 0.45f))
            .clickable(enabled = hidup) { padaKlik() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            teks.uppercase(),
            color = if (hidup) fg else fg.copy(alpha = 0.6f),
            fontSize = 12.sp,
            letterSpacing = 1.1.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
        )
    }
}

@Composable
fun Nota(teks: AnnotatedString, merah: Boolean = false, modifier: Modifier = Modifier) {
    val aksen = if (merah) Warna.Bata else Warna.Oker
    Row(
        modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .background(aksen.copy(alpha = 0.07f))
    ) {
        Box(Modifier.width(2.dp).fillMaxHeight().background(aksen))
        Text(
            teks,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            color = Warna.Dakwat,
            fontSize = 13.5.sp,
            lineHeight = 21.sp,
        )
    }
}

@Composable
fun Nota(teks: String, merah: Boolean = false, modifier: Modifier = Modifier) =
    Nota(huraiPenanda(teks), merah, modifier)

@Composable
fun BlokKod(kod: String, modifier: Modifier = Modifier) {
    Text(
        kod,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Warna.Garis, RectangleShape)
            .background(Warna.Editor)
            .padding(12.dp),
        color = Warna.Dakwat,
        fontFamily = FontFamily.Monospace,
        fontSize = 13.sp,
        lineHeight = 21.sp,
    )
}

/** Editor kod. Papan kekunci telefon tiada simbol pengaturcaraan, jadi kita bekalkan sendiri. */
@Composable
fun EditorKod(
    nilai: TextFieldValue,
    padaUbah: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier) {
        BasicTextField(
            value = nilai,
            onValueChange = padaUbah,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp)
                .border(1.dp, Warna.Garis, RectangleShape)
                .background(Warna.Editor)
                .padding(11.dp),
            textStyle = LocalTextStyle.current.copy(
                color = Warna.Dakwat,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.5.sp,
                lineHeight = 22.sp,
            ),
            cursorBrush = SolidColor(Warna.Oker),
        )
        Spacer(Modifier.height(7.dp))
        BarSimbol { simbol ->
            val a = nilai.selection.min
            val b = nilai.selection.max
            val teksBaharu = nilai.text.substring(0, a) + simbol + nilai.text.substring(b)
            padaUbah(
                nilai.copy(
                    text = teksBaharu,
                    selection = androidx.compose.ui.text.TextRange(a + simbol.length),
                )
            )
        }
    }
}

private val SIMBOL = listOf(
    "{", "}", "(", ")", "[", "]", ";", "=", "=>", "<", ">", "!", "&&", "||",
    "'", "\"", "`", "+", "-", "*", "/", "%", ".", ",", "_", "  ",
)

@Composable
private fun BarSimbol(padaSisip: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items(SIMBOL) { s ->
            Box(
                Modifier
                    .widthIn(min = 36.dp)
                    .height(34.dp)
                    .border(1.dp, Warna.Garis, RectangleShape)
                    .background(Warna.Panel2)
                    .clickable { padaSisip(s) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (s == "  ") "\u2192" else s,
                    color = Warna.Dakwat,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                )
            }
        }
    }
}
