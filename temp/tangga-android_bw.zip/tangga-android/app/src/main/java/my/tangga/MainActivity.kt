package my.tangga

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import my.tangga.ui.LevelSkrin
import my.tangga.ui.PetaSkrin
import my.tangga.ui.Warna

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AplikasiTangga() }
    }
}

private val skema = darkColorScheme(
    primary = Warna.Oker,
    background = Warna.Dasar,
    surface = Warna.Panel,
    onBackground = Warna.Dakwat,
    onSurface = Warna.Dakwat,
    error = Warna.Bata,
)

@Composable
fun AplikasiTangga(vm: TanggaViewModel = viewModel()) {
    val k by vm.keadaan.collectAsState()

    MaterialTheme(colorScheme = skema) {
        Surface(
            Modifier
                .fillMaxSize()
                .background(Warna.Dasar)
                .systemBarsPadding(),
            color = Warna.Dasar,
        ) {
            BackHandler(enabled = k.skrin == Skrin.LEVEL) { vm.kePeta() }

            when (k.skrin) {
                Skrin.PETA -> PetaSkrin(k) { vm.bukaLevel(it) }
                Skrin.LEVEL -> LevelSkrin(
                    k = k,
                    padaKembali = vm::kePeta,
                    padaKodUbah = vm::tetapkanKod,
                    padaTeksUbah = vm::tetapkanJawapanTeks,
                    padaJalan = vm::jalankan,
                    padaSemakRamal = vm::semakRamal,
                    padaPilih = vm::pilih,
                    padaPetunjuk = vm::bukaPetunjuk,
                    padaJawapan = vm::bukaJawapan,
                    padaSetSemula = vm::setSemula,
                    padaLangkah = vm::bukaLevel,
                )
            }
        }
    }
}
