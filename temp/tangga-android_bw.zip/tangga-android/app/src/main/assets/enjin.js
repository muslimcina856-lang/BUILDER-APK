/* Dijana daripada bank tugasan Tangga. Jangan sunting terus. */

/* ============================================================
   TANGGA — 2,400 level belajar coding (JavaScript), Bahasa Melayu
   Enjin: Web Worker + ujian sebenar. Progres disimpan.
   ============================================================ */

/* ---------- RNG deterministik ---------- */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const ri = (r, a, b) => a + Math.floor(r() * (b - a + 1));
const rp = (r, arr) => arr[Math.floor(r() * arr.length)];
const U = (args, expected) => ({ args, expected });
const B = (args, baling = true) => ({ args, baling });
// Fungsi dan Promise tidak boleh dihantar ke Worker. Hantar sumbernya, bina semula di sana.
const EV = (src) => ({ __ev: src });

/* ---------- Bab ---------- */
const BAB = [
  { n: 1, nama: "Nilai & Pemboleh Ubah", dari: 1, hingga: 100 },
  { n: 2, nama: "Syarat & Logik", dari: 101, hingga: 240 },
  { n: 3, nama: "Gelung", dari: 241, hingga: 400 },
  { n: 4, nama: "Fungsi", dari: 401, hingga: 560 },
  { n: 5, nama: "Array", dari: 561, hingga: 740 },
  { n: 6, nama: "String", dari: 741, hingga: 900 },
  { n: 7, nama: "Objek & Peta", dari: 901, hingga: 1060 },
  { n: 8, nama: "Rekursi", dari: 1061, hingga: 1180 },
  { n: 9, nama: "Algoritma & Kerumitan", dari: 1181, hingga: 1320 },
  { n: 10, nama: "Kod Bertahan", dari: 1321, hingga: 1500 },
  { n: 11, nama: "Ralat & Cara Membalas", dari: 1501, hingga: 1660 },
  { n: 12, nama: "Async & Masa", dari: 1661, hingga: 1800 },
  { n: 13, nama: "Keselamatan Asas", dari: 1801, hingga: 1940 },
  { n: 14, nama: "Menulis Ujian", dari: 1941, hingga: 2060 },
  { n: 15, nama: "Refactor & Kualiti", dari: 2061, hingga: 2180 },
  { n: 16, nama: "Debug Lanjutan", dari: 2181, hingga: 2280 },
  { n: 17, nama: "Code Review & Kerjaya", dari: 2281, hingga: 2340 },
  { n: 18, nama: "Pangkalan Data & SQL", dari: 2341, hingga: 2480 },
  { n: 19, nama: "Git & Kerja Berpasukan", dari: 2481, hingga: 2600 },
  { n: 20, nama: "Membaca Kod Orang Lain", dari: 2601, hingga: 2700 },
  { n: 21, nama: "Struktur Data Klasik", dari: 2701, hingga: 2840 },
  { n: 22, nama: "Regex & Corak Teks", dari: 2841, hingga: 2960 },
  { n: 23, nama: "HTTP & API", dari: 2961, hingga: 3100 },
  { n: 24, nama: "Prestasi & Cache", dari: 3101, hingga: 3220 },
  { n: 25, nama: "Reka Bentuk & Abstraksi", dari: 3221, hingga: 3340 },
  { n: 26, nama: "Cabaran Campur", dari: 3341, hingga: 3500 },
];
const JUMLAH = 3500;

/* ============================================================
   BANK TUGASAN
   jenis: tulis | baiki | kukuh | ramal | pilih
   ============================================================ */
const TUGAS = [
  /* ================= BAB 1 — NILAI ================= */
  {
    bab: 1, jenis: "tulis", fn: "luas",
    tajuk: "Luas segi empat",
    gen: (r) => ({ p: ri(r, 3, 40), l: ri(r, 2, 30), p2: ri(r, 5, 60), l2: ri(r, 1, 25) }),
    brief: () => "Tulis fungsi `luas(p, l)` yang pulangkan luas segi empat tepat. Luas = panjang × lebar.",
    starter: () => "function luas(p, l) {\n  // tulis di sini\n}",
    cases: (p) => [U([p.p, p.l], p.p * p.l), U([p.p2, p.l2], p.p2 * p.l2), U([0, 9], 0), U([1, 1], 1)],
    hints: () => ["Guna `return` untuk pulangkan nilai, bukan `console.log`.", "Operator darab ialah `*`."],
    jawapan: () => "function luas(p, l) {\n  return p * l;\n}",
  },
  {
    bab: 1, jenis: "ramal",
    tajuk: "Nilai berubah",
    gen: (r) => ({ a: ri(r, 2, 9), b: ri(r, 2, 9) }),
    kod: (p) => `let x = ${p.a};\nlet y = x;\nx = ${p.b};\nconsole.log(y);`,
    output: (p) => String(p.a),
    brief: () => "Apa yang dicetak? Taip nilainya sahaja.",
    hints: () => ["`y = x` menyalin nilai pada saat itu.", "Tukar `x` kemudian tidak menyentuh `y`."],
  },
  {
    bab: 1, jenis: "pilih",
    tajuk: "Campur jenis",
    gen: (r) => ({ a: ri(r, 2, 8) }),
    soalan: (p) => `Apa hasil \`"${p.a}" + 1\` dan \`"${p.a}" - 1\` dalam JavaScript?`,
    pilihan: (p) => [
      `"${p.a}1" dan ${p.a - 1}`,
      `${p.a + 1} dan ${p.a - 1}`,
      `"${p.a}1" dan "${p.a}1"`,
      `Kedua-duanya ralat`,
    ],
    betul: () => 0,
    huraian: () => "`+` dengan string bermaksud sambung. `-` tiada makna string, jadi JS tukar string kepada nombor dulu. Inilah punca banyak bug — jangan bergantung padanya.",
  },
  {
    bab: 1, jenis: "baiki", fn: "tukar",
    tajuk: "Tukar dua nilai",
    gen: (r) => ({ a: ri(r, 1, 50), b: ri(r, 51, 99) }),
    brief: () => "`tukar(a, b)` sepatutnya pulangkan `[b, a]`. Ia rosak. Baiki.",
    starter: () => "function tukar(a, b) {\n  a = b;\n  b = a;\n  return [a, b];\n}",
    cases: (p) => [U([p.a, p.b], [p.b, p.a]), U([1, 2], [2, 1]), U([0, 7], [7, 0])],
    hints: () => ["Selepas `a = b`, nilai asal `a` sudah hilang.", "Cara paling ringkas: `return [b, a];`"],
    jawapan: () => "function tukar(a, b) {\n  return [b, a];\n}",
  },
  {
    bab: 1, jenis: "tulis", fn: "keFahrenheit",
    tajuk: "Celsius ke Fahrenheit",
    gen: (r) => ({ c: ri(r, -10, 45) }),
    brief: () => "Tulis `keFahrenheit(c)`. Formula: F = C × 9/5 + 32.",
    starter: () => "function keFahrenheit(c) {\n\n}",
    cases: (p) => [U([0], 32), U([100], 212), U([p.c], p.c * 9 / 5 + 32), U([-40], -40)],
    hints: () => ["Ikut susunan operasi: darab dan bahagi dahulu, campur kemudian.", "`return c * 9 / 5 + 32;`"],
    jawapan: () => "function keFahrenheit(c) {\n  return c * 9 / 5 + 32;\n}",
  },

  /* ================= BAB 2 — SYARAT ================= */
  {
    bab: 2, jenis: "tulis", fn: "gred",
    tajuk: "Gred markah",
    gen: (r) => ({ m: ri(r, 0, 100) }),
    brief: () => "Tulis `gred(markah)`:\n80+ → \"A\", 65–79 → \"B\", 50–64 → \"C\", bawah 50 → \"G\".",
    starter: () => "function gred(markah) {\n\n}",
    cases: (p) => [U([95], "A"), U([80], "A"), U([79], "B"), U([65], "B"), U([64], "C"), U([50], "C"), U([49], "G"), U([0], "G"),
      U([p.m], p.m >= 80 ? "A" : p.m >= 65 ? "B" : p.m >= 50 ? "C" : "G")],
    hints: () => ["Susun dari besar ke kecil supaya syarat tak bertindih.", "Guna `if / else if / else`, bukan banyak `if` berasingan."],
    jawapan: () => "function gred(markah) {\n  if (markah >= 80) return \"A\";\n  if (markah >= 65) return \"B\";\n  if (markah >= 50) return \"C\";\n  return \"G\";\n}",
  },
  {
    bab: 2, jenis: "tulis", fn: "bolehUndi",
    tajuk: "Layak mengundi",
    brief: () => "Tulis `bolehUndi(umur, warganegara)`. Pulangkan `true` hanya jika umur 18 ke atas DAN `warganegara` benar.",
    starter: () => "function bolehUndi(umur, warganegara) {\n\n}",
    cases: () => [U([18, true], true), U([17, true], false), U([40, false], false), U([18, false], false), U([90, true], true)],
    hints: () => ["`&&` bermaksud kedua-dua syarat mesti benar.", "Kau boleh terus `return umur >= 18 && warganegara;`"],
    jawapan: () => "function bolehUndi(umur, warganegara) {\n  return umur >= 18 && warganegara === true;\n}",
  },
  {
    bab: 2, jenis: "ramal",
    tajuk: "Nilai palsu",
    gen: (r) => ({ v: rp(r, ['""', "0", "null", "undefined", "NaN"]) }),
    kod: (p) => `const x = ${p.v};\nconsole.log(x || "ganti");`,
    output: () => "ganti",
    brief: () => "Apa yang dicetak?",
    hints: () => ["`\"\"`, `0`, `null`, `undefined`, `NaN` dan `false` semuanya *falsy*.", "`||` pulangkan sebelah kanan bila kiri falsy."],
  },
  {
    bab: 2, jenis: "pilih",
    tajuk: "Dua sama dengan, atau tiga",
    soalan: () => "Apa beza `==` dan `===`?",
    pilihan: () => [
      "`===` bandingkan nilai dan jenis; `==` tukar jenis dahulu",
      "Tiada beza, `===` cuma gaya penulisan",
      "`==` lebih pantas kerana lebih pendek",
      "`===` hanya untuk nombor",
    ],
    betul: () => 0,
    huraian: () => "`\"1\" == 1` ialah true, tetapi `\"1\" === 1` ialah false. Guna `===` sebagai default. Satu-satunya `==` yang berguna ialah `x == null` untuk tangkap null dan undefined sekali gus.",
  },
  {
    bab: 2, jenis: "baiki", fn: "kategoriUmur",
    tajuk: "Syarat tersusun salah",
    brief: () => "`kategoriUmur(u)` sepatutnya: bawah 13 → \"kanak\", 13–19 → \"remaja\", 20+ → \"dewasa\". Ia sentiasa pulangkan \"dewasa\". Baiki susunan.",
    starter: () => "function kategoriUmur(u) {\n  if (u >= 0) return \"dewasa\";\n  if (u >= 13) return \"remaja\";\n  return \"kanak\";\n}",
    cases: () => [U([5], "kanak"), U([12], "kanak"), U([13], "remaja"), U([19], "remaja"), U([20], "dewasa"), U([70], "dewasa")],
    hints: () => ["Syarat paling ketat mesti diperiksa dahulu.", "`u >= 0` sentiasa benar untuk umur, jadi ia menelan semua kes."],
    jawapan: () => "function kategoriUmur(u) {\n  if (u < 13) return \"kanak\";\n  if (u < 20) return \"remaja\";\n  return \"dewasa\";\n}",
  },

  /* ================= BAB 3 — GELUNG ================= */
  {
    bab: 3, jenis: "tulis", fn: "jumlahHingga",
    tajuk: "Jumlah 1 hingga n",
    gen: (r) => ({ n: ri(r, 5, 60) }),
    brief: () => "Tulis `jumlahHingga(n)` yang pulangkan 1 + 2 + ... + n. Jika n kurang 1, pulangkan 0.",
    starter: () => "function jumlahHingga(n) {\n\n}",
    cases: (p) => [U([1], 1), U([5], 15), U([0], 0), U([-3], 0), U([p.n], (p.n * (p.n + 1)) / 2)],
    hints: () => ["Mulakan pembolehubah `jumlah = 0` di luar gelung.", "`for (let i = 1; i <= n; i++) jumlah += i;`"],
    jawapan: () => "function jumlahHingga(n) {\n  let jumlah = 0;\n  for (let i = 1; i <= n; i++) jumlah += i;\n  return jumlah;\n}",
  },
  {
    bab: 3, jenis: "tulis", fn: "kiraGenap",
    tajuk: "Kira nombor genap",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 4, 9) }, () => ri(r, 1, 40)) }),
    brief: () => "Tulis `kiraGenap(arr)` yang pulangkan berapa banyak nombor genap dalam array.",
    starter: () => "function kiraGenap(arr) {\n\n}",
    cases: (p) => [U([[1, 2, 3, 4]], 2), U([[]], 0), U([[1, 3, 5]], 0), U([p.arr], p.arr.filter((x) => x % 2 === 0).length)],
    hints: () => ["`x % 2 === 0` bermaksud genap.", "Guna kaunter, atau `arr.filter(...).length`."],
    jawapan: () => "function kiraGenap(arr) {\n  let n = 0;\n  for (const x of arr) if (x % 2 === 0) n++;\n  return n;\n}",
  },
  {
    bab: 3, jenis: "ramal",
    tajuk: "Gelung dalam gelung",
    gen: (r) => ({ a: ri(r, 2, 3), b: ri(r, 2, 3) }),
    kod: (p) => `let n = 0;\nfor (let i = 0; i < ${p.a}; i++) {\n  for (let j = 0; j < ${p.b}; j++) n++;\n}\nconsole.log(n);`,
    output: (p) => String(p.a * p.b),
    brief: () => "Berapa nilai akhir `n`?",
    hints: () => ["Gelung dalam berjalan penuh setiap kali gelung luar berputar sekali.", "Jawapannya ialah hasil darab dua had."],
  },
  {
    bab: 3, jenis: "baiki", fn: "akhirArray",
    tajuk: "Tersasar satu",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 3, 7) }, () => ri(r, 10, 99)) }),
    brief: () => "`akhirArray(arr)` sepatutnya pulangkan elemen terakhir. Ia pulangkan `undefined`. Baiki.",
    starter: () => "function akhirArray(arr) {\n  return arr[arr.length];\n}",
    cases: (p) => [U([[1, 2, 3]], 3), U([["a"]], "a"), U([p.arr], p.arr[p.arr.length - 1])],
    hints: () => ["Indeks array bermula dari 0.", "Elemen terakhir berada di `length - 1`."],
    jawapan: () => "function akhirArray(arr) {\n  return arr[arr.length - 1];\n}",
  },
  {
    bab: 3, jenis: "tulis", fn: "tapisLebih",
    tajuk: "Tapis melebihi had",
    gen: (r) => ({ had: ri(r, 10, 50), arr: Array.from({ length: ri(r, 5, 9) }, () => ri(r, 1, 80)) }),
    brief: () => "Tulis `tapisLebih(arr, had)` yang pulangkan array baharu berisi nombor yang **lebih besar** daripada had. Jangan ubah array asal.",
    starter: () => "function tapisLebih(arr, had) {\n\n}",
    cases: (p) => [U([[1, 5, 9], 4], [5, 9]), U([[], 3], []), U([[1, 2], 10], []), U([p.arr, p.had], p.arr.filter((x) => x > p.had))],
    hints: () => ["Bina array kosong, kemudian `push` yang layak.", "Atau: `return arr.filter(x => x > had);`"],
    jawapan: () => "function tapisLebih(arr, had) {\n  return arr.filter((x) => x > had);\n}",
  },

  /* ================= BAB 4 — FUNGSI ================= */
  {
    bab: 4, jenis: "tulis", fn: "diskaun",
    tajuk: "Kira harga diskaun",
    gen: (r) => ({ h: ri(r, 20, 400), d: rp(r, [10, 20, 25, 50]) }),
    brief: () => "Tulis `diskaun(harga, peratus)` yang pulangkan harga selepas potongan. Bulatkan kepada 2 titik perpuluhan.",
    starter: () => "function diskaun(harga, peratus) {\n\n}",
    cases: (p) => [U([100, 10], 90), U([59.9, 50], 29.95), U([p.h, p.d], Math.round(p.h * (1 - p.d / 100) * 100) / 100)],
    hints: () => ["Harga akhir = harga × (1 − peratus/100).", "Bulatkan: `Math.round(x * 100) / 100`."],
    jawapan: () => "function diskaun(harga, peratus) {\n  return Math.round(harga * (1 - peratus / 100) * 100) / 100;\n}",
  },
  {
    bab: 4, jenis: "tulis", fn: "sapa",
    tajuk: "Nilai lalai",
    gen: (r) => ({ nama: rp(r, ["Aisyah", "Kumar", "Wei Ling", "Jelani", "Farid"]) }),
    brief: () => "Tulis `sapa(nama, salam)`. Jika `salam` tidak diberi, guna `\"Hai\"`. Pulangkan `\"<salam>, <nama>!\"`.",
    starter: () => "function sapa(nama, salam) {\n\n}",
    cases: (p) => [U(["Ali"], "Hai, Ali!"), U(["Ali", "Selamat pagi"], "Selamat pagi, Ali!"), U([p.nama], `Hai, ${p.nama}!`)],
    hints: () => ["Parameter lalai: `function sapa(nama, salam = \"Hai\")`.", "Guna template literal dengan backtick."],
    jawapan: () => "function sapa(nama, salam = \"Hai\") {\n  return `${salam}, ${nama}!`;\n}",
  },
  {
    bab: 4, jenis: "ramal",
    tajuk: "Fungsi ingat keadaan",
    gen: (r) => ({ k: ri(r, 2, 5) }),
    kod: (p) => `function buatKaunter() {\n  let n = 0;\n  return () => ++n;\n}\nconst kira = buatKaunter();\n${Array.from({ length: p.k }, () => "kira();").join("\n")}\nconsole.log(kira());`,
    output: (p) => String(p.k + 1),
    brief: () => "Apa yang dicetak?",
    hints: () => ["Fungsi dalaman masih pegang `n` walaupun `buatKaunter` sudah tamat. Itu closure.", "Kira berapa kali `kira()` dipanggil semuanya."],
  },
  {
    bab: 4, jenis: "baiki", fn: "tambahKe",
    tajuk: "Fungsi yang mencemar luar",
    brief: () => "`tambahKe(arr, x)` sepatutnya pulangkan array **baharu**, tanpa ubah array asal. Sekarang ia merosakkan input pemanggil. Baiki.",
    starter: () => "function tambahKe(arr, x) {\n  arr.push(x);\n  return arr;\n}",
    cases: () => [U([[1, 2], 3], [1, 2, 3]), U([[], 1], [1])],
    syarat: () => [{ ujian: (s) => !/\.push\s*\(/.test(s) || /\[\s*\.\.\.\s*arr/.test(s), mesej: "Jangan `push` terus ke `arr` yang masuk." }],
    hints: () => ["Salin dahulu: `[...arr]`.", "`return [...arr, x];`"],
    jawapan: () => "function tambahKe(arr, x) {\n  return [...arr, x];\n}",
  },

  /* ================= BAB 5 — ARRAY ================= */
  {
    bab: 5, jenis: "tulis", fn: "purata",
    tajuk: "Purata array",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 3, 6) }, () => ri(r, 1, 20)) }),
    brief: () => "Tulis `purata(arr)`. Untuk array kosong, pulangkan `0` (bukan NaN).",
    starter: () => "function purata(arr) {\n\n}",
    cases: (p) => [U([[2, 4]], 3), U([[]], 0), U([[5]], 5), U([p.arr], p.arr.reduce((a, b) => a + b, 0) / p.arr.length)],
    hints: () => ["Periksa `arr.length === 0` dahulu.", "`arr.reduce((a, b) => a + b, 0) / arr.length`"],
    jawapan: () => "function purata(arr) {\n  if (arr.length === 0) return 0;\n  return arr.reduce((a, b) => a + b, 0) / arr.length;\n}",
  },
  {
    bab: 5, jenis: "tulis", fn: "unik",
    tajuk: "Buang pendua",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 6, 10) }, () => ri(r, 1, 5)) }),
    brief: () => "Tulis `unik(arr)` yang pulangkan array tanpa pendua, mengekalkan susunan asal.",
    starter: () => "function unik(arr) {\n\n}",
    cases: (p) => [U([[1, 1, 2]], [1, 2]), U([[]], []), U([["a", "b", "a"]], ["a", "b"]), U([p.arr], [...new Set(p.arr)])],
    hints: () => ["`new Set(arr)` buang pendua dan kekalkan susunan.", "`return [...new Set(arr)];`"],
    jawapan: () => "function unik(arr) {\n  return [...new Set(arr)];\n}",
  },
  {
    bab: 5, jenis: "tulis", fn: "kumpulIkut",
    tajuk: "Kumpul ikut kunci",
    brief: () => "Tulis `kumpulIkut(senarai, kunci)`. Contoh: `kumpulIkut([{j:\"a\",n:1},{j:\"b\",n:2},{j:\"a\",n:3}], \"j\")` → `{a:[{j:\"a\",n:1},{j:\"a\",n:3}], b:[{j:\"b\",n:2}]}`.",
    starter: () => "function kumpulIkut(senarai, kunci) {\n\n}",
    cases: () => [
      U([[{ j: "a", n: 1 }, { j: "b", n: 2 }, { j: "a", n: 3 }], "j"], { a: [{ j: "a", n: 1 }, { j: "a", n: 3 }], b: [{ j: "b", n: 2 }] }),
      U([[], "j"], {}),
      U([[{ k: "x" }], "k"], { x: [{ k: "x" }] }),
    ],
    hints: () => ["Mula dengan objek kosong `{}`.", "Untuk setiap item: `(hasil[item[kunci]] ||= []).push(item)`."],
    jawapan: () => "function kumpulIkut(senarai, kunci) {\n  const hasil = {};\n  for (const item of senarai) {\n    const k = item[kunci];\n    if (!hasil[k]) hasil[k] = [];\n    hasil[k].push(item);\n  }\n  return hasil;\n}",
  },
  {
    bab: 5, jenis: "ramal",
    tajuk: "Rantaian map dan filter",
    gen: (r) => ({ n: ri(r, 2, 4) }),
    kod: (p) => `const a = [1, 2, 3, 4, 5];\nconst b = a.filter(x => x > ${p.n}).map(x => x * 2);\nconsole.log(b.length);`,
    output: (p) => String(5 - p.n),
    brief: () => "Apa panjang `b`?",
    hints: () => ["`filter` tapis dahulu, `map` cuma tukar nilai — panjang tak berubah.", "Kira berapa nombor 1–5 yang lebih besar daripada had."],
  },
  {
    bab: 5, jenis: "baiki", fn: "duaPertama",
    tajuk: "Splice memusnahkan",
    brief: () => "`duaPertama(arr)` sepatutnya pulangkan 2 elemen pertama tanpa mengubah `arr`. `splice` merosakkan array asal. Baiki.",
    starter: () => "function duaPertama(arr) {\n  return arr.splice(0, 2);\n}",
    cases: () => [U([[1, 2, 3, 4]], [1, 2]), U([[9]], [9]), U([[]], [])],
    syarat: () => [{ ujian: (s) => !/\.splice\s*\(/.test(s), mesej: "Buang `splice` — ia mengubah array asal." }],
    hints: () => ["`slice` menyalin, `splice` memotong.", "`return arr.slice(0, 2);`"],
    jawapan: () => "function duaPertama(arr) {\n  return arr.slice(0, 2);\n}",
  },

  /* ================= BAB 6 — STRING ================= */
  {
    bab: 6, jenis: "tulis", fn: "kapitalPertama",
    tajuk: "Huruf besar di depan",
    gen: (r) => ({ s: rp(r, ["nasi lemak", "kucing", "hujan petang", "kod bertahan"]) }),
    brief: () => "Tulis `kapitalPertama(s)` yang besarkan huruf pertama sahaja. String kosong pulangkan string kosong.",
    starter: () => "function kapitalPertama(s) {\n\n}",
    cases: (p) => [U(["ali"], "Ali"), U([""], ""), U(["a"], "A"), U([p.s], p.s[0].toUpperCase() + p.s.slice(1))],
    hints: () => ["Periksa string kosong dahulu, kalau tidak `s[0]` jadi undefined.", "`s[0].toUpperCase() + s.slice(1)`"],
    jawapan: () => "function kapitalPertama(s) {\n  if (!s) return \"\";\n  return s[0].toUpperCase() + s.slice(1);\n}",
  },
  {
    bab: 6, jenis: "tulis", fn: "kiraPerkataan",
    tajuk: "Kira perkataan",
    brief: () => "Tulis `kiraPerkataan(s)`. Ruang berlebihan di hujung atau di tengah tidak boleh dikira sebagai perkataan.",
    starter: () => "function kiraPerkataan(s) {\n\n}",
    cases: () => [U(["satu dua tiga"], 3), U(["  ruang  banyak  "], 2), U([""], 0), U(["   "], 0), U(["satu"], 1)],
    hints: () => ["`trim()` buang ruang di hujung.", "`s.trim().split(/\\s+/)` pecah ikut mana-mana ruang."],
    jawapan: () => "function kiraPerkataan(s) {\n  const t = s.trim();\n  if (!t) return 0;\n  return t.split(/\\s+/).length;\n}",
  },
  {
    bab: 6, jenis: "tulis", fn: "palindrom",
    tajuk: "Palindrom",
    brief: () => "Tulis `palindrom(s)`. Abaikan huruf besar/kecil dan ruang. `\"Kasur ini rusak\"` → `true`.",
    starter: () => "function palindrom(s) {\n\n}",
    cases: () => [U(["katak"], true), U(["Kasur ini rusak"], true), U(["ayam"], false), U([""], true), U(["A"], true)],
    hints: () => ["Bersihkan dahulu: kecilkan huruf, buang ruang.", "Bandingkan dengan versi terbalik: `[...t].reverse().join(\"\")`."],
    jawapan: () => "function palindrom(s) {\n  const t = s.toLowerCase().replace(/\\s/g, \"\");\n  return t === [...t].reverse().join(\"\");\n}",
  },
  {
    bab: 6, jenis: "tulis", fn: "potong",
    tajuk: "Potong dengan elipsis",
    gen: (r) => ({ had: ri(r, 6, 12) }),
    brief: () => "Tulis `potong(s, had)`. Jika panjang `s` melebihi `had`, pulangkan `had` aksara pertama diikuti `\"…\"`. Kalau tidak, pulangkan `s` seadanya.",
    starter: () => "function potong(s, had) {\n\n}",
    cases: () => [U(["selamat pagi", 7], "selamat…"), U(["pendek", 10], "pendek"), U(["", 3], ""), U(["abcd", 4], "abcd"), U(["abcde", 4], "abcd…")],
    hints: () => ["Bandingkan `s.length > had`.", "`s.slice(0, had) + \"…\"`"],
    jawapan: () => "function potong(s, had) {\n  if (s.length <= had) return s;\n  return s.slice(0, had) + \"…\";\n}",
  },

  /* ================= BAB 7 — OBJEK ================= */
  {
    bab: 7, jenis: "tulis", fn: "jumlahNilai",
    tajuk: "Jumlah nilai objek",
    brief: () => "Tulis `jumlahNilai(obj)` yang jumlahkan semua nilai nombor dalam objek. Objek kosong → 0.",
    starter: () => "function jumlahNilai(obj) {\n\n}",
    cases: () => [U([{ a: 1, b: 2 }], 3), U([{}], 0), U([{ x: 10 }], 10), U([{ a: -1, b: 1 }], 0)],
    hints: () => ["`Object.values(obj)` beri array nilai.", "Kemudian `reduce` seperti array biasa."],
    jawapan: () => "function jumlahNilai(obj) {\n  return Object.values(obj).reduce((a, b) => a + b, 0);\n}",
  },
  {
    bab: 7, jenis: "tulis", fn: "gabung",
    tajuk: "Gabung dua objek",
    brief: () => "Tulis `gabung(a, b)`. Nilai dari `b` mengatasi `a`. Kedua-dua input tidak boleh berubah.",
    starter: () => "function gabung(a, b) {\n\n}",
    cases: () => [U([{ x: 1 }, { y: 2 }], { x: 1, y: 2 }), U([{ x: 1 }, { x: 9 }], { x: 9 }), U([{}, {}], {})],
    syarat: () => [{ ujian: (s) => !/Object\.assign\s*\(\s*a\b/.test(s), mesej: "`Object.assign(a, ...)` mengubah `a`. Buat objek baharu." }],
    hints: () => ["Spread: `{ ...a, ...b }`.", "Yang belakang menang."],
    jawapan: () => "function gabung(a, b) {\n  return { ...a, ...b };\n}",
  },
  {
    bab: 7, jenis: "ramal",
    tajuk: "Rujukan, bukan salinan",
    gen: (r) => ({ v: ri(r, 2, 9) }),
    kod: (p) => `const a = { n: 1 };\nconst b = a;\nb.n = ${p.v};\nconsole.log(a.n);`,
    output: (p) => String(p.v),
    brief: () => "Apa yang dicetak?",
    hints: () => ["Objek disalin sebagai rujukan, bukan nilai.", "`a` dan `b` menunjuk kepada objek yang sama."],
  },
  {
    bab: 7, jenis: "tulis", fn: "ambilDalam",
    tajuk: "Ambil nilai bersarang dengan selamat",
    brief: () => "Tulis `ambilDalam(obj, laluan, lalai)`. `laluan` ialah string macam `\"a.b.c\"`. Jika mana-mana peringkat hilang, pulangkan `lalai`.",
    starter: () => "function ambilDalam(obj, laluan, lalai) {\n\n}",
    cases: () => [
      U([{ a: { b: { c: 5 } } }, "a.b.c", 0], 5),
      U([{ a: {} }, "a.b.c", 0], 0),
      U([{}, "a", "tiada"], "tiada"),
      U([{ a: { b: 0 } }, "a.b", 9], 0),
    ],
    hints: () => ["Pecahkan laluan: `laluan.split(\".\")`.", "Berjalan setapak demi setapak, berhenti bila jumpa null atau undefined."],
    jawapan: () => "function ambilDalam(obj, laluan, lalai) {\n  let semasa = obj;\n  for (const k of laluan.split(\".\")) {\n    if (semasa == null || !(k in Object(semasa))) return lalai;\n    semasa = semasa[k];\n  }\n  return semasa === undefined ? lalai : semasa;\n}",
  },

  /* ================= BAB 8 — REKURSI ================= */
  {
    bab: 8, jenis: "tulis", fn: "faktorial",
    tajuk: "Faktorial",
    gen: (r) => ({ n: ri(r, 3, 9) }),
    brief: () => "Tulis `faktorial(n)` secara rekursif. `faktorial(0)` ialah 1.",
    starter: () => "function faktorial(n) {\n\n}",
    cases: (p) => {
      let f = 1; for (let i = 2; i <= p.n; i++) f *= i;
      return [U([0], 1), U([1], 1), U([5], 120), U([p.n], f)];
    },
    hints: () => ["Setiap rekursi perlu kes henti, kalau tidak ia tak berhenti.", "`return n * faktorial(n - 1);`"],
    jawapan: () => "function faktorial(n) {\n  if (n <= 1) return 1;\n  return n * faktorial(n - 1);\n}",
  },
  {
    bab: 8, jenis: "tulis", fn: "ratakan",
    tajuk: "Ratakan array bersarang",
    brief: () => "Tulis `ratakan(arr)` yang ratakan array bersarang berapa lapis pun. `[1,[2,[3,[4]]]]` → `[1,2,3,4]`.",
    starter: () => "function ratakan(arr) {\n\n}",
    cases: () => [U([[1, [2, [3, [4]]]]], [1, 2, 3, 4]), U([[]], []), U([[[[]]]], []), U([[1, 2]], [1, 2])],
    hints: () => ["Untuk setiap elemen, tanya: adakah ia array?", "`Array.isArray(x) ? ratakan(x) : [x]` kemudian gabung."],
    jawapan: () => "function ratakan(arr) {\n  const hasil = [];\n  for (const x of arr) {\n    if (Array.isArray(x)) hasil.push(...ratakan(x));\n    else hasil.push(x);\n  }\n  return hasil;\n}",
  },
  {
    bab: 8, jenis: "tulis", fn: "kiraNod",
    tajuk: "Kira nod pokok",
    brief: () => "Setiap nod ialah `{nilai, anak: []}`. Tulis `kiraNod(pokok)` yang kira jumlah semua nod. `null` → 0.",
    starter: () => "function kiraNod(pokok) {\n\n}",
    cases: () => [
      U([null], 0),
      U([{ nilai: 1, anak: [] }], 1),
      U([{ nilai: 1, anak: [{ nilai: 2, anak: [] }, { nilai: 3, anak: [{ nilai: 4, anak: [] }] }] }], 4),
    ],
    hints: () => ["Kes henti: `pokok == null` pulangkan 0.", "1 + jumlah kiraan setiap anak."],
    jawapan: () => "function kiraNod(pokok) {\n  if (pokok == null) return 0;\n  let n = 1;\n  for (const a of pokok.anak || []) n += kiraNod(a);\n  return n;\n}",
  },

  /* ================= BAB 9 — ALGORITMA ================= */
  {
    bab: 9, jenis: "tulis", fn: "cariBinari",
    tajuk: "Carian binari",
    brief: () => "Tulis `cariBinari(arr, sasaran)` untuk array **tersusun menaik**. Pulangkan indeks, atau `-1` jika tiada. Jangan guna `indexOf`.",
    starter: () => "function cariBinari(arr, sasaran) {\n\n}",
    cases: () => [U([[1, 3, 5, 7, 9], 7], 3), U([[1, 3, 5], 2], -1), U([[], 1], -1), U([[4], 4], 0), U([[1, 2, 3, 4, 5, 6], 1], 0)],
    syarat: () => [{ ujian: (s) => !/indexOf|includes|find\s*\(/.test(s), mesej: "Guna carian binari sebenar, bukan `indexOf` atau `find`." }],
    hints: () => ["Simpan `kiri = 0` dan `kanan = arr.length - 1`.", "Kira tengah, kemudian buang separuh yang tak mungkin."],
    jawapan: () => "function cariBinari(arr, sasaran) {\n  let kiri = 0, kanan = arr.length - 1;\n  while (kiri <= kanan) {\n    const t = Math.floor((kiri + kanan) / 2);\n    if (arr[t] === sasaran) return t;\n    if (arr[t] < sasaran) kiri = t + 1;\n    else kanan = t - 1;\n  }\n  return -1;\n}",
  },
  {
    bab: 9, jenis: "tulis", fn: "duaJumlah",
    tajuk: "Dua nombor yang berjumlah",
    brief: () => "Tulis `duaJumlah(arr, sasaran)` yang pulangkan `[i, j]` indeks dua nombor yang berjumlah `sasaran`. Tiada padanan → `null`.",
    starter: () => "function duaJumlah(arr, sasaran) {\n\n}",
    cases: () => [U([[2, 7, 11], 9], [0, 1]), U([[3, 2, 4], 6], [1, 2]), U([[1, 2], 99], null), U([[], 0], null)],
    hints: () => ["Cara mudah: dua gelung bersarang, O(n²).", "Cara pantas: simpan nilai yang sudah dilihat dalam Map, O(n)."],
    jawapan: () => "function duaJumlah(arr, sasaran) {\n  const dilihat = new Map();\n  for (let i = 0; i < arr.length; i++) {\n    const perlu = sasaran - arr[i];\n    if (dilihat.has(perlu)) return [dilihat.get(perlu), i];\n    dilihat.set(arr[i], i);\n  }\n  return null;\n}",
  },
  {
    bab: 9, jenis: "pilih",
    tajuk: "Kerumitan masa",
    soalan: () => "Dua gelung bersarang yang setiap satu berjalan sepanjang array `n` — apa kerumitannya?",
    pilihan: () => ["O(n²)", "O(n)", "O(log n)", "O(1)"],
    betul: () => 0,
    huraian: () => "Setiap elemen luar mencetuskan `n` pusingan dalam, jadi n × n. Pada n = 1,000 itu sejuta operasi. Pada n = 100,000 ia sudah tergantung.",
  },
  {
    bab: 9, jenis: "tulis", fn: "palingKerap",
    tajuk: "Paling kerap muncul",
    brief: () => "Tulis `palingKerap(arr)` yang pulangkan nilai paling kerap. Jika seri, pulangkan yang muncul dahulu. Array kosong → `null`.",
    starter: () => "function palingKerap(arr) {\n\n}",
    cases: () => [U([[1, 2, 2, 3]], 2), U([[]], null), U([["a"]], "a"), U([[1, 1, 2, 2]], 1)],
    hints: () => ["Bina peta kiraan dahulu, kemudian cari maksimum.", "Untuk kekalkan susunan seri, lalui array asal semasa mencari maksimum."],
    jawapan: "function palingKerap(arr) {\n  if (arr.length === 0) return null;\n  const kira = new Map();\n  for (const x of arr) kira.set(x, (kira.get(x) || 0) + 1);\n  let terbaik = arr[0];\n  for (const x of arr) if (kira.get(x) > kira.get(terbaik)) terbaik = x;\n  return terbaik;\n}",
  },

  /* ================= BAB 10 — KOD BERTAHAN ================= */
  {
    bab: 10, jenis: "kukuh", fn: "bahagi",
    tajuk: "Bahagi yang tak boleh dipecahkan",
    brief: () => "`bahagi(a, b)` mesti:\n• baling ralat bermesej `\"sifar\"` jika `b` ialah 0\n• baling ralat bermesej `\"nombor\"` jika mana-mana input bukan nombor terhingga\n• kalau tidak, pulangkan hasil bahagi",
    starter: () => "function bahagi(a, b) {\n  return a / b;\n}",
    cases: () => [U([10, 2], 5), U([-9, 3], -3), B([1, 0], "sifar"), B(["5", 1], "nombor"), B([1, null], "nombor"), B([NaN, 1], "nombor")],
    hints: () => ["`typeof x !== \"number\" || !Number.isFinite(x)` tangkap string, null dan NaN sekali gus.", "Baling: `throw new Error(\"nombor\")`. Periksa jenis sebelum periksa sifar."],
    jawapan: () => "function bahagi(a, b) {\n  for (const x of [a, b]) {\n    if (typeof x !== \"number\" || !Number.isFinite(x)) throw new Error(\"nombor tidak sah\");\n  }\n  if (b === 0) throw new Error(\"tidak boleh bahagi sifar\");\n  return a / b;\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "pertama",
    tajuk: "Ambil elemen pertama dengan selamat",
    brief: () => "`pertama(arr, lalai)` mesti pulangkan elemen pertama. Jika `arr` bukan array, kosong, `null` atau `undefined` — pulangkan `lalai`. Jangan sesekali baling ralat.",
    starter: () => "function pertama(arr, lalai) {\n  return arr[0];\n}",
    cases: () => [U([[1, 2], 0], 1), U([[], 0], 0), U([null, "x"], "x"), U([undefined, "x"], "x"), U(["bukan array", "x"], "x"), U([[0], 9], 0)],
    hints: () => ["`Array.isArray(arr)` ialah satu-satunya semakan yang boleh dipercayai.", "Hati-hati: elemen `0` itu falsy tapi sah. Jangan guna `arr[0] || lalai`."],
    jawapan: () => "function pertama(arr, lalai) {\n  if (!Array.isArray(arr) || arr.length === 0) return lalai;\n  return arr[0];\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "hadNombor",
    tajuk: "Hadkan dalam julat",
    gen: (r) => ({ min: ri(r, 0, 5), maks: ri(r, 20, 60) }),
    brief: () => "`hadNombor(n, min, maks)` mesti pulangkan `n` yang dihimpit dalam julat. Jika `n` bukan nombor terhingga, baling ralat bermesej `\"nombor\"`.",
    starter: () => "function hadNombor(n, min, maks) {\n\n}",
    cases: (p) => [U([5, 0, 10], 5), U([-3, 0, 10], 0), U([99, 0, 10], 10), B(["7", 0, 10], "nombor"), B([Infinity, 0, 10], "nombor"), U([p.min, p.min, p.maks], p.min)],
    hints: () => ["Sahkan input dahulu, kemudian himpit.", "`Math.min(maks, Math.max(min, n))`"],
    jawapan: () => "function hadNombor(n, min, maks) {\n  if (typeof n !== \"number\" || !Number.isFinite(n)) throw new Error(\"nombor tidak sah\");\n  return Math.min(maks, Math.max(min, n));\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "hurai",
    tajuk: "Hurai JSON tanpa terhempas",
    brief: () => "`hurai(teks, lalai)` mesti pulangkan objek hasil `JSON.parse`. Jika teks rosak atau bukan string — pulangkan `lalai`. Tidak boleh baling.",
    starter: () => "function hurai(teks, lalai) {\n  return JSON.parse(teks);\n}",
    cases: () => [U(['{"a":1}', null], { a: 1 }), U(["{rosak", "L"], "L"), U([null, "L"], "L"), U([123, "L"], "L"), U(["[1,2]", null], [1, 2])],
    hints: () => ["Balut `JSON.parse` dalam `try / catch`.", "Periksa `typeof teks !== \"string\"` sebelum cuba hurai."],
    jawapan: () => "function hurai(teks, lalai) {\n  if (typeof teks !== \"string\") return lalai;\n  try {\n    return JSON.parse(teks);\n  } catch {\n    return lalai;\n  }\n}",
  },
  {
    bab: 10, jenis: "pilih",
    tajuk: "Gagal awal atau diam-diam",
    soalan: () => "Fungsi kau terima umur `-5`. Mana pendekatan terbaik?",
    pilihan: () => [
      "Baling ralat serta-merta dengan mesej yang jelas",
      "Tukar senyap kepada 0 dan teruskan",
      "Pulangkan `undefined`",
      "Catat ke console dan teruskan seperti biasa",
    ],
    betul: () => 0,
    huraian: () => "Data rosak yang dibetulkan senyap akan merebak jauh dari punca, dan kau akan debug di tempat yang salah tiga hari kemudian. Gagal di sempadan, dekat dengan sumber masalah.",
  },
  {
    bab: 10, jenis: "kukuh", fn: "sahkanPengguna",
    tajuk: "Sahkan borang pendaftaran",
    brief: () => "`sahkanPengguna(obj)` mesti pulangkan array mesej ralat (kosong bermakna sah):\n• `\"nama diperlukan\"` jika nama bukan string tak kosong selepas trim\n• `\"umur tidak sah\"` jika umur bukan integer 13–120\n• `\"emel tidak sah\"` jika emel tiada `@`\nSusunan mesej: nama, umur, emel.",
    starter: () => "function sahkanPengguna(obj) {\n\n}",
    cases: () => [
      U([{ nama: "Ali", umur: 20, emel: "a@b.com" }], []),
      U([{ nama: "  ", umur: 20, emel: "a@b.com" }], ["nama diperlukan"]),
      U([{ nama: "Ali", umur: 5, emel: "a@b.com" }], ["umur tidak sah"]),
      U([{ nama: "Ali", umur: 20, emel: "abc" }], ["emel tidak sah"]),
      U([{}], ["nama diperlukan", "umur tidak sah", "emel tidak sah"]),
    ],
    hints: () => ["Kumpul semua ralat, jangan berhenti pada yang pertama — pengguna patut nampak semuanya sekali gus.", "`Number.isInteger(obj.umur)` dan `typeof obj.emel === \"string\" && obj.emel.includes(\"@\")`."],
    jawapan: () => "function sahkanPengguna(obj) {\n  const o = obj || {};\n  const ralat = [];\n  if (typeof o.nama !== \"string\" || o.nama.trim() === \"\") ralat.push(\"nama diperlukan\");\n  if (!Number.isInteger(o.umur) || o.umur < 13 || o.umur > 120) ralat.push(\"umur tidak sah\");\n  if (typeof o.emel !== \"string\" || !o.emel.includes(\"@\")) ralat.push(\"emel tidak sah\");\n  return ralat;\n}",
  },

  /* ================= BAB 11 — RALAT & CARA MEMBALAS ================= */
  {
    bab: 11, jenis: "tulis", fn: "cuba",
    tajuk: "Corak hasil, bukan baling",
    brief: () => "Tulis `cuba(fn)`. Jalankan `fn()`. Jika berjaya pulangkan `{ok: true, nilai: hasil}`. Jika ia baling, pulangkan `{ok: false, ralat: mesej}`.",
    starter: () => "function cuba(fn) {\n\n}",
    cases: () => [
      { args: [EV("() => 5")], expected: { ok: true, nilai: 5 } },
      { args: [EV("() => { throw new Error('pecah'); }")], expected: { ok: false, ralat: "pecah" } },
    ],
    hints: () => ["`try { ... } catch (e) { ... }`.", "Mesej ada pada `e.message`."],
    jawapan: () => "function cuba(fn) {\n  try {\n    return { ok: true, nilai: fn() };\n  } catch (e) {\n    return { ok: false, ralat: e.message };\n  }\n}",
  },
  {
    bab: 11, jenis: "pilih",
    tajuk: "Membaca jejak tindanan",
    soalan: () => "Jejak: `TypeError: Cannot read properties of undefined (reading 'nama')\\n  at papar (app.js:42)\\n  at main (app.js:10)`. Di mana kau mula?",
    pilihan: () => [
      "app.js baris 42, dan periksa apa yang `undefined`",
      "app.js baris 10, kerana ia dipanggil dahulu",
      "Baris terakhir jejak, sentiasa",
      "Tiada guna — mula debug dari atas fail",
    ],
    betul: () => 0,
    huraian: () => "Baris paling atas dalam jejak ialah tempat ia sebenarnya pecah. Baris di bawahnya cuma menunjukkan siapa yang memanggil. Baca dari atas ke bawah untuk laluan, tetapi mula membaiki di baris pertama.",
  },
  {
    bab: 11, jenis: "kukuh", fn: "muatProfil",
    tajuk: "Balas dengan konteks",
    brief: () => "`muatProfil(id, ambil)` memanggil `ambil(id)` yang mungkin baling. Bila ia baling, kau mesti baling semula ralat baharu dengan mesej `\"gagal muat profil <id>: <mesej asal>\"`.",
    starter: () => "function muatProfil(id, ambil) {\n  return ambil(id);\n}",
    cases: () => [
      { args: [7, EV("(id) => ({ id })")], expected: { id: 7 } },
      { args: [9, EV("() => { throw new Error('tiada rangkaian'); }")], baling: "gagal muat profil 9: tiada rangkaian" },
    ],
    hints: () => ["Tangkap, bina mesej baharu, kemudian baling semula.", "Jangan telan ralat — sebaliknya tambah konteks yang orang seterusnya perlukan."],
    jawapan: () => "function muatProfil(id, ambil) {\n  try {\n    return ambil(id);\n  } catch (e) {\n    throw new Error(`gagal muat profil ${id}: ${e.message}`);\n  }\n}",
  },
  {
    bab: 11, jenis: "tulis", fn: "cubaSemula",
    tajuk: "Cuba semula sebelum menyerah",
    brief: () => "Tulis `cubaSemula(fn, kali)`. Panggil `fn()` sehingga `kali` percubaan. Pulangkan hasil pertama yang berjaya. Jika semua gagal, baling ralat terakhir.",
    starter: () => "function cubaSemula(fn, kali) {\n\n}",
    cases: () => [
      { args: [EV("() => 1"), 3], expected: 1 },
      { args: [EV("(() => { let n = 0; return () => { n++; if (n < 3) throw new Error('belum'); return 'ok'; }; })()"), 5], expected: "ok" },
      { args: [EV("() => { throw new Error('sentiasa gagal'); }"), 2], baling: "sentiasa gagal" },
    ],
    hints: () => ["Gelung `kali` kali, `return` sebaik berjaya.", "Simpan ralat terakhir dalam pembolehubah, baling selepas gelung tamat."],
    jawapan: () => "function cubaSemula(fn, kali) {\n  let akhir;\n  for (let i = 0; i < kali; i++) {\n    try {\n      return fn();\n    } catch (e) {\n      akhir = e;\n    }\n  }\n  throw akhir;\n}",
  },
  {
    bab: 11, jenis: "pilih",
    tajuk: "Mesej ralat yang berguna",
    soalan: () => "Mesej ralat mana paling berguna untuk orang yang akan membaiki?",
    pilihan: () => [
      "`Gagal simpan tempahan #4821: tarikh keluar (2024-03-01) sebelum tarikh masuk (2024-03-05)`",
      "`Ralat berlaku. Sila cuba lagi.`",
      "`ERR_INVALID_STATE`",
      "`Maaf, sesuatu telah berlaku 😢`",
    ],
    betul: () => 0,
    huraian: () => "Mesej yang baik ada tiga bahagian: apa yang cuba dibuat, apa yang salah, dan nilai sebenar yang menyebabkannya. Mesej yang meminta maaf tanpa memberi maklumat cuma membuang masa orang.",
  },
  {
    bab: 11, jenis: "baiki", fn: "jumlahSelamat",
    tajuk: "Catch yang menelan",
    brief: () => "`jumlahSelamat(arr)` menelan setiap ralat dan pulangkan 0 secara senyap — jadi bug tak pernah dilihat. Ia patut pulangkan jumlah nombor sah, dan baling `\"input mesti array\"` jika `arr` bukan array.",
    starter: () => "function jumlahSelamat(arr) {\n  try {\n    let j = 0;\n    for (const x of arr) j += x;\n    return j;\n  } catch (e) {\n    return 0;\n  }\n}",
    cases: () => [U([[1, 2, 3]], 6), U([[]], 0), B([null], "input mesti array"), B(["abc"], "input mesti array"), U([[1, "2"]], 3)],
    syarat: () => [{ ujian: (s) => !/catch\s*(\([^)]*\))?\s*\{\s*return\s+0\s*;?\s*\}/.test(s), mesej: "Buang `catch` yang menelan ralat menjadi 0." }],
    hints: () => ["Sahkan input dahulu — jangan guna try/catch sebagai ganti semakan.", "`Number(x)` tukar `\"2\"` kepada 2."],
    jawapan: () => "function jumlahSelamat(arr) {\n  if (!Array.isArray(arr)) throw new Error(\"input mesti array\");\n  let j = 0;\n  for (const x of arr) j += Number(x);\n  return j;\n}",
  },

  /* ================= BAB 12 — ASYNC ================= */
  {
    bab: 12, jenis: "ramal",
    tajuk: "Susunan yang mengelirukan",
    kod: () => `console.log("A");\nsetTimeout(() => console.log("B"), 0);\nPromise.resolve().then(() => console.log("C"));\nconsole.log("D");`,
    output: () => "A D C B",
    brief: () => "Taip susunan cetakan, dipisah ruang. Contoh: `A B C D`",
    hints: () => ["Kod segerak habis dahulu: A, D.", "Promise (microtask) mendahului setTimeout (macrotask): C sebelum B."],
  },
  {
    bab: 12, jenis: "tulis", fn: "kumpulSemua",
    tajuk: "Jalan serentak, bukan berbaris",
    brief: () => "Tulis `kumpulSemua(janji)` — terima array Promise dan pulangkan Promise yang selesai dengan array semua nilai, mengikut susunan asal. Jangan `await` satu-satu dalam gelung.",
    starter: () => "async function kumpulSemua(janji) {\n\n}",
    cases: () => [
      { args: [EV("[Promise.resolve(1), Promise.resolve(2)]")], expected: [1, 2] },
      { args: [EV("[]")], expected: [] },
    ],
    syarat: () => [{ ujian: (s) => /Promise\.all/.test(s), mesej: "Guna `Promise.all` supaya semuanya berjalan serentak." }],
    hints: () => ["`await` dalam gelung memaksa satu demi satu — lambat.", "`return Promise.all(janji);`"],
    jawapan: () => "async function kumpulSemua(janji) {\n  return Promise.all(janji);\n}",
  },
  {
    bab: 12, jenis: "baiki", fn: "ambilNama",
    tajuk: "Terlupa await",
    brief: () => "`ambilNama(muat)` sepatutnya pulangkan `nama` daripada objek yang dipulangkan `muat()`. Sekarang ia pulangkan `undefined`. Baiki.",
    starter: () => "async function ambilNama(muat) {\n  const data = muat();\n  return data.nama;\n}",
    cases: () => [
      { args: [EV("() => Promise.resolve({ nama: 'Aina' })")], expected: "Aina" },
      { args: [EV("() => Promise.resolve({ nama: 'Bakri' })")], expected: "Bakri" },
    ],
    hints: () => ["`muat()` pulangkan Promise, bukan objek.", "Tambah `await` sebelum `muat()`."],
    jawapan: () => "async function ambilNama(muat) {\n  const data = await muat();\n  return data.nama;\n}",
  },
  {
    bab: 12, jenis: "pilih",
    tajuk: "Await dalam gelung",
    soalan: () => "Kau perlu ambil 50 rekod bebas dari API. Mana lebih baik?",
    pilihan: () => [
      "`Promise.all` supaya kesemua 50 berjalan serentak",
      "`for` dengan `await` di dalam, satu demi satu",
      "Panggil semuanya tanpa `await` dan harap ia siap",
      "Panggil dalam `setTimeout` berlainan",
    ],
    betul: () => 0,
    huraian: () => "Kerja bebas patut berjalan serentak. `await` dalam gelung menjadikan 50 panggilan × 200ms = 10 saat, sedangkan `Promise.all` selesai dalam ~200ms. Tetapi jika API ada had kadar, kau perlu had serentak — itu bab seterusnya dalam kerja sebenar.",
  },

  /* ================= BAB 13 — KESELAMATAN ================= */
  {
    bab: 13, jenis: "tulis", fn: "lepasHTML",
    tajuk: "Lepaskan HTML sebelum papar",
    brief: () => "Tulis `lepasHTML(s)` yang tukar `&` → `&amp;`, `<` → `&lt;`, `>` → `&gt;`, `\"` → `&quot;`. Susunan penting: `&` dahulu.",
    starter: () => "function lepasHTML(s) {\n\n}",
    cases: () => [
      U(["<b>hai</b>"], "&lt;b&gt;hai&lt;/b&gt;"),
      U(["a & b"], "a &amp; b"),
      U(['say "hi"'], "say &quot;hi&quot;"),
      U([""], ""),
      U(["<script>"], "&lt;script&gt;"),
    ],
    hints: () => ["Ganti `&` dahulu, kalau tidak kau akan melepaskan `&` dalam `&lt;` yang baru kau buat.", "`s.replace(/&/g, \"&amp;\")` kemudian yang lain."],
    jawapan: () => "function lepasHTML(s) {\n  return String(s)\n    .replace(/&/g, \"&amp;\")\n    .replace(/</g, \"&lt;\")\n    .replace(/>/g, \"&gt;\")\n    .replace(/\"/g, \"&quot;\");\n}",
  },
  {
    bab: 13, jenis: "pilih",
    tajuk: "Pertanyaan pangkalan data",
    soalan: () => "Kenapa `\"SELECT * FROM ahli WHERE nama = '\" + input + \"'\"` berbahaya?",
    pilihan: () => [
      "Input pengguna jadi sebahagian arahan SQL — dia boleh tulis arahan sendiri",
      "Ia lambat kerana penyambungan string",
      "Ia hanya masalah jika pangkalan data itu MySQL",
      "Tiada masalah selagi kau tapis perkataan `DROP`",
    ],
    betul: () => 0,
    huraian: () => "Penyelesaiannya bukan menapis perkataan (senarai hitam sentiasa boleh dipintas) tetapi pertanyaan berparameter: hantar SQL dan data secara berasingan, supaya pemacu tahu mana arahan dan mana nilai.",
  },
  {
    bab: 13, jenis: "kukuh", fn: "namaFailSelamat",
    tajuk: "Halang laluan menyeleweng",
    brief: () => "`namaFailSelamat(nama)` mesti baling ralat bermesej `\"nama fail tidak sah\"` jika nama mengandungi `..`, `/`, `\\`, atau kosong. Kalau selamat, pulangkan nama itu.",
    starter: () => "function namaFailSelamat(nama) {\n  return nama;\n}",
    cases: () => [
      U(["laporan.pdf"], "laporan.pdf"),
      B(["../../etc/passwd"], "tidak sah"),
      B(["folder/fail.txt"], "tidak sah"),
      B([""], "tidak sah"),
      B([null], "tidak sah"),
      U(["gambar_2024.png"], "gambar_2024.png"),
    ],
    hints: () => ["Semak jenis dahulu — `null.includes` akan pecah.", "Lebih selamat: benarkan hanya aksara yang kau jangka, contohnya `/^[\\w.-]+$/`."],
    jawapan: () => "function namaFailSelamat(nama) {\n  if (typeof nama !== \"string\" || nama === \"\") throw new Error(\"nama fail tidak sah\");\n  if (!/^[\\w.-]+$/.test(nama) || nama.includes(\"..\")) throw new Error(\"nama fail tidak sah\");\n  return nama;\n}",
  },
  {
    bab: 13, jenis: "pilih",
    tajuk: "Di mana kunci rahsia disimpan",
    soalan: () => "Kau perlu panggil API berbayar yang memerlukan kunci rahsia dari aplikasi web kau. Di mana kunci itu patut berada?",
    pilihan: () => [
      "Pada pelayan kau; browser panggil pelayan kau, pelayan panggil API",
      "Dalam kod JavaScript frontend, tetapi disamarkan",
      "Dalam localStorage selepas log masuk",
      "Dalam pembolehubah persekitaran yang dibundel ke frontend",
    ],
    betul: () => 0,
    huraian: () => "Apa sahaja yang sampai ke browser boleh dibaca — penyamaran, minifikasi dan pembolehubah persekitaran frontend semuanya tidak menyembunyikan apa-apa. Rahsia tinggal di pelayan; frontend bercakap dengan pelayan kau.",
  },

  /* ================= BAB 14 — UJIAN ================= */
  {
    bab: 14, jenis: "tulis", fn: "sama",
    tajuk: "Pembanding untuk ujian",
    brief: () => "Tulis `sama(a, b)` — perbandingan mendalam untuk nombor, string, array dan objek biasa. Susunan kunci objek tidak penting.",
    starter: () => "function sama(a, b) {\n\n}",
    cases: () => [
      U([1, 1], true), U([[1, 2], [1, 2]], true), U([[1, 2], [2, 1]], false),
      U([{ a: 1, b: 2 }, { b: 2, a: 1 }], true), U([{ a: 1 }, { a: 2 }], false),
      U([null, null], true), U([{ a: [1] }, { a: [1] }], true),
    ],
    hints: () => ["Mula dengan `a === b` untuk primitif.", "Untuk objek: bandingkan bilangan kunci, kemudian rekursi setiap kunci."],
    jawapan: () => "function sama(a, b) {\n  if (a === b) return true;\n  if (a === null || b === null) return false;\n  if (typeof a !== \"object\" || typeof b !== \"object\") return false;\n  if (Array.isArray(a) !== Array.isArray(b)) return false;\n  const ka = Object.keys(a), kb = Object.keys(b);\n  if (ka.length !== kb.length) return false;\n  return ka.every((k) => sama(a[k], b[k]));\n}",
  },
  {
    bab: 14, jenis: "pilih",
    tajuk: "Ujian yang bernilai",
    soalan: () => "Kau baru tulis `diskaun(harga, peratus)`. Ujian mana paling penting ditulis dahulu?",
    pilihan: () => [
      "Kes sempadan: peratus 0, peratus 100, harga 0, peratus negatif",
      "Sepuluh kes dengan nombor rawak yang berbeza",
      "Satu kes yang biasa, itu sudah memadai",
      "Ujian yang memeriksa fungsi itu wujud",
    ],
    betul: () => 0,
    huraian: () => "Bug hidup di sempadan, bukan di tengah. Sepuluh nombor rawak dalam julat biasa menguji perkara yang sama sepuluh kali.",
  },
  {
    bab: 14, jenis: "baiki", fn: "ujiTambah",
    tajuk: "Ujian yang sentiasa lulus",
    brief: () => "`ujiTambah(tambah)` sepatutnya pulangkan `true` hanya jika fungsi `tambah` betul. Sekarang ia lulus untuk apa-apa sahaja. Baiki supaya ia benar-benar menguji.",
    starter: () => "function ujiTambah(tambah) {\n  tambah(1, 2);\n  return true;\n}",
    cases: () => [
      { args: [EV("(a, b) => a + b")], expected: true },
      { args: [EV("(a, b) => a - b")], expected: false },
      { args: [EV("() => 3")], expected: false },
    ],
    hints: () => ["Ujian mesti membandingkan hasil sebenar dengan hasil dijangka.", "Satu kes tidak cukup — `return 3` akan lulus ujian `1+2`."],
    jawapan: () => "function ujiTambah(tambah) {\n  return tambah(1, 2) === 3 && tambah(0, 0) === 0 && tambah(-1, 5) === 4;\n}",
  },

  /* ================= BAB 15 — REFACTOR ================= */
  {
    bab: 15, jenis: "baiki", fn: "kiraJumlahBil",
    tajuk: "Nama yang tak memberitahu apa-apa",
    brief: () => "Fungsi ini betul tetapi tiada siapa boleh membacanya. Namakan semula pembolehubah supaya bermakna. Tingkah laku mesti kekal sama.",
    starter: () => "function kiraJumlahBil(x) {\n  let a = 0;\n  for (const b of x) a += b.c * b.d;\n  return a;\n}",
    cases: () => [
      U([[{ c: 2, d: 3 }, { c: 1, d: 5 }]], 11),
      U([[]], 0),
      U([[{ c: 10, d: 1 }]], 10),
    ],
    syarat: () => [
      { ujian: (s) => !/\blet\s+a\s*=/.test(s), mesej: "Namakan semula `a` kepada sesuatu yang bermakna." },
      { ujian: (s) => !/\bof\s+x\b/.test(s), mesej: "Namakan semula parameter `x`." },
    ],
    hints: () => ["Nama yang baik menyatakan apa benda itu, bukan jenisnya.", "Contoh: `barang`, `jumlah`, `item.harga * item.kuantiti`."],
    jawapan: () => "function kiraJumlahBil(barang) {\n  let jumlah = 0;\n  for (const item of barang) jumlah += item.c * item.d;\n  return jumlah;\n}",
  },
  {
    bab: 15, jenis: "baiki", fn: "hantar",
    tajuk: "Keluarkan yang berulang",
    brief: () => "Tiga cabang mengulang logik format yang sama. Keluarkan ia menjadi satu tempat. Tingkah laku kekal sama.",
    starter: () => "function hantar(jenis, nama) {\n  if (jenis === \"emel\") return \"[EMEL] \" + nama.trim().toUpperCase();\n  if (jenis === \"sms\") return \"[SMS] \" + nama.trim().toUpperCase();\n  return \"[LAIN] \" + nama.trim().toUpperCase();\n}",
    cases: () => [
      U(["emel", " ali "], "[EMEL] ALI"),
      U(["sms", "budi"], "[SMS] BUDI"),
      U(["apa", " x"], "[LAIN] X"),
    ],
    syarat: () => [{ ujian: (s) => (s.match(/toUpperCase/g) || []).length === 1, mesej: "`toUpperCase` masih berulang. Satu tempat sahaja." }],
    hints: () => ["Kira nilai yang sama sekali dahulu, simpan dalam pembolehubah.", "Label boleh datang dari objek peta, bukan tiga `if`."],
    jawapan: () => "function hantar(jenis, nama) {\n  const label = { emel: \"EMEL\", sms: \"SMS\" }[jenis] || \"LAIN\";\n  const bersih = nama.trim().toUpperCase();\n  return `[${label}] ${bersih}`;\n}",
  },
  {
    bab: 15, jenis: "baiki", fn: "bolehMasuk",
    tajuk: "Ratakan sarang if",
    brief: () => "Empat lapis `if` bersarang. Tulis semula guna *early return* supaya laluan gagal keluar awal. Tingkah laku kekal sama.",
    starter: () => "function bolehMasuk(u) {\n  if (u) {\n    if (u.aktif) {\n      if (u.umur >= 18) {\n        if (u.bayar) {\n          return true;\n        }\n      }\n    }\n  }\n  return false;\n}",
    cases: () => [
      U([{ aktif: true, umur: 20, bayar: true }], true),
      U([{ aktif: false, umur: 20, bayar: true }], false),
      U([{ aktif: true, umur: 12, bayar: true }], false),
      U([null], false),
      U([{ aktif: true, umur: 20, bayar: false }], false),
    ],
    syarat: () => [{ ujian: (s) => (s.match(/\bif\s*\(/g) || []).length <= 4 && !/\{\s*if[\s\S]*\{\s*if[\s\S]*\{\s*if/.test(s), mesej: "Masih bersarang. Keluar awal untuk setiap kegagalan." }],
    hints: () => ["Balikkan setiap syarat dan `return false` serta-merta.", "Laluan berjaya berakhir rata di bawah, tanpa lekukan."],
    jawapan: () => "function bolehMasuk(u) {\n  if (!u) return false;\n  if (!u.aktif) return false;\n  if (u.umur < 18) return false;\n  if (!u.bayar) return false;\n  return true;\n}",
  },

  /* ================= BAB 16 — DEBUG ================= */
  {
    bab: 16, jenis: "baiki", fn: "cariIndeks",
    tajuk: "Binari yang tergantung",
    brief: () => "Carian binari ini kadangkala tak berhenti. Cari puncanya dan baiki.",
    starter: () => "function cariIndeks(arr, s) {\n  let kiri = 0, kanan = arr.length - 1;\n  while (kiri <= kanan) {\n    const t = Math.floor((kiri + kanan) / 2);\n    if (arr[t] === s) return t;\n    if (arr[t] < s) kiri = t;\n    else kanan = t;\n  }\n  return -1;\n}",
    cases: () => [U([[1, 3, 5, 7], 5], 2), U([[1, 3, 5, 7], 4], -1), U([[], 1], -1), U([[2], 2], 0), U([[1, 2, 3], 3], 2)],
    hints: () => ["Jika `kiri = t` dan `t` tidak berubah, julat tidak pernah mengecil.", "Gerakkan melepasi tengah: `t + 1` dan `t - 1`."],
    jawapan: () => "function cariIndeks(arr, s) {\n  let kiri = 0, kanan = arr.length - 1;\n  while (kiri <= kanan) {\n    const t = Math.floor((kiri + kanan) / 2);\n    if (arr[t] === s) return t;\n    if (arr[t] < s) kiri = t + 1;\n    else kanan = t - 1;\n  }\n  return -1;\n}",
  },
  {
    bab: 16, jenis: "baiki", fn: "hampirSama",
    tajuk: "Perpuluhan menipu",
    brief: () => "`hampirSama(a, b)` sepatutnya `true` bila dua nombor cukup dekat. `0.1 + 0.2 === 0.3` ialah `false` dalam JS. Baiki.",
    starter: () => "function hampirSama(a, b) {\n  return a === b;\n}",
    cases: () => [U([0.1 + 0.2, 0.3], true), U([1, 1], true), U([1, 1.5], false), U([0, 0.0000000001], true), U([5, 5.1], false)],
    hints: () => ["Nombor perpuluhan disimpan sebagai anggaran binari.", "Bandingkan beza mutlak dengan ambang kecil: `Math.abs(a - b) < 1e-9`."],
    jawapan: () => "function hampirSama(a, b) {\n  return Math.abs(a - b) < 1e-9;\n}",
  },
  {
    bab: 16, jenis: "baiki", fn: "buangGenap",
    tajuk: "Mengubah semasa melangkah",
    brief: () => "`buangGenap(arr)` sepatutnya pulangkan array tanpa nombor genap. Ia terlepas sebahagian kerana ia membuang elemen semasa gelung berjalan. Baiki.",
    starter: () => "function buangGenap(arr) {\n  const salinan = [...arr];\n  for (let i = 0; i < salinan.length; i++) {\n    if (salinan[i] % 2 === 0) salinan.splice(i, 1);\n  }\n  return salinan;\n}",
    cases: () => [U([[1, 2, 4, 5]], [1, 5]), U([[2, 2, 2]], []), U([[1, 3]], [1, 3]), U([[]], []), U([[2, 4, 1, 6, 8]], [1])],
    hints: () => ["Selepas `splice`, elemen seterusnya bergeser ke indeks semasa — kemudian `i++` melangkaunya.", "Bina array baharu sebaliknya, atau lalui dari belakang ke depan."],
    jawapan: () => "function buangGenap(arr) {\n  return arr.filter((x) => x % 2 !== 0);\n}",
  },

  /* ================= BAB 17 — CODE REVIEW ================= */
  {
    bab: 17, jenis: "pilih",
    tajuk: "Membalas ulasan yang tajam",
    soalan: () => "Pengulas menulis: \"Kod ini teruk, siapa yang tulis macam ni?\" Apa balasan terbaik?",
    pilihan: () => [
      "\"Boleh tunjuk bahagian mana dan apa masalahnya? Saya nak faham supaya boleh baiki.\"",
      "\"Kalau awak boleh buat lebih baik, buat sendiri.\"",
      "Diam, terima semua, tukar apa sahaja yang dia mahu",
      "Balas dengan mengkritik kod dia pula",
    ],
    betul: () => 0,
    huraian: () => "Alihkan perbualan daripada penilaian kepada butiran teknikal. Kau dapat maklumat yang berguna, dan nada perbualan berubah tanpa kau perlu berlawan. Jika corak itu berulang, itu isu untuk dibawa kepada ketua, bukan untuk dilawan dalam ulasan.",
  },
  {
    bab: 17, jenis: "pilih",
    tajuk: "Laporan bug yang boleh ditindak",
    soalan: () => "Apa yang mesti ada dalam laporan bug supaya orang boleh terus membaikinya?",
    pilihan: () => [
      "Langkah menghasilkan semula, apa yang dijangka, apa yang berlaku, dan persekitaran",
      "Tangkapan skrin sahaja",
      "\"Tak jalan\" dengan nombor tiket",
      "Penjelasan panjang tentang kesan kepada perniagaan",
    ],
    betul: () => 0,
    huraian: () => "Tanpa langkah menghasilkan semula, pembangun menghabiskan masa meneka. Empat perkara itu memotong masa siasatan lebih daripada apa-apa lagi.",
  },
  {
    bab: 17, jenis: "pilih",
    tajuk: "Bila kau tak tahu",
    soalan: () => "Dalam temuduga teknikal kau ditanya sesuatu yang kau tak tahu. Apa yang paling kuat?",
    pilihan: () => [
      "\"Saya tak pernah guna itu. Berdasarkan apa yang saya tahu, saya jangka ia berfungsi begini — betul?\"",
      "Diam sampai penemuduga tukar soalan",
      "Teka dengan yakin dan harap ia betul",
      "\"Saya tak tahu.\" dan berhenti di situ",
    ],
    betul: () => 0,
    huraian: () => "Penemuduga menilai cara kau berfikir bila kau buntu, kerana itulah keadaan kerja sebenar. Mengaku had pengetahuan kemudian menaakul dengan kuat menunjukkan kedua-dua kejujuran dan kemahiran.",
  },
];

/* ============================================================
   BANK TAMBAHAN — variasi kedua untuk setiap bab
   ============================================================ */
const TUGAS_TAMBAHAN = [
  /* ===== BAB 1 ===== */
  {
    bab: 1, jenis: "tulis", fn: "keSen",
    tajuk: "Ringgit kepada sen",
    gen: (r) => ({ h: ri(r, 1, 400) + ri(r, 0, 99) / 100 }),
    brief: () => "Wang disimpan sebagai integer sen supaya tiada ralat perpuluhan. Tulis `keSen(ringgit)` yang pulangkan integer sen.",
    starter: () => "function keSen(ringgit) {\n\n}",
    cases: (p) => [U([19.99], 1999), U([0], 0), U([0.1 + 0.2], 30), U([p.h], Math.round(p.h * 100))],
    hints: () => ["`0.1 + 0.2` ialah 0.30000000000000004 dalam JS.", "`Math.round(ringgit * 100)` membuang ralat itu."],
    jawapan: () => "function keSen(ringgit) {\n  return Math.round(ringgit * 100);\n}",
  },
  {
    bab: 1, jenis: "ramal",
    tajuk: "typeof yang menipu",
    gen: (r) => ({ x: rp(r, [["null", "object"], ["[]", "object"], ["NaN", "number"], ["undefined", "undefined"], ["(() => {})", "function"]]) }),
    kod: (p) => `console.log(typeof ${p.x[0]});`,
    output: (p) => p.x[1],
    brief: () => "Apa yang dicetak?",
    hints: () => ["`typeof null` ialah `\"object\"` — pepijat lama JS yang tak pernah dibaiki.", "Array juga `\"object\"`. Guna `Array.isArray()` untuk semak array."],
  },
  {
    bab: 1, jenis: "pilih",
    tajuk: "const, let atau var",
    soalan: () => "Mana amalan yang betul untuk mengisytihar pembolehubah hari ini?",
    pilihan: () => [
      "`const` sebagai default, `let` bila nilai perlu berubah, jangan guna `var`",
      "`var` di mana-mana, ia paling serasi",
      "`let` sentiasa, `const` menyusahkan",
      "Tiada beza, ketiga-tiganya sama",
    ],
    betul: () => 0,
    huraian: () => "`var` bocor keluar dari blok dan boleh diisytihar semula tanpa amaran. `const` menghalang penetapan semula — ia tidak membekukan isi objek, tetapi ia menandakan niat kau kepada pembaca seterusnya.",
  },
  {
    bab: 1, jenis: "baiki", fn: "jumlahInput",
    tajuk: "Nilai dari borang ialah string",
    brief: () => "`jumlahInput(a, b)` menerima nilai dari medan borang, yang sentiasa string. Sekarang `\"5\" + \"3\"` jadi `\"53\"`. Baiki supaya ia sentiasa pulangkan nombor.",
    starter: () => "function jumlahInput(a, b) {\n  return a + b;\n}",
    cases: () => [U(["5", "3"], 8), U([5, 3], 8), U(["0", "0"], 0), U(["1.5", "2.5"], 4)],
    hints: () => ["`Number(x)` tukar string kepada nombor.", "`return Number(a) + Number(b);`"],
    jawapan: () => "function jumlahInput(a, b) {\n  return Number(a) + Number(b);\n}",
  },
  {
    bab: 1, jenis: "tulis", fn: "bulatKe",
    tajuk: "Bulatkan ke tempat perpuluhan",
    brief: () => "Tulis `bulatKe(n, tempat)` yang bulatkan `n` kepada bilangan tempat perpuluhan yang diberi.",
    starter: () => "function bulatKe(n, tempat) {\n\n}",
    cases: () => [U([3.14159, 2], 3.14), U([2.567, 1], 2.6), U([10, 0], 10), U([1.2345, 3], 1.235)],
    hints: () => ["Darab, bulatkan, bahagi balik.", "`Math.round(n * 10 ** tempat) / 10 ** tempat`"],
    jawapan: () => "function bulatKe(n, tempat) {\n  const f = 10 ** tempat;\n  return Math.round(n * f) / f;\n}",
  },

  /* ===== BAB 2 ===== */
  {
    bab: 2, jenis: "tulis", fn: "hariMinggu",
    tajuk: "Nombor kepada nama hari",
    brief: () => "Tulis `hariMinggu(n)`. 0 → \"Ahad\", 1 → \"Isnin\", … 6 → \"Sabtu\". Luar julat → \"tidak sah\".",
    starter: () => "function hariMinggu(n) {\n\n}",
    cases: () => [U([0], "Ahad"), U([3], "Rabu"), U([6], "Sabtu"), U([7], "tidak sah"), U([-1], "tidak sah")],
    hints: () => ["Array lebih bersih daripada tujuh `if`.", "`const h = [\"Ahad\", …]; return h[n] || \"tidak sah\";` — tetapi hati-hati dengan indeks negatif."],
    jawapan: () => "function hariMinggu(n) {\n  const h = [\"Ahad\", \"Isnin\", \"Selasa\", \"Rabu\", \"Khamis\", \"Jumaat\", \"Sabtu\"];\n  if (!Number.isInteger(n) || n < 0 || n > 6) return \"tidak sah\";\n  return h[n];\n}",
  },
  {
    bab: 2, jenis: "tulis", fn: "tambang",
    tajuk: "Tambang bas mengikut umur",
    brief: () => "Tulis `tambang(umur)`: bawah 7 → 0, 7–17 → 1.5, 18–59 → 3, 60 ke atas → 1.",
    starter: () => "function tambang(umur) {\n\n}",
    cases: () => [U([3], 0), U([7], 1.5), U([17], 1.5), U([18], 3), U([59], 3), U([60], 1), U([80], 1)],
    hints: () => ["Susun dari kecil ke besar, kemudian `return` awal.", "Semak sempadan: 6/7, 17/18, 59/60."],
    jawapan: () => "function tambang(umur) {\n  if (umur < 7) return 0;\n  if (umur < 18) return 1.5;\n  if (umur < 60) return 3;\n  return 1;\n}",
  },
  {
    bab: 2, jenis: "ramal",
    tajuk: "Ternary berlapis",
    gen: (r) => ({ n: ri(r, 1, 15) }),
    kod: (p) => `const n = ${p.n};\nconsole.log(n > 10 ? "besar" : n > 5 ? "sederhana" : "kecil");`,
    output: (p) => (p.n > 10 ? "besar" : p.n > 5 ? "sederhana" : "kecil"),
    brief: () => "Apa yang dicetak?",
    hints: () => ["Baca dari kiri: syarat pertama diperiksa dahulu.", "Kalau gagal, keseluruhan bahagian selepas `:` diperiksa pula."],
  },
  {
    bab: 2, jenis: "pilih",
    tajuk: "Menyongsangkan logik",
    soalan: () => "Apa yang sama makna dengan `!(a && b)`?",
    pilihan: () => ["`!a || !b`", "`!a && !b`", "`a || b`", "`!(a) && b`"],
    betul: () => 0,
    huraian: () => "Hukum De Morgan: songsangkan setiap bahagian dan tukar `&&` menjadi `||`. Berguna semasa membalikkan syarat untuk *early return* — \"jika bukan (aktif dan berbayar)\" menjadi \"jika tidak aktif atau tidak berbayar\".",
  },
  {
    bab: 2, jenis: "baiki", fn: "adaStok",
    tajuk: "Satu tanda sama dengan",
    brief: () => "`adaStok(n)` sepatutnya pulangkan `true` hanya bila `n` lebih besar daripada 0. Ia sentiasa pulangkan `true` dan diam-diam menukar nilai input. Baiki.",
    starter: () => "function adaStok(n) {\n  if (n = 0) return false;\n  return true;\n}",
    cases: () => [U([0], false), U([5], true), U([-1], false), U([1], true)],
    hints: () => ["`=` menetapkan nilai. `===` membandingkan.", "`if (n = 0)` menetapkan n kepada 0, kemudian menilai 0 sebagai falsy."],
    jawapan: () => "function adaStok(n) {\n  return n > 0;\n}",
  },

  /* ===== BAB 3 ===== */
  {
    bab: 3, jenis: "tulis", fn: "fizzbuzz",
    tajuk: "Fizz, Buzz",
    brief: () => "Tulis `fizzbuzz(n)` yang pulangkan array string 1 hingga n. Gandaan 3 → \"Fizz\", gandaan 5 → \"Buzz\", gandaan kedua-duanya → \"FizzBuzz\", selain itu nombor sebagai string.",
    starter: () => "function fizzbuzz(n) {\n\n}",
    cases: () => [
      U([5], ["1", "2", "Fizz", "4", "Buzz"]),
      U([0], []),
      U([15], ["1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz", "11", "Fizz", "13", "14", "FizzBuzz"]),
    ],
    hints: () => ["Periksa gandaan 15 dahulu, kalau tidak \"FizzBuzz\" tak pernah tercapai.", "`String(i)` untuk nombor biasa — ujian membandingkan string."],
    jawapan: () => "function fizzbuzz(n) {\n  const hasil = [];\n  for (let i = 1; i <= n; i++) {\n    if (i % 15 === 0) hasil.push(\"FizzBuzz\");\n    else if (i % 3 === 0) hasil.push(\"Fizz\");\n    else if (i % 5 === 0) hasil.push(\"Buzz\");\n    else hasil.push(String(i));\n  }\n  return hasil;\n}",
  },
  {
    bab: 3, jenis: "tulis", fn: "maksimum",
    tajuk: "Nilai terbesar, tanpa Math.max",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 4, 8) }, () => ri(r, -30, 90)) }),
    brief: () => "Tulis `maksimum(arr)` guna gelung sahaja. Array kosong → `null`. Jangan guna `Math.max`.",
    starter: () => "function maksimum(arr) {\n\n}",
    cases: (p) => [U([[3, 9, 2]], 9), U([[]], null), U([[-5, -1]], -1), U([[7]], 7), U([p.arr], Math.max(...p.arr))],
    syarat: () => [{ ujian: (s) => !/Math\.max|\.sort\s*\(/.test(s), mesej: "Guna gelung — bukan `Math.max` atau `sort`." }],
    hints: () => ["Mula dengan `arr[0]` sebagai calon, bukan 0 — kalau tidak nombor negatif akan pecah.", "Bandingkan setiap elemen dengan calon semasa."],
    jawapan: () => "function maksimum(arr) {\n  if (arr.length === 0) return null;\n  let terbesar = arr[0];\n  for (const x of arr) if (x > terbesar) terbesar = x;\n  return terbesar;\n}",
  },
  {
    bab: 3, jenis: "ramal",
    tajuk: "Continue dan break",
    kod: () => `let j = 0;\nfor (let i = 1; i <= 6; i++) {\n  if (i % 2 === 0) continue;\n  if (i > 4) break;\n  j += i;\n}\nconsole.log(j);`,
    output: () => "4",
    brief: () => "Apa nilai akhir `j`?",
    hints: () => ["`continue` langkau baki badan gelung; `break` keluar terus.", "Jejak setiap i: 1, 2, 3, 4, 5 — mana yang benar-benar ditambah?"],
  },
  {
    bab: 3, jenis: "baiki", fn: "kiraTurun",
    tajuk: "Gelung yang tak pernah berhenti",
    brief: () => "`kiraTurun(n)` sepatutnya pulangkan `[n, n-1, …, 1]`. Sekarang ia tergantung selamanya. Cari sebabnya.",
    starter: () => "function kiraTurun(n) {\n  const hasil = [];\n  while (n > 0) {\n    hasil.push(n);\n  }\n  return hasil;\n}",
    cases: () => [U([3], [3, 2, 1]), U([0], []), U([1], [1]), U([5], [5, 4, 3, 2, 1])],
    hints: () => ["Setiap `while` mesti ada sesuatu yang mengubah syaratnya.", "`n` tak pernah berkurang, jadi `n > 0` kekal benar."],
    jawapan: () => "function kiraTurun(n) {\n  const hasil = [];\n  while (n > 0) {\n    hasil.push(n);\n    n--;\n  }\n  return hasil;\n}",
  },
  {
    bab: 3, jenis: "tulis", fn: "sifir",
    tajuk: "Sifir sampai sepuluh",
    gen: (r) => ({ n: ri(r, 2, 12) }),
    brief: () => "Tulis `sifir(n)` yang pulangkan array `[n×1, n×2, …, n×10]`.",
    starter: () => "function sifir(n) {\n\n}",
    cases: (p) => [U([3], [3, 6, 9, 12, 15, 18, 21, 24, 27, 30]), U([1], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), U([p.n], Array.from({ length: 10 }, (_, i) => p.n * (i + 1)))],
    hints: () => ["Gelung dari 1 hingga 10.", "`hasil.push(n * i)`"],
    jawapan: () => "function sifir(n) {\n  const hasil = [];\n  for (let i = 1; i <= 10; i++) hasil.push(n * i);\n  return hasil;\n}",
  },

  /* ===== BAB 4 ===== */
  {
    bab: 4, jenis: "tulis", fn: "guna",
    tajuk: "Fungsi sebagai hujah",
    brief: () => "Tulis `guna(fn, kali)` yang panggil `fn(i)` untuk `i` dari 0 hingga `kali-1`, dan pulangkan array hasilnya.",
    starter: () => "function guna(fn, kali) {\n\n}",
    cases: () => [
      { args: [EV("(i) => i * 2"), 3], expected: [0, 2, 4] },
      { args: [EV("(i) => 'a' + i"), 2], expected: ["a0", "a1"] },
      { args: [EV("(i) => i"), 0], expected: [] },
    ],
    hints: () => ["Fungsi ialah nilai biasa — kau boleh hantar dan panggil ia.", "`hasil.push(fn(i))` dalam gelung."],
    jawapan: () => "function guna(fn, kali) {\n  const hasil = [];\n  for (let i = 0; i < kali; i++) hasil.push(fn(i));\n  return hasil;\n}",
  },
  {
    bab: 4, jenis: "tulis", fn: "gunaDua",
    tajuk: "Sambung dua fungsi",
    brief: () => "Tulis `gunaDua(f, g, x)` yang pulangkan `f(g(x))` — jalankan `g` dahulu, kemudian suapkan hasilnya ke `f`.",
    starter: () => "function gunaDua(f, g, x) {\n\n}",
    cases: () => [
      { args: [EV("(n) => n + 1"), EV("(n) => n * 2"), 5], expected: 11 },
      { args: [EV("(s) => s.toUpperCase()"), EV("(s) => s.trim()"), "  ali "], expected: "ALI" },
    ],
    hints: () => ["Dalam ke luar: `g(x)` dahulu.", "`return f(g(x));`"],
    jawapan: () => "function gunaDua(f, g, x) {\n  return f(g(x));\n}",
  },
  {
    bab: 4, jenis: "ramal",
    tajuk: "Apa yang boleh diubah fungsi",
    kod: () => `function ubah(o, n) {\n  o.a = 9;\n  n = 9;\n}\nconst obj = { a: 1 };\nlet num = 1;\nubah(obj, num);\nconsole.log(obj.a + "," + num);`,
    output: () => "9,1",
    brief: () => "Apa yang dicetak?",
    hints: () => ["Nombor dihantar sebagai salinan nilai.", "Objek dihantar sebagai salinan rujukan — fungsi masih boleh mencapai objek yang sama."],
  },
  {
    bab: 4, jenis: "pilih",
    tajuk: "Fungsi tulen",
    soalan: () => "Apa yang menjadikan sebuah fungsi *tulen* (pure)?",
    pilihan: () => [
      "Input sama sentiasa beri output sama, dan ia tidak menyentuh apa-apa di luar dirinya",
      "Ia ditulis sebagai arrow function",
      "Ia tidak menerima sebarang parameter",
      "Ia kurang daripada sepuluh baris",
    ],
    betul: () => 0,
    huraian: () => "Fungsi tulen mudah diuji kerana kau tidak perlu menyediakan apa-apa keadaan dahulu, dan mudah dipercayai kerana ia tidak boleh merosakkan benda lain. Kod yang menyentuh pangkalan data, jam atau rangkaian tidak tulen — asingkan bahagian itu supaya bahagian logik kekal tulen.",
  },

  /* ===== BAB 5 ===== */
  {
    bab: 5, jenis: "tulis", fn: "susunNaik",
    tajuk: "Susun tanpa merosakkan asal",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 4, 7) }, () => ri(r, 1, 99)) }),
    brief: () => "Tulis `susunNaik(arr)` yang pulangkan salinan tersusun menaik. Array asal tidak boleh berubah.",
    starter: () => "function susunNaik(arr) {\n\n}",
    cases: (p) => [U([[3, 1, 2]], [1, 2, 3]), U([[10, 9, 1]], [1, 9, 10]), U([[]], []), U([p.arr], [...p.arr].sort((a, b) => a - b))],
    syarat: () => [{ ujian: (s) => !/\barr\.sort\s*\(/.test(s), mesej: "`arr.sort()` menyusun array asal. Salin dahulu." }],
    hints: () => ["`sort` mengubah array di tempatnya — salin dengan `[...arr]`.", "Untuk nombor kau mesti beri pembanding: `.sort((a, b) => a - b)`."],
    jawapan: () => "function susunNaik(arr) {\n  return [...arr].sort((a, b) => a - b);\n}",
  },
  {
    bab: 5, jenis: "tulis", fn: "belah",
    tajuk: "Belah kepada kumpulan",
    gen: (r) => ({ saiz: ri(r, 2, 4) }),
    brief: () => "Tulis `belah(arr, saiz)` yang pecahkan array kepada kumpulan sebesar `saiz`. Kumpulan terakhir boleh lebih kecil.",
    starter: () => "function belah(arr, saiz) {\n\n}",
    cases: () => [U([[1, 2, 3, 4, 5], 2], [[1, 2], [3, 4], [5]]), U([[], 3], []), U([[1, 2, 3], 3], [[1, 2, 3]]), U([[1], 5], [[1]])],
    hints: () => ["Melompat `saiz` langkah setiap kali: `i += saiz`.", "`arr.slice(i, i + saiz)` ambil satu kumpulan."],
    jawapan: () => "function belah(arr, saiz) {\n  const hasil = [];\n  for (let i = 0; i < arr.length; i += saiz) hasil.push(arr.slice(i, i + saiz));\n  return hasil;\n}",
  },
  {
    bab: 5, jenis: "tulis", fn: "gandingkan",
    tajuk: "Gandingkan dua array",
    brief: () => "Tulis `gandingkan(a, b)` yang pulangkan array pasangan `[a[i], b[i]]`. Berhenti pada array yang lebih pendek.",
    starter: () => "function gandingkan(a, b) {\n\n}",
    cases: () => [U([[1, 2], ["x", "y"]], [[1, "x"], [2, "y"]]), U([[1, 2, 3], ["x"]], [[1, "x"]]), U([[], []], [])],
    hints: () => ["Panjang gelung ialah `Math.min(a.length, b.length)`.", "`hasil.push([a[i], b[i]])`"],
    jawapan: () => "function gandingkan(a, b) {\n  const n = Math.min(a.length, b.length);\n  const hasil = [];\n  for (let i = 0; i < n; i++) hasil.push([a[i], b[i]]);\n  return hasil;\n}",
  },
  {
    bab: 5, jenis: "ramal",
    tajuk: "Sort yang mengejutkan",
    kod: () => `console.log([10, 9, 1].sort().join(","));`,
    output: () => "1,10,9",
    brief: () => "Apa yang dicetak?",
    hints: () => ["`sort` tanpa pembanding menukar setiap elemen kepada string.", "Sebagai string, \"10\" datang sebelum \"9\"."],
  },
  {
    bab: 5, jenis: "baiki", fn: "tigaTeratas",
    tajuk: "Sort yang merosakkan input",
    brief: () => "`tigaTeratas(arr)` sepatutnya pulangkan 3 nombor terbesar menurun, tanpa mengubah `arr`. Baiki.",
    starter: () => "function tigaTeratas(arr) {\n  return arr.sort((a, b) => b - a).slice(0, 3);\n}",
    cases: () => [U([[1, 9, 5, 3]], [9, 5, 3]), U([[2]], [2]), U([[]], []), U([[4, 4, 4, 4]], [4, 4, 4])],
    syarat: () => [{ ujian: (s) => !/\barr\.sort\s*\(/.test(s), mesej: "Masih menyusun `arr` secara terus. Salin dahulu." }],
    hints: () => ["`sort` sentiasa mengubah array yang dipanggil.", "`[...arr].sort((a, b) => b - a).slice(0, 3)`"],
    jawapan: () => "function tigaTeratas(arr) {\n  return [...arr].sort((a, b) => b - a).slice(0, 3);\n}",
  },

  /* ===== BAB 6 ===== */
  {
    bab: 6, jenis: "tulis", fn: "terbalik",
    tajuk: "Terbalikkan string",
    gen: (r) => ({ s: rp(r, ["hujan", "komputer", "sekolah", "bendera"]) }),
    brief: () => "Tulis `terbalik(s)` yang pulangkan string terbalik.",
    starter: () => "function terbalik(s) {\n\n}",
    cases: (p) => [U(["abc"], "cba"), U([""], ""), U(["a"], "a"), U([p.s], [...p.s].reverse().join(""))],
    hints: () => ["String tidak boleh diubah, tetapi array boleh.", "`[...s].reverse().join(\"\")`"],
    jawapan: () => "function terbalik(s) {\n  return [...s].reverse().join(\"\");\n}",
  },
  {
    bab: 6, jenis: "tulis", fn: "kiraHuruf",
    tajuk: "Kira kemunculan huruf",
    brief: () => "Tulis `kiraHuruf(s, huruf)` yang kira berapa kali `huruf` muncul dalam `s`. Abaikan huruf besar/kecil.",
    starter: () => "function kiraHuruf(s, huruf) {\n\n}",
    cases: () => [U(["Malaysia", "a"], 3), U(["", "a"], 0), U(["AAA", "a"], 3), U(["kucing", "z"], 0)],
    hints: () => ["Kecilkan kedua-duanya dahulu supaya perbandingan adil.", "Gelung setiap aksara dan kira yang sepadan."],
    jawapan: () => "function kiraHuruf(s, huruf) {\n  const t = s.toLowerCase();\n  const h = huruf.toLowerCase();\n  let n = 0;\n  for (const c of t) if (c === h) n++;\n  return n;\n}",
  },
  {
    bab: 6, jenis: "ramal",
    tajuk: "Indeks negatif",
    kod: () => `const s = "penyelesaian";\nconsole.log(s.slice(-4));`,
    output: () => "aian",
    brief: () => "Apa yang dicetak?",
    hints: () => ["Indeks negatif dalam `slice` dikira dari hujung.", "`-4` bermakna empat aksara terakhir. `substring` pula tidak menyokong ini."],
  },
  {
    bab: 6, jenis: "tulis", fn: "tajukKes",
    tajuk: "Besarkan setiap perkataan",
    brief: () => "Tulis `tajukKes(s)` yang besarkan huruf pertama setiap perkataan dan kecilkan yang lain. `\"nasi LEMAK panas\"` → `\"Nasi Lemak Panas\"`.",
    starter: () => "function tajukKes(s) {\n\n}",
    cases: () => [U(["nasi LEMAK panas"], "Nasi Lemak Panas"), U([""], ""), U(["a"], "A"), U(["satu"], "Satu")],
    hints: () => ["Pecah ikut ruang, proses setiap kepingan, sambung balik.", "`w[0].toUpperCase() + w.slice(1).toLowerCase()`"],
    jawapan: () => "function tajukKes(s) {\n  if (!s) return \"\";\n  return s.split(\" \").map((w) => (w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w)).join(\" \");\n}",
  },

  /* ===== BAB 7 ===== */
  {
    bab: 7, jenis: "tulis", fn: "balikObjek",
    tajuk: "Tukar kunci dengan nilai",
    brief: () => "Tulis `balikObjek(obj)` yang tukar kunci menjadi nilai dan sebaliknya. `{a: 1, b: 2}` → `{\"1\": \"a\", \"2\": \"b\"}`.",
    starter: () => "function balikObjek(obj) {\n\n}",
    cases: () => [U([{ a: 1, b: 2 }], { 1: "a", 2: "b" }), U([{}], {}), U([{ x: "y" }], { y: "x" })],
    hints: () => ["`Object.entries(obj)` beri array `[kunci, nilai]`.", "Kunci objek sentiasa menjadi string."],
    jawapan: () => "function balikObjek(obj) {\n  const hasil = {};\n  for (const [k, v] of Object.entries(obj)) hasil[v] = k;\n  return hasil;\n}",
  },
  {
    bab: 7, jenis: "tulis", fn: "ambilKunci",
    tajuk: "Ambil kunci tertentu sahaja",
    brief: () => "Tulis `ambilKunci(obj, kunci)` di mana `kunci` ialah array nama. Pulangkan objek baharu yang hanya mengandungi kunci itu — langkau yang tiada.",
    starter: () => "function ambilKunci(obj, kunci) {\n\n}",
    cases: () => [
      U([{ a: 1, b: 2, c: 3 }, ["a", "c"]], { a: 1, c: 3 }),
      U([{ a: 1 }, ["z"]], {}),
      U([{ a: 0 }, ["a"]], { a: 0 }),
      U([{}, []], {}),
    ],
    hints: () => ["Guna `k in obj` untuk semak kewujudan — jangan guna `obj[k] ?` kerana nilai 0 dan false adalah sah.", "Bina objek kosong dan isi satu demi satu."],
    jawapan: () => "function ambilKunci(obj, kunci) {\n  const hasil = {};\n  for (const k of kunci) if (k in obj) hasil[k] = obj[k];\n  return hasil;\n}",
  },
  {
    bab: 7, jenis: "pilih",
    tajuk: "Melalui kunci objek",
    soalan: () => "Kenapa `Object.keys(obj)` biasanya lebih selamat daripada `for (const k in obj)`?",
    pilihan: () => [
      "`for...in` juga melalui kunci yang diwarisi dari prototaip",
      "`for...in` tidak berfungsi pada objek",
      "`Object.keys` lebih pantas dalam semua kes",
      "Tiada beza langsung",
    ],
    betul: () => 0,
    huraian: () => "`for...in` naik ke rantaian prototaip, jadi ia boleh mengambil sifat yang bukan milik objek itu sendiri. `Object.keys` hanya beri kunci milik objek — itu hampir sentiasa yang kau maksudkan.",
  },
  {
    bab: 7, jenis: "tulis", fn: "kiraKunci",
    tajuk: "Kira kunci bersarang",
    brief: () => "Tulis `kiraKunci(obj)` yang kira jumlah semua kunci, termasuk yang berada dalam objek bersarang. `{a: 1, b: {c: 2}}` → 3.",
    starter: () => "function kiraKunci(obj) {\n\n}",
    cases: () => [
      U([{ a: 1, b: { c: 2 } }], 3),
      U([{}], 0),
      U([{ a: { b: { c: 1 } } }], 3),
      U([{ a: 1, b: 2 }], 2),
    ],
    hints: () => ["Setiap kunci dikira 1, kemudian tambah kiraan dalam nilainya jika ia objek.", "Array bukan objek biasa di sini — anggap semua nilai objek sebagai boleh direkursi."],
    jawapan: () => "function kiraKunci(obj) {\n  let n = 0;\n  for (const k of Object.keys(obj)) {\n    n++;\n    const v = obj[k];\n    if (v && typeof v === \"object\") n += kiraKunci(v);\n  }\n  return n;\n}",
  },

  /* ===== BAB 8 ===== */
  {
    bab: 8, jenis: "tulis", fn: "fib",
    tajuk: "Fibonacci yang tak tergantung",
    brief: () => "Tulis `fib(n)`. `fib(0)` = 0, `fib(1)` = 1, selebihnya jumlah dua sebelumnya. Ujian termasuk `fib(35)` — rekursi naif akan tamat masa.",
    starter: () => "function fib(n) {\n\n}",
    cases: () => [U([0], 0), U([1], 1), U([10], 55), U([35], 9227465)],
    hints: () => ["Rekursi naif mengira `fib(30)` berjuta kali. Simpan hasil yang sudah dikira.", "Parameter tambahan: `function fib(n, memo = {})`, kemudian semak `memo[n]` sebelum mengira."],
    jawapan: () => "function fib(n, memo = {}) {\n  if (n <= 1) return n;\n  if (memo[n] !== undefined) return memo[n];\n  memo[n] = fib(n - 1, memo) + fib(n - 2, memo);\n  return memo[n];\n}",
  },
  {
    bab: 8, jenis: "tulis", fn: "dalamPokok",
    tajuk: "Kedalaman pokok",
    brief: () => "Nod ialah `{nilai, anak: []}`. Tulis `dalamPokok(pokok)` yang pulangkan kedalaman maksimum. `null` → 0, satu nod → 1.",
    starter: () => "function dalamPokok(pokok) {\n\n}",
    cases: () => [
      U([null], 0),
      U([{ nilai: 1, anak: [] }], 1),
      U([{ nilai: 1, anak: [{ nilai: 2, anak: [{ nilai: 3, anak: [] }] }] }], 3),
      U([{ nilai: 1, anak: [{ nilai: 2, anak: [] }, { nilai: 3, anak: [] }] }], 2),
    ],
    hints: () => ["1 + kedalaman anak yang paling dalam.", "`Math.max(...anak.map(dalamPokok))` — tetapi hati-hati bila senarai anak kosong."],
    jawapan: () => "function dalamPokok(pokok) {\n  if (!pokok) return 0;\n  const anak = pokok.anak || [];\n  if (anak.length === 0) return 1;\n  return 1 + Math.max(...anak.map(dalamPokok));\n}",
  },
  {
    bab: 8, jenis: "ramal",
    tajuk: "Susunan rekursi",
    kod: () => `function turun(n) {\n  if (n === 0) return "";\n  return turun(n - 1) + n;\n}\nconsole.log(turun(4));`,
    output: () => "1234",
    brief: () => "Apa yang dicetak?",
    hints: () => ["Panggilan rekursif berlaku sebelum penyambungan.", "Rekursi turun sampai 0 dahulu, kemudian membina semula ke atas."],
  },

  /* ===== BAB 9 ===== */
  {
    bab: 9, jenis: "tulis", fn: "anagram",
    tajuk: "Anagram",
    brief: () => "Tulis `anagram(a, b)` — `true` jika kedua-dua string mengandungi huruf yang sama. Abaikan ruang dan huruf besar/kecil.",
    starter: () => "function anagram(a, b) {\n\n}",
    cases: () => [U(["kuda", "daku"], true), U(["Batu", "buta"], true), U(["ali", "alii"], false), U(["", ""], true), U(["a b", "ba"], true)],
    hints: () => ["Bersihkan kedua-duanya, susun huruf, kemudian bandingkan.", "`[...s.toLowerCase().replace(/\\s/g, \"\")].sort().join(\"\")`"],
    jawapan: () => "function anagram(a, b) {\n  const bersih = (s) => [...s.toLowerCase().replace(/\\s/g, \"\")].sort().join(\"\");\n  return bersih(a) === bersih(b);\n}",
  },
  {
    bab: 9, jenis: "tulis", fn: "nomborHilang",
    tajuk: "Cari nombor yang hilang",
    brief: () => "`arr` mengandungi integer berbeza dari 1 hingga n, dengan satu nombor hilang (jadi panjangnya n−1). Tulis `nomborHilang(arr)` yang cari nombor itu.",
    starter: () => "function nomborHilang(arr) {\n\n}",
    cases: () => [U([[1, 2, 4, 5]], 3), U([[2]], 1), U([[1, 3]], 2), U([[1, 2, 3, 5]], 4)],
    hints: () => ["n ialah `arr.length + 1`.", "Jumlah 1 hingga n ialah `n * (n + 1) / 2`. Tolak jumlah sebenar."],
    jawapan: () => "function nomborHilang(arr) {\n  const n = arr.length + 1;\n  const sepatutnya = (n * (n + 1)) / 2;\n  const sebenar = arr.reduce((a, b) => a + b, 0);\n  return sepatutnya - sebenar;\n}",
  },
  {
    bab: 9, jenis: "tulis", fn: "susunGabung",
    tajuk: "Isihan gabungan",
    gen: (r) => ({ arr: Array.from({ length: ri(r, 5, 9) }, () => ri(r, 1, 60)) }),
    brief: () => "Laksanakan `susunGabung(arr)` — isihan gabungan. Belah dua, isih setiap separuh secara rekursif, kemudian cantumkan. Jangan guna `sort`.",
    starter: () => "function susunGabung(arr) {\n\n}",
    cases: (p) => [U([[3, 1, 2]], [1, 2, 3]), U([[]], []), U([[5]], [5]), U([[9, 8, 7, 1]], [1, 7, 8, 9]), U([p.arr], [...p.arr].sort((a, b) => a - b))],
    syarat: () => [{ ujian: (s) => !/\.sort\s*\(/.test(s), mesej: "Laksanakan sendiri — jangan guna `sort`." }],
    hints: () => ["Kes henti: array dengan 0 atau 1 elemen sudah tersusun.", "Cantum: bandingkan kepala kedua-dua separuh, ambil yang lebih kecil dahulu."],
    jawapan: () => "function susunGabung(arr) {\n  if (arr.length <= 1) return arr.slice();\n  const tengah = Math.floor(arr.length / 2);\n  const kiri = susunGabung(arr.slice(0, tengah));\n  const kanan = susunGabung(arr.slice(tengah));\n  const hasil = [];\n  let i = 0, j = 0;\n  while (i < kiri.length && j < kanan.length) {\n    if (kiri[i] <= kanan[j]) hasil.push(kiri[i++]);\n    else hasil.push(kanan[j++]);\n  }\n  return hasil.concat(kiri.slice(i), kanan.slice(j));\n}",
  },
  {
    bab: 9, jenis: "pilih",
    tajuk: "Kenapa peta lebih pantas",
    soalan: () => "Kau perlu semak 10,000 kali sama ada ID wujud dalam senarai 50,000 rekod. Apa yang patut kau buat dahulu?",
    pilihan: () => [
      "Bina `Set` atau `Map` sekali, kemudian setiap semakan menjadi O(1)",
      "Guna `arr.includes()` setiap kali — mudah dibaca",
      "Susun array dahulu, kemudian `includes`",
      "Pecahkan senarai kepada beberapa array kecil",
    ],
    betul: () => 0,
    huraian: () => "`includes` mengimbas seluruh array setiap kali: 10,000 × 50,000 = 500 juta perbandingan. Membina Set sekali kos 50,000, kemudian setiap semakan hampir percuma. Ini corak yang paling kerap menyelamatkan kod perlahan dalam kerja sebenar.",
  },

  /* ===== BAB 10 ===== */
  {
    bab: 10, jenis: "kukuh", fn: "ambilKonfig",
    tajuk: "Nilai lalai yang tidak menelan sifar",
    brief: () => "`ambilKonfig(obj, kunci, lalai)` mesti pulangkan nilai konfigurasi. Guna `lalai` hanya bila kunci itu benar-benar tiada. `0`, `false` dan `\"\"` adalah nilai yang sah.",
    starter: () => "function ambilKonfig(obj, kunci, lalai) {\n  return obj[kunci] || lalai;\n}",
    cases: () => [
      U([{ had: 5 }, "had", 10], 5),
      U([{ had: 0 }, "had", 10], 0),
      U([{ aktif: false }, "aktif", true], false),
      U([{ nama: "" }, "nama", "tiada"], ""),
      U([{}, "had", 10], 10),
      U([null, "had", 10], 10),
    ],
    hints: () => ["`||` menolak semua nilai falsy — termasuk 0 dan false yang sah.", "Semak `undefined` secara eksplisit, atau guna `??`."],
    jawapan: () => "function ambilKonfig(obj, kunci, lalai) {\n  if (!obj || typeof obj !== \"object\") return lalai;\n  return obj[kunci] === undefined ? lalai : obj[kunci];\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "tarikhSah",
    tajuk: "Sahkan tarikh",
    brief: () => "`tarikhSah(s)` mesti pulangkan `true` hanya untuk tarikh sebenar dalam format `YYYY-MM-DD`. Bulan 13 dan 30 Februari mesti ditolak. Bukan string → `false`.",
    starter: () => "function tarikhSah(s) {\n\n}",
    cases: () => [
      U(["2024-02-29"], true), U(["2023-02-29"], false), U(["2024-13-01"], false),
      U(["2024-1-1"], false), U([null], false), U(["hai"], false), U(["2024-12-31"], true),
    ],
    hints: () => ["Semak bentuk dengan regex dahulu: `/^\\d{4}-\\d{2}-\\d{2}$/`.", "Kemudian bina `Date` dan pastikan ia menghasilkan semula tarikh yang sama — itu menangkap 30 Februari."],
    jawapan: () => "function tarikhSah(s) {\n  if (typeof s !== \"string\" || !/^\\d{4}-\\d{2}-\\d{2}$/.test(s)) return false;\n  const d = new Date(s + \"T00:00:00Z\");\n  if (Number.isNaN(d.getTime())) return false;\n  return d.toISOString().slice(0, 10) === s;\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "hadSenarai",
    tajuk: "Tolak input yang terlalu besar",
    brief: () => "`hadSenarai(arr, maks)` memproses senarai daripada pengguna. Ia mesti baling ralat bermesej `\"terlalu banyak\"` jika panjang melebihi `maks`, dan `\"array\"` jika input bukan array. Kalau selamat, pulangkan panjangnya.",
    starter: () => "function hadSenarai(arr, maks) {\n  return arr.length;\n}",
    cases: () => [
      U([[1, 2], 5], 2), U([[], 5], 0),
      B([[1, 2, 3, 4, 5, 6], 5], "terlalu banyak"),
      B([null, 5], "array"), B(["abc", 5], "array"),
    ],
    hints: () => ["Input tanpa had ialah cara paling mudah untuk melumpuhkan pelayan kau.", "Semak jenis dahulu, kemudian panjang."],
    jawapan: () => "function hadSenarai(arr, maks) {\n  if (!Array.isArray(arr)) throw new Error(\"input mesti array\");\n  if (arr.length > maks) throw new Error(\"terlalu banyak item\");\n  return arr.length;\n}",
  },
  {
    bab: 10, jenis: "kukuh", fn: "kuantitiSah",
    tajuk: "Kuantiti pesanan",
    brief: () => "`kuantitiSah(k)` untuk pesanan. Mesti baling `\"kuantiti\"` jika `k` bukan integer positif (0, negatif, perpuluhan, string, null semuanya ditolak). Kalau sah, pulangkan `k`.",
    starter: () => "function kuantitiSah(k) {\n\n}",
    cases: () => [
      U([1], 1), U([50], 50),
      B([0], "kuantiti"), B([-2], "kuantiti"), B([1.5], "kuantiti"),
      B(["3"], "kuantiti"), B([null], "kuantiti"), B([NaN], "kuantiti"),
    ],
    hints: () => ["`Number.isInteger` menolak perpuluhan, NaN, string dan null sekali gus.", "Kemudian semak `k > 0`."],
    jawapan: () => "function kuantitiSah(k) {\n  if (!Number.isInteger(k) || k <= 0) throw new Error(\"kuantiti tidak sah\");\n  return k;\n}",
  },
  {
    bab: 10, jenis: "pilih",
    tajuk: "Di mana pengesahan berlaku",
    soalan: () => "Frontend kau sudah menyemak borang. Perlukah pelayan menyemak sekali lagi?",
    pilihan: () => [
      "Ya — sesiapa boleh menghantar permintaan terus ke pelayan tanpa melalui borang kau",
      "Tidak, itu kerja berulang yang membazir",
      "Hanya jika borang itu awam",
      "Hanya untuk medan kata laluan",
    ],
    betul: () => 0,
    huraian: () => "Pengesahan frontend adalah untuk pengalaman pengguna. Pengesahan backend adalah untuk keselamatan. Sesiapa boleh menghantar permintaan terus dengan `curl` — apa sahaja yang berlaku dalam browser tidak boleh dipercayai.",
  },

  /* ===== BAB 11 ===== */
  {
    bab: 11, jenis: "tulis", fn: "mesejPengguna",
    tajuk: "Terjemah kod ralat untuk pengguna",
    brief: () => "Tulis `mesejPengguna(kod)`:\n`\"TIADA_RANGKAIAN\"` → `\"Sambungan terputus. Cuba lagi.\"`\n`\"TIADA_AKSES\"` → `\"Anda tiada kebenaran untuk tindakan ini.\"`\n`\"TIDAK_JUMPA\"` → `\"Rekod tidak dijumpai.\"`\nKod lain → `\"Ralat tidak dijangka (<kod>).\"`",
    starter: () => "function mesejPengguna(kod) {\n\n}",
    cases: () => [
      U(["TIADA_RANGKAIAN"], "Sambungan terputus. Cuba lagi."),
      U(["TIADA_AKSES"], "Anda tiada kebenaran untuk tindakan ini."),
      U(["TIDAK_JUMPA"], "Rekod tidak dijumpai."),
      U(["XYZ"], "Ralat tidak dijangka (XYZ)."),
      U([""], "Ralat tidak dijangka ()."),
    ],
    hints: () => ["Objek peta lebih bersih daripada rantaian `if`.", "Fallback mesti masih mengandungi kod supaya sokongan boleh menjejakinya."],
    jawapan: () => "function mesejPengguna(kod) {\n  const peta = {\n    TIADA_RANGKAIAN: \"Sambungan terputus. Cuba lagi.\",\n    TIADA_AKSES: \"Anda tiada kebenaran untuk tindakan ini.\",\n    TIDAK_JUMPA: \"Rekod tidak dijumpai.\",\n  };\n  return peta[kod] || `Ralat tidak dijangka (${kod}).`;\n}",
  },
  {
    bab: 11, jenis: "tulis", fn: "sahkanSemua",
    tajuk: "Kumpul semua kegagalan",
    brief: () => "Tulis `sahkanSemua(senarai, semak)`. `semak(item)` pulangkan string ralat atau `null`. Pulangkan array `{indeks, ralat}` untuk setiap item yang gagal. Semua item mesti diperiksa — jangan berhenti pada yang pertama.",
    starter: () => "function sahkanSemua(senarai, semak) {\n\n}",
    cases: () => [
      { args: [[1, -2, 3, -4], EV("(x) => (x < 0 ? 'negatif' : null)")], expected: [{ indeks: 1, ralat: "negatif" }, { indeks: 3, ralat: "negatif" }] },
      { args: [[1, 2], EV("() => null")], expected: [] },
      { args: [[], EV("() => 'x'")], expected: [] },
    ],
    hints: () => ["Guna `forEach` atau gelung berindeks supaya kau ada nombor indeks.", "Tambah ke array hasil hanya bila `semak` pulangkan sesuatu."],
    jawapan: () => "function sahkanSemua(senarai, semak) {\n  const ralat = [];\n  senarai.forEach((item, indeks) => {\n    const r = semak(item);\n    if (r) ralat.push({ indeks, ralat: r });\n  });\n  return ralat;\n}",
  },
  {
    bab: 11, jenis: "baiki", fn: "simpan",
    tajuk: "Catch yang mencatat tetapi menipu",
    brief: () => "`simpan(data, tulis)` menangkap ralat, mencatatnya, kemudian pulangkan `true` seolah-olah berjaya. Pemanggil tidak pernah tahu ia gagal. Baiki: pulangkan `true` bila berjaya, `false` bila gagal.",
    starter: () => "function simpan(data, tulis) {\n  try {\n    tulis(data);\n  } catch (e) {\n    console.log(\"ralat:\", e.message);\n  }\n  return true;\n}",
    cases: () => [
      { args: [{ a: 1 }, EV("() => undefined")], expected: true },
      { args: [{ a: 1 }, EV("() => { throw new Error('cakera penuh'); }")], expected: false },
    ],
    hints: () => ["`return` mesti berada di dalam cabang yang betul.", "Berjaya dan gagal mesti menghasilkan nilai pulangan yang berbeza."],
    jawapan: () => "function simpan(data, tulis) {\n  try {\n    tulis(data);\n    return true;\n  } catch (e) {\n    console.log(\"gagal simpan:\", e.message);\n    return false;\n  }\n}",
  },
  {
    bab: 11, jenis: "pilih",
    tajuk: "Bila patut cuba semula",
    soalan: () => "Panggilan API kau gagal. Bila cuba semula automatik itu **berbahaya**?",
    pilihan: () => [
      "Bila operasi itu tidak idempoten — contohnya \"caj kad kredit\"",
      "Bila ralat itu ialah timeout rangkaian",
      "Bila pelayan pulangkan 503",
      "Bila kau hanya membaca data",
    ],
    betul: () => 0,
    huraian: () => "Cuba semula sesuai untuk kegagalan sementara pada operasi yang selamat diulang. Untuk operasi yang mengubah wang atau stok, kau perlu kunci idempoten supaya pelayan mengenali percubaan berulang sebagai permintaan yang sama, bukan permintaan baharu.",
  },
  {
    bab: 11, jenis: "pilih",
    tajuk: "Apa yang tak boleh masuk mesej ralat",
    soalan: () => "Mesej ralat mana yang tidak selamat dipaparkan kepada pengguna?",
    pilihan: () => [
      "`Log masuk gagal: tiada pengguna dengan emel ali@contoh.com dalam jadual ahli`",
      "`Emel atau kata laluan tidak betul.`",
      "`Sila isi medan emel.`",
      "`Sesi tamat. Sila log masuk semula.`",
    ],
    betul: () => 0,
    huraian: () => "Mesej itu mengesahkan emel mana yang wujud dalam sistem kau, dan mendedahkan struktur pangkalan data. Beri mesej yang sama untuk emel salah dan kata laluan salah; simpan butiran sebenar dalam log pelayan.",
  },

  /* ===== BAB 12 ===== */
  {
    bab: 12, jenis: "tulis", fn: "pertamaSiap",
    tajuk: "Yang pertama sampai",
    brief: () => "Tulis `pertamaSiap(janji)` yang pulangkan hasil Promise pertama yang selesai antara array yang diberi.",
    starter: () => "async function pertamaSiap(janji) {\n\n}",
    cases: () => [
      { args: [EV("[new Promise(r => setTimeout(() => r('lambat'), 50)), Promise.resolve('cepat')]")], expected: "cepat" },
      { args: [EV("[Promise.resolve(1)]")], expected: 1 },
    ],
    hints: () => ["`Promise.race` selesai sebaik sahaja satu daripadanya selesai.", "`return Promise.race(janji);`"],
    jawapan: () => "async function pertamaSiap(janji) {\n  return Promise.race(janji);\n}",
  },
  {
    bab: 12, jenis: "tulis", fn: "semuaKeputusan",
    tajuk: "Jangan biar satu kegagalan membunuh semua",
    brief: () => "Tulis `semuaKeputusan(janji)`. `Promise.all` gagal keseluruhannya jika satu gagal. Kau mahu array `{ok: true, nilai}` atau `{ok: false, ralat}` untuk setiap satu.",
    starter: () => "async function semuaKeputusan(janji) {\n\n}",
    cases: () => [
      { args: [EV("[Promise.resolve(1), Promise.reject(new Error('pecah'))]")], expected: [{ ok: true, nilai: 1 }, { ok: false, ralat: "pecah" }] },
      { args: [EV("[]")], expected: [] },
    ],
    hints: () => ["Balut setiap Promise: `p.then(v => ({ok: true, nilai: v}), e => ({ok: false, ralat: e.message}))`.", "Kemudian `Promise.all` pada array yang sudah dibalut — ia tak akan gagal lagi."],
    jawapan: () => "async function semuaKeputusan(janji) {\n  return Promise.all(\n    janji.map((p) =>\n      Promise.resolve(p).then(\n        (nilai) => ({ ok: true, nilai }),\n        (e) => ({ ok: false, ralat: e.message })\n      )\n    )\n  );\n}",
  },
  {
    bab: 12, jenis: "ramal",
    tajuk: "Apa yang dipulangkan async",
    kod: () => `async function beri() { return 5; }\nconsole.log(beri() instanceof Promise);`,
    output: () => "true",
    brief: () => "Apa yang dicetak? Taip `true` atau `false`.",
    hints: () => ["Fungsi `async` sentiasa membungkus nilai pulangannya dalam Promise.", "Itulah sebabnya kau mesti `await` walaupun fungsi itu tidak menunggu apa-apa."],
  },
  {
    bab: 12, jenis: "baiki", fn: "gandaDua",
    tajuk: "Rantaian then yang terputus",
    brief: () => "`gandaDua(muat)` sepatutnya pulangkan `n × 2` daripada objek yang dimuat. Ia pulangkan `undefined`. Baiki.",
    starter: () => "function gandaDua(muat) {\n  return muat().then((d) => {\n    d.n * 2;\n  });\n}",
    cases: () => [
      { args: [EV("() => Promise.resolve({ n: 4 })")], expected: 8 },
      { args: [EV("() => Promise.resolve({ n: 0 })")], expected: 0 },
    ],
    hints: () => ["Badan berkurungan memerlukan `return` yang eksplisit.", "Buang kurungan, atau tambah `return` di dalamnya."],
    jawapan: () => "function gandaDua(muat) {\n  return muat().then((d) => d.n * 2);\n}",
  },

  /* ===== BAB 13 ===== */
  {
    bab: 13, jenis: "tulis", fn: "sembunyiKad",
    tajuk: "Topeng nombor kad",
    brief: () => "Tulis `sembunyiKad(no)` yang menggantikan semua digit kecuali 4 terakhir dengan `*`. Kad kurang 4 digit → topeng semuanya.",
    starter: () => "function sembunyiKad(no) {\n\n}",
    cases: () => [
      U(["1234567812345678"], "************5678"),
      U(["12345"], "*2345"),
      U(["1234"], "1234"),
      U(["12"], "**"),
      U([""], ""),
    ],
    hints: () => ["Jika panjang 4 atau kurang dan lebih daripada 0, topeng semuanya.", "`\"*\".repeat(n - 4) + no.slice(-4)`"],
    jawapan: () => "function sembunyiKad(no) {\n  const s = String(no);\n  if (s.length <= 2) return \"*\".repeat(s.length);\n  if (s.length <= 4) return s.length === 4 ? s : \"*\".repeat(s.length);\n  return \"*\".repeat(s.length - 4) + s.slice(-4);\n}",
  },
  {
    bab: 13, jenis: "kukuh", fn: "urlSah",
    tajuk: "Hanya benarkan skema yang kau jangka",
    brief: () => "`urlSah(s)` mesti pulangkan `true` hanya untuk URL `http://` atau `https://`. `javascript:`, `data:` dan bukan string mesti ditolak.",
    starter: () => "function urlSah(s) {\n  return s.startsWith(\"http\");\n}",
    cases: () => [
      U(["https://contoh.com"], true), U(["http://contoh.com/a"], true),
      U(["javascript:alert(1)"], false), U(["data:text/html,x"], false),
      U(["httpx://jahat"], false), U([null], false), U([""], false),
      U(["  https://contoh.com"], false),
    ],
    hints: () => ["`startsWith(\"http\")` juga lulus untuk `httpx://` — senarai putih mesti tepat.", "Guna `new URL(s)` dalam try/catch dan periksa `u.protocol`."],
    jawapan: () => "function urlSah(s) {\n  if (typeof s !== \"string\" || s !== s.trim() || s === \"\") return false;\n  try {\n    const u = new URL(s);\n    return u.protocol === \"http:\" || u.protocol === \"https:\";\n  } catch {\n    return false;\n  }\n}",
  },
  {
    bab: 13, jenis: "kukuh", fn: "hadKadar",
    tajuk: "Had kadar mudah",
    brief: () => "`hadKadar(cap, sekarang, tetingkap, maks)` — `cap` ialah array cap masa (ms) percubaan lepas. Pulangkan `true` jika percubaan baharu dibenarkan: bilangan cap dalam `tetingkap` ms terakhir mesti kurang daripada `maks`.",
    starter: () => "function hadKadar(cap, sekarang, tetingkap, maks) {\n\n}",
    cases: () => [
      U([[], 1000, 1000, 3], true),
      U([[900, 950, 990], 1000, 1000, 3], false),
      U([[100, 200], 5000, 1000, 3], true),
      U([[4500, 4800], 5000, 1000, 3], true),
      U([[4500, 4800, 4900], 5000, 1000, 3], false),
    ],
    hints: () => ["Cap dianggap dalam tetingkap jika `sekarang - c < tetingkap`.", "Tapis dahulu, kemudian bandingkan panjang dengan `maks`."],
    jawapan: () => "function hadKadar(cap, sekarang, tetingkap, maks) {\n  const dalam = cap.filter((c) => sekarang - c < tetingkap);\n  return dalam.length < maks;\n}",
  },
  {
    bab: 13, jenis: "pilih",
    tajuk: "Menyimpan kata laluan",
    soalan: () => "Bagaimana kata laluan patut disimpan dalam pangkalan data?",
    pilihan: () => [
      "Hash sehala yang perlahan dan bergaram, seperti bcrypt atau argon2",
      "Disulitkan dengan kunci yang disimpan pada pelayan",
      "MD5 atau SHA-256 supaya pantas",
      "Teks biasa, tetapi dalam jadual berasingan yang dilindungi",
    ],
    betul: () => 0,
    huraian: () => "Penyulitan boleh dinyahsulit — jika kunci bocor, semua kata laluan bocor. Hash sehala tidak boleh dibalikkan. Ia mesti *perlahan* dengan sengaja: SHA-256 terlalu pantas, membolehkan berbilion tekaan sesaat. Garam menghalang satu jadual pra-kira daripada memecahkan semua akaun sekali gus.",
  },

  /* ===== BAB 14 ===== */
  {
    bab: 14, jenis: "tulis", fn: "jangka",
    tajuk: "Penegasan dengan mesej berguna",
    brief: () => "Tulis `jangka(dapat, sepatutnya)`. Jika sama, pulangkan `true`. Jika tidak, baling ralat bermesej `\"Jangka <sepatutnya>, dapat <dapat>\"` menggunakan JSON.",
    starter: () => "function jangka(dapat, sepatutnya) {\n\n}",
    cases: () => [
      U([3, 3], true),
      U(["a", "a"], true),
      B([2, 3], "Jangka 3, dapat 2"),
      B(["x", "y"], 'Jangka "y", dapat "x"'),
    ],
    hints: () => ["`JSON.stringify` membezakan `\"3\"` daripada `3` dalam mesej — itulah gunanya.", "Bandingkan dengan `===` untuk kes ini."],
    jawapan: () => "function jangka(dapat, sepatutnya) {\n  if (dapat === sepatutnya) return true;\n  throw new Error(`Jangka ${JSON.stringify(sepatutnya)}, dapat ${JSON.stringify(dapat)}`);\n}",
  },
  {
    bab: 14, jenis: "baiki", fn: "esok",
    tajuk: "Ujian yang bergantung pada hari ini",
    brief: () => "`esok(tarikhISO)` sepatutnya pulangkan tarikh keesokan hari dalam format `YYYY-MM-DD`. Sekarang ia mengabaikan parameter dan guna tarikh sistem, jadi ujiannya tidak boleh dipercayai. Baiki.",
    starter: () => "function esok(tarikhISO) {\n  const d = new Date();\n  d.setDate(d.getDate() + 1);\n  return d.toISOString().slice(0, 10);\n}",
    cases: () => [
      U(["2024-02-28"], "2024-02-29"),
      U(["2023-12-31"], "2024-01-01"),
      U(["2024-03-01"], "2024-03-02"),
    ],
    hints: () => ["Fungsi yang membaca jam sistem tidak boleh diuji secara deterministik. Terima masa sebagai input.", "`new Date(tarikhISO + \"T00:00:00Z\")` kemudian `setUTCDate(getUTCDate() + 1)`."],
    jawapan: () => "function esok(tarikhISO) {\n  const d = new Date(tarikhISO + \"T00:00:00Z\");\n  d.setUTCDate(d.getUTCDate() + 1);\n  return d.toISOString().slice(0, 10);\n}",
  },
  {
    bab: 14, jenis: "pilih",
    tajuk: "Ujian yang kadang lulus kadang gagal",
    soalan: () => "Ujian kau lulus 9 kali daripada 10. Apa punca paling biasa?",
    pilihan: () => [
      "Ia bergantung pada masa, susunan berjalan, atau keadaan yang dikongsi antara ujian",
      "Mesin ujian terlalu perlahan",
      "Terlalu banyak penegasan dalam satu ujian",
      "Nama ujian terlalu panjang",
    ],
    betul: () => 0,
    huraian: () => "Ujian goyah lebih teruk daripada tiada ujian, kerana pasukan mula mengabaikan kegagalan. Punca biasa: `Date.now()`, nombor rawak, panggilan rangkaian sebenar, dan ujian yang berkongsi pangkalan data tanpa membersihkannya.",
  },

  /* ===== BAB 15 ===== */
  {
    bab: 15, jenis: "baiki", fn: "hargaAkhir",
    tajuk: "Nombor ajaib",
    brief: () => "Fungsi ini betul tetapi tiada siapa tahu apa `0.06` dan `500` bermaksud. Namakan ia sebagai pemalar huruf besar di dalam fungsi. Tingkah laku kekal sama.",
    starter: () => "function hargaAkhir(harga) {\n  if (harga > 500) return harga * 1.06 * 0.9;\n  return harga * 1.06;\n}",
    cases: () => [U([100], 106), U([600], 572.4), U([500], 530), U([0], 0)],
    syarat: () => [{ ujian: (s) => (s.match(/const\s+[A-Z][A-Z_]{2,}\s*=/g) || []).length >= 2, mesej: "Isytihar sekurang-kurangnya dua pemalar bernama, contohnya `const KADAR_CUKAI = 0.06;`" }],
    hints: () => ["Nama pemalar memberitahu pembaca kenapa nombor itu ada di sana.", "Contoh: `KADAR_CUKAI`, `HAD_DISKAUN`, `KADAR_DISKAUN`."],
    jawapan: () => "function hargaAkhir(harga) {\n  const KADAR_CUKAI = 1.06;\n  const HAD_DISKAUN = 500;\n  const KADAR_DISKAUN = 0.9;\n  const denganCukai = harga * KADAR_CUKAI;\n  if (harga > HAD_DISKAUN) return denganCukai * KADAR_DISKAUN;\n  return denganCukai;\n}",
  },
  {
    bab: 15, jenis: "baiki", fn: "statusPesanan",
    tajuk: "Rantaian if menjadi peta",
    brief: () => "Enam `if` yang hanya memetakan satu nilai kepada satu lagi. Gantikan dengan satu objek peta. Tingkah laku kekal sama.",
    starter: () => "function statusPesanan(k) {\n  if (k === 1) return \"baru\";\n  if (k === 2) return \"dibayar\";\n  if (k === 3) return \"dibungkus\";\n  if (k === 4) return \"dihantar\";\n  if (k === 5) return \"selesai\";\n  return \"tidak diketahui\";\n}",
    cases: () => [U([1], "baru"), U([4], "dihantar"), U([5], "selesai"), U([9], "tidak diketahui"), U([0], "tidak diketahui")],
    syarat: () => [{ ujian: (s) => (s.match(/\bif\s*\(/g) || []).length <= 1, mesej: "Masih terlalu banyak `if`. Guna satu objek peta." }],
    hints: () => ["Peta data lebih mudah dibaca dan diubah daripada cabang logik.", "`const peta = { 1: \"baru\", … }; return peta[k] || \"tidak diketahui\";`"],
    jawapan: () => "function statusPesanan(k) {\n  const peta = { 1: \"baru\", 2: \"dibayar\", 3: \"dibungkus\", 4: \"dihantar\", 5: \"selesai\" };\n  return peta[k] || \"tidak diketahui\";\n}",
  },
  {
    bab: 15, jenis: "pilih",
    tajuk: "Bila jangan refactor",
    soalan: () => "Bila kau patut **tidak** refactor kod yang hodoh?",
    pilihan: () => [
      "Bila ia tiada ujian dan kau akan menghantar hari ini",
      "Bila ia ditulis oleh orang lain",
      "Bila ia lebih daripada 50 baris",
      "Bila ia guna nama pembolehubah yang pendek",
    ],
    betul: () => 0,
    huraian: () => "Refactor tanpa ujian hanyalah menulis semula sambil berharap. Tulis ujian yang mengunci tingkah laku semasa dahulu — walaupun tingkah laku itu pelik — kemudian baru ubah bentuknya. Dan jangan campurkan refactor dengan perubahan tingkah laku dalam commit yang sama.",
  },

  /* ===== BAB 16 ===== */
  {
    bab: 16, jenis: "baiki", fn: "senaraiIndeks",
    tajuk: "var dalam gelung",
    brief: () => "`senaraiIndeks(n)` sepatutnya pulangkan `[0, 1, 2, …]`. Ia pulangkan `n` berulang kali. Cari sebabnya.",
    starter: () => "function senaraiIndeks(n) {\n  const fn = [];\n  for (var i = 0; i < n; i++) {\n    fn.push(function () { return i; });\n  }\n  return fn.map((f) => f());\n}",
    cases: () => [U([3], [0, 1, 2]), U([1], [0]), U([0], []), U([4], [0, 1, 2, 3])],
    hints: () => ["`var` ialah satu pembolehubah untuk seluruh fungsi, dikongsi oleh semua fungsi dalam gelung.", "`let` mencipta pengikatan baharu setiap pusingan."],
    jawapan: () => "function senaraiIndeks(n) {\n  const fn = [];\n  for (let i = 0; i < n; i++) {\n    fn.push(function () { return i; });\n  }\n  return fn.map((f) => f());\n}",
  },
  {
    bab: 16, jenis: "baiki", fn: "adaObjek",
    tajuk: "Membandingkan objek dengan tiga sama dengan",
    brief: () => "`adaObjek(senarai, cari)` sepatutnya cari objek dengan `id` yang sama. `===` membandingkan rujukan, bukan isi, jadi ia sentiasa `false`. Baiki.",
    starter: () => "function adaObjek(senarai, cari) {\n  return senarai.some((x) => x === cari);\n}",
    cases: () => [
      U([[{ id: 1 }, { id: 2 }], { id: 2 }], true),
      U([[{ id: 1 }], { id: 9 }], false),
      U([[], { id: 1 }], false),
      U([[{ id: 0 }], { id: 0 }], true),
    ],
    hints: () => ["Dua objek dengan isi sama tetap dua objek berbeza.", "Bandingkan medan yang penting: `x.id === cari.id`."],
    jawapan: () => "function adaObjek(senarai, cari) {\n  return senarai.some((x) => x.id === cari.id);\n}",
  },
  {
    bab: 16, jenis: "pilih",
    tajuk: "Bug yang tak boleh dihasilkan semula",
    soalan: () => "Pengguna melaporkan bug yang kau tak boleh hasilkan semula. Langkah pertama yang paling berguna?",
    pilihan: () => [
      "Kecilkan jurang: dapatkan persekitaran, data dan langkah tepat mereka",
      "Tambah lebih banyak `console.log` di seluruh kod",
      "Tulis semula bahagian itu dari awal",
      "Tandakan sebagai \"tidak boleh dihasilkan semula\" dan tutup",
    ],
    betul: () => 0,
    huraian: () => "Bug yang tidak boleh dihasilkan semula bermakna keadaan kau berbeza daripada keadaan mereka. Cari beza itu — pelayar, data, kebenaran, zon masa, saiz skrin. Selepas kau boleh menghasilkannya semula, membaikinya biasanya bahagian yang mudah.",
  },

  /* ===== BAB 17 ===== */
  {
    bab: 17, jenis: "pilih",
    tajuk: "Memberi anggaran masa",
    soalan: () => "Ketua tanya berapa lama sesuatu tugas akan ambil. Kau tak pasti. Apa jawapan terbaik?",
    pilihan: () => [
      "\"Dua hingga empat hari, bergantung pada sama ada API lama itu berfungsi. Saya boleh sahkan selepas setengah hari menyiasat.\"",
      "\"Dua hari.\" — bagi angka supaya nampak yakin",
      "\"Susah nak cakap.\"",
      "Beri anggaran terpanjang yang munasabah supaya kau selamat",
    ],
    betul: () => 0,
    huraian: () => "Anggaran yang baik ada julat, sebab julat itu wujud, dan cadangan bagaimana untuk mengecilkannya. Satu nombor tunggal menyembunyikan risiko, dan anggaran melampau yang selamat merosakkan kepercayaan bila kau habis awal setiap kali.",
  },
  {
    bab: 17, jenis: "pilih",
    tajuk: "Menulis ulasan kod",
    soalan: () => "Kau mengulas kod rakan sekerja dan tak setuju dengan pendekatannya. Bentuk komen yang mana paling berkesan?",
    pilihan: () => [
      "\"Bahagian ini akan bermasalah bila senarai lebih 10k — Set akan buat lookup O(1). Nak saya tunjukkan?\"",
      "\"Ini tak cekap.\"",
      "\"Kenapa awak buat macam ni?\"",
      "Luluskan sahaja dan baiki sendiri kemudian",
    ],
    betul: () => 0,
    huraian: () => "Komen yang berkesan menyatakan kesan konkrit, mencadangkan alternatif, dan membuka ruang perbualan. Membaiki sendiri secara senyap merampas peluang belajar dan menjadikan kau satu-satunya orang yang faham kod itu.",
  },
  {
    bab: 17, jenis: "pilih",
    tajuk: "Skop yang membengkak",
    soalan: () => "Separuh jalan dalam tugas, kau diminta tambah tiga ciri lagi \"sekali gus\". Respons terbaik?",
    pilihan: () => [
      "\"Boleh — itu tambah kira-kira seminggu. Nak saya hantar yang asal dahulu, atau tunda semuanya?\"",
      "Terima diam-diam dan cuba siapkan pada tarikh asal",
      "Tolak terus kerana ia tiada dalam spesifikasi",
      "Siapkan tiga ciri baharu itu dahulu",
    ],
    betul: () => 0,
    huraian: () => "Jangan tolak permintaan — nyatakan kosnya dan pulangkan keputusan kepada orang yang berhak membuatnya. Menerima diam-diam ialah punca paling biasa tarikh akhir yang terlepas, dan orang lain tak pernah tahu ia berlaku.",
  },

  /* ===== BAB 26 — CABARAN CAMPUR ===== */
  {
    bab: 26, jenis: "tulis", fn: "keRinggit",
    tajuk: "Format wang",
    brief: () => "Tulis `keRinggit(n)` → `\"RM1,234.50\"`. Sentiasa 2 titik perpuluhan, koma setiap tiga digit. Bukan nombor terhingga → baling `\"nombor\"`.",
    starter: () => "function keRinggit(n) {\n\n}",
    cases: () => [
      U([0], "RM0.00"), U([1234.5], "RM1,234.50"), U([1000000], "RM1,000,000.00"),
      U([9.9], "RM9.90"), U([999], "RM999.00"), B(["12"], "nombor"), B([NaN], "nombor"),
    ],
    hints: () => ["`n.toFixed(2)` beri string dengan dua tempat perpuluhan.", "Untuk koma: `bulat.replace(/\\B(?=(\\d{3})+(?!\\d))/g, \",\")`"],
    jawapan: () => "function keRinggit(n) {\n  if (typeof n !== \"number\" || !Number.isFinite(n)) throw new Error(\"nombor tidak sah\");\n  const [bulat, perpuluhan] = n.toFixed(2).split(\".\");\n  return \"RM\" + bulat.replace(/\\B(?=(\\d{3})+(?!\\d))/g, \",\") + \".\" + perpuluhan;\n}",
  },
  {
    bab: 26, jenis: "tulis", fn: "hurailBaris",
    tajuk: "Hurai baris CSV",
    brief: () => "Tulis `hurailBaris(baris)` yang pecahkan baris CSV ikut koma, tetapi koma **dalam petikan berganda** bukan pemisah. Petikan itu sendiri dibuang.",
    starter: () => "function hurailBaris(baris) {\n\n}",
    cases: () => [
      U(["satu,dua"], ["satu", "dua"]),
      U(['a,"b,c",d'], ["a", "b,c", "d"]),
      U(['"x"'], ["x"]),
      U([""], [""]),
      U(["a,,b"], ["a", "", "b"]),
    ],
    hints: () => ["`split(\",\")` tak boleh dipakai — kau perlu mengimbas aksara demi aksara.", "Simpan bendera `dalamPetikan`; koma hanya memisah bila bendera itu palsu."],
    jawapan: () => "function hurailBaris(baris) {\n  const hasil = [];\n  let semasa = \"\";\n  let dalamPetikan = false;\n  for (const c of baris) {\n    if (c === '\"') dalamPetikan = !dalamPetikan;\n    else if (c === \",\" && !dalamPetikan) { hasil.push(semasa); semasa = \"\"; }\n    else semasa += c;\n  }\n  hasil.push(semasa);\n  return hasil;\n}",
  },
  {
    bab: 26, jenis: "tulis", fn: "gabungDalam",
    tajuk: "Gabung mendalam",
    brief: () => "Tulis `gabungDalam(a, b)` yang gabungkan objek bersarang. Bila kedua-dua pihak ada objek pada kunci sama, gabungkan ia secara rekursif. Selain itu nilai `b` menang. Input tidak boleh berubah.",
    starter: () => "function gabungDalam(a, b) {\n\n}",
    cases: () => [
      U([{ a: { x: 1 } }, { a: { y: 2 } }], { a: { x: 1, y: 2 } }),
      U([{ a: 1 }, { a: { b: 2 } }], { a: { b: 2 } }),
      U([{}, { a: 1 }], { a: 1 }),
      U([{ a: { b: { c: 1 } } }, { a: { b: { d: 2 } } }], { a: { b: { c: 1, d: 2 } } }),
    ],
    hints: () => ["Mula dengan salinan cetek `a`, kemudian lalui kunci `b`.", "Rekursi hanya bila kedua-dua nilai ialah objek biasa, bukan array atau null."],
    jawapan: () => "function gabungDalam(a, b) {\n  const objBiasa = (v) => v && typeof v === \"object\" && !Array.isArray(v);\n  const hasil = { ...a };\n  for (const k of Object.keys(b)) {\n    if (objBiasa(hasil[k]) && objBiasa(b[k])) hasil[k] = gabungDalam(hasil[k], b[k]);\n    else hasil[k] = b[k];\n  }\n  return hasil;\n}",
  },
  {
    bab: 26, jenis: "tulis", fn: "statistik",
    tajuk: "Ringkasan statistik",
    brief: () => "Tulis `statistik(arr)` → `{min, maks, purata, median}`. Median untuk bilangan genap ialah purata dua nilai tengah. Bukan array → baling `\"array\"`; array kosong → baling `\"kosong\"`.",
    starter: () => "function statistik(arr) {\n\n}",
    cases: () => [
      U([[1, 2, 3, 4]], { min: 1, maks: 4, purata: 2.5, median: 2.5 }),
      U([[5]], { min: 5, maks: 5, purata: 5, median: 5 }),
      U([[3, 1, 2]], { min: 1, maks: 3, purata: 2, median: 2 }),
      B([[]], "kosong"), B([null], "array"),
    ],
    hints: () => ["Susun salinan dahulu — median memerlukan susunan.", "Ganjil: elemen tengah. Genap: purata dua elemen tengah."],
    jawapan: () => "function statistik(arr) {\n  if (!Array.isArray(arr)) throw new Error(\"input mesti array\");\n  if (arr.length === 0) throw new Error(\"array kosong\");\n  const s = [...arr].sort((a, b) => a - b);\n  const n = s.length;\n  const tengah = Math.floor(n / 2);\n  return {\n    min: s[0],\n    maks: s[n - 1],\n    purata: s.reduce((a, b) => a + b, 0) / n,\n    median: n % 2 ? s[tengah] : (s[tengah - 1] + s[tengah]) / 2,\n  };\n}",
  },
  {
    bab: 26, jenis: "tulis", fn: "penapisSelamat",
    tajuk: "Tapis tanpa terhempas",
    brief: () => "Tulis `penapisSelamat(senarai, syarat)`. Jika `syarat(item)` membaling ralat, item itu ditinggalkan dan pemprosesan diteruskan — bukan menghentikan segalanya.",
    starter: () => "function penapisSelamat(senarai, syarat) {\n\n}",
    cases: () => [
      { args: [[1, 2, 3], EV("(x) => { if (x === 2) throw new Error('rosak'); return x > 1; }")], expected: [3] },
      { args: [[1, 2], EV("() => true")], expected: [1, 2] },
      { args: [[1, 2], EV("() => { throw new Error('semua'); }")], expected: [] },
    ],
    hints: () => ["Bungkus setiap panggilan `syarat` dalam try/catch di dalam gelung.", "Gagal untuk satu item tidak sepatutnya menjadi gagal untuk keseluruhan kelompok."],
    jawapan: () => "function penapisSelamat(senarai, syarat) {\n  const hasil = [];\n  for (const item of senarai) {\n    try {\n      if (syarat(item)) hasil.push(item);\n    } catch (e) {\n      // langkau item yang bermasalah\n    }\n  }\n  return hasil;\n}",
  },
  {
    bab: 26, jenis: "kukuh", fn: "kendaliPermintaan",
    tajuk: "Pengendali permintaan lengkap",
    brief: () => "`kendaliPermintaan(req)` mesti pulangkan `{status, badan}`:\n• bukan objek, atau tiada `laluan` → `{status: 400, badan: \"permintaan tidak sah\"}`\n• laluan bukan `\"/ahli\"` → `{status: 404, badan: \"tidak dijumpai\"}`\n• kaedah bukan `\"GET\"` → `{status: 405, badan: \"kaedah tidak dibenarkan\"}`\n• selain itu → `{status: 200, badan: \"ok\"}`",
    starter: () => "function kendaliPermintaan(req) {\n\n}",
    cases: () => [
      U([{ laluan: "/ahli", kaedah: "GET" }], { status: 200, badan: "ok" }),
      U([{ laluan: "/ahli", kaedah: "POST" }], { status: 405, badan: "kaedah tidak dibenarkan" }),
      U([{ laluan: "/lain", kaedah: "GET" }], { status: 404, badan: "tidak dijumpai" }),
      U([{}], { status: 400, badan: "permintaan tidak sah" }),
      U([null], { status: 400, badan: "permintaan tidak sah" }),
      U(["x"], { status: 400, badan: "permintaan tidak sah" }),
    ],
    hints: () => ["Periksa dari paling umum ke paling khusus: bentuk, kemudian laluan, kemudian kaedah.", "Setiap semakan gagal ialah `return` awal."],
    jawapan: () => "function kendaliPermintaan(req) {\n  if (!req || typeof req !== \"object\" || typeof req.laluan !== \"string\") {\n    return { status: 400, badan: \"permintaan tidak sah\" };\n  }\n  if (req.laluan !== \"/ahli\") return { status: 404, badan: \"tidak dijumpai\" };\n  if (req.kaedah !== \"GET\") return { status: 405, badan: \"kaedah tidak dibenarkan\" };\n  return { status: 200, badan: \"ok\" };\n}",
  },
  {
    bab: 26, jenis: "tulis", fn: "carianKabur",
    tajuk: "Carian yang memaafkan",
    brief: () => "Tulis `carianKabur(senarai, teks)` yang pulangkan item yang mengandungi `teks`, abaikan huruf besar/kecil dan ruang di hujung. `teks` kosong → pulangkan semua item.",
    starter: () => "function carianKabur(senarai, teks) {\n\n}",
    cases: () => [
      U([["Nasi Lemak", "Roti Canai", "nasi goreng"], "nasi"], ["Nasi Lemak", "nasi goreng"]),
      U([["a", "b"], ""], ["a", "b"]),
      U([["a", "b"], "  "], ["a", "b"]),
      U([["Teh Ais"], "AIS"], ["Teh Ais"]),
      U([[], "x"], []),
    ],
    hints: () => ["Kecilkan kedua-dua belah sekali sahaja, bukan dalam setiap perbandingan.", "Jika `teks.trim()` kosong, pulangkan salinan senarai penuh."],
    jawapan: () => "function carianKabur(senarai, teks) {\n  const cari = String(teks).trim().toLowerCase();\n  if (!cari) return [...senarai];\n  return senarai.filter((x) => String(x).toLowerCase().includes(cari));\n}",
  },
  {
    bab: 26, jenis: "kukuh", fn: "ringkasanPesanan",
    tajuk: "Ringkasan pesanan hujung ke hujung",
    brief: () => "`ringkasanPesanan(p)` di mana `p = {barang: [{nama, harga, kuantiti}]}`.\n• bukan objek, atau `barang` bukan array → baling `\"pesanan tidak sah\"`\n• `barang` kosong → baling `\"pesanan kosong\"`\n• mana-mana harga bukan nombor ≥ 0, atau kuantiti bukan integer > 0 → baling `\"barang tidak sah\"`\n• kalau tidak → `{bilangan, jumlah}` dengan jumlah dibulatkan 2 titik perpuluhan",
    starter: () => "function ringkasanPesanan(p) {\n\n}",
    cases: () => [
      U([{ barang: [{ nama: "a", harga: 2.5, kuantiti: 2 }, { nama: "b", harga: 1, kuantiti: 3 }] }], { bilangan: 5, jumlah: 8 }),
      U([{ barang: [{ nama: "a", harga: 0, kuantiti: 1 }] }], { bilangan: 1, jumlah: 0 }),
      B([{ barang: [] }], "kosong"),
      B([{}], "tidak sah"),
      B([null], "tidak sah"),
      B([{ barang: [{ nama: "a", harga: -1, kuantiti: 1 }] }], "barang tidak sah"),
      B([{ barang: [{ nama: "a", harga: 1, kuantiti: 0 }] }], "barang tidak sah"),
    ],
    hints: () => ["Sahkan bentuk luar dahulu, kemudian setiap item, kemudian baru kira.", "Bulatkan sekali di hujung, bukan pada setiap baris."],
    jawapan: () => "function ringkasanPesanan(p) {\n  if (!p || typeof p !== \"object\" || !Array.isArray(p.barang)) throw new Error(\"pesanan tidak sah\");\n  if (p.barang.length === 0) throw new Error(\"pesanan kosong\");\n  let bilangan = 0;\n  let jumlah = 0;\n  for (const b of p.barang) {\n    if (typeof b.harga !== \"number\" || !Number.isFinite(b.harga) || b.harga < 0) throw new Error(\"barang tidak sah\");\n    if (!Number.isInteger(b.kuantiti) || b.kuantiti <= 0) throw new Error(\"barang tidak sah\");\n    bilangan += b.kuantiti;\n    jumlah += b.harga * b.kuantiti;\n  }\n  return { bilangan, jumlah: Math.round(jumlah * 100) / 100 };\n}",
  },
];

TUGAS.push(...TUGAS_TAMBAHAN);

/* ============================================================
   BANK KETIGA — Pangkalan Data, Git, Membaca Kod Orang Lain
   ============================================================ */
const TUGAS_TAMBAHAN_3 = [
  /* ===== BAB 18 — PANGKALAN DATA & SQL ===== */
  {
    bab: 18, jenis: "tulis", fn: "binaPertanyaan",
    tajuk: "Pertanyaan berparameter",
    brief: () => "Tulis `binaPertanyaan(jadual, syarat)` yang pulangkan `{sql, params}`.\n• `(\"ahli\", {umur: 30})` → `{sql: \"SELECT * FROM ahli WHERE umur = ?\", params: [30]}`\n• syarat kosong → tiada `WHERE`\n• beberapa syarat disambung dengan ` AND `\n• nama jadual bukan huruf kecil/garis bawah sahaja → baling `\"jadual\"`",
    starter: () => "function binaPertanyaan(jadual, syarat) {\n\n}",
    cases: () => [
      U(["ahli", { umur: 30 }], { sql: "SELECT * FROM ahli WHERE umur = ?", params: [30] }),
      U(["ahli", {}], { sql: "SELECT * FROM ahli", params: [] }),
      U(["pesanan", { a: 1, b: "x" }], { sql: "SELECT * FROM pesanan WHERE a = ? AND b = ?", params: [1, "x"] }),
      B(["ahli; DROP TABLE x", {}], "jadual"),
      B(["Ahli", {}], "jadual"),
    ],
    hints: () => ["Nilai jadi `?`; hanya pengecam seperti nama jadual perlu disenarai-putih.", "`Object.entries(syarat)` beri kunci dan nilai sekali gus."],
    jawapan: () => "function binaPertanyaan(jadual, syarat) {\n  if (typeof jadual !== \"string\" || !/^[a-z_]+$/.test(jadual)) throw new Error(\"nama jadual tidak sah\");\n  const masukan = Object.entries(syarat || {});\n  if (masukan.length === 0) return { sql: `SELECT * FROM ${jadual}`, params: [] };\n  const klausa = masukan.map(([k]) => `${k} = ?`).join(\" AND \");\n  return { sql: `SELECT * FROM ${jadual} WHERE ${klausa}`, params: masukan.map(([, v]) => v) };\n}",
  },
  {
    bab: 18, jenis: "tulis", fn: "cantum",
    tajuk: "LEFT JOIN dalam ingatan",
    brief: () => "Tulis `cantum(pesanan, pengguna)`. Setiap pesanan `{id, penggunaId, jumlah}` dipadankan dengan pengguna `{id, nama}`. Pulangkan `[{id, nama, jumlah}]`. Jika pengguna tiada, `nama` ialah `null` — semua pesanan kekal, seperti LEFT JOIN.",
    starter: () => "function cantum(pesanan, pengguna) {\n\n}",
    cases: () => [
      U([[{ id: 1, penggunaId: 7, jumlah: 20 }], [{ id: 7, nama: "Aini" }]], [{ id: 1, nama: "Aini", jumlah: 20 }]),
      U([[{ id: 2, penggunaId: 9, jumlah: 5 }], [{ id: 7, nama: "Aini" }]], [{ id: 2, nama: null, jumlah: 5 }]),
      U([[], [{ id: 1, nama: "x" }]], []),
    ],
    hints: () => ["Bina `Map` daripada pengguna dahulu — mencari dalam array untuk setiap pesanan ialah masalah N+1 versi ingatan.", "`new Map(pengguna.map((u) => [u.id, u]))`"],
    jawapan: () => "function cantum(pesanan, pengguna) {\n  const peta = new Map(pengguna.map((u) => [u.id, u]));\n  return pesanan.map((p) => ({\n    id: p.id,\n    nama: peta.has(p.penggunaId) ? peta.get(p.penggunaId).nama : null,\n    jumlah: p.jumlah,\n  }));\n}",
  },
  {
    bab: 18, jenis: "tulis", fn: "halaman",
    tajuk: "LIMIT dan OFFSET",
    brief: () => "Tulis `halaman(arr, muka, saiz)`. `muka` bermula dari 1. Melebihi hujung → array kosong. `muka` atau `saiz` bukan integer positif → baling `\"halaman\"`.",
    starter: () => "function halaman(arr, muka, saiz) {\n\n}",
    cases: () => [
      U([[1, 2, 3, 4, 5], 1, 2], [1, 2]),
      U([[1, 2, 3, 4, 5], 2, 2], [3, 4]),
      U([[1, 2, 3, 4, 5], 3, 2], [5]),
      U([[1, 2, 3], 9, 2], []),
      B([[1], 0, 2], "halaman"),
      B([[1], 1, 0], "halaman"),
    ],
    hints: () => ["Offset ialah `(muka - 1) * saiz`.", "`arr.slice(offset, offset + saiz)`"],
    jawapan: () => "function halaman(arr, muka, saiz) {\n  if (!Number.isInteger(muka) || muka < 1 || !Number.isInteger(saiz) || saiz < 1) {\n    throw new Error(\"halaman tidak sah\");\n  }\n  const offset = (muka - 1) * saiz;\n  return arr.slice(offset, offset + saiz);\n}",
  },
  {
    bab: 18, jenis: "tulis", fn: "kiraIkut",
    tajuk: "GROUP BY dengan COUNT",
    brief: () => "Tulis `kiraIkut(baris, kunci)` yang kira bilangan baris bagi setiap nilai kunci. `[{bandar:\"KL\"},{bandar:\"JB\"},{bandar:\"KL\"}]` dengan `\"bandar\"` → `{KL: 2, JB: 1}`.",
    starter: () => "function kiraIkut(baris, kunci) {\n\n}",
    cases: () => [
      U([[{ bandar: "KL" }, { bandar: "JB" }, { bandar: "KL" }], "bandar"], { KL: 2, JB: 1 }),
      U([[], "bandar"], {}),
      U([[{ s: "a" }], "s"], { a: 1 }),
    ],
    hints: () => ["Sama corak dengan `kumpulIkut`, tetapi simpan kiraan bukan senarai.", "`hasil[nilai] = (hasil[nilai] || 0) + 1`"],
    jawapan: () => "function kiraIkut(baris, kunci) {\n  const hasil = {};\n  for (const b of baris) {\n    const v = b[kunci];\n    hasil[v] = (hasil[v] || 0) + 1;\n  }\n  return hasil;\n}",
  },
  {
    bab: 18, jenis: "pilih",
    tajuk: "INNER atau LEFT JOIN",
    soalan: () => "Kau mahu senaraikan semua pelanggan, termasuk yang belum pernah membuat pesanan. Join yang mana?",
    pilihan: () => [
      "`LEFT JOIN` dari jadual pelanggan — pelanggan tanpa pesanan kekal, dengan lajur pesanan NULL",
      "`INNER JOIN` — ia sudah termasuk semua baris",
      "Dua pertanyaan berasingan, kemudian gabungkan dalam kod",
      "`RIGHT JOIN` dari jadual pesanan",
    ],
    betul: () => 0,
    huraian: () => "`INNER JOIN` membuang baris yang tiada padanan — pelanggan tanpa pesanan akan hilang senyap. Perangkap biasa: menambah `WHERE pesanan.status = 'siap'` pada LEFT JOIN akan menukarnya semula menjadi INNER JOIN, kerana NULL gagal syarat itu. Letak syarat itu dalam `ON`, bukan `WHERE`.",
  },
  {
    bab: 18, jenis: "pilih",
    tajuk: "Masalah N+1",
    soalan: () => "Halaman kau memuatkan 100 pesanan, kemudian untuk setiap satu, membuat satu pertanyaan untuk mendapatkan nama pelanggan. Apa masalahnya?",
    pilihan: () => [
      "101 perjalanan ke pangkalan data — satu pertanyaan JOIN atau satu `WHERE id IN (…)` akan menggantikan semuanya",
      "Tiada masalah selagi setiap pertanyaan itu pantas",
      "Pangkalan data akan kehabisan memori",
      "Ia hanya masalah jika kau guna MySQL",
    ],
    betul: () => 0,
    huraian: () => "Setiap pertanyaan ada kos tetap — latensi rangkaian, penghuraian, pengurusan sambungan. Seratus pertanyaan 2ms ialah 200ms yang hampir semuanya adalah kos overhed. Ini pepijat prestasi paling biasa dalam aplikasi web, dan ia biasanya tersembunyi di dalam gelung.",
  },
  {
    bab: 18, jenis: "pilih",
    tajuk: "Apa yang indeks lakukan",
    soalan: () => "Kau tambah indeks pada lajur `emel`. Apa kesan sebenarnya?",
    pilihan: () => [
      "Bacaan yang menapis `emel` jadi jauh lebih pantas; tulisan jadi sedikit lebih perlahan dan storan bertambah",
      "Semua pertanyaan pada jadual itu jadi lebih pantas",
      "Ia menjadikan lajur itu unik secara automatik",
      "Ia tiada kesan sehingga jadual melebihi sejuta baris",
    ],
    betul: () => 0,
    huraian: () => "Indeks ialah struktur berasingan yang mesti dikemas kini pada setiap INSERT, UPDATE dan DELETE. Indeks yang tak pernah digunakan tetap membayar kos tulisan itu — jadi indeks apa yang kau tapis dan susun, bukan setiap lajur.",
  },
  {
    bab: 18, jenis: "pilih",
    tajuk: "Pindahan wang",
    soalan: () => "Kau menolak RM100 dari satu akaun dan menambahnya ke akaun lain. Pelayan terhempas antara dua operasi itu. Apa yang menghalang wang itu lenyap?",
    pilihan: () => [
      "Transaksi — kedua-dua tulisan berjaya bersama, atau kedua-duanya dibatalkan",
      "Menyimpan log setiap operasi supaya ia boleh dibaiki kemudian",
      "Menjalankan kedua-dua kemas kini dalam satu fungsi",
      "Cuba semula operasi kedua sehingga berjaya",
    ],
    betul: () => 0,
    huraian: () => "Meletakkan dua tulisan dalam satu fungsi tidak menjadikannya atomik — pelayan boleh mati di antaranya. Transaksi memberi kau jaminan itu di peringkat pangkalan data. Log dan cuba semula ialah pembaikan selepas kerosakan; transaksi menghalang kerosakan itu berlaku.",
  },

  /* ===== BAB 19 — GIT & KERJA BERPASUKAN ===== */
  {
    bab: 19, jenis: "tulis", fn: "hurailStatus",
    tajuk: "Baca output git status",
    brief: () => "Setiap baris ialah kod dua aksara diikuti ruang dan nama fail. Tulis `hurailStatus(baris)` → `{diubah, baharu, dipadam}`.\n• kod mengandungi `?` atau `A` → baharu\n• kod mengandungi `D` → dipadam\n• kod mengandungi `M` → diubah",
    starter: () => "function hurailStatus(baris) {\n\n}",
    cases: () => [
      U([[" M src/app.js", "?? nota.txt", " D lama.js"]], { diubah: ["src/app.js"], baharu: ["nota.txt"], dipadam: ["lama.js"] }),
      U([[]], { diubah: [], baharu: [], dipadam: [] }),
      U([["A  baru.js"]], { diubah: [], baharu: ["baru.js"], dipadam: [] }),
      U([["MM a.js", "M  b.js"]], { diubah: ["a.js", "b.js"], baharu: [], dipadam: [] }),
    ],
    hints: () => ["Kod ialah `baris.slice(0, 2)`, nama fail ialah `baris.slice(3)`.", "Periksa mengikut keutamaan: baharu, kemudian dipadam, kemudian diubah."],
    jawapan: () => "function hurailStatus(baris) {\n  const hasil = { diubah: [], baharu: [], dipadam: [] };\n  for (const b of baris) {\n    const kod = b.slice(0, 2);\n    const nama = b.slice(3);\n    if (kod.includes(\"?\") || kod.includes(\"A\")) hasil.baharu.push(nama);\n    else if (kod.includes(\"D\")) hasil.dipadam.push(nama);\n    else if (kod.includes(\"M\")) hasil.diubah.push(nama);\n  }\n  return hasil;\n}",
  },
  {
    bab: 19, jenis: "tulis", fn: "sahkanKomit",
    tajuk: "Sahkan mesej komit",
    brief: () => "Format: `<jenis>: <penerangan>`, jenis mesti salah satu daripada `feat fix docs refactor test chore`. Tulis `sahkanKomit(mesej)` yang pulangkan array ralat:\n• bentuk atau jenis salah → `[\"jenis tidak sah\"]` sahaja\n• penerangan kosong → `\"penerangan kosong\"`\n• penerangan bermula huruf besar → `\"huruf besar di awal penerangan\"`\n• berakhir dengan noktah → `\"tiada noktah di hujung\"`\n• panjang melebihi 72 → `\"terlalu panjang\"`",
    starter: () => "function sahkanKomit(mesej) {\n\n}",
    cases: () => [
      U(["feat: tambah log masuk"], []),
      U(["Tambah log masuk"], ["jenis tidak sah"]),
      U(["wip: sesuatu"], ["jenis tidak sah"]),
      U(["feat: Tambah log masuk"], ["huruf besar di awal penerangan"]),
      U(["fix: betulkan ralat."], ["tiada noktah di hujung"]),
      U(["feat: "], ["penerangan kosong"]),
      U(["feat: " + "a".repeat(80)], ["terlalu panjang"]),
    ],
    hints: () => ["Regex bentuk: `/^([a-z]+): (.*)$/`.", "Jika bentuk gagal, pulangkan awal — semakan lain tiada makna tanpa bentuk yang sah."],
    jawapan: () => "function sahkanKomit(mesej) {\n  if (typeof mesej !== \"string\") return [\"jenis tidak sah\"];\n  const jenisSah = [\"feat\", \"fix\", \"docs\", \"refactor\", \"test\", \"chore\"];\n  const padan = mesej.match(/^([a-z]+): (.*)$/);\n  if (!padan || !jenisSah.includes(padan[1])) return [\"jenis tidak sah\"];\n  const ralat = [];\n  const teks = padan[2];\n  if (teks.trim() === \"\") ralat.push(\"penerangan kosong\");\n  else {\n    if (teks[0] !== teks[0].toLowerCase()) ralat.push(\"huruf besar di awal penerangan\");\n    if (teks.endsWith(\".\")) ralat.push(\"tiada noktah di hujung\");\n  }\n  if (mesej.length > 72) ralat.push(\"terlalu panjang\");\n  return ralat;\n}",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Commit lawan push",
    soalan: () => "Kau jalankan `git commit`. Di mana kerja kau sekarang?",
    pilihan: () => [
      "Dalam repositori tempatan kau sahaja — orang lain belum nampak apa-apa sehingga kau `push`",
      "Sudah berada di pelayan dan boleh dilihat pasukan",
      "Dalam kawasan pementasan, menunggu `git add`",
      "Dalam cawangan utama secara automatik",
    ],
    betul: () => 0,
    huraian: () => "Git ialah sistem teragih: `add` memindahkan perubahan ke kawasan pementasan, `commit` menyimpannya ke sejarah tempatan, `push` menghantarnya ke remote. Komit tempatan tidak menjadi sandaran — jika cakera kau rosak, ia hilang.",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Kunci API dalam sejarah",
    soalan: () => "Kau tersilap komit kunci API dan sudah push. Apa langkah pertama?",
    pilihan: () => [
      "Batalkan dan gantikan kunci itu serta-merta — anggap ia sudah bocor",
      "Buat komit baharu yang memadamkan baris itu",
      "Tulis semula sejarah dengan `git filter-repo` dan force push",
      "Jadikan repositori itu peribadi",
    ],
    betul: () => 0,
    huraian: () => "Sebaik sahaja rahsia itu dipush, anggap ia sudah dibaca — pengimbas mengesan kunci dalam repositori awam dalam beberapa saat. Menulis semula sejarah adalah langkah kedua yang berguna, tetapi salinan mungkin sudah wujud dalam fork, cache CI, dan klon tempatan orang lain. Kunci baharu ialah satu-satunya pembaikan sebenar.",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Rebase pada cawangan kongsi",
    soalan: () => "Cawangan kau sudah dipush dan rakan sekerja sedang bekerja atasnya. Selamatkah `git rebase` kemudian force push?",
    pilihan: () => [
      "Tidak — rebase mencipta komit baharu, jadi sejarah rakan sekerja tidak lagi sepadan",
      "Ya, rebase sentiasa lebih bersih daripada merge",
      "Ya, selagi kau beritahu mereka selepas itu",
      "Tidak, kerana rebase memadam komit selamanya",
    ],
    betul: () => 0,
    huraian: () => "Peraturan mudah: rebase kerja tempatan yang belum dikongsi, merge kerja yang sudah dikongsi. Selepas force push, `git pull` rakan sekerja akan cuba mencantumkan dua versi sejarah yang berbeza, dan hasilnya kekacauan yang mahal untuk dibersihkan.",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Konflik cantuman",
    soalan: () => "Git melaporkan konflik dalam satu fail. Apa yang sebenarnya berlaku?",
    pilihan: () => [
      "Dua cawangan mengubah baris yang sama, jadi Git berhenti dan meminta kau memutuskan",
      "Salah seorang membuat kesilapan dan komitnya perlu dibuang",
      "Fail itu rosak dan perlu dipulihkan",
      "Git tidak dapat memuat turun versi terkini",
    ],
    betul: () => 0,
    huraian: () => "Konflik bukan ralat — ia Git menolak untuk meneka. Selesaikan dengan membaca kedua-dua belah, faham niat setiap perubahan, kemudian tulis versi yang betul. Menerima satu pihak secara membuta boleh memadamkan kerja orang lain secara senyap.",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Selepas reset --hard",
    soalan: () => "Kau jalankan `git reset --hard` dan kehilangan komit yang belum dipush. Boleh dipulihkan?",
    pilihan: () => [
      "Selalunya boleh — `git reflog` menyimpan rekod ke mana HEAD pernah menunjuk",
      "Tidak, `--hard` memadam secara kekal",
      "Hanya jika kau ada sandaran fail",
      "Hanya jika komit itu sudah dipush",
    ],
    betul: () => 0,
    huraian: () => "Git jarang membuang objek serta-merta. `git reflog` menunjukkan setiap kedudukan HEAD terdahulu, dan kau boleh `git checkout` atau `git reset` kembali ke sana. Perubahan yang belum pernah dikomit pula benar-benar hilang — itu sebabnya komit kecil dan kerap.",
  },
  {
    bab: 19, jenis: "pilih",
    tajuk: "Apa yang tidak masuk repositori",
    soalan: () => "Mana yang tidak sepatutnya dikomit ke repositori?",
    pilihan: () => [
      "Rahsia, `node_modules`, fail binari yang dijana, dan konfigurasi tempatan",
      "Fail ujian, kerana ia membesarkan repositori",
      "Dokumentasi, kerana ia cepat lapuk",
      "Fail konfigurasi, kerana setiap orang berbeza",
    ],
    betul: () => 0,
    huraian: () => "Peraturan: jika ia boleh dijana semula, atau ia rahsia, atau ia khusus mesin kau, ia tidak masuk. Templat konfigurasi seperti `.env.contoh` sepatutnya dikomit — nilai sebenar tidak.",
  },

  /* ===== BAB 20 — MEMBACA KOD ORANG LAIN ===== */
  {
    bab: 20, jenis: "pilih",
    tajuk: "Di mana mula membaca",
    soalan: () => "Kau baru sertai projek dengan 400 fail. Di mana kau mula?",
    pilihan: () => [
      "Jalankan ia, cari titik masuk, kemudian ikut satu permintaan sebenar dari hujung ke hujung",
      "Baca setiap fail mengikut susunan abjad",
      "Mula dengan fail terbesar, kerana di situlah logik utama",
      "Baca dokumentasi sahaja sehingga kau faham semuanya",
    ],
    betul: () => 0,
    huraian: () => "Kod difahami melalui laluan, bukan melalui inventori. Pilih satu ciri yang kau boleh cetuskan, letak titik henti atau log, dan ikut data dari input sehingga output. Selepas dua atau tiga laluan, bentuk keseluruhan sistem mula muncul.",
  },
  {
    bab: 20, jenis: "ramal",
    tajuk: "Baca satu baris padat",
    kod: () => `const f = (a) => a.reduce((m, x) => ((m[x] = (m[x] || 0) + 1), m), {});\nconsole.log(JSON.stringify(f(["a", "b", "a"])));`,
    output: () => '{"a":2,"b":1}',
    brief: () => "Apa yang dicetak? Taip tepat termasuk kurungan dan petikan.",
    hints: () => ["`reduce` di sini mengumpul ke dalam objek `{}`, bukan nombor.", "Operator koma menilai kedua-dua bahagian dan pulangkan yang terakhir — iaitu `m`."],
  },
  {
    bab: 20, jenis: "pilih",
    tajuk: "Apa yang kod ini buat",
    soalan: () => "`const g = (s) => s.split(\"\").filter((c, i, a) => a.indexOf(c) === i).join(\"\");` — apa yang `g` lakukan?",
    pilihan: () => [
      "Membuang aksara berulang, mengekalkan kemunculan pertama",
      "Menyusun aksara mengikut abjad",
      "Membalikkan string",
      "Mengira bilangan aksara unik",
    ],
    betul: () => 0,
    huraian: () => "`a.indexOf(c) === i` benar hanya untuk kemunculan pertama sesuatu aksara. Corak ini muncul di mana-mana dalam kod lama sebagai cara membuang pendua sebelum `Set` menjadi biasa — mengenalinya menjimatkan banyak masa membaca.",
  },
  {
    bab: 20, jenis: "baiki", fn: "kiraDiskaun",
    tajuk: "Pepijat dalam kod yang kau tak tulis",
    brief: () => "Fungsi ini berfungsi dalam ujian pembangun asal, tetapi terhempas dalam pengeluaran untuk sesetengah pengguna. Cari sebabnya dan baiki.",
    starter: () => "function kiraDiskaun(senarai) {\n  return senarai\n    .filter((x) => x.aktif)\n    .map((x) => x.harga * (1 - x.diskaun))\n    .reduce((a, b) => a + b);\n}",
    cases: () => [
      U([[{ aktif: true, harga: 100, diskaun: 0.1 }, { aktif: false, harga: 50, diskaun: 0 }]], 90),
      U([[]], 0),
      U([[{ aktif: false, harga: 10, diskaun: 0 }]], 0),
      U([[{ aktif: true, harga: 200, diskaun: 0.5 }]], 100),
    ],
    hints: () => ["Apa yang berlaku bila `filter` tidak meninggalkan apa-apa?", "`reduce` tanpa nilai awal membaling ralat pada array kosong."],
    jawapan: () => "function kiraDiskaun(senarai) {\n  return senarai\n    .filter((x) => x.aktif)\n    .map((x) => x.harga * (1 - x.diskaun))\n    .reduce((a, b) => a + b, 0);\n}",
  },
  {
    bab: 20, jenis: "pilih",
    tajuk: "Pagar yang tiada sebab",
    soalan: () => "Kau jumpa `if (id === 4711) return;` tanpa komen, dalam kod berumur tiga tahun. Apa yang kau buat?",
    pilihan: () => [
      "Siasat dahulu — `git log -S` untuk cari komit yang menambahnya, dan baca mesej serta isu berkaitan",
      "Buang, kerana ia jelas hack",
      "Biarkan selamanya dan jangan sentuh bahagian itu",
      "Tukar kepada pemalar bernama dan teruskan",
    ],
    betul: () => 0,
    huraian: () => "Kod pelik biasanya ialah pembaikan kepada masalah sebenar yang tiada siapa dokumenkan. `git log -S \"4711\"` mencari komit yang memperkenalkan rentetan itu. Selepas kau tahu sebabnya, kau boleh membuangnya dengan yakin — atau menambah komen yang sepatutnya ada sejak awal.",
  },
  {
    bab: 20, jenis: "ramal",
    tajuk: "Jejak rantaian transformasi",
    kod: () => `const d = [5, 12, 8, 1, 20]\n  .filter((x) => x > 4)\n  .map((x) => x - 1)\n  .sort((a, b) => b - a)\n  .slice(0, 2);\nconsole.log(d.join("-"));`,
    output: () => "19-11",
    brief: () => "Apa yang dicetak?",
    hints: () => ["Kerjakan satu langkah pada satu masa, tulis array selepas setiap langkah.", "Selepas filter: [5,12,8,20]. Teruskan dari situ."],
  },
  {
    bab: 20, jenis: "tulis", fn: "kiraKerapan",
    tajuk: "Tulis semula supaya boleh dibaca",
    brief: () => "Fungsi mampat ini mengira kekerapan setiap item:\n\n`const f=(a)=>a.reduce((m,x)=>((m[x]=(m[x]||0)+1),m),{})`\n\nTulis semula sebagai `kiraKerapan(senarai)` dengan tingkah laku yang sama, tetapi guna gelung dan nama yang bermakna. Jangan guna operator koma.",
    starter: () => "function kiraKerapan(senarai) {\n\n}",
    cases: () => [
      U([["a", "b", "a"]], { a: 2, b: 1 }),
      U([[]], {}),
      U([[1, 1, 1]], { 1: 3 }),
    ],
    syarat: () => [
      { ujian: (s) => !/,\s*m\s*\)/.test(s), mesej: "Buang operator koma — tulis langkahnya secara berasingan." },
      { ujian: (s) => /\bfor\b|\bforEach\b/.test(s), mesej: "Guna gelung supaya setiap langkah kelihatan." },
    ],
    hints: () => ["Kod pintar yang mengambil masa lima minit untuk difahami lebih mahal daripada kod jelas yang panjang tiga baris.", "Objek kosong, gelung, tambah kiraan, pulangkan."],
    jawapan: () => "function kiraKerapan(senarai) {\n  const kekerapan = {};\n  for (const item of senarai) {\n    kekerapan[item] = (kekerapan[item] || 0) + 1;\n  }\n  return kekerapan;\n}",
  },
  {
    bab: 20, jenis: "pilih",
    tajuk: "Mengubah kod yang kau tak faham",
    soalan: () => "Kau perlu mengubah fungsi 200 baris yang tiada ujian dan tiada siapa faham. Langkah pertama?",
    pilihan: () => [
      "Tulis ujian yang mengunci tingkah laku semasa dahulu, walaupun tingkah laku itu kelihatan salah",
      "Refactor supaya bersih, kemudian buat perubahan",
      "Tulis semula dari awal berdasarkan apa yang kau fikir ia patut buat",
      "Buat perubahan minimum dan harap tiada apa yang pecah",
    ],
    betul: () => 0,
    huraian: () => "Ujian yang menangkap tingkah laku semasa dipanggil ujian ciri (characterization test). Ia tidak mengesahkan bahawa kod itu betul — ia mengesahkan bahawa kau tidak mengubahnya secara tidak sengaja. Selepas jaring itu ada, refactor dan perubahan menjadi selamat.",
  },
];

TUGAS.push(...TUGAS_TAMBAHAN_3);

/* ============================================================
   BANK KEEMPAT — Struktur Data, Regex, HTTP, Prestasi, Reka Bentuk
   ============================================================ */
const TUGAS_TAMBAHAN_4 = [
  /* ===== BAB 21 — STRUKTUR DATA KLASIK ===== */
  {
    bab: 21, jenis: "tulis", fn: "kurunganSeimbang",
    tajuk: "Kurungan seimbang (tindanan)",
    brief: () => "Tulis `kurunganSeimbang(s)` yang semak sama ada `()`, `[]` dan `{}` berpasangan dan bersarang dengan betul. Abaikan aksara lain.",
    starter: () => "function kurunganSeimbang(s) {\n\n}",
    cases: () => [
      U(["({[]})"], true), U(["(]"], false), U(["("], false), U([""], true),
      U(["a(b)c"], true), U([")("], false), U(["{[()]}"], true),
    ],
    hints: () => ["Tindanan (stack) ialah array dengan `push` dan `pop`.", "Kurungan buka ditolak masuk; kurungan tutup mesti padan dengan yang terakhir keluar. Di hujung, tindanan mesti kosong."],
    jawapan: () => "function kurunganSeimbang(s) {\n  const pasangan = { \")\": \"(\", \"]\": \"[\", \"}\": \"{\" };\n  const tindanan = [];\n  for (const c of s) {\n    if (c === \"(\" || c === \"[\" || c === \"{\") tindanan.push(c);\n    else if (pasangan[c]) {\n      if (tindanan.pop() !== pasangan[c]) return false;\n    }\n  }\n  return tindanan.length === 0;\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "jalanGiliran",
    tajuk: "Giliran masuk dahulu keluar dahulu",
    brief: () => "Tulis `jalanGiliran(operasi)`. Operasi ialah `[\"masuk\", nilai]` atau `[\"keluar\"]`. `keluar` pada giliran kosong tidak buat apa-apa. Pulangkan `{baki, dikeluarkan}`.",
    starter: () => "function jalanGiliran(operasi) {\n\n}",
    cases: () => [
      U([[["masuk", 1], ["masuk", 2], ["keluar"]]], { baki: [2], dikeluarkan: [1] }),
      U([[["keluar"]]], { baki: [], dikeluarkan: [] }),
      U([[]], { baki: [], dikeluarkan: [] }),
      U([[["masuk", "a"], ["keluar"], ["keluar"]]], { baki: [], dikeluarkan: ["a"] }),
    ],
    hints: () => ["Giliran keluar dari depan: `shift`. Tindanan keluar dari belakang: `pop`.", "Semak panjang sebelum `shift` — kalau tidak kau akan menyimpan `undefined`."],
    jawapan: () => "function jalanGiliran(operasi) {\n  const baki = [];\n  const dikeluarkan = [];\n  for (const [jenis, nilai] of operasi) {\n    if (jenis === \"masuk\") baki.push(nilai);\n    else if (baki.length > 0) dikeluarkan.push(baki.shift());\n  }\n  return { baki, dikeluarkan };\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "terbalikPaut",
    tajuk: "Terbalikkan senarai berpaut",
    brief: () => "Nod ialah `{nilai, seterusnya}` dengan `null` di hujung. Tulis `terbalikPaut(kepala)` yang pulangkan kepala senarai terbalik.",
    starter: () => "function terbalikPaut(kepala) {\n\n}",
    cases: () => [
      U([{ nilai: 1, seterusnya: { nilai: 2, seterusnya: null } }], { nilai: 2, seterusnya: { nilai: 1, seterusnya: null } }),
      U([null], null),
      U([{ nilai: 9, seterusnya: null }], { nilai: 9, seterusnya: null }),
      U([{ nilai: 1, seterusnya: { nilai: 2, seterusnya: { nilai: 3, seterusnya: null } } }],
        { nilai: 3, seterusnya: { nilai: 2, seterusnya: { nilai: 1, seterusnya: null } } }),
    ],
    hints: () => ["Simpan tiga penunjuk: sebelum, semasa, seterusnya.", "Simpan `semasa.seterusnya` dahulu sebelum kau menimpanya — kalau tidak baki senarai hilang."],
    jawapan: () => "function terbalikPaut(kepala) {\n  let sebelum = null;\n  let semasa = kepala;\n  while (semasa) {\n    const seterusnya = semasa.seterusnya;\n    semasa.seterusnya = sebelum;\n    sebelum = semasa;\n    semasa = seterusnya;\n  }\n  return sebelum;\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "bfs",
    tajuk: "Lawatan melebar dahulu",
    brief: () => "Graf ialah `{nod: [jiran]}`. Tulis `bfs(graf, mula)` yang pulangkan susunan lawatan melebar dahulu. Jangan lawat nod dua kali. Nod tiada dalam graf dianggap tiada jiran.",
    starter: () => "function bfs(graf, mula) {\n\n}",
    cases: () => [
      U([{ a: ["b", "c"], b: ["d"], c: [], d: [] }, "a"], ["a", "b", "c", "d"]),
      U([{ a: ["b"], b: ["a"] }, "a"], ["a", "b"]),
      U([{}, "a"], ["a"]),
      U([{ a: ["b", "c"], b: ["c"], c: [] }, "a"], ["a", "b", "c"]),
    ],
    hints: () => ["Guna giliran (`shift`) dan `Set` untuk nod yang sudah dilawat.", "Tandakan nod sebagai dilawat semasa memasukkannya ke giliran, bukan semasa mengeluarkannya."],
    jawapan: () => "function bfs(graf, mula) {\n  const dilawat = new Set([mula]);\n  const giliran = [mula];\n  const susunan = [];\n  while (giliran.length > 0) {\n    const nod = giliran.shift();\n    susunan.push(nod);\n    for (const jiran of graf[nod] || []) {\n      if (!dilawat.has(jiran)) {\n        dilawat.add(jiran);\n        giliran.push(jiran);\n      }\n    }\n  }\n  return susunan;\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "dfs",
    tajuk: "Lawatan mendalam dahulu",
    brief: () => "Tulis `dfs(graf, mula)` yang pulangkan susunan lawatan mendalam dahulu — ikut jiran pertama sehingga habis sebelum kembali.",
    starter: () => "function dfs(graf, mula) {\n\n}",
    cases: () => [
      U([{ a: ["b", "c"], b: ["d"], c: [], d: [] }, "a"], ["a", "b", "d", "c"]),
      U([{ a: ["b"], b: ["a"] }, "a"], ["a", "b"]),
      U([{}, "x"], ["x"]),
      U([{ a: ["b", "c"], b: ["c"], c: [] }, "a"], ["a", "b", "c"]),
    ],
    hints: () => ["Rekursi ialah cara paling semula jadi — fungsi dalaman yang melawat satu nod.", "Beza dengan BFS hanyalah giliran menjadi tindanan, atau gelung menjadi rekursi."],
    jawapan: () => "function dfs(graf, mula) {\n  const dilawat = new Set();\n  const susunan = [];\n  function lawat(nod) {\n    if (dilawat.has(nod)) return;\n    dilawat.add(nod);\n    susunan.push(nod);\n    for (const jiran of graf[nod] || []) lawat(jiran);\n  }\n  lawat(mula);\n  return susunan;\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "adaKitaran",
    tajuk: "Kesan kitaran dalam graf berarah",
    brief: () => "Tulis `adaKitaran(graf)` yang pulangkan `true` jika graf berarah itu mengandungi kitaran. Nod yang menunjuk kepada dirinya sendiri juga kitaran.",
    starter: () => "function adaKitaran(graf) {\n\n}",
    cases: () => [
      U([{ a: ["b"], b: ["c"], c: ["a"] }], true),
      U([{ a: ["b"], b: [] }], false),
      U([{ a: ["a"] }], true),
      U([{}], false),
      U([{ a: ["b"], b: ["c"], c: [], d: ["a"] }], false),
    ],
    hints: () => ["Jejak dua set: nod yang sudah selesai, dan nod yang sedang berada dalam laluan semasa.", "Jika kau bertemu nod yang masih dalam laluan semasa, itu kitaran."],
    jawapan: () => "function adaKitaran(graf) {\n  const selesai = new Set();\n  const dalamLaluan = new Set();\n  function lawat(nod) {\n    if (dalamLaluan.has(nod)) return true;\n    if (selesai.has(nod)) return false;\n    dalamLaluan.add(nod);\n    for (const jiran of graf[nod] || []) {\n      if (lawat(jiran)) return true;\n    }\n    dalamLaluan.delete(nod);\n    selesai.add(nod);\n    return false;\n  }\n  return Object.keys(graf).some(lawat);\n}",
  },
  {
    bab: 21, jenis: "tulis", fn: "jalanLRU",
    tajuk: "Cache LRU",
    brief: () => "Tulis `jalanLRU(operasi, kapasiti)`. Operasi ialah `[\"set\", kunci, nilai]` atau `[\"get\", kunci]`. Bila penuh, buang kunci yang **paling lama tidak digunakan**. `get` yang berjaya menyegarkan kunci itu. Pulangkan array kunci yang tinggal, dari paling lama ke paling baharu.",
    starter: () => "function jalanLRU(operasi, kapasiti) {\n\n}",
    cases: () => [
      U([[["set", "a", 1], ["set", "b", 2], ["set", "c", 3]], 2], ["b", "c"]),
      U([[["set", "a", 1], ["set", "b", 2], ["get", "a"], ["set", "c", 3]], 2], ["a", "c"]),
      U([[], 2], []),
      U([[["set", "a", 1], ["set", "a", 2]], 2], ["a"]),
    ],
    hints: () => ["`Map` mengekalkan susunan sisipan — itu separuh daripada penyelesaiannya.", "Untuk menyegarkan kunci: `delete` kemudian `set` semula, supaya ia berpindah ke hujung."],
    jawapan: () => "function jalanLRU(operasi, kapasiti) {\n  const cache = new Map();\n  for (const [jenis, kunci, nilai] of operasi) {\n    if (jenis === \"get\") {\n      if (cache.has(kunci)) {\n        const v = cache.get(kunci);\n        cache.delete(kunci);\n        cache.set(kunci, v);\n      }\n    } else {\n      if (cache.has(kunci)) cache.delete(kunci);\n      cache.set(kunci, nilai);\n      if (cache.size > kapasiti) cache.delete(cache.keys().next().value);\n    }\n  }\n  return [...cache.keys()];\n}",
  },
  {
    bab: 21, jenis: "pilih",
    tajuk: "Map atau objek biasa",
    soalan: () => "Bila `Map` lebih sesuai daripada objek biasa `{}`?",
    pilihan: () => [
      "Bila kunci bukan string, bila susunan sisipan penting, atau bila kunci datang dari input pengguna",
      "Sentiasa — `Map` lebih laju dalam semua keadaan",
      "Hanya bila kau perlu lebih daripada 1,000 entri",
      "Bila kau perlu menukarkannya kepada JSON",
    ],
    betul: () => 0,
    huraian: () => "Objek menukar setiap kunci kepada string dan mewarisi sifat seperti `constructor` — kunci daripada input pengguna boleh berlanggar dengannya. `Map` menerima sebarang jenis kunci, mengekalkan susunan, dan mempunyai `.size`. Tetapi `JSON.stringify` tidak memahami `Map` — itu sebabnya objek masih berguna untuk data yang akan dihantar.",
  },

  /* ===== BAB 22 — REGEX & CORAK TEKS ===== */
  {
    bab: 22, jenis: "tulis", fn: "cariEmel",
    tajuk: "Cabut semua alamat emel",
    brief: () => "Tulis `cariEmel(teks)` yang pulangkan array semua alamat emel dalam teks. Tiada padanan → array kosong.",
    starter: () => "function cariEmel(teks) {\n\n}",
    cases: () => [
      U(["hubungi a@b.com atau c.d@e.co.uk"], ["a@b.com", "c.d@e.co.uk"]),
      U(["tiada apa-apa"], []),
      U([""], []),
      U(["x@y.my."], ["x@y.my."]),
    ],
    hints: () => ["Bendera `g` diperlukan untuk mendapat semua padanan, bukan yang pertama sahaja.", "`teks.match(re) || []` — `match` pulangkan `null` bila tiada padanan, bukan array kosong."],
    jawapan: () => "function cariEmel(teks) {\n  return teks.match(/[\\w.+-]+@[\\w-]+\\.[\\w.-]+/g) || [];\n}",
  },
  {
    bab: 22, jenis: "tulis", fn: "buangTag",
    tajuk: "Buang tag HTML",
    brief: () => "Tulis `buangTag(s)` yang membuang semua tag HTML tetapi mengekalkan teks di dalamnya.",
    starter: () => "function buangTag(s) {\n\n}",
    cases: () => [
      U(["<b>hai</b>"], "hai"), U(["a<br/>b"], "ab"), U([""], ""),
      U(["<p class=\"x\">teks</p>"], "teks"), U(["tiada tag"], "tiada tag"),
    ],
    hints: () => ["Satu tag ialah `<` diikuti apa-apa yang bukan `>`, kemudian `>`.", "`s.replace(/<[^>]*>/g, \"\")`"],
    jawapan: () => "function buangTag(s) {\n  return s.replace(/<[^>]*>/g, \"\");\n}",
  },
  {
    bab: 22, jenis: "tulis", fn: "nomborDalam",
    tajuk: "Cabut nombor dari teks",
    brief: () => "Tulis `nomborDalam(s)` yang pulangkan semua nombor dalam teks sebagai **nombor**, termasuk perpuluhan dan negatif.",
    starter: () => "function nomborDalam(s) {\n\n}",
    cases: () => [
      U(["harga -5 dan 3.5"], [-5, 3.5]),
      U(["tiada nombor"], []),
      U(["10 20"], [10, 20]),
      U(["suhu 36.6 darjah"], [36.6]),
    ],
    hints: () => ["`-?\\d+(\\.\\d+)?` menangkap negatif dan perpuluhan.", "`match` pulangkan string — kau perlu `.map(Number)`."],
    jawapan: () => "function nomborDalam(s) {\n  return (s.match(/-?\\d+(\\.\\d+)?/g) || []).map(Number);\n}",
  },
  {
    bab: 22, jenis: "tulis", fn: "telefonSah",
    tajuk: "Sahkan nombor telefon bimbit",
    brief: () => "Tulis `telefonSah(s)`. Selepas membuang tanda sengkang dan ruang, nombor mesti digit sahaja, bermula `01`, dan panjang 10 atau 11. Bukan string → `false`.",
    starter: () => "function telefonSah(s) {\n\n}",
    cases: () => [
      U(["012-3456789"], true), U(["0123456789"], true), U(["011 1234 5678"], true),
      U(["03-12345678"], false), U(["012-345678"], false), U(["012-34567890123"], false),
      U([null], false), U(["012-345678a"], false),
    ],
    hints: () => ["Bersihkan dahulu: `s.replace(/[-\\s]/g, \"\")`.", "Kemudian satu regex: `/^01\\d{8,9}$/`."],
    jawapan: () => "function telefonSah(s) {\n  if (typeof s !== \"string\") return false;\n  const bersih = s.replace(/[-\\s]/g, \"\");\n  return /^01\\d{8,9}$/.test(bersih);\n}",
  },
  {
    bab: 22, jenis: "tulis", fn: "tukarTarikh",
    tajuk: "Kumpulan tangkapan",
    brief: () => "Tulis `tukarTarikh(s)` yang tukar `\"31/12/2024\"` kepada `\"2024-12-31\"`. Jika bentuknya tidak sepadan, pulangkan `s` tanpa diubah.",
    starter: () => "function tukarTarikh(s) {\n\n}",
    cases: () => [
      U(["31/12/2024"], "2024-12-31"), U(["01/01/2000"], "2000-01-01"),
      U(["2024-12-31"], "2024-12-31"), U(["hai"], "hai"), U([""], ""),
    ],
    hints: () => ["Kurungan dalam regex mencipta kumpulan tangkapan.", "Dalam string gantian, `$1` merujuk kumpulan pertama."],
    jawapan: () => "function tukarTarikh(s) {\n  return s.replace(/^(\\d{2})\\/(\\d{2})\\/(\\d{4})$/, \"$3-$2-$1\");\n}",
  },
  {
    bab: 22, jenis: "ramal",
    tajuk: "Tamak secara lalai",
    kod: () => `console.log("<a><b>".match(/<.*>/)[0]);`,
    output: () => "<a><b>",
    brief: () => "Apa yang dicetak?",
    hints: () => ["`.*` mengambil sebanyak mungkin, kemudian berundur hanya sekadar cukup untuk padan.", "`.*?` ialah versi malas yang berhenti seawal mungkin — ia akan beri `<a>`."],
  },
  {
    bab: 22, jenis: "baiki", fn: "buangRuang",
    tajuk: "Bendera g yang tertinggal",
    brief: () => "`buangRuang(s)` sepatutnya membuang **semua** ruang. Ia hanya membuang yang pertama. Baiki.",
    starter: () => "function buangRuang(s) {\n  return s.replace(/\\s/, \"\");\n}",
    cases: () => [U(["a b c"], "abc"), U(["  x  "], "x"), U([""], ""), U(["tiadaruang"], "tiadaruang")],
    hints: () => ["`replace` tanpa bendera `g` hanya menggantikan padanan pertama.", "Tambah `g` selepas garis miring penutup."],
    jawapan: () => "function buangRuang(s) {\n  return s.replace(/\\s/g, \"\");\n}",
  },
  {
    bab: 22, jenis: "pilih",
    tajuk: "Bila regex jadi bahaya",
    soalan: () => "Kau menyemak input pengguna dengan `/^(a+)+$/`. Apa risikonya?",
    pilihan: () => [
      "Backtracking bencana — satu input pendek yang direka khas boleh menggantung CPU selama beberapa minit",
      "Ia akan menolak input yang sah",
      "Ia hanya perlahan pada input yang sangat panjang",
      "Tiada risiko, regex sentiasa linear",
    ],
    betul: () => 0,
    huraian: () => "Kuantifier bersarang seperti `(a+)+` mencipta bilangan laluan padanan yang meningkat secara eksponen. Input seperti 30 huruf `a` diikuti satu `b` boleh membekukan proses. Ini serangan ReDoS. Elak kuantifier bersarang, dan hadkan panjang input sebelum regex berjalan.",
  },

  /* ===== BAB 23 — HTTP & API ===== */
  {
    bab: 23, jenis: "tulis", fn: "binaURL",
    tajuk: "Bina URL dengan parameter",
    brief: () => "Tulis `binaURL(asas, param)` yang menambah rentetan pertanyaan. Nilai mesti dienkod. Kunci dengan nilai `null` atau `undefined` dilangkau. Tiada parameter → pulangkan `asas` seadanya.",
    starter: () => "function binaURL(asas, param) {\n\n}",
    cases: () => [
      U(["https://a.com/x", { q: "nasi lemak", n: 2 }], "https://a.com/x?q=nasi%20lemak&n=2"),
      U(["https://a.com", {}], "https://a.com"),
      U(["https://a.com", { a: 1, b: null, c: undefined }], "https://a.com?a=1"),
      U(["https://a.com", { t: "a&b" }], "https://a.com?t=a%26b"),
    ],
    hints: () => ["`encodeURIComponent` melarikan ruang, `&` dan `=` supaya ia tidak memecahkan URL.", "Bina array `\"kunci=nilai\"` kemudian `join(\"&\")`."],
    jawapan: () => "function binaURL(asas, param) {\n  const bahagian = Object.entries(param || {})\n    .filter(([, v]) => v !== null && v !== undefined)\n    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);\n  return bahagian.length === 0 ? asas : `${asas}?${bahagian.join(\"&\")}`;\n}",
  },
  {
    bab: 23, jenis: "tulis", fn: "kendaliRespons",
    tajuk: "Apa nak buat dengan setiap status",
    brief: () => "Tulis `kendaliRespons(status)`:\n• 200–299 → `\"guna\"`\n• 401 → `\"log masuk semula\"`\n• 403 → `\"tiada akses\"`\n• 404 → `\"tidak dijumpai\"`\n• 429 atau 500–599 → `\"cuba semula\"`\n• selain itu → `\"papar ralat\"`",
    starter: () => "function kendaliRespons(status) {\n\n}",
    cases: () => [
      U([200], "guna"), U([204], "guna"), U([401], "log masuk semula"),
      U([403], "tiada akses"), U([404], "tidak dijumpai"), U([429], "cuba semula"),
      U([500], "cuba semula"), U([503], "cuba semula"), U([400], "papar ralat"), U([418], "papar ralat"),
    ],
    hints: () => ["Kes khusus dahulu, julat kemudian.", "Perbezaan penting: 401 bermakna \"siapa awak?\", 403 bermakna \"saya tahu siapa awak, dan tidak\"."],
    jawapan: () => "function kendaliRespons(status) {\n  if (status >= 200 && status < 300) return \"guna\";\n  if (status === 401) return \"log masuk semula\";\n  if (status === 403) return \"tiada akses\";\n  if (status === 404) return \"tidak dijumpai\";\n  if (status === 429 || (status >= 500 && status < 600)) return \"cuba semula\";\n  return \"papar ralat\";\n}",
  },
  {
    bab: 23, jenis: "tulis", fn: "kelewatanCuba",
    tajuk: "Backoff eksponen",
    brief: () => "Tulis `kelewatanCuba(cuba, asas)` = `asas × 2^(cuba−1)`, dihadkan pada 30000 ms. `cuba` bukan integer ≥ 1 → baling `\"cuba\"`.",
    starter: () => "function kelewatanCuba(cuba, asas) {\n\n}",
    cases: () => [
      U([1, 100], 100), U([3, 100], 400), U([10, 1000], 30000),
      U([1, 1000], 1000), U([4, 250], 2000), B([0, 100], "cuba"), B([1.5, 100], "cuba"),
    ],
    hints: () => ["Cuba semula serta-merta berulang kali hanya menambah beban pelayan yang sudah tenat.", "`Math.min(asas * 2 ** (cuba - 1), 30000)`"],
    jawapan: () => "function kelewatanCuba(cuba, asas) {\n  if (!Number.isInteger(cuba) || cuba < 1) throw new Error(\"cuba tidak sah\");\n  return Math.min(asas * 2 ** (cuba - 1), 30000);\n}",
  },
  {
    bab: 23, jenis: "tulis", fn: "hurailKuki",
    tajuk: "Hurai pengepala kuki",
    brief: () => "Tulis `hurailKuki(s)` yang tukar `\"a=1; b=2\"` kepada `{a: \"1\", b: \"2\"}`. String kosong → `{}`. Nilai kekal sebagai string.",
    starter: () => "function hurailKuki(s) {\n\n}",
    cases: () => [
      U(["a=1; b=2"], { a: "1", b: "2" }), U([""], {}), U(["x=1"], { x: "1" }),
      U(["a=1;b=2"], { a: "1", b: "2" }), U(["sesi=abc123"], { sesi: "abc123" }),
    ],
    hints: () => ["Pecah pada `;` diikuti ruang pilihan: `/;\\s*/`.", "Setiap kepingan dipecah sekali sahaja pada `=` pertama."],
    jawapan: () => "function hurailKuki(s) {\n  const hasil = {};\n  if (!s) return hasil;\n  for (const bahagian of s.split(/;\\s*/)) {\n    const i = bahagian.indexOf(\"=\");\n    if (i > 0) hasil[bahagian.slice(0, i)] = bahagian.slice(i + 1);\n  }\n  return hasil;\n}",
  },
  {
    bab: 23, jenis: "tulis", fn: "kursorSeterusnya",
    tajuk: "Halaman berasaskan kursor",
    brief: () => "Tulis `kursorSeterusnya(item, had)`. Pulangkan `{item, kursor}` — `item` ialah `had` item pertama, `kursor` ialah `id` item selepasnya, atau `null` jika sudah habis.",
    starter: () => "function kursorSeterusnya(item, had) {\n\n}",
    cases: () => [
      U([[{ id: 1 }, { id: 2 }, { id: 3 }], 2], { item: [{ id: 1 }, { id: 2 }], kursor: 3 }),
      U([[{ id: 1 }], 2], { item: [{ id: 1 }], kursor: null }),
      U([[], 2], { item: [], kursor: null }),
    ],
    hints: () => ["Ambil `had` item, kemudian intai satu lagi untuk kursor.", "Halaman berasaskan kursor tidak melompat bila data baharu disisipkan — offset boleh."],
    jawapan: () => "function kursorSeterusnya(item, had) {\n  const halaman = item.slice(0, had);\n  const seterusnya = item[had];\n  return { item: halaman, kursor: seterusnya ? seterusnya.id : null };\n}",
  },
  {
    bab: 23, jenis: "pilih",
    tajuk: "Idempoten",
    soalan: () => "Kaedah HTTP mana yang idempoten — memanggilnya lima kali memberi kesan yang sama seperti sekali?",
    pilihan: () => [
      "`GET`, `PUT` dan `DELETE` — tetapi bukan `POST`",
      "Semua kaedah HTTP adalah idempoten",
      "Hanya `GET`",
      "`POST` dan `PUT`, kerana kedua-duanya menghantar data",
    ],
    betul: () => 0,
    huraian: () => "`PUT` menetapkan keadaan kepada nilai yang diberi — ulangi seberapa kali pun, hasilnya sama. `POST` mencipta sesuatu yang baharu setiap kali, jadi cuba semula automatik boleh mencipta dua pesanan. Itulah sebabnya API pembayaran memerlukan kunci idempoten pada `POST`.",
  },
  {
    bab: 23, jenis: "pilih",
    tajuk: "Apa yang CORS lindungi",
    soalan: () => "CORS menyekat permintaan browser kau ke API lain. Apa yang ia sebenarnya lindungi?",
    pilihan: () => [
      "Pengguna — ia menghalang laman jahat daripada membaca respons API yang menggunakan kuki log masuk pengguna",
      "Pelayan API — ia menghalang orang daripada memanggil API itu",
      "Data kau daripada diintip semasa dalam perjalanan",
      "Tiada apa; ia hanya kesilapan konfigurasi",
    ],
    betul: () => 0,
    huraian: () => "CORS bukan keselamatan pelayan — `curl` dan mana-mana backend boleh memanggil API itu tanpa halangan. Ia peraturan browser yang menghalang laman `jahat.com` daripada membuat permintaan berkuki ke `bank.com` dan **membaca** jawapannya. Jika kau perlu menyekat siapa yang boleh memanggil API, itu kerja pengesahan, bukan CORS.",
  },
  {
    bab: 23, jenis: "pilih",
    tajuk: "Status untuk data rosak",
    soalan: () => "Pengguna yang sudah log masuk menghantar borang dengan emel tidak sah. Status apa yang kau pulangkan?",
    pilihan: () => [
      "400 — permintaan itu sendiri tidak sah",
      "401 — pengesahan gagal",
      "403 — dilarang",
      "500 — ralat pelayan",
    ],
    betul: () => 0,
    huraian: () => "401 bermakna \"kami tidak tahu siapa awak\", 403 bermakna \"kami tahu, dan awak tidak dibenarkan\", 400 bermakna \"apa yang awak hantar itu salah\". Memulangkan 500 untuk kesilapan pengguna akan membanjiri amaran pengeluaran kau dengan bunyi bising.",
  },

  /* ===== BAB 24 — PRESTASI & CACHE ===== */
  {
    bab: 24, jenis: "tulis", fn: "ingatKira",
    tajuk: "Memoisasi",
    brief: () => "Tulis `ingatKira(fn, hujah)`. Panggil `fn` untuk setiap nilai dalam `hujah`, tetapi simpan hasil supaya hujah yang sama tidak memanggil `fn` dua kali. Pulangkan `{hasil, panggilan}` — `panggilan` ialah bilangan kali `fn` benar-benar dijalankan.",
    starter: () => "function ingatKira(fn, hujah) {\n\n}",
    cases: () => [
      { args: [EV("(x) => x * 2"), [1, 2, 1, 1]], expected: { hasil: [2, 4, 2, 2], panggilan: 2 } },
      { args: [EV("(x) => x"), []], expected: { hasil: [], panggilan: 0 } },
      { args: [EV("(x) => x + 1"), [5, 5, 5]], expected: { hasil: [6, 6, 6], panggilan: 1 } },
    ],
    hints: () => ["`Map` menyimpan hujah asal sebagai kunci tanpa menukarnya kepada string.", "Semak `cache.has(h)` sebelum memanggil, bukan selepas."],
    jawapan: () => "function ingatKira(fn, hujah) {\n  const cache = new Map();\n  let panggilan = 0;\n  const hasil = hujah.map((h) => {\n    if (!cache.has(h)) {\n      panggilan++;\n      cache.set(h, fn(h));\n    }\n    return cache.get(h);\n  });\n  return { hasil, panggilan };\n}",
  },
  {
    bab: 24, jenis: "tulis", fn: "nyahlantun",
    tajuk: "Nyahlantun (debounce)",
    brief: () => "Diberi array cap masa peristiwa, tulis `nyahlantun(peristiwa, tetingkap)` yang pulangkan cap masa yang **benar-benar akan dicetuskan**. Peristiwa dicetuskan hanya jika tiada peristiwa lain berlaku dalam `tetingkap` ms selepasnya.",
    starter: () => "function nyahlantun(peristiwa, tetingkap) {\n\n}",
    cases: () => [
      U([[0, 50, 300], 100], [50, 300]),
      U([[], 100], []),
      U([[0], 100], [0]),
      U([[0, 10, 20], 100], [20]),
      U([[0, 200, 400], 100], [0, 200, 400]),
    ],
    hints: () => ["Peristiwa terakhir sentiasa dicetuskan — tiada apa yang mengikutinya.", "Untuk yang lain: bandingkan jurang dengan peristiwa seterusnya, bukan yang sebelumnya."],
    jawapan: () => "function nyahlantun(peristiwa, tetingkap) {\n  return peristiwa.filter((t, i) => {\n    const seterusnya = peristiwa[i + 1];\n    return seterusnya === undefined || seterusnya - t >= tetingkap;\n  });\n}",
  },
  {
    bab: 24, jenis: "tulis", fn: "pendikit",
    tajuk: "Pendikit (throttle)",
    brief: () => "Tulis `pendikit(peristiwa, tetingkap)`. Peristiwa pertama dicetuskan. Selepas itu, peristiwa hanya dicetuskan jika sekurang-kurangnya `tetingkap` ms telah berlalu sejak cetusan terakhir.",
    starter: () => "function pendikit(peristiwa, tetingkap) {\n\n}",
    cases: () => [
      U([[0, 50, 120, 130, 300], 100], [0, 120, 300]),
      U([[], 100], []),
      U([[0], 100], [0]),
      U([[0, 99], 100], [0]),
      U([[0, 100], 100], [0, 100]),
    ],
    hints: () => ["Jejak masa cetusan terakhir, bukan masa peristiwa terakhir.", "Nyahlantun menunggu sehingga senyap; pendikit membenarkan aliran tetap."],
    jawapan: () => "function pendikit(peristiwa, tetingkap) {\n  const hasil = [];\n  let terakhir = -Infinity;\n  for (const t of peristiwa) {\n    if (t - terakhir >= tetingkap) {\n      hasil.push(t);\n      terakhir = t;\n    }\n  }\n  return hasil;\n}",
  },
  {
    bab: 24, jenis: "tulis", fn: "jalanCacheTTL",
    tajuk: "Cache dengan tempoh luput",
    brief: () => "Tulis `jalanCacheTTL(operasi, tempoh)`. Operasi ialah `[\"set\", kunci, nilai, masa]` atau `[\"get\", kunci, masa]`. Entri luput bila umurnya mencapai `tempoh`. Pulangkan array hasil setiap `get` — `null` jika tiada atau sudah luput.",
    starter: () => "function jalanCacheTTL(operasi, tempoh) {\n\n}",
    cases: () => [
      U([[["set", "a", 1, 0], ["get", "a", 50], ["get", "a", 150], ["get", "b", 0]], 100], [1, null, null]),
      U([[], 100], []),
      U([[["set", "a", 1, 0], ["set", "a", 2, 100], ["get", "a", 150]], 100], [2]),
      U([[["set", "a", 1, 0], ["get", "a", 100]], 100], [null]),
    ],
    hints: () => ["Simpan masa penyimpanan bersama nilai: `{nilai, disimpan}`.", "Luput bila `masa - disimpan >= tempoh` — perhatikan sempadan tepat."],
    jawapan: () => "function jalanCacheTTL(operasi, tempoh) {\n  const cache = new Map();\n  const hasil = [];\n  for (const [jenis, kunci, a, b] of operasi) {\n    if (jenis === \"set\") {\n      cache.set(kunci, { nilai: a, disimpan: b });\n    } else {\n      const e = cache.get(kunci);\n      if (!e || a - e.disimpan >= tempoh) hasil.push(null);\n      else hasil.push(e.nilai);\n    }\n  }\n  return hasil;\n}",
  },
  {
    bab: 24, jenis: "tulis", fn: "kumpulPermintaan",
    tajuk: "Kelompokkan permintaan",
    brief: () => "Tulis `kumpulPermintaan(id, saiz)` yang membuang pendua (kekalkan susunan pertama) kemudian memecahkan kepada kelompok bersaiz `saiz`.",
    starter: () => "function kumpulPermintaan(id, saiz) {\n\n}",
    cases: () => [
      U([[1, 2, 2, 3, 4], 2], [[1, 2], [3, 4]]),
      U([[], 2], []),
      U([[1, 1, 1], 2], [[1]]),
      U([[1, 2, 3], 2], [[1, 2], [3]]),
    ],
    hints: () => ["Dua langkah, satu demi satu: nyahduplikasi, kemudian pecah.", "Meminta ID yang sama dua kali dalam satu kelompok ialah pembaziran yang mudah dielakkan."],
    jawapan: () => "function kumpulPermintaan(id, saiz) {\n  const unik = [...new Set(id)];\n  const hasil = [];\n  for (let i = 0; i < unik.length; i += saiz) hasil.push(unik.slice(i, i + saiz));\n  return hasil;\n}",
  },
  {
    bab: 24, jenis: "baiki", fn: "unikPantas",
    tajuk: "Semakan O(n²) tersembunyi",
    brief: () => "`unikPantas(arr)` betul tetapi mengimbas seluruh hasil untuk setiap elemen — pada 50,000 item ia menggantung. Tulis semula supaya semakan kewujudan menjadi masa malar.",
    starter: () => "function unikPantas(arr) {\n  const hasil = [];\n  for (const x of arr) {\n    if (!hasil.includes(x)) hasil.push(x);\n  }\n  return hasil;\n}",
    cases: () => [U([[1, 1, 2]], [1, 2]), U([[]], []), U([["a", "b", "a"]], ["a", "b"]), U([[3, 2, 3, 1]], [3, 2, 1])],
    syarat: () => [{ ujian: (s) => /new Set|new Map/.test(s), mesej: "Guna `Set` atau `Map` untuk semakan kewujudan masa malar." }],
    hints: () => ["`includes` di dalam gelung ialah punca paling biasa kod yang tiba-tiba perlahan pada data sebenar.", "`Set` menyimpan apa yang sudah dilihat, dan `has` ialah O(1)."],
    jawapan: () => "function unikPantas(arr) {\n  const dilihat = new Set();\n  const hasil = [];\n  for (const x of arr) {\n    if (!dilihat.has(x)) {\n      dilihat.add(x);\n      hasil.push(x);\n    }\n  }\n  return hasil;\n}",
  },
  {
    bab: 24, jenis: "pilih",
    tajuk: "Ukur sebelum optimum",
    soalan: () => "Halaman kau terasa perlahan. Apa langkah pertama?",
    pilihan: () => [
      "Ukur — profil dan cari di mana masa sebenarnya dihabiskan",
      "Cache semuanya yang boleh dicache",
      "Tulis semula gelung terdalam supaya lebih cekap",
      "Naik taraf pelayan",
    ],
    betul: () => 0,
    huraian: () => "Tekaan tentang prestasi hampir selalu salah. Kod yang kelihatan mahal selalunya bukan puncanya — biasanya ia satu pertanyaan pangkalan data yang tidak diindeks, atau imej 4MB, atau panggilan rangkaian bersiri. Optimumkan tanpa mengukur dan kau akan menghabiskan seminggu untuk memperbaiki 2%.",
  },
  {
    bab: 24, jenis: "pilih",
    tajuk: "Purata menipu",
    soalan: () => "Latensi API kau: purata 120ms, p99 4,000ms. Apa maksudnya?",
    pilihan: () => [
      "Satu daripada setiap 100 permintaan mengambil 4 saat — ramai pengguna sebenar mengalaminya berkali-kali sehari",
      "Prestasi baik; purata itu yang penting",
      "Ada satu permintaan pencilan yang boleh diabaikan",
      "Sistem itu stabil kerana purata rendah",
    ],
    betul: () => 0,
    huraian: () => "Satu halaman selalunya membuat 20 permintaan. Pada p99 4 saat, kira-kira satu daripada lima muat halaman akan terkena sekurang-kurangnya satu permintaan lambat. Purata menyembunyikan ekor; pantau p95 dan p99, kerana itulah yang pengguna rasa.",
  },

  /* ===== BAB 25 — REKA BENTUK & ABSTRAKSI ===== */
  {
    bab: 25, jenis: "tulis", fn: "jalanAkaun",
    tajuk: "Peraturan yang dijaga di satu tempat",
    brief: () => "Tulis `jalanAkaun(operasi)`. Operasi ialah `[\"deposit\", n]` atau `[\"keluar\", n]`. Baki bermula 0.\n• `n` bukan nombor > 0 → catat `\"jumlah tidak sah\"`, baki tak berubah\n• pengeluaran melebihi baki → catat `\"baki tidak cukup\"`, baki tak berubah\nPulangkan `{baki, ralat}`.",
    starter: () => "function jalanAkaun(operasi) {\n\n}",
    cases: () => [
      U([[["deposit", 100], ["keluar", 30]]], { baki: 70, ralat: [] }),
      U([[["keluar", 10]]], { baki: 0, ralat: ["baki tidak cukup"] }),
      U([[["deposit", -5]]], { baki: 0, ralat: ["jumlah tidak sah"] }),
      U([[]], { baki: 0, ralat: [] }),
      U([[["deposit", 50], ["keluar", 50], ["keluar", 1]]], { baki: 0, ralat: ["baki tidak cukup"] }),
    ],
    hints: () => ["Sahkan jumlah dahulu, kemudian baru peraturan perniagaan.", "Baki hanya berubah di satu tempat — itulah maksud enkapsulasi."],
    jawapan: () => "function jalanAkaun(operasi) {\n  let baki = 0;\n  const ralat = [];\n  for (const [jenis, n] of operasi) {\n    if (typeof n !== \"number\" || !Number.isFinite(n) || n <= 0) {\n      ralat.push(\"jumlah tidak sah\");\n      continue;\n    }\n    if (jenis === \"deposit\") baki += n;\n    else if (n > baki) ralat.push(\"baki tidak cukup\");\n    else baki -= n;\n  }\n  return { baki, ralat };\n}",
  },
  {
    bab: 25, jenis: "tulis", fn: "mesinKeadaan",
    tajuk: "Mesin keadaan pesanan",
    brief: () => "Keadaan bermula `\"baru\"`. Peralihan dibenarkan:\n• baru → dibayar, dibatalkan\n• dibayar → dihantar, dibatalkan\n• dihantar → selesai\n• selesai, dibatalkan → tiada\nTulis `mesinKeadaan(peristiwa)` yang pulangkan `{keadaan, ditolak}`.",
    starter: () => "function mesinKeadaan(peristiwa) {\n\n}",
    cases: () => [
      U([["dibayar", "dihantar", "selesai"]], { keadaan: "selesai", ditolak: [] }),
      U([["dihantar"]], { keadaan: "baru", ditolak: ["dihantar"] }),
      U([["dibayar", "dibatalkan", "dihantar"]], { keadaan: "dibatalkan", ditolak: ["dihantar"] }),
      U([[]], { keadaan: "baru", ditolak: [] }),
    ],
    hints: () => ["Peralihan yang sah ialah data, bukan logik: `{baru: [\"dibayar\", \"dibatalkan\"], …}`.", "Menyimpannya sebagai jadual bermakna peraturan boleh dibaca sekali pandang."],
    jawapan: () => "function mesinKeadaan(peristiwa) {\n  const peralihan = {\n    baru: [\"dibayar\", \"dibatalkan\"],\n    dibayar: [\"dihantar\", \"dibatalkan\"],\n    dihantar: [\"selesai\"],\n    selesai: [],\n    dibatalkan: [],\n  };\n  let keadaan = \"baru\";\n  const ditolak = [];\n  for (const p of peristiwa) {\n    if (peralihan[keadaan].includes(p)) keadaan = p;\n    else ditolak.push(p);\n  }\n  return { keadaan, ditolak };\n}",
  },
  {
    bab: 25, jenis: "tulis", fn: "bekasKonfig",
    tajuk: "Konfigurasi berlapis",
    brief: () => "Tulis `bekasKonfig(lapisan)` — array objek konfigurasi dari keutamaan paling rendah ke paling tinggi. Lapisan kemudian mengatasi yang awal. Objek bersarang digabungkan, bukan diganti.",
    starter: () => "function bekasKonfig(lapisan) {\n\n}",
    cases: () => [
      U([[{ a: 1, b: { x: 1 } }, { b: { y: 2 } }]], { a: 1, b: { x: 1, y: 2 } }),
      U([[]], {}),
      U([[{ a: 1 }, { a: 2 }]], { a: 2 }),
      U([[{ a: { b: 1 } }, { a: 2 }]], { a: 2 }),
    ],
    hints: () => ["Ini corak lalai → fail → persekitaran → bendera baris arahan.", "Gabung dua objek pada satu masa, secara rekursif untuk nilai objek biasa."],
    jawapan: () => "function bekasKonfig(lapisan) {\n  const objBiasa = (v) => v && typeof v === \"object\" && !Array.isArray(v);\n  function gabung(a, b) {\n    const hasil = { ...a };\n    for (const k of Object.keys(b)) {\n      if (objBiasa(hasil[k]) && objBiasa(b[k])) hasil[k] = gabung(hasil[k], b[k]);\n      else hasil[k] = b[k];\n    }\n    return hasil;\n  }\n  return lapisan.reduce((a, b) => gabung(a, b), {});\n}",
  },
  {
    bab: 25, jenis: "baiki", fn: "tukarMataWang",
    tajuk: "Kebergantungan tersembunyi",
    brief: () => "`tukarMataWang` membaca pembolehubah global `kadar`. Ia tidak boleh diuji, dan dua bahagian aplikasi tidak boleh guna kadar berbeza. Tukar supaya kadar masuk sebagai parameter kedua.",
    starter: () => "let kadar = 1;\n\nfunction tukarMataWang(jumlah) {\n  return jumlah * kadar;\n}",
    cases: () => [U([100, 4.5], 450), U([0, 4.5], 0), U([10, 0.5], 5), U([2, 3], 6)],
    syarat: () => [{ ujian: (s) => !/^\s*let\s+kadar/m.test(s), mesej: "Buang pembolehubah global `kadar` sepenuhnya." }],
    hints: () => ["Keadaan global menjadikan fungsi bergantung pada sesuatu yang tidak kelihatan dalam tandatangannya.", "Apa yang fungsi perlukan sepatutnya datang melalui parameternya."],
    jawapan: () => "function tukarMataWang(jumlah, kadar) {\n  return jumlah * kadar;\n}",
  },
  {
    bab: 25, jenis: "ramal",
    tajuk: "this yang tercicir",
    kod: () => `const obj = { n: 5, beri() { return this.n; } };\nconst f = obj.beri;\nconsole.log(obj.beri() + "," + f());`,
    output: () => "5,undefined",
    brief: () => "Apa yang dicetak?",
    hints: () => ["`this` ditentukan oleh **cara** fungsi dipanggil, bukan di mana ia ditulis.", "`f()` dipanggil tanpa objek pemilik, jadi `this` bukan lagi `obj`."],
  },
  {
    bab: 25, jenis: "pilih",
    tajuk: "Komposisi atau pewarisan",
    soalan: () => "Kau perlu `PenggunaAdmin` yang boleh buat semua yang `Pengguna` boleh, tambah beberapa keupayaan. Apa pendekatan yang lebih tahan lama?",
    pilihan: () => [
      "Komposisi — bina keupayaan sebagai bahagian berasingan dan gabungkan mengikut keperluan",
      "Pewarisan — `PenggunaAdmin extends Pengguna`",
      "Salin kod `Pengguna` ke dalam `PenggunaAdmin`",
      "Satu kelas dengan bendera `adalahAdmin`",
    ],
    betul: () => 0,
    huraian: () => "Pewarisan berfungsi sehingga kau perlukan `PenggunaAdminTamu` yang mahu separuh daripada setiap satu. Hierarki menjadi rapuh kerana ia memaksa setiap objek masuk ke dalam satu jalur. Komposisi membiarkan kau memilih keupayaan tanpa membentuk semula pokok warisan.",
  },
  {
    bab: 25, jenis: "pilih",
    tajuk: "Satu tanggungjawab",
    soalan: () => "Fungsi `simpanPesanan` mengesahkan input, mengira cukai, menulis ke pangkalan data, menghantar emel, dan mencatat log. Apa masalah praktikalnya?",
    pilihan: () => [
      "Kau tidak boleh menguji pengiraan cukai tanpa pangkalan data dan pelayan emel",
      "Ia terlalu panjang untuk dibaca dalam satu skrin",
      "Ia melanggar peraturan penamaan",
      "Tiada masalah selagi ia berfungsi",
    ],
    betul: () => 0,
    huraian: () => "Ujian ialah ujian lakmus yang praktikal. Jika kau tidak boleh menguji satu bahagian tanpa menyediakan empat bahagian lain, tanggungjawabnya bercampur. Asingkan logik tulen daripada kesan sampingan, dan kedua-duanya menjadi lebih mudah diuji dan diubah.",
  },
  {
    bab: 25, jenis: "pilih",
    tajuk: "Bergantung pada bentuk, bukan pelaksanaan",
    soalan: () => "Kod kau memanggil `hantarEmel(...)` daripada satu perpustakaan tertentu di 30 tempat. Kenapa itu berisiko?",
    pilihan: () => [
      "Menukar pembekal bermakna menyentuh 30 tempat — satu lapisan nipis `hantarNotis` menjadikannya satu tempat",
      "Perpustakaan itu mungkin mempunyai pepijat",
      "Ia menjadikan kod lebih perlahan",
      "Tiada risiko jika perpustakaan itu popular",
    ],
    betul: () => 0,
    huraian: () => "Ini bukan alasan untuk membalut segala-galanya — pembalut yang terlalu banyak lapisan juga menyakitkan. Peraturan praktikal: balut perkara yang kau jangka akan berubah atau perlu dipalsukan dalam ujian. Pembekal emel, pembekal pembayaran dan penyimpanan fail memenuhi kedua-dua kriteria itu.",
  },
];

TUGAS.push(...TUGAS_TAMBAHAN_4);

/* ---------- Peta level ---------- */
function babUntuk(n) {
  return BAB.find((b) => n >= b.dari && n <= b.hingga) || BAB[0];
}
function levelKe(n) {
  const bab = babUntuk(n);
  const r = mulberry32(n * 2654435761 + 101);
  let bank = TUGAS.filter((t) => t.bab === bab.n);
  let tugas;
  if (bab.n === 26) {
    // Cabaran campur: tugasan sukar bab 26 bercampur dengan semua bab sebelumnya
    bank = bank.concat(TUGAS.filter((t) => t.bab >= 5 && t.bab !== 26));
    tugas = bank[Math.floor(r() * bank.length)];
  } else if (bank.length === 0) {
    tugas = TUGAS[Math.floor(r() * TUGAS.length)];
  } else {
    tugas = bank[(n - bab.dari) % bank.length];
  }
  const p = tugas.gen ? tugas.gen(r) : {};
  return { n, bab, tugas, p };
}
const val = (x, p) => (typeof x === "function" ? x(p) : x);

/* ---------- Runner ---------- */
const WORKER_SRC = `
function fmt(v){
  if (v === undefined) return "undefined";
  if (v === null) return "null";
  if (typeof v === "string") return JSON.stringify(v);
  if (typeof v === "function") return "[fungsi]";
  try { return JSON.stringify(v); } catch (e) { return String(v); }
}
function eq(a,b){
  if (a === b) return true;
  if (typeof a === "number" && typeof b === "number") {
    if (a !== a && b !== b) return true;
    return Math.abs(a-b) < 1e-9;
  }
  if (a === null || b === null) return false;
  if (typeof a !== "object" || typeof b !== "object") return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  var ka = Object.keys(a), kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (var i=0;i<ka.length;i++){
    var k = ka[i];
    if (!Object.prototype.hasOwnProperty.call(b,k)) return false;
    if (!eq(a[k], b[k])) return false;
  }
  return true;
}
function hidup(v){
  if (v && typeof v === "object") {
    if (typeof v.__ev === "string") { return new Function("return (" + v.__ev + ");")(); }
    if (Array.isArray(v)) return v.map(hidup);
  }
  return v;
}
self.onmessage = function(e){
  var d = e.data;
  var fn;
  try {
    fn = new Function('"use strict";' + d.code + "\\nreturn typeof " + d.fn + ' === "function" ? ' + d.fn + " : undefined;")();
  } catch (err) {
    self.postMessage({ fatal: "Kod tak boleh dibaca — " + (err && err.message ? err.message : String(err)) });
    return;
  }
  if (typeof fn !== "function") {
    self.postMessage({ fatal: "Fungsi " + d.fn + " tidak dijumpai. Semak ejaan nama." });
    return;
  }
  var out = [];
  var i = 0;
  function seterusnya(){
    if (i >= d.cases.length) { self.postMessage({ results: out }); return; }
    var c = d.cases[i];
    var hasil, err = null;
    try { hasil = fn.apply(null, c.args.map(hidup)); }
    catch (ex) { err = ex && ex.message ? ex.message : String(ex); }
    Promise.resolve(err === null ? hasil : null).then(function(nilai){
      var lulus, papar;
      if (c.baling) {
        lulus = err !== null && (c.baling === true || String(err).toLowerCase().indexOf(String(c.baling).toLowerCase()) >= 0);
        papar = err === null ? "tiada ralat dibaling — dapat " + fmt(nilai) : "ralat: " + err;
      } else {
        lulus = err === null && eq(nilai, c.expected);
        papar = err === null ? fmt(nilai) : "RALAT: " + err;
      }
      out.push({ lulus: lulus, papar: papar });
      i++; seterusnya();
    }, function(rej){
      var m = rej && rej.message ? rej.message : String(rej);
      var lulus = c.baling ? (c.baling === true || m.toLowerCase().indexOf(String(c.baling).toLowerCase()) >= 0) : false;
      out.push({ lulus: lulus, papar: "RALAT: " + m });
      i++; seterusnya();
    });
  }
  seterusnya();
};
`;

/* Sandaran: jalankan dalam thread utama kalau Worker disekat.
   Tiada perlindungan masa tamat di sini — gelung tak berhenti akan membekukan halaman. */
function hidupM(v) {
  if (v && typeof v === "object") {
    if (typeof v.__ev === "string") { try { return new Function("return (" + v.__ev + ");")(); } catch (e) { return v; } }
    if (Array.isArray(v)) return v.map(hidupM);
  }
  return v;
}
function fmtM(v) {
  if (v === undefined) return "undefined";
  if (v === null) return "null";
  if (typeof v === "string") return JSON.stringify(v);
  if (typeof v === "function") return "[fungsi]";
  try { return JSON.stringify(v); } catch (e) { return String(v); }
}
function eqM(a, b) {
  if (a === b) return true;
  if (typeof a === "number" && typeof b === "number") return (a !== a && b !== b) || Math.abs(a - b) < 1e-9;
  if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a), kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  return ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && eqM(a[k], b[k]));
}
async function jalanSandaran(code, fnName, cases) {
  let fn;
  try {
    fn = new Function('"use strict";' + code + "\nreturn typeof " + fnName + ' === "function" ? ' + fnName + " : undefined;")();
  } catch (err) {
    return { fatal: "Kod tak boleh dibaca — " + (err && err.message ? err.message : String(err)) };
  }
  if (typeof fn !== "function") return { fatal: `Fungsi ${fnName} tidak dijumpai. Semak ejaan nama.` };
  const out = [];
  for (const c of cases) {
    let nilai, err = null;
    try { nilai = await Promise.resolve(fn.apply(null, c.args.map(hidupM))); }
    catch (ex) { err = ex && ex.message ? ex.message : String(ex); }
    let lulus, papar;
    if (c.baling) {
      lulus = err !== null && (c.baling === true || String(err).toLowerCase().includes(String(c.baling).toLowerCase()));
      papar = err === null ? "tiada ralat dibaling — dapat " + fmtM(nilai) : "ralat: " + err;
    } else {
      lulus = err === null && eqM(nilai, c.expected);
      papar = err === null ? fmtM(nilai) : "RALAT: " + err;
    }
    out.push({ lulus, papar });
  }
  return { results: out };
}

let urlWorker = null;
function jalanUjian(code, fnName, cases, ms = 4000) {
  return new Promise((resolve) => {
    let w;
    try {
      if (!urlWorker) urlWorker = URL.createObjectURL(new Blob([WORKER_SRC], { type: "text/javascript" }));
      w = new Worker(urlWorker);
    } catch (e) {
      jalanSandaran(code, fnName, cases).then(resolve);
      return;
    }
    const t = setTimeout(() => {
      try { w.terminate(); } catch (e) {}
      resolve({ fatal: "Masa tamat selepas 4 saat — kemungkinan besar ada gelung yang tak berhenti." });
    }, ms);
    w.onmessage = (ev) => { clearTimeout(t); try { w.terminate(); } catch (e) {} resolve(ev.data); };
    w.onerror = (ev) => { clearTimeout(t); try { w.terminate(); } catch (e) {} resolve({ fatal: "Ralat enjin: " + (ev.message || "tidak diketahui") }); };
    w.postMessage({ code, fn: fnName, cases });
  });
}

/* ---------- Simpanan ---------- */
const KUNCI = "tangga:progres:v1";
const KOSONG = { siap: {}, xp: 0, sekarang: 1, hariAkhir: null, rentetan: 0 };

/* ============================================================
   UI
   ============================================================ */
const CSS = `
:root{
  --dasar:#101E33; --panel:#0B1626; --panel2:#152742;
  --garis:#22406B; --garis2:#1A3155;
  --dakwat:#DDE7F7; --senyap:#7B95BC;
  --oker:#F0B429; --bata:#E4695B; --hijau:#7FBF8F;
}
*{box-sizing:border-box}
.tg{
  min-height:100vh;background:var(--dasar);color:var(--dakwat);
  font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
  background-image:linear-gradient(var(--garis2) 1px,transparent 1px),linear-gradient(90deg,var(--garis2) 1px,transparent 1px);
  background-size:28px 28px;background-position:-1px -1px;
}
.mono{font-family:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace}
.kandungan{max-width:760px;margin:0 auto;padding:0 14px 96px}
.tajukbar{
  position:sticky;top:0;z-index:20;background:rgba(11,22,38,.94);
  backdrop-filter:blur(6px);border-bottom:1px solid var(--garis);
  padding:10px 14px;display:flex;align-items:center;gap:12px;
}
.jenama{font-family:ui-monospace,monospace;font-size:13px;letter-spacing:.34em;font-weight:700;color:var(--oker)}
.tolak{margin-left:auto;display:flex;gap:14px;font-family:ui-monospace,monospace;font-size:11px;color:var(--senyap)}
.tolak b{color:var(--dakwat);font-weight:600}

.blok{border:1px solid var(--garis);background:var(--panel);margin-top:14px}
.blokkepala{
  display:flex;align-items:stretch;border-bottom:1px solid var(--garis);
}
.nomborlevel{
  font-family:ui-monospace,monospace;font-size:26px;font-weight:700;color:var(--oker);
  padding:12px 14px;border-right:1px solid var(--garis);min-width:96px;
  display:flex;align-items:center;justify-content:center;letter-spacing:-.02em;
}
.kepalateks{padding:9px 13px;display:flex;flex-direction:column;justify-content:center;gap:3px;min-width:0}
.eyebrow{font-family:ui-monospace,monospace;font-size:10px;letter-spacing:.16em;color:var(--senyap);text-transform:uppercase}
.tajuk{font-size:16px;font-weight:600;line-height:1.25}
.badan{padding:14px 13px}
.brief{font-size:14.5px;line-height:1.62;white-space:pre-wrap;color:#C9D8EE}
.brief code{font-family:ui-monospace,monospace;background:var(--panel2);border:1px solid var(--garis2);padding:1px 5px;font-size:13px;color:var(--oker)}

textarea.editor{
  width:100%;background:#08111E;color:#E6EEFB;border:1px solid var(--garis);
  font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13.5px;line-height:1.62;
  padding:11px;min-height:210px;resize:vertical;outline:none;tab-size:2;
}
textarea.editor:focus{border-color:var(--oker)}
input.jawab{
  width:100%;background:#08111E;color:#E6EEFB;border:1px solid var(--garis);
  font-family:ui-monospace,monospace;font-size:15px;padding:12px;outline:none;
}
input.jawab:focus{border-color:var(--oker)}

.simbolbar{display:flex;gap:4px;overflow-x:auto;padding:7px 0 0;-webkit-overflow-scrolling:touch}
.simbolbar button{
  flex:0 0 auto;min-width:34px;height:32px;background:var(--panel2);color:var(--dakwat);
  border:1px solid var(--garis);font-family:ui-monospace,monospace;font-size:14px;cursor:pointer;
}
.simbolbar button:active{background:var(--oker);color:#0B1626}

.butang{
  font-family:ui-monospace,monospace;font-size:12px;letter-spacing:.09em;text-transform:uppercase;
  padding:12px 16px;border:1px solid var(--garis);background:var(--panel2);color:var(--dakwat);
  cursor:pointer;font-weight:600;
}
.butang:hover{border-color:var(--senyap)}
.butang.utama{background:var(--oker);border-color:var(--oker);color:#0B1626}
.butang.utama:disabled{opacity:.5;cursor:default}
.butang:focus-visible{outline:2px solid var(--oker);outline-offset:2px}
.baris{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}

.keputusan{border:1px solid var(--garis);margin-top:14px}
.keputusankepala{
  padding:9px 12px;font-family:ui-monospace,monospace;font-size:11.5px;letter-spacing:.12em;
  text-transform:uppercase;border-bottom:1px solid var(--garis);display:flex;gap:10px;align-items:center;
}
.lulus{color:var(--hijau)} .gagal{color:var(--bata)}
.kes{
  display:flex;gap:9px;padding:8px 12px;border-bottom:1px solid var(--garis2);
  font-family:ui-monospace,monospace;font-size:12px;align-items:flex-start;
}
.kes:last-child{border-bottom:none}
.tanda{flex:0 0 auto;width:15px;font-weight:700}
.kesteks{min-width:0;overflow-wrap:anywhere;color:#B9CBE4;line-height:1.55}
.kesteks .lbl{color:var(--senyap)}

.nota{
  border-left:2px solid var(--oker);background:rgba(240,180,41,.06);
  padding:10px 12px;margin-top:11px;font-size:13.5px;line-height:1.6;
}
.nota.merah{border-left-color:var(--bata);background:rgba(228,105,91,.07)}

pre.kod{
  background:#08111E;border:1px solid var(--garis);padding:12px;overflow-x:auto;
  font-family:ui-monospace,monospace;font-size:13px;line-height:1.65;color:#E6EEFB;margin:0;
}
.pilihanbtn{
  display:block;width:100%;text-align:left;padding:13px 14px;margin-top:8px;
  background:var(--panel2);border:1px solid var(--garis);color:var(--dakwat);
  font-size:14px;line-height:1.5;cursor:pointer;
}
.pilihanbtn:hover{border-color:var(--senyap)}
.pilihanbtn.betul{border-color:var(--hijau);background:rgba(127,191,143,.12)}
.pilihanbtn.salah{border-color:var(--bata);background:rgba(228,105,91,.12)}

/* Peta */
.babbaris{
  display:flex;align-items:center;gap:12px;padding:13px 12px;border:1px solid var(--garis);
  background:var(--panel);margin-top:9px;cursor:pointer;width:100%;text-align:left;color:inherit;
}
.babbaris:hover{border-color:var(--oker)}
.babno{font-family:ui-monospace,monospace;font-size:11px;color:var(--senyap);flex:0 0 30px}
.babisi{flex:1;min-width:0}
.babnama{font-size:14.5px;font-weight:600;margin-bottom:6px}
.dimensi{display:flex;align-items:center;gap:7px;font-family:ui-monospace,monospace;font-size:10.5px;color:var(--senyap)}
.rel{flex:1;height:3px;background:var(--garis2);position:relative}
.rel i{position:absolute;left:0;top:0;bottom:0;background:var(--oker);display:block}

.lompat{display:flex;gap:8px;margin-top:14px}
.lompat input{
  flex:1;background:#08111E;border:1px solid var(--garis);color:var(--dakwat);
  font-family:ui-monospace,monospace;font-size:14px;padding:11px;outline:none;
}
.kakibar{
  position:fixed;left:0;right:0;bottom:0;background:rgba(11,22,38,.96);
  border-top:1px solid var(--garis);padding:9px 14px;display:flex;gap:8px;justify-content:center;
  backdrop-filter:blur(6px);z-index:20;
}
@media (prefers-reduced-motion:no-preference){
  .blok{animation:naik .18s ease-out}
  @keyframes naik{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
}
`;


/* ============================================================
   Lapisan API untuk Android. Kotlin bercakap dengan enjin ini
   melalui AndroidJambatan.balas(id, jsonString).
   ============================================================ */
function __fmt(v) {
  if (v === undefined) return "undefined";
  if (v === null) return "null";
  if (typeof v === "string") return JSON.stringify(v);
  if (typeof v === "function") return "[fungsi]";
  try { return JSON.stringify(v); } catch (e) { return String(v); }
}

function __hujah(args) {
  try {
    const s = args.map(function (a) {
      if (typeof a === "function") return "fn";
      if (a && typeof a === "object" && typeof a.__ev === "string") return a.__ev.length > 26 ? "fn" : a.__ev;
      return JSON.stringify(a);
    }).join(", ");
    return "(" + (s.length > 90 ? s.slice(0, 90) + "\u2026" : s) + ")";
  } catch (e) { return "(\u2026)"; }
}

/* Runner tempatan. Global yang berbahaya dibayangi supaya kod pengguna
   tidak boleh mencapai jambatan Android atau rangkaian. */
async function __jalan(kod, fnName, kes) {
  let fn;
  try {
    fn = new Function(
      "AndroidJambatan", "TanggaEnjin", "window", "document", "fetch",
      "XMLHttpRequest", "WebSocket", "localStorage", "indexedDB", "importScripts",
      '"use strict";' + kod + "\nreturn typeof " + fnName + ' === "function" ? ' + fnName + " : undefined;"
    )();
  } catch (err) {
    return { fatal: "Kod tak boleh dibaca \u2014 " + (err && err.message ? err.message : String(err)) };
  }
  if (typeof fn !== "function") {
    return { fatal: "Fungsi " + fnName + " tidak dijumpai. Semak ejaan nama." };
  }
  const keluar = [];
  for (const c of kes) {
    let nilai, err = null;
    try { nilai = await Promise.resolve(fn.apply(null, c.args.map(hidupM))); }
    catch (ex) { err = ex && ex.message ? ex.message : String(ex); }
    let lulus, papar;
    if (c.baling) {
      lulus = err !== null && (c.baling === true || String(err).toLowerCase().indexOf(String(c.baling).toLowerCase()) >= 0);
      papar = err === null ? "tiada ralat dibaling \u2014 dapat " + __fmt(nilai) : "ralat: " + err;
    } else {
      lulus = err === null && eqM(nilai, c.expected);
      papar = err === null ? __fmt(nilai) : "RALAT: " + err;
    }
    keluar.push({ lulus: lulus, papar: papar });
  }
  return { results: keluar };
}

const TanggaEnjin = {
  jumlah: function () { return JUMLAH; },

  bab: function () {
    return JSON.stringify(BAB.map(function (b) {
      return { n: b.n, nama: b.nama, dari: b.dari, hingga: b.hingga };
    }));
  },

  level: function (n) {
    const L = levelKe(n), t = L.tugas, p = L.p;
    const asas = {
      n: n, bab: L.bab.n, namaBab: L.bab.nama, jenis: t.jenis,
      tajuk: val(t.tajuk, p), brief: val(t.brief, p),
      petunjuk: val(t.hints, p) || []
    };
    if (t.jenis === "ramal") {
      asas.kod = val(t.kod, p);
      return JSON.stringify(asas);
    }
    if (t.jenis === "pilih") {
      asas.soalan = val(t.soalan, p);
      asas.pilihan = val(t.pilihan, p);
      asas.betul = val(t.betul, p);
      asas.huraian = val(t.huraian, p);
      return JSON.stringify(asas);
    }
    asas.fn = val(t.fn, p);
    asas.starter = val(t.starter, p);
    asas.jawapan = val(t.jawapan, p) || "";
    asas.kes = val(t.cases, p).map(function (c) {
      return {
        hujah: __hujah(c.args),
        jangka: c.baling ? ("baling \"" + (c.baling === true ? "apa-apa" : c.baling) + "\"") : __fmt(c.expected)
      };
    });
    return JSON.stringify(asas);
  },

  semakRamal: function (n, teks) {
    const L = levelKe(n);
    const jangka = String(val(L.tugas.output, L.p)).trim();
    return JSON.stringify({
      lulus: String(teks).trim().toLowerCase() === jangka.toLowerCase(),
      jangka: jangka
    });
  },

  /* Async: hasil dihantar balik melalui jambatan, bukan dipulangkan. */
  jalan: function (n, kod, id) {
    try {
      const L = levelKe(n), t = L.tugas, p = L.p;
      const syarat = t.syarat ? val(t.syarat, p) : [];
      const gagal = syarat.find(function (s) { return !s.ujian(kod); });
      if (gagal) {
        AndroidJambatan.balas(id, JSON.stringify({ fatal: gagal.mesej }));
        return;
      }
      __jalan(kod, val(t.fn, p), val(t.cases, p)).then(function (hasil) {
        AndroidJambatan.balas(id, JSON.stringify(hasil));
      }, function (e) {
        AndroidJambatan.balas(id, JSON.stringify({ fatal: String(e && e.message || e) }));
      });
    } catch (e) {
      AndroidJambatan.balas(id, JSON.stringify({ fatal: String(e && e.message || e) }));
    }
  }
};

window.TanggaEnjin = TanggaEnjin;
