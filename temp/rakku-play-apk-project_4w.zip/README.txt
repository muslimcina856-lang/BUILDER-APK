Rakku Play Android WebView Project

Ini ZIP project Android, bukan ZIP website.

Cara pakai:
1. Upload ZIP ini ke bot/build app Telegram yang menerima Android Studio/Gradle project.
2. Build APK.
3. Install APK.

URL web yang dibuka app:
https://rakkumusic.vercel.app

Kalau URL Vercel kamu beda, edit:
app/src/main/res/values/strings.xml

Ganti app_url menjadi URL web Rakku Play kamu.

Fitur:
- WebView full screen
- JavaScript aktif
- Download audio lewat DownloadManager Android
- Share tetap memakai URL YouTube dari web
- App tidak menyisipkan iklan
- Audio tidak dipause otomatis saat keluar dari full player/app, selama Android/WebView masih mengizinkan proses berjalan

Catatan:
Background audio di WebView bergantung aturan Android dan WebView. Jika Android membatasi aplikasi di background atau WebView menghentikan media, audio bisa berhenti. Untuk background audio sekuat Spotify butuh native audio service, bukan WebView biasa.
