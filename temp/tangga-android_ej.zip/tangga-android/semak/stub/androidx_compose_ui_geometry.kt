@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.geometry


class Offset(val x: Float, val y: Float) {
    companion object { val Zero = Offset(0f, 0f) }
}

class Size(val width: Float, val height: Float)

// ---------------------------------------------------------------------
