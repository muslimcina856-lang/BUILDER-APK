@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.graphics

import androidx.compose.ui.geometry.Offset


class Color(val nilai: Long) {
    fun copy(alpha: Float = 1f): Color = this
    companion object
}


interface Shape
val RectangleShape: Shape = object : Shape {}

interface Brush {
    // Dalam Compose sebenar ini ialah ahli companion, bukan sambungan
    // peringkat atas. Ahli TIDAK boleh diimport, jadi memodelkannya dengan
    // betul di sini menghalang `import ...graphics.linearGradient` daripada
    // lulus semakan tetapi gagal binaan sebenar.
    companion object {
        fun linearGradient(
            colors: List<Color>,
            start: androidx.compose.ui.geometry.Offset = androidx.compose.ui.geometry.Offset.Zero,
            end: androidx.compose.ui.geometry.Offset = androidx.compose.ui.geometry.Offset.Zero,
        ): Brush = object : Brush {}

        fun radialGradient(
            colors: List<Color>,
            center: androidx.compose.ui.geometry.Offset = androidx.compose.ui.geometry.Offset.Zero,
            radius: Float = 0f,
        ): Brush = object : Brush {}

        fun verticalGradient(colors: List<Color>): Brush = object : Brush {}

        fun horizontalGradient(colors: List<Color>): Brush = object : Brush {}
    }
}

class SolidColor(warna: Color) : Brush

// ---------------------------------------------------------------------







fun androidx.compose.ui.Modifier.graphicsLayer(
    scaleX: Float = 1f,
    scaleY: Float = 1f,
    alpha: Float = 1f,
    translationX: Float = 0f,
    translationY: Float = 0f,
    rotationZ: Float = 0f,
): androidx.compose.ui.Modifier = this

// ---------------------------------------------------------------------
