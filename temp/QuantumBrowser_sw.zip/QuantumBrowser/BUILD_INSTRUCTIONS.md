# Arahan Build: Quantum Browser (2026)

Projek ini telah siap dibina dengan semua kod sumber yang diperlukan untuk ciri **Multi-Profile Storan Terasing**.

## Lokasi Projek:
`/storage/emulated/0/WORKSPACE/QuantumBrowser/`

## Cara Build & Install:
Kerana persekitaran Termux tidak mempunyai SDK Android lengkap secara default, anda boleh lakukan salah satu daripada ini:

1. **Gunakan AIDE atau Sketchware Pro:**
   - Buka aplikasi AIDE/Sketchware di Android.
   - Import folder `QuantumBrowser` ini.
   - Tekan "Run" atau "Build".

2. **Gunakan Android Studio (PC):**
   - Salin folder ini ke PC.
   - Buka dalam Android Studio.
   - Tekan Build -> Build Bundle(s) / APK(s) -> Build APK(s).

3. **Gunakan CLI (Jika SDK terpasang):**
   ```bash
   cd /storage/emulated/0/WORKSPACE/QuantumBrowser
   gradle assembleDebug
   ```

## Ciri yang Disiapkan:
- **ProfileStore API:** Pengasingan kuki dan cache antara profil.
- **WebView 2026:** Support WebGPU dan WebNN.
- **UI Profil:** Butang "Profiles" untuk tukar akaun sepantas kilat.
- **Icon:** Ikon minimalis profesional sudah dimasukkan.

Fail utama:
- `app/src/main/java/com/quantum/browser/MainActivity.kt` (Logik Profil)
- `app/src/main/res/layout/activity_main.xml` (Antaramuka)
