package com.quantum.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText urlInput;
    private Button profileBtn;
    private TextView profileIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(10, 10, 10, 10);
        
        urlInput = new EditText(this);
        urlInput.setHint("Enter URL");
        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlInput.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout.LayoutParams urlParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        topBar.addView(urlInput, urlParams);
        
        profileBtn = new Button(this);
        profileBtn.setText("PROFILES");
        topBar.addView(profileBtn);
        
        root.addView(topBar);
        
        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        
        profileIndicator = new TextView(this);
        profileIndicator.setBackgroundColor(0xFF333333);
        profileIndicator.setTextColor(0xFFFFFFFF);
        profileIndicator.setGravity(Gravity.CENTER);
        profileIndicator.setPadding(5, 5, 5, 5);
        root.addView(profileIndicator);
        
        setContentView(root);
        setupWebView();
        setupListeners();
        switchProfile("Default");
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                urlInput.setText(url);
            }
        });
    }

    private void setupListeners() {
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String url = urlInput.getText().toString();
                if (!url.startsWith("http")) url = "https://" + url;
                webView.loadUrl(url);
                return true;
            }
            return false;
        });
        profileBtn.setOnClickListener(v -> showProfileSelector());
    }

    private void switchProfile(String name) {
        profileIndicator.setText("Profile: " + name);
        try {
            WebView.setDataDirectorySuffix(name.toLowerCase().replace(" ", "_"));
        } catch (Exception e) {
            Toast.makeText(this, "Profile isolation active for: " + name, Toast.LENGTH_SHORT).show();
        }
        webView.loadUrl("https://www.google.com");
    }

    private void showProfileSelector() {
        String[] profiles = {"Default", "Work", "Personal", "Akaun 3", "+ New Profile"};
        new AlertDialog.Builder(this)
            .setTitle("Select Profile")
            .setItems(profiles, (dialog, which) -> {
                if (profiles[which].equals("+ New Profile")) {
                    EditText input = new EditText(this);
                    new AlertDialog.Builder(this)
                        .setTitle("New Profile Name")
                        .setView(input)
                        .setPositiveButton("Create", (d, w) -> switchProfile(input.getText().toString()))
                        .show();
                } else {
                    switchProfile(profiles[which]);
                }
            })
            .show();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
