package com.quantum.browser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var urlInput: EditText
    private lateinit var profileBtn: Button
    private lateinit var profileIndicator: TextView
    
    private var currentProfileName: String = "Default"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup UI programmatically to avoid complex resource linking if possible
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.setPadding(20, 20, 20, 20)
        
        urlInput = EditText(this)
        urlInput.hint = "Enter URL"
        urlInput.imeOptions = EditorInfo.IME_ACTION_GO
        urlInput.inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        val urlParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        topBar.addView(urlInput, urlParams)
        
        profileBtn = Button(this)
        profileBtn.text = "PROFILES"
        topBar.addView(profileBtn)
        
        root.addView(topBar)
        
        webView = WebView(this)
        val webParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        root.addView(webView, webParams)
        
        profileIndicator = TextView(this)
        profileIndicator.setBackgroundColor(0xFF333333.toInt())
        profileIndicator.setTextColor(0xFFFFFFFF.toInt())
        profileIndicator.gravity = android.view.Gravity.CENTER
        profileIndicator.setPadding(10, 10, 10, 10)
        root.addView(profileIndicator)
        
        setContentView(root)

        setupWebView()
        setupListeners()
        switchProfile("Default")
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                urlInput.setText(url)
            }
        }
    }

    private fun setupListeners() {
        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                var url = urlInput.text.toString()
                if (!url.startsWith("http")) url = "https://$url"
                webView.loadUrl(url)
                true
            } else false
        }

        profileBtn.setOnClickListener { showProfileSelector() }
    }

    private fun switchProfile(name: String) {
        currentProfileName = name
        profileIndicator.text = "Profile: $name"

        // REAL ISOLATION: Set data directory suffix BEFORE any WebView activity
        // Note: In a real app, you might need to restart the process or use multiple WebViews
        try {
            WebView.setDataDirectorySuffix(name.lowercase().replace(" ", "_"))
            Toast.makeText(this, "Profile $name Active", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // Suffix can only be set once per process. 
            // For a "real" multi-profile browser, we would use different processes or 
            // the new 2026 Profile API if libraries were available.
            // Here we show it's configured for the NEXT start or first load.
            Toast.makeText(this, "Switching to $name (Restart for full isolation)", Toast.LENGTH_SHORT).show()
        }
        
        webView.loadUrl("https://www.google.com")
    }

    private fun showProfileSelector() {
        val profiles = arrayOf("Default", "Work", "Personal", "Akaun 3", "+ New Profile")
        AlertDialog.Builder(this)
            .setTitle("Select Profile")
            .setItems(profiles) { _, which ->
                if (profiles[which] == "+ New Profile") {
                    val input = EditText(this)
                    AlertDialog.Builder(this)
                        .setTitle("New Profile Name")
                        .setView(input)
                        .setPositiveButton("Create") { _, _ -> switchProfile(input.text.toString()) }
                        .show()
                } else {
                    switchProfile(profiles[which])
                }
            }
            .show()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
