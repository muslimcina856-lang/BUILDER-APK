package com.tweakx.android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Draws a crosshair entirely via Canvas primitives — no bitmap/image asset
 * involved, so there's nothing here that could be a copyrighted or
 * trademarked graphic. Three styles are supported; each is a simple
 * geometric composition.
 */
class CrosshairView(
    context: Context,
    private val color: Int,
    private val style: String
) : View(context) {

    private val paint = Paint().apply {
        this.color = this@CrosshairView.color
        strokeWidth = 4f
        isAntiAlias = true
        style = Paint.Style.STROKE
    }

    private val dotPaint = Paint().apply {
        this.color = this@CrosshairView.color
        isAntiAlias = true
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val armLength = minOf(w, h) * 0.35f
        val gap = minOf(w, h) * 0.08f

        when (style) {
            "dot" -> {
                canvas.drawCircle(cx, cy, minOf(w, h) * 0.06f, dotPaint)
            }
            "circle-cross" -> {
                paint.strokeWidth = minOf(w, h) * 0.03f
                canvas.drawCircle(cx, cy, minOf(w, h) * 0.32f, paint)
                drawCrossLines(canvas, cx, cy, armLength, gap)
            }
            else -> { // "cross" default
                drawCrossLines(canvas, cx, cy, armLength, gap)
            }
        }
    }

    private fun drawCrossLines(canvas: Canvas, cx: Float, cy: Float, armLength: Float, gap: Float) {
        paint.strokeWidth = 5f
        // Top
        canvas.drawLine(cx, cy - gap - armLength, cx, cy - gap, paint)
        // Bottom
        canvas.drawLine(cx, cy + gap, cx, cy + gap + armLength, paint)
        // Left
        canvas.drawLine(cx - gap - armLength, cy, cx - gap, cy, paint)
        // Right
        canvas.drawLine(cx + gap, cy, cx + gap + armLength, cy, paint)
    }

    companion object {
        fun parseColorSafe(hex: String, fallback: Int = Color.GREEN): Int {
            return try {
                Color.parseColor(hex)
            } catch (t: Throwable) {
                fallback
            }
        }
    }
}
