package com.tweakx.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.EventChannel
import rikka.shizuku.Shizuku

/**
 * Thin router: registers MethodChannel/EventChannel and forwards calls to
 * ShizukuManager / TweakBridge. No business logic lives here (see spec #15).
 */
class MainActivity : FlutterActivity() {

    private val shizukuChannelName = "com.tweakx.android/shizuku"
    private val tweakChannelName = "com.tweakx.android/tweak"
    private val deviceChannelName = "com.tweakx.android/device"
    private val shizukuEventChannelName = "com.tweakx.android/shizuku_events"
    private val appsChannelName = "com.tweakx.android/apps"
    private val gameChannelName = "com.tweakx.android/game"
    private val gameEventChannelName = "com.tweakx.android/game_events"
    private val overlayChannelName = "com.tweakx.android/overlay"

    private lateinit var tweakBridge: TweakBridge
    private lateinit var gameBridge: GameBridge
    private lateinit var appListManager: AppListManager
    private lateinit var gameMonitor: GameMonitor
    private var eventSink: EventChannel.EventSink? = null
    private var gameEventSink: EventChannel.EventSink? = null

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread {
                    eventSink?.success(ShizukuManager.getStatusMap())
                }
            }
        }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread { eventSink?.success(ShizukuManager.getStatusMap()) }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        tweakBridge = TweakBridge(getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
        gameBridge = GameBridge()
        appListManager = AppListManager(applicationContext)
        gameMonitor = GameMonitor(gameBridge)

        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuChannelName)
            .setMethodCallHandler { call, result -> handleShizukuCall(call, result) }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, tweakChannelName)
            .setMethodCallHandler { call, result -> handleTweakCall(call, result) }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result -> handleDeviceCall(call, result) }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, appsChannelName)
            .setMethodCallHandler { call, result -> handleAppsCall(call, result) }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, gameChannelName)
            .setMethodCallHandler { call, result -> handleGameCall(call, result) }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, overlayChannelName)
            .setMethodCallHandler { call, result -> handleOverlayCall(call, result) }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, shizukuEventChannelName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    eventSink = sink
                    sink?.success(ShizukuManager.getStatusMap())
                }

                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            })

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, gameEventChannelName)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    gameEventSink = sink
                }

                override fun onCancel(arguments: Any?) {
                    gameEventSink = null
                }
            })
    }

    private fun handleAppsCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getLaunchableApps" -> {
                    val apps = appListManager.getLaunchableApps().map {
                        mapOf(
                            "packageName" to it.packageName,
                            "label" to it.label,
                            "iconBase64" to (it.iconBase64 ?: "")
                        )
                    }
                    result.success(apps)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("APPS_ERROR", e.message ?: "Unknown apps error", null)
        }
    }

    private fun handleGameCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getResolution" -> result.success(gameBridge.getResolution())
                "setResolution" -> {
                    val width = call.argument<Int>("width")
                        ?: return result.error("INVALID_ARGS", "Missing 'width'", null)
                    val height = call.argument<Int>("height")
                        ?: return result.error("INVALID_ARGS", "Missing 'height'", null)
                    result.success(gameBridge.setResolution(width, height))
                }
                "resetResolution" -> result.success(gameBridge.resetResolution())
                "setDpi" -> {
                    val dpi = call.argument<Int>("dpi")
                        ?: return result.error("INVALID_ARGS", "Missing 'dpi'", null)
                    result.success(gameBridge.setDpi(dpi))
                }
                "resetDpi" -> result.success(gameBridge.resetDpi())
                "getPeakRefreshRate" -> result.success(gameBridge.getPeakRefreshRate())
                "setPeakRefreshRate" -> {
                    val hz = call.argument<Int>("hz")
                        ?: return result.error("INVALID_ARGS", "Missing 'hz'", null)
                    result.success(gameBridge.setPeakRefreshRate(hz))
                }
                "resetPeakRefreshRate" -> result.success(gameBridge.resetPeakRefreshRate())
                "getThermalStatus" -> result.success(gameBridge.getThermalStatus())
                "getTouchInfo" -> result.success(gameBridge.getTouchInfo())
                "getBrightness" -> result.success(tweakBridge.getBrightness())
                "setBrightness" -> {
                    val value = call.argument<Int>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setBrightness(value))
                }
                "getAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    result.success(tweakBridge.getAnimationScale(setting))
                }
                "setAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    val value = call.argument<Double>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setAnimationScale(setting, value))
                }
                "launchApp" -> {
                    val packageName = call.argument<String>("packageName")
                        ?: return result.error("INVALID_ARGS", "Missing 'packageName'", null)
                    result.success(gameBridge.launchApp(packageName))
                }
                "startMonitoring" -> {
                    val packageName = call.argument<String>("packageName")
                        ?: return result.error("INVALID_ARGS", "Missing 'packageName'", null)
                    gameMonitor.start(packageName) {
                        runOnUiThread {
                            gameEventSink?.success(
                                mapOf("event" to "gameClosed", "packageName" to packageName)
                            )
                        }
                    }
                    result.success(null)
                }
                "stopMonitoring" -> {
                    gameMonitor.stop()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("GAME_ERROR", e.message ?: "Unknown game error", null)
        }
    }

    private fun handleShizukuCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "isAvailable" -> result.success(ShizukuManager.isAvailable())
                "isPermissionGranted" -> result.success(ShizukuManager.isPermissionGranted())
                "requestPermission" -> {
                    ShizukuManager.requestPermission()
                    result.success(null)
                }
                "getStatus" -> result.success(ShizukuManager.getStatusMap())
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("SHIZUKU_ERROR", e.message ?: "Unknown Shizuku error", null)
        }
    }

    private fun handleTweakCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getBrightness" -> result.success(tweakBridge.getBrightness())
                "setBrightness" -> {
                    val value = call.argument<Int>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setBrightness(value))
                }
                "getScreenTimeout" -> result.success(tweakBridge.getScreenTimeout())
                "setScreenTimeout" -> {
                    val value = call.argument<Int>("valueMs")
                        ?: return result.error("INVALID_ARGS", "Missing 'valueMs'", null)
                    result.success(tweakBridge.setScreenTimeout(value))
                }
                "getAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    result.success(tweakBridge.getAnimationScale(setting))
                }
                "setAnimationScale" -> {
                    val setting = call.argument<String>("setting")
                        ?: return result.error("INVALID_ARGS", "Missing 'setting'", null)
                    val value = call.argument<Double>("value")
                        ?: return result.error("INVALID_ARGS", "Missing 'value'", null)
                    result.success(tweakBridge.setAnimationScale(setting, value))
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("TWEAK_ERROR", e.message ?: "Unknown tweak error", null)
        }
    }

    private fun handleDeviceCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getInfo" -> result.success(tweakBridge.getDeviceInfo())
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("DEVICE_ERROR", e.message ?: "Unknown device error", null)
        }
    }

    private fun handleOverlayCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "canDrawOverlays" -> {
                    result.success(Settings.canDrawOverlays(this))
                }
                "requestOverlayPermission" -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    result.success(null)
                }
                "showCrosshair" -> {
                    if (!Settings.canDrawOverlays(this)) {
                        return result.error(
                            "OVERLAY_PERMISSION_DENIED",
                            "Display over other apps permission is not granted",
                            null
                        )
                    }
                    val colorHex = call.argument<String>("color") ?: "#00E676"
                    val size = call.argument<Int>("size") ?: 48
                    val style = call.argument<String>("style") ?: "cross"
                    val intent = Intent(this, OverlayService::class.java).apply {
                        action = OverlayService.ACTION_SHOW
                        putExtra(OverlayService.EXTRA_COLOR, CrosshairView.parseColorSafe(colorHex))
                        putExtra(OverlayService.EXTRA_SIZE, size)
                        putExtra(OverlayService.EXTRA_STYLE, style)
                    }
                    startService(intent)
                    result.success(null)
                }
                "hideCrosshair" -> {
                    val intent = Intent(this, OverlayService::class.java).apply {
                        action = OverlayService.ACTION_HIDE
                    }
                    startService(intent)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("OVERLAY_ERROR", e.message ?: "Unknown overlay error", null)
        }
    }

    override fun onResume() {
        super.onResume()
        eventSink?.success(ShizukuManager.getStatusMap())
    }

    override fun onDestroy() {
        gameMonitor.stop()
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        super.onDestroy()
    }
}
