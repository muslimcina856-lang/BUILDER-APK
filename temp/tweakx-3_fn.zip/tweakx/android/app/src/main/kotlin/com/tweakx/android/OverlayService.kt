package com.tweakx.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat

/**
 * Renders a real floating crosshair overlay + a small floating control
 * button on top of whatever app is in the foreground, using
 * WindowManager.addView with TYPE_APPLICATION_OVERLAY.
 *
 * REQUIRES: Settings.canDrawOverlays(context) == true, i.e. the user has
 * granted "Display over other apps" for TweakX. This is a normal Android
 * permission granted manually in system Settings — it has nothing to do
 * with Shizuku, and TweakX cannot grant it on the user's behalf. If the
 * permission isn't granted, startService intentionally does nothing
 * (checked from the Flutter side before starting) rather than silently
 * failing or crashing.
 *
 * The crosshair itself is drawn as a simple vector-style shape (two
 * perpendicular lines + a center gap) built entirely in code — no bundled
 * image asset, so there's no placeholder/copyright concern. Style/color
 * are configurable from Flutter via Intent extras.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.tweakx.android.action.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.tweakx.android.action.HIDE_OVERLAY"
        const val EXTRA_COLOR = "color"
        const val EXTRA_SIZE = "size"
        const val EXTRA_STYLE = "style" // "cross", "dot", "circle-cross"
        const val NOTIFICATION_CHANNEL_ID = "tweakx_overlay"
        const val NOTIFICATION_ID = 4201
    }

    private var windowManager: WindowManager? = null
    private var crosshairView: View? = null
    private var controlView: View? = null
    private var crosshairVisible = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> {
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundWithNotification()
                val color = intent.getIntExtra(EXTRA_COLOR, Color.GREEN)
                val size = intent.getIntExtra(EXTRA_SIZE, 48)
                val style = intent.getStringExtra(EXTRA_STYLE) ?: "cross"
                showOverlay(color, size, style)
            }
            ACTION_HIDE -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "TweakX Overlay",
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("TweakX crosshair active")
            .setContentText("Tap the floating control to hide it")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showOverlay(color: Int, sizeDp: Int, style: String) {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // --- Crosshair view: centered, non-interactive (click-through) ---
        val density = resources.displayMetrics.density
        val sizePx = (sizeDp * density).toInt()

        val crosshair = CrosshairView(this, color, style).apply {
            layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)
        }
        val crosshairParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        windowManager?.addView(crosshair, crosshairParams)
        crosshairView = crosshair

        // --- Floating control: small draggable button to toggle crosshair
        //     visibility without leaving the game. This one IS touchable. ---
        val controlSizePx = (36 * density).toInt()
        val control = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setBackgroundColor(Color.parseColor("#CC121212"))
            setPadding(controlSizePx / 5, controlSizePx / 5, controlSizePx / 5, controlSizePx / 5)
            alpha = 0.85f
        }
        val controlParams = WindowManager.LayoutParams(
            controlSizePx,
            controlSizePx,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }

        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDrag = false

        control.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = controlParams.x
                    initialY = controlParams.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) isDrag = true
                    controlParams.x = initialX + dx
                    controlParams.y = initialY + dy
                    windowManager?.updateViewLayout(control, controlParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDrag) {
                        crosshairVisible = !crosshairVisible
                        crosshairView?.visibility =
                            if (crosshairVisible) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(control, controlParams)
        controlView = control
    }

    private fun removeOverlay() {
        try {
            crosshairView?.let { windowManager?.removeView(it) }
            controlView?.let { windowManager?.removeView(it) }
        } catch (t: Throwable) {
            // Views may already be detached; ignore.
        } finally {
            crosshairView = null
            controlView = null
        }
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}
