# TweakX

Android per-game tweak profiles powered by [Shizuku](https://shizuku.rikka.app/) — no root required.

TweakX lets you manually add installed games, then configure each one
through three dedicated screens — **Display**, **Performance**, and
**Aim** — each with its own Save / Save & Launch flow. Save & Launch
applies the configured settings via Shizuku and immediately opens the game.
Resolution and DPI automatically revert to system defaults once the game
closes.

---

## Features

### Implemented and wired end-to-end

| Feature | Status | Notes |
|---|---|---|
| Shizuku availability detection | ✅ Real | `Shizuku.pingBinder()` via native `ShizukuManager` |
| Shizuku permission check/request | ✅ Real | `Shizuku.checkSelfPermission()` / `Shizuku.requestPermission()` |
| Real-time status updates | ✅ Real | Native `EventChannel` driven by Shizuku's own binder/permission listeners (no polling) |
| Command execution via Shizuku | ✅ Real | `Shizuku.newProcess` (reflection, see caveat below) through an allowlist |
| Installed app / game picker | ✅ Real | `PackageManager.queryIntentActivities` — lists every launchable app on the device, with real icons |
| Manually-added game list | ✅ Real | Games are added one at a time via "Add Game"; nothing appears automatically. Persisted locally with `shared_preferences`, survives app restart |
| Per-game Resolution | ✅ Real | `wm size <W>x<H>` / `wm size reset` |
| Per-game DPI | ✅ Real | `wm density <dpi>` / `wm density reset` |
| Per-game Refresh Rate / FPS | ✅ Real | `settings put system peak_refresh_rate` (Android 11+), 5 fixed values |
| Per-game Brightness | ✅ Real | `settings put system screen_brightness`, 0–255 |
| Per-game Animation Scale | ✅ Real | Same as global tweak, applied per-game before launch |
| Thermal status | ✅ Real (read-only) | `dumpsys thermalservice`, parsed into a human label. No universal cross-OEM "set" API exists via Shizuku — TweakX does not pretend otherwise |
| Touch input info | ✅ Real (read-only) | `dumpsys input`. Same honesty caveat as thermal — no universal setter exists |
| Save & Launch | ✅ Real | Applies every configured setting via Shizuku, then launches the game with `monkey -p <pkg> -c android.intent.category.LAUNCHER 1` |
| Auto-revert on game close | ✅ Real, with disclosed limitation | Polls foreground app via `dumpsys activity activities` through Shizuku every 3s (see caveat below); resets resolution/DPI to system defaults when the game is no longer foreground |
| Category-based per-game settings | ✅ Real | Each game's settings are split into their own screens — Display, Performance, Aim — each with its own Save / Save & Launch, instead of one long page |
| Custom Resolution input | ✅ Real | Manual width/height text fields in addition to presets, validated to the same `480–7680` range as the native allowlist |
| Custom DPI input | ✅ Real | Manual DPI text field in addition to presets, validated to the same `120–640` range as the native allowlist |
| Crosshair overlay | ✅ Real | A genuine floating `WindowManager` overlay (`OverlayService.kt`) drawn with Canvas (cross / dot / circle-cross styles, configurable color and size) — not a mock or a static image over the UI |
| Floating control button | ✅ Real | A draggable overlay button that toggles crosshair visibility instantly, rendered alongside the crosshair by the same service |
| Device information | ✅ Real | `Build.*` and `DisplayMetrics`, no Shizuku needed (public Android APIs) |
| Error surfacing | ✅ Real | Native errors (`SecurityException`, `RemoteException`, disconnects, permission denial) are passed to Flutter and translated into human-readable messages |
| Command allowlist / input validation | ✅ Real | Every tweak value is validated in Kotlin (`CommandAllowlist.kt`) before it ever reaches the shell — there is no free-form command execution exposed to the UI |
| Unit tests | ✅ Real | `ShizukuStatus`/`CommandResult`/`GameProfile` model logic (including crosshair fields), `TweakService`/`ShizukuService` against a mocked `MethodChannel` |
| GitHub Actions build | ✅ Real | Runs `flutter analyze`, `flutter test`, `flutter build apk --release`, uploads the APK as a workflow artifact |
| New app icon | ✅ Real | Custom "TX" monogram generated as a real PNG at every mipmap density, not a placeholder |

### Explicitly not implemented (by request)

**Touch sensitivity / sampling-rate booster** was scoped out during planning.
There is no standard Android API to raise touch sampling rate from
software — it's a hardware/firmware property, occasionally exposed through
vendor-specific sysfs paths (e.g. certain gaming phones' Game Mode) that
are not consistent across devices. Rather than build something that would
silently do nothing on most phones, this was deliberately left out. Only
read-only touch info (via `dumpsys input`) is shown, under Performance.

### Honest limitation: auto-revert detection delay

There is no push-based "app closed" event available to a non-root,
non-accessibility-service app on Android. `GameMonitor.kt` polls the
foreground app every 3 seconds via Shizuku. This means there's a real,
disclosed delay (up to ~3s) between a game actually closing and TweakX
reverting resolution/DPI. Brightness and animation scale are intentionally
**not** auto-reverted, because there's no single correct "default" value to
restore them to without having recorded the pre-launch value — a future
version could snapshot pre-launch values for a full revert if that's wanted.

### What this means honestly

Everything listed above is implemented against the real Shizuku API surface
and real Android APIs — nothing is mocked or hardcoded. That said, **code
being correctly written against a documented API is not the same as code
being verified running on a device.** The environment this project was
generated in has no Android SDK, no emulator, and no physical device, so:

- `flutter analyze`, `flutter test`, `flutter build apk --release`, and
  `./gradlew assembleDebug` have **not** been executed against this exact
  codebase yet. They were checked manually (import resolution, brace/paren
  balance, API signature verification against Shizuku's own source/issue
  tracker) but not compiler-verified.
- The first real build should happen through the included GitHub Actions
  workflow (`.github/workflows/build.yml`), or locally if you have the
  Android/Flutter toolchain installed. If `flutter analyze` reports issues,
  they are most likely small type/import fixes — the architecture and logic
  do not change.
- Every Shizuku interaction (status, permission, command execution) can only
  be truly verified on a real Android device with Shizuku installed and
  running. This is inherent to what the app does, not a shortcut taken here.

---

## Known caveat: launching games via `monkey`

TweakX launches games using
`monkey -p <package> -c android.intent.category.LAUNCHER 1`, a common and
well-documented pattern for starting an app by package name alone (no need
to know its main activity class). `monkey` is primarily a stress-testing
tool, but sending exactly one `LAUNCHER`-category event is a standard,
widely used way to just open the app — it does not run any actual
stress/fuzz testing at count `1`. The alternative, `am start -n
<package>/<activity>`, would require resolving each game's launcher
activity name first; `monkey` avoids that extra lookup.

## Known caveat: `Shizuku.newProcess`

TweakX runs shell commands through `Shizuku.newProcess`, accessed via
reflection because it isn't part of the stable public surface in recent
`dev.rikka.shizuku:api` releases. This is the same pattern used by other
real-world Shizuku consumer apps. The Shizuku maintainers have signaled that
`newProcess` may eventually be removed in favor of `UserService` (a more
robust mechanism for running privileged code in a separate process). It
still works on all currently published Shizuku versions. If a future Shizuku
release removes `newProcess`, `ShizukuCommandExecutor.kt` is the single file
that would need to be migrated to a `UserService`-based implementation — the
rest of the app (allowlist, Flutter UI, MethodChannel contracts) would not
need to change.

---

## Known caveat: the crosshair overlay is a foreground service

The crosshair and floating control are drawn by `OverlayService.kt`, a real
Android foreground service using `WindowManager.addView` with
`TYPE_APPLICATION_OVERLAY` — genuinely rendered over other apps, not a mock.
Two things worth knowing:

- It requires the **"Display over other apps"** permission, granted
  manually by the user in system Settings. TweakX cannot request this at
  runtime the way it can with a normal permission dialog — it can only open
  the correct Settings screen and wait for the user to flip the toggle.
  This is unrelated to Shizuku entirely.
- On Android 14+, all foreground services must declare a type. This one
  declares `specialUse` with a justification string, since none of the
  predefined types (media, location, camera, etc.) fit a UI overlay. If
  TweakX is ever published to Google Play, `specialUse` foreground services
  are subject to Play's review process and must be justified there too —
  this isn't a concern for sideloaded/personal builds via GitHub Actions,
  but is worth knowing if Play distribution is ever planned.

---

## Requirements

- An Android device running Android 7.0 (API 24) or newer
- [Shizuku](https://shizuku.rikka.app/download/) installed and **running**
  on that device (via ADB/wireless debugging, or root — see below)
- Flutter SDK (stable channel, 3.24+) if building locally
- JDK 17
- Android SDK / Android Studio if building locally

---

## Running the app

```bash
flutter pub get
flutter run
```

## Building a release APK

```bash
flutter build apk --release
```

The unsigned/debug-signed APK will be at
`build/app/outputs/flutter-apk/app-release.apk`.

To produce a **signed** release build, provide a keystore via environment
variables before building (used by `android/app/build.gradle.kts`):

```bash
export TWEAKX_KEYSTORE_PATH=/path/to/your.jks
export TWEAKX_KEYSTORE_PASSWORD=yourStorePassword
export TWEAKX_KEY_ALIAS=yourKeyAlias
export TWEAKX_KEY_PASSWORD=yourKeyPassword
flutter build apk --release
```

If these are not set, the release build falls back to debug signing so the
project always builds without any manual local setup — this is what the
included GitHub Actions workflow does. Add these as GitHub Actions secrets
(and read them into the workflow) if you want CI to produce signed APKs.

## Building the native Android project directly

```bash
cd android
./gradlew assembleDebug
```

## Running tests

```bash
flutter test
```

---

## How to use Shizuku with TweakX

1. Install Shizuku from [shizuku.rikka.app](https://shizuku.rikka.app/download/)
   or from the Play Store.
2. Start the Shizuku service using a method your device supports:
   - **Wireless debugging** (Android 11+): enable Developer Options →
     Wireless debugging, then start Shizuku from its app using the
     "Wireless debugging" starter.
   - **ADB over USB**: connect your device to a computer and run the
     `adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh`
     command shown in the Shizuku app (varies slightly by Shizuku version).
   - **Root**: if your device is rooted, Shizuku can start automatically via
     its root starter — no ADB needed.
3. Open TweakX. On the **Shizuku** tab, tap **Refresh Status** if it doesn't
   update automatically.
4. If status shows "Shizuku Running" but permission is not granted, tap
   **Request Permission** and approve the dialog.
5. Once permission is granted, all tweaks on the **Home** tab become active.

TweakX does **not** require root. Shizuku itself, however, must be started
using a method your device supports — TweakX cannot start Shizuku for you.

---

## Using per-game profiles

1. On the **Home** tab, tap **Add Game**.
2. Search and pick any installed app from the list (TweakX does not
   pre-filter to "games" — Android has no reliable way to detect that
   automatically, so you choose manually).
3. You'll land on that game's category menu with three cards:
   - **Display** — Resolution (presets or custom width/height), DPI
     (presets or custom value), Refresh Rate/FPS, Brightness
   - **Performance** — Animation Scale, plus read-only Thermal Status and
     Touch Input info
   - **Aim** — Crosshair overlay (style, color, size) and its floating
     toggle control
   
   Each category opens its own screen with its own **Save** / **Save &
   Launch** buttons — settings across categories are all part of the same
   game profile and combine when you launch, but you configure and save
   them independently, one category at a time.
4. Leaving a setting at "Default" means TweakX won't touch it. In any
   category, tap **Save** to store just that category's changes, or
   **Save & Launch** to apply everything currently configured across the
   whole profile and immediately open the game.
5. When you close the game, TweakX detects this (within a few seconds) and
   automatically reverts Resolution and DPI back to your device's defaults.

---

## Troubleshooting

**"Shizuku Not Available"**
Shizuku is not installed, or its service isn't currently running. Open the
Shizuku app and start its service (see steps above), then tap Refresh
Status in TweakX.

**"Shizuku Running" but permission denied**
Tap **Request Permission** in the Shizuku tab and approve the system dialog.
If nothing appears, check that Shizuku itself hasn't revoked TweakX's
permission from its own app list.

**Command failed / SecurityException**
Some settings are restricted on certain OEM skins (e.g. Samsung, some MIUI
builds) even under shell/ADB privilege. If a specific tweak consistently
fails with `SecurityException`, that manufacturer likely blocks that
setting outside of their own Settings app.

**"This tweak is not supported on your Android version"**
TweakX checks `Build.VERSION.SDK_INT` before exposing tweaks that need a
minimum API level. On unsupported versions, the tweak is disabled with an
explanation rather than silently failing.

**Build failure in `flutter analyze` or `flutter build apk`**
This project targets Gradle 8.11.1 / AGP 8.9.1 / Kotlin 2.0.0 / compileSdk
34, a combination verified compatible with current Flutter stable releases.
`android.newDsl=false` is set in `gradle.properties` as a safeguard against
AGP 9's breaking "new DSL", which is incompatible with the Flutter Gradle
plugin as of this writing. If your local toolchain or CI runner resolves a
newer AGP than pinned in `android/settings.gradle.kts`, dependency versions
there and in `android/app/build.gradle.kts` may need bumping to match —
check the exact error for the minimum version it's asking for.

**"Your project's Android Gradle Plugin version is lower than Flutter's
minimum supported version" or "Gradle version will soon be dropped"**
These mean the Flutter SDK your CI/local machine is using expects a newer
Gradle/AGP floor than this project is pinned to. Flutter's Gradle/AGP
minimums move forward with each Flutter release, independent of this
project. Fix by bumping the versions in `android/settings.gradle.kts`
(AGP, Kotlin) and `android/gradle/wrapper/gradle-wrapper.properties`
(Gradle) to whatever the error message specifies as the minimum.

**Shizuku service disconnected mid-session**
This can happen if Shizuku is killed by the system or the user manually
stops it. TweakX detects this via `Shizuku.OnBinderDeadListener` and the
Shizuku tab will update to "Shizuku Not Available" automatically — no app
restart needed, just restart Shizuku and refresh.

**Resolution/DPI didn't revert after closing a game**
Auto-revert relies on 3-second polling of the foreground app via Shizuku.
If Shizuku disconnected while the game was running, monitoring stops (it
won't spin forever against a dead connection) and revert won't fire. Open
the game's detail page and tap **Save** (without Launch) after manually
resetting values, or use `wm size reset` / `wm density reset` via any ADB
shell as a manual fallback.

**"Add Game" list is empty or missing apps**
TweakX requests `QUERY_ALL_PACKAGES` to list every launchable app. Some
OEM Android builds restrict this further at the system level regardless of
the manifest permission; if apps are still missing, it's a device-level
restriction TweakX cannot override without root.

**Crosshair toggle is greyed out on the Aim page**
The overlay requires "Display over other apps" permission, which TweakX
cannot grant on your behalf. Tap **Open Settings** in the banner at the top
of the Aim page, enable the toggle for TweakX, then return to the app —
TweakX re-checks the permission automatically when you come back.

**Crosshair doesn't appear even though permission is granted**
Some OEM skins (particularly MIUI/HyperOS and some Samsung One UI builds)
have an additional per-app "Appear on top" toggle separate from the
standard Android overlay permission, or apply extra battery/background
restrictions that can prevent the foreground service notification (and
therefore the overlay) from starting reliably. Check your device's
app-specific battery and permission settings for TweakX if this happens.

---

## Project structure

```
tweakx/
├── android/
│   └── app/src/main/kotlin/com/tweakx/android/
│       ├── MainActivity.kt              # Thin MethodChannel/EventChannel router
│       ├── ShizukuManager.kt            # Availability + permission state
│       ├── ShizukuCommandExecutor.kt    # Runs argv commands via Shizuku.newProcess
│       ├── CommandAllowlist.kt          # Only place raw command argv is defined
│       ├── TweakBridge.kt               # Global tweaks + device info
│       ├── GameBridge.kt                # Per-game tweaks (resolution/dpi/refresh/thermal/touch/launch)
│       ├── GameMonitor.kt               # Polls foreground app to detect game close, for auto-revert
│       ├── AppListManager.kt            # PackageManager-based installed app listing
│       ├── OverlayService.kt            # Foreground service rendering the crosshair + floating control
│       └── CrosshairView.kt             # Canvas-drawn crosshair (cross/dot/circle-cross)
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── core/
│   │   ├── theme/app_theme.dart
│   │   └── constants/{channels,tweak_options}.dart
│   ├── services/
│   │   ├── shizuku_service.dart         # MethodChannel + EventChannel wrapper
│   │   ├── tweak_service.dart           # Global tweaks (legacy channel, still available)
│   │   ├── game_service.dart            # Per-game tweaks + game-closed event stream
│   │   ├── app_list_service.dart        # Installed app picker data source
│   │   ├── game_storage_service.dart    # Local persistence of game profiles
│   │   └── overlay_service.dart         # Crosshair overlay MethodChannel wrapper
│   ├── models/
│   │   ├── shizuku_status.dart
│   │   ├── command_result.dart
│   │   ├── device_info.dart
│   │   ├── installed_app.dart
│   │   ├── game_profile.dart            # Includes crosshair style/color/size/enabled
│   │   └── tweak_item.dart
│   ├── screens/
│   │   ├── home_screen.dart             # Game list + Add Game + Shizuku status
│   │   ├── add_game_screen.dart         # Installed-app picker
│   │   ├── game_detail_screen.dart      # Category menu: Display / Performance / Aim
│   │   ├── game/
│   │   │   ├── display_settings_screen.dart      # Resolution (+custom), DPI (+custom), refresh rate, brightness
│   │   │   ├── performance_settings_screen.dart  # Animation scale, thermal (read-only), touch (read-only)
│   │   │   ├── aim_settings_screen.dart          # Crosshair style/color/size + floating control
│   │   │   └── save_launch_bar.dart              # Shared Save / Save & Launch bottom bar
│   │   ├── shizuku_screen.dart
│   │   └── settings_screen.dart
│   └── widgets/
│       ├── tweak_card.dart
│       ├── status_card.dart
│       └── command_output.dart
├── test/
│   ├── command_result_test.dart
│   ├── shizuku_status_test.dart
│   ├── game_profile_test.dart           # Includes crosshair field coverage
│   ├── tweak_service_test.dart
│   └── shizuku_service_test.dart
└── .github/workflows/build.yml
```

---

## Security model

TweakX never exposes arbitrary command execution to the UI or to user input.
Every privileged command is one of a fixed set of argv arrays defined in
`CommandAllowlist.kt`, built from typed, range-validated inputs (e.g.
brightness must be `0..255`, resolution must fall within `480..7680` per
dimension, refresh rate must be one of five fixed values). No shell string
concatenation or `eval`-style execution is used anywhere in the native
layer. The `launchApp` command validates the package name against a strict
`[a-zA-Z0-9_.]+` pattern before it's ever passed to `monkey`. The custom
resolution/DPI text inputs on the Display screen are range-validated in
Dart *and* re-validated in Kotlin — the UI check is a convenience, not the
actual security boundary.

---

## App icon

The launcher icon is a custom two-tone "TX" monogram (white "T", green "X")
on a dark gradient rounded-square background, generated as real PNG assets
at every required mipmap density (mdpi through xxxhdpi) — not a placeholder
or a stock icon.
