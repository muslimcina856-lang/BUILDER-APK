import 'package:flutter_test/flutter_test.dart';
import 'package:tweakx/models/game_profile.dart';

void main() {
  group('GameProfile.hasAnyCustomSetting', () {
    test('is false for a freshly added game with no settings', () {
      const profile = GameProfile(packageName: 'com.example.game', label: 'Game');
      expect(profile.hasAnyCustomSetting, isFalse);
    });

    test('is true when any single field is set', () {
      const profile = GameProfile(
        packageName: 'com.example.game',
        label: 'Game',
        dpi: 400,
      );
      expect(profile.hasAnyCustomSetting, isTrue);
    });

    test('is true when crosshair is enabled even with no other settings', () {
      const profile = GameProfile(
        packageName: 'com.example.game',
        label: 'Game',
        crosshairEnabled: true,
      );
      expect(profile.hasAnyCustomSetting, isTrue);
    });
  });

  group('GameProfile.copyWith', () {
    const base = GameProfile(packageName: 'com.example.game', label: 'Game');

    test('sets a new field while preserving others', () {
      final withRes = base.copyWith(resolutionWidth: 1920, resolutionHeight: 1080);
      final withDpi = withRes.copyWith(dpi: 400);

      expect(withDpi.resolutionWidth, 1920);
      expect(withDpi.resolutionHeight, 1080);
      expect(withDpi.dpi, 400);
    });

    test('clearResolution removes only resolution fields', () {
      final withBoth = base.copyWith(
        resolutionWidth: 1920,
        resolutionHeight: 1080,
        dpi: 400,
      );
      final cleared = withBoth.copyWith(clearResolution: true);

      expect(cleared.resolutionWidth, isNull);
      expect(cleared.resolutionHeight, isNull);
      expect(cleared.dpi, 400);
    });

    test('clearAnimationScale removes only animation scale', () {
      final withScale = base.copyWith(animationScale: 0.5, brightness: 200);
      final cleared = withScale.copyWith(clearAnimationScale: true);

      expect(cleared.animationScale, isNull);
      expect(cleared.brightness, 200);
    });
  });

  group('GameProfile JSON round-trip', () {
    test('serializes and deserializes all fields correctly', () {
      const original = GameProfile(
        packageName: 'com.tencent.ig',
        label: 'PUBG Mobile',
        iconBase64: 'AAAA',
        resolutionWidth: 1920,
        resolutionHeight: 1080,
        dpi: 400,
        refreshRateHz: 90,
        brightness: 200,
        animationScale: 0.5,
        crosshairEnabled: true,
        crosshairStyle: 'dot',
        crosshairColorHex: '#FF5252',
        crosshairSize: 64,
      );

      final json = original.toJson();
      final restored = GameProfile.fromJson(json);

      expect(restored.packageName, original.packageName);
      expect(restored.label, original.label);
      expect(restored.iconBase64, original.iconBase64);
      expect(restored.resolutionWidth, original.resolutionWidth);
      expect(restored.resolutionHeight, original.resolutionHeight);
      expect(restored.dpi, original.dpi);
      expect(restored.refreshRateHz, original.refreshRateHz);
      expect(restored.brightness, original.brightness);
      expect(restored.animationScale, original.animationScale);
      expect(restored.crosshairEnabled, original.crosshairEnabled);
      expect(restored.crosshairStyle, original.crosshairStyle);
      expect(restored.crosshairColorHex, original.crosshairColorHex);
      expect(restored.crosshairSize, original.crosshairSize);
    });

    test('handles null optional fields and crosshair defaults correctly', () {
      const original = GameProfile(
        packageName: 'com.example.game',
        label: 'Untouched Game',
      );

      final restored = GameProfile.fromJson(original.toJson());

      expect(restored.resolutionWidth, isNull);
      expect(restored.dpi, isNull);
      expect(restored.crosshairEnabled, isFalse);
      expect(restored.crosshairStyle, 'cross');
      expect(restored.crosshairColorHex, '#00E676');
      expect(restored.crosshairSize, 48);
      expect(restored.hasAnyCustomSetting, isFalse);
    });
  });
}
