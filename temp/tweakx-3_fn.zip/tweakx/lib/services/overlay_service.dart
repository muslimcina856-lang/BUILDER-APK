import 'package:flutter/services.dart';
import '../core/constants/channels.dart';

/// Wraps the overlay/* MethodChannel calls. Backed by a real Android
/// foreground Service (OverlayService.kt) drawing an actual WindowManager
/// overlay — nothing here is simulated. The "Display over other apps"
/// permission this depends on is a standard Android permission the user
/// grants manually in system Settings; it has nothing to do with Shizuku.
class OverlayService {
  OverlayService._internal();

  static final OverlayService instance = OverlayService._internal();

  static const MethodChannel _channel = MethodChannel(Channels.overlay);

  Future<bool> canDrawOverlays() async {
    try {
      final result = await _channel.invokeMethod<bool>('canDrawOverlays');
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  /// Opens the real Android system Settings screen where the user grants
  /// "Display over other apps" for TweakX. TweakX cannot grant this
  /// permission programmatically — only the user can, in Settings.
  Future<void> requestOverlayPermission() async {
    try {
      await _channel.invokeMethod('requestOverlayPermission');
    } on PlatformException {
      // no-op; caller can re-check canDrawOverlays() after returning
    }
  }

  /// Returns null on success, or a human-readable error message on failure
  /// (e.g. permission not granted).
  Future<String?> showCrosshair({
    required String style,
    required String colorHex,
    required int size,
  }) async {
    try {
      await _channel.invokeMethod('showCrosshair', {
        'style': style,
        'color': colorHex,
        'size': size,
      });
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Failed to show crosshair overlay';
    }
  }

  Future<void> hideCrosshair() async {
    try {
      await _channel.invokeMethod('hideCrosshair');
    } on PlatformException {
      // no-op
    }
  }
}
