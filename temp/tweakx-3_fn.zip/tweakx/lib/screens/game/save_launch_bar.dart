import 'package:flutter/material.dart';

/// Shared bottom bar with Save + Save & Launch, used identically across
/// Display / Performance / Aim category screens so each has its own
/// self-contained flow as requested.
class SaveLaunchBar extends StatelessWidget {
  final bool saving;
  final VoidCallback onSave;
  final VoidCallback onSaveAndLaunch;
  final String launchLabel;

  const SaveLaunchBar({
    super.key,
    required this.saving,
    required this.onSave,
    required this.onSaveAndLaunch,
    this.launchLabel = 'Save & Launch',
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: saving ? null : onSave,
                child: const Text('Save'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: FilledButton.icon(
                onPressed: saving ? null : onSaveAndLaunch,
                icon: saving
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.black,
                        ),
                      )
                    : const Icon(Icons.play_arrow_rounded, size: 20),
                label: Text(saving ? 'Applying...' : launchLabel),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
