import 'package:flutter/material.dart';
import '../../core/constants/tweak_options.dart';
import '../../core/theme/app_theme.dart';
import '../../models/game_profile.dart';
import '../../services/game_service.dart';
import '../../services/game_storage_service.dart';
import '../../widgets/tweak_card.dart';
import 'save_launch_bar.dart';

class PerformanceSettingsScreen extends StatefulWidget {
  final GameProfile profile;

  const PerformanceSettingsScreen({super.key, required this.profile});

  @override
  State<PerformanceSettingsScreen> createState() =>
      _PerformanceSettingsScreenState();
}

class _PerformanceSettingsScreenState extends State<PerformanceSettingsScreen> {
  final _service = GameService.instance;
  final _storage = GameStorageService.instance;

  late GameProfile _profile;
  bool _saving = false;
  String? _thermalInfo;
  String? _touchInfo;
  bool _loadingInfo = true;

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    _loadReadOnlyInfo();
  }

  Future<void> _loadReadOnlyInfo() async {
    final thermal = await _service.getThermalStatus();
    final touch = await _service.getTouchInfo();
    if (!mounted) return;
    setState(() {
      _thermalInfo =
          thermal.success ? _summarizeThermal(thermal.stdout) : thermal.humanError;
      _touchInfo =
          touch.success ? _summarizeTouch(touch.stdout) : touch.humanError;
      _loadingInfo = false;
    });
  }

  String _summarizeThermal(String raw) {
    final match = RegExp(r'mStatus\s*=\s*(\d+)').firstMatch(raw);
    if (match != null) {
      const labels = {
        '0': 'None',
        '1': 'Light',
        '2': 'Moderate',
        '3': 'Severe',
        '4': 'Critical',
        '5': 'Emergency',
        '6': 'Shutdown',
      };
      final level = labels[match.group(1)] ?? 'Unknown';
      return 'Current thermal level: $level';
    }
    return raw.isEmpty ? 'No thermal data available' : 'Status read from device';
  }

  String _summarizeTouch(String raw) {
    return raw.isEmpty
        ? 'No touch data available'
        : 'Touch input service is active';
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (!mounted) return;
    _showSnack('Performance settings saved');
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);

    final errors = <String>[];

    if (_profile.animationScale != null) {
      for (final setting in ['window', 'transition', 'animator']) {
        final r =
            await _service.setAnimationScale(setting, _profile.animationScale!);
        if (!r.success) {
          errors.add('Animation: ${r.humanError}');
          break;
        }
      }
    }

    final launchResult = await _service.launchApp(_profile.packageName);
    if (!launchResult.success) {
      errors.add('Launch: ${launchResult.humanError}');
    } else if (_profile.hasAnyCustomSetting) {
      await _service.startMonitoring(_profile.packageName);
    }

    if (!mounted) return;
    setState(() => _saving = false);
    _showSnack(
        errors.isEmpty ? '${_profile.label} launched' : errors.join(' • '));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Performance')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          TweakCard(
            icon: Icons.animation_outlined,
            title: 'Animation Scale',
            description: 'System animation speed while playing',
            currentValueLabel: _profile.animationScale != null
                ? '${_profile.animationScale}x'
                : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.animationScales.map((scale) {
                final selected = _profile.animationScale == scale;
                return ChoiceChip(
                  label: Text('${scale}x'),
                  selected: selected,
                  onSelected: (_) => setState(
                      () => _profile = _profile.copyWith(animationScale: scale)),
                  selectedColor: AppTheme.accent,
                  backgroundColor: AppTheme.surfaceVariant,
                  labelStyle: TextStyle(
                    color: selected ? Colors.black : AppTheme.textSecondary,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                  side: BorderSide.none,
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.thermostat_outlined,
            title: 'Thermal Status',
            subtitle:
                'Read-only — Android has no universal API to force a thermal profile across devices',
            value: _loadingInfo ? null : _thermalInfo,
          ),
          const SizedBox(height: 12),
          _ReadOnlyInfoCard(
            icon: Icons.touch_app_outlined,
            title: 'Touch Input',
            subtitle:
                'Read-only — no universal touch-sampling setter exists via Shizuku',
            value: _loadingInfo ? null : _touchInfo,
          ),
        ],
      ),
      bottomNavigationBar: SaveLaunchBar(
        saving: _saving,
        onSave: _save,
        onSaveAndLaunch: _saveAndLaunch,
      ),
    );
  }
}

class _ReadOnlyInfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String? value;

  const _ReadOnlyInfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppTheme.textSecondary, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  value == null
                      ? const SizedBox(
                          height: 14,
                          width: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.accent,
                          ),
                        )
                      : Text(
                          value!,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.accent,
                          ),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
