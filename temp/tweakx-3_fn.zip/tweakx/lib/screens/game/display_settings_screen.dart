import 'package:flutter/material.dart';
import '../../core/constants/tweak_options.dart';
import '../../core/theme/app_theme.dart';
import '../../models/game_profile.dart';
import '../../services/game_service.dart';
import '../../services/game_storage_service.dart';
import '../../widgets/tweak_card.dart';
import 'save_launch_bar.dart';

class DisplaySettingsScreen extends StatefulWidget {
  final GameProfile profile;

  const DisplaySettingsScreen({super.key, required this.profile});

  @override
  State<DisplaySettingsScreen> createState() => _DisplaySettingsScreenState();
}

class _DisplaySettingsScreenState extends State<DisplaySettingsScreen> {
  final _service = GameService.instance;
  final _storage = GameStorageService.instance;

  late GameProfile _profile;
  bool _saving = false;

  final _widthController = TextEditingController();
  final _heightController = TextEditingController();
  final _dpiController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _profile = widget.profile;
    if (_profile.resolutionWidth != null) {
      _widthController.text = _profile.resolutionWidth.toString();
      _heightController.text = _profile.resolutionHeight.toString();
    }
    if (_profile.dpi != null) {
      _dpiController.text = _profile.dpi.toString();
    }
  }

  @override
  void dispose() {
    _widthController.dispose();
    _heightController.dispose();
    _dpiController.dispose();
    super.dispose();
  }

  void _applyCustomResolution() {
    final w = int.tryParse(_widthController.text);
    final h = int.tryParse(_heightController.text);
    if (w == null || h == null) {
      _showSnack('Enter valid width and height');
      return;
    }
    if (w < 480 || w > 7680 || h < 480 || h > 7680) {
      _showSnack('Resolution must be between 480 and 7680 per side');
      return;
    }
    setState(() {
      _profile = _profile.copyWith(resolutionWidth: w, resolutionHeight: h);
    });
  }

  void _applyCustomDpi() {
    final dpi = int.tryParse(_dpiController.text);
    if (dpi == null) {
      _showSnack('Enter a valid DPI value');
      return;
    }
    if (dpi < 120 || dpi > 640) {
      _showSnack('DPI must be between 120 and 640');
      return;
    }
    setState(() => _profile = _profile.copyWith(dpi: dpi));
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (!mounted) return;
    _showSnack('Display settings saved');
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);

    final errors = <String>[];

    if (_profile.resolutionWidth != null && _profile.resolutionHeight != null) {
      final r = await _service.setResolution(
          _profile.resolutionWidth!, _profile.resolutionHeight!);
      if (!r.success) errors.add('Resolution: ${r.humanError}');
    }
    if (_profile.dpi != null) {
      final r = await _service.setDpi(_profile.dpi!);
      if (!r.success) errors.add('DPI: ${r.humanError}');
    }
    if (_profile.refreshRateHz != null) {
      final r = await _service.setPeakRefreshRate(_profile.refreshRateHz!);
      if (!r.success) errors.add('Refresh rate: ${r.humanError}');
    }
    if (_profile.brightness != null) {
      final r = await _service.setBrightness(_profile.brightness!);
      if (!r.success) errors.add('Brightness: ${r.humanError}');
    }

    final launchResult = await _service.launchApp(_profile.packageName);
    if (!launchResult.success) {
      errors.add('Launch: ${launchResult.humanError}');
    } else if (_profile.hasAnyCustomSetting) {
      await _service.startMonitoring(_profile.packageName);
    }

    if (!mounted) return;
    setState(() => _saving = false);
    _showSnack(errors.isEmpty
        ? '${_profile.label} launched'
        : errors.join(' • '));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Display')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          TweakCard(
            icon: Icons.aspect_ratio_outlined,
            title: 'Resolution',
            description: 'Rendering resolution for this game',
            currentValueLabel: _profile.resolutionWidth != null
                ? '${_profile.resolutionWidth}×${_profile.resolutionHeight}'
                : 'Default',
            control: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: TweakOptions.resolutions.map((res) {
                    final selected = _profile.resolutionWidth == res['width'] &&
                        _profile.resolutionHeight == res['height'];
                    return _chip(
                      label: '${res['width']}×${res['height']}',
                      selected: selected,
                      onSelected: () => setState(() {
                        _profile = _profile.copyWith(
                          resolutionWidth: res['width'],
                          resolutionHeight: res['height'],
                        );
                        _widthController.text = res['width'].toString();
                        _heightController.text = res['height'].toString();
                      }),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                const Text('Custom resolution',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: _numberField(_widthController, 'Width')),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: Text('×', style: TextStyle(color: AppTheme.textSecondary)),
                    ),
                    Expanded(child: _numberField(_heightController, 'Height')),
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: _applyCustomResolution,
                      icon: const Icon(Icons.check_circle_outline_rounded),
                      color: AppTheme.accent,
                      tooltip: 'Apply custom resolution',
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.grid_on_outlined,
            title: 'DPI',
            description: 'Screen density for this game',
            currentValueLabel: _profile.dpi != null ? '${_profile.dpi}' : 'Default',
            control: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: TweakOptions.dpiOptions.map((dpi) {
                    final selected = _profile.dpi == dpi;
                    return _chip(
                      label: '$dpi',
                      selected: selected,
                      onSelected: () {
                        setState(() => _profile = _profile.copyWith(dpi: dpi));
                        _dpiController.text = dpi.toString();
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                const Text('Custom DPI',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: _numberField(_dpiController, 'DPI (120-640)')),
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: _applyCustomDpi,
                      icon: const Icon(Icons.check_circle_outline_rounded),
                      color: AppTheme.accent,
                      tooltip: 'Apply custom DPI',
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.speed_outlined,
            title: 'Refresh Rate / FPS',
            description: 'Peak display refresh rate for this game',
            currentValueLabel: _profile.refreshRateHz != null
                ? '${_profile.refreshRateHz} Hz'
                : 'Default',
            control: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: TweakOptions.refreshRates.map((hz) {
                final selected = _profile.refreshRateHz == hz;
                return _chip(
                  label: '${hz}Hz',
                  selected: selected,
                  onSelected: () => setState(
                      () => _profile = _profile.copyWith(refreshRateHz: hz)),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          TweakCard(
            icon: Icons.brightness_6_outlined,
            title: 'Brightness',
            description: 'Screen brightness for this game',
            currentValueLabel:
                _profile.brightness != null ? '${_profile.brightness}' : 'Default',
            control: Slider(
              value: (_profile.brightness ?? 128)
                  .clamp(TweakOptions.brightnessMin, TweakOptions.brightnessMax)
                  .toDouble(),
              min: TweakOptions.brightnessMin.toDouble(),
              max: TweakOptions.brightnessMax.toDouble(),
              onChanged: (v) => setState(
                  () => _profile = _profile.copyWith(brightness: v.round())),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SaveLaunchBar(
        saving: _saving,
        onSave: _save,
        onSaveAndLaunch: _saveAndLaunch,
      ),
    );
  }

  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onSelected,
  }) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onSelected(),
      selectedColor: AppTheme.accent,
      backgroundColor: AppTheme.surfaceVariant,
      labelStyle: TextStyle(
        color: selected ? Colors.black : AppTheme.textSecondary,
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
      side: BorderSide.none,
    );
  }

  Widget _numberField(TextEditingController controller, String hint) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
        filled: true,
        fillColor: AppTheme.surfaceVariant,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
