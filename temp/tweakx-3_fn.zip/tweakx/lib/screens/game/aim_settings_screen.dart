import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../models/game_profile.dart';
import '../../services/game_service.dart';
import '../../services/game_storage_service.dart';
import '../../services/overlay_service.dart';
import '../../widgets/tweak_card.dart';
import 'save_launch_bar.dart';

class AimSettingsScreen extends StatefulWidget {
  final GameProfile profile;

  const AimSettingsScreen({super.key, required this.profile});

  @override
  State<AimSettingsScreen> createState() => _AimSettingsScreenState();
}

class _AimSettingsScreenState extends State<AimSettingsScreen>
    with WidgetsBindingObserver {
  final _overlay = OverlayService.instance;
  final _gameService = GameService.instance;
  final _storage = GameStorageService.instance;

  late GameProfile _profile;
  bool _saving = false;
  bool _hasOverlayPermission = false;
  bool _checkingPermission = true;

  static const _styles = ['cross', 'dot', 'circle-cross'];
  static const _styleLabels = {
    'cross': 'Cross',
    'dot': 'Dot',
    'circle-cross': 'Circle + Cross',
  };
  static const _colors = {
    '#00E676': Color(0xFF00E676),
    '#FF5252': Color(0xFFFF5252),
    '#FFFFFF': Color(0xFFFFFFFF),
    '#FFC107': Color(0xFFFFC107),
    '#2196F3': Color(0xFF2196F3),
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _profile = widget.profile;
    _checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Re-check permission when returning from the system Settings screen.
    if (state == AppLifecycleState.resumed) {
      _checkPermission();
    }
  }

  Future<void> _checkPermission() async {
    final granted = await _overlay.canDrawOverlays();
    if (!mounted) return;
    setState(() {
      _hasOverlayPermission = granted;
      _checkingPermission = false;
    });
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _save() async {
    await _storage.addOrUpdateGame(_profile);
    if (!mounted) return;
    _showSnack('Aim settings saved');
  }

  Future<void> _toggleCrosshairPreview(bool enabled) async {
    if (enabled && !_hasOverlayPermission) {
      _showSnack('Grant "Display over other apps" permission first');
      return;
    }
    setState(() => _profile = _profile.copyWith(crosshairEnabled: enabled));
    if (enabled) {
      final error = await _overlay.showCrosshair(
        style: _profile.crosshairStyle,
        colorHex: _profile.crosshairColorHex,
        size: _profile.crosshairSize,
      );
      if (error != null) {
        _showSnack(error);
        setState(() => _profile = _profile.copyWith(crosshairEnabled: false));
      }
    } else {
      await _overlay.hideCrosshair();
    }
  }

  Future<void> _updateStyleLive(String style) async {
    setState(() => _profile = _profile.copyWith(crosshairStyle: style));
    if (_profile.crosshairEnabled) {
      await _overlay.showCrosshair(
        style: _profile.crosshairStyle,
        colorHex: _profile.crosshairColorHex,
        size: _profile.crosshairSize,
      );
    }
  }

  Future<void> _updateColorLive(String colorHex) async {
    setState(() => _profile = _profile.copyWith(crosshairColorHex: colorHex));
    if (_profile.crosshairEnabled) {
      await _overlay.showCrosshair(
        style: _profile.crosshairStyle,
        colorHex: _profile.crosshairColorHex,
        size: _profile.crosshairSize,
      );
    }
  }

  Future<void> _updateSizeLive(double size) async {
    setState(() => _profile = _profile.copyWith(crosshairSize: size.round()));
  }

  Future<void> _saveAndLaunch() async {
    setState(() => _saving = true);
    await _storage.addOrUpdateGame(_profile);

    final errors = <String>[];

    final launchResult = await _gameService.launchApp(_profile.packageName);
    if (!launchResult.success) {
      errors.add('Launch: ${launchResult.humanError}');
    } else {
      if (_profile.crosshairEnabled) {
        if (!_hasOverlayPermission) {
          errors.add('Crosshair: overlay permission not granted');
        } else {
          final error = await _overlay.showCrosshair(
            style: _profile.crosshairStyle,
            colorHex: _profile.crosshairColorHex,
            size: _profile.crosshairSize,
          );
          if (error != null) errors.add('Crosshair: $error');
        }
      }
      if (_profile.hasAnyCustomSetting) {
        await _gameService.startMonitoring(_profile.packageName);
      }
    }

    if (!mounted) return;
    setState(() => _saving = false);
    _showSnack(
        errors.isEmpty ? '${_profile.label} launched' : errors.join(' • '));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Aim')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 140),
        children: [
          if (!_checkingPermission && !_hasOverlayPermission)
            _PermissionBanner(
              onGrant: () async {
                await _overlay.requestOverlayPermission();
              },
            ),
          if (!_checkingPermission && !_hasOverlayPermission)
            const SizedBox(height: 16),
          TweakCard(
            icon: Icons.gps_fixed_rounded,
            title: 'Crosshair Overlay',
            description: 'Floating crosshair drawn over this game',
            currentValueLabel: _profile.crosshairEnabled ? 'On' : 'Off',
            enabled: _hasOverlayPermission,
            disabledReason: _checkingPermission
                ? null
                : 'Requires "Display over other apps" permission',
            control: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(
                    'Show crosshair preview now',
                    style: TextStyle(color: AppTheme.textPrimary, fontSize: 13),
                  ),
                  value: _profile.crosshairEnabled,
                  activeColor: AppTheme.accent,
                  onChanged: _hasOverlayPermission
                      ? (v) => _toggleCrosshairPreview(v)
                      : null,
                ),
                const SizedBox(height: 8),
                const Text('Style',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _styles.map((style) {
                    final selected = _profile.crosshairStyle == style;
                    return ChoiceChip(
                      label: Text(_styleLabels[style]!),
                      selected: selected,
                      onSelected: _hasOverlayPermission
                          ? (_) => _updateStyleLive(style)
                          : null,
                      selectedColor: AppTheme.accent,
                      backgroundColor: AppTheme.surfaceVariant,
                      labelStyle: TextStyle(
                        color: selected ? Colors.black : AppTheme.textSecondary,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                      side: BorderSide.none,
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                const Text('Color',
                    style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: _colors.entries.map((entry) {
                    final selected = _profile.crosshairColorHex == entry.key;
                    return GestureDetector(
                      onTap: _hasOverlayPermission
                          ? () => _updateColorLive(entry.key)
                          : null,
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: entry.value,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selected
                                ? Colors.white
                                : Colors.white.withValues(alpha: 0.2),
                            width: selected ? 2.5 : 1,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Size',
                        style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                    Text('${_profile.crosshairSize}dp',
                        style: const TextStyle(
                            fontSize: 12,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
                Slider(
                  value: _profile.crosshairSize.toDouble(),
                  min: 24,
                  max: 120,
                  onChanged: _hasOverlayPermission ? _updateSizeLive : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.accent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.control_camera_rounded,
                        color: AppTheme.accent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Floating Control',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'A small draggable button appears alongside the crosshair whenever it\'s active. Tap it to instantly show/hide the crosshair without leaving your game. Drag it anywhere on screen.',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.textSecondary,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SaveLaunchBar(
        saving: _saving,
        onSave: _save,
        onSaveAndLaunch: _saveAndLaunch,
      ),
    );
  }
}

class _PermissionBanner extends StatelessWidget {
  final VoidCallback onGrant;

  const _PermissionBanner({required this.onGrant});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFC107).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFC107).withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.warning_amber_rounded,
                  color: Color(0xFFFFC107), size: 18),
              SizedBox(width: 8),
              Text(
                'Permission required',
                style: TextStyle(
                  color: Color(0xFFFFC107),
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'The crosshair overlay needs "Display over other apps" permission, granted manually in Android Settings. This is separate from Shizuku.',
            style: TextStyle(
              fontSize: 12.5,
              color: AppTheme.textSecondary,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: onGrant,
              child: const Text('Open Settings'),
            ),
          ),
        ],
      ),
    );
  }
}
