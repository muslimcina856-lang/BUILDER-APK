package com.qiblacompass.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.qiblacompass.app.location.LocationProvider
import com.qiblacompass.app.sensor.CompassSensor
import com.qiblacompass.app.ui.theme.DarkBackground
import com.qiblacompass.app.ui.theme.GrayText
import com.qiblacompass.app.ui.theme.GreenAccent
import com.qiblacompass.app.ui.theme.GreenPrimary
import com.qiblacompass.app.ui.theme.QiblaCompassTheme
import com.qiblacompass.app.ui.theme.WhiteText

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QiblaCompassTheme {
                QiblaApp()
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun QiblaApp() {
    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    if (permissionsState.allPermissionsGranted) {
        QiblaCompassContent()
    } else {
        PermissionScreen(
            onRequestPermission = { permissionsState.launchMultiplePermissionRequest() }
        )
    }
}

@Composable
fun QiblaCompassContent() {
    val context = LocalContext.current

    var azimuth by remember { mutableFloatStateOf(0f) }
    var userLat by remember { mutableDoubleStateOf(0.0) }
    var userLng by remember { mutableDoubleStateOf(0.0) }
    var locationReady by remember { mutableStateOf(false) }
    var accuracyGood by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val compass = CompassSensor(context)
        compass.setOnAzimuthChangedListener { newAzimuth ->
            azimuth = newAzimuth
        }
        compass.setOnAccuracyStatusListener { good ->
            accuracyGood = good
        }
        compass.start()

        val locationProvider = LocationProvider(context)
        locationProvider.requestLocation { lat, lng ->
            userLat = lat
            userLng = lng
            locationReady = true
        }

        onDispose {
            compass.stop()
            locationProvider.stop()
        }
    }

    QiblaScreen(
        azimuth = azimuth,
        userLat = userLat,
        userLng = userLng,
        locationReady = locationReady,
        accuracyGood = accuracyGood
    )
}

@Composable
fun PermissionScreen(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "🕌",
            fontSize = 72.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Qibla Compass",
            color = WhiteText,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Aplikasi memerlukan akses lokasi untuk mengira arah Kiblat yang tepat dari lokasi anda.",
            color = GrayText,
            fontSize = 15.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(
                containerColor = GreenPrimary,
                contentColor = WhiteText
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.size(width = 240.dp, height = 50.dp)
        ) {
            Text(
                text = "Benarkan Lokasi",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Tiada iklan. Tiada tracking.\nHanya arah Kiblat. 🤲",
            color = GreenAccent,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
    }
}
