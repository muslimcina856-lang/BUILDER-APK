package com.qiblacompass.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkCard = Color(0xFF21262D)
val GreenPrimary = Color(0xFF1B5E20)
val GreenLight = Color(0xFF4CAF50)
val GreenAccent = Color(0xFF69F0AE)
val GoldAccent = Color(0xFFFFD700)
val WhiteText = Color(0xFFE6EDF3)
val GrayText = Color(0xFF8B949E)
val RedAccent = Color(0xFFFF5252)
