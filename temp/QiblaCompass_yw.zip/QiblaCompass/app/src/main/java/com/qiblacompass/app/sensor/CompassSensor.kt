package com.qiblacompass.app.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

class CompassSensor(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private var gravity: FloatArray? = null
    private var geomagnetic: FloatArray? = null
    private var onAzimuthChanged: ((Float) -> Unit)? = null
    private var onAccuracyStatus: ((Boolean) -> Unit)? = null

    fun setOnAzimuthChangedListener(listener: (Float) -> Unit) {
        onAzimuthChanged = listener
    }

    fun setOnAccuracyStatusListener(listener: (Boolean) -> Unit) {
        onAccuracyStatus = listener
    }

    fun start() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        magnetometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> gravity = event.values.clone()
            Sensor.TYPE_MAGNETIC_FIELD -> geomagnetic = event.values.clone()
        }
        val g = gravity ?: return
        val m = geomagnetic ?: return
        val r = FloatArray(9)
        val i = FloatArray(9)
        if (SensorManager.getRotationMatrix(r, i, g, m)) {
            val orientation = FloatArray(3)
            SensorManager.getOrientation(r, orientation)
            val azimuthRad = orientation[0]
            val azimuthDeg = ((Math.toDegrees(azimuthRad.toDouble()).toFloat()) + 360f) % 360f
            onAzimuthChanged?.invoke(azimuthDeg)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
        if (sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            onAccuracyStatus?.invoke(accuracy >= SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM)
        }
    }
}
