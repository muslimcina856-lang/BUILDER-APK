package com.qiblacompass.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qiblacompass.app.qibla.QiblaCalculator
import com.qiblacompass.app.ui.theme.DarkBackground
import com.qiblacompass.app.ui.theme.DarkCard
import com.qiblacompass.app.ui.theme.GoldAccent
import com.qiblacompass.app.ui.theme.GrayText
import com.qiblacompass.app.ui.theme.GreenAccent
import com.qiblacompass.app.ui.theme.GreenLight
import com.qiblacompass.app.ui.theme.GreenPrimary
import com.qiblacompass.app.ui.theme.RedAccent
import com.qiblacompass.app.ui.theme.WhiteText
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun QiblaScreen(
    azimuth: Float,
    userLat: Double,
    userLng: Double,
    locationReady: Boolean,
    accuracyGood: Boolean
) {
    val qiblaBearing = if (locationReady) {
        QiblaCalculator.calculateQiblaBearing(userLat, userLng).toFloat()
    } else 0f

    val distance = if (locationReady) {
        QiblaCalculator.calculateDistanceToKaaba(userLat, userLng)
    } else 0.0

    // Smooth rotation animation
    val targetCompassRotation = -azimuth
    val animatedCompass by animateFloatAsState(
        targetValue = targetCompassRotation,
        animationSpec = tween(durationMillis = 300),
        label = "compass"
    )

    val qiblaRelative = (qiblaBearing - azimuth + 360f) % 360f
    val animatedQibla by animateFloatAsState(
        targetValue = qiblaRelative,
        animationSpec = tween(durationMillis = 300),
        label = "qibla"
    )

    // Check if pointing at Qibla (within 5 degrees)
    val isPointingQibla = locationReady && (qiblaRelative < 5f || qiblaRelative > 355f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Title
        Text(
            text = "🕌 Qibla Compass",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = WhiteText
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Status indicator
        val statusColor = when {
            !locationReady -> RedAccent
            !accuracyGood -> GoldAccent
            isPointingQibla -> GreenAccent
            else -> GreenLight
        }
        val statusText = when {
            !locationReady -> "📍 Mendapatkan lokasi..."
            !accuracyGood -> "⚠️ Kalibrasi kompas diperlukan"
            isPointingQibla -> "✅ Anda menghadap Kiblat!"
            else -> "🧭 Putar telefon ke arah Kiblat"
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = statusText,
                color = statusColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Compass
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(320.dp)
        ) {
            // Outer glow when pointing at Qibla
            if (isPointingQibla) {
                Box(
                    modifier = Modifier
                        .size(320.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    GreenAccent.copy(alpha = 0.3f),
                                    Color.Transparent
                                )
                            ),
                            CircleShape
                        )
                )
            }

            Canvas(modifier = Modifier.size(300.dp)) {
                val centerX = size.width / 2f
                val centerY = size.height / 2f
                val radius = size.width / 2f - 20f

                // Draw compass rose (rotates with phone)
                drawCompassRose(centerX, centerY, radius, animatedCompass)

                // Draw Qibla arrow (points to Kaaba)
                if (locationReady) {
                    drawQiblaArrow(centerX, centerY, radius, animatedQibla, isPointingQibla)
                }

                // Center dot
                drawCircle(
                    color = if (isPointingQibla) GreenAccent else WhiteText,
                    radius = 6f,
                    center = Offset(centerX, centerY)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Info cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InfoCard(
                title = "Bearing",
                value = if (locationReady) "${qiblaBearing.toInt()}°" else "—",
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                title = "Jarak",
                value = if (locationReady) "${String.format("%.0f", distance)} km" else "—",
                modifier = Modifier.weight(1f)
            )
            InfoCard(
                title = "Heading",
                value = "${azimuth.toInt()}°",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Coordinates
        if (locationReady) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Lokasi Anda",
                        color = GrayText,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${String.format("%.4f", userLat)}, ${String.format("%.4f", userLng)}",
                        color = WhiteText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Kaaba: 21.4225°N, 39.8262°E",
            color = GrayText,
            fontSize = 11.sp
        )
    }
}

@Composable
fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = GrayText,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = GreenAccent,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun DrawScope.drawCompassRose(cx: Float, cy: Float, radius: Float, rotation: Float) {
    rotate(degrees = rotation, pivot = Offset(cx, cy)) {
        // Outer circle
        drawCircle(
            color = Color(0xFF30363D),
            radius = radius,
            center = Offset(cx, cy),
            style = Stroke(width = 3f)
        )

        // Inner circle
        drawCircle(
            color = Color(0xFF21262D),
            radius = radius - 30f,
            center = Offset(cx, cy),
            style = Stroke(width = 1f)
        )

        // Degree ticks
        for (deg in 0 until 360 step 5) {
            val rad = Math.toRadians(deg.toDouble()).toFloat()
            val isCardinal = deg % 90 == 0
            val isMajor = deg % 30 == 0
            val tickLen = when {
                isCardinal -> 20f
                isMajor -> 14f
                else -> 8f
            }
            val tickColor = when {
                isCardinal -> Color.White
                isMajor -> Color(0xFF8B949E)
                else -> Color(0xFF484F58)
            }
            val outerX = cx + radius * sin(rad)
            val outerY = cy - radius * cos(rad)
            val innerX = cx + (radius - tickLen) * sin(rad)
            val innerY = cy - (radius - tickLen) * cos(rad)

            drawLine(
                color = tickColor,
                start = Offset(outerX, outerY),
                end = Offset(innerX, innerY),
                strokeWidth = if (isCardinal) 3f else if (isMajor) 2f else 1f
            )
        }

        // Cardinal direction labels
        val labelRadius = radius - 40f
        val cardinals = listOf(
            Triple(0f, "N", Color(0xFFFF5252)),
            Triple(90f, "E", Color.White),
            Triple(180f, "S", Color.White),
            Triple(270f, "W", Color.White)
        )

        for ((deg, label, color) in cardinals) {
            val rad = Math.toRadians(deg.toDouble()).toFloat()
            val lx = cx + labelRadius * sin(rad)
            val ly = cy - labelRadius * cos(rad)

            drawContext.canvas.nativeCanvas.apply {
                val paint = android.graphics.Paint().apply {
                    this.color = android.graphics.Color.argb(
                        (color.alpha * 255).toInt(),
                        (color.red * 255).toInt(),
                        (color.green * 255).toInt(),
                        (color.blue * 255).toInt()
                    )
                    textSize = if (label == "N") 26f else 20f
                    textAlign = android.graphics.Paint.Align.CENTER
                    isFakeBoldText = true
                    isAntiAlias = true
                }
                save()
                translate(lx, ly)
                rotate(deg)
                drawText(label, 0f, 8f, paint)
                restore()
            }
        }

        // North triangle indicator
        val northPath = Path().apply {
            val topX = cx
            val topY = cy - radius + 8f
            moveTo(topX, topY)
            lineTo(topX - 8f, topY + 16f)
            lineTo(topX + 8f, topY + 16f)
            close()
        }
        drawPath(northPath, color = Color(0xFFFF5252))
    }
}

private fun DrawScope.drawQiblaArrow(
    cx: Float, cy: Float, radius: Float, angle: Float, isPointing: Boolean
) {
    rotate(degrees = angle, pivot = Offset(cx, cy)) {
        val arrowColor = if (isPointing) Color(0xFF69F0AE) else Color(0xFFFFD700)
        val arrowLen = radius - 50f

        // Arrow line
        drawLine(
            color = arrowColor,
            start = Offset(cx, cy),
            end = Offset(cx, cy - arrowLen),
            strokeWidth = 4f,
            cap = StrokeCap.Round
        )

        // Arrow head
        val headPath = Path().apply {
            moveTo(cx, cy - arrowLen - 12f)
            lineTo(cx - 12f, cy - arrowLen + 10f)
            lineTo(cx + 12f, cy - arrowLen + 10f)
            close()
        }
        drawPath(headPath, color = arrowColor)

        // Kaaba icon (small square)
        val kaabaSize = 14f
        val kaabaY = cy - arrowLen - 28f
        drawRect(
            color = arrowColor,
            topLeft = Offset(cx - kaabaSize / 2, kaabaY - kaabaSize / 2),
            size = androidx.compose.ui.geometry.Size(kaabaSize, kaabaSize)
        )
        drawRect(
            color = Color.Black,
            topLeft = Offset(cx - kaabaSize / 2 + 2f, kaabaY - kaabaSize / 2 + 2f),
            size = androidx.compose.ui.geometry.Size(kaabaSize - 4f, kaabaSize - 4f)
        )
    }
}
