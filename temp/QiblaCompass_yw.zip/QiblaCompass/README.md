# 🕌 Qibla Compass

Aplikasi penunjuk arah Kiblat untuk Android — **tanpa iklan, tanpa tracking**.

## Features
- 🧭 Kompas real-time menggunakan sensor telefon
- 📍 Auto-detect lokasi GPS untuk kiraan bearing yang tepat
- 🏛️ Arrow penunjuk arah Kaaba yang berputar mengikut orientasi telefon
- 📏 Paparan jarak ke Kaaba dalam kilometer
- ✅ Indikator hijau apabila menghadap Kiblat (±5°)
- ⚠️ Amaran jika kompas perlu dikalibrasi
- 🌙 Dark theme yang selesa di mata

## Tech Stack
- **Kotlin** + **Jetpack Compose**
- **Material3** dark color scheme
- **Play Services Location** untuk GPS
- **Accompanist Permissions** untuk runtime permissions
- **Hardware Sensors**: Accelerometer + Magnetometer

## Cara Build
1. Buka **Android Studio** (Hedgehog 2023.1.1+)
2. **Open** → pilih folder `QiblaCompass`
3. Tunggu Gradle sync
4. Klik **Run ▶️**

Atau via terminal:
```bash
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Permissions
- `ACCESS_FINE_LOCATION` — untuk GPS koordinat
- `ACCESS_COARSE_LOCATION` — fallback lokasi

## Formula
Qibla bearing dikira menggunakan **Great Circle bearing formula** dari lokasi pengguna ke koordinat Kaaba (21.4225°N, 39.8262°E).

---
Tiada iklan. Tiada tracking. Hanya arah Kiblat. 🤲
