# Skybound Quest — Relics of the Aether

`v0.2.0` ialah vertical slice action-platformer 2D untuk Android yang dibina
menggunakan Flutter dan Flame. Versi ini menukar prototaip arena asal kepada
satu misi lengkap bernama **Aether Ruins** dengan pemilihan watak, objektif,
combat yang boleh dibaca, checkpoint, boss, kemenangan, kekalahan dan restart.

## Misi

1. Pilih Nova, Aegis, Pyra atau Volt.
2. Teroka Aether Ruins dan kumpul tiga Relik Langit.
3. Tewaskan Monitor Golem.
4. Masuk ke portal yang telah diaktifkan.

Pemain boleh mengelak sebahagian musuh biasa, tetapi ketiga-tiga relik dan boss
wajib diselesaikan untuk membuka portal.

## Ciri yang telah dilaksanakan

- Satu level mendatar/menegak sepanjang 3,360 unit menggunakan tileset dan
  background pixel art sebenar.
- Platform satu hala, jurang, spike yang memberi damage, checkpoint dan dua
  pickup pemulihan.
- Empat avatar dengan statistik, resource dan dua skill berbeza.
- Enam musuh termasuk boss dua fasa; AI melee, ranged, flying, patrol dan
  penjagaan jarak tidak lagi menggunakan tingkah laku yang sama.
- Projectile sebenar dengan pergerakan, collision sasaran/platform, julat dan
  maksimum sasaran.
- Windup telegraph, attack arc, shockwave, trail, hit particle, damage number,
  status indicator, hit flash, knockback dan animasi prosedural.
- HP, shield, defense, resistance, crit, life steal, i-frame, poise, stagger,
  status bertindan dan periodic damage.
- HUD lengkap: HP, shield, tenaga, cooldown, relik, objektif, baki musuh dan
  boss bar.
- Skrin pilih watak, loading, pause, kemenangan, kekalahan, masa tamat dan
  restart penuh.
- Audio serangan, hit, lompat, landing, pickup, checkpoint dan keputusan misi.
- Kamera terkunci pada sempadan level dan mengikuti hero dengan kelajuan
  terkawal.
- Kawalan multi-touch serta sokongan papan kekunci untuk desktop/debug.

## Kawalan

### Android

- Kiri/kanan: dua butang di kiri bawah.
- Lompat: butang `LOMPAT` di kanan bawah.
- Serangan utama: butang `SERANG`.
- Skill khas: butang `SKILL` dengan indikator cooldown.
- Pause: butang di kanan atas.

### Papan kekunci

| Tindakan | Kekunci |
|---|---|
| Bergerak | `A/D` atau anak panah kiri/kanan |
| Lompat | `W`, anak panah atas atau `Space` |
| Serangan utama | `J` atau `Z` |
| Skill khas | `K` atau `X` |
| Pause | `P` atau `Esc` |

## Menyediakan Android dan menjalankan game

Projek sumber sengaja tidak membawa folder platform yang dijana oleh Flutter.
Dari akar projek, jalankan:

```bash
./tool/bootstrap_android.sh
flutter run
```

Skrip tersebut menjalankan `flutter create`, dependency restore, format check,
analyzer, ujian, verifier combat dan build APK debug. Langkah manual yang sama:

```bash
flutter create --platforms=android --org com.earlxz .
flutter pub get
dart format lib test tool/verify_combat.dart
flutter analyze
flutter test
dart run tool/verify_combat.dart
flutter build apk --debug
```

APK debug akan berada di:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

Untuk AAB release:

```bash
flutter build appbundle --release
```

Release sebenar masih memerlukan keystore, application ID, ikon aplikasi dan
konfigurasi Play Store milik penerbit.

## Semakan tanpa Flutter SDK

Semakan aset, import relatif, delimiter sumber, katalog actor/skill dan
konfigurasi projek boleh dijalankan menggunakan Python 3:

```bash
python3 tool/validate_project.py
```

Semakan penuh yang memerlukan Flutter:

```bash
./tool/validate_flutter.sh
```

## Struktur penting

```text
lib/game/combat/       HP, damage, status, poise dan lifecycle skill
lib/game/components/   Level, actor, AI, projectile, pickup dan VFX
lib/game/data/         Katalog empat avatar dan enam musuh
lib/game/input/        State input multi-touch/papan kekunci
lib/game/level/        Kemajuan objektif dan portal
lib/ui/                Skrin tajuk, HUD, kawalan dan overlay
assets/                 280 imej, 130 audio serta manifest
third_party/raw/        Arkib/lesen aset CC0 asal
test/                   Ujian combat, progress dan input
tool/                   Bootstrap serta validator projek
```

## Skop versi ini

Versi `0.2.0` ialah **satu vertical slice yang boleh tamat**, bukan kempen enam
kawasan. Save game, progression merentas level, tetapan kawalan terperinci,
localization dan art/animasi produksi penuh belum termasuk. Batasan dan hasil
semakan diterangkan dalam `docs/VALIDATION.md`.
