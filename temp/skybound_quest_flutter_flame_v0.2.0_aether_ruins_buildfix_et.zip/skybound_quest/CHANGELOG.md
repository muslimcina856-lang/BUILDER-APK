# Changelog

## 0.2.0+2 — Aether Ruins vertical slice

### Ditambah

- Skrin pemilihan empat avatar dengan statistik dan penerangan skill.
- Level Aether Ruins menggunakan tileset/background sebenar, platform, jurang,
  hazard, dekorasi dan ambient lights.
- Tiga relik, checkpoint, pickup HP, portal, objektif, kemenangan dan kekalahan.
- Projectile bergerak dengan collision actor/platform dan trail.
- Attack arc, shockwave, particle impact, floating damage, hit flash dan
  animasi prosedural actor.
- AI patrol, melee, ranged, flying serta boss dua fasa.
- HUD baharu, cooldown ring, boss bar, pause, restart dan statistik tamat.
- Sound manager untuk serangan, hit, traversal, pickup dan keputusan misi.
- Kamera bounds/follow dan kawalan papan kekunci.
- Ujian input, progress, periodic status dan skill lifecycle.
- Validator statik serta skrip validasi Flutter/APK.

### Dibaiki

- Konflik jenis `num` → `double` pada `hero_component.dart`.
- Tick status terakhir yang terlepas pada hujung duration.
- Nombor periodic damage kini menggunakan nilai yang benar-benar dikenakan.
- Input tersangkut apabila aplikasi kehilangan fokus atau keluar ke menu.
- Reset level kini membersihkan semua actor, pickup, objektif dan VFX.

### Diubah

- Dependency yang tidak digunakan (`flame_tiled`, `shared_preferences`) dibuang.
- Dokumentasi lama berasaskan wishlist diganti dengan skop implementasi sebenar.
- Versi package dinaikkan daripada `0.1.0+1` kepada `0.2.0+2`.
