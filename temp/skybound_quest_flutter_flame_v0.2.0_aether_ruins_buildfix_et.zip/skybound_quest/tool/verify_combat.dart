import 'package:skybound_quest/game/combat/combat_actor_state.dart';
import 'package:skybound_quest/game/combat/combat_models.dart';
import 'package:skybound_quest/game/combat/combat_resolver.dart';
import 'package:skybound_quest/game/combat/health_pool.dart';
import 'package:skybound_quest/game/combat/skill_controller.dart';
import 'package:skybound_quest/game/data/actor_catalog.dart';

void check(bool condition, String message) {
  if (!condition) throw StateError(message);
}

void closeTo(double actual, double expected, String message) {
  if ((actual - expected).abs() > 0.0001) {
    throw StateError('$message: $actual (jangkaan $expected)');
  }
}

void main() {
  ActorCatalog.validate();
  check(ActorCatalog.all.length == 10, 'Katalog mesti mempunyai 10 actor.');
  check(
    ActorCatalog.all.every((actor) => actor.skills.isNotEmpty),
    'Semua actor wajib mempunyai skill.',
  );

  final pool = HealthPool(100)..addShield(20);
  final shieldHit = pool.applyDamage(30, invulnerabilityAfterHit: 0.3);
  closeTo(shieldHit.absorbedByShield, 20, 'Shield mesti menyerap dahulu');
  closeTo(shieldHit.healthDamage, 10, 'Baki damage mesti masuk ke HP');
  closeTo(pool.current, 90, 'HP selepas shield tidak tepat');
  final blocked = pool.applyDamage(20);
  check(blocked.blockedByInvulnerability, 'I-frame mesti menyekat hit kedua.');
  pool.update(0.31);
  pool.applyDamage(500);
  check(pool.isDead && pool.current == 0, 'HP mesti clamp pada sifar.');

  final shieldOnly = HealthPool(100)..addShield(40);
  final shieldOnlyHit = shieldOnly.applyDamage(
    15,
    invulnerabilityAfterHit: 0.25,
  );
  closeTo(
    shieldOnlyHit.absorbedByShield,
    15,
    'Hit shield-only mesti diserap',
  );
  check(
    shieldOnly.applyDamage(15).blockedByInvulnerability,
    'Hit shield-only mesti mengaktifkan i-frame.',
  );

  final attacker = CombatActorState(ActorCatalog.nova);
  final target = CombatActorState(ActorCatalog.mimicCube);
  const resolver = CombatResolver();
  final hit = resolver.resolve(
    attacker: attacker,
    target: target,
    hit: ActorCatalog.nova.skills.first.hit,
    criticalRoll: 1,
  );
  check(hit.landed, 'Serangan hero patut mengenai mob.');
  check(target.health.current < target.health.maximum, 'Mob mesti kehilangan HP.');

  final friendly = CombatActorState(ActorCatalog.aegis);
  final friendlyResult = resolver.resolve(
    attacker: attacker,
    target: friendly,
    hit: ActorCatalog.nova.skills.first.hit,
  );
  check(
    friendlyResult.rejection == DamageRejection.sameFaction,
    'Friendly fire mesti ditolak.',
  );

  final burnTarget = CombatActorState(ActorCatalog.pyra);
  burnTarget.statuses.apply(
    ActorCatalog.burning,
    sourceActorId: ActorCatalog.emberWisp.id,
  );
  final burnFrame = burnTarget.update(ActorCatalog.burning.duration);
  check(
    burnFrame.periodicDamage.length == 4,
    'Burning empat saat mesti menghasilkan empat tick.',
  );
  check(
    burnFrame.periodicDamage.every(
      (event) => (event.amount - 2.1).abs() <= 0.0001,
    ),
    'Periodic event mesti membawa damage selepas resistance.',
  );
  closeTo(
    burnTarget.health.current,
    86.6,
    'Tick terakhir pada sempadan duration tidak tepat',
  );

  final skill = ActorCatalog.nova.skills.first;
  final controller = SkillController([skill]);
  final activation = controller.tryActivate(
    skill.id,
    availableResource: 100,
    actionPrevented: false,
  );
  check(activation.accepted, 'Skill mesti boleh diaktifkan.');
  final castEvents = controller.update(skill.windup + 0.001);
  check(
    castEvents.any((event) => event.type == SkillEventType.attackWindowOpened),
    'Damage window mesti dibuka selepas windup.',
  );
  final finishEvents = controller.update(
    skill.activeTime + skill.recovery + 0.01,
  );
  check(
    finishEvents.any((event) => event.type == SkillEventType.castFinished),
    'Skill mesti menamatkan recovery.',
  );

  final expensive = ActorCatalog.pyra.skills.last;
  final poorController = SkillController([expensive]);
  final rejected = poorController.tryActivate(
    expensive.id,
    availableResource: 0,
    actionPrevented: false,
  );
  check(!rejected.accepted, 'Skill tanpa resource mesti ditolak.');

  final trueDamageTarget = CombatActorState(ActorCatalog.monitorGolem);
  final trueDamage = resolver.resolve(
    attacker: attacker,
    target: trueDamageTarget,
    hit: const HitDefinition(
      baseDamage: 25,
      attackScaling: 0,
      damageType: DamageType.trueDamage,
    ),
  );
  closeTo(
    trueDamage.application.healthDamage,
    25,
    'True damage mesti mengabaikan defense',
  );

  print(
    'Combat verification passed: 10 actors, HP, skills, statuses, '
    'cooldowns and boundary ticks.',
  );
}
