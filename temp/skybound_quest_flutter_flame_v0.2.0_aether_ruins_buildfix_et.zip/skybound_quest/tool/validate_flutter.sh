#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK tidak dijumpai. Pasang Flutter 3.41 atau lebih baharu dahulu." >&2
  exit 1
fi

python3 tool/validate_project.py
flutter pub get
dart format lib test tool/verify_combat.dart
flutter analyze
flutter test
dart run tool/verify_combat.dart
flutter build apk --debug

echo "Semua semakan Flutter lulus. APK debug tersedia di build/app/outputs/flutter-apk/app-debug.apk"
