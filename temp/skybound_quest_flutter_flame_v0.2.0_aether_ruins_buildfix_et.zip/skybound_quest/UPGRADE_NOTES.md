# Nota naik taraf 0.1 → 0.2

## Ringkasan

Versi 0.1 hanya menunjukkan combat backend di atas arena primitive. Versi 0.2
menjadikannya satu vertical slice yang mempunyai presentation, encounter dan
completion loop.

## Perubahan utama

| Bahagian | Sebelum | Selepas |
|---|---|---|
| Level | Rect hijau dan latar rata | Tiles, scenery, platform, jurang, spike dan dekorasi |
| Combat | Damage range segera | Projectile, telegraph, VFX, audio dan feedback hit |
| Animasi | Loop dua frame sama | State timing, flip, bob, squash/stretch, cast/hit/death |
| AI | Semua mengejar pada paksi X | Patrol, ranged spacing, flying, edge probe dan boss phase |
| Objektif | Tiada | 3 relik → boss → portal |
| Flow | Tiada win/lose/restart | Title, loading, pause, victory, defeat dan reset penuh |
| UI | HUD asas | Vitals, resource, cooldown, objective, boss bar dan stats |
| Dunia | Spike visual sahaja | Hazard damage, fall respawn, checkpoint dan heal pickup |
| Kualiti | Ujian combat minimum | Ujian combat/progress/input + static/full validators |

## Fail sumber baharu

```text
lib/game/audio/sound_manager.dart
lib/game/components/combat_effects.dart
lib/game/components/level_objects.dart
lib/game/components/projectile_component.dart
lib/game/level/level_progress.dart
lib/ui/title_screen.dart
test/level_progress_test.dart
test/player_input_test.dart
tool/validate_project.py
tool/validate_flutter.sh
```

## Fail utama yang dinaik taraf

```text
lib/main.dart
lib/game/skybound_game.dart
lib/game/components/arena_stage.dart
lib/game/components/combat_actor_component.dart
lib/game/components/hero_component.dart
lib/game/components/mob_component.dart
lib/ui/combat_hud.dart
lib/game/combat/status_controller.dart
lib/game/combat/combat_actor_state.dart
```

## Keserasian projek

- Minimum Dart/Flutter kekal seperti `pubspec.yaml`: Dart 3.11 dan Flutter 3.41.
- Folder Android boleh dijana semula menggunakan `tool/bootstrap_android.sh`.
- Katalog actor lama dikekalkan; balancing dan skill definitions masih berada
  di `lib/game/data/actor_catalog.dart`.
- Semua aset dan notis pihak ketiga asal dikekalkan.
