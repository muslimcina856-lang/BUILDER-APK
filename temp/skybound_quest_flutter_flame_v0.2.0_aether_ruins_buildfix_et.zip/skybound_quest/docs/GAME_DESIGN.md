# Reka bentuk semasa — Aether Ruins v0.2

Dokumen ini menerangkan kandungan yang benar-benar wujud dalam build `0.2.0`.
Ia menggantikan pelan enam kawasan lama yang sebelum ini belum dilaksanakan.

## Identiti permainan

- Genre: action-platformer 2D dengan combat berasaskan timing.
- Platform sasaran: Android landscape; papan kekunci disokong untuk debug.
- Format semasa: satu misi vertical slice yang mempunyai mula, objektif, boss
  dan penamat.
- Matlamat reka bentuk: pendek tetapi lengkap, mudah dibaca pada telefon dan
  menunjukkan semua sistem utama sebelum kandungan kempen ditambah.

## Aliran misi

1. **Pemilihan avatar** — pemain membandingkan HP, attack, speed dan dua skill.
2. **Zon pengenalan** — pergerakan, lompat, Mimic Cube dan platform asas.
3. **Relik pertama** — laluan menegak memperkenalkan Wisp/projectile.
4. **Zon hazard** — spike, jurang dan Drill Spike menguji timing.
5. **Checkpoint tengah** — memulihkan HP, memberi shield dan menetapkan spawn.
6. **Relik kedua** — Guard Bot menjaga platform tinggi.
7. **Relik ketiga** — Scout Drone menguji sasaran udara dan perubahan arah.
8. **Arena boss** — Monitor Golem menggunakan slam dekat dan beam jauh; fasa
   kedua bermula di bawah 50% HP.
9. **Portal** — aktif hanya selepas tiga relik dan boss selesai.

## Susun atur level

- Saiz dunia: `3360 × 560` unit.
- Empat segmen tanah utama dipisahkan oleh jurang yang boleh dilompat.
- Sepuluh platform tinggi membentuk laluan alternatif dan lokasi relik.
- Empat kelompok spike mempunyai collision damage sebenar.
- Satu checkpoint berada sebelum separuh kedua misi.
- Dua pickup HP memberi ruang pemulihan sebelum encounter penting.
- Kamera mempunyai zoom tetap, follow berkelajuan terhad dan bounds supaya
  ruang kosong di luar level tidak kelihatan.

## Avatar

| Avatar | Kekuatan | Skill utama | Skill khas |
|---|---|---|---|
| Nova | Seimbang | Sunsteel Slash | Sky Dash |
| Aegis | HP, defense dan poise tinggi | Shield Breaker | Guardian Quake |
| Pyra | Damage/range tinggi | Ember Orb | Solar Burst |
| Volt | Kelajuan dan crit tinggi | Spark Jab | Thunder Step |

Setiap avatar berkongsi fizik dan sistem combat yang sama, tetapi timing,
resource, damage type, jarak dan mobiliti skill mereka berbeza.

## Musuh dan counterplay

| Musuh | Tingkah laku | Counterplay utama |
|---|---|---|
| Mimic Cube | Patrol, mengejar dan hop/chomp | Baca windup dan serang selepas ia terlepas |
| Ember Wisp | Terbang dan mengekalkan jarak | Dekati, lompat atau elak Cinder Spit |
| Drill Spike | Mengejar dan dash charge | Tukar arah ketika telegraph muncul |
| Guard Bot | Menjaga jarak dan menembak | Gunakan platform atau lompat melepasi bolt |
| Scout Drone | Hover relatif kepada hero dan swoop | Bait serangan, kemudian tukar arah |
| Monitor Golem | Slam dekat, beam jauh, fasa kedua laju | Kawal jarak dan serang ketika recovery |

## Maklum balas pemain

- Garis/lingkaran telegraph membezakan serangan melee, projectile dan area.
- Cooldown skill dipaparkan sebagai cincin pada butang sentuh.
- Hit mempunyai flash, particle, knockback, damage number dan bunyi.
- Crit/stagger menggunakan paparan yang lebih berat.
- Status aktif dipaparkan sebagai pip berwarna di atas actor.
- Banner mengumumkan relik, checkpoint, fasa boss dan objektif penting.
- Skrin tamat memaparkan masa, relik dan jumlah musuh yang ditewaskan.

## Keadaan permainan

```text
loading → playing ↔ paused
                  ↘ victory
                  ↘ defeat
```

`restartLevel()` memulihkan hero, semua mob, relic, pickup, checkpoint, portal,
cooldown, status dan statistik misi tanpa mencipta route baharu.

## Sasaran prestasi

- Render menggunakan sprite sedia ada dan bentuk Canvas ringan.
- VFX sementara menghapuskan diri selepas tempoh pendek.
- Hanya enam musuh aktif dalam vertical slice ini.
- Aset audio pendek dipra-muat sekali oleh `SoundManager`.
- Filter pixel art ditetapkan kepada `FilterQuality.none`.

## Batasan yang diketahui

- Sprite actor sumber hanya menyediakan sedikit frame; state gerak/serangan
  diperkaya menggunakan flip, frame timing, bob, squash/stretch dan flash,
  bukan animation sheet produksi penuh.
- Tiada save game atau progression antara level.
- Tiada controller/gamepad, accessibility remap atau localization.
- Level belum menggunakan editor Tiled/chunk streaming kerana hanya satu misi.
- Release signing dan metadata store bukan sebahagian daripada source game.

## Laluan selepas v0.2

Keutamaan seterusnya ialah animation sheet unik setiap avatar, satu level kedua,
save/progression, accessibility control scaling dan playtest balancing. Kandungan
baharu perlu mengekalkan standard vertical slice ini: objektif jelas, encounter
berbeza, checkpoint, keputusan misi dan ujian regresi.
