# Sistem combat v0.2

## Pipeline bersama

Hero dan semua mob menggunakan `CombatActorState`, `HealthPool`,
`SkillController`, `StatusController` dan `CombatResolver` yang sama.
Perbezaan datang daripada blueprint, skill dan pengawal input/AI.

1. Input atau AI meminta aktivasi skill.
2. Controller menyemak kematian, stun, cast aktif, resource dan cooldown.
3. Skill memasuki `windup`; telegraph dilukis pada actor.
4. `attackWindowOpened` diterbitkan tepat sekali apabila fasa active bermula.
5. Melee/area/dash menyemak sasaran; projectile mencipta komponen bergerak.
6. Resolver mengira crit, defense, resistance, shield, HP dan i-frame.
7. Hit yang berjaya memproses poise, stagger, status, knockback dan life steal.
8. Game menghasilkan VFX, nombor damage dan audio berdasarkan hasil sebenar.
9. Actor mati apabila HP sifar dan keputusan hanya dilaporkan sekali.

## Formula damage

```text
rawDamage = baseDamage + attackPower × attackScaling
criticalDamage = rawDamage × criticalMultiplier          (jika crit)
defenseMultiplier = 100 ÷ (100 + defense)
resistanceMultiplier = 1 - resistance
gameplayDamage = max(1, criticalDamage × defenseMultiplier × resistanceMultiplier)
```

`trueDamage` mengabaikan defense dan resistance. Resistance dikekang antara
`-50%` dan `80%`. Shield menyerap damage dahulu; nombor damage menggunakan
jumlah sebenar yang diserap shield + ditolak daripada HP.

## Fasa skill

| Fasa | Fungsi |
|---|---|
| Windup | Telegraph dan ruang counterplay |
| Active | Membuka satu attack window atau menghasilkan projectile |
| Recovery | Actor belum boleh memulakan skill lain |
| Cooldown | Masa sebelum skill yang sama boleh digunakan semula |

Cooldown bermula ketika cast diterima. HUD memaparkan nisbah cooldown `1 → 0`.
Resource ditolak sekali ketika aktivasi dan pulih mengikut statistik actor.

## Corak serangan

### Melee

- Menghasilkan attack arc.
- Memerlukan sasaran berada dalam range dan di hadapan actor.
- Sasaran diutamakan mengikut jarak.

### Area

- Menghasilkan shockwave.
- Tidak memerlukan arah pandangan.
- Boleh mengenai sehingga `maximumTargets`.

### Dash

- Memberi impulse mendatar sepanjang active window.
- Boleh memberi invulnerability untuk tempoh yang ditakrifkan.
- Menghasilkan trail dan masih menggunakan penapisan sasaran/range.

### Projectile

- Mempunyai position, velocity, radius, jarak perjalanan dan senarai sasaran
  yang telah terkena.
- Berlanggar dengan platform dunia dan actor hostile.
- Boleh menembusi beberapa sasaran jika `maximumTargets > 1`.
- Cinder Spit, Guard Bolt, Ember Orb dan Screen Beam mempunyai kelajuan visual
  berbeza.

## HP, shield dan i-frame

`HealthPool` memastikan:

- HP dan heal sentiasa clamp dalam `0..maximum`.
- Shield menerima damage sebelum HP.
- I-frame menolak hit biasa tetapi boleh diabaikan oleh hit tertentu.
- Damage berkala sengaja mengabaikan i-frame.
- Death flag hanya baharu sekali bagi setiap hayat.
- `revive()` membersihkan shield, i-frame dan death flag.

Hazard dan jatuh menggunakan HealthPool yang sama. Jatuh memulangkan hero ke
checkpoint sekiranya hit tersebut tidak membunuhnya.

## Poise dan stagger

Setiap hit boleh mengurangkan poise. Apabila poise mencapai sifar:

- cast aktif sasaran dibatalkan;
- hasil hit ditanda sebagai stagger;
- poise dipulihkan kepada maksimum untuk kitaran seterusnya.

Poise juga pulih perlahan setiap frame ketika actor hidup.

## Status berkala

Status menyokong duration, stack, tick interval, damage, slow dan action lock.
Versi ini merangkumi Burning, Poisoned, Chilled dan Stunned.

Tick hanya menggunakan bahagian `dt` ketika status masih aktif. Oleh itu status
berdurasi empat saat dengan interval satu saat menghasilkan tepat empat tick,
termasuk tick pada sempadan akhir. Event UI membawa **damage sebenar selepas
resistance dan shield**, bukan nilai mentah status.

## AI combat

- Keputusan AI dibuat pada interval pendek, bukan setiap operasi render.
- Melee mengejar dan memilih skill mengikut jarak.
- Ranged cuba mengekalkan preferred distance.
- Flying actor mempunyai hover target dan clamp ketinggian.
- Mob grounded menggunakan gravity, platform landing dan edge probe.
- Boss memilih slam/beam berdasarkan jarak dan mendapat speed multiplier dalam
  fasa kedua.

## Ujian

`test/combat_core_test.dart` meliputi shield, i-frame, clamp, death, friendly
fire, true damage, periodic tick akhir, resistance, skill phase dan cooldown.
`tool/verify_combat.dart` menyediakan smoke test deterministik tanpa widget.
