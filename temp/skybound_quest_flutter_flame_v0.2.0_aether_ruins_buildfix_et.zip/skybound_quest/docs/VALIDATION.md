# Rekod validasi v0.2.0+2

Dokumen ini membezakan semakan yang benar-benar telah dijalankan daripada
semakan yang masih memerlukan Flutter SDK. Ia tidak mendakwa APK berjaya dibina
dalam persekitaran yang tidak mempunyai Flutter.

## Semakan yang telah lulus

Semakan berikut dijalankan dari akar projek menggunakan Python 3:

```bash
python3 tool/validate_project.py
```

Keputusan terakhir:

```text
PASS: semakan statik projek selesai
  versi              : 0.2.0+2
  fail Dart          : 25
  import disemak     : 108
  aset dirujuk       : 72
  imej/audio runtime : 280/130
  actor/skill        : 10/15
  direktori aset     : 7
  jump/reach/gap     : 94.3/106.0/100.0
```

Validator ini menyemak:

- nama package, versi dan direktori aset dalam `pubspec.yaml`;
- semua import relatif serta import package dalaman;
- delimiter, string dan komen yang tidak ditutup;
- setiap rujukan imej, audio dan manifest yang boleh dikesan;
- jumlah aset runtime asal: 280 imej dan 130 audio;
- ID actor/skill yang unik serta jumlah 10 actor dan 15 skill;
- ralat `num` ke `double` asal tidak muncul semula;
- ketinggian lompatan, jarak mendatar avatar paling perlahan dan jurang level;
- dependency lama yang telah dibuang tidak diimport semula.

Sintaks kedua-dua skrip shell juga telah disemak menggunakan:

```bash
bash -n tool/bootstrap_android.sh
bash -n tool/validate_flutter.sh
```

Semasa perbandingan dengan arkib v0.1 asal, tiada fail asal dibuang. Aset,
lesen dan arkib pihak ketiga dikekalkan; perubahan tertumpu pada source,
ujian, dokumentasi dan alat validasi.

## Semakan Flutter yang masih wajib

Persekitaran penyediaan arkib ini tidak mempunyai executable `flutter` atau
`dart`, dan akses rangkaian shell tidak tersedia untuk memasang SDK. Oleh itu,
perkara berikut belum boleh disahkan di sini:

- `flutter pub get` terhadap registry sebenar;
- hasil `dart format` rasmi;
- `flutter analyze`;
- `flutter test`;
- `dart run tool/verify_combat.dart`;
- `flutter build apk --debug` pada Android toolchain.

Jalankan satu arahan berikut pada mesin yang mempunyai Flutter 3.41 atau lebih
baharu:

```bash
./tool/bootstrap_android.sh
```

Skrip itu menjana folder Android dan kemudian menjalankan keseluruhan pipeline:

```text
static validator -> pub get -> format -> analyze -> tests -> combat verifier
-> APK debug
```

Jika folder Android sudah wujud, jalankan terus:

```bash
./tool/validate_flutter.sh
```

APK debug yang lulus akan berada di:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Kriteria penerimaan gameplay

Selepas build berjaya, smoke test manual minimum ialah:

1. pilih setiap satu daripada empat avatar dan pastikan level boleh dimuatkan;
2. gerak, lompat, guna serangan utama dan skill khas;
3. pastikan projectile bergerak dan berhenti pada sasaran atau platform;
4. ambil tiga relik, aktifkan checkpoint dan tewaskan Monitor Golem;
5. pastikan portal hanya aktif selepas relik dan boss selesai;
6. uji spike, jatuh, defeat, pause, resume dan restart;
7. pastikan restart memulihkan hero, musuh, relik, pickup dan objektif;
8. masuk portal dan sahkan overlay kemenangan serta statistik tamat.

## Batasan release

Versi ini ialah satu vertical slice yang boleh tamat, bukan build store-ready.
Release production masih memerlukan keystore, application ID akhir, ikon,
metadata store, ujian pada peranti fizikal dan playtest balancing.
