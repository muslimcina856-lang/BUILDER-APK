# Notis aset pihak ketiga

Semua aset yang disertakan datang daripada Kenney dan diterbitkan di bawah
Creative Commons Zero (CC0 1.0). Lesen asal bagi setiap pek dikekalkan di dalam
folder `third_party/raw/<nama_pek>/License.txt` atau `license.txt`.

Pek yang disertakan:

- Pixel Platformer 1.2
- Platformer Art Extended Enemies
- Pixel UI Pack
- Mobile Controls 1.0
- Impact Sounds

Aset boleh digunakan untuk tujuan peribadi, pendidikan dan komersial. Kredit
tidak diwajibkan oleh lesen, tetapi kredit `Kenney — https://kenney.nl` digalakkan.

Lihat `assets/manifests/asset_catalog.csv` untuk sumber, kiraan dan pemilihan
aset runtime.

