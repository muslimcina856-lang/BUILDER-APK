import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/combat/combat_models.dart';
import '../game/data/actor_catalog.dart';

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key, required this.onStart});

  final ValueChanged<String> onStart;

  @override
  State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen> {
  String _selectedId = 'nova';

  @override
  Widget build(BuildContext context) {
    final selected = ActorCatalog.byId(_selectedId);
    return Scaffold(
      backgroundColor: const Color(0xFF071225),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const CustomPaint(painter: _TitleBackdropPainter()),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxHeight < 500;
                return Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1060),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                      child: Column(
                        children: [
                          _TitleHeader(compact: compact),
                          SizedBox(height: compact ? 10 : 20),
                          Expanded(
                            child: _AvatarStrip(
                              selectedId: _selectedId,
                              onSelected: (id) => setState(() => _selectedId = id),
                            ),
                          ),
                          SizedBox(height: compact ? 8 : 14),
                          Text(
                            '${selected.skills.first.name.toUpperCase()}  •  ${selected.skills.last.name.toUpperCase()}',
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Color(0xFFFFD166),
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.8,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            selected.skills.last.description,
                            textAlign: TextAlign.center,
                            maxLines: compact ? 1 : 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Color(0xFFBBD3DF),
                              fontSize: 12,
                              height: 1.15,
                            ),
                          ),
                          const SizedBox(height: 10),
                          _StartButton(
                            avatar: selected,
                            onPressed: () => widget.onStart(selected.id),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TitleHeader extends StatelessWidget {
  const _TitleHeader({required this.compact});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'SKYBOUND QUEST',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontSize: compact ? 30 : 42,
            height: 0.95,
            fontWeight: FontWeight.w900,
            letterSpacing: 3.5,
            shadows: const [
              Shadow(color: Color(0xFF34D9D1), blurRadius: 18),
              Shadow(color: Colors.black, blurRadius: 5, offset: Offset(2, 3)),
            ],
          ),
        ),
        const SizedBox(height: 5),
        const Text(
          'RELICS OF THE AETHER',
          style: TextStyle(
            color: Color(0xFFFFD166),
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 5,
          ),
        ),
      ],
    );
  }
}

class _AvatarStrip extends StatelessWidget {
  const _AvatarStrip({required this.selectedId, required this.onSelected});

  final String selectedId;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final cardWidth = constraints.maxWidth >= 820
            ? (constraints.maxWidth - 36) / 4
            : 176.0;
        return ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          itemCount: ActorCatalog.playableAvatars.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (context, index) {
            final avatar = ActorCatalog.playableAvatars[index];
            return SizedBox(
              width: cardWidth,
              child: _AvatarCard(
                avatar: avatar,
                selected: avatar.id == selectedId,
                onTap: () => onSelected(avatar.id),
              ),
            );
          },
        );
      },
    );
  }
}

class _AvatarCard extends StatelessWidget {
  const _AvatarCard({
    required this.avatar,
    required this.selected,
    required this.onTap,
  });

  final ActorBlueprint avatar;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = _avatarColor(avatar.id);
    return AnimatedScale(
      duration: const Duration(milliseconds: 150),
      scale: selected ? 1.0 : 0.96,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(10),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 11),
            decoration: BoxDecoration(
              color: selected ? const Color(0xEE142B45) : const Color(0xC9101E33),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: selected ? accent : Colors.white24, width: selected ? 3.0 : 1.5),
              boxShadow: selected
                  ? [BoxShadow(color: accent.withAlpha(75), blurRadius: 18, spreadRadius: 2)]
                  : const [],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: Image.asset(
                    'assets/images/${avatar.spriteFrames.first}',
                    fit: BoxFit.contain,
                    filterQuality: FilterQuality.none,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  avatar.name.toUpperCase(),
                  style: TextStyle(
                    color: selected ? accent : Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.6,
                  ),
                ),
                const SizedBox(height: 7),
                _MiniStat(label: 'HP', value: avatar.stats.maxHealth / 170, color: const Color(0xFFFF5B66)),
                const SizedBox(height: 4),
                _MiniStat(label: 'ATK', value: avatar.stats.attackPower / 24, color: const Color(0xFFFFD166)),
                const SizedBox(height: 4),
                _MiniStat(label: 'SPD', value: avatar.stats.moveSpeed / 190, color: const Color(0xFF5CE1E6)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value, required this.color});

  final String label;
  final double value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 30,
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF9FB6C7),
              fontSize: 9,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: LinearProgressIndicator(
              value: value.clamp(0, 1).toDouble(),
              minHeight: 5,
              backgroundColor: Colors.black38,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}

class _StartButton extends StatelessWidget {
  const _StartButton({required this.avatar, required this.onPressed});

  final ActorBlueprint avatar;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final accent = _avatarColor(avatar.id);
    return SizedBox(
      width: 310,
      height: 52,
      child: FilledButton(
        style: FilledButton.styleFrom(
          backgroundColor: accent,
          foregroundColor: const Color(0xFF071225),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(7),
            side: const BorderSide(color: Colors.white, width: 2),
          ),
          elevation: 8,
        ),
        onPressed: onPressed,
        child: Text(
          'MULA MISI SEBAGAI ${avatar.name.toUpperCase()}',
          style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.8),
        ),
      ),
    );
  }
}

Color _avatarColor(String id) => switch (id) {
      'nova' => const Color(0xFF62E88F),
      'aegis' => const Color(0xFF77B8FF),
      'pyra' => const Color(0xFFFF759D),
      'volt' => const Color(0xFFFFCA3A),
      _ => const Color(0xFFFFFFFF),
    };

class _TitleBackdropPainter extends CustomPainter {
  const _TitleBackdropPainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF071225), Color(0xFF174C6B), Color(0xFF236A69)],
        ).createShader(Offset.zero & size),
    );
    final random = math.Random(42);
    final star = Paint()..color = const Color(0xFFBFFAFF);
    for (var i = 0; i < 70; i++) {
      final point = Offset(random.nextDouble() * size.width, random.nextDouble() * size.height * 0.65);
      final side = i % 5 == 0 ? 3.0 : 1.5;
      canvas.drawRect(
        Rect.fromCenter(center: point, width: side, height: side),
        star,
      );
    }
    final far = Paint()..color = const Color(0xAA102E4B);
    final near = Paint()..color = const Color(0xDD0A263D);
    final farPath = Path()..moveTo(0, size.height);
    final nearPath = Path()..moveTo(0, size.height);
    for (var x = 0.0; x <= size.width + 160; x += 150) {
      farPath.lineTo(x, size.height * 0.48 + math.sin(x * 0.012) * 38);
      nearPath.lineTo(x, size.height * 0.68 + math.cos(x * 0.009) * 52);
    }
    farPath..lineTo(size.width, size.height)..close();
    nearPath..lineTo(size.width, size.height)..close();
    canvas.drawPath(farPath, far);
    canvas.drawPath(nearPath, near);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
