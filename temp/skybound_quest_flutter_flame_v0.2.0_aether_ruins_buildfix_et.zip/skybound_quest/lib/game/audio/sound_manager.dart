import 'dart:async';
import 'dart:math';

import 'package:flame_audio/flame_audio.dart';

enum SoundCue {
  lightAttack,
  heavyAttack,
  projectile,
  hit,
  heavyHit,
  jump,
  landing,
  pickup,
  checkpoint,
  victory,
  defeat,
}

class SoundManager {
  SoundManager({Random? random}) : _random = random ?? Random();

  final Random _random;
  bool enabled = true;
  double masterVolume = 0.7;

  static const _preloadFiles = <String>[
    'impactMetal_light_001.ogg',
    'impactMetal_light_003.ogg',
    'impactMetal_heavy_002.ogg',
    'impactPunch_medium_001.ogg',
    'impactPunch_medium_003.ogg',
    'impactSoft_medium_002.ogg',
    'impactGlass_light_003.ogg',
    'impactBell_heavy_001.ogg',
    'impactBell_heavy_003.ogg',
    'footstep_grass_001.ogg',
    'footstep_grass_003.ogg',
  ];

  Future<void> preload() async {
    try {
      await FlameAudio.audioCache.loadAll(_preloadFiles);
    } catch (_) {
      // Audio tidak boleh menghalang permainan daripada bermula.
    }
  }

  void play(SoundCue cue, {double volume = 1}) {
    if (!enabled || masterVolume <= 0) return;
    final file = switch (cue) {
      SoundCue.lightAttack => _pick(const [
          'impactMetal_light_001.ogg',
          'impactMetal_light_003.ogg',
        ]),
      SoundCue.heavyAttack => 'impactMetal_heavy_002.ogg',
      SoundCue.projectile => 'impactGlass_light_003.ogg',
      SoundCue.hit => _pick(const [
          'impactPunch_medium_001.ogg',
          'impactPunch_medium_003.ogg',
          'impactSoft_medium_002.ogg',
        ]),
      SoundCue.heavyHit => 'impactMetal_heavy_002.ogg',
      SoundCue.jump => 'footstep_grass_001.ogg',
      SoundCue.landing => 'footstep_grass_003.ogg',
      SoundCue.pickup => 'impactBell_heavy_001.ogg',
      SoundCue.checkpoint => 'impactBell_heavy_003.ogg',
      SoundCue.victory => 'impactBell_heavy_001.ogg',
      SoundCue.defeat => 'impactMetal_heavy_002.ogg',
    };
    unawaited(_play(file, (volume * masterVolume).clamp(0, 1).toDouble()));
  }

  String _pick(List<String> files) => files[_random.nextInt(files.length)];

  Future<void> _play(String file, double volume) async {
    try {
      await FlameAudio.play(file, volume: volume);
    } catch (_) {
      // Sesetengah peranti/web mungkin belum memberi akses audio.
    }
  }
}
