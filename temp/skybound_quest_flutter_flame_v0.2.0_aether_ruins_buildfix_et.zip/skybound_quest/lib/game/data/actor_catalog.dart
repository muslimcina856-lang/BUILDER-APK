import '../combat/combat_models.dart';

class ActorCatalog {
  ActorCatalog._();

  static const burning = StatusEffectSpec(
    id: 'burning',
    type: StatusType.burning,
    duration: 4,
    maxStacks: 3,
    damagePerTick: 3,
    tickInterval: 1,
  );

  static const poisoned = StatusEffectSpec(
    id: 'poisoned',
    type: StatusType.poisoned,
    duration: 6,
    maxStacks: 4,
    damagePerTick: 2,
    tickInterval: 1,
  );

  static const chilled = StatusEffectSpec(
    id: 'chilled',
    type: StatusType.chilled,
    duration: 2.5,
    maxStacks: 1,
    moveSpeedMultiplier: 0.65,
  );

  static const stunned = StatusEffectSpec(
    id: 'stunned',
    type: StatusType.stunned,
    duration: 0.7,
    maxStacks: 1,
    preventsAction: true,
  );

  static final nova = ActorBlueprint(
    id: 'nova',
    name: 'Nova',
    faction: ActorFaction.hero,
    isPlayableAvatar: true,
    stats: CombatStats(
      maxHealth: 120,
      attackPower: 18,
      defense: 12,
      moveSpeed: 155,
      criticalChance: 0.12,
      criticalMultiplier: 1.65,
      maxPoise: 42,
    ),
    spriteFrames: const [
      'characters/tile_0000.png',
      'characters/tile_0001.png',
    ],
    skills: [
      SkillDefinition(
        id: 'sunsteel_slash',
        name: 'Sunsteel Slash',
        description: 'Tebasan pantas jarak dekat dengan stagger sederhana.',
        pattern: AttackPattern.melee,
        hit: const HitDefinition(
          baseDamage: 12,
          attackScaling: 1,
          poiseDamage: 16,
          knockback: 105,
        ),
        cooldown: 0.36,
        windup: 0.08,
        activeTime: 0.1,
        recovery: 0.18,
        range: 58,
      ),
      SkillDefinition(
        id: 'sky_dash',
        name: 'Sky Dash',
        description: 'Meluncur ke hadapan sambil kebal seketika dan menebas sasaran.',
        pattern: AttackPattern.dash,
        hit: const HitDefinition(
          baseDamage: 22,
          attackScaling: 1.25,
          poiseDamage: 28,
          knockback: 170,
        ),
        cooldown: 2.4,
        windup: 0.1,
        activeTime: 0.18,
        recovery: 0.25,
        range: 125,
        resourceCost: 25,
        dashDistance: 90,
        selfInvulnerability: 0.2,
      ),
    ],
  );

  static final aegis = ActorBlueprint(
    id: 'aegis',
    name: 'Aegis',
    faction: ActorFaction.hero,
    isPlayableAvatar: true,
    stats: CombatStats(
      maxHealth: 165,
      attackPower: 14,
      defense: 25,
      moveSpeed: 125,
      criticalChance: 0.05,
      maxPoise: 70,
      resistances: const {DamageType.physical: 0.08},
    ),
    spriteFrames: const [
      'characters/tile_0002.png',
      'characters/tile_0003.png',
    ],
    skills: [
      SkillDefinition(
        id: 'shield_breaker',
        name: 'Shield Breaker',
        description: 'Hentaman berat yang memberi poise damage tinggi.',
        pattern: AttackPattern.melee,
        hit: const HitDefinition(
          baseDamage: 15,
          attackScaling: 1.1,
          poiseDamage: 35,
          knockback: 145,
        ),
        cooldown: 0.65,
        windup: 0.18,
        activeTime: 0.12,
        recovery: 0.35,
        range: 62,
      ),
      SkillDefinition(
        id: 'guardian_quake',
        name: 'Guardian Quake',
        description: 'Menghentam tanah dan mencederakan sehingga empat musuh berdekatan.',
        pattern: AttackPattern.area,
        hit: const HitDefinition(
          baseDamage: 20,
          attackScaling: 1.2,
          poiseDamage: 42,
          knockback: 190,
          statusEffect: stunned,
        ),
        cooldown: 5,
        windup: 0.42,
        activeTime: 0.18,
        recovery: 0.5,
        range: 105,
        resourceCost: 38,
        maximumTargets: 4,
      ),
    ],
  );

  static final pyra = ActorBlueprint(
    id: 'pyra',
    name: 'Pyra',
    faction: ActorFaction.hero,
    isPlayableAvatar: true,
    stats: CombatStats(
      maxHealth: 95,
      attackPower: 23,
      defense: 8,
      moveSpeed: 145,
      maxResource: 120,
      resourceRegenPerSecond: 16,
      criticalChance: 0.1,
      resistances: const {DamageType.fire: 0.3},
    ),
    spriteFrames: const [
      'characters/tile_0004.png',
      'characters/tile_0005.png',
    ],
    skills: [
      SkillDefinition(
        id: 'ember_orb',
        name: 'Ember Orb',
        description: 'Peluru api jarak jauh yang menambah stack Burning.',
        pattern: AttackPattern.projectile,
        hit: const HitDefinition(
          baseDamage: 10,
          attackScaling: 0.9,
          damageType: DamageType.fire,
          poiseDamage: 8,
          knockback: 55,
          statusEffect: burning,
        ),
        cooldown: 0.7,
        windup: 0.16,
        activeTime: 0.08,
        recovery: 0.2,
        range: 260,
        resourceCost: 8,
      ),
      SkillDefinition(
        id: 'solar_burst',
        name: 'Solar Burst',
        description: 'Letupan api sekeliling yang mengenai ramai sasaran.',
        pattern: AttackPattern.area,
        hit: const HitDefinition(
          baseDamage: 26,
          attackScaling: 1.35,
          damageType: DamageType.fire,
          poiseDamage: 25,
          knockback: 165,
          statusEffect: burning,
        ),
        cooldown: 4.2,
        windup: 0.34,
        activeTime: 0.16,
        recovery: 0.45,
        range: 115,
        resourceCost: 42,
        maximumTargets: 5,
      ),
    ],
  );

  static final volt = ActorBlueprint(
    id: 'volt',
    name: 'Volt',
    faction: ActorFaction.hero,
    isPlayableAvatar: true,
    stats: CombatStats(
      maxHealth: 105,
      attackPower: 16,
      defense: 10,
      moveSpeed: 185,
      criticalChance: 0.18,
      criticalMultiplier: 1.8,
      maxPoise: 34,
      resistances: const {DamageType.lightning: 0.25},
    ),
    spriteFrames: const [
      'characters/tile_0006.png',
      'characters/tile_0007.png',
    ],
    skills: [
      SkillDefinition(
        id: 'spark_jab',
        name: 'Spark Jab',
        description: 'Serangan sangat pantas dengan peluang crit yang tinggi.',
        pattern: AttackPattern.melee,
        hit: const HitDefinition(
          baseDamage: 8,
          attackScaling: 0.8,
          damageType: DamageType.lightning,
          poiseDamage: 9,
          knockback: 75,
        ),
        cooldown: 0.22,
        windup: 0.04,
        activeTime: 0.07,
        recovery: 0.11,
        range: 52,
      ),
      SkillDefinition(
        id: 'thunder_step',
        name: 'Thunder Step',
        description: 'Dash elektrik yang menembusi sehingga tiga musuh.',
        pattern: AttackPattern.dash,
        hit: const HitDefinition(
          baseDamage: 18,
          attackScaling: 1.15,
          damageType: DamageType.lightning,
          poiseDamage: 18,
          knockback: 125,
          statusEffect: stunned,
        ),
        cooldown: 3,
        windup: 0.07,
        activeTime: 0.22,
        recovery: 0.2,
        range: 155,
        resourceCost: 30,
        dashDistance: 120,
        selfInvulnerability: 0.16,
        maximumTargets: 3,
      ),
    ],
  );

  static final mimicCube = ActorBlueprint(
    id: 'mimic_cube',
    name: 'Mimic Cube',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 58,
      attackPower: 10,
      defense: 6,
      moveSpeed: 80,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 24,
    ),
    spriteFrames: const [
      'characters/tile_0011.png',
      'characters/tile_0012.png',
    ],
    skills: [
      SkillDefinition(
        id: 'cube_chomp',
        name: 'Cube Chomp',
        description: 'Gigitan jarak dekat selepas windup yang mudah dibaca.',
        pattern: AttackPattern.melee,
        hit: const HitDefinition(
          baseDamage: 9,
          attackScaling: 0.8,
          poiseDamage: 12,
          knockback: 85,
        ),
        cooldown: 1.25,
        windup: 0.34,
        activeTime: 0.12,
        recovery: 0.42,
        range: 48,
      ),
    ],
  );

  static final emberWisp = ActorBlueprint(
    id: 'ember_wisp',
    name: 'Ember Wisp',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 42,
      attackPower: 12,
      defense: 3,
      moveSpeed: 110,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 18,
      resistances: const {DamageType.fire: 0.5},
    ),
    spriteFrames: const [
      'characters/tile_0013.png',
      'characters/tile_0014.png',
    ],
    skills: [
      SkillDefinition(
        id: 'cinder_spit',
        name: 'Cinder Spit',
        description: 'Peluru api perlahan yang menyebabkan Burning.',
        pattern: AttackPattern.projectile,
        hit: const HitDefinition(
          baseDamage: 7,
          attackScaling: 0.75,
          damageType: DamageType.fire,
          poiseDamage: 6,
          knockback: 45,
          statusEffect: burning,
        ),
        cooldown: 1.8,
        windup: 0.5,
        activeTime: 0.1,
        recovery: 0.35,
        range: 220,
      ),
    ],
  );

  static final drillSpike = ActorBlueprint(
    id: 'drill_spike',
    name: 'Drill Spike',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 76,
      attackPower: 13,
      defense: 14,
      moveSpeed: 95,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 44,
    ),
    spriteFrames: const [
      'characters/tile_0015.png',
      'characters/tile_0016.png',
      'characters/tile_0017.png',
    ],
    skills: [
      SkillDefinition(
        id: 'drill_charge',
        name: 'Drill Charge',
        description: 'Charge lurus yang kuat tetapi mempunyai windup panjang.',
        pattern: AttackPattern.dash,
        hit: const HitDefinition(
          baseDamage: 14,
          attackScaling: 1.1,
          poiseDamage: 25,
          knockback: 155,
        ),
        cooldown: 2.8,
        windup: 0.62,
        activeTime: 0.25,
        recovery: 0.55,
        range: 135,
        dashDistance: 105,
      ),
    ],
  );

  static final guardBot = ActorBlueprint(
    id: 'guard_bot',
    name: 'Guard Bot',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 92,
      attackPower: 15,
      defense: 18,
      moveSpeed: 70,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 52,
    ),
    spriteFrames: const [
      'characters/tile_0018.png',
      'characters/tile_0019.png',
      'characters/tile_0020.png',
    ],
    skills: [
      SkillDefinition(
        id: 'guard_bolt',
        name: 'Guard Bolt',
        description: 'Tembakan elektrik tepat dari jarak sederhana.',
        pattern: AttackPattern.projectile,
        hit: const HitDefinition(
          baseDamage: 11,
          attackScaling: 0.9,
          damageType: DamageType.lightning,
          poiseDamage: 10,
          knockback: 70,
        ),
        cooldown: 1.55,
        windup: 0.42,
        activeTime: 0.1,
        recovery: 0.38,
        range: 250,
      ),
    ],
  );

  static final monitorGolem = ActorBlueprint(
    id: 'monitor_golem',
    name: 'Monitor Golem',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 480,
      attackPower: 24,
      defense: 28,
      moveSpeed: 52,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 130,
      resistances: const {
        DamageType.physical: 0.12,
        DamageType.lightning: -0.2,
      },
    ),
    spriteFrames: const [
      'characters/tile_0021.png',
      'characters/tile_0022.png',
      'characters/tile_0023.png',
    ],
    skills: [
      SkillDefinition(
        id: 'golem_slam',
        name: 'Golem Slam',
        description: 'Hentaman kawasan dekat dengan knockback sangat tinggi.',
        pattern: AttackPattern.area,
        hit: const HitDefinition(
          baseDamage: 20,
          attackScaling: 1,
          poiseDamage: 38,
          knockback: 220,
          statusEffect: stunned,
        ),
        cooldown: 3.3,
        windup: 0.78,
        activeTime: 0.2,
        recovery: 0.72,
        range: 110,
        maximumTargets: 3,
      ),
      SkillDefinition(
        id: 'screen_beam',
        name: 'Screen Beam',
        description: 'Laser jarak jauh; windup lama memberi ruang untuk mengelak.',
        pattern: AttackPattern.projectile,
        hit: const HitDefinition(
          baseDamage: 28,
          attackScaling: 1.2,
          damageType: DamageType.lightning,
          poiseDamage: 22,
          knockback: 125,
          invulnerabilityAfterHit: 0.45,
        ),
        cooldown: 5.2,
        windup: 1.05,
        activeTime: 0.25,
        recovery: 0.85,
        range: 360,
      ),
    ],
  );

  static final scoutDrone = ActorBlueprint(
    id: 'scout_drone',
    name: 'Scout Drone',
    faction: ActorFaction.enemy,
    stats: CombatStats(
      maxHealth: 48,
      attackPower: 11,
      defense: 5,
      moveSpeed: 135,
      maxResource: 0,
      resourceRegenPerSecond: 0,
      maxPoise: 20,
    ),
    spriteFrames: const [
      'characters/tile_0024.png',
      'characters/tile_0025.png',
      'characters/tile_0026.png',
    ],
    skills: [
      SkillDefinition(
        id: 'drone_swoop',
        name: 'Drone Swoop',
        description: 'Terjunan laju ke arah hero, kemudian berundur.',
        pattern: AttackPattern.dash,
        hit: const HitDefinition(
          baseDamage: 9,
          attackScaling: 0.85,
          poiseDamage: 12,
          knockback: 95,
        ),
        cooldown: 2,
        windup: 0.36,
        activeTime: 0.22,
        recovery: 0.5,
        range: 145,
        dashDistance: 100,
      ),
    ],
  );

  static final List<ActorBlueprint> playableAvatars = [nova, aegis, pyra, volt];

  static final List<ActorBlueprint> mobs = [
    mimicCube,
    emberWisp,
    drillSpike,
    guardBot,
    monitorGolem,
    scoutDrone,
  ];

  static final List<ActorBlueprint> all = [...playableAvatars, ...mobs];

  static ActorBlueprint byId(String id) => all.firstWhere((actor) => actor.id == id);

  static void validate() {
    final actorIds = all.map((actor) => actor.id).toSet();
    if (actorIds.length != all.length) {
      throw StateError('Id actor berulang dalam katalog.');
    }
    for (final actor in all) {
      if (actor.skills.isEmpty) {
        throw StateError('${actor.id} tidak mempunyai skill serangan.');
      }
      for (final skill in actor.skills) {
        if (skill.hit.baseDamage + actor.stats.attackPower * skill.hit.attackScaling <= 0) {
          throw StateError('${actor.id}/${skill.id} tidak menghasilkan damage.');
        }
      }
    }
  }
}

