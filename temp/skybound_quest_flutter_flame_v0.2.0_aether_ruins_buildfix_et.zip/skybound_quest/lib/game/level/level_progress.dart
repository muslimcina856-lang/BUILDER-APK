class LevelProgress {
  LevelProgress({required this.totalRelics});

  final int totalRelics;
  int relicsCollected = 0;
  int enemiesDefeated = 0;
  bool bossDefeated = false;

  bool get hasAllRelics => relicsCollected >= totalRelics;
  bool get portalUnlocked => hasAllRelics && bossDefeated;

  bool collectRelic() {
    if (relicsCollected >= totalRelics) return false;
    relicsCollected++;
    return true;
  }

  void defeatEnemy({required bool isBoss}) {
    enemiesDefeated++;
    if (isBoss) bossDefeated = true;
  }

  String objectiveText({required int enemiesRemaining}) {
    if (!hasAllRelics) {
      return 'Cari relik langit · $relicsCollected / $totalRelics';
    }
    if (!bossDefeated) {
      return 'Tewaskan Monitor Golem';
    }
    if (enemiesRemaining > 0) {
      return 'Masuk portal · Musuh berbaki $enemiesRemaining';
    }
    return 'Masuk ke portal langit';
  }

  void reset() {
    relicsCollected = 0;
    enemiesDefeated = 0;
    bossDefeated = false;
  }
}
