import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import '../skybound_game.dart';
import 'arena_stage.dart';
import 'combat_actor_component.dart';

class HeroComponent extends CombatActorComponent {
  HeroComponent({
    required SkyboundGame gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
  }) : super(gameRef: gameRef, blueprint: blueprint, position: position);

  static const gravity = 1050.0;
  static const jumpVelocity = -445.0;
  static const coyoteDuration = 0.12;
  static const jumpBufferDuration = 0.15;

  final Vector2 velocity = Vector2.zero();
  double _coyoteRemaining = 0;
  double _jumpBufferRemaining = 0;
  double _stepTimer = 0;
  bool _grounded = false;

  @override
  bool get isGrounded => _grounded;

  @override
  double get motionSpeed => velocity.x.abs();

  @override
  double get verticalSpeed => velocity.y;

  @override
  void update(double dt) {
    super.update(dt);
    if (state.isDead || gameRef.phase.value != GamePhase.playing) return;

    final input = gameRef.input;
    if (input.consumePrimary()) tryUseSkill(blueprint.skills.first.id);
    if (input.consumeSecondary() && blueprint.skills.length > 1) {
      tryUseSkill(blueprint.skills[1].id);
    }
    if (input.consumeJump()) _jumpBufferRemaining = jumpBufferDuration;

    _coyoteRemaining = _grounded
        ? coyoteDuration
        : (_coyoteRemaining - dt).clamp(0, coyoteDuration).toDouble();
    _jumpBufferRemaining =
        (_jumpBufferRemaining - dt).clamp(0, jumpBufferDuration).toDouble();

    final movementAllowed = state.canAct;
    final double axis = movementAllowed ? input.horizontalAxis : 0.0;
    if (axis != 0) facing = axis.sign;
    final castMultiplier = state.skills.isCasting ? 0.48 : 1.0;
    velocity.x = axis * state.effectiveMoveSpeed * castMultiplier + horizontalImpulse;
    horizontalImpulse *= math.pow(0.006, dt).toDouble();

    if (_jumpBufferRemaining > 0 && _coyoteRemaining > 0 && movementAllowed) {
      velocity.y = jumpVelocity;
      _grounded = false;
      _coyoteRemaining = 0;
      _jumpBufferRemaining = 0;
      gameRef.onHeroJump(position);
    }
    if (!input.jumpHeld && velocity.y < -110) velocity.y *= 0.55;

    velocity.y += gravity * dt;
    final previousBottom = position.y + size.y / 2;
    final nextX = (position.x + velocity.x * dt)
        .clamp(24, ArenaStage.worldWidth - 24)
        .toDouble();
    final nextY = position.y + velocity.y * dt;
    final landing = gameRef.stage.landingTop(
      left: nextX - size.x * 0.3,
      right: nextX + size.x * 0.3,
      previousBottom: previousBottom,
      nextBottom: nextY + size.y / 2,
    );
    position.x = nextX;
    if (velocity.y >= 0 && landing != null) {
      final landingSpeed = velocity.y;
      position.y = landing - size.y / 2;
      velocity.y = 0;
      if (!_grounded && landingSpeed > 150) gameRef.onHeroLanded(position, landingSpeed);
      _grounded = true;
    } else {
      position.y = nextY;
      _grounded = false;
    }

    _updateFootsteps(dt, axis);
    _checkHazards();
    if (position.y > ArenaStage.worldHeight + 70) {
      gameRef.handleHeroFall();
    }
  }

  void _updateFootsteps(double dt, double axis) {
    if (!_grounded || axis == 0 || state.skills.isCasting) {
      _stepTimer = 0;
      return;
    }
    _stepTimer -= dt;
    if (_stepTimer <= 0) {
      _stepTimer = 0.34;
      gameRef.onHeroStep();
    }
  }

  void _checkHazards() {
    final bounds = Rect.fromCenter(
      center: Offset(position.x, position.y + 6),
      width: size.x * 0.46,
      height: size.y * 0.68,
    );
    if (gameRef.stage.collidesHazard(bounds)) {
      gameRef.damageHeroFromHazard(knockbackDirection: -facing);
    }
  }

  void teleport(Vector2 target) {
    position.setFrom(target);
    velocity.setZero();
    horizontalImpulse = 0;
    _grounded = false;
    _coyoteRemaining = 0;
    _jumpBufferRemaining = 0;
  }

  @override
  void resetAt(Vector2 target) {
    super.resetAt(target);
    velocity.setZero();
    _grounded = false;
    _coyoteRemaining = 0;
    _jumpBufferRemaining = 0;
    _stepTimer = 0;
  }

  @override
  void receiveKnockback(double impulse) {
    super.receiveKnockback(impulse);
    velocity.y = -145;
    _grounded = false;
  }
}
