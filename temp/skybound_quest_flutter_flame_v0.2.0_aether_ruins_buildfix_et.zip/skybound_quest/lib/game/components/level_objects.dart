import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../skybound_game.dart';

class RelicComponent extends PositionComponent {
  RelicComponent({
    required this.gameRef,
    required Vector2 position,
    required this.index,
  }) : super(position: position, size: Vector2.all(42), anchor: Anchor.center) {
    priority = 20;
  }

  final SkyboundGame gameRef;
  final int index;
  Sprite? _sprite;
  bool active = true;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(await gameRef.images.load('tiles/tile_0067.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (!active || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && !hero.state.isDead && position.distanceTo(hero.position) < 42) {
      active = false;
      gameRef.collectRelic(this);
    }
  }

  void reset() {
    active = true;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    if (!active) return;
    final pulse = (math.sin(_time * 3.6 + index) + 1) / 2;
    final center = Offset(size.x / 2, size.y / 2 + math.sin(_time * 2.2 + index) * 4);
    final glow = Paint()
      ..shader = Gradient.radial(
        center,
        24.0 + pulse * 7.0,
        const [Color(0xAA7EEBFF), Color(0x007EEBFF)],
      );
    canvas.drawCircle(center, 30, glow);
    _sprite?.render(
      canvas,
      position: Vector2(center.dx - 16, center.dy - 16),
      size: Vector2.all(32),
      overridePaint: Paint()..filterQuality = FilterQuality.none,
    );
    canvas.drawCircle(
      center,
      19.0 + pulse * 3.0,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFBDF8FF).withAlpha((90 + pulse * 130).round()),
    );
  }
}

class HealingPickupComponent extends PositionComponent {
  HealingPickupComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2.all(38), anchor: Anchor.center) {
    priority = 20;
  }

  final SkyboundGame gameRef;
  Sprite? _sprite;
  bool active = true;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _sprite = Sprite(await gameRef.images.load('tiles/tile_0044.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (!active || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 38) {
      final healed = hero.state.health.heal(38);
      if (healed > 0) {
        active = false;
        gameRef.collectHealing(position, healed);
      }
    }
  }

  void reset() {
    active = true;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    if (!active) return;
    final bob = math.sin(_time * 2.5) * 3;
    final pulse = (math.sin(_time * 4) + 1) / 2;
    canvas.drawCircle(
      Offset(size.x / 2, size.y / 2 + bob),
      18.0 + pulse * 4.0,
      Paint()..color = const Color(0x44FF506D),
    );
    _sprite?.render(
      canvas,
      position: Vector2(4.0, 4.0 + bob),
      size: Vector2.all(30),
      overridePaint: Paint()..filterQuality = FilterQuality.none,
    );
  }
}

class CheckpointComponent extends PositionComponent {
  CheckpointComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(62, 86), anchor: Anchor.bottomCenter) {
    priority = 8;
  }

  final SkyboundGame gameRef;
  Sprite? _inactiveSprite;
  Sprite? _activeSprite;
  bool activated = false;
  double _time = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _inactiveSprite = Sprite(await gameRef.images.load('tiles/tile_0111.png'));
    _activeSprite = Sprite(await gameRef.images.load('tiles/tile_0112.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (activated || gameRef.phase.value != GamePhase.playing) return;
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 68) {
      activated = true;
      gameRef.activateCheckpoint(this);
    }
  }

  void reset() {
    activated = false;
    _time = 0;
  }

  Vector2 get respawnPoint => Vector2(position.x + 34, position.y - 25);

  @override
  void render(Canvas canvas) {
    final pulse = (math.sin(_time * 3) + 1) / 2;
    if (activated) {
      final beam = Paint()
        ..shader = Gradient.linear(
          Offset(size.x / 2, size.y),
          Offset(size.x / 2, 0),
          [
            const Color(0x005BFFF1),
            const Color(0x885BFFF1).withAlpha((70 + pulse * 70).round()),
          ],
        );
      canvas.drawRect(Rect.fromLTWH(8, -70, size.x - 16, size.y + 70), beam);
    }
    final sprite = activated ? _activeSprite : _inactiveSprite;
    sprite?.render(
      canvas,
      position: Vector2(2, 10),
      size: Vector2(58, 72),
      overridePaint: Paint()..filterQuality = FilterQuality.none,
    );
  }
}

class GoalPortalComponent extends PositionComponent {
  GoalPortalComponent({required this.gameRef, required Vector2 position})
      : super(position: position, size: Vector2(112, 150), anchor: Anchor.bottomCenter) {
    priority = 12;
  }

  final SkyboundGame gameRef;
  Sprite? _left;
  Sprite? _right;
  double _time = 0;
  bool _entered = false;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _left = Sprite(await gameRef.images.load('tiles/tile_0093.png'));
    _right = Sprite(await gameRef.images.load('tiles/tile_0094.png'));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    if (_entered || !gameRef.portalUnlocked || gameRef.phase.value != GamePhase.playing) {
      return;
    }
    final hero = gameRef.heroOrNull;
    if (hero != null && position.distanceTo(hero.position) < 62) {
      _entered = true;
      gameRef.completeLevel();
    }
  }

  void reset() {
    _entered = false;
    _time = 0;
  }

  @override
  void render(Canvas canvas) {
    final unlocked = gameRef.portalUnlocked;
    final pulse = (math.sin(_time * 2.8) + 1) / 2;
    final center = Offset(size.x / 2, 78);
    final portalColor = unlocked ? const Color(0xFF62F4FF) : const Color(0xFF738097);
    canvas.drawOval(
      Rect.fromCenter(
        center: center,
        width: 66.0 + pulse * 8.0,
        height: 104.0 + pulse * 8.0,
      ),
      Paint()
        ..shader = Gradient.radial(
          center,
          62,
          [portalColor.withAlpha(unlocked ? 150 : 50), portalColor.withAlpha(0)],
        ),
    );
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 56, height: 98),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = portalColor.withAlpha(unlocked ? 230 : 120),
    );
    _left?.render(
      canvas,
      position: Vector2(3, 38),
      size: Vector2(52, 88),
      overridePaint: Paint()..filterQuality = FilterQuality.none,
    );
    _right?.render(
      canvas,
      position: Vector2(57, 38),
      size: Vector2(52, 88),
      overridePaint: Paint()..filterQuality = FilterQuality.none,
    );
    if (!unlocked) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: center, width: 28, height: 25),
          const Radius.circular(4),
        ),
        Paint()..color = const Color(0xDD26334D),
      );
      canvas.drawArc(
        Rect.fromCenter(center: center.translate(0, -14), width: 18, height: 22),
        math.pi,
        math.pi,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 5
          ..color = const Color(0xFFC7D0DF),
      );
    }
  }
}
