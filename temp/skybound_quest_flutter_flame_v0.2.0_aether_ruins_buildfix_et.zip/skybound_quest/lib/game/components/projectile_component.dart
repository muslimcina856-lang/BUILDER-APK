import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import 'combat_actor_component.dart';
import 'combat_effects.dart';

class ProjectileComponent extends TransientComponent {
  ProjectileComponent({
    required this.owner,
    required this.skill,
    required Vector2 position,
    required this.velocity,
    required this.color,
  })  : radius = skill.id == 'screen_beam' ? 12.0 : 9.0,
        super(
          position: position,
          size: Vector2.all(skill.id == 'screen_beam' ? 28.0 : 22.0),
        );

  final CombatActorComponent owner;
  final SkillDefinition skill;
  final Vector2 velocity;
  final Color color;
  final double radius;
  double _travelled = 0;
  double _trailTimer = 0;
  int _targetsHit = 0;
  final Set<CombatActorComponent> _hitTargets = {};

  @override
  void update(double dt) {
    super.update(dt);
    final delta = velocity * dt;
    position += delta;
    _travelled += delta.length;
    _trailTimer -= dt;
    if (_trailTimer <= 0) {
      _trailTimer = skill.id == 'screen_beam' ? 0.025 : 0.055;
      owner.gameRef.addTransient(
        TrailPuffEffect(
          position: position.clone(),
          color: color,
          radius: skill.id == 'screen_beam' ? 8.0 : 5.0,
        ),
      );
    }

    final collisionBounds = Rect.fromCircle(
      center: Offset(position.x, position.y),
      radius: radius * 0.5,
    );
    if (owner.gameRef.stage.collidesSolid(collisionBounds)) {
      _expire();
      return;
    }

    for (final target in owner.hostileTargets) {
      if (_hitTargets.contains(target)) continue;
      final hitRadius = radius + math.min(target.size.x, target.size.y) * 0.34;
      if (position.distanceTo(target.position) > hitRadius) continue;

      _hitTargets.add(target);
      owner.resolveSkillHit(
        target,
        skill,
        impactPosition: position,
      );
      _targetsHit++;
      if (_targetsHit >= skill.maximumTargets) {
        removeFromParent();
        return;
      }
    }

    if (_travelled >= skill.range + 36) _expire();
  }

  void _expire() {
    owner.gameRef.addTransient(
      ImpactEffect(
        position: position.clone(),
        color: color,
        heavy: skill.id == 'screen_beam',
        seed: owner.gameRef.random.nextInt(1 << 30),
      ),
    );
    removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final center = Offset(size.x / 2, size.y / 2);
    final direction = velocity.clone();
    if (direction.length2 > 0) direction.normalize();
    final trailEnd = center.translate(-direction.x * 30, -direction.y * 30);
    canvas.drawLine(
      trailEnd,
      center,
      Paint()
        ..strokeWidth = skill.id == 'screen_beam' ? 10.0 : 6.0
        ..strokeCap = StrokeCap.round
        ..color = color.withAlpha(85),
    );
    canvas.drawCircle(
      center,
      radius + 7.0,
      Paint()
        ..shader = Gradient.radial(
          center,
          radius + 7.0,
          [color.withAlpha(145), color.withAlpha(0)],
        ),
    );
    final core = Path()
      ..moveTo(center.dx, center.dy - radius)
      ..lineTo(center.dx + radius, center.dy)
      ..lineTo(center.dx, center.dy + radius)
      ..lineTo(center.dx - radius, center.dy)
      ..close();
    canvas.drawPath(core, Paint()..color = color);
    canvas.drawCircle(
      center,
      math.max(2, radius * 0.34).toDouble(),
      Paint()..color = const Color(0xFFFFFFFF),
    );
  }
}
