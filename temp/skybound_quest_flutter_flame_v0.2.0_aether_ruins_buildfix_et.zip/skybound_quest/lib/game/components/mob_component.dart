import 'dart:math' as math;

import 'package:flame/components.dart';

import '../combat/combat_models.dart';
import '../skybound_game.dart';
import 'arena_stage.dart';
import 'combat_actor_component.dart';

class MobComponent extends CombatActorComponent {
  MobComponent({
    required SkyboundGame gameRef,
    required ActorBlueprint blueprint,
    required Vector2 position,
  })  : _flying = blueprint.id == 'ember_wisp' || blueprint.id == 'scout_drone',
        super(
          gameRef: gameRef,
          blueprint: blueprint,
          position: position,
          size: blueprint.id == 'monitor_golem'
              ? Vector2.all(86)
              : blueprint.id == 'scout_drone'
                  ? Vector2(58, 46)
                  : Vector2.all(52),
        );

  final bool _flying;
  final Vector2 velocity = Vector2.zero();
  double _decisionTimer = 0;
  double _desiredAxis = 0;
  double _patrolDirection = -1;
  double _hoverClock = 0;
  double _hopCooldown = 0;
  int _skillIndex = 0;
  bool _grounded = false;
  bool _enragedAnnounced = false;

  @override
  bool get isGrounded => _grounded && !_flying;

  @override
  double get motionSpeed => velocity.x.abs();

  @override
  double get verticalSpeed => velocity.y;

  @override
  void update(double dt) {
    super.update(dt);
    if (state.isDead) return;
    if (gameRef.phase.value != GamePhase.playing || gameRef.hero.state.isDead) {
      _desiredAxis = 0;
      return;
    }

    _hoverClock += dt;
    _hopCooldown = math.max(0, _hopCooldown - dt).toDouble();
    _decisionTimer -= dt;
    if (_decisionTimer <= 0) {
      _decisionTimer = blueprint.id == 'monitor_golem' ? 0.08 : 0.12;
      _makeDecision();
    }

    if (_flying) {
      _moveFlying(dt);
    } else {
      _moveGrounded(dt);
    }
  }

  void _makeDecision() {
    final hero = gameRef.hero;
    final delta = hero.position - position;
    final distance = delta.length;

    if (distance > blueprint.aggroRange) {
      _patrol();
      return;
    }
    if (delta.x.abs() > 0.01) facing = delta.x.sign;
    if (!state.canAct || state.skills.isCasting) {
      _desiredAxis = 0;
      return;
    }

    switch (blueprint.id) {
      case 'ember_wisp':
      case 'guard_bot':
        _rangedDecision(distance, delta);
        break;
      case 'scout_drone':
        _droneDecision(distance, delta);
        break;
      case 'monitor_golem':
        _bossDecision(distance, delta);
        break;
      default:
        _meleeDecision(distance, delta);
        break;
    }
  }

  void _patrol() {
    final offset = position.x - spawnPosition.x;
    if (offset.abs() > 78) _patrolDirection = -offset.sign;
    _desiredAxis = _patrolDirection;
  }

  void _meleeDecision(double distance, Vector2 delta) {
    final skill = blueprint.skills[_skillIndex % blueprint.skills.length];
    if (distance <= skill.range * 0.92 && delta.y.abs() < 78) {
      final result = tryUseSkill(skill.id);
      if (result.accepted) {
        _skillIndex++;
        _desiredAxis = 0;
      }
      return;
    }
    _desiredAxis = delta.x.sign;
    if (blueprint.id == 'mimic_cube' &&
        _grounded &&
        _hopCooldown <= 0 &&
        distance < 175) {
      velocity.y = -235;
      _grounded = false;
      _hopCooldown = 1.1;
    }
  }

  void _rangedDecision(double distance, Vector2 delta) {
    final skill = blueprint.skills.first;
    final preferred = skill.range * 0.62;
    if (distance <= skill.range && delta.y.abs() < 120) {
      final result = tryUseSkill(skill.id);
      if (result.accepted) {
        _desiredAxis = 0;
        return;
      }
    }
    if (distance < preferred * 0.65) {
      _desiredAxis = -delta.x.sign;
    } else if (distance > preferred) {
      _desiredAxis = delta.x.sign;
    } else {
      _desiredAxis = 0;
    }
  }

  void _droneDecision(double distance, Vector2 delta) {
    final skill = blueprint.skills.first;
    if (distance <= skill.range && delta.y.abs() < 155) {
      final result = tryUseSkill(skill.id);
      if (result.accepted) {
        _desiredAxis = 0;
        return;
      }
    }
    _desiredAxis = distance < 110 ? -delta.x.sign : delta.x.sign;
  }

  void _bossDecision(double distance, Vector2 delta) {
    final healthRatio = state.health.ratio;
    if (healthRatio < 0.5 && !_enragedAnnounced) {
      _enragedAnnounced = true;
      gameRef.onBossEnraged();
    }
    final closeSkill = blueprint.skills.first;
    final rangedSkill = blueprint.skills.length > 1 ? blueprint.skills[1] : closeSkill;
    final skill = distance < 135 ? closeSkill : rangedSkill;
    if (distance <= skill.range && delta.y.abs() < 135) {
      final result = tryUseSkill(skill.id);
      if (result.accepted) {
        _desiredAxis = 0;
        return;
      }
    }
    _desiredAxis = delta.x.sign;
  }

  void _moveFlying(double dt) {
    final hero = gameRef.hero;
    final speedMultiplier = blueprint.id == 'scout_drone' ? 1.12 : 0.88;
    final droneSwooping =
        blueprint.id == 'scout_drone' && state.skills.isCasting;
    final desiredY = blueprint.id == 'scout_drone'
        ? hero.position.y -
            (droneSwooping ? 8 : 62) +
            math.sin(_hoverClock * 2.8) * (droneSwooping ? 8 : 26)
        : spawnPosition.y + math.sin(_hoverClock * 2.1) * 34;
    final castSlowdown = state.skills.isCasting ? 0.24 : 1.0;
    velocity.x = _desiredAxis * state.effectiveMoveSpeed * speedMultiplier * castSlowdown +
        horizontalImpulse;
    velocity.y += (desiredY - position.y) * 3.4 * dt;
    velocity.y *= math.pow(0.08, dt).toDouble();
    horizontalImpulse *= math.pow(0.02, dt).toDouble();
    position += velocity * dt;
    position.x = position.x.clamp(28, ArenaStage.worldWidth - 28).toDouble();
    position.y = position.y.clamp(95, 350).toDouble();
    _grounded = false;
  }

  void _moveGrounded(double dt) {
    final enragedMultiplier = blueprint.id == 'monitor_golem' && state.health.ratio < 0.5
        ? 1.3
        : 1.0;
    final castSlowdown = state.skills.isCasting ? 0.08 : 1.0;
    velocity.x = _desiredAxis *
            state.effectiveMoveSpeed *
            enragedMultiplier *
            castSlowdown +
        horizontalImpulse;
    horizontalImpulse *= math.pow(0.018, dt).toDouble();

    final feet = position.y + size.y / 2;
    var nextX = position.x + velocity.x * dt;
    if (_grounded && velocity.x.abs() > 1 && horizontalImpulse.abs() < 55) {
      final direction = velocity.x.sign;
      final probeX = nextX + direction * size.x * 0.36;
      if (!gameRef.stage.hasSupportAhead(x: probeX, feetY: feet + 3)) {
        nextX = position.x;
        velocity.x = 0;
        _patrolDirection = -direction;
      }
    }

    velocity.y += HeroLikePhysics.gravity * dt;
    final previousBottom = feet;
    final nextY = position.y + velocity.y * dt;
    final landing = gameRef.stage.landingTop(
      left: nextX - size.x * 0.3,
      right: nextX + size.x * 0.3,
      previousBottom: previousBottom,
      nextBottom: nextY + size.y / 2,
    );
    position.x = nextX.clamp(24, ArenaStage.worldWidth - 24).toDouble();
    if (velocity.y >= 0 && landing != null) {
      position.y = landing - size.y / 2;
      velocity.y = 0;
      _grounded = true;
    } else {
      position.y = nextY;
      _grounded = false;
    }

    if (position.y > ArenaStage.worldHeight + 90) {
      state.health.applyDamage(
        state.health.maximum * 2,
        bypassInvulnerability: true,
      );
    }
  }

  @override
  void receiveKnockback(double impulse) {
    super.receiveKnockback(impulse);
    if (_flying) {
      velocity.y -= 55;
    } else {
      velocity.y = -125;
      _grounded = false;
    }
  }

  @override
  void resetAt(Vector2 target) {
    super.resetAt(target);
    velocity.setZero();
    _decisionTimer = 0;
    _desiredAxis = 0;
    _patrolDirection = -1;
    _hoverClock = 0;
    _hopCooldown = 0;
    _skillIndex = 0;
    _grounded = false;
    _enragedAnnounced = false;
  }
}

abstract final class HeroLikePhysics {
  static const gravity = 1050.0;
}
