import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/sprite.dart';

import '../skybound_game.dart';

class ArenaStage extends PositionComponent {
  ArenaStage({required this.gameRef})
      : platforms = const [
          Rect.fromLTWH(-120, 390, 800, 100),
          Rect.fromLTWH(760, 390, 720, 100),
          Rect.fromLTWH(1580, 390, 760, 100),
          Rect.fromLTWH(2440, 390, 920, 100),
          Rect.fromLTWH(330, 305, 180, 24),
          Rect.fromLTWH(550, 235, 170, 24),
          Rect.fromLTWH(875, 305, 180, 24),
          Rect.fromLTWH(1130, 300, 170, 24),
          Rect.fromLTWH(1320, 225, 170, 24),
          Rect.fromLTWH(1710, 300, 180, 24),
          Rect.fromLTWH(1950, 225, 190, 24),
          Rect.fromLTWH(2180, 150, 170, 24),
          Rect.fromLTWH(2570, 300, 180, 24),
          Rect.fromLTWH(2820, 235, 180, 24),
        ],
        hazards = const [
          Rect.fromLTWH(1010, 365, 90, 25),
          Rect.fromLTWH(1845, 365, 72, 25),
          Rect.fromLTWH(2245, 365, 72, 25),
          Rect.fromLTWH(2685, 365, 72, 25),
        ],
        super(position: Vector2.zero(), size: Vector2(3360, 560)) {
    priority = -100;
  }

  final SkyboundGame gameRef;
  final List<Rect> platforms;
  final List<Rect> hazards;
  final Map<int, Sprite> _tiles = {};
  final Map<int, Sprite> _backgrounds = {};
  final Paint _pixelPaint = Paint()..filterQuality = FilterQuality.none;
  final Paint _farPaint = Paint()
    ..filterQuality = FilterQuality.none
    ..colorFilter = const ColorFilter.mode(
      Color(0xFF31536A),
      BlendMode.modulate,
    );
  final Paint _midPaint = Paint()
    ..filterQuality = FilterQuality.none
    ..colorFilter = const ColorFilter.mode(
      Color(0xFF2F786A),
      BlendMode.modulate,
    );
  double _time = 0;

  static const double worldWidth = 3360;
  static const double worldHeight = 560;

  static const _tileIndexes = <int>{
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    29,
    44,
    67,
    69,
    84,
    85,
    88,
    96,
    97,
    105,
    111,
    112,
    124,
    125,
    128,
    130,
    145,
    151,
  };

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    for (final index in _tileIndexes) {
      _tiles[index] = Sprite(
        await gameRef.images.load('tiles/tile_${index.toString().padLeft(4, '0')}.png'),
      );
    }
    for (final index in const [8, 9, 10, 11, 14, 15]) {
      _backgrounds[index] = Sprite(
        await gameRef.images
            .load('backgrounds/tile_${index.toString().padLeft(4, '0')}.png'),
      );
    }
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
  }

  double? landingTop({
    required double left,
    required double right,
    required double previousBottom,
    required double nextBottom,
  }) {
    double? nearest;
    for (final platform in platforms) {
      final overlaps = right > platform.left + 3 && left < platform.right - 3;
      final crossesTop =
          previousBottom <= platform.top + 4 && nextBottom >= platform.top;
      if (overlaps &&
          crossesTop &&
          (nearest == null || platform.top < nearest)) {
        nearest = platform.top;
      }
    }
    return nearest;
  }

  Rect? supportingPlatform({
    required double x,
    required double feetY,
    double maximumDrop = 34,
  }) {
    Rect? best;
    var bestDistance = double.infinity;
    for (final platform in platforms) {
      if (x < platform.left + 8 || x > platform.right - 8) continue;
      final distance = platform.top - feetY;
      if (distance < -8 || distance > maximumDrop) continue;
      if (distance.abs() < bestDistance) {
        bestDistance = distance.abs();
        best = platform;
      }
    }
    return best;
  }

  bool hasSupportAhead({
    required double x,
    required double feetY,
    double maximumDrop = 30,
  }) =>
      supportingPlatform(x: x, feetY: feetY, maximumDrop: maximumDrop) != null;

  bool collidesHazard(Rect actorBounds) {
    for (final hazard in hazards) {
      if (hazard.overlaps(actorBounds)) return true;
    }
    return false;
  }

  bool collidesSolid(Rect bounds) {
    for (final platform in platforms) {
      if (platform.overlaps(bounds)) return true;
    }
    return false;
  }

  @override
  void render(Canvas canvas) {
    _drawSky(canvas);
    _drawFarScenery(canvas);
    _drawMidScenery(canvas);
    for (final platform in platforms) {
      _drawPlatform(canvas, platform);
    }
    _drawHazards(canvas);
    _drawDecorations(canvas);
    _drawAmbientLights(canvas);
  }

  void _drawSky(Canvas canvas) {
    final sky = Paint()
      ..shader = Gradient.linear(
        const Offset(0, 0),
        Offset(0, size.y),
        const [
          Color(0xFF091A38),
          Color(0xFF174D72),
          Color(0xFF55A98B),
        ],
        const [0, 0.58, 1],
      );
    canvas.drawRect(Offset.zero & Size(size.x, size.y), sky);

    final stars = Paint()..color = const Color(0xAABDF8FF);
    for (var i = 0; i < 58; i++) {
      final x = 30.0 + i.toDouble() * 57.0;
      final y = 25.0 + ((i * 37) % 120).toDouble();
      final side = i % 7 == 0 ? 2.5 : 1.3;
      canvas.drawRect(
        Rect.fromCenter(center: Offset(x, y), width: side, height: side),
        stars,
      );
    }

    final moonGlow = Paint()
      ..shader = Gradient.radial(
        const Offset(485, 90),
        100,
        const [Color(0x88DDF7FF), Color(0x00DDF7FF)],
      );
    canvas.drawCircle(const Offset(485, 90), 100, moonGlow);
    canvas.drawCircle(
      const Offset(485, 90),
      31,
      Paint()..color = const Color(0xFFD8F2EB),
    );
  }

  void _drawFarScenery(Canvas canvas) {
    const variants = [8, 9, 10, 11];
    for (var i = 0; i < 18; i++) {
      final sprite = _backgrounds[variants[i % variants.length]];
      if (sprite == null) continue;
      sprite.render(
        canvas,
        position: Vector2(
          i.toDouble() * 192.0 - 20.0,
          95.0 + (i % 3).toDouble() * 12.0,
        ),
        size: Vector2.all(210),
        overridePaint: _farPaint,
      );
    }
  }

  void _drawMidScenery(Canvas canvas) {
    for (var i = 0; i < 18; i++) {
      final sprite = _backgrounds[i.isEven ? 14 : 15];
      if (sprite == null) continue;
      sprite.render(
        canvas,
        position: Vector2(
          i.toDouble() * 190.0 - 35.0,
          195.0 + (i % 2).toDouble() * 8.0,
        ),
        size: Vector2.all(215),
        overridePaint: _midPaint,
      );
    }
    final mist = Paint()..color = const Color(0x1832E2C3);
    canvas.drawRect(Rect.fromLTWH(0, 322, size.x, 68), mist);
    final abyss = Paint()
      ..shader = Gradient.linear(
        const Offset(0, 382),
        Offset(0, size.y),
        const [Color(0xFF153F4D), Color(0xFF06111F)],
      );
    canvas.drawRect(Rect.fromLTWH(0, 382, size.x, size.y - 382), abyss);
  }

  void _drawPlatform(Canvas canvas, Rect platform) {
    const tileSize = 36.0;
    final columns = math.max(1, (platform.width / tileSize).ceil()).toInt();
    final rows = math.max(1, (platform.height / tileSize).ceil()).toInt();
    for (var row = 0; row < rows; row++) {
      for (var column = 0; column < columns; column++) {
        final isTop = row == 0;
        final index = isTop
            ? (column == 0
                ? 0
                : column == columns - 1
                    ? 3
                    : (column.isEven ? 1 : 2))
            : (column + row).isEven
                ? 4
                : 5;
        final sprite = _tiles[index];
        if (sprite == null) continue;
        final drawWidth = math
            .min(tileSize, platform.right - (platform.left + column * tileSize))
            .toDouble();
        final drawHeight = math
            .min(tileSize, platform.bottom - (platform.top + row * tileSize))
            .toDouble();
        sprite.render(
          canvas,
          position: Vector2(
            platform.left + column * tileSize,
            platform.top + row * tileSize,
          ),
          size: Vector2(drawWidth, drawHeight),
          overridePaint: _pixelPaint,
        );
      }
    }
    canvas.drawRect(
      Rect.fromLTWH(platform.left, platform.top, platform.width, 3),
      Paint()..color = const Color(0xFF9FF27A),
    );
  }

  void _drawHazards(Canvas canvas) {
    final spike = _tiles[69];
    if (spike == null) return;
    for (final hazard in hazards) {
      final count = math.max(1, (hazard.width / 30).ceil()).toInt();
      for (var i = 0; i < count; i++) {
        spike.render(
          canvas,
          position: Vector2(hazard.left + i * 30, hazard.top - 7),
          size: Vector2(32, 32),
          overridePaint: _pixelPaint,
        );
      }
    }
  }

  void _drawDecorations(Canvas canvas) {
    const decorations = <_Decoration>[
      _Decoration(125, 72, 282, 88, 108),
      _Decoration(124, 190, 330, 56, 56),
      _Decoration(84, 245, 342, 54, 54),
      _Decoration(29, 430, 266, 44, 44),
      _Decoration(96, 800, 335, 52, 52),
      _Decoration(97, 920, 335, 54, 54),
      _Decoration(85, 1185, 250, 54, 54),
      _Decoration(105, 1390, 330, 72, 58),
      _Decoration(111, 1625, 318, 58, 70),
      _Decoration(125, 2010, 135, 78, 94),
      _Decoration(128, 2290, 113, 48, 48),
      _Decoration(130, 2505, 334, 58, 58),
      _Decoration(145, 3005, 330, 48, 48),
    ];
    for (final decoration in decorations) {
      final sprite = _tiles[decoration.tile];
      if (sprite == null) continue;
      sprite.render(
        canvas,
        position: Vector2(decoration.x, decoration.y),
        size: Vector2(decoration.width, decoration.height),
        overridePaint: _pixelPaint,
      );
    }
  }

  void _drawAmbientLights(Canvas canvas) {
    final paint = Paint();
    for (var i = 0; i < 30; i++) {
      final x = 60.0 + i.toDouble() * 107.0;
      final y = 170.0 +
          math.sin(_time * 1.2 + i.toDouble() * 0.73) * 28.0 +
          (i % 4).toDouble() * 37.0;
      final pulse = (math.sin(_time * 2.3 + i) + 1) / 2;
      paint.color = const Color(0xFFB8FFB0).withAlpha((45 + pulse * 115).round());
      canvas.drawCircle(Offset(x, y), 1.5 + pulse * 1.7, paint);
    }
  }
}

class _Decoration {
  const _Decoration(this.tile, this.x, this.y, this.width, this.height);

  final int tile;
  final double x;
  final double y;
  final double width;
  final double height;
}
