enum ActorFaction { hero, enemy, neutral }

enum DamageType { physical, fire, frost, poison, lightning, trueDamage }

enum AttackPattern { melee, projectile, area, dash }

enum StatusType { burning, poisoned, chilled, stunned, armorBroken }

class CombatStats {
  CombatStats({
    required this.maxHealth,
    required this.attackPower,
    required this.defense,
    required this.moveSpeed,
    this.maxResource = 100,
    this.resourceRegenPerSecond = 12,
    this.criticalChance = 0.05,
    this.criticalMultiplier = 1.5,
    this.lifeSteal = 0,
    this.maxPoise = 30,
    Map<DamageType, double>? resistances,
  }) : resistances = Map.unmodifiable(resistances ?? const {}) {
    if (maxHealth <= 0 || attackPower < 0 || defense < 0 || moveSpeed < 0) {
      throw ArgumentError('Stat asas tidak sah.');
    }
    if (maxResource < 0 || resourceRegenPerSecond < 0 || maxPoise <= 0) {
      throw ArgumentError('Resource atau poise tidak sah.');
    }
    if (criticalChance < 0 || criticalChance > 1) {
      throw ArgumentError.value(criticalChance, 'criticalChance');
    }
    if (criticalMultiplier < 1 || lifeSteal < 0 || lifeSteal > 1) {
      throw ArgumentError('Crit multiplier atau life steal tidak sah.');
    }
  }

  final double maxHealth;
  final double attackPower;
  final double defense;
  final double moveSpeed;
  final double maxResource;
  final double resourceRegenPerSecond;
  final double criticalChance;
  final double criticalMultiplier;
  final double lifeSteal;
  final double maxPoise;
  final Map<DamageType, double> resistances;

  double resistanceFor(DamageType type) =>
      (resistances[type] ?? 0).clamp(-0.5, 0.8).toDouble();
}

class StatusEffectSpec {
  const StatusEffectSpec({
    required this.id,
    required this.type,
    required this.duration,
    this.maxStacks = 1,
    this.damagePerTick = 0,
    this.tickInterval = 1,
    this.moveSpeedMultiplier = 1,
    this.preventsAction = false,
  });

  final String id;
  final StatusType type;
  final double duration;
  final int maxStacks;
  final double damagePerTick;
  final double tickInterval;
  final double moveSpeedMultiplier;
  final bool preventsAction;
}

class HitDefinition {
  const HitDefinition({
    required this.baseDamage,
    this.attackScaling = 1,
    this.damageType = DamageType.physical,
    this.poiseDamage = 10,
    this.knockback = 80,
    this.canCritical = true,
    this.bypassesInvulnerability = false,
    this.invulnerabilityAfterHit = 0.32,
    this.statusEffect,
  });

  final double baseDamage;
  final double attackScaling;
  final DamageType damageType;
  final double poiseDamage;
  final double knockback;
  final bool canCritical;
  final bool bypassesInvulnerability;
  final double invulnerabilityAfterHit;
  final StatusEffectSpec? statusEffect;
}

class SkillDefinition {
  SkillDefinition({
    required this.id,
    required this.name,
    required this.description,
    required this.pattern,
    required this.hit,
    required this.cooldown,
    required this.windup,
    required this.activeTime,
    required this.recovery,
    required this.range,
    this.resourceCost = 0,
    this.dashDistance = 0,
    this.selfInvulnerability = 0,
    this.maximumTargets = 1,
  }) {
    if (id.isEmpty || name.isEmpty || description.isEmpty) {
      throw ArgumentError('Setiap skill memerlukan id, nama dan penerangan.');
    }
    if (cooldown < 0 || windup < 0 || activeTime <= 0 || recovery < 0) {
      throw ArgumentError('Timing skill $id tidak sah.');
    }
    if (range <= 0 || resourceCost < 0 || maximumTargets <= 0) {
      throw ArgumentError('Jarak, kos atau sasaran skill $id tidak sah.');
    }
  }

  final String id;
  final String name;
  final String description;
  final AttackPattern pattern;
  final HitDefinition hit;
  final double cooldown;
  final double windup;
  final double activeTime;
  final double recovery;
  final double range;
  final double resourceCost;
  final double dashDistance;
  final double selfInvulnerability;
  final int maximumTargets;

  double get totalCastTime => windup + activeTime + recovery;
}

class ActorBlueprint {
  ActorBlueprint({
    required this.id,
    required this.name,
    required this.faction,
    required this.stats,
    required List<SkillDefinition> skills,
    required List<String> spriteFrames,
    this.isPlayableAvatar = false,
    this.aggroRange = 220,
  })  : skills = List.unmodifiable(skills),
        spriteFrames = List.unmodifiable(spriteFrames) {
    if (id.isEmpty || name.isEmpty) {
      throw ArgumentError('Actor memerlukan id dan nama.');
    }
    if (skills.isEmpty) {
      throw ArgumentError('Actor $id wajib mempunyai sekurang-kurangnya satu skill serangan.');
    }
    if (spriteFrames.isEmpty) {
      throw ArgumentError('Actor $id memerlukan sekurang-kurangnya satu sprite.');
    }
    final uniqueSkills = skills.map((skill) => skill.id).toSet();
    if (uniqueSkills.length != skills.length) {
      throw ArgumentError('Actor $id mempunyai id skill yang berulang.');
    }
  }

  final String id;
  final String name;
  final ActorFaction faction;
  final CombatStats stats;
  final List<SkillDefinition> skills;
  final List<String> spriteFrames;
  final bool isPlayableAvatar;
  final double aggroRange;

  SkillDefinition skillById(String skillId) =>
      skills.firstWhere((skill) => skill.id == skillId);
}

