import 'combat_actor_state.dart';
import 'combat_models.dart';
import 'health_pool.dart';

enum DamageRejection { none, sameFaction, targetDead, invulnerable }

class DamageResolution {
  const DamageResolution({
    required this.rawDamage,
    required this.mitigatedDamage,
    required this.application,
    required this.wasCritical,
    required this.wasStaggered,
    required this.rejection,
    required this.knockback,
  });

  final double rawDamage;
  final double mitigatedDamage;
  final DamageApplication application;
  final bool wasCritical;
  final bool wasStaggered;
  final DamageRejection rejection;
  final double knockback;

  bool get landed => rejection == DamageRejection.none && application.totalApplied > 0;
}

class CombatResolver {
  const CombatResolver({this.allowFriendlyFire = false});

  final bool allowFriendlyFire;

  DamageResolution resolve({
    required CombatActorState attacker,
    required CombatActorState target,
    required HitDefinition hit,
    double criticalRoll = 1,
  }) {
    if (target.isDead) return _rejected(DamageRejection.targetDead);
    if (!allowFriendlyFire &&
        attacker.blueprint.faction == target.blueprint.faction &&
        attacker.blueprint.faction != ActorFaction.neutral) {
      return _rejected(DamageRejection.sameFaction);
    }

    final attackerStats = attacker.blueprint.stats;
    final targetStats = target.blueprint.stats;
    var raw = hit.baseDamage + attackerStats.attackPower * hit.attackScaling;
    final critical = hit.canCritical && criticalRoll < attackerStats.criticalChance;
    if (critical) raw *= attackerStats.criticalMultiplier;

    final mitigated = hit.damageType == DamageType.trueDamage
        ? raw
        : raw *
            (100 / (100 + targetStats.defense)) *
            (1 - targetStats.resistanceFor(hit.damageType));
    final finalDamage = mitigated.clamp(1, double.infinity).toDouble();
    final application = target.health.applyDamage(
      finalDamage,
      bypassInvulnerability: hit.bypassesInvulnerability,
      invulnerabilityAfterHit: hit.invulnerabilityAfterHit,
    );
    if (application.blockedByInvulnerability) {
      return DamageResolution(
        rawDamage: raw,
        mitigatedDamage: finalDamage,
        application: application,
        wasCritical: critical,
        wasStaggered: false,
        rejection: DamageRejection.invulnerable,
        knockback: 0,
      );
    }

    var staggered = false;
    if (application.totalApplied > 0) {
      staggered = target.applyPoiseDamage(hit.poiseDamage);
      final status = hit.statusEffect;
      if (status != null) {
        target.statuses.apply(status, sourceActorId: attacker.blueprint.id);
      }
      if (attackerStats.lifeSteal > 0 && application.healthDamage > 0) {
        attacker.health.heal(application.healthDamage * attackerStats.lifeSteal);
      }
    }

    return DamageResolution(
      rawDamage: raw,
      mitigatedDamage: finalDamage,
      application: application,
      wasCritical: critical,
      wasStaggered: staggered,
      rejection: DamageRejection.none,
      knockback: hit.knockback,
    );
  }

  DamageResolution _rejected(DamageRejection rejection) => DamageResolution(
        rawDamage: 0,
        mitigatedDamage: 0,
        application: const DamageApplication(
          requested: 0,
          absorbedByShield: 0,
          healthDamage: 0,
          blockedByInvulnerability: false,
          killed: false,
        ),
        wasCritical: false,
        wasStaggered: false,
        rejection: rejection,
        knockback: 0,
      );
}

