import 'combat_models.dart';

class PeriodicDamageEvent {
  const PeriodicDamageEvent({
    required this.sourceActorId,
    required this.statusId,
    required this.damageType,
    required this.amount,
  });

  final String sourceActorId;
  final String statusId;
  final DamageType damageType;
  final double amount;
}

class ActiveStatusSnapshot {
  const ActiveStatusSnapshot({
    required this.id,
    required this.type,
    required this.stacks,
    required this.remaining,
  });

  final String id;
  final StatusType type;
  final int stacks;
  final double remaining;
}

class _ActiveStatus {
  _ActiveStatus({
    required this.spec,
    required this.sourceActorId,
  })  : remaining = spec.duration,
        untilNextTick = spec.tickInterval;

  final StatusEffectSpec spec;
  String sourceActorId;
  double remaining;
  double untilNextTick;
  int stacks = 1;
}

class StatusController {
  final List<_ActiveStatus> _active = [];

  List<ActiveStatusSnapshot> get active => List.unmodifiable(
        _active.map(
          (status) => ActiveStatusSnapshot(
            id: status.spec.id,
            type: status.spec.type,
            stacks: status.stacks,
            remaining: status.remaining,
          ),
        ),
      );

  bool get preventsAction => _active.any((status) => status.spec.preventsAction);

  double get moveSpeedMultiplier => _active.fold(
        1.0,
        (value, status) => value * status.spec.moveSpeedMultiplier,
      );

  void apply(StatusEffectSpec spec, {required String sourceActorId}) {
    if (spec.duration <= 0 || spec.maxStacks <= 0 || spec.tickInterval <= 0) {
      throw ArgumentError('Status ${spec.id} tidak sah.');
    }
    final existing = _active.where((status) => status.spec.id == spec.id).firstOrNull;
    if (existing == null) {
      _active.add(_ActiveStatus(spec: spec, sourceActorId: sourceActorId));
      return;
    }
    existing.stacks =
        (existing.stacks + 1).clamp(1, spec.maxStacks).toInt();
    existing.remaining = spec.duration;
    existing.sourceActorId = sourceActorId;
  }

  List<PeriodicDamageEvent> update(double dt) {
    if (dt < 0) throw ArgumentError.value(dt, 'dt');
    final events = <PeriodicDamageEvent>[];
    for (final status in List<_ActiveStatus>.of(_active)) {
      final activeTime = dt.clamp(0, status.remaining).toDouble();
      status.remaining -= dt;
      status.untilNextTick -= activeTime;
      while (status.untilNextTick <= 0) {
        if (status.spec.damagePerTick > 0) {
          events.add(
            PeriodicDamageEvent(
              sourceActorId: status.sourceActorId,
              statusId: status.spec.id,
              damageType: _damageTypeFor(status.spec.type),
              amount: status.spec.damagePerTick * status.stacks,
            ),
          );
        }
        status.untilNextTick += status.spec.tickInterval;
      }
      if (status.remaining <= 0) _active.remove(status);
    }
    return events;
  }

  void clear() => _active.clear();

  DamageType _damageTypeFor(StatusType type) => switch (type) {
        StatusType.burning => DamageType.fire,
        StatusType.poisoned => DamageType.poison,
        StatusType.chilled => DamageType.frost,
        StatusType.stunned || StatusType.armorBroken => DamageType.physical,
      };
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    return iterator.moveNext() ? iterator.current : null;
  }
}
