import 'dart:math';
import 'dart:ui' show Color;

import 'package:flame/components.dart';
import 'package:flame/experimental.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';

import 'audio/sound_manager.dart';
import 'combat/combat_models.dart';
import 'combat/combat_resolver.dart';
import 'combat/health_pool.dart';
import 'combat/status_controller.dart';
import 'components/arena_stage.dart';
import 'components/combat_actor_component.dart';
import 'components/combat_effects.dart';
import 'components/hero_component.dart';
import 'components/level_objects.dart';
import 'components/mob_component.dart';
import 'data/actor_catalog.dart';
import 'input/player_input.dart';
import 'level/level_progress.dart';

enum GamePhase { loading, playing, paused, victory, defeat }

class SkyboundGame extends FlameGame {
  SkyboundGame({this.selectedAvatarId = 'nova'})
      : progress = LevelProgress(totalRelics: 3);

  final String selectedAvatarId;
  final PlayerInput input = PlayerInput();
  final CombatResolver combatResolver = const CombatResolver();
  final Random random = Random();
  final SoundManager sound = SoundManager();
  final LevelProgress progress;

  final ValueNotifier<GamePhase> phase = ValueNotifier(GamePhase.loading);
  final ValueNotifier<HealthSnapshot> heroHealth = ValueNotifier(
    const HealthSnapshot(current: 1, maximum: 1, shield: 0, isDead: false),
  );
  final ValueNotifier<double> heroResource = ValueNotifier(1);
  final ValueNotifier<double> primaryCooldown = ValueNotifier(0);
  final ValueNotifier<double> secondaryCooldown = ValueNotifier(0);
  final ValueNotifier<double> bossHealth = ValueNotifier(1);
  final ValueNotifier<bool> bossEncounter = ValueNotifier(false);
  final ValueNotifier<int> relicCount = ValueNotifier(0);
  final ValueNotifier<int> enemiesRemaining = ValueNotifier(0);
  final ValueNotifier<String> objective = ValueNotifier('Memuatkan dunia...');
  final ValueNotifier<String?> banner = ValueNotifier(null);

  final List<CombatActorComponent> combatants = [];
  final List<RelicComponent> relics = [];
  final List<HealingPickupComponent> healingPickups = [];
  late final ArenaStage stage;
  late final CheckpointComponent checkpoint;
  late final GoalPortalComponent portal;
  HeroComponent? _hero;
  MobComponent? _boss;
  Vector2 _checkpointSpawn = Vector2(130, 364);
  double _bannerRemaining = 0;
  double _endPauseRemaining = 0;
  double _elapsedSeconds = 0;

  HeroComponent get hero => _hero!;
  HeroComponent? get heroOrNull => _hero;
  ActorBlueprint get selectedAvatar => ActorCatalog.byId(selectedAvatarId);
  bool get portalUnlocked => progress.portalUnlocked;
  String get elapsedTimeLabel {
    final totalSeconds = _elapsedSeconds.floor();
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    ActorCatalog.validate();
    await sound.preload();

    stage = ArenaStage(gameRef: this);
    await world.add(stage);

    _hero = HeroComponent(
      gameRef: this,
      blueprint: selectedAvatar,
      position: _checkpointSpawn.clone(),
    );
    await register(hero);

    final spawns = <(ActorBlueprint, Vector2)>[
      (ActorCatalog.mimicCube, Vector2(500, 364)),
      (ActorCatalog.emberWisp, Vector2(930, 240)),
      (ActorCatalog.drillSpike, Vector2(1260, 364)),
      (ActorCatalog.guardBot, Vector2(1785, 274)),
      (ActorCatalog.scoutDrone, Vector2(2200, 120)),
      (ActorCatalog.monitorGolem, Vector2(2790, 347)),
    ];
    for (final spawn in spawns) {
      final mob = MobComponent(
        gameRef: this,
        blueprint: spawn.$1,
        position: spawn.$2,
      );
      if (spawn.$1.id == 'monitor_golem') _boss = mob;
      await register(mob);
    }

    relics.addAll([
      RelicComponent(gameRef: this, position: Vector2(630, 190), index: 0),
      RelicComponent(gameRef: this, position: Vector2(1405, 178), index: 1),
      RelicComponent(gameRef: this, position: Vector2(2265, 102), index: 2),
    ]);
    healingPickups.addAll([
      HealingPickupComponent(gameRef: this, position: Vector2(1190, 258)),
      HealingPickupComponent(gameRef: this, position: Vector2(2630, 338)),
    ]);
    checkpoint = CheckpointComponent(gameRef: this, position: Vector2(1640, 390));
    portal = GoalPortalComponent(gameRef: this, position: Vector2(3180, 390));
    await world.addAll([...relics, ...healingPickups, checkpoint, portal]);

    camera.viewfinder.zoom = 1.48;
    camera.setBounds(
      Rectangle.fromLTWH(
        0,
        0,
        ArenaStage.worldWidth,
        ArenaStage.worldHeight,
      ),
      considerViewport: true,
    );
    camera.follow(hero, maxSpeed: 620);

    enemiesRemaining.value = combatants
        .where((actor) => actor.blueprint.faction == ActorFaction.enemy)
        .length;
    phase.value = GamePhase.playing;
    showBanner('Kumpul 3 relik · Tewaskan Golem · Masuk portal', seconds: 4.2);
    _publishObjective();
    publishHeroVitals();
  }

  Future<void> register(CombatActorComponent actor) async {
    combatants.add(actor);
    await world.add(actor);
  }

  void addTransient(TransientComponent component) {
    world.add(component);
  }

  void publishHeroVitals() {
    final value = _hero;
    if (value == null) return;
    final nextHealth = value.state.health.snapshot;
    final previousHealth = heroHealth.value;
    if ((nextHealth.current - previousHealth.current).abs() > 0.001 ||
        (nextHealth.maximum - previousHealth.maximum).abs() > 0.001 ||
        (nextHealth.shield - previousHealth.shield).abs() > 0.001 ||
        nextHealth.isDead != previousHealth.isDead) {
      heroHealth.value = nextHealth;
    }

    final maximumResource = value.state.blueprint.stats.maxResource;
    final resourceRatio = maximumResource == 0
        ? 0.0
        : (value.state.resource / maximumResource).clamp(0, 1).toDouble();
    _setDouble(heroResource, resourceRatio);

    final skills = value.blueprint.skills;
    _setDouble(primaryCooldown, value.state.skills.cooldownRatio(skills.first.id));
    _setDouble(
      secondaryCooldown,
      skills.length > 1 ? value.state.skills.cooldownRatio(skills[1].id) : 0,
    );
  }

  void _setDouble(ValueNotifier<double> notifier, double value) {
    if ((notifier.value - value).abs() > 0.005) notifier.value = value;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (phase.value == GamePhase.playing) _elapsedSeconds += dt;
    publishHeroVitals();

    final boss = _boss;
    if (boss != null) {
      _setDouble(bossHealth, boss.state.health.ratio);
      final active = !boss.state.isDead && hero.position.x > 2460;
      if (bossEncounter.value != active) bossEncounter.value = active;
    }

    if (_bannerRemaining > 0) {
      _bannerRemaining -= dt;
      if (_bannerRemaining <= 0 && banner.value != null) banner.value = null;
    }
    if (_endPauseRemaining > 0) {
      _endPauseRemaining -= dt;
      if (_endPauseRemaining <= 0) pauseEngine();
    }
  }

  void onSkillCast(CombatActorComponent actor, SkillDefinition skill) {
    if (skill.pattern == AttackPattern.projectile) {
      sound.play(SoundCue.projectile, volume: actor.isBoss ? 0.8 : 0.48);
    } else if (skill.pattern == AttackPattern.area || actor.isBoss) {
      sound.play(SoundCue.heavyAttack, volume: 0.62);
    } else if (actor.blueprint.faction == ActorFaction.hero) {
      sound.play(SoundCue.lightAttack, volume: 0.42);
    }
  }

  void onCombatHit({
    required CombatActorComponent attacker,
    required CombatActorComponent target,
    required SkillDefinition skill,
    required DamageResolution result,
    required Vector2 position,
  }) {
    final damage = result.application.totalApplied;
    if (damage <= 0) return;
    final heavy = result.wasCritical || result.wasStaggered || attacker.isBoss;
    final color = attacker.damageColor(skill.hit.damageType);
    addTransient(
      ImpactEffect(
        position: position.clone(),
        color: color,
        heavy: heavy,
        seed: random.nextInt(1 << 30),
      ),
    );
    addTransient(
      FloatingTextEffect(
        position: position + Vector2(0, -34),
        text: '${result.wasCritical ? 'CRIT ' : ''}${damage.ceil()}',
        color: result.wasCritical ? const Color(0xFFFFE66D) : color,
        emphasized: heavy,
      ),
    );
    sound.play(heavy ? SoundCue.heavyHit : SoundCue.hit, volume: heavy ? 0.72 : 0.43);
  }

  void onPeriodicDamage(CombatActorComponent target, PeriodicDamageEvent event) {
    if (target.state.isDead) return;
    final color = switch (event.damageType) {
      DamageType.fire => const Color(0xFFFF7043),
      DamageType.poison => const Color(0xFF8DE35C),
      DamageType.frost => const Color(0xFF62D7FF),
      _ => const Color(0xFFFFFFFF),
    };
    addTransient(
      FloatingTextEffect(
        position: target.position + Vector2(0, -32),
        text: event.amount.ceil().toString(),
        color: color,
      ),
    );
  }

  void onActorDefeated(CombatActorComponent actor) {
    if (actor.blueprint.faction == ActorFaction.hero) {
      if (phase.value == GamePhase.playing) {
        phase.value = GamePhase.defeat;
        input.releaseAll();
        sound.play(SoundCue.defeat, volume: 0.7);
        _endPauseRemaining = 0.9;
      }
      return;
    }

    progress.defeatEnemy(isBoss: actor.isBoss);
    enemiesRemaining.value = combatants
        .where(
          (value) =>
              value.blueprint.faction == ActorFaction.enemy && !value.state.isDead,
        )
        .length;
    addTransient(
      ImpactEffect(
        position: actor.position.clone(),
        color: actor.accentColor,
        heavy: true,
        seed: random.nextInt(1 << 30),
      ),
    );
    if (actor.isBoss) {
      bossEncounter.value = false;
      showBanner(
        progress.hasAllRelics
            ? 'Golem tumbang · Portal langit telah aktif!'
            : 'Golem tumbang · Cari relik yang masih hilang',
        seconds: 3.4,
      );
    }
    _publishObjective();
  }

  void collectRelic(RelicComponent component) {
    if (!progress.collectRelic()) return;
    relicCount.value = progress.relicsCollected;
    sound.play(SoundCue.pickup, volume: 0.72);
    addTransient(
      ShockwaveEffect(
        position: component.position.clone(),
        color: const Color(0xFF7EEBFF),
        maximumRadius: 58,
      ),
    );
    final message = progress.portalUnlocked
        ? 'Semua relik ditemui · Portal langit telah aktif!'
        : progress.hasAllRelics
            ? 'Semua relik ditemui! Tewaskan Monitor Golem.'
            : 'Relik langit ${progress.relicsCollected} / ${progress.totalRelics}';
    showBanner(message, seconds: 2.3);
    _publishObjective();
  }

  void collectHealing(Vector2 position, double amount) {
    sound.play(SoundCue.pickup, volume: 0.5);
    addTransient(
      FloatingTextEffect(
        position: position.clone(),
        text: '+${amount.ceil()} HP',
        color: const Color(0xFF6CFF9B),
        emphasized: true,
      ),
    );
  }

  void activateCheckpoint(CheckpointComponent component) {
    _checkpointSpawn = component.respawnPoint;
    hero.state.health.heal(28);
    hero.state.health.addShield(14, cap: 24);
    sound.play(SoundCue.checkpoint, volume: 0.75);
    showBanner('Checkpoint diaktifkan · HP dan perisai dipulihkan', seconds: 2.8);
  }

  void damageHeroFromHazard({required double knockbackDirection}) {
    if (phase.value != GamePhase.playing || hero.state.isDead) return;
    final application = hero.state.health.applyDamage(
      22,
      invulnerabilityAfterHit: 0.9,
    );
    if (application.totalApplied <= 0) return;
    hero.receiveKnockback(knockbackDirection * 185);
    sound.play(SoundCue.heavyHit, volume: 0.6);
    addTransient(
      ImpactEffect(
        position: hero.position.clone(),
        color: const Color(0xFFFF4D5F),
        heavy: true,
        seed: random.nextInt(1 << 30),
      ),
    );
    addTransient(
      FloatingTextEffect(
        position: hero.position + Vector2(0, -36),
        text: '22',
        color: const Color(0xFFFF6B76),
        emphasized: true,
      ),
    );
  }

  void handleHeroFall() {
    if (phase.value != GamePhase.playing || hero.state.isDead) return;
    final fallPosition = hero.position.clone();
    final application = hero.state.health.applyDamage(
      26,
      invulnerabilityAfterHit: 1.15,
    );
    if (!hero.state.isDead) {
      hero.teleport(_checkpointSpawn);
      hero.state.health.grantInvulnerability(1.15);
    }
    if (application.totalApplied > 0) {
      sound.play(SoundCue.heavyHit, volume: 0.65);
      addTransient(
        ImpactEffect(
          position: fallPosition,
          color: const Color(0xFF8DEBFF),
          heavy: true,
          seed: random.nextInt(1 << 30),
        ),
      );
      showBanner('Kembali ke checkpoint', seconds: 1.5);
    }
  }

  void onHeroJump(Vector2 position) {
    sound.play(SoundCue.jump, volume: 0.28);
    addTransient(
      TrailPuffEffect(
        position: position + Vector2(0, 22),
        color: const Color(0xFFA8E6CF),
        radius: 12,
      ),
    );
  }

  void onHeroLanded(Vector2 position, double speed) {
    sound.play(SoundCue.landing, volume: (speed / 620).clamp(0.2, 0.55).toDouble());
    addTransient(
      ShockwaveEffect(
        position: position + Vector2(0, 22),
        color: const Color(0xFFB8E3B3),
        maximumRadius: (speed / 7).clamp(24, 58).toDouble(),
      ),
    );
  }

  void onHeroStep() {
    sound.play(SoundCue.landing, volume: 0.12);
  }

  void onBossEnraged() {
    showBanner('AMARAN · Monitor Golem memasuki fasa kedua!', seconds: 2.8);
  }

  void completeLevel() {
    if (phase.value != GamePhase.playing || !portalUnlocked) return;
    phase.value = GamePhase.victory;
    input.releaseAll();
    sound.play(SoundCue.victory, volume: 0.85);
    banner.value = null;
    _endPauseRemaining = 0.7;
  }

  void togglePause() {
    if (phase.value == GamePhase.playing) {
      phase.value = GamePhase.paused;
      input.releaseAll();
      pauseEngine();
    } else if (phase.value == GamePhase.paused) {
      resumeGame();
    }
  }

  void resumeGame() {
    if (phase.value != GamePhase.paused) return;
    phase.value = GamePhase.playing;
    resumeEngine();
  }

  void restartLevel() {
    resumeEngine();
    input.releaseAll();
    phase.value = GamePhase.playing;
    _endPauseRemaining = 0;
    progress.reset();
    _elapsedSeconds = 0;
    relicCount.value = 0;
    _checkpointSpawn = Vector2(130, 364);

    for (final child in world.children.toList()) {
      if (child is TransientComponent) child.removeFromParent();
    }
    hero.resetAt(_checkpointSpawn);
    for (final actor in combatants.whereType<MobComponent>()) {
      actor.resetAt(actor.spawnPosition);
    }
    for (final relic in relics) {
      relic.reset();
    }
    for (final pickup in healingPickups) {
      pickup.reset();
    }
    checkpoint.reset();
    portal.reset();

    enemiesRemaining.value = combatants
        .where((actor) => actor.blueprint.faction == ActorFaction.enemy)
        .length;
    bossEncounter.value = false;
    bossHealth.value = 1;
    _publishObjective();
    publishHeroVitals();
    showBanner('Misi dimulakan semula', seconds: 1.8);
  }

  void showBanner(String message, {double seconds = 2}) {
    banner.value = message;
    _bannerRemaining = seconds;
  }

  void setSoundEnabled(bool enabled) {
    sound.enabled = enabled;
  }

  void _publishObjective() {
    objective.value = progress.objectiveText(
      enemiesRemaining: enemiesRemaining.value,
    );
  }

  @override
  void onRemove() {
    input.releaseAll();
    heroHealth.dispose();
    heroResource.dispose();
    primaryCooldown.dispose();
    secondaryCooldown.dispose();
    bossHealth.dispose();
    bossEncounter.dispose();
    relicCount.dispose();
    enemiesRemaining.dispose();
    objective.dispose();
    banner.dispose();
    phase.dispose();
    super.onRemove();
  }
}
