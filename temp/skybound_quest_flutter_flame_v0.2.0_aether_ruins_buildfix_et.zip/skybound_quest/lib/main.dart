import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'game/skybound_game.dart';
import 'ui/combat_hud.dart';
import 'ui/title_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const SkyboundApp());
}

class SkyboundApp extends StatelessWidget {
  const SkyboundApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF071225),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF42E3D0),
          brightness: Brightness.dark,
        ),
      ),
      home: const _HomeScreen(),
    );
  }
}

class _HomeScreen extends StatelessWidget {
  const _HomeScreen();

  @override
  Widget build(BuildContext context) {
    return TitleScreen(
      onStart: (avatarId) {
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => GameScreen(selectedAvatarId: avatarId),
          ),
        );
      },
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.selectedAvatarId});

  final String selectedAvatarId;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with WidgetsBindingObserver {
  late final SkyboundGame game = SkyboundGame(
    selectedAvatarId: widget.selectedAvatarId,
  );
  final FocusNode _focusNode = FocusNode(debugLabel: 'SkyboundKeyboard');
  final Set<LogicalKeyboardKey> _handledDown = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _handledDown.clear();
      game.input.releaseAll();
      if (game.phase.value == GamePhase.playing) game.togglePause();
    }
  }

  void _handleKeyEvent(KeyEvent event) {
    final key = event.logicalKey;
    if (event is KeyDownEvent && _handledDown.add(key)) {
      if (key == LogicalKeyboardKey.keyJ || key == LogicalKeyboardKey.keyZ) {
        game.input.queuePrimary();
      } else if (key == LogicalKeyboardKey.keyK || key == LogicalKeyboardKey.keyX) {
        game.input.queueSecondary();
      } else if (key == LogicalKeyboardKey.escape || key == LogicalKeyboardKey.keyP) {
        game.togglePause();
      }
    } else if (event is KeyUpEvent) {
      _handledDown.remove(key);
    }

    final pressed = HardwareKeyboard.instance.logicalKeysPressed;
    game.input.setLeft(
      pressed.contains(LogicalKeyboardKey.arrowLeft) ||
          pressed.contains(LogicalKeyboardKey.keyA),
    );
    game.input.setRight(
      pressed.contains(LogicalKeyboardKey.arrowRight) ||
          pressed.contains(LogicalKeyboardKey.keyD),
    );
    game.input.setJump(
      pressed.contains(LogicalKeyboardKey.arrowUp) ||
          pressed.contains(LogicalKeyboardKey.keyW) ||
          pressed.contains(LogicalKeyboardKey.space),
    );
  }

  void _exitToMenu() {
    _handledDown.clear();
    game.resumeEngine();
    game.input.releaseAll();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return KeyboardListener(
      focusNode: _focusNode,
      autofocus: true,
      onKeyEvent: _handleKeyEvent,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          fit: StackFit.expand,
          children: [
            GameWidget(game: game),
            CombatHud(game: game, onExit: _exitToMenu),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _handledDown.clear();
    game.input.releaseAll();
    _focusNode.dispose();
    super.dispose();
  }
}
