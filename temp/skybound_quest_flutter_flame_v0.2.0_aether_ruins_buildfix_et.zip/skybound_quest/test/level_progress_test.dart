import 'package:flutter_test/flutter_test.dart';
import 'package:skybound_quest/game/level/level_progress.dart';

void main() {
  test('portal hanya terbuka selepas semua relik dan boss ditewaskan', () {
    final progress = LevelProgress(totalRelics: 3);

    expect(progress.portalUnlocked, isFalse);
    expect(progress.collectRelic(), isTrue);
    expect(progress.collectRelic(), isTrue);
    expect(progress.collectRelic(), isTrue);
    expect(progress.collectRelic(), isFalse);
    expect(progress.hasAllRelics, isTrue);
    expect(progress.portalUnlocked, isFalse);

    progress.defeatEnemy(isBoss: true);
    expect(progress.portalUnlocked, isTrue);
  });

  test('reset mengembalikan kemajuan level ke keadaan awal', () {
    final progress = LevelProgress(totalRelics: 1)
      ..collectRelic()
      ..defeatEnemy(isBoss: true);

    progress.reset();

    expect(progress.relicsCollected, 0);
    expect(progress.enemiesDefeated, 0);
    expect(progress.bossDefeated, isFalse);
  });

  test('teks objektif mengikuti kemajuan misi', () {
    final progress = LevelProgress(totalRelics: 2);

    expect(
      progress.objectiveText(enemiesRemaining: 4),
      'Cari relik langit · 0 / 2',
    );
    progress.collectRelic();
    expect(
      progress.objectiveText(enemiesRemaining: 4),
      'Cari relik langit · 1 / 2',
    );
    progress.collectRelic();
    expect(
      progress.objectiveText(enemiesRemaining: 4),
      'Tewaskan Monitor Golem',
    );
    progress.defeatEnemy(isBoss: true);
    expect(
      progress.objectiveText(enemiesRemaining: 2),
      'Masuk portal · Musuh berbaki 2',
    );
    expect(
      progress.objectiveText(enemiesRemaining: 0),
      'Masuk ke portal langit',
    );
  });
}
