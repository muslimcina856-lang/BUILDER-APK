import 'package:flutter_test/flutter_test.dart';
import 'package:skybound_quest/game/input/player_input.dart';

void main() {
  group('PlayerInput', () {
    test('paksi mendatar menggabungkan dua butang dengan stabil', () {
      final input = PlayerInput();

      expect(input.horizontalAxis, 0);
      input.setLeft(true);
      expect(input.horizontalAxis, -1);
      input.setRight(true);
      expect(input.horizontalAxis, 0);
      input.setLeft(false);
      expect(input.horizontalAxis, 1);
      input.setRight(false);
      expect(input.horizontalAxis, 0);
    });

    test('jump hanya di-queue pada rising edge', () {
      final input = PlayerInput();

      input.setJump(true);
      expect(input.jumpHeld, isTrue);
      expect(input.consumeJump(), isTrue);
      expect(input.consumeJump(), isFalse);

      input.setJump(true);
      expect(input.consumeJump(), isFalse);
      input.setJump(false);
      input.setJump(true);
      expect(input.consumeJump(), isTrue);
    });

    test('serangan dikonsum sekali dan releaseAll membersihkan semua input', () {
      final input = PlayerInput()
        ..setLeft(true)
        ..setJump(true)
        ..queuePrimary()
        ..queueSecondary();

      expect(input.consumePrimary(), isTrue);
      expect(input.consumePrimary(), isFalse);
      input.queuePrimary();
      input.releaseAll();

      expect(input.horizontalAxis, 0);
      expect(input.jumpHeld, isFalse);
      expect(input.consumeJump(), isFalse);
      expect(input.consumePrimary(), isFalse);
      expect(input.consumeSecondary(), isFalse);
    });
  });
}
