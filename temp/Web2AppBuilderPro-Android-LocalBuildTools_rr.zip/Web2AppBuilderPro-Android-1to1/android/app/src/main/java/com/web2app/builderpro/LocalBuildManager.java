package com.web2app.builderpro;

import android.content.Context;
import android.os.Build;
import android.system.Os;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.json.JSONObject;
import org.tukaani.xz.XZInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Optional on-device Android build engine.
 *
 * The web generator always remains usable without this manager.  When the
 * toolchain marker is absent the native bridge simply saves the source ZIP.
 * The user must explicitly unlock and run the hidden installer before local
 * APK builds are attempted.
 */
public final class LocalBuildManager {
    public interface ProgressListener {
        void onProgress(int progress, String stage);
    }

    private static final String BUILD_TOOLS_ARM64_URL = "https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/v34.0.4/build-tools-34.0.4-aarch64.tar.xz";
    private static final String BUILD_TOOLS_ARM_URL = "https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/v34.0.4/build-tools-34.0.4-arm.tar.xz";
    private static final String JDK11_ARM64_URL = "https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/jdk-11/jdk11-aarch64.tar.xz";
    private static final String JDK11_ARM_URL = "https://github.com/AndroidIDEOfficial/androidide-tools/releases/download/jdk-11/jdk11-aarch32.tar.xz";
    private static final String GRADLE_URL = "https://services.gradle.org/distributions/gradle-6.1.1-bin.zip";
    private static final String PLATFORM_PACKAGE = "platforms;android-29";
    private static final String PLATFORM_29_URL = "https://dl.google.com/android/repository/platform-29_r05.zip";

    private final Context context;
    private final File toolRoot;
    private final File readyMarker;
    private volatile boolean installing;
    private volatile boolean building;

    public LocalBuildManager(Context context) {
        this.context = context.getApplicationContext();
        this.toolRoot = new File(context.getFilesDir(), "w2a-local-build");
        this.readyMarker = new File(toolRoot, ".ready-v1");
    }

    public boolean isInstalling() { return installing; }
    public boolean isBuilding() { return building; }

    public String getArchitectureLabel() {
        String abi = Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : Build.CPU_ABI;
        if (abi == null) return "unknown";
        if (abi.contains("arm64")) return "arm64-v8a";
        if (abi.contains("armeabi") || abi.startsWith("arm")) return "armeabi-v7a";
        return abi;
    }

    public boolean isReady() {
        try {
            if (!readyMarker.isFile()) return false;
            File sdk = findSdkRoot();
            File javaHome = findJavaHome();
            File gradle = findGradleHome();
            File aapt2 = new File(sdk, "build-tools/34.0.4/aapt2");
            File platform = new File(sdk, "platforms/android-29/android.jar");
            File signer = new File(sdk, "build-tools/34.0.4/lib/apksigner.jar");
            return new File(javaHome, "bin/java").isFile()
                    && new File(gradle, "bin/gradle").isFile()
                    && aapt2.isFile()
                    && platform.isFile()
                    && signer.isFile();
        } catch (Exception ignored) {
            return false;
        }
    }

    public String getStatusJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("installed", isReady());
            obj.put("installing", installing);
            obj.put("building", building);
            obj.put("arch", getArchitectureLabel());
            obj.put("message", isReady()
                    ? "Toolchain ready. Generate will build, sign, and include an APK in the ZIP."
                    : installing ? "Installing local build toolchain..."
                    : "Toolchain not installed. Generate will keep saving the source ZIP normally.");
            return obj.toString();
        } catch (Exception e) {
            return "{\"installed\":false,\"message\":\"Status unavailable\"}";
        }
    }

    public void install(ProgressListener listener) throws Exception {
        if (installing) throw new IllegalStateException("Tool installation is already running");
        installing = true;
        try {
            ensureSupportedArchitecture();
            if (!toolRoot.exists() && !toolRoot.mkdirs()) throw new IOException("Cannot create tool directory");
            if (readyMarker.exists()) readyMarker.delete();

            File sdk = new File(toolRoot, "android-sdk");
            if (!sdk.exists() && !sdk.mkdirs()) throw new IOException("Cannot create Android SDK directory");

            int steps = 4;
            installTarComponent("ARM build tools 34.0.4", getBuildToolsUrl(), sdk, 0, steps, listener);
            installPlatform29Direct(sdk, 1, steps, listener);
            installTarComponent("OpenJDK 11", getJdkUrl(), toolRoot, 2, steps, listener);
            installZipComponent("Gradle 6.1.1", GRADLE_URL, toolRoot, 3, steps, listener);

            listener.onProgress(82, "Preparing build-tools 30.0.3 compatibility alias...");
            ensureBuildToolsAlias();

            listener.onProgress(86, "Downloading Gradle/Android dependencies and running toolchain self-test...");
            runSelfTest(listener);

            writeText(readyMarker, "ready\narch=" + getArchitectureLabel() + "\n");
            listener.onProgress(100, "Local build tools ready");
        } finally {
            installing = false;
        }
    }

    public File buildProject(byte[] sourceZip, String appName, ProgressListener listener) throws Exception {
        if (!isReady()) throw new IllegalStateException("Local build tools are not installed");
        if (building) throw new IllegalStateException("A local build is already running");
        building = true;
        File work = new File(context.getCacheDir(), "w2a-build-" + UUID.randomUUID());
        try {
            if (!work.mkdirs()) throw new IOException("Could not create build workspace");
            File projectDir = new File(work, "project");
            if (!projectDir.mkdirs()) throw new IOException("Could not create project workspace");

            listener.onProgress(5, "Extracting generated project...");
            unzip(new ByteArrayInputStream(sourceZip), projectDir);
            prepareProjectForLocalBuild(projectDir);

            listener.onProgress(15, "Compiling Android project...");
            File gradleHome = findGradleHome();
            File gradleScript = new File(gradleHome, "bin/gradle");
            List<String> gradleCmd = Arrays.asList(
                    "/system/bin/sh", gradleScript.getAbsolutePath(),
                    "--no-daemon", "--stacktrace", "assembleRelease",
                    "-Pandroid.aapt2FromMavenOverride=" + getAapt2().getAbsolutePath()
            );
            ProcessResult build = runCommand(gradleCmd, projectDir, buildEnvironment(), null, 30, listener, 15, 76, "Gradle build");
            if (build.exitCode != 0) throw new IOException("Gradle build failed:\n" + build.tail);

            File unsignedApk = new File(projectDir, "app/build/outputs/apk/release/app-release-unsigned.apk");
            if (!unsignedApk.isFile()) {
                File alt = findByName(new File(projectDir, "app/build/outputs/apk"), "app-release.apk");
                if (alt != null) unsignedApk = alt;
            }
            if (!unsignedApk.isFile()) throw new IOException("Release APK output was not found");

            listener.onProgress(78, "Aligning APK...");
            File aligned = new File(work, "aligned.apk");
            ProcessResult align = runCommand(Arrays.asList(getZipAlign().getAbsolutePath(), "-f", "4", unsignedApk.getAbsolutePath(), aligned.getAbsolutePath()),
                    work, buildEnvironment(), null, 5, null, 0, 0, null);
            if (align.exitCode != 0 || !aligned.isFile()) throw new IOException("zipalign failed:\n" + align.tail);

            listener.onProgress(84, "Preparing signing key...");
            File keystore = ensureSigningKey();
            File signed = new File(work, sanitizeBaseName(appName) + ".apk");
            listener.onProgress(88, "Signing installable APK...");
            signApk(aligned, signed, keystore);
            verifyApk(signed);

            listener.onProgress(94, "Adding APK into final ZIP...");
            File finalZip = new File(work, sanitizeBaseName(appName) + "-project-with-apk.zip");
            appendApkToZip(sourceZip, signed, "APK/" + sanitizeBaseName(appName) + ".apk", finalZip);
            listener.onProgress(100, "Project ZIP + installable APK ready");
            return finalZip;
        } finally {
            building = false;
            // Caller copies the final ZIP immediately. Cleanup is deliberately delayed by
            // MainActivity after the file has been persisted to Downloads.
        }
    }

    public void cleanupBuildOutput(File finalZip) {
        if (finalZip == null) return;
        File parent = finalZip.getParentFile();
        if (parent != null && parent.getName().startsWith("w2a-build-")) deleteRecursive(parent);
    }

    private void prepareProjectForLocalBuild(File projectDir) throws Exception {
        File props = new File(projectDir, "gradle.properties");
        String existing = props.isFile() ? readText(props) : "";
        if (!existing.endsWith("\n")) existing += "\n";
        existing += "android.aapt2FromMavenOverride=" + getAapt2().getAbsolutePath().replace("\\", "\\\\") + "\n";
        existing += "org.gradle.jvmargs=-Xmx1024m -Dfile.encoding=UTF-8\n";
        writeText(props, existing);
    }

    private void runSelfTest(ProgressListener listener) throws Exception {
        File root = new File(toolRoot, "self-test");
        deleteRecursive(root);
        File javaDir = new File(root, "app/src/main/java/com/w2a/selftest");
        File values = new File(root, "app/src/main/res/values");
        if (!javaDir.mkdirs() || !values.mkdirs()) throw new IOException("Could not create self-test project");

        writeText(new File(root, "settings.gradle"), "include ':app'\nrootProject.name='W2AToolchainSelfTest'\n");
        writeText(new File(root, "build.gradle"),
                "buildscript { repositories { google(); mavenCentral() } dependencies { classpath 'com.android.tools.build:gradle:3.6.4' } }\n" +
                "allprojects { repositories { google(); mavenCentral() } }\n");
        writeText(new File(root, "gradle.properties"),
                "android.useAndroidX=true\nandroid.enableJetifier=true\nandroid.aapt2FromMavenOverride=" + getAapt2().getAbsolutePath() + "\norg.gradle.jvmargs=-Xmx1024m -Dfile.encoding=UTF-8\n");
        writeText(new File(root, "app/build.gradle"),
                "apply plugin: 'com.android.application'\n" +
                "android { compileSdkVersion 29; buildToolsVersion '30.0.3'; defaultConfig { applicationId 'com.w2a.selftest'; minSdkVersion 26; targetSdkVersion 29; versionCode 1; versionName '1' } }\n" +
                "dependencies { implementation 'com.google.android.gms:play-services-location:19.0.1' }\n");
        writeText(new File(root, "app/src/main/AndroidManifest.xml"),
                "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\" package=\"com.w2a.selftest\"><application android:theme=\"@style/AppTheme\"><activity android:name=\".MainActivity\" android:exported=\"true\"><intent-filter><action android:name=\"android.intent.action.MAIN\"/><category android:name=\"android.intent.category.LAUNCHER\"/></intent-filter></activity></application></manifest>");
        writeText(new File(values, "styles.xml"), "<resources><style name=\"AppTheme\" parent=\"android:Theme.DeviceDefault.NoActionBar\"/></resources>");
        writeText(new File(javaDir, "MainActivity.java"), "package com.w2a.selftest; public class MainActivity extends android.app.Activity {}\n");

        File gradle = new File(findGradleHome(), "bin/gradle");
        ProcessResult result = runCommand(Arrays.asList("/system/bin/sh", gradle.getAbsolutePath(), "--no-daemon", "assembleDebug", "-Pandroid.aapt2FromMavenOverride=" + getAapt2().getAbsolutePath()),
                root, buildEnvironment(), null, 30, listener, 86, 99, "Toolchain self-test");
        File apk = new File(root, "app/build/outputs/apk/debug/app-debug.apk");
        if (result.exitCode != 0 || !apk.isFile()) throw new IOException("Toolchain self-test failed:\n" + result.tail);
    }

    private void installPlatform29Direct(File sdk, int step, int total, ProgressListener listener) throws Exception {
        File downloads = new File(toolRoot, "downloads");
        if (!downloads.exists()) downloads.mkdirs();
        File archive = new File(downloads, "platform-29_r05.zip");
        download("Android platform 29", PLATFORM_29_URL, archive, step, total, listener);

        listener.onProgress(percentFor(step, total, 86), "Extracting Android platform 29...");
        File stage = new File(toolRoot, "platform-29-stage");
        deleteRecursive(stage);
        if (!stage.mkdirs()) throw new IOException("Could not create Android platform staging directory");
        try (InputStream in = new BufferedInputStream(new FileInputStream(archive))) { unzip(in, stage); }

        File androidJar = findByName(stage, "android.jar");
        if (androidJar == null) throw new IOException("android.jar not found in Android platform 29 archive");
        File extractedRoot = androidJar.getParentFile();
        File platforms = new File(sdk, "platforms");
        File target = new File(platforms, "android-29");
        if (!platforms.exists() && !platforms.mkdirs()) throw new IOException("Could not create platforms directory");
        deleteRecursive(target);
        copyDirectory(extractedRoot, target);
        deleteRecursive(stage);
        archive.delete();
        if (!new File(target, "android.jar").isFile()) throw new IOException("Android platform 29 extraction failed");
    }

    private void ensureBuildToolsAlias() throws Exception {
        File sdk = findSdkRoot();
        File source = new File(sdk, "build-tools/34.0.4");
        if (!source.isDirectory()) {
            File found = findDirectoryNamed(sdk, "34.0.4");
            if (found != null && new File(found, "aapt2").isFile()) source = found;
        }
        if (!source.isDirectory()) throw new IOException("Build tools 34.0.4 not found");
        File parent = source.getParentFile();
        File alias = new File(parent, "30.0.3");
        if (alias.exists()) return;
        try {
            Os.symlink(source.getAbsolutePath(), alias.getAbsolutePath());
        } catch (Throwable symlinkError) {
            copyDirectory(source, alias);
            File sourceProps = new File(alias, "source.properties");
            if (sourceProps.isFile()) {
                String text = readText(sourceProps).replaceAll("Pkg.Revision\\s*=.*", "Pkg.Revision=30.0.3");
                writeText(sourceProps, text);
            }
        }
    }

    private File ensureSigningKey() throws Exception {
        File key = new File(toolRoot, "signing/w2a-local-build.jks");
        if (key.isFile()) return key;
        File parent = key.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) throw new IOException("Could not create signing directory");
        File keytool = new File(findJavaHome(), "bin/keytool");
        ProcessResult result = runCommand(Arrays.asList(
                        keytool.getAbsolutePath(), "-genkeypair", "-keystore", key.getAbsolutePath(),
                        "-storepass", "w2abuilder", "-keypass", "w2abuilder", "-alias", "w2a",
                        "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
                        "-dname", "CN=Web2App Builder Pro, OU=Local Build, O=W2A, C=MY"),
                toolRoot, buildEnvironment(), null, 3, null, 0, 0, null);
        if (result.exitCode != 0 || !key.isFile()) throw new IOException("Could not create signing key:\n" + result.tail);
        return key;
    }

    private void signApk(File input, File output, File keystore) throws Exception {
        File signer = new File(findSdkRoot(), "build-tools/34.0.4/lib/apksigner.jar");
        File java = new File(findJavaHome(), "bin/java");
        ProcessResult result = runCommand(Arrays.asList(
                        java.getAbsolutePath(), "-jar", signer.getAbsolutePath(), "sign",
                        "--ks", keystore.getAbsolutePath(), "--ks-key-alias", "w2a",
                        "--ks-pass", "pass:w2abuilder", "--key-pass", "pass:w2abuilder",
                        "--out", output.getAbsolutePath(), input.getAbsolutePath()),
                toolRoot, buildEnvironment(), null, 5, null, 0, 0, null);
        if (result.exitCode != 0 || !output.isFile()) throw new IOException("APK signing failed:\n" + result.tail);
    }

    private void verifyApk(File apk) throws Exception {
        File signer = new File(findSdkRoot(), "build-tools/34.0.4/lib/apksigner.jar");
        File java = new File(findJavaHome(), "bin/java");
        ProcessResult result = runCommand(Arrays.asList(java.getAbsolutePath(), "-jar", signer.getAbsolutePath(), "verify", apk.getAbsolutePath()),
                toolRoot, buildEnvironment(), null, 3, null, 0, 0, null);
        if (result.exitCode != 0) throw new IOException("Signed APK verification failed:\n" + result.tail);
    }

    private void appendApkToZip(byte[] sourceZip, File apk, String apkPath, File output) throws Exception {
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new ByteArrayInputStream(sourceZip)));
             ZipOutputStream zout = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(output)))) {
            ZipEntry entry;
            byte[] buffer = new byte[64 * 1024];
            while ((entry = zin.getNextEntry()) != null) {
                if (apkPath.equals(entry.getName())) continue;
                ZipEntry copy = new ZipEntry(entry.getName());
                copy.setTime(entry.getTime());
                zout.putNextEntry(copy);
                int n;
                while ((n = zin.read(buffer)) != -1) zout.write(buffer, 0, n);
                zout.closeEntry();
            }
            ZipEntry dir = new ZipEntry("APK/");
            zout.putNextEntry(dir);
            zout.closeEntry();
            ZipEntry apkEntry = new ZipEntry(apkPath);
            zout.putNextEntry(apkEntry);
            try (InputStream in = new BufferedInputStream(new FileInputStream(apk))) {
                int n;
                while ((n = in.read(buffer)) != -1) zout.write(buffer, 0, n);
            }
            zout.closeEntry();
        }
    }

    private Map<String, String> buildEnvironment() throws Exception {
        return sdkEnvironment(findJavaHome(), findSdkRoot());
    }

    private Map<String, String> sdkEnvironment(File javaHome, File sdk) throws Exception {
        Map<String, String> env = new HashMap<>();
        env.put("JAVA_HOME", javaHome.getAbsolutePath());
        env.put("ANDROID_HOME", sdk.getAbsolutePath());
        env.put("ANDROID_SDK_ROOT", sdk.getAbsolutePath());
        File gradleUserHome = new File(toolRoot, "gradle-home");
        if (!gradleUserHome.exists()) gradleUserHome.mkdirs();
        env.put("GRADLE_USER_HOME", gradleUserHome.getAbsolutePath());
        env.put("HOME", toolRoot.getAbsolutePath());
        String path = new File(javaHome, "bin").getAbsolutePath() + ":" + new File(sdk, "build-tools/34.0.4").getAbsolutePath() + ":/system/bin:/system/xbin";
        env.put("PATH", path);
        return env;
    }

    private ProcessResult runCommand(List<String> command, File cwd, Map<String, String> envAdditions, String stdin,
                                     int timeoutMinutes, ProgressListener listener, int progressStart, int progressEnd, String stage) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(cwd);
        pb.redirectErrorStream(true);
        Map<String, String> env = pb.environment();
        env.putAll(envAdditions);
        Process process = pb.start();
        if (stdin != null) {
            try (OutputStream out = process.getOutputStream()) {
                out.write(stdin.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
        } else {
            try { process.getOutputStream().close(); } catch (Exception ignored) {}
        }

        StringBuilder tail = new StringBuilder();
        Thread reader = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                int pulse = 0;
                while ((line = br.readLine()) != null) {
                    synchronized (tail) {
                        tail.append(line).append('\n');
                        if (tail.length() > 16000) tail.delete(0, tail.length() - 16000);
                    }
                    if (listener != null && progressEnd > progressStart && ++pulse % 18 == 0) {
                        int span = Math.max(1, progressEnd - progressStart);
                        int p = Math.min(progressEnd - 1, progressStart + (pulse / 18) % span);
                        listener.onProgress(p, stage == null ? line : stage + ": " + trimLine(line));
                    }
                }
            } catch (Exception ignored) {}
        }, "w2a-process-reader");
        reader.start();

        boolean finished = process.waitFor(timeoutMinutes, TimeUnit.MINUTES);
        if (!finished) {
            process.destroy();
            process.destroyForcibly();
            throw new IOException("Command timed out: " + join(command));
        }
        reader.join(3000);
        return new ProcessResult(process.exitValue(), tail.toString());
    }

    private static String trimLine(String line) {
        if (line == null) return "working";
        line = line.trim();
        return line.length() > 90 ? line.substring(0, 90) + "..." : line;
    }

    private void installTarComponent(String label, String url, File destination, int step, int total, ProgressListener listener) throws Exception {
        File downloads = new File(toolRoot, "downloads");
        if (!downloads.exists()) downloads.mkdirs();
        File archive = new File(downloads, "part-" + step + ".tar.xz");
        download(label, url, archive, step, total, listener);
        listener.onProgress(percentFor(step, total, 86), "Extracting " + label + "...");
        extractTarXz(archive, destination);
        archive.delete();
    }

    private void installZipComponent(String label, String url, File destination, int step, int total, ProgressListener listener) throws Exception {
        File downloads = new File(toolRoot, "downloads");
        if (!downloads.exists()) downloads.mkdirs();
        File archive = new File(downloads, "part-" + step + ".zip");
        download(label, url, archive, step, total, listener);
        listener.onProgress(percentFor(step, total, 86), "Extracting " + label + "...");
        try (InputStream in = new BufferedInputStream(new FileInputStream(archive))) { unzip(in, destination); }
        archive.delete();
    }

    private void download(String label, String url, File destination, int step, int total, ProgressListener listener) throws Exception {
        listener.onProgress(percentFor(step, total, 0), "Downloading " + label + "...");
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        conn.setRequestProperty("User-Agent", "Web2App-Builder-Pro/LocalBuildTools");
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("Download failed for " + label + " (HTTP " + code + ")");
        long totalBytes = conn.getContentLengthLong();
        long read = 0;
        byte[] buffer = new byte[64 * 1024];
        try (InputStream in = new BufferedInputStream(conn.getInputStream());
             OutputStream out = new BufferedOutputStream(new FileOutputStream(destination))) {
            int n;
            int last = -1;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
                read += n;
                if (totalBytes > 0) {
                    int part = (int) Math.min(85, (read * 85L) / totalBytes);
                    int p = percentFor(step, total, part);
                    if (p != last) {
                        last = p;
                        listener.onProgress(p, "Downloading " + label + "...");
                    }
                }
            }
        } finally {
            conn.disconnect();
        }
        if (destination.length() == 0) throw new IOException("Downloaded file is empty: " + label);
    }

    private static int percentFor(int step, int total, int partPercent) {
        double segment = 70.0 / total;
        return (int) Math.min(70, Math.round(step * segment + segment * (partPercent / 100.0)));
    }

    private void extractTarXz(File archive, File destination) throws Exception {
        try (InputStream fileIn = new BufferedInputStream(new FileInputStream(archive));
             XZInputStream xz = new XZInputStream(fileIn);
             TarArchiveInputStream tar = new TarArchiveInputStream(xz)) {
            TarArchiveEntry entry;
            byte[] buffer = new byte[64 * 1024];
            while ((entry = tar.getNextTarEntry()) != null) {
                File out = safeChild(destination, entry.getName());
                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("Could not create " + out);
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Could not create " + parent);
                if (entry.isSymbolicLink()) {
                    if (out.exists()) out.delete();
                    String target = entry.getLinkName();
                    if (target == null || target.startsWith("/") || target.contains("../")) continue;
                    try { Os.symlink(target, out.getAbsolutePath()); } catch (Throwable ignored) {}
                    continue;
                }
                try (OutputStream fos = new BufferedOutputStream(new FileOutputStream(out))) {
                    int n;
                    while ((n = tar.read(buffer)) != -1) fos.write(buffer, 0, n);
                }
                if ((entry.getMode() & 0111) != 0) out.setExecutable(true, false);
            }
        }
    }

    private void unzip(InputStream input, File destination) throws Exception {
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(input))) {
            ZipEntry entry;
            byte[] buffer = new byte[64 * 1024];
            while ((entry = zip.getNextEntry()) != null) {
                File out = safeChild(destination, entry.getName());
                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("Could not create " + out);
                } else {
                    File parent = out.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Could not create " + parent);
                    try (OutputStream fos = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zip.read(buffer)) != -1) fos.write(buffer, 0, n);
                    }
                }
            }
        }
    }

    private File safeChild(File root, String child) throws Exception {
        File out = new File(root, child);
        String rootPath = root.getCanonicalPath() + File.separator;
        String outPath = out.getCanonicalPath();
        if (!outPath.equals(root.getCanonicalPath()) && !outPath.startsWith(rootPath)) throw new IOException("Unsafe archive path: " + child);
        return out;
    }

    private File findSdkRoot() throws Exception {
        File direct = new File(toolRoot, "android-sdk");
        if (direct.isDirectory()) return direct;
        File marker = findDirectoryContaining(toolRoot, "build-tools");
        if (marker != null) return marker;
        throw new IOException("Android SDK root not found");
    }

    private File findJavaHome() throws Exception {
        File java = findByRelativeSuffix(toolRoot, "/bin/java");
        if (java == null) throw new IOException("OpenJDK java binary not found");
        return java.getParentFile().getParentFile();
    }

    private File findGradleHome() throws Exception {
        File direct = new File(toolRoot, "gradle-6.1.1");
        if (new File(direct, "bin/gradle").isFile()) return direct;
        File gradle = findByRelativeSuffix(toolRoot, "/bin/gradle");
        if (gradle != null && gradle.getAbsolutePath().contains("gradle-6.1.1")) return gradle.getParentFile().getParentFile();
        throw new IOException("Gradle 6.1.1 not found");
    }

    private File getAapt2() throws Exception { return new File(findSdkRoot(), "build-tools/34.0.4/aapt2"); }
    private File getZipAlign() throws Exception { return new File(findSdkRoot(), "build-tools/34.0.4/zipalign"); }

    private String getBuildToolsUrl() throws Exception {
        String arch = getArchitectureLabel();
        if (arch.equals("arm64-v8a")) return BUILD_TOOLS_ARM64_URL;
        if (arch.equals("armeabi-v7a")) return BUILD_TOOLS_ARM_URL;
        throw new IOException("Unsupported CPU architecture for local Android build: " + arch);
    }

    private String getJdkUrl() throws Exception {
        String arch = getArchitectureLabel();
        if (arch.equals("arm64-v8a")) return JDK11_ARM64_URL;
        if (arch.equals("armeabi-v7a")) return JDK11_ARM_URL;
        throw new IOException("Unsupported CPU architecture for local Android build: " + arch);
    }

    private void ensureSupportedArchitecture() throws Exception {
        String arch = getArchitectureLabel();
        if (!arch.equals("arm64-v8a") && !arch.equals("armeabi-v7a")) {
            throw new IOException("Local build tools currently support ARM/ARM64 Android devices only. Detected: " + arch);
        }
    }

    private File findByName(File root, String name) {
        if (root == null || !root.exists()) return null;
        Deque<File> queue = new ArrayDeque<>();
        queue.add(root);
        int seen = 0;
        while (!queue.isEmpty() && seen++ < 20000) {
            File f = queue.removeFirst();
            if (f.isFile() && f.getName().equals(name)) return f;
            File[] children = f.isDirectory() ? f.listFiles() : null;
            if (children != null) for (File c : children) queue.addLast(c);
        }
        return null;
    }

    private File findDirectoryNamed(File root, String name) {
        if (root == null || !root.exists()) return null;
        Deque<File> queue = new ArrayDeque<>(); queue.add(root); int seen = 0;
        while (!queue.isEmpty() && seen++ < 20000) {
            File f = queue.removeFirst();
            if (f.isDirectory() && f.getName().equals(name)) return f;
            File[] children = f.isDirectory() ? f.listFiles() : null;
            if (children != null) for (File c : children) if (c.isDirectory()) queue.addLast(c);
        }
        return null;
    }

    private File findDirectoryContaining(File root, String childName) {
        if (root == null || !root.exists()) return null;
        Deque<File> queue = new ArrayDeque<>(); queue.add(root); int seen = 0;
        while (!queue.isEmpty() && seen++ < 20000) {
            File f = queue.removeFirst();
            if (f.isDirectory() && new File(f, childName).isDirectory()) return f;
            File[] children = f.isDirectory() ? f.listFiles() : null;
            if (children != null) for (File c : children) if (c.isDirectory()) queue.addLast(c);
        }
        return null;
    }

    private File findByRelativeSuffix(File root, String suffix) {
        if (root == null || !root.exists()) return null;
        Deque<File> queue = new ArrayDeque<>(); queue.add(root); int seen = 0;
        while (!queue.isEmpty() && seen++ < 30000) {
            File f = queue.removeFirst();
            if (f.isFile() && f.getAbsolutePath().replace('\\', '/').endsWith(suffix)) return f;
            File[] children = f.isDirectory() ? f.listFiles() : null;
            if (children != null) for (File c : children) queue.addLast(c);
        }
        return null;
    }

    private void copyDirectory(File source, File target) throws Exception {
        if (source.isDirectory()) {
            if (!target.exists() && !target.mkdirs()) throw new IOException("Could not create " + target);
            File[] children = source.listFiles();
            if (children != null) for (File child : children) copyDirectory(child, new File(target, child.getName()));
        } else {
            try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(target)) {
                byte[] buffer = new byte[64 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            if (source.canExecute()) target.setExecutable(true, false);
        }
    }

    private static void deleteRecursive(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory() && !java.nio.file.Files.isSymbolicLink(file.toPath())) {
            File[] children = file.listFiles();
            if (children != null) for (File c : children) deleteRecursive(c);
        }
        try { file.delete(); } catch (Exception ignored) {}
    }

    private static void writeText(File file, String text) throws Exception {
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Could not create " + parent);
        try (FileOutputStream out = new FileOutputStream(file, false)) { out.write(text.getBytes(StandardCharsets.UTF_8)); }
    }

    private static String readText(File file) throws Exception {
        try (InputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toString("UTF-8");
        }
    }

    private static String sanitizeBaseName(String name) {
        String s = name == null ? "Web2App" : name.trim().replaceAll("[^a-zA-Z0-9._-]+", "_");
        if (s.isEmpty()) s = "Web2App";
        return s;
    }

    private static String repeatedYes(int count) {
        StringBuilder b = new StringBuilder(count * 2);
        for (int i = 0; i < count; i++) b.append("y\n");
        return b.toString();
    }

    private static String join(List<String> values) {
        StringBuilder b = new StringBuilder();
        for (String v : values) { if (b.length() > 0) b.append(' '); b.append(v); }
        return b.toString();
    }

    private static final class ProcessResult {
        final int exitCode;
        final String tail;
        ProcessResult(int exitCode, String tail) { this.exitCode = exitCode; this.tail = tail; }
    }
}
