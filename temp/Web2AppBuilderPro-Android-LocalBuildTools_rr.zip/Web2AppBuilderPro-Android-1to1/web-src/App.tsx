
import React, { useState } from 'react';
import { Smartphone, Download, Settings, Layers, Calendar, RefreshCw, Code, Copy, Check, AppWindow, X, Server, Cpu } from 'lucide-react';
import { AppConfig, DEFAULT_CONFIG } from './types';
import ConfigForm from './components/ConfigForm';
import { generateAndroidZip } from './services/zipGenerator';

const SECRET_TAP_TARGET = 7;

type BuildToolsStatus = {
  installed: boolean;
  installing?: boolean;
  building?: boolean;
  arch?: string;
  message?: string;
};

const App: React.FC = () => {
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [isGenerating, setIsGenerating] = useState(false);
  const [mode, setMode] = useState<'webview' | 'builder'>('webview'); // 'webview' = standard, 'builder' = Web2App App mode
  const [showPromptModal, setShowPromptModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [secretTapCount, setSecretTapCount] = useState(0);
  const [showBuildTools, setShowBuildTools] = useState(false);
  const [buildToolsStatus, setBuildToolsStatus] = useState<BuildToolsStatus>({ installed: false, message: 'Not checked' });
  const [buildToolsProgress, setBuildToolsProgress] = useState(0);
  const [buildToolsStage, setBuildToolsStage] = useState('');

  const handleConfigChange = (newConfig: Partial<AppConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      // Pass the current mode to the generator
      await generateAndroidZip(config, mode);
    } catch (error) {
      console.error("Failed to generate zip", error);
      alert("Error generating project: " + (error instanceof Error ? error.message : "Unknown error"));
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleMode = () => {
    setMode(prev => prev === 'webview' ? 'builder' : 'webview');
  };

  const readBuildToolsStatus = () => {
    const androidBridge = (window as any).AndroidFunction;
    if (!androidBridge?.getBuildToolsStatus) {
      setBuildToolsStatus({ installed: false, message: 'Local build bridge unavailable in browser mode.' });
      return;
    }
    try {
      const raw = androidBridge.getBuildToolsStatus();
      const status = typeof raw === 'string' ? JSON.parse(raw) : raw;
      setBuildToolsStatus(status || { installed: false, message: 'Unknown status' });
    } catch (error) {
      console.error('Could not read build tools status', error);
      setBuildToolsStatus({ installed: false, message: 'Could not read toolchain status.' });
    }
  };

  const handleSecretTap = () => {
    setSecretTapCount(prev => {
      const tapCount = prev + 1;
      if (tapCount >= SECRET_TAP_TARGET) {
        setShowBuildTools(true);
        setTimeout(readBuildToolsStatus, 0);
        return 0;
      }
      return tapCount;
    });
  };

  const handleInstallBuildTools = () => {
    const androidBridge = (window as any).AndroidFunction;
    if (!androidBridge?.installBuildTools) {
      alert('Build tools installer is only available inside the Android app.');
      return;
    }

    const requestId = `tools-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    setBuildToolsProgress(0);
    setBuildToolsStage('Preparing installer...');
    setBuildToolsStatus(prev => ({ ...prev, installing: true, message: 'Installing local build tools...' }));

    (window as any).__W2A_BUILD_TOOLS_EVENT__ = (event: any) => {
      if (!event || event.requestId !== requestId) return;
      if (typeof event.progress === 'number') setBuildToolsProgress(event.progress);
      if (event.stage) setBuildToolsStage(event.stage);
      if (event.done) {
        setBuildToolsStatus({
          installed: !!event.success,
          installing: false,
          arch: event.arch,
          message: event.message || (event.success ? 'Local build tools are ready.' : 'Tool installation failed.'),
        });
      }
    };

    androidBridge.installBuildTools(requestId);
  };


  const promptText = `Bertindak sebagai Jurutera Frontend Kanan (Senior Frontend Engineer). Bina aplikasi web React (Single Page Application) bernama 'Web2App Builder Pro' menggunakan Tailwind CSS (tema gelap/slate). Aplikasi ini adalah "Android Project Generator" yang berjalan sepenuhnya di browser (Client-side) tanpa backend, menghasilkan fail ZIP.

**OBJEKTIF:**
Mewujudkan tool yang membolehkan pengguna menukar website menjadi aplikasi Android (WebView) atau membina "Aplikasi Pembuat Aplikasi" (Web2App App).

**MOD & FUNGSI (Sangat Penting):**

1.  **Antaramuka (UI):**
    *   Togol mode: "Standard WebView" vs "Web2App App Mode".
    *   Layout: Kiri (Borang), Kanan (Preview Struktur & Info).

2.  **Mode 1: Standard WebView (Default)**
    *   Output: Projek Android WebView biasa untuk website online.
    *   Input Tambahan: Target URL, User Agent.

3.  **Mode 2: Web2App App (Builder Mode)**
    *   Output: Projek Android yang memuatkan \`file:///android_asset/index.html\` (Offline).
    *   **Ciri Khas:** HTML/JS dalaman app ini akan disuntik (injected) ke dalam folder \`assets/\` projek yang dijana. Ini membolehkan APK yang dihasilkan berfungsi sebagai "Generator" offline di telefon Android. Ia akan menjana ZIP dan menyimpannya ke folder Download menggunakan \`JavascriptInterface\`.

4.  **PERINCIAN KONFIGURASI (HARDCODED SYSTEM):**
    *   Gradle: 6.1.1
    *   AGP: 3.6.4
    *   Build Tools: 30.0.3
    *   Min SDK: 26 (Android 8.0)
    *   Target/Compile SDK: 29 (Android 10)
    *   Architecture: arm64-v8a

    *   **Validity (Expiration):**
        *   Input: Nombor hari.
        *   *Default:* 0 (Lifetime).
        *   *Fungsi:* Jika > 0, tambah logik 'Time Bomb' dalam Java yang menutup app selepas X hari dari tarikh install pertama.

    *   **WebView Settings:**
        *   Enable Javascript (Checkbox, Default: True).
        *   Enable Zoom (Checkbox, Default: False).
        *   (REMOVED) Enable Pull-to-Refresh.

    *   **App Icon:**
        *   Upload fail imej. Mesti auto-resize guna Canvas ke folder mipmap (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi).`;

  const copyPrompt = async () => {
    try {
      const androidBridge = (window as any).AndroidFunction;
      if (androidBridge?.copyText) {
        androidBridge.copyText(promptText);
      } else {
        await navigator.clipboard.writeText(promptText);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy prompt', error);
      alert('Unable to copy prompt.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8 pb-20">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-slate-700 pb-6 gap-4">
          <div>
            <h1 onClick={handleSecretTap} className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent flex items-center gap-3">
              <Smartphone className="w-8 h-8 text-blue-500" />
              {mode === 'webview' ? 'Web2App Builder Pro' : 'Web2App App Generator'}
            </h1>
            <p className="text-slate-400 mt-2">
              {mode === 'webview' 
                ? 'Generate a complete Android WebView Project from a URL.' 
                : 'Generate a local HTML/Asset based Android Project shell.'}
            </p>
          </div>

          <div className="flex flex-col gap-3 w-full md:w-auto items-end">
            <button 
              onClick={toggleMode}
              className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-medium transition-all w-full md:w-auto ${mode === 'builder' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-600'}`}
            >
              {mode === 'webview' ? (
                <>
                  <AppWindow className="w-4 h-4" />
                  Switch to Web2App App
                </>
              ) : (
                <>
                  <Smartphone className="w-4 h-4" />
                  Back to Standard Builder
                </>
              )}
            </button>
            
            <button 
              onClick={() => setShowPromptModal(true)}
              className="flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg font-medium bg-slate-800/50 text-blue-400 border border-blue-500/30 hover:bg-slate-700 hover:border-blue-500/50 transition-all text-xs"
            >
              <Code className="w-3 h-3" />
              Create your own
            </button>
          </div>
        </header>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Form */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-xl">
              <div className="flex items-center gap-2 mb-6 text-xl font-semibold text-white border-b border-slate-700 pb-2">
                <Settings className="w-5 h-5 text-indigo-400" />
                {mode === 'webview' ? 'WebView Configuration' : 'Local App Configuration'}
              </div>
              <ConfigForm config={config} onChange={handleConfigChange} mode={mode} />
            </div>
          </div>

          {/* Right Column: Preview / Info */}
          <div className="space-y-6">
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-xl">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-400" />
                Project Structure
              </h3>
              <ul className="space-y-3 text-sm text-slate-300 font-mono">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  app/src/main/java
                </li>
                {mode === 'builder' && (
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                    app/src/main/assets (Local HTML)
                  </li>
                )}
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                  AndroidManifest.xml
                </li>
                 <li className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  build.gradle (Project)
                </li>
              </ul>

              {/* HARDCODED SYSTEM SETTINGS DISPLAY */}
              <div className="mt-6 p-4 bg-slate-900 rounded border border-slate-700 space-y-3">
                <div className="flex items-center gap-2 text-xs text-slate-500 uppercase tracking-wider border-b border-slate-800 pb-2 mb-2">
                    <Server className="w-3 h-3" />
                    System Configuration
                </div>
                
                <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Gradle Version</span>
                      <span className="text-emerald-400 font-mono font-medium">6.1.1</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Android Plugin (AGP)</span>
                      <span className="text-emerald-400 font-mono font-medium">3.6.4</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Build Tools</span>
                      <span className="text-emerald-400 font-mono font-medium">30.0.3</span>
                    </div>
                     <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Java Version</span>
                      <span className="text-emerald-400 font-mono font-medium">1.8 (Java 8)</span>
                    </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 uppercase tracking-wider border-b border-slate-800 pb-2 pt-2 mb-2">
                    <Cpu className="w-3 h-3" />
                    Targeting
                </div>

                <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Architecture</span>
                      <span className="text-emerald-400 font-mono font-medium">arm64-v8a</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Min SDK</span>
                      <span className="text-emerald-400 font-mono font-medium">26 (Android 8.0)</span>
                    </div>
                     <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Compile/Target SDK</span>
                      <span className="text-emerald-400 font-mono font-medium">29 (Android 10)</span>
                    </div>
                </div>
              </div>
            </div>

            {config.expirationDays > 0 && (
              <div className="bg-red-900/20 rounded-xl p-6 border border-red-500/30 shadow-xl">
                 <h3 className="text-lg font-semibold text-red-400 mb-2 flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Expiration Active
                </h3>
                <p className="text-sm text-red-200">
                  This app will automatically stop working on 
                  <strong className="block mt-1 text-lg">
                    {new Date(Date.now() + config.expirationDays * 24 * 60 * 60 * 1000).toLocaleDateString()}
                  </strong>
                  (Calculated from generation time)
                </p>
              </div>
            )}
            
            <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/30">
               <p className="text-xs text-blue-200 italic text-center">
                 "No AI used in generation. Pure template logic."
               </p>
            </div>

          </div>
        </div>

        {/* Generate Button Footer */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-slate-900/90 backdrop-blur-lg border-t border-slate-700 z-50 flex justify-center">
            <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full max-w-5xl flex items-center justify-center gap-3 px-8 py-4 rounded-xl font-bold text-lg shadow-xl transition-all ${
              isGenerating 
                ? 'bg-slate-700 cursor-not-allowed text-slate-400' 
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white hover:shadow-blue-500/25 active:scale-95'
            }`}
          >
            {isGenerating ? (
              <>
                <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Building Project...
              </>
            ) : (
              <>
                <Download className="w-6 h-6" />
                Generate {mode === 'webview' ? 'WebView App' : 'Local App'}
              </>
            )}
          </button>
        </div>

        {/* Prompt Modal */}
        {showPromptModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-slate-800 rounded-xl border border-slate-700 w-full max-w-3xl max-h-[80vh] flex flex-col shadow-2xl">
              <div className="flex items-center justify-between p-6 border-b border-slate-700">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Code className="w-5 h-5 text-blue-400" />
                  Prompt for AI Generation
                </h3>
                <button 
                  onClick={() => setShowPromptModal(false)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <X />
                </button>
              </div>
              <div className="p-6 overflow-y-auto custom-scrollbar">
                <p className="text-sm text-slate-400 mb-4">
                  Copy this prompt and paste it into ChatGPT, Claude, or Gemini to recreate a tool exactly like this one.
                </p>
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 relative group">
                  <pre className="text-slate-300 whitespace-pre-wrap font-mono text-sm leading-relaxed">
                    {promptText}
                  </pre>
                  <button
                    onClick={copyPrompt}
                    className="absolute top-4 right-4 p-2 bg-slate-800 rounded-md border border-slate-700 hover:bg-slate-700 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-300" />}
                  </button>
                </div>
              </div>
              <div className="p-6 border-t border-slate-700 flex justify-end">
                <button
                  onClick={copyPrompt}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                  {copied ? 'Copied!' : 'Copy to Clipboard'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Hidden Local Build Tools Modal - unlock by tapping the title 7 times */}
        {showBuildTools && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-slate-800 rounded-xl border border-slate-700 w-full max-w-3xl flex flex-col shadow-2xl">
              <div className="flex items-center justify-between p-6 border-b border-slate-700">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-emerald-400" />
                  Local Build Tools
                </h3>
                <button
                  onClick={() => setShowBuildTools(false)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <X />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="bg-slate-900 rounded-lg border border-slate-700 p-4 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Toolchain Status</span>
                    <span className={buildToolsStatus.installed ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                      {buildToolsStatus.installed ? 'READY' : buildToolsStatus.installing ? 'INSTALLING' : 'NOT INSTALLED'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Device Architecture</span>
                    <span className="text-slate-300 font-mono">{buildToolsStatus.arch || 'Detect on device'}</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {buildToolsStatus.message || 'When these tools are absent, Generate keeps the original source-ZIP behavior.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div className="p-3 bg-slate-900 rounded border border-slate-700"><span className="text-slate-400">JDK</span><strong className="block text-white mt-1">OpenJDK 11 / Android</strong></div>
                  <div className="p-3 bg-slate-900 rounded border border-slate-700"><span className="text-slate-400">Gradle</span><strong className="block text-white mt-1">6.1.1</strong></div>
                  <div className="p-3 bg-slate-900 rounded border border-slate-700"><span className="text-slate-400">Android Platform</span><strong className="block text-white mt-1">SDK 29</strong></div>
                  <div className="p-3 bg-slate-900 rounded border border-slate-700"><span className="text-slate-400">ARM Build Tools</span><strong className="block text-white mt-1">34.0.4 → 30.0.3 alias</strong></div>
                </div>

                {buildToolsStatus.installing && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>{buildToolsStage || 'Installing...'}</span>
                      <span>{Math.max(0, Math.min(100, Math.round(buildToolsProgress)))}%</span>
                    </div>
                    <div className="w-full h-2 bg-slate-700 rounded-full">
                      <div className="h-2 bg-blue-600 rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, buildToolsProgress))}%` }} />
                    </div>
                  </div>
                )}

                <div className="bg-blue-900/20 rounded-lg border border-blue-500/30 p-4">
                  <p className="text-xs text-blue-200 leading-relaxed">
                    Generate remains safe to use before installation: it will save the project ZIP exactly as before. Once READY, Generate builds and signs an installable APK and adds it under <strong>APK/</strong> inside the same ZIP.
                  </p>
                </div>
              </div>

              <div className="p-6 border-t border-slate-700 flex gap-3 justify-end">
                <button
                  onClick={readBuildToolsStatus}
                  disabled={!!buildToolsStatus.installing}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Refresh
                </button>
                <button
                  onClick={handleInstallBuildTools}
                  disabled={!!buildToolsStatus.installing}
                  className={`px-6 py-2 text-white rounded-lg font-medium transition-colors flex items-center gap-2 ${buildToolsStatus.installing ? 'bg-slate-700 cursor-not-allowed text-slate-400' : buildToolsStatus.installed ? 'bg-emerald-600' : 'bg-blue-600 hover:bg-blue-500'}`}
                >
                  {buildToolsStatus.installing ? <RefreshCw className="w-4 h-4 animate-spin" /> : buildToolsStatus.installed ? <Check className="w-4 h-4" /> : <Download className="w-4 h-4" />}
                  {buildToolsStatus.installed ? 'Repair / Reinstall Tools' : 'Download & Install Tools'}
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default App;