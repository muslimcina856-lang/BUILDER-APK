# Local Build Tools - Ringkasan

**Unlock:** tap tajuk `Web2App Builder Pro` 7 kali.

**Tanpa tools:** Generate = ZIP source biasa.

**Dengan status READY:** Generate = ZIP source + `APK/<AppName>.apk` yang telah di-zipalign, sign dan verify.

**Jika build gagal:** source ZIP tetap cuba disimpan.

**Tools:** JDK 11 + Gradle 6.1.1 + Android SDK 29 + Android ARM build-tools 34.0.4.

**CPU local build:** ARM64 / ARM32. x86 menggunakan fallback ZIP biasa.

**Internet:** diperlukan semasa pemasangan awal toolchain dan apabila Gradle perlu mengambil dependency yang belum berada dalam cache. Selepas dependency lengkap/cached, build seterusnya boleh menggunakan cache tempatan.

**READY check:** installer melakukan self-test Gradle dan tidak menanda READY jika compiler tidak benar-benar berfungsi pada device.
