package com.virtualize.androidx.earlstore

import android.content.Context
import androidx.compose.runtime.mutableStateListOf

data class VirtualDevice(
    val id: String,
    val name: String,
    val model: String,
    val androidVersion: String,
    var isRooted: Boolean,
    var location: String,
    var androidId: String = DeviceManager.generateRandomHex(16),
    var imei: String = DeviceManager.generateRandomDigits(15),
    var macAddress: String = DeviceManager.generateRandomMac(),
    var serialNumber: String = DeviceManager.generateRandomHex(12).uppercase(),
    var phoneNumber: String = DeviceManager.generateRandomPhoneNumber(),
    var processor: String = DeviceManager.generateRandomProcessor(),
    var isGpuAccelerated: Boolean = true,
    var isRootCloaked: Boolean = true
)

object DeviceManager {
    val virtualDevices = mutableStateListOf<VirtualDevice>()

    fun addDevice(name: String, model: String, androidVersion: String) {
        virtualDevices.add(
            VirtualDevice(
                id = System.currentTimeMillis().toString(),
                name = name,
                model = model,
                androidVersion = androidVersion,
                isRooted = false,
                location = "None"
            )
        )
    }

    fun refreshIdentity(deviceId: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(
                androidId = generateRandomHex(16),
                imei = generateRandomDigits(15),
                macAddress = generateRandomMac(),
                serialNumber = generateRandomHex(12).uppercase(),
                phoneNumber = generateRandomPhoneNumber(),
                processor = generateRandomProcessor()
            )
        }
    }

    fun renameDevice(deviceId: String, newName: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(name = newName)
        }
    }

    fun toggleRoot(deviceId: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(isRooted = !device.isRooted)
        }
    }

    fun toggleGpuAcceleration(deviceId: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(isGpuAccelerated = !device.isGpuAccelerated)
        }
    }

    fun toggleRootCloaking(deviceId: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(isRootCloaked = !device.isRootCloaked)
        }
    }

    fun setLocation(deviceId: String, location: String) {
        val index = virtualDevices.indexOfFirst { it.id == deviceId }
        if (index != -1) {
            val device = virtualDevices[index]
            virtualDevices[index] = device.copy(location = location)
        }
    }

    fun generateRandomHex(length: Int): String {
        val chars = "0123456789abcdef"
        return (1..length).map { chars.random() }.joinToString("")
    }

    fun generateRandomDigits(length: Int): String {
        return (1..length).map { (0..9).random() }.joinToString("")
    }

    fun generateRandomMac(): String {
        val chars = "0123456789ABCDEF"
        return (1..6).joinToString(":") { 
            "${chars.random()}${chars.random()}"
        }
    }

    fun generateRandomPhoneNumber(): String {
        val prefixes = listOf("+6011", "+6012", "+6013", "+6014", "+6016", "+6017", "+6018", "+6019")
        return "${prefixes.random()}${generateRandomDigits(7)}"
    }

    fun generateRandomProcessor(): String {
        val processors = listOf(
            "Snapdragon 8 Gen 3", "Snapdragon 8 Gen 2", "Snapdragon 8+ Gen 1",
            "Exynos 2400", "Exynos 2200", "Dimensity 9300", "Dimensity 9200+",
            "Apple A17 Pro", "Apple A16 Bionic", "Google Tensor G3"
        )
        return processors.random()
    }
}
