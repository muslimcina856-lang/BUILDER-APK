package com.virtualize.androidx.earlstore

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.virtualize.androidx.earlstore.ui.theme.VirtualAndroidTheme

class VirtualLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val deviceId = intent.getStringExtra("DEVICE_ID") ?: ""
        val deviceName = intent.getStringExtra("DEVICE_NAME") ?: "Virtual Device"

        setContent {
            VirtualAndroidTheme {
                VirtualLauncherScreen(deviceId, deviceName)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualLauncherScreen(deviceId: String, deviceName: String) {
    val context = LocalContext.current
    var showImportDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    if (showImportDialog) {
        ImportAppDialog(onDismiss = { showImportDialog = false })
    }

    if (showExportDialog) {
        ExportAppDialog(onDismiss = { showExportDialog = false })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(deviceName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("VDevice System Active", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Settings inside VM */ }) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            
            // System Apps Grid
            Text("System Apps", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
            
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            ) {
                item { AppIcon("Play Store", Icons.Default.Shop, Color(0xFF4285F4)) }
                item { AppIcon("Chrome", Icons.Default.Language, Color(0xFFEA4335)) }
                item { AppIcon("Files", Icons.Default.Folder, Color(0xFFFBBC05)) }
                item { AppIcon("Gallery", Icons.Default.Image, Color(0xFF34A853)) }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Management Section
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("App Management", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ManagementButton(
                            label = "Import App",
                            sub = "From Host",
                            icon = Icons.Default.Download,
                            color = MaterialTheme.colorScheme.primary,
                            onClick = { showImportDialog = true }
                        )
                        ManagementButton(
                            label = "Export App",
                            sub = "To Host",
                            icon = Icons.Default.Upload,
                            color = MaterialTheme.colorScheme.secondary,
                            onClick = { showExportDialog = true }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.ManagementButton(label: String, sub: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.weight(1f).clickable { onClick() },
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = color)
            Spacer(modifier = Modifier.height(8.dp))
            Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun AppIcon(name: String, icon: ImageVector, color: Color) {
    Column(
        modifier = Modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(56.dp).clip(CircleShape).background(color.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(28.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(name, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun ImportAppDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import from Host") },
        text = { Text("Searching for applications on your phone... (Placeholder)") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Scan") } }
    )
}

@Composable
fun ExportAppDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export to Host") },
        text = { Text("Select applications from this virtual device to export... (Placeholder)") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Select") } }
    )
}
