package com.virtualize.androidx.earlstore

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.virtualize.androidx.earlstore.ui.theme.VirtualAndroidTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VirtualAndroidTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var currentScreen by remember { mutableStateOf("Home") }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { 
                    Text("Virtual Android", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) 
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            ) {
                NavigationBarItem(
                    selected = currentScreen == "Home",
                    onClick = { currentScreen = "Home" },
                    label = { Text("Home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = currentScreen == "VDevice",
                    onClick = { currentScreen = "VDevice" },
                    label = { Text("VDevice") },
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = currentScreen == "Settings",
                    onClick = { currentScreen = "Settings" },
                    label = { Text("Settings") },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (currentScreen) {
                "Home" -> HomeScreen()
                "VDevice" -> CreateVDeviceScreen(onCreated = { currentScreen = "Home" })
                "Settings" -> SettingsScreen()
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val devices = DeviceManager.virtualDevices
    var selectedDevice by remember { mutableStateOf<VirtualDevice?>(null) }
    var deviceToRename by remember { mutableStateOf<VirtualDevice?>(null) }

    if (selectedDevice != null) {
        DeviceInfoDialog(device = selectedDevice!!, onDismiss = { selectedDevice = null })
    }

    if (deviceToRename != null) {
        RenameDeviceDialog(device = deviceToRename!!, onDismiss = { deviceToRename = null })
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Your Virtual Devices", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Long press to rename device", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))
        
        if (devices.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)).background(Color.LightGray.copy(alpha = 0.3f)), contentAlignment = Alignment.Center) {
                Text("No devices created yet.", color = Color.Gray)
            }
        } else {
            LazyColumn {
                items(devices) { device ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .combinedClickable(
                                onClick = { selectedDevice = device },
                                onLongClick = { deviceToRename = device }
                            )
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(device.name, fontWeight = FontWeight.Bold)
                                Text("${device.model} | Android ${device.androidVersion}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RenameDeviceDialog(device: VirtualDevice, onDismiss: () -> Unit) {
    var newName by remember { mutableStateOf(device.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename Device") },
        text = {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("New Name") },
                singleLine = true
            )
        },
        confirmButton = {
            Button(onClick = {
                DeviceManager.renameDevice(device.id, newName)
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceInfoDialog(device: VirtualDevice, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var showCloneDialog by remember { mutableStateOf(false) }

    if (showCloneDialog) {
        CloneAppDialog(deviceId = device.id, onDismiss = { showCloneDialog = false })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(device.name, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                InfoRow("Model", device.model)
                InfoRow("Processor", device.processor)
                InfoRow("IMEI", device.imei)
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { 
                        VirtualEngine.launch(context, device)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Launch VDevice")
                }

                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showCloneDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clone App")
                    }
                    
                    OutlinedButton(
                        onClick = { DeviceManager.refreshIdentity(device.id); onDismiss() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Text("Refresh")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun CloneAppDialog(deviceId: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    // In a real app, you would fetch installed apps list here
    val dummyApps = listOf("WhatsApp", "Telegram", "Facebook", "TikTok", "Instagram")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select App to Clone") },
        text = {
            LazyColumn {
                items(dummyApps) { appName ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { 
                        VirtualEngine.cloneApp(context, deviceId, "com.example.${appName.lowercase()}")
                        onDismiss()
                    }.padding(12.dp)) {
                        Text(appName)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = FontWeight.Medium, color = Color.Gray)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateVDeviceScreen(onCreated: () -> Unit) {
    val models = remember { generateDeviceModels() }
    var searchQuery by remember { mutableStateOf("") }
    
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Create New VDevice", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            placeholder = { Text("Search Model (e.g. iQOO 13, S24)") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        
        LazyColumn {
            items(models.filter { it.name.contains(searchQuery, ignoreCase = true) }) { model ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    onClick = { 
                        DeviceManager.addDevice("VDevice ${DeviceManager.virtualDevices.size + 1}", model.name, model.androidVersion)
                        onCreated()
                    }
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(model.name, fontWeight = FontWeight.Bold)
                            Text("Android ${model.androidVersion} | ${model.brand}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    var showRootList by remember { mutableStateOf(false) }

    if (showRootList) {
        RootManagementDialog(onDismiss = { showRootList = false })
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        
        Spacer(modifier = Modifier.height(24.dp))
        
        SettingsItem(title = "Advanced Management", subtitle = "Root, GPU, and Cloaking", icon = Icons.Default.SettingsSuggest, onClick = { showRootList = true })
        SettingsItem(title = "Mock Location", subtitle = "Set custom GPS coordinates", icon = Icons.Default.LocationOn)
        
        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
        
        Text("About Earl Store", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Aplikasi Virtual Android ini dibina khas untuk komuniti Earl Store. Diuruskan oleh @earlxz.")
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/earlxz"))) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.Person, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Contact Us")
            }

            Button(
                onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/earlstore2004"))) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Channel")
            }
        }
    }
}

@Composable
fun RootManagementDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Advanced Device Control") },
        text = {
            LazyColumn {
                items(DeviceManager.virtualDevices) { device ->
                    Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Text(device.name, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Root Access", modifier = Modifier.weight(1f))
                            Switch(checked = device.isRooted, onCheckedChange = { DeviceManager.toggleRoot(device.id) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("GPU Acceleration", modifier = Modifier.weight(1f))
                            Switch(checked = device.isGpuAccelerated, onCheckedChange = { DeviceManager.toggleGpuAcceleration(device.id) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Root Cloaking", modifier = Modifier.weight(1f))
                            Switch(checked = device.isRootCloaked, onCheckedChange = { DeviceManager.toggleRootCloaking(device.id) })
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
fun SettingsItem(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit = {}) {
    Row(modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}

data class DeviceModel(val name: String, val brand: String, val androidVersion: String)

fun generateDeviceModels(): List<DeviceModel> {
    val list = mutableListOf<DeviceModel>()
    list.add(DeviceModel("iQOO 13", "iQOO", "15"))
    list.add(DeviceModel("Samsung Galaxy S24 Ultra", "Samsung", "14"))
    list.add(DeviceModel("Google Pixel 9 Pro XL", "Google", "15"))
    list.add(DeviceModel("ROG Phone 8 Pro", "ASUS", "14"))
    list.add(DeviceModel("Xiaomi 14 Ultra", "Xiaomi", "14"))
    
    // Samsung (More)
    list.add(DeviceModel("Samsung Galaxy Z Fold 6", "Samsung", "14"))
    list.add(DeviceModel("Samsung Galaxy Z Flip 6", "Samsung", "14"))
    
    // Add 100+ more real models logic...
    for (i in 1..100) {
        list.add(DeviceModel("Real Model $i", "Various", "14"))
    }
    return list
}
