import 'dart:async';

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../game/game_controller.dart';
import '../game/game_data.dart';
import '../game/game_state.dart';
import '../flame/warung_kita_game.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.controller,
    required this.onExit,
  });

  final GameController controller;
  final Future<void> Function() onExit;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with WidgetsBindingObserver {
  int _tab = 0;

  GameController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      unawaited(controller.save());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Scaffold(
          appBar: _buildTopBar(),
          body: _buildTab(),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (index) {
              if (controller.serviceActive && index != 0) {
                _showNotice('Selesaikan operasi warung sebelum membuka bahagian lain.');
                return;
              }
              setState(() => _tab = index);
            },
            destinations: const [
              NavigationDestination(icon: Icon(Icons.storefront), label: 'Warung'),
              NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Stok'),
              NavigationDestination(icon: Icon(Icons.restaurant_menu), label: 'Menu'),
              NavigationDestination(icon: Icon(Icons.upgrade), label: 'Naik Taraf'),
              NavigationDestination(icon: Icon(Icons.assessment), label: 'Laporan'),
            ],
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildTopBar() {
    final state = controller.state;
    return AppBar(
      toolbarHeight: 94,
      backgroundColor: AppColors.brown,
      foregroundColor: Colors.white,
      automaticallyImplyLeading: false,
      titleSpacing: 10,
      title: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset('assets/app_icon.png', width: 62, height: 62),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                _StatChip(icon: Icons.payments, text: 'RM ${state.money}'),
                _StatChip(icon: Icons.calendar_today, text: 'Hari ${state.day}'),
                _StatChip(icon: Icons.star, text: 'Rep ${state.reputation}'),
                _StatChip(icon: Icons.store, text: 'Lv.${controller.warungLevel}'),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          tooltip: 'Simpan dan ke menu',
          onPressed: controller.serviceActive ? null : widget.onExit,
          icon: const Icon(Icons.home_rounded),
        ),
      ],
    );
  }

  Widget _buildTab() {
    return switch (_tab) {
      0 => _WarungTab(controller: controller, showNotice: _showNotice, goToMenu: () => setState(() => _tab = 2)),
      1 => _StockTab(controller: controller, showNotice: _showNotice),
      2 => _MenuTab(controller: controller, showNotice: _showNotice),
      3 => _UpgradeTab(controller: controller, showNotice: _showNotice),
      _ => _ReportTab(
          controller: controller,
          showNotice: _showNotice,
          manualSave: () async {
            await controller.save();
            if (mounted) _showNotice('Permainan berjaya disimpan.');
          },
        ),
    };
  }

  void _showNotice(String message) {
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Warung Kita'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Baik'),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.darkBrown.withOpacity(0.55),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.gold),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _WarungTab extends StatefulWidget {
  const _WarungTab({
    required this.controller,
    required this.showNotice,
    required this.goToMenu,
  });

  final GameController controller;
  final ValueChanged<String> showNotice;
  final VoidCallback goToMenu;

  @override
  State<_WarungTab> createState() => _WarungTabState();
}

class _WarungTabState extends State<_WarungTab> {
  late final WarungKitaGame _game;

  GameController get controller => widget.controller;

  @override
  void initState() {
    super.initState();
    _game = WarungKitaGame(controller: controller);
  }

  @override
  void dispose() {
    _game.shutdown();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Operasi Warung Masa Nyata'),
        const SizedBox(height: 8),
        const Text(
          'Pelanggan akan berjalan ke kaunter, membuat pesanan, makan dan keluar secara automatik.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              AspectRatio(
                aspectRatio: 4 / 5,
                child: ColoredBox(
                  color: const Color(0xFFEDD49F),
                  child: GameWidget<WarungKitaGame>(
                    game: _game,
                    loadingBuilder: (context) => const Center(
                      child: CircularProgressIndicator(color: AppColors.orange),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Text(
                  controller.serviceStatus,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.darkBrown,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: LinearProgressIndicator(
                  value: controller.serviceProgress,
                  minHeight: 16,
                  borderRadius: BorderRadius.circular(20),
                  backgroundColor: const Color(0xFF7A3D1E),
                  color: AppColors.green,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Dilayan: ${controller.customersTotal - controller.customersRemaining}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'Baki: ${controller.customersRemaining}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: FilledButton.icon(
                  onPressed: controller.serviceActive
                      ? null
                      : () {
                          final error = controller.startService();
                          if (error != null) widget.showNotice(error);
                        },
                  icon: const Icon(Icons.local_fire_department),
                  label: Text(
                    controller.serviceActive
                        ? 'Simulasi Sedang Berjalan'
                        : 'Buka Warung Hari Ini',
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.green,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: controller.serviceActive
                    ? null
                    : () async => widget.showNotice(
                          await controller.buyBasicBundle(),
                        ),
                icon: const Icon(Icons.shopping_basket),
                label: const Text('Beli Stok Asas'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: controller.serviceActive ? null : widget.goToMenu,
                icon: const Icon(Icons.restaurant_menu),
                label: const Text('Semak Menu'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(54),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Ringkasan Hari Ini', style: _cardTitleStyle),
                const SizedBox(height: 10),
                _InfoLine(
                  label: 'Anggaran pelanggan',
                  value: '${controller.customerCapacity()}',
                ),
                _InfoLine(
                  label: 'Hidangan boleh disediakan',
                  value: '${controller.estimatedServings()}',
                ),
                _InfoLine(
                  label: 'Menu aktif',
                  value:
                      '${controller.availableMenuItems(requireStock: false).length} / ${menuItems.length}',
                ),
                const _InfoLine(label: 'Enjin permainan', value: 'Flame 1.23.0'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _StockTab extends StatelessWidget {
  const _StockTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Inventori Bahan'),
        const SizedBox(height: 8),
        const Text(
          'Beli bahan sebelum membuka warung. Taraf stor memberikan diskaun.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        Image.asset('assets/images/ingredient_storage.png', height: 150, fit: BoxFit.contain),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: controller.serviceActive
              ? null
              : () async => showNotice(await controller.buyBasicBundle()),
          icon: const Icon(Icons.shopping_cart_checkout),
          label: const Text('Beli Pakej Asas'),
          style: FilledButton.styleFrom(backgroundColor: AppColors.green),
        ),
        const SizedBox(height: 12),
        for (final ingredient in ingredients.values) ...[
          Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: AppColors.gold.withOpacity(0.35),
                child: Text(ingredient.name.substring(0, 1)),
              ),
              title: Text(ingredient.name, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('Stok: ${controller.state.inventory[ingredient.id] ?? 0} unit'),
              trailing: FilledButton(
                onPressed: controller.serviceActive
                    ? null
                    : () async => showNotice(await controller.buyStock(ingredient.id, 5)),
                style: FilledButton.styleFrom(
                  minimumSize: const Size(86, 46),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                ),
                child: Text('+5\nRM ${controller.stockPrice(ingredient.id, 5)}', textAlign: TextAlign.center),
              ),
            ),
          ),
          const SizedBox(height: 9),
        ],
      ],
    );
  }
}

class _MenuTab extends StatelessWidget {
  const _MenuTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Menu Jualan'),
        const SizedBox(height: 8),
        const Text(
          'Aktifkan menu yang mahu dijual. Menu tahap 2 dibuka melalui Taraf Warung.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        for (final item in menuItems.values) ...[
          _MenuCard(controller: controller, item: item, showNotice: showNotice),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _MenuCard extends StatelessWidget {
  const _MenuCard({required this.controller, required this.item, required this.showNotice});

  final GameController controller;
  final MenuDefinition item;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    final unlocked = controller.warungLevel >= item.unlockLevel;
    final active = controller.state.menuEnabled[item.id] ?? true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(item.imagePath, width: 116, height: 82, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name, style: _cardTitleStyle),
                  Text('Harga jual: RM ${item.price}'),
                  const SizedBox(height: 4),
                  Text(
                    controller.recipeText(item.recipe),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            FilledButton(
              onPressed: !unlocked || controller.serviceActive
                  ? null
                  : () async => showNotice(await controller.toggleMenu(item.id)),
              style: FilledButton.styleFrom(
                backgroundColor: active ? AppColors.green : const Color(0xFF7F766C),
                minimumSize: const Size(74, 48),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: Text(unlocked ? (active ? 'Aktif' : 'Tutup') : 'Lv.${item.unlockLevel}'),
            ),
          ],
        ),
      ),
    );
  }
}

class _UpgradeTab extends StatelessWidget {
  const _UpgradeTab({required this.controller, required this.showNotice});

  final GameController controller;
  final ValueChanged<String> showNotice;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Naik Taraf Warung'),
        const SizedBox(height: 8),
        const Text(
          'Gunakan keuntungan untuk mengembangkan operasi.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Image.asset('assets/images/kitchen_equipment.png', height: 190, fit: BoxFit.cover),
        ),
        const SizedBox(height: 12),
        for (final definition in upgrades.values) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${definition.name} • Lv.${controller.state.upgradeLevels[definition.id]}',
                          style: _cardTitleStyle,
                        ),
                        const SizedBox(height: 4),
                        Text(definition.description, style: const TextStyle(color: AppColors.muted)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Builder(
                    builder: (context) {
                      final level = controller.state.upgradeLevels[definition.id] ?? 1;
                      final maxed = level >= definition.maxLevel;
                      return FilledButton(
                        onPressed: maxed || controller.serviceActive
                            ? null
                            : () async => showNotice(await controller.buyUpgrade(definition.id)),
                        style: FilledButton.styleFrom(
                          backgroundColor: AppColors.green,
                          minimumSize: const Size(88, 52),
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                        ),
                        child: Text(maxed ? 'MAKS' : 'Naik\nRM ${controller.upgradeCost(definition.id)}', textAlign: TextAlign.center),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _ReportTab extends StatelessWidget {
  const _ReportTab({
    required this.controller,
    required this.showNotice,
    required this.manualSave,
  });

  final GameController controller;
  final ValueChanged<String> showNotice;
  final Future<void> Function() manualSave;

  @override
  Widget build(BuildContext context) {
    final report = controller.state.lastReport;
    final stats = controller.state.stats;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Laporan Perniagaan'),
        const SizedBox(height: 12),
        if (report == null)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Belum ada laporan. Buka warung untuk memulakan hari pertama.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 17),
              ),
            ),
          )
        else
          _DailyReportCard(report: report),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Statistik Keseluruhan', style: _cardTitleStyle),
                const SizedBox(height: 8),
                _InfoLine(label: 'Hari dimainkan', value: '${stats.daysPlayed}'),
                _InfoLine(label: 'Pelanggan dilayan', value: '${stats.served}'),
                _InfoLine(label: 'Pelanggan terlepas', value: '${stats.missed}'),
                _InfoLine(label: 'Jumlah hasil', value: 'RM ${stats.revenue}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: manualSave,
          icon: const Icon(Icons.save),
          label: const Text('Simpan Sekarang'),
          style: FilledButton.styleFrom(backgroundColor: AppColors.green),
        ),
        const SizedBox(height: 8),
        const Text(
          'Kemajuan turut disimpan secara automatik selepas pembelian dan selepas hari operasi tamat.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ],
    );
  }
}

class _DailyReportCard extends StatelessWidget {
  const _DailyReportCard({required this.report});

  final GameReport report;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Keputusan Hari ${report.day}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.brown)),
            const SizedBox(height: 12),
            _InfoLine(label: 'Pelanggan dilayan', value: '${report.served}'),
            _InfoLine(label: 'Pelanggan terlepas', value: '${report.missed}'),
            _InfoLine(label: 'Jualan dan bonus', value: 'RM ${report.revenue}'),
            _InfoLine(label: 'Tip pelanggan', value: 'RM ${report.tips}'),
            _InfoLine(label: 'Reputasi diperoleh', value: '+${report.reputation}'),
            const Divider(height: 24),
            Text(report.note, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.greenDark, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: AppColors.brown,
        fontSize: 27,
        fontWeight: FontWeight.w900,
        shadows: [Shadow(color: Color(0xFFF5C96E), offset: Offset(1, 1))],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.darkBrown))),
          Text(value, style: const TextStyle(color: AppColors.greenDark, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

const _cardTitleStyle = TextStyle(
  color: AppColors.brown,
  fontSize: 19,
  fontWeight: FontWeight.w900,
);
