import 'dart:math';

import 'game_data.dart';

class GameReport {
  GameReport({
    required this.day,
    required this.served,
    required this.missed,
    required this.revenue,
    required this.tips,
    required this.reputation,
    required this.note,
  });

  final int day;
  final int served;
  final int missed;
  final int revenue;
  final int tips;
  final int reputation;
  final String note;

  Map<String, dynamic> toJson() => {
        'day': day,
        'served': served,
        'missed': missed,
        'revenue': revenue,
        'tips': tips,
        'reputation': reputation,
        'note': note,
      };

  factory GameReport.fromJson(Map<Object?, Object?> json) {
    return GameReport(
      day: _toInt(json['day']),
      served: _toInt(json['served']),
      missed: _toInt(json['missed']),
      revenue: _toInt(json['revenue']),
      tips: _toInt(json['tips']),
      reputation: _toInt(json['reputation']),
      note: json['note']?.toString() ?? '',
    );
  }
}

class GameStats {
  GameStats({
    this.served = 0,
    this.missed = 0,
    this.revenue = 0,
    this.daysPlayed = 0,
  });

  int served;
  int missed;
  int revenue;
  int daysPlayed;

  Map<String, dynamic> toJson() => {
        'served': served,
        'missed': missed,
        'revenue': revenue,
        'daysPlayed': daysPlayed,
      };

  factory GameStats.fromJson(Map<Object?, Object?> json) {
    return GameStats(
      served: _toInt(json['served']),
      missed: _toInt(json['missed']),
      revenue: _toInt(json['revenue']),
      daysPlayed: _toInt(json['daysPlayed'] ?? json['days_played']),
    );
  }
}

class GameState {
  GameState({
    required this.money,
    required this.day,
    required this.reputation,
    required this.inventory,
    required this.menuEnabled,
    required this.upgradeLevels,
    required this.stats,
    required this.lastSeen,
    this.lastReport,
  });

  int money;
  int day;
  int reputation;
  final Map<String, int> inventory;
  final Map<String, bool> menuEnabled;
  final Map<String, int> upgradeLevels;
  final GameStats stats;
  int lastSeen;
  GameReport? lastReport;

  factory GameState.fresh() {
    final inventory = <String, int>{
      for (final key in ingredients.keys) key: 8,
    };
    inventory
      ..['rice'] = 18
      ..['egg'] = 14
      ..['chicken'] = 12
      ..['bread'] = 14;

    return GameState(
      money: 280,
      day: 1,
      reputation: 0,
      inventory: inventory,
      menuEnabled: {for (final key in menuItems.keys) key: true},
      upgradeLevels: {
        'warung': 1,
        'kitchen': 1,
        'tables': 1,
        'storage': 1,
      },
      stats: GameStats(),
      lastSeen: DateTime.now().millisecondsSinceEpoch,
    );
  }

  int applyOfflineProgress() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final elapsedMs = (now - lastSeen)
        .clamp(0, const Duration(hours: 4).inMilliseconds)
        .toInt();
    final elapsed = Duration(milliseconds: elapsedMs);
    if (elapsed.inMinutes < 5) {
      lastSeen = now;
      return 0;
    }

    final blocks = elapsed.inMinutes ~/ 5;
    final passive = min(
      180,
      blocks * (2 + upgradeLevels['warung']! + upgradeLevels['tables']!),
    );
    money += passive;
    lastReport = GameReport(
      day: max(0, day - 1),
      served: 0,
      missed: 0,
      revenue: passive,
      tips: 0,
      reputation: 0,
      note: 'Pendapatan tempahan offline: RM $passive',
    );
    lastSeen = now;
    return passive;
  }

  Map<String, dynamic> toJson() => {
        'version': '0.3.1-flutter-flame',
        'money': money,
        'day': day,
        'reputation': reputation,
        'inventory': inventory,
        'menuEnabled': menuEnabled,
        'upgradeLevels': upgradeLevels,
        'stats': stats.toJson(),
        'lastSeen': lastSeen,
        'lastReport': lastReport?.toJson(),
      };

  factory GameState.fromJson(Map<String, dynamic> json) {
    final defaults = GameState.fresh();

    final rawInventory = json['inventory'];
    if (rawInventory is Map) {
      for (final key in ingredients.keys) {
        defaults.inventory[key] = _toInt(rawInventory[key], defaults.inventory[key]!);
      }
    }

    final rawMenu = json['menuEnabled'] ?? json['menu_enabled'];
    if (rawMenu is Map) {
      for (final key in menuItems.keys) {
        defaults.menuEnabled[key] = _toBool(rawMenu[key], true);
      }
    }

    final rawUpgrades = json['upgradeLevels'] ?? json['upgrades'];
    if (rawUpgrades is Map) {
      for (final key in upgrades.keys) {
        defaults.upgradeLevels[key] = max(1, _toInt(rawUpgrades[key], 1));
      }
    }

    final rawStats = json['stats'];
    final parsedStats = rawStats is Map
        ? GameStats.fromJson(rawStats)
        : GameStats();

    final rawReport = json['lastReport'] ?? json['last_report'];
    final parsedReport = rawReport is Map
        ? GameReport.fromJson(rawReport)
        : null;

    return GameState(
      money: _toInt(json['money'], defaults.money),
      day: max(1, _toInt(json['day'], defaults.day)),
      reputation: max(0, _toInt(json['reputation'], defaults.reputation)),
      inventory: defaults.inventory,
      menuEnabled: defaults.menuEnabled,
      upgradeLevels: defaults.upgradeLevels,
      stats: parsedStats,
      lastSeen: _toInt(json['lastSeen'] ?? json['last_seen'], defaults.lastSeen),
      lastReport: parsedReport,
    );
  }
}

int _toInt(Object? value, [int fallback = 0]) {
  if (value is int) return value;
  if (value is num) return value.round();
  return int.tryParse(value?.toString() ?? '') ?? fallback;
}

bool _toBool(Object? value, [bool fallback = false]) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) {
    if (value.toLowerCase() == 'true') return true;
    if (value.toLowerCase() == 'false') return false;
  }
  return fallback;
}
