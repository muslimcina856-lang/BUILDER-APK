import 'dart:math';
import 'dart:ui' as ui;

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/game_controller.dart';
import '../game/game_data.dart';

class WarungKitaGame extends FlameGame {
  WarungKitaGame({required this.controller});

  final GameController controller;
  final Random _random = Random();

  final List<String> _customerAssets = const [
    'student_boy.png',
    'student_girl.png',
    'waiter_male.png',
    'waiter_female.png',
  ];

  final Map<String, ui.Image> _loadedImages = <String, ui.Image>{};

  WarungSceneComponent? _scene;
  bool _sessionRunning = false;
  bool _canSpawn = true;
  bool _disposed = false;
  int _spawned = 0;
  int _customerStyleIndex = 0;
  double _spawnDelay = 0;

  @override
  Color backgroundColor() => const Color(0xFFEDD49F);

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    camera.viewfinder
      ..anchor = Anchor.topLeft
      ..position = Vector2.zero();

    const files = <String>[
      'warung_stall.png',
      'service_counter.png',
      'kitchen_equipment.png',
      'ingredient_storage.png',
      'cook_male.png',
      'cook_female.png',
      'waiter_male.png',
      'waiter_female.png',
      'student_boy.png',
      'student_girl.png',
      'nasi_lemak.png',
      'mee_goreng.png',
      'roti_bakar.png',
      'teh_tarik.png',
      'kopi.png',
      'nasi_ayam.png',
    ];

    final loaded = await images.loadAll(files);
    for (var i = 0; i < files.length; i++) {
      _loadedImages[files[i]] = loaded[i];
    }

    _scene = WarungSceneComponent(
      images: _loadedImages,
      gameSize: size.clone(),
    );
    await world.add(_scene!);

    controller.addListener(_handleControllerChanged);
    _handleControllerChanged();
  }

  @override
  void onGameResize(Vector2 newSize) {
    super.onGameResize(newSize);
    _scene?.resizeTo(newSize);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!_sessionRunning || !controller.serviceActive) return;

    if (_spawnDelay > 0) {
      _spawnDelay -= dt;
      return;
    }

    if (_canSpawn && _spawned < controller.customersTotal) {
      _spawnCustomer();
    }
  }

  void _handleControllerChanged() {
    if (_disposed) return;

    if (controller.serviceActive && !_sessionRunning) {
      _sessionRunning = true;
      _spawned = controller.customersTotal - controller.customersRemaining;
      _canSpawn = true;
      _spawnDelay = 0.25;
    } else if (!controller.serviceActive && _sessionRunning) {
      _sessionRunning = false;
    }
  }

  void _spawnCustomer() {
    final imageName = _customerAssets[
        _customerStyleIndex % _customerAssets.length];
    _customerStyleIndex++;
    final image = _loadedImages[imageName];
    if (image == null) return;

    _canSpawn = false;
    _spawned++;

    final seatOnLeft = _spawned.isOdd;
    world.add(
      CustomerComponent(
        game: this,
        sprite: Sprite(image),
        seatOnLeft: seatOnLeft,
      ),
    );
  }

  CustomerServiceResult resolveCustomer(CustomerComponent customer) {
    final result = controller.serveNextCustomer();
    if (result.served && result.item != null) {
      final imageName = result.item!.imagePath.split('/').last;
      final foodImage = _loadedImages[imageName];
      if (foodImage != null) customer.showFood(foodImage);
    }

    _canSpawn = true;
    _spawnDelay = 0.22 + _random.nextDouble() * 0.18;
    return result;
  }

  Vector2 get entryPoint => Vector2(size.x * 0.5, size.y + size.y * 0.12);

  Vector2 get counterPoint => Vector2(size.x * 0.52, size.y * 0.42);

  Vector2 seatPoint(bool left) {
    return Vector2(
      size.x * (left ? 0.25 : 0.75),
      size.y * (0.68 + _random.nextDouble() * 0.04),
    );
  }

  Vector2 get exitPoint => Vector2(size.x * 1.12, size.y * 0.88);

  double get customerSpeed {
    final kitchenLevel = controller.state.upgradeLevels['kitchen'] ?? 1;
    return size.y * (0.27 + kitchenLevel * 0.012);
  }

  double get orderingDuration {
    final kitchenLevel = controller.state.upgradeLevels['kitchen'] ?? 1;
    return max(0.38, 1.1 - kitchenLevel * 0.1);
  }

  void shutdown() {
    if (_disposed) return;
    _disposed = true;
    controller.removeListener(_handleControllerChanged);
  }

  @override
  void onRemove() {
    shutdown();
    super.onRemove();
  }
}

class WarungSceneComponent extends PositionComponent {
  WarungSceneComponent({
    required this.images,
    required Vector2 gameSize,
  }) : _gameSize = gameSize {
    priority = -100;
    size = gameSize;
  }

  final Map<String, ui.Image> images;
  Vector2 _gameSize;

  void resizeTo(Vector2 newSize) {
    _gameSize = newSize.clone();
    size = newSize;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final width = _gameSize.x;
    final height = _gameSize.y;
    if (width <= 0 || height <= 0) return;

    final wallPaint = Paint()..color = const Color(0xFFF5DCA9);
    final floorPaintA = Paint()..color = const Color(0xFFE7BE74);
    final floorPaintB = Paint()..color = const Color(0xFFDFAE62);
    final borderPaint = Paint()
      ..color = const Color(0xFF8A4A25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(1.0, width * 0.004);

    canvas.drawRect(Rect.fromLTWH(0, 0, width, height * 0.48), wallPaint);

    const columns = 8;
    const rows = 7;
    final tileWidth = width / columns;
    final floorTop = height * 0.40;
    final tileHeight = (height - floorTop) / rows;
    for (var row = 0; row < rows; row++) {
      for (var column = 0; column < columns; column++) {
        final rect = Rect.fromLTWH(
          column * tileWidth,
          floorTop + row * tileHeight,
          tileWidth,
          tileHeight,
        );
        canvas.drawRect(
          rect,
          (row + column).isEven ? floorPaintA : floorPaintB,
        );
        canvas.drawRect(rect, borderPaint);
      }
    }

    final wallLine = Paint()
      ..color = const Color(0xFF6B3418)
      ..strokeWidth = max(2.0, width * 0.012);
    canvas.drawLine(
      Offset(0, floorTop),
      Offset(width, floorTop),
      wallLine,
    );

    _drawAsset(
      canvas,
      'warung_stall.png',
      Rect.fromLTWH(width * 0.16, height * 0.015, width * 0.68, height * 0.29),
    );
    _drawAsset(
      canvas,
      'kitchen_equipment.png',
      Rect.fromLTWH(width * 0.02, height * 0.25, width * 0.28, height * 0.14),
    );
    _drawAsset(
      canvas,
      'ingredient_storage.png',
      Rect.fromLTWH(width * 0.70, height * 0.25, width * 0.27, height * 0.13),
    );
    _drawAsset(
      canvas,
      'service_counter.png',
      Rect.fromLTWH(width * 0.30, height * 0.30, width * 0.40, height * 0.13),
    );
    _drawAsset(
      canvas,
      'cook_female.png',
      Rect.fromLTWH(width * 0.12, height * 0.22, width * 0.17, height * 0.22),
    );
    _drawAsset(
      canvas,
      'waiter_male.png',
      Rect.fromLTWH(width * 0.70, height * 0.25, width * 0.15, height * 0.20),
    );

    _drawDiningSet(canvas, Offset(width * 0.24, height * 0.69), width);
    _drawDiningSet(canvas, Offset(width * 0.76, height * 0.69), width);

    final pathPaint = Paint()
      ..color = const Color(0x55FFF7DD)
      ..strokeWidth = width * 0.10
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(width * 0.5, height * 0.47),
      Offset(width * 0.5, height * 0.96),
      pathPaint,
    );

    final openPaint = Paint()
      ..color = const Color(0xFF58A93B)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(width * 0.44, height * 0.455, width * 0.12, height * 0.025),
        Radius.circular(width * 0.02),
      ),
      openPaint,
    );
  }

  void _drawDiningSet(Canvas canvas, Offset center, double width) {
    final tablePaint = Paint()..color = const Color(0xFF9A572C);
    final tableTopPaint = Paint()..color = const Color(0xFFC97A3B);
    final chairPaint = Paint()..color = const Color(0xFF6F3C22);
    final tableWidth = width * 0.25;
    final tableHeight = width * 0.10;

    final table = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center,
        width: tableWidth,
        height: tableHeight,
      ),
      Radius.circular(width * 0.025),
    );
    canvas.drawRRect(table, tablePaint);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(center.dx, center.dy - tableHeight * 0.10),
          width: tableWidth * 0.90,
          height: tableHeight * 0.70,
        ),
        Radius.circular(width * 0.018),
      ),
      tableTopPaint,
    );

    final chairSize = width * 0.055;
    for (final dx in <double>[-tableWidth * 0.36, tableWidth * 0.36]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(center.dx + dx, center.dy + tableHeight * 0.78),
            width: chairSize,
            height: chairSize,
          ),
          Radius.circular(width * 0.012),
        ),
        chairPaint,
      );
    }
  }

  void _drawAsset(Canvas canvas, String name, Rect bounds) {
    final image = images[name];
    if (image == null) return;

    final imageRatio = image.width / image.height;
    final boundsRatio = bounds.width / bounds.height;
    late Rect destination;
    if (imageRatio > boundsRatio) {
      final targetHeight = bounds.width / imageRatio;
      destination = Rect.fromLTWH(
        bounds.left,
        bounds.top + (bounds.height - targetHeight) / 2,
        bounds.width,
        targetHeight,
      );
    } else {
      final targetWidth = bounds.height * imageRatio;
      destination = Rect.fromLTWH(
        bounds.left + (bounds.width - targetWidth) / 2,
        bounds.top,
        targetWidth,
        bounds.height,
      );
    }

    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      destination,
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

enum CustomerPhase { entering, ordering, walkingToSeat, eating, leaving }

class CustomerComponent extends SpriteComponent {
  CustomerComponent({
    required this.game,
    required Sprite sprite,
    required this.seatOnLeft,
  }) : super(sprite: sprite, anchor: Anchor.center, priority: 20);

  final WarungKitaGame game;
  final bool seatOnLeft;

  CustomerPhase _phase = CustomerPhase.entering;
  late Vector2 _target;
  double _phaseTimer = 0;
  FoodBubbleComponent? _bubble;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final characterWidth = game.size.x * 0.13;
    size = Vector2(characterWidth, characterWidth * 1.55);
    position = game.entryPoint;
    _target = game.counterPoint;
  }

  @override
  void update(double dt) {
    super.update(dt);

    switch (_phase) {
      case CustomerPhase.entering:
      case CustomerPhase.walkingToSeat:
      case CustomerPhase.leaving:
        _moveTowardsTarget(dt);
        break;
      case CustomerPhase.ordering:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _completeOrder();
        break;
      case CustomerPhase.eating:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) {
          _phase = CustomerPhase.leaving;
          _target = game.exitPoint;
        }
        break;
    }
  }

  void _moveTowardsTarget(double dt) {
    final delta = _target - position;
    final distance = delta.length;
    if (distance <= max(2.0, game.size.x * 0.006)) {
      position = _target;
      _arrived();
      return;
    }

    final step = game.customerSpeed * dt;
    if (step >= distance) {
      position = _target;
      _arrived();
      return;
    }
    position += delta.normalized() * step;
  }

  void _arrived() {
    switch (_phase) {
      case CustomerPhase.entering:
        _phase = CustomerPhase.ordering;
        _phaseTimer = game.orderingDuration;
        break;
      case CustomerPhase.walkingToSeat:
        _phase = CustomerPhase.eating;
        _phaseTimer = 0.85;
        break;
      case CustomerPhase.leaving:
        removeFromParent();
        break;
      case CustomerPhase.ordering:
      case CustomerPhase.eating:
        break;
    }
  }

  void _completeOrder() {
    final result = game.resolveCustomer(this);
    if (result.served) {
      _phase = CustomerPhase.walkingToSeat;
      _target = game.seatPoint(seatOnLeft);
    } else {
      _phase = CustomerPhase.leaving;
      _target = game.exitPoint;
      add(
        MoodBubbleComponent(
          happy: false,
          position: Vector2(size.x * 0.70, -size.y * 0.05),
          bubbleSize: game.size.x * 0.075,
        ),
      );
    }
  }

  void showFood(ui.Image image) {
    _bubble?.removeFromParent();
    final bubble = FoodBubbleComponent(
      image: image,
      position: Vector2(size.x * 0.68, -size.y * 0.08),
      bubbleSize: game.size.x * 0.09,
    );
    _bubble = bubble;
    add(bubble);
  }
}

class FoodBubbleComponent extends PositionComponent {
  FoodBubbleComponent({
    required this.image,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final ui.Image image;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final shadowPaint = Paint()..color = const Color(0x44000000);
    final bubblePaint = Paint()..color = Colors.white;
    final borderPaint = Paint()
      ..color = const Color(0xFFF28C28)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.x * 0.06;

    canvas.drawCircle(
      Offset(size.x * 0.54, size.y * 0.57),
      size.x * 0.51,
      shadowPaint,
    );
    canvas.drawCircle(
      Offset(size.x * 0.5, size.y * 0.5),
      size.x * 0.48,
      bubblePaint,
    );
    canvas.drawCircle(
      Offset(size.x * 0.5, size.y * 0.5),
      size.x * 0.48,
      borderPaint,
    );

    final inset = size.x * 0.15;
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(
        inset,
        inset,
        size.x - inset * 2,
        size.y - inset * 2,
      ),
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class MoodBubbleComponent extends PositionComponent {
  MoodBubbleComponent({
    required this.happy,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final bool happy;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final background = Paint()..color = Colors.white;
    final line = Paint()
      ..color = happy ? const Color(0xFF3F8F35) : const Color(0xFFC4482D)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.x * 0.08
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(Offset(size.x / 2, size.y / 2), size.x * 0.47, background);
    canvas.drawCircle(
      Offset(size.x * 0.36, size.y * 0.40),
      size.x * 0.035,
      Paint()..color = line.color,
    );
    canvas.drawCircle(
      Offset(size.x * 0.64, size.y * 0.40),
      size.x * 0.035,
      Paint()..color = line.color,
    );

    final mouth = Path();
    if (happy) {
      mouth.moveTo(size.x * 0.31, size.y * 0.60);
      mouth.quadraticBezierTo(
        size.x * 0.50,
        size.y * 0.78,
        size.x * 0.69,
        size.y * 0.60,
      );
    } else {
      mouth.moveTo(size.x * 0.31, size.y * 0.70);
      mouth.quadraticBezierTo(
        size.x * 0.50,
        size.y * 0.52,
        size.x * 0.69,
        size.y * 0.70,
      );
    }
    canvas.drawPath(mouth, line);
  }
}
