# Warung Kita — Flutter + Flame

Prototaip game simulasi warung offline untuk Android. Projek ini ialah projek Flutter standard dan menggunakan Flame untuk paparan permainan masa nyata.

## Teknologi

- Flutter / Dart
- Flame 1.23.0
- shared_preferences 2.3.2
- Android portrait
- Simpanan tempatan tanpa pelayan

Flame 1.23.0 dipin secara tepat kerana ia menyokong Dart 3.4 dan memberikan keserasian lebih luas kepada persekitaran binaan Flutter.

## Ciri versi 0.3.1

- Peta warung masa nyata yang dirender oleh Flame.
- Pelanggan berjalan masuk, membuat pesanan, bergerak ke meja dan keluar.
- Watak dan gelembung makanan menggunakan aset sprite sebenar.
- Sistem jualan, tip, reputasi, stok dan resipi.
- Enam menu: nasi lemak, mee goreng, roti bakar, teh tarik, kopi dan nasi ayam.
- Empat kategori naik taraf: warung, dapur, meja dan stor.
- Laporan harian, statistik keseluruhan dan pendapatan offline.
- Auto-simpan menggunakan shared_preferences.
- Ikon aplikasi Android pelbagai resolusi.

## Bina APK

Jalankan dari folder yang mengandungi `pubspec.yaml`:

```bash
flutter clean
flutter pub get
flutter build apk --release
```

APK akan terhasil di:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Struktur utama

```text
lib/
├── flame/
│   └── warung_kita_game.dart
├── game/
│   ├── game_controller.dart
│   ├── game_data.dart
│   ├── game_repository.dart
│   └── game_state.dart
├── screens/
│   ├── game_screen.dart
│   └── main_menu_screen.dart
└── main.dart
```

## Pengenalan oleh bot binaan

Jenis projek: **Flutter**

Pengesan harus menemui fail berikut pada akar ZIP:

- `pubspec.yaml`
- `lib/main.dart`
- `android/settings.gradle.kts`
- `android/app/build.gradle.kts`
