# Build Fix 0.3.1 Resource

Build number kekal `1` (`version: 0.3.1+1`).

## Ralat dibetulkan

AAPT menolak nilai warna terus pada atribut drawable:

```xml
<item android:drawable="#2B160D" />
```

Kedua-dua fail berikut kini menggunakan `shape` dengan `solid` color yang sah:

- `android/app/src/main/res/drawable/launch_background.xml`
- `android/app/src/main/res/drawable-v21/launch_background.xml`

```xml
<item>
    <shape android:shape="rectangle">
        <solid android:color="#2B160D" />
    </shape>
</item>
```
