# Pembaikan Build v0.3.1

Versi ini membetulkan kegagalan kompilasi yang dilaporkan oleh bot binaan.

## Punca utama

Kod terdahulu menggunakan postfix increment dalam cascade Dart:

```dart
..daysPlayed++;
```

Bentuk itu tidak sah dalam cascade. Ia telah diganti tanpa mengubah logik permainan:

```dart
..daysPlayed += 1;
```

## Kemas kini alat Android

- Gradle Wrapper: `8.14.4`
- Android Gradle Plugin: `8.11.1`
- Kotlin Gradle Plugin: `2.2.20`
- Java target: `17`
- Flutter compatibility flags: `android.newDsl=false`, `android.builtInKotlin=false`

## Arahan binaan

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Untuk keluaran:

```bash
flutter build apk --release
```
