# Pelaksanaan Flame

`lib/flame/warung_kita_game.dart` mengandungi:

- `WarungKitaGame`: game loop, cache aset, sesi pelanggan dan koordinat peta.
- `WarungSceneComponent`: lantai, dinding, gerai, dapur, kaunter, pekerja dan meja.
- `CustomerComponent`: state machine pelanggan.
- `FoodBubbleComponent`: gelembung hidangan selepas jualan berjaya.
- `MoodBubbleComponent`: maklum balas apabila stok habis.

Aliran pelanggan:

```text
Masuk → Kaunter → Pesanan → Meja → Makan → Keluar
```

Aliran data:

```text
Flame customer component
        ↓
GameController.serveNextCustomer()
        ↓
Inventori / wang / reputasi / laporan
        ↓
ChangeNotifier → Flutter HUD
```
