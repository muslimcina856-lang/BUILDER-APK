import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}
val releaseSigningKeys = listOf("keyAlias", "keyPassword", "storeFile", "storePassword")
val releaseStorePath = keystoreProperties.getProperty("storeFile")?.trim()
val releaseStoreFile = releaseStorePath
    ?.takeIf { it.isNotEmpty() }
    ?.let { file(it) }
val hasReleaseSigning = keystorePropertiesFile.exists() &&
    releaseSigningKeys.all { !keystoreProperties.getProperty(it).isNullOrBlank() } &&
    releaseStoreFile?.isFile == true

android {
    namespace = "com.aiauto.claw"
    buildFeatures {
        buildConfig = true
    }
    compileSdk = 36
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.aiauto.claw.full"
        minSdk = 24
        targetSdk = 28
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        buildConfigField("boolean", "FULL_LINUX_EDITION", "true")
    }

    // Full/PRoot sengaja mengekalkan targetSdk 28 supaya executable yang
    // dipasang dalam ruang aplikasi boleh dijalankan. Hanya amaran target SDK
    // yang disengajakan ini dikecualikan; semakan lint lain kekal aktif.
    lint {
        disable += "ExpiredTargetSdkVersion"
    }

    signingConfigs {
        create("release") {
            if (hasReleaseSigning) {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = releaseStoreFile
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        // Builder pihak ketiga memaksa `assembleDebug`. Flutter menentukan
        // mod enjin daripada sifat `isDebuggable`, bukan semata-mata nama task.
        // Jadikan variant debug non-debuggable supaya Flutter membina AOT/mod
        // release yang konsisten dalam SATU variant; jangan campurkan artifact
        // assembleDebug dengan assembleRelease kerana native engine dan snapshot
        // boleh menjadi tidak sepadan lalu crash ketika FlutterJNI attach.
        getByName("debug") {
            isDebuggable = false
            isJniDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
            // Jangan hidupkan R8 pada variant compatibility ini. Flutter sudah
            // membina Dart AOT/release; release buildType sebenar di bawah kekal
            // menggunakan minify + resource shrinking.
            isMinifyEnabled = false
            isShrinkResources = false
        }

        release {
            isDebuggable = false
            isJniDebuggable = false
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                logger.warn(
                    "Tiada key.properties lengkap atau fail keystore tidak ditemui; " +
                        "artifact buildType release menggunakan debug key untuk ujian sahaja."
                )
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.webkit:webkit:1.14.0")
}

// Flutter memproses pubspec assets di dalam task compileFlutterBuild*. Panel
// binaan yang memanggil `flutter build` secara terus tidak melalui skrip shell
// projek, jadi runtime Linux mesti disediakan sebagai dependency Gradle juga.
val flutterProjectDir = rootProject.projectDir.parentFile
val repositoryDir = flutterProjectDir.parentFile
val linuxRuntimeBuilder = repositoryDir.resolve("scripts/linux/prepare_bundled_runtime.py")
val linuxRuntimeAssetDir = flutterProjectDir.resolve("assets/linux/full")
val linuxRuntimePack = linuxRuntimeAssetDir.resolve("runtime-pack.zip")
val linuxRuntimeManifest = linuxRuntimeAssetDir.resolve("runtime-manifest.json")
val linuxRuntimeChecksum = linuxRuntimeAssetDir.resolve("runtime-pack.sha256")
val pythonExecutable = System.getenv("PYTHON")
    ?.trim()
    ?.takeIf { it.isNotEmpty() }
    ?: if (System.getProperty("os.name").lowercase().contains("windows")) {
        "python"
    } else {
        "python3"
    }

val prepareBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "build setup"
    description = "Muat turun, sahkan dan bina asset Linux ARM64 sebelum Flutter membungkus assets."
    workingDir(repositoryDir)
    commandLine(pythonExecutable, linuxRuntimeBuilder.absolutePath)
    environment("PYTHONUNBUFFERED", "1")

    inputs.file(linuxRuntimeBuilder)
    inputs.dir(repositoryDir.resolve("scripts/linux/licenses"))
    outputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }

    doFirst {
        if (!linuxRuntimeBuilder.isFile) {
            throw GradleException("Pembina runtime Linux tiada: $linuxRuntimeBuilder")
        }
        linuxRuntimeAssetDir.mkdirs()
    }
}

val verifyBundledLinuxRuntime by tasks.registering(Exec::class) {
    group = "verification"
    description = "Sahkan runtime Linux yang akan dibundel ialah ZIP Alpine/PRoot ARM64 yang lengkap."
    dependsOn(prepareBundledLinuxRuntime)
    workingDir(repositoryDir)
    commandLine(
        pythonExecutable,
        linuxRuntimeBuilder.absolutePath,
        "--verify-only",
        "--output",
        linuxRuntimePack.absolutePath,
    )
    environment("PYTHONUNBUFFERED", "1")
    inputs.files(linuxRuntimePack, linuxRuntimeManifest, linuxRuntimeChecksum)
    outputs.upToDateWhen { false }
}

// Dependency terus pada compileFlutterBuild* penting: `preBuild` sahaja tidak
// menjamin runtime siap sebelum Flutter memeriksa pubspec.yaml.
tasks.configureEach {
    if (name.startsWith("compileFlutterBuild")) {
        dependsOn(verifyBundledLinuxRuntime)
    }
}

// Sesetengah panel binaan pihak ketiga hanya mencari app-debug.apk. Variant
// `debug` di atas sudah dibina oleh Flutter sebagai release/AOT yang konsisten
// kerana `isDebuggable = false`. Langkah ini hanya menormalkan NAMA/LOKASI
// output; ia tidak lagi membina atau menyalin silang daripada variant release.
tasks.configureEach {
    if (name == "assembleDebug") {
        doLast {
            val appBuildDir = layout.buildDirectory.get().asFile
            val gradleDebugDir = appBuildDir.resolve("outputs/apk/debug")
            val flutterApkDir = appBuildDir.resolve("outputs/flutter-apk")

            val variantApk = gradleDebugDir
                .walkTopDown()
                .filter { it.isFile && it.extension.equals("apk", ignoreCase = true) && it.length() > 0L }
                .maxByOrNull { it.lastModified() }
                ?: throw GradleException(
                    "APK variant debug non-debuggable tidak dijana: ${gradleDebugDir.absolutePath}"
                )

            // Pastikan artifact benar-benar AOT dan mempunyai pasangan native
            // release yang lengkap sebelum diserahkan kepada builder.
            java.util.zip.ZipFile(variantApk).use { apk ->
                val entries = apk.entries().asSequence().map { it.name }.toSet()
                val hasFlutterEngine = entries.contains("lib/arm64-v8a/libflutter.so")
                val hasAotApp = entries.contains("lib/arm64-v8a/libapp.so")
                val hasDebugKernel = entries.contains("assets/flutter_assets/kernel_blob.bin")
                if (!hasFlutterEngine || !hasAotApp || hasDebugKernel) {
                    throw GradleException(
                        "Artifact builder bukan release/AOT yang konsisten: " +
                            "libflutter.so=$hasFlutterEngine, libapp.so=$hasAotApp, " +
                            "kernel_blob.bin=$hasDebugKernel"
                    )
                }
            }

            flutterApkDir.mkdirs()
            val debugName = flutterApkDir.resolve("app-debug.apk")
            val releaseName = flutterApkDir.resolve("app-release.apk")
            variantApk.copyTo(debugName, overwrite = true)
            variantApk.copyTo(releaseName, overwrite = true)

            logger.lifecycle(
                "assembleDebug menghasilkan satu artifact release/AOT yang konsisten: " +
                    debugName.absolutePath
            )
        }
    }
}
