package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.widget.EditText;
import android.content.SharedPreferences;
import android.content.ComponentName;
import android.app.admin.DevicePolicyManager;

public class AdminReceiver extends DeviceAdminReceiver {
    
    private boolean checkPin(Context context, String enteredPin) {
        SharedPreferences prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
        String savedPin = prefs.getString("flutter.admin_pin", "1234");
        return enteredPin.equals(savedPin);
    }
    
    private void showPinDialog(final Context context, final Intent intent) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Verifikasi PIN");
        builder.setMessage("Masukkan PIN untuk menonaktifkan admin:");
        
        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        builder.setView(input);
        
        builder.setPositiveButton("OK", (dialog, which) -> {
            String pin = input.getText().toString();
            if (checkPin(context, pin)) {
                Toast.makeText(context, "Admin disabled", Toast.LENGTH_SHORT).show();
                super.onDisabled(context, intent);
            } else {
                Toast.makeText(context, "PIN salah! Admin tetap aktif.", Toast.LENGTH_LONG).show();
                reactivateAdmin(context);
            }
        });
        
        builder.setNegativeButton("Batal", (dialog, which) -> {
            reactivateAdmin(context);
        });
        
        builder.setCancelable(false);
        builder.show();
    }
    
    private void reactivateAdmin(Context context) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminName = new ComponentName(context, AdminReceiver.class);
        
        if (!dpm.isAdminActive(adminName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Aktifkan admin untuk melanjutkan");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        showPinDialog(context, intent);
    }
}