abstract final class UsageGuide {
  static const String title = 'Cara Guna Ai MultiAgent';

  static const List<UsageGuideSection> sections = <UsageGuideSection>[
    UsageGuideSection(
      title: '1. Sediakan provider',
      iconName: 'key',
      steps: <String>[
        'Buka tab Provider, pilih penyedia AI, masukkan API key sendiri dan tekan Uji sambungan.',
        'Pilih model yang telah disahkan oleh provider. Model itu menjadi penyelaras utama untuk chat, tools dan sub-agent.',
      ],
    ),
    UsageGuideSection(
      title: '2. Beri arahan dalam Chat',
      iconName: 'chat',
      steps: <String>[
        'Tulis hasil yang anda mahu dalam bahasa biasa. AI akan memilih tools, skills dan sub-agent apabila diperlukan.',
        'Tekan butang berhenti jika mahu membatalkan tugasan yang sedang berjalan.',
      ],
    ),
    UsageGuideSection(
      title: '3. Browser dan screenshot',
      iconName: 'browser',
      steps: <String>[
        'Minta AI membuka laman, mencari kandungan, mengklik elemen atau mengambil screenshot.',
        'Browser berjalan tersembunyi dan senyap. Screenshot dipaparkan sebagai satu gambar penuh; tekan gambar untuk zum dan pratonton skrin penuh.',
      ],
    ),
    UsageGuideSection(
      title: '4. Gambar, video dan audio',
      iconName: 'media',
      steps: <String>[
        'Media yang dihantar oleh AI boleh dipratonton terus dalam chat tanpa disimpan secara automatik.',
        'Tekan ikon skrin penuh untuk melihat gambar atau video dengan lebih jelas. Tekan Simpan untuk memilih lokasi pada peranti.',
      ],
    ),
    UsageGuideSection(
      title: '5. Shell dan PC Windows',
      iconName: 'linux',
      steps: <String>[
        'Buka tab Workspace untuk menggunakan Shell Alpine Linux ARM64 dan melihat status PC Windows local.',
        'PC Windows dimuat turun dan disediakan automatik pada kali pertama Workspace dibuka. AI boleh menjalankan cmd.exe dan fail .exe yang berada dalam /workspace atau lampiran chat; aplikasi yang dipasang dalam drive C: Wine juga boleh dibuka semula.',
        'Aplikasi Windows GUI dirender secara headless pada desktop 1280×720. AI boleh mengambil screenshot, menyenaraikan/fokus tetingkap, klik koordinat, menaip teks dan menghantar kekunci. Lapisan ini menggunakan Wine WoW64 + Box64 dan bukan VM/kernel Windows penuh.',
        'Untuk Shell, gunakan apk bagi memasang pakej, contohnya: apk update && apk add --no-cache python3 git.',
        'Shell dan PC Windows berada dalam storan peribadi aplikasi. Fail luar hanya masuk apabila anda memilih atau memuat turunnya sendiri.',
      ],
    ),
    UsageGuideSection(
      title: '6. Fail dan hasil kerja',
      iconName: 'file',
      steps: <String>[
        'Lampirkan fail melalui butang + dalam Chat untuk dianalisis.',
        'Hasil yang dicipta disimpan dahulu dalam workspace peribadi aplikasi. Gunakan butang Simpan untuk menyalinnya ke lokasi pilihan anda.',
      ],
    ),
    UsageGuideSection(
      title: '7. Kerja di latar belakang',
      iconName: 'background',
      steps: <String>[
        'Semasa tugasan aktif, aplikasi boleh meneruskan kerja di latar belakang sehingga 30 minit jika Android tidak menyekatnya.',
        'Skrin kekal menyala semasa aplikasi dibuka. Browser tersembunyi kekal tanpa bunyi dan media halaman tidak dimainkan secara automatik.',
      ],
    ),
    UsageGuideSection(
      title: '8. Sub-agent dan tools',
      iconName: 'agents',
      steps: <String>[
        'Satu model utama menyelaras tugasan. Untuk kerja kompleks, ia boleh mencipta sub-agent dinamik seperti penyelidik, penguji atau penyemak kod.',
        'Sub-agent menggunakan provider dan model yang sedang dipilih serta hanya menerima tools yang diperlukan untuk subtugasnya.',
        'Untuk kerja Windows, AI mengutamakan PC Windows local. Server MCP Windows hanya digunakan sebagai pilihan tambahan apabila kerja memerlukan PC Windows penuh atau peranti jauh yang telah anda konfigurasi.',
      ],
    ),
  ];

  static Map<String, dynamic> toMap() => <String, dynamic>{
        'title': title,
        'sections': sections.map((item) => item.toMap()).toList(),
      };

  static String asPlainText() => sections
      .map(
        (section) => <String>[
          section.title,
          ...section.steps.map((step) => '- $step'),
        ].join('\n'),
      )
      .join('\n\n');
}

class UsageGuideSection {
  const UsageGuideSection({
    required this.title,
    required this.iconName,
    required this.steps,
  });

  final String title;
  final String iconName;
  final List<String> steps;

  Map<String, dynamic> toMap() => <String, dynamic>{
        'title': title,
        'steps': steps,
      };
}
