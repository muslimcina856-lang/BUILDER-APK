import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config/app_config.dart';
import 'linux_workspace_service.dart';

class WindowsRuntimeStatus {
  const WindowsRuntimeStatus({
    required this.rootPath,
    required this.rootfsReady,
    required this.box64Ready,
    required this.wineReady,
    required this.prefixReady,
    required this.manifestValid,
    required this.usedBytes,
    required this.runtimeVersion,
    required this.box64Version,
    required this.wineVersion,
    required this.healthStatus,
  });

  final String rootPath;
  final bool rootfsReady;
  final bool box64Ready;
  final bool wineReady;
  final bool prefixReady;
  final bool manifestValid;
  final int usedBytes;
  final String runtimeVersion;
  final String box64Version;
  final String wineVersion;
  final String healthStatus;

  bool get ready =>
      rootfsReady && box64Ready && wineReady && prefixReady && manifestValid;
}

class WindowsExecutablePath {
  const WindowsExecutablePath({required this.hostPath, required this.guestPath});

  final String hostPath;
  final String guestPath;
}

/// Runtime Windows-compatible tempatan untuk Ai MultiAgent Full.
///
/// Ini bukan VM/kernel Windows penuh. Ia menggunakan Ubuntu ARM64 sebagai
/// userspace, Box64 untuk x86_64 dan Wine WoW64 untuk aplikasi Windows x86/x64.
/// Runtime dimuat turun sekali pada penggunaan pertama dan disimpan berasingan
/// daripada Shell Alpine supaya reset Shell tidak memadam PC Windows.
class WindowsRuntimeService {
  factory WindowsRuntimeService() => _instance;
  WindowsRuntimeService._();

  static final WindowsRuntimeService _instance = WindowsRuntimeService._();

  static const String expectedRuntimeVersion =
      '1.1.0-ubuntu-24.04.4-box64-0.4.4-wine-11.11-wow64';
  static const String expectedDistribution = 'Ubuntu Base';
  static const String expectedDistributionVersion = '24.04.4';
  static const String expectedArchitecture = 'aarch64';
  static const String expectedWineVersion = '11.11';
  static const String expectedBox64Version = '0.4.4';
  static const String _box64Commit =
      '2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a';
  static const String displayName = ':99';
  static const int desktopWidth = 1280;
  static const int desktopHeight = 720;

  static const String _ubuntuBaseUrl =
      'https://cdimage.ubuntu.com/ubuntu-base/releases/noble/release/ubuntu-base-24.04.4-base-arm64.tar.gz';
  static const String _ubuntuBaseSha256 =
      '04207713ece899c3740823d33690441ad3a7f0ded1101aca744e2b0f37ac7ff2';
  static const String _wineUrl =
      'https://github.com/Kron4ek/Wine-Builds/releases/download/11.11/wine-11.11-staging-tkg-amd64-wow64.tar.xz';
  static const String _wineSha256 =
      '44f5330be22424c51d2b48ddc60dc4e1fca686628cedd9e76cd2b041a4aeb3d9';

  static Future<WindowsRuntimeStatus>? _installInFlight;

  Future<Directory> ensurePrivateRoot() async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final support = await getApplicationSupportDirectory();
    _assertPrivateAppPath(support.path);
    final root = Directory(p.join(support.path, 'windows'));
    await root.create(recursive: true);
    for (final child in <String>['home', 'tmp', 'runtime', 'cache']) {
      await Directory(p.join(root.path, child)).create(recursive: true);
    }
    return root;
  }

  Future<WindowsRuntimeStatus> status({bool includeSize = true}) async {
    if (!AppConfig.isFullEdition) {
      return const WindowsRuntimeStatus(
        rootPath: '',
        rootfsReady: false,
        box64Ready: false,
        wineReady: false,
        prefixReady: false,
        manifestValid: false,
        usedBytes: 0,
        runtimeVersion: '',
        box64Version: '',
        wineVersion: '',
        healthStatus: 'unavailable_in_standard',
      );
    }
    final root = await ensurePrivateRoot();
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final rootfsReady = _isFileOrLink(p.join(rootfs.path, 'bin/sh'));
    final box64Ready =
        _isFileOrLink(p.join(rootfs.path, 'usr/local/bin/box64')) ||
            _isFileOrLink(p.join(rootfs.path, 'usr/bin/box64'));
    final wineReady = _isFileOrLink(p.join(rootfs.path, 'opt/wine/bin/wine'));
    final prefixReady =
        _isFileOrLink(p.join(root.path, 'home/.wine/system.reg'));
    final manifest = await _readManifest(root);
    final manifestValid = _manifestIsValid(manifest);
    return WindowsRuntimeStatus(
      rootPath: root.path,
      rootfsReady: rootfsReady,
      box64Ready: box64Ready,
      wineReady: wineReady,
      prefixReady: prefixReady,
      manifestValid: manifestValid,
      usedBytes: includeSize ? await _directorySize(root) : 0,
      runtimeVersion: manifest?['runtime_version']?.toString() ?? '',
      box64Version: manifest?['box64_version']?.toString() ?? '',
      wineVersion: manifest?['wine_version']?.toString() ?? '',
      healthStatus: manifest?['health_status']?.toString() ?? 'not_installed',
    );
  }

  Future<WindowsRuntimeStatus> ensureReady() {
    if (!AppConfig.isFullEdition) return status();
    final existing = _installInFlight;
    if (existing != null) return existing;
    final operation = _ensureReadyInternal();
    _installInFlight = operation;
    return operation.whenComplete(() {
      if (identical(_installInFlight, operation)) _installInFlight = null;
    });
  }

  Future<WindowsRuntimeStatus> _ensureReadyInternal() async {
    var current = await status();
    if (current.ready && current.runtimeVersion == expectedRuntimeVersion) {
      return current;
    }

    final linux = await LinuxWorkspaceService().ensureBundledRuntimeReady();
    if (!linux.ready) {
      throw const FileSystemException(
        'Shell Alpine perlu tersedia sebelum PC Windows boleh disediakan.',
      );
    }

    final root = await ensurePrivateRoot();
    final manifest = await _readManifest(root);
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final structuralRootfs = _isFileOrLink(p.join(rootfs.path, 'bin/sh'));
    final versionMatches = _manifestIsValid(manifest);

    if (!structuralRootfs || !versionMatches) {
      await _bootstrapUbuntuRootfs(root, linux.rootPath);
    }

    await _configureCompatibilityLayer(root, linux.rootPath);
    current = await status();
    if (!current.ready) {
      throw const FileSystemException(
        'PC Windows belum melepasi pemeriksaan kesihatan selepas pemasangan.',
      );
    }
    return current;
  }

  Future<void> _bootstrapUbuntuRootfs(
    Directory windowsRoot,
    String linuxRootPath,
  ) async {
    final linux = LinuxWorkspaceService();
    final bootstrapHost = Directory(
      p.join(linuxRootPath, 'home', '.ai-windows-bootstrap'),
    );
    if (await bootstrapHost.exists()) {
      await bootstrapHost.delete(recursive: true);
    }
    await bootstrapHost.create(recursive: true);

    final command = '''
set -eu
apk add --no-cache ca-certificates curl tar gzip >/dev/null
rm -rf /root/.ai-windows-bootstrap
mkdir -p /root/.ai-windows-bootstrap/rootfs
curl -fL --retry 3 --connect-timeout 20 \\
  -o /root/.ai-windows-bootstrap/ubuntu-base.tar.gz \\
  ${_shellQuote(_ubuntuBaseUrl)}
echo '${_ubuntuBaseSha256}  /root/.ai-windows-bootstrap/ubuntu-base.tar.gz' | sha256sum -c -
tar -xzf /root/.ai-windows-bootstrap/ubuntu-base.tar.gz \\
  -C /root/.ai-windows-bootstrap/rootfs
test -e /root/.ai-windows-bootstrap/rootfs/bin/sh
''';
    final spec = await linux.commandSpec(
      command: command,
      relativeWorkingDirectory: '.',
      autoInstallBundledRuntime: true,
    );
    if (spec == null) {
      throw const FileSystemException('Shell Alpine tidak tersedia.');
    }
    await _runChecked(
      spec,
      timeout: const Duration(minutes: 20),
      failureLabel: 'Muat turun Ubuntu Base gagal',
    );

    final stagedRootfs = Directory(p.join(bootstrapHost.path, 'rootfs'));
    if (!_isFileOrLink(p.join(stagedRootfs.path, 'bin/sh'))) {
      throw const FileSystemException(
        'Arkib Ubuntu Base tidak menghasilkan rootfs yang sah.',
      );
    }
    final target = Directory(p.join(windowsRoot.path, 'rootfs'));
    final previous = Directory(p.join(windowsRoot.path, 'rootfs.previous'));
    if (await previous.exists()) await previous.delete(recursive: true);
    if (await target.exists()) await target.rename(previous.path);
    try {
      await stagedRootfs.rename(target.path);
      if (await previous.exists()) await previous.delete(recursive: true);
    } catch (_) {
      if (await target.exists()) await target.delete(recursive: true);
      if (await previous.exists()) await previous.rename(target.path);
      rethrow;
    } finally {
      if (await bootstrapHost.exists()) {
        await bootstrapHost.delete(recursive: true);
      }
    }
  }

  Future<void> _configureCompatibilityLayer(
    Directory root,
    String linuxRootPath,
  ) async {
    final installCommand = '''
set -eu
export DEBIAN_FRONTEND=noninteractive
if ! grep -RqsE '^deb .*noble.* universe' /etc/apt/sources.list /etc/apt/sources.list.d 2>/dev/null; then
  cat >>/etc/apt/sources.list <<'UBUNTU_UNIVERSE'
deb http://ports.ubuntu.com/ubuntu-ports noble main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-security main restricted universe multiverse
UBUNTU_UNIVERSE
fi
cat >/usr/sbin/policy-rc.d <<'POLICY'
#!/bin/sh
exit 101
POLICY
chmod 755 /usr/sbin/policy-rc.d
apt-get update
apt-get install -y --no-install-recommends \\
  ca-certificates curl wget gnupg xz-utils tar procps \\
  xvfb scrot xdotool openbox wine64 fonts-dejavu-core fonts-liberation
rm -f /etc/apt/sources.list.d/box64.list /etc/apt/sources.list.d/box64.sources
mkdir -p /usr/share/keyrings
wget -qO- 'https://pi-apps-coders.github.io/box64-debs/KEY.gpg' \\
  | gpg --dearmor --batch --yes -o /usr/share/keyrings/box64-archive-keyring.gpg
cat >/etc/apt/sources.list.d/box64.sources <<'BOX64'
Types: deb
URIs: https://Pi-Apps-Coders.github.io/box64-debs/debian
Suites: ./
Signed-By: /usr/share/keyrings/box64-archive-keyring.gpg
BOX64
apt-get update
apt-get install -y --no-install-recommends box64-generic-arm
rm -rf /opt/wine /opt/wine.staging
mkdir -p /opt/wine.staging /tmp/ai-windows
curl -fL --retry 3 --connect-timeout 20 \\
  -o /tmp/ai-windows/wine.tar.xz \\
  ${_shellQuote(_wineUrl)}
echo '${_wineSha256}  /tmp/ai-windows/wine.tar.xz' | sha256sum -c -
tar -xJf /tmp/ai-windows/wine.tar.xz -C /opt/wine.staging
WINE_BIN="\$(find /opt/wine.staging -type f -path '*/bin/wine' -print -quit)"
if [ -z "\$WINE_BIN" ]; then
  WINE_BIN="\$(find /opt/wine.staging -type l -path '*/bin/wine' -print -quit)"
fi
test -n "\$WINE_BIN"
WINE_HOME="\$(dirname "\$(dirname "\$WINE_BIN")")"
mv "\$WINE_HOME" /opt/wine
rm -rf /opt/wine.staging /tmp/ai-windows
command -v box64
test -x /opt/wine/bin/wine
''';
    await _runChecked(
      await commandSpec(
        command: installCommand,
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(minutes: 30),
      failureLabel: 'Pemasangan Box64/Wine gagal',
    );

    // Pakej Debian generik dicuba dahulu kerana pemasangannya lebih cepat.
    // Pada kernel Android + PRoot, dokumentasi Box64 mengesyorkan BAD_SIGNAL=ON.
    // Jika probe Wine gagal, bina versi PRoot-specific yang dipin ke commit rasmi.
    try {
      await _runChecked(
        await commandSpec(
          command:
              'BOX64_NOBANNER=1 box64 /opt/wine/bin/wine --version',
          relativeWorkingDirectory: '.',
          requireReady: false,
          linuxRootPath: linuxRootPath,
        ),
        timeout: const Duration(seconds: 45),
        failureLabel: 'Probe Box64 generik gagal',
      );
    } on FileSystemException {
      await _installProotBox64Fallback(linuxRootPath);
    }

    late _ProcessOutput result;
    try {
      result = await _windowsHealthCheck(linuxRootPath);
    } on FileSystemException {
      final fallbackMarker = File(
        p.join(root.path, 'rootfs/opt/ai-windows/box64-proot-build'),
      );
      if (await fallbackMarker.exists()) rethrow;
      await _installProotBox64Fallback(linuxRootPath);
      result = await _windowsHealthCheck(linuxRootPath);
    }
    final lines = result.stdout
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList(growable: false);
    final wineVersion = lines.firstWhere(
      (line) => line.toLowerCase().contains('wine-'),
      orElse: () => 'wine-$expectedWineVersion',
    );
    final box64Version = await _box64Version(linuxRootPath);
    await _writeManifest(
      root,
      box64Version: box64Version,
      wineVersion: wineVersion,
    );
  }

  Future<void> _installProotBox64Fallback(String linuxRootPath) async {
    final command = '''
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends build-essential cmake git
rm -rf /tmp/ai-box64-src /tmp/ai-box64-build
git clone -q --depth 1 --branch v0.4.4 https://github.com/ptitSeb/box64.git /tmp/ai-box64-src
cd /tmp/ai-box64-src
git checkout -q --detach ${_shellQuote(_box64Commit)}
test "\$(git rev-parse HEAD)" = ${_shellQuote(_box64Commit)}
cmake -S . -B /tmp/ai-box64-build -DARM64=1 -DCMAKE_C_COMPILER=gcc -DBAD_SIGNAL=ON -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build /tmp/ai-box64-build --parallel 2
cmake --install /tmp/ai-box64-build
strip /usr/local/bin/box64 2>/dev/null || true
mkdir -p /opt/ai-windows
printf '%s\\n' ${_shellQuote(_box64Commit)} >/opt/ai-windows/box64-proot-build
rm -rf /tmp/ai-box64-src /tmp/ai-box64-build
BOX64_NOBANNER=1 /usr/local/bin/box64 /opt/wine/bin/wine --version
apt-get purge -y build-essential cmake git || true
apt-get autoremove -y || true
apt-get clean
''';
    await _runChecked(
      await commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(minutes: 35),
      failureLabel:
          'Fallback Box64 $expectedBox64Version untuk Android/PRoot gagal',
    );
  }

  Future<_ProcessOutput> _windowsHealthCheck(String linuxRootPath) async {
    final healthCommand = '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
"\$BOX64_BIN" /opt/wine/bin/wine --version
"\$BOX64_BIN" /opt/wine/bin/wine cmd.exe /d /s /c "ver"
test -f /root/.wine/system.reg
''';
    return _runChecked(
      await commandSpec(
        command: healthCommand,
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(minutes: 8),
      failureLabel: 'Pemeriksaan Wine/Box64 gagal',
    );
  }

  Future<String> _box64Version(String linuxRootPath) async {
    final result = await _runChecked(
      await commandSpec(
        command: 'box64 --version 2>&1 || box64 -v 2>&1 || true',
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(seconds: 30),
      failureLabel: 'Semakan versi Box64 gagal',
      allowNonZero: true,
    );
    final text = '${result.stdout}\n${result.stderr}'.trim();
    return text.isEmpty ? 'box64' : text.split('\n').first.trim();
  }

  Future<LinuxCommandSpec> commandSpec({
    required String command,
    String relativeWorkingDirectory = '.',
    bool requireReady = true,
    String? linuxRootPath,
  }) async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    if (requireReady) {
      final quickStatus = await status(includeSize: false);
      if (!quickStatus.ready ||
          quickStatus.runtimeVersion != expectedRuntimeVersion) {
        await ensureReady();
      }
    }
    final root = await ensurePrivateRoot();
    final linuxStatus = await LinuxWorkspaceService().status();
    final linuxRoot = linuxRootPath ?? linuxStatus.rootPath;
    if (linuxRoot.isEmpty) {
      throw const FileSystemException('Runtime PRoot Shell tidak tersedia.');
    }
    final proot = File(p.join(linuxRoot, 'runtime/bin/proot'));
    final dns = File(p.join(linuxRoot, 'runtime/android-resolv.conf'));
    final workspace = Directory(p.join(linuxRoot, 'workspace'));
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final home = Directory(p.join(root.path, 'home'));
    final tmp = Directory(p.join(root.path, 'tmp'));
    final attachments = Directory(
      p.join((await getApplicationDocumentsDirectory()).path, 'chat_attachments'),
    );
    await workspace.create(recursive: true);
    await home.create(recursive: true);
    await tmp.create(recursive: true);
    final safeRelative = p.normalize(relativeWorkingDirectory);
    if (p.isAbsolute(safeRelative) ||
        safeRelative == '..' ||
        safeRelative.startsWith('../')) {
      throw const FileSystemException('Working directory Windows tidak selamat.');
    }
    final guestCwd = safeRelative == '.' || safeRelative.isEmpty
        ? '/workspace'
        : '/workspace/${safeRelative.replaceAll('\\', '/')}';

    return LinuxCommandSpec(
      executable: proot.path,
      arguments: <String>[
        '--kill-on-exit',
        '--link2symlink',
        '-0',
        '-r',
        rootfs.path,
        ..._safeSystemBinds(),
        '-b',
        '${workspace.path}:/workspace',
        '-b',
        '${home.path}:/root',
        '-b',
        '${tmp.path}:/tmp',
        if (await attachments.exists()) ...<String>[
          '-b',
          '${attachments.path}:/attachments',
        ],
        if (await dns.exists()) ...<String>[
          '-b',
          '${dns.path}:/etc/resolv.conf',
        ],
        '-w',
        guestCwd,
        '/usr/bin/env',
        '-i',
        'HOME=/root',
        'USER=root',
        'LOGNAME=root',
        'TERM=xterm-256color',
        'LANG=C.UTF-8',
        'DISPLAY=$displayName',
        'WINEPREFIX=/root/.wine',
        'WINEARCH=win64',
        'WINEDEBUG=-all',
        'WINEDLLOVERRIDES=mscoree,mshtml=',
        'BOX64_NOBANNER=1',
        'PATH=/opt/wine/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        '/bin/sh',
        '-lc',
        command,
      ],
      hostWorkingDirectory: workspace.path,
      environment: <String, String>{
        'HOME': home.path,
        'TMPDIR': tmp.path,
        'PROOT_TMP_DIR': tmp.path,
        'PROOT_NO_SECCOMP': '1',
      },
    );
  }

  String wrapWindowsCommand(String command) => '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
exec "\$BOX64_BIN" /opt/wine/bin/wine cmd.exe /d /s /c ${_shellQuote(command)}
''';

  String wrapWindowsExecutable(
    String guestPath,
    List<String> arguments,
  ) {
    final args = arguments.map(_shellQuote).join(' ');
    return '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
exec "\$BOX64_BIN" /opt/wine/bin/wine ${_shellQuote(guestPath)}${args.isEmpty ? '' : ' $args'}
''';
  }

  Future<WindowsExecutablePath> resolveExecutablePath(String rawPath) async {
    final value = rawPath.trim();
    final slashPath = value.replaceAll('\\', '/');
    if (value.isEmpty || p.posix.extension(slashPath).toLowerCase() != '.exe') {
      throw const FileSystemException('Fail Windows mesti mempunyai sambungan .exe.');
    }
    final linux = await LinuxWorkspaceService().status();
    if (linux.rootPath.isEmpty) {
      throw const FileSystemException('Workspace Shell tidak tersedia.');
    }
    final workspace = Directory(p.join(linux.rootPath, 'workspace'));
    final attachments = Directory(
      p.join((await getApplicationDocumentsDirectory()).path, 'chat_attachments'),
    );
    final windowsRoot = await ensurePrivateRoot();
    final driveC = Directory(
      p.join(windowsRoot.path, 'home', '.wine', 'drive_c'),
    );

    if (slashPath.startsWith('/workspace/')) {
      final relative = slashPath.substring('/workspace/'.length);
      return _validatedGuestFile(workspace, relative, '/workspace');
    }
    if (slashPath.startsWith('/attachments/')) {
      final relative = slashPath.substring('/attachments/'.length);
      return _validatedGuestFile(attachments, relative, '/attachments');
    }
    if (RegExp(r'^[zZ]:/workspace/').hasMatch(slashPath)) {
      final relative = slashPath.substring('Z:/workspace/'.length);
      return _validatedGuestFile(workspace, relative, '/workspace');
    }
    if (RegExp(r'^[zZ]:/attachments/').hasMatch(slashPath)) {
      final relative = slashPath.substring('Z:/attachments/'.length);
      return _validatedGuestFile(attachments, relative, '/attachments');
    }
    if (RegExp(r'^[cC]:/').hasMatch(slashPath)) {
      final relative = slashPath.substring(3);
      return _validatedGuestFile(
        driveC,
        relative,
        '/root/.wine/drive_c',
      );
    }
    if (p.isAbsolute(value)) {
      final normalized = p.normalize(value);
      if (normalized == workspace.path || p.isWithin(workspace.path, normalized)) {
        final relative = p.relative(normalized, from: workspace.path);
        return _validatedGuestFile(workspace, relative, '/workspace');
      }
      if (normalized == attachments.path ||
          p.isWithin(attachments.path, normalized)) {
        final relative = p.relative(normalized, from: attachments.path);
        return _validatedGuestFile(attachments, relative, '/attachments');
      }
      if (normalized == driveC.path || p.isWithin(driveC.path, normalized)) {
        final relative = p.relative(normalized, from: driveC.path);
        return _validatedGuestFile(
          driveC,
          relative,
          '/root/.wine/drive_c',
        );
      }
      throw const FileSystemException(
        'EXE mesti berada dalam /workspace, lampiran chat atau drive C: Wine.',
      );
    }
    return _validatedGuestFile(workspace, slashPath, '/workspace');
  }

  Future<WindowsExecutablePath> _validatedGuestFile(
    Directory root,
    String relative,
    String guestRoot,
  ) async {
    final normalizedRelative = p.normalize(relative);
    if (p.isAbsolute(normalizedRelative) ||
        normalizedRelative == '..' ||
        normalizedRelative.startsWith('../')) {
      throw const FileSystemException('Laluan EXE tidak selamat.');
    }
    final host = p.normalize(p.join(root.path, normalizedRelative));
    if (host != root.path && !p.isWithin(root.path, host)) {
      throw const FileSystemException('Laluan EXE keluar daripada ruang dibenarkan.');
    }
    final file = File(host);
    if (!await file.exists()) {
      throw FileSystemException('Fail EXE tidak ditemui.', host);
    }
    final guestRelative = normalizedRelative.replaceAll('\\', '/');
    return WindowsExecutablePath(
      hostPath: host,
      guestPath: '$guestRoot/$guestRelative',
    );
  }

  Future<String> screenshotHostPath() async {
    final linux = await LinuxWorkspaceService().status();
    if (linux.rootPath.isEmpty) {
      throw const FileSystemException('Workspace Shell tidak tersedia.');
    }
    final directory = Directory(
      p.join(linux.rootPath, 'workspace', 'windows', 'screenshots'),
    );
    await directory.create(recursive: true);
    final stamp = DateTime.now().toUtc().millisecondsSinceEpoch;
    return p.join(directory.path, 'windows-$stamp.png');
  }

  Future<void> reset() async {
    if (!AppConfig.isFullEdition) return;
    final root = await ensurePrivateRoot();
    if (await root.exists()) await root.delete(recursive: true);
    await ensurePrivateRoot();
  }

  String _xvfbBootstrap() => '''
mkdir -p /tmp/.X11-unix
if [ ! -S /tmp/.X11-unix/X99 ]; then
  rm -f /tmp/.X99-lock
  Xvfb $displayName -screen 0 ${desktopWidth}x${desktopHeight}x24 -nolisten tcp >/tmp/ai-windows-xvfb.log 2>&1 &
  i=0
  while [ ! -S /tmp/.X11-unix/X99 ] && [ "\$i" -lt 50 ]; do
    i=\$((i + 1))
    sleep 0.1
  done
fi
test -S /tmp/.X11-unix/X99
if [ ! -f /tmp/ai-windows-openbox.pid ] || ! kill -0 "\$(cat /tmp/ai-windows-openbox.pid 2>/dev/null || true)" 2>/dev/null; then
  DISPLAY=$displayName openbox --sm-disable >/tmp/ai-windows-openbox.log 2>&1 &
  echo \$! >/tmp/ai-windows-openbox.pid
  sleep 0.2
fi
''';

  Future<_ProcessOutput> _runChecked(
    LinuxCommandSpec spec, {
    required Duration timeout,
    required String failureLabel,
    bool allowNonZero = false,
  }) async {
    final process = await Process.start(
      spec.executable,
      spec.arguments,
      workingDirectory: spec.hostWorkingDirectory,
      environment: spec.environment,
      includeParentEnvironment: false,
      runInShell: false,
    );
    final stdoutFuture = process.stdout
        .transform(const Utf8Decoder(allowMalformed: true))
        .join();
    final stderrFuture = process.stderr
        .transform(const Utf8Decoder(allowMalformed: true))
        .join();
    int exitCode;
    try {
      exitCode = await process.exitCode.timeout(timeout);
    } on TimeoutException {
      process.kill(ProcessSignal.sigkill);
      throw FileSystemException('$failureLabel: tamat masa.');
    }
    final stdout = await stdoutFuture;
    final stderr = await stderrFuture;
    if (exitCode != 0 && !allowNonZero) {
      throw FileSystemException(
        '$failureLabel (exit $exitCode): ${_clip('$stdout\n$stderr')}',
      );
    }
    return _ProcessOutput(exitCode: exitCode, stdout: stdout, stderr: stderr);
  }

  Future<Map<String, dynamic>?> _readManifest(Directory root) async {
    final file = File(p.join(root.path, 'runtime/manifest.json'));
    if (!await file.exists()) return null;
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } on Object {
      return null;
    }
    return null;
  }

  bool _manifestIsValid(Map<String, dynamic>? manifest) =>
      manifest?['runtime_version'] == expectedRuntimeVersion &&
      manifest?['distribution'] == expectedDistribution &&
      manifest?['distribution_version'] == expectedDistributionVersion &&
      manifest?['architecture'] == expectedArchitecture &&
      manifest?['health_status'] == 'verified';

  Future<void> _writeManifest(
    Directory root, {
    required String box64Version,
    required String wineVersion,
  }) async {
    final file = File(p.join(root.path, 'runtime/manifest.json'));
    await file.parent.create(recursive: true);
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(<String, dynamic>{
        'schema': 1,
        'runtime_version': expectedRuntimeVersion,
        'distribution': expectedDistribution,
        'distribution_version': expectedDistributionVersion,
        'architecture': expectedArchitecture,
        'box64_version': box64Version,
        'wine_version': wineVersion,
        'wine_mode': 'wow64',
        'desktop': '$desktopWidth x $desktopHeight',
        'health_status': 'verified',
        'installed_at': DateTime.now().toUtc().toIso8601String(),
      }),
      flush: true,
    );
  }

  List<String> _safeSystemBinds() {
    final arguments = <String>[];
    for (final path in <String>[
      '/proc',
      '/dev/null',
      '/dev/zero',
      '/dev/random',
      '/dev/urandom',
      '/dev/tty',
      '/dev/pts',
    ]) {
      if (FileSystemEntity.typeSync(path, followLinks: false) !=
          FileSystemEntityType.notFound) {
        arguments.addAll(<String>['-b', path]);
      }
    }
    return arguments;
  }

  Future<int> _directorySize(Directory root) async {
    if (!await root.exists()) return 0;
    var total = 0;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // Fail boleh berubah semasa proses Wine aktif; abaikan satu entri.
        }
      }
    }
    return total;
  }

  bool _isFileOrLink(String path) {
    final type = FileSystemEntity.typeSync(path, followLinks: false);
    return type == FileSystemEntityType.file || type == FileSystemEntityType.link;
  }

  void _assertPrivateAppPath(String path) {
    if (!Platform.isAndroid) return;
    final normalized = p.normalize(path);
    if (!normalized.startsWith('/data/user/') &&
        !normalized.startsWith('/data/data/')) {
      throw FileSystemException(
        'PC Windows mesti berada dalam storan internal private aplikasi.',
        normalized,
      );
    }
  }

  static String _shellQuote(String value) =>
      "'${value.replaceAll("'", "'\\''").replaceAll('\u0000', '')}'";

  static String _clip(String value) {
    const max = 6000;
    final text = value.trim();
    return text.length <= max ? text : '…${text.substring(text.length - max)}';
  }
}

class _ProcessOutput {
  const _ProcessOutput({
    required this.exitCode,
    required this.stdout,
    required this.stderr,
  });

  final int exitCode;
  final String stdout;
  final String stderr;
}
