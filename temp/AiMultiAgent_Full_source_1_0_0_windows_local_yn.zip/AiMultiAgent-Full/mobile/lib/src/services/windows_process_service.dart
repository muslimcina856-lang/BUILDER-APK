import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'windows_runtime_service.dart';

class _WindowsRollingTextBuffer {
  _WindowsRollingTextBuffer(this.maxChars);

  final int maxChars;
  String _value = '';
  bool _truncated = false;

  void write(Object? chunk) {
    final text = chunk?.toString() ?? '';
    if (text.isEmpty) return;
    final combined = '$_value$text';
    if (combined.length <= maxChars) {
      _value = combined;
      return;
    }
    _value = combined.substring(combined.length - maxChars);
    _truncated = true;
  }

  @override
  String toString() =>
      _truncated ? '… output awal dipotong …\n$_value' : _value;
}

class WindowsJob {
  WindowsJob({
    required this.id,
    required this.command,
    required this.workingDirectory,
    required this.startedAt,
    required this.process,
    required this.kind,
  });

  final String id;
  final String command;
  final String workingDirectory;
  final DateTime startedAt;
  final Process process;
  final String kind;
  final _WindowsRollingTextBuffer stdout =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  final _WindowsRollingTextBuffer stderr =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  int? exitCode;
  DateTime? finishedAt;

  bool get running => exitCode == null;

  Map<String, dynamic> snapshot() => <String, dynamic>{
        'job_id': id,
        'kind': kind,
        'command': command,
        'working_directory': workingDirectory,
        'running': running,
        'exit_code': exitCode,
        'started_at': startedAt.toIso8601String(),
        'finished_at': finishedAt?.toIso8601String(),
        'stdout': stdout.toString(),
        'stderr': stderr.toString(),
      };
}

class WindowsProcessService {
  factory WindowsProcessService() => _instance;
  WindowsProcessService._();

  static final WindowsProcessService _instance = WindowsProcessService._();
  static const Uuid _uuid = Uuid();
  static const int _maxRetainedJobs = 32;
  static const int _maxConcurrentJobs = 1;
  static const Duration _gracefulStopTimeout = Duration(seconds: 3);
  static const Duration _forcedStopTimeout = Duration(seconds: 2);

  final WindowsRuntimeService _runtime = WindowsRuntimeService();
  final Map<String, WindowsJob> _jobs = <String, WindowsJob>{};

  Iterable<WindowsJob> get jobs => _jobs.values;

  bool isDestructiveCommand(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    const patterns = <String>[
      ' del ',
      ' erase ',
      ' rmdir ',
      ' rd /s',
      ' format ',
      ' diskpart',
      ' bcdedit',
      ' reg delete',
      ' shutdown',
      ' cipher /w',
      ' taskkill /f',
    ];
    final padded = ' $normalized ';
    return patterns.any(padded.contains);
  }

  Future<ToolResult> startCommand({
    required String command,
    String workingDirectory = '.',
  }) async {
    final text = command.trim();
    if (text.isEmpty) {
      return const ToolResult(success: false, output: 'Arahan Windows kosong.');
    }
    return _start(
      displayCommand: text,
      guestCommand: _runtime.wrapWindowsCommand(text),
      workingDirectory: workingDirectory,
      kind: 'cmd',
    );
  }

  Future<ToolResult> startExecutable({
    required String path,
    List<String> arguments = const <String>[],
    String workingDirectory = '.',
  }) async {
    try {
      final resolved = await _runtime.resolveExecutablePath(path);
      final cleanArguments = arguments
          .map((value) => value.replaceAll('\u0000', ''))
          .toList(growable: false);
      return _start(
        displayCommand: '${resolved.guestPath} ${cleanArguments.join(' ')}'.trim(),
        guestCommand: _runtime.wrapWindowsExecutable(
          resolved.guestPath,
          cleanArguments,
        ),
        workingDirectory: workingDirectory,
        kind: 'exe',
      );
    } on FileSystemException catch (error) {
      return ToolResult(success: false, output: error.message);
    }
  }

  Future<ToolResult> _start({
    required String displayCommand,
    required String guestCommand,
    required String workingDirectory,
    required String kind,
  }) async {
    if (!AppConfig.isFullEdition) {
      return const ToolResult(
        success: false,
        output: 'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final runningJobs = _jobs.values.where((job) => job.running).length;
    if (runningJobs >= _maxConcurrentJobs) {
      return const ToolResult(
        success: false,
        output: 'Satu proses Windows sedang aktif. Pantau atau hentikan job itu dahulu.',
      );
    }
    _pruneCompletedJobs();
    try {
      await _runtime.ensureReady();
      final spec = await _runtime.commandSpec(
        command: guestCommand,
        relativeWorkingDirectory: workingDirectory,
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final job = WindowsJob(
        id: _uuid.v4(),
        command: displayCommand,
        workingDirectory: workingDirectory,
        startedAt: DateTime.now(),
        process: process,
        kind: kind,
      );
      _jobs[job.id] = job;
      process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stdout.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stderr.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      unawaited(process.exitCode.then((code) {
        job.exitCode = code;
        job.finishedAt = DateTime.now();
      }));
      return ToolResult(
        success: true,
        output: jsonEncode(job.snapshot()),
        data: job.snapshot(),
      );
    } on FileSystemException catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows tidak dapat dimulakan: ${error.message}',
      );
    } on ProcessException catch (error) {
      return ToolResult(
        success: false,
        output: 'Proses Windows gagal dimulakan: ${error.message}',
      );
    } on TimeoutException {
      return const ToolResult(
        success: false,
        output: 'Penyediaan PC Windows tamat masa.',
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows gagal dimulakan dengan selamat: $error',
      );
    }
  }

  Future<ToolResult> poll(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    final snapshot = job.snapshot();
    return ToolResult(
      success: job.exitCode == null || job.exitCode == 0,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> stop(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    if (!job.running) return poll(jobId);
    await _stopJob(job);
    final snapshot = job.snapshot();
    return ToolResult(
      success: !job.running,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> listWindows() async {
    if (!_jobs.values.any((job) => job.running)) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk diperiksa.',
      );
    }
    const command = r'''
DISPLAY=:99
export DISPLAY
ids="$(xdotool search --onlyvisible --name '.*' 2>/dev/null || true)"
for id in $ids; do
  name="$(xdotool getwindowname "$id" 2>/dev/null || true)"
  printf '%s\t%s\n' "$id" "$name"
done
''';
    return _runControl(command, action: 'list_windows');
  }

  Future<ToolResult> uiAction({
    required String action,
    int? x,
    int? y,
    int? button,
    String text = '',
    String key = '',
    String windowId = '',
  }) async {
    if (!_jobs.values.any((job) => job.running)) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk dikawal.',
      );
    }
    String command;
    switch (action) {
      case 'click':
        final safeX = x ?? -1;
        final safeY = y ?? -1;
        final safeButton = button ?? 1;
        if (safeX < 0 ||
            safeX >= WindowsRuntimeService.desktopWidth ||
            safeY < 0 ||
            safeY >= WindowsRuntimeService.desktopHeight ||
            safeButton < 1 ||
            safeButton > 5) {
          return const ToolResult(
            success: false,
            output: 'Koordinat atau butang mouse Windows tidak sah.',
          );
        }
        command =
            'DISPLAY=:99 xdotool mousemove --sync $safeX $safeY click $safeButton';
        break;
      case 'type':
        final clean = text.replaceAll('\u0000', '');
        if (clean.isEmpty || clean.length > 4000) {
          return const ToolResult(
            success: false,
            output: 'Teks untuk ditaip mesti 1 hingga 4000 aksara.',
          );
        }
        command =
            'DISPLAY=:99 xdotool type --clearmodifiers --delay 8 ${_shellQuote(clean)}';
        break;
      case 'key':
        final clean = key.trim();
        if (!RegExp(r'^[A-Za-z0-9_+:.\-]{1,120}$').hasMatch(clean)) {
          return const ToolResult(
            success: false,
            output: 'Nama kekunci xdotool tidak sah.',
          );
        }
        command = 'DISPLAY=:99 xdotool key --clearmodifiers ${_shellQuote(clean)}';
        break;
      case 'focus':
        final clean = windowId.trim();
        if (!RegExp(r'^\d{1,20}$').hasMatch(clean)) {
          return const ToolResult(
            success: false,
            output: 'window_id mesti nombor daripada windows_list_windows.',
          );
        }
        command = 'DISPLAY=:99 xdotool windowactivate --sync $clean';
        break;
      default:
        return const ToolResult(
          success: false,
          output: 'Action GUI Windows tidak dikenali.',
        );
    }
    return _runControl(command, action: action);
  }

  Future<ToolResult> _runControl(
    String command, {
    required String action,
  }) async {
    try {
      final spec = await _runtime.commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stdoutFuture = process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stdout = await stdoutFuture;
      final stderr = await stderrFuture;
      final data = <String, dynamic>{
        'action': action,
        'exit_code': exitCode,
        'stdout': stdout,
        'stderr': stderr,
      };
      return ToolResult(
        success: exitCode == 0,
        output: exitCode == 0
            ? (stdout.trim().isEmpty ? 'Action GUI Windows selesai.' : stdout.trim())
            : 'Action GUI Windows gagal (exit $exitCode): $stderr',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Action GUI Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Action GUI Windows gagal: $error');
    }
  }

  Future<ToolResult> screenshot() async {
    final running = _jobs.values.where((job) => job.running).isNotEmpty;
    if (!running) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk di-screenshot.',
      );
    }
    try {
      final hostPath = await _runtime.screenshotHostPath();
      final linuxRoot = (await WindowsRuntimeService().commandSpec(
        command: 'true',
        relativeWorkingDirectory: '.',
      ));
      final workspaceHost = linuxRoot.hostWorkingDirectory;
      final relative = p.relative(hostPath, from: workspaceHost).replaceAll('\\', '/');
      final guestPath = '/workspace/$relative';
      final spec = await _runtime.commandSpec(
        command: 'DISPLAY=${WindowsRuntimeService.displayName} scrot -q 100 ${_shellQuote(guestPath)}',
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stderr = await stderrFuture;
      if (exitCode != 0 || !await File(hostPath).exists()) {
        return ToolResult(
          success: false,
          output: 'Screenshot Windows gagal (exit $exitCode): $stderr',
        );
      }
      final data = <String, dynamic>{
        'path': hostPath,
        'mime': 'image/png',
        'width': WindowsRuntimeService.desktopWidth,
        'height': WindowsRuntimeService.desktopHeight,
      };
      return ToolResult(
        success: true,
        output: 'Screenshot PC Windows tersedia.',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Screenshot Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Screenshot Windows gagal: $error');
    }
  }

  Future<void> stopAll() async {
    final running = _jobs.values.where((job) => job.running).toList(growable: false);
    await Future.wait(running.map(_stopJob));
  }

  Future<void> _stopJob(WindowsJob job) async {
    if (!job.running) return;
    final sent = job.process.kill(ProcessSignal.sigterm);
    if (!sent) job.process.kill(ProcessSignal.sigkill);
    try {
      final code = await job.process.exitCode.timeout(_gracefulStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
      return;
    } on TimeoutException {
      job.process.kill(ProcessSignal.sigkill);
    }
    try {
      final code = await job.process.exitCode.timeout(_forcedStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
    } on TimeoutException {
      job.stderr.write('\nProses Windows tidak memberi respons selepas SIGKILL.');
    }
  }

  void _pruneCompletedJobs() {
    if (_jobs.length < _maxRetainedJobs) return;
    final completed = _jobs.values.where((job) => !job.running).toList()
      ..sort((a, b) =>
          (a.finishedAt ?? a.startedAt).compareTo(b.finishedAt ?? b.startedAt));
    while (_jobs.length >= _maxRetainedJobs && completed.isNotEmpty) {
      _jobs.remove(completed.removeAt(0).id);
    }
  }

  void dispose() => unawaited(stopAll());

  static String _shellQuote(String value) =>
      "'${value.replaceAll("'", "'\\''").replaceAll('\u0000', '')}'";
}
