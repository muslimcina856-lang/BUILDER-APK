// ALZZCONTROLLER - Core App
console.log('ALZZCONTROLLER v1.0 loaded');
