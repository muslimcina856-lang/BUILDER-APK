# 🚀 YonzDB - Database Management Platform

YonzDB adalah aplikasi Flutter modern untuk manajemen database dengan UI cyberpunk.

## 📋 Default Credentials

```
Email:    admin@yonzdb.com
Password: YonzDB@2024
```

## 🚀 Build & Run

```bash
# Get dependencies
flutter pub get

# Run
flutter run

# Build Release APK
flutter build apk --release
```

## 📦 Output

```
Release APK: build/app/outputs/apk/release/app-release.apk
App Bundle:  build/app/outputs/bundle/release/app-release.aab
```

## 🎨 Theme

- Primary: #00D4FF (Cyan)
- Secondary: #FF006E (Pink)
- Background: #0A0E27 (Dark)

---

**Version**: 1.0.0 | **Status**: ✅ Ready
