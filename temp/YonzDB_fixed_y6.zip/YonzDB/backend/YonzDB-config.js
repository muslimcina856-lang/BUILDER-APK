module.exports = {
  tokens: "8218577733:AAGCZaBwKPkhHxR-chv0fwPklEszfRJAdE0",  // Ubah Jadi Token Bot Mu !!!
  owner: "7837260212", // Ubah Jadi Id Mu !!!
  port: "2005", // Ubah Jadi Port Panel Mu !!!
  ipvps: "kyu-silence.hostingvvip.my.id" // Ubah Jadi Ip Vps Mu !!!
};