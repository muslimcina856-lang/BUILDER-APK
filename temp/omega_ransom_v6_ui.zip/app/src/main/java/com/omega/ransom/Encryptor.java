package com.omega.ransom;

public class Encryptor {
    // Placeholder for encryption logic
}
