import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import '../services/language_service.dart';

/// Looks up a translated string for [key] using the language currently
/// selected in [LanguageService]. Falls back to English, then to the key
/// itself, so a missing translation never crashes the UI.
String tr(BuildContext context, String key) {
  final lang = context.watch<LanguageService>().language ?? AppLanguage.en;
  return AppStrings.of(lang, key);
}

/// Same lookup, but without subscribing to rebuilds — use inside
/// callbacks/dialogs built outside the widget tree's build method.
String trStatic(BuildContext context, String key) {
  final lang = context.read<LanguageService>().language ?? AppLanguage.en;
  return AppStrings.of(lang, key);
}

class AppStrings {
  static String of(AppLanguage lang, String key) {
    return _table[key]?[lang] ?? _table[key]?[AppLanguage.en] ?? key;
  }

  static final Map<String, Map<AppLanguage, String>> _table = {
    // ── Common ──────────────────────────────────────────────────
    'app_name': {
      AppLanguage.en: 'Earl Builder',
      AppLanguage.ms: 'Earl Builder',
      AppLanguage.id: 'Earl Builder',
    },
    'app_tagline': {
      AppLanguage.en: 'Build APK from a project link',
      AppLanguage.ms: 'Bina APK daripada pautan projek',
      AppLanguage.id: 'Bangun APK dari tautan proyek',
    },
    'common_cancel': {
      AppLanguage.en: 'Cancel',
      AppLanguage.ms: 'Batal',
      AppLanguage.id: 'Batal',
    },
    'common_continue': {
      AppLanguage.en: 'Continue',
      AppLanguage.ms: 'Teruskan',
      AppLanguage.id: 'Lanjutkan',
    },
    'common_close': {
      AppLanguage.en: 'Close',
      AppLanguage.ms: 'Tutup',
      AppLanguage.id: 'Tutup',
    },
    'common_retry': {
      AppLanguage.en: 'Retry',
      AppLanguage.ms: 'Cuba Lagi',
      AppLanguage.id: 'Coba Lagi',
    },
    'common_ok': {
      AppLanguage.en: 'OK',
      AppLanguage.ms: 'OK',
      AppLanguage.id: 'OK',
    },
    'common_server_error': {
      AppLanguage.en: 'Error: could not reach the server.',
      AppLanguage.ms: 'Ralat: tidak dapat sambung ke server.',
      AppLanguage.id: 'Error: tidak dapat terhubung ke server.',
    },

    // ── Home screen ─────────────────────────────────────────────
    'home_free_credits_tooltip': {
      AppLanguage.en: 'Free Credits',
      AppLanguage.ms: 'Kredit Percuma',
      AppLanguage.id: 'Kredit Gratis',
    },
    'home_show_ads_tooltip': {
      AppLanguage.en: 'Show Ads',
      AppLanguage.ms: 'Tonton Iklan',
      AppLanguage.id: 'Tonton Iklan',
    },
    'home_watch_ads': {
      AppLanguage.en: 'Watch Ads',
      AppLanguage.ms: 'Tonton Iklan',
      AppLanguage.id: 'Tonton Iklan',
    },
    'home_stats_credits': {
      AppLanguage.en: 'CURRENT BALANCE',
      AppLanguage.ms: 'BAKI SEMASA',
      AppLanguage.id: 'SALDO SAAT INI',
    },
    'home_stats_submits': {
      AppLanguage.en: 'Submits',
      AppLanguage.ms: 'Penghantaran',
      AppLanguage.id: 'Kiriman',
    },
    'home_stats_telegram': {
      AppLanguage.en: 'Telegram',
      AppLanguage.ms: 'Telegram',
      AppLanguage.id: 'Telegram',
    },
    'home_link_telegram_title': {
      AppLanguage.en: 'Link Telegram',
      AppLanguage.ms: 'Ikat Telegram',
      AppLanguage.id: 'Hubungkan Telegram',
    },
    'home_link_telegram_subtitle': {
      AppLanguage.en: 'Get build notifications',
      AppLanguage.ms: 'Dapatkan notifikasi build',
      AppLanguage.id: 'Dapatkan notifikasi build',
    },
    'home_linked_to': {
      AppLanguage.en: 'Linked to',
      AppLanguage.ms: 'Terikat dengan',
      AppLanguage.id: 'Terhubung dengan',
    },
    'home_linked_badge': {
      AppLanguage.en: 'Linked',
      AppLanguage.ms: 'Terikat',
      AppLanguage.id: 'Terhubung',
    },
    'home_redeem_code_title': {
      AppLanguage.en: 'Redeem Code',
      AppLanguage.ms: 'Tebus Kod',
      AppLanguage.id: 'Tukar Kode',
    },
    'home_redeem_code_subtitle': {
      AppLanguage.en: 'Redeem a 12-character code for credits',
      AppLanguage.ms: 'Tebus kod 12-aksara untuk kredit',
      AppLanguage.id: 'Tukar kode 12-karakter untuk kredit',
    },
    'home_about_title': {
      AppLanguage.en: 'About',
      AppLanguage.ms: 'Tentang',
      AppLanguage.id: 'Tentang',
    },
    'home_about_subtitle': {
      AppLanguage.en: 'App info, owner & updates',
      AppLanguage.ms: 'Info app, pemilik & kemas kini',
      AppLanguage.id: 'Info app, pemilik & pembaruan',
    },
    'home_no_history_title': {
      AppLanguage.en: 'No history yet',
      AppLanguage.ms: 'Belum ada sejarah',
      AppLanguage.id: 'Belum ada riwayat',
    },
    'home_no_history_subtitle': {
      AppLanguage.en: 'Submitted projects will appear here.',
      AppLanguage.ms: 'Projek yang dihantar akan muncul di sini.',
      AppLanguage.id: 'Proyek yang dikirim akan muncul di sini.',
    },
    'home_section_activity': {
      AppLanguage.en: 'ACTIVITY',
      AppLanguage.ms: 'AKTIVITI',
      AppLanguage.id: 'AKTIVITAS',
    },
    'home_section_history': {
      AppLanguage.en: 'HISTORY',
      AppLanguage.ms: 'SEJARAH',
      AppLanguage.id: 'RIWAYAT',
    },
    'home_device_id_label': {
      AppLanguage.en: 'DEVICE ID',
      AppLanguage.ms: 'ID PERANTI',
      AppLanguage.id: 'ID PERANGKAT',
    },
    'home_copy_device_id': {
      AppLanguage.en: 'Copy Device ID',
      AppLanguage.ms: 'Salin ID Peranti',
      AppLanguage.id: 'Salin ID Perangkat',
    },
    'home_device_id_copied': {
      AppLanguage.en: 'Device ID copied!',
      AppLanguage.ms: 'ID Peranti disalin!',
      AppLanguage.id: 'ID Perangkat disalin!',
    },
    'home_submit_project': {
      AppLanguage.en: 'Submit Project Link',
      AppLanguage.ms: 'Hantar Pautan Projek',
      AppLanguage.id: 'Kirim Tautan Proyek',
    },
    'home_telegram_required_title': {
      AppLanguage.en: 'Telegram Required',
      AppLanguage.ms: 'Telegram Diperlukan',
      AppLanguage.id: 'Telegram Diperlukan',
    },
    'home_telegram_required_body': {
      AppLanguage.en:
          'You need to link a Telegram ID first to receive build notifications. '
          'Without a Telegram ID, you won\'t be notified when your build is done.',
      AppLanguage.ms:
          'Anda perlu bind Telegram ID terlebih dahulu untuk menerima notifikasi build. '
          'Tanpa Telegram ID, anda tidak akan dapat notifikasi apabila build selesai.',
      AppLanguage.id:
          'Anda perlu menghubungkan ID Telegram terlebih dahulu untuk menerima notifikasi build. '
          'Tanpa ID Telegram, Anda tidak akan mendapat notifikasi saat build selesai.',
    },
    'home_link_now': {
      AppLanguage.en: 'Link Now',
      AppLanguage.ms: 'Ikat Sekarang',
      AppLanguage.id: 'Hubungkan Sekarang',
    },
    'home_free_credits_dialog_title': {
      AppLanguage.en: 'Free Credits',
      AppLanguage.ms: 'Kredit Percuma',
      AppLanguage.id: 'Kredit Gratis',
    },
    'home_free_credits_dialog_body': {
      AppLanguage.en:
          'Watch an ad to earn between 1 and 10 credits, selected randomly '
          'each time with an equal chance for every amount.\n\n'
          'Ads aren\'t always available — if there\'s nothing to watch right '
          'now, check back again later.',
      AppLanguage.ms:
          'Tonton satu iklan untuk dapat antara 1 hingga 10 kredit, dipilih secara '
          'rawak setiap kali dengan peluang yang sama bagi setiap jumlah.\n\n'
          'Iklan tidak selalu ada — kalau takde apa nak ditonton sekarang, '
          'cuba semak semula lain kali.',
      AppLanguage.id:
          'Tonton iklan untuk mendapatkan antara 1 hingga 10 kredit, dipilih secara '
          'acak setiap kali dengan peluang yang sama untuk setiap jumlah.\n\n'
          'Iklan tidak selalu tersedia — jika tidak ada yang bisa ditonton sekarang, '
          'coba cek lagi nanti.',
    },
    'home_got_it': {
      AppLanguage.en: 'Got it',
      AppLanguage.ms: 'Faham',
      AppLanguage.id: 'Mengerti',
    },
    'home_ad_available_title': {
      AppLanguage.en: 'Ad available',
      AppLanguage.ms: 'Iklan tersedia',
      AppLanguage.id: 'Iklan tersedia',
    },
    'home_ad_progress_views': {
      AppLanguage.en: '{current}/{limit} views',
      AppLanguage.ms: '{current}/{limit} tontonan',
      AppLanguage.id: '{current}/{limit} tayangan',
    },
    'home_ad_progress_days': {
      AppLanguage.en: '{remaining} days remaining',
      AppLanguage.ms: '{remaining} hari berbaki',
      AppLanguage.id: '{remaining} hari tersisa',
    },
    'home_ad_daily_remaining': {
      AppLanguage.en: '{n} rewards left today',
      AppLanguage.ms: '{n} ganjaran berbaki hari ini',
      AppLanguage.id: '{n} hadiah tersisa hari ini',
    },
    'home_ad_watch_now': {
      AppLanguage.en: 'Watch now',
      AppLanguage.ms: 'Tonton sekarang',
      AppLanguage.id: 'Tonton sekarang',
    },
    'home_maintenance_title': {
      AppLanguage.en: 'Server Under Maintenance',
      AppLanguage.ms: 'Server Sedang Diselenggara',
      AppLanguage.id: 'Server Sedang Dalam Perbaikan',
    },
    'home_unavailable_title': {
      AppLanguage.en: 'Server Unavailable',
      AppLanguage.ms: 'Server Tidak Tersedia',
      AppLanguage.id: 'Server Tidak Tersedia',
    },
    'home_unavailable_message': {
      AppLanguage.en: 'Cannot reach the server right now. Please try again shortly.',
      AppLanguage.ms: 'Tidak dapat menghubungi server sekarang. Sila cuba sebentar lagi.',
      AppLanguage.id: 'Tidak dapat menghubungi server saat ini. Silakan coba lagi sebentar.',
    },
    'home_maintenance_default_message': {
      AppLanguage.en: 'Please try again later.',
      AppLanguage.ms: 'Sila cuba lagi nanti.',
      AppLanguage.id: 'Silakan coba lagi nanti.',
    },
    'home_maintenance_auto_unlock': {
      AppLanguage.en: 'This screen will unlock automatically once the server is back.',
      AppLanguage.ms: 'Skrin ini akan buka semula secara automatik apabila server kembali online.',
      AppLanguage.id: 'Layar ini akan terbuka otomatis begitu server kembali online.',
    },
    'home_loading': {
      AppLanguage.en: 'Loading…',
      AppLanguage.ms: 'Memuatkan…',
      AppLanguage.id: 'Memuat…',
    },
    'home_not_set': {
      AppLanguage.en: 'Not set',
      AppLanguage.ms: 'Belum ditetapkan',
      AppLanguage.id: 'Belum diatur',
    },
    'home_estimated_minutes': {
      AppLanguage.en: 'Estimated: ~{n} min',
      AppLanguage.ms: 'Anggaran: ~{n} minit',
      AppLanguage.id: 'Perkiraan: ~{n} menit',
    },
    'home_refresh_status_tooltip': {
      AppLanguage.en: 'Refresh status',
      AppLanguage.ms: 'Muat semula status',
      AppLanguage.id: 'Segarkan status',
    },
    'home_clear': {
      AppLanguage.en: 'Clear',
      AppLanguage.ms: 'Kosongkan',
      AppLanguage.id: 'Bersihkan',
    },
    'home_build_running': {
      AppLanguage.en: 'build running',
      AppLanguage.ms: 'build sedang berjalan',
      AppLanguage.id: 'build sedang berjalan',
    },
    'home_builds_running': {
      AppLanguage.en: 'builds running',
      AppLanguage.ms: 'build sedang berjalan',
      AppLanguage.id: 'build sedang berjalan',
    },

    // ── Upload screen ───────────────────────────────────────────
    'upload_title': {
      AppLanguage.en: 'Submit Project Link',
      AppLanguage.ms: 'Hantar Pautan Projek',
      AppLanguage.id: 'Kirim Tautan Proyek',
    },
    'upload_select_zip': {
      AppLanguage.en: 'Select ZIP File',
      AppLanguage.ms: 'Pilih Fail ZIP',
      AppLanguage.id: 'Pilih File ZIP',
    },
    'upload_supports': {
      AppLanguage.en: 'Paste a project download link. The builder will download, detect and build it.',
      AppLanguage.ms: 'Tampal pautan muat turun projek. Builder akan muat turun, kesan dan membinanya.',
      AppLanguage.id: 'Tempel tautan unduhan proyek. Builder akan mengunduh, mendeteksi, dan membangunnya.',
    },
    'upload_file_selected': {
      AppLanguage.en: 'File Selected',
      AppLanguage.ms: 'Fail Dipilih',
      AppLanguage.id: 'File Dipilih',
    },
    'upload_ready': {
      AppLanguage.en: 'Ready to submit a link',
      AppLanguage.ms: 'Sedia untuk menghantar pautan',
      AppLanguage.id: 'Siap mengirim tautan',
    },
    'upload_ready_named': {
      AppLanguage.en: 'Ready:',
      AppLanguage.ms: 'Sedia:',
      AppLanguage.id: 'Siap:',
    },
    'upload_validating': {
      AppLanguage.en: 'Validating project…',
      AppLanguage.ms: 'Mengesahkan projek…',
      AppLanguage.id: 'Memvalidasi proyek…',
    },
    'upload_validating_link': {
      AppLanguage.en: 'Checking project link…',
      AppLanguage.ms: 'Memeriksa pautan projek…',
      AppLanguage.id: 'Memeriksa tautan proyek…',
    },
    'upload_link_required': {
      AppLanguage.en: 'Files over 3 MB must be submitted using a project link.',
      AppLanguage.ms: 'Fail melebihi 3 MB mesti dihantar menggunakan pautan projek.',
      AppLanguage.id: 'File melebihi 3 MB harus dikirim menggunakan tautan proyek.',
    },
    'upload_enter_project_link': {
      AppLanguage.en: 'Enter project link',
      AppLanguage.ms: 'Masukkan pautan projek',
      AppLanguage.id: 'Masukkan tautan proyek',
    },
    'upload_link_label': {
      AppLanguage.en: 'Project link',
      AppLanguage.ms: 'Pautan projek',
      AppLanguage.id: 'Tautan proyek',
    },
    'upload_file_name_optional': {
      AppLanguage.en: 'Result file name (optional)',
      AppLanguage.ms: 'Nama fail hasil (opsional)',
      AppLanguage.id: 'Nama file hasil (opsional)',
    },
    'upload_file_name_hint': {
      AppLanguage.en: 'Example: Skybound Quest v1.0',
      AppLanguage.ms: 'Contoh: Skybound Quest v1.0',
      AppLanguage.id: 'Contoh: Skybound Quest v1.0',
    },
    'upload_file_name_helper': {
      AppLanguage.en: 'Leave empty to use the current automatic name.',
      AppLanguage.ms: 'Biarkan kosong untuk guna nama automatik sekarang.',
      AppLanguage.id: 'Biarkan kosong untuk memakai nama otomatis saat ini.',
    },
    'upload_link_ready': {
      AppLanguage.en: 'Project link ready to submit',
      AppLanguage.ms: 'Pautan projek sedia untuk dihantar',
      AppLanguage.id: 'Tautan proyek siap dikirim',
    },
    'upload_invalid_link': {
      AppLanguage.en: 'Enter a valid HTTP or HTTPS project link.',
      AppLanguage.ms: 'Masukkan pautan projek HTTP atau HTTPS yang sah.',
      AppLanguage.id: 'Masukkan tautan proyek HTTP atau HTTPS yang valid.',
    },
    'upload_project_missing': {
      AppLanguage.en: 'The selected project file can no longer be found.',
      AppLanguage.ms: 'Fail projek yang dipilih tidak lagi ditemui.',
      AppLanguage.id: 'File proyek yang dipilih tidak lagi ditemukan.',
    },
    'upload_invalid_project': {
      AppLanguage.en: 'The file is not a valid supported project ZIP.',
      AppLanguage.ms: 'Fail ini bukan ZIP projek disokong yang sah.',
      AppLanguage.id: 'File ini bukan ZIP proyek yang valid dan didukung.',
    },
    'upload_link_too_large': {
      AppLanguage.en: 'The linked project exceeds the 1 GB validation limit.',
      AppLanguage.ms: 'Projek berpautan melebihi had pengesahan 1 GB.',
      AppLanguage.id: 'Proyek tertaut melebihi batas validasi 1 GB.',
    },
    'upload_failed_colon': {
      AppLanguage.en: 'Failed:',
      AppLanguage.ms: 'Gagal:',
      AppLanguage.id: 'Gagal:',
    },
    'upload_select_file_first': {
      AppLanguage.en: 'ENTER LINK FIRST',
      AppLanguage.ms: 'MASUKKAN PAUTAN DAHULU',
      AppLanguage.id: 'MASUKKAN TAUTAN DULU',
    },
    'upload_submit_project': {
      AppLanguage.en: 'SUBMIT LINK',
      AppLanguage.ms: 'HANTAR PAUTAN',
      AppLanguage.id: 'KIRIM TAUTAN',
    },
    'upload_starting': {
      AppLanguage.en: 'Sending project link…',
      AppLanguage.ms: 'Menghantar pautan projek…',
      AppLanguage.id: 'Mengirim tautan proyek…',
    },
    'upload_uploading': {
      AppLanguage.en: 'Sending link…',
      AppLanguage.ms: 'Menghantar pautan…',
      AppLanguage.id: 'Mengirim tautan…',
    },
    'upload_processing': {
      AppLanguage.en: 'Starting the build…',
      AppLanguage.ms: 'Memulakan build…',
      AppLanguage.id: 'Memulai build…',
    },
    'upload_success': {
      AppLanguage.en: 'Success',
      AppLanguage.ms: 'Berjaya',
      AppLanguage.id: 'Berhasil',
    },
    'upload_success_queued': {
      AppLanguage.en: 'Success! Queued for build.',
      AppLanguage.ms: 'Berjaya! Dalam giliran untuk dibina.',
      AppLanguage.id: 'Berhasil! Masuk antrean untuk build.',
    },
    'upload_submit_another': {
      AppLanguage.en: 'Submit Another',
      AppLanguage.ms: 'Hantar Lagi',
      AppLanguage.id: 'Kirim Lagi',
    },
    'upload_back': {
      AppLanguage.en: 'Back',
      AppLanguage.ms: 'Kembali',
      AppLanguage.id: 'Kembali',
    },
    'upload_file_too_large': {
      AppLanguage.en: 'File exceeds the 1 GB limit.',
      AppLanguage.ms: 'Fail melebihi had 1 GB.',
      AppLanguage.id: 'File melebihi batas 1 GB.',
    },
    'upload_pick_failed': {
      AppLanguage.en: 'Failed to pick file',
      AppLanguage.ms: 'Gagal memilih fail',
      AppLanguage.id: 'Gagal memilih file',
    },

    // ── Bind Telegram screen ────────────────────────────────────
    'bind_title': {
      AppLanguage.en: 'Link Telegram',
      AppLanguage.ms: 'Ikat Telegram',
      AppLanguage.id: 'Hubungkan Telegram',
    },
    'bind_already_linked_title': {
      AppLanguage.en: 'Device Already Linked',
      AppLanguage.ms: 'Peranti Sudah Diikat',
      AppLanguage.id: 'Perangkat Sudah Terhubung',
    },
    'bind_linked_with': {
      AppLanguage.en: 'Linked with Telegram ID:',
      AppLanguage.ms: 'Terikat dengan Telegram ID:',
      AppLanguage.id: 'Terhubung dengan ID Telegram:',
    },
    'bind_to_link_another': {
      AppLanguage.en: 'To link a different Telegram account, unbind this device first.',
      AppLanguage.ms: 'Untuk mengikat akaun Telegram lain, unbind dahulu peranti ini.',
      AppLanguage.id: 'Untuk menghubungkan akun Telegram lain, putuskan perangkat ini dulu.',
    },
    'bind_unbind': {
      AppLanguage.en: 'Unbind',
      AppLanguage.ms: 'Unbind',
      AppLanguage.id: 'Putuskan',
    },
    'bind_unbind_confirm_title': {
      AppLanguage.en: 'Unbind Telegram?',
      AppLanguage.ms: 'Unbind Telegram?',
      AppLanguage.id: 'Putuskan Telegram?',
    },
    'bind_unbind_confirm_body': {
      AppLanguage.en:
          'This device will be disconnected from its current Telegram account. '
          'You will need to link a Telegram account again before you can use related features.',
      AppLanguage.ms:
          'Peranti ini akan diputuskan daripada akaun Telegram yang sedia ada. '
          'Anda perlu mengikat semula akaun Telegram sebelum boleh guna semula ciri berkaitan.',
      AppLanguage.id:
          'Perangkat ini akan diputuskan dari akun Telegram yang ada. '
          'Anda perlu menghubungkan akun Telegram lagi sebelum bisa menggunakan fitur terkait.',
    },
    'bind_unbind_failed': {
      AppLanguage.en: 'Failed to unbind.',
      AppLanguage.ms: 'Gagal unbind.',
      AppLanguage.id: 'Gagal memutuskan.',
    },
    'bind_unbind_success': {
      AppLanguage.en: 'Telegram unbound successfully. You can link a new account now.',
      AppLanguage.ms: 'Telegram berjaya diunbind. Anda boleh ikat akaun baru sekarang.',
      AppLanguage.id: 'Telegram berhasil diputuskan. Anda bisa menghubungkan akun baru sekarang.',
    },
    'bind_enter_telegram_id': {
      AppLanguage.en: 'Enter Your Telegram ID',
      AppLanguage.ms: 'Masukkan Telegram ID Anda',
      AppLanguage.id: 'Masukkan ID Telegram Anda',
    },
    'bind_code_will_be_sent': {
      AppLanguage.en:
          'A verification code will be sent to that Telegram account. You will '
          'need to enter it to confirm the link.',
      AppLanguage.ms:
          'Satu kod pengesahan akan dihantar ke Telegram tersebut. Anda perlu '
          'memasukkan kod itu untuk sahkan pengikatan.',
      AppLanguage.id:
          'Kode verifikasi akan dikirim ke akun Telegram itu. Anda perlu '
          'memasukkan kode tersebut untuk mengonfirmasi koneksi.',
    },
    'bind_telegram_id_label': {
      AppLanguage.en: 'Telegram ID',
      AppLanguage.ms: 'Telegram ID',
      AppLanguage.id: 'ID Telegram',
    },
    'bind_telegram_id_invalid': {
      AppLanguage.en: 'Invalid Telegram ID. Please enter a numeric ID.',
      AppLanguage.ms: 'Telegram ID tidak sah. Sila masukkan ID berangka.',
      AppLanguage.id: 'ID Telegram tidak valid. Silakan masukkan ID berupa angka.',
    },
    'bind_send_code': {
      AppLanguage.en: 'Send Verification Code',
      AppLanguage.ms: 'Hantar Kod Pengesahan',
      AppLanguage.id: 'Kirim Kode Verifikasi',
    },
    'bind_enter_code_title': {
      AppLanguage.en: 'Enter Verification Code',
      AppLanguage.ms: 'Masukkan Kod Pengesahan',
      AppLanguage.id: 'Masukkan Kode Verifikasi',
    },
    'bind_check_telegram_message': {
      AppLanguage.en: 'Check the Telegram message from the bot and enter the code you received.',
      AppLanguage.ms: 'Semak mesej Telegram daripada bot dan masukkan kod yang diterima.',
      AppLanguage.id: 'Periksa pesan Telegram dari bot dan masukkan kode yang Anda terima.',
    },
    'bind_verification_code_label': {
      AppLanguage.en: 'Verification Code',
      AppLanguage.ms: 'Kod Pengesahan',
      AppLanguage.id: 'Kode Verifikasi',
    },
    'bind_enter_code_received': {
      AppLanguage.en: 'Please enter the verification code you received.',
      AppLanguage.ms: 'Sila masukkan kod pengesahan yang diterima.',
      AppLanguage.id: 'Silakan masukkan kode verifikasi yang Anda terima.',
    },
    'bind_confirm_and_link': {
      AppLanguage.en: 'Confirm & Link',
      AppLanguage.ms: 'Sahkan & Ikat',
      AppLanguage.id: 'Konfirmasi & Hubungkan',
    },
    'bind_use_different_id': {
      AppLanguage.en: 'Use a different Telegram ID',
      AppLanguage.ms: 'Guna Telegram ID lain',
      AppLanguage.id: 'Gunakan ID Telegram lain',
    },
    'bind_code_expired': {
      AppLanguage.en: 'Code expired',
      AppLanguage.ms: 'Kod tamat tempoh',
      AppLanguage.id: 'Kode kedaluwarsa',
    },
    'bind_request_new_code': {
      AppLanguage.en: 'Request a new code',
      AppLanguage.ms: 'Minta kod baharu',
      AppLanguage.id: 'Minta kode baru',
    },
    'bind_code_send_failed': {
      AppLanguage.en: 'Failed to send verification code.',
      AppLanguage.ms: 'Gagal menghantar kod pengesahan.',
      AppLanguage.id: 'Gagal mengirim kode verifikasi.',
    },
    'bind_code_sent': {
      AppLanguage.en: 'Verification code has been sent to your Telegram.',
      AppLanguage.ms: 'Kod pengesahan telah dihantar ke Telegram anda.',
      AppLanguage.id: 'Kode verifikasi telah dikirim ke Telegram Anda.',
    },
    'bind_code_wrong': {
      AppLanguage.en: 'Incorrect verification code.',
      AppLanguage.ms: 'Kod pengesahan salah.',
      AppLanguage.id: 'Kode verifikasi salah.',
    },
    'bind_important': {
      AppLanguage.en: 'Important',
      AppLanguage.ms: 'Penting',
      AppLanguage.id: 'Penting',
    },
    'bind_open_telegram_bot': {
      AppLanguage.en: 'Open Telegram Bot',
      AppLanguage.ms: 'Buka Bot Telegram',
      AppLanguage.id: 'Buka Bot Telegram',
    },
    'bind_resend_code': {
      AppLanguage.en: 'Send Code Again',
      AppLanguage.ms: 'Hantar Kod Semula',
      AppLanguage.id: 'Kirim Kode Lagi',
    },

    // ── Claim Code screen ───────────────────────────────────────
    'claim_title': {
      AppLanguage.en: 'Redeem a Code',
      AppLanguage.ms: 'Tebus Kod',
      AppLanguage.id: 'Tukar Kode',
    },
    'claim_subtitle': {
      AppLanguage.en: 'Enter the 12-character code given to you by the owner to add credits to your account.',
      AppLanguage.ms: 'Masukkan kod 12-aksara yang diberikan oleh pemilik untuk menambah kredit ke akaun anda.',
      AppLanguage.id: 'Masukkan kode 12-karakter yang diberikan oleh pemilik untuk menambah kredit ke akun Anda.',
    },
    'claim_code_label': {
      AppLanguage.en: 'Credit Code',
      AppLanguage.ms: 'Kod Kredit',
      AppLanguage.id: 'Kode Kredit',
    },
    'claim_redeem_button': {
      AppLanguage.en: 'REDEEM',
      AppLanguage.ms: 'TEBUS',
      AppLanguage.id: 'TUKAR',
    },
    'claim_enter_code': {
      AppLanguage.en: 'Please enter a code.',
      AppLanguage.ms: 'Sila masukkan kod.',
      AppLanguage.id: 'Silakan masukkan kode.',
    },
    'claim_new_balance': {
      AppLanguage.en: 'New balance:',
      AppLanguage.ms: 'Baki baharu:',
      AppLanguage.id: 'Saldo baru:',
    },
    'claim_credits': {
      AppLanguage.en: 'credits',
      AppLanguage.ms: 'kredit',
      AppLanguage.id: 'kredit',
    },

    // ── Ad view screen ──────────────────────────────────────────
    'ad_media_failed': {
      AppLanguage.en: 'The ad media failed to load. No timer was started.',
      AppLanguage.ms: 'Media iklan gagal dimuatkan. Timer tidak dimulakan.',
      AppLanguage.id: 'Media iklan gagal dimuat. Timer tidak dimulai.',
    },
    'ad_no_ads_available': {
      AppLanguage.en: 'No ads available right now. Check back later.',
      AppLanguage.ms: 'Tiada iklan buat masa ini. Sila semak semula nanti.',
      AppLanguage.id: 'Tidak ada iklan saat ini. Silakan cek lagi nanti.',
    },
    'ad_load_failed': {
      AppLanguage.en: 'Could not load ad. Please try again later.',
      AppLanguage.ms: 'Gagal memuatkan iklan. Sila cuba lagi nanti.',
      AppLanguage.id: 'Gagal memuat iklan. Silakan coba lagi nanti.',
    },
    'ad_reward_earned_title': {
      AppLanguage.en: 'Reward Earned!',
      AppLanguage.ms: 'Ganjaran Diterima!',
      AppLanguage.id: 'Hadiah Diterima!',
    },
    'ad_you_earned': {
      AppLanguage.en: 'You earned',
      AppLanguage.ms: 'Anda mendapat',
      AppLanguage.id: 'Anda mendapat',
    },
    'ad_credits': {
      AppLanguage.en: 'credits.',
      AppLanguage.ms: 'kredit.',
      AppLanguage.id: 'kredit.',
    },
    'ad_nice': {
      AppLanguage.en: 'Nice!',
      AppLanguage.ms: 'Bagus!',
      AppLanguage.id: 'Mantap!',
    },
    'ad_claim_failed': {
      AppLanguage.en: 'Could not claim reward.',
      AppLanguage.ms: 'Gagal menuntut ganjaran.',
      AppLanguage.id: 'Gagal mengklaim hadiah.',
    },
    'ad_claim_failed_connection': {
      AppLanguage.en: 'Could not claim reward. Please check your connection.',
      AppLanguage.ms: 'Gagal menuntut ganjaran. Sila semak sambungan anda.',
      AppLanguage.id: 'Gagal mengklaim hadiah. Silakan periksa koneksi Anda.',
    },
    'ad_skip': {
      AppLanguage.en: 'Skip Ad',
      AppLanguage.ms: 'Langkau Iklan',
      AppLanguage.id: 'Lewati Iklan',
    },
    'ad_reward_granted': {
      AppLanguage.en: 'Reward Granted',
      AppLanguage.ms: 'Ganjaran Diberi',
      AppLanguage.id: 'Hadiah Diberikan',
    },
    'ad_skip_confirm_title': {
      AppLanguage.en: 'Skip this ad?',
      AppLanguage.ms: 'Langkau iklan ini?',
      AppLanguage.id: 'Lewati iklan ini?',
    },
    'ad_skip_confirm_body': {
      AppLanguage.en: 'You won\'t get any credits if you skip now.',
      AppLanguage.ms: 'Anda tidak akan dapat sebarang kredit jika langkau sekarang.',
      AppLanguage.id: 'Anda tidak akan mendapat kredit jika melewati sekarang.',
    },
    'ad_keep_watching': {
      AppLanguage.en: 'Keep Watching',
      AppLanguage.ms: 'Terus Tonton',
      AppLanguage.id: 'Lanjutkan Menonton',
    },
    'ad_daily_limit_reached': {
      AppLanguage.en: 'You\'ve watched the max ads for today. Come back tomorrow for more.',
      AppLanguage.ms: 'Anda telah menonton had maksimum iklan untuk hari ini. Sila kembali esok.',
      AppLanguage.id: 'Anda telah menonton batas maksimum iklan hari ini. Silakan kembali besok.',
    },
    'home_ads_left_today': {
      AppLanguage.en: '{n}/{limit} ad views left today.',
      AppLanguage.ms: '{n}/{limit} tontonan iklan berbaki hari ini.',
      AppLanguage.id: '{n}/{limit} tontonan iklan tersisa hari ini.',
    },

    // ── About screen ────────────────────────────────────────────
    'about_title': {
      AppLanguage.en: 'About',
      AppLanguage.ms: 'Tentang',
      AppLanguage.id: 'Tentang',
    },
    'about_this_app': {
      AppLanguage.en: 'About this App',
      AppLanguage.ms: 'Tentang App Ini',
      AppLanguage.id: 'Tentang Aplikasi Ini',
    },
    'about_contact': {
      AppLanguage.en: 'Contact',
      AppLanguage.ms: 'Hubungi',
      AppLanguage.id: 'Kontak',
    },
    'about_owner': {
      AppLanguage.en: 'Owner',
      AppLanguage.ms: 'Pemilik',
      AppLanguage.id: 'Pemilik',
    },
    'about_owner_subtitle': {
      AppLanguage.en: 'Get in touch with the developer',
      AppLanguage.ms: 'Hubungi pembangun aplikasi',
      AppLanguage.id: 'Hubungi pengembang aplikasi',
    },
    'about_channel': {
      AppLanguage.en: 'Channel',
      AppLanguage.ms: 'Saluran',
      AppLanguage.id: 'Kanal',
    },
    'about_channel_subtitle': {
      AppLanguage.en: 'Latest updates and announcements',
      AppLanguage.ms: 'Kemas kini dan pengumuman terkini',
      AppLanguage.id: 'Pembaruan dan pengumuman terbaru',
    },
    'about_language': {
      AppLanguage.en: 'Language',
      AppLanguage.ms: 'Bahasa',
      AppLanguage.id: 'Bahasa',
    },
    'about_language_subtitle': {
      AppLanguage.en: 'Change the app\'s display language',
      AppLanguage.ms: 'Tukar bahasa paparan app',
      AppLanguage.id: 'Ubah bahasa tampilan aplikasi',
    },

    // ── Language select screen ──────────────────────────────────
    'lang_select_title': {
      AppLanguage.en: 'Choose your language',
      AppLanguage.ms: 'Pilih bahasa anda',
      AppLanguage.id: 'Pilih bahasa Anda',
    },
    'lang_select_subtitle': {
      AppLanguage.en: 'You can change this later in Settings.',
      AppLanguage.ms: 'Anda boleh tukar ini kemudian di Tetapan.',
      AppLanguage.id: 'Anda dapat mengubahnya nanti di Pengaturan.',
    },
    'lang_select_continue': {
      AppLanguage.en: 'Continue',
      AppLanguage.ms: 'Teruskan',
      AppLanguage.id: 'Lanjutkan',
    },
    'lang_name_en': {
      AppLanguage.en: 'English',
      AppLanguage.ms: 'English',
      AppLanguage.id: 'English',
    },
    'lang_name_ms': {
      AppLanguage.en: 'Malay',
      AppLanguage.ms: 'Bahasa Melayu',
      AppLanguage.id: 'Bahasa Melayu',
    },
    'lang_name_id': {
      AppLanguage.en: 'Indonesian',
      AppLanguage.ms: 'Bahasa Indonesia',
      AppLanguage.id: 'Bahasa Indonesia',
    },
  };
}
