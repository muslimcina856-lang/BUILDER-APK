# Changelog — Earl Builder (User App)

All notable changes to this project will be documented in this file.

## [1.5.1+7] — 2026-08-12

### Fixed
- Restored missing `.gitignore` files (root, android, ios, linux, macos, windows)
- Corrected version number (was accidentally reset to 1.0.0+1)

### Changed
- About screen now displays the app launcher icon instead of a generic Material icon
- About screen footer updated to copyright notice with privacy policy link

## [1.5.0+6] — 2026-08-01

### Added
- In-app ZIP project detection matching the build worker
- Generic project-link flow for files over 3 MB
- Streamed temporary link validation with guaranteed `.part` cleanup

### Changed
- Files up to 3 MB now use one direct request; chunk sessions were removed
- Release R8 rules are narrower and Gradle/JDK versions are aligned
- Broad Android storage permissions were removed
- Signing secrets are excluded and replaced by a setup template
- Launcher artwork replaced with a dedicated builder emblem, adaptive icon and Android 13 themed layer

## [1.4.0+5] — 2026-07-11 (v11.4c — no auto-play wording)

### Added
- Background music feature: paste streaming URL on Upload screen, music plays on app launch, loops continuously
- Spotify mint accent color (`#34E0A1`) for branding
- Splash screen with mint background and centered rounded square
- Adaptive launcher icon (mint with white "E" mark) + monochrome layer for Android 13+ themed icons
- `POST_NOTIFICATIONS` + `WAKE_LOCK` permissions for background music playback

### Changed
- Renamed `initAutoPlay()` → `playSaved()` in audio service
- Removed all "auto-play" wording from UI text + comments (replaced with "play & loop")
- Background Music card moved from About screen to Upload screen (top of screen, before drop zone)
- About screen cleaned up — no Background Music section

### Fixed
- 4 hidden runtime errors in upload flow (mounted checks, abort flag, null upload_id, _asMap helper)
- Mid-session stream drops now detected via `onPlayerStateChanged` listener ("Stream interrupted" status)

## [1.3.0+4] — 2026-07-10 (v11.3c — auto-loop)

### Added
- Auto-play on app launch if URL saved
- `ReleaseMode.loop` for continuous streaming
- "Last attempt" UI hint when playback fails

## [1.2.0+3] — 2026-07-09 (v11.2 — initial music feature)

### Added
- Background music card with TextField + Play/Stop button
- `AudioService` singleton wrapping audioplayers

## [1.1.0+2] — 2026-07-08 (v11.1 — polish release)

### Changed
- Material 3 dark theme applied across both apps
- Premium typography scale (11-32px)
- English localization throughout

## [1.0.0+1] — 2026-07-07 (v11.0 — initial release)

### Added
- Project ZIP upload with chunked transfer (512 KB chunks)
- Build queue via Vercel API
- Telegram bot binding for build notifications
- Credit system with redeem codes
