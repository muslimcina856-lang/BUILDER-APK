import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:earl_builder/config.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/services/language_service.dart';
import 'package:earl_builder/theme/app_theme.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _pickLanguage(BuildContext context) async {
    final languageService = context.read<LanguageService>();
    final current = languageService.language ?? AppLanguage.en;

    final picked = await showModalBottomSheet<AppLanguage>(
      context: context,
      backgroundColor: AppColors.bgRaised,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadius.card)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppSpacing.lg),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final lang in AppLanguage.values)
                  ListTile(
                    title: Text(
                      AppStrings.of(current, 'lang_name_${lang.name}'),
                      style: AppText.body,
                    ),
                    trailing: lang == current
                        ? const Icon(Icons.check_rounded, color: AppColors.accent)
                        : null,
                    onTap: () => Navigator.pop(ctx, lang),
                  ),
              ],
            ),
          ),
        );
      },
    );

    if (picked != null) {
      await languageService.setLanguage(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'about_title'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xxxl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.hero),
                child: Image.asset(
                  'ic_launcher-playstore.png',
                  width: 64,
                  height: 64,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Center(
              child: Text(tr(context, 'app_name'), style: AppText.title),
            ),
            const SizedBox(height: AppSpacing.xs),
            Center(
              child: Text(AppConfig.appTagline, style: AppText.subtitle),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            Text(tr(context, 'about_this_app'), style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.md),
            Text(
              AppConfig.aboutDescription,
              style: AppText.body.copyWith(
                color: AppColors.textSecondary,
                height: 1.6,
              ),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            Text(tr(context, 'about_contact'), style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.md),
            _LinkTile(
              icon: Icons.person_rounded,
              label: tr(context, 'about_owner'),
              subtitle: tr(context, 'about_owner_subtitle'),
              onTap: () => _openLink(AppConfig.ownerLink),
            ),
            const SizedBox(height: AppSpacing.sm),
            _LinkTile(
              icon: Icons.campaign_rounded,
              label: tr(context, 'about_channel'),
              subtitle: tr(context, 'about_channel_subtitle'),
              onTap: () => _openLink(AppConfig.channelLink),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            const Text('SETTINGS', style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.md),
            _LinkTile(
              icon: Icons.language_rounded,
              label: tr(context, 'about_language'),
              subtitle: tr(context, 'about_language_subtitle'),
              onTap: () => _pickLanguage(context),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            Center(
              child: GestureDetector(
                onTap: () => _openLink('https://app.earlstore.online/privacy'),
                child: Text(
                  '© 2026 Earlxz. All rights reserved.',
                  style: AppText.caption.copyWith(color: AppColors.textDisabled),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LinkTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _LinkTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Row(
            children: [
              Icon(icon, size: AppIcons.lg, color: AppColors.textPrimary),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: AppText.heading.copyWith(fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: AppText.subtitle),
                  ],
                ),
              ),
              const Icon(
                Icons.open_in_new_rounded,
                size: AppIcons.sm,
                color: AppColors.textMuted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
