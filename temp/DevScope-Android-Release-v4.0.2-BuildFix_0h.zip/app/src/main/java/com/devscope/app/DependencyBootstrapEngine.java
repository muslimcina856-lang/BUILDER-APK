package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Builds reproducible dependency bootstrap files for CodeProjectGenerator projects.
 * The Android app does not pretend to install desktop toolchains locally. Instead,
 * every exported project receives executable setup/verify scripts that install the
 * project's real language modules in the target environment and fail loudly when
 * the required external toolchain is unavailable.
 */
public final class DependencyBootstrapEngine {
    private DependencyBootstrapEngine() {}

    public static final class Plan {
        public final String target;
        public final String engine;
        public final String runtime;
        public final List<String> requiredTools;
        public final List<String> manifests;
        public final String installCommand;
        public final String verifyCommand;
        public final boolean externalToolchainRequired;
        public final LinkedHashMap<String, String> bootstrapFiles;

        Plan(String target, String engine, String runtime, List<String> requiredTools,
             List<String> manifests, String installCommand, String verifyCommand,
             boolean externalToolchainRequired, LinkedHashMap<String, String> bootstrapFiles) {
            this.target = target;
            this.engine = engine;
            this.runtime = runtime;
            this.requiredTools = requiredTools;
            this.manifests = manifests;
            this.installCommand = installCommand;
            this.verifyCommand = verifyCommand;
            this.externalToolchainRequired = externalToolchainRequired;
            this.bootstrapFiles = bootstrapFiles;
        }
    }

    public static Plan attach(CodeProjectGenerator.GeneratedProject project) throws Exception {
        if (project == null) throw new IllegalArgumentException("Generated project is required");
        Plan plan = create(project);
        for (Map.Entry<String, String> e : plan.bootstrapFiles.entrySet()) {
            project.files.put(e.getKey(), e.getValue());
        }
        return plan;
    }

    public static Plan create(CodeProjectGenerator.GeneratedProject project) throws Exception {
        String target = project.target;
        String runtime = runtimeName(target);
        List<String> tools = requiredTools(target);
        List<String> manifests = manifests(project);
        String install = installCommand(target);
        String verify = verifyCommand(target);

        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("devscope/setup.sh", setupSh(target, tools));
        files.put("devscope/verify.sh", verifySh(target));
        files.put("devscope/repair.sh", repairSh(target));
        files.put("devscope/install-toolchain.sh", installToolchainSh(target));
        files.put("devscope/setup.ps1", setupPs1(target, tools));
        files.put("devscope/verify.ps1", verifyPs1(target));
        files.put("devscope/repair.ps1", repairPs1(target));
        files.put("devscope/install-toolchain.ps1", installToolchainPs1(target));
        files.put("devscope/env.example", envExample(project));
        files.put("devscope/bootstrap.json", bootstrapJson(project, runtime, tools, manifests, install, verify).toString(2));
        files.put("devscope/DEPENDENCIES.md", dependenciesReadme(project, runtime, tools, manifests, install, verify));

        return new Plan(target, project.engine, runtime, tools, manifests, install, verify, true, files);
    }

    public static String renderReport(Plan plan, CodeProjectGenerator.GeneratedProject project) {
        StringBuilder b = new StringBuilder();
        b.append("DEPENDENCY BOOTSTRAP // REAL PROJECT\n\n");
        b.append("target             ").append(plan.target).append('\n');
        b.append("engine             ").append(plan.engine).append('\n');
        b.append("runtime/toolchain  ").append(plan.runtime).append('\n');
        b.append("execution          EXTERNAL TOOLCHAIN REQUIRED\n");
        b.append("android behavior   generate + verify bundle metadata; no fake local install\n\n");
        b.append("REQUIRED TOOLS\n");
        for (String t : plan.requiredTools) b.append("  + ").append(t).append('\n');
        b.append("\nMANIFESTS\n");
        if (plan.manifests.isEmpty()) b.append("  none\n");
        else for (String m : plan.manifests) b.append("  + ").append(m).append('\n');
        b.append("\nAUTO MODULE INSTALL\n  ").append(plan.installCommand).append('\n');
        b.append("\nVERIFY / COMPILE\n  ").append(plan.verifyCommand).append('\n');
        b.append("\nBOOTSTRAP FILES\n");
        for (String name : plan.bootstrapFiles.keySet()) b.append("  + ").append(name).append('\n');
        b.append("\nONE COMMAND\n");
        b.append("  Linux/macOS/Termux:  DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1 sh devscope/setup.sh\n");
        b.append("  Windows PowerShell:   $env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN='1'; ./devscope/setup.ps1\n");
        b.append("\nPROJECT FILES          ").append(project.files.size()).append('\n');
        b.append("BOOTSTRAP FILES        ").append(plan.bootstrapFiles.size()).append('\n');
        b.append("\nNOTE\n");
        b.append("The setup scripts install language modules using the target package manager.\n");
        b.append("repair.sh/repair.ps1 can clear broken build/module state and rerun setup + verification.\n");
        b.append("If the runtime/compiler is missing they can invoke the generated toolchain installer\n");
        b.append("when DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1. Unsupported host/package-manager paths fail\n");
        b.append("with a real error instead of reporting a fake READY state.\n");
        return b.toString();
    }

    public static void verifyBundle(CodeProjectGenerator.GeneratedProject project, Plan plan) throws Exception {
        if (project == null || plan == null) throw new IllegalArgumentException("Generate a project first");
        for (String file : plan.manifests) {
            if (!project.files.containsKey(file)) throw new IllegalStateException("Missing dependency manifest: " + file);
            String text = project.files.get(file);
            if (text == null || text.trim().isEmpty()) throw new IllegalStateException("Empty dependency manifest: " + file);
        }
        for (String file : plan.bootstrapFiles.keySet()) {
            if (!project.files.containsKey(file)) throw new IllegalStateException("Missing bootstrap file: " + file);
            String text = project.files.get(file);
            if (text == null || text.trim().isEmpty()) throw new IllegalStateException("Empty bootstrap file: " + file);
        }
        if (!project.files.containsKey(project.mainFile)) throw new IllegalStateException("Missing main source: " + project.mainFile);
        if (!project.files.containsKey("flow.json")) throw new IllegalStateException("Missing flow.json");
    }

    private static List<String> manifests(CodeProjectGenerator.GeneratedProject project) {
        String[] candidates = {"requirements.txt", "package.json", "pom.xml", "build.gradle.kts", "DevScopeGenerated.csproj", "go.mod", "CMakeLists.txt", "Cargo.toml", "Gemfile", "composer.json"};
        ArrayList<String> out = new ArrayList<>();
        for (String c : candidates) if (project.files.containsKey(c)) out.add(c);
        return out;
    }

    private static String runtimeName(String target) {
        if (CodeProjectGenerator.PYTHON.equals(target)) return "Python 3 + pip";
        if (CodeProjectGenerator.JAVASCRIPT.equals(target) || CodeProjectGenerator.TYPESCRIPT.equals(target)) return "Node.js + npm";
        if (CodeProjectGenerator.JAVA.equals(target)) return "JDK 17+ + Maven";
        if (CodeProjectGenerator.KOTLIN.equals(target)) return "JDK 17+ + Gradle";
        if (CodeProjectGenerator.CSHARP.equals(target)) return ".NET SDK";
        if (CodeProjectGenerator.GO.equals(target)) return "Go toolchain";
        if (CodeProjectGenerator.C.equals(target)) return "C compiler + CMake + libcurl";
        if (CodeProjectGenerator.CPP.equals(target)) return "C++17 compiler + CMake + libcurl";
        if (CodeProjectGenerator.RUST.equals(target)) return "Rust + Cargo";
        if (CodeProjectGenerator.RUBY.equals(target)) return "Ruby + Bundler";
        if (CodeProjectGenerator.PHP.equals(target)) return "PHP + Composer";
        return "external toolchain";
    }

    private static List<String> requiredTools(String target) {
        ArrayList<String> out = new ArrayList<>();
        if (CodeProjectGenerator.PYTHON.equals(target)) { out.add("python3|python"); out.add("pip"); }
        else if (CodeProjectGenerator.JAVASCRIPT.equals(target) || CodeProjectGenerator.TYPESCRIPT.equals(target)) { out.add("node"); out.add("npm"); }
        else if (CodeProjectGenerator.JAVA.equals(target)) { out.add("java"); out.add("mvn"); }
        else if (CodeProjectGenerator.KOTLIN.equals(target)) { out.add("java"); out.add("gradle"); }
        else if (CodeProjectGenerator.CSHARP.equals(target)) out.add("dotnet");
        else if (CodeProjectGenerator.GO.equals(target)) out.add("go");
        else if (CodeProjectGenerator.C.equals(target)) { out.add("cc|clang|gcc"); out.add("cmake"); out.add("libcurl development package"); }
        else if (CodeProjectGenerator.CPP.equals(target)) { out.add("c++|clang++|g++"); out.add("cmake"); out.add("libcurl development package"); }
        else if (CodeProjectGenerator.RUST.equals(target)) { out.add("rustc"); out.add("cargo"); }
        else if (CodeProjectGenerator.RUBY.equals(target)) { out.add("ruby"); out.add("bundle"); }
        else if (CodeProjectGenerator.PHP.equals(target)) { out.add("php"); out.add("composer"); }
        out.add("Chrome/Chromium + compatible WebDriver where required by generated engine");
        return out;
    }

    private static String installCommand(String target) {
        if (CodeProjectGenerator.PYTHON.equals(target)) return "python -m pip install -r requirements.txt";
        if (CodeProjectGenerator.JAVASCRIPT.equals(target) || CodeProjectGenerator.TYPESCRIPT.equals(target)) return "npm install";
        if (CodeProjectGenerator.JAVA.equals(target)) return "mvn -DskipTests dependency:go-offline";
        if (CodeProjectGenerator.KOTLIN.equals(target)) return "gradle --no-daemon dependencies";
        if (CodeProjectGenerator.CSHARP.equals(target)) return "dotnet restore";
        if (CodeProjectGenerator.GO.equals(target)) return "go mod download && go mod verify";
        if (CodeProjectGenerator.C.equals(target) || CodeProjectGenerator.CPP.equals(target)) return "cmake -S . -B build && cmake --build build";
        if (CodeProjectGenerator.RUST.equals(target)) return "cargo fetch";
        if (CodeProjectGenerator.RUBY.equals(target)) return "bundle install";
        if (CodeProjectGenerator.PHP.equals(target)) return "composer install --no-interaction";
        return "unsupported target";
    }

    private static String verifyCommand(String target) {
        if (CodeProjectGenerator.PYTHON.equals(target)) return "python -m py_compile main.py && python -c \"import selenium\"";
        if (CodeProjectGenerator.JAVASCRIPT.equals(target)) return "node --check main.js && node -e \"require.resolve('selenium-webdriver')\"";
        if (CodeProjectGenerator.TYPESCRIPT.equals(target)) return "npx tsc --noEmit";
        if (CodeProjectGenerator.JAVA.equals(target)) return "mvn -DskipTests package";
        if (CodeProjectGenerator.KOTLIN.equals(target)) return "gradle --no-daemon compileKotlin";
        if (CodeProjectGenerator.CSHARP.equals(target)) return "dotnet build --no-restore";
        if (CodeProjectGenerator.GO.equals(target)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(target) || CodeProjectGenerator.CPP.equals(target)) return "cmake --build build";
        if (CodeProjectGenerator.RUST.equals(target)) return "cargo build";
        if (CodeProjectGenerator.RUBY.equals(target)) return "ruby -c main.rb && bundle check";
        if (CodeProjectGenerator.PHP.equals(target)) return "php -l main.php && composer validate --no-check-publish";
        return "unsupported target";
    }

    private static String setupSh(String target, List<String> tools) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" +
                "echo '[DevScope] target: " + sh(target) + "'\n" +
                shellToolCheck(target) +
                "if [ \"${DEVSCOPE_AUTO_INSTALL_TOOLCHAIN:-0}\" = \"1\" ] && [ \"${DEVSCOPE_TOOLCHAIN_MISSING:-0}\" = \"1\" ]; then\n  sh devscope/install-toolchain.sh\nfi\n" +
                shellFinalToolCheck(target) +
                shellInstall(target) +
                "echo '[DevScope] module installation complete'\nsh devscope/verify.sh\n";
    }

    private static String verifySh(String target) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" + shellVerify(target) + "\necho '[DevScope] verification complete'\n";
    }


    private static String repairSh(String target) {
        return "#!/usr/bin/env sh\nset -eu\nROOT=$(CDPATH= cd -- \"$(dirname -- \"$0\")/..\" && pwd)\ncd \"$ROOT\"\n" + shellRepair(target) + "\nsh devscope/setup.sh\n";
    }

    private static String installToolchainSh(String target) {
        String apt = aptPackages(target), brew = brewPackages(target), pkg = termuxPackages(target);
        return "#!/usr/bin/env sh\nset -eu\n" +
                "echo '[DevScope] attempting host toolchain install for " + sh(target) + "'\n" +
                "if command -v pkg >/dev/null 2>&1; then pkg update -y; pkg install -y " + pkg + "; exit 0; fi\n" +
                "if command -v apt-get >/dev/null 2>&1; then SUDO=''; if [ \"$(id -u)\" != 0 ]; then command -v sudo >/dev/null 2>&1 || { echo 'sudo/root required for apt'; exit 31; }; SUDO=sudo; fi; $SUDO apt-get update; $SUDO apt-get install -y " + apt + "; exit 0; fi\n" +
                "if command -v brew >/dev/null 2>&1; then brew install " + brew + "; exit 0; fi\n" +
                "echo 'No supported package manager found (Termux pkg, apt-get, Homebrew).' >&2\nexit 32\n";
    }

    private static String setupPs1(String target, List<String> tools) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" +
                "Write-Host '[DevScope] target: " + ps(target) + "'\n" +
                powerShellToolCheck(target) +
                "if ($env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN -eq '1' -and $script:MissingToolchain) { & (Join-Path $PSScriptRoot 'install-toolchain.ps1') }\n" +
                powerShellFinalToolCheck(target) +
                powerShellInstall(target) +
                "Write-Host '[DevScope] module installation complete'\n& (Join-Path $PSScriptRoot 'verify.ps1')\n";
    }

    private static String verifyPs1(String target) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" + powerShellVerify(target) + "\nWrite-Host '[DevScope] verification complete'\n";
    }


    private static String repairPs1(String target) {
        return "$ErrorActionPreference='Stop'\n$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path\nSet-Location $Root\n" + powerShellRepair(target) + "\n& (Join-Path $PSScriptRoot 'setup.ps1')\n";
    }

    private static String installToolchainPs1(String target) {
        String winget = wingetId(target);
        return "$ErrorActionPreference='Stop'\n" +
                "if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'winget not available; install the required toolchain manually.' }\n" +
                (winget.isEmpty()
                        ? "throw 'Automatic Windows toolchain install is not safely defined for this target. Install the compiler/runtime manually, then rerun setup.ps1.'\n"
                        : "winget install --id " + winget + " --exact --accept-package-agreements --accept-source-agreements\n") ;
    }

    private static String shellToolCheck(String t) {
        String check = shellCheckExpr(t);
        return "DEVSCOPE_TOOLCHAIN_MISSING=0\nif ! (" + check + "); then DEVSCOPE_TOOLCHAIN_MISSING=1; export DEVSCOPE_TOOLCHAIN_MISSING; echo '[DevScope] toolchain missing'; fi\n";
    }

    private static String shellFinalToolCheck(String t) {
        return "if ! (" + shellCheckExpr(t) + "); then echo '[DevScope] required toolchain still unavailable' >&2; exit 33; fi\n";
    }

    private static String shellCheckExpr(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1";
        if (CodeProjectGenerator.JAVA.equals(t)) return "command -v java >/dev/null 2>&1 && command -v mvn >/dev/null 2>&1";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "command -v java >/dev/null 2>&1 && command -v gradle >/dev/null 2>&1";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "command -v dotnet >/dev/null 2>&1";
        if (CodeProjectGenerator.GO.equals(t)) return "command -v go >/dev/null 2>&1";
        if (CodeProjectGenerator.C.equals(t)) return "(command -v cc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1 || command -v gcc >/dev/null 2>&1) && command -v cmake >/dev/null 2>&1";
        if (CodeProjectGenerator.CPP.equals(t)) return "(command -v c++ >/dev/null 2>&1 || command -v clang++ >/dev/null 2>&1 || command -v g++ >/dev/null 2>&1) && command -v cmake >/dev/null 2>&1";
        if (CodeProjectGenerator.RUST.equals(t)) return "command -v rustc >/dev/null 2>&1 && command -v cargo >/dev/null 2>&1";
        if (CodeProjectGenerator.RUBY.equals(t)) return "command -v ruby >/dev/null 2>&1 && command -v bundle >/dev/null 2>&1";
        if (CodeProjectGenerator.PHP.equals(t)) return "command -v php >/dev/null 2>&1 && command -v composer >/dev/null 2>&1";
        return "false";
    }

    private static String shellInstall(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "PY=$(command -v python3 || command -v python)\n\"$PY\" -m pip install --upgrade pip\n\"$PY\" -m pip install -r requirements.txt\n\"$PY\" -m pip freeze > devscope/requirements.lock.txt\n";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "npm install\nnpm ls --all > devscope/npm-tree.txt || true\n";
        if (CodeProjectGenerator.JAVA.equals(t)) return "mvn -q -DskipTests dependency:go-offline\nmvn -q dependency:tree -DoutputFile=devscope/maven-dependency-tree.txt\n";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "gradle --no-daemon dependencies > devscope/gradle-dependency-tree.txt\n";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet restore\n";
        if (CodeProjectGenerator.GO.equals(t)) return "go mod download\ngo mod tidy\ngo mod verify\n";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake -S . -B build\ncmake --build build\n{ cmake --version; (cc --version 2>/dev/null || c++ --version 2>/dev/null || clang --version 2>/dev/null || true); (curl-config --version 2>/dev/null || true); } > devscope/toolchain-lock.txt\n";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo fetch\ncargo generate-lockfile\n";
        if (CodeProjectGenerator.RUBY.equals(t)) return "bundle install\nbundle lock\n";
        if (CodeProjectGenerator.PHP.equals(t)) return "composer install --no-interaction --prefer-dist\n";
        return "echo 'unsupported target' >&2; exit 34\n";
    }

    private static String shellVerify(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "PY=$(command -v python3 || command -v python)\n\"$PY\" -m py_compile main.py\n\"$PY\" -c 'import selenium; print(selenium.__version__)'";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t)) return "node --check main.js\nnode -e \"require.resolve('selenium-webdriver'); console.log('selenium-webdriver ok')\"";
        if (CodeProjectGenerator.TYPESCRIPT.equals(t)) return "npx tsc --noEmit";
        if (CodeProjectGenerator.JAVA.equals(t)) return "mvn -q -DskipTests package";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "gradle --no-daemon compileKotlin";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet build --no-restore";
        if (CodeProjectGenerator.GO.equals(t)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake --build build";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo build";
        if (CodeProjectGenerator.RUBY.equals(t)) return "ruby -c main.rb\nbundle check";
        if (CodeProjectGenerator.PHP.equals(t)) return "php -l main.php\ncomposer validate --no-check-publish";
        return "exit 35";
    }

    private static String powerShellToolCheck(String t) {
        return "$script:MissingToolchain = -not (" + psCheckExpr(t) + ")\nif ($script:MissingToolchain) { Write-Warning '[DevScope] toolchain missing' }\n";
    }

    private static String powerShellFinalToolCheck(String t) {
        return "if (-not (" + psCheckExpr(t) + ")) { throw '[DevScope] required toolchain still unavailable' }\n";
    }

    private static String psCheckExpr(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "(Get-Command python -ErrorAction SilentlyContinue) -or (Get-Command py -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "(Get-Command node -ErrorAction SilentlyContinue) -and (Get-Command npm -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.JAVA.equals(t)) return "(Get-Command java -ErrorAction SilentlyContinue) -and (Get-Command mvn -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "(Get-Command java -ErrorAction SilentlyContinue) -and (Get-Command gradle -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "Get-Command dotnet -ErrorAction SilentlyContinue";
        if (CodeProjectGenerator.GO.equals(t)) return "Get-Command go -ErrorAction SilentlyContinue";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "Get-Command cmake -ErrorAction SilentlyContinue";
        if (CodeProjectGenerator.RUST.equals(t)) return "(Get-Command rustc -ErrorAction SilentlyContinue) -and (Get-Command cargo -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.RUBY.equals(t)) return "(Get-Command ruby -ErrorAction SilentlyContinue) -and (Get-Command bundle -ErrorAction SilentlyContinue)";
        if (CodeProjectGenerator.PHP.equals(t)) return "(Get-Command php -ErrorAction SilentlyContinue) -and (Get-Command composer -ErrorAction SilentlyContinue)";
        return "$false";
    }

    private static String powerShellInstall(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m pip install --upgrade pip\n& $Py -m pip install -r requirements.txt\n& $Py -m pip freeze | Set-Content devscope/requirements.lock.txt\n";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "npm install\nnpm ls --all | Set-Content devscope/npm-tree.txt\n";
        if (CodeProjectGenerator.JAVA.equals(t)) return "mvn -q -DskipTests dependency:go-offline\nmvn -q dependency:tree '-DoutputFile=devscope/maven-dependency-tree.txt'\n";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "gradle --no-daemon dependencies | Set-Content devscope/gradle-dependency-tree.txt\n";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet restore\n";
        if (CodeProjectGenerator.GO.equals(t)) return "go mod download\ngo mod tidy\ngo mod verify\n";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake -S . -B build\ncmake --build build\ncmake --version | Set-Content devscope/toolchain-lock.txt\n";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo fetch\ncargo generate-lockfile\n";
        if (CodeProjectGenerator.RUBY.equals(t)) return "bundle install\nbundle lock\n";
        if (CodeProjectGenerator.PHP.equals(t)) return "composer install --no-interaction --prefer-dist\n";
        return "throw 'unsupported target'\n";
    }

    private static String powerShellVerify(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m py_compile main.py\n& $Py -c \"import selenium; print(selenium.__version__)\"";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t)) return "node --check main.js\nnode -e \"require.resolve('selenium-webdriver'); console.log('selenium-webdriver ok')\"";
        if (CodeProjectGenerator.TYPESCRIPT.equals(t)) return "npx tsc --noEmit";
        if (CodeProjectGenerator.JAVA.equals(t)) return "mvn -q -DskipTests package";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "gradle --no-daemon compileKotlin";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet build --no-restore";
        if (CodeProjectGenerator.GO.equals(t)) return "go build ./...";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake --build build";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo build";
        if (CodeProjectGenerator.RUBY.equals(t)) return "ruby -c main.rb\nbundle check";
        if (CodeProjectGenerator.PHP.equals(t)) return "php -l main.php\ncomposer validate --no-check-publish";
        return "throw 'unsupported target'";
    }


    private static String shellRepair(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "PY=$(command -v python3 || command -v python || true)\n[ -n \"$PY\" ] && \"$PY\" -m pip install --force-reinstall -r requirements.txt || true";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "rm -rf node_modules";
        if (CodeProjectGenerator.JAVA.equals(t)) return "rm -rf target ~/.m2/repository/org/seleniumhq/selenium 2>/dev/null || true";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "rm -rf build .gradle 2>/dev/null || true";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "rm -rf bin obj 2>/dev/null || true";
        if (CodeProjectGenerator.GO.equals(t)) return "go clean -cache 2>/dev/null || true";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "rm -rf build";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo clean 2>/dev/null || true";
        if (CodeProjectGenerator.RUBY.equals(t)) return "bundle clean --force 2>/dev/null || true";
        if (CodeProjectGenerator.PHP.equals(t)) return "composer clear-cache 2>/dev/null || true";
        return "true";
    }

    private static String powerShellRepair(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "$Py = if (Get-Command python -ErrorAction SilentlyContinue) {'python'} else {'py'}\n& $Py -m pip install --force-reinstall -r requirements.txt";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "if (Test-Path node_modules) { Remove-Item node_modules -Recurse -Force }";
        if (CodeProjectGenerator.JAVA.equals(t)) return "if (Test-Path target) { Remove-Item target -Recurse -Force }";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "if (Test-Path build) { Remove-Item build -Recurse -Force }; if (Test-Path .gradle) { Remove-Item .gradle -Recurse -Force }";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "foreach ($d in @('bin','obj')) { if (Test-Path $d) { Remove-Item $d -Recurse -Force } }";
        if (CodeProjectGenerator.GO.equals(t)) return "go clean -cache";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "if (Test-Path build) { Remove-Item build -Recurse -Force }";
        if (CodeProjectGenerator.RUST.equals(t)) return "cargo clean";
        if (CodeProjectGenerator.RUBY.equals(t)) return "bundle clean --force";
        if (CodeProjectGenerator.PHP.equals(t)) return "composer clear-cache";
        return "Write-Host 'nothing to repair'";
    }

    private static String aptPackages(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "python3 python3-pip";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "nodejs npm";
        if (CodeProjectGenerator.JAVA.equals(t)) return "openjdk-17-jdk maven";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "openjdk-17-jdk gradle";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet-sdk-8.0";
        if (CodeProjectGenerator.GO.equals(t)) return "golang-go";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "build-essential cmake libcurl4-openssl-dev";
        if (CodeProjectGenerator.RUST.equals(t)) return "rustc cargo";
        if (CodeProjectGenerator.RUBY.equals(t)) return "ruby ruby-dev bundler";
        if (CodeProjectGenerator.PHP.equals(t)) return "php-cli composer";
        return "";
    }

    private static String brewPackages(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "python";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "node";
        if (CodeProjectGenerator.JAVA.equals(t)) return "openjdk@17 maven";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "openjdk@17 gradle";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet";
        if (CodeProjectGenerator.GO.equals(t)) return "go";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "cmake curl";
        if (CodeProjectGenerator.RUST.equals(t)) return "rustup-init";
        if (CodeProjectGenerator.RUBY.equals(t)) return "ruby";
        if (CodeProjectGenerator.PHP.equals(t)) return "php composer";
        return "";
    }

    private static String termuxPackages(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "python";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "nodejs";
        if (CodeProjectGenerator.JAVA.equals(t)) return "openjdk-17 maven";
        if (CodeProjectGenerator.KOTLIN.equals(t)) return "openjdk-17 gradle";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "dotnet-sdk-8.0";
        if (CodeProjectGenerator.GO.equals(t)) return "golang";
        if (CodeProjectGenerator.C.equals(t) || CodeProjectGenerator.CPP.equals(t)) return "clang cmake libcurl";
        if (CodeProjectGenerator.RUST.equals(t)) return "rust";
        if (CodeProjectGenerator.RUBY.equals(t)) return "ruby";
        if (CodeProjectGenerator.PHP.equals(t)) return "php composer";
        return "";
    }

    private static String wingetId(String t) {
        if (CodeProjectGenerator.PYTHON.equals(t)) return "Python.Python.3.12";
        if (CodeProjectGenerator.JAVASCRIPT.equals(t) || CodeProjectGenerator.TYPESCRIPT.equals(t)) return "OpenJS.NodeJS.LTS";
        if (CodeProjectGenerator.JAVA.equals(t)) return "EclipseAdoptium.Temurin.17.JDK";
        if (CodeProjectGenerator.CSHARP.equals(t)) return "Microsoft.DotNet.SDK.8";
        if (CodeProjectGenerator.GO.equals(t)) return "GoLang.Go";
        if (CodeProjectGenerator.RUST.equals(t)) return "Rustlang.Rustup";
        if (CodeProjectGenerator.PHP.equals(t)) return "PHP.PHP";
        return "";
    }

    private static JSONObject bootstrapJson(CodeProjectGenerator.GeneratedProject p, String runtime, List<String> tools,
                                            List<String> manifests, String install, String verify) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "devscope-bootstrap-v1");
        root.put("target", p.target);
        root.put("engine", p.engine);
        root.put("runtime", runtime);
        root.put("externalToolchainRequired", true);
        root.put("requiredTools", new JSONArray(tools));
        root.put("manifests", new JSONArray(manifests));
        root.put("installCommand", install);
        root.put("verifyCommand", verify);
        root.put("autoInstallToolchainFlag", "DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1");
        root.put("generatedBy", "DevScope Android 4.0.2");
        return root;
    }

    private static String dependenciesReadme(CodeProjectGenerator.GeneratedProject p, String runtime, List<String> tools,
                                             List<String> manifests, String install, String verify) {
        StringBuilder b = new StringBuilder();
        b.append("# DevScope Dependency Bootstrap\n\n");
        b.append("Target: **").append(p.target).append("**  \nEngine: **").append(p.engine).append("**  \nRuntime: **").append(runtime).append("**\n\n");
        b.append("## One-command setup\n\n```sh\nDEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1 sh devscope/setup.sh\n```\n\n");
        b.append("Windows PowerShell:\n\n```powershell\n$env:DEVSCOPE_AUTO_INSTALL_TOOLCHAIN='1'\n./devscope/setup.ps1\n```\n\n");
        b.append("The setup script installs project modules with the real package manager and then executes the verify script. If a compiler/runtime is missing, the optional generated toolchain installer is invoked. Unsupported host setups fail explicitly.\n\n");
        b.append("## Required tools\n\n");
        for (String t : tools) b.append("- ").append(t).append('\n');
        b.append("\n## Dependency manifests\n\n");
        for (String m : manifests) b.append("- `").append(m).append("`\n");
        b.append("\nInstall: `").append(install).append("`  \nVerify: `").append(verify).append("`\n\n");
        b.append("## Android note\n\nDevScope is an Android application. It generates and validates these bootstrap files but does not claim that standard Android contains Python, Node, Go, Rust, .NET, desktop WebDriver, or C/C++ toolchains. Run the exported setup script in the target host/toolchain (including Termux where supported).\n");
        return b.toString();
    }

    private static String envExample(CodeProjectGenerator.GeneratedProject p) {
        StringBuilder out = new StringBuilder("# Copy to your preferred secret manager or shell environment.\n# Recorder secrets are never embedded in generated source.\n");
        try {
            JSONObject flow = new JSONObject(p.files.get("flow.json"));
            JSONArray steps = flow.optJSONArray("steps");
            if (steps != null) {
                for (int i = 0; i < steps.length(); i++) {
                    JSONObject s = steps.optJSONObject(i);
                    if (s == null) continue;
                    if (s.optBoolean("secret", false)) out.append("DEVSCOPE_SECRET_").append(i + 1).append("=\n");
                    if ("fileInput".equals(s.optString("type"))) out.append("DEVSCOPE_FILE_").append(i + 1).append("=\n");
                }
            }
        } catch (Exception ignored) {}
        out.append("WEBDRIVER_URL=http://127.0.0.1:9515\n");
        return out.toString();
    }

    private static String sh(String s) { return s.replace("'", "'\\''"); }
    private static String ps(String s) { return s.replace("'", "''"); }
}
