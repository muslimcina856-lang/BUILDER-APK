# DevScope Android 4.0

DevScope is an **Android-native** WebView runtime laboratory for experienced developers. Version 4.0 keeps the real WebView inspection/automation and multi-language CODEGEN stack, then adds a real **Dependency Bootstrap Engine**: generated projects include setup, toolchain-install, repair, verify, environment and bootstrap metadata files for their target language.

There is no demo website, seeded telemetry, fake network response, fake automation step, fake code-generator output, or placeholder export action in the runtime UI. Runtime data comes from the current WebView session and user actions. Code generation is deterministic from the current Action Script.

## Android-only application

The application itself remains Android Native (`com.devscope.app`). Python/Go/C/C++/C#/JavaScript/etc. are **generated source targets**, not alternate app implementations. DevScope performs recording, inspection, editing and project generation on Android; exported source projects can then be built/run with their real external toolchains.

## Core modules

- **TRACE** — navigation, request, service-worker request, console, HTTP/TLS errors and automation/codegen events.
- **DOM** — live rendered DOM tree and tap-to-pick element inspector.
- **NETWORK** — real `WebResourceRequest` metadata plus page `PerformanceResourceTiming`.
- **CONSOLE** — JavaScript console messages with source and line.
- **STORAGE** — current origin cookies, localStorage and sessionStorage.
- **SOURCE** — rendered DOM outerHTML, MHTML export, viewport PNG capture and Android print/PDF.
- **RUNTIME** — JavaScript evaluator inside the currently loaded page.
- **AUTOMATE** — real interaction recorder -> editable Action Script -> Android replay runner.
- **CODEGEN** — generate editable source code and complete language project ZIPs from the Action Script.
- **DEPS** — attach real setup/toolchain-install/repair/verify scripts and dependency metadata to generated projects.
- **DOWNLOADS** — real Android `DownloadManager` queue/history with session cookies and User-Agent.

## AUTOMATE

Press **REC** and use the live WebView. DevScope records real clicks, input/change, select, checkbox/radio, contenteditable changes, submit, scroll, navigation toolbar actions and Runtime JavaScript into an editable JSON Action Script.

Passwords are recorded as `secret:true` without storing the password value. File inputs remain explicit file steps. The Android runner stops with an error if a required secret/file/selector is unavailable; it does not mark a failed step as successful.

Supported native Android replay actions include navigation, interaction, waits, assertions, extraction, DOM editing, storage, cookies, User-Agent, JavaScript, dispatch and Android downloads.

## CODEGEN — one recording, many real source targets

The CODEGEN tab consumes the current Action Script and can generate:

1. **Python / Selenium** — `main.py`, `requirements.txt`
2. **JavaScript / Selenium** — `main.js`, `package.json`
3. **TypeScript / Selenium** — `main.ts`, `package.json`, `tsconfig.json`
4. **Java / Selenium** — Maven project with `pom.xml`
5. **Kotlin / Selenium** — Gradle Kotlin/JVM project
6. **C# (C+) / Selenium** — `.csproj` + `Program.cs`
7. **Go / chromedp** — `go.mod` + `main.go`
8. **C / W3C WebDriver** — `main.c` + `CMakeLists.txt`, using libcurl against a real WebDriver endpoint
9. **C++ / W3C WebDriver** — `main.cpp` + `CMakeLists.txt`, using libcurl against a real WebDriver endpoint
10. **Rust / thirtyfour** — Cargo project
11. **Ruby / Selenium** — `Gemfile` + `main.rb`
12. **PHP / php-webdriver** — `composer.json` + `main.php`

Every generated project also contains:

- `flow.json` — canonical DevScope recording used to generate the source
- `README.md` — target/prerequisite notes and security behavior
- the target's real dependency/build metadata

### Real compatibility validation

CODEGEN validates the recorded action types before generating a target. If a target cannot faithfully represent an action, generation is blocked and the incompatible action is shown. Example: the low-level C target intentionally rejects extracted-variable flows, secret input, file upload and polling actions it cannot faithfully implement in the generated C client.

This is deliberate: DevScope never emits a fake no-op and calls it supported.

### Secrets and file inputs

Generated projects do not embed recorded passwords. Secret steps read environment variables such as:

- `DEVSCOPE_SECRET_4`
- `DEVSCOPE_FILE_7`

If required values are missing, generated runners fail explicitly.

### CODEGEN controls

- **GENERATE** — compile current Action Script into the selected language source.
- **code editor** — generated main source is editable directly on Android before export.
- **COPY CODE** — Android clipboard.
- **EXPORT CODE** — Storage Access Framework; saves the edited main source with the real language extension.
- **PROJECT ZIP** — builds a ZIP on Android containing source, dependency/build files, `flow.json` and README. Edits made in the code editor replace the main source inside that ZIP.

## Download Center

Website-triggered downloads use Android `DownloadManager`. DevScope passes the active WebView Cookie and User-Agent headers where available, shows real progress/status and supports open/share for completed downloads.

## Capture/export

- Inspector text: `.txt`
- Native Action Script: `.json`
- Generated source: `.py`, `.js`, `.ts`, `.java`, `.kt`, `.cs`, `.go`, `.c`, `.cpp`, `.rs`, `.rb`, `.php`
- Generated full language project: `.zip`
- Page archive: `.mht`
- Visible WebView capture: `.png`
- PDF: Android print/PDF flow
- Web file upload: Android WebView file chooser

## Deliberate limits

DevScope does not invent information that Android WebView does not expose. Request-body/response-body coverage is not claimed where WebView APIs do not provide it. Cross-origin/browser restrictions still apply. CAPTCHA/human verification is not bypassed.

Generated scripts are source projects for their actual external ecosystems. They need the listed language runtime/browser driver/dependencies when run outside Android. DevScope itself does not pretend to contain Python, Go, GCC, .NET, Rust or Node compilers.

## Build

- Android Native
- namespace/applicationId: `com.devscope.app`
- minSdk 24
- compileSdk/targetSdk 35
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle distribution configured for 8.9
- versionCode 6 / versionName 4.0.2

The source archive contains the standard Gradle Android project structure. The wrapper JAR is intentionally not bundled in this source archive.

## v4 Dependency Bootstrap Engine

Every CODEGEN project now receives real dependency bootstrap assets under `devscope/`:

- `setup.sh` / `setup.ps1` install target-language modules using the actual package manager.
- `install-toolchain.sh` / `install-toolchain.ps1` optionally install supported runtimes/toolchains when `DEVSCOPE_AUTO_INSTALL_TOOLCHAIN=1`.
- `verify.sh` / `verify.ps1` compile or validate the generated project without pretending success.
- `repair.sh` / `repair.ps1` clear broken dependency/build state, reinstall modules and rerun verification.
- `bootstrap.json` records runtime, required tools, manifests, install and verify commands.
- `env.example` lists required secret/file environment variables without embedding credentials.
- Dependency lock/tree files are produced by the setup process where the target ecosystem supports them.

DevScope itself remains Android-only. Standard Android does not ship every external compiler/runtime, so the DEPS panel generates, validates and exports the real bootstrap bundle rather than faking local installation. The exported bootstrap can also run under Termux for supported toolchains.

## v4.0.2 build fixes
This release retains the Android printing import fix (`android.print.PrintManager`) and fixes Android's checked `JSONException` requirement for pretty-printing `JSONObject` values. Pretty-print failures fall back to compact valid JSON without dropping the underlying data.
