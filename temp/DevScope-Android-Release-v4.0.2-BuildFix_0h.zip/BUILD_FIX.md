# DevScope Android v4.0.2 Build Fix

Fixed the two compile blockers reported by Android javac:

1. `refreshStorage()` no longer calls checked `JSONObject.toString(2)` directly inside a callback. It now uses the safe shared pretty-printer.
2. `pretty(JSONObject)` catches `org.json.JSONException` and falls back to compact `JSONObject.toString()` without losing data.

Also retained from v4.0.1:
- `android.print.PrintManager` correct package import.

No UI or functional module was removed.
