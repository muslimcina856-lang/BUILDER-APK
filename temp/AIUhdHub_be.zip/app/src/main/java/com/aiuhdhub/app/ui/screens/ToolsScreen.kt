@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.aiuhdhub.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.data.DownloadableModel
import com.aiuhdhub.app.data.ModelsRepository
import com.aiuhdhub.app.ui.components.GlassCard
import com.aiuhdhub.app.ui.theme.*
import com.aiuhdhub.app.utils.ModelDownloader
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

enum class ModelFilter(val label: String, val keyword: String?) {
    ALL("Semua", null),
    PHOTO("Foto", "Foto"),
    ANIME("Anime", "Anime"),
    SHADER("Shader", "Shader")
}

@Composable
fun ToolsScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var selectedFilter by remember { mutableStateOf(ModelFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }

    // Simpan status download model
    val downloadedStatus = remember {
        mutableStateMapOf<String, Boolean>().apply {
            ModelsRepository.getDownloadableModels().forEach { model ->
                put(model.id, ModelDownloader.isModelDownloaded(context, model.filename))
            }
        }
    }

    // Simpan progress download model
    val downloadProgress = remember { mutableStateMapOf<String, Int>() }
    val isDownloading = remember { mutableStateMapOf<String, Boolean>() }

    val allModels = ModelsRepository.getDownloadableModels()
    val filteredModels = remember(selectedFilter, searchQuery) {
        allModels.filter { model ->
            val matchesFilter = selectedFilter.keyword == null ||
                    model.type.contains(selectedFilter.keyword, ignoreCase = true) ||
                    model.engineType.contains(selectedFilter.keyword, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                    model.name.contains(searchQuery, ignoreCase = true) ||
                    model.description.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 50.dp, start = 24.dp, end = 24.dp, bottom = 16.dp)
        ) {
            Text(
                text = "Model Hub",
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 28.sp),
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Muat turun model AI UHD untuk diproses secara lokal",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            placeholder = {
                Text("Cari model...", color = TextMuted)
            },
            leadingIcon = {
                Icon(Icons.Filled.Search, contentDescription = null, tint = TextMuted)
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear", tint = TextMuted)
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark,
                focusedBorderColor = AccentBlue.copy(alpha = 0.5f),
                unfocusedBorderColor = DividerColor,
                cursorColor = AccentBlue,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModelFilter.entries.forEach { filter ->
                FilterChipItem(
                    label = filter.label,
                    selected = selectedFilter == filter,
                    onClick = { selectedFilter = filter },
                    color = when (filter) {
                        ModelFilter.ALL -> AccentCyan
                        ModelFilter.PHOTO -> AccentBlue
                        ModelFilter.ANIME -> AccentPurple
                        ModelFilter.SHADER -> AccentGreen
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Models List
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 4.dp,
                bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(
                items = filteredModels,
                key = { it.id }
            ) { model ->
                val downloaded = downloadedStatus[model.id] ?: false
                val progress = downloadProgress[model.id] ?: 0
                val downloading = isDownloading[model.id] ?: false

                ModelCard(
                    model = model,
                    isDownloaded = downloaded,
                    downloadProgress = progress,
                    isDownloading = downloading,
                    onDownloadClick = {
                        coroutineScope.launch {
                            isDownloading[model.id] = true
                            ModelDownloader.downloadModel(context, model.downloadUrl, model.filename)
                                .collect { state ->
                                    when (state) {
                                        is ModelDownloader.DownloadState.Progress -> {
                                            downloadProgress[model.id] = state.progress
                                        }
                                        is ModelDownloader.DownloadState.Success -> {
                                            downloadedStatus[model.id] = true
                                            isDownloading[model.id] = false
                                            downloadProgress[model.id] = 100
                                            Toast.makeText(context, "${model.name} sedia digunakan!", Toast.LENGTH_SHORT).show()
                                        }
                                        is ModelDownloader.DownloadState.Error -> {
                                            isDownloading[model.id] = false
                                            Toast.makeText(context, "Ralat: ${state.message}", Toast.LENGTH_LONG).show()
                                        }
                                        else -> {}
                                    }
                                }
                        }
                    },
                    onDeleteClick = {
                        ModelDownloader.deleteModel(context, model.filename)
                        downloadedStatus[model.id] = false
                        downloadProgress[model.id] = 0
                        Toast.makeText(context, "${model.name} dipadam.", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            if (filteredModels.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SearchOff,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Tiada model ditemui",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelCard(
    model: DownloadableModel,
    isDownloaded: Boolean,
    downloadProgress: Int,
    isDownloading: Boolean,
    onDownloadClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val accentColor = when {
        model.type.contains("Foto") -> AccentBlue
        model.type.contains("Anime") -> AccentPurple
        else -> AccentGreen
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = accentColor,
        showGlow = false
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = model.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = model.type,
                        style = MaterialTheme.typography.bodySmall,
                        color = accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isDownloaded) StatusActive.copy(alpha = 0.15f)
                            else if (isDownloading) AccentOrange.copy(alpha = 0.15f)
                            else DividerColor
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isDownloaded) "Telah Dimuat Turun"
                        else if (isDownloading) "Memuat Turun ($downloadProgress%)"
                        else "Belum Dimuat Turun",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDownloaded) StatusActive
                        else if (isDownloading) AccentOrange
                        else TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Description
            Text(
                text = model.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Info details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Saiz Fail", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(model.size, style = MaterialTheme.typography.labelMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Enjin AI", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(model.engineType, style = MaterialTheme.typography.labelMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Keserasian", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(model.compatibility, style = MaterialTheme.typography.labelMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress Bar if downloading
            if (isDownloading) {
                LinearProgressIndicator(
                    progress = downloadProgress / 100f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = AccentOrange,
                    trackColor = DividerColor
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                if (isDownloaded) {
                    Button(
                        onClick = onDeleteClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusInactive.copy(alpha = 0.15f),
                            contentColor = StatusInactive
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Padam", style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    Button(
                        onClick = onDownloadClick,
                        enabled = !isDownloading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentBlue,
                            contentColor = PrimaryDark,
                            disabledContainerColor = DividerColor,
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Muat Turun", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    color: Color
) {
    val bgColor = if (selected) color.copy(alpha = 0.2f) else Color.Transparent
    val borderColor = if (selected) color.copy(alpha = 0.5f) else DividerColor
    val textColor = if (selected) color else TextMuted

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = textColor,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
