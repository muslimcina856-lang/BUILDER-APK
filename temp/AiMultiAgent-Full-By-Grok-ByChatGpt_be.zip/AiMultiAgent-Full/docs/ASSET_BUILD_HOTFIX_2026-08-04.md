# Hotfix asset Linux semasa build terus

## Ralat asal

```text
No file or variants found for asset: assets/linux/full/runtime-pack.zip.
Target debug_android_application failed: Failed to bundle asset files.
```

`runtime-pack.zip` ialah asset terjana. Skrip `build_debug.sh` dan `build_full.sh`
memang menjana fail itu dahulu, tetapi sesetengah panel hanya menjalankan
`flutter build apk` secara terus. Dalam laluan tersebut skrip projek tidak pernah
dipanggil, lalu task `compileFlutterBuildDebug` membaca `pubspec.yaml` ketika fail
masih belum wujud.

## Pembetulan

`mobile/android/app/build.gradle.kts` kini mendaftarkan:

- `prepareBundledLinuxRuntime`: menjalankan pembina Alpine/PRoot dan menghasilkan
  `runtime-pack.zip`, manifest serta SHA-256;
- `verifyBundledLinuxRuntime`: mengesahkan CRC, struktur, manifest, permission,
  symlink dan ELF AArch64; dan
- dependency terus daripada setiap task bernama `compileFlutterBuild*` kepada
  task verifikasi tersebut.

Dependency terus pada `compileFlutterBuild*` digunakan kerana dependency pada
`preBuild` sahaja tidak menjamin urutan sebelum Flutter memproses asset.

Pembina runtime juga menggunakan `curl` atau `wget` sebagai fallback selepas
kegagalan `urllib`. Muat turun masih tertakluk kepada had saiz dan pengesahan
SHA-256/saiz sumber yang sama.

## Laluan build yang dilindungi

```text
flutter run
flutter build apk --debug
flutter build apk --release
flutter build appbundle --release
./scripts/build_debug.sh
./scripts/build_full.sh
```

## Urutan baharu

```text
compileFlutterBuildDebug/Release
  -> verifyBundledLinuxRuntime
     -> prepareBundledLinuxRuntime
        -> jana runtime-pack.zip + sidecar
     -> verify-only
  -> Flutter bundle assets
```

Jika Python, rangkaian atau cache sumber tiada, build kini berhenti pada task
penyediaan runtime dengan sebab sebenar. Ia tidak lagi sampai kepada ralat
`pubspec.yaml` yang mengelirukan.
