# Audit rakaman skrin dan pembetulan media — 4 Ogos 2026

## Skop

Dua rakaman skrin diperiksa dari awal hingga akhir:

- `Screenrecorder-2026-08-04-06-16-01-795.mp4` — kira-kira 2 minit 13 saat.
- `Screenrecorder-2026-08-04-06-26-15-360.mp4` — kira-kira 25 saat.

Perubahan ini hanya menambah halaman **Cara Guna**. Tiada halaman Terma Penggunaan, Polisi Privasi atau polisi keselamatan baharu ditambah pada UI.

## Masalah yang disahkan

1. Linux Workspace memanggil `setState` dengan callback yang memulangkan `Future`, lalu memaparkan ralat Flutter.
2. Screenshot browser dipaparkan menggunakan `BoxFit.cover`, menyebabkan bahagian imej kelihatan dipotong.
3. Tiada pratonton skrin penuh/zoom dan aliran Simpan yang jelas untuk screenshot.
4. Video dan audio artifact tidak mempunyai pemain pratonton lengkap sebelum pengguna memilih untuk menyimpan fail.
5. Artifact halaman web dibuka sebagai WebView besar dan menghasilkan kawasan putih panjang dalam chat.
6. Browser Chromium tersembunyi membenarkan media halaman dimulakan tanpa interaksi pengguna; audio TikTok/YouTube boleh kedengaran walaupun browser tidak dipaparkan.
7. Kad proses memaparkan JSON mentah daripada browser dan payload halaman terlalu besar untuk dihantar semula kepada model.
8. AI tidak menerima senarai server MCP aktif dalam konteks runtime, jadi ia sukar memilih PC Windows yang telah dikonfigurasi.
9. Ikon Full lama tidak sepadan dengan rekaan premium yang diminta.

## Pembetulan

- Callback refresh Linux Workspace kini menyegerakkan assignment `Future` di dalam `setState` tanpa callback async.
- Screenshot native menggunakan tangkapan berjubin dan dicantumkan menjadi satu PNG halaman penuh. Output dihadkan secara terkawal untuk mengelakkan `Bitmap` melampau.
- Imej dalam chat menggunakan `BoxFit.contain`; pratonton penuh menggunakan `InteractiveViewer`, paparan ikut lebar, pan dan zoom sehingga 8x.
- Tool `media_preview` menghasilkan artifact gambar/video/audio daripada URL langsung tanpa menulis fail ke storan. Fail rangkaian hanya dimuat turun apabila pengguna memilih Simpan; fail sementara separa dibersihkan jika pemindahan gagal.
- Video tidak autoplay, mempunyai play/jeda, scrub, skrin penuh dan berhenti apabila aplikasi meninggalkan foreground.
- Audio tidak autoplay, mempunyai play/jeda, scrub dan berhenti apabila aplikasi meninggalkan foreground.
- Pratonton HTML ditutup secara lalai, JavaScript dimatikan dan elemen audio/video dibuang daripada HTML preview.
- WebView tersembunyi menetapkan `mediaPlaybackRequiresUserGesture=true`, menyuntik skrip senyap pada document-start, memaksa `audio/video` muted dan menyekat Web Audio daripada berbunyi.
- Payload browser kepada model dipendekkan; HTML/artifact mentah tidak dihantar kepada model dan kad proses menggunakan ringkasan mesra pengguna.
- `runtime_info` menyertakan server MCP aktif. Agent diarahkan menggunakan tools PC Windows sebenar apabila Linux ARM64 tidak sesuai, dan tidak mereka akses jika server/tool tiada.
- Halaman **Cara Guna** ditambah pada tab Lagi dan tersedia kepada AI melalui tool baca sahaja `app_usage_guide`.
- Semua aset launcher, adaptive icon, round icon, launch logo dan aset store Full diganti dengan ikon hitam-ungu premium.

## Validasi

Lulus:

- `scripts/verify_source.py`
- `scripts/verify_release_config.py`
- `scripts/check_source_text.py`
- `scripts/check_project.sh`
- ujian pembina runtime Linux dan fixture parser DuckDuckGo

Flutter SDK dan Android SDK tidak tersedia dalam persekitaran audit ini, jadi APK tidak dibina di sini. Build sebenar perlu dijalankan dalam panel/CI projek; hook Gradle yang sedia ada akan menyediakan runtime Linux sebelum Flutter membungkus asset.
