# Linux terbina — Ai MultiAgent Full

Edisi Full menggunakan **Alpine Linux 3.24.1 aarch64 + PRoot 0.15**. Runtime bukan lagi langkah manual. `scripts/build_full.sh` akan:

1. memuat turun Alpine minirootfs rasmi dan PRoot Android daripada commit yang dipinkan;
2. mengesahkan SHA-256 Alpine, commit/saiz/format ELF64 AArch64 PRoot, CRC, nama entri unik, symlink, permission Unix dan struktur arkib;
3. membina `mobile/assets/linux/full/runtime-pack.zip` bersama manifest sumber dan checksum;
4. membina APK/AAB ARM64; dan
5. gagal jika runtime tidak benar-benar wujud dalam APK atau AAB.

```bash
./scripts/build_full.sh
```

Untuk menyediakan asset tanpa membina Android:

```bash
python3 scripts/linux/prepare_bundled_runtime.py
python3 scripts/linux/prepare_bundled_runtime.py --verify-only
```

Cache muat turun berada di `.cache/linux-runtime`. Untuk binaan offline, sediakan cache dahulu dan gunakan:

```bash
python3 scripts/linux/prepare_bundled_runtime.py --offline
```

## Kandungan runtime

```text
runtime/bin/proot
runtime/lib/...
runtime/manifest.json
runtime/licenses/...
rootfs/bin/sh
rootfs/sbin/apk
rootfs/...
home/.profile
```

Pada penggunaan pertama, aplikasi mengekstrak asset ke storan internal private dan menjalankan health check sebenar: PRoot mesti boleh memulakan shell, `uname -m` mesti `aarch64`, Alpine mesti versi 3.24.1, `/sbin/apk` mesti ditemui dan `apk --version` mesti mengeluarkan `apk-tools`. Pemasangan menggunakan staging, backup, marker kesihatan dan rollback. Jika proses/telefon mati ketika pertukaran rootfs, aplikasi memulihkan transaksi pada permulaan seterusnya sebelum menggunakan runtime. Naik taraf runtime mengekalkan `/workspace`, `/root`, cache browser dan snapshot pengguna. Pakej yang dipasang terus ke rootfs perlu dipasang semula selepas pertukaran versi runtime; reset memang memadam semuanya.

`terminal_start` memasang runtime bawaan secara automatik sebelum arahan pertama. AI diarahkan menggunakan `linux_workspace_status`, `terminal_start`, kemudian `terminal_poll` sehingga job selesai dan `terminal_stop` apabila perlu. Terminal tidak mempunyai stdin interaktif; AI menggunakan flag non-interaktif, tidak membuka editor interaktif, dan tidak menggunakan `sudo` kerana pengguna guest sudah root. Pengurus pakej ialah `apk`, contohnya:

```sh
apk update && apk add git python3
```

Bind PRoot terhad kepada `/proc`, peranti asas yang wujud (`/dev/null`, `/dev/zero`, random, tty/pts), serta folder private aplikasi (`/workspace`, `/root`, `/tmp`). `/sys`, `/sdcard`, `/storage` dan data aplikasi lain tidak dibind.

## Sempadan kemampuan

Ini ialah Linux userland ARM64 melalui PRoot, bukan kernel/VM baharu dan bukan akses kepada PC jauh. Root hanya diemulasikan di dalam guest. Tiada root Android, systemd atau desktop GUI secara lalai.

## Keserasian Android

Release Full dibina untuk `arm64-v8a` sahaja. Ia mengekalkan compatibility `targetSdk 28` kerana pelaksanaan binary dari direktori writable aplikasi disekat untuk aplikasi yang menyasarkan API 29 ke atas. `compileSdk` kekal 36. Edisi Full bukan binaan gedung aplikasi.

Import ZIP melalui File Picker masih disediakan sebagai laluan pemulihan sahaja. ZIP import tertakluk kepada had 512 MiB terkompres, 2 GiB diekstrak, 100,000 entri, 512 MiB setiap entri, sasaran symlink 4 KiB, path traversal, nama entri berganda, symlink ke storan Android, manifest, ELF AArch64, permission, staging dan health-check yang sama. Output stdout/stderr setiap job menggunakan rolling buffer dan maksimum 8 job serentak dan hanya 64 job terakhir dikekalkan.

## Asset source dan artifact Android

`runtime-pack.zip` ialah fail terjana dan tidak disimpan dalam arkib source. Ini bukan bermaksud APK tiada Linux. Jika `build_debug.sh`/`build_full.sh` digunakan, skrip menjana asset dahulu. Jika panel memanggil `flutter build apk` atau `flutter build appbundle` secara terus, task Gradle `prepareBundledLinuxRuntime` dan `verifyBundledLinuxRuntime` dijalankan sebagai dependency terus bagi `compileFlutterBuild*` sebelum Flutter memeriksa senarai asset dalam `pubspec.yaml`. Build akan gagal dengan ralat penyediaan runtime yang jelas jika Python/rangkaian/cache tiada, bukannya ralat asset hilang. Untuk binaan tanpa rangkaian, cache rasmi perlu disediakan dan `--offline` digunakan.
