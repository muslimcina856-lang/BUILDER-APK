import 'dart:convert';

/// Respons provider yang tidak selamat untuk diteruskan kepada executor tool.
class ProviderResponseIntegrityException implements Exception {
  const ProviderResponseIntegrityException({
    required this.code,
    required this.message,
    this.details = const <String, dynamic>{},
  });

  final String code;
  final String message;
  final Map<String, dynamic> details;

  @override
  String toString() => '$code: $message';
}

/// Menyatukan pemeriksaan completion metadata untuk semua protokol provider.
class ProviderResponseGuard {
  const ProviderResponseGuard._();

  static void ensureOpenAiChatComplete(Map<String, dynamic> data) {
    for (final raw in data['choices'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final choice = Map<String, dynamic>.from(raw);
      _rejectTruncatedReason(
        choice['finish_reason'] ?? choice['finishReason'],
        protocol: 'openai_chat',
      );
    }
  }

  static void ensureOpenAiStreamComplete({
    required String? finishReason,
    required bool sawDone,
  }) {
    _rejectTruncatedReason(finishReason, protocol: 'openai_chat_stream');
    if (finishReason == null && !sawDone) {
      throw const ProviderResponseIntegrityException(
        code: 'INCOMPLETE_STREAM',
        message:
            'Stream tamat tanpa finish_reason atau penanda completion. '
            'Respons separa tidak akan digunakan.',
      );
    }
  }

  static void ensureOpenAiResponsesComplete(Map<String, dynamic> data) {
    final status = data['status']?.toString().trim().toLowerCase();
    if (status == 'incomplete') {
      final details = Map<String, dynamic>.from(
        data['incomplete_details'] as Map? ?? const <String, dynamic>{},
      );
      throw ProviderResponseIntegrityException(
        code: 'OUTPUT_TRUNCATED',
        message:
            'Respons API tidak lengkap (${details['reason'] ?? 'sebab tidak diketahui'}). '
            'Tool call tidak akan dijalankan.',
        details: details,
      );
    }
    if (status == 'failed' || status == 'cancelled') {
      throw ProviderResponseIntegrityException(
        code: 'OUTPUT_INCOMPLETE',
        message: 'Respons API berstatus $status dan tidak selamat digunakan.',
      );
    }
  }

  static void ensureAnthropicComplete(Map<String, dynamic> data) {
    _rejectTruncatedReason(
      data['stop_reason'] ?? data['stopReason'],
      protocol: 'anthropic',
    );
  }

  static void ensureGeminiComplete(Map<String, dynamic> data) {
    for (final raw in data['candidates'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final candidate = Map<String, dynamic>.from(raw);
      _rejectTruncatedReason(
        candidate['finishReason'] ?? candidate['finish_reason'],
        protocol: 'gemini',
      );
    }
  }

  static void ensureGenericComplete(Map<String, dynamic> data) {
    _rejectTruncatedReason(
      data['finish_reason'] ??
          data['finishReason'] ??
          data['stop_reason'] ??
          data['stopReason'],
      protocol: 'custom',
    );
    final status = data['status']?.toString().trim().toLowerCase();
    if (status == 'incomplete') {
      throw const ProviderResponseIntegrityException(
        code: 'OUTPUT_TRUNCATED',
        message: 'Provider memulangkan respons tidak lengkap.',
      );
    }
  }

  static Map<String, dynamic> decodeToolArguments(Object? value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    if (value == null) return <String, dynamic>{};
    final raw = value.toString().trim();
    if (raw.isEmpty) {
      throw const ProviderResponseIntegrityException(
        code: 'INVALID_TOOL_ARGUMENTS',
        message: 'Argumen tool kosong atau terpotong.',
      );
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {
      // Ditukar kepada ralat berstruktur di bawah. Jangan teruskan raw payload.
    }
    throw ProviderResponseIntegrityException(
      code: 'INVALID_TOOL_ARGUMENTS',
      message:
          'JSON argumen tool tidak lengkap atau tidak sah (${raw.length} aksara). '
          'Tool call tidak akan dijalankan.',
      details: <String, dynamic>{'argument_chars': raw.length},
    );
  }

  static void _rejectTruncatedReason(
    Object? rawReason, {
    required String protocol,
  }) {
    final reason = rawReason?.toString().trim().toLowerCase() ?? '';
    if (reason.isEmpty) return;
    const truncatedReasons = <String>{
      'length',
      'max_tokens',
      'max_output_tokens',
      'max_tokens_reached',
      'token_limit',
    };
    if (truncatedReasons.contains(reason)) {
      throw ProviderResponseIntegrityException(
        code: 'OUTPUT_TRUNCATED',
        message:
            'Output $protocol terhenti kerana had token ($reason). '
            'Tool call separa tidak akan dijalankan.',
        details: <String, dynamic>{
          'protocol': protocol,
          'finish_reason': reason,
        },
      );
    }
    if (<String>{
      'malformed_function_call',
      'malformed_tool_call',
      'unexpected_tool_call',
    }.contains(reason)) {
      throw ProviderResponseIntegrityException(
        code: 'INVALID_TOOL_ARGUMENTS',
        message: 'Provider melaporkan tool call rosak ($reason).',
        details: <String, dynamic>{
          'protocol': protocol,
          'finish_reason': reason,
        },
      );
    }
    if (<String>{
      'content_filter',
      'safety',
      'recitation',
      'blocked',
    }.contains(reason)) {
      throw ProviderResponseIntegrityException(
        code: 'OUTPUT_INCOMPLETE',
        message: 'Provider menghentikan output sebelum lengkap ($reason).',
        details: <String, dynamic>{
          'protocol': protocol,
          'finish_reason': reason,
        },
      );
    }
  }
}
