import 'dart:convert';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class DuckDuckGoSearchResult {
  const DuckDuckGoSearchResult({
    required this.rank,
    required this.title,
    required this.url,
    required this.snippet,
    required this.displayUrl,
    required this.source,
  });

  final int rank;
  final String title;
  final String url;
  final String snippet;
  final String displayUrl;
  final String source;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'rank': rank,
        'title': title,
        'url': url,
        'display_url': displayUrl,
        'snippet': snippet,
        'source': source,
      };
}

class DuckDuckGoSearchResponse {
  const DuckDuckGoSearchResponse({
    required this.query,
    required this.endpoint,
    required this.results,
    required this.elapsedMs,
  });

  final String query;
  final String endpoint;
  final List<DuckDuckGoSearchResult> results;
  final int elapsedMs;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'query': query,
        'engine': 'DuckDuckGo',
        'endpoint': endpoint,
        'count': results.length,
        'elapsed_ms': elapsedMs,
        'results': results.map((item) => item.toJson()).toList(),
      };

  String prettyJson() => const JsonEncoder.withIndent('  ').convert(toJson());
}

class DuckDuckGoSearchService {
  DuckDuckGoSearchService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Header menyerupai browser sebenar — kurangkan peluang page bot/captcha.
  static const Map<String, String> _headers = <String, String>{
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
    'Accept':
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,'
        'image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9,ms;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
  };

  Future<DuckDuckGoSearchResponse> search({
    required String query,
    int maxResults = 10,
    String region = 'wt-wt',
    String safeSearch = 'moderate',
    String timeRange = '',
  }) async {
    final normalized = query.trim();
    if (normalized.isEmpty) throw const FormatException('Query carian kosong.');
    final limit = maxResults.clamp(1, AppConfig.maxSearchResults).toInt();
    final watch = Stopwatch()..start();

    final parameters = <String, String>{
      'q': normalized,
      'kl': region.trim().isEmpty ? 'wt-wt' : region.trim(),
      if (safeSearch == 'off') 'kp': '-2',
      if (safeSearch == 'strict') 'kp': '1',
      if (safeSearch == 'moderate') 'kp': '-1',
      if (timeRange.trim().isNotEmpty) 'df': timeRange.trim(),
    };

    FormatException? lastFormat;
    HttpExceptionLike? lastHttp;

    // 1) html.duckduckgo.com (utama)
    // 2) lite.duckduckgo.com (fallback)
    // Setiap endpoint dicuba sehingga 2 kali dengan jeda singkat.
    final endpoints = <({String host, String path, String mode})>[
      (host: 'html.duckduckgo.com', path: '/html/', mode: 'html'),
      (host: 'lite.duckduckgo.com', path: '/lite/', mode: 'lite'),
    ];

    for (final endpoint in endpoints) {
      final uri = Uri.https(endpoint.host, endpoint.path, parameters);
      for (var attempt = 1; attempt <= 2; attempt++) {
        try {
          final response = await _client
              .get(uri, headers: _headers)
              .timeout(AppConfig.defaultTimeout);
          if (response.statusCode < 200 || response.statusCode >= 300) {
            lastHttp = HttpExceptionLike(
              'DuckDuckGo ${endpoint.host} HTTP ${response.statusCode}.',
            );
            if (attempt < 2) {
              await Future<void>.delayed(Duration(milliseconds: 350 * attempt));
              continue;
            }
            break;
          }

          final body = response.body;
          if (_looksLikeBlockPage(body)) {
            lastFormat = const FormatException(
              'DuckDuckGo menolak permintaan (captcha/rate-limit). '
              'Tunggu sekejap dan cuba semula.',
            );
            if (attempt < 2) {
              await Future<void>.delayed(Duration(milliseconds: 600 * attempt));
              continue;
            }
            break;
          }

          final values = endpoint.mode == 'html'
              ? parseHtmlResults(body, limit: limit, source: 'html')
              : parseLiteResults(body, limit: limit);

          // Fallback parser longgar jika selector utama kosong.
          final resolved = values.isNotEmpty
              ? values
              : parseLooseResults(body, limit: limit, source: '${endpoint.mode}-loose');

          if (resolved.isNotEmpty) {
            watch.stop();
            return DuckDuckGoSearchResponse(
              query: normalized,
              endpoint: uri.toString(),
              results: resolved,
              elapsedMs: watch.elapsedMilliseconds,
            );
          }

          lastFormat = const FormatException(
            'DuckDuckGo tidak memulangkan hasil yang boleh dibaca.',
          );
          if (attempt < 2) {
            await Future<void>.delayed(Duration(milliseconds: 400 * attempt));
          }
        } on FormatException catch (error) {
          lastFormat = error;
        } on HttpExceptionLike catch (error) {
          lastHttp = error;
        } catch (error) {
          lastHttp = HttpExceptionLike('DuckDuckGo ralat rangkaian: $error');
          if (attempt < 2) {
            await Future<void>.delayed(Duration(milliseconds: 400 * attempt));
          }
        }
      }
    }

    watch.stop();
    if (lastHttp != null && lastFormat == null) throw lastHttp;
    throw lastFormat ??
        const FormatException(
          'DuckDuckGo tidak memulangkan hasil yang boleh dibaca.',
        );
  }

  static bool _looksLikeBlockPage(String body) {
    final lower = body.toLowerCase();
    return lower.contains('anomaly-modal') ||
        lower.contains('please complete the following challenge') ||
        lower.contains('unusual traffic') ||
        (lower.contains('captcha') && lower.contains('duckduckgo')) ||
        lower.contains('bot detection') ||
        (lower.contains('challenge') && lower.contains('cloudflare'));
  }

  static List<DuckDuckGoSearchResult> parseHtmlResults(
    String body, {
    required int limit,
    String source = 'html',
  }) {
    final document = html_parser.parse(body);
    final values = <DuckDuckGoSearchResult>[];
    final seen = <String>{};

    final nodes = document.querySelectorAll(
      '.result, .web-result, .results_links, .results_links_deep, '
      'div[class*="result"], article[class*="result"]',
    );

    for (final element in nodes) {
      final anchor = element.querySelector(
        '.result__a, a.result-link, h2 a, a[data-testid="result-title-a"], a[href]',
      );
      if (anchor == null) continue;
      final url = _decodeRedirect(anchor.attributes['href'] ?? '');
      if (!_isHttpUrl(url) || !_isExternalResult(url) || !seen.add(url)) continue;
      final title = _clean(anchor.text);
      if (title.isEmpty) continue;
      final snippet = _clean(
        element
                .querySelector(
                  '.result__snippet, .result-snippet, .result__body, '
                  '[class*="snippet"]',
                )
                ?.text ??
            '',
      );
      final display = _clean(
        element.querySelector('.result__url, .result-url, cite')?.text ??
            Uri.parse(url).host,
      );
      values.add(
        DuckDuckGoSearchResult(
          rank: values.length + 1,
          title: title,
          url: url,
          snippet: snippet,
          displayUrl: display.isEmpty ? Uri.parse(url).host : display,
          source: source,
        ),
      );
      if (values.length >= limit) break;
    }
    return values;
  }

  static List<DuckDuckGoSearchResult> parseLiteResults(
    String body, {
    required int limit,
  }) {
    final document = html_parser.parse(body);
    final values = <DuckDuckGoSearchResult>[];
    final seen = <String>{};
    final resultAnchors = document.querySelectorAll('a.result-link');
    final anchors =
        resultAnchors.isNotEmpty ? resultAnchors : document.querySelectorAll('a[href]');
    for (final anchor in anchors) {
      final raw = anchor.attributes['href'] ?? '';
      final url = _decodeRedirect(raw);
      if (!_isHttpUrl(url) || !_isExternalResult(url) || !seen.add(url)) continue;
      final title = _clean(anchor.text);
      if (title.isEmpty || title.toLowerCase() == 'next page') continue;
      final row = anchor.parent?.parent;
      final nextRow = row?.nextElementSibling;
      final snippetNode =
          nextRow?.querySelector('.result-snippet, .result__snippet');
      final nearbyText =
          _clean(snippetNode?.text ?? nextRow?.text ?? row?.text ?? '');
      var snippet = nearbyText
          .replaceFirst(title, '')
          .replaceFirst(RegExp(r'^\d+[.]?\s*'), '')
          .trim();
      if (snippet.length > 700) snippet = snippet.substring(0, 700);
      values.add(
        DuckDuckGoSearchResult(
          rank: values.length + 1,
          title: title,
          url: url,
          snippet: snippet,
          displayUrl: Uri.parse(url).host,
          source: 'lite',
        ),
      );
      if (values.length >= limit) break;
    }
    return values;
  }

  /// Parser longgar: ambil pautan luar yang nampak seperti hasil carian.
  static List<DuckDuckGoSearchResult> parseLooseResults(
    String body, {
    required int limit,
    String source = 'loose',
  }) {
    final document = html_parser.parse(body);
    final values = <DuckDuckGoSearchResult>[];
    final seen = <String>{};

    for (final anchor in document.querySelectorAll('a[href]')) {
      final url = _decodeRedirect(anchor.attributes['href'] ?? '');
      if (!_isHttpUrl(url) || !_isExternalResult(url) || !seen.add(url)) continue;
      final title = _clean(anchor.text);
      if (title.length < 3) continue;
      final lower = title.toLowerCase();
      if (lower == 'next' ||
          lower == 'next page' ||
          lower == 'previous' ||
          (lower.startsWith('http') && title.length < 12)) {
        continue;
      }
      final parentText = _clean(anchor.parent?.text ?? '');
      var snippet = parentText.replaceFirst(title, '').trim();
      if (snippet.length > 400) snippet = snippet.substring(0, 400);
      values.add(
        DuckDuckGoSearchResult(
          rank: values.length + 1,
          title: title,
          url: url,
          snippet: snippet,
          displayUrl: Uri.parse(url).host,
          source: source,
        ),
      );
      if (values.length >= limit) break;
    }
    return values;
  }

  static String _decodeRedirect(String raw) {
    var normalized = raw.trim();
    if (normalized.startsWith('//')) normalized = 'https:$normalized';
    final parsed = Uri.tryParse(normalized);
    if (parsed == null) return normalized;
    final uddg = parsed.queryParameters['uddg'];
    if (uddg != null && uddg.isNotEmpty) {
      return Uri.decodeComponent(uddg);
    }
    final pathUddg = parsed.queryParameters['u'] ?? parsed.queryParameters['url'];
    if (pathUddg != null && pathUddg.isNotEmpty) {
      return Uri.decodeComponent(pathUddg);
    }
    return normalized;
  }

  static bool _isHttpUrl(String value) {
    final uri = Uri.tryParse(value);
    return uri != null &&
        <String>{'http', 'https'}.contains(uri.scheme) &&
        uri.host.isNotEmpty;
  }

  static bool _isExternalResult(String url) {
    final host = Uri.tryParse(url)?.host.toLowerCase() ?? '';
    if (host.isEmpty) return false;
    if (host == 'duckduckgo.com' || host.endsWith('.duckduckgo.com')) {
      return false;
    }
    return true;
  }

  static String _clean(String value) => value.replaceAll(RegExp(r'\s+'), ' ').trim();

  void dispose() => _client.close();
}

class HttpExceptionLike implements Exception {
  const HttpExceptionLike(this.message);
  final String message;
  @override
  String toString() => message;
}
