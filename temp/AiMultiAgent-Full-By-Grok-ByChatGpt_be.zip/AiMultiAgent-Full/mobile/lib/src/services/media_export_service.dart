import 'dart:async';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config/app_config.dart';

class MediaExportResult {
  const MediaExportResult({
    required this.success,
    required this.cancelled,
    required this.message,
  });

  final bool success;
  final bool cancelled;
  final String message;
}

class MediaExportService {
  MediaExportService({http.Client? client}) : _client = client ?? http.Client();

  static const MethodChannel _channel = MethodChannel('com.aiauto.claw/media');
  final http.Client _client;

  Future<MediaExportResult> save({
    required String title,
    required String mimeType,
    String localPath = '',
    String? remoteUrl,
    void Function(double? progress)? onProgress,
  }) async {
    File? temporaryFile;
    try {
      var source = localPath.trim().isEmpty ? null : File(localPath.trim());
      if (source == null || !await source.exists()) {
        final uri = Uri.tryParse(remoteUrl?.trim() ?? '');
        if (uri == null ||
            !<String>{'http', 'https'}.contains(uri.scheme) ||
            uri.host.isEmpty) {
          throw const FormatException('Sumber media tidak sah.');
        }
        temporaryFile = await _download(uri, title, onProgress);
        source = temporaryFile;
      }

      final raw = await _channel.invokeMapMethod<String, dynamic>(
        'saveFile',
        <String, dynamic>{
          'path': source.path,
          'fileName': _safeFilename(title, source.path),
          'mimeType': mimeType.trim().isEmpty
              ? 'application/octet-stream'
              : mimeType.trim(),
        },
      );
      final result = Map<String, dynamic>.from(raw ?? const <String, dynamic>{});
      final cancelled = result['cancelled'] == true;
      final success = result['success'] == true;
      return MediaExportResult(
        success: success,
        cancelled: cancelled,
        message: cancelled
            ? 'Simpanan dibatalkan.'
            : success
                ? 'Fail berjaya disimpan.'
                : result['error']?.toString() ?? 'Fail tidak dapat disimpan.',
      );
    } on MissingPluginException {
      return const MediaExportResult(
        success: false,
        cancelled: false,
        message: 'Pemilih lokasi simpan tidak tersedia pada peranti ini.',
      );
    } on PlatformException catch (error) {
      return MediaExportResult(
        success: false,
        cancelled: false,
        message: error.message ?? error.code,
      );
    } catch (error) {
      return MediaExportResult(
        success: false,
        cancelled: false,
        message: error.toString().replaceFirst('Exception: ', ''),
      );
    } finally {
      if (temporaryFile != null) {
        try {
          if (await temporaryFile.exists()) await temporaryFile.delete();
        } catch (_) {
          // Fail sementara akan dibersihkan oleh sistem jika penghapusan gagal.
        }
      }
    }
  }

  Future<File> _download(
    Uri uri,
    String title,
    void Function(double? progress)? onProgress,
  ) async {
    final request = http.Request('GET', uri)
      ..headers.addAll(<String, String>{
        'User-Agent':
            'Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 AiMultiAgent/1.0.0',
        'Accept': '*/*',
      });
    final response = await _client
        .send(request)
        .timeout(AppConfig.browserTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('HTTP ${response.statusCode} ketika memuat turun media.');
    }
    final total = response.contentLength;
    if (total != null && total > AppConfig.maxDownloadBytes) {
      throw const FileSystemException('Fail melebihi had muat turun 250 MB.');
    }

    final tempDirectory = await getTemporaryDirectory();
    final file = File(
      p.join(
        tempDirectory.path,
        'export-${DateTime.now().microsecondsSinceEpoch}-${_safeFilename(title, uri.path)}',
      ),
    );
    await file.parent.create(recursive: true);
    final sink = file.openWrite();
    var received = 0;
    try {
      await for (final chunk in response.stream) {
        received += chunk.length;
        if (received > AppConfig.maxDownloadBytes) {
          throw const FileSystemException('Fail melebihi had muat turun 250 MB.');
        }
        sink.add(chunk);
        onProgress?.call(total == null || total <= 0 ? null : received / total);
      }
      await sink.flush();
      await sink.close();
    } catch (_) {
      await sink.close();
      if (await file.exists()) await file.delete();
      rethrow;
    }
    onProgress?.call(1);
    return file;
  }

  String _safeFilename(String title, String fallbackPath) {
    var value = title.trim();
    if (value.isEmpty) value = p.basename(fallbackPath);
    if (value.isEmpty) value = 'media-${DateTime.now().millisecondsSinceEpoch}';
    value = value.replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1F]'), '_');
    if (p.extension(value).isEmpty) {
      final extension = p.extension(fallbackPath);
      if (extension.isNotEmpty) value += extension;
    }
    return value.length > 120 ? value.substring(value.length - 120) : value;
  }

  void dispose() => _client.close();
}
