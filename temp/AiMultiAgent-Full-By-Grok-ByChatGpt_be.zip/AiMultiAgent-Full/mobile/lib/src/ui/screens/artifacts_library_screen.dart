import 'dart:io';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../services/media_export_service.dart';
import '../../theme/app_theme.dart';

/// Perpustakaan artifact (imej, zip, fail, dll) — diikat kepada sesi chat.
/// Chat baru tidak boleh akses artifact sesi lain; buka sesi tersebut untuk guna.
class ArtifactsLibraryScreen extends StatefulWidget {
  const ArtifactsLibraryScreen({super.key, this.sessionIdOnly});

  /// Jika diisi, hanya papar artifact sesi ini (contoh dari dalam chat).
  final String? sessionIdOnly;

  @override
  State<ArtifactsLibraryScreen> createState() => _ArtifactsLibraryScreenState();
}

class _ArtifactsLibraryScreenState extends State<ArtifactsLibraryScreen> {
  final MediaExportService _export = MediaExportService();
  final Set<String> _selected = <String>{};
  List<_ArtifactEntry> _items = <_ArtifactEntry>[];
  bool _loading = true;
  String? _filterSessionId;

  @override
  void initState() {
    super.initState();
    _filterSessionId = widget.sessionIdOnly;
    _reload();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final state = AppScope.of(context);
    final rows = await state.database.listArtifacts(sessionId: _filterSessionId);
    final sessions = await state.database.listChatSessions(limit: 200);
    final titles = <String, String>{
      for (final s in sessions) s['id'] as String: s['title'] as String? ?? 'Chat',
    };
    final items = <_ArtifactEntry>[];
    for (final row in rows) {
      final art = ChatArtifact.fromJson(
        Map<String, dynamic>.from(row['artifact'] as Map),
      );
      final sid = row['sessionId']?.toString() ?? '';
      items.add(
        _ArtifactEntry(
          key: '${sid}_${art.id}',
          sessionId: sid,
          sessionTitle: titles[sid] ?? 'Sesi ${sid.length > 8 ? sid.substring(0, 8) : sid}',
          messageId: row['messageId']?.toString() ?? '',
          createdAt: DateTime.fromMillisecondsSinceEpoch(
            (row['createdAt'] as num?)?.toInt() ?? 0,
          ),
          artifact: art,
        ),
      );
    }
    if (!mounted) return;
    setState(() {
      _items = items;
      _selected.removeWhere((id) => items.every((e) => e.key != id));
      _loading = false;
    });
  }

  void _selectAll() {
    setState(() {
      _selected
        ..clear()
        ..addAll(_items.map((e) => e.key));
    });
  }

  void _unselectAll() {
    setState(() => _selected.clear());
  }

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam artifact?'),
        content: Text(
          '${_selected.length} item akan dipadam dari mesej berkaitan. '
          'Fail pada storan juga dipadam jika wujud.',
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Padam')),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    final state = AppScope.of(context);
    final bySession = <String, List<_ArtifactEntry>>{};
    for (final entry in _items.where((e) => _selected.contains(e.key))) {
      bySession.putIfAbsent(entry.sessionId, () => <_ArtifactEntry>[]).add(entry);
    }

    for (final entry in bySession.entries) {
      final messages = await state.database.listMessages(entry.key);
      for (final message in messages) {
        final removeIds = entry.value
            .where((e) => e.messageId == message.id)
            .map((e) => e.artifact.id)
            .toSet();
        if (removeIds.isEmpty) continue;
        // Padam fail local
        for (final e in entry.value.where((x) => x.messageId == message.id)) {
          final path = e.artifact.localPath.trim();
          if (path.isNotEmpty) {
            try {
              final f = File(path);
              if (await f.exists()) await f.delete();
            } catch (_) {}
          }
        }
        final meta = Map<String, dynamic>.from(message.metadata);
        final arts = (meta['artifacts'] as List? ?? const <dynamic>[])
            .whereType<Map>()
            .where((m) => !removeIds.contains(m['id']?.toString()))
            .toList();
        meta['artifacts'] = arts;
        final updated = message.copyWith(metadata: meta);
        await state.database.saveMessage(updated);
      }
    }

    await state.reloadCurrentSessionMessages();

    _selected.clear();
    await _reload();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Artifact dipadam.')),
      );
    }
  }

  Future<void> _downloadSelected() async {
    final picked = _items.where((e) => _selected.contains(e.key)).toList();
    if (picked.isEmpty) return;
    var ok = 0;
    for (final entry in picked) {
      final art = entry.artifact;
      final path = art.localPath.trim();
      if (path.isEmpty && art.url.isEmpty) continue;
      final result = await _export.save(
        title: art.title.isEmpty ? art.id : art.title,
        mimeType: art.mimeType,
        localPath: path,
        remoteUrl: art.url.isEmpty ? null : art.url,
      );
      if (result.success) ok++;
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$ok / ${picked.length} fail dihantar ke simpanan.')),
    );
  }

  Future<void> _shareOrOpenSelected() async {
    final picked = _items.where((e) => _selected.contains(e.key)).toList();
    if (picked.isEmpty) return;
    // Tanpa share_plus: buka fail supaya user boleh share dari sheet sistem.
    for (final entry in picked) {
      final path = entry.artifact.localPath.trim();
      if (path.isEmpty) continue;
      final f = File(path);
      if (await f.exists()) {
        await OpenFilex.open(path);
      }
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Fail dibuka — guna menu kongsi sistem jika perlu.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentSession = AppScope.of(context).sessionId;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.sessionIdOnly == null
              ? 'Perpustakaan Artifact'
              : 'Artifact sesi ini',
        ),
        actions: <Widget>[
          if (_items.isNotEmpty)
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'all') _selectAll();
                if (v == 'none') _unselectAll();
              },
              itemBuilder: (_) => const <PopupMenuEntry<String>>[
                PopupMenuItem(value: 'all', child: Text('Pilih semua')),
                PopupMenuItem(value: 'none', child: Text('Nyahpilih semua')),
              ],
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
                  child: Text(
                    widget.sessionIdOnly != null
                        ? 'Hanya artifact yang dibuat/diterima dalam sesi chat ini. '
                            'Chat lain tidak boleh akses item di sini.'
                        : 'Semua artifact mengikut sesi. Untuk guna dalam chat, buka sesi tersebut. '
                            'Chat baru tidak akses artifact sesi lain.',
                    style: const TextStyle(color: AppTheme.textSecondary, height: 1.4, fontSize: 13),
                  ),
                ),
                if (widget.sessionIdOnly == null)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: FilterChip(
                        label: Text(
                          _filterSessionId == null
                              ? 'Semua sesi'
                              : (_filterSessionId == currentSession
                                  ? 'Sesi semasa sahaja'
                                  : 'Sesi ditapis'),
                        ),
                        selected: _filterSessionId != null,
                        onSelected: (sel) {
                          setState(() {
                            _filterSessionId = sel ? currentSession : null;
                          });
                          _reload();
                        },
                      ),
                    ),
                  ),
                Expanded(
                  child: _items.isEmpty
                      ? const Center(
                          child: Text(
                            'Tiada artifact lagi.',
                            style: TextStyle(color: AppTheme.textMuted),
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 100),
                          itemCount: _items.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final item = _items[index];
                            final selected = _selected.contains(item.key);
                            final art = item.artifact;
                            return Material(
                              color: AppTheme.surface,
                              borderRadius: BorderRadius.circular(16),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(16),
                                onTap: () {
                                  setState(() {
                                    if (selected) {
                                      _selected.remove(item.key);
                                    } else {
                                      _selected.add(item.key);
                                    }
                                  });
                                },
                                onLongPress: () async {
                                  final path = art.localPath.trim();
                                  if (path.isNotEmpty && await File(path).exists()) {
                                    await OpenFilex.open(path);
                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(10, 10, 12, 10),
                                  child: Row(
                                    children: <Widget>[
                                      Checkbox(
                                        value: selected,
                                        onChanged: (v) {
                                          setState(() {
                                            if (v == true) {
                                              _selected.add(item.key);
                                            } else {
                                              _selected.remove(item.key);
                                            }
                                          });
                                        },
                                      ),
                                      Icon(
                                        _iconFor(art.kind),
                                        color: AppTheme.purpleLight,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              art.title.isEmpty ? art.kind.name : art.title,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(fontWeight: FontWeight.w700),
                                            ),
                                            const SizedBox(height: 2),
                                            Text(
                                              '${item.sessionTitle} · ${art.kind.name}'
                                              '${art.subtitle.isEmpty ? '' : ' · ${art.subtitle}'}',
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                color: AppTheme.textMuted,
                                                fontSize: 12,
                                              ),
                                            ),
                                            if (item.sessionId == currentSession)
                                              const Text(
                                                'Sesi semasa',
                                                style: TextStyle(
                                                  color: AppTheme.success,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      bottomNavigationBar: _selected.isEmpty
          ? null
          : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                decoration: const BoxDecoration(
                  color: Color(0xFF0E131C),
                  border: Border(top: BorderSide(color: Color(0xFF1C2433))),
                ),
                child: Row(
                  children: <Widget>[
                    Text(
                      '${_selected.length} dipilih',
                      style: const TextStyle(color: AppTheme.textSecondary),
                    ),
                    const Spacer(),
                    IconButton(
                      tooltip: 'Buka / kongsi',
                      onPressed: _shareOrOpenSelected,
                      icon: const Icon(Icons.ios_share_rounded),
                    ),
                    IconButton(
                      tooltip: 'Muat turun / simpan',
                      onPressed: _downloadSelected,
                      icon: const Icon(Icons.download_rounded),
                    ),
                    IconButton(
                      tooltip: 'Padam',
                      onPressed: _deleteSelected,
                      icon: const Icon(Icons.delete_outline_rounded, color: AppTheme.danger),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  IconData _iconFor(ArtifactKind kind) {
    return switch (kind) {
      ArtifactKind.image => Icons.image_outlined,
      ArtifactKind.video => Icons.videocam_outlined,
      ArtifactKind.audio => Icons.audiotrack_outlined,
      ArtifactKind.webpage || ArtifactKind.html => Icons.language_rounded,
      ArtifactKind.searchResults => Icons.search_rounded,
      ArtifactKind.file => Icons.insert_drive_file_outlined,
    };
  }
}

class _ArtifactEntry {
  const _ArtifactEntry({
    required this.key,
    required this.sessionId,
    required this.sessionTitle,
    required this.messageId,
    required this.createdAt,
    required this.artifact,
  });

  final String key;
  final String sessionId;
  final String sessionTitle;
  final String messageId;
  final DateTime createdAt;
  final ChatArtifact artifact;
}
