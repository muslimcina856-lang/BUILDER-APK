import 'package:flutter/material.dart';

import '../../app.dart';

class PersonalizationScreen extends StatefulWidget {
  const PersonalizationScreen({super.key});

  @override
  State<PersonalizationScreen> createState() => _PersonalizationScreenState();
}

class _PersonalizationScreenState extends State<PersonalizationScreen> {
  final _nickname = TextEditingController();
  final _instructions = TextEditingController();
  bool _saving = false;
  bool _seeded = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_seeded) return;
    _seeded = true;
    final state = AppScope.of(context);
    _nickname.text = state.userNickname;
    _instructions.text = state.customInstructions;
  }

  @override
  void dispose() {
    _nickname.dispose();
    _instructions.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pemeribadian'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simpan',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
        children: <Widget>[
          TextField(
            controller: _nickname,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Nama panggilan',
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _instructions,
            minLines: 8,
            maxLines: 16,
            decoration: const InputDecoration(
              labelText: 'Arahan tersuai',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    await AppScope.read(context).savePersonalization(
      nickname: _nickname.text,
      instructions: _instructions.text,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Pemeribadian disimpan.')),
    );
  }
}
