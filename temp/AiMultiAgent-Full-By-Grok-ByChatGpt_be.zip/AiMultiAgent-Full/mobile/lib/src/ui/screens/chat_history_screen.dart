import 'package:flutter/material.dart';

import '../../app.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';

class ChatHistoryScreen extends StatefulWidget {
  const ChatHistoryScreen({super.key});

  @override
  State<ChatHistoryScreen> createState() => _ChatHistoryScreenState();
}

class _ChatHistoryScreenState extends State<ChatHistoryScreen> {
  Future<List<Map<String, dynamic>>> _future =
      Future.value(const <Map<String, dynamic>>[]);
  int _retentionDays = 30;
  bool _ready = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_ready) return;
    _ready = true;
    _reload();
  }

  void _reload() {
    final state = AppScope.of(context);
    setState(() {
      _future = state.listChatSessions();
    });
    state.getChatHistoryRetentionDays().then((days) {
      if (mounted) setState(() => _retentionDays = days);
    });
  }

  String _formatTime(int ms) {
    if (ms <= 0) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Baru tadi';
    if (diff.inHours < 1) return '${diff.inMinutes} min lalu';
    if (diff.inDays < 1) return '${diff.inHours} jam lalu';
    if (diff.inDays < 7) return '${diff.inDays} hari lalu';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  Future<void> _pickRetention() async {
    final state = AppScope.of(context);
    final choice = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: AppTheme.surfaceHigh,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (context) {
        final options = <Map<String, int>>[
          {'label': 7, 'days': 7},
          {'label': 14, 'days': 14},
          {'label': 30, 'days': 30},
          {'label': 90, 'days': 90},
          {'label': 0, 'days': 0},
        ];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  'Auto-padam sejarah selepas',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
              for (final opt in options)
                ListTile(
                  title: Text(
                    opt['days'] == 0
                        ? 'Tiada (simpan selamanya)'
                        : '${opt['days']} hari',
                  ),
                  trailing: _retentionDays == opt['days']
                      ? const Icon(Icons.check_rounded, color: AppTheme.cyan)
                      : null,
                  onTap: () => Navigator.pop(context, opt['days']),
                ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (choice == null) return;
    await state.setChatHistoryRetentionDays(choice);
    if (!mounted) return;
    setState(() {
      _retentionDays = choice;
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sejarah chat'),
        actions: <Widget>[
          TextButton(
            onPressed: _pickRetention,
            child: Text(
              _retentionDays <= 0 ? 'Tiada padam' : '$_retentionDays hari',
              style: const TextStyle(color: AppTheme.cyan, fontSize: 13),
            ),
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final sessions = snapshot.data ?? const <Map<String, dynamic>>[];
          if (sessions.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Belum ada sejarah chat.\nSetiap perbualan auto-tersimpan di sini.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.textSecondary, height: 1.45),
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 40),
            itemCount: sessions.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = sessions[index];
              final id = item['id']?.toString() ?? '';
              final title = item['title']?.toString() ?? 'Chat';
              final count = item['message_count'] as int? ?? 0;
              final updated = item['updated_at'] as int? ?? 0;
              final isActive = id == state.sessionId;
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  leading: Icon(
                    isActive
                        ? Icons.chat_bubble_rounded
                        : Icons.chat_bubble_outline_rounded,
                    color: isActive ? AppTheme.cyan : AppTheme.textSecondary,
                  ),
                  title: Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    '${_formatTime(updated)} · $count mesej'
                    '${isActive ? ' · aktif' : ''}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline_rounded, size: 20),
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Padam chat?'),
                          content: Text('Padam "$title"?'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: const Text('Batal'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context, true),
                              child: const Text('Padam'),
                            ),
                          ],
                        ),
                      );
                      if (ok != true) return;
                      await state.deleteChatSession(id);
                      if (!mounted) return;
                      setState(_reload);
                    },
                  ),
                  onTap: () async {
                    await state.openSession(id);
                    if (!context.mounted) return;
                    Navigator.of(context).pop();
                  },
                  onLongPress: () => _renameSession(context, state, id, title),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _renameSession(
    BuildContext context,
    AppState state,
    String id,
    String current,
  ) async {
    final controller = TextEditingController(text: current);
    final next = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Namakan semula'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textInputAction: TextInputAction.done,
          onSubmitted: (value) => Navigator.pop(context, value),
          decoration: const InputDecoration(labelText: 'Nama chat'),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (next == null || next.trim().isEmpty) return;
    await state.renameChatSession(id, next);
    if (mounted) setState(_reload);
  }
}
