import 'dart:io';

import 'package:ai_multiagent/src/services/file_write_coordinator.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late Directory workspace;
  late FileWriteCoordinator coordinator;

  setUp(() async {
    workspace = await Directory.systemTemp.createTemp('ai-write-test-');
    coordinator = FileWriteCoordinator(workspace);
  });

  tearDown(() async {
    if (await workspace.exists()) {
      await workspace.delete(recursive: true);
    }
  });

  test('small file is committed atomically', () async {
    final target = File('${workspace.path}/index.html');
    final result = await coordinator.begin(
      ownerId: 'run-1',
      target: target,
      relativePath: 'index.html',
      content: '<!doctype html><title>Siap</title>',
      done: true,
    );

    expect(result.committed, isTrue);
    expect(await target.readAsString(), contains('<title>Siap</title>'));
    expect(result.sha256, isNotEmpty);
  });

  test('staged chunks require sequence and deduplicate identical retry', () async {
    final target = File('${workspace.path}/app.js');
    final first = await coordinator.begin(
      ownerId: 'run-1',
      target: target,
      relativePath: 'app.js',
      content: 'const a = 1;\n',
      done: false,
    );

    expect(await target.exists(), isFalse);
    final second = await coordinator.append(
      ownerId: 'run-1',
      writeId: first.writeId,
      sequence: 1,
      content: 'const b = 2;\n',
    );
    final duplicate = await coordinator.append(
      ownerId: 'run-1',
      writeId: first.writeId,
      sequence: 1,
      content: 'const b = 2;\n',
    );

    expect(duplicate.bytes, second.bytes);
    final committed = await coordinator.commit(
      ownerId: 'run-1',
      writeId: first.writeId,
      expectedBytes: second.bytes,
    );
    expect(committed.committed, isTrue);
    expect(await target.readAsString(), 'const a = 1;\nconst b = 2;\n');
  });

  test('wrong sequence cannot corrupt staged content', () async {
    final first = await coordinator.begin(
      ownerId: 'run-1',
      target: File('${workspace.path}/app.js'),
      relativePath: 'app.js',
      content: 'first\n',
      done: false,
    );

    expect(
      () => coordinator.append(
        ownerId: 'run-1',
        writeId: first.writeId,
        sequence: 3,
        content: 'wrong\n',
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'SEQUENCE_MISMATCH',
        ),
      ),
    );
  });

  test('overwrite requires matching base hash and preserves original', () async {
    final target = File('${workspace.path}/data.json');
    await target.writeAsString('{"old":true}');

    expect(
      () => coordinator.begin(
        ownerId: 'run-1',
        target: target,
        relativePath: 'data.json',
        content: '{"new":true}',
        overwrite: true,
        baseSha256: 'wrong',
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'VERSION_CONFLICT',
        ),
      ),
    );
    expect(await target.readAsString(), '{"old":true}');
  });

  test('atomic replace requires current hash and updates valid content', () async {
    final target = File('${workspace.path}/data.json');
    await target.writeAsString('{"old":true}');
    final baseHash = await FileWriteCoordinator.sha256File(target);

    final result = await coordinator.atomicReplace(
      target: target,
      relativePath: 'data.json',
      content: '{"new":true}',
      baseSha256: baseHash,
    );

    expect(result.committed, isTrue);
    expect(await target.readAsString(), '{"new":true}');
  });

  test('invalid JSON is never committed', () async {
    final target = File('${workspace.path}/data.json');
    final staged = await coordinator.begin(
      ownerId: 'run-1',
      target: target,
      relativePath: 'data.json',
      content: '{"unfinished":',
      done: false,
    );

    expect(
      () => coordinator.commit(
        ownerId: 'run-1',
        writeId: staged.writeId,
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'FORMAT_INVALID',
        ),
      ),
    );
    expect(await target.exists(), isFalse);
  });

  test('failed immediate commit releases path for a clean retry', () async {
    final target = File('${workspace.path}/retry.json');

    await expectLater(
      coordinator.begin(
        ownerId: 'run-1',
        target: target,
        relativePath: 'retry.json',
        content: '{"unfinished":',
        done: true,
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'FORMAT_INVALID',
        ),
      ),
    );

    final retried = await coordinator.begin(
      ownerId: 'run-1',
      target: target,
      relativePath: 'retry.json',
      content: '{"ready":true}',
      done: true,
    );
    expect(retried.committed, isTrue);
    expect(await target.readAsString(), '{"ready":true}');
  });

  test('empty and oversized chunks are rejected', () async {
    final target = File('${workspace.path}/large.txt');
    expect(
      () => coordinator.begin(
        ownerId: 'run-1',
        target: target,
        relativePath: 'large.txt',
        content: '',
      ),
      throwsA(isA<FileWriteException>()),
    );
    expect(
      () => coordinator.begin(
        ownerId: 'run-1',
        target: target,
        relativePath: 'large.txt',
        content: List<String>.filled(
          FileWriteCoordinator.maxChunkBytes + 1,
          'a',
        ).join(),
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'PAYLOAD_TOO_LARGE',
        ),
      ),
    );
  });

  test('a second writer cannot claim an active path', () async {
    await coordinator.begin(
      ownerId: 'run-1',
      target: File('${workspace.path}/shared.txt'),
      relativePath: 'shared.txt',
      content: 'first',
      done: false,
    );

    expect(
      () => coordinator.begin(
        ownerId: 'run-2',
        target: File('${workspace.path}/shared.txt'),
        relativePath: 'shared.txt',
        content: 'second',
        done: false,
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'FILE_BUSY',
        ),
      ),
    );
  });

  test('legacy path append remains atomic for existing and new files', () async {
    final existing = File('${workspace.path}/legacy.txt');
    await existing.writeAsString('first');

    final appended = await coordinator.appendExisting(
      ownerId: 'run-1',
      target: existing,
      relativePath: 'legacy.txt',
      content: '-second',
    );
    final created = await coordinator.appendExisting(
      ownerId: 'run-1',
      target: File('${workspace.path}/created.txt'),
      relativePath: 'created.txt',
      content: 'created',
    );

    expect(appended.committed, isTrue);
    expect(await existing.readAsString(), 'first-second');
    expect(created.committed, isTrue);
    expect(
      await File('${workspace.path}/created.txt').readAsString(),
      'created',
    );
  });

  test('path mutex cache is released after completed operations', () async {
    for (var index = 0; index < 25; index++) {
      await coordinator.begin(
        ownerId: 'run-1',
        target: File('${workspace.path}/lock-$index.txt'),
        relativePath: 'lock-$index.txt',
        content: 'value',
        done: true,
      );
    }

    expect(coordinator.activeLockCount, 0);
  });

  test('concurrent legacy appends are serialized without lost content', () async {
    final target = File('${workspace.path}/concurrent.txt');
    await target.writeAsString('base');

    await Future.wait(<Future<FileWriteSnapshot>>[
      coordinator.appendExisting(
        ownerId: 'run-1',
        target: target,
        relativePath: 'concurrent.txt',
        content: '-one',
      ),
      coordinator.appendExisting(
        ownerId: 'run-2',
        target: target,
        relativePath: 'concurrent.txt',
        content: '-two',
      ),
    ]);

    final content = await target.readAsString();
    expect(content, startsWith('base'));
    expect('-one'.allMatches(content).length, 1);
    expect('-two'.allMatches(content).length, 1);
    expect(coordinator.activeLockCount, 0);
  });

  test('legacy append supports a file beyond the former 16 MiB cap', () async {
    final target = File('${workspace.path}/large-existing.txt');
    final sink = target.openWrite();
    final block = List<int>.filled(4096, 97);
    for (var index = 0; index < 4097; index++) {
      sink.add(block);
    }
    await sink.close();

    final before = await target.length();
    final result = await coordinator.appendExisting(
      ownerId: 'run-1',
      target: target,
      relativePath: 'large-existing.txt',
      content: 'b',
    );

    expect(before, greaterThan(16 * 1024 * 1024));
    expect(result.bytes, before + 1);
    expect(await target.length(), before + 1);
  });

  test('different append is rejected after commit', () async {
    final first = await coordinator.begin(
      ownerId: 'run-1',
      target: File('${workspace.path}/done.txt'),
      relativePath: 'done.txt',
      content: 'first',
      done: false,
    );
    await coordinator.append(
      ownerId: 'run-1',
      writeId: first.writeId,
      sequence: 1,
      content: 'second',
      done: true,
    );

    expect(
      () => coordinator.append(
        ownerId: 'run-1',
        writeId: first.writeId,
        sequence: 2,
        content: 'third',
      ),
      throwsA(
        isA<FileWriteException>().having(
          (error) => error.code,
          'code',
          'WRITE_ALREADY_COMMITTED',
        ),
      ),
    );
  });

  test('restart removes an unjournaled append tail', () async {
    final first = await coordinator.begin(
      ownerId: 'run-1',
      target: File('${workspace.path}/resume.txt'),
      relativePath: 'resume.txt',
      content: 'safe',
      done: false,
    );
    final staging = Directory('${workspace.path}/.write_staging');
    final part = await staging
        .list()
        .where((entity) => entity is File && entity.path.endsWith('.part'))
        .cast<File>()
        .first;
    await part.writeAsString('orphan', mode: FileMode.append, flush: true);

    final restarted = FileWriteCoordinator(workspace);
    final status = await restarted.status(
      ownerId: 'run-1',
      writeId: first.writeId,
    );
    expect(status.bytes, 4);
    await restarted.commit(ownerId: 'run-1', writeId: first.writeId);
    expect(
      await File('${workspace.path}/resume.txt').readAsString(),
      'safe',
    );
  });
}
