#!/usr/bin/env python3
"""Download, verify and assemble the bundled ARM64 Linux runtime.

The resulting ZIP is a Flutter asset consumed by LinuxWorkspaceService. The
script deliberately uses only Python's standard library so release builds and
CI do not need extra Python packages.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

RUNTIME_SCHEMA = 1
RUNTIME_VERSION = "1.0.0-alpine-3.24.1-proot-0.15"
ALPINE_VERSION = "3.24.1"
ALPINE_BRANCH = "v3.24"
ALPINE_ARCHIVE = f"alpine-minirootfs-{ALPINE_VERSION}-aarch64.tar.gz"
ALPINE_URL = (
    f"https://dl-cdn.alpinelinux.org/alpine/{ALPINE_BRANCH}/releases/"
    f"aarch64/{ALPINE_ARCHIVE}"
)
ALPINE_SHA256 = "f55a90f69052c5bd6f92cb09a8f47065970830b194c917a006fb94028e721259"
PROOT_COMMIT = "01f83b8841358450c78333d1b33ab30d4943bec4"
PROOT_ARCHIVE = "proot-android-aarch64.tar.gz"
PROOT_URL = (
    "https://raw.githubusercontent.com/green-green-avk/build-proot-android/"
    f"{PROOT_COMMIT}/packages/{PROOT_ARCHIVE}"
)
# The commit-pinned archive is 175 KiB. GitHub may vary HTTP encoding but the
# decoded file itself must keep this exact size. Its SHA-256 is recorded in the
# generated manifest and can additionally be enforced with --proot-sha256.
PROOT_EXPECTED_SIZE = 179448
MAX_DOWNLOAD_BYTES = 64 * 1024 * 1024
MAX_PACK_BYTES = 512 * 1024 * 1024
MAX_EXTRACTED_BYTES = 2 * 1024 * 1024 * 1024
MAX_PACK_ENTRIES = 100_000
MAX_SINGLE_ENTRY_BYTES = 512 * 1024 * 1024
MAX_SYMLINK_TARGET_BYTES = 4096
MAX_SOURCE_ARCHIVE_ENTRIES = 100_000
MAX_SOURCE_EXTRACTED_BYTES = 2 * 1024 * 1024 * 1024
MAX_SOURCE_SINGLE_ENTRY_BYTES = 512 * 1024 * 1024
USER_AGENT = "AiMultiAgent-LinuxRuntimeBuilder/1.0"


class RuntimeBuildError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, destination: Path, *, offline: bool, force: bool) -> Path:
    if destination.is_file() and destination.stat().st_size > 0 and not force:
        return destination
    if offline:
        raise RuntimeBuildError(f"Cache offline tiada: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    if partial.exists():
        partial.unlink()
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=90) as response, partial.open("wb") as output:
                total = 0
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    total += len(block)
                    if total > MAX_DOWNLOAD_BYTES:
                        raise RuntimeBuildError(f"Muat turun melebihi had: {url}")
                    output.write(block)
            partial.replace(destination)
            return destination
        except (OSError, urllib.error.URLError, RuntimeBuildError) as error:
            last_error = error
            if partial.exists():
                partial.unlink()
            if attempt < 2:
                time.sleep(2 ** attempt)
    # Sesetengah panel build menetapkan proxy/TLS hanya untuk curl atau wget.
    # Gunakan alat sistem sebagai fallback supaya build terus daripada Flutter
    # tidak gagal hanya kerana urllib tidak mewarisi konfigurasi rangkaian itu.
    external_commands: list[list[str]] = []
    if shutil.which("curl"):
        external_commands.append(
            [
                "curl",
                "--fail",
                "--location",
                "--retry",
                "3",
                "--retry-delay",
                "1",
                "--connect-timeout",
                "30",
                "--max-time",
                "300",
                "--output",
                str(partial),
                url,
            ]
        )
    if shutil.which("wget"):
        external_commands.append(
            [
                "wget",
                "--tries=3",
                "--timeout=90",
                "--output-document",
                str(partial),
                url,
            ]
        )

    external_errors: list[str] = []
    for command in external_commands:
        partial.unlink(missing_ok=True)
        result = subprocess.run(command, check=False)
        if result.returncode == 0 and partial.is_file():
            size = partial.stat().st_size
            if 0 < size <= MAX_DOWNLOAD_BYTES:
                partial.replace(destination)
                return destination
            external_errors.append(
                f"{command[0]} menghasilkan saiz tidak sah: {size} bait"
            )
        else:
            external_errors.append(f"{command[0]} exit={result.returncode}")
        partial.unlink(missing_ok=True)

    details = "; ".join(external_errors) if external_errors else "curl/wget tiada"
    raise RuntimeBuildError(
        f"Gagal memuat turun {url}: urllib={last_error}; fallback={details}"
    )


def verify_downloads(alpine: Path, proot: Path, proot_sha256: str | None) -> tuple[str, str]:
    alpine_digest = sha256_file(alpine)
    if alpine_digest != ALPINE_SHA256:
        raise RuntimeBuildError(
            f"SHA-256 Alpine tidak sepadan: {alpine_digest} != {ALPINE_SHA256}"
        )
    if proot.stat().st_size != PROOT_EXPECTED_SIZE:
        raise RuntimeBuildError(
            f"Saiz PRoot tidak sepadan: {proot.stat().st_size} != {PROOT_EXPECTED_SIZE}"
        )
    proot_digest = sha256_file(proot)
    if proot_sha256 and proot_digest.lower() != proot_sha256.lower():
        raise RuntimeBuildError(
            f"SHA-256 PRoot tidak sepadan: {proot_digest} != {proot_sha256}"
        )
    return alpine_digest, proot_digest


def safe_member_path(name: str) -> PurePosixPath:
    normalized = PurePosixPath(name.replace("\\", "/"))
    if normalized.is_absolute() or ".." in normalized.parts:
        raise RuntimeBuildError(f"Arkib mengandungi laluan tidak selamat: {name}")
    parts = tuple(part for part in normalized.parts if part not in ("", "."))
    if not parts:
        raise RuntimeBuildError(f"Nama entri arkib tidak sah: {name}")
    return PurePosixPath(*parts)


def safe_extract_tar(
    archive: Path,
    destination: Path,
    *,
    allow_absolute_symlinks: bool,
) -> None:
    """Extract tar without trusting tarfile.extractall path/link handling."""
    destination.mkdir(parents=True, exist_ok=True)
    pending_links: list[tuple[Path, str, bool]] = []
    directory_modes: list[tuple[Path, int]] = []
    seen_members: set[str] = set()
    extracted_bytes = 0
    entry_count = 0
    with tarfile.open(archive, "r:gz") as tf:
        for member in tf:
            raw_name = member.name.replace("\\", "/")
            if raw_name in ("", ".", "./"):
                continue
            entry_count += 1
            if entry_count > MAX_SOURCE_ARCHIVE_ENTRIES:
                raise RuntimeBuildError("Arkib sumber mempunyai terlalu banyak entri.")
            if member.size < 0 or member.size > MAX_SOURCE_SINGLE_ENTRY_BYTES:
                raise RuntimeBuildError(f"Entri arkib sumber terlalu besar: {member.name}")
            extracted_bytes += member.size
            if extracted_bytes > MAX_SOURCE_EXTRACTED_BYTES:
                raise RuntimeBuildError("Saiz ekstrak arkib sumber melebihi had keselamatan.")
            rel = safe_member_path(raw_name)
            rel_name = rel.as_posix()
            if rel_name in seen_members:
                raise RuntimeBuildError(f"Arkib sumber mengandungi entri berganda: {member.name}")
            seen_members.add(rel_name)
            target = destination.joinpath(*rel.parts)
            if member.isdev() or member.isfifo() or member.issparse():
                raise RuntimeBuildError(f"Jenis fail arkib tidak dibenarkan: {member.name}")
            target.parent.mkdir(parents=True, exist_ok=True)

            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                directory_modes.append((target, stat.S_IMODE(member.mode) or 0o755))
                continue

            if member.issym():
                link_target = member.linkname.replace("\\", "/")
                if not link_target:
                    raise RuntimeBuildError(f"Symlink kosong: {member.name}")
                link = PurePosixPath(link_target)
                if link.is_absolute():
                    if not allow_absolute_symlinks:
                        raise RuntimeBuildError(
                            f"Symlink mutlak tidak dibenarkan: {member.name} -> {link_target}"
                        )
                else:
                    depth = 0
                    for part in (*rel.parent.parts, *link.parts):
                        if part in ("", "."):
                            continue
                        depth += -1 if part == ".." else 1
                        if depth < 0:
                            raise RuntimeBuildError(
                                f"Symlink keluar daripada arkib: {member.name} -> {link_target}"
                            )
                pending_links.append((target, link_target, False))
                continue

            if member.islnk():
                hard_rel = safe_member_path(member.linkname)
                hard_target = destination.joinpath(*hard_rel.parts)
                pending_links.append((target, str(hard_target), True))
                continue

            if not member.isfile():
                raise RuntimeBuildError(f"Jenis entri tar tidak disokong: {member.name}")
            source = tf.extractfile(member)
            if source is None:
                raise RuntimeBuildError(f"Kandungan fail tar tiada: {member.name}")
            with source, target.open("wb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            target.chmod(stat.S_IMODE(member.mode) or 0o644)

    for target, link_target, hard_link in pending_links:
        if target.exists() or target.is_symlink():
            target.unlink()
        if hard_link:
            hard_path = Path(link_target)
            if not hard_path.exists() or not hard_path.is_file():
                raise RuntimeBuildError(f"Sasaran hardlink tiada: {target} -> {hard_path}")
            os.link(hard_path, target)
        else:
            os.symlink(link_target, target)

    for directory, mode in sorted(
        directory_modes, key=lambda item: len(item[0].parts), reverse=True
    ):
        directory.chmod(mode)


def locate_proot_root(extracted: Path) -> Path:
    candidates = sorted(extracted.glob("**/bin/proot"))
    if len(candidates) != 1:
        raise RuntimeBuildError(
            f"Arkib PRoot mesti mempunyai satu bin/proot; ditemui {len(candidates)}"
        )
    return candidates[0].parent.parent


def validate_arm64_elf(path: Path) -> None:
    header = path.read_bytes()[:20]
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise RuntimeBuildError(f"Bukan binary ELF: {path}")
    if header[4] != 2 or header[5] != 1:
        raise RuntimeBuildError(f"ELF bukan 64-bit little-endian: {path}")
    machine = int.from_bytes(header[18:20], "little")
    if machine != 183:
        raise RuntimeBuildError(f"ELF bukan AArch64 (e_machine={machine}): {path}")


def copy_tree(source: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(source, destination, symlinks=True)


def configure_rootfs(stage: Path, licenses_dir: Path) -> None:
    rootfs = stage / "rootfs"
    (rootfs / "etc/apk").mkdir(parents=True, exist_ok=True)
    (rootfs / "etc/apk/repositories").write_text(
        "\n".join(
            [
                f"https://dl-cdn.alpinelinux.org/alpine/{ALPINE_BRANCH}/main",
                f"https://dl-cdn.alpinelinux.org/alpine/{ALPINE_BRANCH}/community",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (rootfs / "etc/hostname").write_text("ai-multiagent\n", encoding="utf-8")
    (rootfs / "etc/hosts").write_text(
        "127.0.0.1 localhost ai-multiagent\n::1 localhost ip6-localhost\n",
        encoding="utf-8",
    )
    (rootfs / "etc/resolv.conf").write_text(
        "nameserver 1.1.1.1\nnameserver 8.8.8.8\noptions timeout:2 attempts:3\n",
        encoding="utf-8",
    )
    (rootfs / "etc/motd").write_text(
        "Ai MultiAgent Full - Alpine Linux ARM64 (PRoot sandbox)\n",
        encoding="utf-8",
    )
    profile_dir = rootfs / "etc/profile.d"
    profile_dir.mkdir(parents=True, exist_ok=True)
    profile = profile_dir / "ai-multiagent.sh"
    profile.write_text(
        "export HOME=/root\n"
        "export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n"
        "export LANG=C.UTF-8\n"
        "export PAGER=cat\n",
        encoding="utf-8",
    )
    profile.chmod(0o644)

    home = stage / "home"
    home.mkdir(parents=True, exist_ok=True)
    (home / ".profile").write_text(
        ". /etc/profile 2>/dev/null || true\n"
        "cd /workspace 2>/dev/null || true\n",
        encoding="utf-8",
    )
    (home / "README.txt").write_text(
        "Workspace projek: /workspace\nPengurus pakej: apk\nContoh: apk update && apk add git python3\n",
        encoding="utf-8",
    )

    target = stage / "runtime/licenses"
    target.mkdir(parents=True, exist_ok=True)
    for license_file in sorted(licenses_dir.glob("*.txt")):
        shutil.copy2(license_file, target / license_file.name)


def make_manifest(alpine_digest: str, proot_digest: str) -> dict[str, object]:
    return {
        "schema": RUNTIME_SCHEMA,
        "runtime_version": RUNTIME_VERSION,
        "architecture": "aarch64",
        "android_abi": "arm64-v8a",
        "distribution": "Alpine Linux",
        "distribution_version": ALPINE_VERSION,
        "package_manager": "apk",
        "shell": "/bin/sh",
        "proot_version": "0.15",
        "delivery": "embedded_flutter_asset",
        "sources": {
            "alpine_url": ALPINE_URL,
            "alpine_sha256": alpine_digest,
            "proot_url": PROOT_URL,
            "proot_commit": PROOT_COMMIT,
            "proot_sha256": proot_digest,
            "proot_size": PROOT_EXPECTED_SIZE,
        },
    }


def write_asset_metadata(
    output: Path,
    manifest: dict[str, object],
    *,
    reused: bool,
) -> dict[str, object]:
    digest = sha256_file(output)
    asset_dir = output.parent
    asset_dir.mkdir(parents=True, exist_ok=True)
    (asset_dir / "runtime-pack.sha256").write_text(
        f"{digest}  {output.name}\n", encoding="utf-8"
    )
    (asset_dir / "runtime-manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    build_info = {
        "output": str(output),
        "output_bytes": output.stat().st_size,
        "output_sha256": digest,
        "reused_existing_pack": reused,
        "manifest": manifest,
    }
    (asset_dir / "runtime-build-info.json").write_text(
        json.dumps(build_info, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return build_info


def zip_info(name: str, mode: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name)
    info.create_system = 3
    info.external_attr = (mode & 0xFFFF) << 16
    return info


def add_path(zf: zipfile.ZipFile, path: Path, arcname: str) -> None:
    mode = path.lstat().st_mode
    if path.is_symlink():
        info = zip_info(arcname, stat.S_IFLNK | 0o777)
        zf.writestr(info, os.readlink(path).encode("utf-8"), zipfile.ZIP_STORED)
    elif path.is_dir():
        info = zip_info(arcname.rstrip("/") + "/", stat.S_IFDIR | stat.S_IMODE(mode))
        zf.writestr(info, b"", zipfile.ZIP_STORED)
    elif path.is_file():
        info = zip_info(arcname, stat.S_IFREG | stat.S_IMODE(mode))
        with path.open("rb") as handle:
            zf.writestr(info, handle.read(), zipfile.ZIP_DEFLATED)


def create_pack(stage: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".part")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", allowZip64=True) as zf:
        for top in ("runtime", "rootfs", "home"):
            base = stage / top
            add_path(zf, base, f"{top}/")
            for path in sorted(base.rglob("*")):
                add_path(zf, path, f"{top}/{path.relative_to(base).as_posix()}")
    temporary.replace(output)


def _zip_mode(info: zipfile.ZipInfo) -> int:
    return (info.external_attr >> 16) & 0xFFFF


def _validate_zip_symlink(name: str, target_bytes: bytes) -> None:
    if not target_bytes or len(target_bytes) > MAX_SYMLINK_TARGET_BYTES:
        raise RuntimeBuildError(f"Sasaran symlink ZIP tidak sah: {name}")
    try:
        target = target_bytes.decode("utf-8")
    except UnicodeDecodeError as error:
        raise RuntimeBuildError(f"Sasaran symlink ZIP bukan UTF-8: {name}") from error
    normalized = target.replace("\\", "/")
    if not normalized or "\x00" in normalized:
        raise RuntimeBuildError(f"Sasaran symlink ZIP kosong/tidak sah: {name}")

    lower = normalized.lower()
    blocked = (
        "/sdcard",
        "/storage",
        "/mnt/media_rw",
        "/data/media",
        "/data/user",
        "/data/data",
    )
    if any(lower == root or lower.startswith(root + "/") for root in blocked):
        raise RuntimeBuildError(f"Symlink ZIP menunjuk storan Android: {name} -> {target}")

    link = safe_member_path(name)
    target_path = PurePosixPath(normalized)
    if target_path.is_absolute():
        if not link.parts or link.parts[0] != "rootfs":
            raise RuntimeBuildError(
                f"Symlink mutlak hanya dibenarkan dalam rootfs: {name} -> {target}"
            )
        return

    depth = 0
    for part in (*link.parent.parts, *target_path.parts):
        if part in ("", "."):
            continue
        depth += -1 if part == ".." else 1
        if depth < 0:
            raise RuntimeBuildError(f"Symlink ZIP keluar sandbox: {name} -> {target}")


def verify_pack(
    path: Path,
    *,
    require_pinned_sources: bool = True,
) -> dict[str, object]:
    if not path.is_file() or path.stat().st_size <= 0:
        raise RuntimeBuildError(f"Runtime pack tiada atau kosong: {path}")
    if path.stat().st_size > MAX_PACK_BYTES:
        raise RuntimeBuildError(f"Runtime pack melebihi had {MAX_PACK_BYTES} bait: {path}")
    with zipfile.ZipFile(path, "r") as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeBuildError(f"CRC ZIP gagal pada {bad}")
        infos = zf.infolist()
        if len(infos) > MAX_PACK_ENTRIES:
            raise RuntimeBuildError("Runtime pack mempunyai terlalu banyak entri.")
        raw_names = [info.filename for info in infos]
        if len(raw_names) != len(set(raw_names)):
            raise RuntimeBuildError("Runtime pack mengandungi nama entri berganda.")

        total_size = 0
        for info in infos:
            raw_name = info.filename.rstrip("/")
            safe_member_path(raw_name)
            if info.file_size < 0 or info.file_size > MAX_SINGLE_ENTRY_BYTES:
                raise RuntimeBuildError(f"Entri ZIP terlalu besar: {info.filename}")
            total_size += info.file_size
            if total_size > MAX_EXTRACTED_BYTES:
                raise RuntimeBuildError("Saiz ekstrak runtime pack melebihi had keselamatan.")

            mode = _zip_mode(info)
            file_type = stat.S_IFMT(mode)
            if info.is_dir():
                if file_type not in (0, stat.S_IFDIR):
                    raise RuntimeBuildError(f"Jenis direktori ZIP tidak sah: {info.filename}")
                continue
            if file_type == stat.S_IFLNK:
                _validate_zip_symlink(raw_name, zf.read(info))
            elif file_type not in (0, stat.S_IFREG):
                raise RuntimeBuildError(f"Jenis entri ZIP tidak disokong: {info.filename}")

        names = set(raw_names)
        required = {
            "runtime/bin/proot",
            "runtime/manifest.json",
            "rootfs/bin/sh",
            "rootfs/sbin/apk",
            "rootfs/usr/bin/env",
            "rootfs/etc/alpine-release",
        }
        missing = sorted(required - names)
        if missing:
            raise RuntimeBuildError(f"Runtime pack tidak lengkap: {', '.join(missing)}")

        proot_info = zf.getinfo("runtime/bin/proot")
        proot_mode = _zip_mode(proot_info)
        if stat.S_IFMT(proot_mode) != stat.S_IFREG or not (proot_mode & 0o111):
            raise RuntimeBuildError("Binary PRoot mesti fail biasa dan executable.")

        manifest = json.loads(zf.read("runtime/manifest.json"))
        if manifest.get("schema") != RUNTIME_SCHEMA:
            raise RuntimeBuildError("Schema manifest runtime tidak disokong.")
        if manifest.get("runtime_version") != RUNTIME_VERSION:
            raise RuntimeBuildError("Versi manifest runtime tidak tepat.")
        if manifest.get("architecture") != "aarch64":
            raise RuntimeBuildError("Arkitektur manifest bukan aarch64.")
        if manifest.get("android_abi") != "arm64-v8a":
            raise RuntimeBuildError("ABI Android manifest bukan arm64-v8a.")
        if manifest.get("distribution") != "Alpine Linux":
            raise RuntimeBuildError("Distribution manifest bukan Alpine Linux.")
        if manifest.get("distribution_version") != ALPINE_VERSION:
            raise RuntimeBuildError("Versi Alpine manifest tidak tepat.")
        if manifest.get("package_manager") != "apk" or manifest.get("shell") != "/bin/sh":
            raise RuntimeBuildError("Kontrak shell/package manager runtime tidak tepat.")
        sources = manifest.get("sources")
        if not isinstance(sources, dict):
            raise RuntimeBuildError("Metadata sumber runtime tiada atau tidak sah.")
        if require_pinned_sources:
            expected_sources = {
                "alpine_url": ALPINE_URL,
                "alpine_sha256": ALPINE_SHA256,
                "proot_url": PROOT_URL,
                "proot_commit": PROOT_COMMIT,
                "proot_size": PROOT_EXPECTED_SIZE,
            }
            for key, expected in expected_sources.items():
                if sources.get(key) != expected:
                    raise RuntimeBuildError(
                        f"Metadata sumber runtime tidak tepat: {key}"
                    )
        proot_digest = sources.get("proot_sha256")
        if (
            not isinstance(proot_digest, str)
            or len(proot_digest) != 64
            or any(char not in "0123456789abcdefABCDEF" for char in proot_digest)
        ):
            raise RuntimeBuildError("SHA-256 PRoot dalam manifest tidak sah.")
        release = zf.read("rootfs/etc/alpine-release").decode("utf-8").strip()
        if release != ALPINE_VERSION:
            raise RuntimeBuildError(f"Rootfs bukan Alpine {ALPINE_VERSION}: {release}")
        proot = zf.read("runtime/bin/proot")
        if proot[:4] != b"\x7fELF" or len(proot) < 20:
            raise RuntimeBuildError("Binary PRoot dalam ZIP bukan ELF.")
        if proot[4] != 2 or proot[5] != 1:
            raise RuntimeBuildError("Binary PRoot dalam ZIP bukan ELF64 little-endian.")
        if int.from_bytes(proot[18:20], "little") != 183:
            raise RuntimeBuildError("Binary PRoot dalam ZIP bukan AArch64.")
        return manifest


def build(args: argparse.Namespace) -> None:
    root = Path(__file__).resolve().parents[2]
    cache = args.cache_dir.resolve()
    output = args.output.resolve()
    if args.verify_only:
        manifest = verify_pack(output)
        print(json.dumps({"verified": str(output), "manifest": manifest}, indent=2))
        return

    if output.is_file() and not args.force_download and not args.force_rebuild:
        try:
            manifest = verify_pack(output)
            sources = manifest.get("sources")
            if (
                args.proot_sha256
                and isinstance(sources, dict)
                and str(sources.get("proot_sha256", "")).lower()
                != args.proot_sha256.lower()
            ):
                raise RuntimeBuildError(
                    "Runtime sedia ada tidak sepadan dengan --proot-sha256."
                )
            build_info = write_asset_metadata(output, manifest, reused=True)
            print(json.dumps(build_info, indent=2, sort_keys=True))
            return
        except (RuntimeBuildError, OSError, zipfile.BadZipFile, json.JSONDecodeError):
            output.unlink(missing_ok=True)
            for sidecar in (
                output.parent / "runtime-pack.sha256",
                output.parent / "runtime-manifest.json",
                output.parent / "runtime-build-info.json",
            ):
                sidecar.unlink(missing_ok=True)

    alpine = download(
        ALPINE_URL,
        cache / ALPINE_ARCHIVE,
        offline=args.offline,
        force=args.force_download,
    )
    proot = download(
        PROOT_URL,
        cache / PROOT_ARCHIVE,
        offline=args.offline,
        force=args.force_download,
    )
    try:
        alpine_digest, proot_digest = verify_downloads(
            alpine, proot, args.proot_sha256
        )
    except RuntimeBuildError:
        if args.offline or args.force_download:
            raise
        # Cache separa/terpotong tidak boleh menyebabkan build kekal rosak.
        alpine.unlink(missing_ok=True)
        proot.unlink(missing_ok=True)
        alpine = download(
            ALPINE_URL, cache / ALPINE_ARCHIVE, offline=False, force=True
        )
        proot = download(
            PROOT_URL, cache / PROOT_ARCHIVE, offline=False, force=True
        )
        alpine_digest, proot_digest = verify_downloads(
            alpine, proot, args.proot_sha256
        )

    licenses = root / "scripts/linux/licenses"
    with tempfile.TemporaryDirectory(prefix="ai-linux-runtime-") as temp_name:
        temp = Path(temp_name)
        proot_extract = temp / "proot-source"
        stage = temp / "stage"
        safe_extract_tar(
            proot, proot_extract, allow_absolute_symlinks=False
        )
        safe_extract_tar(
            alpine, stage / "rootfs", allow_absolute_symlinks=True
        )
        proot_root = locate_proot_root(proot_extract)
        copy_tree(proot_root, stage / "runtime")
        proot_binary = stage / "runtime/bin/proot"
        proot_binary.chmod(0o700)
        validate_arm64_elf(proot_binary)
        shell = stage / "rootfs/bin/sh"
        if not shell.exists() and not shell.is_symlink():
            raise RuntimeBuildError("Alpine rootfs tidak mempunyai bin/sh.")
        configure_rootfs(stage, licenses)
        manifest = make_manifest(alpine_digest, proot_digest)
        manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
        (stage / "runtime/manifest.json").write_bytes(manifest_bytes)
        create_pack(stage, output)

    verified = verify_pack(output)
    build_info = write_asset_metadata(output, verified, reused=False)
    print(json.dumps(build_info, indent=2, sort_keys=True))


def parse_args() -> argparse.Namespace:
    project_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(
        description="Sediakan Alpine ARM64 + PRoot sebagai asset runtime Full."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=project_root / "mobile/assets/linux/full/runtime-pack.zip",
    )
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=project_root / ".cache/linux-runtime",
    )
    parser.add_argument("--offline", action="store_true", help="Gunakan cache sahaja.")
    parser.add_argument("--force-download", action="store_true")
    parser.add_argument(
        "--force-rebuild",
        action="store_true",
        help="Bina semula runtime walaupun output sedia ada lulus verifikasi.",
    )
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument(
        "--proot-sha256",
        default=os.environ.get("AI_MULTIAGENT_PROOT_SHA256"),
        help="Checksum tambahan untuk arkib PRoot commit-pinned.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    try:
        build(parse_args())
    except (RuntimeBuildError, OSError, tarfile.TarError, zipfile.BadZipFile, json.JSONDecodeError) as error:
        raise SystemExit(f"RUNTIME BUILD GAGAL: {error}")
