#!/usr/bin/env python3
from __future__ import annotations

import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOBILE = ROOT / "mobile"
ANDROID = MOBILE / "android" / "app"
errors: list[str] = []


def read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        errors.append(f"Fail tiada: {path.relative_to(ROOT)}")
        return ""


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


build = read(ANDROID / "build.gradle.kts")
IS_FULL = 'applicationId = "com.aiauto.claw.full"' in build
EDITION = "Full" if IS_FULL else "Standard"
manifest_path = ANDROID / "src/main/AndroidManifest.xml"
manifest = read(manifest_path)
main_activity = read(ANDROID / "src/main/kotlin/com/aiauto/claw/MainActivity.kt")
keep_alive = read(ANDROID / "src/main/kotlin/com/aiauto/claw/ExecutionKeepAliveService.kt")
browser_engine = read(ANDROID / "src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt")
proguard = read(ANDROID / "proguard-rules.pro")
app_config = read(MOBILE / "lib/src/config/app_config.dart")
app_edition = read(MOBILE / "lib/src/config/app_edition.dart")
app_state = read(MOBILE / "lib/src/state/app_state.dart")
tool_engine = read(MOBILE / "lib/src/services/tool_engine.dart")
platform_bridge = read(MOBILE / "lib/src/services/platform_bridge_service.dart")
agent_runtime = read(MOBILE / "lib/src/services/agent_runtime.dart")
settings = read(MOBILE / "lib/src/ui/screens/settings_screen.dart")
more = read(MOBILE / "lib/src/ui/screens/more_screen.dart")
script_name = "build_full.sh" if IS_FULL else "build_play.sh"
build_script = read(ROOT / "scripts" / script_name)
workflow = read(ROOT / ".github/workflows/android-release-check.yml")

require("isDebuggable = false" in build, "Release mesti tidak debuggable")
require("isMinifyEnabled = true" in build, "R8 minify mesti aktif")
require("isShrinkResources = true" in build, "Resource shrinking mesti aktif")
require("proguard-android-optimize.txt" in build, "Fail ProGuard optimize tidak digunakan")
require("hasReleaseSigning" in build and "releaseStoreFile?.isFile == true" in build,
        "Pengesahan keystore release tidak lengkap")
require("android.permission.WAKE_LOCK" in manifest, "Kebenaran WAKE_LOCK tiada")
require("android.permission.FOREGROUND_SERVICE" in manifest, "Kebenaran foreground service tiada")
require("android.permission.FOREGROUND_SERVICE_DATA_SYNC" in manifest,
        "Kebenaran foreground service dataSync tiada")
require("ExecutionKeepAliveService" in manifest and 'android:foregroundServiceType="dataSync"' in manifest,
        "Foreground service 30 minit tidak didaftarkan")
require("FLAG_KEEP_SCREEN_ON" in main_activity and "window.clearFlags" in main_activity,
        "Keep-screen-on foreground tidak lengkap")
require("startExecutionKeepAlive" in main_activity and "getRuntimeContext" in main_activity,
        "Method channel runtime/keep-alive tidak lengkap")
require("PARTIAL_WAKE_LOCK" in keep_alive, "Partial wake lock tiada")
require("30L * 60L * 1000L" in keep_alive, "Had native 30 minit tiada")
require("START_NOT_STICKY" in keep_alive, "Foreground service mesti START_NOT_STICKY")
require("desktopMode" in browser_engine and "desktopUserAgent" in browser_engine,
        "Browser desktop mode tidak lengkap")
require("mediaPlaybackRequiresUserGesture = true" in browser_engine and
        "addDocumentStartJavaScript" in browser_engine and
        "captureScreenshotTile" in browser_engine,
        "Senyap media awal atau screenshot penuh browser tidak lengkap")
require('implementation("androidx.webkit:webkit:1.14.0")' in build,
        "AndroidX WebKit untuk suntikan senyap awal tidak dipinkan")
require("120_000L" in browser_engine and "60_000L" in browser_engine,
        "Timeout native browser tidak dikemas kini")
require("ExecutionKeepAliveService" in proguard and "BackgroundBrowserEngine" in proguard,
        "Keep rule R8 untuk komponen native tiada")
require("defaultTimeout = Duration(minutes: 3)" in app_config, "Timeout rangkaian global bukan 3 minit")
require("browserTimeout = Duration(minutes: 2)" in app_config, "Timeout browser bukan 2 minit")
require("backgroundExecutionLimit = Duration(minutes: 30)" in app_config,
        "Had latar belakang Dart bukan 30 minit")
require("bool backgroundExecutionAllowed = true" in app_state,
        "Latar belakang patut diaktifkan secara lalai pada pemasangan baharu")
require("_backgroundLimitTimer" in app_state and "_stopRunAfterBackgroundLimit" in app_state,
        "Timer had latar belakang tiada")
require("PlatformBridgeService" in platform_bridge and "remotePcAccess" in platform_bridge,
        "Konteks runtime platform tiada")
require("id: 'runtime_info'" in tool_engine and "desktop_mode" in tool_engine,
        "Tool runtime/browser desktop tiada")
require("configuredMcpServers" in tool_engine and
        "server PC Windows" in agent_runtime,
        "Fallback ke tools PC Windows melalui MCP belum diberi kepada agent")
require("app_usage_guide" in tool_engine and
        (MOBILE / "lib/src/ui/screens/usage_guide_screen.dart").exists(),
        "Cara Guna aplikasi belum lengkap")
require("id: 'media_preview'" in tool_engine and
        "gunakan media_preview" in agent_runtime,
        "Agent belum boleh menghantar pratonton media URL sebelum muat turun")
require("panggil runtime_info" in agent_runtime and "Jangan kata tiada akses browser" in agent_runtime,
        "Arahan model tentang browser/peranti tidak lengkap")
require("runtimeContextSnapshot" in agent_runtime and
        "Konteks runtime sebenar aplikasi" in agent_runtime,
        "Konteks runtime belum disuntik terus ke prompt model")
require("Target API ${AppConfig.androidTargetSdk}" in settings and
        "Target API ${AppConfig.androidTargetSdk}" in more,
        "Target API tidak dipaparkan dalam aplikasi")
require("AppEdition.play => 'Standard'" in app_edition, "Nama edisi Standard belum digunakan")

ui_text = "\n".join(
    path.read_text(encoding="utf-8")
    for path in (MOBILE / "lib").rglob("*.dart")
)
forbidden_store_label = "Google" + " Play"
require(forbidden_store_label not in ui_text, "Label gedung lama masih terdapat dalam kod UI")

require("flutter build apk --release" in build_script, "Skrip release tidak membina APK")
require("flutter build appbundle --release" in build_script, "Skrip release tidak membina AAB")
require("mapping.txt" in build_script and "R8 mapping.txt tidak dijana" in build_script,
        "Skrip release tidak mengesahkan output R8")
require("scripts/build_full.sh" in workflow,
        "CI tidak memanggil skrip APK/AAB/R8 release")

if IS_FULL:
    require('applicationId = "com.aiauto.claw.full"' in build, "Package Full salah")
    require("targetSdk = 28" in build, "Target API Full salah")
    linux_service = read(MOBILE / "lib/src/services/linux_workspace_service.dart")
    terminal_service = read(MOBILE / "lib/src/services/terminal_service.dart")
    linux_screen = read(MOBILE / "lib/src/ui/screens/linux_workspace_screen.dart")
    linux_builder = read(ROOT / "scripts/linux/prepare_bundled_runtime.py")
    debug_script = read(ROOT / "scripts/build_debug.sh")
    pubspec = read(MOBILE / "pubspec.yaml")
    require("prepare_bundled_runtime.py" in build_script,
            "Build Full tidak menyediakan runtime Linux sebelum Flutter build")
    require("prepareBundledLinuxRuntime" in build and
            "verifyBundledLinuxRuntime" in build and
            'name.startsWith("compileFlutterBuild")' in build and
            "dependsOn(verifyBundledLinuxRuntime)" in build,
            "Build Gradle terus tidak menyediakan/mengesahkan runtime sebelum Flutter memeriksa assets")
    require("prepare_bundled_runtime.py" in debug_script and
            "--target-platform android-arm64" in debug_script and
            "EMBEDDED_RUNTIME_SHA" in debug_script and
            "--verify-only --output" in debug_script,
            "Build debug Full tidak menyediakan/mengesahkan runtime Linux ARM64 terbenam")
    require("--target-platform android-arm64" in build_script,
            "Build Full mesti menghasilkan artifact ARM64 sahaja")
    require("runtime-pack.zip" in build_script and "RUNTIME_ENTRY" in build_script and
            "runtime_entries" in build_script and
            "EMBEDDED_RUNTIME_SHA" in build_script and
            "--verify-only --output" in build_script,
            "Build Full tidak membuktikan runtime Linux yang sah/identik masuk ke APK/AAB")
    require("assets/linux/full/runtime-pack.zip" in pubspec and
            "assets/linux/full/runtime-manifest.json" in pubspec,
            "Asset runtime Linux Full tidak disenaraikan secara khusus")
    require("ensureBundledRuntimeReady" in linux_service and
            "_runHealthCheck" in linux_service and
            "apk --version" in linux_service and
            "output.contains('apk-tools')" in linux_service and
            "_validateArm64Elf" in linux_service and
            "_rollbackInstall" in linux_service and
            "_recoverInterruptedInstall" in linux_service and
            "_verifyActiveRuntimeAndClearBackup" in linux_service,
            "Pemasangan, health check apk, ABI, rollback atau pemulihan transaksi Linux tidak lengkap")
    require("maxExtractedRuntimeBytes" in linux_service and
            "maxRuntimeEntries" in linux_service and
            "maxSingleRuntimeEntryBytes" in linux_service and
            "maxSymlinkTargetBytes" in linux_service and
            "seenEntries" in linux_service and
            "rawParts.contains('..')" in linux_service,
            "Had keselamatan saiz, entri unik, laluan dan symlink runtime pack tidak lengkap")
    require("autoInstallBundledRuntime: true" in terminal_service and
            "ProcessException" in terminal_service,
            "Terminal AI tidak auto-install atau tidak mengendalikan kegagalan proses")
    require("class _RollingTextBuffer" in terminal_service and
            "Utf8Decoder(allowMalformed: true)" in terminal_service and
            "Future<void> stopAll()" in terminal_service and
            "_maxRetainedJobs = 64" in terminal_service and
            "_maxConcurrentJobs = 8" in terminal_service and
            "runningJobs >= _maxConcurrentJobs" in terminal_service,
            "Terminal Linux belum mengehadkan output/job serentak atau menghentikan semua proses dengan selamat")
    require("unawaited(terminalService.stopAll())" in app_state and
            "await terminalService.stopAll()" in app_state,
            "Proses Linux tidak dihentikan pada batal, had latar belakang atau reset sesi")
    require("automaticInstallOnFirstCommand" in tool_engine and
            "expectedRuntimeVersion" in tool_engine,
            "Konteks Linux belum disuntik terus kepada model")
    require("Alpine Linux" in agent_runtime and "apk, bukan apt/dpkg" in agent_runtime,
            "AI belum diajar penggunaan Alpine/apk dengan tepat")
    require("Kemas kini apk" in linux_screen and "apt update" not in linux_screen and
            "setState(() => _runtimeError = null);" in linux_screen and
            "_stopTerminalJobsForRuntimeChange" in linux_screen,
            "UI Linux Full masih menggunakan Debian atau tidak memulihkan status/proses dengan betul")
    require("ALPINE_SHA256" in linux_builder and "PROOT_COMMIT" in linux_builder and
            "validate_arm64_elf" in linux_builder and "verify_pack" in linux_builder and
            "MAX_EXTRACTED_BYTES" in linux_builder and
            "MAX_SOURCE_EXTRACTED_BYTES" in linux_builder and
            "seen_members" in linux_builder and
            "nama entri berganda" in linux_builder and
            "_validate_zip_symlink" in linux_builder,
            "Pembina runtime tidak mempin/mengesahkan sumber, saiz, ZIP, symlink dan PRoot ARM64")
    require('"supportedAbis" to Build.SUPPORTED_ABIS.toList()' in main_activity,
            "Konteks ABI peranti tidak diberikan kepada AI")
    icon = MOBILE / "assets/images/app_icon_full.png"
    try:
        data = icon.read_bytes()
        png_signature = bytes.fromhex("89504e470d0a1a0a")
        require(data.startswith(png_signature), "Ikon Full mesti PNG")
        width, height = struct.unpack(">II", data[16:24])
        require((width, height) == (1024, 1024), "Ikon Full mesti 1024x1024")
    except Exception as exc:
        errors.append(f"Ikon Full gagal dibaca: {exc}")
else:
    require('applicationId = "com.aiauto.claw"' in build, "Package Standard salah")
    require("targetSdk = 36" in build, "Target API Standard salah")

try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml tidak sah: {exc}")

if errors:
    print(f"SEMAKAN RELEASE GAGAL: {EDITION}")
    for item in errors:
        print(f"- {item}")
    sys.exit(1)

print(f"SEMAKAN RELEASE LULUS: {EDITION}")
print("- R8/minify dan shrink resources aktif")
print("- APK + AAB release diwajibkan oleh skrip/CI")
print("- Screen awake, foreground service dan had 30 minit disahkan")
print("- Runtime browser/peranti dan target API disahkan")
if IS_FULL:
    print("- Alpine Linux ARM64/PRoot, auto-install, health check dan embedding artifact disahkan")
