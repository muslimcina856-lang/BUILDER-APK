#!/usr/bin/env python3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVICES = ROOT / "mobile/lib/src/services"
MODELS = ROOT / "mobile/lib/src/models/app_models.dart"
PROVIDERS_UI = ROOT / "mobile/lib/src/ui/screens/providers_screen.dart"
CHAT_UI = ROOT / "mobile/lib/src/ui/screens/chat_screen.dart"
APP_STATE = ROOT / "mobile/lib/src/state/app_state.dart"
ANDROID_BROWSER = ROOT / (
    "mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt"
)
BROWSER_SESSION = SERVICES / "browser_session_service.dart"
TOOL_ENGINE = SERVICES / "tool_engine.dart"
PROVIDER = SERVICES / "provider_service.dart"
RUNTIME = SERVICES / "agent_runtime.dart"
POLICY = SERVICES / "provider_model_policy.dart"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


tool = read(TOOL_ENGINE)
provider = read(PROVIDER)
runtime = read(RUNTIME)
chat = read(CHAT_UI)
models = read(MODELS)
providers_ui = read(PROVIDERS_UI)
policy = read(POLICY)
app_state = read(APP_STATE)
browser = read(ANDROID_BROWSER)
browser_session = read(BROWSER_SESSION)
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


# Provider output must be rejected before malformed tool arguments reach execution.
require((SERVICES / "provider_response_guard.dart").exists(), "Provider guard belum ada")
require("ensureOpenAiChatComplete" in provider, "OpenAI finish_reason belum dijaga")
require("ensureOpenAiResponsesComplete" in provider, "OpenAI Responses incomplete belum dijaga")
require("ensureAnthropicComplete" in provider, "Anthropic stop_reason belum dijaga")
require("ensureGeminiComplete" in provider, "Gemini finishReason belum dijaga")
require("{'value': value.toString()}" not in provider, "JSON tool rosak masih diteruskan")

# File writes must be explicit, bounded and transactional.
require((SERVICES / "file_write_coordinator.dart").exists(), "Coordinator fail belum ada")
require("_suggestedWritePath" not in tool, "Path fail masih diteka")
require("'chunks': <String, dynamic>" not in tool, "Payload chunks besar masih tersedia")
for tool_id in ("file_commit", "file_write_status", "file_abort", "str_replace"):
    require(f"id: '{tool_id}'" in tool, f"Tool {tool_id} belum ada")
require("expected_sha256" in tool, "Hash/version guard belum diekspos")

# file_read must not load the entire large file before paging.
read_block = tool.split("Future<ToolResult> _fileRead", 1)[1].split(
    "Future<FileWriteCoordinator> _fileWriter", 1
)[0] if "Future<FileWriteCoordinator> _fileWriter" in tool else ""
require("RandomAccessFile" in read_block, "file_read belum paging dari disk")
require("await file.readAsString()" not in read_block, "file_read masih membaca seluruh fail")

# Current UI regressions.
search_block = tool.split("Future<ToolResult> _webSearch", 1)[1].split(
    "Future<ToolResult> _browserOpen", 1
)[0]
require("ArtifactKind.searchResults" not in search_block,
        "web_search masih mencipta artifact UI walaupun hasil hanya untuk AI")
require("a.kind != ArtifactKind.searchResults" in chat,
        "Artifact carian lama belum ditapis daripada paparan chat")
require("return SelectableText(" in chat, "Teks mesej pengguna belum selectable")
require("fallbackThink" not in runtime, "Reasoning masih boleh menjadi jawapan akhir")
require("risk: ToolRisk.localWrite" in tool.split("id: 'skill_set_enabled'", 1)[1].split("),", 1)[0],
        "skill_set_enabled masih ditanda readOnly")
require("_sendSettled" in app_state and "await settled.future" in app_state,
        "Edit ketika AI berjalan masih boleh berlumba dan hilangkan lampiran/sejarah")
require("_pendingPasteImport" in chat and "await pendingPaste" in chat,
        "Hantar mesej masih boleh memintas import paste panjang")
user_shell = chat.split("class _UserMessageShell", 1)[1].split(
    "class _CopyBurstButton", 1
)[0]
require("Listener(" in user_shell and
        "onPointerDown: _trackPointerDown" in user_shell and
        "onPointerMove: _trackPointerMove" in user_shell and
        "onPointerUp: _finishPointerTap" in user_shell and
        "onPointerCancel: _cancelPointerTap" in user_shell,
        "Ketikan pada teks/seluruh gelembung pengguna belum toggle Edit/Salin")
require("onTap: _toggle" not in user_shell,
        "GestureDetector lama masih berlumba dengan SelectableText")
require("AnimatedSize(" in user_shell and "showMenu<" not in user_shell,
        "Bar Edit/Salin asal telah ditukar kepada menu terapung")
require("bool isWritingFinalAnswer = false" in app_state,
        "Status mula menulis jawapan akhir belum direkod")
require("state.isSending && !state.isWritingFinalAnswer" in chat,
        "Langkah pemikiran belum ditutup ketika jawapan akhir mula ditulis")
require("e.state == RunEventState.failed" in app_state,
        "Ralat tool sementara masih disimpan selepas jawapan berjaya")
completed_block = chat.split("class _CompletedProcessCard", 1)[1].split(
    "class _LiveProcessCard", 1
)[0]
require("_ThinkingStep(" in completed_block,
        "Pemikiran siap belum menggunakan rupa timeline pemikiran hidup")
require("(ada ralat)" not in completed_block,
        "Pemikiran berjaya masih menulis ada ralat")
require("'table': _HorizontalMarkdownTableBuilder()" in chat,
        "Jadual Markdown belum mempunyai renderer mendatar")
table_block = chat.split("class _HorizontalMarkdownTableBuilder", 1)[1].split(
    "class _CodeBlockBuilder", 1
)[0] if "class _HorizontalMarkdownTableBuilder" in chat else ""
require("scrollDirection: Axis.horizontal" in table_block and
        "FixedColumnWidth" in table_block,
        "Jadual panjang belum mengekalkan lebar kolum dan boleh dileret")
require("if (pendingResult != null) {" in browser,
        "Slot callback browser masih boleh diambil sebelum pending lama dibersihkan")
clear_pending = browser.split("private fun clearPending()", 1)[1].split(
    "private fun safeSuccess", 1
)[0]
require("pendingDone.set(true)" in clear_pending,
        "clearPending tidak memuktamadkan status callback browser")
send_file_block = tool.split("id: 'send_file'", 1)[1].split("),", 1)[0]
require("'required': <String>['path']" in send_file_block,
        "send_file masih menerima panggilan tanpa path")
require("Fail kosong ditolak" in tool and "isTargetBusy" in tool,
        "send_file belum menolak fail kosong/transaksi aktif")

# Terminal console belongs to the current turn only. It lists simultaneous
# running jobs, keeps only the latest completed output when all stop, and
# preserves stdin while the agent continues polling/thinking.
terminal_sliver = chat.split("// Konsol per **mesej/turn**", 1)[1].split(
    "const SliverToBoxAdapter(child: SizedBox(height: 8))", 1
)[0]
terminal_console = chat.split("class _LiveTerminalConsole", 1)[1]
require("_terminalJobsForScope(" in terminal_sliver and
        "state.terminalScopeStartedAt" in terminal_sliver and
        ").isNotEmpty" in terminal_sliver,
        "Konsol turn semasa belum dipaparkan berdasarkan kewujudan job turn itu")
require("if (state.isSending ||" not in terminal_sliver,
        "Konsol kosong masih muncul pada chat yang tidak menggunakan terminal")
require("List<TerminalJob> _terminalJobsForScope" in chat and
        "!job.startedAt.isBefore(start)" in chat,
        "Job terminal belum ditapis mengikut masa mula turn semasa")
require("terminalScopeStartedAt = runStartedAt;" in app_state,
        "Turn baharu belum menetapkan skop terminal baharu")
require("final runningJobs =" in terminal_console and
        ".where((job) => job.running)" in terminal_console,
        "Senarai pilihan konsol belum dihadkan kepada job yang sedang aktif")
auto_select = terminal_console.split("void _autoSelect()", 1)[1].split(
    "@override\n  void dispose()", 1
)[0]
require("runningJobs.any" in auto_select and
        "_selectedJobId = runningJobs.last.id" in auto_select,
        "Konsol belum bertukar automatik apabila job terpilih tamat")
require("if (runningJobs.length > 1)" in terminal_console and
        "items: runningJobs" in terminal_console,
        "Dropdown konsol belum terhad kepada dua atau lebih job aktif")
require("exit ${job.exitCode}" not in terminal_console and
        "exit ${j.exitCode}" not in terminal_console,
        "Job yang sudah mati masih dipaparkan sebagai pilihan exit")
require("finishedAt" in chat and
        "_latestFinishedJob" in terminal_console,
        "Konsol belum mengekalkan job yang paling akhir selesai")
require("writeStdin(job.id, text)" in terminal_console and
        "if (job.running)" in terminal_console,
        "Input stdin untuk proses aktif telah terjejas")
require("terminal_poll" in runtime and "terminal_stdin" in runtime and
        "_maxStepsPerAgent" not in runtime,
        "Agent tidak lagi boleh menunggu proses interaktif tanpa had langkah")

# Media generation is removed while ordinary media handling remains.
joined_generation = "\n".join((tool, provider, runtime, models, providers_ui, policy))
for token in (
    "generate_speech",
    "generate_image",
    "generate_video",
    "speechModel",
    "imageModel",
    "videoModel",
    "MediaGenSupport",
):
    require(token not in joined_generation, f"Fungsi model janaan masih ada: {token}")
for retained in ("media_preview", "send_file", "video_sample_frames"):
    require(retained in tool, f"Fungsi media biasa terpadam: {retained}")

# Browser form automation imported selectively from the reviewed ByClaude build.
for browser_tool in ("browser_select_option", "browser_press_key"):
    require(f"id: '{browser_tool}'" in tool, f"Tool {browser_tool} belum ada")
    require(f"'{browser_tool}'" in runtime, f"Agent browser belum menerima {browser_tool}")
require("'type_mode': <String, dynamic>" in tool,
        "browser_fill belum menyokong input bertopeng")
for token in (
    '"selectOption" -> selectOption(',
    '"pressKey" -> pressKey(',
    "CLAW_PRELUDE",
    "INTERACTIVE_SELECTOR",
    "deepAll",
):
    require(token in browser, f"Enjin browser lanjutan belum lengkap: {token}")
require("browser_native_unavailable" in browser_session and "domActions" in browser_session,
        "Fallback HTTP masih boleh berpura-pura melaksanakan tindakan DOM")

# Browser session/cookie management: values may be injected, but status/results
# must expose names/keys only and a new chat must perform a full reset.
for session_tool in (
    "browser_clear_session",
    "browser_session_status",
    "browser_cookie_set",
    "browser_cookie_delete",
    "browser_inject_token",
    "browser_inject_session",
):
    require(f"id: '{session_tool}'" in tool, f"Tool {session_tool} belum ada")
    require(f"'{session_tool}'" in runtime, f"Agent belum menerima {session_tool}")
for token in (
    '"clearSession" -> clearSession(',
    '"sessionStatus" -> sessionStatus(',
    '"setCookie" -> setCookie(',
    '"deleteCookie" -> deleteCookie(',
    '"injectSession" -> injectSession(',
    "WebStorage.getInstance().deleteAllData()",
    "clearHttpAuthUsernamePassword()",
    "cookieNames",
    "localStorageKeys",
    "sessionStorageKeys",
):
    require(token in browser, f"Pengurusan sesi native belum lengkap: {token}")
require("Future<void> clearSession()" in browser_session,
        "Servis Dart belum mempunyai reset sesi penuh")
require("await browserSession.clearSession()" in app_state,
        "Sesi chat baharu masih hanya membuang cookies")
require("cookie_value" not in browser and "token_value" not in browser,
        "Status sesi tidak boleh memulangkan nilai cookie/token")

# Token default dinaikkan, tetapi had langkah agent ByClaude sengaja tidak diambil.
require("this.maxTokens = 8192" in models and "?? 8192" in models,
        "Default maxTokens belum dinaikkan kepada 8192")
require("_maxStepsPerAgent" not in runtime,
        "Had langkah agent ByClaude tidak sepatutnya dimasukkan")
require(not (SERVICES / "duckduckgo_search_service.dart.bak").exists(),
        "Fail backup .bak tidak sepatutnya dibungkus")

if errors:
    print("UJIAN REGRESI PERMINTAAN GAGAL")
    for error in errors:
        print("-", error)
    raise SystemExit(1)

print("UJIAN REGRESI PERMINTAAN LULUS")
