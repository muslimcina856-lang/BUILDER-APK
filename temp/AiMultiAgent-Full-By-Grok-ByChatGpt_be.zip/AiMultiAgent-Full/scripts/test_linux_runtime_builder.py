#!/usr/bin/env python3
"""Ujian tanpa rangkaian untuk pembina runtime Linux Full.

Ujian ini tidak menjalankan PRoot; ia mengesahkan kontrak arkib, perlindungan
path traversal, symlink, metadata ARM64 dan verifikasi runtime-pack.zip.
"""
from __future__ import annotations

import io
import json
import os
import stat
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import warnings
import zipfile
from contextlib import redirect_stdout
from unittest.mock import patch
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent / "linux"
sys.path.insert(0, str(SCRIPT_DIR))

import prepare_bundled_runtime as runtime_builder  # noqa: E402

from prepare_bundled_runtime import (  # noqa: E402
    ALPINE_SHA256,
    ALPINE_URL,
    PROOT_COMMIT,
    PROOT_EXPECTED_SIZE,
    PROOT_URL,
    RUNTIME_SCHEMA,
    RUNTIME_VERSION,
    RuntimeBuildError,
    build,
    create_pack,
    download,
    safe_extract_tar,
    verify_pack,
)


def arm64_elf_stub() -> bytes:
    data = bytearray(64)
    data[0:4] = b"\x7fELF"
    data[4] = 2  # ELFCLASS64
    data[5] = 1  # little-endian
    data[6] = 1  # ELF version
    data[18:20] = (183).to_bytes(2, "little")  # EM_AARCH64
    return bytes(data)


def add_bytes(tf: tarfile.TarFile, name: str, data: bytes, mode: int = 0o644) -> None:
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = mode
    tf.addfile(info, io.BytesIO(data))


def expect_runtime_error(action, label: str) -> None:
    try:
        action()
    except RuntimeBuildError:
        return
    raise AssertionError(f"Sepatutnya ditolak: {label}")


def test_safe_tar_extraction(temp: Path) -> None:
    archive = temp / "safe.tar.gz"
    with tarfile.open(archive, "w:gz") as tf:
        add_bytes(tf, "root/bin/proot", arm64_elf_stub(), 0o700)
        link = tarfile.TarInfo("root/bin/proot-link")
        link.type = tarfile.SYMTYPE
        link.linkname = "proot"
        link.mode = 0o777
        tf.addfile(link)
    output = temp / "safe-out"
    safe_extract_tar(archive, output, allow_absolute_symlinks=False)
    assert (output / "root/bin/proot").is_file()
    assert (output / "root/bin/proot-link").is_symlink()
    assert (output / "root/bin/proot-link").readlink().as_posix() == "proot"

    traversal = temp / "traversal.tar.gz"
    with tarfile.open(traversal, "w:gz") as tf:
        add_bytes(tf, "../outside", b"blocked")
    expect_runtime_error(
        lambda: safe_extract_tar(
            traversal,
            temp / "traversal-out",
            allow_absolute_symlinks=False,
        ),
        "tar path traversal",
    )

    escaping_link = temp / "escaping-link.tar.gz"
    with tarfile.open(escaping_link, "w:gz") as tf:
        link = tarfile.TarInfo("root/bin/escape")
        link.type = tarfile.SYMTYPE
        link.linkname = "../../../outside"
        tf.addfile(link)
    expect_runtime_error(
        lambda: safe_extract_tar(
            escaping_link,
            temp / "escaping-link-out",
            allow_absolute_symlinks=False,
        ),
        "symlink keluar arkib",
    )

    duplicate = temp / "duplicate.tar.gz"
    with tarfile.open(duplicate, "w:gz") as tf:
        add_bytes(tf, "root/repeated", b"first")
        add_bytes(tf, "root/repeated", b"second")
    expect_runtime_error(
        lambda: safe_extract_tar(
            duplicate,
            temp / "duplicate-out",
            allow_absolute_symlinks=False,
        ),
        "nama entri tar berganda",
    )


def runtime_manifest() -> dict[str, object]:
    return {
        "schema": RUNTIME_SCHEMA,
        "runtime_version": RUNTIME_VERSION,
        "architecture": "aarch64",
        "android_abi": "arm64-v8a",
        "distribution": "Alpine Linux",
        "distribution_version": "3.24.1",
        "package_manager": "apk",
        "shell": "/bin/sh",
        "proot_version": "0.15",
        "delivery": "test",
        "sources": {
            "alpine_url": ALPINE_URL,
            "alpine_sha256": ALPINE_SHA256,
            "proot_url": PROOT_URL,
            "proot_commit": PROOT_COMMIT,
            "proot_sha256": "0" * 64,
            "proot_size": PROOT_EXPECTED_SIZE,
        },
    }


def test_runtime_pack_contract(temp: Path) -> None:
    stage = temp / "stage"
    (stage / "runtime/bin").mkdir(parents=True)
    (stage / "rootfs/bin").mkdir(parents=True)
    (stage / "rootfs/sbin").mkdir(parents=True)
    (stage / "rootfs/usr/bin").mkdir(parents=True)
    (stage / "rootfs/etc").mkdir(parents=True)
    (stage / "home").mkdir(parents=True)
    proot = stage / "runtime/bin/proot"
    proot.write_bytes(arm64_elf_stub())
    proot.chmod(0o700)
    shell = stage / "rootfs/bin/sh"
    shell.write_text("#!/bin/sh\n", encoding="utf-8")
    shell.chmod(0o755)
    apk = stage / "rootfs/sbin/apk"
    apk.write_text("#!/bin/sh\n", encoding="utf-8")
    apk.chmod(0o755)
    env = stage / "rootfs/usr/bin/env"
    env.write_text("#!/bin/sh\n", encoding="utf-8")
    env.chmod(0o755)
    (stage / "rootfs/etc/alpine-release").write_text(
        "3.24.1\n", encoding="utf-8"
    )
    (stage / "runtime/manifest.json").write_text(
        json.dumps(runtime_manifest()),
        encoding="utf-8",
    )
    (stage / "rootfs/bin/ash").symlink_to("sh")
    (stage / "rootfs/bin/busybox-absolute").symlink_to("/bin/busybox")

    pack = temp / "runtime-pack.zip"
    create_pack(stage, pack)
    manifest = verify_pack(pack)
    assert manifest["runtime_version"] == RUNTIME_VERSION
    assert manifest["architecture"] == "aarch64"

    # Output yang sah mesti boleh digunakan semula tanpa cache atau rangkaian.
    with redirect_stdout(io.StringIO()):
        build(
            SimpleNamespace(
                cache_dir=temp / "missing-cache",
                output=pack,
                verify_only=False,
                offline=True,
                force_download=False,
                force_rebuild=False,
                proot_sha256=None,
            )
        )
    assert (pack.parent / "runtime-pack.sha256").is_file()
    assert (pack.parent / "runtime-manifest.json").is_file()
    build_info = json.loads(
        (pack.parent / "runtime-build-info.json").read_text(encoding="utf-8")
    )
    assert build_info["reused_existing_pack"] is True

    custom_stage = temp / "custom-stage"
    import shutil
    shutil.copytree(stage, custom_stage, symlinks=True)
    custom_manifest = runtime_manifest()
    custom_manifest["delivery"] = "manual_recovery_pack"
    custom_manifest["proot_version"] = "custom-compatible"
    custom_manifest["sources"] = {
        "proot_sha256": "1" * 64,
        "rootfs_tree_sha256": "2" * 64,
    }
    (custom_stage / "runtime/manifest.json").write_text(
        json.dumps(custom_manifest), encoding="utf-8"
    )
    custom_pack = temp / "custom-runtime-pack.zip"
    create_pack(custom_stage, custom_pack)
    verify_pack(custom_pack, require_pinned_sources=False)
    expect_runtime_error(
        lambda: verify_pack(custom_pack),
        "recovery pack tanpa sumber rasmi tidak boleh dianggap asset terbina",
    )

    with zipfile.ZipFile(pack) as zf:
        info = zf.getinfo("runtime/bin/proot")
        mode = info.external_attr >> 16
        assert stat.S_ISREG(mode)
        assert mode & stat.S_IXUSR
        link_info = zf.getinfo("rootfs/bin/ash")
        assert stat.S_ISLNK(link_info.external_attr >> 16)
        assert zf.read("rootfs/bin/ash") == b"sh"

    bad_stage = temp / "bad-stage"
    (bad_stage / "runtime/bin").mkdir(parents=True)
    (bad_stage / "rootfs/bin").mkdir(parents=True)
    (bad_stage / "rootfs/sbin").mkdir(parents=True)
    (bad_stage / "rootfs/usr/bin").mkdir(parents=True)
    (bad_stage / "rootfs/etc").mkdir(parents=True)
    (bad_stage / "home").mkdir(parents=True)
    (bad_stage / "runtime/bin/proot").write_bytes(b"not-an-elf")
    (bad_stage / "rootfs/bin/sh").write_text("#!/bin/sh\n", encoding="utf-8")
    (bad_stage / "rootfs/sbin/apk").write_text("#!/bin/sh\n", encoding="utf-8")
    (bad_stage / "rootfs/usr/bin/env").write_text("#!/bin/sh\n", encoding="utf-8")
    (bad_stage / "rootfs/etc/alpine-release").write_text(
        "3.24.1\n", encoding="utf-8"
    )
    (bad_stage / "runtime/manifest.json").write_text(
        json.dumps(runtime_manifest()),
        encoding="utf-8",
    )
    bad_pack = temp / "bad-runtime-pack.zip"
    (bad_stage / "runtime/bin/proot").chmod(0o700)
    create_pack(bad_stage, bad_pack)
    expect_runtime_error(lambda: verify_pack(bad_pack), "PRoot bukan ELF")

    duplicate_pack = temp / "duplicate-runtime-pack.zip"
    duplicate_pack.write_bytes(pack.read_bytes())
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(duplicate_pack, "a") as zf:
            info = zipfile.ZipInfo("runtime/manifest.json")
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            zf.writestr(info, json.dumps(runtime_manifest()).encode("utf-8"))
    expect_runtime_error(
        lambda: verify_pack(duplicate_pack),
        "nama entri ZIP berganda",
    )

    escaping_stage = temp / "escaping-stage"
    import shutil
    shutil.copytree(stage, escaping_stage, symlinks=True)
    (escaping_stage / "runtime/bin/escape").symlink_to("../../../outside")
    escaping_pack = temp / "escaping-runtime-pack.zip"
    create_pack(escaping_stage, escaping_pack)
    expect_runtime_error(
        lambda: verify_pack(escaping_pack),
        "symlink ZIP keluar sandbox",
    )

    android_link_stage = temp / "android-link-stage"
    shutil.copytree(stage, android_link_stage, symlinks=True)
    (android_link_stage / "rootfs/bin/storage-link").symlink_to("/sdcard")
    android_link_pack = temp / "android-link-runtime-pack.zip"
    create_pack(android_link_stage, android_link_pack)
    expect_runtime_error(
        lambda: verify_pack(android_link_pack),
        "symlink ZIP ke storan Android",
    )



def test_external_download_fallback(temp: Path) -> None:
    source = temp / "fallback-source.bin"
    source.write_bytes(b"verified-fallback-data")
    destination = temp / "fallback-output.bin"
    fake_bin = temp / "fake-bin"
    fake_bin.mkdir()
    fake_curl = fake_bin / "curl"
    fake_curl.write_text(
        "#!/bin/sh\n"
        "set -eu\n"
        "out=''\n"
        "while [ $# -gt 0 ]; do\n"
        "  if [ \"$1\" = '--output' ]; then shift; out=$1; fi\n"
        "  shift\n"
        "done\n"
        "[ -n \"$out\" ]\n"
        "cp \"$FAKE_RUNTIME_SOURCE\" \"$out\"\n",
        encoding="utf-8",
    )
    fake_curl.chmod(0o755)

    old_path = os.environ.get("PATH", "")
    old_source = os.environ.get("FAKE_RUNTIME_SOURCE")
    os.environ["PATH"] = f"{fake_bin}{os.pathsep}{old_path}"
    os.environ["FAKE_RUNTIME_SOURCE"] = str(source)
    try:
        with patch.object(
            runtime_builder.urllib.request,
            "urlopen",
            side_effect=runtime_builder.urllib.error.URLError("forced test failure"),
        ), patch.object(runtime_builder.time, "sleep", return_value=None):
            result = download(
                "https://example.invalid/runtime.bin",
                destination,
                offline=False,
                force=True,
            )
        assert result == destination
        assert destination.read_bytes() == source.read_bytes()
    finally:
        os.environ["PATH"] = old_path
        if old_source is None:
            os.environ.pop("FAKE_RUNTIME_SOURCE", None)
        else:
            os.environ["FAKE_RUNTIME_SOURCE"] = old_source

def main() -> None:
    with tempfile.TemporaryDirectory(prefix="ai-linux-builder-test-") as name:
        temp = Path(name)
        test_safe_tar_extraction(temp)
        test_runtime_pack_contract(temp)
        test_external_download_fallback(temp)
    print("UJIAN PEMBINA RUNTIME LINUX LULUS")
    print("- Path traversal dan symlink keluar arkib ditolak")
    print("- Kontrak ZIP, nama unik, symlink, mode Unix dan ELF AArch64 disahkan")
    print("- Fallback curl selepas kegagalan urllib disahkan tanpa rangkaian")


if __name__ == "__main__":
    main()
