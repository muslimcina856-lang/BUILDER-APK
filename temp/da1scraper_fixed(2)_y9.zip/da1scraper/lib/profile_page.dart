import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

class ProfilePage extends StatefulWidget {
  final String email;
  final String name;
  final VoidCallback onLogout;

  const ProfilePage({
    super.key,
    required this.email,
    required this.name,
    required this.onLogout,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with SingleTickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  int _historyCount = 0;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;

  final Color bgDark = const Color(0xFF050D1A);
  final Color cardBg = const Color(0xFF0A1628);
  final Color primaryBlue = const Color(0xFF0062CC);
  final Color accentCyan = const Color(0xFF00FBFF);
  final Color cardGlass = const Color(0x0DFFFFFF);
  final Color borderGlass = const Color(0x1AFFFFFF);

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _loadProfileImage();
    _loadHistoryCount();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('pfp_${widget.email}');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _loadHistoryCount() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('history_${widget.email}') ?? '[]';
    final List list = jsonDecode(raw);
    setState(() => _historyCount = list.length);
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        imageQuality: 75,
      );
      if (file != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pfp_${widget.email}', file.path);
        setState(() => _profileImage = File(file.path));
      }
    } catch (_) {}
  }

  void _showImageDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardBg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12, bottom: 16),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: Icon(Icons.camera_alt_outlined, color: accentCyan),
              title: Text('Kamera',
                  style: const TextStyle(
                      color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_library_outlined, color: accentCyan),
              title: Text('Galeri',
                  style: const TextStyle(
                      color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: SingleChildScrollView(
            child: Column(
              children: [
                // Header gradient — pola dari base Dq
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        primaryBlue.withOpacity(0.3),
                        accentCyan.withOpacity(0.12),
                        primaryBlue.withOpacity(0.2),
                      ],
                    ),
                    border: Border(
                      bottom: BorderSide(color: accentCyan.withOpacity(0.15)),
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'PROFIL',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Orbitron',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: accentCyan.withOpacity(0.5),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Avatar — pola dari profile_page.dart Dq
                      GestureDetector(
                        onTap: _showImageDialog,
                        child: Stack(
                          children: [
                            Container(
                              width: 100,
                              height: 100,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [primaryBlue, accentCyan],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: accentCyan.withOpacity(0.3),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: _profileImage != null
                                    ? Image.file(_profileImage!,
                                        fit: BoxFit.cover)
                                    : Icon(
                                        Icons.person_outline,
                                        size: 44,
                                        color: Colors.white.withOpacity(0.8),
                                      ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: accentCyan,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: bgDark, width: 2),
                                ),
                                child: const Icon(Icons.camera_alt,
                                    size: 14, color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        widget.name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.email,
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      // Stats row
                      Row(
                        children: [
                          Expanded(
                            child: _buildStatCard(
                              icon: Icons.history,
                              label: 'Total Scraping',
                              value: _historyCount.toString(),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildStatCard(
                              icon: Icons.check_circle_outline,
                              label: 'Status',
                              value: 'Aktif',
                              valueColor: Colors.greenAccent,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // Info cards
                      _buildInfoRow(
                        icon: Icons.person_outline,
                        label: 'Nama',
                        value: widget.name,
                      ),
                      const SizedBox(height: 10),
                      _buildInfoRow(
                        icon: Icons.email_outlined,
                        label: 'Email',
                        value: widget.email,
                      ),
                      const SizedBox(height: 10),
                      _buildInfoRow(
                        icon: Icons.verified_outlined,
                        label: 'Tipe Akun',
                        value: 'Lokal',
                      ),
                      const SizedBox(height: 32),

                      // Logout button
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.logout, color: Colors.white,
                              size: 18),
                          label: const Text(
                            'KELUAR',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Orbitron',
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.redAccent.withOpacity(0.8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 0,
                          ),
                          onPressed: () async {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                backgroundColor: cardBg,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                                title: const Text('Keluar?',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'Orbitron',
                                        fontSize: 16)),
                                content: const Text(
                                  'Anda akan keluar dari akun.',
                                  style: TextStyle(
                                      color: Colors.white54,
                                      fontFamily: 'ShareTechMono'),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, false),
                                    child: Text('Batal',
                                        style: TextStyle(
                                            color: Colors.white.withOpacity(0.38))),
                                  ),
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, true),
                                    child: const Text('Keluar',
                                        style: TextStyle(
                                            color: Colors.redAccent)),
                                  ),
                                ],
                              ),
                            );
                            if (ok == true) widget.onLogout();
                          },
                        ),
                      ),

                      const SizedBox(height: 24),
                      Text(
                        '© 2026 Da1scraper by FATEzou',
                        style: TextStyle(
                          color: Colors.white12,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    Color? valueColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: accentCyan.withOpacity(0.7), size: 18),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? accentCyan,
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.38),
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: primaryBlue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: accentCyan, size: 16),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.38),
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.87),
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
