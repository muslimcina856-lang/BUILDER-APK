import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'scraper_service.dart';
import 'result_detail_page.dart';

class ScraperPage extends StatefulWidget {
  final String email;
  final String name;

  const ScraperPage({super.key, required this.email, required this.name});

  @override
  State<ScraperPage> createState() => _ScraperPageState();
}

class _ScraperPageState extends State<ScraperPage>
    with SingleTickerProviderStateMixin {
  final urlController = TextEditingController();
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  bool _isLoading = false;
  String _status = '';
  Map<String, dynamic>? _result;

  // Mode scraper
  String _selectedMode = 'snippet';
  final List<Map<String, dynamic>> _modes = [
    {'id': 'snippet', 'label': 'Web Snippet', 'icon': Icons.web_outlined},
    {'id': 'media', 'label': 'Media Downloader', 'icon': Icons.download_outlined},
    {'id': 'meta', 'label': 'Meta Extractor', 'icon': Icons.info_outline},
    {'id': 'text', 'label': 'Text Extractor', 'icon': Icons.article_outlined},
  ];

  // Tema dari base Dq
  final Color bgDark = const Color(0xFF050D1A);
  final Color cardBg = const Color(0xFF0A1628);
  final Color primaryBlue = const Color(0xFF0062CC);
  final Color accentCyan = const Color(0xFF00FBFF);
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    urlController.dispose();
    super.dispose();
  }

  Future<void> _runScraper() async {
    final url = urlController.text.trim();
    if (url.isEmpty) {
      _setStatus('⚠ Masukkan URL terlebih dahulu');
      return;
    }
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      _setStatus('⚠ URL harus diawali https:// atau http://');
      return;
    }

    setState(() {
      _isLoading = true;
      _status = 'Menghubungi target...';
      _result = null;
    });

    try {
      final result = await ScraperService.scrape(
        url: url,
        mode: _selectedMode,
        onStatus: (s) => setState(() => _status = s),
      );

      setState(() {
        _result = result;
        _status = '✓ Selesai';
      });

      // Simpan ke riwayat
      await _saveToHistory(url, result);
    } catch (e) {
      setState(() => _status = '✗ Error: ${e.toString()}');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveToHistory(String url, Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'history_${widget.email}';
    final existing = prefs.getString(key) ?? '[]';
    final List list = jsonDecode(existing);
    list.insert(0, {
      'url': url,
      'mode': _selectedMode,
      'timestamp': DateTime.now().toIso8601String(),
      'data': data,
    });
    // Maksimal 50 riwayat
    if (list.length > 50) list.removeLast();
    await prefs.setString(key, jsonEncode(list));
  }

  Future<void> _exportAsJson() async {
    if (_result == null) return;
    try {
      final json = const JsonEncoder.withIndent('  ').convert(_result);
      final dir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/da1scraper_$timestamp.json');
      await file.writeAsString(json);
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Da1scraper Result',
        text: 'Hasil scraping dari Da1scraper',
      );
    } catch (e) {
      _setStatus('Gagal export: $e');
    }
  }

  Future<void> _exportAsTxt() async {
    if (_result == null) return;
    try {
      final buffer = StringBuffer();
      buffer.writeln('=== DA1SCRAPER RESULT ===');
      buffer.writeln('URL    : ${_result!['url'] ?? '-'}');
      buffer.writeln('Mode   : $_selectedMode');
      buffer.writeln('Time   : ${DateTime.now()}');
      buffer.writeln('');
      _result!.forEach((k, v) {
        if (k != 'url') buffer.writeln('[$k]\n$v\n');
      });

      final dir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${dir.path}/da1scraper_$timestamp.txt');
      await file.writeAsString(buffer.toString());
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Da1scraper Result',
      );
    } catch (e) {
      _setStatus('Gagal export: $e');
    }
  }

  void _setStatus(String s) => setState(() => _status = s);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    _buildModeSelector(),
                    const SizedBox(height: 16),
                    _buildUrlInput(),
                    const SizedBox(height: 16),
                    _buildRunButton(),
                    if (_status.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      _buildStatusBar(),
                    ],
                    if (_result != null) ...[
                      const SizedBox(height: 20),
                      _buildResultCard(),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            primaryBlue.withOpacity(0.25),
            accentCyan.withOpacity(0.1),
            primaryBlue.withOpacity(0.2),
          ],
        ),
        border: Border(
          bottom: BorderSide(color: accentCyan.withOpacity(0.15)),
        ),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Opacity(
              opacity: _pulseAnim.value,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accentCyan,
                  boxShadow: [
                    BoxShadow(
                      color: accentCyan.withOpacity(0.6),
                      blurRadius: 8,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'DA1SCRAPER',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: accentCyan.withOpacity(0.6),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
              Text(
                'Halo, ${widget.name}',
                style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
          const Spacer(),
          Icon(Icons.radar, color: accentCyan.withOpacity(0.7), size: 28),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'MODE SCRAPER',
          style: TextStyle(
            color: accentCyan,
            fontSize: 11,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 3.2,
          ),
          itemCount: _modes.length,
          itemBuilder: (_, i) {
            final mode = _modes[i];
            final bool isSelected = _selectedMode == mode['id'];
            return GestureDetector(
              onTap: () => setState(() => _selectedMode = mode['id']),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? accentCyan.withOpacity(0.15)
                      : cardGlass,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? accentCyan : borderGlass,
                    width: isSelected ? 1.5 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      mode['icon'] as IconData,
                      color: isSelected ? accentCyan : Colors.white.withOpacity(0.38),
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        mode['label'] as String,
                        style: TextStyle(
                          color: isSelected ? accentCyan : Colors.white54,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                          fontWeight: isSelected
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildUrlInput() {
    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: urlController,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontFamily: 'ShareTechMono',
              ),
              decoration: InputDecoration(
                hintText: 'https://target.com/page',
                hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
                prefixIcon: Icon(Icons.link, color: accentCyan, size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 4,
                ),
              ),
            ),
          ),
          // Paste button
          GestureDetector(
            onTap: () async {
              final data = await Clipboard.getData('text/plain');
              if (data?.text != null) {
                urlController.text = data!.text!;
              }
            },
            child: Container(
              padding: const EdgeInsets.all(14),
              child: Icon(Icons.content_paste, color: Colors.white.withOpacity(0.38), size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRunButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          gradient: _isLoading
              ? LinearGradient(
                  colors: [primaryBlue.withOpacity(0.4), accentCyan.withOpacity(0.4)],
                )
              : LinearGradient(
                  colors: [primaryBlue, accentCyan],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: _isLoading
              ? []
              : [
                  BoxShadow(
                    color: accentCyan.withOpacity(0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: _isLoading ? null : _runScraper,
            borderRadius: BorderRadius.circular(14),
            child: Center(
              child: _isLoading
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(accentCyan),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'MENGAMBIL DATA...',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Orbitron',
                            fontSize: 12,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    )
                  : const Text(
                      'JALANKAN SCRAPER',
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBar() {
    final bool isError = _status.contains('✗') || _status.contains('⚠');
    final bool isSuccess = _status.contains('✓');
    final Color statusColor = isError
        ? Colors.redAccent
        : isSuccess
            ? Colors.greenAccent
            : accentCyan;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: statusColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 14,
            height: 14,
            child: _isLoading
                ? CircularProgressIndicator(
                    strokeWidth: 1.5,
                    valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                  )
                : Icon(
                    isError ? Icons.error_outline : Icons.check_circle_outline,
                    color: statusColor,
                    size: 14,
                  ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _status,
              style: TextStyle(
                color: statusColor,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'HASIL SCRAPING',
              style: TextStyle(
                color: accentCyan,
                fontSize: 11,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
            const Spacer(),
            // Export buttons
            _buildExportBtn(
              label: 'JSON',
              icon: Icons.data_object,
              onTap: _exportAsJson,
            ),
            const SizedBox(width: 8),
            _buildExportBtn(
              label: 'TXT',
              icon: Icons.text_snippet_outlined,
              onTap: _exportAsTxt,
            ),
            const SizedBox(width: 8),
            _buildExportBtn(
              label: 'Detail',
              icon: Icons.open_in_new,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ResultDetailPage(
                      result: _result!,
                      url: urlController.text.trim(),
                      mode: _selectedMode,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderGlass),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _result!.entries
                .where((e) => e.value != null && e.value.toString().isNotEmpty)
                .map((entry) => _buildResultRow(entry.key, entry.value))
                .toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildResultRow(String key, dynamic value) {
    final String displayValue = value is List
        ? value.join('\n• ')
        : value.toString();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            key.toUpperCase(),
            style: TextStyle(
              color: accentCyan.withOpacity(0.8),
              fontSize: 10,
              fontFamily: 'Orbitron',
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 4),
          GestureDetector(
            onLongPress: () {
              Clipboard.setData(ClipboardData(text: displayValue));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('$key disalin',
                      style: const TextStyle(fontFamily: 'ShareTechMono')),
                  backgroundColor: accentCyan.withOpacity(0.8),
                  duration: const Duration(seconds: 1),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              );
            },
            child: Text(
              value is List ? '• $displayValue' : displayValue,
              style: TextStyle(
                color: Colors.white.withOpacity(0.87),
                fontSize: 13,
                fontFamily: 'ShareTechMono',
                height: 1.5,
              ),
              maxLines: 6,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Divider(color: Colors.white.withOpacity(0.06), height: 16),
        ],
      ),
    );
  }

  Widget _buildExportBtn({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderGlass),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: accentCyan, size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: accentCyan,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
