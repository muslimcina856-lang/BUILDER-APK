package com.carromroyale.game3d

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
