# Aplikasi ini tiada kebergantungan pihak ketiga dan tiada kod Dart yang
# dipanggil secara refleksi, jadi peraturan yang diperlukan sangat sedikit.
# Enjin Flutter sendiri ialah kod natif dan tidak disentuh R8.

# Kelas embedding Flutter dirujuk daripada AndroidManifest dan JNI.
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# MainActivity dirujuk melalui nama dalam manifest.
-keep class com.carromroyale.game3d.MainActivity { *; }

# Kekalkan nombor baris supaya surih tindanan ranap masih boleh dibaca,
# tetapi sembunyikan nama fail sumber sebenar.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
