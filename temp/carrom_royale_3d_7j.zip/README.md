# Carrom Royale 3D

Permainan carrom Flutter untuk Android — enjin fizik cakera tersuai, kamera
perspektif 3D sebenar, dan lawan AI yang membidik secara geometri.
Tiada pakej luaran: hanya Flutter SDK.

---

## Cara jalankan

```bash
unzip carrom_royale_3d.zip
cd carrom_royale_3d
flutter pub get
flutter run                  # peranti/emulator Android
flutter build apk --release  # keluaran APK
flutter test                 # ujian fizik
```

**Tiada `flutter create` diperlukan.** Satu-satunya fail yang tiada dalam zip
ialah `gradle-wrapper.jar` (binari) dan skrip `gradlew` — Flutter menyuntiknya
secara automatik pada binaan pertama, dan ia TIDAK menimpa fail sedia ada, jadi
konfigurasi dalam zip ini kekal. `android/local.properties` juga dijana sendiri
oleh Flutter.

Binaan release ditandatangani dengan kunci debug supaya `flutter build apk
--release` terus jalan. Untuk terbitan sebenar di Play Store, jana keystore
sendiri dan ganti `signingConfig` dalam `android/app/build.gradle`.

### Matriks versi

Semua dipin secara eksplisit — tiada `flutter.compileSdkVersion` yang berubah
ikut versi Flutter yang dipasang.

| Komponen | Versi | Kenapa versi ini |
|---|---|---|
| **compileSdk** | **36** | Android 16 — ditetapkan eksplisit, bukan warisan Flutter |
| **targetSdk** | **36** | sepadan compileSdk |
| minSdk | 24 | Flutter tak lagi sokong API 21–23 secara aktif |
| **versionCode** | **1** | nombor binaan = 1 |
| versionName | 1.0.0 | sepadan `version: 1.0.0+1` dalam pubspec |
| Android Gradle Plugin | 8.13.2 | 8.x terkini; API 36 perlu AGP ≥ 8.9.1 |
| Gradle | 8.13 | minimum **dan** lalai rasmi untuk AGP 8.13 |
| Kotlin | 2.2.21 | pasangan rasmi AGP 8.13.2 dalam dokumentasi Google |
| JDK | 17 | diwajibkan AGP 8.13 |
| Java / Kotlin JVM target | 17 / 17 | mesti sama, jika tidak AGP gagal |
| Dart SDK | `>=3.8.0 <4.0.0` | diwajibkan flutter_lints 6.0.0 |
| flutter_lints | ^6.0.0 | versi terkini di pub.dev |
| Kebergantungan runtime | **tiada** | hanya Flutter SDK |

**AGP 9.x sengaja dielakkan.** Ia keluaran major dengan DSL baharu, dan
keserasiannya dengan Flutter masih dalam audit terbuka
(flutter/flutter#175688, mitigasi `android.newDsl=false`). AGP 8.13.2 ialah
versi terkini yang menyokong API 36 **dan** terbukti stabil dengan Flutter.

Dua API usang turut dielakkan: `rootProject.buildDir` (dibuang dalam Gradle 9)
digantikan `layout.buildDirectory`, dan `kotlinOptions {}` (dijadual dibuang
dalam Kotlin 2.3) digantikan DSL `compilerOptions`.

**Nota:** compileSdk 36 memerlukan platform "Android 16 (API 36)" dipasang
melalui SDK Manager. Jika tidak, Gradle gagal dengan `Failed to find target
with hash string 'android-36'`.

---

## Binaan release

```bash
# AAB untuk Google Play — Play memecah ABI sendiri, jadi jangan guna
# --split-per-abi di sini.
flutter build appbundle --release \
        --obfuscate --split-debug-info=build/symbols

# APK untuk edaran terus. --split-per-abi menghasilkan satu APK setiap
# seni bina dan bukan satu APK gemuk (kira-kira 30-40% lebih kecil).
flutter build apk --release --split-per-abi \
        --obfuscate --split-debug-info=build/symbols
```

`--obfuscate` mengelirukan nama simbol Dart; `--split-debug-info` mengeluarkan
peta simbol daripada binari supaya saiznya mengecil. **Simpan folder
`build/symbols`** untuk setiap keluaran — tanpanya surih tindanan ranap dari
pengguna tidak boleh dibaca semula.

Sebaik dibuka, kedua-duanya terus berjalan menggunakan kunci debug. Untuk
terbitan sebenar, buat dua perkara:

**1. Jana keystore dan sambungkannya**

```bash
keytool -genkey -v -keystore ~/carrom-release.jks \
        -keyalg RSA -keysize 2048 -validity 10000 -alias carrom
cp android/key.properties.example android/key.properties
# isi laluan dan kata laluan sebenar dalam android/key.properties
```

`build.gradle` mengesan `android/key.properties` secara automatik. Jika ada, ia
menandatangani dengan kunci anda; jika tiada, ia jatuh balik ke kunci debug.
Fail itu dan `*.jks` sudah disenaraikan dalam `.gitignore` — **jangan sekali-kali
commit**. Hilang keystore bermakna anda tidak boleh mengemas kini aplikasi itu
di Play Store selama-lamanya.

**2. Tukar applicationId kepada domain anda sendiri**

Sekarang ia `com.carromroyale.game3d`. Google Play **menolak** apa-apa yang
bermula dengan `com.example`, dan applicationId **tidak boleh diubah** selepas
penerbitan pertama. Tukar di tiga tempat sekaligus: `namespace` dan
`applicationId` dalam `android/app/build.gradle`, baris `package` dan laluan
folder `MainActivity.kt`, dan baris `-keep` dalam `proguard-rules.pro`.

### Apa yang sudah disiapkan untuk release

| | |
|---|---|
| Penandatanganan | `key.properties` dengan jatuh balik ke kunci debug |
| R8 | `minifyEnabled` + `shrinkResources` dihidupkan |
| Peraturan ProGuard | `android/app/proguard-rules.pro` (kekalkan embedding Flutter) |
| Kebenaran release | **kosong** — INTERNET hanya dalam varian debug/profile |
| Sandaran | dimatikan; permainan tidak menyimpan data pengguna |
| Ikon | adaptif (API 26+) + monokrom bertema + PNG legasi untuk API 24-25 |
| Skrin lancar | latar gelap sepadan, tiada kelipan putih |
| Orientasi | dikunci menegak |

Jejak `Dart` tiada `print()` atau `debugPrint()` langsung, jadi tiada log
terlepas ke binaan release.

---

## Model fizik

Semua unit dunia ialah **milimeter sebenar** papan bertaraf ICF: kawasan
permainan 740 mm, buah berjejari 15.9 mm, striker 20.6 mm, lubang 22.6 mm.

**Geseran gelongsor–putaran terganding.** Satu cakera rata yang menggelongsor
sambil berputar berkongsi satu belanjawan geseran Coulomb antara gerakan lurus
dan gerakan putaran (kesan Contensou):

```
denom      = sqrt(v² + (ω·r·k)²)
a_lurus    = μg · v/denom
α_putaran  = μg · K/r · (ω·r·k)/denom
```

Kesannya nyata semasa bermain: buah yang berputar laju meluncur lebih jauh,
dan buah yang laju kehilangan putaran lebih perlahan. Daya geseran sisi
**membengkokkan** laluan tanpa menambah laju, jadi tenaga sistem terjamin
menurun secara monotonik (ada ujian untuk ini).

**Perlanggaran** diselesaikan dengan impuls. Untuk normal `n` dan tangen `t`:

```
j_n = -(1+e)·vₙ / (1/mA + 1/mB)
j_t = -vₜ / (1/mA + 1/mB + rA²/IA + rB²/IB),  |j_t| ≤ μ·|j_n|
Δω  = I⁻¹ · (r × j_t)
```

Halaju titik sentuh mengambil kira putaran (`v + ω × r`), jadi putaran
berpindah antara buah — sebab itu buah yang dilanggar sisi akan berputar.
Momen inersia cakera pejal `I = ½mr²`.

**Ketepatan.** Setiap bingkai dipecahkan kepada sub-langkah supaya tiada buah
bergerak melebihi 0.32 × jejari per langkah — striker pada 3.35 m/s pun tidak
boleh menembusi buah lain. Impuls halaju dan pembetulan kedudukan diasingkan
supaya kelompok 19 buah semasa pukulan pembuka kekal stabil.

**Sempadan.** Bantal rata hanya wujud di luar bukaan lubang; titik bukaan
dikira daripada persilangan bulatan lubang dengan garisan bantal, bukan
diteka. Sudut dilindungi arka cekung supaya buah tidak boleh terbang keluar.

---

## Saluran render 3D

Bukan lukisan 2D yang "nampak macam 3D" — ini unjuran perspektif sebenar.

* Kamera *look-at* dengan asas ortonormal `(right, up, forward)`.
  Unjuran: `skrin = asal + k·(cx/cz, −cy/cz)`.
* Kerana unjuran linear terhadap `k`, faktor muat dikira **sekali** daripada
  kotak sempadan lapan bucu papan — papan sentiasa muat tepat pada mana-mana
  saiz skrin tanpa lelaran.
* **Unjuran songsang** memancarkan sinar dari kamera melalui titik sentuhan
  dan memotongnya dengan satah `z = 0`. Sebab itu jari anda memetakan tepat ke
  koordinat papan walaupun kamera dicondongkan.
* Bulatan diunjur titik demi titik, jadi ia menjadi **elips** dengan betul.
  Setiap buah ialah silinder pendek: cincin bawah pada `z = 0`, cincin atas
  pada `z = tebal`, dan siluet sisi ialah **lilitan cembung** gabungan
  kedua-dua cincin — betul dari mana-mana sudut.
* Muka bingkai kayu diwarnakan dengan pencahayaan Lambert daripada normal
  muka, dengan pemusnahan muka belakang sebenar.
* Bayang ialah unjuran cincin atas ke satah papan sepanjang arah cahaya:
  `p − (L.xy / L.z)·h`.
* Ukiran pada buah diputar mengikut sudut fizik sebenar — jadi anda boleh
  **nampak** putaran yang dikira oleh enjin.

Butang `3D / ATAS` menukar kecondongan kamera secara lancar; kedua-dua mod
menggunakan saluran unjuran yang sama.

---

## Peraturan yang dilaksanakan

* Susunan pembukaan rasmi: ratu di tengah, cincin 6, cincin 12 (9 putih, 9 hitam).
* Masukkan buah sendiri → giliran diteruskan.
* Buah lawan yang termasuk dikira **untuk lawan**.
* Striker masuk lubang, atau tidak menyentuh apa-apa → foul + satu buah dipulangkan.
* Tiada buah untuk dipulangkan → **hutang** yang dibayar daripada buah berikutnya.
* **Ratu**: hanya boleh dicuba selepas ada satu buah sendiri. Jika masuk
  bersama buah sendiri → terus dilindungi. Jika masuk sendirian → wajib
  dilindungi pada pukulan berikutnya, kalau tidak ratu dikembalikan ke tengah.
* **Buah terakhir sebelum ratu tidak sah** — buah itu dipulangkan.
* Mata papan = baki buah lawan + 5 jika ratu dilindungi (jika skor < 22).
* Perlawanan sehingga 25 mata atau 8 papan.
* Buah yang dipulangkan diletak dengan carian lingkaran ke ruang kosong
  terdekat dari tengah.

---

## Lawan AI

Dua peringkat:

1. **Geometri.** Bagi setiap buah sendiri × setiap lubang × 11 kedudukan
   striker, kira titik *bola hantu* — pusat striker pada saat sentuhan:
   `hantu = buah − arah_lubang · (r_striker + r_buah)`. Tapis pukulan dengan
   sudut potong terlalu tipis, laluan terhalang (ujian bulatan tersapu), atau
   sudut di luar hemisfera sah. Kuasa dianggar daripada jarak dibahagi kosinus
   sudut potong.
2. **Pengesahan.** Calon terbaik disimulasikan penuh menggunakan enjin fizik
   yang sama, kemudian dimarkahkan: buah sendiri +130, buah lawan −85, striker
   masuk −175, ratu +150 jika boleh dilindungi, ditambah nilai kedudukan
   selepas pukulan.

Empat tahap kesukaran mengubah lebar carian dan ralat manusia yang
ditambah (Santai ±4.9°/±24% kuasa … Pro ±0.3°/±2%).

---

## Struktur

```
lib/
  core/      vec.dart      Vec2 / Vec3 / pembantu
             spec.dart     geometri papan + pemalar fizik
  physics/   piece.dart    cakera tegar (jisim, inersia, putaran)
             world.dart    integrasi, impuls, bantal, lubang
  game/      setup.dart    susunan & penempatan semula
             game.dart     mesin keadaan + enjin peraturan
             ai.dart       carian bola hantu + simulasi
             prediction.dart  ramalan laluan bidikan
  render/    camera.dart      unjuran perspektif + songsangan
             board_renderer.dart  papan 3D bercahaya
             piece_renderer.dart  buah 3D + bayang
             scene_painter.dart   susunan kedalaman + kesan
             palette.dart
  ui/        menu_screen.dart, game_screen.dart, hud.dart
test/        physics_test.dart
```

## Pengoptimuman render

Sasaran utama: `BoardRenderer` bergantung pada kamera **sahaja** — tiada
keadaan permainan. Namun setiap bingkai ia mengulang kerja yang menghasilkan
piksel yang serupa:

| Kerja per bingkai | Sebelum | Selepas |
|---|---:|---:|
| Unjuran titik (papan) | 400 | 0 |
| `Path.combine` (boolean geometri CPU) | 2 | 0 |
| Kecerunan dibina | 13 | 0 |
| `Paint` diperuntukkan (papan) | 22 | 0 |
| `Paint` diperuntukkan (bayang buah) | 40 | 0 |
| Senarai diperuntukkan + diisih | 1 | 0 |

Papan kini dirakam sekali ke dalam `ui.Picture`; bingkai berikutnya hanya
`drawPicture` — senarai paparan yang sudah siap. Cache terbatal hanya apabila
saiz, pitch, atau yaw berubah, iaitu semasa peralihan 3D/atas dan goncangan
kamera. Pada 60 fps ini menghapuskan kira-kira **28,700 operasi sesaat**.

Dua `Paint` bayang buah adalah malar sepenuhnya, jadi diangkat menjadi
`static final`. Senarai buah boleh-lihat kini diguna semula dan bukan
diperuntukkan semula setiap bingkai.

Tiada `saveLayer` langsung dalam kod ini — dokumentasi Flutter menyenaraikannya
sebagai operasi paling mahal kerana ia memperuntukkan penimbal luar-skrin dan
mencetuskan pertukaran sasaran render pada GPU.

**Yang sengaja TIDAK dilakukan:** melangkau bingkai ketika melahu. Ia akan
menjatuhkan penggunaan CPU ke sifar semasa membidik, tetapi memerlukan
penjejakan setiap keadaan yang boleh mengubah paparan — terlepas satu sahaja
bermakna bingkai basi. Risiko itu tidak berbaloi; Ticker Flutter sudah
disenyapkan secara automatik apabila aplikasi di latar belakang.

## Pengesahan

Sandbox tempat kod ini ditulis tiada Dart SDK, jadi `flutter analyze` tidak
dapat dijalankan. Sebagai ganti, tiga pemeriksa statik ditulis khas dan
dijalankan sehingga bersih:

* **Rujukan ahli** — jadual ahli setiap kelas dibina (termasuk warisan dan
  `extension`), jenis pembolehubah disimpulkan, dan setiap `x.ahli` disahkan
  wujud. Nama yang taip-nya tidak pasti diabaikan, bukan diteka.
* **Argumen pembina** — setiap argumen bernama disemak terhadap tandatangan
  pembina sebenar, termasuk parameter `required` yang tertinggal.
* **Import** — setiap jenis dan fungsi peringkat atas milik projek disahkan
  boleh dicapai melalui senarai import failnya.

Ditambah semakan berangka geometri papan (mulut lubang cukup luas untuk
striker, jejari tangkapan mencetus sebelum buah tersepit, jarak sub-langkah
lebih kecil daripada zon tangkapan, cincin buah pembukaan tidak bertindih) dan
semakan keseimbangan kurungan, CRLF, tab dan newline akhir pada setiap fail.

## Ujian

`flutter test` mengesahkan: susunan papan sah tanpa pertindihan, tenaga
kinetik tidak pernah bertambah sepanjang 900 langkah, hukum pemulihan
dipatuhi, momentum terpelihara semasa impuls, buah tidak pernah terlepas
keluar papan pada kelajuan maksimum, unjuran songsang tepat dalam 0.5 mm,
dan peraturan foul serta ratu berkelakuan betul.
