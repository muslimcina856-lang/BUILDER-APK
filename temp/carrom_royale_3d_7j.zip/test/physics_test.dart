import 'dart:ui';

import 'package:carrom_royale_3d/core/spec.dart';
import 'package:carrom_royale_3d/core/vec.dart';
import 'package:carrom_royale_3d/game/game.dart';
import 'package:carrom_royale_3d/game/setup.dart';
import 'package:carrom_royale_3d/physics/piece.dart';
import 'package:carrom_royale_3d/physics/world.dart';
import 'package:carrom_royale_3d/render/camera.dart';
import 'package:flutter_test/flutter_test.dart';

double kinetic(PhysicsWorld w) {
  var e = 0.0;
  for (final p in w.pieces) {
    if (!p.inPlay) continue;
    e += 0.5 * p.mass * p.velocity.lengthSq;
    e += 0.5 * p.inertia * p.angularVelocity * p.angularVelocity;
  }
  return e;
}

void main() {
  group('susunan papan', () {
    test('19 buah, tiada pertindihan, semua dalam kawasan permainan', () {
      final w = PhysicsWorld();
      arrangeBoard(w);

      expect(w.countOnBoard(PieceKind.white), 9);
      expect(w.countOnBoard(PieceKind.black), 9);
      expect(w.countOnBoard(PieceKind.queen), 1);

      final coins = w.pieces.where((p) => p.kind.isCoin).toList();
      for (var i = 0; i < coins.length; i++) {
        final a = coins[i];
        expect(a.position.length + a.radius, lessThan(BoardSpec.half));
        for (var j = i + 1; j < coins.length; j++) {
          final b = coins[j];
          expect(
            a.position.distanceTo(b.position),
            greaterThanOrEqualTo(a.radius + b.radius - 1e-6),
            reason: 'buah $i dan $j bertindih',
          );
        }
      }
    });
  });

  group('fizik', () {
    test('tenaga kinetik tidak pernah bertambah', () {
      final w = PhysicsWorld();
      arrangeBoard(w);
      final s = w.striker!;
      s.onBoard = true;
      s.position = Vec2(0, BoardSpec.baselineY(0));
      s.velocity = Vec2.polar(1.4, 3000);

      var last = kinetic(w);
      for (var i = 0; i < 900; i++) {
        w.step(1 / 120);
        final now = kinetic(w);
        expect(now, lessThanOrEqualTo(last * 1.000001 + 1e-6),
            reason: 'tenaga bertambah pada langkah $i');
        last = now;
      }
      expect(w.settled, isTrue, reason: 'sistem sepatutnya berhenti');
    });

    test('hukum pemulihan dipatuhi pada perlanggaran sepusat', () {
      final w = PhysicsWorld();
      final a = Piece.coin(0, PieceKind.white, const Vec2(-40, 0));
      final b = Piece.coin(1, PieceKind.black, const Vec2(0, 0));
      a.velocity = const Vec2(900, 0);
      w.pieces.addAll([a, b]);

      final approach = (a.velocity - b.velocity).x;
      for (var i = 0; i < 40; i++) {
        w.step(1 / 240);
        if (b.velocity.x > 1) break;
      }
      final separation = (b.velocity - a.velocity).x;
      expect(separation / approach, closeTo(Phys.coinRestitution, 0.08));
    });

    test('momentum terpelihara semasa impuls sentuhan', () {
      final w = PhysicsWorld();
      final a = Piece.coin(0, PieceKind.white, const Vec2(-30.9, 0));
      final b = Piece.coin(1, PieceKind.black, const Vec2(0, 0));
      a.velocity = const Vec2(1200, 0);
      w.pieces.addAll([a, b]);

      final before = a.velocity * a.mass + b.velocity * b.mass;
      w.step(1 / 480); // satu langkah kecil: geseran hampir tiada
      final after = a.velocity * a.mass + b.velocity * b.mass;

      final frictionBound =
          Phys.slideFriction * Phys.gravity * (a.mass + b.mass) * (1 / 480) * 1.6;
      expect((after - before).length, lessThan(frictionBound));
    });

    test('buah masuk lubang apabila melepasi bibir', () {
      final w = PhysicsWorld();
      final target = BoardSpec.pocketCenter(2);
      final coin = Piece.coin(0, PieceKind.white, target - const Vec2(60, 60));
      coin.velocity = (target - coin.position).normalized * 700;
      w.pieces.add(coin);

      for (var i = 0; i < 200 && !coin.pocketed; i++) {
        w.step(1 / 240);
      }
      expect(coin.pocketed, isTrue);
      expect(coin.pocketIndex, 2);
      expect(w.pocketedThisShot.length, 1);
    });

    test('buah tidak pernah terlepas keluar papan', () {
      final w = PhysicsWorld();
      arrangeBoard(w);
      final s = w.striker!;
      s.onBoard = true;
      s.position = Vec2(0, BoardSpec.baselineY(0));
      s.velocity = Vec2.polar(1.05, Phys.maxStrikerSpeed);

      for (var i = 0; i < 1400; i++) {
        w.step(1 / 120);
        for (final p in w.pieces) {
          if (!p.inPlay) continue;
          final limit = BoardSpec.half + BoardSpec.jawRadius;
          expect(p.position.x.abs(), lessThan(limit));
          expect(p.position.y.abs(), lessThan(limit));
        }
      }
    });
  });

  group('kamera 3D', () {
    test('unjuran songsang memulangkan titik asal pada satah papan', () {
      final cam = SceneCamera();
      cam.configure(const Size(1080, 1920), pitchRad: 1.02);

      for (final probe in const [
        Vec2(0, 0),
        Vec2(300, -260),
        Vec2(-355, 355),
        Vec2(120, -370),
      ]) {
        final screen = cam.projectPlane(probe);
        final back = cam.unproject(screen);
        expect(back, isNotNull);
        expect(back!.distanceTo(probe), lessThan(0.5),
            reason: 'gagal untuk $probe');
      }
    });
  });

  group('peraturan', () {
    test('striker masuk lubang menamatkan giliran dan dikenakan penalti', () {
      final g = CarromGame(difficulty: Difficulty.biasa, versusAi: false, seed: 7);
      g.players[0].pocketedCount = 2;
      // Tandakan satu buah putih sebagai telah masuk supaya ada yang boleh dipulangkan.
      final white = g.world.pieces.firstWhere((p) => p.kind == PieceKind.white);
      white.pocketed = true;

      final before = g.players[0].pocketedCount;
      g.shoot(angle: 1.5708, p: 0.9);
      // Paksa striker masuk lubang.
      final s = g.world.striker!;
      s.position = BoardSpec.pocketCenter(2);
      s.velocity = Vec2.zero;
      for (var i = 0; i < 400 && g.phase == GamePhase.simulating; i++) {
        g.update(1 / 120);
      }

      expect(g.players[0].fouls, greaterThan(0));
      expect(g.players[0].pocketedCount, lessThanOrEqualTo(before));
    });

    test('ratu dikembalikan jika gagal dilindungi', () {
      final g = CarromGame(difficulty: Difficulty.biasa, versusAi: false, seed: 3);
      g.queenPendingBy = 0;
      g.queenOnBoard = false;
      final queen = g.world.pieces.firstWhere((p) => p.kind == PieceKind.queen);
      queen.pocketed = true;

      g.shoot(angle: 1.5708, p: 0.12);
      for (var i = 0; i < 1400 && g.phase == GamePhase.simulating; i++) {
        g.update(1 / 120);
      }

      expect(g.queenPendingBy, -1);
      expect(g.queenOnBoard, isTrue);
      expect(queen.pocketed, isFalse);
    });
  });
}
