import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../core/spec.dart';
import '../core/vec.dart';
import '../game/ai.dart';
import '../game/game.dart';
import '../render/camera.dart';
import '../render/board_renderer.dart';
import '../render/palette.dart';
import '../render/scene_painter.dart';
import 'hud.dart';

enum _DragMode { none, place, aim }

class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.difficulty,
    required this.versusAi,
  });

  final Difficulty difficulty;
  final bool versusAi;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late final CarromGame game;
  late final AiPlayer ai;
  late final Ticker _ticker;

  final SceneCamera camera = SceneCamera();
  final SparkField sparks = SparkField();
  final BoardCache boardCache = BoardCache();
  final ValueNotifier<int> _frame = ValueNotifier<int>(0);

  Duration _last = Duration.zero;
  _DragMode _mode = _DragMode.none;
  bool _aiBusy = false;
  bool _guide = true;
  bool _tilted = true;
  double _pitch = 1.02;
  double _hapticCooldown = 0;

  static const double _pitch3d = 1.02; // ~58 darjah
  static const double _pitchFlat = 1.5533; // ~89 darjah (hampir atas)

  @override
  void initState() {
    super.initState();
    game = CarromGame(difficulty: widget.difficulty, versusAi: widget.versusAi);
    ai = AiPlayer(widget.difficulty, math.Random());
    _ticker = createTicker(_tick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _frame.dispose();
    boardCache.dispose();
    game.dispose();
    super.dispose();
  }

  void _tick(Duration now) {
    var dt = (now - _last).inMicroseconds / 1e6;
    _last = now;
    dt = clampD(dt, 0, 1 / 24);
    if (dt <= 0) return;

    game.update(dt);
    sparks.update(dt);
    if (_hapticCooldown > 0) _hapticCooldown -= dt;

    for (final impact in game.world.impacts) {
      sparks.burst(impact.point, impact.strength, wall: impact.againstWall);
      if (impact.strength > 0.35 && _hapticCooldown <= 0) {
        _hapticCooldown = 0.09;
        HapticFeedback.lightImpact();
      }
    }
    game.world.impacts.clear();

    final target = _tilted ? _pitch3d : _pitchFlat;
    if ((_pitch - target).abs() > 0.001) {
      _pitch += (target - _pitch) * math.min(1.0, dt * 7);
    }

    if (game.me.isAi &&
        !_aiBusy &&
        (game.phase == GamePhase.positioning || game.phase == GamePhase.aiming)) {
      _runAi();
    }

    _frame.value++;
    if (mounted) setState(() {});
  }

  Future<void> _runAi() async {
    _aiBusy = true;
    game.aiThinking = true;
    try {
      await Future<void>.delayed(const Duration(milliseconds: 380));
      if (!mounted) return;

      final plan = await Future<ShotPlan>(() => ai.decide(game));
      if (!mounted) return;

      game.setStrikerX(plan.strikerX);
      game.setAim(plan.angle, plan.power);
      await Future<void>.delayed(const Duration(milliseconds: 420));
      if (!mounted) return;

      game.shoot(angle: plan.angle, p: plan.power);
    } catch (_) {
      // Jangan sekali-kali biarkan giliran AI tersekat: kalau perancangan
      // gagal, tembak lurus ke hadapan supaya permainan terus berjalan.
      final stillAiTurn = game.me.isAi &&
          (game.phase == GamePhase.positioning ||
              game.phase == GamePhase.aiming);
      if (mounted && stillAiTurn) {
        game.shoot(angle: BoardSpec.forwardAngle(game.current), p: 0.75);
      }
    } finally {
      // Mesti dilepaskan pada SETIAP laluan keluar, termasuk `return` awal
      // dan pengecualian — jika tidak, AI tidak akan bermain lagi.
      game.aiThinking = false;
      _aiBusy = false;
    }
  }

  // ------------------------------------------------------------------ input

  Vec2? _toBoard(Offset local) => camera.unproject(local);

  void _onPanStart(DragStartDetails d) {
    if (!game.awaitingHuman) return;
    final p = _toBoard(d.localPosition);
    if (p == null) return;
    final striker = Vec2(game.strikerX, game.baselineY);
    final grabRadius = BoardSpec.strikerRadius * 2.8;
    if (game.phase == GamePhase.positioning &&
        p.distanceTo(striker) < grabRadius) {
      _mode = _DragMode.place;
      game.setStrikerX(p.x);
    } else {
      _mode = _DragMode.aim;
      _applyAim(p);
    }
  }

  void _onPanUpdate(DragUpdateDetails d) {
    if (!game.awaitingHuman || _mode == _DragMode.none) return;
    final p = _toBoard(d.localPosition);
    if (p == null) return;
    if (_mode == _DragMode.place) {
      game.setStrikerX(p.x);
    } else {
      _applyAim(p);
    }
  }

  void _onPanEnd(DragEndDetails d) {
    if (_mode == _DragMode.aim && game.awaitingHuman && game.power > 0.08) {
      HapticFeedback.mediumImpact();
      game.shoot();
    }
    _mode = _DragMode.none;
  }

  /// Kawalan lastik: tarik ke belakang striker, lepas untuk tembak.
  void _applyAim(Vec2 touch) {
    final striker = Vec2(game.strikerX, game.baselineY);
    final pull = striker - touch;
    if (pull.length < 6) return;
    game.setAim(pull.angle, clampD(pull.length / 265.0, 0.05, 1.0));
  }

  void _onTapDown(TapDownDetails d) {
    if (!game.awaitingHuman || game.phase != GamePhase.positioning) return;
    final p = _toBoard(d.localPosition);
    if (p == null) return;
    if ((p.y - game.baselineY).abs() < 70) {
      game.setStrikerX(p.x);
    }
  }

  // ------------------------------------------------------------------ paparan

  @override
  Widget build(BuildContext context) {
    final showBoardOver = game.phase == GamePhase.boardOver;
    final showMatchOver = game.phase == GamePhase.matchOver;

    return Scaffold(
      backgroundColor: Palette.roomDeep,
      body: Stack(
        children: [
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: _onTapDown,
              onPanStart: _onPanStart,
              onPanUpdate: _onPanUpdate,
              onPanEnd: _onPanEnd,
              child: RepaintBoundary(
                child: CustomPaint(
                  painter: ScenePainter(
                    game: game,
                    camera: camera,
                    sparks: sparks,
                    pitch: _pitch,
                    showGuide: _guide,
                    dragAim: _mode == _DragMode.aim,
                    boardCache: boardCache,
                    repaintNotifier: _frame,
                  ),
                  size: Size.infinite,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _topBar(),
                const Spacer(),
                if (game.bannerTimer > 0)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Banner2(text: game.banner, visible: true),
                  ),
                const SizedBox(height: 10),
                _bottomBar(),
              ],
            ),
          ),
          if (game.aiThinking)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(top: 96),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Palette.hudBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Palette.hudLine),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            width: 12,
                            height: 12,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Palette.brass),
                          ),
                          const SizedBox(width: 9),
                          Text('AI MENGIRA SUDUT', style: Palette.label.copyWith(fontSize: 10)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (showBoardOver)
            Positioned.fill(
              child: ResultSheet(
                title:
                    '${game.players[game.boardWinner].name} menang papan ${game.boardNumber}',
                lines: [
                  'Mata perlawanan  ${game.players[0].matchScore} — ${game.players[1].matchScore}',
                  'Sasaran ${game.matchTarget} mata',
                ],
                primaryLabel: 'PAPAN SETERUSNYA',
                onPrimary: () => setState(game.nextBoard),
                onMenu: () => Navigator.of(context).pop(),
              ),
            ),
          if (showMatchOver)
            Positioned.fill(
              child: ResultSheet(
                title: game.matchWinner == 0
                    ? 'ANDA JUARA'
                    : '${game.players[game.matchWinner].name} JUARA',
                lines: [
                  'Keputusan akhir  ${game.players[0].matchScore} — ${game.players[1].matchScore}',
                  '${game.boardNumber} papan dimainkan',
                ],
                primaryLabel: 'MAIN LAGI',
                onPrimary: () => setState(() {
                  game.boardNumber = 0;
                  for (final p in game.players) {
                    p.matchScore = 0;
                  }
                  game.matchWinner = -1;
                  game.nextBoard();
                }),
                onMenu: () => Navigator.of(context).pop(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PlayerCard(game: game, index: 0, alignEnd: false),
          const Spacer(),
          Column(
            children: [
              Text('PAPAN ${game.boardNumber}', style: Palette.label.copyWith(fontSize: 9)),
              const SizedBox(height: 4),
              GlassButton(
                icon: Icons.close,
                onTap: () => Navigator.of(context).pop(),
              ),
            ],
          ),
          const Spacer(),
          PlayerCard(game: game, index: 1, alignEnd: true),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    final hint = _hintText();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Column(
        children: [
          Row(
            children: [
              GlassButton(
                icon: _tilted ? Icons.threed_rotation : Icons.crop_square,
                label: _tilted ? '3D' : 'ATAS',
                active: _tilted,
                onTap: () => setState(() => _tilted = !_tilted),
              ),
              const SizedBox(width: 8),
              GlassButton(
                icon: _guide ? Icons.visibility : Icons.visibility_off,
                label: 'PANDUAN',
                active: _guide,
                onTap: () => setState(() => _guide = !_guide),
              ),
              const Spacer(),
              if (game.queenPendingBy >= 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: const Color(0xE0431216),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: Palette.queenRed),
                  ),
                  child: Text('RATU BELUM DILINDUNGI',
                      style: Palette.label.copyWith(fontSize: 9, color: Palette.coinBone)),
                ),
            ],
          ),
          const SizedBox(height: 10),
          PowerMeter(power: game.power, active: game.awaitingHuman),
          const SizedBox(height: 7),
          SizedBox(
            height: 30,
            child: Text(hint, textAlign: TextAlign.center, style: Palette.body),
          ),
        ],
      ),
    );
  }

  String _hintText() {
    if (game.phase == GamePhase.simulating) return 'Buah sedang bergerak…';
    if (game.me.isAi) return '${game.me.name} sedang bermain';
    if (game.phase == GamePhase.positioning) {
      return 'Seret striker pada garisan • tarik ke belakang untuk membidik';
    }
    return 'Kuasa ${(game.power * 100).round()}%  •  lepas untuk tembak';
  }
}
