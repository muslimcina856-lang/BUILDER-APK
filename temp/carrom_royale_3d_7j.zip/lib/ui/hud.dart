import 'package:flutter/material.dart';

import '../core/vec.dart';
import '../game/game.dart';
import '../physics/piece.dart';
import '../render/palette.dart';

class PlayerCard extends StatelessWidget {
  const PlayerCard({
    super.key,
    required this.game,
    required this.index,
    required this.alignEnd,
  });

  final CarromGame game;
  final int index;
  final bool alignEnd;

  @override
  Widget build(BuildContext context) {
    final p = game.players[index];
    final active = game.current == index && game.phase != GamePhase.matchOver;
    final left = game.coinsLeft(p.kind);
    final coinColor =
        p.kind == PieceKind.white ? Palette.coinBone : Palette.coinEbony;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 240),
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 10),
      decoration: BoxDecoration(
        color: active ? const Color(0xF01A3334) : Palette.hudBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: active ? Palette.brass : Palette.hudLine,
          width: active ? 1.4 : 1.0,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!alignEnd) _dot(coinColor),
              if (!alignEnd) const SizedBox(width: 7),
              Text(p.name.toUpperCase(), style: Palette.label),
              if (game.queenOwner == index) ...[
                const SizedBox(width: 6),
                const Icon(Icons.workspace_premium,
                    size: 14, color: Palette.queenRed),
              ],
              if (game.queenPendingBy == index) ...[
                const SizedBox(width: 6),
                const Icon(Icons.hourglass_bottom,
                    size: 14, color: Palette.brass),
              ],
              if (alignEnd) const SizedBox(width: 7),
              if (alignEnd) _dot(coinColor),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text('${p.matchScore}', style: Palette.number),
              const SizedBox(width: 6),
              Text('mata', style: Palette.label.copyWith(fontSize: 9)),
            ],
          ),
          const SizedBox(height: 5),
          _CoinTray(
            total: 9,
            remaining: left,
            color: coinColor,
            alignEnd: alignEnd,
          ),
          if (p.due > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('hutang ${p.due}',
                  style: Palette.label
                      .copyWith(color: Palette.danger, fontSize: 9)),
            ),
        ],
      ),
    );
  }

  Widget _dot(Color c) => Container(
        width: 11,
        height: 11,
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          border: Border.all(color: const Color(0x66FFFFFF), width: 0.8),
        ),
      );
}

class _CoinTray extends StatelessWidget {
  const _CoinTray({
    required this.total,
    required this.remaining,
    required this.color,
    required this.alignEnd,
  });

  final int total;
  final int remaining;
  final Color color;
  final bool alignEnd;

  @override
  Widget build(BuildContext context) {
    final chips = List<Widget>.generate(total, (i) {
      final potted = i >= remaining;
      return Container(
        width: 8,
        height: 8,
        margin: const EdgeInsets.symmetric(horizontal: 1.5),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: potted ? color : const Color(0x2AFFFFFF),
          border: Border.all(
            color: potted ? const Color(0x88E0B04A) : const Color(0x33FFFFFF),
            width: 0.8,
          ),
        ),
      );
    });
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: alignEnd ? chips.reversed.toList() : chips,
    );
  }
}

class PowerMeter extends StatelessWidget {
  const PowerMeter({super.key, required this.power, required this.active});

  final double power;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 10,
      decoration: BoxDecoration(
        color: const Color(0x66000000),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Palette.hudLine),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Align(
          alignment: Alignment.centerLeft,
          child: FractionallySizedBox(
            widthFactor: clampD(power, 0, 1),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Palette.teal,
                    Color.lerp(Palette.brass, Palette.danger, power)!,
                  ],
                ),
              ),
              child: const SizedBox.expand(),
            ),
          ),
        ),
      ),
    );
  }
}

class Banner2 extends StatelessWidget {
  const Banner2({super.key, required this.text, required this.visible});

  final String text;
  final bool visible;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 260),
        opacity: visible ? 1 : 0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          decoration: BoxDecoration(
            color: Palette.hudBg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Palette.hudLine),
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: Palette.body.copyWith(fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }
}

class GlassButton extends StatelessWidget {
  const GlassButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.label,
    this.active = false,
  });

  final IconData icon;
  final String? label;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? const Color(0xE01E4A47) : Palette.hudBg,
      borderRadius: BorderRadius.circular(11),
      child: InkWell(
        borderRadius: BorderRadius.circular(11),
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: label == null ? 10.0 : 13.0, vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: active ? Palette.brass : Palette.hudLine),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: active ? Palette.brass : const Color(0xFFB9C9C7)),
              if (label != null) ...[
                const SizedBox(width: 7),
                Text(label!, style: Palette.label.copyWith(fontSize: 10)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class ResultSheet extends StatelessWidget {
  const ResultSheet({
    super.key,
    required this.title,
    required this.lines,
    required this.primaryLabel,
    required this.onPrimary,
    required this.onMenu,
  });

  final String title;
  final List<String> lines;
  final String primaryLabel;
  final VoidCallback onPrimary;
  final VoidCallback onMenu;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xAA02090A),
      alignment: Alignment.center,
      child: Container(
        width: 320,
        padding: const EdgeInsets.fromLTRB(22, 24, 22, 18),
        decoration: BoxDecoration(
          color: const Color(0xF20D1E20),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Palette.hudLine),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, textAlign: TextAlign.center, style: Palette.display.copyWith(fontSize: 24)),
            const SizedBox(height: 14),
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Text(l, textAlign: TextAlign.center, style: Palette.body),
              ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: onPrimary,
                style: FilledButton.styleFrom(
                  backgroundColor: Palette.brass,
                  foregroundColor: const Color(0xFF1A1206),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: Text(primaryLabel,
                    style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.4)),
              ),
            ),
            TextButton(
              onPressed: onMenu,
              child: Text('MENU UTAMA', style: Palette.label.copyWith(fontSize: 10)),
            ),
          ],
        ),
      ),
    );
  }
}
