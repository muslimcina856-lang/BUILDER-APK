import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../core/vec.dart';
import '../game/game.dart';
import '../game/setup.dart';
import '../physics/world.dart';
import '../render/board_renderer.dart';
import '../render/camera.dart';
import '../render/palette.dart';
import '../render/piece_renderer.dart';
import 'game_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final PhysicsWorld _preview = PhysicsWorld();
  final ValueNotifier<double> _t = ValueNotifier<double>(0);
  Duration _last = Duration.zero;
  Difficulty _difficulty = Difficulty.biasa;
  bool _versusAi = true;

  @override
  void initState() {
    super.initState();
    arrangeBoard(_preview);
    _ticker = createTicker((now) {
      final dt = (now - _last).inMicroseconds / 1e6;
      _last = now;
      _t.value += clampD(dt, 0, 0.05);
    })..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _t.dispose();
    super.dispose();
  }

  void _start() {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => GameScreen(difficulty: _difficulty, versusAi: _versusAi),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Palette.roomDeep,
      body: Stack(
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: CustomPaint(
                painter: _PreviewPainter(_preview, _t),
              ),
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xCC050D0D), Color(0x22050D0D), Color(0xF2050D0D)],
                  stops: [0.0, 0.42, 0.78],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 26, 24, 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('DEWAN', style: Palette.label.copyWith(letterSpacing: 6)),
                  const SizedBox(height: 6),
                  const Text('CARROM\nROYALE 3D', style: Palette.display),
                  const SizedBox(height: 8),
                  Container(width: 54, height: 2, color: Palette.brass),
                  const Spacer(),
                  Text('LAWAN', style: Palette.label),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _choice('AI', _versusAi, () => setState(() => _versusAi = true)),
                      const SizedBox(width: 8),
                      _choice('2 PEMAIN', !_versusAi, () => setState(() => _versusAi = false)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  AnimatedOpacity(
                    duration: const Duration(milliseconds: 200),
                    opacity: _versusAi ? 1 : 0.35,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text('TAHAP AI', style: Palette.label),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            for (final d in Difficulty.values) ...[
                              _choice(
                                d.label.toUpperCase(),
                                _difficulty == d,
                                _versusAi ? () => setState(() => _difficulty = d) : null,
                                dense: true,
                              ),
                              if (d != Difficulty.values.last) const SizedBox(width: 6),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 26),
                  FilledButton(
                    onPressed: _start,
                    style: FilledButton.styleFrom(
                      backgroundColor: Palette.brass,
                      foregroundColor: const Color(0xFF1A1206),
                      padding: const EdgeInsets.symmetric(vertical: 17),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(13)),
                    ),
                    child: const Text('MULA BERMAIN',
                        style: TextStyle(
                            fontWeight: FontWeight.w900, letterSpacing: 2.2, fontSize: 15)),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Fizik cakera sebenar • kamera perspektif • peraturan ICF penuh',
                    textAlign: TextAlign.center,
                    style: Palette.label.copyWith(fontSize: 9, letterSpacing: 1.1),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _choice(String text, bool active, VoidCallback? onTap, {bool dense = false}) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: EdgeInsets.symmetric(vertical: dense ? 9.0 : 13.0),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? const Color(0xE01E4A47) : const Color(0x99101F20),
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: active ? Palette.brass : Palette.hudLine),
          ),
          child: Text(
            text,
            style: Palette.label.copyWith(
              fontSize: dense ? 9.0 : 11.0,
              color: active ? Palette.brass : const Color(0xFF9FB3B2),
            ),
          ),
        ),
      ),
    );
  }
}

class _PreviewPainter extends CustomPainter {
  _PreviewPainter(this.world, this.t) : super(repaint: t);

  final PhysicsWorld world;
  final ValueNotifier<double> t;
  final SceneCamera cam = SceneCamera();

  @override
  void paint(Canvas canvas, Size size) {
    final time = t.value;
    cam.configure(
      Size(size.width, size.height * 0.92),
      pitchRad: 0.72 + math.sin(time * 0.25) * 0.06,
      yawRad: math.sin(time * 0.18) * 0.30,
      zoom: 0.86,
    );
    final board = BoardRenderer(cam);
    final pieces = PieceRenderer(cam);

    board.paintRoom(canvas, size);
    canvas.save();
    canvas.translate(0, -size.height * 0.06);
    board.paint(canvas, size);

    final live = world.pieces.where((p) => p.inPlay).toList()
      ..sort((a, b) => cam
          .depth(Vec3(b.position.x, b.position.y, 0))
          .compareTo(cam.depth(Vec3(a.position.x, a.position.y, 0))));
    for (final p in live) {
      pieces.paintShadow(canvas, p);
    }
    for (final p in live) {
      pieces.paint(canvas, p);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _PreviewPainter old) => true;
}
