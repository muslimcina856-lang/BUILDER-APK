import '../core/spec.dart';
import '../core/vec.dart';

enum PieceKind { striker, white, black, queen }

extension PieceKindX on PieceKind {
  bool get isCoin => this != PieceKind.striker;
  bool get isPlayerCoin => this == PieceKind.white || this == PieceKind.black;

  String get label {
    switch (this) {
      case PieceKind.striker:
        return 'Striker';
      case PieceKind.white:
        return 'Putih';
      case PieceKind.black:
        return 'Hitam';
      case PieceKind.queen:
        return 'Ratu';
    }
  }
}

/// Cakera tegar dengan jisim, momen inersia, dan putaran.
/// Momen inersia cakera pejal: I = 1/2 m r^2.
class Piece {
  final int id;
  final PieceKind kind;
  final double radius;
  final double thickness;
  final double mass;
  final double invMass;
  final double inertia;
  final double invInertia;

  Vec2 position;
  Vec2 velocity = Vec2.zero;
  double angle;
  double angularVelocity = 0;

  bool onBoard = true;
  bool pocketed = false;
  int pocketIndex = -1;

  /// 0..1 animasi jatuh ke dalam lubang.
  double pocketProgress = 0;

  /// 0..1 kilauan selepas dilanggar (kesan visual sahaja).
  double glow = 0;

  Piece({
    required this.id,
    required this.kind,
    required this.radius,
    required this.thickness,
    required this.mass,
    required this.position,
    this.angle = 0,
  })  : invMass = 1.0 / mass,
        inertia = 0.5 * mass * radius * radius,
        invInertia = 1.0 / (0.5 * mass * radius * radius);

  bool get inPlay => onBoard && !pocketed;
  double get speed => velocity.length;

  bool get isResting =>
      velocity.lengthSq < Phys.sleepLinear * Phys.sleepLinear &&
      angularVelocity.abs() < Phys.sleepAngular;

  void stop() {
    velocity = Vec2.zero;
    angularVelocity = 0;
  }

  void resetTo(Vec2 p) {
    position = p;
    velocity = Vec2.zero;
    angularVelocity = 0;
    onBoard = true;
    pocketed = false;
    pocketIndex = -1;
    pocketProgress = 0;
  }

  Piece cloneShallow() {
    final c = Piece(
      id: id,
      kind: kind,
      radius: radius,
      thickness: thickness,
      mass: mass,
      position: position,
      angle: angle,
    );
    c.velocity = velocity;
    c.angularVelocity = angularVelocity;
    c.onBoard = onBoard;
    c.pocketed = pocketed;
    c.pocketIndex = pocketIndex;
    c.pocketProgress = pocketProgress;
    return c;
  }

  static Piece coin(int id, PieceKind kind, Vec2 pos) => Piece(
        id: id,
        kind: kind,
        radius: BoardSpec.coinRadius,
        thickness: BoardSpec.coinThickness,
        mass: BoardSpec.coinMass,
        position: pos,
        angle: (id * 0.7) % 6.28318,
      );

  static Piece striker(int id, Vec2 pos) => Piece(
        id: id,
        kind: PieceKind.striker,
        radius: BoardSpec.strikerRadius,
        thickness: BoardSpec.strikerThickness,
        mass: BoardSpec.strikerMass,
        position: pos,
      );
}
