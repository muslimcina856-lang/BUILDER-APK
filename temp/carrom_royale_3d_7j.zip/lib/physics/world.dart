import 'dart:math' as math;

import '../core/spec.dart';
import '../core/vec.dart';
import 'piece.dart';

class ImpactEvent {
  final Vec2 point;
  final double strength; // 0..1
  final bool againstWall;
  ImpactEvent(this.point, this.strength, this.againstWall);
}

class PocketEvent {
  final Piece piece;
  final int pocket;
  PocketEvent(this.piece, this.pocket);
}

/// Enjin fizik cakera 2D dengan geseran gelongsor-berputar terganding.
///
/// Model geseran: satu cakera rata yang menggelongsor sambil berputar
/// berkongsi satu belanjawan geseran Coulomb antara gerakan lurus dan
/// gerakan putaran (kesan Contensou). Sebab itu buah yang berputar laju
/// meluncur lebih jauh, dan buah yang laju kehilangan putaran lebih perlahan.
class PhysicsWorld {
  final List<Piece> pieces = <Piece>[];

  final List<PocketEvent> pocketedThisShot = <PocketEvent>[];
  final List<ImpactEvent> impacts = <ImpactEvent>[];

  bool firstContactMade = false;
  PieceKind? firstContactKind;
  double strongestImpact = 0;
  double elapsed = 0;
  int strikerId = -1;

  void clear() {
    pieces.clear();
    resetShot();
  }

  void resetShot() {
    pocketedThisShot.clear();
    impacts.clear();
    firstContactMade = false;
    firstContactKind = null;
    strongestImpact = 0;
    elapsed = 0;
  }

  Piece? byId(int id) {
    for (final p in pieces) {
      if (p.id == id) return p;
    }
    return null;
  }

  Piece? get striker => byId(strikerId);

  Iterable<Piece> get live => pieces.where((p) => p.inPlay);

  int countOnBoard(PieceKind kind) =>
      pieces.where((p) => p.kind == kind && p.inPlay).length;

  bool get settled {
    for (final p in pieces) {
      if (!p.inPlay) continue;
      if (!p.isResting) return false;
    }
    return true;
  }

  bool get anyMoving => !settled;

  void stopAll() {
    for (final p in pieces) {
      p.stop();
    }
  }

  // ---------------------------------------------------------------- langkah

  /// Melangkah simulasi. [fast] mengurangkan ketepatan untuk carian AI.
  void step(double dt, {bool fast = false}) {
    if (dt <= 0) return;
    impacts.clear();

    final n = _substepCount(dt, fast);
    final h = dt / n;
    for (var i = 0; i < n; i++) {
      _integrate(h);
      _solveContacts(fast);
      _separate(fast ? 1 : 2);
      for (final p in pieces) {
        if (p.inPlay) _bounds(p);
      }
      _capture();
    }
    _sleep();
    elapsed += dt;
  }

  /// Animasi kosmetik sahaja (jatuh ke lubang, kilauan).
  void animate(double dt) {
    for (final p in pieces) {
      if (p.pocketed && p.pocketProgress < 1) {
        p.pocketProgress = math.min(1.0, p.pocketProgress + dt * 3.4);
      }
      if (p.glow > 0) p.glow = math.max(0.0, p.glow - dt * 2.6);
    }
  }

  int _substepCount(double dt, bool fast) {
    var maxV = 0.0;
    for (final p in pieces) {
      if (!p.inPlay) continue;
      final s = p.velocity.lengthSq;
      if (s > maxV) maxV = s;
    }
    maxV = math.sqrt(maxV);
    final travel = maxV * dt;
    final limit = Phys.substepTravel * BoardSpec.coinRadius;
    // `NaN.ceil()` melontar UnsupportedError dalam Dart, bukan pulangkan NaN.
    if (!travel.isFinite) return fast ? 6 : Phys.maxSubsteps;
    var n = (travel / limit).ceil();
    if (n < 1) n = 1;
    final cap = fast ? 6 : Phys.maxSubsteps;
    if (n > cap) n = cap;
    return n;
  }

  // ------------------------------------------------------------- integrasi

  void _integrate(double h) {
    final mu = Phys.slideFriction * Phys.gravity;
    final rf = Phys.contactRadiusFactor;

    for (final p in pieces) {
      if (!p.inPlay) continue;

      final v = p.velocity;
      final w = p.angularVelocity;
      final speed = v.length;
      final spinSurface = w.abs() * p.radius * rf;

      if (speed < 1e-7 && spinSurface < 1e-7) continue;

      // Pembahagian belanjawan geseran antara gelongsor dan putaran.
      final denom = math.sqrt(speed * speed + spinSurface * spinSurface) + 1e-9;
      final slideShare = speed / denom;
      final spinShare = spinSurface / denom;

      var nv = v;
      if (speed > 1e-7) {
        final decel = mu * slideShare + Phys.viscousDrag * speed;
        final ns = math.max(0.0, speed - decel * h);
        nv = v * (ns / speed);

        // Hanyutan sisi akibat putaran: daya geseran sisi membengkokkan
        // laluan tanpa menambah laju, jadi tenaga kekal menurun.
        if (spinSurface > 1e-6 && ns > 1e-6) {
          final lateral = Phys.spinDrift * mu * spinShare * slideShare;
          final bend = -w.sign * lateral * h / math.max(ns, 1.0);
          nv = nv.rotated(bend);
        }
      }

      var nw = w;
      if (w.abs() > 1e-7) {
        // alpha = mu * k / r  (torque geseran / momen inersia cakera)
        final alpha = Phys.spinFrictionK * mu / p.radius * spinShare;
        final mag = math.max(0.0, w.abs() - alpha * h);
        nw = w.sign * mag;
      }

      p.velocity = nv;
      p.angularVelocity = nw;
      p.position = p.position + nv * h;
      p.angle += nw * h;
    }
  }

  void _sleep() {
    for (final p in pieces) {
      if (!p.inPlay) continue;
      if (p.velocity.lengthSq < Phys.sleepLinear * Phys.sleepLinear) {
        p.velocity = Vec2.zero;
      }
      if (p.angularVelocity.abs() < Phys.sleepAngular) {
        p.angularVelocity = 0;
      }
    }
  }

  // ------------------------------------------------------------- perlanggaran

  void _solveContacts(bool fast) {
    final n = pieces.length;
    for (var i = 0; i < n; i++) {
      final a = pieces[i];
      if (!a.inPlay) continue;
      for (var j = i + 1; j < n; j++) {
        final b = pieces[j];
        if (!b.inPlay) continue;

        final d = b.position - a.position;
        final rr = a.radius + b.radius;
        final dist2 = d.lengthSq;
        if (dist2 >= rr * rr || dist2 < 1e-12) continue;

        final dist = math.sqrt(dist2);
        final nrm = d / dist;

        // Halaju titik sentuh = v + omega x r
        final ra = nrm * a.radius;
        final rb = nrm * (-b.radius);
        final va = a.velocity + Vec2(-a.angularVelocity * ra.y, a.angularVelocity * ra.x);
        final vb = b.velocity + Vec2(-b.angularVelocity * rb.y, b.angularVelocity * rb.x);
        final rv = vb - va;
        final vn = rv.dot(nrm);
        if (vn > 0) continue; // sudah memisah

        final invSum = a.invMass + b.invMass;
        final e = Phys.coinRestitution;
        final jn = -(1 + e) * vn / invSum;
        final impulse = nrm * jn;
        a.velocity = a.velocity - impulse * a.invMass;
        b.velocity = b.velocity + impulse * b.invMass;

        // Geseran tangen + pemindahan putaran
        final t = nrm.perp;
        final vt = rv.dot(t);
        final rotTerm = a.invInertia * a.radius * a.radius +
            b.invInertia * b.radius * b.radius;
        var jt = -vt / (invSum + rotTerm);
        final maxFriction = Phys.contactFriction * jn.abs();
        jt = clampD(jt, -maxFriction, maxFriction);
        final fi = t * jt;
        a.velocity = a.velocity - fi * a.invMass;
        b.velocity = b.velocity + fi * b.invMass;
        a.angularVelocity -= a.invInertia * ra.cross(fi);
        b.angularVelocity += b.invInertia * rb.cross(fi);

        _registerImpact(a, b, a.position + nrm * a.radius, jn, false, fast);
      }
    }
  }

  /// Pembetulan kedudukan sahaja — memisahkan pertindihan tanpa menambah tenaga.
  void _separate(int iterations) {
    for (var it = 0; it < iterations; it++) {
      final n = pieces.length;
      for (var i = 0; i < n; i++) {
        final a = pieces[i];
        if (!a.inPlay) continue;
        for (var j = i + 1; j < n; j++) {
          final b = pieces[j];
          if (!b.inPlay) continue;
          final d = b.position - a.position;
          final rr = a.radius + b.radius;
          final dist2 = d.lengthSq;
          if (dist2 >= rr * rr) continue;

          double dist = math.sqrt(dist2);
          Vec2 nrm;
          if (dist < 1e-9) {
            nrm = const Vec2(1, 0);
            dist = 0;
          } else {
            nrm = d / dist;
          }
          final pen = rr - dist;
          final invSum = a.invMass + b.invMass;
          final corr = nrm * (pen * 0.82 / invSum);
          a.position = a.position - corr * a.invMass;
          b.position = b.position + corr * b.invMass;
        }
      }
    }
  }

  void _registerImpact(
      Piece a, Piece b, Vec2 point, double jn, bool wall, bool fast) {
    final strength = clampD(jn.abs() / 9000.0, 0, 1);
    if (strength > strongestImpact) strongestImpact = strength;
    a.glow = math.max(a.glow, strength);
    b.glow = math.max(b.glow, strength);

    if (!firstContactMade && (a.kind == PieceKind.striker || b.kind == PieceKind.striker)) {
      final other = a.kind == PieceKind.striker ? b : a;
      firstContactMade = true;
      firstContactKind = other.kind;
    }
    if (!fast && strength > 0.02) {
      impacts.add(ImpactEvent(point, strength, wall));
    }
  }

  // ------------------------------------------------------------------ sempadan

  void _bounds(Piece p) {
    final r = p.radius;
    const half = BoardSpec.half;
    final open = BoardSpec.wallOpening;

    // Bantal rata wujud hanya di luar bukaan lubang.
    if (p.position.y - r < -half && p.position.x.abs() < open) {
      _wall(p, const Vec2(0, 1), (-half) - (p.position.y - r), Phys.cushionRestitution);
    }
    if (p.position.y + r > half && p.position.x.abs() < open) {
      _wall(p, const Vec2(0, -1), (p.position.y + r) - half, Phys.cushionRestitution);
    }
    if (p.position.x - r < -half && p.position.y.abs() < open) {
      _wall(p, const Vec2(1, 0), (-half) - (p.position.x - r), Phys.cushionRestitution);
    }
    if (p.position.x + r > half && p.position.y.abs() < open) {
      _wall(p, const Vec2(-1, 0), (p.position.x + r) - half, Phys.cushionRestitution);
    }

    // Rahang sudut: arka cekung yang hanya aktif bila buah benar-benar
    // melepasi garisan bantal melalui mulut lubang.
    //
    // Gate mesti `ax + r > half || ay + r > half` — iaitu buah benar-benar
    // menonjol keluar. Gate lama membandingkan pusat buah dengan
    // `half - r * 0.25`, meninggalkan jalur di mana buah sudah melepasi
    // bantal tetapi belum cukup hampir untuk mencetuskan rahang, dan bantal
    // rata pula sudah dimatikan kerana koordinat satu lagi melebihi bukaan.
    // Dalam jalur itu buah boleh menonjol sehingga ~11.7 mm tanpa sebarang
    // tindak balas perlanggaran.
    final ax = p.position.x.abs();
    final ay = p.position.y.abs();
    if (ax > open && ay > open && (ax + r > half || ay + r > half)) {
      final idx = _quadrantPocket(p.position);
      final c = BoardSpec.pocketCenter(idx);
      final d = p.position - c;
      final dist = d.length;
      final limit = BoardSpec.jawRadius - r;
      if (dist > limit && dist > 1e-9) {
        _wall(p, -(d / dist), dist - limit, Phys.jawRestitution);
      }
    }
  }

  int _quadrantPocket(Vec2 p) {
    if (p.y < 0) return p.x < 0 ? 0 : 1;
    return p.x < 0 ? 3 : 2;
  }

  /// [n] menghala ke dalam papan; [penetration] > 0 bermakna bertindih.
  void _wall(Piece p, Vec2 n, double penetration, double restitution) {
    if (penetration > 0) {
      p.position = p.position + n * penetration;
    }
    final vn = p.velocity.dot(n);
    if (vn >= 0) return;

    final t = n.perp;
    // Halaju tangen pada titik sentuh (r = -n * radius)
    final vtRel = p.velocity.dot(t) - p.angularVelocity * p.radius;

    final jn = -(1 + restitution) * vn / p.invMass;
    p.velocity = p.velocity + n * (jn * p.invMass);

    final rotTerm = p.invInertia * p.radius * p.radius;
    var jt = -vtRel / (p.invMass + rotTerm);
    final maxFriction = Phys.cushionFriction * jn.abs();
    jt = clampD(jt, -maxFriction, maxFriction);
    p.velocity = p.velocity + t * (jt * p.invMass);
    p.angularVelocity += p.invInertia * (-p.radius * jt);

    final strength = clampD(jn.abs() / 9000.0, 0, 1);
    if (strength > 0.02) {
      impacts.add(ImpactEvent(p.position - n * p.radius, strength, true));
    }
  }

  // ------------------------------------------------------------------- lubang

  void _capture() {
    for (final p in pieces) {
      if (!p.inPlay) continue;
      for (var i = 0; i < 4; i++) {
        final c = BoardSpec.pocketCenter(i);
        if (p.position.distanceSqTo(c) <
            BoardSpec.captureRadius * BoardSpec.captureRadius) {
          p.pocketed = true;
          p.pocketIndex = i;
          p.pocketProgress = 0;
          p.velocity = Vec2.zero;
          p.angularVelocity *= 0.4;
          p.position = c;
          pocketedThisShot.add(PocketEvent(p, i));
          break;
        }
      }
    }
  }

  // ------------------------------------------------------------------ salinan

  PhysicsWorld cloneForSimulation() {
    final w = PhysicsWorld();
    for (final p in pieces) {
      w.pieces.add(p.cloneShallow());
    }
    w.strikerId = strikerId;
    return w;
  }
}
