import 'dart:math' as math;

import '../core/spec.dart';
import '../core/vec.dart';
import '../physics/piece.dart';
import '../physics/world.dart';

/// Susunan pembukaan rasmi: ratu di tengah, cincin dalam 6 buah selang-seli,
/// cincin luar 12 buah selang-seli — jumlah 9 putih + 9 hitam.
void arrangeBoard(PhysicsWorld world) {
  world.clear();
  var id = 0;

  world.pieces.add(Piece.coin(id++, PieceKind.queen, Vec2.zero));

  const innerR = BoardSpec.coinRadius * 2 + 0.35;
  for (var i = 0; i < 6; i++) {
    final a = math.pi / 2 + i * math.pi / 3;
    final kind = i.isEven ? PieceKind.black : PieceKind.white;
    world.pieces.add(Piece.coin(id++, kind, Vec2.polar(a, innerR)));
  }

  const outerR = BoardSpec.coinRadius * 4 + 0.9;
  for (var i = 0; i < 12; i++) {
    final a = math.pi / 2 + math.pi / 12 + i * math.pi / 6;
    final kind = i.isEven ? PieceKind.white : PieceKind.black;
    world.pieces.add(Piece.coin(id++, kind, Vec2.polar(a, outerR)));
  }

  final striker = Piece.striker(id++, Vec2(0, BoardSpec.baselineY(0)));
  striker.onBoard = false; // striker hanya wujud semasa pukulan
  world.pieces.add(striker);
  world.strikerId = striker.id;
}

/// Mencari kedudukan kosong berhampiran tengah untuk mengembalikan buah
/// (penalti atau ratu tidak dilindungi). Lingkaran keluar sehingga jumpa ruang.
Vec2 findFreeSpot(PhysicsWorld world, double radius, {Vec2? preferred}) {
  final origin = preferred ?? Vec2.zero;
  if (_isFree(world, origin, radius)) return origin;

  for (var ring = 1; ring <= 14; ring++) {
    final r = ring * radius * 0.95;
    final count = 6 + ring * 4;
    final phase = ring * 0.37;
    for (var i = 0; i < count; i++) {
      final a = phase + i * 2 * math.pi / count;
      final p = origin + Vec2.polar(a, r);
      if (p.length > BoardSpec.half - radius * 2.2) continue;
      if (_isFree(world, p, radius)) return p;
    }
  }
  return origin;
}

bool _isFree(PhysicsWorld world, Vec2 p, double radius) {
  for (var i = 0; i < 4; i++) {
    if (p.distanceTo(BoardSpec.pocketCenter(i)) < BoardSpec.pocketRadius + radius + 6) {
      return false;
    }
  }
  for (final other in world.pieces) {
    if (!other.inPlay) continue;
    final min = radius + other.radius + 0.6;
    if (p.distanceSqTo(other.position) < min * min) return false;
  }
  return true;
}
