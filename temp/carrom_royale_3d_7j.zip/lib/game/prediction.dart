import 'dart:math' as math;

import '../core/spec.dart';
import '../core/vec.dart';
import '../physics/piece.dart';
import '../physics/world.dart';

class Segment {
  final Vec2 a;
  final Vec2 b;
  const Segment(this.a, this.b);
}

class Prediction {
  final List<Segment> path;

  /// Pusat striker pada saat sentuhan pertama.
  final Vec2? contact;

  /// Buah pertama yang akan disentuh.
  final Piece? target;

  /// Arah anggaran buah tersebut akan bergerak (garis pusat-ke-pusat).
  final Vec2? targetDir;

  /// Benar jika laluan berakhir masuk lubang.
  final bool intoPocket;

  const Prediction(this.path, this.contact, this.target, this.targetDir, this.intoPocket);
}

/// Ramalan laluan striker: ujian bulatan tersapu terhadap setiap buah,
/// dan pantulan pada bantal. Berhenti pada sentuhan pertama kerana
/// selepas itu hasilnya bergantung pada impuls sebenar.
Prediction predictShot(
  PhysicsWorld world,
  Vec2 start,
  double angle, {
  double strikerRadius = BoardSpec.strikerRadius,
  int maxBounces = 3,
  double maxDistance = 2300,
}) {
  final segments = <Segment>[];
  var origin = start;
  var dir = Vec2.polar(angle, 1);
  var budget = maxDistance;

  for (var bounce = 0; bounce <= maxBounces; bounce++) {
    // --- sentuhan buah terdekat ---
    double bestT = double.infinity;
    Piece? hit;
    for (final p in world.pieces) {
      if (!p.inPlay || p.kind == PieceKind.striker) continue;
      final t = _sweepCircle(origin, dir, strikerRadius, p.position, p.radius);
      if (t != null && t > 0.4 && t < bestT) {
        bestT = t;
        hit = p;
      }
    }

    // --- sentuhan bantal ---
    final wall = _wallHit(origin, dir, strikerRadius);

    if (hit != null && bestT <= (wall?.t ?? double.infinity) && bestT <= budget) {
      final contact = origin + dir * bestT;
      segments.add(Segment(origin, contact));
      final td = (hit.position - contact).normalized;
      return Prediction(segments, contact, hit, td, false);
    }

    if (wall == null || wall.t > budget) {
      segments.add(Segment(origin, origin + dir * budget));
      return Prediction(segments, null, null, null, false);
    }

    final at = origin + dir * wall.t;
    segments.add(Segment(origin, at));
    budget -= wall.t;

    if (wall.pocket) {
      return Prediction(segments, null, null, null, true);
    }
    // pantulan cermin
    dir = dir - wall.normal * (2 * dir.dot(wall.normal));
    origin = at + dir * 0.01;
    if (budget <= 1) break;
  }

  return Prediction(segments, null, null, null, false);
}

class _WallHit {
  final double t;
  final Vec2 normal;
  final bool pocket;
  const _WallHit(this.t, this.normal, this.pocket);
}

_WallHit? _wallHit(Vec2 origin, Vec2 dir, double radius) {
  final lim = BoardSpec.half - radius;
  double best = double.infinity;
  Vec2 normal = Vec2.zero;
  var tangential = 0.0;

  void consider(double t, Vec2 n, double tang) {
    if (t > 1e-4 && t < best) {
      best = t;
      normal = n;
      tangential = tang;
    }
  }

  if (dir.x.abs() > 1e-9) {
    final tR = (lim - origin.x) / dir.x;
    if (tR > 0) consider(tR, const Vec2(-1, 0), (origin.y + dir.y * tR).abs());
    final tL = (-lim - origin.x) / dir.x;
    if (tL > 0) consider(tL, const Vec2(1, 0), (origin.y + dir.y * tL).abs());
  }
  if (dir.y.abs() > 1e-9) {
    final tT = (lim - origin.y) / dir.y;
    if (tT > 0) consider(tT, const Vec2(0, -1), (origin.x + dir.x * tT).abs());
    final tB = (-lim - origin.y) / dir.y;
    if (tB > 0) consider(tB, const Vec2(0, 1), (origin.x + dir.x * tB).abs());
  }

  if (best == double.infinity) return null;
  final intoPocket = tangential > BoardSpec.wallOpening - radius * 0.4;
  return _WallHit(best, normal, intoPocket);
}

/// Masa (jarak) sehingga bulatan bergerak berjejari [rA] menyentuh
/// bulatan pegun berjejari [rB]. Mengembalikan null jika tiada sentuhan.
double? _sweepCircle(Vec2 origin, Vec2 dir, double rA, Vec2 center, double rB) {
  final rel = origin - center;
  final rr = rA + rB;
  final a = dir.dot(dir);
  final b = 2 * rel.dot(dir);
  final c = rel.dot(rel) - rr * rr;
  final disc = b * b - 4 * a * c;
  if (disc < 0) return null;
  final sq = math.sqrt(disc);
  final t1 = (-b - sq) / (2 * a);
  if (t1 >= 0) return t1;
  final t2 = (-b + sq) / (2 * a);
  if (t2 >= 0) return t2;
  return null;
}
