import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../core/spec.dart';
import '../core/vec.dart';
import '../physics/piece.dart';
import '../physics/world.dart';
import 'setup.dart';

enum Side { white, black }

enum PlayerType { human, ai }

enum Difficulty { santai, biasa, susah, pro }

extension DifficultyX on Difficulty {
  String get label {
    switch (this) {
      case Difficulty.santai:
        return 'Santai';
      case Difficulty.biasa:
        return 'Biasa';
      case Difficulty.susah:
        return 'Susah';
      case Difficulty.pro:
        return 'Pro';
    }
  }

  /// Ralat sudut membidik (radian) dan ralat kuasa (pecahan).
  double get aimNoise {
    switch (this) {
      case Difficulty.santai:
        return 0.085;
      case Difficulty.biasa:
        return 0.040;
      case Difficulty.susah:
        return 0.016;
      case Difficulty.pro:
        return 0.005;
    }
  }

  double get powerNoise {
    switch (this) {
      case Difficulty.santai:
        return 0.24;
      case Difficulty.biasa:
        return 0.12;
      case Difficulty.susah:
        return 0.05;
      case Difficulty.pro:
        return 0.02;
    }
  }

  int get searchWidth {
    switch (this) {
      case Difficulty.santai:
        return 4;
      case Difficulty.biasa:
        return 8;
      case Difficulty.susah:
        return 12;
      case Difficulty.pro:
        return 16;
    }
  }
}

enum GamePhase { positioning, aiming, simulating, boardOver, matchOver }

class PlayerState {
  final Side side;
  final PlayerType type;
  final String name;

  int matchScore = 0;
  int pocketedCount = 0;
  int fouls = 0;

  /// Buah yang terhutang kerana foul semasa tiada buah untuk dipulangkan.
  int due = 0;

  PlayerState({required this.side, required this.type, required this.name});

  PieceKind get kind => side == Side.white ? PieceKind.white : PieceKind.black;
  bool get isAi => type == PlayerType.ai;
}

class ShotRecord {
  final int player;
  final double angle;
  final double power;
  final List<PieceKind> pocketed;
  final bool foul;
  ShotRecord(this.player, this.angle, this.power, this.pocketed, this.foul);
}

/// Keadaan penuh satu perlawanan carrom.
class CarromGame extends ChangeNotifier {
  CarromGame({
    required this.difficulty,
    required bool versusAi,
    this.matchTarget = 25,
    int? seed,
  })  : rng = math.Random(seed),
        players = [
          PlayerState(side: Side.white, type: PlayerType.human, name: 'Anda'),
          PlayerState(
            side: Side.black,
            type: versusAi ? PlayerType.ai : PlayerType.human,
            name: versusAi ? 'AI' : 'Pemain 2',
          ),
        ] {
    startBoard(firstPlayer: 0);
  }

  final PhysicsWorld world = PhysicsWorld();
  final List<PlayerState> players;
  final Difficulty difficulty;
  final int matchTarget;
  final math.Random rng;
  final List<ShotRecord> history = <ShotRecord>[];

  GamePhase phase = GamePhase.positioning;
  int current = 0;
  int boardNumber = 1;
  int boardWinner = -1;
  int matchWinner = -1;

  /// Pemain yang telah memasukkan ratu tetapi belum melindunginya.
  int queenPendingBy = -1;

  /// Pemain yang berjaya melindungi ratu.
  int queenOwner = -1;
  bool queenOnBoard = true;

  double strikerX = 0;
  double aimAngle = math.pi / 2;
  double power = 0.55;

  String banner = 'Papan 1 — giliran anda';
  double bannerTimer = 3;
  bool aiThinking = false;
  double shake = 0;

  final List<String> feed = <String>[];

  PlayerState get me => players[current];
  PlayerState get foe => players[1 - current];
  PieceKind get myKind => me.kind;
  PieceKind get foeKind => foe.kind;
  double get baselineY => BoardSpec.baselineY(current);
  double get strikerLimit => BoardSpec.strikerLimit(BoardSpec.strikerRadius);
  bool get awaitingHuman =>
      !me.isAi && (phase == GamePhase.positioning || phase == GamePhase.aiming);

  int coinsLeft(PieceKind kind) => world.countOnBoard(kind);

  // ------------------------------------------------------------------ papan

  void startBoard({int firstPlayer = 0}) {
    arrangeBoard(world);
    current = firstPlayer;
    queenOnBoard = true;
    queenOwner = -1;
    queenPendingBy = -1;
    boardWinner = -1;
    for (final p in players) {
      p.pocketedCount = 0;
      p.due = 0;
    }
    feed.clear();
    beginTurn(quiet: true);
  }

  void nextBoard() {
    boardNumber++;
    startBoard(firstPlayer: boardWinner >= 0 ? boardWinner : 0);
    _say('Papan $boardNumber bermula');
  }

  void beginTurn({bool quiet = false}) {
    world.resetShot();
    final s = world.striker;
    if (s != null) {
      strikerX = _nearestLegalStrikerX(strikerX);
      s.resetTo(Vec2(strikerX, baselineY));
      s.onBoard = false; // belum diletak di atas papan
    }
    aimAngle = BoardSpec.forwardAngle(current);
    power = 0.55;
    phase = GamePhase.positioning;
    shake = 0;
    if (!quiet) {
      _say(me.isAi ? 'Giliran ${me.name}' : 'Giliran anda — letak striker');
    }
    notifyListeners();
  }

  // -------------------------------------------------------------- kawalan

  void setStrikerX(double x) {
    if (phase != GamePhase.positioning && phase != GamePhase.aiming) return;
    strikerX = _nearestLegalStrikerX(x);
    final s = world.striker;
    if (s != null) s.position = Vec2(strikerX, baselineY);
    notifyListeners();
  }

  double _nearestLegalStrikerX(double x) {
    final lim = strikerLimit;
    var best = clampD(x, -lim, lim);
    if (_strikerFits(best)) return best;
    // Cari kedudukan sah terdekat ke kiri/kanan.
    for (var d = 2.0; d <= 2 * lim; d += 2.0) {
      final a = clampD(best - d, -lim, lim);
      if (_strikerFits(a)) return a;
      final b = clampD(best + d, -lim, lim);
      if (_strikerFits(b)) return b;
    }
    return best;
  }

  bool _strikerFits(double x) {
    final p = Vec2(x, baselineY);
    for (final other in world.pieces) {
      if (!other.inPlay || other.kind == PieceKind.striker) continue;
      final min = BoardSpec.strikerRadius + other.radius + 0.5;
      if (p.distanceSqTo(other.position) < min * min) return false;
    }
    return true;
  }

  /// Sudut dihadkan ke hemisfera hadapan supaya striker tidak ditembak
  /// terus ke bantal belakang.
  double clampAim(double angle) {
    final fwd = BoardSpec.forwardAngle(current);
    final d = angleDelta(fwd, angle);
    const maxSpread = 1.30; // ~74.5 darjah
    return fwd + clampD(d, -maxSpread, maxSpread);
  }

  void setAim(double angle, double p) {
    if (phase != GamePhase.positioning && phase != GamePhase.aiming) return;
    aimAngle = clampAim(angle);
    power = clampD(p, 0.05, 1.0);
    phase = GamePhase.aiming;
    notifyListeners();
  }

  void shoot({double? angle, double? p}) {
    if (phase != GamePhase.positioning && phase != GamePhase.aiming) return;
    final s = world.striker;
    if (s == null) return;

    aimAngle = clampAim(angle ?? aimAngle);
    power = clampD(p ?? power, 0.05, 1.0);

    s.resetTo(Vec2(strikerX, baselineY));
    s.onBoard = true;
    final speed =
        Phys.minStrikerSpeed + (Phys.maxStrikerSpeed - Phys.minStrikerSpeed) * power;
    s.velocity = Vec2.polar(aimAngle, speed);
    s.angularVelocity = 0;

    world.resetShot();
    phase = GamePhase.simulating;
    aiThinking = false;
    notifyListeners();
  }

  // --------------------------------------------------------------- kemaskini

  void update(double dt) {
    if (bannerTimer > 0) bannerTimer -= dt;
    if (shake > 0) shake = math.max(0.0, shake - dt * 2.4);

    if (phase == GamePhase.simulating) {
      world.step(dt);
      if (world.strongestImpact > 0.28) {
        shake = math.max(shake, math.min(1.0, world.strongestImpact));
        world.strongestImpact = 0;
      }
      if (world.settled || world.elapsed > Phys.maxShotSeconds) {
        world.stopAll();
        _resolveShot();
      }
    }
    world.animate(dt);
  }

  // ------------------------------------------------------------ leraian pukulan

  void _resolveShot() {
    final mine = <Piece>[];
    final theirs = <Piece>[];
    var strikerIn = false;
    var queenIn = false;

    for (final e in world.pocketedThisShot) {
      switch (e.piece.kind) {
        case PieceKind.striker:
          strikerIn = true;
          break;
        case PieceKind.queen:
          queenIn = true;
          break;
        default:
          if (e.piece.kind == myKind) {
            mine.add(e.piece);
          } else {
            theirs.add(e.piece);
          }
      }
    }

    final events = <String>[];
    var foul = false;

    if (!world.firstContactMade) {
      foul = true;
      events.add('Striker tidak menyentuh sebarang buah');
    }
    if (strikerIn) {
      foul = true;
      events.add('Striker masuk lubang');
    }

    // Buah lawan yang termasuk dikira milik lawan.
    if (theirs.isNotEmpty) {
      players[1 - current].pocketedCount += theirs.length;
      events.add('${theirs.length} buah lawan masuk (dikira untuk lawan)');
    }

    // Buah sendiri — bayar hutang penalti dahulu.
    var creditedMine = 0;
    for (final p in mine) {
      if (me.due > 0) {
        me.due--;
        _respawn(p);
        events.add('Satu buah dikembalikan (bayar hutang penalti)');
      } else {
        me.pocketedCount++;
        creditedMine++;
      }
    }

    // ------- Peraturan ratu -------
    if (queenIn) {
      queenOnBoard = false;
      if (foul) {
        _returnQueen();
        events.add('Ratu dikembalikan kerana foul');
      } else if (creditedMine > 0) {
        queenOwner = current;
        queenPendingBy = -1;
        events.add('RATU DILINDUNGI (+5 mata papan)');
      } else {
        queenPendingBy = current;
        events.add('Ratu masuk — wajib lindung pukulan seterusnya');
      }
    } else if (queenPendingBy == current) {
      if (!foul && creditedMine > 0) {
        queenOwner = current;
        queenPendingBy = -1;
        events.add('RATU DILINDUNGI (+5 mata papan)');
      } else {
        _returnQueen();
        queenPendingBy = -1;
        events.add('Gagal lindung ratu — ratu dikembalikan');
      }
    }

    // ------- Peraturan buah terakhir sebelum ratu -------
    if (coinsLeft(myKind) == 0 && queenOnBoard) {
      _penalty(current);
      foul = true;
      events.add('Buah terakhir tidak sah sebelum ratu — dipulangkan');
    }

    if (foul) {
      me.fouls++;
      if (strikerIn || !world.firstContactMade) _penalty(current);
    }

    history.add(ShotRecord(
      current,
      aimAngle,
      power,
      world.pocketedThisShot.map((e) => e.piece.kind).toList(),
      foul,
    ));

    // ------- Papan tamat? -------
    if (coinsLeft(myKind) == 0 && !queenOnBoard && queenPendingBy == -1) {
      _finishBoard(current);
      return;
    }

    final keepTurn = !foul && (creditedMine > 0 || queenIn);
    if (!keepTurn) current = 1 - current;

    if (events.isEmpty) {
      events.add(creditedMine > 0 ? 'Buah masuk!' : 'Tiada buah masuk');
    }
    for (final e in events) {
      feed.insert(0, e);
    }
    while (feed.length > 6) {
      feed.removeLast();
    }
    _say(events.join('  •  '));
    beginTurn(quiet: true);
  }

  void _returnQueen() {
    Piece? queen;
    for (final p in world.pieces) {
      if (p.kind == PieceKind.queen) queen = p;
    }
    if (queen == null) return;
    queen.resetTo(findFreeSpot(world, queen.radius));
    queenOnBoard = true;
  }

  void _respawn(Piece p) {
    p.resetTo(findFreeSpot(world, p.radius));
  }

  void _penalty(int playerIndex) {
    final player = players[playerIndex];
    final kind = player.kind;
    Piece? victim;
    for (final p in world.pieces) {
      if (p.kind == kind && p.pocketed) {
        victim = p;
        break;
      }
    }
    if (victim != null && player.pocketedCount > 0) {
      player.pocketedCount--;
      _respawn(victim);
    } else {
      player.due++;
    }
  }

  void _finishBoard(int winner) {
    boardWinner = winner;
    final loserKind = players[1 - winner].kind;
    var points = world.countOnBoard(loserKind);
    if (queenOwner == winner && players[winner].matchScore < 22) points += 5;
    if (points < 1) points = 1;
    players[winner].matchScore += points;

    if (players[winner].matchScore >= matchTarget || boardNumber >= 8) {
      matchWinner = winner;
      phase = GamePhase.matchOver;
      _say('${players[winner].name} MENANG PERLAWANAN');
    } else {
      phase = GamePhase.boardOver;
      _say('${players[winner].name} menang papan $boardNumber (+$points mata)');
    }
    notifyListeners();
  }

  void _say(String msg) {
    banner = msg;
    bannerTimer = 3.4;
  }
}
