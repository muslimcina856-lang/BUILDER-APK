import 'dart:math' as math;

import '../core/spec.dart';
import '../core/vec.dart';
import '../physics/piece.dart';
import '../physics/world.dart';
import 'game.dart';

class ShotPlan {
  double strikerX;
  double angle;
  double power;
  double prior;
  double score;
  String reason;

  ShotPlan({
    required this.strikerX,
    required this.angle,
    required this.power,
    this.prior = 0,
    this.score = 0,
    this.reason = '',
  });
}

class _SimOutcome {
  int mine = 0;
  int theirs = 0;
  bool queen = false;
  bool strikerIn = false;
  bool contact = false;
}

/// Pemain AI.
///
/// Peringkat 1 — geometri: bagi setiap buah sendiri dan setiap lubang,
/// kira titik "bola hantu" (posisi striker semasa sentuhan) dan tapis
/// laluan yang terhalang atau sudut potong terlalu tipis.
/// Peringkat 2 — pengesahan: simulasi fizik penuh ke atas calon terbaik
/// dan pilih hasil dengan markah tertinggi.
class AiPlayer {
  AiPlayer(this.difficulty, this.rng);

  final Difficulty difficulty;
  final math.Random rng;

  ShotPlan decide(CarromGame game) {
    final candidates = _generate(game);
    if (candidates.isEmpty) return _fallback(game);

    candidates.sort((a, b) => b.prior.compareTo(a.prior));
    final width = math.min(difficulty.searchWidth, candidates.length);
    final pool = candidates.sublist(0, width);

    for (final plan in pool) {
      plan.score = _evaluate(game, plan);
    }
    pool.sort((a, b) => b.score.compareTo(a.score));

    // Tahap rendah kadangkala pilih pukulan kedua/ketiga terbaik.
    var pickIndex = 0;
    if (difficulty == Difficulty.santai && pool.length > 1) {
      pickIndex = rng.nextInt(math.min(3, pool.length));
    } else if (difficulty == Difficulty.biasa && pool.length > 1 && rng.nextDouble() < 0.3) {
      pickIndex = rng.nextInt(math.min(2, pool.length));
    }

    final best = pool[pickIndex];
    if (best.score < -40 && pool.length > 1) {
      // Semua pilihan buruk: main selamat.
      final safe = _fallback(game);
      safe.reason = 'Main selamat';
      return safe;
    }

    // Tambah ralat manusia mengikut tahap kesukaran.
    final jitterAngle = (rng.nextDouble() * 2 - 1) * difficulty.aimNoise;
    final jitterPower = 1 + (rng.nextDouble() * 2 - 1) * difficulty.powerNoise;
    return ShotPlan(
      strikerX: best.strikerX,
      angle: game.clampAim(best.angle + jitterAngle),
      power: clampD(best.power * jitterPower, 0.18, 1.0),
      score: best.score,
      reason: best.reason,
    );
  }

  // ------------------------------------------------------------- penjanaan

  List<ShotPlan> _generate(CarromGame game) {
    final out = <ShotPlan>[];
    final world = game.world;
    final baseY = game.baselineY;
    final limit = game.strikerLimit;
    final rs = BoardSpec.strikerRadius;

    final targets = <Piece>[];
    for (final p in world.pieces) {
      if (!p.inPlay) continue;
      if (p.kind == game.myKind) targets.add(p);
    }
    // Ratu boleh dicuba jika sudah ada sekurang-kurangnya satu buah sendiri,
    // atau jika ia satu-satunya sasaran berbaki.
    final canQueen = game.me.pocketedCount > 0 || targets.isEmpty;
    if (canQueen && game.queenOnBoard) {
      for (final p in world.pieces) {
        if (p.inPlay && p.kind == PieceKind.queen) targets.add(p);
      }
    }
    if (targets.isEmpty) return out;

    const strikerSamples = 11;
    for (final target in targets) {
      final isQueen = target.kind == PieceKind.queen;
      for (var pi = 0; pi < 4; pi++) {
        final pocket = BoardSpec.pocketCenter(pi);
        final toPocket = pocket - target.position;
        final potDist = toPocket.length;
        if (potDist < 1e-3) continue;
        final potDir = toPocket / potDist;

        // Titik bola hantu: pusat striker pada saat sentuhan.
        final ghost = target.position - potDir * (rs + target.radius);
        if (ghost.x.abs() > BoardSpec.half - rs || ghost.y.abs() > BoardSpec.half - rs) {
          continue;
        }
        if (!_clearPath(world, target.position, pocket, target.radius, {target.id})) {
          continue;
        }

        for (var si = 0; si < strikerSamples; si++) {
          final t = strikerSamples == 1 ? 0.5 : si / (strikerSamples - 1);
          final sx = -limit + 2 * limit * t;
          final start = Vec2(sx, baseY);
          final aim = ghost - start;
          final aimDist = aim.length;
          if (aimDist < rs * 1.2) continue;
          final aimDir = aim / aimDist;

          final cut = aimDir.dot(potDir);
          if (cut < 0.22) continue; // sudut potong terlalu tipis

          // Arah mesti menghala ke dalam papan.
          final forward = BoardSpec.forwardAngle(game.current);
          if (angleDelta(forward, aimDir.angle).abs() > 1.28) continue;

          if (!_clearPath(world, start, ghost, rs, {target.id})) continue;

          // Anggaran kuasa: jarak striker + jarak buah, dilaraskan sudut potong.
          final need = (aimDist + potDist * 1.35) / math.max(0.3, cut);
          final pw = clampD(0.20 + need / 2100.0, 0.22, 1.0);

          final prior = (cut * cut * cut) *
              (1200.0 / (600.0 + aimDist + potDist)) *
              (isQueen ? 0.9 : 1.0);

          out.add(ShotPlan(
            strikerX: sx,
            angle: aimDir.angle,
            power: pw,
            prior: prior,
            reason: isQueen ? 'Cuba ratu' : 'Masukkan ${target.kind.label}',
          ));
        }
      }
    }
    return out;
  }

  ShotPlan _fallback(CarromGame game) {
    // Tolak kelompok buah sendiri ke arah lubang terdekat dengan kuasa sederhana.
    final world = game.world;
    Piece? nearest;
    var bestD = double.infinity;
    final origin = Vec2(0, game.baselineY);
    for (final p in world.pieces) {
      if (!p.inPlay) continue;
      if (p.kind != game.myKind && p.kind != PieceKind.queen) continue;
      final d = p.position.distanceTo(origin);
      if (d < bestD) {
        bestD = d;
        nearest = p;
      }
    }
    final target = nearest?.position ?? Vec2.zero;
    final sx = clampD(target.x * 0.6, -game.strikerLimit, game.strikerLimit);
    final dir = (target - Vec2(sx, game.baselineY)).normalized;
    return ShotPlan(
      strikerX: sx,
      angle: game.clampAim(dir.angle),
      power: 0.42 + rng.nextDouble() * 0.2,
      reason: 'Pecahkan kelompok',
    );
  }

  // ------------------------------------------------------------- penilaian

  double _evaluate(CarromGame game, ShotPlan plan) {
    final sim = game.world.cloneForSimulation();
    final striker = sim.striker;
    if (striker == null) return -999;

    striker.resetTo(Vec2(plan.strikerX, game.baselineY));
    striker.onBoard = true;
    final speed = Phys.minStrikerSpeed +
        (Phys.maxStrikerSpeed - Phys.minStrikerSpeed) * plan.power;
    striker.velocity = Vec2.polar(plan.angle, speed);

    const dt = 1 / 90.0;
    var steps = 0;
    while (!sim.settled && steps < 380) {
      sim.step(dt, fast: true);
      steps++;
    }

    final o = _SimOutcome();
    o.contact = sim.firstContactMade;
    for (final e in sim.pocketedThisShot) {
      switch (e.piece.kind) {
        case PieceKind.striker:
          o.strikerIn = true;
          break;
        case PieceKind.queen:
          o.queen = true;
          break;
        default:
          if (e.piece.kind == game.myKind) {
            o.mine++;
          } else {
            o.theirs++;
          }
      }
    }

    var score = 0.0;
    score += o.mine * 130.0;
    score -= o.theirs * 85.0;
    if (o.strikerIn) score -= 175.0;
    if (!o.contact) score -= 240.0;
    if (o.queen) {
      final canCover = o.mine > 0;
      score += canCover ? 150.0 : 45.0;
      if (!canCover && game.me.pocketedCount == 0) score -= 60.0;
    }

    // Kedudukan selepas pukulan: buah sendiri dekat lubang itu bagus,
    // buah lawan dekat lubang itu buruk.
    for (final p in sim.pieces) {
      if (!p.inPlay) continue;
      if (p.kind != game.myKind && p.kind != game.foeKind) continue;
      var closest = double.infinity;
      for (var i = 0; i < 4; i++) {
        final d = p.position.distanceTo(BoardSpec.pocketCenter(i));
        if (d < closest) closest = d;
      }
      final bonus = math.max(0.0, 150.0 - closest) / 150.0 * 12.0;
      if (p.kind == game.myKind) {
        score += bonus;
      } else {
        score -= bonus * 0.8;
      }
    }

    // Elakkan pukulan terlalu kuat tanpa hasil (buah bertaburan tak terkawal).
    if (o.mine == 0 && !o.queen) score -= plan.power * 14.0;

    return score;
  }

  // ------------------------------------------------------------- geometri

  /// Ujian bulatan tersapu: adakah laluan [from] -> [to] bagi cakera berjejari
  /// [radius] bebas daripada buah lain?
  bool _clearPath(
    PhysicsWorld world,
    Vec2 from,
    Vec2 to,
    double radius,
    Set<int> ignore,
  ) {
    final seg = to - from;
    final len = seg.length;
    if (len < 1e-6) return true;
    final dir = seg / len;

    for (final p in world.pieces) {
      if (!p.inPlay || ignore.contains(p.id)) continue;
      if (p.kind == PieceKind.striker && ignore.contains(p.id)) continue;
      final rel = p.position - from;
      final along = rel.dot(dir);
      if (along < -p.radius || along > len + p.radius) continue;
      final perp = (rel - dir * along).length;
      if (perp < radius + p.radius - 0.5) return false;
    }
    return true;
  }
}
