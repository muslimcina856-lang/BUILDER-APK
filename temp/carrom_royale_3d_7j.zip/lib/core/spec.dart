import 'dart:math' as math;

import 'vec.dart';

/// Semua ukuran ikut papan carrom bertaraf ICF, dalam milimeter.
class BoardSpec {
  BoardSpec._();

  /// Kawasan permainan 74 cm x 74 cm.
  static const double playSize = 740.0;
  static const double half = playSize / 2;

  // --- Buah ---
  static const double coinRadius = 15.9; // diameter 31.8 mm
  static const double coinThickness = 7.4;
  static const double coinMass = 5.5; // gram

  static const double strikerRadius = 20.6; // diameter 41.2 mm
  static const double strikerThickness = 8.6;
  static const double strikerMass = 15.0;

  // --- Lubang ---
  static const double pocketRadius = 22.6;

  /// Jarak pusat lubang ke dalam dari garisan bantal.
  static const double pocketOffset = 7.7;

  /// Jejari "rahang" sudut — dinding cekung penahan supaya buah tak terbang keluar.
  static const double jawRadius = pocketRadius * 1.5;

  /// Radius pusat lubang dari paksi.
  static const double pocketAxis = half - pocketOffset;

  /// Titik di mana bantal rata berakhir (mulut lubang bermula).
  /// Diperoleh daripada persilangan bulatan lubang dengan garisan bantal.
  static final double wallOpening =
      pocketAxis - math.sqrt(pocketRadius * pocketRadius - pocketOffset * pocketOffset);

  /// Buah dianggap masuk apabila pusatnya melepasi bibir lubang.
  static const double captureRadius = pocketRadius * 0.92;

  // --- Bingkai kayu ---
  static const double frameWidth = 76.0;
  static const double frameHeight = 24.0;
  static const double frameBevel = 9.0;
  static const double outerHalf = half + frameWidth;
  static const double boardDepth = 26.0;

  // --- Rajah permukaan ---
  static const double baseLineInset = 96.0; // pusat garisan asas dari bantal
  static const double baseLineHalfLength = 232.0;
  static const double baseLineGap = 11.0; // jarak antara dua garisan selari
  static const double baseCircleRadius = 22.5;
  static const double outerCircleRadius = 85.0;
  static const double innerCircleRadius = 31.8;
  static const double arrowLength = 196.0;
  static const double lineWidth = 2.6;

  /// Kedudukan pusat lubang. 0=kiri-bawah, 1=kanan-bawah, 2=kanan-atas, 3=kiri-atas.
  static Vec2 pocketCenter(int i) {
    final sx = (i == 0 || i == 3) ? -1.0 : 1.0;
    final sy = (i < 2) ? -1.0 : 1.0;
    return Vec2(sx * pocketAxis, sy * pocketAxis);
  }

  /// Garisan asas pemain: indeks 0 di bawah (-y), indeks 1 di atas (+y).
  static double baselineY(int playerIndex) =>
      playerIndex == 0 ? -(half - baseLineInset) : (half - baseLineInset);

  /// Arah tembakan sah bagi pemain (menghala ke tengah papan).
  static double forwardAngle(int playerIndex) =>
      playerIndex == 0 ? math.pi / 2 : -math.pi / 2;

  /// Had kiri/kanan letak striker supaya kekal atas garisan asas.
  static double strikerLimit(double strikerRadius) =>
      baseLineHalfLength - strikerRadius * 0.55;
}

/// Pemalar model fizik. Satu unit = mm, saat, gram.
class Phys {
  Phys._();

  static const double gravity = 9810.0; // mm/s^2

  /// Geseran gelongsor buah atas permukaan bersalut serbuk.
  static const double slideFriction = 0.085;

  /// Faktor jejari sentuhan berkesan untuk cakera rata (kesan Contensou).
  static const double contactRadiusFactor = 0.62;

  /// Pengganda nyahpecutan sudut relatif kepada nyahpecutan lurus.
  static const double spinFrictionK = 1.22;

  /// Kekuatan hanyutan sisi akibat putaran (buah "membelok").
  static const double spinDrift = 0.17;

  /// Seretan bendalir kecil supaya buah perlahan berhenti dengan lembut.
  static const double viscousDrag = 0.16;

  static const double coinRestitution = 0.86;
  static const double contactFriction = 0.14;
  static const double cushionRestitution = 0.62;
  static const double cushionFriction = 0.20;
  static const double jawRestitution = 0.32;

  static const double sleepLinear = 3.5; // mm/s
  static const double sleepAngular = 0.15; // rad/s

  static const double maxStrikerSpeed = 3350.0;
  static const double minStrikerSpeed = 300.0;

  static const int maxSubsteps = 26;

  /// Panjang langkah maksimum per subpecahan (pecahan jejari buah).
  static const double substepTravel = 0.32;

  /// Had masa satu pukulan sebelum dipaksa berhenti.
  static const double maxShotSeconds = 9.5;
}
