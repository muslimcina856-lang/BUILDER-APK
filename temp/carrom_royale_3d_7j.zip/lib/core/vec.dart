import 'dart:math' as math;

/// Vektor 2D. Unit dunia = milimeter sebenar papan carrom.
class Vec2 {
  final double x;
  final double y;

  const Vec2(this.x, this.y);

  static const Vec2 zero = Vec2(0, 0);

  Vec2 operator +(Vec2 o) => Vec2(x + o.x, y + o.y);
  Vec2 operator -(Vec2 o) => Vec2(x - o.x, y - o.y);
  Vec2 operator *(double s) => Vec2(x * s, y * s);
  Vec2 operator /(double s) => Vec2(x / s, y / s);
  Vec2 operator -() => Vec2(-x, -y);

  double dot(Vec2 o) => x * o.x + y * o.y;

  /// Hasil darab silang 2D (skalar z).
  double cross(Vec2 o) => x * o.y - y * o.x;

  double get lengthSq => x * x + y * y;
  double get length => math.sqrt(x * x + y * y);
  double get angle => math.atan2(y, x);

  /// Putaran 90 darjah lawan jam.
  Vec2 get perp => Vec2(-y, x);

  Vec2 get normalized {
    final l = length;
    if (l < 1e-12) return Vec2.zero;
    return Vec2(x / l, y / l);
  }

  Vec2 rotated(double a) {
    final c = math.cos(a);
    final s = math.sin(a);
    return Vec2(x * c - y * s, x * s + y * c);
  }

  double distanceTo(Vec2 o) => (this - o).length;
  double distanceSqTo(Vec2 o) => (this - o).lengthSq;

  Vec2 withLength(double l) {
    final n = normalized;
    return Vec2(n.x * l, n.y * l);
  }

  Vec2 clampLength(double maxLen) {
    final l = length;
    if (l <= maxLen || l < 1e-12) return this;
    return this * (maxLen / l);
  }

  static Vec2 polar(double angle, double radius) =>
      Vec2(math.cos(angle) * radius, math.sin(angle) * radius);

  static Vec2 lerp(Vec2 a, Vec2 b, double t) =>
      Vec2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);

  @override
  String toString() => '(${x.toStringAsFixed(1)}, ${y.toStringAsFixed(1)})';
}

/// Vektor 3D untuk saluran render perspektif.
class Vec3 {
  final double x;
  final double y;
  final double z;

  const Vec3(this.x, this.y, this.z);

  static const Vec3 zero = Vec3(0, 0, 0);

  Vec3 operator +(Vec3 o) => Vec3(x + o.x, y + o.y, z + o.z);
  Vec3 operator -(Vec3 o) => Vec3(x - o.x, y - o.y, z - o.z);
  Vec3 operator *(double s) => Vec3(x * s, y * s, z * s);
  Vec3 operator -() => Vec3(-x, -y, -z);

  double dot(Vec3 o) => x * o.x + y * o.y + z * o.z;

  Vec3 cross(Vec3 o) => Vec3(
        y * o.z - z * o.y,
        z * o.x - x * o.z,
        x * o.y - y * o.x,
      );

  double get length => math.sqrt(x * x + y * y + z * z);

  Vec3 get normalized {
    final l = length;
    if (l < 1e-12) return Vec3.zero;
    return Vec3(x / l, y / l, z / l);
  }

  Vec2 get xy => Vec2(x, y);

  static Vec3 plane(Vec2 p, [double z = 0]) => Vec3(p.x, p.y, z);
}

/// `double.clamp` memulangkan `num` pada sesetengah versi SDK.
/// Pembantu ini menjamin jenis `double` di seluruh projek.
double clampD(double v, double lo, double hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

double lerpD(double a, double b, double t) => a + (b - a) * t;

/// Beza sudut terkecil dalam julat [-pi, pi].
double angleDelta(double a, double b) {
  var d = (b - a) % (2 * math.pi);
  if (d > math.pi) d -= 2 * math.pi;
  if (d < -math.pi) d += 2 * math.pi;
  return d;
}
