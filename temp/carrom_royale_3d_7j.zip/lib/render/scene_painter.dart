import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/spec.dart';
import '../core/vec.dart';
import '../game/game.dart';
import '../game/prediction.dart';
import '../physics/piece.dart';
import 'board_renderer.dart';
import 'camera.dart';
import 'palette.dart';
import 'piece_renderer.dart';

class Spark {
  Vec2 position;
  Vec2 velocity;
  double life;
  double maxLife;
  double size;
  Spark(this.position, this.velocity, this.life, this.size) : maxLife = life;
}

class SparkField {
  final List<Spark> sparks = <Spark>[];
  final math.Random rng = math.Random();

  void burst(Vec2 at, double strength, {bool wall = false}) {
    final count = (3 + strength * 9).round();
    for (var i = 0; i < count; i++) {
      final a = rng.nextDouble() * math.pi * 2;
      final sp = 60 + rng.nextDouble() * 320 * strength;
      sparks.add(Spark(
        at,
        Vec2.polar(a, sp),
        0.18 + rng.nextDouble() * 0.30,
        (wall ? 1.4 : 2.2) + rng.nextDouble() * 2.4,
      ));
    }
    if (sparks.length > 260) {
      sparks.removeRange(0, sparks.length - 260);
    }
  }

  void update(double dt) {
    for (var i = sparks.length - 1; i >= 0; i--) {
      final s = sparks[i];
      s.life -= dt;
      if (s.life <= 0) {
        sparks.removeAt(i);
        continue;
      }
      s.position = s.position + s.velocity * dt;
      s.velocity = s.velocity * (1 - 4.2 * dt);
    }
  }
}

class ScenePainter extends CustomPainter {
  ScenePainter({
    required this.game,
    required this.camera,
    required this.sparks,
    required this.pitch,
    required this.showGuide,
    required this.dragAim,
    required this.boardCache,
    required this.repaintNotifier,
  }) : super(repaint: repaintNotifier);

  final CarromGame game;
  final SceneCamera camera;
  final SparkField sparks;
  final double pitch;
  final bool showGuide;
  final bool dragAim;
  final BoardCache boardCache;
  final Listenable repaintNotifier;

  /// Digunakan semula setiap bingkai supaya `.where().toList()` tidak
  /// memperuntukkan senarai baharu 60 kali sesaat.
  static final List<Piece> _visible = <Piece>[];

  late PieceRenderer _pieces;

  @override
  void paint(Canvas canvas, Size size) {
    final shake = game.shake;
    // Yaw dikira sekali dan digunakan semula sebagai kunci cache: apabila
    // goncangan reda, yaw kembali tepat 0 dan cache papan mula kena semula.
    final yaw = math.sin(game.world.elapsed * 9) * 0.004 * shake;
    camera.configure(size, pitchRad: pitch, yawRad: yaw);
    _pieces = PieceRenderer(camera);

    boardCache.paintRoom(canvas, camera, size, pitch, yaw);

    canvas.save();
    if (shake > 0.01) {
      canvas.translate(
        math.sin(game.world.elapsed * 47) * 5 * shake,
        math.cos(game.world.elapsed * 39) * 4 * shake,
      );
    }

    boardCache.paintBoard(canvas, camera, size, pitch, yaw);
    _paintBaseline(canvas);

    _visible.clear();
    for (final p in game.world.pieces) {
      if (p.onBoard || p.pocketed) _visible.add(p);
    }
    for (final p in _visible) {
      if (p.inPlay) _pieces.paintShadow(canvas, p);
    }
    _visible.sort((a, b) => camera
        .depth(Vec3(b.position.x, b.position.y, 0))
        .compareTo(camera.depth(Vec3(a.position.x, a.position.y, 0))));
    for (final p in _visible) {
      _pieces.paint(canvas, p);
    }

    _paintAim(canvas);
    _paintSparks(canvas);
    canvas.restore();
  }

  // ------------------------------------------------------------ garisan asas

  void _paintBaseline(Canvas canvas) {
    if (!game.awaitingHuman) return;
    final y = game.baselineY;
    final lim = game.strikerLimit;
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 7
      ..color = const Color(0x552E9E93);
    canvas.drawLine(
      camera.projectPlane(Vec2(-lim, y)),
      camera.projectPlane(Vec2(lim, y)),
      glow,
    );
  }

  // -------------------------------------------------------------- panduan bidik

  void _paintAim(Canvas canvas) {
    final striker = game.world.striker;
    if (striker == null) return;
    if (game.phase == GamePhase.simulating || game.phase == GamePhase.matchOver) return;
    if (game.me.isAi) return;

    final start = Vec2(game.strikerX, game.baselineY);

    // Striker hantu semasa peletakan.
    if (!striker.onBoard) {
      final ghost = Piece.striker(-1, start);
      ghost.angle = striker.angle;
      _pieces.paintShadow(canvas, ghost);
      _pieces.paint(canvas, ghost);
    }

    if (!showGuide && !dragAim) return;

    final pred = predictShot(game.world, start, game.aimAngle);

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.4
      ..color = const Color(0xCC7FE3D8);

    for (var i = 0; i < pred.path.length; i++) {
      final seg = pred.path[i];
      final a = camera.projectPlane(seg.a);
      final b = camera.projectPlane(seg.b);
      _dashed(canvas, a, b, line, dash: i == 0 ? 13.0 : 8.0, gap: i == 0 ? 8.0 : 9.0);
    }

    // Bulatan hantu pada titik sentuhan + arah buah selepas dilanggar.
    if (pred.contact != null) {
      canvas.drawPath(
        camera.circlePath(pred.contact!, BoardSpec.strikerRadius, 0.6, segments: 34),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8
          ..color = const Color(0x99FFFFFF),
      );
      if (pred.target != null && pred.targetDir != null) {
        final from = pred.target!.position;
        final to = from + pred.targetDir! * 150;
        final pa = camera.projectPlane(from);
        final pb = camera.projectPlane(to);
        final arrow = Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 2.6
          ..color = const Color(0xCCE0B04A);
        canvas.drawLine(pa, pb, arrow);
        final dir = (pb - pa);
        final len = dir.distance;
        if (len > 1) {
          final u = dir / len;
          final n = Offset(-u.dy, u.dx);
          canvas.drawLine(pb, pb - u * 14 + n * 8, arrow);
          canvas.drawLine(pb, pb - u * 14 - n * 8, arrow);
        }
      }
    } else if (pred.intoPocket) {
      final last = pred.path.isNotEmpty ? pred.path.last.b : start;
      canvas.drawCircle(
        camera.projectPlane(last),
        9,
        Paint()..color = const Color(0x99E05A4A),
      );
    }

    // Lastik: garis tarik ke belakang berkadar dengan kuasa.
    if (dragAim) {
      final back = start - Vec2.polar(game.aimAngle, 60 + 190 * game.power);
      final a = camera.projectPlane(start);
      final b = camera.projectPlane(back);
      canvas.drawLine(
        a,
        b,
        Paint()
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 5
          ..shader = ui.Gradient.linear(a, b, [
            const Color(0xFFE0B04A),
            Color.lerp(const Color(0xFFE0B04A), Palette.danger, game.power)!,
          ]),
      );
    }
  }

  void _dashed(Canvas canvas, Offset a, Offset b, Paint paint,
      {double dash = 10, double gap = 8}) {
    final delta = b - a;
    final len = delta.distance;
    if (len < 1) return;
    final u = delta / len;
    // Progres gelung bergantung sepenuhnya pada dash > 0. Jika dash dan gap
    // kedua-duanya sifar, `t` tidak pernah bertambah dan aplikasi tergantung
    // kekal. Semua pemanggil kini menghantar nilai bukan sifar, tetapi gantung
    // ialah mod kegagalan paling teruk — jadi jamin di sini.
    final step = dash > 0.01 ? dash : 10.0;
    final skip = gap > 0 ? gap : 0.0;
    var t = 0.0;
    while (t < len) {
      final e = math.min(t + step, len);
      canvas.drawLine(a + u * t, a + u * e, paint);
      t = e + skip;
    }
  }

  // ------------------------------------------------------------------ percikan

  void _paintSparks(Canvas canvas) {
    if (sparks.sparks.isEmpty) return;
    final paint = Paint()..blendMode = BlendMode.plus;
    for (final s in sparks.sparks) {
      final k = clampD(s.life / s.maxLife, 0, 1);
      final p = camera.projectPlane(s.position, 3.0);
      paint.color = Color.lerp(
        const Color(0x00FFD9A0),
        const Color(0xFFFFE7B4),
        k * k,
      )!;
      canvas.drawCircle(p, s.size * k, paint);
    }
  }

  @override
  bool shouldRepaint(covariant ScenePainter old) => true;
}
