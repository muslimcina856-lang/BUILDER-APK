import 'dart:math' as math;
import 'dart:ui';

import '../core/spec.dart';
import '../core/vec.dart';

/// Kamera perspektif sebenar.
///
/// Ruang dunia: x ke kanan, y ke hadapan (menjauhi pemain), z ke atas.
/// Permukaan papan berada pada z = 0.
///
/// Unjuran: skrin = asal + k * (cx/cz, -cy/cz) di mana (cx, cy, cz) ialah
/// koordinat ruang kamera. Kerana ia linear terhadap k, faktor muat
/// dikira sekali sahaja daripada kotak sempadan unjuran unit — jadi papan
/// sentiasa muat tepat tanpa lelaran.
class SceneCamera {
  double pitch = 1.02; // radian dari satah papan (pi/2 = pandangan atas)
  double yaw = 0;
  double orbit = 0;
  double distance = BoardSpec.playSize * 2.55;
  Size viewport = Size.zero;

  late Vec3 _eye;
  late Vec3 _right;
  late Vec3 _up;
  late Vec3 _forward;
  double _k = 1;
  Offset _origin = Offset.zero;

  /// Vektor menghala ke sumber cahaya (dinormalkan).
  static const Vec3 light = Vec3(-0.40, -0.34, 0.85);

  void configure(Size size, {double pitchRad = 1.02, double yawRad = 0, double zoom = 1}) {
    viewport = size;
    pitch = pitchRad;
    yaw = yawRad;

    final cp = math.cos(pitch);
    final sp = math.sin(pitch);
    final target = const Vec3(0, 0, 0);
    final dir = Vec3(math.sin(yaw) * cp, -math.cos(yaw) * cp, sp);
    _eye = target + dir * distance;

    _forward = (target - _eye).normalized;
    const worldUp = Vec3(0, 0, 1);
    _right = _forward.cross(worldUp).normalized;
    _up = _right.cross(_forward).normalized;

    _k = 1;
    _origin = Offset.zero;
    _fit(size, zoom);
  }

  void _fit(Size size, double zoom) {
    const oh = BoardSpec.outerHalf;
    const h = BoardSpec.frameHeight;
    final probes = <Vec3>[
      const Vec3(-oh, -oh, 0),
      const Vec3(oh, -oh, 0),
      const Vec3(oh, oh, 0),
      const Vec3(-oh, oh, 0),
      const Vec3(-oh, -oh, h),
      const Vec3(oh, -oh, h),
      const Vec3(oh, oh, h),
      const Vec3(-oh, oh, h),
    ];

    var minX = double.infinity, minY = double.infinity;
    var maxX = -double.infinity, maxY = -double.infinity;
    for (final p in probes) {
      final u = _unitProject(p);
      if (u.dx < minX) minX = u.dx;
      if (u.dx > maxX) maxX = u.dx;
      if (u.dy < minY) minY = u.dy;
      if (u.dy > maxY) maxY = u.dy;
    }
    final bw = math.max(1e-6, maxX - minX);
    final bh = math.max(1e-6, maxY - minY);
    final avail = Size(size.width * 0.98, size.height * 0.98);
    _k = math.min(avail.width / bw, avail.height / bh) * zoom;

    final cx = (minX + maxX) * 0.5;
    final cy = (minY + maxY) * 0.5;
    _origin = Offset(
      size.width * 0.5 - _k * cx,
      size.height * 0.5 - _k * cy,
    );
  }

  Offset _unitProject(Vec3 p) {
    final d = p - _eye;
    final cz = d.dot(_forward);
    final safe = cz < 1.0 ? 1.0 : cz;
    return Offset(d.dot(_right) / safe, -d.dot(_up) / safe);
  }

  /// Kedudukan kamera dalam ruang dunia.
  Vec3 get eye => _eye;

  Offset project(Vec3 p) {
    final u = _unitProject(p);
    return Offset(_origin.dx + _k * u.dx, _origin.dy + _k * u.dy);
  }

  Offset projectPlane(Vec2 p, [double z = 0]) => project(Vec3(p.x, p.y, z));

  /// Jarak dari kamera — untuk susunan lukisan jauh ke dekat.
  double depth(Vec3 p) => (p - _eye).dot(_forward);

  /// Piksel per milimeter pada kedalaman titik tersebut.
  double pixelsPerMm(Vec3 p) {
    final cz = depth(p);
    return _k / (cz < 1.0 ? 1.0 : cz);
  }

  /// Songsangan unjuran: sinar dari kamera melalui titik skrin,
  /// dipotong dengan satah z = 0. Ini yang membolehkan sentuhan jari
  /// dipetakan tepat ke koordinat papan.
  Vec2? unproject(Offset screen, {double planeZ = 0}) {
    final ux = (screen.dx - _origin.dx) / _k;
    final uy = -(screen.dy - _origin.dy) / _k;
    final dir = _forward + _right * ux + _up * uy;
    if (dir.z.abs() < 1e-9) return null;
    final t = (planeZ - _eye.z) / dir.z;
    if (t <= 0) return null;
    final hit = _eye + dir * t;
    // Jika kamera belum dikonfigurasi dengan saiz yang sah, _k boleh sifar dan
    // seluruh pengiraan menjadi NaN. Sekali NaN masuk ke strikerX, kedudukan
    // buah menjadi NaN, `settled` tidak akan benar, dan permainan beku kekal.
    // Tapis di sini — pemanggil sudah mengendalikan null.
    if (!hit.x.isFinite || !hit.y.isFinite) return null;
    return Vec2(hit.x, hit.y);
  }

  /// Poligon bulatan dunia diunjur — tepat di bawah perspektif kerana
  /// setiap titik diunjur secara individu (bulatan menjadi elips).
  List<Offset> circlePoints(Vec2 center, double radius, double z, int segments) {
    final pts = <Offset>[];
    for (var i = 0; i < segments; i++) {
      final a = i * 2 * math.pi / segments;
      pts.add(project(Vec3(
        center.x + math.cos(a) * radius,
        center.y + math.sin(a) * radius,
        z,
      )));
    }
    return pts;
  }

  Path circlePath(Vec2 center, double radius, double z, {int segments = 40}) =>
      polygon(circlePoints(center, radius, z, segments));

  static Path polygon(List<Offset> pts) {
    final path = Path();
    if (pts.isEmpty) return path;
    path.moveTo(pts.first.dx, pts.first.dy);
    for (var i = 1; i < pts.length; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    path.close();
    return path;
  }

  /// Lilitan cembung (algoritma rantai monoton Andrew).
  /// Digunakan untuk siluet sisi buah: gabungan cincin bawah dan atas.
  static List<Offset> convexHull(List<Offset> input) {
    if (input.length < 3) return List<Offset>.from(input);
    final pts = List<Offset>.from(input)
      ..sort((a, b) => a.dx == b.dx ? a.dy.compareTo(b.dy) : a.dx.compareTo(b.dx));

    double cross(Offset o, Offset a, Offset b) =>
        (a.dx - o.dx) * (b.dy - o.dy) - (a.dy - o.dy) * (b.dx - o.dx);

    final lower = <Offset>[];
    for (final p in pts) {
      while (lower.length >= 2 &&
          cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) {
        lower.removeLast();
      }
      lower.add(p);
    }
    final upper = <Offset>[];
    for (var i = pts.length - 1; i >= 0; i--) {
      final p = pts[i];
      while (upper.length >= 2 &&
          cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) {
        upper.removeLast();
      }
      upper.add(p);
    }
    lower.removeLast();
    upper.removeLast();
    return [...lower, ...upper];
  }

  /// Keamatan Lambert bagi satu muka dengan normal [n].
  static double lambert(Vec3 n, {double ambient = 0.34}) {
    final d = n.normalized.dot(light);
    return ambient + (1.0 - ambient) * math.max(0.0, d);
  }
}
