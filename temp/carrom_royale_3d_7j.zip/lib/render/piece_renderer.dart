import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/vec.dart';
import '../physics/piece.dart';
import 'camera.dart';
import 'palette.dart';

/// Setiap buah dilukis sebagai silinder pendek sebenar:
///  * cincin bawah pada z = 0 dan cincin atas pada z = tebal, kedua-duanya
///    diunjur titik demi titik (bulatan menjadi elips di bawah perspektif),
///  * sisi ialah lilitan cembung gabungan kedua-dua cincin — ini memberi
///    siluet yang betul dari mana-mana sudut kamera,
///  * bayang ialah unjuran cincin atas ke satah papan sepanjang arah cahaya.
class PieceRenderer {
  PieceRenderer(this.cam);

  final SceneCamera cam;
  static const int _segments = 30;

  /// Anjakan bayang bagi titik pada ketinggian h: p - (L.xy / L.z) * h
  static Vec2 _shadowOffset(double h) {
    const l = SceneCamera.light;
    return Vec2(-l.x / l.z * h, -l.y / l.z * h);
  }

  // Malar: tidak pernah berubah mengikut buah atau bingkai, jadi diperuntukkan
  // sekali sahaja dan bukan 2 x 20 buah x 60 bingkai = 2,400 objek sesaat.
  static final Paint _castShadowPaint = Paint()
    ..color = const Color(0x66000000)
    ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
  static final Paint _contactShadowPaint = Paint()
    ..color = const Color(0x59000000)
    ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5);

  void paintShadow(Canvas canvas, Piece p) {
    if (!p.inPlay) return;
    final off = _shadowOffset(p.thickness);
    final ring = <Offset>[];
    for (var i = 0; i < _segments; i++) {
      final a = i * 2 * math.pi / _segments;
      final w = p.position + Vec2.polar(a, p.radius);
      ring.add(cam.projectPlane(w));
      ring.add(cam.projectPlane(w + off));
    }
    final path = SceneCamera.polygon(SceneCamera.convexHull(ring));
    canvas.drawPath(path, _castShadowPaint);
    // Oklusi sentuh: bayang gelap tepat di bawah buah.
    canvas.drawPath(
      cam.circlePath(p.position, p.radius * 0.96, 0.01, segments: 24),
      _contactShadowPaint,
    );
  }

  void paint(Canvas canvas, Piece p) {
    if (!p.onBoard && !p.pocketed) return;

    final drop = p.pocketed ? Curves.easeIn.transform(clampD(p.pocketProgress, 0, 1)) : 0.0;
    if (drop >= 1) return;

    final z0 = -drop * 88.0;
    final scale = 1 - drop * 0.30;
    final r = p.radius * scale;
    final th = p.thickness * scale;

    final bottom = <Offset>[];
    final top = <Offset>[];
    for (var i = 0; i < _segments; i++) {
      final a = i * 2 * math.pi / _segments;
      final w = p.position + Vec2.polar(a, r);
      bottom.add(cam.project(Vec3(w.x, w.y, z0)));
      top.add(cam.project(Vec3(w.x, w.y, z0 + th)));
    }

    final colors = _colorsFor(p.kind);
    final silhouette = SceneCamera.convexHull([...bottom, ...top]);
    final sidePath = SceneCamera.polygon(silhouette);
    final topPath = SceneCamera.polygon(top);
    final b = sidePath.getBounds();

    // --- sisi ---
    final lightScreen = cam.project(Vec3(
      p.position.x + SceneCamera.light.x * r * 2.4,
      p.position.y + SceneCamera.light.y * r * 2.4,
      z0 + th,
    ));
    final darkScreen = cam.project(Vec3(
      p.position.x - SceneCamera.light.x * r * 2.4,
      p.position.y - SceneCamera.light.y * r * 2.4,
      z0,
    ));
    canvas.drawPath(
      sidePath,
      Paint()
        ..shader = ui.Gradient.linear(
          lightScreen,
          darkScreen,
          [colors.edgeLit, colors.edge, colors.edgeDark],
          const [0.0, 0.5, 1.0],
        ),
    );

    // --- muka atas ---
    final hi = cam.project(Vec3(
      p.position.x + SceneCamera.light.x * r * 0.45,
      p.position.y + SceneCamera.light.y * r * 0.45,
      z0 + th,
    ));
    canvas.drawPath(
      topPath,
      Paint()
        ..shader = ui.Gradient.radial(
          hi,
          math.max(2.0, b.longestSide * 0.72),
          [colors.faceLit, colors.face, colors.faceDark],
          const [0.0, 0.55, 1.0],
        ),
    );

    // --- kilauan spekular kecil ---
    canvas.drawCircle(
      hi,
      math.max(1.0, b.shortestSide * 0.14),
      Paint()
        ..blendMode = BlendMode.plus
        ..shader = ui.Gradient.radial(
          hi,
          math.max(1.0, b.shortestSide * 0.14),
          [const Color(0x66FFFFFF), const Color(0x00FFFFFF)],
        ),
    );

    _engrave(canvas, p, r, z0 + th, colors);

    // --- bibir atas ---
    canvas.drawPath(
      topPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(0.7, cam.pixelsPerMm(Vec3(p.position.x, p.position.y, z0 + th)) * 0.7)
        ..color = colors.rim,
    );

    // --- kilauan selepas dilanggar ---
    if (p.glow > 0.02) {
      canvas.drawPath(
        topPath,
        Paint()
          ..blendMode = BlendMode.plus
          ..color = Color.lerp(const Color(0x00FFD9A0), const Color(0x77FFD9A0), clampD(p.glow, 0, 1))!,
      );
    }
  }

  void _engrave(Canvas canvas, Piece p, double r, double z, _CoinColors colors) {
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(0.6, cam.pixelsPerMm(Vec3(p.position.x, p.position.y, z)) * 0.6)
      ..color = colors.engrave;

    canvas.drawPath(cam.circlePath(p.position, r * 0.74, z, segments: 26), stroke);

    if (p.kind == PieceKind.queen) {
      // Mahkota lapan bucu — diputar mengikut sudut fizik sebenar buah,
      // jadi putaran (spin) kelihatan pada skrin.
      final pts = <Offset>[];
      for (var i = 0; i < 16; i++) {
        final a = p.angle + i * math.pi / 8;
        final rad = i.isEven ? r * 0.62 : r * 0.26;
        final w = p.position + Vec2.polar(a, rad);
        pts.add(cam.project(Vec3(w.x, w.y, z)));
      }
      canvas.drawPath(
        SceneCamera.polygon(pts),
        Paint()..color = const Color(0xFFF2C15E),
      );
      canvas.drawPath(
        SceneCamera.polygon(pts),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = stroke.strokeWidth
          ..color = const Color(0xFF7C1418),
      );
    } else if (p.kind == PieceKind.striker) {
      canvas.drawPath(
        cam.circlePath(p.position, r * 0.52, z, segments: 24),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(1.0, stroke.strokeWidth * 2.4)
          ..color = Palette.strikerRing,
      );
      canvas.drawPath(
        cam.circlePath(p.position, r * 0.16, z, segments: 14),
        Paint()..color = Palette.strikerRing,
      );
      // Empat tanda indeks yang berputar bersama striker.
      for (var i = 0; i < 4; i++) {
        final a = p.angle + i * math.pi / 2;
        final w1 = p.position + Vec2.polar(a, r * 0.62);
        final w2 = p.position + Vec2.polar(a, r * 0.82);
        canvas.drawLine(
          cam.project(Vec3(w1.x, w1.y, z)),
          cam.project(Vec3(w2.x, w2.y, z)),
          Paint()
            ..strokeWidth = math.max(1.0, stroke.strokeWidth * 1.6)
            ..color = Palette.strikerRing,
        );
      }
    } else {
      canvas.drawPath(cam.circlePath(p.position, r * 0.42, z, segments: 20), stroke);
      // Satu takuk supaya putaran buah kelihatan.
      final w1 = p.position + Vec2.polar(p.angle, r * 0.44);
      final w2 = p.position + Vec2.polar(p.angle, r * 0.72);
      canvas.drawLine(
        cam.project(Vec3(w1.x, w1.y, z)),
        cam.project(Vec3(w2.x, w2.y, z)),
        Paint()
          ..strokeWidth = math.max(0.8, stroke.strokeWidth * 1.4)
          ..color = colors.engrave,
      );
    }
  }

  _CoinColors _colorsFor(PieceKind kind) {
    switch (kind) {
      case PieceKind.white:
        return const _CoinColors(
          face: Palette.coinBone,
          faceLit: Color(0xFFFFF8E2),
          faceDark: Color(0xFFCDB78C),
          edge: Palette.coinBoneEdge,
          edgeLit: Color(0xFFE2CFA6),
          edgeDark: Color(0xFF7E6A46),
          rim: Color(0xFF8A7550),
          engrave: Color(0x99816A45),
        );
      case PieceKind.black:
        return const _CoinColors(
          face: Palette.coinEbony,
          faceLit: Color(0xFF6A554D),
          faceDark: Color(0xFF150F0D),
          edge: Palette.coinEbonyEdge,
          edgeLit: Color(0xFF6E5B54),
          edgeDark: Color(0xFF130E0C),
          rim: Color(0xFF6E5B54),
          engrave: Color(0x998C7468),
        );
      case PieceKind.queen:
        return const _CoinColors(
          face: Palette.queenRed,
          faceLit: Color(0xFFEE6355),
          faceDark: Color(0xFF7E1418),
          edge: Palette.queenEdge,
          edgeLit: Color(0xFFB1332F),
          edgeDark: Color(0xFF4B0B0E),
          rim: Color(0xFFF0C46A),
          engrave: Color(0xAAFFD98A),
        );
      case PieceKind.striker:
        return const _CoinColors(
          face: Palette.strikerBody,
          faceLit: Color(0xFFFFFFFF),
          faceDark: Color(0xFFC3CFCC),
          edge: Color(0xFFD3DDDA),
          edgeLit: Color(0xFFF2F7F5),
          edgeDark: Color(0xFF77837F),
          rim: Color(0xFF8C9A96),
          engrave: Color(0x99738280),
        );
    }
  }
}

class _CoinColors {
  final Color face;
  final Color faceLit;
  final Color faceDark;
  final Color edge;
  final Color edgeLit;
  final Color edgeDark;
  final Color rim;
  final Color engrave;

  const _CoinColors({
    required this.face,
    required this.faceLit,
    required this.faceDark,
    required this.edge,
    required this.edgeLit,
    required this.edgeDark,
    required this.rim,
    required this.engrave,
  });
}
