import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/spec.dart';
import '../core/vec.dart';
import 'camera.dart';
import 'palette.dart';

/// Melukis papan sebagai objek 3D sebenar: setiap muka bingkai ialah poligon
/// dunia yang diunjur, dan warnanya dikira daripada normal muka menggunakan
/// pencahayaan Lambert. Tiada "kepura-puraan 2D" — jika kamera dicondongkan,
/// geometri betul dengan sendirinya.
class BoardRenderer {
  BoardRenderer(this.cam);

  final SceneCamera cam;

  static const double _h = BoardSpec.frameHeight;
  static const double _oh = BoardSpec.outerHalf;
  static const double _ih = BoardSpec.half; // tepi dalam pada z = 0
  static const double _ib = BoardSpec.half + BoardSpec.frameBevel; // tepi dalam pada z = h

  void paintRoom(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = ui.Gradient.radial(
          Offset(size.width * 0.5, size.height * 0.34),
          size.longestSide * 0.78,
          [Palette.roomGlow, Palette.roomMid, Palette.roomDeep],
          [0.0, 0.45, 1.0],
        ),
    );

    // Pancaran lampu gantung di atas papan.
    canvas.drawCircle(
      Offset(size.width * 0.5, size.height * 0.1),
      size.width * 0.55,
      Paint()
        ..shader = ui.Gradient.radial(
          Offset(size.width * 0.5, size.height * 0.1),
          size.width * 0.55,
          [const Color(0x33FFE2A8), const Color(0x00FFE2A8)],
        ),
    );
  }

  void paint(Canvas canvas, Size size) {
    _paintFloorShadow(canvas);
    _paintOuterWalls(canvas);
    _paintPocketShafts(canvas);

    canvas.save();
    canvas.clipPath(_boardTopWithHoles());
    _paintFrameTop(canvas);
    _paintBevel(canvas);
    _paintSurface(canvas);
    _paintDiagram(canvas);
    canvas.restore();

    _paintPocketRims(canvas);
    _paintFrameInlay(canvas);
  }

  // ------------------------------------------------------------------ bayang

  void _paintFloorShadow(Canvas canvas) {
    const spread = 78.0;
    final pts = <Offset>[
      cam.projectPlane(const Vec2(-_oh - spread, -_oh - spread * 0.4), -BoardSpec.boardDepth),
      cam.projectPlane(const Vec2(_oh + spread, -_oh - spread * 0.4), -BoardSpec.boardDepth),
      cam.projectPlane(const Vec2(_oh + spread * 1.5, _oh + spread), -BoardSpec.boardDepth),
      cam.projectPlane(const Vec2(-_oh + spread * 0.4, _oh + spread), -BoardSpec.boardDepth),
    ];
    canvas.drawPath(
      SceneCamera.polygon(pts),
      Paint()
        ..color = const Color(0x99000000)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 26),
    );
  }

  // ------------------------------------------------------ dinding luar papan

  void _paintOuterWalls(Canvas canvas) {
    const zBottom = -BoardSpec.boardDepth;
    final sides = <_Face>[
      _Face(
        const [
          Vec3(-_oh, -_oh, _h),
          Vec3(_oh, -_oh, _h),
          Vec3(_oh, -_oh, zBottom),
          Vec3(-_oh, -_oh, zBottom),
        ],
        const Vec3(0, -1, 0),
      ),
      _Face(
        const [
          Vec3(_oh, -_oh, _h),
          Vec3(_oh, _oh, _h),
          Vec3(_oh, _oh, zBottom),
          Vec3(_oh, -_oh, zBottom),
        ],
        const Vec3(1, 0, 0),
      ),
      _Face(
        const [
          Vec3(-_oh, _oh, _h),
          Vec3(-_oh, -_oh, _h),
          Vec3(-_oh, -_oh, zBottom),
          Vec3(-_oh, _oh, zBottom),
        ],
        const Vec3(-1, 0, 0),
      ),
      _Face(
        const [
          Vec3(_oh, _oh, _h),
          Vec3(-_oh, _oh, _h),
          Vec3(-_oh, _oh, zBottom),
          Vec3(_oh, _oh, zBottom),
        ],
        const Vec3(0, 1, 0),
      ),
    ];

    for (final f in sides) {
      if (!f.facesCamera(cam)) continue; // pemusnahan muka belakang
      final shade = SceneCamera.lambert(f.normal, ambient: 0.24);
      final top = _shade(Palette.rosewood, shade);
      final bottom = _shade(Palette.rosewoodDark, shade * 0.72);
      final pts = f.points.map(cam.project).toList();
      final path = SceneCamera.polygon(pts);
      final bounds = path.getBounds();
      canvas.drawPath(
        path,
        Paint()
          ..shader = ui.Gradient.linear(
            bounds.topCenter,
            bounds.bottomCenter,
            [top, bottom],
          ),
      );
    }
  }

  // -------------------------------------------------------------- muka atas

  Path _ringPath(double outerHalf, double innerHalf, double z) {
    final outer = SceneCamera.polygon([
      cam.project(Vec3(-outerHalf, -outerHalf, z)),
      cam.project(Vec3(outerHalf, -outerHalf, z)),
      cam.project(Vec3(outerHalf, outerHalf, z)),
      cam.project(Vec3(-outerHalf, outerHalf, z)),
    ]);
    final inner = SceneCamera.polygon([
      cam.project(Vec3(-innerHalf, -innerHalf, z)),
      cam.project(Vec3(innerHalf, -innerHalf, z)),
      cam.project(Vec3(innerHalf, innerHalf, z)),
      cam.project(Vec3(-innerHalf, innerHalf, z)),
    ]);
    return Path.combine(ui.PathOperation.difference, outer, inner);
  }

  Path _boardTopWithHoles() {
    var top = SceneCamera.polygon([
      cam.project(const Vec3(-_oh, -_oh, _h)),
      cam.project(const Vec3(_oh, -_oh, _h)),
      cam.project(const Vec3(_oh, _oh, _h)),
      cam.project(const Vec3(-_oh, _oh, _h)),
    ]);
    for (var i = 0; i < 4; i++) {
      final hole = cam.circlePath(
        BoardSpec.pocketCenter(i),
        BoardSpec.pocketRadius,
        0,
        segments: 44,
      );
      top = Path.combine(ui.PathOperation.difference, top, hole);
    }
    return top;
  }

  void _paintFrameTop(Canvas canvas) {
    final path = _ringPath(_oh, _ib, _h);
    final bounds = path.getBounds();
    final shade = SceneCamera.lambert(const Vec3(0, 0, 1), ambient: 0.42);
    canvas.drawPath(
      path,
      Paint()
        ..shader = ui.Gradient.linear(
          bounds.topCenter,
          bounds.bottomCenter,
          [
            _shade(Palette.rosewood, shade * 1.18),
            _shade(Palette.rosewood, shade * 0.86),
          ],
        ),
    );

    // Urat kayu halus pada bingkai.
    final grain = Paint()
      ..color = const Color(0x1A000000)
      ..strokeWidth = 1.1
      ..style = PaintingStyle.stroke;
    canvas.save();
    canvas.clipPath(path);
    for (var i = -14; i <= 14; i++) {
      final t = i / 14.0;
      final p1 = cam.project(Vec3(-_oh, t * _oh + math.sin(i * 1.7) * 6, _h));
      final p2 = cam.project(Vec3(_oh, t * _oh + math.cos(i * 2.3) * 6, _h));
      canvas.drawLine(p1, p2, grain);
    }
    canvas.restore();
  }

  void _paintBevel(Canvas canvas) {
    // Empat muka condong dari tepi dalam atas (±_ib, z=h) ke bantal (±_ih, z=0).
    final faces = <_Face>[
      _Face(
        const [
          Vec3(-_ib, -_ib, _h),
          Vec3(_ib, -_ib, _h),
          Vec3(_ih, -_ih, 0),
          Vec3(-_ih, -_ih, 0),
        ],
        Vec3(0, 1, BoardSpec.frameBevel / BoardSpec.frameHeight).normalized,
      ),
      _Face(
        const [
          Vec3(_ib, -_ib, _h),
          Vec3(_ib, _ib, _h),
          Vec3(_ih, _ih, 0),
          Vec3(_ih, -_ih, 0),
        ],
        Vec3(-1, 0, BoardSpec.frameBevel / BoardSpec.frameHeight).normalized,
      ),
      _Face(
        const [
          Vec3(_ib, _ib, _h),
          Vec3(-_ib, _ib, _h),
          Vec3(-_ih, _ih, 0),
          Vec3(_ih, _ih, 0),
        ],
        Vec3(0, -1, BoardSpec.frameBevel / BoardSpec.frameHeight).normalized,
      ),
      _Face(
        const [
          Vec3(-_ib, _ib, _h),
          Vec3(-_ib, -_ib, _h),
          Vec3(-_ih, -_ih, 0),
          Vec3(-_ih, _ih, 0),
        ],
        Vec3(1, 0, BoardSpec.frameBevel / BoardSpec.frameHeight).normalized,
      ),
    ];

    for (final f in faces) {
      final shade = SceneCamera.lambert(f.normal, ambient: 0.28);
      final pts = f.points.map(cam.project).toList();
      canvas.drawPath(
        SceneCamera.polygon(pts),
        Paint()..color = _shade(const Color(0xFF6B3A25), shade),
      );
    }
  }

  void _paintSurface(Canvas canvas) {
    final surface = SceneCamera.polygon([
      cam.project(const Vec3(-_ih, -_ih, 0)),
      cam.project(const Vec3(_ih, -_ih, 0)),
      cam.project(const Vec3(_ih, _ih, 0)),
      cam.project(const Vec3(-_ih, _ih, 0)),
    ]);
    final b = surface.getBounds();

    canvas.drawPath(
      surface,
      Paint()
        ..shader = ui.Gradient.linear(
          b.topCenter,
          b.bottomCenter,
          [
            _shade(Palette.teakLight, 1.0),
            _shade(Palette.teak, 0.95),
            _shade(Palette.teakDark, 0.9),
          ],
          [0.0, 0.55, 1.0],
        ),
    );

    canvas.save();
    canvas.clipPath(surface);

    // Urat kayu jati berjalan mengikut paksi y, dilukis dalam ruang dunia
    // supaya lengkungan perspektif betul.
    final grain = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 46; i++) {
      final t = i / 45.0;
      final x = -_ih + t * 2 * _ih;
      final wobble = math.sin(i * 2.11) * 9 + math.cos(i * 0.77) * 5;
      final alpha = 0.05 + 0.07 * (0.5 + 0.5 * math.sin(i * 3.7));
      grain
        ..color = Color.fromRGBO(60, 30, 8, alpha)
        ..strokeWidth = 0.8 + (i % 5 == 0 ? 1.6 : 0.0);
      final path = Path();
      for (var s = 0; s <= 10; s++) {
        final y = -_ih + (2 * _ih) * (s / 10.0);
        final xx = x + math.sin(y / 130 + i) * (3 + wobble * 0.15);
        final p = cam.projectPlane(Vec2(xx, y));
        if (s == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      canvas.drawPath(path, grain);
    }

    // Kilauan lampu di atas permukaan bergilap.
    final glowCenter = cam.projectPlane(const Vec2(-90, -60));
    canvas.drawCircle(
      glowCenter,
      b.width * 0.52,
      Paint()
        ..blendMode = BlendMode.plus
        ..shader = ui.Gradient.radial(
          glowCenter,
          b.width * 0.52,
          [const Color(0x2AFFF0D0), const Color(0x00FFF0D0)],
        ),
    );

    // Vignette pinggir.
    canvas.drawPath(
      surface,
      Paint()
        ..shader = ui.Gradient.radial(
          b.center,
          b.longestSide * 0.62,
          [const Color(0x00000000), const Color(0x59000000)],
          [0.55, 1.0],
        ),
    );
    canvas.restore();

    // Garisan bantal dalam.
    canvas.drawPath(
      surface,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0x66301708),
    );
  }

  // ------------------------------------------------------------------ rajah

  void _paintDiagram(Canvas canvas) {
    final ink = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..color = Palette.ink;
    final red = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..color = Palette.inkRed;

    double w(Vec2 at, double mm) =>
        math.max(0.8, cam.pixelsPerMm(Vec3(at.x, at.y, 0)) * mm);

    // Bulatan tengah.
    ink.strokeWidth = w(Vec2.zero, BoardSpec.lineWidth);
    canvas.drawPath(
        cam.circlePath(Vec2.zero, BoardSpec.outerCircleRadius, 0, segments: 64), ink);
    canvas.drawPath(
        cam.circlePath(Vec2.zero, BoardSpec.innerCircleRadius, 0, segments: 48), ink);
    canvas.drawPath(
      cam.circlePath(Vec2.zero, BoardSpec.innerCircleRadius * 0.55, 0, segments: 32),
      Paint()..color = const Color(0x33AE2F27),
    );

    // Empat sisi: garisan asas berkembar + bulatan asas merah + panah sudut.
    for (var side = 0; side < 4; side++) {
      final rot = side * math.pi / 2;
      final base = BoardSpec.half - BoardSpec.baseLineInset;
      const halfLen = BoardSpec.baseLineHalfLength;

      for (final off in [-BoardSpec.baseLineGap / 2, BoardSpec.baseLineGap / 2]) {
        final a = Vec2(-halfLen, -(base + off)).rotated(rot);
        final b = Vec2(halfLen, -(base + off)).rotated(rot);
        ink.strokeWidth = w(a, BoardSpec.lineWidth);
        _worldLine(canvas, a, b, ink);
      }

      for (final sx in [-1.0, 1.0]) {
        final c = Vec2(sx * halfLen, -base).rotated(rot);
        red.strokeWidth = w(c, BoardSpec.lineWidth * 1.15);
        canvas.drawPath(
          cam.circlePath(c, BoardSpec.baseCircleRadius, 0, segments: 30),
          red,
        );
        canvas.drawPath(
          cam.circlePath(c, BoardSpec.baseCircleRadius * 0.34, 0, segments: 20),
          Paint()..color = Palette.inkRed,
        );
      }

      // Panah diagonal dari bulatan asas menuju ke tengah.
      final origin = Vec2(halfLen, -base).rotated(rot);
      final dir = Vec2(-1, 1).normalized.rotated(rot);
      final tip = origin + dir * BoardSpec.arrowLength;
      red.strokeWidth = w(origin, BoardSpec.lineWidth);
      _worldLine(canvas, origin + dir * BoardSpec.baseCircleRadius * 1.4, tip, red);
      final back = dir.perp * (BoardSpec.baseCircleRadius * 0.55);
      _worldLine(canvas, tip, tip - dir * 26 + back, red);
      _worldLine(canvas, tip, tip - dir * 26 - back, red);
    }
  }

  void _worldLine(Canvas canvas, Vec2 a, Vec2 b, Paint paint) {
    canvas.drawLine(cam.projectPlane(a), cam.projectPlane(b), paint);
  }

  // ----------------------------------------------------------------- lubang

  void _paintPocketShafts(Canvas canvas) {
    for (var i = 0; i < 4; i++) {
      final c = BoardSpec.pocketCenter(i);
      final top = cam.circlePoints(c, BoardSpec.pocketRadius, 0, 34);
      final bottom = cam.circlePoints(c, BoardSpec.pocketRadius * 0.66, -76, 34);
      final hull = SceneCamera.convexHull([...top, ...bottom]);
      final path = SceneCamera.polygon(hull);
      final b = path.getBounds();
      canvas.drawPath(
        path,
        Paint()
          ..shader = ui.Gradient.linear(
            b.topCenter,
            b.bottomCenter,
            [const Color(0xFF2A1A12), Palette.pocketVoid],
          ),
      );

      // Sinar lembut memantul pada dinding jauh lubang.
      final far = cam.projectPlane(c + const Vec2(0, -BoardSpec.pocketRadius * 0.45), -14);
      canvas.drawCircle(
        far,
        math.max(3.0, cam.pixelsPerMm(Vec3(c.x, c.y, 0)) * BoardSpec.pocketRadius * 0.5),
        Paint()
          ..blendMode = BlendMode.plus
          ..shader = ui.Gradient.radial(
            far,
            math.max(3.0, cam.pixelsPerMm(Vec3(c.x, c.y, 0)) * BoardSpec.pocketRadius * 0.5),
            [const Color(0x33C79A5A), const Color(0x00C79A5A)],
          ),
      );
    }
  }

  void _paintPocketRims(Canvas canvas) {
    for (var i = 0; i < 4; i++) {
      final c = BoardSpec.pocketCenter(i);
      final ppm = cam.pixelsPerMm(Vec3(c.x, c.y, 0));
      canvas.drawPath(
        cam.circlePath(c, BoardSpec.pocketRadius, 0, segments: 44),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(1.2, ppm * 2.2)
          ..color = Palette.brassDim,
      );
      canvas.drawPath(
        cam.circlePath(c, BoardSpec.pocketRadius * 1.16, 0, segments: 44),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(0.8, ppm * 1.1)
          ..color = const Color(0x552B1508),
      );
    }
  }

  void _paintFrameInlay(Canvas canvas) {
    // Tanam tembaga nipis di sekeliling bingkai atas.
    canvas.drawPath(
      _ringPath(_ib + 14, _ib + 10, _h),
      Paint()..color = const Color(0x8CE0B04A),
    );
    canvas.drawPath(
      _ringPath(_oh - 12, _oh - 16, _h),
      Paint()..color = const Color(0x998C6B25),
    );
  }

  /// Pengubah kecerahan yang selamat merentas versi Flutter
  /// (tiada API warna yang telah usang digunakan).
  static Color _shade(Color base, double k) {
    if (k <= 1) {
      return Color.lerp(const Color(0xFF000000), base, clampD(k, 0, 1))!;
    }
    return Color.lerp(base, const Color(0xFFFFFFFF), clampD(k - 1, 0, 1) * 0.55)!;
  }
}

class _Face {
  final List<Vec3> points;
  final Vec3 normal;
  const _Face(this.points, this.normal);

  /// Pemusnahan muka belakang sebenar: muka hanya dilukis jika normalnya
  /// menghala ke arah kamera.
  bool facesCamera(SceneCamera cam) {
    var cx = 0.0, cy = 0.0, cz = 0.0;
    for (final p in points) {
      cx += p.x;
      cy += p.y;
      cz += p.z;
    }
    final n = points.length.toDouble();
    final centroid = Vec3(cx / n, cy / n, cz / n);
    return normal.dot(cam.eye - centroid) > 0;
  }
}

/// Cache papan yang dirakam.
///
/// [BoardRenderer] bergantung pada kamera SAHAJA — tiada keadaan permainan.
/// Tanpa cache, setiap bingkai mengulang ~400 unjuran titik, dua operasi
/// boolean `Path.combine` (geometri sisi-CPU, mahal), 13 kecerunan dan 22
/// peruntukan `Paint` untuk menghasilkan piksel yang SERUPA.
///
/// Dengan merakamnya ke dalam `ui.Picture`, kerja Dart itu berlaku sekali
/// sahaja dan bingkai berikutnya hanya `drawPicture` — senarai paparan yang
/// sudah siap. Cache hanya terbatal apabila saiz, pitch, atau yaw berubah,
/// iaitu semasa peralihan 3D/atas dan goncangan kamera sahaja.
///
/// Bilik dirakam berasingan kerana ia dilukis di luar transformasi goncangan.
class BoardCache {
  ui.Picture? _room;
  ui.Picture? _board;
  Size? _size;
  double _pitch = double.nan;
  double _yaw = double.nan;

  /// Bilangan kali papan benar-benar dirakam semula — berguna untuk mengesan
  /// pembatalan cache yang tidak dijangka semasa pembangunan.
  int rebuilds = 0;

  void _ensure(SceneCamera cam, Size size, double pitch, double yaw) {
    if (_board != null && _size == size && _pitch == pitch && _yaw == yaw) {
      return;
    }
    final renderer = BoardRenderer(cam);

    final roomRec = ui.PictureRecorder();
    renderer.paintRoom(Canvas(roomRec), size);
    final newRoom = roomRec.endRecording();

    final boardRec = ui.PictureRecorder();
    renderer.paint(Canvas(boardRec), size);
    final newBoard = boardRec.endRecording();

    _room?.dispose();
    _board?.dispose();
    _room = newRoom;
    _board = newBoard;
    _size = size;
    _pitch = pitch;
    _yaw = yaw;
    rebuilds++;
  }

  void paintRoom(Canvas canvas, SceneCamera cam, Size size, double pitch, double yaw) {
    _ensure(cam, size, pitch, yaw);
    canvas.drawPicture(_room!);
  }

  void paintBoard(Canvas canvas, SceneCamera cam, Size size, double pitch, double yaw) {
    _ensure(cam, size, pitch, yaw);
    canvas.drawPicture(_board!);
  }

  void dispose() {
    _room?.dispose();
    _board?.dispose();
    _room = null;
    _board = null;
    _size = null;
  }
}
