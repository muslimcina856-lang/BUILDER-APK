import 'package:flutter/material.dart';

/// Arah visual: "dewan carrom waktu malam".
/// Lampu gantung tunggal di atas papan jati, bingkai kayu rosewood,
/// tanam tembaga, dan bilik petrol gelap di sekeliling.
class Palette {
  Palette._();

  // Bilik
  static const Color roomDeep = Color(0xFF07100F);
  static const Color roomMid = Color(0xFF122528);
  static const Color roomGlow = Color(0xFF1E4247);

  // Kayu
  static const Color teakLight = Color(0xFFD59B58);
  static const Color teak = Color(0xFFBC7F3E);
  static const Color teakDark = Color(0xFF8E5B27);
  static const Color rosewood = Color(0xFF54291B);
  static const Color rosewoodDark = Color(0xFF34170F);
  static const Color brass = Color(0xFFE0B04A);
  static const Color brassDim = Color(0xFF8C6B25);

  // Rajah permukaan
  static const Color ink = Color(0xFF3A2313);
  static const Color inkRed = Color(0xFFAE2F27);

  // Buah
  static const Color coinBone = Color(0xFFF2E5C6);
  static const Color coinBoneEdge = Color(0xFFBFA679);
  static const Color coinEbony = Color(0xFF2A211E);
  static const Color coinEbonyEdge = Color(0xFF554540);
  static const Color queenRed = Color(0xFFC1272D);
  static const Color queenEdge = Color(0xFF7C1418);
  static const Color strikerBody = Color(0xFFF6F8F6);
  static const Color strikerRing = Color(0xFF1F7A72);

  // Lubang
  static const Color pocketVoid = Color(0xFF05090A);

  // UI
  static const Color hudBg = Color(0xE60B1A1C);
  static const Color hudLine = Color(0x33E0B04A);
  static const Color teal = Color(0xFF2E9E93);
  static const Color danger = Color(0xFFE05A4A);

  static const TextStyle display = TextStyle(
    fontSize: 30,
    height: 1.05,
    fontWeight: FontWeight.w800,
    letterSpacing: 3.2,
    color: brass,
  );

  static const TextStyle label = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w700,
    letterSpacing: 2.4,
    color: Color(0xFF9FB3B2),
  );

  static const TextStyle body = TextStyle(
    fontSize: 13.5,
    height: 1.35,
    color: Color(0xFFD8E2E0),
  );

  static const TextStyle number = TextStyle(
    fontSize: 26,
    fontWeight: FontWeight.w800,
    letterSpacing: -0.5,
    color: Colors.white,
  );
}
