import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'provider_model_policy.dart';

class ProviderException implements Exception {
  ProviderException(this.message, {this.statusCode, this.body});

  final String message;
  final int? statusCode;
  final String? body;

  @override
  String toString() => message;
}

class ProviderService {
  ProviderService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static const _uuid = Uuid();

  Future<ProviderTestResult> test(ProviderConfig config, String apiKey) async {
    final watch = Stopwatch()..start();
    var models = <String>[];
    try {
      try {
        models = await listChatModels(config, apiKey);
      } catch (_) {
        models = cachedChatModels(config);
      }
      final chosenModel = config.model.isNotEmpty
          ? config.model.trim()
          : (models.isNotEmpty ? models.first : '');
      if (chosenModel.isEmpty) {
        throw ProviderException(
          'Model belum dipilih dan provider tidak memulangkan senarai model.',
        );
      }
      if (models.isNotEmpty &&
          !models.any(
            (item) => item.toLowerCase() == chosenModel.toLowerCase(),
          )) {
        throw ProviderException(
          'Model $chosenModel tidak tersedia untuk API key ini. '
          'Pilih salah satu model yang disahkan daripada senarai live.',
        );
      }
      final turn = await complete(
        config: config,
        apiKey: apiKey,
        modelOverride: chosenModel,
        maxNetworkRetries: 2,
        messages: <ChatMessage>[
          ChatMessage(
            id: _uuid.v4(),
            sessionId: 'provider-test',
            role: MessageRole.user,
            content: 'Jawab tepat dengan perkataan OK.',
            createdAt: DateTime.now(),
          ),
        ],
        tools: const <ToolDefinition>[],
      );
      watch.stop();
      final ok = turn.text.trim().isNotEmpty;
      return ProviderTestResult(
        success: ok,
        message: ok
            ? 'Sambungan berjaya. Respons: ${turn.text.trim()}'
            : 'Provider tidak memulangkan teks.',
        latencyMs: watch.elapsedMilliseconds,
        models: models,
      );
    } catch (error) {
      watch.stop();
      return ProviderTestResult(
        success: false,
        message: error.toString(),
        latencyMs: watch.elapsedMilliseconds,
        models: models,
      );
    }
  }

  Future<List<String>> listModels(
    ProviderConfig config,
    String apiKey,
  ) async {
    if (config.modelsPath.trim().isEmpty) return config.availableModels;
    final uri = _uri(config, config.modelsPath, apiKey: apiKey);
    final response = await _client
        .get(uri, headers: _headers(config, apiKey))
        .timeout(Duration(seconds: config.timeoutSeconds));
    _ensureSuccess(response);
    final decoded = jsonDecode(response.body);
    final values = <String>[];
    if (decoded is Map && decoded['data'] is List) {
      for (final item in decoded['data'] as List) {
        if (item is Map && item['id'] != null) values.add(item['id'].toString());
      }
    } else if (decoded is Map && decoded['models'] is List) {
      for (final item in decoded['models'] as List) {
        if (item is Map) {
          final name = item['name'] ?? item['id'] ?? item['model'];
          if (name != null) values.add(name.toString().replaceFirst('models/', ''));
        } else {
          values.add(item.toString());
        }
      }
    }
    values.sort();
    return values.toSet().toList();
  }

  /// Senarai model yang sesuai dijadikan model chat/orchestrator.
  /// Endpoint provider ialah sumber utama; model suara/transkripsi khusus tidak
  /// dipaparkan sebagai model chat.
  Future<List<String>> listChatModels(
    ProviderConfig config,
    String apiKey,
  ) async {
    final models = await listModels(config, apiKey);
    return ProviderModelPolicy.chatModels(config, models);
  }

  List<String> cachedChatModels(ProviderConfig config) =>
      ProviderModelPolicy.chatModels(config, config.availableModels);

  bool isModelUnavailableError(Object error) =>
      ProviderModelPolicy.isModelUnavailableError(error);

  Future<String?> resolveFallbackModel(
    ProviderConfig config,
    String apiKey, {
    String? exclude,
  }) async {
    List<String> models;
    try {
      models = await listChatModels(config, apiKey);
    } catch (_) {
      models = cachedChatModels(config);
    }
    return ProviderModelPolicy.preferredModel(
      config,
      models,
      exclude: exclude,
    );
  }

  Future<ModelTurn> complete({
    required ProviderConfig config,
    required String apiKey,
    required List<ChatMessage> messages,
    required List<ToolDefinition> tools,
    String? modelOverride,
    void Function(String partial)? onPartial,
    bool Function()? isCancelled,
    int? maxNetworkRetries,
  }) async {
    final model = modelOverride?.trim().isNotEmpty == true
        ? modelOverride!.trim()
        : config.model.trim();
    if (model.isEmpty) throw ProviderException('Model belum dipilih.');

    // Ralat rangkaian (DNS/socket/timeout): retry tanpa had, backoff.
    // Boleh henti bila isCancelled() true. Ujian provider: maxNetworkRetries.
    var attempt = 0;
    while (true) {
      attempt++;
      if (isCancelled?.call() == true) {
        throw ProviderException('Dibatalkan semasa menunggu rangkaian.');
      }
      try {
        return await switch (config.protocol) {
          ProviderProtocol.openAiChat =>
            _openAiChat(
              config,
              apiKey,
              messages,
              tools,
              model,
              onPartial: onPartial,
            ),
          ProviderProtocol.openAiResponses =>
            _openAiResponses(config, apiKey, messages, tools, model),
          ProviderProtocol.anthropic =>
            _anthropic(config, apiKey, messages, tools, model),
          ProviderProtocol.gemini =>
            _gemini(config, apiKey, messages, tools, model),
          ProviderProtocol.customRest =>
            _customRest(config, apiKey, messages, tools, model),
        };
      } catch (error) {
        if (!_isTransientNetworkError(error)) rethrow;
        if (maxNetworkRetries != null && attempt > maxNetworkRetries!) {
          rethrow;
        }
        final waitSec = (1 << (attempt - 1).clamp(0, 4)).clamp(1, 20);
        onPartial?.call(
          'Rangkaian gagal (cuba #$attempt). Cuba semula dalam ${waitSec}s… '
          'Pastikan internet hidup. Boleh batal.',
        );
        for (var i = 0; i < waitSec; i++) {
          if (isCancelled?.call() == true) {
            throw ProviderException('Dibatalkan semasa menunggu rangkaian.');
          }
          await Future<void>.delayed(const Duration(seconds: 1));
        }
      }
    }
  }

  static bool _isTransientNetworkError(Object error) {
    if (error is SocketException) return true;
    if (error is HttpException) return true;
    if (error is TimeoutException) return true;
    if (error is http.ClientException) return true;
    final s = error.toString().toLowerCase();
    return s.contains('socket') ||
        s.contains('timed out') ||
        s.contains('timeout') ||
        s.contains('connection') ||
        s.contains('network') ||
        s.contains('failed host lookup') ||
        s.contains('connection reset') ||
        s.contains('connection closed') ||
        s.contains('connection abort') ||
        s.contains('software caused connection abort') ||
        s.contains('broken pipe');
  }

  Future<ModelTurn> _openAiChat(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model, {
    void Function(String partial)? onPartial,
  }) async {
    // Hanya mesej user TERAKHIR dengan gambar di-inline penuh.
    final lastImageUserIndex = messages.lastIndexWhere(
      (m) =>
          m.role == MessageRole.user &&
          m.attachments.any((a) => a.kind == AttachmentKind.image),
    );
    final preparedMessages = <Map<String, dynamic>>[];
    for (var i = 0; i < messages.length; i++) {
      final message = messages[i];
      final allowInlineImages = i == lastImageUserIndex;
      preparedMessages.add(
        await _openAiMessage(message, inlineImages: allowInlineImages),
      );
    }
    final payloadBase = <String, dynamic>{
      'model': model,
      'messages': preparedMessages,
      'temperature': config.temperature,
      'max_tokens': config.maxTokens,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools.map((item) => item.toOpenAiJson()).toList(),
      if (tools.isNotEmpty && config.supportsTools) 'tool_choice': 'auto',
    };

    // Cuba stream dulu supaya UI nampak teks/fikiran secara langsung.
    try {
      return await _openAiChatStream(
        config,
        apiKey,
        Map<String, dynamic>.from(payloadBase)..['stream'] = true,
        onPartial: onPartial,
      );
    } catch (error) {
      // Provider tak support stream / SSE rosak → fallback non-stream.
      final s = error.toString().toLowerCase();
      final canFallback = s.contains('stream') ||
          s.contains('event') ||
          s.contains('json') ||
          s.contains('400') ||
          s.contains('unsupported') ||
          s.contains('parse');
      if (!canFallback && error is! FormatException) {
        // Ralat rangkaian tulen — biar retry di complete().
        rethrow;
      }
    }

    final response = await _post(
      config,
      apiKey,
      config.chatPath,
      Map<String, dynamic>.from(payloadBase)..['stream'] = false,
    );
    final data = _decodeMap(response.body);
    final choices = data['choices'] as List?;
    if (choices == null || choices.isEmpty) {
      throw ProviderException(
        'Respons provider tiada choices.',
        body: response.body,
      );
    }
    final message = Map<String, dynamic>.from(
      (choices.first as Map)['message'] as Map? ?? const <String, dynamic>{},
    );
    final text = _contentToText(message['content']);
    final reasoning = _extractReasoning(message, data);
    final calls = <ToolCall>[];
    for (final raw in message['tool_calls'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      final function = Map<String, dynamic>.from(
        item['function'] as Map? ?? const <String, dynamic>{},
      );
      calls.add(
        ToolCall(
          id: item['id']?.toString() ?? _uuid.v4(),
          name: function['name']?.toString() ?? '',
          arguments: _decodeArguments(function['arguments']),
        ),
      );
    }
    if (text.isNotEmpty) onPartial?.call(text);
    return ModelTurn(
      text: text,
      toolCalls: calls,
      raw: data,
      reasoning: reasoning,
    );
  }

  Future<ModelTurn> _openAiChatStream(
    ProviderConfig config,
    String apiKey,
    Map<String, dynamic> payload, {
    void Function(String partial)? onPartial,
  }) async {
    final uri = _uri(config, config.chatPath, apiKey: apiKey);
    final body = jsonEncode(payload);
    final approxMb = body.length / (1024 * 1024);
    final adaptive = approxMb > 1.5
        ? (config.timeoutSeconds + (approxMb * 40).round()).clamp(180, 600)
        : config.timeoutSeconds;

    final request = http.Request('POST', uri)
      ..headers.addAll(<String, String>{
        ..._headers(config, apiKey),
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
        'Connection': 'keep-alive',
      })
      ..body = body;

    final streamed = await _client.send(request).timeout(
      Duration(seconds: adaptive),
    );
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      final errBody = await streamed.stream.bytesToString();
      throw ProviderException(
        'HTTP ${streamed.statusCode} semasa stream.',
        statusCode: streamed.statusCode,
        body: errBody,
      );
    }

    final contentType = streamed.headers['content-type'] ?? '';
    // Sesetengah provider abaikan stream=true dan balas JSON biasa.
    if (contentType.contains('application/json') &&
        !contentType.contains('event-stream')) {
      final full = await streamed.stream.bytesToString();
      final data = _decodeMap(full);
      final choices = data['choices'] as List?;
      if (choices == null || choices.isEmpty) {
        throw ProviderException('Respons JSON tiada choices.', body: full);
      }
      final message = Map<String, dynamic>.from(
        (choices.first as Map)['message'] as Map? ?? const <String, dynamic>{},
      );
      final text = _contentToText(message['content']);
      if (text.isNotEmpty) onPartial?.call(text);
      final calls = <ToolCall>[];
      for (final raw in message['tool_calls'] as List? ?? const <dynamic>[]) {
        if (raw is! Map) continue;
        final item = Map<String, dynamic>.from(raw);
        final function = Map<String, dynamic>.from(
          item['function'] as Map? ?? const <String, dynamic>{},
        );
        calls.add(
          ToolCall(
            id: item['id']?.toString() ?? _uuid.v4(),
            name: function['name']?.toString() ?? '',
            arguments: _decodeArguments(function['arguments']),
          ),
        );
      }
      return ModelTurn(
        text: text,
        toolCalls: calls,
        raw: data,
        reasoning: _extractReasoning(message, data),
      );
    }

    final textBuf = StringBuffer();
    final reasoningBuf = StringBuffer();
    // index -> {id, name, arguments}
    final toolAcc = <int, Map<String, String>>{};
    var lineCarry = '';
    var lastEmit = DateTime.fromMillisecondsSinceEpoch(0);
    var rawChunks = <Map<String, dynamic>>[];

    void emitPartial({bool force = false}) {
      if (onPartial == null) return;
      final now = DateTime.now();
      if (!force && now.difference(lastEmit).inMilliseconds < 120) return;
      lastEmit = now;
      final r = reasoningBuf.toString().trim();
      final c = textBuf.toString();
      if (r.isNotEmpty && c.isEmpty) {
        onPartial('💭 $r');
      } else if (c.isNotEmpty) {
        onPartial(c);
      }
    }

    await for (final chunk in streamed.stream.transform(utf8.decoder)) {
      lineCarry += chunk;
      final parts = lineCarry.split('\n');
      lineCarry = parts.removeLast();
      for (var line in parts) {
        line = line.trimRight();
        if (line.isEmpty) continue;
        if (line.startsWith(':')) continue; // SSE comment/keepalive
        if (!line.startsWith('data:')) continue;
        final dataStr = line.substring(5).trim();
        if (dataStr.isEmpty) continue;
        if (dataStr == '[DONE]') {
          emitPartial(force: true);
          break;
        }
        Map<String, dynamic> data;
        try {
          data = Map<String, dynamic>.from(jsonDecode(dataStr) as Map);
        } catch (_) {
          continue;
        }
        rawChunks.add(data);
        final choices = data['choices'] as List?;
        if (choices == null || choices.isEmpty) continue;
        final choice = choices.first;
        if (choice is! Map) continue;
        final delta = choice['delta'] ?? choice['message'];
        if (delta is! Map) continue;
        final d = Map<String, dynamic>.from(delta);

        final rc = d['reasoning_content'] ?? d['reasoning'] ?? d['thinking'];
        if (rc is String && rc.isNotEmpty) {
          reasoningBuf.write(rc);
          emitPartial();
        }
        final content = d['content'];
        if (content is String && content.isNotEmpty) {
          textBuf.write(content);
          emitPartial();
        } else if (content is List) {
          for (final block in content) {
            if (block is Map && block['type'] == 'text') {
              final tx = block['text']?.toString() ?? '';
              if (tx.isNotEmpty) {
                textBuf.write(tx);
                emitPartial();
              }
            }
          }
        }

        final tcs = d['tool_calls'] as List?;
        if (tcs != null) {
          for (final raw in tcs) {
            if (raw is! Map) continue;
            final item = Map<String, dynamic>.from(raw);
            final idx = (item['index'] as num?)?.toInt() ?? 0;
            final acc = toolAcc.putIfAbsent(
              idx,
              () => <String, String>{
                'id': '',
                'name': '',
                'arguments': '',
              },
            );
            if (item['id'] != null) {
              acc['id'] = item['id'].toString();
            }
            final fn = item['function'];
            if (fn is Map) {
              if (fn['name'] != null) {
                acc['name'] = fn['name'].toString();
              }
              if (fn['arguments'] != null) {
                acc['arguments'] =
                    (acc['arguments'] ?? '') + fn['arguments'].toString();
              }
            }
          }
          if (toolAcc.isNotEmpty && textBuf.isEmpty) {
            final names = toolAcc.values
                .map((e) => e['name'])
                .where((n) => n != null && n!.isNotEmpty)
                .join(', ');
            if (names.isNotEmpty) {
              onPartial?.call('🔧 Menyusun tool: $names');
            }
          }
        }
      }
    }
    emitPartial(force: true);

    final calls = <ToolCall>[];
    final sortedKeys = toolAcc.keys.toList()..sort();
    for (final idx in sortedKeys) {
      final acc = toolAcc[idx]!;
      final name = acc['name'] ?? '';
      if (name.isEmpty) continue;
      calls.add(
        ToolCall(
          id: (acc['id']?.isNotEmpty == true) ? acc['id']! : _uuid.v4(),
          name: name,
          arguments: _decodeArguments(acc['arguments'] ?? ''),
        ),
      );
    }

    return ModelTurn(
      text: textBuf.toString(),
      toolCalls: calls,
      raw: <String, dynamic>{
        'stream': true,
        'chunks': rawChunks.length,
      },
      reasoning: reasoningBuf.toString().trim(),
    );
  }

  String _extractReasoning(
    Map<String, dynamic> message,
    Map<String, dynamic> data,
  ) {
    for (final key in <String>[
      'reasoning_content',
      'reasoning',
      'thinking',
      'reasoning_text',
    ]) {
      final v = message[key] ?? data[key];
      if (v is String && v.trim().isNotEmpty) return v.trim();
    }
    final choices = data['choices'] as List?;
    if (choices != null && choices.isNotEmpty && choices.first is Map) {
      final choice = Map<String, dynamic>.from(choices.first as Map);
      final r = choice['reasoning'] ?? choice['reasoning_content'];
      if (r is String && r.trim().isNotEmpty) return r.trim();
    }
    return '';
  }

  Future<ModelTurn> _openAiResponses(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final input = <Map<String, dynamic>>[];
    for (final message in messages) {
      if (message.role == MessageRole.tool) {
        input.add(<String, dynamic>{
          'type': 'function_call_output',
          'call_id': message.toolCallId,
          'output': message.content,
        });
        continue;
      }
      if (message.metadata['toolCalls'] is List) {
        if (message.content.trim().isNotEmpty) {
          input.add(<String, dynamic>{
            'role': 'assistant',
            'content': <Map<String, dynamic>>[
              <String, dynamic>{'type': 'output_text', 'text': message.content},
            ],
          });
        }
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          input.add(<String, dynamic>{
            'type': 'function_call',
            'call_id': call['id'],
            'name': call['name'],
            'arguments': jsonEncode(
              call['arguments'] ?? const <String, dynamic>{},
            ),
          });
        }
        continue;
      }
      final content = await _responsesContent(message);
      input.add(<String, dynamic>{
        'role': _apiRole(message.role),
        'content': content,
      });
    }
    final payload = <String, dynamic>{
      'model': model,
      'input': input,
      'temperature': config.temperature,
      'max_output_tokens': config.maxTokens,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map(
              (item) => <String, dynamic>{
                'type': 'function',
                'name': item.id,
                'description': item.description,
                'parameters': item.parameters,
              },
            )
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final output = data['output'] as List? ?? const <dynamic>[];
    final textParts = <String>[];
    final calls = <ToolCall>[];
    for (final raw in output) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (item['type'] == 'function_call') {
        calls.add(
          ToolCall(
            id: item['call_id']?.toString() ??
                item['id']?.toString() ??
                _uuid.v4(),
            name: item['name']?.toString() ?? '',
            arguments: _decodeArguments(item['arguments']),
          ),
        );
      }
      final content = item['content'];
      if (content is List) {
        for (final block in content) {
          if (block is Map &&
              (block['type'] == 'output_text' || block['type'] == 'text')) {
            textParts.add(block['text']?.toString() ?? '');
          }
        }
      }
    }
    final fallback = data['output_text']?.toString() ?? '';
    final text = textParts.join('\n').trim();
    return ModelTurn(
      text: text.isEmpty ? fallback : text,
      toolCalls: calls,
      raw: data,
    );
  }

  Future<ModelTurn> _anthropic(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final system = messages
        .where((item) => item.role == MessageRole.system)
        .map((item) => item.content)
        .join('\n\n');
    final anthropicMessages = <Map<String, dynamic>>[];
    for (final message in messages.where(
      (item) => item.role != MessageRole.system,
    )) {
      if (message.role == MessageRole.tool) {
        anthropicMessages.add(<String, dynamic>{
          'role': 'user',
          'content': <Map<String, dynamic>>[
            <String, dynamic>{
              'type': 'tool_result',
              'tool_use_id': message.toolCallId,
              'content': message.content,
            },
          ],
        });
        continue;
      }
      final blocks = await _anthropicContent(message);
      if (message.metadata['toolCalls'] is List) {
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          blocks.add(<String, dynamic>{
            'type': 'tool_use',
            'id': call['id'],
            'name': call['name'],
            'input': call['arguments'] ?? const <String, dynamic>{},
          });
        }
      }
      anthropicMessages.add(<String, dynamic>{
        'role': message.role == MessageRole.assistant ? 'assistant' : 'user',
        'content': blocks,
      });
    }
    final payload = <String, dynamic>{
      'model': model,
      'max_tokens': config.maxTokens,
      'temperature': config.temperature,
      if (system.isNotEmpty) 'system': system,
      'messages': anthropicMessages,
      if (tools.isNotEmpty && config.supportsTools)
        'tools': tools
            .map(
              (item) => <String, dynamic>{
                'name': item.id,
                'description': item.description,
                'input_schema': item.parameters,
              },
            )
            .toList(),
    };
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final content = data['content'] as List? ?? const <dynamic>[];
    final text = <String>[];
    final calls = <ToolCall>[];
    for (final raw in content) {
      if (raw is! Map) continue;
      final block = Map<String, dynamic>.from(raw);
      if (block['type'] == 'text') text.add(block['text']?.toString() ?? '');
      if (block['type'] == 'tool_use') {
        calls.add(
          ToolCall(
            id: block['id']?.toString() ?? _uuid.v4(),
            name: block['name']?.toString() ?? '',
            arguments: Map<String, dynamic>.from(
              block['input'] as Map? ?? const <String, dynamic>{},
            ),
          ),
        );
      }
    }
    return ModelTurn(text: text.join('\n'), toolCalls: calls, raw: data);
  }

  Future<ModelTurn> _gemini(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final systemText = messages
        .where((item) => item.role == MessageRole.system)
        .map((item) => item.content)
        .join('\n\n');
    final contents = <Map<String, dynamic>>[];
    for (final message in messages.where(
      (item) => item.role != MessageRole.system,
    )) {
      if (message.role == MessageRole.tool) {
        contents.add(<String, dynamic>{
          'role': 'user',
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{
              'functionResponse': <String, dynamic>{
                'name': message.name ?? 'tool',
                'response': _safeJsonValue(message.content),
              },
            },
          ],
        });
        continue;
      }
      final parts = await _geminiContent(message);
      if (message.metadata['toolCalls'] is List) {
        for (final raw in message.metadata['toolCalls'] as List) {
          if (raw is! Map) continue;
          final call = Map<String, dynamic>.from(raw);
          parts.add(<String, dynamic>{
            'functionCall': <String, dynamic>{
              'name': call['name'],
              'args': call['arguments'] ?? const <String, dynamic>{},
            },
          });
        }
      }
      contents.add(<String, dynamic>{
        'role': message.role == MessageRole.assistant ? 'model' : 'user',
        'parts': parts,
      });
    }
    final payload = <String, dynamic>{
      if (systemText.isNotEmpty)
        'systemInstruction': <String, dynamic>{
          'parts': <Map<String, dynamic>>[
            <String, dynamic>{'text': systemText},
          ],
        },
      'contents': contents,
      'generationConfig': <String, dynamic>{
        'temperature': config.temperature,
        'maxOutputTokens': config.maxTokens,
      },
      if (tools.isNotEmpty && config.supportsTools)
        'tools': <Map<String, dynamic>>[
          <String, dynamic>{
            'functionDeclarations': tools
                .map(
                  (item) => <String, dynamic>{
                    'name': item.id,
                    'description': item.description,
                    'parameters': item.parameters,
                  },
                )
                .toList(),
          },
        ],
    };
    final path = config.chatPath.replaceAll('{model}', model);
    final response = await _post(config, apiKey, path, payload);
    final data = _decodeMap(response.body);
    final candidates = data['candidates'] as List? ?? const <dynamic>[];
    if (candidates.isEmpty) {
      throw ProviderException(
        'Gemini tidak memulangkan candidates.',
        body: response.body,
      );
    }
    final candidate = Map<String, dynamic>.from(candidates.first as Map);
    final content = Map<String, dynamic>.from(
      candidate['content'] as Map? ?? const <String, dynamic>{},
    );
    final text = <String>[];
    final calls = <ToolCall>[];
    for (final raw in content['parts'] as List? ?? const <dynamic>[]) {
      if (raw is! Map) continue;
      final part = Map<String, dynamic>.from(raw);
      if (part['text'] != null) text.add(part['text'].toString());
      if (part['functionCall'] is Map) {
        final call = Map<String, dynamic>.from(part['functionCall'] as Map);
        calls.add(
          ToolCall(
            id: _uuid.v4(),
            name: call['name']?.toString() ?? '',
            arguments: Map<String, dynamic>.from(
              call['args'] as Map? ?? const <String, dynamic>{},
            ),
          ),
        );
      }
    }
    return ModelTurn(text: text.join('\n'), toolCalls: calls, raw: data);
  }

  Future<ModelTurn> _customRest(
    ProviderConfig config,
    String apiKey,
    List<ChatMessage> messages,
    List<ToolDefinition> tools,
    String model,
  ) async {
    final serialisedMessages = <Map<String, dynamic>>[];
    for (final message in messages) {
      serialisedMessages.add(await _openAiMessage(message));
    }
    Map<String, dynamic> payload;
    if (config.customRequestTemplate.trim().isEmpty) {
      payload = <String, dynamic>{
        'model': model,
        'messages': serialisedMessages,
        if (tools.isNotEmpty) 'tools': tools.map((item) => item.toOpenAiJson()).toList(),
      };
    } else {
      var template = config.customRequestTemplate;
      template = template
          .replaceAll('{{model}}', jsonEncode(model))
          .replaceAll('{{messages}}', jsonEncode(serialisedMessages))
          .replaceAll(
            '{{tools}}',
            jsonEncode(tools.map((item) => item.toOpenAiJson()).toList()),
          );
      final decoded = jsonDecode(template);
      if (decoded is! Map) {
        throw ProviderException('Custom request template mesti objek JSON.');
      }
      payload = Map<String, dynamic>.from(decoded);
    }
    final response = await _post(config, apiKey, config.chatPath, payload);
    final data = _decodeMap(response.body);
    final value = _readJsonPath(data, config.customResponsePath);
    final text = value is String ? value : jsonEncode(value);
    return ModelTurn(text: text, raw: data);
  }

  Future<Map<String, dynamic>> _openAiMessage(
    ChatMessage message, {
    bool inlineImages = true,
  }) async {
    if (message.role == MessageRole.tool) {
      return <String, dynamic>{
        'role': 'tool',
        'tool_call_id': message.toolCallId,
        'content': message.content,
      };
    }
    final output = <String, dynamic>{'role': _apiRole(message.role)};
    if (message.metadata['toolCalls'] is List) {
      output['content'] = message.content.isEmpty ? null : message.content;
      output['tool_calls'] = (message.metadata['toolCalls'] as List)
          .whereType<Map>()
          .map(
            (raw) => <String, dynamic>{
              'id': raw['id'],
              'type': 'function',
              'function': <String, dynamic>{
                'name': raw['name'],
                'arguments': jsonEncode(
                  raw['arguments'] ?? const <String, dynamic>{},
                ),
              },
            },
          )
          .toList();
      return output;
    }

    if (message.attachments.isEmpty) {
      output['content'] = message.content;
      return output;
    }
    final blocks = <Map<String, dynamic>>[];
    if (message.content.trim().isNotEmpty) {
      blocks.add(<String, dynamic>{
        'type': 'text',
        'text': message.content,
      });
    }
    for (final attachment in message.attachments) {
      // Sejarah lama: jangan inline gambar lagi (teks sahaja).
      if (!inlineImages && attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
        continue;
      }
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
        continue;
      }
      if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'image_url',
          'image_url': <String, dynamic>{'url': inline.dataUri},
        });
      } else if (attachment.kind == AttachmentKind.audio &&
          !inline.isRemote &&
          inline.base64.isNotEmpty) {
        blocks.add(<String, dynamic>{
          'type': 'input_audio',
          'input_audio': <String, dynamic>{
            'data': inline.base64,
            'format': _audioFormat(attachment.name),
          },
        });
      } else if (inline.text != null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': 'Fail ${attachment.name}:\n${inline.text}',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      }
    }
    output['content'] = blocks;
    return output;
  }

  Future<List<Map<String, dynamic>>> _responsesContent(
    ChatMessage message,
  ) async {
    final blocks = <Map<String, dynamic>>[];
    if (message.content.trim().isNotEmpty) {
      blocks.add(<String, dynamic>{
        'type': 'input_text',
        'text': message.content,
      });
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'input_text',
          'text': _attachmentNotice(attachment),
        });
      } else if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'input_image',
          'image_url': inline.dataUri,
        });
      } else if (inline.isRemote) {
        blocks.add(<String, dynamic>{
          'type': 'input_text',
          'text': '[Lampiran URL: ${attachment.name} — ${inline.sourceUrl}]',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'input_file',
          'filename': attachment.name,
          'file_data': inline.dataUri,
        });
      }
    }
    return blocks;
  }

  Future<List<Map<String, dynamic>>> _anthropicContent(
    ChatMessage message,
  ) async {
    final blocks = <Map<String, dynamic>>[];
    if (message.content.isNotEmpty) {
      blocks.add(<String, dynamic>{'type': 'text', 'text': message.content});
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      } else if (attachment.kind == AttachmentKind.image) {
        blocks.add(<String, dynamic>{
          'type': 'image',
          'source': inline.isRemote
              ? <String, dynamic>{
                  'type': 'url',
                  'url': inline.sourceUrl,
                }
              : <String, dynamic>{
                  'type': 'base64',
                  'media_type': attachment.mimeType,
                  'data': inline.base64,
                },
        });
      } else if (inline.isRemote) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': '[Lampiran URL: ${attachment.name} — ${inline.sourceUrl}]',
        });
      } else if (attachment.mimeType == 'application/pdf') {
        blocks.add(<String, dynamic>{
          'type': 'document',
          'source': <String, dynamic>{
            'type': 'base64',
            'media_type': attachment.mimeType,
            'data': inline.base64,
          },
          'title': attachment.name,
        });
      } else if (inline.text != null) {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': 'Fail ${attachment.name}:\n${inline.text}',
        });
      } else {
        blocks.add(<String, dynamic>{
          'type': 'text',
          'text': _attachmentNotice(attachment),
        });
      }
    }
    return blocks;
  }

  Future<List<Map<String, dynamic>>> _geminiContent(
    ChatMessage message,
  ) async {
    final parts = <Map<String, dynamic>>[];
    if (message.content.isNotEmpty) {
      parts.add(<String, dynamic>{'text': message.content});
    }
    for (final attachment in message.attachments) {
      final inline = await _inlineAttachment(attachment);
      if (inline == null) {
        parts.add(<String, dynamic>{'text': _attachmentNotice(attachment)});
      } else if (inline.isRemote) {
        parts.add(<String, dynamic>{
          'fileData': <String, dynamic>{
            'mimeType': attachment.mimeType,
            'fileUri': inline.sourceUrl,
          },
        });
      } else {
        parts.add(<String, dynamic>{
          'inlineData': <String, dynamic>{
            'mimeType': attachment.mimeType,
            'data': inline.base64,
          },
        });
      }
    }
    return parts;
  }

  Future<_InlineAttachment?> _inlineAttachment(
    ChatAttachment attachment,
  ) async {
    if (attachment.sourceUrl?.isNotEmpty == true) {
      return _InlineAttachment(
        base64: '',
        dataUri: attachment.sourceUrl!,
        sourceUrl: attachment.sourceUrl!,
      );
    }
    if (attachment.path.isEmpty) return null;
    final file = File(attachment.path);
    if (!await file.exists()) return null;
    final size = await file.length();
    if (size > AppConfig.maxInlineModelAttachmentBytes) return null;
    var bytes = await file.readAsBytes();
    var mime = attachment.mimeType;
    // Mampat imej besar — elak JSON 10MB+ yang menyebabkan connection abort.
    if (attachment.kind == AttachmentKind.image ||
        mime.startsWith('image/')) {
      final compressed = await _compressImageForModel(bytes);
      if (compressed != null) {
        bytes = compressed;
        mime = 'image/png';
      }
    }
    String? text;
    if (_isTextMime(mime, attachment.name)) {
      try {
        text = utf8.decode(bytes, allowMalformed: true);
        if (text.length > AppConfig.maxToolOutputChars) {
          text = '${text.substring(0, AppConfig.maxToolOutputChars)}…';
        }
      } catch (_) {
        text = null;
      }
    }
    final encoded = base64Encode(bytes);
    return _InlineAttachment(
      base64: encoded,
      dataUri: 'data:$mime;base64,$encoded',
      text: text,
    );
  }

  /// Kecilkan imej untuk vision API (max sisi ~1280, target < ~700KB).
  Future<Uint8List?> _compressImageForModel(Uint8List bytes) async {
    try {
      if (bytes.lengthInBytes <= 350 * 1024) return null; // sudah kecil
      for (final maxSide in <int>[1280, 960, 720]) {
        final codec = await ui.instantiateImageCodec(
          bytes,
          targetWidth: maxSide,
        );
        final frame = await codec.getNextFrame();
        final image = frame.image;
        final bd = await image.toByteData(format: ui.ImageByteFormat.png);
        image.dispose();
        if (bd == null) continue;
        final out = bd.buffer.asUint8List();
        if (out.lengthInBytes < bytes.lengthInBytes &&
            out.lengthInBytes <= 900 * 1024) {
          return out;
        }
        if (out.lengthInBytes < bytes.lengthInBytes && maxSide <= 720) {
          return out;
        }
      }
    } catch (_) {}
    return null;
  }

  String _attachmentNotice(ChatAttachment attachment) =>
      '[Lampiran: ${attachment.name}, ${attachment.mimeType}, ${attachment.sizeBytes} bait. '
      'Format/saiz ini tidak boleh diinlin secara langsung oleh protokol provider ini.]';

  bool _isTextMime(String mimeType, String name) {
    final extension = p.extension(name).toLowerCase();
    return mimeType.startsWith('text/') ||
        mimeType.contains('json') ||
        mimeType.contains('xml') ||
        mimeType.contains('yaml') ||
        <String>{
          '.md',
          '.txt',
          '.csv',
          '.json',
          '.xml',
          '.yaml',
          '.yml',
          '.dart',
          '.kt',
          '.java',
          '.js',
          '.ts',
          '.py',
          '.sh',
          '.html',
          '.css',
          '.sql',
          '.log',
        }.contains(extension);
  }

  String _audioFormat(String filename) {
    final extension = p.extension(filename).toLowerCase().replaceFirst('.', '');
    return switch (extension) {
      'wav' => 'wav',
      'mp3' => 'mp3',
      'm4a' => 'm4a',
      'ogg' => 'ogg',
      _ => 'wav',
    };
  }

  Future<http.Response> _post(
    ProviderConfig config,
    String apiKey,
    String path,
    Map<String, dynamic> payload, {
    int? timeoutOverride,
  }) async {
    final uri = _uri(config, path, apiKey: apiKey);
    final body = jsonEncode(payload);
    // Payload vision besar → timeout lebih longgar (min 180s, max 600s).
    final approxMb = body.length / (1024 * 1024);
    final adaptive = approxMb > 1.5
        ? (config.timeoutSeconds + (approxMb * 40).round()).clamp(180, 600)
        : config.timeoutSeconds;
    final seconds = timeoutOverride ?? adaptive;
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
            'Connection': 'keep-alive',
          },
          body: body,
        )
        .timeout(Duration(seconds: seconds));
    _ensureSuccess(response);
    return response;
  }

  Uri _uri(
    ProviderConfig config,
    String path, {
    required String apiKey,
  }) {
    final base = config.baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final suffix = path.trim().isEmpty
        ? ''
        : (path.startsWith('/') || path.startsWith('?') ? path : '/$path');
    final parsed = Uri.parse('$base$suffix');
    if (config.authStyle == AuthStyle.queryParameter && apiKey.isNotEmpty) {
      return parsed.replace(
        queryParameters: <String, String>{
          ...parsed.queryParameters,
          config.apiKeyHeader: apiKey,
        },
      );
    }
    return parsed;
  }

  Map<String, String> _headers(ProviderConfig config, String apiKey) {
    final headers = <String, String>{
      'Accept': 'application/json',
      AppConfig.sessionHeader: AppConfig.version,
      ...config.extraHeaders,
    };
    if (apiKey.isEmpty || config.authStyle == AuthStyle.none) return headers;
    if (config.authStyle == AuthStyle.bearer ||
        config.authStyle == AuthStyle.apiKeyHeader ||
        config.authStyle == AuthStyle.xApiKey) {
      headers[config.apiKeyHeader] = '${config.apiKeyPrefix}$apiKey';
    }
    return headers;
  }

  void _ensureSuccess(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) return;
    var message = 'HTTP ${response.statusCode}';
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map) {
          message = error['message']?.toString() ?? message;
        } else if (error != null) {
          message = error.toString();
        } else if (decoded['message'] != null) {
          message = decoded['message'].toString();
        }
      }
    } catch (_) {
      if (response.body.trim().isNotEmpty) {
        message = response.body.trim();
      }
    }
    if (message.length > 800) message = '${message.substring(0, 800)}…';
    throw ProviderException(
      message,
      statusCode: response.statusCode,
      body: response.body,
    );
  }

  Map<String, dynamic> _decodeMap(String body) {
    final decoded = jsonDecode(body);
    if (decoded is! Map) {
      throw ProviderException('Respons provider bukan objek JSON.', body: body);
    }
    return Map<String, dynamic>.from(decoded);
  }

  Map<String, dynamic> _decodeArguments(Object? value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    if (value == null) return <String, dynamic>{};
    try {
      final decoded = jsonDecode(value.toString());
      return decoded is Map
          ? Map<String, dynamic>.from(decoded)
          : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{'value': value.toString()};
    }
  }

  String _contentToText(Object? value) {
    if (value == null) return '';
    if (value is String) return value;
    if (value is List) {
      return value
          .whereType<Map>()
          .map((item) => item['text']?.toString() ?? '')
          .where((item) => item.isNotEmpty)
          .join('\n');
    }
    return value.toString();
  }

  String _apiRole(MessageRole role) => switch (role) {
        MessageRole.system => 'system',
        MessageRole.user => 'user',
        MessageRole.assistant => 'assistant',
        MessageRole.tool => 'tool',
      };

  Object _safeJsonValue(String value) {
    try {
      return jsonDecode(value);
    } catch (_) {
      return <String, dynamic>{'content': value};
    }
  }

  Object? _readJsonPath(Object? value, String path) {
    Object? current = value;
    for (final segment in path.split('.').where((item) => item.isNotEmpty)) {
      if (current is Map) {
        current = current[segment];
      } else if (current is List) {
        final index = int.tryParse(segment);
        if (index == null || index < 0 || index >= current.length) return null;
        current = current[index];
      } else {
        return null;
      }
    }
    return current;
  }

  Future<GeneratedMedia> generateSpeech({
    required ProviderConfig config,
    required String apiKey,
    required String text,
    String voice = '',
    String style = '',
  }) async {
    if (config.speechModel.trim().isEmpty) {
      throw ProviderException('Model suara belum diisi pada provider ini.');
    }
    final model = config.speechModel.trim().toLowerCase();
    if (model.contains('mimo') &&
        (model.contains('tts') || model.contains('voice'))) {
      return _mimoSpeech(config, apiKey, text, voice: voice, style: style);
    }
    if (config.presetId == 'mimo' ||
        (Uri.tryParse(config.baseUrl)?.host ?? '').endsWith('xiaomimimo.com')) {
      return _mimoSpeech(config, apiKey, text, voice: voice, style: style);
    }
    return _openAiSpeech(config, apiKey, text, voice: voice);
  }

  Future<GeneratedMedia> generateImage({
    required ProviderConfig config,
    required String apiKey,
    required String prompt,
    String size = '1024x1024',
  }) async {
    if (config.imageModel.trim().isEmpty) {
      throw ProviderException('Model gambar belum diisi pada provider ini.');
    }
    if (config.presetId == 'gemini' ||
        (Uri.tryParse(config.baseUrl)?.host ?? '')
            .contains('generativelanguage.googleapis.com')) {
      return _geminiImage(config, apiKey, prompt);
    }
    return _openAiImage(config, apiKey, prompt, size: size);
  }

  Future<GeneratedMedia> generateVideo({
    required ProviderConfig config,
    required String apiKey,
    required String prompt,
  }) async {
    if (config.videoModel.trim().isEmpty) {
      throw ProviderException('Model video belum diisi pada provider ini.');
    }
    return _openAiVideo(config, apiKey, prompt);
  }

  Future<GeneratedMedia> _mimoSpeech(
    ProviderConfig config,
    String apiKey,
    String text, {
    String voice = '',
    String style = '',
  }) async {
    final uri = _uri(config, config.chatPath, apiKey: apiKey);
    final styleText = style.trim().isEmpty
        ? 'Natural, clear speaking voice.'
        : style.trim();
    final body = <String, dynamic>{
      'model': config.speechModel.trim(),
      'messages': <Map<String, dynamic>>[
        <String, dynamic>{'role': 'user', 'content': styleText},
        <String, dynamic>{'role': 'assistant', 'content': text},
      ],
      'audio': <String, dynamic>{
        'format': 'wav',
        'voice': voice.trim().isEmpty ? 'mimo_default' : voice.trim(),
      },
    };
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
          },
          body: jsonEncode(body),
        )
        .timeout(AppConfig.defaultTimeout);
    _ensureSuccess(response);
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) {
      throw ProviderException('Respons TTS MiMo tidak sah.');
    }
    final audio = (((decoded['choices'] as List?)?.first as Map?)?['message']
        as Map?)?['audio'];
    if (audio is! Map || audio['data'] == null) {
      throw ProviderException('MiMo TTS tidak pulangkan audio.');
    }
    final bytes = base64Decode(audio['data'].toString());
    return GeneratedMedia(
      bytes: bytes,
      mimeType: 'audio/wav',
      fileName: 'speech_${_uuid.v4().substring(0, 8)}.wav',
    );
  }

  Future<GeneratedMedia> _openAiSpeech(
    ProviderConfig config,
    String apiKey,
    String text, {
    String voice = '',
  }) async {
    final root = config.baseUrl.replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$root/audio/speech');
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
          },
          body: jsonEncode(<String, dynamic>{
            'model': _speechModelId(config),
            'input': text,
            'voice': voice.trim().isEmpty ? 'alloy' : voice.trim(),
            'format': 'mp3',
          }),
        )
        .timeout(AppConfig.defaultTimeout);
    _ensureSuccess(response);
    return GeneratedMedia(
      bytes: response.bodyBytes,
      mimeType: 'audio/mpeg',
      fileName: 'speech_${_uuid.v4().substring(0, 8)}.mp3',
    );
  }

  Future<GeneratedMedia> _openAiImage(
    ProviderConfig config,
    String apiKey,
    String prompt, {
    String size = '1024x1024',
  }) async {
    final root = config.baseUrl.replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.parse('$root/images/generations');
    final model = _imageModelId(config);
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
          },
          body: jsonEncode(<String, dynamic>{
            'model': model,
            'prompt': prompt,
            'size': size,
            'n': 1,
          }),
        )
        .timeout(AppConfig.defaultTimeout);
    _ensureSuccess(response);
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) throw ProviderException('Respons gambar tidak sah.');
    final first = (decoded['data'] as List?)?.isNotEmpty == true
        ? decoded['data'].first
        : null;
    if (first is! Map) throw ProviderException('Tiada gambar dalam respons.');
    if (first['b64_json'] != null) {
      return GeneratedMedia(
        bytes: base64Decode(first['b64_json'].toString()),
        mimeType: 'image/png',
        fileName: 'image_${_uuid.v4().substring(0, 8)}.png',
      );
    }
    final url = first['url']?.toString() ?? '';
    if (url.isEmpty) throw ProviderException('URL gambar kosong.');
    final img = await _client.get(Uri.parse(url)).timeout(AppConfig.defaultTimeout);
    _ensureSuccess(img);
    return GeneratedMedia(
      bytes: img.bodyBytes,
      mimeType: img.headers['content-type'] ?? 'image/png',
      fileName: 'image_${_uuid.v4().substring(0, 8)}.png',
    );
  }

  String _speechModelId(ProviderConfig config) =>
      config.speechModel.trim();

  String _imageModelId(ProviderConfig config) => config.imageModel.trim();

  String _videoModelId(ProviderConfig config) => config.videoModel.trim();

  Future<GeneratedMedia> _openAiVideo(
    ProviderConfig config,
    String apiKey,
    String prompt,
  ) async {
    final root = config.baseUrl.replaceAll(RegExp(r'/+$'), '');
    final headers = <String, String>{
      ..._headers(config, apiKey),
      'Content-Type': 'application/json',
    };
    final body = jsonEncode(<String, dynamic>{
      'model': _videoModelId(config),
      'prompt': prompt,
    });
    final paths = <String>['/videos', '/video/generations', '/videos/generations'];
    http.Response? last;
    for (final path in paths) {
      try {
        final response = await _client
            .post(Uri.parse('$root$path'), headers: headers, body: body)
            .timeout(AppConfig.defaultTimeout);
        last = response;
        if (response.statusCode >= 200 && response.statusCode < 300) {
          return _videoFromResponse(response);
        }
      } catch (_) {}
    }
    final hint = last == null
        ? 'tiada sambungan'
        : 'HTTP ${last.statusCode}: ${last.body.length > 240 ? last.body.substring(0, 240) : last.body}';
    throw ProviderException('Jana video gagal ($hint). Semak model video & endpoint provider.');
  }

  Future<GeneratedMedia> _videoFromResponse(http.Response response) async {
    final type = (response.headers['content-type'] ?? '').toLowerCase();
    if (type.contains('video') || type.contains('octet-stream')) {
      return GeneratedMedia(
        bytes: response.bodyBytes,
        mimeType: type.contains('mp4') ? 'video/mp4' : 'video/mp4',
        fileName: 'video_${_uuid.v4().substring(0, 8)}.mp4',
      );
    }
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map) {
        final b64 = decoded['data'] is List
            ? ((decoded['data'] as List).first as Map?)?['b64_json']
            : decoded['b64_json'];
        if (b64 != null) {
          return GeneratedMedia(
            bytes: base64Decode(b64.toString()),
            mimeType: 'video/mp4',
            fileName: 'video_${_uuid.v4().substring(0, 8)}.mp4',
          );
        }
        final url = decoded['url'] ??
            ((decoded['data'] is List)
                ? ((decoded['data'] as List).first as Map?)?['url']
                : null);
        if (url is String && url.startsWith('http')) {
          final file = await _client.get(Uri.parse(url)).timeout(AppConfig.defaultTimeout);
          _ensureSuccess(file);
          return GeneratedMedia(
            bytes: file.bodyBytes,
            mimeType: file.headers['content-type'] ?? 'video/mp4',
            fileName: 'video_${_uuid.v4().substring(0, 8)}.mp4',
          );
        }
      }
    } catch (_) {}
    throw ProviderException(
      'Provider pulangkan respons video yang belum dikenali. '
      'Semak nama model video.',
    );
  }

  Future<GeneratedMedia> _geminiImage(
    ProviderConfig config,
    String apiKey,
    String prompt,
  ) async {
    final root = config.baseUrl.replaceAll(RegExp(r'/+$'), '');
    final uri = _uri(
      config,
      config.imageModel.contains(':')
          ? '/models/${config.imageModel.trim()}'
          : '/models/${config.imageModel.trim()}:predict',
      apiKey: apiKey,
    );
    final response = await _client
        .post(
          uri,
          headers: <String, String>{
            ..._headers(config, apiKey),
            'Content-Type': 'application/json',
          },
          body: jsonEncode(<String, dynamic>{
            'instances': <Map<String, dynamic>>[
              <String, dynamic>{'prompt': prompt},
            ],
            'parameters': <String, dynamic>{'sampleCount': 1},
          }),
        )
        .timeout(AppConfig.defaultTimeout);
    _ensureSuccess(response);
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) throw ProviderException('Respons Imagen tidak sah.');
    final pred = (decoded['predictions'] as List?)?.first;
    final b64 = pred is Map
        ? (pred['bytesBase64Encoded'] ?? pred['b64_json'])
        : null;
    if (b64 == null) throw ProviderException('Imagen tidak pulangkan imej.');
    return GeneratedMedia(
      bytes: base64Decode(b64.toString()),
      mimeType: 'image/png',
      fileName: 'image_${_uuid.v4().substring(0, 8)}.png',
    );
  }

  void dispose() => _client.close();
}

class GeneratedMedia {
  const GeneratedMedia({
    required this.bytes,
    required this.mimeType,
    required this.fileName,
  });

  final Uint8List bytes;
  final String mimeType;
  final String fileName;
}

class _InlineAttachment {
  const _InlineAttachment({
    required this.base64,
    required this.dataUri,
    this.sourceUrl = '',
    this.text,
  });

  final String base64;
  final String dataUri;
  final String sourceUrl;
  final String? text;

  bool get isRemote => sourceUrl.isNotEmpty;
}
