import '../models/app_models.dart';

/// Polisi ringan untuk memastikan model yang dipaparkan pada ruang chat
/// benar-benar sesuai digunakan sebagai model perbualan/orchestrator.
class MediaGenSupport {
  const MediaGenSupport({
    this.speech = false,
    this.image = false,
    this.video = false,
  });

  final bool speech;
  final bool image;
  final bool video;

  bool get any => speech || image || video;
}

abstract final class ProviderModelPolicy {
  static const List<String> mimoPreferredModels = <String>[
    'mimo-v2.5-pro',
    'mimo-v2.5',
    'mimo-v2-pro',
    'mimo-v2-omni',
  ];

  static const Set<String> _knownUnavailableMimoModels = <String>{
    // Model ini pernah dimasukkan sebagai preset statik tetapi endpoint chat
    // platform MiMo memulangkan "Unsupported model". Senarai live provider
    // tetap menjadi sumber utama untuk model lain.
    'mimo-v2-flash',
  };

  static List<String> chatModels(
    ProviderConfig config,
    Iterable<String> models,
  ) {
    final output = <String>[];
    final seen = <String>{};
    for (final raw in models) {
      var model = raw.trim();
      if (model.isEmpty) continue;
      if (_isMimo(config) && model.startsWith('mimo/')) {
        model = model.substring('mimo/'.length);
      }
      if (!isChatModel(config, model)) continue;
      final key = model.toLowerCase();
      if (seen.add(key)) output.add(model);
    }
    output.sort((a, b) {
      if (_isMimo(config)) {
        final ai = mimoPreferredModels.indexOf(a.toLowerCase());
        final bi = mimoPreferredModels.indexOf(b.toLowerCase());
        final ar = ai < 0 ? 9999 : ai;
        final br = bi < 0 ? 9999 : bi;
        if (ar != br) return ar.compareTo(br);
      }
      return a.toLowerCase().compareTo(b.toLowerCase());
    });
    return output;
  }

  static bool isChatModel(ProviderConfig config, String model) {
    final id = model.trim().toLowerCase();
    if (id.isEmpty) return false;
    if (!_isMimo(config)) return true;
    if (_knownUnavailableMimoModels.contains(id)) return false;
    if (!id.startsWith('mimo-v2')) return false;
    const nonChatTokens = <String>[
      'tts',
      'asr',
      'voiceclone',
      'voicedesign',
      'embedding',
      'rerank',
    ];
    return !nonChatTokens.any(id.contains);
  }

  static String? preferredModel(
    ProviderConfig config,
    Iterable<String> models, {
    String? exclude,
  }) {
    final compatible = chatModels(config, models)
        .where((item) => item != exclude)
        .toList();
    if (compatible.isEmpty) return null;
    if (_isMimo(config)) {
      for (final preferred in mimoPreferredModels) {
        for (final candidate in compatible) {
          if (candidate.toLowerCase() == preferred) return candidate;
        }
      }
    }
    return compatible.first;
  }

  static ProviderConfig migrateStoredProvider(ProviderConfig config) {
    final migratedTimeout = config.timeoutSeconds == 60 ? 180 : config.timeoutSeconds;
    if (!_isMimo(config)) {
      return migratedTimeout == config.timeoutSeconds
          ? config
          : config.copyWith(
              timeoutSeconds: migratedTimeout,
              updatedAt: DateTime.now(),
            );
    }

    final available = chatModels(config, config.availableModels);
    var selected = config.model.trim();
    if (selected.startsWith('mimo/')) {
      selected = selected.substring('mimo/'.length);
    }
    if (!isChatModel(config, selected)) {
      selected = preferredModel(config, available) ?? mimoPreferredModels.first;
    }

    final changed = selected != config.model ||
        migratedTimeout != config.timeoutSeconds ||
        available.length != config.availableModels.length ||
        !_sameValues(available, config.availableModels);
    if (!changed) return config;
    return config.copyWith(
      model: selected,
      timeoutSeconds: migratedTimeout,
      availableModels: available.isEmpty
          ? List<String>.from(mimoPreferredModels)
          : available,
      testStatus: ProviderTestStatus.untested,
      lastTestMessage:
          'Model lama tidak serasi dan telah diganti. Jalankan Uji Sambungan.',
      updatedAt: DateTime.now(),
    );
  }

  static bool isModelUnavailableError(Object error) {
    final value = error.toString().toLowerCase();
    return value.contains('unsupported model') ||
        value.contains('model not found') ||
        value.contains('unknown model') ||
        value.contains('invalid model') ||
        value.contains('model does not exist') ||
        value.contains('model is not available') ||
        value.contains('model unavailable');
  }


  static MediaGenSupport mediaGen(ProviderConfig config) {
    return MediaGenSupport(
      speech: config.speechModel.trim().isNotEmpty,
      image: config.imageModel.trim().isNotEmpty,
      video: config.videoModel.trim().isNotEmpty,
    );
  }

  static bool _isMimo(ProviderConfig config) {
    final preset = config.presetId.trim().toLowerCase();
    final host = Uri.tryParse(config.baseUrl)?.host.toLowerCase() ?? '';
    final name = config.name.trim().toLowerCase();
    return preset == 'mimo' ||
        preset == 'xiaomi_mimo' ||
        host.endsWith('xiaomimimo.com') ||
        name.contains('xiaomi mimo');
  }

  static bool _sameValues(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }
}
