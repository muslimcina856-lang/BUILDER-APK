import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

import '../config/app_config.dart';

class BrowserAction {
  const BrowserAction({required this.type, required this.arguments});

  final String type;
  final Map<String, dynamic> arguments;
}

/// Browser latar belakang berasaskan Android System WebView/Chromium.
///
/// UI browser tidak pernah dipaparkan. Model menerima snapshot berstruktur
/// berupa URL, tajuk, teks, HTML, pautan dan borang. Untuk `open`/`read`, HTTP
/// parser menjadi fallback apabila enjin native tidak tersedia.
class BrowserSessionService extends ChangeNotifier {
  BrowserSessionService({http.Client? client}) : _client = client ?? http.Client();

  static const MethodChannel _channel =
      MethodChannel('com.aiauto.claw/browser');

  final http.Client _client;
  bool _disposed = false;

  String currentUrl = '';
  String currentTitle = '';
  String lastError = '';
  bool busy = false;
  int completedActions = 0;
  bool desktopMode = true;

  bool get isRunning => currentUrl.isNotEmpty;
  bool get isBusy => busy;

  /// Giliran serial — elak parallel tool/sub-agent → browser_busy.
  Future<void> _chain = Future<void>.value();

  Future<Map<String, dynamic>> execute(
    BrowserAction action, {
    Duration timeout = AppConfig.browserTimeout,
  }) async {
    if (_disposed) throw StateError('Sesi browser telah ditutup.');

    final gate = _chain;
    final done = Completer<void>();
    _chain = done.future;
    try {
      await gate;
    } catch (_) {}

    busy = true;
    lastError = '';
    notifyListeners();

    try {
      if (action.type == 'open') {
        desktopMode = action.arguments['desktopMode'] as bool? ?? true;
      }
      final result = await _invokeNative(action).timeout(timeout);
      completedActions++;
      _updateFromResult(result);
      return result;
    } on MissingPluginException catch (error) {
      return _fallback(action, error, timeout);
    } on PlatformException catch (error) {
      if (error.code == 'browser_busy') {
        lastError = error.message ?? error.code;
        return <String, dynamic>{
          'success': false,
          'error': 'browser_busy',
          'message':
              error.message ??
              'Browser sibuk. Tunggu tindakan sebelumnya, kemudian cuba lagi.',
        };
      }
      if (action.type == 'open' || action.type == 'read') {
        return _fallback(action, error, timeout);
      }
      lastError = error.message ?? error.code;
      final details = error.details;
      return <String, dynamic>{
        'success': false,
        'error': error.code,
        'message': error.message ?? error.code,
        if (details is Map) ...Map<String, dynamic>.from(details),
      };
    } catch (error) {
      if (action.type == 'open' || action.type == 'read') {
        return _fallback(action, error, timeout);
      }
      lastError = error.toString();
      return <String, dynamic>{
        'success': false,
        'error': 'browser_error',
        'message': error.toString(),
      };
    } finally {
      busy = false;
      notifyListeners();
      if (!done.isCompleted) {
        done.complete();
      }
    }
  }

  Future<Map<String, dynamic>> _invokeNative(BrowserAction action) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      action.type,
      action.arguments,
    );
    if (raw == null) {
      throw StateError('Browser native tidak memulangkan hasil.');
    }
    return Map<String, dynamic>.from(raw);
  }

  Future<Map<String, dynamic>> _fallback(
    BrowserAction action,
    Object error,
    Duration timeout,
  ) async {
    final rawUrl = action.type == 'open'
        ? action.arguments['url']?.toString() ?? ''
        : currentUrl;
    if (rawUrl.isEmpty) {
      lastError = error.toString();
      throw error;
    }
    final result = await _httpSnapshot(rawUrl).timeout(timeout);
    completedActions++;
    _updateFromResult(result);
    return result;
  }

  Future<Map<String, dynamic>> _httpSnapshot(String rawUrl) async {
    final uri = _validatedUri(rawUrl);
    final response = await _client.get(
      uri,
      headers: <String, String>{
        'User-Agent': desktopMode
            ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0'
            : 'Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 '
                'AiMultiAgent/1.0.0',
        'Accept':
            'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      },
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException(
        'HTTP ${response.statusCode} ketika membaca ${uri.host}.',
        uri: uri,
      );
    }

    final document = html_parser.parse(response.body);
    for (final node in document.querySelectorAll(
      'script,noscript,style,svg,template,canvas',
    )) {
      node.remove();
    }
    final links = document.querySelectorAll('a[href]').take(160).map((node) {
      final href = node.attributes['href'] ?? '';
      final resolved = uri.resolve(href);
      return <String, dynamic>{
        'text': node.text.replaceAll(RegExp(r'\s+'), ' ').trim(),
        'url': resolved.toString(),
      };
    }).where((item) => (item['url']?.toString() ?? '').isNotEmpty).toList();

    // Approximate interactive elements for HTTP fallback (static HTML only).
    final interactiveNodes = document.querySelectorAll(
      'a[href],button,input,textarea,select,[role=button],[role=link],[role=textbox]',
    );
    final interactive = <Map<String, dynamic>>[];
    var idx = 0;
    for (final node in interactiveNodes.take(120)) {
      final tag = node.localName ?? '';
      final type = node.attributes['type'] ?? node.attributes['role'] ?? tag;
      final text = (node.attributes['aria-label'] ??
              node.attributes['placeholder'] ??
              node.attributes['title'] ??
              node.attributes['name'] ??
              node.attributes['id'] ??
              node.text)
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      final hrefRaw = node.attributes['href'];
      final href = hrefRaw == null || hrefRaw.isEmpty
          ? ''
          : uri.resolve(hrefRaw).toString();
      interactive.add(<String, dynamic>{
        'index': idx,
        'tag': tag,
        'type': type,
        'text': text.length > 120 ? '${text.substring(0, 120)}…' : text,
        'name': node.attributes['name'] ?? '',
        'id': node.attributes['id'] ?? '',
        'placeholder': node.attributes['placeholder'] ?? '',
        'href': href,
        'value': type == 'password' ? '[REDACTED]' : (node.attributes['value'] ?? ''),
        'checked': false,
        'disabled': node.attributes.containsKey('disabled'),
      });
      idx++;
    }

    final result = <String, dynamic>{
      'success': true,
      'engine': 'http-fallback',
      'mode': 'http-fallback',
      'url': uri.toString(),
      'title': document.querySelector('title')?.text.trim() ?? uri.host,
      'text': document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '',
      'html': response.body,
      'interactive_elements': interactive,
      'links': links,
      'forms': const <dynamic>[],
      'canGoBack': false,
      'canGoForward': false,
      'desktopMode': desktopMode,
    };
    return result;
  }

  Uri _validatedUri(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null ||
        !<String>{'http', 'https'}.contains(uri.scheme) ||
        uri.host.isEmpty) {
      throw const FormatException('URL HTTP/HTTPS tidak sah.');
    }
    return uri;
  }

  void _updateFromResult(Map<String, dynamic> result) {
    final page = result['page'];
    final source = page is Map
        ? Map<String, dynamic>.from(page)
        : result;
    final url = source['url']?.toString() ?? '';
    final title = source['title']?.toString() ?? '';
    if (url.isNotEmpty) currentUrl = url;
    if (title.isNotEmpty) currentTitle = title;
    lastError = source['success'] == false
        ? source['error']?.toString() ?? 'Tindakan browser gagal.'
        : '';
  }

  Future<void> clearCookies() async {
    try {
      await _channel.invokeMethod<void>('clearCookies');
    } on MissingPluginException {
      // Tiada cookie jar native dalam fallback HTTP.
    }
    currentUrl = '';
    currentTitle = '';
    notifyListeners();
  }

  /// Hentikan kerja browser pending bila agent dibatalkan / berhenti.
  /// Elak skrip/tindakan terus jalan selepas agent stop (lebih cekap).
  Future<void> cancelPending() async {
    busy = false;
    lastError = 'Dibatalkan';
    try {
      await _channel.invokeMethod<void>('cancel');
    } on MissingPluginException {
      // Fallback HTTP tiada pending native.
    } on PlatformException {
      // Abaikan — agent sudah berhenti.
    } catch (_) {}
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    unawaited(cancelPending());
    _client.close();
    super.dispose();
  }
}
