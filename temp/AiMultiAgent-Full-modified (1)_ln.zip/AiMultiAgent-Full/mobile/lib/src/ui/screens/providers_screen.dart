import 'dart:convert';

import 'package:flutter/material.dart';

import '../../app.dart';
import '../../data/provider_catalog.dart';
import '../../models/app_models.dart';
import '../../services/provider_model_policy.dart';
import '../../theme/app_theme.dart';

class ProvidersScreen extends StatelessWidget {
  const ProvidersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Provider AI'),
          actions: <Widget>[
            IconButton.filledTonal(
              tooltip: 'Tambah provider',
              onPressed: () => _addProvider(context),
              icon: const Icon(Icons.add_rounded),
            ),
            const SizedBox(width: 10),
          ],
        ),
        body: state.providers.isEmpty
            ? _EmptyProviders(onAdd: () => _addProvider(context))
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
                itemCount: state.providers.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final provider = state.providers[index];
                  return _ProviderTile(
                    provider: provider,
                    selected: provider.id == state.selectedProviderId,
                    onSelect: () => state.selectProvider(provider.id),
                    onEdit: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => ProviderEditorScreen(
                          provider: provider,
                        ),
                      ),
                    ),
                    onDelete: () async {
                      final ok = await _confirmDelete(
                        context,
                        provider.name,
                      );
                      if (ok) await state.deleteProvider(provider);
                    },
                  );
                },
              ),
        floatingActionButton: state.providers.isEmpty
            ? null
            : FloatingActionButton.extended(
                onPressed: () => _addProvider(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Provider'),
              ),
      ),
    );
  }

  Future<void> _addProvider(BuildContext context) async {
    final preset = await showModalBottomSheet<ProviderPreset>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const _PresetPicker(),
    );
    if (preset == null || !context.mounted) return;
    final provider = AppScope.read(context).createProviderFromPreset(preset);
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ProviderEditorScreen(
          provider: provider,
          isNew: true,
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context, String name) async {
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            icon: const Icon(
              Icons.delete_outline_rounded,
              color: AppTheme.danger,
            ),
            title: const Text('Padam provider?'),
            content: Text(
              'Konfigurasi $name dan API key terenkripsinya akan dipadam daripada peranti.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Batal'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                style: FilledButton.styleFrom(
                  backgroundColor: AppTheme.danger,
                ),
                child: const Text('Padam'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

class _ProviderTile extends StatelessWidget {
  const _ProviderTile({
    required this.provider,
    required this.selected,
    required this.onSelect,
    required this.onEdit,
    required this.onDelete,
  });

  final ProviderConfig provider;
  final bool selected;
  final VoidCallback onSelect;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected
          ? AppTheme.purple.withValues(alpha: .09)
          : AppTheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(21),
        side: BorderSide(
          color: selected
              ? AppTheme.purple.withValues(alpha: .55)
              : const Color(0xFF202638),
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(21),
        onTap: onSelect,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 13, 8, 13),
          child: Row(
            children: <Widget>[
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF34265A), Color(0xFF171B29)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  _providerIcon(provider.presetId),
                  color: AppTheme.purpleLight,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            provider.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        if (selected)
                          const Padding(
                            padding: EdgeInsets.only(left: 6),
                            child: Icon(
                              Icons.check_circle_rounded,
                              size: 18,
                              color: AppTheme.success,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      provider.model.isEmpty
                          ? 'Model belum dipilih'
                          : provider.model,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: <Widget>[
                        _StatusPill(status: provider.testStatus),
                        if (provider.lastLatencyMs != null) ...<Widget>[
                          const SizedBox(width: 7),
                          Text(
                            '${provider.lastLatencyMs} ms',
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                tooltip: 'Pilihan',
                onSelected: (value) {
                  if (value == 'select') onSelect();
                  if (value == 'edit') onEdit();
                  if (value == 'delete') onDelete();
                },
                itemBuilder: (_) => const <PopupMenuEntry<String>>[
                  PopupMenuItem(
                    value: 'select',
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.check_rounded),
                      title: Text('Jadikan aktif'),
                    ),
                  ),
                  PopupMenuItem(
                    value: 'edit',
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.edit_outlined),
                      title: Text('Edit'),
                    ),
                  ),
                  PopupMenuDivider(),
                  PopupMenuItem(
                    value: 'delete',
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        Icons.delete_outline_rounded,
                        color: AppTheme.danger,
                      ),
                      title: Text('Padam'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyProviders extends StatelessWidget {
  const _EmptyProviders({required this.onAdd});

  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: const Icon(
                  Icons.key_rounded,
                  size: 36,
                  color: AppTheme.purpleLight,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Sambungkan model anda',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Tiada login dan tiada backend aplikasi. Masukkan API key, pilih model dan uji sambungan. Semua konfigurasi disimpan secara local.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: onAdd,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Tambah provider'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.status});

  final ProviderTestStatus status;

  @override
  Widget build(BuildContext context) {
    final (label, color, icon) = switch (status) {
      ProviderTestStatus.success => (
          'Berjaya',
          AppTheme.success,
          Icons.check_rounded,
        ),
      ProviderTestStatus.failed => (
          'Gagal',
          AppTheme.danger,
          Icons.close_rounded,
        ),
      ProviderTestStatus.testing => (
          'Menguji',
          AppTheme.warning,
          Icons.sync_rounded,
        ),
      ProviderTestStatus.untested => (
          'Belum diuji',
          AppTheme.textSecondary,
          Icons.circle_outlined,
        ),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetPicker extends StatefulWidget {
  const _PresetPicker();

  @override
  State<_PresetPicker> createState() => _PresetPickerState();
}

class _PresetPickerState extends State<_PresetPicker> {
  final _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final values = ProviderCatalog.presets.where((item) {
      final haystack = '${item.name} ${item.category} ${item.id}'.toLowerCase();
      return haystack.contains(_query.toLowerCase());
    }).toList();
    return FractionallySizedBox(
      heightFactor: .9,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'Pilih provider',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Provider biasa hanya memerlukan API key dan model. Gunakan Custom untuk Base URL atau format API sendiri.',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _search,
                  onChanged: (value) => setState(() => _query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'Cari OpenAI, Xiaomi MiMo, Ollama, Custom…',
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(12, 2, 12, 22),
              itemCount: values.length,
              separatorBuilder: (_, __) => const SizedBox(height: 4),
              itemBuilder: (context, index) {
                final item = values[index];
                return ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  tileColor: AppTheme.surfaceHigh,
                  leading: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: item.isCustom
                          ? AppTheme.cyan.withValues(alpha: .12)
                          : AppTheme.purple.withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Icon(
                      item.isCustom
                          ? Icons.tune_rounded
                          : _providerIcon(item.id),
                      color: item.isCustom
                          ? AppTheme.cyan
                          : AppTheme.purpleLight,
                    ),
                  ),
                  title: Text(
                    item.name,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    item.isCustom ? 'Custom · konfigurasi penuh' : item.category,
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.pop(context, item),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ProviderEditorScreen extends StatefulWidget {
  const ProviderEditorScreen({
    required this.provider,
    this.isNew = false,
    super.key,
  });

  final ProviderConfig provider;
  final bool isNew;

  @override
  State<ProviderEditorScreen> createState() =>
      _ProviderEditorScreenState();
}

class _ProviderEditorScreenState extends State<ProviderEditorScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _name;
  late final TextEditingController _apiKey;
  late final TextEditingController _model;
  late final TextEditingController _baseUrl;
  late final TextEditingController _chatPath;
  late final TextEditingController _modelsPath;
  late final TextEditingController _apiKeyHeader;
  late final TextEditingController _apiKeyPrefix;
  late final TextEditingController _headers;
  late final TextEditingController _customRequest;
  late final TextEditingController _customResponse;
  late final TextEditingController _speechModel;
  late final TextEditingController _imageModel;
  late final TextEditingController _videoModel;

  late ProviderProtocol _protocol;
  late AuthStyle _authStyle;
  late bool _supportsTools;
  late bool _supportsVision;
  late bool _supportsStreaming;
  late double _temperature;
  late int _maxTokens;
  late int _timeout;
  late List<String> _models;

  bool _hideKey = true;
  bool _busy = false;
  String _status = '';
  late ProviderTestStatus _displayStatus;

  bool get _isCustom => widget.provider.isCustom;
  bool get _needsKey => _authStyle != AuthStyle.none;

  @override
  void initState() {
    super.initState();
    final provider = widget.provider;
    _name = TextEditingController(text: provider.name);
    _apiKey = TextEditingController();
    _model = TextEditingController(text: provider.model);
    _baseUrl = TextEditingController(text: provider.baseUrl);
    _chatPath = TextEditingController(text: provider.chatPath);
    _modelsPath = TextEditingController(text: provider.modelsPath);
    _apiKeyHeader = TextEditingController(text: provider.apiKeyHeader);
    _apiKeyPrefix = TextEditingController(text: provider.apiKeyPrefix);
    _headers = TextEditingController(
      text: const JsonEncoder.withIndent('  ').convert(provider.extraHeaders),
    );
    _customRequest = TextEditingController(
      text: provider.customRequestTemplate,
    );
    _customResponse = TextEditingController(
      text: provider.customResponsePath,
    );
    _speechModel = TextEditingController(text: provider.speechModel);
    _imageModel = TextEditingController(text: provider.imageModel);
    _videoModel = TextEditingController(text: provider.videoModel);
    _protocol = provider.protocol;
    _authStyle = provider.authStyle;
    _supportsTools = provider.supportsTools;
    _supportsVision = provider.supportsVision;
    _supportsStreaming = provider.supportsStreaming;
    _temperature = provider.temperature;
    _maxTokens = provider.maxTokens;
    _timeout = provider.timeoutSeconds;
    _models = ProviderModelPolicy.chatModels(
      provider,
      provider.availableModels,
    );
    _displayStatus = provider.testStatus;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final state = AppScope.read(context);
      final key = await state.providerKey(provider.id);
      if (mounted) setState(() => _apiKey.text = key);
    });
  }

  @override
  void dispose() {
    for (final controller in <TextEditingController>[
      _name,
      _apiKey,
      _model,
      _baseUrl,
      _chatPath,
      _modelsPath,
      _apiKeyHeader,
      _apiKeyPrefix,
      _headers,
      _customRequest,
      _customResponse,
      _speechModel,
      _imageModel,
      _videoModel,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final providerName = widget.provider.name;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew ? 'Sambung $providerName' : providerName),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 34),
          children: <Widget>[
            _ProviderHero(
              provider: widget.provider,
              custom: _isCustom,
            ),
            const SizedBox(height: 18),
            if (_isCustom) ..._customFields() else ..._simpleFields(),
            if (_status.isNotEmpty) ...<Widget>[
              const SizedBox(height: 14),
              _StatusPanel(
                text: _status,
                status: _displayStatus,
              ),
            ],
            const SizedBox(height: 18),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : _testOnly,
                    icon: _busy
                        ? const SizedBox(
                            width: 17,
                            height: 17,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.network_check_rounded),
                    label: const Text('Uji'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _saveAndTest,
                    icon: const Icon(Icons.lock_rounded),
                    label: const Text('Uji & simpan local'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              'API key disimpan dalam secure storage Android. Ujian menggunakan permintaan kecil kepada model yang dipilih.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 11.5,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _simpleFields() => <Widget>[
        if (_needsKey) ...<Widget>[
          TextFormField(
            controller: _apiKey,
            obscureText: _hideKey,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              labelText: 'API key',
              prefixIcon: const Icon(Icons.key_rounded),
              suffixIcon: IconButton(
                tooltip: _hideKey ? 'Tunjuk' : 'Sembunyikan',
                onPressed: () => setState(() => _hideKey = !_hideKey),
                icon: Icon(
                  _hideKey
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
              ),
            ),
            validator: (value) {
              if (_needsKey && (value == null || value.trim().isEmpty)) {
                return 'Masukkan API key.';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
        ] else ...<Widget>[
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: AppTheme.success.withValues(alpha: .08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.success.withValues(alpha: .25),
              ),
            ),
            child: const Row(
              children: <Widget>[
                Icon(
                  Icons.lan_rounded,
                  color: AppTheme.success,
                  size: 20,
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Provider local ini tidak memerlukan API key.',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        _ModelField(
          controller: _model,
          models: _models,
          busy: _busy,
          onRefresh: _refreshModels,
          onSelected: (value) => setState(() => _model.text = value),
        ),
        ..._mediaModelFields(),
      ];

  List<Widget> _customFields() => <Widget>[
        const _SectionLabel(
          icon: Icons.tune_rounded,
          title: 'Konfigurasi custom',
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _name,
          decoration: const InputDecoration(labelText: 'Nama konfigurasi'),
          validator: _required,
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _baseUrl,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            labelText: 'Base URL',
            hintText: 'https://api.example.com/v1',
          ),
          validator: (value) {
            final uri = Uri.tryParse(value?.trim() ?? '');
            if (uri == null ||
                !<String>{'http', 'https'}.contains(uri.scheme) ||
                uri.host.isEmpty) {
              return 'Masukkan Base URL HTTP/HTTPS yang sah.';
            }
            return null;
          },
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<ProviderProtocol>(
          value: _protocol,
          decoration: const InputDecoration(labelText: 'Protokol API'),
          items: ProviderProtocol.values
              .map(
                (item) => DropdownMenuItem<ProviderProtocol>(
                  value: item,
                  child: Text(_protocolLabel(item)),
                ),
              )
              .toList(),
          onChanged: (value) => setState(() {
            if (value != null) _protocol = value;
          }),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _chatPath,
          decoration: const InputDecoration(
            labelText: 'Chat endpoint',
            hintText: '/chat/completions',
          ),
          validator: _required,
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _modelsPath,
          decoration: const InputDecoration(
            labelText: 'Models endpoint',
            hintText: '/models atau kosong',
          ),
        ),
        const SizedBox(height: 14),
        const _SectionLabel(
          icon: Icons.key_rounded,
          title: 'Autentikasi',
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<AuthStyle>(
          value: _authStyle,
          decoration: const InputDecoration(labelText: 'Kaedah autentikasi'),
          items: AuthStyle.values
              .map(
                (item) => DropdownMenuItem<AuthStyle>(
                  value: item,
                  child: Text(_authLabel(item)),
                ),
              )
              .toList(),
          onChanged: (value) => setState(() {
            if (value != null) _authStyle = value;
          }),
        ),
        if (_needsKey) ...<Widget>[
          const SizedBox(height: 10),
          TextFormField(
            controller: _apiKey,
            obscureText: _hideKey,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              labelText: 'API key',
              suffixIcon: IconButton(
                onPressed: () => setState(() => _hideKey = !_hideKey),
                icon: Icon(
                  _hideKey
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          LayoutBuilder(
            builder: (context, constraints) {
              final stacked = constraints.maxWidth < 430;
              final headerField = TextFormField(
                controller: _apiKeyHeader,
                decoration: const InputDecoration(
                  labelText: 'Header / query key',
                ),
              );
              final prefixField = TextFormField(
                controller: _apiKeyPrefix,
                decoration: const InputDecoration(
                  labelText: 'Prefix',
                  hintText: 'Bearer ',
                ),
              );
              if (stacked) {
                return Column(
                  children: <Widget>[
                    headerField,
                    const SizedBox(height: 8),
                    prefixField,
                  ],
                );
              }
              return Row(
                children: <Widget>[
                  Expanded(child: headerField),
                  const SizedBox(width: 8),
                  Expanded(child: prefixField),
                ],
              );
            },
          ),
        ],
        const SizedBox(height: 14),
        const _SectionLabel(
          icon: Icons.psychology_alt_outlined,
          title: 'Model',
        ),
        const SizedBox(height: 10),
        _ModelField(
          controller: _model,
          models: _models,
          busy: _busy,
          onRefresh: _refreshModels,
          onSelected: (value) => setState(() => _model.text = value),
        ),
        ..._mediaModelFields(),
        const SizedBox(height: 12),
        ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 4),
          childrenPadding: const EdgeInsets.only(bottom: 8),
          title: const Text(
            'Pilihan lanjutan',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          subtitle: const Text(
            'Headers, format REST dan parameter model',
            style: TextStyle(fontSize: 12),
          ),
          children: <Widget>[
            TextFormField(
              controller: _headers,
              minLines: 3,
              maxLines: 8,
              decoration: const InputDecoration(
                labelText: 'Custom headers (JSON)',
                alignLabelWithHint: true,
              ),
            ),
            if (_protocol == ProviderProtocol.customRest) ...<Widget>[
              const SizedBox(height: 10),
              TextFormField(
                controller: _customRequest,
                minLines: 5,
                maxLines: 12,
                decoration: const InputDecoration(
                  labelText: 'Request template JSON',
                  hintText:
                      '{"model": {{model}}, "messages": {{messages}}}',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _customResponse,
                decoration: const InputDecoration(
                  labelText: 'Response JSON path',
                  hintText: 'choices.0.message.content',
                ),
              ),
            ],
            const SizedBox(height: 12),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tool calling'),
              value: _supportsTools,
              onChanged: (value) => setState(() => _supportsTools = value),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Vision / imej'),
              value: _supportsVision,
              onChanged: (value) => setState(() => _supportsVision = value),
            ),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Streaming'),
              value: _supportsStreaming,
              onChanged: (value) =>
                  setState(() => _supportsStreaming = value),
            ),
            const SizedBox(height: 8),
            Text('Temperature · ${_temperature.toStringAsFixed(2)}'),
            Slider(
              value: _temperature.clamp(0, 2),
              max: 2,
              divisions: 40,
              onChanged: (value) =>
                  setState(() => _temperature = value),
            ),
            LayoutBuilder(
              builder: (context, constraints) {
                final stacked = constraints.maxWidth < 430;
                final tokenField = TextFormField(
                  initialValue: _maxTokens.toString(),
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Max tokens',
                  ),
                  onChanged: (value) {
                    _maxTokens = int.tryParse(value) ?? _maxTokens;
                  },
                );
                final timeoutField = TextFormField(
                  initialValue: _timeout.toString(),
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Timeout (saat)',
                  ),
                  onChanged: (value) {
                    _timeout = int.tryParse(value) ?? _timeout;
                  },
                );
                if (stacked) {
                  return Column(
                    children: <Widget>[
                      tokenField,
                      const SizedBox(height: 8),
                      timeoutField,
                    ],
                  );
                }
                return Row(
                  children: <Widget>[
                    Expanded(child: tokenField),
                    const SizedBox(width: 8),
                    Expanded(child: timeoutField),
                  ],
                );
              },
            ),
          ],
        ),
      ];

  Future<void> _refreshModels() async {
    if (_busy) return;
    final draft = _tryBuildProvider();
    if (draft == null) return;
    final key = _apiKey.text.trim();
    if (draft.authStyle != AuthStyle.none && key.isEmpty) {
      setState(() => _status = 'Masukkan API key untuk mendapatkan model.');
      return;
    }
    setState(() {
      _busy = true;
      _status = 'Mendapatkan senarai model…';
      _displayStatus = ProviderTestStatus.testing;
    });
    try {
      final values = await AppScope.read(context).refreshModels(draft, key);
      if (!mounted) return;
      setState(() {
        _models = values;
        _displayStatus = ProviderTestStatus.success;
        _status = values.isEmpty
            ? 'Provider tidak memulangkan senarai model. Model ID manual masih boleh digunakan.'
            : '${values.length} model tersedia.';
      });
    } catch (error) {
      if (mounted) {
        setState(() {
          _displayStatus = ProviderTestStatus.failed;
          _status = error.toString();
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _testOnly() async {
    if (!_validate()) return;
    final draft = _tryBuildProvider();
    if (draft == null) return;
    setState(() {
      _busy = true;
      _status = 'Menguji sambungan…';
      _displayStatus = ProviderTestStatus.testing;
    });
    try {
      final result = await AppScope.read(context).testProvider(
        draft,
        _apiKey.text.trim(),
      );
      if (!mounted) return;
      setState(() {
        _displayStatus = result.success
            ? ProviderTestStatus.success
            : ProviderTestStatus.failed;
        _status = result.success
            ? 'Berjaya · ${result.latencyMs} ms\n${result.message}'
            : 'Gagal · ${result.message}';
        if (result.models.isNotEmpty) {
          _models = ProviderModelPolicy.chatModels(draft, result.models);
          if (!_models.contains(_model.text.trim()) && _models.isNotEmpty) {
            _model.text = _models.first;
          }
        }
      });
    } catch (error) {
      if (mounted) {
        setState(() {
          _displayStatus = ProviderTestStatus.failed;
          _status = error.toString();
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveAndTest() async {
    if (!_validate()) return;
    final draft = _tryBuildProvider();
    if (draft == null) return;
    setState(() {
      _busy = true;
      _status = 'Menguji sebelum menyimpan…';
      _displayStatus = ProviderTestStatus.testing;
    });
    final state = AppScope.read(context);
    final key = _apiKey.text.trim();
    try {
      final result = await state.testProvider(draft, key);
      if (!mounted) return;

      var shouldSave = result.success;
      if (!result.success) {
        final unavailableModel =
            state.providerService.isModelUnavailableError(result.message) ||
                (result.models.isNotEmpty &&
                    !result.models.any(
                      (item) =>
                          item.toLowerCase() == draft.model.toLowerCase(),
                    ));
        if (unavailableModel) {
          final liveModels = ProviderModelPolicy.chatModels(
            draft,
            result.models,
          );
          if (liveModels.isNotEmpty) {
            setState(() {
              _models = liveModels;
              _model.text = liveModels.first;
              _displayStatus = ProviderTestStatus.failed;
              _status = '${result.message}\nModel diselaraskan kepada '
                  '${liveModels.first}. Tekan Uji & simpan sekali lagi.';
            });
          } else {
            setState(() {
              _displayStatus = ProviderTestStatus.failed;
              _status = result.message;
            });
          }
          return;
        }

        shouldSave = await showDialog<bool>(
              context: context,
              builder: (dialogContext) => AlertDialog(
                icon: const Icon(
                  Icons.wifi_off_rounded,
                  color: AppTheme.warning,
                ),
                title: const Text('Ujian sambungan gagal'),
                content: Text(
                  '${result.message}\n\nSimpan juga? Gunakan pilihan ini '
                  'hanya untuk server local yang sedang offline.',
                ),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.pop(dialogContext, false),
                    child: const Text('Semak semula'),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.pop(dialogContext, true),
                    child: const Text('Simpan juga'),
                  ),
                ],
              ),
            ) ??
            false;
      }

      if (!shouldSave || !mounted) {
        setState(() {
          _displayStatus = ProviderTestStatus.failed;
          _status = result.message;
        });
        return;
      }

      final mergedModels = ProviderModelPolicy.chatModels(
        draft,
        result.models.isNotEmpty
            ? result.models
            : <String>{
                ...draft.availableModels,
                if (draft.model.isNotEmpty) draft.model,
              },
      );
      final tested = draft.copyWith(
        availableModels: mergedModels,
        testStatus: result.success
            ? ProviderTestStatus.success
            : ProviderTestStatus.failed,
        lastTestMessage: result.message,
        lastLatencyMs: result.latencyMs,
      );
      await state.saveProvider(tested, apiKey: key);
      await state.selectProvider(tested.id);
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (mounted) {
        setState(() {
          _displayStatus = ProviderTestStatus.failed;
          _status = error.toString();
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  bool _validate() {
    if (!(_formKey.currentState?.validate() ?? false)) return false;
    if (_model.text.trim().isEmpty) {
      setState(() => _status = 'Masukkan atau pilih Model ID.');
      return false;
    }
    if (_isCustom) {
      final base = Uri.tryParse(_baseUrl.text.trim());
      if (base == null ||
          !base.hasScheme ||
          !<String>{'http', 'https'}.contains(base.scheme.toLowerCase())) {
        setState(() => _status = 'Base URL mesti bermula dengan http:// atau https://.');
        return false;
      }
    }
    return true;
  }

  ProviderConfig? _tryBuildProvider() {
    try {
      return _buildProvider();
    } on FormatException catch (error) {
      setState(() {
        _displayStatus = ProviderTestStatus.failed;
        _status = error.message;
      });
      return null;
    } catch (error) {
      setState(() {
        _displayStatus = ProviderTestStatus.failed;
        _status = 'Konfigurasi tidak sah: $error';
      });
      return null;
    }
  }

  ProviderConfig _buildProvider() {
    Map<String, String> headers = widget.provider.extraHeaders;
    if (_isCustom) {
      final raw = _headers.text.trim();
      if (raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is! Map) {
          throw const FormatException('Custom headers mesti objek JSON.');
        }
        headers = decoded.map(
          (key, value) => MapEntry(key.toString(), value.toString()),
        );
      } else {
        headers = <String, String>{};
      }
    }
    final built = widget.provider.copyWith(
      name: _isCustom ? _name.text.trim() : widget.provider.name,
      protocol: _isCustom ? _protocol : widget.provider.protocol,
      baseUrl: _isCustom ? _baseUrl.text.trim() : widget.provider.baseUrl,
      chatPath: _isCustom ? _chatPath.text.trim() : widget.provider.chatPath,
      modelsPath:
          _isCustom ? _modelsPath.text.trim() : widget.provider.modelsPath,
      authStyle: _isCustom ? _authStyle : widget.provider.authStyle,
      apiKeyHeader:
          _isCustom ? _apiKeyHeader.text.trim() : widget.provider.apiKeyHeader,
      apiKeyPrefix: _isCustom
          ? _apiKeyPrefix.text
          : widget.provider.apiKeyPrefix,
      model: _model.text.trim(),
      availableModels: <String>{
        ..._models,
        if (_model.text.trim().isNotEmpty) _model.text.trim(),
      }.toList()
        ..sort(),
      extraHeaders: headers,
      temperature: _temperature,
      maxTokens: _maxTokens,
      timeoutSeconds: _timeout.clamp(30, 900).toInt(),
      supportsTools: _supportsTools,
      supportsVision: _supportsVision,
      supportsStreaming: _supportsStreaming,
      customRequestTemplate: _isCustom ? _customRequest.text : '',
      customResponsePath: _isCustom
          ? _customResponse.text.trim()
          : widget.provider.customResponsePath,
      speechModel: _speechModel.text.trim(),
      imageModel: _imageModel.text.trim(),
      videoModel: _videoModel.text.trim(),
      updatedAt: DateTime.now(),
    );
    return built.copyWith(
      availableModels: ProviderModelPolicy.chatModels(
        built,
        built.availableModels,
      ),
    );
  }

  List<Widget> _mediaModelFields() => <Widget>[
        const SizedBox(height: 16),
        const _SectionLabel(
          icon: Icons.auto_awesome_outlined,
          title: 'Model janaan (pilihan)',
        ),
        const SizedBox(height: 6),
        const Text(
          'Kosong = AI tak ada tool itu. Isi nama model bila provider ada jana suara / gambar / video.',
          style: TextStyle(fontSize: 12.5, height: 1.35),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _speechModel,
          decoration: const InputDecoration(
            labelText: 'Model suara',
            hintText: 'contoh mimo-v2.5-tts',
          ),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _imageModel,
          decoration: const InputDecoration(
            labelText: 'Model gambar',
            hintText: 'contoh gpt-image-1',
          ),
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _videoModel,
          decoration: const InputDecoration(
            labelText: 'Model video',
            hintText: 'contoh sora-2',
          ),
        ),
      ];

  String? _required(String? value) =>
      value == null || value.trim().isEmpty ? 'Medan ini diperlukan.' : null;
}

class _ProviderHero extends StatelessWidget {
  const _ProviderHero({
    required this.provider,
    required this.custom,
  });

  final ProviderConfig provider;
  final bool custom;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFF1A142B), Color(0xFF10141F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF2B2343)),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: AppTheme.purple.withValues(alpha: .13),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              custom ? Icons.tune_rounded : _providerIcon(provider.presetId),
              color: AppTheme.purpleLight,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  provider.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  custom
                      ? 'Base URL, protokol dan format boleh disesuaikan.'
                      : provider.authStyle == AuthStyle.none
                          ? 'Pilih model untuk server local.'
                          : 'Masukkan API key dan pilih model sahaja.',
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ModelField extends StatelessWidget {
  const _ModelField({
    required this.controller,
    required this.models,
    required this.busy,
    required this.onRefresh,
    required this.onSelected,
  });

  final TextEditingController controller;
  final List<String> models;
  final bool busy;
  final VoidCallback onRefresh;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: TextFormField(
                controller: controller,
                decoration: const InputDecoration(
                  labelText: 'Model ID',
                  prefixIcon: Icon(Icons.psychology_alt_outlined),
                  hintText: 'Pilih atau masukkan secara manual',
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Pilih atau masukkan model.'
                    : null,
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filledTonal(
              tooltip: 'Dapatkan model daripada provider',
              onPressed: busy ? null : onRefresh,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        if (models.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          SizedBox(
            height: 42,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: models.length,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (context, index) {
                final model = models[index];
                final selected = controller.text == model;
                return ChoiceChip(
                  selected: selected,
                  label: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 230),
                    child: Text(
                      model,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  onSelected: (_) => onSelected(model),
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.icon, required this.title});

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Icon(icon, size: 18, color: AppTheme.purpleLight),
        const SizedBox(width: 7),
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w900,
            color: AppTheme.purpleLight,
          ),
        ),
      ],
    );
  }
}

class _StatusPanel extends StatelessWidget {
  const _StatusPanel({required this.text, required this.status});

  final String text;
  final ProviderTestStatus status;

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      ProviderTestStatus.success => AppTheme.success,
      ProviderTestStatus.failed => AppTheme.danger,
      ProviderTestStatus.testing => AppTheme.warning,
      ProviderTestStatus.untested => AppTheme.cyan,
    };
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: .24)),
      ),
      child: Text(
        text,
        style: TextStyle(color: color, height: 1.4),
      ),
    );
  }
}

IconData _providerIcon(String id) {
  if (id.contains('gemini') || id.contains('vertex')) {
    return Icons.auto_awesome_rounded;
  }
  if (id.contains('anthropic')) return Icons.blur_on_rounded;
  if (id.contains('ollama') ||
      id.contains('lmstudio') ||
      id.contains('local')) {
    return Icons.lan_rounded;
  }
  if (id.contains('mimo')) return Icons.motion_photos_on_rounded;
  if (id.contains('openrouter') || id.contains('gateway')) {
    return Icons.hub_rounded;
  }
  return Icons.psychology_alt_rounded;
}

String _protocolLabel(ProviderProtocol value) => switch (value) {
      ProviderProtocol.openAiChat => 'OpenAI Chat Completions',
      ProviderProtocol.openAiResponses => 'OpenAI Responses',
      ProviderProtocol.anthropic => 'Anthropic Messages',
      ProviderProtocol.gemini => 'Google Gemini',
      ProviderProtocol.customRest => 'Custom REST JSON',
    };

String _authLabel(AuthStyle value) => switch (value) {
      AuthStyle.bearer => 'Bearer header',
      AuthStyle.apiKeyHeader => 'API key header',
      AuthStyle.xApiKey => 'x-api-key header',
      AuthStyle.queryParameter => 'Query parameter',
      AuthStyle.none => 'Tiada autentikasi',
    };
