package com.aiinpaint.app

import android.graphics.Bitmap
import android.util.Log
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

object GitHubHelper {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private const val TAG = "GitHubHelper"

    // Upload ke litterbox (24h), fallback ke 0x0.st
    fun uploadImage(file: File): String? {
        // Try litterbox first
        try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("reqtype", "fileupload")
                .addFormDataPart("time", "24h")
                .addFormDataPart("fileToUpload", file.name, file.asRequestBody("image/png".toMediaType()))
                .build()

            val request = Request.Builder()
                .url("https://litterbox.catbox.moe/resources/internals/api.php")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val url = response.body?.string()?.trim()
                    if (!url.isNullOrBlank() && url.startsWith("http")) {
                        Log.d(TAG, "Uploaded to litterbox: $url")
                        return url
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Litterbox failed", e)
        }

        // Fallback 0x0.st
        try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("image/png".toMediaType()))
                .build()

            val request = Request.Builder()
                .url("https://0x0.st")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val url = response.body?.string()?.trim()
                    if (!url.isNullOrBlank() && url.startsWith("http")) {
                        Log.d(TAG, "Uploaded to 0x0.st: $url")
                        return url
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "0x0.st failed", e)
        }

        return null
    }

    fun triggerWorkflow(imageUrl: String, maskUrl: String): Boolean {
        val json = JSONObject().apply {
            put("event_type", "inpaint")
            put("client_payload", JSONObject().apply {
                put("image_url", imageUrl)
                put("mask_url", maskUrl)
            })
        }

        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://api.github.com/repos/${AppConfig.GITHUB_REPO}/dispatches")
            .addHeader("Authorization", "token ${AppConfig.GITHUB_TOKEN}")
            .addHeader("Accept", "application/vnd.github+json")
            .addHeader("X-GitHub-Api-Version", "2022-11-28")
            .post(body)
            .build()

        return try {
            client.newCall(request).execute().use { it.code == 204 }
        } catch (e: Exception) {
            Log.e(TAG, "Trigger failed", e)
            false
        }
    }

    fun getLatestRunId(): Long? {
        val request = Request.Builder()
            .url("https://api.github.com/repos/${AppConfig.GITHUB_REPO}/actions/runs?per_page=5")
            .addHeader("Authorization", "token ${AppConfig.GITHUB_TOKEN}")
            .addHeader("Accept", "application/vnd.github+json")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val json = JSONObject(response.body?.string() ?: return null)
                val runs = json.getJSONArray("workflow_runs")
                for (i in 0 until runs.length()) {
                    val run = runs.getJSONObject(i)
                    if (run.getString("name").contains("inpaint", ignoreCase = true)) {
                        return run.getLong("id")
                    }
                }
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "getLatestRunId failed", e)
            null
        }
    }

    fun waitForCompletion(runId: Long, timeoutMinutes: Int = 50, onProgress: (String) -> Unit): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMinutes * 60 * 1000L) {
            val request = Request.Builder()
                .url("https://api.github.com/repos/${AppConfig.GITHUB_REPO}/actions/runs/$runId")
                .addHeader("Authorization", "token ${AppConfig.GITHUB_TOKEN}")
                .addHeader("Accept", "application/vnd.github+json")
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return false
                    val json = JSONObject(response.body?.string() ?: return false)
                    val status = json.getString("status")
                    val conclusion = json.optString("conclusion", "")
                    onProgress("Status: $status ${if (conclusion.isNotEmpty()) "($conclusion)" else ""}")

                    if (status == "completed") {
                        return conclusion == "success"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Polling error", e)
            }
            Thread.sleep(15000)
        }
        return false
    }

    fun downloadArtifact(runId: Long, saveDir: File): File? {
        // Get artifacts
        val listReq = Request.Builder()
            .url("https://api.github.com/repos/${AppConfig.GITHUB_REPO}/actions/runs/$runId/artifacts")
            .addHeader("Authorization", "token ${AppConfig.GITHUB_TOKEN}")
            .addHeader("Accept", "application/vnd.github+json")
            .build()

        try {
            client.newCall(listReq).execute().use { response ->
                if (!response.isSuccessful) return null
                val json = JSONObject(response.body?.string() ?: return null)
                val artifacts = json.getJSONArray("artifacts")
                if (artifacts.length() == 0) return null

                val artifact = artifacts.getJSONObject(0)
                val downloadUrl = artifact.getString("archive_download_url")

                val dlReq = Request.Builder()
                    .url(downloadUrl)
                    .addHeader("Authorization", "token ${AppConfig.GITHUB_TOKEN}")
                    .addHeader("Accept", "application/vnd.github+json")
                    .build()

                client.newCall(dlReq).execute().use { dlResponse ->
                    if (!dlResponse.isSuccessful) return null
                    saveDir.mkdirs()
                    val zipFile = File(saveDir, "result.zip")
                    FileOutputStream(zipFile).use { fos ->
                        dlResponse.body?.byteStream()?.copyTo(fos)
                    }
                    return zipFile
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Download artifact failed", e)
            return null
        }
    }

    fun saveBitmapToFile(bitmap: Bitmap, file: File): Boolean {
        return try {
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
