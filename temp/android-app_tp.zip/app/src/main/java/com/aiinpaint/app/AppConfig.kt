package com.aiinpaint.app

/**
 * ===== CONFIG YANG PERLU DIISI =====
 * Hanya dua nilai ni sahaja yang wajib.
 */
object AppConfig {
    const val GITHUB_TOKEN = "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"
    const val GITHUB_REPO = "earltiktokofficial04-jpg/AI-REMOVAL"   // contoh: ali/ai-inpaint
}
