import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'partner_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'anime_home.dart';
import 'spotify_page.dart';
import 'ai_page.dart';
import 'comic_page.dart';
import 'al_quran.dart';
import 'sholat_tools_page.dart';
import 'hijri_doa_page.dart';
import 'tiktok_booster.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ===== QUICK ACTIONS DOT INDICATOR =====
  int _quickActionsPage = 0;
  late PageController _quickActionsController;

  // ===== WEATHER =====
  String _weatherTemp = '--';
  String _weatherCity = 'Memuat...';
  String _weatherDesc = '';
  String _weatherHumidity = '--';
  String _weatherWind = '--';
  bool _weatherLoading = true;
  IconData _weatherIcon = Icons.wb_sunny_rounded;

  // ===== COLOR PALETTE (UPDATED TO SILVER/BLACK) =====
  final Color bgDark        = const Color(0xFF000000); // Hitam Pekat
  final Color primarySilver = const Color(0xFF424242); // Silver Utama (Pengganti Purple)
  final Color accentSilver  = const Color(0xFFE0E0E0); // Silver Terang (Pengganti Accent Purple)
  final Color lightSilver   = const Color(0xFFBDBDBD); // Silver Muda
  final Color primaryWhite  = Colors.white;
  final Color accentGrey    = const Color(0xFF9E9E9E);
  final Color cardGlass     = const Color(0x1AFFFFFF); // Sedikit lebih pekat agar terlihat di background hitam
  final Color borderGlass   = const Color(0x26FFFFFF);

  // Quick Actions list - 10 items
  late List<Map<String, dynamic>> _quickActionItems;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _quickActionsController = PageController(viewportFraction: 0.88);
    _quickActionsController.addListener(() {
      final page = _quickActionsController.page?.round() ?? 0;
      if (page != _quickActionsPage) {
        setState(() => _quickActionsPage = page);
      }
    });

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _fetchWeather();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('wss://ws-dark.darkverse.my.id'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers        = data['onlineUsers'] ?? 0;
          activeConnections  = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  // ===== WEATHER FETCH (GPS REAL) =====
  Future<void> _fetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) setState(() {
          _weatherTemp = '--';
          _weatherCity = 'GPS Mati';
          _weatherDesc = 'Aktifkan lokasi di pengaturan';
          _weatherLoading = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) setState(() {
            _weatherTemp = '--';
            _weatherCity = 'Izin Ditolak';
            _weatherDesc = 'Izinkan akses lokasi';
            _weatherLoading = false;
          });
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        if (mounted) setState(() {
          _weatherTemp = '--';
          _weatherCity = 'Izin Diblokir';
          _weatherDesc = 'Buka Settings > Izin Lokasi';
          _weatherLoading = false;
        });
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      ).timeout(const Duration(seconds: 15));

      final lat = position.latitude;
      final lon = position.longitude;

      final response = await http.get(
        Uri.parse('https://wttr.in/$lat,$lon?format=j1'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final current = data['current_condition'][0];
        final nearest = data['nearest_area'][0];
        final cityName = nearest['areaName'][0]['value'] ?? 'Lokasimu';
        final tempC = current['temp_C'] ?? '--';
        final humidity = current['humidity'] ?? '--';
        final windKmph = current['windspeedKmph'] ?? '--';
        final desc = current['weatherDesc'][0]['value'] ?? '';
        final weatherCode = int.tryParse(current['weatherCode'].toString()) ?? 113;

        IconData icon;
        if (weatherCode == 113) {
          icon = Icons.wb_sunny_rounded;
        } else if (weatherCode <= 119) {
          icon = Icons.wb_cloudy_rounded;
        } else if (weatherCode <= 176) {
          icon = Icons.cloud_rounded;
        } else if (weatherCode <= 263) {
          icon = Icons.grain_rounded;
        } else if (weatherCode <= 389) {
          icon = Icons.thunderstorm_rounded;
        } else {
          icon = Icons.ac_unit_rounded;
        }

        if (mounted) {
          setState(() {
            _weatherTemp = '$tempC°C';
            _weatherCity = cityName;
            _weatherDesc = desc;
            _weatherHumidity = '$humidity%';
            _weatherWind = '$windKmph km/h';
            _weatherIcon = icon;
            _weatherLoading = false;
          });
        }
      } else {
        throw Exception('HTTP ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _weatherTemp = '--';
          _weatherCity = 'Gagal memuat';
          _weatherDesc = 'Cek koneksi internet';
          _weatherLoading = false;
        });
      }
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username, password: password,
            listBug: listBug, role: role,
            expiredDate: expiredDate, sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = InfoPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = ToolsPage(
              sessionKey: sessionKey, userRole: role, listDoos: listDoos);
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  // ════════════════════════════════════════════════════════
  //  BUILD NEWS PAGE
  // ════════════════════════════════════════════════════════
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── HEADER CARD ──────────────────────────────────
          _sectionPad(
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: _glassBox(
                radius: 24,
                shadow: BoxShadow(
                  color: primarySilver.withOpacity(0.25), // Silver Shadow
                  blurRadius: 24, offset: const Offset(0, 10),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [primarySilver, accentSilver], // Silver Gradient
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [BoxShadow(color: accentSilver.withOpacity(0.4), blurRadius: 12)],
                        ),
                        child: _profileImage != null
                            ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                            : Icon(Icons.person_rounded, color: Colors.black, size: 28), // Icon Hitam agar kontras
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Hai, $username 👋",
                              style: TextStyle(
                                color: primaryWhite, fontSize: 17,
                                fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                              )),
                            const SizedBox(height: 5),
                            Row(children: [
                              _roleBadge(role.toUpperCase()),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text("· Exp: $expiredDate",
                                  style: TextStyle(color: accentGrey, fontSize: 11),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ]),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _buildStatChip(Icons.group_rounded, "$onlineUsers", "Online"),
                      const SizedBox(width: 24),
                      _buildStatChip(Icons.wifi_rounded, "$activeConnections", "Koneksi"),
                      const Spacer(),
                      _onlineBadge(),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ── BERITA TERBARU SECTION (style like image 2) ─────
          _sectionPad(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 4, height: 18,
                          decoration: BoxDecoration(
                            color: accentSilver, // Silver Indicator
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "Berita Terbaru",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                    Text(
                      "${newsList.length} artikel",
                      style: TextStyle(
                        color: accentSilver, // Silver Text
                        fontSize: 12,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (newsList.isNotEmpty)
                  SizedBox(
                    height: 200,
                    child: PageView.builder(
                      controller: PageController(viewportFraction: 0.88),
                      itemCount: newsList.length,
                      itemBuilder: (ctx, i) {
                        final item = newsList[i];
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: const Color(0xFF1A1A1A), // Abu Gelap
                            border: Border.all(color: accentSilver.withOpacity(0.3)),
                            boxShadow: [BoxShadow(
                              color: primarySilver.withOpacity(0.3), // Silver Shadow
                              blurRadius: 14, offset: const Offset(0, 6),
                            )],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(fit: StackFit.expand, children: [
                              // Background media
                              if (item['image'] != null && item['image'].toString().isNotEmpty)
                                NewsMedia(url: item['image']),
                              // Gradient overlay
                              Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.black.withOpacity(0.85),
                                      primarySilver.withOpacity(0.2), // Silver overlay
                                      Colors.transparent,
                                    ],
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                  ),
                                ),
                              ),
                              // NEWS badge top-left
                              Positioned(
                                top: 12, left: 12,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: accentSilver, // Badge Silver
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    "NEWS",
                                    style: TextStyle(
                                      color: Colors.black, // Teks Hitam agar kontras
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ),
                              // Title & desc bottom
                              Positioned(
                                bottom: 14, left: 14, right: 14,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item['title'] ?? '',
                                      style: TextStyle(
                                        color: primaryWhite, fontSize: 14,
                                        fontFamily: 'Orbitron', fontWeight: FontWeight.bold,
                                        shadows: [Shadow(color: primarySilver.withOpacity(0.8), blurRadius: 8)],
                                      )),
                                    const SizedBox(height: 3),
                                    Text(item['desc'] ?? '',
                                      style: TextStyle(color: accentSilver, fontSize: 11),
                                      maxLines: 1, overflow: TextOverflow.ellipsis),
                                  ],
                                ),
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── JOIN CHANNEL + MANAGE SENDER ─────────────────
          _sectionPad(
            child: Row(
              children: [
                Expanded(child: _actionBannerCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Join Channel",
                  sub: "HOXTEN Project",
                  color: Colors.blue,
                  onTap: () => _openUrl("https://t.me/ProjectHoxten"),
                )),
                const SizedBox(width: 10),
                Expanded(child: _actionBannerCard(
                  icon: Icons.sensors,
                  label: "Manage Sender",
                  sub: "Kelola sender aktif",
                  color: Colors.redAccent,
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => BugSenderPage(
                      sessionKey: sessionKey, username: username, role: role),
                  )),
                )),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── WEATHER CARD ─────────────────────────────────
          _sectionPad(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF1A237E).withOpacity(0.4), // Biru Gelap (Agar cuaca tetap identitas birunya, tapi lebih tipis)
                    const Color(0xFF0D47A1).withOpacity(0.2),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.blue.withOpacity(0.3)),
                boxShadow: [BoxShadow(
                  color: Colors.blue.withOpacity(0.2),
                  blurRadius: 16, offset: const Offset(0, 8),
                )],
              ),
              child: _weatherLoading
                  ? Row(
                      children: [
                        const SizedBox(width: 8),
                        SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.blue.shade200),
                        ),
                        const SizedBox(width: 12),
                        Text('Memuat cuaca...',
                          style: TextStyle(color: Colors.white60, fontSize: 13)),
                      ],
                    )
                  : Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(_weatherIcon,
                            color: Colors.amber, size: 36),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.wb_sunny_rounded,
                                    color: Colors.blue.shade200, size: 14),
                                  const SizedBox(width: 6),
                                  Text('WEATHER',
                                    style: TextStyle(
                                      color: Colors.blue.shade200,
                                      fontSize: 11, fontFamily: 'Orbitron',
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.2,
                                    )),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(_weatherTemp,
                                style: const TextStyle(
                                  color: Colors.white, fontSize: 28,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                )),
                              Text(_weatherCity,
                                style: TextStyle(
                                  color: Colors.white70, fontSize: 13,
                                  fontWeight: FontWeight.w600)),
                              Text(_weatherDesc,
                                style: TextStyle(
                                  color: Colors.white38, fontSize: 11)),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.water_drop_rounded,
                                  color: Colors.lightBlue, size: 14),
                                const SizedBox(width: 4),
                                Text(_weatherHumidity,
                                  style: const TextStyle(
                                    color: Colors.white70, fontSize: 12)),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.air_rounded,
                                  color: Colors.lightBlue, size: 14),
                                const SizedBox(width: 4),
                                Text(_weatherWind,
                                  style: const TextStyle(
                                    color: Colors.white70, fontSize: 12)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            GestureDetector(
                              onTap: () {
                                setState(() => _weatherLoading = true);
                                _fetchWeather();
                              },
                              child: Icon(Icons.refresh_rounded,
                                color: Colors.blue.shade200, size: 18),
                            ),
                          ],
                        ),
                      ],
                    ),
            ),
          ),

          const SizedBox(height: 16),

          // ── QUICK ACTIONS CAROUSEL with DOT INDICATOR ──────
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _sectionHeader(Icons.bolt_rounded, "Quick Actions"),
                    Text(
                      "Geser untuk melihat menu",
                      style: TextStyle(
                        color: accentGrey, fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: PageView(
                  controller: _quickActionsController,
                  physics: const BouncingScrollPhysics(),
                  clipBehavior: Clip.none,
                  onPageChanged: (page) {
                    setState(() => _quickActionsPage = page);
                  },
                  children: [
                    _quickActionCard(
                      icon: Icons.chat_bubble_outline_rounded,
                      label: "Chat AI",
                      sub: "Tanya Apa Saja",
                      gradient: [const Color(0xFF1A237E), const Color(0xFF3B5BDB)],
                      iconBg: const Color(0xFF3B5BDB),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => AIPage(username: username, sessionKey: sessionKey))),
                    ),
                    _quickActionCard(
                      icon: Icons.menu_book_outlined,
                      label: "Comic",
                      sub: "Baca Komik Gratis",
                      gradient: [const Color(0xFF7B0000), const Color(0xFFCC2200)],
                      iconBg: const Color(0xFFCC2200),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const ComicPage())),
                    ),
                    _quickActionCard(
                      icon: FontAwesomeIcons.tiktok,
                      label: "TikTok Booster",
                      sub: "Boost Akun TikTok",
                      gradient: [const Color(0xFF010101), const Color(0xFF2C2C2C)],
                      iconBg: const Color(0xFF444444),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => TikTokBooster(sessionKey: sessionKey, role: role))),
                    ),
                    _quickActionCard(
                      icon: Icons.play_circle_outline_rounded,
                      label: "Anime",
                      sub: "Nonton Anime Sub ID",
                      gradient: [const Color(0xFF7B0000), const Color(0xFFCC0000)],
                      iconBg: const Color(0xFFCC0000),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const HomeAnimePage())),
                    ),
                    _quickActionCard(
                      icon: Icons.music_note_rounded,
                      label: "Spotify",
                      sub: "Putar Musik Favoritmu",
                      gradient: [const Color(0xFF0A3D1F), const Color(0xFF1DB954)],
                      iconBg: const Color(0xFF1DB954),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const SpotifyPage())),
                    ),
                    _quickActionCard(
                      icon: Icons.menu_book_rounded,
                      label: "Al-Qur'an",
                      sub: "Baca Al-Qur'an Digital",
                      gradient: [const Color(0xFF311B92), const Color(0xFF7E57C2)],
                      iconBg: const Color(0xFF7E57C2),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const AlQuranPage())),
                    ),
                    _quickActionCard(
                      icon: Icons.auto_stories_rounded,
                      label: "Doa Harian",
                      sub: "Kumpulan Doa Islam",
                      gradient: [const Color(0xFF4A148C), const Color(0xFF8E6FD8)],
                      iconBg: const Color(0xFF8E6FD8),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const HijriDoaPage())),
                    ),
                    _quickActionCard(
                      icon: Icons.calendar_month_rounded,
                      label: "Kalender Hijriah",
                      sub: "Tanggal Islam Hari Ini",
                      gradient: [const Color(0xFF1B5E20), const Color(0xFF2E7D32)],
                      iconBg: const Color(0xFF43A047),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const HijriDoaPage())),
                    ),
                    _quickActionCard(
                      icon: Icons.mosque_rounded,
                      label: "Jadwal Sholat",
                      sub: "Waktu Sholat Hari Ini",
                      gradient: [const Color(0xFF004D40), const Color(0xFF00796B)],
                      iconBg: const Color(0xFF00897B),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const SholatToolsPage())),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // ── DOT INDICATOR ──────────────────────────────
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(9, (index) {
                    final isActive = index == _quickActionsPage;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeInOut,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: isActive ? 20 : 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: isActive ? accentSilver : accentSilver.withOpacity(0.3), // Silver Dots
                        borderRadius: BorderRadius.circular(4),
                      ),
                    );
                  }),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // ── INFO & PENGUMUMAN ─────────────────────────────
          _sectionPad(
            child: GestureDetector(
              onTap: _showInfoDialog,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.blue.shade900.withOpacity(0.5),
                      Colors.cyan.shade900.withOpacity(0.3),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.cyan.withOpacity(0.5)),
                  boxShadow: [BoxShadow(
                    color: Colors.blue.withOpacity(0.3),
                    blurRadius: 15, offset: const Offset(0, 6),
                  )],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.cyan.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.info_outline, color: Colors.cyan, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Info & Pengumuman",
                            style: TextStyle(
                              color: Colors.white, fontSize: 14,
                              fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                            )),
                          const SizedBox(height: 2),
                          Text("Klik untuk melihat info terbaru",
                            style: TextStyle(color: Colors.white60, fontSize: 11)),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, color: Colors.cyan, size: 15),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ── DIVIDER ───────────────────────────────────────
          Center(
            child: Container(
              width: 60, height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, accentSilver, Colors.transparent], // Silver Gradient Divider
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ── HUBUNGI KAMI ──────────────────────────────────
          _sectionPad(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(Icons.headset_mic_outlined, "HUBUNGI KAMI"),
                const SizedBox(height: 14),
                _buildContactCard(
                  icon: FontAwesomeIcons.whatsapp,
                  label: "WhatsApp Developer",
                  subtitle: "Chat langsung dengan developer",
                  color: const Color(0xFF25D366),
                  url: "https://wa.me/6289636594032",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Telegram Developer",
                  subtitle: "Fast response via Telegram",
                  color: const Color(0xFF0088cc),
                  url: "https://t.me/hafz_reals",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: Icons.telegram,
                  label: "Channel Information",
                  subtitle: "Update terbaru & pengumuman",
                  color: const Color(0xFF00BCD4),
                  url: "https://t.me/https://ProjectHoxten",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.tiktok,
                  label: "TikTok Developer",
                  subtitle: "content about the application",
                  color: Colors.white,
                  url: "https://www.tiktok.com/@Hafz_111",
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════
  //  HELPER WIDGETS
  // ════════════════════════════════════════════════════════

  Widget _sectionPad({required Widget child}) =>
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: child);

  BoxDecoration _glassBox({double radius = 16, BoxShadow? shadow}) =>
      BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderGlass),
        boxShadow: shadow != null ? [shadow] : [],
      );

  Widget _sectionHeader(IconData icon, String title) => Row(
    children: [
      Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: accentSilver.withOpacity(0.18), // Silver container
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: accentSilver, size: 16),
      ),
      const SizedBox(width: 8),
      Text(title,
        style: TextStyle(
          color: primaryWhite, fontSize: 15,
          fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
          letterSpacing: 0.5,
        )),
    ],
  );

  Widget _roleBadge(String text) {
    final lowerRole = text.toLowerCase();
    Color badgeColor;
    if (lowerRole == 'owner') {
      badgeColor = const Color(0xFFFFD700);
    } else if (lowerRole == 'partner') {
      badgeColor = const Color(0xFF00E5FF);
    } else if (lowerRole == 'admin') {
      badgeColor = const Color(0xFFFF6D00);
    } else if (lowerRole == 'reseller' || lowerRole == 'seller') {
      badgeColor = const Color(0xFF69FF47);
    } else {
      badgeColor = accentSilver; // Badge Member menjadi Silver
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.18),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: badgeColor.withOpacity(0.5)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6,
          decoration: BoxDecoration(color: badgeColor, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(text,
          style: TextStyle(color: badgeColor, fontSize: 10,
              fontWeight: FontWeight.bold, letterSpacing: 0.8)),
      ]),
    );
  }

  Widget _onlineBadge() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: const Color(0xFF00E676), width: 1.5),
      boxShadow: [BoxShadow(
        color: const Color(0xFF00E676).withOpacity(0.25), blurRadius: 8)],
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 7,
          height: 7,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: Color(0xFF00E676),
            boxShadow: [
              BoxShadow(
                color: Color(0xFF00E676),
                blurRadius: 6,
                spreadRadius: 1,
              ),
            ],
          ),
        ),
        const SizedBox(width: 6),
        const Text("ONLINE",
          style: TextStyle(
            color: Color(0xFF00E676), fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron', fontSize: 12, letterSpacing: 1.5,
          )),
      ],
    ),
  );

  Widget _buildStatChip(IconData icon, String value, String label) =>
      Row(children: [
        Icon(icon, color: accentSilver, size: 17), // Silver Icon
        const SizedBox(width: 5),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value,
            style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold,
                fontSize: 13, fontFamily: 'ShareTechMono')),
          Text(label,
            style: TextStyle(color: accentGrey, fontSize: 10)),
        ]),
      ]);

  Widget _actionBannerCard({
    required IconData icon,
    required String label,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.45)),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 10)],
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: color.withOpacity(0.18),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(icon, color: color, size: 16),
            ),
            const SizedBox(width: 9),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                  style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
                  overflow: TextOverflow.ellipsis),
                Text(sub,
                  style: TextStyle(color: color.withOpacity(0.7), fontSize: 10),
                  overflow: TextOverflow.ellipsis),
              ],
            )),
            Icon(Icons.arrow_forward_ios, color: color, size: 12),
          ]),
        ),
      );

  Widget _quickActionCard({
    required IconData icon,
    required String label,
    required String sub,
    required List<Color> gradient,
    required Color iconBg,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: gradient.last.withOpacity(0.35),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -18,
              bottom: -18,
              child: Icon(icon, size: 90,
                color: Colors.white.withOpacity(0.07)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                    ),
                    child: Icon(icon, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          )),
                        const SizedBox(height: 4),
                        Text(sub,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          )),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.arrow_forward_rounded,
                      color: Colors.white, size: 18),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required String url,
  }) =>
      GestureDetector(
        onTap: () => _openUrl(url),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: _glassBox(
            radius: 16,
            shadow: BoxShadow(
              color: primarySilver.withOpacity(0.1), // Silver Shadow
              blurRadius: 10, offset: const Offset(0, 4),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.5)),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                    style: TextStyle(
                      color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                    style: TextStyle(color: accentGrey, fontSize: 11)),
                ],
              )),
              Icon(Icons.arrow_forward_ios, color: Colors.white38, size: 13),
            ],
          ),
        ),
      );

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark, // Hitam Pekat
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Icon(Icons.info_outline, color: accentSilver), // Silver Icon
          const SizedBox(width: 8),
          Text("Info & Pengumuman",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
        ]),
        content: Text(
          "🔥 Update Terbaru 🔥\n\n"
          "• Penambahan Tools Banyak Sekaligus\n"
          "• Memperbagus Dashboard\n"
          "• Dan Lain Lain!\n\n"
          "Terima kasih telah menggunakan HOXTEN!",
          style: TextStyle(color: Colors.white70, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Tutup", style: TextStyle(color: accentSilver)), // Silver Text
          ),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark, // Hitam Pekat
      child: SafeArea(
        child: Column(children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primarySilver.withOpacity(0.3), bgDark], // Silver Gradient ke Hitam
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
              ),
            ),
            child: Row(children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [primarySilver, accentSilver]), // Silver Gradient
                  boxShadow: [BoxShadow(color: accentSilver.withOpacity(0.35), blurRadius: 12)],
                ),
                child: _profileImage != null
                    ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                    : Icon(Icons.person_rounded, color: Colors.black, size: 30), // Icon Hitam
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username,
                    style: TextStyle(
                      color: primaryWhite, fontWeight: FontWeight.bold,
                      fontSize: 16, fontFamily: 'Orbitron',
                    )),
                  const SizedBox(height: 4),
                  _roleBadge(role.toUpperCase()),
                ],
              )),
            ]),
          ),
          Expanded(
            child: ListView(children: [
              if (role == 'seller' || role == 'reseller')
                _buildDrawerMenuItem(
                  icon: Icons.storefront_rounded,
                  label: "Seller Page",
                  onTap: () => _onSidebarTabSelected(1),
                ),
              if (role == 'admin')
                _buildDrawerMenuItem(
                  icon: Icons.admin_panel_settings_rounded,
                  label: "Admin Page",
                  onTap: () => _onSidebarTabSelected(2),
                ),
              if (role == 'partner')
                _buildDrawerMenuItem(
                  icon: Icons.handshake_rounded,
                  label: "Partner Page",
                  onTap: () => _onSidebarTabSelected(3),
                ),
              if (role == 'owner')
                _buildDrawerMenuItem(
                  icon: Icons.workspace_premium_rounded,
                  label: "Owner Page",
                  onTap: () => _onSidebarTabSelected(4),
                ),
              _buildDrawerMenuItem(
                icon: Icons.history_rounded,
                label: "Riwayat Aktivitas",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role),
                  ));
                },
              ),
              _buildDrawerMenuItem(
                icon: Icons.lock_outline_rounded,
                label: "Ganti Password",
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: username, sessionKey: sessionKey),
                  ));
                },
              ),
              const SizedBox(height: 8),
              _buildDrawerMenuItem(
                icon: Icons.logout_rounded,
                label: "Log Out",
                isLogout: true,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                },
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? Colors.redAccent : accentSilver;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.1) : cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isLogout
            ? Colors.red.withOpacity(0.4) : borderGlass),
      ),
      child: ListTile(
        leading: Icon(icon, color: color, size: 20),
        title: Text(label,
          style: TextStyle(color: isLogout ? Colors.redAccent : primaryWhite,
              fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark, // Hitam Pekat
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("Hai, $username",
          style: TextStyle(
            color: primaryWhite, fontWeight: FontWeight.bold,
            fontSize: 18, fontFamily: 'Orbitron',
          )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: accentSilver), // Silver Icon
            tooltip: 'Customer Service',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ContactPage())),
          ),
          IconButton(
            icon: const Icon(FontAwesomeIcons.userCircle,
                color: Color(0xFFE0E0E0)), // Silver Icon
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ProfilePage(
                username: username, password: password,
                role: role, expiredDate: expiredDate,
                sessionKey: sessionKey,
              )),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primarySilver.withOpacity(0.08), bgDark], // Silver subtle gradient
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0A0A0A), // Abu Sangat Gelap (Bukan Ungu)
          border: Border(top: BorderSide(color: borderGlass)),
          boxShadow: [BoxShadow(
            color: primarySilver.withOpacity(0.12), // Silver Shadow
            blurRadius: 12, offset: const Offset(0, -2),
          )],
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentSilver, // Silver Selected
          unselectedItemColor: accentGrey,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.notifications_none_rounded), label: "Info"),
            BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), label: "Tools"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    _quickActionsController.dispose();
    super.dispose();
  }
}

// ════════════════════════════════════════════════════════
//  NEWS MEDIA WIDGET
// ════════════════════════════════════════════════════════
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFE0E0E0)), // Silver Spinner
      );
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.grey.shade800,
        child: const Icon(Icons.error, color: Color(0xFFE0E0E0)), // Silver Icon Error
      ),
    );
  }
}