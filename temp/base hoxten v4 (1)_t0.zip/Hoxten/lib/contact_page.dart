import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA WARNA MERAH ---
  static const Color bgDark = Color(0xFF121212); // Hitam keabuan (Dark Grey)
  static const Color primaryRed = Color(0xFF9E9E9E); // Silver utama
  static const Color accentRed = Color(0xFFE0E0E0); // Silver terang untuk aksen

  // Warna glass effect dengan opacity
  static const Color cardGlass = Color.fromARGB(13, 192, 192, 192); // Silver dengan opacity rendah
  static const Color borderGlass = Color.fromARGB(26, 192, 192, 192); // Silver dengan opacity sedang

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentRed),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Customer Service",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              bgDark,
              primaryRed.withOpacity(0.1), // Gradien merah
              bgDark,
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Header Icon
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.2), // Background ikon merah
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: primaryRed.withOpacity(0.4), // Shadow merah
                        blurRadius: 20,
                      )
                    ],
                  ),
                  child: Icon(
                    Icons.support_agent_rounded,
                    size: 60,
                    color: accentRed, // Ikon merah terang
                  ),
                ),
                SizedBox(height: 24),
                Text(
                  "Need Help?",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 40),

                // Grid Buttons
                Column(
                  children: [
                    _buildContactButton(
                      label: "Telegram",
                      icon: FontAwesomeIcons.telegram,
                      color: Colors.blue,
                      url: "https://t.me/hafz_reals",
                    ),
                    SizedBox(height: 16),
                    _buildContactButton(
                      label: "WhatsApp",
                      icon: FontAwesomeIcons.whatsapp,
                      color: Colors.green,
                      url: "https://wa.me/62",
                    ),
                    SizedBox(height: 16),
                    _buildContactButton(
                      label: "TikTok",
                      icon: FontAwesomeIcons.tiktok,
                      color: Colors.white,
                      url: "https://www.tiktok.com/@hafzz_111",
                    ),
                    SizedBox(height: 16),
                    _buildContactButton(
                      label: "Instagram",
                      icon: FontAwesomeIcons.instagram,
                      color: Colors.pinkAccent,
                      url: "https://www.instagram.com/hafzz_store1?igsh=dHlxMGM2dmZ4ZmRu",
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(url),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: primaryRed.withOpacity(0.1), // Shadow merah
              blurRadius: 10,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2), // Background icon dengan opacity
                    shape: BoxShape.circle,
                  ),
                  child: FaIcon(
                    icon,
                    color: color,
                    size: 24,
                  ),
                ),
                SizedBox(width: 20),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.white54,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
}