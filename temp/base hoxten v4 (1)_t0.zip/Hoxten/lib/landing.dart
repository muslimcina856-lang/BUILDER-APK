import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ===== PERUBAHAN WARNA (UNGU -> SILVER/ABU) =====
  static const Color primaryDark   = Color(0xFF0A0118); // Tetap gelap
  static const Color deepSilver    = Color(0xFF1A1A1A); // Pengganti Deep Purple (Abu Gelap)
  static const Color primarySilver = Color(0xFF424242); // Pengganti Primary Purple
  static const Color brightSilver  = Color(0xFF9E9E9E); // Pengganti Bright Purple (Silver Utama)
  static const Color accentSilver  = Color(0xFFBDBDBD); // Pengganti Accent Purple (Abu Terang)
  static const Color neonSilver    = Color(0xFFE0E0E0); // Pengganti Neon Purple (Putih Kebiruan/Silver Pucat)
  static const Color glassBg       = Color(0x14FFFFFF);
  static const Color glassBorder   = Color(0x26FFFFFF);

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
      ),
    );
    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.8, curve: Curves.easeOutCubic),
      ),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  // ===== DIALOG KATALOG HARGA =====
  void _showPriceCatalog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: primaryDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: brightSilver.withOpacity(0.5), width: 1.5), // Bright Silver
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: brightSilver.withOpacity(0.3), width: 1), // Bright Silver
            ),
          ),
          child: const Row(
            children: [
              Icon(Icons.shopping_cart_rounded, color: Color(0xFFE0E0E0), size: 24), // Neon Silver
              SizedBox(width: 10),
              Text(
                "PRICES LIST HOXTEN",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildPriceCategory(
                  role: "Member",
                  icon: Icons.person_outline_rounded,
                  color: const Color(0xFF9E9E9E),
                  prices: [
                    {"duration": "1 Bulan", "price": "15k"},
                    {"duration": "Permanent", "price": "25k"},
                  ],
                ),
                const SizedBox(height: 12),
                _buildPriceCategory(
                  role: "Reseller",
                  icon: Icons.admin_panel_settings_outlined,
                  color: const Color(0xFFFF6D00),
                  prices: [
                    {"duration": "Permanent", "price": "50k"},
                  ],
                ),
                const SizedBox(height: 12),
                _buildPriceCategory(
                  role: "owner",
                  icon: Icons.handshake_outlined,
                  color: const Color(0xFF00E5FF),
                  prices: [
                    {"duration": "Permanent", "price": "100k"},
                  ],
                ),
                const SizedBox(height: 12),
                _buildPriceCategory(
                  role: "ADMIN",
                  icon: Icons.workspace_premium_outlined,
                  color: const Color(0xFFFFD700),
                  prices: [
                    {"duration": "Permanent", "price": "300k"},
                  ],
                  badge: "Unlock All Akses!",
                ),
                const SizedBox(height: 20),
                // Divider
                Container(
                  width: 60,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.transparent, const Color(0xFFE0E0E0), Colors.transparent], // Neon Silver
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Tombol Hubungi Telegram
                Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0088cc), Color(0xFF00A8E8)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF0088cc).withOpacity(0.4),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(ctx);
                      _openUrl("https://t.me/hafz_reals");
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
                        SizedBox(width: 10),
                        Text(
                          "Hubungi via Telegram",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              "Tutup",
              style: TextStyle(color: Colors.white60),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceCategory({
    required String role,
    required IconData icon,
    required Color color,
    required List<Map<String, String>> prices,
    String? badge,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: glassBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                role,
                style: TextStyle(
                  color: color,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              if (badge != null) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD700).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5)),
                  ),
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Color(0xFFFFD700),
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 12),
          ...prices.map((price) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  price["duration"]!,
                  style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: color.withOpacity(0.3)),
                  ),
                  child: Text(
                    "Rp ${price["price"]}",
                    style: TextStyle(
                      color: color,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          )).toList(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [primaryDark, deepSilver, Color(0xFF121212), primaryDark], // Menggunakan deepSilver
            stops: [0.0, 0.3, 0.7, 1.0],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -80,
              right: -80,
              child: _buildGlowCircle(200, brightSilver.withOpacity(0.12)), // Bright Silver
            ),
            Positioned(
              bottom: 100,
              left: -60,
              child: _buildGlowCircle(160, const Color(0xFFE0E0E0).withOpacity(0.08)), // Neon Silver
            ),
            Positioned(
              top: 300,
              left: -40,
              child: _buildGlowCircle(120, brightSilver.withOpacity(0.06)), // Bright Silver
            ),
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 30),
                        _buildLogo(),
                        const SizedBox(height: 18),
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [accentSilver, Colors.white, const Color(0xFFE0E0E0)], // Silver Gradients
                            stops: [0.0, 0.5, 1.0],
                          ).createShader(bounds),
                          child: const Text(
                            "HOXTEN",
                            style: TextStyle(
                              fontSize: 38,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: 2.0,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        _buildPoweredByBadge(),
                        const SizedBox(height: 28),
                        _buildFeatureCards(),
                        const SizedBox(height: 24),
                        _buildHeroImage(),
                        const SizedBox(height: 28),
                        _buildSignInButton(),
                        const SizedBox(height: 14),
                        _buildBuyAccessButton(),
                        const SizedBox(height: 28),
                        _buildContactRow(),
                        const SizedBox(height: 30),
                        Text(
                          "© 2026 HOXTEN • All Rights Reserved",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.25),
                            fontSize: 11,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlowCircle(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [
          BoxShadow(color: color, blurRadius: 60, spreadRadius: 20),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          colors: [primarySilver, deepSilver], // Silver Radial
        ),
        border: Border.all(
          color: brightSilver, // Bright Silver Border
          width: 2.5,
        ),
        boxShadow: [
          BoxShadow(
            color: brightSilver.withOpacity(0.5), // Bright Silver Glow
            blurRadius: 25,
            spreadRadius: 4,
          ),
        ],
      ),
      child: Center(
        child: ClipOval(
          child: SizedBox(
            width: 90,
            height: 90,
            child: Image.asset(
              'assets/images/logo.jpg',
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPoweredByBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: glassBg,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: glassBorder),
        boxShadow: [
          BoxShadow(
            color: brightSilver.withOpacity(0.15), // Bright Silver Shadow
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFFE0E0E0), // Neon Silver Dot
              boxShadow: [
                BoxShadow(color: Color(0xFFE0E0E0), blurRadius: 6, spreadRadius: 1),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            "Powered By @hafz_reals",
            style: TextStyle(
              color: Colors.white60,
              fontSize: 12.5,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCards() {
    final features = [
      {'icon': Icons.shield_rounded, 'label': 'Secure', 'color': const Color(0xFF9E9E9E)}, // Silver
      {'icon': Icons.bolt_rounded, 'label': 'Fast', 'color': const Color(0xFFBDBDBD)}, // Silver Light
      {'icon': Icons.whatshot_rounded, 'label': 'Power', 'color': const Color(0xFFE0E0E0)}, // Neon Silver
    ];
    return Row(
      children: features.map((f) {
        final isLast = f == features.last;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: isLast ? 0 : 10),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: glassBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: (f['color'] as Color).withOpacity(0.35),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (f['color'] as Color).withOpacity(0.18),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Icon(f['icon'] as IconData, color: f['color'] as Color, size: 28),
                  const SizedBox(height: 8),
                  Text(
                    f['label'] as String,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.85),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildHeroImage() {
    return Container(
      width: double.infinity,
      height: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: glassBorder),
        boxShadow: [
          BoxShadow(
            color: brightSilver.withOpacity(0.2), // Bright Silver Shadow
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              "assets/images/Rangers.png",
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [deepSilver, primarySilver], // Silver Fallback Gradient
                    ),
                  ),
                  child: const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.image_rounded, color: glassBorder, size: 48),
                        SizedBox(height: 8),
                        Text(
                          "Taruh gambar di assets/images/Rangers.png",
                          style: TextStyle(color: glassBorder, fontSize: 10),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, primaryDark.withOpacity(0.75)],
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSignInButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [primarySilver, brightSilver, const Color(0xFFE0E0E0)], // Silver Gradient
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: brightSilver.withOpacity(0.45), // Silver Glow
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: const Color(0xFFE0E0E0).withOpacity(0.2), // Neon Silver Glow
            blurRadius: 40,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: () => Navigator.pushNamed(context, "/login"),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.login_rounded, color: Colors.black, size: 20), // Icon hitam agar kontras dengan silver
            SizedBox(width: 10),
            Text(
              "Sign in",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: Colors.black, // Teks hitam agar kontras
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBuyAccessButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        color: glassBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: brightSilver.withOpacity(0.5), width: 1.5), // Bright Silver Border
        boxShadow: [
          BoxShadow(
            color: brightSilver.withOpacity(0.12), // Bright Silver Shadow
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.transparent,
          side: BorderSide.none,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: () => _showPriceCatalog(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_rounded, color: accentSilver, size: 20), // Accent Silver
            const SizedBox(width: 10),
            Text(
              "Buy Access",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: accentSilver, // Accent Silver
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFE0E0E0).withOpacity(0.2), // Neon Silver bg
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFE0E0E0).withOpacity(0.5), width: 1),
              ),
              child: const Text(
                "CLICK HERE",
                style: TextStyle(
                  color: Color(0xFFE0E0E0), // Neon Silver Text
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactRow() {
    return Row(
      children: [
        Expanded(
          child: _buildContactButton(
            icon: FontAwesomeIcons.telegram,
            label: "Telegram",
            url: "https://t.me/hafz_reals",
            color: const Color(0xFF0088cc),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _buildContactButton(
            icon: FontAwesomeIcons.tiktok,
            label: "TikTok",
            url: "https://www.tiktok.com/@hafzz_111",
            color: const Color(0xFFFFFFFF),
          ),
        ),
      ],
    );
  }

  Widget _buildContactButton({
    required IconData icon,
    required String label,
    required String url,
    required Color color,
  }) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          border: Border.all(color: color.withOpacity(0.3), width: 1.2),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 19),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}