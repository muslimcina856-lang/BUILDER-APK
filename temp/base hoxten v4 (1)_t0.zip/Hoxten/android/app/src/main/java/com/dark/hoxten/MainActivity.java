package com.dark.hoxten;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
