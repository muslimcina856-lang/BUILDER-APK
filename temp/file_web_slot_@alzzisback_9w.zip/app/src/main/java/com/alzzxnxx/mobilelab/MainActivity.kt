package com.alzzxnxx.mobilelab
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread
class MainActivity:AppCompatActivity(){
 private val id=UUID.randomUUID().toString(); var base=""; lateinit var st:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);st=findViewById(R.id.status)
 findViewById<Button>(R.id.connect).setOnClickListener{if(!findViewById<CheckBox>(R.id.consent).isChecked){st.text="Consent required";return@setOnClickListener};base=findViewById<EditText>(R.id.url).text.toString().trimEnd('/');reg()}
 findViewById<Button>(R.id.camera).setOnClickListener{if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),5)else ev("CAMERA_PERMISSION","User granted camera permission")}
 findViewById<Button>(R.id.file).setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},6)}
 }
 fun reg(){thread{try{post("/api/register","""{"agent_id":"$id","name":"${esc(findViewById<EditText>(R.id.name).text.toString())}","platform":"Android","version":"1.0","consent":true}""");runOnUiThread{st.text="Connected: $id"};while(true){Thread.sleep(10000);try{post("/api/heartbeat","""{"agent_id":"$id"}""")}catch(_:Exception){}}}catch(e:Exception){runOnUiThread{st.text="Connection failed: ${e.message}"}}}}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==6&&c==Activity.RESULT_OK)ev("FILE_SELECTED","User selected a file using Android picker")}
 fun ev(k:String,v:String){if(base.isBlank())return;thread{try{post("/api/event","""{"agent_id":"$id","kind":"$k","detail":"${esc(v)}"}""")}catch(_:Exception){}}}
 fun post(path:String,body:String){val c=URL(base+path).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.connectTimeout=8000;c.readTimeout=8000;c.outputStream.use{it.write(body.toByteArray())};if(c.responseCode !in 200..299)throw RuntimeException("HTTP ${c.responseCode}");c.disconnect()}
 fun esc(s:String)=s.replace("\","\\").replace(""","\"")
}
