# ALZZXNXX Consent Agent

Consent-based Android security-lab demonstration.

- Visible UI
- Android permission dialog for camera
- No covert capture
- No persistence
- No arbitrary shell
- No credential collection

Build with JDK 17 and Gradle 8.11.1 / AGP 8.6.1:
./gradlew assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
