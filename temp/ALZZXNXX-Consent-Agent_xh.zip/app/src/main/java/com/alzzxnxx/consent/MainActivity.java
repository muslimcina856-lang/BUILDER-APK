package com.alzzxnxx.consent;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status;
    static final int CAMERA_REQ = 100;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40,60,40,40);

        TextView title = new TextView(this);
        title.setText("ALZZXNXX Consent Security Lab");
        title.setTextSize(24);

        status = new TextView(this);
        status.setText("\\nActions require visible user consent.");

        Button cam = new Button(this);
        cam.setText("Request Camera Permission");
        cam.setOnClickListener(v -> requestCamera());

        Button info = new Button(this);
        info.setText("Show Device Info");
        info.setOnClickListener(v -> showInfo());

        box.addView(title);
        box.addView(status);
        box.addView(cam);
        box.addView(info);
        setContentView(box);
    }

    void requestCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQ);
        } else {
            status.setText("\\nCamera permission is already granted. No automatic capture is performed.");
        }
    }

    void showInfo() {
        status.setText("\\nDevice: " + android.os.Build.MANUFACTURER + " "
                + android.os.Build.MODEL + "\\nAndroid: "
                + android.os.Build.VERSION.RELEASE);
    }
}
