# KuroPlay AndroidIDE merge notes

## What was merged
- Original project remains the project root and keeps the original app label `KuroPlay` and original launcher icon resources.
- AI Studio Kotlin/Compose screens, navigation, networking, Room, DataStore, account, anime, manga, reader, player, and gear loading were moved into `app/src/main/kotlin/com/kano/playjv/`.
- Package and application ID are `com.kano.playjv`.
- The API base URL remains `https://kano-streaming.pages.dev/`.
- Network headers and Firebase REST API query keys are redacted from debug HTTP logs; logging is disabled in release builds.
- Direct key granting from the UI was removed until rewarded-ad verification is connected and validated on the server.

## Build environment
- JDK 17
- Android SDK Platform 36 and compatible Build Tools
- Android Gradle Plugin 8.13.0 / Gradle 8.13
- Kotlin 2.3.10 / KSP 2.3.10
- Compose BOM 2026.09.00 (stable Compose libraries)

## AndroidIDE
Open the extracted `KuroPlay` folder as an existing project, allow Gradle to sync, then run `:app:assembleDebug`.

## Firebase authentication note
The project uses Firebase Authentication REST endpoints, not the Google Services Gradle plugin or Firebase Android SDK. Therefore the AI Studio `google-services.json` (which named a different application ID) is intentionally not carried over. Check Firebase API-key restrictions/provider settings for the target app and backend before production release.

## Verification status
Source tree and package/resource/Gradle consistency were checked after merging. A full Android Gradle build must still be run in AndroidIDE with SDK Platform 36 installed; this work environment did not include a local Android SDK installation.

## Perbaikan build (revisi)
- Compose BOM 2026.09.00 (Compose 1.12.1) butuh AGP 9.1+ dan compileSdk 37 -> diturunkan ke BOM 2025.10.01 (Compose 1.9.4) yang cocok dengan AGP 8.13.0 + compileSdk 36.
- core-ktx 1.18.0 -> 1.17.0, activity-compose 1.10.1 -> 1.11.0, Room 2.7.0 -> 2.8.4, OkHttp 4.10.0 -> 4.12.0.
- `HttpLoggingInterceptor.redactQueryParams` tidak ada di OkHttp 4.x (compile error) -> diganti logger kustom yang menyensor `key=`.
- Firebase refresh token (`securetoken.googleapis.com/v1/token`) sekarang dikirim sebagai form-urlencoded.
- Error Firebase (EMAIL_EXISTS, INVALID_LOGIN_CREDENTIALS, dll.) dibaca dari body HTTP dan diterjemahkan, bukan lagi "HTTP 400".

## Perbaikan setelah uji di HP
- Rotasi layar tidak lagi membuat ulang activity (`configChanges` di manifest), jadi episode tidak mengulang.
- Player: portrait = video 16:9 di atas, landscape/fullscreen = memenuhi layar dengan status/nav bar disembunyikan; auto-rotate ikut bekerja.
- AccountScreen: loop refresh tak berujung (efek bergantung pada seluruh profil) diganti agar hanya bergantung pada uid -> angka kunci tidak lagi berkedip & UI tidak macet.
- `keys` pada KeyBalance/StatusResponse dibuat nullable; nilai kosong tidak lagi menimpa saldo menjadi 0 (owner tidak ditimpa 0).
- Bottom bar: inset navigasi ganda dihapus.

## Versi 2.2.0
- Wajib login: layar login/daftar tampil penuh saat app dibuka; konten baru bisa dipakai setelah login (`KuroApp` sebagai gerbang).
- Tab "Akun" diganti "Tentang": info app, developer, premium/keys, logout.
- versionCode 14 / versionName 2.2.0.

## Login Google (2.3.0)
- Credential Manager + `GetSignInWithGoogleOption` -> Google ID token -> Firebase REST `accounts:signInWithIdp` -> worker (`/api/auth/me`).
- Akun baru (server belum punya profil) diminta memilih username -> `check-username` + `setup-profile`.
- Syarat: Google provider aktif di Firebase `kanoplay-ed6b7`, serta SHA-1 penanda tangan APK + package `com.kano.playjv` terdaftar di Firebase (Android OAuth client). Web client ID ada di `GOOGLE_WEB_CLIENT_ID` (app/build.gradle.kts).

## Versi 2.4.0 - lepas dari worker Cloudflare
- Akun & library sekarang sepenuhnya Firebase project `kuroplay-app`: Auth (email + Google) dan Firestore (REST). Tidak ada lagi panggilan ke `/api/auth`, `/api/library`, `/api/keys`, `/api/premium`.
- Daftar anime/manga/stream masih memakai `API_BASE_URL` (kano-streaming.pages.dev: `/api/anime-v2`, `/api/komik/*`). Kalau domain itu dimatikan, konten ikut mati.
- Keys & premium dihapus (butuh backend tepercaya untuk pembayaran). Semua episode bebas ditonton.
- Struktur Firestore: `usernames/{name}`, `users/{uid}`, `users/{uid}/animeHistory|animeBookmarks|mangaHistory|mangaBookmarks/{base64url(id)}`. Rules ada di `firestore.rules`. Untuk jadi owner/admin: tambahkan field boolean `isOwner`/`isAdmin` pada `users/{uid}` lewat Firebase Console.
- Player: portrait = video 16:9 + daftar episode geser samping; tombol prev/next; auto next (pengaturan di tab Tentang, juga bisa di panel player).
- Indikator gerigi dipusatkan.

## v2.5.0
- Anime & manga langsung dari AnimeKita / MangaDex (tanpa web/worker, tanpa Cloudflare KV).
- Populer = urut skor dari ~60 anime terbaru; filter genre anime di sisi aplikasi (genre diambil dari pencarian AnimeKita, lalu di-cache).
- Tombol Berikutnya dinonaktifkan bila tidak ada halaman lanjut.
- Kunci/premium ditampilkan sebagai ikon ∞ saja (tanpa pembelian).
- Coil memakai OkHttp dengan Referer MangaDex agar cover tampil.

## v2.6.0
- User biasa: 3 kunci awal (disimpan di Firestore users/{uid}.keys; bila kosong dianggap 3). 1 episode baru = 1 kunci; episode yang sudah dibuka gratis (subkoleksi users/{uid}/unlocked).
- Iklan rewarded AdMob (ID TEST Google) = +3 kunci. Tombol di Tentang dan di layar player saat kunci habis.
- Premium: isi field `premiumUntil` (tipe timestamp atau number ms epoch) di users/{uid} lewat Console. Owner (isOwner=true) dan premium tampil ∞.
- firestore.rules diperbarui: wajib dipasang ulang di Console.

## v2.6.1
- Perbaikan error kompilasi: definisi AnimePage/ANIME_PAGE_SIZE/POOL_TTL_MS yang hilang dan import di AuthRepository.
