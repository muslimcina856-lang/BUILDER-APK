package com.kano.playjv

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.core.network.NetworkClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KuroPlay", appName)
  }

  @Test
  fun `resolve image URL prefixes relative worker path`() {
    val raw = "/api/komik-img?url=https%3A%2F%2Ftest.jpg"
    val resolved = NetworkClient.resolveImageUrl(raw)
    assertTrue(resolved.startsWith("https://kano-streaming.pages.dev/api/komik-img"))
  }

  @Test
  fun `anime model creation and chapter split validation`() {
    val episode = AnimeEpisode(ch = "1", url = "101|series-1|ep-1|1")
    val parts = episode.url.split("|")
    assertEquals(4, parts.size)
    assertEquals("101", parts[0])
    assertEquals("series-1", parts[1])
    assertEquals("ep-1", parts[2])
    assertEquals("1", parts[3])
  }
}
