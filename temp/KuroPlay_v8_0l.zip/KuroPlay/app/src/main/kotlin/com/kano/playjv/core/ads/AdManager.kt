package com.kano.playjv.core.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/** Iklan rewarded AdMob. Memakai ID TEST resmi Google; ganti sebelum rilis sungguhan. */
object AdManager {
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    private var ad: RewardedAd? = null
    private var loading = false

    fun isReady(): Boolean = ad != null

    fun preload(context: Context) {
        if (ad != null || loading) return
        loading = true
        RewardedAd.load(
            context.applicationContext,
            TEST_REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(loaded: RewardedAd) {
                    ad = loaded
                    loading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    loading = false
                }
            }
        )
    }

    /** Menampilkan iklan. [onReward] dipanggil sekali bila penonton berhak atas hadiah. */
    fun show(activity: Activity, onReward: () -> Unit, onFail: (String) -> Unit) {
        val current = ad
        if (current == null) {
            preload(activity)
            onFail("Iklan belum siap, coba lagi sebentar lagi.")
            return
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                preload(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
                preload(activity)
                onFail("Iklan gagal ditampilkan.")
            }
        }
        current.show(activity) { onReward() }
    }
}

fun Context.findHostActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
