package com.kano.playjv.ui.navigation

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.kano.playjv.core.components.KuroBottomBar
import com.kano.playjv.core.components.KuroTopBar
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.account.AccountScreen
import com.kano.playjv.ui.anime.AnimeDetailScreen
import com.kano.playjv.ui.anime.AnimeListScreen
import com.kano.playjv.ui.home.HomeScreen
import com.kano.playjv.ui.library.LibraryScreen
import com.kano.playjv.ui.manga.MangaDetailScreen
import com.kano.playjv.ui.manga.MangaListScreen
import com.kano.playjv.ui.manga.MangaReaderScreen
import com.kano.playjv.ui.player.VideoPlayerScreen
import com.kano.playjv.core.model.UserProfile
import com.kano.playjv.ui.theme.KuroBgPrimary
import kotlinx.coroutines.flow.map

const val ROUTE_HOME = "beranda"
const val ROUTE_ANIME = "anime"
const val ROUTE_MANGA = "manga"
const val ROUTE_LIBRARY = "library"
const val ROUTE_ACCOUNT = "akun"

private data class ProfileHolder(val profile: UserProfile?)

/**
 * Gerbang login: aplikasi hanya bisa dipakai setelah login.
 * holder == null  -> DataStore belum selesai dibaca (layar kosong sebentar)
 * profile == null -> belum login -> tampilkan layar login/daftar
 */
@Composable
fun KuroApp(
    repository: KuroRepository,
    authRepository: AuthRepository,
    preferences: UserPreferences
) {
    val holder by remember { authRepository.userProfileFlow.map { ProfileHolder(it) } }
        .collectAsState(initial = null)
    val current = holder

    when {
        current == null -> Box(modifier = Modifier.fillMaxSize().background(KuroBgPrimary))
        current.profile == null -> Box(
            modifier = Modifier
                .fillMaxSize()
                .background(KuroBgPrimary)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            AccountScreen(authRepository = authRepository, preferences = preferences)
        }
        else -> KuroMainApp(repository, authRepository, preferences)
    }
}

@Composable
private fun KuroMainApp(
    repository: KuroRepository,
    authRepository: AuthRepository,
    preferences: UserPreferences
) {
    val navController = rememberNavController()
    val focusManager = LocalFocusManager.current
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME

    val userProfile by authRepository.userProfileFlow.collectAsState(initial = null)
    val currentUid = userProfile?.uid ?: "guest_user"
    val isLoggedIn = userProfile != null

    // Determine if top/bottom bars should be visible
    val isFullScreen = currentRoute.startsWith("player/") || currentRoute.startsWith("reader/")
    val isTopLevelTab = currentRoute in listOf(ROUTE_HOME, ROUTE_ANIME, ROUTE_MANGA, ROUTE_LIBRARY, ROUTE_ACCOUNT)

    Scaffold(
        containerColor = KuroBgPrimary,
        topBar = {
            if (!isFullScreen && isTopLevelTab) {
                KuroTopBar(
                    title = "KuroPlay",
                    keysLabel = when {
                        userProfile?.isOwner == true -> "∞"
                        userProfile?.premium?.active == true -> "∞"
                        userProfile != null -> "${userProfile?.keys ?: 0}"
                        else -> null
                    },
                    onKeysClick = { navController.navigate(ROUTE_ACCOUNT) },
                    onSearchClick = {
                        if (currentRoute == ROUTE_MANGA) {
                            navController.navigate(ROUTE_MANGA)
                        } else {
                            navController.navigate(ROUTE_ANIME)
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!isFullScreen && isTopLevelTab) {
                KuroBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        focusManager.clearFocus()
                        navController.navigate(route) {
                            popUpTo(ROUTE_HOME) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isFullScreen) androidx.compose.foundation.layout.PaddingValues() else innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = ROUTE_HOME
            ) {
                composable(ROUTE_HOME) {
                    HomeScreen(
                        repository = repository,
                        currentUid = currentUid,
                        onNavigateToAnimeDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        },
                        onNavigateToMangaDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        },
                        onNavigateToPlayer = { slug, ep, channelId, title ->
                            navController.navigate("player/${Uri.encode(slug)}/${Uri.encode(ep)}/${Uri.encode(channelId)}/${Uri.encode(title)}")
                        },
                        onNavigateToReader = { idSeries, idChapter, title ->
                            navController.navigate("reader/${Uri.encode(idSeries)}/${Uri.encode(idChapter)}/${Uri.encode(title)}")
                        },
                        onNavigateToAnimeTab = { navController.navigate(ROUTE_ANIME) },
                        onNavigateToMangaTab = { navController.navigate(ROUTE_MANGA) }
                    )
                }

                composable(ROUTE_ANIME) {
                    AnimeListScreen(
                        repository = repository,
                        onNavigateToDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        }
                    )
                }

                composable(ROUTE_MANGA) {
                    MangaListScreen(
                        repository = repository,
                        onNavigateToDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        }
                    )
                }

                composable(ROUTE_LIBRARY) {
                    LibraryScreen(
                        repository = repository,
                        currentUid = currentUid,
                        isLoggedIn = isLoggedIn,
                        onNavigateToAnimeDetail = { slug ->
                            navController.navigate("anime_detail/${Uri.encode(slug)}")
                        },
                        onNavigateToMangaDetail = { idSeries ->
                            navController.navigate("manga_detail/${Uri.encode(idSeries)}")
                        }
                    )
                }

                composable(ROUTE_ACCOUNT) {
                    AccountScreen(
                        authRepository = authRepository,
                        preferences = preferences
                    )
                }

                composable(
                    route = "anime_detail/{slug}",
                    arguments = listOf(navArgument("slug") { type = NavType.StringType })
                ) { backStackEntry ->
                    val slug = backStackEntry.arguments?.getString("slug") ?: ""
                    AnimeDetailScreen(
                        animeId = slug,
                        repository = repository,
                        currentUid = currentUid,
                        onBack = { navController.popBackStack() },
                        onPlayEpisode = { s, ep, channelId, title ->
                            navController.navigate("player/${Uri.encode(s)}/${Uri.encode(ep)}/${Uri.encode(channelId)}/${Uri.encode(title)}")
                        }
                    )
                }

                composable(
                    route = "manga_detail/{idSeries}",
                    arguments = listOf(navArgument("idSeries") { type = NavType.StringType })
                ) { backStackEntry ->
                    val idSeries = backStackEntry.arguments?.getString("idSeries") ?: ""
                    MangaDetailScreen(
                        idSeries = idSeries,
                        repository = repository,
                        currentUid = currentUid,
                        onBack = { navController.popBackStack() },
                        onReadChapter = { sId, chId, title ->
                            navController.navigate("reader/${Uri.encode(sId)}/${Uri.encode(chId)}/${Uri.encode(title)}")
                        }
                    )
                }

                composable(
                    route = "player/{slug}/{epNumber}/{channelId}/{title}",
                    arguments = listOf(
                        navArgument("slug") { type = NavType.StringType },
                        navArgument("epNumber") { type = NavType.StringType },
                        navArgument("channelId") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val slug = backStackEntry.arguments?.getString("slug") ?: ""
                    val epNumber = backStackEntry.arguments?.getString("epNumber") ?: ""
                    val channelId = backStackEntry.arguments?.getString("channelId") ?: ""
                    val title = backStackEntry.arguments?.getString("title") ?: ""

                    VideoPlayerScreen(
                        slug = slug,
                        epNumber = epNumber,
                        channelId = channelId,
                        animeTitle = title,
                        repository = repository,
                        preferences = preferences,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = "reader/{idSeries}/{idChapter}/{title}",
                    arguments = listOf(
                        navArgument("idSeries") { type = NavType.StringType },
                        navArgument("idChapter") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val idSeries = backStackEntry.arguments?.getString("idSeries") ?: ""
                    val idChapter = backStackEntry.arguments?.getString("idChapter") ?: ""
                    val title = backStackEntry.arguments?.getString("title") ?: ""

                    MangaReaderScreen(
                        idSeries = idSeries,
                        idChapter = idChapter,
                        chapterTitle = title,
                        repository = repository,
                        preferences = preferences,
                        onBack = { navController.popBackStack() },
                        onNavigateToChapter = { newChId, newTitle ->
                            navController.navigate("reader/${Uri.encode(idSeries)}/${Uri.encode(newChId)}/${Uri.encode(newTitle)}") {
                                popUpTo("reader/{idSeries}/{idChapter}/{title}") { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
    }
}
