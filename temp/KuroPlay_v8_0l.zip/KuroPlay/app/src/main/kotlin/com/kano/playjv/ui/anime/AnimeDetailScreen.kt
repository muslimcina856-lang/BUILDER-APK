package com.kano.playjv.ui.anime

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeBookmarkItem
import com.kano.playjv.core.model.AnimeDetail
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AnimeDetailScreen(
    animeId: String,
    repository: KuroRepository,
    currentUid: String,
    onBack: () -> Unit,
    onPlayEpisode: (slug: String, epNumber: String, channelId: String, animeTitle: String) -> Unit
) {
    BackHandler { onBack() }

    var animeDetail by remember { mutableStateOf<AnimeDetail?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSynopsisExpanded by remember { mutableStateOf(false) }


    val isBookmarked by repository.isAnimeBookmarkedFlow(animeId, currentUid).collectAsState(initial = false)
    val coroutineScope = rememberCoroutineScope()

    fun loadDetail() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res = repository.getAnimeDetail(animeId)
            if (res.isSuccess) {
                animeDetail = res.getOrNull()
                isLoading = false
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat detail anime"
                isLoading = false
            }
        }
    }

    LaunchedEffect(animeId) {
        loadDetail()
    }

    fun handleEpisodeClick(ep: AnimeEpisode) {
        val detail = animeDetail ?: return
        onPlayEpisode(animeId, ep.ch, ep.url, detail.judul)
    }

    Scaffold(
        topBar = {
            Surface(
                color = KuroBgPrimary,
                border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali",
                            tint = KuroTextPrimary
                        )
                    }
                    Text(
                        text = animeDetail?.judul ?: "Detail Anime",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = KuroTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    animeDetail?.let { detail ->
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    repository.toggleAnimeBookmark(
                                        AnimeBookmarkItem(
                                            slug = animeId,
                                            title = detail.judul,
                                            cover = detail.cover
                                        ),
                                        isBookmarked
                                    )
                                }
                            },
                            modifier = Modifier.testTag("detail_bookmark_button")
                        ) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = if (isBookmarked) KuroGold else KuroTextPrimary
                            )
                        }
                    }
                }
            }
        },
        containerColor = KuroBgPrimary
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isLoading && animeDetail == null) {
                GearProgressIndicator(
                    progress = 65,
                    statusText = "Memuat detail anime...",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (errorMessage != null && animeDetail == null) {
                ErrorStateView(
                    message = errorMessage ?: "Terjadi kesalahan",
                    onRetry = { loadDetail() },
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (animeDetail != null) {
                val detail = animeDetail!!

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("anime_detail_content"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Banner with Poster + Info
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            AsyncImage(
                                model = detail.cover,
                                contentDescription = detail.judul,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, KuroBorder, RoundedCornerShape(10.dp))
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = detail.judul,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = KuroTextPrimary
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    StatusBadge(text = detail.type.ifBlank { "TV" })
                                    StatusBadge(text = detail.status.ifBlank { "Ongoing" })
                                }

                                if (detail.rating.isNotBlank() && detail.rating != "-") {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = KuroGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = detail.rating,
                                            fontSize = 13.sp,
                                            color = KuroTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                if (detail.published.isNotBlank()) {
                                    Text(
                                        text = "Rilis: ${detail.published}",
                                        fontSize = 12.sp,
                                        color = KuroTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Synopsis
                    if (detail.sinopsis.isNotBlank()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = KuroSurface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isSynopsisExpanded = !isSynopsisExpanded }
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Sinopsis",
                                        fontWeight = FontWeight.Bold,
                                        color = KuroTextPrimary,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = detail.sinopsis,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = KuroTextSecondary,
                                        maxLines = if (isSynopsisExpanded) Int.MAX_VALUE else 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (isSynopsisExpanded) "Tutup" else "Baca selengkapnya...",
                                        color = KuroTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Episodes Header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Daftar Episode",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KuroTextPrimary
                            )
                            Text(
                                text = "${detail.chapter.size} Episode",
                                fontSize = 12.sp,
                                color = KuroTextSecondary
                            )
                        }
                    }

                    // Episode Items
                    if (detail.chapter.isEmpty()) {
                        item {
                            EmptyStateView(message = "Belum ada episode tersedia")
                        }
                    } else {
                        items(detail.chapter, key = { it.url }) { ep ->
                            EpisodeRowItem(
                                episode = ep,
                                onClick = { handleEpisodeClick(ep) }
                            )
                        }
                    }
                }
            }
        }
    }

    // No Keys Dialog
}

@Composable
fun EpisodeRowItem(
    episode: AnimeEpisode,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("episode_item_${episode.ch}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = KuroSurfaceElevated,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = KuroTextPrimary,
                        modifier = Modifier
                            .padding(6.dp)
                            .fillMaxSize()
                    )
                }
                Text(
                    text = "Episode ${episode.ch}",
                    fontWeight = FontWeight.SemiBold,
                    color = KuroTextPrimary,
                    fontSize = 14.sp
                )
            }

            Text(
                text = "Tonton",
                color = KuroTextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
