package com.kano.playjv.ui.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.core.model.AnimeHistoryItem
import com.kano.playjv.core.model.StreamSource
import com.kano.playjv.core.network.NetworkClient
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.data.repository.UnlockResult
import com.kano.playjv.core.ads.AdManager
import android.widget.Toast
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    slug: String,
    epNumber: String,
    channelId: String,
    animeTitle: String,
    repository: KuroRepository,
    preferences: UserPreferences,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val coroutineScope = rememberCoroutineScope()

    // Episode yang sedang diputar
    var currentEp by remember { mutableStateOf(epNumber) }
    var currentChannelId by remember { mutableStateOf(channelId) }
    var episodes by remember { mutableStateOf<List<AnimeEpisode>>(emptyList()) }
    val autoNext by preferences.autoNextFlow.collectAsState(initial = true)

    var availableStreams by remember { mutableStateOf<List<StreamSource>>(emptyList()) }
    var selectedStream by remember { mutableStateOf<StreamSource?>(null) }
    var isLoadingStreams by remember { mutableStateOf(true) }
    var streamError by remember { mutableStateOf<String?>(null) }
    var isPlayerBuffering by remember { mutableStateOf(false) }
    var keysBlocked by remember { mutableStateOf(false) }
    var adBusy by remember { mutableStateOf(false) }

    var isControlsVisible by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var showQualityDialog by remember { mutableStateOf(false) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply { playWhenReady = true }
    }

    // Navigasi episode
    val currentIndex = episodes.indexOfFirst { it.ch == currentEp }
    val prevEpisode = if (currentIndex > 0) episodes[currentIndex - 1] else null
    val nextEpisode = if (currentIndex >= 0) episodes.getOrNull(currentIndex + 1) else null

    fun playEpisode(ep: AnimeEpisode) {
        currentPositionMs = 0L
        durationMs = 0L
        currentEp = ep.ch
        currentChannelId = ep.url
    }

    // Dipanggil dari listener ExoPlayer; selalu memakai nilai terbaru
    val onEnded by rememberUpdatedState(newValue = {
        if (autoNext) nextEpisode?.let { playEpisode(it) }
        Unit
    })

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isPlayerBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_READY) {
                    durationMs = exoPlayer.duration.coerceAtLeast(0L)
                }
                if (state == Player.STATE_ENDED) {
                    onEnded()
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                streamError = "Gagal memutar video: ${error.localizedMessage ?: "Error tidak dikenal"}"
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.stop()
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.let { w ->
                WindowInsetsControllerCompat(w, w.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Sembunyikan status/nav bar saat landscape; lepas kunci orientasi setelah kembali ke portrait
    LaunchedEffect(isLandscape) {
        val w = activity?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(w, w.decorView)
        if (isLandscape) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
            delay(800)
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Daftar episode untuk strip di bawah video
    LaunchedEffect(slug) {
        val detail = repository.getAnimeDetail(slug).getOrNull() ?: return@LaunchedEffect
        val list = detail.chapter
        val numeric = list.isNotEmpty() && list.all { it.ch.toDoubleOrNull() != null }
        // Numerik: urut naik. Non-numerik: anggap sumber terbaru-dulu, balik supaya episode awal di kiri.
        episodes = if (numeric) list.sortedBy { it.ch.toDouble() } else list.reversed()
    }

    // Progress
    LaunchedEffect(exoPlayer, isPlaying) {
        while (isPlaying) {
            currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            delay(1000)
        }
    }

    // Sembunyikan kontrol otomatis
    LaunchedEffect(isControlsVisible, isPlaying) {
        if (isControlsVisible && isPlaying) {
            delay(4000)
            isControlsVisible = false
        }
    }

    fun fetchStream() {
        val channel = currentChannelId
        val epLabel = currentEp
        coroutineScope.launch {
            isLoadingStreams = true
            streamError = null
            keysBlocked = false
            when (val u = repository.unlockEpisode(slug, epLabel)) {
                is UnlockResult.NoKeys -> {
                    exoPlayer.stop()
                    keysBlocked = true
                    isLoadingStreams = false
                    return@launch
                }
                is UnlockResult.Error -> {
                    streamError = u.message
                    isLoadingStreams = false
                    return@launch
                }
                is UnlockResult.Spent ->
                    Toast.makeText(context, "1 kunci terpakai, sisa ${u.left}", Toast.LENGTH_SHORT).show()
                else -> {}
            }
            val res = repository.getAnimeStream(channel)
            if (res.isSuccess) {
                val serverStreams = res.getOrNull()?.streams?.values?.flatten() ?: emptyList()
                if (serverStreams.isNotEmpty()) {
                    availableStreams = serverStreams
                    val defaultStream = serverStreams.first()
                    selectedStream = defaultStream
                    val playUrl = NetworkClient.resolveStreamUrl(defaultStream.link)
                    exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(playUrl)))
                    exoPlayer.prepare()
                    exoPlayer.play()

                    repository.recordAnimeHistory(
                        AnimeHistoryItem(
                            slug = slug,
                            title = animeTitle,
                            cover = "",
                            lastEp = epLabel,
                            seriesUrl = slug,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                } else {
                    streamError = "Sumber video tidak ditemukan"
                }
                isLoadingStreams = false
            } else {
                streamError = res.exceptionOrNull()?.message ?: "Gagal mendapatkan link streaming"
                isLoadingStreams = false
            }
        }
    }

    LaunchedEffect(currentChannelId) {
        fetchStream()
    }

    BackHandler {
        if (isLandscape) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            onBack()
        }
    }

    fun toggleFullscreen() {
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    // Portrait: video 16:9 di atas, panel episode di bawah. Landscape: video memenuhi layar.
    val playerBoxModifier = if (isLandscape) {
        Modifier.fillMaxSize()
    } else {
        Modifier
            .statusBarsPadding()
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("video_player_container")
    ) {
        Box(modifier = playerBoxModifier) {
            if (isLoadingStreams) {
                GearProgressIndicator(
                    progress = 75,
                    statusText = "Menyiapkan video...",
                    size = 56.dp,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (keysBlocked) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Kunci habis", color = KuroTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "Tonton iklan untuk +3 kunci. 1 episode baru memakai 1 kunci.",
                        color = KuroTextSecondary,
                        fontSize = 12.sp
                    )
                    Button(
                        enabled = !adBusy,
                        onClick = {
                            val act = activity ?: return@Button
                            adBusy = true
                            AdManager.show(
                                act,
                                onReward = {
                                    coroutineScope.launch {
                                        repository.grantAdKeys()
                                        adBusy = false
                                        fetchStream()
                                    }
                                },
                                onFail = { msg ->
                                    adBusy = false
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    ) { Text("Tonton iklan (+3 kunci)") }
                    TextButton(onClick = onBack) { Text("Kembali", color = KuroTextSecondary) }
                }
            } else if (streamError != null) {
                ErrorStateView(
                    message = streamError ?: "Gagal memutar",
                    onRetry = { fetchStream() },
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            keepScreenOn = true
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { isControlsVisible = !isControlsVisible }
                )

                if (isPlayerBuffering) {
                    CircularProgressIndicator(
                        color = KuroTextPrimary,
                        modifier = Modifier
                            .size(40.dp)
                            .align(Alignment.Center)
                    )
                }

                AnimatedVisibility(
                    visible = isControlsVisible,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(if (isLandscape) 16.dp else 8.dp)
                    ) {
                        // Bar atas
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopStart),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                if (isLandscape) {
                                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                } else {
                                    onBack()
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Kembali",
                                    tint = Color.White
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = animeTitle,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Episode $currentEp",
                                    color = KuroTextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            if (availableStreams.size > 1) {
                                Surface(
                                    color = KuroSurfaceElevated,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, KuroBorder),
                                    modifier = Modifier.clickable { showQualityDialog = true }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.HighQuality,
                                            contentDescription = "Kualitas",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = selectedStream?.name ?: "Kualitas",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Kontrol tengah: prev, -10, play/pause, +10, next
                        Row(
                            modifier = Modifier.align(Alignment.Center),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(if (isLandscape) 28.dp else 10.dp)
                        ) {
                            IconButton(
                                onClick = { prevEpisode?.let { playEpisode(it) } },
                                enabled = prevEpisode != null,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipPrevious,
                                    contentDescription = "Episode sebelumnya",
                                    tint = if (prevEpisode != null) Color.White else Color.White.copy(alpha = 0.3f),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            IconButton(
                                onClick = {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0L))
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Replay10,
                                    contentDescription = "Mundur 10s",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                modifier = Modifier
                                    .size(52.dp)
                                    .clickable {
                                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    }
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = Color.Black,
                                    modifier = Modifier
                                        .padding(11.dp)
                                        .fillMaxSize()
                                )
                            }

                            IconButton(
                                onClick = {
                                    val limit = if (durationMs > 0) durationMs else Long.MAX_VALUE
                                    exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(limit))
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Forward10,
                                    contentDescription = "Maju 10s",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            IconButton(
                                onClick = { nextEpisode?.let { playEpisode(it) } },
                                enabled = nextEpisode != null,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Episode berikutnya",
                                    tint = if (nextEpisode != null) Color.White else Color.White.copy(alpha = 0.3f),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        // Bar bawah: waktu, timeline, fullscreen
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${formatTime(currentPositionMs)} / ${formatTime(durationMs)}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Slider(
                                value = if (durationMs > 0) {
                                    (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                                } else 0f,
                                onValueChange = { fraction ->
                                    val target = (fraction * durationMs).toLong()
                                    currentPositionMs = target
                                    exoPlayer.seekTo(target)
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = Color.White,
                                    inactiveTrackColor = Color.Gray.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )
                            IconButton(onClick = { toggleFullscreen() }) {
                                Icon(
                                    imageVector = if (isLandscape) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                    contentDescription = "Fullscreen",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // ===== Panel di bawah video (portrait) =====
        if (!isLandscape) {
            val listState = rememberLazyListState()
            LaunchedEffect(episodes, currentEp) {
                val idx = episodes.indexOfFirst { it.ch == currentEp }
                if (idx >= 0) listState.animateScrollToItem(idx)
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(KuroBgPrimary)
                    .padding(top = 14.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = animeTitle,
                        color = KuroTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Episode $currentEp",
                        color = KuroTextSecondary,
                        fontSize = 13.sp
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Auto next", color = KuroTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = autoNext,
                        onCheckedChange = { coroutineScope.launch { preferences.setAutoNext(it) } },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = KuroBgPrimary,
                            checkedTrackColor = KuroTextPrimary,
                            uncheckedThumbColor = KuroTextSecondary,
                            uncheckedTrackColor = KuroSurfaceElevated
                        )
                    )
                }

                Text(
                    text = "Daftar Episode",
                    color = KuroTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (episodes.isEmpty()) {
                    Text(
                        text = "Memuat daftar episode...",
                        color = KuroTextTertiary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                } else {
                    LazyRow(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(episodes) { _, ep ->
                            val selected = ep.ch == currentEp
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (selected) KuroTextPrimary else KuroSurface,
                                border = BorderStroke(1.dp, if (selected) KuroTextPrimary else KuroBorder),
                                modifier = Modifier
                                    .clickable { if (!selected) playEpisode(ep) }
                                    .testTag("player_episode_${ep.ch}")
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .widthIn(min = 52.dp)
                                        .padding(horizontal = 14.dp, vertical = 12.dp)
                                ) {
                                    Text(
                                        text = ep.ch,
                                        color = if (selected) KuroBgPrimary else KuroTextPrimary,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            containerColor = KuroSurfaceElevated,
            title = {
                Text(
                    text = "Pilih Resolusi Video",
                    fontWeight = FontWeight.Bold,
                    color = KuroTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    availableStreams.forEach { stream ->
                        val isSelected = selectedStream == stream
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) KuroTextPrimary else KuroSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedStream = stream
                                    showQualityDialog = false
                                    val currentPos = exoPlayer.currentPosition
                                    val playUrl = NetworkClient.resolveStreamUrl(stream.link)
                                    exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(playUrl)))
                                    exoPlayer.prepare()
                                    exoPlayer.seekTo(currentPos)
                                    exoPlayer.play()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = stream.name,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) KuroBgPrimary else KuroTextPrimary
                                )
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = KuroBgPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) {
                    Text("Tutup", color = KuroTextSecondary)
                }
            }
        )
    }
}

private fun formatTime(millis: Long): String {
    val totalSeconds = (millis / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val hours = minutes / 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes % 60, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }
}
