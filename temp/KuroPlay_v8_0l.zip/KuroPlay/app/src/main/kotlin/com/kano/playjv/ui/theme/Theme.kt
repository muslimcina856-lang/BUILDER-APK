package com.kano.playjv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val KuroColorScheme = darkColorScheme(
    primary = KuroAccent,
    onPrimary = KuroBgPrimary,
    primaryContainer = KuroSurfaceElevated,
    onPrimaryContainer = KuroTextPrimary,
    secondary = KuroAccentSecondary,
    onSecondary = KuroBgPrimary,
    secondaryContainer = KuroSurface,
    onSecondaryContainer = KuroTextPrimary,
    tertiary = KuroTextSecondary,
    onTertiary = KuroBgPrimary,
    background = KuroBgPrimary,
    onBackground = KuroTextPrimary,
    surface = KuroSurface,
    onSurface = KuroTextPrimary,
    surfaceVariant = KuroSurfaceElevated,
    onSurfaceVariant = KuroTextSecondary,
    outline = KuroBorder,
    outlineVariant = KuroBorder,
    error = KuroError,
    onError = KuroTextPrimary
)

@Composable
fun KuroPlayTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KuroColorScheme,
        typography = Typography,
        content = content
    )
}
