package com.kano.playjv.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.kano.playjv.core.model.AnimeBookmarkItem
import com.kano.playjv.core.model.AnimeHistoryItem
import com.kano.playjv.core.model.MangaBookmarkItem
import com.kano.playjv.core.model.MangaHistoryItem

@Entity(tableName = "anime_history", primaryKeys = ["slug", "userUid"])
data class AnimeHistoryEntity(
    val slug: String,
    val userUid: String,
    val title: String,
    val cover: String,
    val lastEp: String,
    val seriesUrl: String,
    val timestamp: Long
) {
    fun toModel() = AnimeHistoryItem(
        slug = slug,
        title = title,
        cover = cover,
        lastEp = lastEp,
        seriesUrl = seriesUrl,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(model: AnimeHistoryItem, userUid: String) = AnimeHistoryEntity(
            slug = model.slug,
            userUid = userUid,
            title = model.title,
            cover = model.cover,
            lastEp = model.lastEp,
            seriesUrl = model.seriesUrl,
            timestamp = model.timestamp
        )
    }
}

@Entity(tableName = "anime_bookmark", primaryKeys = ["slug", "userUid"])
data class AnimeBookmarkEntity(
    val slug: String,
    val userUid: String,
    val title: String,
    val cover: String,
    val timestamp: Long
) {
    fun toModel() = AnimeBookmarkItem(
        slug = slug,
        title = title,
        cover = cover,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(model: AnimeBookmarkItem, userUid: String) = AnimeBookmarkEntity(
            slug = model.slug,
            userUid = userUid,
            title = model.title,
            cover = model.cover,
            timestamp = model.timestamp
        )
    }
}

@Entity(tableName = "manga_history", primaryKeys = ["id_series", "userUid"])
data class MangaHistoryEntity(
    val id_series: String,
    val userUid: String,
    val title: String,
    val image: String,
    val lastChapter: Double,
    val id_chapter: String,
    val time: Long
) {
    fun toModel() = MangaHistoryItem(
        id_series = id_series,
        title = title,
        image = image,
        lastChapter = lastChapter,
        id_chapter = id_chapter,
        time = time
    )

    companion object {
        fun fromModel(model: MangaHistoryItem, userUid: String) = MangaHistoryEntity(
            id_series = model.id_series,
            userUid = userUid,
            title = model.title,
            image = model.image,
            lastChapter = model.lastChapter,
            id_chapter = model.id_chapter,
            time = model.time
        )
    }
}

@Entity(tableName = "manga_bookmark", primaryKeys = ["id_series", "userUid"])
data class MangaBookmarkEntity(
    val id_series: String,
    val userUid: String,
    val title: String,
    val image: String,
    val timestamp: Long
) {
    fun toModel() = MangaBookmarkItem(
        id_series = id_series,
        title = title,
        image = image,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(model: MangaBookmarkItem, userUid: String) = MangaBookmarkEntity(
            id_series = model.id_series,
            userUid = userUid,
            title = model.title,
            image = model.image,
            timestamp = model.timestamp
        )
    }
}
