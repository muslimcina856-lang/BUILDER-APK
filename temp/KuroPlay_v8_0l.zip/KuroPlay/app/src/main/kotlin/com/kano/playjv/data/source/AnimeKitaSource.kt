package com.kano.playjv.data.source

import com.kano.playjv.core.model.AnimeDetail
import com.kano.playjv.core.model.AnimeEpisode
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.core.model.EpisodeStreamData
import com.kano.playjv.core.model.StreamSource
import com.kano.playjv.core.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Sumber anime: API AnimeKita (sama seperti yang dipakai worker lama), dipanggil langsung dari aplikasi.
 */
object AnimeKitaSource {
    private const val BASE = "https://apps.animekita.org/api/v1.2.5"
    private const val UA = "Dart/3.9 (dart:io)"

    // Filter judul non-anime (disalin dari worker lama)
    private val nonAnimeKeywords = listOf(
        "kamen rider", "kamenrider", "kamen-raider", "super sentai", "supersentai", "sentai",
        "ultraman", "ultra man", "power rangers", "power ranger", "tokusatsu", "kaiju", "garo",
        "ryukendo", "metal hero", "metal heroes", "beetleborgs", "masked rider", "mystic knights",
        "tattooed teen", "live action", "ben 10", "teen titans", "avatar the last airbender",
        "spongebob", "regular show", "adventure time", "soul land", "battle through the heavens",
        "perfect world", "throne of seal", "douluo dalu", "swallowed star", "renegade immortal",
        "against the gods", "martial universe", "tales of demons and gods", "stellar transformations",
        "coiling dragon", "the great ruler", "wu dong qian kun"
    )

    private fun isAnime(title: String): Boolean {
        val t = title.lowercase().trim()
        return t.isNotEmpty() && nonAnimeKeywords.none { t.contains(it) }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(BASE + path)
            .header("User-Agent", UA).header("Accept", "application/json").build()
        NetworkClient.httpClient.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw Exception("AnimeKita HTTP ${res.code}")
            res.body?.string().orEmpty()
        }
    }

    private suspend fun post(path: String, form: Map<String, String>): String = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().apply { form.forEach { (k, v) -> add(k, v) } }.build()
        val req = Request.Builder().url(BASE + path)
            .header("User-Agent", UA).header("Accept", "application/json").post(body).build()
        NetworkClient.httpClient.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw Exception("AnimeKita HTTP ${res.code}")
            res.body?.string().orEmpty()
        }
    }

    private fun JSONObject.str(key: String): String =
        if (isNull(key)) "" else optString(key, "")

    /** Genre bisa berupa array string, array objek, atau string dipisah koma. */
    internal fun parseGenres(any: Any?): List<String> {
        val out = mutableListOf<String>()
        when (any) {
            is JSONArray -> for (i in 0 until any.length()) {
                when (val e = any.opt(i)) {
                    is String -> out += e
                    is JSONObject -> out += listOf("name", "nama", "genre", "title").map { e.str(it) }.firstOrNull { it.isNotBlank() } ?: ""
                }
            }
            is String -> out += any.split(",", "/")
        }
        return out.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }

    private fun parseItems(arr: JSONArray?, status: String?): List<AnimeItem> {
        if (arr == null) return emptyList()
        val list = mutableListOf<AnimeItem>()
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            val judul = a.str("judul")
            if (!isAnime(judul)) continue
            list += AnimeItem(
                judul = judul,
                cover = a.str("cover"),
                url = a.str("url"),
                lastch = a.str("lastch"),
                type = "TV",
                status = status ?: a.str("status"),
                score = a.str("score").ifBlank { "-" },
                rating = a.str("score").ifBlank { "-" },
                sinopsis = a.str("sinopsis"),
                genre = parseGenres(a.opt("genre"))
            )
        }
        return list
    }

    suspend fun ongoing(page: Int): List<AnimeItem> {
        val raw = JSONArray(get("/home/ongoing.php?page=$page&type=all"))
        return parseItems(raw, "Ongoing")
    }

    suspend fun search(query: String, page: Int, count: Int = 20): List<AnimeItem> {
        val raw = JSONObject(get("/search.php?keyword=${enc(query)}&page=$page&per_page=$count"))
        val arr = raw.optJSONArray("data")?.optJSONObject(0)?.optJSONArray("result")
        return parseItems(arr, null)
    }

    suspend fun detail(id: String): AnimeDetail {
        val raw = JSONObject(
            post(
                "/series.php?url=${enc(id)}",
                mapOf("get" to "top", "post_type" to "1", "post_id" to id, "token" to "")
            )
        )
        val a = raw.optJSONArray("data")?.optJSONObject(0) ?: throw Exception("Anime tidak ditemukan")
        val seriesId = a.str("series_id").ifBlank { id }
        val chapters = mutableListOf<AnimeEpisode>()
        a.optJSONArray("chapter")?.let { arr ->
            for (i in 0 until arr.length()) {
                val ch = arr.optJSONObject(i) ?: continue
                chapters += AnimeEpisode(
                    ch = ch.str("ch"),
                    url = listOf(ch.str("id"), seriesId, ch.str("url"), ch.str("ch")).joinToString("|")
                )
            }
        }
        return AnimeDetail(
            judul = a.str("judul"),
            cover = a.str("cover"),
            sinopsis = a.str("sinopsis").take(600),
            rating = a.str("rating").ifBlank { "-" },
            type = a.str("type").ifBlank { "TV" },
            status = a.str("status"),
            published = a.str("published"),
            series_id = seriesId,
            genre = parseGenres(a.opt("genre")),
            chapter = chapters
        )
    }

    /** channelId format: epId|seriesUrl|epUrl|epNumDisplay */
    suspend fun episodeStreams(channelId: String): EpisodeStreamData {
        val parts = channelId.split("|")
        if (parts.size < 4) throw Exception("Format channel_id salah")
        val (epId, seriesUrl, epUrl, epNumDisplay) = parts
        val epNumNumeric = Regex("^(\\d+)").find(epNumDisplay)?.groupValues?.get(1) ?: "1"

        val raw = JSONObject(
            post(
                "/series/episode/data.php?url=${enc(epUrl)}",
                mapOf(
                    "post_type" to "2", "post_id" to epId, "series_id" to seriesUrl,
                    "series_url" to seriesUrl, "episode" to epNumNumeric, "token" to ""
                )
            )
        )
        val epData = raw.optJSONArray("data")?.optJSONObject(0)
        val streamsObj = epData?.optJSONObject("streams") ?: throw Exception("Stream tidak ditemukan")

        val streams = mutableListOf<StreamSource>()
        for (reso in listOf("720p", "480p", "360p")) {
            val arr = streamsObj.optJSONArray(reso) ?: continue
            if (arr.length() == 0) continue
            var chosen: JSONObject? = null
            for (preferred in listOf(871, 99)) {
                for (i in 0 until arr.length()) {
                    val s = arr.optJSONObject(i) ?: continue
                    if (s.optInt("provide", -1) == preferred) { chosen = s; break }
                }
                if (chosen != null) break
            }
            if (chosen == null) chosen = arr.optJSONObject(0)
            val link = chosen?.str("link").orEmpty()
            if (link.isNotBlank()) streams += StreamSource(name = reso, link = link)
        }
        if (streams.isEmpty()) throw Exception("Tidak ada link video")
        return EpisodeStreamData(title = "Episode $epNumDisplay", streams = mapOf("Server" to streams))
    }
}
