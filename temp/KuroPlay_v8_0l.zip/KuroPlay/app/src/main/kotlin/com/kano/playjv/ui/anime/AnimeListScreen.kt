package com.kano.playjv.ui.anime

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.AnimeItem
import com.kano.playjv.data.repository.AnimePage
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.home.AnimeCard
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Genre difilter di sisi aplikasi (API AnimeKita tidak punya filter genre)
private val ANIME_GENRES = listOf(
    "Action", "Adventure", "Comedy", "Fantasy", "Romance", "Sci-Fi", "Slice of Life",
    "Supernatural", "School", "Shounen", "Seinen", "Mystery", "Horror", "Sports",
    "Isekai", "Mecha", "Psychological", "Thriller", "Magic", "Harem"
)

@Composable
fun AnimeListScreen(
    repository: KuroRepository,
    onNavigateToDetail: (String) -> Unit
) {
    var selectedTab by remember { mutableStateOf("ongoing") } // "ongoing" atau "popular"
    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var currentPage by remember { mutableIntStateOf(1) }

    var animeList by remember { mutableStateOf<List<AnimeItem>>(emptyList()) }
    var hasNext by remember { mutableStateOf(true) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var loadJob by remember { mutableStateOf<Job?>(null) }

    fun loadAnime() {
        loadJob?.cancel()
        loadJob = coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res: Result<AnimePage> = if (searchQuery.isNotBlank()) {
                repository.searchAnime(searchQuery, currentPage).map { AnimePage(it, it.size >= 10) }
            } else {
                repository.getAnimePage(selectedTab, selectedGenre, currentPage)
            }
            if (res.isSuccess) {
                val page = res.getOrThrow()
                animeList = page.items
                hasNext = page.hasNext
            } else {
                animeList = emptyList()
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat anime"
            }
            isLoading = false
        }
    }

    // Satu-satunya pemicu muat ulang saat tab/genre/halaman berubah
    LaunchedEffect(selectedTab, selectedGenre, currentPage) {
        if (searchQuery.isBlank()) loadAnime()
    }

    val heavyMode = searchQuery.isBlank() && (selectedGenre != null || selectedTab == "popular")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { query ->
                searchQuery = query
                searchJob?.cancel()
                searchJob = coroutineScope.launch {
                    delay(400) // debounce
                    currentPage = 1
                    loadAnime()
                }
            },
            placeholder = { Text("Cari judul anime...", color = KuroTextTertiary) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = KuroTextSecondary)
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = {
                        searchQuery = ""
                        currentPage = 1
                        loadAnime()
                    }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = KuroTextSecondary)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = KuroSurface,
                unfocusedContainerColor = KuroSurface,
                focusedBorderColor = KuroTextPrimary,
                unfocusedBorderColor = KuroBorder,
                focusedTextColor = KuroTextPrimary,
                unfocusedTextColor = KuroTextPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("anime_search_field")
        )

        if (searchQuery.isBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterTabChip(
                    title = "Ongoing",
                    selected = selectedTab == "ongoing" && selectedGenre == null,
                    onClick = {
                        selectedTab = "ongoing"
                        selectedGenre = null
                        currentPage = 1
                    }
                )
                FilterTabChip(
                    title = "Populer",
                    selected = selectedTab == "popular" && selectedGenre == null,
                    onClick = {
                        selectedTab = "popular"
                        selectedGenre = null
                        currentPage = 1
                    }
                )
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ANIME_GENRES) { genre ->
                    val isSelected = selectedGenre == genre
                    FilterTabChip(
                        title = genre,
                        selected = isSelected,
                        onClick = {
                            selectedGenre = if (isSelected) null else genre
                            currentPage = 1
                        }
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (isLoading && animeList.isEmpty()) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(6) { SkeletonCard(height = 210.dp) }
                }
            } else if (errorMessage != null && animeList.isEmpty()) {
                ErrorStateView(
                    message = errorMessage ?: "Terjadi kesalahan",
                    onRetry = { loadAnime() },
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (!isLoading && animeList.isEmpty()) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    EmptyStateView(
                        message = when {
                            searchQuery.isNotBlank() -> "Anime \"$searchQuery\" tidak ditemukan"
                            selectedGenre != null && currentPage == 1 ->
                                "Tidak ada anime bergenre $selectedGenre di daftar anime terbaru"
                            currentPage > 1 -> "Tidak ada halaman berikutnya"
                            else -> "Daftar anime kosong"
                        }
                    )
                    if (currentPage > 1) {
                        PaginationBar(
                            currentPage = currentPage,
                            hasNext = false,
                            onPrevious = { currentPage-- },
                            onNext = {}
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("anime_grid_list")
                ) {
                    items(animeList, key = { it.url }) { anime ->
                        AnimeCard(
                            anime = anime,
                            onClick = { onNavigateToDetail(anime.url) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item(span = { GridItemSpan(maxLineSpan) }) {
                        PaginationBar(
                            currentPage = currentPage,
                            hasNext = hasNext,
                            onPrevious = { if (currentPage > 1) currentPage-- },
                            onNext = { if (hasNext) currentPage++ }
                        )
                    }
                }
            }

            GearLoadingOverlay(
                isLoading = isLoading && animeList.isNotEmpty(),
                statusText = if (heavyMode) "Menyiapkan data genre/populer (pertama kali agak lama)..." else "Memuat anime...",
                onCancel = {
                    loadJob?.cancel()
                    isLoading = false
                }
            )
        }
    }
}

@Composable
private fun PaginationBar(
    currentPage: Int,
    hasNext: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(
            onClick = onPrevious,
            enabled = currentPage > 1,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = KuroTextPrimary),
            border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder)
        ) {
            Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Sebelumnya")
            Text("Sebelumnya", maxLines = 1)
        }

        Text(
            text = "Hal $currentPage",
            color = KuroTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 14.dp)
        )

        OutlinedButton(
            onClick = onNext,
            enabled = hasNext,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = KuroTextPrimary),
            border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder)
        ) {
            Text("Berikutnya", maxLines = 1)
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Berikutnya")
        }
    }
}

@Composable
fun FilterTabChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) KuroTextPrimary else KuroSurface,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) KuroTextPrimary else KuroBorder),
        modifier = Modifier
            .clickable { onClick() }
            .testTag("filter_tab_$title")
    ) {
        Text(
            text = title,
            color = if (selected) KuroBgPrimary else KuroTextSecondary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}
