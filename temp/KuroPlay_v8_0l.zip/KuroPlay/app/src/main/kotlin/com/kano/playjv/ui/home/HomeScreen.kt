package com.kano.playjv.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.*
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    repository: KuroRepository,
    currentUid: String,
    onNavigateToAnimeDetail: (String) -> Unit,
    onNavigateToMangaDetail: (String) -> Unit,
    onNavigateToPlayer: (slug: String, epNumber: String, channelId: String, title: String) -> Unit,
    onNavigateToReader: (idSeries: String, idChapter: String, title: String) -> Unit,
    onNavigateToAnimeTab: () -> Unit,
    onNavigateToMangaTab: () -> Unit
) {
    var ongoingAnime by remember { mutableStateOf<List<AnimeItem>>(emptyList()) }
    var popularManga by remember { mutableStateOf<List<MangaItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val animeHistory by repository.getAnimeHistoryFlow(currentUid).collectAsState(initial = emptyList())
    val mangaHistory by repository.getMangaHistoryFlow(currentUid).collectAsState(initial = emptyList())

    val coroutineScope = rememberCoroutineScope()

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null

            val animeRes = repository.getAnimeList("ongoing", 1)
            val mangaRes = repository.getPopularManga()

            if (animeRes.isSuccess && mangaRes.isSuccess) {
                ongoingAnime = animeRes.getOrDefault(emptyList())
                popularManga = mangaRes.getOrDefault(emptyList())
                isLoading = false
            } else {
                errorMessage = animeRes.exceptionOrNull()?.message
                    ?: mangaRes.exceptionOrNull()?.message
                    ?: "Gagal memuat beranda"
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KuroBgPrimary)
    ) {
        if (isLoading && ongoingAnime.isEmpty()) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                item {
                    Text(
                        "Memuat Rekomendasi...",
                        color = KuroTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        repeat(3) {
                            SkeletonCard(modifier = Modifier.width(130.dp), height = 190.dp)
                        }
                    }
                }
                item {
                    Text(
                        "Manga Populer...",
                        color = KuroTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        repeat(3) {
                            SkeletonCard(modifier = Modifier.width(130.dp), height = 190.dp)
                        }
                    }
                }
            }
        } else if (errorMessage != null && ongoingAnime.isEmpty()) {
            ErrorStateView(
                message = errorMessage ?: "Terjadi kesalahan jaringan",
                onRetry = { loadData() },
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_content_list"),
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                // Section: Continue Watching
                if (animeHistory.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title = "Lanjut Menonton",
                            badgeText = "Riwayat",
                            onSeeAllClick = null
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(animeHistory, key = { it.slug }) { item ->
                                HistoryAnimeCard(
                                    item = item,
                                    onClick = { onNavigateToAnimeDetail(item.slug) }
                                )
                            }
                        }
                    }
                }

                // Section: Continue Reading
                if (mangaHistory.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title = "Lanjut Membaca",
                            badgeText = "Komik",
                            onSeeAllClick = null
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(mangaHistory, key = { it.id_series }) { item ->
                                HistoryMangaCard(
                                    item = item,
                                    onClick = { onNavigateToMangaDetail(item.id_series) }
                                )
                            }
                        }
                    }
                }

                // Section: Featured Ongoing Anime
                if (ongoingAnime.isNotEmpty()) {
                    val featured = ongoingAnime.firstOrNull()
                    if (featured != null) {
                        item {
                            FeaturedAnimeBanner(
                                anime = featured,
                                onClick = { onNavigateToAnimeDetail(featured.url) }
                            )
                        }
                    }

                    item {
                        HomeSectionHeader(
                            title = "Anime Ongoing",
                            badgeText = "Update",
                            onSeeAllClick = onNavigateToAnimeTab
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(ongoingAnime.take(15), key = { it.url }) { anime ->
                                AnimeCard(
                                    anime = anime,
                                    onClick = { onNavigateToAnimeDetail(anime.url) }
                                )
                            }
                        }
                    }
                }

                // Section: Popular Manga
                if (popularManga.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title = "Manga Populer",
                            badgeText = "MangaDex",
                            onSeeAllClick = onNavigateToMangaTab
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(popularManga.take(15), key = { it.id_series }) { manga ->
                                MangaCard(
                                    manga = manga,
                                    onClick = { onNavigateToMangaDetail(manga.id_series) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeSectionHeader(
    title: String,
    badgeText: String? = null,
    onSeeAllClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                color = KuroTextPrimary
            )
            if (badgeText != null) {
                StatusBadge(text = badgeText)
            }
        }

        if (onSeeAllClick != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { onSeeAllClick() }
                    .padding(4.dp)
            ) {
                Text(
                    text = "Semua",
                    fontSize = 12.sp,
                    color = KuroTextSecondary,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Lihat Semua",
                    tint = KuroTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun FeaturedAnimeBanner(
    anime: AnimeItem,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(200.dp)
            .clickable { onClick() }
            .testTag("featured_anime_banner")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = anime.cover,
                contentDescription = anime.judul,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                KuroBgPrimary.copy(alpha = 0.5f),
                                KuroBgPrimary.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusBadge(text = "ONGOING", color = KuroSurfaceElevated)
                    if (anime.lastch.isNotBlank()) {
                        StatusBadge(text = anime.lastch)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = anime.judul,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    ),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Surface(
                shape = CircleShape,
                color = KuroTextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(42.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Tonton",
                    tint = KuroBgPrimary,
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun AnimeCard(
    anime: AnimeItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = modifier
            .width(135.dp)
            .clickable { onClick() }
            .testTag("anime_card_${anime.url}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
            ) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = anime.judul,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (anime.lastch.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                    ) {
                        StatusBadge(text = anime.lastch)
                    }
                }
            }
            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = anime.judul,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    ),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    minLines = 2
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = anime.type.ifBlank { "TV" },
                        fontSize = 10.sp,
                        color = KuroTextTertiary
                    )
                    Text(
                        text = anime.status.ifBlank { "Ongoing" },
                        fontSize = 10.sp,
                        color = KuroTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun MangaCard(
    manga: MangaItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = modifier
            .width(135.dp)
            .clickable { onClick() }
            .testTag("manga_card_${manga.id_series}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
            ) {
                AsyncImage(
                    model = manga.image,
                    contentDescription = manga.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                val ch = manga.latestChapters.firstOrNull()?.chapter
                if (!ch.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                    ) {
                        StatusBadge(text = "Ch. $ch")
                    }
                }
            }
            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = manga.title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    ),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    minLines = 2
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "MangaDex",
                    fontSize = 10.sp,
                    color = KuroTextTertiary
                )
            }
        }
    }
}

@Composable
fun HistoryAnimeCard(
    item: AnimeHistoryItem,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = Modifier
            .width(170.dp)
            .clickable { onClick() }
            .testTag("history_anime_${item.slug}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AsyncImage(
                model = item.cover,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(54.dp, 70.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (item.lastEp.isNotBlank()) "Ep ${item.lastEp}" else "Tonton",
                    fontSize = 11.sp,
                    color = KuroGold,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun HistoryMangaCard(
    item: MangaHistoryItem,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = Modifier
            .width(170.dp)
            .clickable { onClick() }
            .testTag("history_manga_${item.id_series}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AsyncImage(
                model = item.image,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(54.dp, 70.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = KuroTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (item.lastChapter > 0) "Ch. ${item.lastChapter}" else "Baca",
                    fontSize = 11.sp,
                    color = KuroTextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
