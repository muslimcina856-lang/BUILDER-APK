package com.kano.playjv.ui.manga

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kano.playjv.core.components.*
import com.kano.playjv.core.model.MangaBookmarkItem
import com.kano.playjv.core.model.MangaChapterItem
import com.kano.playjv.core.model.MangaDetail
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun MangaDetailScreen(
    idSeries: String,
    repository: KuroRepository,
    currentUid: String,
    onBack: () -> Unit,
    onReadChapter: (idSeries: String, idChapter: String, chapterTitle: String) -> Unit
) {
    BackHandler { onBack() }

    var mangaDetail by remember { mutableStateOf<MangaDetail?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSynopsisExpanded by remember { mutableStateOf(false) }

    val isBookmarked by repository.isMangaBookmarkedFlow(idSeries, currentUid).collectAsState(initial = false)
    val coroutineScope = rememberCoroutineScope()

    fun loadDetail() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res = repository.getMangaDetail(idSeries)
            if (res.isSuccess) {
                mangaDetail = res.getOrNull()
                isLoading = false
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat detail komik"
                isLoading = false
            }
        }
    }

    LaunchedEffect(idSeries) {
        loadDetail()
    }

    Scaffold(
        topBar = {
            Surface(
                color = KuroBgPrimary,
                border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("manga_detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali",
                            tint = KuroTextPrimary
                        )
                    }
                    Text(
                        text = mangaDetail?.title ?: "Detail Komik",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = KuroTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    mangaDetail?.let { detail ->
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    repository.toggleMangaBookmark(
                                        MangaBookmarkItem(
                                            id_series = idSeries,
                                            title = detail.title,
                                            image = detail.image
                                        ),
                                        isBookmarked
                                    )
                                }
                            },
                            modifier = Modifier.testTag("manga_bookmark_button")
                        ) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = if (isBookmarked) KuroGold else KuroTextPrimary
                            )
                        }
                    }
                }
            }
        },
        containerColor = KuroBgPrimary
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isLoading && mangaDetail == null) {
                GearProgressIndicator(
                    progress = 60,
                    statusText = "Memuat detail komik...",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (errorMessage != null && mangaDetail == null) {
                ErrorStateView(
                    message = errorMessage ?: "Terjadi kesalahan",
                    onRetry = { loadDetail() },
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (mangaDetail != null) {
                val detail = mangaDetail!!

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("manga_detail_content"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Banner with Poster + Info
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            AsyncImage(
                                model = detail.image,
                                contentDescription = detail.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, KuroBorder, RoundedCornerShape(10.dp))
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = detail.title,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = KuroTextPrimary
                                )

                                val statusLabel = when (detail.info?.status) {
                                    1 -> "Ongoing"
                                    2 -> "Completed"
                                    3 -> "Hiatus"
                                    4 -> "Cancelled"
                                    else -> "Ongoing"
                                }
                                StatusBadge(text = statusLabel)

                                // Genres
                                if (detail.genres.isNotEmpty()) {
                                    Text(
                                        text = detail.genres.take(3).joinToString(", "),
                                        fontSize = 11.sp,
                                        color = KuroTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Synopsis
                    if (detail.synopsis.isNotBlank()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = KuroSurface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isSynopsisExpanded = !isSynopsisExpanded }
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Sinopsis",
                                        fontWeight = FontWeight.Bold,
                                        color = KuroTextPrimary,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = detail.synopsis,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = KuroTextSecondary,
                                        maxLines = if (isSynopsisExpanded) Int.MAX_VALUE else 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (isSynopsisExpanded) "Tutup" else "Baca selengkapnya...",
                                        color = KuroTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Chapters Header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Daftar Chapter",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = KuroTextPrimary
                            )
                            Text(
                                text = "${detail.chapters.size} Chapter",
                                fontSize = 12.sp,
                                color = KuroTextSecondary
                            )
                        }
                    }

                    // Chapter Items
                    if (detail.chapters.isEmpty()) {
                        item {
                            EmptyStateView(message = "Belum ada chapter Bahasa Indonesia")
                        }
                    } else {
                        items(detail.chapters, key = { it.id_chapter }) { ch ->
                            ChapterRowItem(
                                chapter = ch,
                                onClick = { onReadChapter(idSeries, ch.id_chapter, ch.title) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterRowItem(
    chapter: MangaChapterItem,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = KuroSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("chapter_item_${chapter.id_chapter}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = KuroSurfaceElevated,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoStories,
                        contentDescription = "Read",
                        tint = KuroTextPrimary,
                        modifier = Modifier
                            .padding(6.dp)
                            .fillMaxSize()
                    )
                }
                Column {
                    Text(
                        text = chapter.title.ifBlank { "Chapter ${chapter.number}" },
                        fontWeight = FontWeight.SemiBold,
                        color = KuroTextPrimary,
                        fontSize = 14.sp
                    )
                    if (chapter.time.isNotBlank()) {
                        Text(
                            text = chapter.time,
                            fontSize = 11.sp,
                            color = KuroTextTertiary
                        )
                    }
                }
            }

            Text(
                text = "Baca",
                color = KuroTextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
