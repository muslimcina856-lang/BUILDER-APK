package com.kano.playjv.ui.theme

import androidx.compose.ui.graphics.Color

val KuroBgPrimary = Color(0xFF080808)
val KuroBgSecondary = Color(0xFF101010)
val KuroSurface = Color(0xFF171717)
val KuroSurfaceElevated = Color(0xFF202020)
val KuroBorder = Color(0xFF2C2C2C)
val KuroTextPrimary = Color(0xFFF5F5F5)
val KuroTextSecondary = Color(0xFFA3A3A3)
val KuroTextTertiary = Color(0xFF747474)
val KuroAccent = Color(0xFFFFFFFF)
val KuroAccentSecondary = Color(0xFFE0E0E0)
val KuroError = Color(0xFFFF4A4A)
val KuroGold = Color(0xFFFFD700)
val KuroSuccess = Color(0xFF4CAF50)
