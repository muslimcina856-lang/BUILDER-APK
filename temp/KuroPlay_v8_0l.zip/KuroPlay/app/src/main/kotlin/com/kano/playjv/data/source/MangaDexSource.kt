package com.kano.playjv.data.source

import com.kano.playjv.core.model.MangaChapterItem
import com.kano.playjv.core.model.MangaChapterPages
import com.kano.playjv.core.model.MangaDetail
import com.kano.playjv.core.model.MangaGenre
import com.kano.playjv.core.model.MangaInfo
import com.kano.playjv.core.model.MangaItem
import com.kano.playjv.core.model.MangaLatestChapter
import com.kano.playjv.core.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.OffsetDateTime

/**
 * Sumber manga: API MangaDex (sama seperti yang dipakai worker lama), dipanggil langsung dari aplikasi.
 */
object MangaDexSource {
    private const val MD = "https://api.mangadex.org"
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    private const val LIST_QUERY =
        "?limit=30&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive&availableTranslatedLanguage[]=id"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun getJson(url: String): JSONObject = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept", "application/json, text/plain, */*")
            .header("Accept-Language", "en-US,en;q=0.9,id;q=0.8")
            .header("Referer", "https://mangadex.org/")
            .header("Origin", "https://mangadex.org")
            .build()
        NetworkClient.httpClient.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw Exception("MangaDex HTTP ${res.code}")
            val text = res.body?.string().orEmpty()
            if (text.trim().startsWith("<")) throw Exception("MangaDex membalas HTML (kemungkinan diblokir)")
            JSONObject(text)
        }
    }

    private fun JSONObject.str(key: String): String =
        if (isNull(key)) "" else optString(key, "")

    private fun firstValue(o: JSONObject?, vararg prefer: String): String {
        if (o == null) return ""
        for (k in prefer) {
            val v = o.str(k)
            if (v.isNotBlank()) return v
        }
        val keys = o.keys()
        while (keys.hasNext()) {
            val v = o.str(keys.next())
            if (v.isNotBlank()) return v
        }
        return ""
    }

    private fun coverUrl(mangaId: String, fileName: String) =
        "https://uploads.mangadex.org/covers/$mangaId/$fileName.512.jpg"

    private fun coverOf(m: JSONObject): String {
        val rels = m.optJSONArray("relationships") ?: return ""
        for (i in 0 until rels.length()) {
            val r = rels.optJSONObject(i) ?: continue
            if (r.str("type") == "cover_art") {
                val fn = r.optJSONObject("attributes")?.str("fileName").orEmpty()
                if (fn.isNotBlank()) return coverUrl(m.str("id"), fn)
            }
        }
        return ""
    }

    private fun mapManga(m: JSONObject): MangaItem {
        val a = m.optJSONObject("attributes")
        val last = a?.str("lastChapter").orEmpty()
        return MangaItem(
            title = firstValue(a?.optJSONObject("title"), "en", "id", "ja").ifBlank { "Untitled" },
            id_series = m.str("id"),
            image = coverOf(m),
            latestChapters = if (last.isNotBlank()) {
                listOf(MangaLatestChapter(chapter = last, id_chapter = a?.str("latestUploadedChapter").orEmpty(), releaseTime = ""))
            } else emptyList()
        )
    }

    private fun mapList(j: JSONObject): List<MangaItem> {
        val arr = j.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map { mapManga(it) }
    }

    private fun timeAgo(ts: String): String {
        return try {
            val d = System.currentTimeMillis() - OffsetDateTime.parse(ts).toInstant().toEpochMilli()
            when {
                d < 60_000 -> "baru saja"
                d < 3_600_000 -> "${d / 60_000} menit lalu"
                d < 86_400_000 -> "${d / 3_600_000} jam lalu"
                d < 604_800_000 -> "${d / 86_400_000} hari lalu"
                else -> ts.take(10)
            }
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun search(q: String): List<MangaItem> {
        if (q.isBlank()) return emptyList()
        return mapList(
            getJson(
                "$MD/manga?title=${enc(q)}&limit=30&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive" +
                    "&contentRating[]=erotica&availableTranslatedLanguage[]=id"
            )
        )
    }

    suspend fun latest() = mapList(getJson("$MD/manga$LIST_QUERY&order[latestUploadedChapter]=desc"))
    suspend fun popular() = mapList(getJson("$MD/manga$LIST_QUERY&order[followedCount]=desc"))
    suspend fun recommended() = mapList(getJson("$MD/manga$LIST_QUERY&order[rating]=desc"))

    suspend fun byGenre(tagId: String): List<MangaItem> {
        if (tagId.isBlank()) return emptyList()
        return mapList(
            getJson(
                "$MD/manga?includedTags[]=$tagId&limit=30&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive" +
                    "&availableTranslatedLanguage[]=id&order[followedCount]=desc"
            )
        )
    }

    suspend fun genres(): List<MangaGenre> {
        val arr = getJson("$MD/manga/tag").optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<MangaGenre>()
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue
            val a = t.optJSONObject("attributes") ?: continue
            if (a.str("group") == "genre") {
                out += MangaGenre(id = t.str("id"), name = a.optJSONObject("name")?.str("en").orEmpty())
            }
        }
        return out
    }

    suspend fun detail(id: String): MangaDetail {
        val j = getJson("$MD/manga/$id?includes[]=cover_art&includes[]=author&includes[]=artist")
        val m = j.optJSONObject("data") ?: throw Exception("Komik tidak ditemukan")
        val a = m.optJSONObject("attributes")

        val genres = mutableListOf<String>()
        a?.optJSONArray("tags")?.let { tags ->
            for (i in 0 until tags.length()) {
                val n = tags.optJSONObject(i)?.optJSONObject("attributes")?.optJSONObject("name")?.str("en").orEmpty()
                if (n.isNotBlank()) genres += n
            }
        }

        val feed = getJson("$MD/manga/$id/feed?translatedLanguage[]=id&order[chapter]=desc&limit=500&includeExternalUrl=0")
        val chapters = mutableListOf<MangaChapterItem>()
        feed.optJSONArray("data")?.let { arr ->
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                val ca = c.optJSONObject("attributes")
                val chNo = ca?.str("chapter").orEmpty()
                val title = ca?.str("title").orEmpty()
                chapters += MangaChapterItem(
                    title = if (title.isNotBlank()) "Ch. $chNo: $title" else "Chapter $chNo",
                    number = chNo.toDoubleOrNull() ?: 0.0,
                    id_chapter = c.str("id"),
                    time = timeAgo(ca?.str("publishAt").orEmpty())
                )
            }
        }

        val statusNum = when (a?.str("status")) {
            "completed" -> 2
            "hiatus" -> 3
            "cancelled" -> 4
            else -> 1
        }
        return MangaDetail(
            title = firstValue(a?.optJSONObject("title"), "en", "id", "ja").ifBlank { "Untitled" },
            id_series = m.str("id"),
            image = coverOf(m),
            synopsis = firstValue(a?.optJSONObject("description"), "id", "en"),
            info = MangaInfo(status = statusNum, rating = null),
            genres = genres,
            chapters = chapters
        )
    }

    suspend fun chapterPages(id: String): MangaChapterPages {
        val j = getJson("$MD/at-home/server/$id")
        val baseUrl = j.str("baseUrl")
        val ch = j.optJSONObject("chapter")
        if (baseUrl.isBlank() || ch == null) throw Exception("Chapter tidak ditemukan")
        val hash = ch.str("hash")
        val files: JSONArray = ch.optJSONArray("dataSaver") ?: JSONArray()
        val images = (0 until files.length()).map { "$baseUrl/data-saver/$hash/${files.getString(it)}" }
        return MangaChapterPages(title = "", id_chapter = id, images = images, next_chapter = null, prev_chapter = null)
    }
}
