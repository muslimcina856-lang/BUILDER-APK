package com.kano.playjv.core.network

import android.util.Log
import com.kano.playjv.BuildConfig
import com.kano.playjv.data.remote.FirebaseAuthApi
import com.kano.playjv.data.remote.FirebaseTokenApi
import com.kano.playjv.data.remote.FirestoreApi
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClient {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    val httpClient: OkHttpClient get() = okHttpClient

    /** Client untuk Coil: menambah Referer/UA untuk gambar MangaDex (sama seperti proxy di worker lama). */
    val imageClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val req = chain.request()
                val host = req.url.host
                if (host.endsWith("mangadex.org") || host.endsWith("mangadex.network")) {
                    chain.proceed(
                        req.newBuilder()
                            .header("Referer", "https://mangadex.org/")
                            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            .build()
                    )
                } else {
                    chain.proceed(req)
                }
            }
            .build()
    }

    private val okHttpClient: OkHttpClient by lazy {
        val builder = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .callTimeout(40, TimeUnit.SECONDS)

        // Diagnostics are debug-only; auth headers and Firebase query keys are redacted.
        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor { message ->
                Log.d("KuroHttp", message.replace(Regex("([?&]key=)[^&\\s]+"), "$1REDACTED"))
            }.apply {
                redactHeader("Authorization")
                redactHeader("Cookie")
                level = HttpLoggingInterceptor.Level.HEADERS
            }
            builder.addInterceptor(logging)
        }
        builder.build()
    }

    val firebaseAuthApi: FirebaseAuthApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://identitytoolkit.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FirebaseAuthApi::class.java)
    }

    val firebaseTokenApi: FirebaseTokenApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://securetoken.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FirebaseTokenApi::class.java)
    }

    val firestoreApi: FirestoreApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://firestore.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FirestoreApi::class.java)
    }

    /**
     * Resolves image URLs: if an image path is relative like "/api/komik-img?url=...",
     * it prepends the API base URL.
     */
    fun resolveImageUrl(rawUrl: String): String {
        if (rawUrl.isBlank()) return ""
        if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
            return rawUrl
        }
        val base = BuildConfig.API_BASE_URL.removeSuffix("/")
        val path = if (rawUrl.startsWith("/")) rawUrl else "/$rawUrl"
        return "$base$path"
    }

    /**
     * Resolves video stream URLs: if proxy stream is needed or direct mp4/hls.
     */
    fun resolveStreamUrl(streamUrl: String): String {
        if (streamUrl.isBlank()) return ""
        if (streamUrl.startsWith("http://") || streamUrl.startsWith("https://")) {
            return streamUrl
        }
        val base = BuildConfig.API_BASE_URL.removeSuffix("/")
        val path = if (streamUrl.startsWith("/")) streamUrl else "/$streamUrl"
        return "$base$path"
    }
}
