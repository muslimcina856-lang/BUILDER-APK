package com.kano.playjv.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KuroDao {
    // Anime History
    @Query("SELECT * FROM anime_history WHERE userUid = :uid ORDER BY timestamp DESC LIMIT 50")
    fun getAnimeHistoryFlow(uid: String): Flow<List<AnimeHistoryEntity>>

    @Query("SELECT * FROM anime_history WHERE userUid = :uid ORDER BY timestamp DESC LIMIT 50")
    suspend fun getAnimeHistory(uid: String): List<AnimeHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimeHistory(item: AnimeHistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAnimeHistory(items: List<AnimeHistoryEntity>)

    @Query("DELETE FROM anime_history WHERE userUid = :uid AND slug NOT IN (SELECT slug FROM anime_history WHERE userUid = :uid ORDER BY timestamp DESC LIMIT 50)")
    suspend fun trimAnimeHistory(uid: String)

    @Query("DELETE FROM anime_history WHERE slug = :slug AND userUid = :uid")
    suspend fun deleteAnimeHistory(slug: String, uid: String)

    @Query("DELETE FROM anime_history WHERE userUid = :uid")
    suspend fun clearAnimeHistory(uid: String)

    // Anime Bookmark
    @Query("SELECT * FROM anime_bookmark WHERE userUid = :uid ORDER BY timestamp DESC")
    fun getAnimeBookmarksFlow(uid: String): Flow<List<AnimeBookmarkEntity>>

    @Query("SELECT * FROM anime_bookmark WHERE userUid = :uid ORDER BY timestamp DESC")
    suspend fun getAnimeBookmarks(uid: String): List<AnimeBookmarkEntity>

    @Query("SELECT EXISTS(SELECT 1 FROM anime_bookmark WHERE slug = :slug AND userUid = :uid)")
    fun isAnimeBookmarkedFlow(slug: String, uid: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimeBookmark(item: AnimeBookmarkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAnimeBookmarks(items: List<AnimeBookmarkEntity>)

    @Query("DELETE FROM anime_bookmark WHERE slug = :slug AND userUid = :uid")
    suspend fun deleteAnimeBookmark(slug: String, uid: String)

    @Query("DELETE FROM anime_bookmark WHERE userUid = :uid")
    suspend fun clearAnimeBookmarks(uid: String)

    // Manga History
    @Query("SELECT * FROM manga_history WHERE userUid = :uid ORDER BY time DESC LIMIT 50")
    fun getMangaHistoryFlow(uid: String): Flow<List<MangaHistoryEntity>>

    @Query("SELECT * FROM manga_history WHERE userUid = :uid ORDER BY time DESC LIMIT 50")
    suspend fun getMangaHistory(uid: String): List<MangaHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMangaHistory(item: MangaHistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMangaHistory(items: List<MangaHistoryEntity>)

    @Query("DELETE FROM manga_history WHERE userUid = :uid AND id_series NOT IN (SELECT id_series FROM manga_history WHERE userUid = :uid ORDER BY time DESC LIMIT 50)")
    suspend fun trimMangaHistory(uid: String)

    @Query("DELETE FROM manga_history WHERE id_series = :idSeries AND userUid = :uid")
    suspend fun deleteMangaHistory(idSeries: String, uid: String)

    @Query("DELETE FROM manga_history WHERE userUid = :uid")
    suspend fun clearMangaHistory(uid: String)

    // Manga Bookmark
    @Query("SELECT * FROM manga_bookmark WHERE userUid = :uid ORDER BY timestamp DESC")
    fun getMangaBookmarksFlow(uid: String): Flow<List<MangaBookmarkEntity>>

    @Query("SELECT * FROM manga_bookmark WHERE userUid = :uid ORDER BY timestamp DESC")
    suspend fun getMangaBookmarks(uid: String): List<MangaBookmarkEntity>

    @Query("SELECT EXISTS(SELECT 1 FROM manga_bookmark WHERE id_series = :idSeries AND userUid = :uid)")
    fun isMangaBookmarkedFlow(idSeries: String, uid: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMangaBookmark(item: MangaBookmarkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMangaBookmarks(items: List<MangaBookmarkEntity>)

    @Query("DELETE FROM manga_bookmark WHERE id_series = :idSeries AND userUid = :uid")
    suspend fun deleteMangaBookmark(idSeries: String, uid: String)

    @Query("DELETE FROM manga_bookmark WHERE userUid = :uid")
    suspend fun clearMangaBookmarks(uid: String)
}
