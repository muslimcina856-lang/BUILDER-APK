package com.kano.playjv.data.repository

import com.kano.playjv.BuildConfig
import com.kano.playjv.core.model.*
import com.kano.playjv.core.network.NetworkClient
import com.kano.playjv.data.local.*
import com.kano.playjv.data.remote.*
import com.kano.playjv.data.source.AnimeKitaSource
import com.kano.playjv.data.source.MangaDexSource
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map

/** Satu halaman daftar anime; [hasNext] false bila tidak ada halaman berikutnya. */
data class AnimePage(val items: List<AnimeItem>, val hasNext: Boolean)

private const val ANIME_PAGE_SIZE = 18
private const val POOL_TTL_MS = 10 * 60_000L

class KuroRepository(
    private val dao: KuroDao,
    private val preferences: UserPreferences,
    private val authRepository: AuthRepository
) {
    private suspend fun getCurrentUid(): String {
        return preferences.userProfileFlow.firstOrNull()?.uid ?: "guest_user"
    }

    suspend fun unlockEpisode(slug: String, ep: String): UnlockResult = authRepository.unlockEpisode(slug, ep)

    suspend fun grantAdKeys(): Result<Int> = authRepository.grantAdKeys()

    // ===== ANIME (AnimeKita, langsung dari aplikasi) =====
    suspend fun getAnimeList(action: String, page: Int = 1): Result<List<AnimeItem>> =
        getAnimePage(mode = action, genre = null, page = page).map { it.items }

    /**
     * Satu halaman anime.
     *  - ongoing: halaman asli dari server
     *  - popular: dari "kolam" anime terbaru, diurutkan berdasarkan skor
     *  - genre   : dari kolam yang sama, difilter di sisi aplikasi (API tidak punya filter genre)
     */
    suspend fun getAnimePage(mode: String, genre: String?, page: Int): Result<AnimePage> {
        return try {
            when {
                genre != null -> {
                    val g = genre.trim()
                    val all = loadPool().filter { a -> a.genre.any { it.equals(g, true) || it.contains(g, true) } }
                    Result.success(slice(all, page))
                }
                mode == "popular" -> {
                    val all = loadPool().sortedByDescending { it.score.toDoubleOrNull() ?: 0.0 }
                    Result.success(slice(all, page))
                }
                else -> {
                    val items = AnimeKitaSource.ongoing(page)
                    val firstUrl = items.firstOrNull()?.url
                    // Jaga-jaga bila server mengembalikan halaman yang sama untuk page berbeda
                    val repeated = page > 1 && firstUrl != null && ongoingFirstUrl[page - 1] == firstUrl
                    if (firstUrl != null) ongoingFirstUrl[page] = firstUrl
                    if (repeated) Result.success(AnimePage(emptyList(), false))
                    else Result.success(AnimePage(items, items.isNotEmpty()))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Gagal memuat anime"))
        }
    }

    private fun slice(all: List<AnimeItem>, page: Int): AnimePage {
        val from = (page - 1) * ANIME_PAGE_SIZE
        if (from >= all.size) return AnimePage(emptyList(), false)
        val to = minOf(from + ANIME_PAGE_SIZE, all.size)
        return AnimePage(all.subList(from, to), to < all.size)
    }

    private val ongoingFirstUrl = ConcurrentHashMap<Int, String>()
    private val metaCache = ConcurrentHashMap<String, AnimeItem>()
    private var pool: List<AnimeItem> = emptyList()
    private var poolAt = 0L
    private val poolMutex = Mutex()

    /** Anime terbaru (3 halaman) + genre & skor, dipakai untuk tab Populer dan filter genre. */
    private suspend fun loadPool(): List<AnimeItem> = poolMutex.withLock {
        if (pool.isNotEmpty() && System.currentTimeMillis() - poolAt < POOL_TTL_MS) return@withLock pool
        val base = coroutineScope {
            (1..3).map { p -> async { runCatching { AnimeKitaSource.ongoing(p) }.getOrDefault(emptyList()) } }
                .awaitAll().flatten()
        }.distinctBy { it.url }
        if (base.isEmpty()) throw Exception("Gagal memuat daftar anime")
        val enriched = coroutineScope {
            base.chunked(6).flatMap { chunk -> chunk.map { async { enrich(it) } }.awaitAll() }
        }
        pool = enriched
        poolAt = System.currentTimeMillis()
        enriched
    }

    /** Melengkapi genre & skor lewat pencarian judul (fallback: halaman detail). */
    private suspend fun enrich(item: AnimeItem): AnimeItem {
        metaCache[item.url]?.let { return it }
        var genres = item.genre
        var score = item.score
        try {
            val found = AnimeKitaSource.search(item.judul, 1, 5)
            val match = found.firstOrNull { it.url == item.url }
                ?: found.firstOrNull { it.judul.equals(item.judul, true) }
            if (match != null) {
                genres = match.genre
                score = match.score
            }
        } catch (_: Exception) {}
        if (genres.isEmpty()) {
            try {
                val d = AnimeKitaSource.detail(item.url)
                genres = d.genre
                if (score == "-" || score.isBlank()) score = d.rating
            } catch (_: Exception) {}
        }
        val result = item.copy(genre = genres, score = score)
        metaCache[item.url] = result
        return result
    }

    suspend fun searchAnime(query: String, page: Int = 1): Result<List<AnimeItem>> {
        return try {
            Result.success(AnimeKitaSource.search(query, page))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Pencarian anime gagal"))
        }
    }

    suspend fun getAnimeDetail(id: String): Result<AnimeDetail> {
        return try {
            Result.success(AnimeKitaSource.detail(id))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Detail anime tidak ditemukan"))
        }
    }

    suspend fun getAnimeStream(channelId: String): Result<EpisodeStreamData> {
        return try {
            Result.success(AnimeKitaSource.episodeStreams(channelId))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Stream tidak ditemukan"))
        }
    }

    // ===== MANGA (MangaDex, langsung dari aplikasi) =====
    suspend fun getLatestManga(): Result<List<MangaItem>> =
        try { Result.success(MangaDexSource.latest()) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Gagal memuat komik terbaru")) }

    suspend fun getPopularManga(): Result<List<MangaItem>> =
        try { Result.success(MangaDexSource.popular()) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Gagal memuat komik populer")) }

    suspend fun getRecommendedManga(): Result<List<MangaItem>> =
        try { Result.success(MangaDexSource.recommended()) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Gagal memuat rekomendasi komik")) }

    suspend fun searchManga(query: String): Result<List<MangaItem>> =
        try { Result.success(MangaDexSource.search(query)) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Pencarian komik gagal")) }

    suspend fun getMangaDetail(idSeries: String): Result<MangaDetail> =
        try { Result.success(MangaDexSource.detail(idSeries)) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Detail komik tidak ditemukan")) }

    suspend fun getMangaChapterPages(idChapter: String): Result<MangaChapterPages> =
        try { Result.success(MangaDexSource.chapterPages(idChapter)) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Halaman chapter tidak ditemukan")) }

    suspend fun getMangaGenres(): Result<List<MangaGenre>> =
        try { Result.success(MangaDexSource.genres()) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Gagal memuat genre")) }

    suspend fun getMangaByGenre(genreId: String): Result<List<MangaItem>> =
        try { Result.success(MangaDexSource.byGenre(genreId)) } catch (e: Exception) { Result.failure(Exception(e.message ?: "Gagal memuat genre komik")) }

    // ===== LOCAL ROOM + FIRESTORE LIBRARY SYNC =====
    fun getAnimeHistoryFlow(uid: String): Flow<List<AnimeHistoryItem>> =
        dao.getAnimeHistoryFlow(uid).map { list -> list.map { it.toModel() } }

    fun getAnimeBookmarksFlow(uid: String): Flow<List<AnimeBookmarkItem>> =
        dao.getAnimeBookmarksFlow(uid).map { list -> list.map { it.toModel() } }

    fun isAnimeBookmarkedFlow(slug: String, uid: String): Flow<Boolean> =
        dao.isAnimeBookmarkedFlow(slug, uid)

    fun getMangaHistoryFlow(uid: String): Flow<List<MangaHistoryItem>> =
        dao.getMangaHistoryFlow(uid).map { list -> list.map { it.toModel() } }

    fun getMangaBookmarksFlow(uid: String): Flow<List<MangaBookmarkItem>> =
        dao.getMangaBookmarksFlow(uid).map { list -> list.map { it.toModel() } }

    fun isMangaBookmarkedFlow(idSeries: String, uid: String): Flow<Boolean> =
        dao.isMangaBookmarkedFlow(idSeries, uid)

    // Library disimpan lokal (Room) dan disinkronkan ke Firestore: users/{uid}/<koleksi>/{id}
    private val fs = NetworkClient.firestoreApi
    private val project = BuildConfig.FIREBASE_PROJECT_ID
    private val docBase get() = "projects/$project/databases/(default)/documents"

    private suspend fun session(): Pair<String, String>? {
        val token = authRepository.getValidToken() ?: return null
        val uid = preferences.userProfileFlow.firstOrNull()?.uid ?: return null
        return uid to "Bearer $token"
    }

    private suspend fun putDoc(collection: String, id: String, fields: Map<String, FsValue>) {
        val (uid, auth) = session() ?: return
        try {
            fs.setDocument(project, "users/$uid/$collection/${fsDocId(id)}", auth, FsDocument(fields = fields))
        } catch (_: Exception) {}
    }

    private suspend fun deleteDoc(collection: String, id: String) {
        val (uid, auth) = session() ?: return
        try {
            fs.commit(
                project, auth,
                FsCommitRequest(listOf(FsWrite(delete = "$docBase/users/$uid/$collection/${fsDocId(id)}")))
            )
        } catch (_: Exception) {}
    }

    private suspend fun clearCollection(collection: String) {
        val (uid, auth) = session() ?: return
        try {
            val docs = fs.listDocuments(project, "users/$uid/$collection", auth).documents.orEmpty()
            docs.mapNotNull { it.name }.chunked(100).forEach { chunk ->
                fs.commit(project, auth, FsCommitRequest(chunk.map { FsWrite(delete = it) }))
            }
        } catch (_: Exception) {}
    }

    private suspend fun listFields(collection: String, uid: String, auth: String): List<Map<String, FsValue>?> =
        fs.listDocuments(project, "users/$uid/$collection", auth).documents.orEmpty().map { it.fields }

    suspend fun recordAnimeHistory(item: AnimeHistoryItem) {
        val uid = getCurrentUid()
        dao.insertAnimeHistory(AnimeHistoryEntity.fromModel(item, uid))
        dao.trimAnimeHistory(uid)
        putDoc(
            "animeHistory", item.slug,
            mapOf(
                "slug" to fsStr(item.slug), "title" to fsStr(item.title), "cover" to fsStr(item.cover),
                "lastEp" to fsStr(item.lastEp), "seriesUrl" to fsStr(item.seriesUrl),
                "timestamp" to fsLong(item.timestamp)
            )
        )
    }

    suspend fun toggleAnimeBookmark(item: AnimeBookmarkItem, isBookmarked: Boolean) {
        val uid = getCurrentUid()
        if (isBookmarked) {
            dao.deleteAnimeBookmark(item.slug, uid)
            deleteDoc("animeBookmarks", item.slug)
        } else {
            dao.insertAnimeBookmark(AnimeBookmarkEntity.fromModel(item, uid))
            putDoc(
                "animeBookmarks", item.slug,
                mapOf(
                    "slug" to fsStr(item.slug), "title" to fsStr(item.title), "cover" to fsStr(item.cover),
                    "timestamp" to fsLong(item.timestamp)
                )
            )
        }
    }

    suspend fun recordMangaHistory(item: MangaHistoryItem) {
        val uid = getCurrentUid()
        dao.insertMangaHistory(MangaHistoryEntity.fromModel(item, uid))
        dao.trimMangaHistory(uid)
        putDoc(
            "mangaHistory", item.id_series,
            mapOf(
                "id_series" to fsStr(item.id_series), "title" to fsStr(item.title), "image" to fsStr(item.image),
                "lastChapter" to fsDouble(item.lastChapter), "id_chapter" to fsStr(item.id_chapter),
                "time" to fsLong(item.time)
            )
        )
    }

    suspend fun toggleMangaBookmark(item: MangaBookmarkItem, isBookmarked: Boolean) {
        val uid = getCurrentUid()
        if (isBookmarked) {
            dao.deleteMangaBookmark(item.id_series, uid)
            deleteDoc("mangaBookmarks", item.id_series)
        } else {
            dao.insertMangaBookmark(MangaBookmarkEntity.fromModel(item, uid))
            putDoc(
                "mangaBookmarks", item.id_series,
                mapOf(
                    "id_series" to fsStr(item.id_series), "title" to fsStr(item.title), "image" to fsStr(item.image),
                    "timestamp" to fsLong(item.timestamp)
                )
            )
        }
    }

    suspend fun syncLibraryFromServer(): Result<Unit> {
        val (uid, auth) = session() ?: return Result.failure(Exception("Belum login"))
        return try {
            val animeHistory = listFields("animeHistory", uid, auth).map { f ->
                AnimeHistoryItem(
                    slug = f.getStr("slug"), title = f.getStr("title"), cover = f.getStr("cover"),
                    lastEp = f.getStr("lastEp"), seriesUrl = f.getStr("seriesUrl"), timestamp = f.getLong("timestamp")
                )
            }.filter { it.slug.isNotBlank() }
            val animeBookmarks = listFields("animeBookmarks", uid, auth).map { f ->
                AnimeBookmarkItem(
                    slug = f.getStr("slug"), title = f.getStr("title"), cover = f.getStr("cover"),
                    timestamp = f.getLong("timestamp")
                )
            }.filter { it.slug.isNotBlank() }
            val mangaHistory = listFields("mangaHistory", uid, auth).map { f ->
                MangaHistoryItem(
                    id_series = f.getStr("id_series"), title = f.getStr("title"), image = f.getStr("image"),
                    lastChapter = f.getDouble("lastChapter"), id_chapter = f.getStr("id_chapter"), time = f.getLong("time")
                )
            }.filter { it.id_series.isNotBlank() }
            val mangaBookmarks = listFields("mangaBookmarks", uid, auth).map { f ->
                MangaBookmarkItem(
                    id_series = f.getStr("id_series"), title = f.getStr("title"), image = f.getStr("image"),
                    timestamp = f.getLong("timestamp")
                )
            }.filter { it.id_series.isNotBlank() }

            dao.insertAllAnimeHistory(animeHistory.map { AnimeHistoryEntity.fromModel(it, uid) })
            dao.trimAnimeHistory(uid)
            dao.insertAllAnimeBookmarks(animeBookmarks.map { AnimeBookmarkEntity.fromModel(it, uid) })
            dao.insertAllMangaHistory(mangaHistory.map { MangaHistoryEntity.fromModel(it, uid) })
            dao.trimMangaHistory(uid)
            dao.insertAllMangaBookmarks(mangaBookmarks.map { MangaBookmarkEntity.fromModel(it, uid) })
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("Gagal sinkron library: ${e.message}"))
        }
    }

    suspend fun deleteAnimeHistory(slug: String) {
        dao.deleteAnimeHistory(slug, getCurrentUid())
        deleteDoc("animeHistory", slug)
    }

    suspend fun deleteMangaHistory(idSeries: String) {
        dao.deleteMangaHistory(idSeries, getCurrentUid())
        deleteDoc("mangaHistory", idSeries)
    }

    suspend fun clearHistory(which: String) {
        val uid = getCurrentUid()
        when (which) {
            "anime" -> {
                dao.clearAnimeHistory(uid)
                clearCollection("animeHistory")
            }
            "manga" -> {
                dao.clearMangaHistory(uid)
                clearCollection("mangaHistory")
            }
            else -> {
                dao.clearAnimeHistory(uid)
                dao.clearMangaHistory(uid)
                clearCollection("animeHistory")
                clearCollection("mangaHistory")
            }
        }
    }
}

data class AnimePage(val items: List<AnimeItem>, val hasNext: Boolean)

private const val ANIME_PAGE_SIZE = 18
private const val POOL_TTL_MS = 10 * 60_000L
