package com.kano.playjv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import coil.Coil
import com.google.android.gms.ads.MobileAds
import com.kano.playjv.core.ads.AdManager
import coil.ImageLoader
import com.kano.playjv.core.network.NetworkClient
import com.kano.playjv.data.local.KuroDatabase
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.AuthRepository
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.navigation.KuroApp
import com.kano.playjv.ui.theme.KuroBgPrimary
import com.kano.playjv.ui.theme.KuroPlayTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        MobileAds.initialize(this) { AdManager.preload(applicationContext) }

        // Gambar MangaDex butuh header Referer
        Coil.setImageLoader(
            ImageLoader.Builder(applicationContext)
                .okHttpClient(NetworkClient.imageClient)
                .build()
        )

        val preferences = UserPreferences(applicationContext)
        val database = KuroDatabase.getDatabase(applicationContext)
        val authRepository = AuthRepository(preferences)
        val kuroRepository = KuroRepository(
            dao = database.kuroDao(),
            preferences = preferences,
            authRepository = authRepository
        )

        setContent {
            KuroPlayTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = KuroBgPrimary
                ) {
                    KuroApp(
                        repository = kuroRepository,
                        authRepository = authRepository,
                        preferences = preferences
                    )
                }
            }
        }
    }
}
