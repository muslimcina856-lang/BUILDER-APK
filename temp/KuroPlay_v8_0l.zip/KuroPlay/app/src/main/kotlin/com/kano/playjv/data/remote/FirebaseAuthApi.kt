package com.kano.playjv.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class FirebaseAuthRequest(
    val email: String,
    val password: String,
    val returnSecureToken: Boolean = true
)

@JsonClass(generateAdapter = true)
data class FirebaseIdpRequest(
    val postBody: String,
    val requestUri: String = "http://localhost",
    val returnIdpCredential: Boolean = true,
    val returnSecureToken: Boolean = true
)

@JsonClass(generateAdapter = true)
data class FirebaseAuthResponse(
    val idToken: String? = null,
    val email: String? = null,
    val refreshToken: String? = null,
    val expiresIn: String? = null,
    val localId: String? = null,
    val isNewUser: Boolean? = null,
    val error: FirebaseAuthErrorContainer? = null
)

@JsonClass(generateAdapter = true)
data class FirebaseAuthErrorContainer(
    val code: Int = 0,
    val message: String = "",
    val errors: List<FirebaseAuthErrorItem>? = null
)

@JsonClass(generateAdapter = true)
data class FirebaseAuthErrorItem(
    val message: String = "",
    val domain: String = "",
    val reason: String = ""
)

@JsonClass(generateAdapter = true)
data class FirebaseRefreshTokenResponse(
    val id_token: String? = null,
    val refresh_token: String? = null,
    val expires_in: String? = null,
    val user_id: String? = null
)

@JsonClass(generateAdapter = true)
data class PasswordResetRequest(
    val requestType: String = "PASSWORD_RESET",
    val email: String
)

@JsonClass(generateAdapter = true)
data class PasswordResetResponse(
    val email: String? = null
)

interface FirebaseAuthApi {

    @POST("v1/accounts:signUp")
    suspend fun signUp(
        @Query("key") apiKey: String,
        @Body body: FirebaseAuthRequest
    ): FirebaseAuthResponse

    @POST("v1/accounts:signInWithPassword")
    suspend fun signIn(
        @Query("key") apiKey: String,
        @Body body: FirebaseAuthRequest
    ): FirebaseAuthResponse

    @POST("v1/accounts:signInWithIdp")
    suspend fun signInWithIdp(
        @Query("key") apiKey: String,
        @Body body: FirebaseIdpRequest
    ): FirebaseAuthResponse

    @POST("v1/accounts:sendOobCode")
    suspend fun resetPassword(
        @Query("key") apiKey: String,
        @Body body: PasswordResetRequest
    ): PasswordResetResponse
}

interface FirebaseTokenApi {
    // securetoken.googleapis.com requires application/x-www-form-urlencoded
    @FormUrlEncoded
    @POST("v1/token")
    suspend fun refreshToken(
        @Query("key") apiKey: String,
        @Field("grant_type") grantType: String = "refresh_token",
        @Field("refresh_token") refreshToken: String
    ): FirebaseRefreshTokenResponse
}
