package com.kano.playjv.core.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom Canvas-drawn mechanical rotating gear with visible teeth and central axle.
 */
@Composable
fun GearIcon(
    modifier: Modifier = Modifier,
    size: Dp = 90.dp,
    gearColor: Color = Color(0xFFD4D4D4),
    accentColor: Color = Color(0xFF888888),
    teethCount: Int = 10,
    rotationDurationMs: Int = 3000
) {
    val infiniteTransition = rememberInfiniteTransition(label = "gear_rotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = rotationDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gear_angle"
    )

    Canvas(
        modifier = modifier
            .size(size)
            .testTag("gear_icon_canvas")
    ) {
        val centerX = this.size.width / 2f
        val centerY = this.size.height / 2f
        val outerRadius = (this.size.minDimension / 2f) * 0.95f
        val rootRadius = outerRadius * 0.78f
        val rimRadius = outerRadius * 0.58f
        val hubRadius = outerRadius * 0.28f
        val holeRadius = outerRadius * 0.16f

        rotate(degrees = angle, pivot = Offset(centerX, centerY)) {
            val gearPath = Path()
            val totalSteps = teethCount * 4
            val angleStep = (2 * PI / totalSteps).toFloat()

            for (i in 0 until totalSteps) {
                val stepType = i % 4
                // 0: rise to tooth tip, 1: tooth tip flat, 2: fall to root, 3: root bottom
                val r = when (stepType) {
                    0, 1 -> outerRadius
                    else -> rootRadius
                }
                val curAngle = i * angleStep
                val x = centerX + r * cos(curAngle)
                val y = centerY + r * sin(curAngle)

                if (i == 0) {
                    gearPath.moveTo(x, y)
                } else {
                    gearPath.lineTo(x, y)
                }
            }
            gearPath.close()

            // Draw solid gear body and teeth
            drawPath(
                path = gearPath,
                color = gearColor,
                style = Fill
            )

            // Draw outer rim outline
            drawPath(
                path = gearPath,
                color = accentColor,
                style = Stroke(width = 2.dp.toPx())
            )

            // Draw central hole cut-out (background color to make it hollow)
            drawCircle(
                color = KuroBgPrimary,
                radius = rimRadius,
                center = Offset(centerX, centerY)
            )

            // Draw 4 mechanical spokes connecting hub to rim
            val spokeWidth = 4.dp.toPx()
            for (s in 0 until 4) {
                val spokeAngle = (s * PI / 2).toFloat()
                val x1 = centerX + hubRadius * cos(spokeAngle)
                val y1 = centerY + hubRadius * sin(spokeAngle)
                val x2 = centerX + rimRadius * cos(spokeAngle)
                val y2 = centerY + rimRadius * sin(spokeAngle)
                drawLine(
                    color = gearColor,
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    strokeWidth = spokeWidth
                )
            }

            // Draw central solid hub
            drawCircle(
                color = gearColor,
                radius = hubRadius,
                center = Offset(centerX, centerY)
            )

            // Draw center axle hole
            drawCircle(
                color = KuroBgPrimary,
                radius = holeRadius,
                center = Offset(centerX, centerY)
            )
            drawCircle(
                color = accentColor,
                radius = holeRadius,
                center = Offset(centerX, centerY),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }
    }
}

/**
 * Reusable GearProgressIndicator with animated percentage (1-100%) and message.
 */
@Composable
fun GearProgressIndicator(
    progress: Int,
    statusText: String = "Memuat data...",
    modifier: Modifier = Modifier,
    size: Dp = 80.dp,
    onCancel: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp)
            .testTag("gear_progress_indicator"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(size + 30.dp)
        ) {
            GearIcon(
                size = size,
                gearColor = KuroTextPrimary,
                accentColor = KuroTextTertiary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "${progress.coerceIn(1, 100)}%",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                letterSpacing = 1.sp
            ),
            color = KuroTextPrimary,
            modifier = Modifier.testTag("gear_progress_percentage")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyMedium,
            color = KuroTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .widthIn(max = 240.dp)
                .testTag("gear_progress_status")
        )

        if (onCancel != null) {
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onCancel,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = KuroTextSecondary
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("gear_progress_cancel_button")
            ) {
                Text("Batal", fontSize = 12.sp)
            }
        }
    }
}

/**
 * State holder that implements the non-linear realistic visual progress simulation:
 * Starts at 1%, climbs progressively, slows down near 95-99% while waiting for network response,
 * and jumps to 100% upon success before smoothly dismissing.
 */
@Composable
fun rememberSimulatedProgress(
    isLoading: Boolean,
    isSuccess: Boolean = false,
    baseDurationMs: Long = 3500L
): State<Int> {
    val progressState = remember { mutableIntStateOf(1) }

    LaunchedEffect(isLoading, isSuccess) {
        if (!isLoading) {
            if (isSuccess) {
                progressState.intValue = 100
                delay(250)
            } else {
                progressState.intValue = 1
            }
            return@LaunchedEffect
        }

        progressState.intValue = 1
        var current = 1
        val startTime = System.currentTimeMillis()

        while (isLoading) {
            val elapsed = System.currentTimeMillis() - startTime
            val fraction = (elapsed.toFloat() / baseDurationMs).coerceIn(0f, 1f)

            // Non-linear easing: fast start, gradual deceleration
            val target = when {
                fraction < 0.2f -> (1 + fraction * 180).toInt() // jumps up to ~37%
                fraction < 0.5f -> (37 + (fraction - 0.2f) * 110).toInt() // up to ~70%
                fraction < 0.8f -> (70 + (fraction - 0.5f) * 60).toInt() // up to ~88%
                else -> (88 + (fraction - 0.8f) * 45).toInt().coerceAtMost(98) // creeps to 98%
            }

            if (target > current) {
                current = target
                progressState.intValue = current
            }
            delay(50)
        }
    }

    return progressState
}

/**
 * Fullscreen modal overlay displaying the GearProgressIndicator.
 */
@Composable
fun GearLoadingOverlay(
    isLoading: Boolean,
    statusText: String = "Memuat...",
    onCancel: (() -> Unit)? = null
) {
    val simulatedProgress = rememberSimulatedProgress(isLoading = isLoading)

    AnimatedVisibility(
        visible = isLoading,
        enter = fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.95f),
        exit = fadeOut(tween(250))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(KuroBgPrimary.copy(alpha = 0.92f))
                .testTag("gear_loading_overlay"),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = KuroSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(KuroBorder)
                ),
                modifier = Modifier
                    .padding(32.dp)
                    .widthIn(min = 220.dp, max = 320.dp)
            ) {
                GearProgressIndicator(
                    progress = simulatedProgress.value,
                    statusText = statusText,
                    onCancel = onCancel
                )
            }
        }
    }
}
