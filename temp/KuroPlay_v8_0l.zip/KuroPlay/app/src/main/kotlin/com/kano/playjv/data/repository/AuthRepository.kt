package com.kano.playjv.data.repository

import android.util.Base64
import com.kano.playjv.BuildConfig
import com.kano.playjv.core.model.PremiumStatus
import com.kano.playjv.core.model.UserProfile
import com.kano.playjv.core.model.UsernameCheckResponse
import com.kano.playjv.core.network.NetworkClient
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.remote.FirebaseAuthRequest
import com.kano.playjv.data.remote.FirebaseAuthResponse
import com.kano.playjv.data.remote.FirebaseIdpRequest
import com.kano.playjv.data.remote.FsCommitRequest
import com.kano.playjv.data.remote.FsDocument
import com.kano.playjv.data.remote.FsMask
import com.kano.playjv.data.remote.FsPrecondition
import com.kano.playjv.data.remote.FsValue
import com.kano.playjv.data.remote.FsWrite
import com.kano.playjv.data.remote.PasswordResetRequest
import com.kano.playjv.data.remote.fsDocId
import com.kano.playjv.data.remote.fsLong
import com.kano.playjv.data.remote.fsStr
import com.kano.playjv.data.remote.getBool
import com.kano.playjv.data.remote.getLong
import com.kano.playjv.data.remote.getStr
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import org.json.JSONObject
import retrofit2.HttpException

const val DEFAULT_KEYS = 3
const val AD_REWARD_KEYS = 3

sealed class UnlockResult {
    object Unlimited : UnlockResult()
    object AlreadyOpen : UnlockResult()
    data class Spent(val left: Int) : UnlockResult()
    object NoKeys : UnlockResult()
    data class Error(val message: String) : UnlockResult()
}

/** Login berhasil, tetapi akun belum punya username/profil di Firestore. */
class NeedUsernameException : Exception("Username diperlukan")

/**
 * Akun aplikasi: Firebase Authentication (REST) + profil di Firestore (REST).
 * Tidak lagi bergantung pada worker Cloudflare.
 */
class AuthRepository(
    private val preferences: UserPreferences
) {
    private val authApi = NetworkClient.firebaseAuthApi
    private val tokenApi = NetworkClient.firebaseTokenApi
    private val fs = NetworkClient.firestoreApi
    private val apiKey = BuildConfig.FIREBASE_API_KEY
    private val project = BuildConfig.FIREBASE_PROJECT_ID
    private val docBase get() = "projects/$project/databases/(default)/documents"
    private val usernameRegex = Regex("^[a-z0-9_]{3,20}$")

    val userProfileFlow: Flow<UserProfile?> = preferences.userProfileFlow

    suspend fun getValidToken(): String? {
        val currentToken = preferences.idTokenFlow.firstOrNull() ?: return null
        val expiry = preferences.tokenExpiryFlow.firstOrNull() ?: 0L
        val now = System.currentTimeMillis()

        // Token masih berlaku > 2 menit
        if (expiry > now + 120_000) return currentToken

        val refreshToken = preferences.refreshTokenFlow.firstOrNull() ?: return currentToken
        return try {
            val response = tokenApi.refreshToken(apiKey = apiKey, refreshToken = refreshToken)
            val newIdToken = response.id_token
            val newRefreshToken = response.refresh_token ?: refreshToken
            val expiresIn = response.expires_in?.toLongOrNull() ?: 3600L
            if (!newIdToken.isNullOrBlank()) {
                preferences.saveAuthTokens(newIdToken, newRefreshToken, expiresIn)
                newIdToken
            } else {
                currentToken
            }
        } catch (e: Exception) {
            currentToken
        }
    }

    // ===== Username =====

    suspend fun checkUsername(username: String): Result<UsernameCheckResponse> {
        val name = username.trim().lowercase()
        if (!usernameRegex.matches(name)) {
            return Result.success(
                UsernameCheckResponse(
                    status = true,
                    available = false,
                    message = "Username 3-20 karakter: huruf kecil, angka, underscore"
                )
            )
        }
        return try {
            fs.getDocument(project, "usernames/$name")
            Result.success(UsernameCheckResponse(status = true, available = false, message = "Username sudah dipakai"))
        } catch (e: HttpException) {
            if (e.code() == 404) {
                Result.success(UsernameCheckResponse(status = true, available = true, message = "Username tersedia"))
            } else {
                Result.failure(friendlyError(e))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ===== Login / daftar =====

    suspend fun login(email: String, pass: String): Result<UserProfile> {
        return try {
            val authRes = authApi.signIn(
                apiKey = apiKey,
                body = FirebaseAuthRequest(email = email.trim().lowercase(), password = pass)
            )
            finishSignIn(authRes, email.trim().lowercase())
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    suspend fun loginWithGoogle(googleIdToken: String): Result<UserProfile> {
        return try {
            val authRes = authApi.signInWithIdp(
                apiKey = apiKey,
                body = FirebaseIdpRequest(postBody = "id_token=$googleIdToken&providerId=google.com")
            )
            finishSignIn(authRes, "")
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    suspend fun register(username: String, email: String, pass: String): Result<UserProfile> {
        return try {
            val name = username.trim().lowercase()
            val chk = checkUsername(name).getOrThrow()
            if (!chk.available) return Result.failure(Exception(chk.message ?: "Username tidak tersedia"))

            val authRes = authApi.signUp(
                apiKey = apiKey,
                body = FirebaseAuthRequest(email = email.trim().lowercase(), password = pass)
            )
            val idToken = authRes.idToken
                ?: return Result.failure(Exception(authRes.error?.message ?: "Registrasi gagal"))
            preferences.saveAuthTokens(idToken, authRes.refreshToken ?: "", authRes.expiresIn?.toLongOrNull() ?: 3600L)

            val uid = authRes.localId ?: jwtClaim(idToken, "user_id")
                ?: return Result.failure(Exception("UID tidak ditemukan"))
            createProfile(uid, authRes.email ?: email.trim().lowercase(), name, idToken)
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    /** Langkah lanjutan untuk akun yang belum punya username (login Google pertama kali, dsb). */
    suspend fun completeProfile(username: String): Result<UserProfile> {
        val token = getValidToken() ?: return Result.failure(Exception("Sesi login tidak ditemukan, ulangi login"))
        val uid = jwtClaim(token, "user_id") ?: return Result.failure(Exception("UID tidak ditemukan"))
        val email = jwtClaim(token, "email") ?: ""
        return try {
            createProfile(uid, email, username.trim().lowercase(), token)
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    suspend fun refreshProfile(): Result<UserProfile> {
        val token = getValidToken() ?: return Result.failure(Exception("Belum login"))
        val uid = jwtClaim(token, "user_id") ?: return Result.failure(Exception("UID tidak ditemukan"))
        return try {
            val profile = loadProfile(uid, token, jwtClaim(token, "email") ?: "")
                ?: return Result.failure(NeedUsernameException())
            preferences.saveUserProfile(profile)
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    suspend fun resetPassword(email: String): Result<Unit> {
        return try {
            authApi.resetPassword(
                apiKey = apiKey,
                body = PasswordResetRequest(email = email.trim().lowercase())
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    suspend fun logout() {
        preferences.clearSession()
    }

    // ===== Internal =====

    private suspend fun finishSignIn(authRes: FirebaseAuthResponse, fallbackEmail: String): Result<UserProfile> {
        val idToken = authRes.idToken
            ?: return Result.failure(Exception(authRes.error?.message ?: "Login gagal: token tidak ditemukan"))
        preferences.saveAuthTokens(idToken, authRes.refreshToken ?: "", authRes.expiresIn?.toLongOrNull() ?: 3600L)

        val uid = authRes.localId ?: jwtClaim(idToken, "user_id")
            ?: return Result.failure(Exception("UID tidak ditemukan"))
        val profile = loadProfile(uid, idToken, authRes.email ?: fallbackEmail)
            ?: return Result.failure(NeedUsernameException())
        preferences.saveUserProfile(profile)
        return Result.success(profile)
    }

    /** Mengambil users/{uid}. Mengembalikan null kalau dokumen belum ada. */
    private suspend fun loadProfile(uid: String, idToken: String, fallbackEmail: String): UserProfile? {
        return try {
            val doc = fs.getDocument(project, "users/$uid", "Bearer $idToken")
            val f = doc.fields
            UserProfile(
                uid = uid,
                username = f.getStr("username"),
                email = f.getStr("email").ifBlank { fallbackEmail },
                isOwner = f.getBool("isOwner"),
                isAdmin = f.getBool("isAdmin"),
                premium = premiumFrom(f),
                keys = if (f?.containsKey("keys") == true) f.getLong("keys").toInt() else DEFAULT_KEYS,
                avatar = f.getStr("avatar").ifBlank { null }
            )
        } catch (e: HttpException) {
            if (e.code() == 404) null else throw e
        }
    }

    private fun premiumFrom(f: Map<String, FsValue>?): PremiumStatus? {
        val v = f?.get("premiumUntil") ?: return null
        val until = v.timestampValue?.let { runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrNull() }
            ?: v.integerValue?.toLongOrNull()
            ?: v.doubleValue?.toLong()
            ?: return null
        val now = System.currentTimeMillis()
        if (until <= now) return null
        return PremiumStatus(
            active = true,
            plan = "premium",
            expiresAt = until,
            daysLeft = ((until - now) / 86_400_000L).toInt()
        )
    }

    // ===== Kunci (user biasa) =====

    /** Profil terbaru dari server; bila gagal, pakai salinan lokal. */
    private suspend fun currentProfile(): UserProfile? =
        refreshProfile().getOrNull() ?: preferences.userProfileFlow.firstOrNull()

    private fun isUnlimited(p: UserProfile): Boolean =
        p.isOwner || (p.premium?.active == true && p.premium.expiresAt > System.currentTimeMillis())

    private val unlockedCache = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /**
     * Dipanggil sebelum episode diputar. Premium/owner: bebas. Episode yang pernah dibuka: gratis.
     * Selain itu memakai 1 kunci.
     */
    suspend fun unlockEpisode(slug: String, ep: String): UnlockResult {
        val profile = currentProfile() ?: return UnlockResult.Error("Belum login")
        if (isUnlimited(profile)) return UnlockResult.Unlimited
        val uid = profile.uid
        val key = "$uid|$slug|$ep"
        if (unlockedCache.contains(key)) return UnlockResult.AlreadyOpen
        val token = getValidToken() ?: return UnlockResult.Error("Sesi habis, silakan login ulang")
        val auth = "Bearer $token"
        val docPath = "users/$uid/unlocked/${fsDocId("$slug|$ep")}"
        try {
            fs.getDocument(project, docPath, auth)
            unlockedCache.add(key)
            return UnlockResult.AlreadyOpen
        } catch (e: HttpException) {
            if (e.code() != 404) return UnlockResult.Error(friendlyError(e).message ?: "Gagal memeriksa kunci")
        } catch (e: Exception) {
            return UnlockResult.Error(friendlyError(e).message ?: "Gagal memeriksa kunci")
        }
        if (profile.keys <= 0) return UnlockResult.NoKeys
        val left = profile.keys - 1
        return try {
            fs.commit(
                project = project,
                auth = auth,
                body = FsCommitRequest(
                    writes = listOf(
                        FsWrite(
                            update = FsDocument(name = "$docBase/users/$uid", fields = mapOf("keys" to fsLong(left.toLong()))),
                            updateMask = FsMask(listOf("keys"))
                        ),
                        FsWrite(
                            update = FsDocument(name = "$docBase/$docPath", fields = mapOf("at" to fsLong(System.currentTimeMillis()))),
                            currentDocument = FsPrecondition(exists = false)
                        )
                    )
                )
            )
            preferences.updateKeys(left)
            unlockedCache.add(key)
            UnlockResult.Spent(left)
        } catch (e: Exception) {
            UnlockResult.Error(friendlyError(e).message ?: "Gagal memakai kunci")
        }
    }

    /** Hadiah iklan: +[AD_REWARD_KEYS] kunci. Mengembalikan saldo baru. */
    suspend fun grantAdKeys(): Result<Int> {
        val profile = currentProfile() ?: return Result.failure(Exception("Belum login"))
        if (isUnlimited(profile)) return Result.success(profile.keys)
        val token = getValidToken() ?: return Result.failure(Exception("Sesi habis, silakan login ulang"))
        val newKeys = profile.keys + AD_REWARD_KEYS
        return try {
            fs.commit(
                project = project,
                auth = "Bearer $token",
                body = FsCommitRequest(
                    writes = listOf(
                        FsWrite(
                            update = FsDocument(
                                name = "$docBase/users/${profile.uid}",
                                fields = mapOf("keys" to fsLong(newKeys.toLong()))
                            ),
                            updateMask = FsMask(listOf("keys"))
                        )
                    )
                )
            )
            preferences.updateKeys(newKeys)
            Result.success(newKeys)
        } catch (e: Exception) {
            Result.failure(friendlyError(e))
        }
    }

    /** Membuat usernames/{name} dan users/{uid} secara atomik. */
    private suspend fun createProfile(uid: String, email: String, name: String, token: String): Result<UserProfile> {
        if (!usernameRegex.matches(name)) {
            return Result.failure(Exception("Username 3-20 karakter: huruf kecil, angka, underscore"))
        }
        val now = System.currentTimeMillis()
        fs.commit(
            project = project,
            auth = "Bearer $token",
            body = FsCommitRequest(
                writes = listOf(
                    FsWrite(
                        update = FsDocument(name = "$docBase/usernames/$name", fields = mapOf("uid" to fsStr(uid))),
                        currentDocument = FsPrecondition(exists = false)
                    ),
                    FsWrite(
                        update = FsDocument(
                            name = "$docBase/users/$uid",
                            fields = mapOf(
                                "username" to fsStr(name),
                                "email" to fsStr(email),
                                "createdAt" to fsLong(now)
                            )
                        ),
                        currentDocument = FsPrecondition(exists = false)
                    )
                )
            )
        )
        val profile = UserProfile(uid = uid, username = name, email = email)
        preferences.saveUserProfile(profile)
        return Result.success(profile)
    }

    private fun jwtClaim(jwt: String, key: String): String? {
        return try {
            val payload = jwt.split(".")[1]
            val json = String(Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP))
            JSONObject(json).optString(key).ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Retrofit melempar HttpException ("HTTP 400") untuk error Firebase/Firestore.
     * Baca body JSON-nya dan terjemahkan ke pesan yang jelas.
     */
    private fun friendlyError(e: Exception): Exception {
        if (e is NeedUsernameException) return e
        if (e is HttpException) {
            val raw = try { e.response()?.errorBody()?.string() } catch (_: Exception) { null }
            val code = raw?.let {
                Regex("\"message\"\\s*:\\s*\"([^\"]+)\"").find(it)?.groupValues?.get(1)
            }
            val msg = when {
                code == null -> when (e.code()) {
                    403 -> "Akses ditolak (403). Cek Firestore Rules / pembatasan API key."
                    404 -> "Data tidak ditemukan (404)."
                    else -> "Kesalahan server (HTTP ${e.code()})"
                }
                code.startsWith("EMAIL_EXISTS") -> "Email sudah terdaftar"
                code.startsWith("INVALID_LOGIN_CREDENTIALS") ||
                    code.startsWith("INVALID_PASSWORD") ||
                    code.startsWith("EMAIL_NOT_FOUND") -> "Email atau password salah"
                code.startsWith("INVALID_EMAIL") -> "Format email tidak valid"
                code.startsWith("WEAK_PASSWORD") -> "Password terlalu lemah (minimal 6 karakter)"
                code.startsWith("USER_DISABLED") -> "Akun dinonaktifkan"
                code.startsWith("TOO_MANY_ATTEMPTS") -> "Terlalu banyak percobaan, coba lagi nanti"
                code.startsWith("OPERATION_NOT_ALLOWED") ->
                    "Metode login ini belum diaktifkan di Firebase Console"
                code.contains("insufficient permissions", ignoreCase = true) ->
                    "Akses database ditolak. Periksa Firestore Rules di Firebase Console."
                code.contains("does not exist", ignoreCase = true) ->
                    "Database Firestore belum dibuat di Firebase Console."
                code.contains("already exists", ignoreCase = true) -> "Username sudah dipakai"
                code.contains("API_KEY") || code.contains("blocked", ignoreCase = true) ->
                    "API key Firebase ditolak (cek pembatasan API key di Google Cloud Console)"
                else -> "Firebase: $code"
            }
            return Exception(msg)
        }
        return e
    }
}
