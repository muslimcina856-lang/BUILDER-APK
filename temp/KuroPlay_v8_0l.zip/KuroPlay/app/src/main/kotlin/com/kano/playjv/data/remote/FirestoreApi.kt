package com.kano.playjv.data.remote

import android.util.Base64
import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

// ===== Model REST Firestore =====

@JsonClass(generateAdapter = true)
data class FsValue(
    val stringValue: String? = null,
    val integerValue: String? = null, // Firestore REST mengirim integer sebagai string
    val timestampValue: String? = null,
    val doubleValue: Double? = null,
    val booleanValue: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class FsDocument(
    val name: String? = null,
    val fields: Map<String, FsValue>? = null
)

@JsonClass(generateAdapter = true)
data class FsListResponse(
    val documents: List<FsDocument>? = null,
    val nextPageToken: String? = null
)

@JsonClass(generateAdapter = true)
data class FsPrecondition(val exists: Boolean)

@JsonClass(generateAdapter = true)
data class FsMask(val fieldPaths: List<String>)

@JsonClass(generateAdapter = true)
data class FsWrite(
    val update: FsDocument? = null,
    val updateMask: FsMask? = null,
    val delete: String? = null,
    val currentDocument: FsPrecondition? = null
)

@JsonClass(generateAdapter = true)
data class FsCommitRequest(val writes: List<FsWrite>)

@JsonClass(generateAdapter = true)
data class FsCommitResponse(val commitTime: String? = null)

interface FirestoreApi {

    @GET("v1/projects/{project}/databases/(default)/documents/{path}")
    suspend fun getDocument(
        @Path("project") project: String,
        @Path("path", encoded = true) path: String,
        @Header("Authorization") auth: String? = null
    ): FsDocument

    /** Upsert: membuat dokumen bila belum ada, mengganti seluruh field bila sudah ada. */
    @PATCH("v1/projects/{project}/databases/(default)/documents/{path}")
    suspend fun setDocument(
        @Path("project") project: String,
        @Path("path", encoded = true) path: String,
        @Header("Authorization") auth: String?,
        @Body body: FsDocument
    ): FsDocument

    @GET("v1/projects/{project}/databases/(default)/documents/{path}")
    suspend fun listDocuments(
        @Path("project") project: String,
        @Path("path", encoded = true) path: String,
        @Header("Authorization") auth: String?,
        @Query("pageSize") pageSize: Int = 300
    ): FsListResponse

    @POST("v1/projects/{project}/databases/(default)/documents:commit")
    suspend fun commit(
        @Path("project") project: String,
        @Header("Authorization") auth: String?,
        @Body body: FsCommitRequest
    ): FsCommitResponse
}

// ===== Helper pembuat & pembaca field =====

fun fsStr(v: String) = FsValue(stringValue = v)
fun fsLong(v: Long) = FsValue(integerValue = v.toString())
fun fsDouble(v: Double) = FsValue(doubleValue = v)
fun fsBool(v: Boolean) = FsValue(booleanValue = v)

fun Map<String, FsValue>?.getStr(key: String): String = this?.get(key)?.stringValue ?: ""
fun Map<String, FsValue>?.getLong(key: String): Long {
    val v = this?.get(key) ?: return 0L
    return v.integerValue?.toLongOrNull() ?: v.doubleValue?.toLong() ?: 0L
}
fun Map<String, FsValue>?.getDouble(key: String): Double {
    val v = this?.get(key) ?: return 0.0
    return v.doubleValue ?: v.integerValue?.toDoubleOrNull() ?: 0.0
}
fun Map<String, FsValue>?.getBool(key: String): Boolean = this?.get(key)?.booleanValue ?: false

/** ID dokumen Firestore tidak boleh berisi "/", jadi ID asli di-encode (URL-safe Base64). */
fun fsDocId(raw: String): String =
    Base64.encodeToString(raw.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
