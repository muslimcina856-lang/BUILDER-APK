package com.kano.playjv.ui.manga

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.kano.playjv.core.components.ErrorStateView
import com.kano.playjv.core.components.GearProgressIndicator
import com.kano.playjv.core.model.MangaChapterPages
import com.kano.playjv.core.model.MangaHistoryItem
import com.kano.playjv.data.local.UserPreferences
import com.kano.playjv.data.repository.KuroRepository
import com.kano.playjv.ui.theme.*
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

@Composable
fun MangaReaderScreen(
    idSeries: String,
    idChapter: String,
    chapterTitle: String,
    repository: KuroRepository,
    preferences: UserPreferences,
    onBack: () -> Unit,
    onNavigateToChapter: (newChapterId: String, newTitle: String) -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    var chapterPages by remember { mutableStateOf<MangaChapterPages?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Reading mode: "VERTICAL" or "PAGED"
    var readingMode by remember { mutableStateOf("VERTICAL") }
    var isControlsVisible by remember { mutableStateOf(true) }

    val coroutineScope = rememberCoroutineScope()

    // Load preferred reading mode from DataStore
    LaunchedEffect(Unit) {
        val savedMode = preferences.mangaReaderModeFlow.firstOrNull() ?: "VERTICAL"
        readingMode = savedMode
    }

    fun loadPages() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res = repository.getMangaChapterPages(idChapter)
            if (res.isSuccess) {
                val pages = res.getOrNull()
                if (pages != null && pages.images.isNotEmpty()) {
                    chapterPages = pages
                    // Record history in Room
                    val num = chapterTitle.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 1.0
                    repository.recordMangaHistory(
                        MangaHistoryItem(
                            id_series = idSeries,
                            title = chapterTitle,
                            image = "",
                            lastChapter = num,
                            id_chapter = idChapter,
                            time = System.currentTimeMillis()
                        )
                    )
                } else {
                    errorMessage = "Halaman chapter tidak ditemukan"
                }
                isLoading = false
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Gagal memuat chapter"
                isLoading = false
            }
        }
    }

    LaunchedEffect(idChapter) {
        loadPages()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("manga_reader_container")
    ) {
        if (isLoading && chapterPages == null) {
            GearProgressIndicator(
                progress = 70,
                statusText = "Memuat halaman chapter...",
                modifier = Modifier.align(Alignment.Center)
            )
        } else if (errorMessage != null && chapterPages == null) {
            ErrorStateView(
                message = errorMessage ?: "Terjadi kesalahan",
                onRetry = { loadPages() },
                modifier = Modifier.align(Alignment.Center)
            )
        } else if (chapterPages != null) {
            val pages = chapterPages!!

            // Reader content: Vertical or Paged
            if (readingMode == "VERTICAL") {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { isControlsVisible = !isControlsVisible }
                        .testTag("manga_reader_vertical_list")
                ) {
                    itemsIndexed(pages.images, key = { index, url -> "$index-$url" }) { index, imgUrl ->
                        MangaImageItem(
                            imageUrl = imgUrl,
                            pageNumber = index + 1,
                            total = pages.images.size
                        )
                    }
                }
            } else {
                val pagerState = rememberPagerState(pageCount = { pages.images.size })
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { isControlsVisible = !isControlsVisible }
                        .testTag("manga_reader_horizontal_pager")
                ) { pageIndex ->
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        MangaImageItem(
                            imageUrl = pages.images[pageIndex],
                            pageNumber = pageIndex + 1,
                            total = pages.images.size,
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            // Top Bar Overlay
            AnimatedVisibility(
                visible = isControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(onClick = onBack) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Kembali",
                                    tint = Color.White
                                )
                            }
                            Text(
                                text = chapterTitle,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        // Mode switcher: Vertical vs Paged
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = KuroSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                            modifier = Modifier
                                .clickable {
                                    val newMode = if (readingMode == "VERTICAL") "PAGED" else "VERTICAL"
                                    readingMode = newMode
                                    coroutineScope.launch {
                                        preferences.setMangaReaderMode(newMode)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (readingMode == "VERTICAL") Icons.Default.ViewStream else Icons.Default.ViewCarousel,
                                    contentDescription = "Mode Baca",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (readingMode == "VERTICAL") "Vertikal" else "Per Halaman",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Bar Overlay (Next / Prev Chapter)
            AnimatedVisibility(
                visible = isControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KuroBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${pages.images.size} Halaman",
                            color = KuroTextSecondary,
                            fontSize = 12.sp
                        )

                        Text(
                            text = "KuroPlay Reader",
                            color = KuroTextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MangaImageItem(
    imageUrl: String,
    pageNumber: Int,
    total: Int,
    contentScale: ContentScale = ContentScale.FillWidth
) {
    var retryTrigger by remember { mutableIntStateOf(0) }

    SubcomposeAsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(imageUrl)
            .setParameter("retry", retryTrigger)
            .crossfade(true)
            .build(),
        contentDescription = "Halaman $pageNumber dari $total",
        contentScale = contentScale,
        loading = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(KuroSurface),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = KuroTextTertiary,
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        error = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(KuroSurface)
                    .clickable { retryTrigger++ },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Coba Lagi",
                        tint = KuroTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Gagal memuat hal $pageNumber. Ketuk untuk coba lagi",
                        color = KuroTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .testTag("manga_page_$pageNumber")
    )
}
