package com.kano.playjv.core.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

// Anime Models
@JsonClass(generateAdapter = true)
data class AnimeItem(
    val judul: String = "",
    val cover: String = "",
    val url: String = "",
    val lastch: String = "",
    val type: String = "TV",
    val status: String = "",
    val score: String = "-",
    val rating: String = "-",
    val sinopsis: String = "",
    val genre: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AnimeEpisode(
    val ch: String = "",
    val url: String = "" // e.g. "epId|seriesUrl|epUrl|epNum"
)

@JsonClass(generateAdapter = true)
data class AnimeDetail(
    val judul: String = "",
    val cover: String = "",
    val sinopsis: String = "",
    val rating: String = "-",
    val type: String = "TV",
    val status: String = "",
    val published: String = "",
    val series_id: String = "",
    val genre: List<String> = emptyList(),
    val chapter: List<AnimeEpisode> = emptyList()
)

@JsonClass(generateAdapter = true)
data class StreamSource(
    val name: String = "",
    val link: String = ""
)

@JsonClass(generateAdapter = true)
data class EpisodeStreamData(
    val title: String = "",
    val streams: Map<String, List<StreamSource>> = emptyMap()
)

// Manga Models
@JsonClass(generateAdapter = true)
data class MangaLatestChapter(
    val chapter: String = "",
    val id_chapter: String = "",
    val releaseTime: String = ""
)

@JsonClass(generateAdapter = true)
data class MangaItem(
    val title: String = "",
    val id_series: String = "",
    val image: String = "",
    val latestChapters: List<MangaLatestChapter> = emptyList()
)

@JsonClass(generateAdapter = true)
data class MangaChapterItem(
    val title: String = "",
    val number: Double = 0.0,
    val id_chapter: String = "",
    val time: String = ""
)

@JsonClass(generateAdapter = true)
data class MangaInfo(
    val status: Int? = 1,
    val rating: Double? = null
)

@JsonClass(generateAdapter = true)
data class MangaDetail(
    val title: String = "",
    val id_series: String = "",
    val image: String = "",
    val synopsis: String = "",
    val info: MangaInfo? = null,
    val genres: List<String> = emptyList(),
    val chapters: List<MangaChapterItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class MangaChapterPages(
    val title: String = "",
    val id_chapter: String = "",
    val images: List<String> = emptyList(),
    val next_chapter: String? = null,
    val prev_chapter: String? = null
)

@JsonClass(generateAdapter = true)
data class MangaGenre(
    val id: String = "",
    val name: String = ""
)

// Auth & User Profile
@JsonClass(generateAdapter = true)
data class PremiumStatus(
    val active: Boolean = false,
    val plan: String? = null,
    val expiresAt: Long = 0,
    val daysLeft: Int = 0,
    val owner: Boolean = false
)

@JsonClass(generateAdapter = true)
data class UserProfile(
    val uid: String = "",
    val username: String = "",
    val email: String = "",
    val isOwner: Boolean = false,
    val isAdmin: Boolean = false,
    val premium: PremiumStatus? = null,
    val keys: Int = 0,
    val avatar: String? = null
)

// Premium & Keys
@JsonClass(generateAdapter = true)
data class PremiumPlan(
    val id: String = "",
    val label: String = "",
    val days: Int = 30,
    val price: Int = 0,
    val pricePerMonth: Int = 0
)

@JsonClass(generateAdapter = true)
data class CreateOrderResponse(
    val status: Boolean = false,
    val orderId: String = "",
    val plan: String = "",
    val planLabel: String = "",
    val amount: Int = 0,
    val paymentUrl: String = "",
    val qrisPayload: String = "",
    val qrisImage: String = "",
    val expiredAt: Long = 0,
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class CheckOrderResponse(
    val status: Boolean = false,
    val orderStatus: String = "pending", // success, pending, expired
    val premium: PremiumStatus? = null,
    val expiredAt: Long? = null,
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class KeyBalance(
    val status: Boolean = false,
    val keys: Int? = null,
    val premiumActive: Boolean = false
)

@JsonClass(generateAdapter = true)
data class UseKeyResponse(
    val status: Boolean = false,
    val free: Boolean = false,
    val premium: Boolean = false,
    val code: String? = null,
    val message: String? = null,
    val keys: Int = 0,
    val used: Int = 0
)

// Library
@JsonClass(generateAdapter = true)
data class AnimeHistoryItem(
    val slug: String = "",
    val title: String = "",
    val cover: String = "",
    val lastEp: String = "",
    val seriesUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class AnimeBookmarkItem(
    val slug: String = "",
    val title: String = "",
    val cover: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class MangaHistoryItem(
    val id_series: String = "",
    val title: String = "",
    val image: String = "",
    val lastChapter: Double = 0.0,
    val id_chapter: String = "",
    val time: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class MangaBookmarkItem(
    val id_series: String = "",
    val title: String = "",
    val image: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class LibraryData(
    val history: List<AnimeHistoryItem> = emptyList(),
    val bookmarks: List<AnimeBookmarkItem> = emptyList(),
    val mangaHistory: List<MangaHistoryItem> = emptyList(),
    val mangaBookmarks: List<MangaBookmarkItem> = emptyList()
)

// Generic API Response Wrappers
@JsonClass(generateAdapter = true)
data class BaseApiResponse<T>(
    val status: Boolean = false,
    val message: String? = null,
    val data: T? = null
)

@JsonClass(generateAdapter = true)
data class UsernameCheckResponse(
    val status: Boolean = false,
    val available: Boolean = false,
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class AuthMeResponse(
    val status: Boolean = false,
    val user: UserProfile? = null,
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class PlansResponse(
    val status: Boolean = false,
    val plans: List<PremiumPlan> = emptyList(),
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class StatusResponse(
    val status: Boolean = false,
    val premium: PremiumStatus? = null,
    val keys: Int? = null,
    val message: String? = null
)
