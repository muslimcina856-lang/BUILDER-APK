package com.kano.playjv.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AnimeHistoryEntity::class,
        AnimeBookmarkEntity::class,
        MangaHistoryEntity::class,
        MangaBookmarkEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KuroDatabase : RoomDatabase() {
    abstract fun kuroDao(): KuroDao

    companion object {
        @Volatile
        private var INSTANCE: KuroDatabase? = null

        fun getDatabase(context: Context): KuroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KuroDatabase::class.java,
                    "kuroplay_database"
                ).fallbackToDestructiveMigration(dropAllTables = false).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
