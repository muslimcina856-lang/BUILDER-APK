# KuroPlay — AndroidIDE project

Aplikasi Android Native berbasis Kotlin dan Jetpack Compose untuk streaming anime dan membaca manga.

## Identitas aplikasi
- Nama aplikasi: **KuroPlay**
- Application ID / package: `com.kano.playjv`
- API base URL: `https://kano-streaming.pages.dev/`

## Build di AndroidIDE
1. Ekstrak ZIP.
2. Buka folder `KuroPlay` sebagai project yang sudah ada.
3. Pastikan JDK 17, Android SDK Platform 36, serta Build Tools yang sesuai tersedia.
4. Sinkronkan Gradle; koneksi internet diperlukan untuk mengunduh dependency yang belum tersimpan.
5. Jalankan task `:app:assembleDebug`.

Dependensi Compose dikelola lewat BOM agar versi Compose UI dan Material 3 tetap selaras. Lihat `MERGE_NOTES.md` untuk detail penggabungan dan catatan yang belum bisa diverifikasi di lingkungan ini.
